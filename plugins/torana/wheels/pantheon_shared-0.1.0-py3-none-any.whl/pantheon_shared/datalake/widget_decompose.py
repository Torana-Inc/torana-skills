"""Widget row decomposition — the rows an aggregate cell was computed FROM.

A dashboard widget that groups collapses many records into one displayed row.
Clicking that row should reveal what it collapsed. This module answers, from the
widget's own SQL alone: *which records constitute this row, and which columns
make up each number in it?*

⛔ WHY THIS IS A REWRITE OF THE WIDGET'S SQL, NOT A QUERY AGAINST THE BASE TABLE
-------------------------------------------------------------------------------
`WIDGET_IMPROVEMENTS_SPEC.md` § 3.3 designed a drill as
`SELECT * FROM <source_table> WHERE <displayed column> = <clicked value>`, and
§ 0.2 records that it was REMOVED before shipping. It could not work: a widget's
displayed columns are frequently aliased or computed (`CASE … AS fixability`), so
filtering the base table by the displayed NAME errors with
`column "fixability" does not exist`.

This takes the other route. The widget's SQL already contains the exact relation
its aggregate was computed over, so we keep that relation verbatim — the same
FROM, the same JOINs, the same WHERE — and remove only the aggregation. No
displayed alias is ever referenced, so the failure that killed the original
approach cannot arise.

⭐ THE PROJECTION — three parts, and the third is not optional
--------------------------------------------------------------
    A. the GROUP BY keys                      (what identifies the clicked row)
    B. every column INSIDE an aggregate       (what the numbers are made of)
    C. the driving table's PRIMARY KEY        (what makes the rows distinct)

⚠️ C exists because of a measured bug. An earlier version projected A+B under
`SELECT DISTINCT`, reasoning that the distinct tuple IS the unit being counted.
That holds for `COUNT(DISTINCT col)` and is catastrophically wrong for `COUNT(*)`:

    widget:    SELECT severity, COUNT(*) FROM vulnerabilities GROUP BY severity
    cell:      Medium = 50,810
    A+B DISTINCT decomposition  ->       1 row      ⛔ off by 50,809
    A+B+C, no DISTINCT          ->  50,810 rows     ✅

`COUNT(*)` has no argument column, so without the primary key there is nothing in
the projection that differs between two constituent rows. Hence: **never
`DISTINCT`, always project the key.** The detail set is the pre-aggregation row
set, exactly.

⚠️ ROW COUNT AND METRIC VALUE ARE DIFFERENT NUMBERS, and the caller must show
both. Measured on a live tenant, a widget grouping (severity, package_manager)
with `COUNT(DISTINCT cve_id)`: the cell reads **218** while the constituent rows
number **45,993**. Both are correct — the metric counts distinct CVEs, the rows
are findings. A panel that shows only the row count next to a cell reading 218
looks broken. Use `reconciliation_sql()` to recompute each metric over the detail
set and display the derivation.

⛔ WHY RECONCILIATION IS SQL AND NOT PYTHON
-------------------------------------------
Recomputing `COUNT(DISTINCT …)` / `MAX(…)` in Python would be a second
implementation of SQL aggregate semantics — NULL handling, DISTINCT, collation —
and it would drift from the first one silently. The database that produced the
cell recomputes it.

This module issues no queries and holds no opinion about rows. It reads SQL and
returns SQL. Fetching, binding and paging are the caller's job.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Dict, Iterable, List, Mapping, Optional, Tuple

import sqlglot
from sqlglot import exp

# Decomposition kinds. `GROUPED` and `UNGROUPED` are both decomposable; the other
# two are not, for different reasons the UI must word differently.
KIND_GROUPED = "grouped"          # GROUP BY present — pin the clicked keys
KIND_UNGROUPED = "ungrouped"      # aggregate, no GROUP BY (a scalar) — whole population
KIND_NOT_AGGREGATE = "not_aggregate"   # each displayed row is already one record
KIND_UNSUPPORTED = "unsupported"       # could not be parsed/rewritten safely

_DIALECT = "postgres"

#: Identifier-safe fallback for a GROUP BY key that is an expression rather than a
#: bare column (e.g. ``DATE_TRUNC('month', ts)``), which has no natural name.
_SYNTHETIC_KEY = "group_key_{i}"


@dataclass(frozen=True)
class Metric:
    """One aggregate in the widget's SELECT — a number in the clicked row."""

    alias: str
    """Displayed column name (``image_count``)."""

    expression: str
    """The aggregate as written (``COUNT(DISTINCT v.torana_artifact_id)``)."""

    arg_columns: Tuple[str, ...]
    """Columns inside the aggregate. Empty for ``COUNT(*)`` — which is exactly
    why the projection also carries a primary key."""


@dataclass(frozen=True)
class Projection:
    """One output column of the detail query."""

    expression: str
    """As written in the widget's SQL (``v.torana_artifact_id``)."""

    alias: str
    """Output name, unqualified and de-duplicated. `reconciliation_sql` rewrites
    metric expressions onto these, so they must be stable and collision-free."""

    role: str
    """``key`` | ``metric_arg`` | ``row_identity`` — lets the UI group columns."""


@dataclass(frozen=True)
class Decomposition:
    """The result of analysing one widget's SQL."""

    kind: str
    sql: Optional[str] = None
    """Parameterised detail SQL, pyformat (``%(cve_id)s``) — bind, never format."""

    params: Tuple[str, ...] = ()
    """Parameter names, each taken from the clicked row by the same name."""

    group_keys: Tuple[str, ...] = ()
    metrics: Tuple[Metric, ...] = ()
    projection: Tuple[Projection, ...] = ()
    reason: Optional[str] = None
    """Why this is not decomposable. Set only for the two non-decomposable kinds;
    it is written to be shown to a user verbatim."""

    warnings: Tuple[str, ...] = ()
    """Non-fatal caveats the UI should surface (e.g. no primary key available)."""

    @property
    def decomposable(self) -> bool:
        return self.kind in (KIND_GROUPED, KIND_UNGROUPED)


def _aggregates(select: exp.Select) -> List[Tuple[str, exp.AggFunc]]:
    """Aggregates in the SELECT list, EXCLUDING window functions.

    ⚠️ `COUNT(*) OVER (PARTITION BY …)` is an `AggFunc` to sqlglot but is NOT a
    grouping aggregate — it produces one value per ROW, so there is nothing to
    decompose and treating it as a metric would invent a grouping that the query
    does not have.

    ⚠️ A ``FILTER (WHERE …)`` clause is part of the metric, not decoration.
    sqlglot models it as a `Filter` NODE WRAPPING the `AggFunc`, so returning the
    bare `AggFunc` silently drops the predicate: `COUNT(*) FILTER (WHERE is_kev)`
    becomes `COUNT(*)`. MEASURED 2026-09-08 on `vulnerabilities_by_team` — four
    differently-filtered metrics all reconciled to the same 1,396, which reads as
    "the numbers are wrong" when in fact the recomputation was. The wrapping
    `Filter` is returned whenever there is one.
    ⛔ ONE METRIC PER OUTPUT COLUMN, never one per aggregate. A column can wrap
    SEVERAL aggregates in a single expression:

        ROUND(100.0 * COUNT(*) FILTER (WHERE NOT is_sla_breached)
              / NULLIF(COUNT(*), 0), 1) AS sla_compliance_pct

    Emitting a Metric per AggFunc produced `sla_compliance_pct` TWICE, each
    carrying only a fragment, and reconciliation then recomputed a raw count
    (1058) and compared it against a percentage (72.9) — reporting a MISMATCH on
    a widget whose arithmetic was correct (MEASURED 2026-09-08:
    100.0*1058/1451 = 72.9). A panel whose job is to say which number to trust
    must never accuse a healthy widget. The whole column expression is the
    metric, recomputed exactly as written.
    """
    out: List[Tuple[str, exp.Expression]] = []
    for item in select.expressions:
        aggs = [a for a in item.find_all(exp.AggFunc)
                if a.find_ancestor(exp.Window) is None
                # ⛔ AN AGGREGATE INSIDE A SUBQUERY IS NOT THIS SELECT'S
                # AGGREGATE. `find_all` descends into scalar subqueries, so a
                # correlated
                #     (SELECT COUNT(*) FROM prioritized_vulnerabilities pv
                #      WHERE date_trunc('week', pv.scan_first_detected_date)
                #            = w.week_start) AS arrivals
                # looked like an aggregate of the OUTER select. Stripping it
                # hoisted `pv.scan_first_detected_date` into a scope where `pv`
                # does not exist, and Postgres refused the whole detail query
                # with `missing FROM-clause entry for table "pv"`.
                # MEASURED 2026-09-09 on `arrival_vs_closure_weekly` (both T2
                # and Classie): the drill-down was dead on every widget built
                # this way.
                # ⚠️ The subquery has its OWN FROM and its own aliases; the outer
                # query cannot reach them. Such a column is not decomposable
                # from here, so it must not be reported as a metric at all.
                and a.find_ancestor(exp.Subquery) is None]
        if not aggs:
            continue
        # Unwrap `expr AS name` so the metric is the EXPRESSION itself.
        expr = item.this if isinstance(item, exp.Alias) else item
        # A bare aggregate keeps its FILTER wrapper; anything compound is taken
        # whole, so the arithmetic between its aggregates survives.
        if len(aggs) == 1:
            filt = aggs[0].find_ancestor(exp.Filter)
            single = filt if filt is not None else aggs[0]
            if single.sql() == expr.sql():
                expr = single
        out.append((item.alias_or_name, expr))
    return out


def _key_name(key: exp.Expression, select: exp.Select, index: int) -> str:
    """A parameter name for one GROUP BY key.

    A bare column names itself. An expression key (``DATE_TRUNC('month', ts)``)
    has no name of its own, so we take the alias of the matching SELECT item —
    which is what the clicked row is keyed by — and fall back to a positional
    synthetic name only when nothing matches.
    """
    if isinstance(key, exp.Column):
        return key.name
    key_sql = key.sql(dialect=_DIALECT)
    for item in select.expressions:
        target = item.this if isinstance(item, exp.Alias) else item
        if target.sql(dialect=_DIALECT) == key_sql:
            name = item.alias_or_name
            if name:
                return name
    return _SYNTHETIC_KEY.format(i=index)


def _unique_alias(base: str, taken: set) -> str:
    """A collision-free output name. Two source tables can both project
    `severity`; the second becomes `severity_2` so `reconciliation_sql` can still
    address each unambiguously."""
    base = re.sub(r"\W", "_", base) or "col"
    if base not in taken:
        taken.add(base)
        return base
    i = 2
    while f"{base}_{i}" in taken:
        i += 1
    alias = f"{base}_{i}"
    taken.add(alias)
    return alias


def _driving_table(select: exp.Select) -> Tuple[Optional[str], Optional[str]]:
    """(table_name, alias) of the FROM relation.

    ⭐ RESOLVES THROUGH A CTE. A bare `FROM <table>` answers directly. When the
    FROM names a CTE defined in this query's own WITH clause, the CTE is followed
    to the real relation it reads, and the ALIAS returned is the CTE's — the
    detail query still selects `FROM <cte>`, so the projected identity column must
    be qualified by the name in scope there, not by the underlying table's.

    ⛔ WHY THIS IS NOT COSMETIC. Returning (None, None) for a CTE meant no primary
    key resolved, and a `COUNT(*)` widget (whose metric contributes no argument
    columns) then projected ONLY its GROUP BY keys — drilling "2 externally
    reachable services" returned two rows each containing just that label, with no
    service key. Every widget in the EM bundles is CTE-driven, so this was the
    common case rather than an edge one.

    Resolution stops at the first hop that is not a single plain table: a CTE
    whose FROM is itself a subquery, a join, or another CTE returns (None, None)
    rather than guessing which side carries identity. A wrong identity column is
    worse than a stated absence, because the caller's "no primary key" warning is
    what tells the reader the rows may not be distinguishable.
    """
    frm = select.find(exp.From)
    if frm is None:
        return None, None
    src = frm.this
    if not isinstance(src, exp.Table):
        return None, None

    name = src.name
    alias = src.alias or src.name

    with_ = select.find(exp.With)
    if with_ is not None:
        for cte in with_.expressions:
            if cte.alias != name:
                continue
            inner = cte.this
            if not isinstance(inner, exp.Select):
                return None, None
            inner_frm = inner.find(exp.From)
            if inner_frm is None or not isinstance(inner_frm.this, exp.Table):
                return None, None
            # The CTE's own FROM may name another CTE; only a real table resolves.
            inner_name = inner_frm.this.name
            if any(c.alias == inner_name for c in with_.expressions):
                return None, None
            # Alias stays the CTE's — the detail query still reads FROM the CTE.
            return inner_name, alias

    return name, alias


def _projects_column(select: exp.Select, relation: Optional[str], col: str) -> bool:
    """Can `relation.col` actually be selected in this query?

    ⛔ A RESOLVED PRIMARY KEY IS NOT AUTOMATICALLY REACHABLE. `_driving_table`
    follows a CTE to the table underneath, but the CTE stands between that table
    and the detail query: if the CTE does not project the key column, selecting it
    raises `column does not exist` and the whole drill-down fails — strictly worse
    than the "no primary key" warning it was meant to replace. A bare `FROM
    <table>` always reaches every column, so only the CTE case is inspected.

    `SELECT *` counts as projecting everything.
    """
    if relation is None:
        return False
    with_ = select.find(exp.With)
    if with_ is None:
        return True                      # plain table — every column reachable
    cte = next((c for c in with_.expressions if c.alias == relation), None)
    if cte is None:
        return True                      # not a CTE — plain table
    inner = cte.this
    if not isinstance(inner, exp.Select):
        return False
    for item in inner.expressions:
        if isinstance(item, exp.Star):
            return True
        if isinstance(item, exp.Column) and item.name == col:
            return True
        if isinstance(item, exp.Alias) and item.alias == col:
            return True
    return False


def _resolve_ordinal_keys(
    keys: List[exp.Expression],
    tree: exp.Select,
) -> List[exp.Expression]:
    """Replace ``GROUP BY 1`` with the SELECT expression it points at.

    ⚠️ MEASURED (2026-09-08, tenant T2): ``critical_age_buckets`` is written
    ``GROUP BY 1`` over a ``CASE … END AS age_bucket``. Left as a literal, the key
    is the integer ``1`` — which is not a column, cannot be bound from the clicked
    row, and would emit ``WHERE 1 = %(param)s``: valid SQL that filters nothing and
    silently returns the WHOLE population as the "rows behind" one bucket.

    Postgres ordinals are 1-based and index the SELECT list. An alias
    (``expr AS name``) is unwrapped to the underlying expression, because the alias
    does not exist yet at the point the rewritten WHERE is applied.

    Out-of-range or non-integer entries are returned unchanged; the caller then
    treats them exactly as any other expression key.
    """
    if not keys:
        return keys
    selects = list(tree.expressions or [])
    out: List[exp.Expression] = []
    for key in keys:
        resolved = key
        if isinstance(key, exp.Literal) and not key.args.get("is_string"):
            try:
                pos = int(key.name)
            except (TypeError, ValueError):
                pos = 0
            if 1 <= pos <= len(selects):
                target = selects[pos - 1]
                resolved = target.this if isinstance(target, exp.Alias) else target
                resolved = resolved.copy()
        out.append(resolved)
    return out


def _not_aggregate_reason(tree: exp.Select, dialect: str = _DIALECT) -> str:
    """Why this widget's rows cannot be opened — two different answers.

    ⛔ THE DEFAULT WORDING IS FALSE FOR ONE OF THEM. "Each row it shows is already
    a single record" is right for a row-level table (`SELECT ... FROM stalled_tickets`),
    and plainly wrong for a widget whose every row IS an aggregate — just of a
    different population:

        SELECT 'Repositories',     (SELECT COUNT(*) FROM allrepo)      UNION ALL
        SELECT 'Container images', (SELECT COUNT(*) FROM images)       UNION ALL
        SELECT 'Assets',           (SELECT COUNT(*) FROM assets)

    MEASURED on Classie ("What we found in your environment"). A reader looking at
    seven counts is told none of them is a count. Both cases are equally
    un-decomposable — there is no shared row set to open — but saying so wrongly
    costs trust in the one panel whose whole job is to be trustworthy.

    ⚠️ SAY WHAT THEY ARE LOOKING AT, not why the machinery cannot act. Two
    earlier drafts explained the mechanism — "not slices of one population", then
    "each row counts a different kind of thing" — and both read as riddles,
    because a reader does not arrive wondering about populations. They arrive
    wanting records. Name the widget for what it is (a summary of several
    different things), say plainly there is nothing to open, and point at the
    numbers that ARE there. ⛔ The last sentence is a promise the UI must keep:
    it is only true because the panel renders the widget's own rows underneath.

    The tell is an aggregate that exists but sits inside a SUBQUERY rather than in
    the SELECT list, so `_aggregates` (which reads the SELECT list only) finds
    none.
    """
    nested = [a for a in tree.find_all(exp.AggFunc)
              if a.find_ancestor(exp.Window) is None]
    if nested:
        # ⛔ NAME THE WIDGET'S OWN RELATIONS. This sentence used to hardcode
        # "repositories, images, assets", so a severity rollup was told it
        # summarised repositories and images — a confident, wrong explanation of
        # a refusal the reader cannot otherwise diagnose. Read the relations out
        # of the SQL, and say the generic thing when none can be named.
        names: List[str] = []
        for t in tree.find_all(exp.Table):
            n = t.name
            if n and n not in names:
                names.append(n)
        if names:
            shown = ", ".join(names[:3])
            return (f"This widget is a summary of several different things — "
                    f"{shown} — so there is nothing to open. "
                    f"The numbers it shows are below.")
        return ("This widget is a summary of several different things, so there "
                "is nothing to open. The numbers it shows are below.")
    return ("This widget does not aggregate — each row it shows is already "
            "a single record.")


def _union_data_branch(tree: exp.Union) -> Optional[exp.Select]:
    """The single aggregating branch of a UNION, or None.

    ⭐ WHY. A widget commonly reads `<real query> UNION ALL <empty-state row>` so
    the panel renders a message instead of a blank when there is no data. sqlglot
    parses that as `exp.Union`, not `exp.Select`, and the whole widget was refused
    with "Only a SELECT can be broken down" — the empty-state branch, whose only
    job is cosmetic, blocked the drill-down of the branch that has the rows.

    ⛔ ONLY WHEN EXACTLY ONE BRANCH AGGREGATES. A `UNION ALL` of several real
    aggregating branches (the "summary of several different things" shape) has no
    single population behind a clicked row, and silently drilling the first branch
    would answer a question the user did not ask. Ambiguity returns None so the
    caller refuses, which is the honest outcome.

    A branch of literals (the empty-state row) contributes no aggregate and is
    ignored. Nested UNIONs are flattened, so a three-way UNION with one real
    branch still resolves.
    """
    branches: List[exp.Expression] = []

    def _flatten(node: exp.Expression) -> None:
        if isinstance(node, exp.Union):
            _flatten(node.left)
            _flatten(node.right)
        else:
            branches.append(node)

    _flatten(tree)
    aggregating = [b for b in branches
                   if isinstance(b, exp.Select) and _aggregates(b)]
    return aggregating[0] if len(aggregating) == 1 else None


def decompose_widget_sql(
    sql: str,
    primary_keys: Optional[Mapping[str, str]] = None,
    dialect: str = _DIALECT,
    pin_keys: bool = True,
) -> Decomposition:
    """Analyse a widget's SQL and build the detail query behind one clicked row.

    Args:
        sql: the widget's own ``sql_command``.
        primary_keys: ``{table_name: pk_column}``. Supplied by the caller — this
            module issues no queries, so it cannot look one up. A table absent
            from the map simply yields no row-identity column plus a warning.
        dialect: sqlglot dialect; the placeholder style follows from it
            (postgres renders ``%(name)s``).

    Returns:
        A `Decomposition`. Check `.decomposable` before using `.sql`.
    """
    primary_keys = primary_keys or {}

    try:
        tree = sqlglot.parse_one(sql, dialect=dialect)
    except Exception as exc:  # noqa: BLE001 — any parse failure is one outcome
        return Decomposition(
            kind=KIND_UNSUPPORTED,
            reason=f"This widget's SQL could not be parsed, so its rows cannot be "
                   f"broken down ({exc.__class__.__name__}).",
        )

    if isinstance(tree, exp.Union):
        tree = _union_data_branch(tree) or tree

    if not isinstance(tree, exp.Select):
        return Decomposition(
            kind=KIND_UNSUPPORTED,
            reason="Only a SELECT can be broken down into the rows behind it.",
        )

    aggs = _aggregates(tree)
    if not aggs:
        return Decomposition(
            kind=KIND_NOT_AGGREGATE,
            reason=_not_aggregate_reason(tree, dialect),
        )

    group = tree.args.get("group")
    keys: List[exp.Expression] = list(group.expressions) if group else []
    keys = _resolve_ordinal_keys(keys, tree)

    metrics: List[Metric] = []
    arg_columns: List[exp.Column] = []
    seen_args: set = set()
    for alias, agg in aggs:
        cols: List[str] = []
        for col in agg.find_all(exp.Column):
            csql = col.sql(dialect=dialect)
            cols.append(csql)
            if csql not in seen_args:
                seen_args.add(csql)
                arg_columns.append(col.copy())
        metrics.append(Metric(
            alias=alias,
            expression=agg.sql(dialect=dialect),
            arg_columns=tuple(cols),
        ))

    warnings: List[str] = []

    # C — row identity. Without it, constituent rows of a COUNT(*) are
    # indistinguishable from one another (see the module docstring).
    table, table_alias = _driving_table(tree)
    pk_col: Optional[exp.Column] = None
    if table and table in primary_keys and _projects_column(
            tree, table_alias, primary_keys[table]):
        pk_col = exp.column(primary_keys[table], table=table_alias)
    else:
        warnings.append(
            "No primary key is available for this widget's source, so rows that "
            "differ only in columns outside the projection will look identical."
        )

    taken: set = set()
    projection: List[Projection] = []
    selected: List[exp.Expression] = []

    def _add(node: exp.Expression, role: str,
             prefer: Optional[str] = None) -> None:
        node_sql = node.sql(dialect=dialect)
        if any(p.expression == node_sql for p in projection):
            return
        # ⛔ NEVER NAME A COLUMN AFTER ITS SQL. `_unique_alias` replaces every
        # non-word character with `_`, so an EXPRESSION key became a column header
        # reading `COALESCE_NULLIF_asset_environment_________unlabelled___`
        # (MEASURED on Classie, "Publicly-accessible assets"). The widget already
        # gave that expression a name — `environment` — and `prefer` is how the
        # caller passes it in. Falls back to the old behaviour only when there is
        # no name to prefer, which is better than inventing one.
        base = prefer or (node.name if isinstance(node, exp.Column) else node_sql)
        alias = _unique_alias(base, taken)
        projection.append(Projection(expression=node_sql, alias=alias, role=role))
        selected.append(exp.alias_(node.copy(), alias))

    if pk_col is not None:
        _add(pk_col, "row_identity")
    for i, key in enumerate(keys):
        # The clicked row is keyed by the DISPLAYED name, and so is the bound
        # parameter — so the projected column must use it too, or the detail
        # table shows a header nobody can match to the chart.
        _add(key, "key", prefer=_key_name(key, tree, i))
    for col in arg_columns:
        _add(col, "metric_arg")

    detail = tree.copy()
    # ⚠️ HAVING goes too: the clicked group already satisfied it, so re-applying it
    # to individual rows filters on a group predicate that no single row can meet.
    # ORDER BY / LIMIT chose WHICH aggregate rows to display — irrelevant once one
    # is pinned, and a LIMIT left in place would silently truncate the detail set.
    for arg in ("group", "order", "limit", "having", "distinct", "offset"):
        detail.set(arg, None)
    detail.set("expressions", selected)

    # ⭐ `pin_keys=False` answers a DIFFERENT question: not "the rows behind this
    # cell" but "the rows behind this WIDGET" — the whole population, no group key
    # pinned. The header Explore button asks that; a chart-slice click does not.
    # The projection and metrics are unchanged, so the caller still learns what the
    # widget aggregates and over which columns.
    params: List[str] = []
    if pin_keys:
        for i, key in enumerate(keys):
            name = _key_name(key, tree, i)
            params.append(name)
            detail = detail.where(
                exp.EQ(this=key.copy(), expression=exp.Placeholder(this=name)),
                copy=False,
            )

    return Decomposition(
        kind=KIND_GROUPED if keys else KIND_UNGROUPED,
        sql=detail.sql(dialect=dialect),
        params=tuple(params),
        # ⛔ THE BINDABLE NAME, never the raw SQL. `group_keys` used to emit the
        # expression verbatim, so a widget grouping on
        # `COALESCE(NULLIF(package_manager, ''), '(unknown)')` handed that whole
        # string to callers as the key. The FE then built
        # `?COALESCE(NULLIF(package_manager,%20''),%20'(unknown)')=npm`, the
        # server looked for a param named `package_manager`, and every drill on
        # such a widget failed with "the clicked row is missing the value(s) this
        # widget groups by" (MEASURED on Classie, where the bundles wrap most
        # group keys this way — it affected nearly every widget).
        # `params` already carried the right name (the SELECT alias); this makes
        # the two agree so a caller cannot pick the wrong one.
        group_keys=tuple(params) if pin_keys else tuple(
            _key_name(k, tree, i) for i, k in enumerate(keys)),
        metrics=tuple(metrics),
        projection=tuple(projection),
        warnings=tuple(warnings),
    )


def reconciliation_sql(
    decomposition: Decomposition,
    dialect: str = _DIALECT,
) -> Optional[str]:
    """SQL that recomputes every metric over the detail set.

    Wraps the detail query and re-applies each aggregate to its own projected
    columns, so the caller can assert the recomputed value equals the number the
    widget displayed. Returns ``_detail_rows`` alongside the metrics, because the
    two are different numbers and the UI must show both.

    ⛔ The comparison is the point: it verifies the REWRITE. If a recomputed
    metric disagrees with the displayed cell, the decomposition is wrong and the
    UI must say so rather than present the rows as an explanation.
    """
    if not decomposition.decomposable or not decomposition.sql:
        return None

    by_expression = {p.expression: p.alias for p in decomposition.projection}
    outer: List[str] = ["COUNT(*) AS _detail_rows"]

    for metric in decomposition.metrics:
        try:
            node = sqlglot.parse_one(metric.expression, dialect=dialect)
        except Exception:  # noqa: BLE001
            continue
        # Rewrite each column reference onto the detail query's output alias: the
        # subquery erases table qualifiers, so `v.torana_artifact_id` is only
        # addressable as the name it was projected under.
        def _rewrite(node: exp.Expression) -> exp.Expression:
            if isinstance(node, exp.Column):
                alias = by_expression.get(node.sql(dialect=dialect))
                if alias:
                    return exp.column(alias)
            return node

        rewritten = node.transform(_rewrite)
        outer.append(
            f"{rewritten.sql(dialect=dialect)} AS "
            f"{_quote_ident(metric.alias, dialect)}"
        )

    return (
        "SELECT " + ", ".join(outer) + "\nFROM (\n"
        + decomposition.sql + "\n) AS _detail"
    )


def sink_table_primary_keys() -> Dict[str, str]:
    """``{table_name: primary_key_column}`` for every sink table.

    ⭐ The `primary_keys` argument of `decompose_widget_sql` exists so this module
    issues no I/O — but every caller then needs the same map, and three callers
    hand-rolling it is three chances to disagree about what identifies a row. The
    schemas already declare it, so read it from there once.

    Best-effort per table: a schema whose `primary_key` cannot be read is omitted
    rather than raising, because a decomposition WITHOUT a row identity is still
    useful (it warns) while a failed import would take out the whole endpoint.
    """
    from . import schemas as _schemas

    out: Dict[str, str] = {}
    for name in getattr(_schemas, "__all__", []):
        cls = getattr(_schemas, name, None)
        if not isinstance(cls, type) or name == "TableSchema":
            continue
        try:
            inst = cls()
            table = getattr(inst, "table_name", None)
            pk = getattr(inst, "primary_key", None)
            if table and pk:
                out[str(table)] = str(pk)
        except Exception:      # noqa: BLE001 — one bad schema must not break the map
            continue
    return out


def primary_keys_with_transformers(
    transformers: Optional[Iterable[Mapping]] = None,
) -> Dict[str, str]:
    """`sink_table_primary_keys()` plus a row identity for TRANSFORMER outputs.

    ⭐ WHY THIS EXISTS. The base map is built from ``schemas.__all__`` — 18 sink
    tables. A transformer output has no schema class, so it is structurally absent,
    and a decomposition over one therefore projects NO row identity. Measured on
    EM-BundleFix-3 (2026-09-08): every one of 22 widgets reads a transformer, so
    *every* ``COUNT(*)`` decomposition produced ``SELECT FROM <table> WHERE …`` — a
    correct total with zero columns behind it, which renders as a working panel
    showing nothing.

    ⛔ NEVER MUTATE THE BASE MAP. `sink_table_primary_keys()` derives from
    module-level schema classes shared by every request in this worker; mutating
    its result would leak one tenant's transformer keys into every later request in
    that process. This copies, and a real sink schema always wins over a
    transformer of the same name (`setdefault`).

    ⚠️ ``unique_key`` is a JSON LIST (``transformer.py:52``) and may be
    multi-column; the projection needs ONE stable column, so the first element is
    taken. A composite key whose first column is not unique on its own degrades row
    identity but never correctness — the caller still emits the same
    "no primary key" warning it emits for an unknown table.

    Args:
        transformers: transformer records as returned by
            ``GET /api/v1/transformers`` — each needs ``destination_table`` and
            ``unique_key``. Anything missing either is skipped silently.
    """
    out = dict(sink_table_primary_keys())
    for t in transformers or ():
        try:
            table = t.get("destination_table")
            uk = t.get("unique_key")
        except AttributeError:      # not a mapping — skip rather than raise
            continue
        if not table or not uk:
            continue
        col = uk[0] if isinstance(uk, (list, tuple)) else uk
        if col:
            out.setdefault(str(table), str(col))
    return out


def _quote_ident(name: str, dialect: str) -> str:
    """Quote an output alias so a metric named e.g. `count` cannot collide with a
    keyword. Goes through sqlglot so the quoting matches the target dialect."""
    return exp.to_identifier(name, quoted=True).sql(dialect=dialect)
