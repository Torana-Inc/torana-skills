"""The decoration SQL generator — the ONLY component that emits decoration statements.

Design: ``DECORATION_LAYER_SPEC.md`` § 3.6.5 (the generator contract, rules G1–G14),
§ 3.6.7 (retraction) and § 3.8.1 (the provenance guards).

> **Do not hand-write decoration SQL anywhere else, and do not paste statements into
> the spec.** Earlier revisions of the design maintained three statements by hand;
> every one drifted from the registry as it grew — two outputs went missing for four
> rounds, the DERIVE apply lost its guard, the CTE wrapper landed on one statement and
> not the other. Statements are *derived*; only the rules are authored.

Three pure callables, no I/O:

    build_apply(decoration)                  -> (sql, sink_columns_written)
    build_retraction(decoration, attribute)  -> (sql, sink_columns_written)
    build_guard(decoration, column)          -> bare predicate fragment

Parameters are bound (``%(name)s``, psycopg style); the only interpolated values are
identifiers and literals taken from the registry — never from user input or fact data.
"""

from __future__ import annotations

from pantheon_shared.datalake.decorations import (
    DECORATIONS,
    PROVENANCE_COLUMN,
    PROVENANCE_PREFIX,
    VERSION_COLUMN,
    Kind,
    Mode,
    decorated_columns,
    lower_ranked,
    sink_columns,
)

__all__ = [
    "build_apply",
    "build_retraction",
    "build_guard",
    "may_write",
    "unescape_guard",
    "stamp_for",
    "fallback_targets",
    "SinkColumnTypes",
]


# Sink column types the generator must cast fact text into. `decoration_facts.value`
# is jsonb; G2 extracts it to TEXT, so every SUBSTITUTE write needs an explicit cast
# back to the sink column's type or Postgres rejects the assignment.
#
# Derived from the live schema at import time rather than hardcoded, so a schema
# change cannot silently desynchronise the cast.
SinkColumnTypes = dict[str, str]

_CAST_OVERRIDES = {
    # Postgres spells these differently from the datalake's schema vocabulary.
    "TIMESTAMP": "timestamp",
    "DECIMAL": "numeric",
    "NUMERIC": "numeric",
    "INTEGER": "integer",
    "BIGINT": "bigint",
    "BOOLEAN": "boolean",
    "DATE": "date",
}


def _sink_cast(data_type: str) -> str:
    """Map a datalake schema ``data_type`` to the cast the apply must emit."""
    base = data_type.split("(")[0].strip().upper()
    return _CAST_OVERRIDES.get(base, "text")


def _sink_types(table: str) -> SinkColumnTypes:
    """Column -> cast target for one sink, read from the live schema.

    Uses the same table->schema map ``meta.py`` maintains, so a schema change
    cannot silently desynchronise the cast (and a new sink table only has to be
    registered in one place).
    """
    from pantheon_shared.datalake.schemas import (
        AssetsSchema, ArtifactsSchema, ControlsSchema, DatastoresSchema,
        FindingsSchema, IdentitySchema, IssuesSchema, PackagesSchema,
        RepositoriesSchema, VulnerabilitySchema,
    )

    table_map = {
        "assets": AssetsSchema,
        "artifacts": ArtifactsSchema,
        "controls": ControlsSchema,
        "datastores": DatastoresSchema,
        "findings": FindingsSchema,
        "identities": IdentitySchema,
        "issues": IssuesSchema,
        "packages": PackagesSchema,
        "repositories": RepositoriesSchema,
        "vulnerabilities": VulnerabilitySchema,
    }
    cls = table_map.get(table)
    if cls is None:
        raise KeyError(
            f"{table!r} has no registered schema — add it here and to "
            "meta.py's _TABLE_MAP before decorating it"
        )
    return {
        col: _sink_cast(
            defn.get("data_type", "VARCHAR") if isinstance(defn, dict) else str(defn)
        )
        for col, defn in cls().get_full_schema().items()
    }


def stamp_for(decoration: str) -> str:
    """The provenance stamp this decoration writes: ``decoration:<name>``."""
    return f"{PROVENANCE_PREFIX}{decoration}"


# ── G5 / § 3.8.1 — the guards ────────────────────────────────────────────────

def build_guard(decoration: str, column: str) -> str:
    """The bare predicate deciding whether this decoration may write ``column``.

    **One helper, used by BOTH the apply job and the ingest borrow path** — the
    drift between two implementations of "may I write this?" is exactly what
    § 3.7.1 exists to prevent, and the Python mirror (``may_write``) is checked
    against this fragment branch-for-branch by test 40.

    Emits **three** clauses for FILL (G5):

    * ``r.<col> IS NULL``            — nothing there yet
    * own stamp                       — OURS: newer facts supersede. **Not optional**:
      without it a tightened 7→3 day SLA reports success and changes nothing.
    * lower-ranked stamps             — a higher-ranked decoration may displace a
      lower-ranked *decoration's* value, never an observed one.

    The third clause is **elided entirely** when ``lower_ranked()`` is empty —
    ``IN ()`` is a Postgres syntax error (``syntax error at or near ")"``), not an
    empty set, and would send the job to ``abandoned`` for an unrelated reason.

    OVERRIDE additionally accepts a legacy ``cve_enrich`` stamp (the frozen copy
    this layer replaces) and a NULL provenance (all pre-layer rows). It never
    accepts a genuine scanner id with a stored value — § 2.6.

    .. warning::
       The returned fragment is **psycopg-escaped** (``LIKE 'decoration:%%'``),
       because it is embedded in statements executed with bind parameters. To
       evaluate it standalone — as test 40's guard harness does — pass it through
       :func:`unescape_guard` first, or psycopg will read the ``%%`` literally.
    """
    spec = DECORATIONS[decoration]
    out = spec.provides[column]
    mine = stamp_for(decoration)
    beneath = lower_ranked(decoration, column)

    if out.mode is Mode.OVERRIDE:
        clauses = [
            f"r.{PROVENANCE_COLUMN} IS NULL",
            f"r.{PROVENANCE_COLUMN} = 'cve_enrich'",
            # `%%` not `%`: these statements are executed through psycopg with bind
            # parameters, where a bare `%` is parsed as a placeholder and raises
            # `TypeError: dict is not a sequence` before Postgres ever sees the SQL.
            # Caught by executing the generated statement, not by reading it.
            f"r.{PROVENANCE_COLUMN} LIKE '{PROVENANCE_PREFIX}%%'",
            # A stamped row with no value is not an observation.
            f"r.{column} IS NULL",
        ]
    else:
        clauses = [
            f"r.{column} IS NULL",
            f"r.{PROVENANCE_COLUMN} = '{mine}'",
        ]
        if beneath:
            listed = ", ".join(f"'{stamp_for(d)}'" for d in beneath)
            clauses.append(f"r.{PROVENANCE_COLUMN} IN ({listed})")

    return "(" + " OR ".join(clauses) + ")"


def unescape_guard(fragment: str) -> str:
    """Turn a psycopg-escaped guard back into plain SQL.

    Needed only when evaluating a guard **standalone** (``SELECT <guard>`` against a
    fixture, as test 40 does) rather than embedding it in a parameterised statement.
    """
    return fragment.replace("%%", "%")


def may_write(
    decoration: str,
    column: str,
    *,
    provenance: str | None,
    current_value: object,
) -> bool:
    """Python mirror of :func:`build_guard`, for the ingest borrow path.

    Kept beside the SQL deliberately: § 3.7.1's two write paths must agree, and the
    only way to keep them agreeing is to define them together and test them against
    each other (test 40 evaluates ``build_guard`` in Postgres and this function in
    Python across the same fixture matrix).
    """
    spec = DECORATIONS[decoration]
    out = spec.provides[column]
    mine = stamp_for(decoration)

    if out.mode is Mode.OVERRIDE:
        return (
            provenance is None
            or provenance == "cve_enrich"
            or provenance.startswith(PROVENANCE_PREFIX)
            or current_value is None
        )

    if current_value is None:
        return True
    if provenance == mine:
        return True
    beneath = {stamp_for(d) for d in lower_ranked(decoration, column)}
    return provenance in beneath


# ── G1–G11, G14 — the apply ──────────────────────────────────────────────────

def build_apply(decoration: str) -> tuple[str, frozenset[str]]:
    """Generate the full apply statement for one decoration.

    Returns ``(sql, sink_columns_written)`` where ``sink_columns_written`` is
    **definitionally** ``frozenset(provides)`` (G11) — stated positively because an
    exclusion list ("everything in the SET minus the bookkeeping columns") shipped
    the same off-by-one twice.

    Bind parameters: ``%(tenant)s``, ``%(namespace)s``, ``%(source_version)s``.
    ``source_version`` is the value **captured at claim time**, never a fresh read —
    a producer landing newer facts mid-apply must not have them stamped by this job.
    """
    spec = DECORATIONS[decoration]
    sink = spec.decorates
    types = _sink_types(sink)
    stamp = stamp_for(decoration)

    # ── G3 + G2: ONE pre-aggregated pivot per decoration, keyed on subject_key.
    # Pre-aggregation is what keeps the join 1:1 — an un-aggregated join fans the
    # sink out 1→N. `value #>> '{}'` extracts the jsonb SCALAR to text: `->> 'attr'`
    # returns NULL for a scalar (reproducing the very bug this layer removes), and
    # `max(jsonb)` does not exist, so extraction must precede aggregation.
    attributes: list[str] = []
    for out in spec.provides.values():
        if out.attribute not in attributes:
            attributes.append(out.attribute)

    pivot_cols = ",\n         ".join(
        f"max(value #>> '{{}}') FILTER (WHERE attribute = '{attr}') AS {attr}"
        for attr in attributes
    )

    # `global` facts are stored under tenant_id='' — identical for every tenant.
    fact_tenant = "''" if spec.scope == "global" else "%(tenant)s"

    # ── G1 + G4 + G6 + G7: one guarded SET clause per declared column.
    # G7: every branch reads `r.<col>` / `ci.<attr>` — pre-update values. Postgres
    # evaluates all SET expressions against the OLD row, so a clause referencing a
    # column this same statement assigns would silently read the stale value.
    set_parts: list[str] = []
    guards: list[str] = []
    for column, out in spec.provides.items():
        guard = build_guard(decoration, column)

        if out.kind is Kind.SUBSTITUTE:
            cast = types.get(column, "text")
            value = f"ci.{out.attribute}::{cast}"
            # The fact must be present for this column to be written at all.
            full_guard = f"(ci.{out.attribute} IS NOT NULL AND {guard})"
        else:
            # G6: the non-NULL guard covers `requires`, NOT `reads`. `reads` is
            # lineage; `requires` is the subset without which the expr yields NULL.
            # Guarding on `reads` INVERTS the breach column — its COALESCE exists
            # precisely to handle a NULL due date, so a reads-guard would write it
            # only where a due date already exists, reviving constant-FALSE
            # is_sla_breached.
            value = out.expr.format(fact=f"ci.{out.attribute}", row="r")
            needed = [f"r.{c} IS NOT NULL" for c in out.requires]
            full_guard = " AND ".join(
                [f"ci.{out.attribute} IS NOT NULL", *needed, guard]
            )
            full_guard = f"({full_guard})"

        guards.append(full_guard)
        set_parts.append(
            f"{column} = CASE WHEN {full_guard} THEN {value} ELSE r.{column} END"
        )

    # ── G8: the stamp is written when this decoration wrote ANY of its columns —
    # the DISJUNCTION, for both modes. A conjunction was wrong and contradicted G12:
    # a policy-only row whose due date came from the scanner but whose breach date
    # policy DID write would get no stamp, leaving it permanently unretractable.
    wrote_any = "(" + "\n            OR ".join(guards) + ")"

    set_parts.append(
        f"{PROVENANCE_COLUMN} = CASE WHEN {wrote_any} THEN '{stamp}' "
        f"ELSE r.{PROVENANCE_COLUMN} END"
    )
    set_parts.append(
        f"{VERSION_COLUMN} = CASE WHEN {wrote_any} THEN %(source_version)s "
        f"ELSE r.{VERSION_COLUMN} END"
    )
    set_parts.append("updated_at = now()")

    set_sql = ",\n         ".join(set_parts)

    # ── G9 + G10: the CTE wrapper makes the sink write and `applied_version` ONE
    # statement, so they can never be observed disagreeing — a crash between them
    # would otherwise leave the backstop re-enqueuing this tenant every tick forever.
    # `rows_updated` comes from `RETURNING counted.n`: the OUTER statement is
    # `UPDATE decoration_status`, which affects exactly one row, so the driver's own
    # rowcount would report 1 for a 4,633-row refresh — and would break the event
    # suppression rule, since a no-op and a real apply would both report 1.
    #
    # G14: the sink-side WHERE always scopes namespace and excludes soft-deleted
    # rows. Jobs are keyed per-namespace, so without it one namespace's job
    # decorates another's rows and stamps applied_version for work it did not scope.
    sql = f"""\
WITH ci AS (
  SELECT subject_key,
         {pivot_cols}
    FROM decoration_facts
   WHERE decoration = '{decoration}'
     AND tenant_id = {fact_tenant}
     AND is_deleted IS NOT TRUE
   GROUP BY subject_key),
updated AS (
  UPDATE {sink} r
     SET {set_sql}
    FROM ci
   WHERE ci.subject_key = r.{spec.subject_column}
     AND r.tenant_id = %(tenant)s
     AND r.namespace_id = %(namespace)s
     AND r.is_deleted IS NOT TRUE
  RETURNING 1),
counted AS (SELECT count(*) AS n FROM updated)
UPDATE decoration_status s
   SET applied_version = %(source_version)s,
       last_success_at = now(),
       updated_at = now()
  FROM counted
 WHERE s.decoration = '{decoration}'
   AND s.tenant_id = %(tenant)s
   AND s.namespace_id = %(namespace)s
RETURNING counted.n AS rows_updated"""

    # G11: definitionally the declared outputs. Not "the SET minus a list".
    return sql, sink_columns(decoration)


# ── G12, G13 — the retraction ────────────────────────────────────────────────

def fallback_targets(decoration: str, attribute: str) -> tuple[tuple[str, str], ...]:
    """``((column, next_lower_decoration), …)`` for the SHARED columns this
    retraction clears.

    G13: the caller must enqueue each of these at a **FRESH generation**. ``job_key``
    is ``decoration|tenant|namespace|generation``, so enqueuing at the *current*
    generation collides with the job that already succeeded — the insert is a no-op,
    no work runs, and the row keeps the NULL the retraction just wrote. The failure
    is invisible: no error, no failed job, and the backstop keys on
    ``source_version``/``applied_version``, neither of which moved.

    Cannot recurse: only the next-lower claimant is returned, and that job is an
    ordinary apply which retracts nothing. The chain terminates in one step by
    construction, not by a depth guard.
    """
    spec = DECORATIONS[decoration]
    targets: list[tuple[str, str]] = []
    for column, out in spec.provides.items():
        if out.attribute != attribute:
            continue
        beneath = lower_ranked(decoration, column)
        if beneath:
            targets.append((column, beneath[0]))
    return tuple(targets)


def build_retraction(decoration: str, attribute: str) -> tuple[str, frozenset[str]]:
    """Generate the reversal statement for one retracted attribute.

    A fact that is deleted must un-decorate its rows. Without this the layer
    reproduces its own § 1.2 complaint: CISA de-lists a CVE, the fact is retracted,
    and every row keeps ``cisa_kev_data`` set while every dashboard keeps counting it.

    G12 — two scoping rules, both of which were got wrong before:

    * Clears **only** the retracted attribute's own column(s).
    * Clears the stamp **only** when ``<no_value_remains>`` across **every** decorated
      column on the relation — all decorations, not just this one. Clearing it while
      any decorated value survives makes that value permanently unretractable (its own
      retraction would fail the ``LIKE 'decoration:%'`` guard) and freely overwritable.

    ``LIKE 'decoration:%'`` in the WHERE is what makes reversal safe: a row whose
    value came from Tenable or SARIF is untouched, because the layer never wrote it.

    **No CTE wrapper (G9).** An apply makes a tenant current with its facts, so
    advancing ``applied_version`` is correct; a retraction *withdraws* facts, and
    marking the tenant current for facts just removed would make the fallback job
    that must still run look unnecessary to the backstop.
    """
    spec = DECORATIONS[decoration]
    sink = spec.decorates

    cleared = tuple(
        col for col, out in spec.provides.items() if out.attribute == attribute
    )
    if not cleared:
        raise KeyError(
            f"{decoration!r} declares no column fed by attribute {attribute!r}"
        )

    # <no_value_remains>: EVERY decorated column on this relation except the ones
    # being cleared. An earlier revision tested only the OTHER decoration's columns,
    # so an ordinary single-decoration row cleared its stamp while cisa_kev_data
    # survived — the corruption the rule exists to prevent, relocated not removed.
    survivors = [c for c in decorated_columns(sink) if c not in cleared]
    no_value_remains = (
        "(" + " AND ".join(f"r.{c} IS NULL" for c in survivors) + ")"
        if survivors else "TRUE"
    )

    set_parts = [f"{c} = NULL" for c in cleared]
    set_parts.append(
        f"{PROVENANCE_COLUMN} = CASE WHEN {no_value_remains} THEN NULL "
        f"ELSE r.{PROVENANCE_COLUMN} END"
    )
    set_parts.append(
        f"{VERSION_COLUMN} = CASE WHEN {no_value_remains} THEN NULL "
        f"ELSE r.{VERSION_COLUMN} END"
    )
    set_parts.append("updated_at = now()")

    fact_tenant = "''" if spec.scope == "global" else "%(tenant)s"

    # A LOWER-ranked retraction must not clear a HIGHER-ranked value: a `policy`
    # retraction of vulnerability_due_date skips rows stamped decoration:cve_intel,
    # so CISA's date stands. Expressed as "the stamp is mine or someone I outrank".
    ownership = [f"r.{PROVENANCE_COLUMN} = '{stamp_for(decoration)}'"]
    for column in cleared:
        for beneath in lower_ranked(decoration, column):
            clause = f"r.{PROVENANCE_COLUMN} = '{stamp_for(beneath)}'"
            if clause not in ownership:
                ownership.append(clause)
    owned = "(" + " OR ".join(ownership) + ")"

    sql = f"""\
UPDATE {sink} r
   SET {",\n       ".join(set_parts)}
  FROM decoration_facts f
 WHERE f.decoration = '{decoration}'
   AND f.attribute = '{attribute}'
   AND f.tenant_id = {fact_tenant}
   AND f.is_deleted IS TRUE
   AND f.subject_key = r.{spec.subject_column}
   AND r.tenant_id = %(tenant)s
   AND r.namespace_id = %(namespace)s
   AND r.is_deleted IS NOT TRUE
   AND r.{PROVENANCE_COLUMN} LIKE '{PROVENANCE_PREFIX}%%'
   AND {owned}
RETURNING r.tenant_id, r.namespace_id"""

    return sql, frozenset(cleared)
