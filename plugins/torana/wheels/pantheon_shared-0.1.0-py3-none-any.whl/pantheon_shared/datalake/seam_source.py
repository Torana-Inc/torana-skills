"""Where the write-seam registry comes from when it cannot be IMPORTED (S22 / row 35).

⛔ THE DEFECT THIS EXISTS TO REMOVE. `kind=declared` writers enter the reachability
map only by IMPORTING the five modules that call ``register_writer()``. Those live in
``torana_mesh`` (pantheon-integration). The three shipped app bundles live in
``pantheon_program_framework``. ⚠️ **No process can import both** — pantheon-program-framework
has no dependency on pantheon-integration, deliberately, and the platform rule is that
inter-service traffic goes through nginx rather than a direct import.

Measured 2026-08-10, and this is the whole row in two commands:

    pantheon-integration-dev       : 20 seam registrations, 0 bundles importable
    pantheon-program-framework-dev :  0 seam registrations, 3 bundles importable

So B11 and B13 — which need BOTH the registry and the bundles — refused on every
validation, correctly, and had therefore **never once run on a shipped bundle**.

## ⭐ Why FETCH rather than import, snapshot, or relocate

The facts already cross the process boundary: the reachability route serves every
column with its writers, their `kind`, and each declared writer's `expected_caller`
and `bridge_id`. Nothing new has to be published — only consumed.

The three rejected alternatives, and why:

  * **Import `torana_mesh` into program-framework** — creates a dependency between two
    services that deliberately have none, and would have to be repeated for every future
    consumer of the seam.
  * **A build-time snapshot** — ⛔ a snapshot DRIFTS, and every hand-maintained list in
    this codebase has been measured drifting. Worse here than elsewhere: a stale snapshot
    makes a newly-shadow column keep PASSING, which is the direction that ships a broken
    widget.
  * **Run the validator only where the seam is importable** — that container has no
    bundles. It is the status quo restated.

## ⛔ AND THE ANSWER IS RECOMPUTED HERE, NEVER READ OFF `declared_dependencies`

⚠️ **Measured, and it is the trap this module exists to walk around.** The payload
carries a `declared_dependencies` list, and it is NOT the caller-only set. It is the
ANY-declared set — every column with *at least one* declared writer:

    declared_dependencies (ANY declared) : 75 columns
    caller-only          (ALL declared)  : 30 columns

The 45-column difference is columns like ``assets.asset_name`` that carry BOTH a mapping
writer and a declared one. A sync fills them. `measure_caller_dependencies` deliberately
excludes them — its own docstring calls this out: telling an author *"this only fills when
<caller> runs"* about a column a sync also fills would send them to configure something
that was never broken, and ⛔ a checker that cries wolf gets waived.

Both are legitimate answers to different questions, and the route is not wrong to serve
the ANY set. But B13 needs the ALL set, so this module reconstructs writers from
``columns[].writers[]`` — which carries `kind` per writer — and lets the existing
`measure_caller_dependencies` logic apply its own rule unchanged. ⭐ One rule, one
implementation, in the module that owns it.

## ⚠️ THE FETCHED ANSWER IS NOT STABLE, AND CALLERS ARE TOLD SO

⛔ Measured 2026-08-10 — 12 identical calls to the same endpoint:

    9 of 12 → 415 declared / 414 reachable / 1 shadow / 63 declared_dependencies
    3 of 12 → 415 declared / 415 reachable / 0 shadow / 75 declared_dependencies

The service runs multiple gunicorn workers with NO hot-reload, so a worker started
before a `register_writer` call site changed keeps serving its in-memory registry
until it is respawned. The two answers above differ by exactly one registration
(``etl.sdg_provenance.datastores``) that one worker still holds and the current source
tree no longer contains.

⭐ This is a REAL PROPERTY of any cross-process read, not an artefact of this module,
and pretending otherwise is how a gate becomes untrustworthy. So every consumer reports
the `registration_count` it ACTUALLY SAW (`ShadowMeasurement.seam_registrations` is
sourced from the snapshot, not from a `len(WRITERS)` that would read 0 on this path),
and `SeamSnapshot.origin` records the URL. A verdict that moves between runs is then
visibly attributable rather than mysterious.

⚠️ `SeamSnapshot.summary` is `{}` against this route. The integration-side payload
carries `columns` / `count` / `declared_dependencies` but NO `summary` block — that is
added by pantheon-datalake's federating wrapper. Measured, not assumed. The field is
kept because it costs nothing and the federated route may be used later; ⛔ it is never
read as though absence meant zero.

⚠️ It also means a fetched answer must never be CACHED across a process's life — see
`fetch_seam_writers`.
"""

from __future__ import annotations

import os
from typing import Any, Dict, List, NamedTuple, Optional, Tuple

#: ⛔ DIRECT to pantheon-integration, never through nginx. The platform rule REVERSED
#: on 2026-09-08 (root `CLAUDE.md`): east-west uses `*_SERVICE_URL`, nginx is
#: north-south only. INTEGRATION_SERVICE_URL is the same string in every environment,
#: whereas the nginx hostname is `pantheon-nginx-dev` locally and `pantheon-nginx`
#: everywhere else — a difference that silently broke Classie twice.
#:
#: Owner verified on Classie 2026-09-08, from inside a container:
#:   pantheon-integration:8003/api/v1/reachability/columns -> 401 (route exists)
#:   pantheon-datalake:8002/api/v1/reachability/columns    -> 404 (no such route)
_SERVICE_URL_ENV = "INTEGRATION_SERVICE_URL"
_SERVICE_URL_DEFAULT = "http://pantheon-integration:8003"

#: Legacy nginx base. Read ONLY as a fallback so a deployment that has not yet been
#: given INTEGRATION_SERVICE_URL keeps working; remove once every environment sets it.
_NGINX_ENV = "PANTHEON_NGINX_INTERNAL_URL"

#: ⚠️ The route lives in pantheon-INTEGRATION (it owns the pipelines, so it owns the
#: writer map). pantheon-datalake exposes `/api/v1/datalake/reachable-columns`, which
#: FEDERATES here — going to the datalake instead would add a hop that can fail on its
#: own and reshape the payload. Mechanism 8 is wanted first-hand.
_REACHABILITY_PATH = "/api/v1/reachability/columns"


class SeamUnavailable(RuntimeError):
    """The seam registry could not be established from ANY source.

    ⛔ Its own type so *"this process cannot see mechanism 8"* stays distinguishable
    from a genuine measurement failure — the same reason `SeamRegistryEmpty` has one.
    Raised rather than returning an empty registry, because an empty registry is
    indistinguishable from "no declared writers exist" and would silently report ~12
    written columns as shadow.
    """


class FetchedWriter(NamedTuple):
    """One writer, of ANY mechanism, as the API reports it.

    ⚠️ Carries exactly the fields `reachability.Writer` needs, so the single consumer
    (`_fetch_declared_seam`) turns these back into REAL `Writer` objects and everything
    downstream — `measure_shadow_set`, `measure_caller_dependencies`, the report,
    `--explain` — runs unchanged on the fetched answer.

    ⭐ That is the whole reason this module is small: it re-implements no rule. It only
    re-supplies the INPUT the rules were always written against.

    ⛔ ALL EIGHT MECHANISMS, not just `declared` — and this is the correction that
    matters, because fetching only mechanism 8 is *plausible and wrong*. The other
    seven are derived by PARSING THE MAPPING TREE, which lives in `torana_mesh` and is
    absent wherever the seam is absent — the two travel together. Measured in
    pantheon-program-framework-dev, supplying only the declared writers:

        declared 415 / reachable  87 / shadow 328      ← mechanism 1 missing entirely
        declared 415 / reachable 414 / shadow   1      ← the truth

    `build_reachability_map` DID record the cause (`parse_errors` = "mapping tree not
    found ... mechanism-1 writers are MISSING"), but nothing consumed it, so a 328-column
    shadow verdict would have shipped as fact — the exact "confident wrong number" this
    row exists to eliminate.
    """

    kind: str
    source: str
    integration: Optional[str]
    detail: str
    expected_caller: Optional[Dict[str, Any]]
    bridge_id: Optional[str]


class SeamSnapshot(NamedTuple):
    """Everything one fetch established, INCLUDING what it could not."""

    #: `{(table, column): [FetchedWriter, ...]}` — declared writers only.
    writers: Dict[Tuple[str, str], List[FetchedWriter]]
    #: Total declared registrations seen, for the honest count consumers report.
    registration_count: int
    #: The payload's own `summary` block, carried through verbatim so a caller can
    #: report the numbers the SERVING WORKER saw rather than re-deriving them.
    summary: Dict[str, Any]
    #: Where the answer came from: "import" or the fetched URL. ⚠️ Load-bearing for
    #: the report — two runs disagreeing is only diagnosable if each says its source.
    origin: str


def _base_url() -> str:
    """Base for the reachability fetch: the owning service, direct.

    Falls back to the legacy nginx base only if INTEGRATION_SERVICE_URL is unset,
    so an environment mid-rollout does not lose mechanism 8.
    """
    direct = (os.getenv(_SERVICE_URL_ENV) or "").strip().rstrip("/")
    if direct:
        return direct
    legacy = (os.getenv(_NGINX_ENV) or "").strip().rstrip("/")
    return legacy or _SERVICE_URL_DEFAULT


def _fetch_json(url: str, params: List[Tuple[str, str]], timeout: float) -> Dict[str, Any]:
    """GET `url` with a service JWT, returning the parsed body.

    ⭐ Uses `PantheonClient`, which is the platform's blessed inter-service path and
    exactly what pantheon-datalake's own reachability federation uses to call this same
    route. It mints and refreshes the service JWT; hand-rolling an Authorization header
    would duplicate a decision that already has an owner.

    ⚠️ Runs the async client on a private event loop. This is called from synchronous
    validator code (`BundleValidator.validate`), and the alternative — making the whole
    validator async — would ripple through every caller for one HTTP GET. A fresh loop
    is used rather than `asyncio.run` on a possibly-running loop, so this stays safe
    when invoked from inside an already-async service.
    """
    import asyncio

    from pantheon_shared.http import PantheonClient

    # ⚠️ The SERVICE-AUTH identity, not a caller's tenant — and that is correct here
    # rather than merely convenient. The answer being fetched is PLATFORM-scoped
    # (`scope=platform` counts every integration Torana ships, connected or not), so it
    # is identical for every tenant. Authoring is a platform question; a tenant-scoped
    # identity would invite a tenant-scoped answer, which would condemn columns that are
    # fine the moment a customer connects an integration.
    #
    # Read from env rather than a service's `settings` object because pantheon-shared
    # cannot import one — these are the same two vars every service's settings read.
    tenant_name = (os.getenv("SERVICE_AUTH_TENANT_NAME")
                   or os.getenv("BOOTSTRAP_TENANT_NAME") or "Torana").strip()
    namespace_name = (os.getenv("SERVICE_AUTH_TENANT_NS_NAME") or "default").strip()

    async def _go() -> Dict[str, Any]:
        client = PantheonClient(
            service_name=os.getenv("APPLICATION_NAME", "pantheon-program-framework"),
            tenant_name=tenant_name,
            namespace_name=namespace_name,
        )
        resp = await client.get(url, params=params, timeout=timeout)
        if resp.status_code != 200:
            raise SeamUnavailable(
                f"reachability route {url} returned HTTP {resp.status_code}: "
                f"{resp.text[:300]}. The write-seam registry could not be "
                f"established, so shadow and caller verdicts would be wrong — "
                f"refusing rather than guessing."
            )
        return resp.json()

    def _run_in_fresh_loop() -> Dict[str, Any]:
        loop = asyncio.new_event_loop()
        try:
            return loop.run_until_complete(_go())
        finally:
            loop.close()

    try:
        # ⛔ A FRESH LOOP IS NOT ENOUGH when a loop is already running on THIS thread.
        # `loop.run_until_complete()` raises "Cannot run the event loop while another
        # loop is running" — asyncio permits only one RUNNING loop per thread, no matter
        # how many loop objects exist. This function is sync and is called from inside
        # async services (the bundle-registry load and B11/B13 during an async request),
        # so that branch was ALWAYS taken there: every call raised, was wrapped as
        # SeamUnavailable, and B11/B13 refused with "registry is EMPTY" on every bundle,
        # on every registry load. The check never once verified what it was written to
        # verify, and the log filled with a refusal that looked like a data problem.
        #
        # Fix: when a loop is already running here, do the blocking wait on a SEPARATE
        # thread, which gets its own fresh loop legally.
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return _run_in_fresh_loop()          # no loop on this thread — cheap path
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as _ex:
            return _ex.submit(_run_in_fresh_loop).result(timeout=timeout + 10)
    except SeamUnavailable:
        raise
    except Exception as exc:                            # noqa: BLE001
        raise SeamUnavailable(
            f"reachability route {url} unreachable ({type(exc).__name__}: {exc}). "
            f"Refusing rather than reporting written columns as shadow."
        ) from exc


def _parse_payload(payload: Dict[str, Any], origin: str) -> SeamSnapshot:
    """Rebuild declared writers from a reachability payload.

    ⛔ Reads `columns[].writers[]`, NEVER `declared_dependencies` — see the module
    docstring: that list is the ANY-declared set (75) and the caller-only rule needs
    per-writer `kind` so the ALL-declared rule (30) can be applied by the module that
    owns it.
    """
    cols = payload.get("columns")
    if not isinstance(cols, list):
        raise SeamUnavailable(
            f"reachability payload from {origin} carried no `columns` list "
            f"(keys: {sorted(payload)}) — refusing to treat that as 'no writers'"
        )

    out: Dict[Tuple[str, str], List[FetchedWriter]] = {}
    count = 0
    for entry in cols:
        if not isinstance(entry, dict):
            continue
        table = str(entry.get("table") or "").lower()
        column = str(entry.get("column") or "").lower()
        if not table or not column:
            continue
        for w in entry.get("writers") or []:
            if not isinstance(w, dict) or not w.get("kind"):
                continue
            ec = w.get("expected_caller")
            out.setdefault((table, column), []).append(FetchedWriter(
                kind=str(w["kind"]),
                source=str(w.get("source") or ""),
                integration=(str(w["integration"]) if w.get("integration") else None),
                detail=str(w.get("detail") or ""),
                expected_caller=ec if isinstance(ec, dict) else None,
                bridge_id=(str(w["bridge_id"]) if w.get("bridge_id") else None),
            ))
            if w["kind"] == "declared":
                count += 1

    if count == 0:
        # ⛔ Zero declared writers from a route that answered 200 is the "confident wrong
        # number" case, not a clean bill: the platform has ~20 registrations, so zero
        # means the serving process could not see them either. Refuse.
        raise SeamUnavailable(
            f"reachability payload from {origin} reported {len(cols)} columns but ZERO "
            f"`kind=declared` writers. The platform has declared writers, so this is a "
            f"degraded answer, not an empty registry — refusing rather than reporting "
            f"~12 written columns as shadow."
        )

    summary = payload.get("summary")
    return SeamSnapshot(
        writers=out,
        registration_count=count,
        summary=summary if isinstance(summary, dict) else {},
        origin=origin,
    )


def fetch_seam_writers(*, timeout: float = 15.0) -> SeamSnapshot:
    """Fetch declared writers over the reachability API.

    ⛔ NEVER CACHED, and the reason is the same one `_shadow_columns()` gives for not
    caching: reachability changes the moment a writer is registered, and a stale cached
    answer would let a fixed column keep failing or — far worse — let a newly-shadow
    column keep passing. The cost is one HTTP call per validation; the alternative is a
    gate that can be wrong in the dangerous direction.

    ⛔ RAISES `SeamUnavailable` on every failure path — unreachable host, non-200, an
    unparseable body, or a 200 carrying no declared writers. It never returns an empty
    snapshot, because an empty registry reads as "no declared writers exist" and that is
    exactly the false clean bill this row exists to eliminate.
    """
    base = _base_url()
    url = f"{base}{_REACHABILITY_PATH}"
    payload = _fetch_json(
        url,
        [("scope", "platform"), ("explain", "true")],
        timeout,
    )
    if not isinstance(payload, dict):
        raise SeamUnavailable(f"reachability route {url} returned "
                              f"{type(payload).__name__}, expected a JSON object")
    return _parse_payload(payload, origin=url)


def seam_fetch_enabled() -> bool:
    """Whether the fetch fallback may run at all.

    ⛔ A KILL SWITCH, not a feature flag, and it defaults ON. `SEAM_FETCH_DISABLED=true`
    restores the exact pre-S22 behaviour — no network call, and a process that cannot
    import the seam REFUSES as it did before.

    ⚠️ It can only ever make the gate MORE conservative. Turning it off cannot cause a
    bundle to PASS; it causes B11/B13 to refuse, which is the safe direction. That
    asymmetry is the only reason a switch is acceptable on a correctness gate at all.
    """
    return (os.getenv("SEAM_FETCH_DISABLED") or "").strip().lower() not in (
        "1", "true", "yes", "on",
    )
