from typing import Dict, Any
from .base import TableSchema


class IssuesSchema(TableSchema):
    """Schema definition for the issues table - tracks tickets, cases, and issues from Jira, ServiceNow, etc."""

    @property
    def table_name(self) -> str:
        return "issues"

    @property
    def primary_key(self) -> str:
        return "torana_issue_id"

    @property
    def description(self) -> str:
        return "Issue tracking data from ticketing systems with priority, assignment, and resolution information"

    @property
    def category(self) -> str:
        return "Operations Data"

    @property
    def timestamp_column(self) -> str:
        """Return the timestamp column for this table."""
        return "updated_at"

    @property
    def schema(self) -> Dict[str, Any]:
        return {
            "torana_issue_id": {"data_type": "VARCHAR(255)", "primary_key": True, "category": "Core Identity",
                "semantic_description": (
                    "Torana's stable id for one tracking TICKET, and the primary key of this table. ⚠️ "
                    "Distinct in ROLE from `vulnerabilities.torana_issue_id`, which is a foreign key "
                    "pointing here and whose NULL means no remediation work exists yet."
                ),
            },
            "source_system_id": {"data_type": "VARCHAR(255)", "category": "Core Identity",
                "semantic_description": (
                    "The ticket's identifier in its tracking system, kept verbatim so the ticket can be "
                    "traced back and re-fetched. Provider-specific in shape and never comparable across "
                    "trackers."
                ),
            },
            "issue_key": {"data_type": "VARCHAR(100)", "category": "Core Identity",
                "semantic_description": (
                    "The human-readable key (e.g. SEC-1234) — what people actually say in "
                    "conversation."
                ),
            },
            "source_system": {"data_type": "VARCHAR(100)", "category": "Core Identity",
                "semantic_description": (
                    "The integration or internal producer that reported this ticket row. ⚠️ Determines "
                    "which other columns are populated at all, since sources differ in what they expose, "
                    "and it is the first thing to check when two rows describe the same ticket differently."
                ),
            },
            "issue_url": {"data_type": "VARCHAR(1000)", "category": "Core Identity",
                "semantic_description": (
                    "Direct link to the ticket in its tracking system, so a finding can be followed to the "
                    "work item that tracks it."
                ),
            },
            "issue_type": {"data_type": "VARCHAR(50)", "category": "Issue Details",
                "semantic_description": (
                    "Kind of ticket: Bug, Story, Task, Vulnerability, Epic."
                ),
            },
            "summary": {"data_type": "VARCHAR(500)", "category": "Issue Details",
                "semantic_description": (
                    "The ticket's title line as entered in the tracking system — the headline shown when "
                    "the issue is listed. Equivalent in role to `findings.title`, on a ticket rather than a "
                    "detection."
                ),
            },
            "description": {"data_type": "TEXT", "category": "Issue Details",
                "semantic_description": (
                    "The ticket body. NOTE this is a DATA column; per-column meaning lives in "
                    "`semantic_description` metadata, not here."
                ),
            },
            "status": {"data_type": "VARCHAR(50)", "category": "Issue Details",
                "semantic_description": (
                    "Where the ticket stands: Open, In Progress, Done, Closed, Blocked. The "
                    "ticket's own state, which can disagree with the vulnerability's — a closed "
                    "ticket does not prove the finding is gone."
                ),
            },
            "resolution": {"data_type": "VARCHAR(50)", "category": "Issue Details",
                "semantic_description": (
                    "How it was resolved: Fixed, Won't Fix, Duplicate, Cannot Reproduce. 'Won't "
                    "Fix' on a security ticket is an accepted risk and should be recorded as "
                    "one."
                ),
            },
            "priority": {"data_type": "VARCHAR(20)", "category": "Issue Details",
                "semantic_description": (
                    "Priority assigned to this TICKET in its tracking system (P1–P4). The team's own view "
                    "of urgency. ⚠️ Distinct from `vulnerabilities.priority`, which is the platform's "
                    "computed remediation urgency from tenant policy — a ticket can be P3 while the "
                    "underlying vulnerability is Critical."
                ),
            },
            "severity": {"data_type": "VARCHAR(20)", "category": "Issue Details",
                "semantic_description": (
                    "Severity recorded ON THE TICKET by the tracking system or the person who raised it. ⛔ "
                    "Distinct from `vulnerabilities.severity`: this is a human or tracker judgement about "
                    "the work item, NOT the scanner's rating of the underlying flaw, and the two frequently "
                    "disagree."
                ),
            },
            "assignee": {"data_type": "VARCHAR(255)", "category": "Assignment",
                "semantic_description": (
                    "Who the ticket is assigned to. Empty means the work is unowned regardless "
                    "of how urgent the finding is."
                ),
            },
            "assignee_email": {"data_type": "VARCHAR(255)", "category": "Assignment",
                "semantic_description": (
                    "Email address of the person the ticket is assigned to, as recorded by the tracking "
                    "system. The routing target for remediation work; NULL when the ticket is unassigned."
                ),
            },
            "reporter": {"data_type": "VARCHAR(255)", "category": "Assignment",
                "semantic_description": (
                    "Display name of the person or system that raised the ticket, as the tracking system "
                    "records it."
                ),
            },
            "reporter_email": {"data_type": "VARCHAR(255)", "category": "Assignment",
                "semantic_description": (
                    "Email address of whoever raised the ticket. Complements `reporter` with a "
                    "machine-usable contact, and is NULL where the tracker withholds addresses."
                ),
            },
            "project_key": {"data_type": "VARCHAR(50)", "category": "Project",
                "semantic_description": (
                    "Short key of the project holding this ticket in the tracking system (for example a "
                    "Jira project key). The stable identifier, whereas `project_name` is the display label "
                    "and can be renamed."
                ),
            },
            "project_name": {"data_type": "VARCHAR(255)", "category": "Project",
                "semantic_description": (
                    "Human-readable name of the project holding this ticket. ⚠️ Renameable in most "
                    "trackers, so group by `project_key` for stable reporting and use this only for "
                    "display."
                ),
            },
            "parent_issue_key": {"data_type": "VARCHAR(100)", "category": "Project",
                "semantic_description": (
                    "Key of the parent ticket when this row is a subtask. ⛔ Present only for subtasks — "
                    "counting all rows as independent work items double-counts a parent and its children."
                ),
            },
            "workflow_state": {"data_type": "VARCHAR(50)", "category": "Workflow",
                "semantic_description": (
                    "Current state in the tracking system's workflow."
                ),
            },
            "created_date": {"data_type": "TIMESTAMP", "category": "Timeline",
                "semantic_description": (
                    "When the ticket was raised. The gap from the finding's detection date is "
                    "how long it took anyone to act."
                ),
            },
            "updated_date": {"data_type": "TIMESTAMP", "category": "Timeline",
                "semantic_description": (
                    "Last change. A stale date on an open ticket suggests stalled work."
                ),
            },
            "resolved_date": {"data_type": "TIMESTAMP", "category": "Timeline",
                "semantic_description": (
                    "When the ticket was resolved in its tracking system. ⚠️ Resolution is not always "
                    "closure: some trackers resolve and close separately, so a resolved ticket may still be "
                    "open by `status`."
                ),
            },
            "due_date": {"data_type": "TIMESTAMP", "category": "Timeline",
                "semantic_description": (
                    "When the ticket is due according to its tracking system. Populated only where the "
                    "tracker or the team sets due dates, so its absence says nothing about urgency."
                ),
            },
            "labels": {"data_type": "JSON", "category": "Labels & Tags",
                "semantic_description": (
                    "Labels applied to the ticket in its tracking system, carried through verbatim. "
                    "Free-form and team-specific, so they are useful as filters within one tracker and "
                    "unreliable across several."
                ),
            },
            "components": {"data_type": "JSON", "category": "Labels & Tags",
                "semantic_description": (
                    "Components the ticket is filed against in its tracking system — the tracker's own "
                    "subdivision of a project. Team-defined, so the vocabulary varies by project."
                ),
            },
            "fix_versions": {"data_type": "JSON", "category": "Labels & Tags",
                "semantic_description": (
                    "Releases this fix is scheduled for. Ties remediation to a shipping date."
                ),
            },
            "custom_fields": {"data_type": "JSON", "category": "Custom Fields",
                "semantic_description": (
                    "Custom fields from the tracking system — often where an org keeps its own "
                    "risk or approval data."
                ),
            },
            "created_via": {"data_type": "VARCHAR(100)", "category": "Audit & Tracking",
                "semantic_description": (
                    "The Torana mechanism that wrote this ticket row — an integration sync, a replay, a "
                    "manual push, or a synthetic dataset load. ⛔ Provenance, not ticket data: it is what "
                    "separates genuinely ingested rows from generated ones, and a query measuring a real "
                    "estate should know which values are synthetic."
                ),
            },
            "dataset_tag": {"data_type": "VARCHAR(200)", "category": "Audit & Tracking",
                "semantic_description": (
                    "Marks this ticket row as seeded by a NAMED synthetic dataset rather than a live "
                    "integration, so such rows can be purged as a set. NULL for genuinely ingested rows. ⛔ "
                    "Filter it out when measuring a real estate — counting demo rows as production ticket "
                    "data is the error this column exists to prevent."
                ),
            },
        }
