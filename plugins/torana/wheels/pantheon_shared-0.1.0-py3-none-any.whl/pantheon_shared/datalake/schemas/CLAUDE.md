# Datalake schemas — the 11 sink-table column definitions

This is where a datalake column is **added, changed or removed**.

## ⛔ MANDATORY — after ANY column change here, revalidate the corpus

A removed column does not remove the SQL that reads it. That SQL keeps its `ANSWERABLE`
verdict, parses, deploys — and fails or returns nothing.

```bash
TORANA_PROFILE=SA python3 \
  $TORANA_ROOT/pantheon-cli/skills/torana-text-to-sql/scripts/reachability_gate.py \
  check-corpus --scope platform --id-column query_id \
  --csv $TORANA_ROOT/pantheon-datalake/torana_datalake/corpus/question_sql.csv

TORANA_PROFILE=SA torana datalake schema audit    # every surface that DESCRIBES the schema
```

⛔ **Also lands on the `vm.tf.*` CATALOG and the shipped APP BUNDLES.** Neither has a
standing check. Commands + rationale: [`../../../../../pantheon-datalake/docs/SCHEMA_CHANGE_CHECKLIST.md`](../../../../../pantheon-datalake/docs/SCHEMA_CHANGE_CHECKLIST.md)

Full rules: [`pantheon-datalake/docs/corpus/CLAUDE.md`](../../../../../pantheon-datalake/docs/corpus/CLAUDE.md)

⚠️ **A column change lands on more than one surface.** The corpus SQL, the semantic overlay,
the `vm.tf.*` catalog and the value domains all describe columns independently. `schema audit`
reconciles them; run it before assuming a removal is complete.

⛔ **REMOVING a column?** Archive it first —
[`removed_columns_archive.csv`](../../../../../pantheon-datalake/docs/corpus/removed_columns_archive.csv).
⛔ **ADDING one?** Check that archive first: 903 columns were deliberately deleted, and
re-adding one without its writer recreates a shadow column.

⚠️ Measured 2026-08-18: the § 1.3 collapse removed 903 columns. 54 of 57 affected corpus
queries were correctly retired — **3 still read `ANSWERABLE` while referencing columns that
no longer exist**, and 8 dead enum declarations survived in the semantic overlay. Nothing
failed, because nothing re-ran.

## Value domains

A column's possible VALUES are declared in
[`../value_domain.py`](../value_domain.py), not here. Adding a categorical column? Declare its
domain there, with the file that declares the vocabulary as its `source`.

## ⭐ ADDING A COLUMN AN AGENT MUST FIND — declare it on ALL FIVE surfaces

⛔ **A physical column that only exists here is INVISIBLE to the things that write SQL.**
Claude Code build skills and Torana agents author SQL from the *declared* surfaces, not from
the table. A column declared here and nowhere else exists, holds data, and is never queried —
the most expensive kind of undone work, because nothing fails.

| # | Surface | File | Why an agent needs it |
|---|---|---|---|
| 1 | **Sink schema** | this directory | the column + what it MEANS (`semantic_description`) |
| 2 | **Value domain** | [`../value_domain.py`](../value_domain.py) | which values are legal — an author filtering on a value that is never written gets 0 rows |
| 3 | **Semantic model** | [`torana_security_mesh_semantic_model_updated.yaml`](torana_security_mesh_semantic_model_updated.yaml) | ⭐ **`synonyms` are how a natural-language question resolves to this column.** No entry ⇒ an agent cannot find it from "which images aren't ours" |
| 4 | **Domain property registry** | [`../../domain_properties/vm.py`](../../domain_properties/vm.py) | ONLY if the column is governed per tenant (`provenance_class=DECLARED`) — the resolution + governance contract |
| 5 | ⛔ **Resolution target** | [`entity_properties_resolved.py`](entity_properties_resolved.py) | ONLY for a governed property (surface 4). **This is where the resolver actually WRITES** (`property_resolution.RESOLVED_TABLE`) and where consumers JOIN |

⛔ **Surface 5 is the one that gets forgotten, and it fails SILENTLY.** MEASURED 2026-09-07:
`image_ownership` shipped on `assets` (5 schemas) and NOT on `entity_properties_resolved` (0). The
upsert **strips keys with no physical column**, so the resolver would log a successful row count
while every consumer read the default forever. It surfaced only because a corpus query joined the
missing column and returned HTTP 400 — had anything caught that error, the metric would have looked
like it was working and awaiting data.

⭐ **The tell: a governed property appears TWICE.** `VARCHAR(n)` on the sink table, `TEXT` on
`entity_properties_resolved`. All six pre-existing properties follow it — `asset_team`, `asset_owner`,
`asset_environment`, `criticality_name`, `public_access`, `has_customer_data`. If your new property
appears once, it is not finished.

⚠️ **Surface 3 is a KNOWN-DRIFTED file — add to it, do not trust it.** `#228` measured **77
declared columns that do not physically exist** in that YAML (`#226`/`#227`/`#229` are the same
family). Adding an entry is correct; treating a neighbouring entry as verified is not.

⚠️ **Synonym collisions are silent and they misroute questions.** `PUBLIC_ACCESS` already claims
`external`; `ASSET_OWNER` claims `owner`. A new synonym that overlaps sends an agent to the wrong
column and it returns confident, wrong SQL. Grep the YAML for every synonym you intend to add.

⭐ **Worked example: `assets.image_ownership`** (first-party vs vendor vs third-party) — the
four-surface walkthrough is § 3.3.1 of
[`11_SpecF_Image_Ownership_And_MET003.md`](../../../../../pantheon-program-framework/docs/VM/11_SpecF_Image_Ownership_And_MET003.md).

⛔ **Is the value TENANT POLICY rather than an observable fact?** Then it is a **domain property**
(surface 4), not an ETL-written column — see [`../../domain_properties/`](../../domain_properties/).
Inferring policy at ingest freezes a guess where it is invisible and unfalsifiable; that is the
defect `#374` records.
