"""Validate the semantic model against the schema classes it describes.

Issues #225-#229 all have the same shape: the semantic model
(``torana_security_mesh_semantic_model_updated.yaml``) is hand-maintained, and
NOTHING checked it against the schema classes sitting in the same directory. It
drifted, and the drift is invisible until an author writes SQL from it and the
query fails - or worse, silently returns nothing.

What the drift looked like when this module was written (measured 2026-08-24):

* ``TORANA_ASSET_ID`` declared as the primary key of ``assets``, ``artifacts``
  and ``vulnerabilities``. No table has that column - the real keys are
  ``torana_entity_id`` / ``torana_artifact_id`` / ``torana_vulnerability_id``.
  The model contradicted ITSELF: its ``relationships`` block joins on
  ``torana_entity_id`` (#226).
* A logical table ``ASSET_EDGES`` whose real name is ``entity_edges`` (#226).
* ``controls``, ``identities`` and ``datastores`` absent entirely; ``FINDINGS``
  present with 0 dimensions and 0 metrics (#227).
* ``PUBLICLY_ACCESSIBLE`` documented, with ``internet_facing`` as a synonym,
  while the populated column is ``public_access`` (#229).

A second, related class this also catches: a schema class whose
``primary_key`` property names a column its own ``schema`` dict does not
define. That was #176 for ``datastores``; ``findings`` and ``identities`` still
had it when this module was written.

The point is not a one-off cleanup. Both checks are cheap, need no database
(they compare declarations to declarations), and are meant to run in the schema
audit so the model can never silently drift again.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence

#: Tables the semantic model is expected to describe.
CANONICAL_TABLES = (
    "assets",
    "artifacts",
    "vulnerabilities",
    "findings",
    "issues",
    "packages",
    "repositories",
    "controls",
    "identities",
    "datastores",
    "entity_edges",
)


@dataclass(frozen=True)
class SchemaFinding:
    """One discrepancy between a declaration and the schema classes."""

    kind: str          # unknown_table | unknown_column | undocumented_table | empty_table | primary_key_not_a_column
    table: str
    name: Optional[str] = None
    detail: str = ""
    issue: str = ""

    def __str__(self) -> str:
        target = f"{self.table}.{self.name}" if self.name else self.table
        suffix = f" [{self.issue}]" if self.issue else ""
        return f"{self.kind}: {target} - {self.detail}{suffix}"


@dataclass
class ValidationReport:
    """Everything the validator found, grouped so a caller can act on it."""

    findings: List[SchemaFinding] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.findings

    def by_kind(self, kind: str) -> List[SchemaFinding]:
        return [f for f in self.findings if f.kind == kind]

    def by_issue(self, issue: str) -> List[SchemaFinding]:
        return [f for f in self.findings if f.issue == issue]

    def summary(self) -> Dict[str, int]:
        counts: Dict[str, int] = {}
        for finding in self.findings:
            counts[finding.kind] = counts.get(finding.kind, 0) + 1
        return counts

    def render(self) -> str:
        if self.ok:
            return "semantic model is consistent with the schema classes"
        lines = [f"{len(self.findings)} discrepancies:"]
        lines.extend(f"  {finding}" for finding in sorted(
            self.findings, key=lambda f: (f.kind, f.table, f.name or "")
        ))
        return "\n".join(lines)


def _schema_instances() -> Dict[str, Any]:
    """Instantiate every registered schema class, keyed by table name."""
    from . import _ALL_TABLE_SCHEMAS

    instances = {}
    for schema_class in _ALL_TABLE_SCHEMAS:
        instance = schema_class()
        instances[instance.table_name] = instance
    return instances


def validate_primary_keys(schemas: Optional[Dict[str, Any]] = None) -> List[SchemaFinding]:
    """Every schema's declared ``primary_key`` must exist in its own ``schema`` dict.

    This is the #176 defect class. ``datastores`` declared
    ``torana_datastore_id`` as its primary key while its schema dict defined
    only ``datastore_id`` - so the declared key named a column that existed
    nowhere, and no row could ever be keyed into the entity graph.
    """
    schemas = schemas if schemas is not None else _schema_instances()
    findings: List[SchemaFinding] = []
    for table_name, instance in sorted(schemas.items()):
        primary_key = instance.primary_key
        if primary_key not in instance.schema:
            findings.append(SchemaFinding(
                kind="primary_key_not_a_column",
                table=table_name,
                name=primary_key,
                detail=(
                    f"primary_key property returns {primary_key!r} but the schema "
                    f"dict does not define it (it defines "
                    f"{', '.join(sorted(instance.schema)[:3])}, ...)"
                ),
                issue="#176",
            ))
    return findings


def _declared_names(table: Dict[str, Any]) -> List[tuple]:
    """(kind, name) for every column-like name a logical table declares."""
    names: List[tuple] = []
    primary_key = table.get("primary_key") or {}
    for column in primary_key.get("columns", []) or []:
        names.append(("primary_key", column))
    for dimension in table.get("dimensions") or []:
        names.append(("dimension", dimension.get("name")))
    for metric in table.get("metrics") or []:
        names.append(("metric", metric.get("name")))
    for time_dimension in table.get("time_dimensions") or []:
        names.append(("time_dimension", time_dimension.get("name")))
    return [(kind, name) for kind, name in names if name]


def validate_semantic_model(
    model: Optional[Dict[str, Any]] = None,
    schemas: Optional[Dict[str, Any]] = None,
    canonical_tables: Sequence[str] = CANONICAL_TABLES,
) -> ValidationReport:
    """Check every name the semantic model declares against the schema classes.

    Args:
        model: Parsed semantic model. Loaded from disk when omitted.
        schemas: Schema instances by table name. Derived when omitted.
        canonical_tables: Tables the model is expected to cover.

    Returns:
        ValidationReport: empty when the model and the schemas agree.
    """
    if model is None:
        from . import load_semantic_model
        model = load_semantic_model()
    schemas = schemas if schemas is not None else _schema_instances()

    report = ValidationReport()
    report.findings.extend(validate_primary_keys(schemas))

    described = set()
    for table in model.get("tables") or []:
        declared_name = table.get("name", "")
        table_name = declared_name.lower()

        if table_name not in schemas:
            report.findings.append(SchemaFinding(
                kind="unknown_table",
                table=declared_name,
                detail=(
                    "the model declares this logical table but no schema class "
                    f"defines it (known tables: {', '.join(sorted(schemas)[:4])}, ...)"
                ),
                issue="#226",
            ))
            continue

        described.add(table_name)
        columns = {column.lower() for column in schemas[table_name].schema}

        for kind, name in _declared_names(table):
            if name.lower() not in columns:
                report.findings.append(SchemaFinding(
                    kind="unknown_column",
                    table=declared_name,
                    name=name,
                    detail=f"declared as a {kind} but the table has no such column",
                    issue="#226",
                ))

        if not (table.get("dimensions") or table.get("metrics")):
            report.findings.append(SchemaFinding(
                kind="empty_table",
                table=declared_name,
                detail="present in the model with no dimensions and no metrics",
                issue="#227",
            ))

    for table_name in canonical_tables:
        if table_name not in described:
            report.findings.append(SchemaFinding(
                kind="undocumented_table",
                table=table_name,
                detail="canonical table absent from the semantic model",
                issue="#227",
            ))

    return report


def undocumented_columns(
    model: Optional[Dict[str, Any]] = None,
    schemas: Optional[Dict[str, Any]] = None,
) -> Dict[str, List[str]]:
    """Real columns the model does NOT describe, per table.

    The inverse direction of ``validate_semantic_model`` and the measurement
    behind #228: knowledge that exists in one surface and not the other. This is
    reported, never failed - a model is allowed to describe a useful subset.
    """
    if model is None:
        from . import load_semantic_model
        model = load_semantic_model()
    schemas = schemas if schemas is not None else _schema_instances()

    gaps: Dict[str, List[str]] = {}
    for table in model.get("tables") or []:
        table_name = table.get("name", "").lower()
        if table_name not in schemas:
            continue
        documented = {name.lower() for _, name in _declared_names(table)}
        columns = {column.lower() for column in schemas[table_name].schema}
        missing = sorted(columns - documented)
        if missing:
            gaps[table_name] = missing
    return gaps
