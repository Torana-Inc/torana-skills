from typing import Dict, Any
from .base import TableSchema


class EntityEdgesSchema(TableSchema):
    """Schema for the entity_edges table (Torana_Asset_Graph_Design.md § 3.3.3).

    The typed, directional, evidence-and-confidence-bearing relationship store —
    the one genuinely new storage surface in AG0. Each row is one directed edge
    between two polymorphic source-neutral keys (§ 3.3.1).

    PK ``torana_edge_id`` = ``sha256(tenant_id : from_key : to_key : edge_type)``
    (§ 3.3.3) — deterministic so the upsert is idempotent on the logical key;
    ``confidence``/``evidence`` are intentionally excluded from the hash so
    re-derivation collapses to one row. ``description``/``first_seen``/``last_seen``
    are explicit business columns (NOT system-injected; § 3.3).

    Indexes (created by the DDL path / explicitly): ``(tenant_id, from_key)``,
    ``(tenant_id, to_key)``, ``(tenant_id, edge_type)`` — forward, reverse, and
    type-filtered traversal for the bounded reachability CTE.
    """

    @property
    def table_name(self) -> str:
        return "entity_edges"

    @property
    def primary_key(self) -> str:
        return "torana_edge_id"

    @property
    def description(self) -> str:
        return (
            "Typed, directional, evidence-bearing relationships between entity-graph "
            "nodes (repo/cloud/service/host/image/gav/pkg/team). Carries match "
            "confidence and per-source evidence; the substrate for code-to-runtime "
            "lineage and reachability (CAASM)."
        )

    @property
    def category(self) -> str:
        return "Entity Graph"

    @property
    def timestamp_column(self) -> str:
        return "updated_at"

    @property
    def schema(self) -> Dict[str, Any]:
        return {
            "torana_edge_id": {"data_type": "VARCHAR(64)", "primary_key": True, "category": "Core Identity",
                "semantic_description": (
                    "Torana's stable id for one relationship between two entities."
                ),
            },
            "from_key": {"data_type": "VARCHAR(512)", "not_null": True, "index": True, "category": "Edge",
                "semantic_description": (
                    "The entity the relationship starts at, as a prefixed key (`image:`, "
                    "`service:`, `repo:`, `pkg:`). Direction matters — reversing from and to "
                    "changes what the query means."
                ),
            },
            "to_key": {"data_type": "VARCHAR(512)", "not_null": True, "index": True, "category": "Edge",
                "semantic_description": (
                    "The entity the relationship points to. For `deployed_as`, from is the "
                    "image and to is the running service."
                ),
            },
            "edge_type": {"data_type": "VARCHAR(50)", "not_null": True, "index": True, "category": "Edge",
                "semantic_description": (
                    "What the relationship IS. The vocabulary is closed and exact: `contains`, "
                    "`owns`, `deployed_as`, `builds_image`, `exposed_via`. Use the literal "
                    "value — an agent once invented `deployed_on`, which matched nothing and "
                    "silently returned zero rows rather than erroring."
                ),
            },
            "evidence": {"data_type": "JSON", "category": "Provenance",
                "semantic_description": (
                    "What established this relationship — the observation or declaration behind "
                    "it. The difference between a fact and an inference."
                ),
            },
            "confidence": {"data_type": "VARCHAR(20)", "not_null": True, "category": "Provenance",
                "semantic_description": (
                    "How certain the platform is that this relationship is real. Derived edges "
                    "carry lower confidence than observed ones."
                ),
            },
            "source_system": {"data_type": "VARCHAR(100)", "category": "Provenance",
                "semantic_description": (
                    "The integration or internal producer that reported this relationship row. ⚠️ "
                    "Determines which other columns are populated at all, since sources differ in what they "
                    "expose, and it is the first thing to check when two rows describe the same "
                    "relationship differently."
                ),
            },
            # created_via distinguishes how the edge was produced — 'sdg_replay' for edges
            # pushed by an SDG dataset replay, vs an integration marker for edges DERIVED
            # live from real provider data (AG3a). dataset_tag scopes replay edges to one
            # dataset. Together they let `clear-sdg-data` purge replayed edges
            # (created_via='sdg_replay') while leaving real-integration-derived edges.
            "created_via": {"data_type": "VARCHAR(50)", "index": True, "category": "Provenance",
                "semantic_description": (
                    "The Torana mechanism that wrote this relationship row — an integration sync, a replay, "
                    "a manual push, or a synthetic dataset load. ⛔ Provenance, not relationship data: it is "
                    "what separates genuinely ingested rows from generated ones, and a query measuring a "
                    "real estate should know which values are synthetic."
                ),
            },
            "dataset_tag": {"data_type": "VARCHAR(255)", "index": True, "category": "Provenance",
                "semantic_description": (
                    "Marks this relationship row as seeded by a NAMED synthetic dataset rather than a live "
                    "integration, so such rows can be purged as a set. NULL for genuinely ingested rows. ⛔ "
                    "Filter it out when measuring a real estate — counting demo rows as production "
                    "relationship data is the error this column exists to prevent."
                ),
            },
            "first_seen": {"data_type": "TIMESTAMP", "category": "Lifecycle",
                "semantic_description": (
                    "When the relationship was first observed. A `deployed_as` edge appearing "
                    "is the moment an image started running."
                ),
            },
            "last_seen": {"data_type": "TIMESTAMP", "category": "Lifecycle",
                "semantic_description": (
                    "When this RELATIONSHIP was last observed. An edge that stopped appearing suggests the "
                    "relationship ended — the workload was scaled down or replaced. ⚠️ Distinct from "
                    "`findings.last_seen`, which dates a detection rather than a link between two entities."
                ),
            },
            "description": {"data_type": "TEXT", "category": "Edge",
                "semantic_description": (
                    "Human-readable note about this relationship. NOTE this is a DATA column; "
                    "per-column meaning lives in `semantic_description` metadata, not here."
                ),
            },
        }
