from typing import Dict, Any
from .base import TableSchema


class AssetsSchema(TableSchema):
    """Schema definition for the assets table."""

    @property
    def table_name(self) -> str:
        return "assets"

    @property
    def primary_key(self) -> str:
        return "torana_entity_id"

    @property
    def description(self) -> str:
        return "Inventory of infrastructure assets, cloud resources, applications, and services with ownership and criticality information"

    @property
    def category(self) -> str:
        return "Asset Data"

    @property
    def timestamp_column(self) -> str:
        """Return the timestamp column for this table."""
        return "updated_at"

    @property
    def schema(self) -> Dict[str, Any]:
        return {
            "torana_entity_id": {"data_type": "VARCHAR(255)", "primary_key": True, "category": "Core Identity",
                "semantic_description": (
                    "Torana's stable id for one asset, prefixed by kind: `service:` for a "
                    "governed running service, `cloud:` for a discovered cloud resource, "
                    "`image:` for a container image. Vulnerabilities join here, and governance "
                    "is inherited along this key. The prefix tells you which supply path "
                    "produced the row."
                ),
            },
            "source_system_id": {"data_type": "VARCHAR(255)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "The asset's id in the system that reported it. Use it to open the asset in "
                    "that tool; not unique across sources."
                ),
            },
            "source_system": {"data_type": "VARCHAR(100)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "The integration or internal producer that reported this asset row. ⚠️ Determines which "
                    "other columns are populated at all, since sources differ in what they expose, and it "
                    "is the first thing to check when two rows describe the same asset differently."
                ),
            },
            "discovery_source": {"data_type": "VARCHAR(100)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "The FEED through which this asset was discovered — which pipeline told the platform it "
                    "exists. ⚠️ Kept distinct from `source_system` because a asset can be discovered by one "
                    "mechanism and maintained by another."
                ),
            },
            "discovery_method": {"data_type": "VARCHAR(50)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "By what MEANS this asset was discovered — an API collection, an inventory sweep, or a "
                    "manual registration. Complements `discovery_source` (which feed) and is how "
                    "automatically-inventoried rows are separated from hand-registered ones."
                ),
            },
            "asset_name": {"data_type": "VARCHAR(255)", "category": "Asset Details",
                "semantic_description": (
                    "The asset's name as its source system knows it. Human-readable, not stable "
                    "enough to join on."
                ),
            },
            "asset_description": {"data_type": "TEXT", "category": "Asset Details",
                "semantic_description": (
                    "Free-text description of what the asset is for, where a source supplies "
                    "one."
                ),
            },
            "asset_type": {"data_type": "VARCHAR(50)", "category": "Asset Details",
                "semantic_description": (
                    "What kind of thing this ASSET is — VM, Container, Service, ReplicaSet, Function, "
                    "Database. Determines which other fields are even meaningful (a Function has no MAC "
                    "address). ⚠️ Distinct from `findings.asset_type`, which is the producer's own label "
                    "copied onto a finding and is not guaranteed to match this canonical value."
                ),
            },
            # Asset-graph (AG0 § 3.3.4): logical-service identity for service:<env>/<name>
            # assets (asset_type='service'). Additive, nullable. Other service governance
            # reuses real existing columns (criticality_name/level, asset_owner,
            # public_access, load_balancer_name).
            "service_name": {"data_type": "VARCHAR(255)", "category": "Asset Details",
                "semantic_description": (
                    "For a running service, its name. With container_cluster_id this is what "
                    "deployment governance matches on."
                ),
            },
            "service_application": {"data_type": "VARCHAR(255)", "category": "Asset Details",
                "semantic_description": (
                    "The application this service belongs to. Used together with the cluster to "
                    "bind a deployment's governance to the right rows."
                ),
            },
            # Asset-graph (AG3a, Torana_Asset_Graph_Design.md § 3.3.4 / § 4.9.3): the
            # container image a runtime/cloud asset is deployed from. Carries the SAME
            # digest the building artifact does, so the `image ──deployed_as──▶ service`
            # edge converges across passes on an immutable, indexed key (not a name).
            # Additive nullable — populated by cloud/runtime mappings (e.g. aws_config).
            "container_image_id": {"data_type": "VARCHAR(512)", "index": True, "category": "Asset Details",
                "semantic_description": (
                    "The image this asset runs. The bridge from a running thing to the artifact "
                    "it was built from, and to that artifact's vulnerabilities."
                ),
            },
            "container_image_digest": {"data_type": "VARCHAR(128)", "index": True, "category": "Asset Details",
                "semantic_description": (
                    "The container image's content hash, recorded on this asset row — the identifier that "
                    "cannot drift. ⚠️ A tag can be repointed at new content; a digest cannot, which is why "
                    "deployments and findings key on it rather than on the tag."
                ),
            },
            "asset_status": {"data_type": "VARCHAR(50)", "category": "Asset Details",
                "semantic_description": (
                    "Whether the asset is Active, Inactive, Decommissioned or Unknown. A "
                    "finding on a decommissioned asset is not worth chasing."
                ),
            },
            "asset_environment": {"data_type": "VARCHAR(50)", "category": "Asset Details",
                "semantic_description": (
                    "Which environment this runs in: production, staging, development, test, "
                    "qa. Drives severity thresholds — the same flaw in prod and in dev are not "
                    "the same problem. OBSERVED-primary: a synced value wins over a declared "
                    "one."
                ),
            },
            "cloud_provider": {"data_type": "VARCHAR(50)", "category": "Cloud Provider-Specific Fields",
                "semantic_description": (
                    "Which cloud this runs in: AWS, Azure, GCP, OCI, or On-Premises."
                ),
            },
            "cloud_account_id": {"data_type": "VARCHAR(100)", "category": "Cloud Provider-Specific Fields",
                "semantic_description": (
                    "The cloud account or subscription. Often the real boundary between teams "
                    "or environments."
                ),
            },
            "cloud_region": {"data_type": "VARCHAR(50)", "category": "Cloud Provider-Specific Fields",
                "semantic_description": (
                    "Cloud region. Matters for data residency and blast radius."
                ),
            },
            "cloud_resource_id": {"data_type": "VARCHAR(255)", "category": "Cloud Provider-Specific Fields",
                "semantic_description": (
                    "The provider's own identifier — ARN, resource id, self-link. What you "
                    "paste into the cloud console."
                ),
            },
            "compute_operating_system": {"data_type": "VARCHAR(100)", "category": "Compute Platform",
                "semantic_description": (
                    "Operating system. Determines which patches and OS-level findings apply."
                ),
            },
            "container_cluster_id": {"data_type": "VARCHAR(255)", "category": "Container Orchestration",
                "semantic_description": (
                    "The cluster this runs in. With service_application, the pair deployment "
                    "governance matches on."
                ),
            },
            "container_cluster_name": {"data_type": "VARCHAR(255)", "category": "Container Orchestration",
                "semantic_description": (
                    "Human-readable name of the cluster this asset runs in, as its orchestrator reports it. "
                    "Groups workloads by cluster for blast-radius questions; NULL for assets that are not "
                    "cluster-hosted."
                ),
            },
            "hostname": {"data_type": "VARCHAR(255)", "category": "Network & Location",
                "semantic_description": (
                    "The asset's host name. Human-recognisable but not reliably unique."
                ),
            },
            # ⛔ NOT a duplicate of `hostname`, and the difference is the whole point.
            # `hostname` is a human label with no uniqueness guarantee; this is the
            # canonical `host:<provider>/<id>` ENTITY KEY of the machine this row runs
            # on, built by host_key(). It is the TO-endpoint of the
            # service ──runs_on──▶ host edge, and `derive_runs_on` gates on exactly
            # (service_env, service_name, host_id).
            #
            # ⚠️ Until this column existed, `runs_on` was UNSATISFIABLE BY ANY PRODUCER
            # ON THE PLATFORM (#133): the edge rule shipped, the relationship contract
            # demanded it, and the column it gates on was on no datalake table at all —
            # so every mapping owing `runs_on` breached forever through no fault of its
            # author, and `host:`-ended relationships were entirely absent from the graph.
            # `EDGE_PRODUCER_STATUS["runs_on"]` was marked `dormant` for that reason.
            #
            # ⛔ THE COLUMN MUST LAND WITH ITS WRITER (#149). A declared-but-unwritten
            # column reports `reachable=false` and renders in the build audit as a
            # "can never work, should never have been authored" defect — which then gets
            # someone to DELETE working SQL. Its writer is the `host_id` derive in
            # kubernetes/workloads.yaml, sourced from the Pod's `spec.nodeName` (the
            # k8s extractor already fetches full Pod objects, so this costs zero new
            # HTTP calls). That derive is a normal mapping step, so reachability parses
            # it from the mapping tree — no write_seam registration is needed or correct
            # here; write_seam is for writes that go through NO mapping.
            "host_id": {"data_type": "VARCHAR(255)", "category": "Network & Location",
                "semantic_description": (
                    "Canonical host:<provider>/<id> entity key of the machine or node this "
                    "asset runs on. The join key for service-to-host relationships; not a "
                    "display name (that is `hostname`)."
                ),
            },
            "private_ipv4_addresses": {"data_type": "JSON", "category": "Network & Location",
                "semantic_description": (
                    "Internal IPv4 addresses. Reachable only from inside the network."
                ),
            },
            "fqdn": {"data_type": "VARCHAR(255)", "category": "Network & Location",
                "semantic_description": (
                    "Fully qualified domain name of this asset. The primary evidence for "
                    "network-reachability questions; NULL means no name was reported, which is not the same "
                    "as the asset being unreachable."
                ),
            },
            "mac_addresses": {"data_type": "JSON", "category": "Network & Location",
                "semantic_description": (
                    "Hardware addresses of the asset's interfaces."
                ),
            },
            "public_access": {"data_type": "BOOLEAN", "category": "Security Configuration",
                "semantic_description": (
                    "Whether this is reachable from the internet. THE canonical exposure column "
                    "— `publicly_accessible` is a deprecated alias kept only so the old name "
                    "cannot be reintroduced. Merged with OR across sources: a stale 'not "
                    "public' must never hide an observed load balancer."
                ),
            },
            "asset_owner": {"data_type": "VARCHAR(255)", "category": "Ownership & Organization",
                "semantic_description": (
                    "The person accountable for this asset. DECLARED — no scanner can know an "
                    "org chart, so it stays empty until a human sets it on a Deployment."
                ),
            },
            "asset_owner_email": {"data_type": "VARCHAR(255)", "category": "Ownership & Organization",
                "semantic_description": (
                    "Contact address for the owner, where supplied."
                ),
            },
            "asset_team": {"data_type": "VARCHAR(100)", "category": "Ownership & Organization",
                "semantic_description": (
                    "The team accountable for remediating findings here. DECLARED and "
                    "platform-canonical: cloud providers carry no team label, so it can only be "
                    "declared. When empty, remediation is assigned to nobody and ages unowned."
                ),
            },
            "image_ownership": {"data_type": "VARCHAR(20)", "category": "Ownership & Organization",
                "semantic_description": (
                    "WHO controls the container image this asset runs — and therefore who a "
                    "vulnerability in it is addressable to: `first_party` (the customer builds "
                    "it), `vendor` (the cloud/platform vendor ships it), `third_party` "
                    "(somebody else's public image), `undetermined` (we looked and the data "
                    "cannot say). ⛔ NOT the registry that hosts the image — a first-party "
                    "build and a mirrored third-party image sit in the SAME registry under the "
                    "same host, so `container_image_registry_provider` cannot answer this. "
                    "DECLARED: a tenant declaration is authoritative; absent one, an "
                    "`artifacts` row for the image (the customer's own registry inventory) "
                    "yields `first_party` and its ABSENCE yields `undetermined`, never a "
                    "confident `vendor`. ⚠️ `undetermined` is NOT a NULL substitute — NULL "
                    "means nothing has looked, `undetermined` means we looked and only a "
                    "human can split vendor from third_party."
                ),
            },
            "load_balancer_name": {"data_type": "VARCHAR(255)", "category": "Load Balancer & Networking",
                "semantic_description": (
                    "Load balancer fronting this asset. Its presence is often what makes a "
                    "private asset internet-reachable."
                ),
            },
            "criticality_name": {"data_type": "VARCHAR(20)", "category": "Risk & Security Posture",
                "semantic_description": (
                    "How much this asset matters to the business"
                    "A judgement, not an observation — the same machine is critical or not "
                    "depending on what it runs. When several deployments claim one image, the "
                    "most critical wins."
                ),
            },
            "criticality_level": {"data_type": "INTEGER", "category": "Risk & Security Posture",
                "semantic_description": (
                    "Numeric form of `criticality_name` for this asset, kept for ordering and comparison. "
                    "⚠️ Two columns holding ONE fact — set them together or set neither, since a query "
                    "reading only one of them silently disagrees with a query reading the other."
                ),
            },
            # Deployment-object governance (Deployment_Object_and_Runtime_Provenance.md § 3.3.4):
            # human-asserted governance stamped onto service:<env>/<name> assets by the K8s
            # integration (and re-stamped by the governance-repaint job on Deployment edit).
            # Additive, nullable, service-only. internet-facing reuses public_access;
            # criticality reuses criticality_name/level; owner reuses asset_owner — so ONLY
            # these two are net-new (data-sensitivity + which Deployment set the governance).
            "has_customer_data": {"data_type": "BOOLEAN", "category": "Risk & Security Posture",
                "semantic_description": (
                    "Whether customer data lives here. DECLARED by a human. Drives escalation "
                    "and compliance scope; no scanner can determine it reliably."
                ),
            },
            "governance_source": {"data_type": "VARCHAR(50)", "category": "Risk & Security Posture",
                "semantic_description": (
                    "Where this row's governance values came from — which deployment or push "
                    "declared them. The audit trail for a value nobody can otherwise explain."
                ),
            },
            "custom_attributes_value": {"data_type": "JSON", "category": "Tags & Metadata",
                "semantic_description": (
                    "Value of the custom attribute named alongside it on this row, carried from the "
                    "source's own tagging. ⛔ Free-form and source-defined, so treat it as investigative "
                    "context rather than a dimension to group by in shipped SQL."
                ),
            },
            "asset_created_at": {"data_type": "TIMESTAMP", "category": "Lifecycle & Management",
                "semantic_description": (
                    "When the asset was created in its source system."
                ),
            },
            "asset_launched_at": {"data_type": "TIMESTAMP", "category": "Lifecycle & Management",
                "semantic_description": (
                    "When it started running. Distinct from creation for anything that stops "
                    "and starts."
                ),
            },
            "asset_first_seen_at": {"data_type": "TIMESTAMP", "category": "Lifecycle & Management",
                "semantic_description": (
                    "When Torana first observed this asset — the platform's own view, "
                    "independent of the source's timestamps."
                ),
            },
            "asset_last_seen_at": {"data_type": "TIMESTAMP", "category": "Lifecycle & Management",
                "semantic_description": (
                    "When Torana last observed it. A stale value suggests the asset is gone or "
                    "the sync stopped."
                ),
            },
            "created_via": {"data_type": "VARCHAR(100)", "category": "Audit & Tracking",
                "semantic_description": (
                    "The Torana mechanism that wrote this asset row — an integration sync, a replay, a "
                    "manual push, or a synthetic dataset load. ⛔ Provenance, not asset data: it is what "
                    "separates genuinely ingested rows from generated ones, and a query measuring a real "
                    "estate should know which values are synthetic."
                ),
            },
            "dataset_tag": {"data_type": "VARCHAR(200)", "category": "Audit & Tracking",
                "semantic_description": (
                    "Marks this asset row as seeded by a NAMED synthetic dataset rather than a live "
                    "integration, so such rows can be purged as a set. NULL for genuinely ingested rows. ⛔ "
                    "Filter it out when measuring a real estate — counting demo rows as production asset "
                    "data is the error this column exists to prevent."
                ),
            },
            # ── Decoration layer provenance (DECORATION_LAYER_SPEC.md § 3.9) ──
            # Required on EVERY decorated sink: the apply statement stamps both
            # unconditionally, so a sink registered in DECORATIONS without them
            # fails loudly per job. `assets` became a decorated sink when the
            # `governance_cluster` / `governance_project` decorations landed —
            # deployment-asserted owning team, criticality and customer-data
            # classification. Mirrors the vulnerabilities pair exactly; keep the
            # two definitions identical.
            #
            # ⚠️ CREATE TABLE IF NOT EXISTS does NOT evolve an existing table, so
            # adding these here does NOT reach tenant schemas already created.
            # They need an explicit ALTER per tenant schema; the datalake's
            # `_verify_provenance_columns()` boot check reports exactly which are
            # still missing (it derives its sink list from DECORATIONS, so it
            # picked `assets` up automatically).
            "decoration_provenance": {
                "data_type": "VARCHAR(64)", "category": "Audit & Tracking",
                "semantic_description": (
                    "Per-property record of where each governance value on this asset row came from. NULL = "
                    "unwritten; `decoration:<name>` = the apply job wrote it; anything else = an "
                    "observation the decoration layer must never overwrite."
                ),
            },
            "decoration_version": {
                "data_type": "VARCHAR(100)", "category": "Audit & Tracking",
                "semantic_description": (
                    "Version of the decoration pass that stamped this row."
                ),
            },
        }