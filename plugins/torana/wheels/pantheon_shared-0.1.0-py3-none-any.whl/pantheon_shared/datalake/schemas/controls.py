from typing import Dict, Any
from .base import TableSchema


class ControlsSchema(TableSchema):
    """Schema definition for the controls table.

    Security controls — protective/preventive mechanisms applied to assets, as
    distinct from `findings` (detections/problems) and `assets` (things you
    protect). Holds two populations distinguished by `source_system`:

      * Inventory of existing controls read from a provider
        (e.g. Cloudflare firewall/WAF rules), `source_system='cloudflare'`.
      * Compensating controls Torana pushes in response to a vulnerability
        (e.g. a Cloudflare WAF custom rule), `source_system='pantheon_waf'`,
        carrying a shadow→active→retired lifecycle and links back to the
        triggering vulnerability/alert.

    Two relationships are modeled distinctly:
      * `parent_control_id` — intra-control structure (a ruleset CONTAINS its
        rules; a security group CONTAINS its rules). Self-referential; NULL for
        top-level / standalone controls.
      * `protects_asset_id` — the asset this control defends (FK → assets).
    """

    @property
    def table_name(self) -> str:
        return "controls"

    @property
    def primary_key(self) -> str:
        return "torana_control_id"

    @property
    def description(self) -> str:
        return (
            "Security controls (WAF/firewall rules, network ACLs, compensating "
            "controls) inventoried from providers or pushed by Torana to mitigate "
            "vulnerabilities"
        )

    @property
    def category(self) -> str:
        return "Security Data"

    @property
    def timestamp_column(self) -> str:
        """Return the timestamp column for this table."""
        return "updated_at"

    @property
    def schema(self) -> Dict[str, Any]:
        return {
            # ── Core Identity ────────────────────────────────────────────────
            "torana_control_id": {
                "data_type": "VARCHAR(255)", "primary_key": True, "category": "Core Identity",
                "semantic_description": (
                "Torana's stable id for one security control, source-neutral so a rule inventoried from "
                "an enforcement point and one Torana deployed itself converge on the same row. Primary "
                "key of this table; one row per control per source, and a ruleset and its member rules "
                "are SEPARATE rows distinguished by `control_class`."
                ),
            },
            "external_id": {
                "data_type": "VARCHAR(255)", "category": "Core Identity",
                "semantic_description": (
                "The control's identifier in the system that owns it, kept verbatim so the rule can be "
                "traced back and re-fetched (a Cloudflare rule id, and the equivalent elsewhere). "
                "Provider-specific in shape and never comparable across sources."
                ),
            },
            "source_system": {
                "data_type": "VARCHAR(100)", "category": "Core Identity",
                "semantic_description": (
                    "The integration or internal producer that reported this control row. ⚠️ Determines "
                    "which other columns are populated at all, since sources differ in what they expose, "
                    "and it is the first thing to check when two rows describe the same control "
                    "differently."
                ),
            },
            "provider": {
                "data_type": "VARCHAR(50)", "category": "Core Identity",
                "semantic_description": (
                    "The vendor or platform family behind this control, set as a mapping constant. ⚠️ One "
                    "level COARSER than `source_system`: several data sources of one vendor share a "
                    "provider value, so group by `provider` to ask about ecosystems and by `source_system` "
                    "to identify the feed."
                ),
            },

            # ── Classification ───────────────────────────────────────────────
            # control_class: waf_rule | waf_ruleset | firewall | firewall_rule | network_acl ...
            "control_class": {
                "data_type": "VARCHAR(50)", "category": "Control Classification",
                "semantic_description": (
                "The KIND of control this row represents — `waf_rule`, `waf_ruleset`, `firewall`, "
                "`firewall_rule`, `network_acl` and similar. Distinguishes an individual rule from the "
                "ruleset that contains it, which is what makes a count of controls meaningful rather "
                "than double-counted."
                ),
            },
            # control_type: compensating | preventive | detective
            "engine": {
                "data_type": "VARCHAR(50)", "category": "Control Classification",
                "semantic_description": (
                "The enforcement engine that evaluates this control, and by extension the syntax its "
                "rule body is written in. Together with `control_class` it says what the control IS; "
                "`engine_rule_id` then identifies it within that engine."
                ),
            },
            "engine_rule_id": {
                "data_type": "VARCHAR(255)", "category": "Control Classification",
                "semantic_description": (
                "The rule's identifier inside its enforcement engine, used to correlate a Torana "
                "control row with the rule as the engine reports it at evaluation time. Meaningful only "
                "in combination with `engine`."
                ),
            },

            # ── Definition / rule body ───────────────────────────────────────
            "name": {
                "data_type": "VARCHAR(500)", "category": "Control Details",
                "semantic_description": (
                "Human-readable name of the SECURITY CONTROL, taken from the rule's own description "
                "field upstream. ⚠️ Distinct from `datastores.name`, `repositories.name` and "
                "`packages.name` — same column name, a control rather than an inventoried resource."
                ),
            },

            # ── Structure & associations ─────────────────────────────────────
            # parent_control_id: intra-control structure (ruleset/SG ⊃ rules). Self-FK.
            # protects_asset_id: the asset this control defends (FK → assets).

            # ── Provider context (Cloudflare et al.) ─────────────────────────
            "cloudflare_zone_id": {
                "data_type": "VARCHAR(255)", "category": "Provider Context",
                "semantic_description": (
                "The Cloudflare zone this control belongs to, carried so a rule can be attributed to "
                "the DNS zone it protects. Vendor-specific by design and NULL for every non-Cloudflare "
                "control."
                ),
            },
            "cloudflare_ruleset_id": {
                "data_type": "VARCHAR(255)", "category": "Provider Context",
                "semantic_description": (
                "The Cloudflare ruleset containing this rule, carried so individual rules can be "
                "grouped back to the ruleset deployed. Vendor-specific by design and NULL for every "
                "non-Cloudflare control."
                ),
            },

            # ── Lifecycle & status ───────────────────────────────────────────
            # status: shadow | active | retired | expired | inactive
            "status": {
                "data_type": "VARCHAR(50)", "category": "Lifecycle & Status",
                "semantic_description": (
                    "Lifecycle state of the control, derived at ingest from the provider's enabled flag; "
                    "the declared value domain is the authority for the permitted values. ⛔ A control can "
                    "be DEFINED without enforcing anything, so counting every row as protection overstates "
                    "coverage — restrict to enforcing states when asking what actually blocks traffic "
                    "today."
                ),
            },
            # ── Efficacy (T10 — proven before/after the control) ──────────────

            # ── Discovery & Inventory ────────────────────────────────────────
            "discovery_source": {
                "data_type": "VARCHAR(100)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "The FEED through which this control was discovered — which pipeline told the platform "
                    "it exists. ⚠️ Kept distinct from `source_system` because a control can be discovered "
                    "by one mechanism and maintained by another."
                ),
            },
            "discovery_method": {
                "data_type": "VARCHAR(50)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "By what MEANS this control was discovered — an API collection, an inventory sweep, or "
                    "a manual registration. Complements `discovery_source` (which feed) and is how "
                    "automatically-inventoried rows are separated from hand-registered ones."
                ),
            },
            "created_via": {
                "data_type": "VARCHAR(100)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "The Torana mechanism that wrote this control row — an integration sync, a replay, a "
                    "manual push, or a synthetic dataset load. ⛔ Provenance, not control data: it is what "
                    "separates genuinely ingested rows from generated ones, and a query measuring a real "
                    "estate should know which values are synthetic."
                ),
            },
            "modified_on": {
                "data_type": "TIMESTAMP_NTZ", "category": "Timeline",
                "semantic_description": (
                "When the control was last changed in its source system, as that system reports it. ⚠️ "
                "Not `updated_at`, which records when Torana last touched the row — a rule unchanged "
                "for a year still gets a fresh `updated_at` on every sync."
                ),
            },

            # ── Finding Linkage ──────────────────────────────────────────────
            "torana_vulnerability_id": {
                "data_type": "VARCHAR(255)", "category": "Finding Linkage",
                "semantic_description": (
                    "The vulnerability this compensating control was pushed in response to — the "
                    "`torana_vulnerability_id` of the row in `vulnerabilities` this control mitigates. "
                    "First-class and joinable so compensating-control matching is a key join, not a "
                    "string comparison across free-text fields. NULL for controls not tied to a specific "
                    "vulnerability (e.g. a standing baseline WAF rule). ⚠️ Populated by the control "
                    "ingest mapping; a control whose source names the finding it answers must set this "
                    "rather than leaving the linkage only in `custom_attributes`, where it cannot be "
                    "joined."
                ),
            },

            # ── Lifecycle / Review ───────────────────────────────────────────
            "expires_at": {
                "data_type": "TIMESTAMP_NTZ", "category": "Lifecycle / Review",
                "semantic_description": (
                    "The review-by date after which this compensating control must be re-validated — a "
                    "temporary mitigation is only as good as its next review. First-class so a sweep can "
                    "find controls PAST their review date and surface them, instead of the date living "
                    "only in `custom_attributes` where nothing queries it. NULL means no review-by was "
                    "recorded (a control with no expiry is a standing one). ⚠️ This is the control's own "
                    "review deadline, distinct from any expiry on the underlying risk acceptance."
                ),
            },

            # ── Tags & Metadata ──────────────────────────────────────────────
            "custom_attributes": {
                "data_type": "VARIANT", "category": "Tags & Metadata",
                "semantic_description": (
                    "Raw source-specific fields for this control, packed as JSON at ingest so nothing the "
                    "source returned is lost. ⛔ For investigation only — its keys vary by source, so "
                    "shipped SQL must read a declared column instead."
                ),
            },
        }
