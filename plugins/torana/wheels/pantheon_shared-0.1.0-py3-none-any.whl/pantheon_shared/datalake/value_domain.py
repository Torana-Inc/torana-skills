"""Per-column VALUE DOMAIN — what a column can hold, declared rather than observed.

NORTH_STAR_BUILD_SYSTEM § 4.7.

⛔ WHY THIS EXISTS. The point of a datalake is that we DECIDE what lands. ETL normalizes, so
a sink column has a known vocabulary and nobody should have to inspect rows to discover that
`severity` is Title-Case or that `Unknown` is possible. Without that we have "simply taken
data from integrations into separate tables" — tables merged, vocabularies not.

⚠️ MEASURED 2026-08-18 on T2, against the semantic overlay that preceded this:

    of 15 decidable enum columns, 11 had DRIFTED
    vulnerabilities.scan_type      declared SAST/DAST/SCA…  stored container_image_scan,
                                   cspm, gitlab_vulnerability_findings  -> ZERO OVERLAP
    vulnerabilities.severity       omitted `Unknown`, which CANONICAL_SEVERITIES declares
    vulnerabilities.status         omitted `Resolved`

Both of the day's production defects came from authoring against a declared value nothing
writes: `required_scan_types` offered `container`, and `vm.tf.em_034` tested a column the
decoration layer fills with a DEADLINE.

⭐ `normalize.py` already documents the consequence, unprompted:

    "SQL `IN` and `=` never match NULL, so a filter naming EVERY value in the vocabulary —
     WHERE severity IN ('Critical','High','Medium','Low','Info') — silently drops the
     absent rows while its author believes it means 'all'."

That is exactly the SQL a skill or a build agent writes when it trusts a stale overlay.

⛔ DECLARED, NEVER OBSERVED. Nothing here reads a tenant's rows. `populated` stays
render+ops only (§ 3.2.1) — a value domain is a fact about the SCHEMA AS IMPLEMENTED, stable
across syncs, while a row count is a fact about this morning. The distinction that governs
every entry below: **"what values exist?" is buildable; "are there enough?" is not.**
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

#: ⛔ A column whose vocabulary nobody has described yet. NOT the same as "free text".
#:
#: `closed=False` + empty `values` means **"not yet described"**. A reader must never take it
#: for "anything goes" — that ambiguity would recreate the very problem this module exists to
#: fix, in new clothes. Callers that need the distinction check `is_described()`.
UNDESCRIBED: Dict[str, Any] = {
    "values": [],
    "closed": False,
    "nullable": True,
    "source": None,
}


def _domain(values: Tuple[str, ...], *, closed: bool, nullable: bool, source: str) -> Dict[str, Any]:
    return {
        "values": list(values),
        "closed": closed,
        "nullable": nullable,
        # ⭐ PROVENANCE IS NOT DECORATION. It is what makes a wrong domain fixable: a reader
        # who disagrees with a value needs to know which file to argue with. A domain with no
        # source is unfalsifiable, which is how the previous overlay drifted unnoticed.
        "source": source,
    }


# ─────────────────────────────────────────────────────────────────────────────────────────
# SEEDED FROM CODE THAT ALREADY DECLARES THE VOCABULARY
#
# ⛔ These MIRROR constants in pantheon-integration; they are not a second opinion.
# `pantheon-shared` cannot import `torana_mesh` (shared is the dependency, not the
# dependent), so the values are restated here — and `tests/datalake/test_value_domain.py`
# asserts they still match the source. ⚠️ A mirror without that test is exactly the
# hand-maintained duplication that caused the drift.
# ─────────────────────────────────────────────────────────────────────────────────────────

#: torana_mesh/etl/normalize.py::CANONICAL_SEVERITIES
#: ⭐ CLOSED because `normalize_severity()` is TOTAL — an unrecognized spelling folds to
#: `Unknown` rather than passing through, so the tuple cannot be escaped.
_SEVERITY = ("Critical", "High", "Medium", "Low", "Info", "Unknown")

#: torana_mesh/etl/normalize.py::CANONICAL_STATUSES
_STATUS = ("Open", "Resolved", "Fixed", "Closed", "Suppressed", "Unknown")

#: torana_mesh/etl/normalize.py::CANONICAL_SCAN_TYPES — § 4.8 landed the normalizer.
#:
#: ⛔ CORRECTED 2026-08-18 (§ 4.7 enrichment). This previously declared the RAW source
#: spellings `container_image_scan / cspm / gitlab_vulnerability_findings`. § 4.8 normalized
#: the column and re-keyed the rows, so those three values are no longer written OR stored —
#: T2 holds SCA/Posture/Unknown. The old declaration had **zero overlap** with reality, which
#: is precisely the failure this module exists to prevent, reintroduced by a stale mirror.
#:
#: ⚠️ Still `closed=False`, deliberately. Three mappings write canonical literals, but TWO
#: write-paths bypass the normalizer entirely and pass source vocabulary through verbatim:
#:   sarif/vulnerabilities.yaml   expr `record.scan_type`  -> ingestors/sarif.py::_scan_type
#:                                returns `explicit.upper()`, so any producer string lands
#:   tenable/vulnerabilities.yaml expr `record.source`      -> raw Tenable source name
#: A normalizer that only SOME writers call does not close a domain (RULE 2).
_SCAN_TYPE = ("SAST", "SCA", "Secrets", "IaC", "Posture", "Unknown")

#: torana_mesh/etl/normalize.py::_IDENTITY_TYPE_ALIASES (the alias TARGETS).
#:
#: ⚠️ OPEN despite having a normalizer, and the reason is the interesting one:
#: `normalize_identity_type()` is deliberately NON-CLAMPING. Its documented fallback
#: snake_cases an unrecognized value and KEEPS it ("federatedIdentity" -> "federated_identity")
#: rather than folding to `unknown`, because a new provider's genuine type is information
#: worth preserving. That design choice is correct and is exactly why this cannot be closed —
#: contrast `normalize_severity`, which folds unknowns and therefore closes.
_IDENTITY_TYPE = (
    "user", "service_account", "service_account_key", "group", "team", "domain",
    "service_principal", "application", "bot", "unknown",
)

#: ⭐ ONE vocabulary, shared by FOUR `provider` columns — NOT four vocabularies.
#:
#: The § 4.7 handoff asked whether the `*.provider` columns are one domain or several, and
#: guessed they might partition (VCS hosts / IdPs / compliance tools). ⛔ The CODE says
#: otherwise: `provider` is uniformly the INTEGRATION SLUG — the tool a row was pulled from —
#: and the same slug is stamped across different tables by different mappings. `github`
#: appears on both repositories and identities; `gitlab`, `okta`, `aikido`, `tenable`,
#: `splunk`, `slack` each straddle 2-3 tables. There is no per-table partition to declare.
#:
#: ⚠️ `jira` (repositories) and `atlassian` (identities) are the SAME vendor stamped two
#: ways — a real inconsistency inside the shared vocabulary, recorded rather than smoothed.
#:
#: OPEN: two writers pass through un-enumerated source values —
#:   sarif/repositories.yaml  expr `record.provider`
#:   asset/repositories.yaml  expr `record.provider`  (asset_inventory.v1.json declares NO
#:                            enum for provider, only prose)
_PROVIDER = (
    "aikido", "atlassian", "aws", "aws_config", "azure", "bitbucket", "circleci",
    "cloudflare", "crowdstrike", "gcp", "github", "gitlab", "jira", "okta",
    "palo_alto_networks", "qualys", "salesforce", "self-hosted", "semgrep", "slack",
    "snyk", "splunk", "tenable", "wiz",
)

_PROVIDER_SOURCE = (
    "mappings: ~35 `op: set` provider constants across torana_mesh/mappings/** (one per "
    "integration family; the SAME slug appears on repositories/identities/findings/controls) "
    "+ sarif/repositories.yaml, asset/repositories.yaml (expr `record.provider` — PASSTHROUGH, "
    "no enum in asset_inventory.v1.json) — NOT normalized"
)

#: ⛔ ONE column, TWO writers, TWO CASINGS — and that is the finding, not a tidy-up.
#:
#: `criticality_name` is written by two paths that disagree on case:
#:   * ingest — `asset_inventory.v1.json` declares a JSON-Schema
#:     `enum: ["Critical","High","Medium","Low", null]` (TitleCase), and
#:   * decoration — `torana_mesh/etl/decoration_producers.py:1060` does
#:     `(dep.get("criticality") or "").strip().lower()`, so it writes `critical`,
#:     keyed against `_CRITICALITY_LEVEL = {"low":1,"medium":2,"high":3,"critical":4}`.
#:
#: Measured on T2 2026-08-19: `assets.criticality_name` holds `critical` on 734 rows and
#: NOTHING else — i.e. the decoration path is the only one that has run, and every row
#: VIOLATES the ingest contract's declared casing.
#:
#: ⚠️ BOTH casings are declared here deliberately. Declaring only TitleCase would tell an
#: author `WHERE criticality_name = 'Critical'` is valid — it returns 0 of 734 rows. Declaring
#: only lowercase would bless the decoration's casing as canonical and hide the divergence.
#: ⛔ The real fix is upstream (one writer must change), and until it does, an author needs to
#: see both or they will write a silent-zero filter. Recorded, not smoothed.
_CRITICALITY_NAME = ("Critical", "High", "Medium", "Low",
                     "critical", "high", "medium", "low")

_CRITICALITY_SOURCE = (
    "SPLIT VOCABULARY — torana_mesh/etl/ingestors/schemas/asset_inventory.v1.json "
    "(enum: Critical|High|Medium|Low) vs torana_mesh/etl/decoration_producers.py:1060 "
    "(.lower() -> critical|high|medium|low). Both writers are live; the casings differ."
)

#: ⭐ THE ROW'S ORIGIN CHANNEL — present on ALL 11 sink tables, and NOT the same concept as
#: `provider` even though 24 of the slugs coincide.
#:
#: `provider` names the INTEGRATION a row was pulled from. `source_system` names the channel
#: that produced the record, which includes three things that are not vendors at all:
#:   * `sarif`            — the SARIF upload channel (any scanner; see the OPEN note below)
#:   * `asset_inventory`  — the `torana ingest assets` push channel
#:   * `governance`       — governance facts asserted outside any scanner
#:   * `torana-entity-graph` — Torana's OWN declared-topology producer
#:     (etl/manifest_interpret.py::DECLARED_SOURCE), written by manifest parsing
#:   * `torana-entity-graph-reconciler` / `torana-graph-health` — Torana's own DERIVED
#:     writers (services/reconciliation.py:172 + services/entity_graph.py:76 `_RECON_SOURCE`;
#:     services/graph_health_verdict.py:71 `_SOURCE`). ⚠️ These dominate some tables —
#:     measured on T2, 33,268 of 185,208 `entity_edges` rows and 63 of 67 `findings` rows.
#:     A query treating `source_system` as "which vendor told us" silently attributes
#:     Torana's own inferences to a scanner.
#: ⛔ So `source_system` ⊅ `provider`. An author filtering `source_system = 'github'` and
#: expecting every GitHub-derived row will miss rows that arrived as `sarif`.
_SOURCE_SYSTEM = (
    "aikido", "asset_inventory", "aws", "aws_config", "azure", "bitbucket", "circleci",
    "cloudflare", "crowdstrike", "elasticsearch", "gcp", "github", "gitlab", "governance",
    "jira", "kubernetes", "okta", "palo_alto", "qualys", "salesforce", "sarif", "semgrep",
    "servicenow", "slack", "snyk", "splunk", "tenable", "torana-entity-graph",
    "torana-entity-graph-reconciler", "torana-graph-health", "wiz",
)

_SOURCE_SYSTEM_SOURCE = (
    "mappings: 97 files `op: set` a constant slug across torana_mesh/mappings/** "
    "+ etl/manifest_interpret.py::DECLARED_SOURCE ('torana-entity-graph') "
    "+ services/reconciliation.py:172, services/entity_graph.py:76 (_RECON_SOURCE), "
    "services/graph_health_verdict.py:71 (_SOURCE); "
    "⛔ OPEN because sarif/vulnerabilities.yaml:133 DERIVES `record.scanner_name` "
    "<- etl/ingestors/sarif.py:127 (`run.tool.driver.name` or 'unknown') — PASSTHROUGH of "
    "any SARIF producer's tool name — NOT normalized"
)

#: ⭐ HOW the row was produced, when it was NOT a normal integration sync. Stamped only by
#: non-standard producers; a normal mapping leaves it NULL (see the NULL note on the entry).
#:
#: ⛔ OPEN BY DESIGN, not by oversight. `etl/ingestors/schemas/entity_edges.v1.json` says so
#: in as many words: *"Free-form VARCHAR(50) — not a validation enum — so adding a producer
#: kind needs no schema-validation change."* Closing it here would contradict the contract
#: the ingest endpoint validates against.
#:
#: ⚠️ `manifest-parse` (hyphen) is NOT declared. It appears once, in a payload EXAMPLE in
#: pantheon-datalake/torana_datalake/corpus/bridge_registry.py:543, while every writer emits
#: `manifest_parse` (underscore). That is a documentation defect, not a second value — and
#: declaring it would bless a spelling nothing writes.
_CREATED_VIA = ("sdg_replay", "etl_derivation", "manifest_parse")

_CREATED_VIA_SOURCE = (
    "torana_mesh/etl/sdg_provenance.py::SDG_CREATED_VIA ('sdg_replay'), "
    "torana_mesh/etl/operators/derive_entity_edges.py:61::_ETL_CREATED_VIA "
    "('etl_derivation'), torana_mesh/etl/manifest_interpret.py:58::DECLARED_CREATED_VIA "
    "('manifest_parse'); ⛔ OPEN by upstream design — "
    "etl/ingestors/schemas/entity_edges.v1.json declares it free-form VARCHAR(50), "
    "explicitly NOT a validation enum"
)

DOMAINS: Dict[Tuple[str, str], Dict[str, Any]] = {
    # ── vulnerabilities ──────────────────────────────────────────────────────────────────
    ("vulnerabilities", "severity"): _domain(
        _SEVERITY, closed=True, nullable=True,
        source="pantheon-integration/torana_mesh/etl/normalize.py::CANONICAL_SEVERITIES",
    ),
    # ⭐ MIGRATED from the semantic model's `enum` (Phase 2a). CVSS v3.1 calls this
    # `exploitCodeMaturity` (vector `E:`) with values Unproven|POC|Functional|High, which is
    # what the model declared. ⛔ OPEN, not closed: BOTH writers are RAW PASSTHROUGHS of a
    # vendor field with no normalizer —
    #   tenable/vulnerabilities.yaml:173  expr `record.plugin.vpr.drivers.exploit_code_maturity`
    #   sarif/vulnerabilities.yaml:213    expr `record.exploit_code_maturity`
    # so a vendor may emit any spelling (`PoC`, `proof-of-concept`) and it lands unchanged.
    # ⚠️ 0 rows on T2, so there is NO observed evidence either way — which is precisely why
    # closure must come from code, and the code does not clamp.
    ("vulnerabilities", "exploit_code_maturity"): _domain(
        ("Unproven", "POC", "Functional", "High"), closed=False, nullable=True,
        source="CVSS v3.1 exploitCodeMaturity (E:) — RAW PASSTHROUGH, no normalizer: "
               "tenable/vulnerabilities.yaml:173, sarif/vulnerabilities.yaml:213",
    ),
    ("vulnerabilities", "vulnerability_status"): _domain(
        _STATUS, closed=False, nullable=True,
        # ⛔ DOWNGRADED from closed=True (§ 4.7 enrichment, 2026-08-18). The mirror was right
        # about the VALUES but wrong about closure: snyk/vulnerabilities.yaml writes
        # `record.attributes.status` as a RAW passthrough (source vocab `open|resolved|
        # ignored`, lowercase), bypassing normalize_status entirely. A reader trusting
        # closed=True would author `WHERE vulnerability_status IN ('Open',...)` and silently
        # drop every Snyk row. The gcp/sarif paths ARE normalized; snyk is the hole.
        source="pantheon-integration/torana_mesh/etl/normalize.py::CANONICAL_STATUSES "
               "(via normalize_status in gcp/*.yaml, sarif set-literal) "
               "+ snyk/vulnerabilities.yaml:95 (expr `record.attributes.status` — PASSTHROUGH, "
               "NOT normalized: open|resolved|ignored)",
    ),
    ("vulnerabilities", "scan_type"): _domain(
        _SCAN_TYPE, closed=False, nullable=True,
        source="pantheon-integration/torana_mesh/etl/normalize.py::CANONICAL_SCAN_TYPES "
               "(§ 4.8; applied in gcp/container_analysis_occurrences.yaml, gcp/scc_findings.yaml, "
               "gitlab/vulnerabilities.yaml) + sarif/vulnerabilities.yaml, "
               "tenable/vulnerabilities.yaml (PASSTHROUGH — NOT normalized)",
    ),
    ("vulnerabilities", "cna_severity"): _domain(
        _SEVERITY, closed=True, nullable=True,
        source="pantheon-integration/torana_mesh/etl/normalize.py::CANONICAL_SEVERITIES "
               "(via normalize_severity in mappings/tenable/vulnerabilities.yaml:287 — sole writer)",
    ),
    ("vulnerabilities", "priority"): _domain(
        ("Critical", "High", "Medium", "Low"), closed=True, nullable=True,
        # ⭐ Closed by an EXHAUSTIVE SQL CASE rather than a normalizer: the sole writer bands a
        # score with a total `ELSE 'Low'`, so no fifth value is reachable. The human-override
        # guard (`priority_source NOT LIKE 'human%%'`) anticipates a writer that does not exist
        # yet — if one lands, it must be constrained to these four or this reopens.
        source="pantheon-integration/torana_mesh/services/priority_recompute.py::_band "
               "(SQL CASE literals; sole registered writer `derived_state.priority_recompute`)",
    ),
    ("vulnerabilities", "package_manager"): _domain(
        (), closed=False, nullable=True,
        # ⚠️ EXAMINED, and the empty tuple is the FINDING: all three writers are passthroughs
        # and NOT ONE declares a literal. The vocabulary is OSV.dev's ecosystem list, owned
        # outside this repo. Values on T2 (`os`, `pypi`, `go`, `go_stdlib`) are observed
        # output, and RULE 1 forbids importing them as a declaration.
        source="mappings: sarif/vulnerabilities.yaml (`record.package_manager` <- "
               "etl/ingestors/sarif.py <- pantheon-cli/skills/torana-scan/references/"
               "osv_lookup.py, `ecosystem.lower()`), gcp/container_analysis_occurrences.yaml "
               "(`_ca_pkg_manager` <- etl/extractors/gcp.py, `packageType.lower()`) "
               "— ALL PASSTHROUGH, zero literals declared in code",
    ),
    ("vulnerabilities", "vulnerability_category"): _domain(
        # ⭐ CONFORMANCE FIX (§ 3.6.2, 2026-08-19): GitLab writes its scan-type vocabulary
        # here (`dependency_scanning`, `secret_detection` — measured on T2), which no
        # declared value covered. ⚠️ This DEEPENS the casing disagreement noted below
        # rather than resolving it: the column now demonstrably holds three vocabularies
        # (GCP uppercase, GitLab snake_case, the `unknown` literal). Declaring what is
        # written is still correct — the alternative is a domain that lies about legal
        # filters — but normalising them remains § 4.8-shaped work.
        ("VULNERABILITY", "MISCONFIGURATION", "unknown",
         "dependency_scanning", "secret_detection"),
        closed=False, nullable=True,
        # ⚠️ The three declared literals disagree on CASE (`unknown` vs the two uppercase),
        # and two writers pass raw `report_type`/`findingClass` through. Recorded as-is;
        # normalizing it is a § 4.8-shaped migration, out of scope here.
        source="mappings: gcp/container_analysis_occurrences.yaml (literal 'VULNERABILITY'), "
               "gcp/scc_findings.yaml (`record.findingClass` or 'MISCONFIGURATION'), "
               "gitlab/vulnerabilities.yaml (`record.report_type` or 'unknown') "
               "— PASSTHROUGH + per-source literals, NOT normalized",
    ),
    ("vulnerabilities", "vulnerability_type"): _domain(
        ("host_detection",), closed=False, nullable=True,
        source="mappings: qualys/host_detections.yaml:71 (constant 'host_detection') "
               "+ snyk/vulnerabilities.yaml (`record.attributes.type` — PASSTHROUGH; Snyk's "
               "package_vulnerability|license|cloud|code|config|custom is comment-only, "
               "not enforced) — NOT normalized",
    ),
    ("vulnerabilities", "exploitability_status"): _domain(
        ("exploited", "not_exploited", "unreachable", "inconclusive"),
        closed=False, nullable=True,
        # ⚠️ OPEN despite every CLIENT enumerating the four values, because the SERVER does
        # not: `_VulnUpdateBody.exploitability_status` is a bare `Optional[str]` whose
        # vocabulary lives only in a trailing comment. Closure enforced solely by a CLI
        # `click.Choice` is closure any other caller can bypass (RULE 2: any doubt -> open).
        source="pantheon-cli/torana_cli/vulnerability.py + pantheon-cli/torana_cli/pentest.py "
               "(click.Choice); server-side torana_mesh/api/routes/ingest.py::_VulnUpdateBody "
               "accepts an UNVALIDATED Optional[str] — no ETL writer exists",
    ),
    ("vulnerabilities", "dependency_type"): _domain(
        ("direct",), closed=False, nullable=True,
        source="mappings: sarif/vulnerabilities.yaml (`record.dependency_type` — PASSTHROUGH) "
               "; the only literal is a producer-side DEFAULT at "
               "pantheon-cli/skills/torana-scan/references/osv_lookup.py:215 — NOT normalized",
    ),
    ("vulnerabilities", "plugin_type"): _domain(
        (), closed=False, nullable=True,
        # ⚠️ EXAMINED: sole writer is a raw passthrough. The mapping comment names `local`
        # and `remote` as EXAMPLES — a comment is not a writer, so they are not declared.
        source="mappings: tenable/vulnerabilities.yaml:71-75 (sole writer, "
               "`record.plugin.type` — PASSTHROUGH of Tenable's vocabulary; zero literals "
               "declared in code) — NOT normalized",
    ),
    ("vulnerabilities", "workaround_type"): _domain(
        (), closed=False, nullable=True,
        # ⚠️ EXAMINED: sole writer is a raw passthrough of a Tenable vendor field; the
        # mapping comment quotes Tenable's documentation, which is not a code declaration.
        source="mappings: tenable/vulnerabilities.yaml:301-305 (sole writer, "
               "`record.plugin.workaround_type` — PASSTHROUGH; zero literals declared "
               "in code) — NOT normalized",
    ),
    # ⭐ THE RECIPE THAT PRODUCED `priority`, as a `+`-joined term list. NOT a flat enum:
    # the sole writer builds it with `CONCAT_WS('+', …)` over SIX independent CASE arms, so
    # the legal values are the ORDERED SUBSETS of the term vocabulary below, not 10 opaque
    # strings. ⚠️ Order is fixed by the CONCAT_WS argument order — `severity+cvss+epss`
    # exists, `epss+severity` cannot. An author matching one term must use LIKE/`ANY`, never
    # `=`: `priority_source LIKE '%%kev%%'`, because `= 'kev'` matches nothing (T2: 0 rows).
    #
    # ⛔ CLOSED, and the closure comes from the SQL, not from the 10 values observed on T2.
    # Each arm emits a fixed literal or NULL, `CONCAT_WS` skips the NULLs, and the whole
    # thing is `NULLIF(…, '')` — so no arm can contribute an unlisted token.
    #
    # ⚠️ `severity` and `unscored-cve` are MUTUALLY EXCLUSIVE and always first: the arm is
    # `CASE WHEN severity IS NULL THEN 'unscored-cve' ELSE 'severity' END`, which is TOTAL,
    # so every non-NULL value begins with exactly one of them. `unscored-cve` marks a CVE
    # NVD has not scored yet — it is scored on its OTHER signals, NOT treated as zero.
    #
    # ⛔ `human` is DELIBERATELY NOT DECLARED. `priority_recompute` guards its UPDATE with
    # `priority_source NOT LIKE 'human%%'` to preserve an override, but grepping
    # pantheon-integration / pantheon-datalake / pantheon-cli finds NO writer that ever sets
    # one. Declaring it would be declaring a value nothing writes — the precise defect this
    # module exists to prevent. If that writer is built, add it and reopen the closure.
    ("vulnerabilities", "priority_source"): _domain(
        ("severity", "unscored-cve", "cvss", "epss", "kev", "exposure", "criticality"),
        closed=True, nullable=True,
        source="pantheon-integration/torana_mesh/services/priority_recompute.py::_priority_sql "
               "(CONCAT_WS('+') over six total CASE arms; sole registered writer "
               "`derived_state.priority_recompute`). ⚠️ TERM vocabulary — a stored value is a "
               "'+'-joined ordered SUBSET (e.g. 'severity+cvss+epss'), never a single term.",
    ),
    # ⚠️ OPEN. Two mappings `op: set` a constant, but sarif/vulnerabilities.yaml derives it
    # from `record.scanner_name`, which etl/ingestors/sarif.py:127 reads out of the uploaded
    # document (`run.tool.driver.name`, defaulting to the literal 'unknown'). Any SARIF
    # producer therefore names itself here — semgrep, trivy, codeql, a bespoke scanner.
    # ⚠️ NOT the same grain as `source_system`: on T2 `source_system='gcp'` covers 114,151
    # rows while `scanner_name` splits them into gcp_container_analysis (114,117) and
    # gcp_security_command_center (34). `scanner_name` names the ENGINE, `source_system` the
    # channel. Group by the wrong one and two distinct scanners collapse into one number.
    ("vulnerabilities", "scanner_name"): _domain(
        ("gcp_container_analysis", "gcp_security_command_center", "unknown"),
        closed=False, nullable=True,
        source="mappings: gcp/container_analysis_occurrences.yaml:227 + gcp/scc_findings.yaml:105 "
               "(`op: set` constants); ⛔ OPEN because sarif/vulnerabilities.yaml derives "
               "`record.scanner_name` <- etl/ingestors/sarif.py:127 "
               "(`run.tool.driver.name` or 'unknown') — PASSTHROUGH — NOT normalized",
    ),
    # ⭐ THE SYNTHETIC-VS-REAL FILTER, and its NULL is the load-bearing part.
    # ⛔ NULL means a GENUINELY INGESTED row — measured on T2, `created_via` is NULL on all
    # 114,151 vulnerabilities and all 1,335 assets. It is stamped ONLY by non-standard
    # producers, so `WHERE created_via IS NULL` is the real-estate filter and
    # `WHERE created_via = 'sdg_replay'` is what `clear-sdg-data` purges on.
    # ⚠️ `WHERE created_via != 'sdg_replay'` DROPS EVERY REAL ROW — SQL `!=` never matches
    # NULL. Use `IS DISTINCT FROM` or `IS NULL`. This is the exact silent-drop that
    # normalize.py's docstring warns about, on the one column where it costs the whole table.
    #
    # ⛔ OPEN, by explicit upstream DESIGN, not by omission: entity_edges.v1.json states
    # "Free-form VARCHAR(50) — not a validation enum — so adding a producer kind needs no
    # schema-validation change." Declaring this closed would contradict the ingest contract.
    ("vulnerabilities", "created_via"): _domain(
        _CREATED_VIA, closed=False, nullable=True, source=_CREATED_VIA_SOURCE,
    ),
    # ⚠️ OPEN, and the passthrough is the whole finding. 27 mappings `op: set` a constant
    # slug (the same integration-slug vocabulary `provider` uses), but
    # sarif/vulnerabilities.yaml:133 DERIVES it from `record.scanner_name`, which
    # etl/ingestors/sarif.py:127 reads straight out of the uploaded SARIF
    # (`run.tool.driver.name`, defaulting to `unknown`). Any tool that can emit SARIF can
    # therefore land any string here — one passthrough writer opens the column (RULE 2).
    #
    # ⚠️ `sarif` and `asset_inventory` are INGEST CHANNELS, not vendors, and
    # `torana-entity-graph` is Torana's own declared-topology producer
    # (etl/manifest_interpret.py::DECLARED_SOURCE) — so this vocabulary is NOT a subset of
    # `_PROVIDER` even though it overlaps it heavily. Do not join the two columns as if the
    # values were interchangeable.
    ("vulnerabilities", "source_system"): _domain(
        _SOURCE_SYSTEM, closed=False, nullable=True, source=_SOURCE_SYSTEM_SOURCE,
    ),

    # ── assets ───────────────────────────────────────────────────────────────────────────
    # ⭐ Same vocabulary and the same NULL rule as vulnerabilities.created_via — NULL means
    # a genuinely ingested row. ⚠️ `!= 'sdg_replay'` drops every real row (SQL != vs NULL).
    ("assets", "created_via"): _domain(
        _CREATED_VIA, closed=False, nullable=True, source=_CREATED_VIA_SOURCE,
    ),
    # ⭐ ONE vocabulary, ELEVEN tables — see _SOURCE_SYSTEM. OPEN for the same reason
    # everywhere: the SARIF channel passes an uploaded tool name straight through.
    ("assets", "source_system"): _domain(
        _SOURCE_SYSTEM, closed=False, nullable=True, source=_SOURCE_SYSTEM_SOURCE,
    ),
    # ⭐ MIGRATED from the semantic model's `enum` (Phase 2a). The model declared
    # `Critical, High, Medium, Low` and 734 of 734 rows hold `critical` — a silent-zero for
    # any author trusting it. See _CRITICALITY_NAME above for why both casings are declared.
    ("assets", "criticality_name"): _domain(
        _CRITICALITY_NAME, closed=False, nullable=True, source=_CRITICALITY_SOURCE,
    ),
    #
    # ⛔ CONFORMANCE FAILURE RECORDED, NOT PAPERED OVER (§ 3.6.2, measured 2026-08-19).
    #
    # T2 holds **62 undeclared values** in this column — `Pod`, `Bucket`, `ServiceAccount`,
    # `ValidatingWebhookConfiguration`, … — none of which appear below. ⚠️ § 3.6.2 offers two
    # resolutions for observed ⊄ declared: fix the DECLARATION, or route the value as a DATA
    # DEFECT. This is the second, and adding the 62 would have been the wrong call.
    #
    # WHY IT IS A DATA DEFECT: every one of the 62 comes from ONE writer,
    # `gcp/cloud_assets.yaml:108`, which stores GCP's raw resource Kind verbatim:
    #
    #     expr: "str(record.get('assetType') or 'cloud_asset').split('/')[-1]"
    #
    # Every OTHER mapping writes the snake_case vocabulary declared below. Measured split on
    # T2: gcp = 1,222 rows / 69 distinct CamelCase Kinds; jira = 1 row (`jira_board`);
    # kubernetes = 1 row (`kubernetes_workload`). So this single column carries TWO
    # incompatible vocabularies, and `WHERE asset_type = 'storage_bucket'` silently misses
    # all 1,222 GCP rows while `= 'Bucket'` finds them.
    #
    # ⛔ Declaring the 62 would RATIFY the bug — it would tell every future author that
    # CamelCase Kinds are a legitimate half of this column's domain, making the
    # normalisation fix harder rather than easier. The fix belongs in the mapping (route
    # GCP's Kind through a normaliser, as `normalize_identity_type` does for identities),
    # and is out of scope here because it is a data-migration-shaped change.
    #
    # ⭐ Recorded in Torana_Schema_Semantics.md § 5.9 as a defect found but not fixed.
    ("assets", "asset_type"): _domain(
        ("host", "endpoint", "repository", "service", "application", "storage_account",
         "virtual_machine", "dns_zone", "virtual_system", "artifact_repository",
         "storage_bucket", "firewall_rule", "public_address", "cloud_sql_instance",
         "kubernetes_cluster", "forwarding_rule", "compute_instance", "ec2_instance",
         "s3_bucket", "jira_board", "salesforce_organization", "custom_setting",
         "custom_object", "kubernetes_workload", "compose_service", "unknown",
         "cloud_resource", "cloud_asset"),
        closed=False, nullable=True,
        # ⚠️ These 28 are the literals ~28 mappings DECLARE. Six further writers pass source
        # vocabulary through verbatim — most consequentially gcp/cloud_assets.yaml, whose
        # `assetType.split('/')[-1]` emits GCP CAI Kinds (`Bucket`, `ReplicaSet`, `Address`…).
        # ⛔ Those PascalCase kinds are NOT listed here on purpose: they are observed output of
        # a passthrough, not a declared vocabulary, and RULE 1 forbids importing them from
        # rows. `closed=False` is what tells a reader the list is not exhaustive.
        source="mappings: ~28 assets mappings under torana_mesh/mappings/** (per-source "
               "literals) + PASSTHROUGH writers wiz/cloud_resources.yaml, "
               "aikido/cloud_resources.yaml, tenable/assets.yaml, aws_config/resources.yaml "
               "(rename), aws_config/compliance.yaml, gcp/cloud_assets.yaml (raw GCP CAI kind) "
               "+ torana_mesh/etl/manifest_interpret.py — NOT normalized",
    ),
    ("assets", "cloud_provider"): _domain(
        ("aws", "gcp", "azure", "generic"), closed=False, nullable=True,
        # ⚠️ A DIFFERENT vocabulary from `_PROVIDER` — these are cloud IaaS names, not
        # integration slugs, so they are deliberately NOT merged into the shared tuple.
        source="mappings: aws_config/resources.yaml, gcp/cloud_assets.yaml, tenable/assets.yaml, "
               "kubernetes/workloads.yaml (literal derives) + aikido/cloud_resources.yaml "
               "(`record.provider.lower()` — PASSTHROUGH); "
               "torana_mesh/integrations/kubernetes_auth.py::_HOST_TO_CLOUD_PROVIDER "
               "— NOT normalized",
    ),
    ("assets", "asset_environment"): _domain(
        ("production",), closed=False, nullable=True,
        # ⚠️ `production` is the ONLY value any code declares (the platform default). Every
        # other write path is free-text operator/CMDB input. The schema docstring names
        # "production, staging, development, test, qa" but nothing enforces it — a docstring
        # is not a writer, so it is not a domain.
        source="torana_mesh/etl/expression.py::default_environment (Environment.PRODUCTION) "
               "+ PASSTHROUGH writers asset/assets.yaml (`record.environment`), "
               "servicenow/cmdb_ci_server.yaml (rename u_environment), "
               "kubernetes/workloads.yaml (operator `env_label`), "
               "torana_mesh/api/routes/ingest.py::_govern_new_value — NOT normalized",
    ),
    ("assets", "asset_status"): _domain(
        ("active", "inactive"), closed=False, nullable=True,
        # ⚠️ ONE writer, a total two-branch ternary — so today the column can only hold these
        # two. Declared OPEN anyway: closure here is an ACCIDENT of there being a single
        # integration, not a normalizer, and the second mapping to write this column reopens
        # it silently. RULE 2 — when in doubt, open. (Also NULL on T2: nothing has run it.)
        source="mappings: wiz/cloud_resources.yaml:44 (sole writer, `'active' if "
               "record.status == 'ACTIVE' else 'inactive'`) — NOT normalized",
    ),

    ("assets", "image_ownership"): _domain(
        ("first_party", "vendor", "third_party", "undetermined"),
        closed=True, nullable=True,
        # ⭐ CLOSED, and RULE 2 ("when in doubt, open") does not apply — the doubt it guards
        # against is a PASSTHROUGH writer letting an upstream vocabulary in. There is none
        # here. Both write paths are total over this tuple:
        #   1. the declaration door validates against `PropertyEntry.allowed_values`
        #      (domain_properties/vm.py::image_ownership) before it can store anything;
        #   2. the derivation is a two-branch total function — an `artifacts` row yields
        #      `first_party`, its absence yields `undetermined`, with no third outcome and
        #      no value taken from ingested data.
        # ⛔ `vendor` / `third_party` are declared but derivation CANNOT emit them: splitting
        # those two requires a human, so a query filtering on them reads declarations only.
        # ⚠️ NULL ≠ `undetermined`. NULL means nothing has resolved this row yet;
        # `undetermined` means the resolver ran and the data genuinely cannot say.
        source="pantheon-shared domain_properties/vm.py::image_ownership.allowed_values "
               "(the single declaration, enforced at the /api/v1/properties door) + "
               "torana_mesh/services/image_ownership.py::resolve_image_ownership "
               "(derivation; total two-branch) — no passthrough writer exists",
    ),

    # ── findings ─────────────────────────────────────────────────────────────────────────
    # ⭐ Same vocabulary and the same NULL rule as vulnerabilities.created_via — NULL means
    # a genuinely ingested row. ⚠️ `!= 'sdg_replay'` drops every real row (SQL != vs NULL).
    ("findings", "created_via"): _domain(
        _CREATED_VIA, closed=False, nullable=True, source=_CREATED_VIA_SOURCE,
    ),
    # ⭐ ONE vocabulary, ELEVEN tables — see _SOURCE_SYSTEM. OPEN for the same reason
    # everywhere: the SARIF channel passes an uploaded tool name straight through.
    ("findings", "source_system"): _domain(
        _SOURCE_SYSTEM, closed=False, nullable=True, source=_SOURCE_SYSTEM_SOURCE,
    ),
    ("findings", "severity"): _domain(
        _SEVERITY, closed=False, nullable=True,
        # ⛔ DOWNGRADED from closed=True (§ 4.7 enrichment, 2026-08-18) — DRIFT FOUND IN DATA.
        # Every ETL mapping routes through normalize_severity, so the Title-Case tuple is
        # right for the ETL path. But two REGISTERED platform writers bypass ETL entirely and
        # write LOWERCASE literals directly (§ 3.9.2 "direct path"): reconciliation.py
        # ("medium"/"low"/`.lower()`) and graph_health_verdict.py ("info"/"medium"/"high",
        # plus a TENANT-CONFIGURED severity from the graph_health_expectations table).
        # Measured on T2: 38 of 39 findings rows are lowercase; only the 1 gitlab row is
        # Title-Case. `WHERE severity = 'Medium'` matches 1 row and misses 35.
        source="pantheon-integration/torana_mesh/etl/normalize.py::CANONICAL_SEVERITIES "
               "(ETL path, via normalize_severity in all findings mappings) + LOWERCASE "
               "direct writers torana_mesh/services/reconciliation.py::_emit_findings and "
               "services/graph_health_verdict.py::_emit (the latter also writes a "
               "tenant-configured GraphHealthExpectation.severity) — casing NOT reconciled",
    ),
    ("findings", "provider"): _domain(
        _PROVIDER, closed=False, nullable=True,
        source=_PROVIDER_SOURCE,
    ),
    ("findings", "finding_category"): _domain(
        ("compliance", "code_vulnerability", "code_quality", "ci_cd", "entity_graph",
         "exposure"),
        closed=False, nullable=True,
        # ⚠️ Every writer is a compile-time literal, so the set IS exhaustive today. Still
        # OPEN: nothing MECHANISM-side prevents the next mapping from adding a seventh value,
        # and an all-literals set is re-derived by hand each time. Honest open > brittle closed.
        source="mappings: qualys/compliance_findings.yaml, semgrep/findings.yaml, "
               "semgrep/rules.yaml, circleci/pipelines.yaml + services/reconciliation.py, "
               "services/deployment_intelligence.py, services/graph_health_verdict.py"
               "::_FINDING_CATEGORY (per-source literals — NOT normalized)",
    ),
    ("findings", "finding_type"): _domain(
        ("compliance_check", "detection", "ci_pipeline", "rule_definition", "sast_finding",
         "pipeline_run", "compliance", "access_assignment", "group_access_assignment",
         "security_event", "scan_run", "threat_log", "security_issue", "unknown",
         "asset_reconciliation", "policy_violation", "data_quality"),
        closed=False, nullable=True,
        source="mappings: qualys/compliance_findings.yaml, crowdstrike/detections.yaml, "
               "gitlab/pipelines.yaml, semgrep/*.yaml, circleci/pipelines.yaml, "
               "aws_config/*.yaml, okta/*.yaml, tenable/scan_results.yaml, "
               "palo_alto/threat_logs.yaml, splunk/security_events.yaml (literals) "
               "+ wiz/security_issues.yaml, aikido/issues.yaml (PASSTHROUGH) "
               "+ services/{reconciliation,deployment_intelligence,graph_health_verdict}.py "
               "— NOT normalized",
    ),
    ("findings", "finding_subcategory"): _domain(
        # ⭐ CONFORMANCE FIX (§ 3.6.2, 2026-08-19): the last three are tenant-authored
        # GraphHealthExpectation keys observed on T2. They are added as EVIDENCE of the
        # unbounded path the note below describes — ⛔ this tuple can never be
        # exhaustive, so a reader must treat it as examples, not as the legal set.
        ("shadow", "drift", "reachable", "remediate", "compensating_controls_required",
         "review", "verdict",
         "enrichment_null_rate", "join_overlap", "no_dual_key"),
        closed=False, nullable=True,
        # ⚠️ No YAML mapping writes this at all — three Python services do. Three of the four
        # write paths are bounded; the fourth writes `ExpectationResult.key`, which is a
        # TENANT-AUTHORED row in graph_health_expectations. A tenant can mint a new value at
        # runtime, so no static tuple can ever be exhaustive here.
        source="torana_mesh/services/reconciliation.py::_Finding.subtype "
               "(shadow|drift|reachable) + services/deployment_intelligence.py::_policy_label "
               "(remediate|compensating_controls_required|review) + "
               "services/graph_health_verdict.py (literal 'verdict' + UNBOUNDED "
               "tenant-configured GraphHealthExpectation.key) — no YAML writer",
    ),
    ("findings", "status"): _domain(
        # ⭐ CONFORMANCE FIX (§ 3.6.2, 2026-08-19): `success` is written and was
        # undeclared. It is a CI-pipeline outcome, not a triage state — further evidence
        # for the casing/vocabulary collision documented below, which is exactly why
        # this domain is and stays `closed=False`.
        ("active", "open", "resolved", "unknown", "success"),
        closed=False, nullable=True,
        # ⛔ The worst casing collision in the schema: nine of twelve write paths are raw
        # renames/passthroughs, so this ONE column holds `open`, `active`, `COMPLIANT` and
        # `CREATE_COMPLETE` simultaneously. normalize_status() EXISTS but is wired only to
        # vulnerabilities — never to findings. Recorded, not fixed (§ 4.8-shaped work).
        source="mappings: qualys/compliance_findings.yaml, gitlab/pipelines.yaml, "
               "semgrep/*.yaml, circleci/pipelines.yaml, wiz/security_issues.yaml, "
               "aws_config/*.yaml, aikido/issues.yaml, tenable/scan_results.yaml "
               "(6 renames + 3 derives — RAW vendor vocabulary) + "
               "services/{reconciliation,deployment_intelligence,graph_health_verdict}.py "
               "(open|resolved) — normalize_status() is NOT applied to findings.status",
    ),
    ("findings", "state"): _domain(
        ("open", "closed"), closed=False, nullable=True,
        # ⚠️ Sole writer is a total two-literal conditional, so the set is complete today.
        # OPEN for the asset_status reason (single-writer closure is not a mechanism), and
        # note the casing diverges from CANONICAL_STATUSES on purpose-by-accident.
        source="mappings: gitlab/pipelines.yaml:53-57 (sole writer, "
               "`'closed' if record.status in (...) else 'open'`) — lowercase, "
               "NOT routed through normalize_status",
    ),
    ("findings", "asset_type"): _domain(
        (), closed=False, nullable=True,
        # ⚠️ EXAMINED: exactly ONE of the 16 findings mappings writes this, and it passes the
        # raw AWS Config `ResourceType` namespace (`AWS::EC2::Instance`, …) straight through.
        # ⛔ Not to be confused with assets.asset_type — the many asset_type mappings target
        # the `assets` table, not `findings`.
        source="mappings: aws_config/compliance.yaml:49-53 (sole findings.asset_type writer, "
               "raw AWS ResourceType — PASSTHROUGH; zero literals declared in code) "
               "— NOT normalized",
    ),
    ("findings", "event_type"): _domain(
        (), closed=False, nullable=True,
        # ⚠️ EXAMINED: sole writer is an `op: rename` of Okta's `eventType`, an open-ended
        # vendor taxonomy (`user.session.start`, …). A rename declares nothing.
        source="mappings: okta/system_log.yaml:61-65 (sole writer, `op: rename` "
               "eventType->event_type — PASSTHROUGH of Okta's event taxonomy; zero literals "
               "declared in code) — NOT normalized",
    ),

    # ── issues ───────────────────────────────────────────────────────────────────────────
    # ⭐ Same vocabulary and the same NULL rule as vulnerabilities.created_via — NULL means
    # a genuinely ingested row. ⚠️ `!= 'sdg_replay'` drops every real row (SQL != vs NULL).
    ("issues", "created_via"): _domain(
        _CREATED_VIA, closed=False, nullable=True, source=_CREATED_VIA_SOURCE,
    ),
    # ⭐ ONE vocabulary, ELEVEN tables — see _SOURCE_SYSTEM. OPEN for the same reason
    # everywhere: the SARIF channel passes an uploaded tool name straight through.
    ("issues", "source_system"): _domain(
        _SOURCE_SYSTEM, closed=False, nullable=True, source=_SOURCE_SYSTEM_SOURCE,
    ),
    ("issues", "severity"): _domain(
        _SEVERITY, closed=True, nullable=True,
        # ⭐ The ONLY column in this pass that closes on the normalizer rule cleanly: one
        # writer, wrapped in normalize_severity, which folds unknowns.
        source="pantheon-integration/torana_mesh/etl/normalize.py::CANONICAL_SEVERITIES "
               "(via normalize_severity in mappings/gitlab/issues.yaml:76 — sole writer; "
               "jira/issues.yaml deliberately does NOT write severity)",
    ),
    ("issues", "status"): _domain(
        ("Open", "In Progress", "Done", "Closed", "Blocked", "opened", "closed", "merged",
         "locked"),
        closed=False, nullable=True,
        # ⛔ TWO CASINGS IN ONE COLUMN, both declared. Jira maps through a file-local alias
        # dict into Title Case; both GitLab mappings `rename` state->status, landing
        # lowercase `opened|closed|merged|locked` verbatim. `WHERE status = 'Closed'` misses
        # every GitLab row (426 of 662 on T2 are `merged`). The Jira mapping's comment claims
        # Title Case "matches gitlab's own convention" — that claim is FALSE against the code.
        source="mappings: jira/issues.yaml:233-237 (inline alias dict -> "
               "Open|In Progress|Done|Closed|Blocked) + gitlab/issues.yaml:29, "
               "gitlab/merge_requests.yaml:44 (`op: rename` state->status — RAW GitLab "
               "vocabulary, lowercase) — normalize_status deliberately NOT applied",
    ),
    ("issues", "issue_type"): _domain(
        # ⭐ CONFORMANCE FIX (Torana_Schema_Semantics.md § 3.6.2, 2026-08-19). The Jira
        # passthrough below is explicitly UNBOUNDED — issue types are per-project
        # admin-configurable — so the declared tuple was missing every value Jira
        # actually emits. Measured on T2: Task 134, Bug 73, Improvement 6, Epic 2.
        # ⛔ Declaring only the three literals told an author that `issue_type = 'Bug'`
        # was an invalid filter while 73 rows held exactly that, which § 3.6.2 names as
        # strictly worse than declaring no domain at all. `closed=False` is retained
        # precisely BECAUSE the Jira set can grow at any tenant.
        ("issue", "merge_request", "Issue", "Bug", "Task", "Epic", "Improvement"),
        closed=False, nullable=True,
        source="mappings: gitlab/issues.yaml:82 (const 'issue'), "
               "gitlab/merge_requests.yaml:83 (const 'merge_request'), "
               "jira/issues.yaml:70-74 (PASSTHROUGH of Jira issuetype.name, default 'Issue' "
               "— per-project admin-configurable) — NOT normalized",
    ),
    ("issues", "priority"): _domain(
        (), closed=False, nullable=True,
        # ⚠️ Deliberately UNDESCRIBED, not "no writer": one writer exists (jira/issues.yaml)
        # but it declares NO literal — it passes an admin-configurable Jira priority name
        # through. The comment names Highest|High|Medium|Low|Lowest as advisory only.
        # Declaring those would be importing a COMMENT as a vocabulary, which RULE 1 forbids.
        source="mappings: jira/issues.yaml:218-222 (sole writer, Jira priority.name — "
               "PASSTHROUGH, admin-configurable; the comment's Highest|High|Medium|Low|Lowest "
               "is ADVISORY, enforced by nothing) — deliberately NOT normalize_severity, "
               "which is the security vocabulary",
    ),
    ("issues", "resolution"): _domain(
        (), closed=False, nullable=True,
        # ⚠️ EXAMINED: sole writer passes Jira's admin-configurable resolution NAME through,
        # with no default literal. The schema docstring names Fixed|Won't Fix|Duplicate|
        # Cannot Reproduce — documentation, enforced by nothing, so not declared.
        source="mappings: jira/issues.yaml:151-155 (sole writer, Jira resolution.name — "
               "PASSTHROUGH, admin-configurable per project; zero literals declared in code) "
               "— NOT normalized",
    ),
    ("issues", "workflow_state"): _domain(
        (), closed=False, nullable=True,
        # ⭐ Un-declarable BY DESIGN. This column exists precisely to preserve the tracker's
        # raw workflow state un-normalized, so `status` can be mapped. Declaring a domain
        # here would defeat the column's entire reason for existing.
        source="mappings: jira/issues.yaml:241-245 (sole writer, raw Jira status.name — "
               "an INTENTIONAL passthrough; the column is the un-normalized escape hatch "
               "that lets `status` be mapped without losing the tracker's own state. "
               "No Python writer; GitLab mappings leave it NULL)",
    ),

    # ── repositories ─────────────────────────────────────────────────────────────────────
    # ⭐ Same vocabulary and the same NULL rule as vulnerabilities.created_via — NULL means
    # a genuinely ingested row. ⚠️ `!= 'sdg_replay'` drops every real row (SQL != vs NULL).
    ("repositories", "created_via"): _domain(
        _CREATED_VIA, closed=False, nullable=True, source=_CREATED_VIA_SOURCE,
    ),
    # ⭐ ONE vocabulary, ELEVEN tables — see _SOURCE_SYSTEM. OPEN for the same reason
    # everywhere: the SARIF channel passes an uploaded tool name straight through.
    ("repositories", "source_system"): _domain(
        _SOURCE_SYSTEM, closed=False, nullable=True, source=_SOURCE_SYSTEM_SOURCE,
    ),
    # ⭐ MIGRATED from the semantic model's `enum` (Phase 2a). Same split vocabulary as
    # assets.criticality_name — written by asset/repositories.yaml (raw passthrough of
    # `record.criticality_name`) and the governance decorations.
    ("repositories", "criticality_name"): _domain(
        _CRITICALITY_NAME, closed=False, nullable=True, source=_CRITICALITY_SOURCE,
    ),
    ("repositories", "provider"): _domain(
        _PROVIDER, closed=False, nullable=True,
        source=_PROVIDER_SOURCE,
    ),
    ("repositories", "visibility"): _domain(
        ("public", "private", "internal"), closed=False, nullable=True,
        # ⚠️ Three of four writers are closed (two ternaries + a JSON-Schema enum) and all
        # agree on these three lowercase tokens — but gitlab/projects.yaml is a bare
        # `op: rename`, so GitLab's vocabulary lands unconstrained. One rename defeats closure.
        source="mappings: github/repositories.yaml:84-87 (ternary private|public), "
               "jira/projects.yaml:62-66 (ternary), asset/repositories.yaml (enum-constrained "
               "by asset_inventory.v1.json$.identity.visibility) + gitlab/projects.yaml:26 "
               "(`op: rename` — PASSTHROUGH) — no normalize_visibility() exists",
    ),
    ("repositories", "environment"): _domain(
        ("production", "staging", "development", "test"), closed=True, nullable=True,
        # ⭐ Closed by a JSON SCHEMA rather than a normalizer, and that is a REAL mechanism,
        # not a docstring: the sole writer is a passthrough, but its only upstream is the
        # `torana ingest assets` route, which runs
        # `jsonschema.Draft202012Validator(schema).validate(doc)` and RAISES on a bad value
        # (verified in torana_mesh/api/routes/ingest.py). A value outside the enum cannot
        # reach the column. ⚠️ If a second, unvalidated writer is ever added, this reopens.
        source="torana_mesh/etl/ingestors/schemas/asset_inventory.v1.json"
               "$.governance.environment.enum (ENFORCED at the API boundary by "
               "torana_mesh/api/routes/ingest.py) via mappings/asset/repositories.yaml:132-136",
    ),
    ("repositories", "platform_type"): _domain(
        ("cloud",), closed=False, nullable=True,
        # ⚠️ A one-value domain, and the value is only half the story: the schema promises a
        # cloud/self-managed distinction but ONLY github/repositories.yaml writes this column,
        # always `cloud`. Self-hosted GitLab/Bitbucket leave it NULL. That is a GAP in the
        # writers, not a vocabulary — so it is recorded open rather than closed at one value.
        source="mappings: github/repositories.yaml:238 (`op: set`, sole writer — "
               "gitlab/bitbucket/snyk/jira/aikido/sarif/asset repositories mappings do NOT "
               "write it) — NOT normalized",
    ),
    ("repositories", "owner_type"): _domain(
        ("User", "Organization"), closed=False, nullable=True,
        # ⚠️ PascalCase here, unlike identity_type which was deliberately snake_cased — the
        # values are GitHub's raw `owner.type` passed through, plus an `''` empty-string
        # fallback the expression can also emit.
        source="mappings: github/repositories.yaml:60-64 (sole writer, "
               "`record.owner.type` — PASSTHROUGH of GitHub's vocabulary, "
               "empty-string fallback) — NOT normalized",
    ),
    ("repositories", "repo_maintenance_status"): _domain(
        (), closed=False, nullable=True,
        # ⛔ The one column in this pass where a domain genuinely CANNOT be declared from
        # code: the sole writer passes Snyk's `attributes.repository_freshness` through and
        # NO literal for it exists anywhere in the repo.
        source="mappings: snyk/repositories.yaml:90-93 (sole writer, "
               "`record.attributes.repository_freshness` — PASSTHROUGH of an undocumented "
               "Snyk vendor field; zero literals anywhere in the repo) — NOT normalized",
    ),

    # ── identities ───────────────────────────────────────────────────────────────────────
    # ⭐ Same vocabulary and the same NULL rule as vulnerabilities.created_via — NULL means
    # a genuinely ingested row. ⚠️ `!= 'sdg_replay'` drops every real row (SQL != vs NULL).
    ("identities", "created_via"): _domain(
        _CREATED_VIA, closed=False, nullable=True, source=_CREATED_VIA_SOURCE,
    ),
    # ⭐ ONE vocabulary, ELEVEN tables — see _SOURCE_SYSTEM. OPEN for the same reason
    # everywhere: the SARIF channel passes an uploaded tool name straight through.
    ("identities", "source_system"): _domain(
        _SOURCE_SYSTEM, closed=False, nullable=True, source=_SOURCE_SYSTEM_SOURCE,
    ),
    ("identities", "identity_type"): _domain(
        _IDENTITY_TYPE, closed=False, nullable=True,
        source="pantheon-integration/torana_mesh/etl/normalize.py::_IDENTITY_TYPE_ALIASES "
               "(alias TARGETS, via normalize_identity_type — NON-CLAMPING, an unrecognized "
               "value is snake_cased and PRESERVED rather than folded to 'unknown') "
               "+ 14 `op: set` constants across mappings/**, all inside the canonical set",
    ),
    ("identities", "provider"): _domain(
        _PROVIDER, closed=False, nullable=True,
        source=_PROVIDER_SOURCE,
    ),
    ("identities", "status"): _domain(
        ("active", "inactive", "disabled", "unknown"), closed=False, nullable=True,
        # ⛔ Same drift class that `normalize_identity_type` was written to fix, still
        # unfixed for this column: three `op: rename` passthroughs inject raw vendor
        # vocabulary (Okta UPPERCASE `ACTIVE|SUSPENDED|DEPROVISIONED…`, GitLab
        # `blocked|deactivated|ldap_blocked`) alongside these four lowercase literals.
        # normalize_status() serves vulnerabilities with a DIFFERENT Title-Case tuple and is
        # not applicable. Owed: a normalize_identity_status().
        source="mappings: github/{users,teams}.yaml (`op: set` active) + 10 ternary derives "
               "across aikido/tenable/gcp/jira/slack/salesforce/splunk "
               "(active|inactive|disabled|unknown) + PASSTHROUGH renames okta/users.yaml:45, "
               "okta/group_members.yaml:43, gitlab/members.yaml:27 — NOT normalized",
    ),

    # ── artifacts ────────────────────────────────────────────────────────────────────────
    # ⭐ Same vocabulary and the same NULL rule as vulnerabilities.created_via — NULL means
    # a genuinely ingested row. ⚠️ `!= 'sdg_replay'` drops every real row (SQL != vs NULL).
    ("artifacts", "created_via"): _domain(
        _CREATED_VIA, closed=False, nullable=True, source=_CREATED_VIA_SOURCE,
    ),
    # ⭐ ONE vocabulary, ELEVEN tables — see _SOURCE_SYSTEM. OPEN for the same reason
    # everywhere: the SARIF channel passes an uploaded tool name straight through.
    ("artifacts", "source_system"): _domain(
        _SOURCE_SYSTEM, closed=False, nullable=True, source=_SOURCE_SYSTEM_SOURCE,
    ),
    # ⭐ MIGRATED from the semantic model's `enum` (Phase 2a). Same split vocabulary.
    ("artifacts", "criticality_name"): _domain(
        _CRITICALITY_NAME, closed=False, nullable=True, source=_CRITICALITY_SOURCE,
    ),
    ("artifacts", "artifact_type"): _domain(
        ("container_image", "jira_sprint"), closed=False, nullable=True,
        # ⚠️ The declared literals are already internally inconsistent with the passthrough:
        # gcp/aikido write `container_image` while Snyk's source emits `image` for the same
        # concept. Unreconciled synonyms — the argument for a normalize_artifact_type().
        source="mappings: aikido/container_images.yaml:76, "
               "gcp/artifact_registry_images.yaml (literals) + snyk/artifacts.yaml:45 "
               "(`record.type` — PASSTHROUGH) — NOT normalized",
    ),
    ("artifacts", "container_image_registry_provider"): _domain(
        ("GAR", "GCR", ""), closed=False, nullable=True,
        # ⭐ The REGISTRY PRODUCT hosting the image, derived from the URI host — NOT the cloud
        # vendor whose API reported it, and NOT an ownership signal (see the schema
        # description). Google runs two non-interchangeable registries: Artifact Registry
        # (`*-docker.pkg.dev` → `GAR`) and the deprecated Container Registry (`gcr.io`,
        # `*.gcr.io` → `GCR`).
        # ⚠️ `""` IS A DECLARED VALUE, not an oversight. The sole writer is a `derive`, and a
        # derive always writes: a record with no `uri`, or a host matching neither registry,
        # lands the EMPTY STRING — never NULL. Omitting it would send an author to write
        # `WHERE provider IS NULL` for "unattributed" and match nothing. `nullable=True`
        # stays because the other artifact writers never touch the column at all.
        # ⚠️ Recorded OPEN because closure-by-single-writer is not a mechanism (see
        # assets.asset_status): nothing normalizes this, so a second writer, or a third
        # Google registry host, escapes the tuple without changing a line here.
        source="mappings: gcp/artifact_registry_images.yaml "
               "`container_image_registry_provider_derive` (sole writer; derives 'GAR' / "
               "'GCR' / '' from the URI host — cited by step id, not line number, because "
               "the block moves; aikido/container_images.yaml and snyk/artifacts.yaml write "
               "artifact rows but never reference this column, leaving it NULL) "
               "— NOT normalized",
    ),

    # ── controls ─────────────────────────────────────────────────────────────────────────
    # ⭐ Same vocabulary and the same NULL rule as vulnerabilities.created_via — NULL means
    # a genuinely ingested row. ⚠️ `!= 'sdg_replay'` drops every real row (SQL != vs NULL).
    ("controls", "created_via"): _domain(
        _CREATED_VIA, closed=False, nullable=True, source=_CREATED_VIA_SOURCE,
    ),
    # ⭐ ONE vocabulary, ELEVEN tables — see _SOURCE_SYSTEM. OPEN for the same reason
    # everywhere: the SARIF channel passes an uploaded tool name straight through.
    ("controls", "source_system"): _domain(
        _SOURCE_SYSTEM, closed=False, nullable=True, source=_SOURCE_SYSTEM_SOURCE,
    ),
    ("controls", "provider"): _domain(
        _PROVIDER, closed=False, nullable=True,
        source=_PROVIDER_SOURCE,
    ),
    ("controls", "control_class"): _domain(
        ("waf_rule",), closed=False, nullable=True,
        source="mappings: cloudflare/firewall_rules.yaml:77 (`op: set`) + "
               "torana_mesh/api/routes/compensating_controls.py:87 "
               "(CompensatingControlIn.control_class — an UNCONSTRAINED `str` default, not a "
               "Literal, so the REST path can write any value) — NOT normalized",
    ),
    ("controls", "status"): _domain(
        ("shadow", "active", "retired", "expired", "inactive"), closed=False, nullable=True,
        # ⚠️ TWO WRITERS THAT DISAGREE: the Cloudflare ETL emits `inactive` for "not
        # enforcing", while the API lifecycle uses `retired`/`expired` for the same concept
        # and never emits `inactive`. Both are declared here because both are written; the
        # conflict is recorded rather than resolved (resolving it is a migration).
        source="mappings: cloudflare/firewall_rules.yaml:117-121 (ternary active|inactive) + "
               "torana_mesh/api/routes/compensating_controls.py:111 "
               "(CompensatingControlIn.status, documented shadow|active|retired|expired) "
               "and :123 (CompensatingControlUpdate.status — UNCONSTRAINED passthrough) "
               "— NOT normalized",
    ),

    # ─────────────────────────────────────────────────────────────────────────────────────
    # ⭐ THE HIGHEST-CONSEQUENCE ENUM IN THE DATALAKE (Torana_Schema_Semantics.md § 3.6.3).
    #
    # `edge_type` decides what a JOIN MEANS. Every other enum mis-filters rows; this one
    # silently changes the QUESTION — traversing `contains` answers "what packages are in
    # this image", traversing `deployed_as` answers "what is running it". An author who
    # picks the wrong one gets a confident, wrong, green answer.
    #
    # ⛔ THE SIX-VS-SEVEN DISCREPANCY, RESOLVED: it was BOTH WRONG. The sibling spec's
    # tracker said six; live T2 data showed seven. The authority is neither — it is
    # `EDGE_ENDPOINT_MAP` in `pantheon_shared/identity/entity_graph_edges.py`, which
    # declares TWELVE. The seven are simply the subset T2 has data for. Measured 2026-08-19:
    #
    #     contains 141,658 · owns 82 · part_of 52 · runs_on 47 · deployed_as 38 ·
    #     builds_image 14 · exposed_via 2
    #
    # The five with no rows on T2 — accesses, builds, declares, depends_on, packaged_in —
    # are DECLARED-BUT-UNOBSERVED, which § 3.6.2 classifies as NOT a defect: another tenant
    # may populate them, and omitting them would tell an author a legal filter is illegal.
    # ⛔ Declaring only the observed seven is exactly the failure § 3.6.3 warns against.
    #
    # ⚠️ `closed=False` DESPITE the values coming from code, per the § 3.6.1 rule that
    # closure must never be inferred from observation. EDGE_ENDPOINT_MAP is the derivation
    # map for edges the platform BUILDS; it does not forbid an ingested edge carrying
    # another type. Closing this would turn a new edge type into an invalid filter.
    # ⭐ Confirmed § 3.6.1 candidate (3 distinct / 141,893 rows on T2), and the ONE case in
    # the whole scan where `closed=True` is defensible: closure comes from CODE, not from
    # observation. `CONFIDENCE_LEVELS` in entity_graph_edges.py is a frozenset the edge
    # writers validate against, so `low` is declared here despite having zero rows on T2 —
    # § 3.6.2 rules declared-but-unobserved is NOT a defect, and omitting it would tell an
    # author that a legal filter is illegal.
    ("entity_edges", "confidence"): _domain(
        ("low", "medium", "high", "authoritative"), closed=True, nullable=True,
        source="pantheon_shared/identity/entity_graph_edges.py:64::CONFIDENCE_LEVELS "
               "(frozenset, code-declared and validated) ∪ observed on T2 2026-08-19 "
               "(authoritative/high/medium present, low unused — not a defect)",
    ),

    ("entity_edges", "edge_type"): _domain(
        (
            "accesses",      # service: -> datastore:  — the service reads/writes that store
            "builds",        # repo:    -> gav:        — this code produces that build artifact
            "builds_image",  # repo:    -> image:      — this code produces that container image
            "contains",      # image:   -> pkg:        — the image ships that package (SCA join)
            "declares",      # repo:    -> cloud:      — code declares that cloud resource
            "depends_on",    # repo:    -> pkg:        — the codebase depends on that package
            "deployed_as",   # image:   -> service:    — that image is RUNNING as this service
            "exposed_via",   # service: -> cloud:      — reachable through that ingress/LB
            "owns",          # *        -> team:       — ownership; the routing edge
            "packaged_in",   # gav:     -> image:      — that build artifact is inside the image
            "part_of",       # cloud:   -> service:    — the resource composes that service
            "runs_on",       # service: -> host:       — the service executes on that host
        ),
        closed=False, nullable=False,
        source="pantheon_shared/identity/entity_graph_edges.py::EDGE_ENDPOINT_MAP "
               "(12 declared) ∪ observed on T2 2026-08-19 (7 present, all a subset — "
               "conformance clean: no observed value is undeclared)",
    ),
    # ── datastores ───────────────────────────────────────────────────────────────────────────
    # ⭐ Same vocabulary and the same NULL rule as vulnerabilities.created_via — NULL means
    # a genuinely ingested row. ⚠️ `!= 'sdg_replay'` drops every real row (SQL != vs NULL).
    ("datastores", "created_via"): _domain(
        _CREATED_VIA, closed=False, nullable=True, source=_CREATED_VIA_SOURCE,
    ),
    # ⭐ ONE vocabulary, ELEVEN tables — see _SOURCE_SYSTEM. OPEN for the same reason
    # everywhere: the SARIF channel passes an uploaded tool name straight through.
    ("datastores", "source_system"): _domain(
        _SOURCE_SYSTEM, closed=False, nullable=True, source=_SOURCE_SYSTEM_SOURCE,
    ),

    # ── packages ─────────────────────────────────────────────────────────────────────────────
    # ⭐ Same vocabulary and the same NULL rule as vulnerabilities.created_via — NULL means
    # a genuinely ingested row. ⚠️ `!= 'sdg_replay'` drops every real row (SQL != vs NULL).
    ("packages", "created_via"): _domain(
        _CREATED_VIA, closed=False, nullable=True, source=_CREATED_VIA_SOURCE,
    ),
    # ⭐ ONE vocabulary, ELEVEN tables — see _SOURCE_SYSTEM. OPEN for the same reason
    # everywhere: the SARIF channel passes an uploaded tool name straight through.
    ("packages", "source_system"): _domain(
        _SOURCE_SYSTEM, closed=False, nullable=True, source=_SOURCE_SYSTEM_SOURCE,
    ),

    # ── entity_edges ─────────────────────────────────────────────────────────────────────────
    # ⭐ Same vocabulary and the same NULL rule as vulnerabilities.created_via — NULL means
    # a genuinely ingested row. ⚠️ `!= 'sdg_replay'` drops every real row (SQL != vs NULL).
    ("entity_edges", "created_via"): _domain(
        _CREATED_VIA, closed=False, nullable=True, source=_CREATED_VIA_SOURCE,
    ),
    # ⭐ ONE vocabulary, ELEVEN tables — see _SOURCE_SYSTEM. OPEN for the same reason
    # everywhere: the SARIF channel passes an uploaded tool name straight through.
    ("entity_edges", "source_system"): _domain(
        _SOURCE_SYSTEM, closed=False, nullable=True, source=_SOURCE_SYSTEM_SOURCE,
    ),

}


def is_described(domain: Optional[Dict[str, Any]]) -> bool:
    """True when someone has actually described this column's vocabulary.

    ⛔ The check that keeps "not yet described" from being read as "free text". Use this
    rather than testing `values` for emptiness — an empty CLOSED domain is a legitimate
    (if odd) statement, while an empty OPEN one is an admission.
    """
    return bool(domain and domain.get("source"))


def domain_for(table: str, column: str) -> Dict[str, Any]:
    """The declared value domain for one column, or the honest UNDESCRIBED placeholder.

    ⚠️ Returns a DEEP copy. `dict(...)` is shallow, so the `values` list would be SHARED —
    one caller appending to a returned placeholder would poison every subsequent column and
    the module constant with it. Caught by `test_placeholder_is_never_mutated_by_a_caller`
    on its first run, which is why that test exists.
    """
    found = DOMAINS.get((table.lower(), column.lower()))
    src = found if found is not None else UNDESCRIBED
    return {**src, "values": list(src["values"])}


def coverage() -> Dict[str, int]:
    """How much of the schema has a described domain — the backlog, countable.

    ⭐ Existing so the gap is a NUMBER rather than a feeling. 196 of 217 columns were
    undescribed when this shipped; a reader who cannot see that assumes the model is complete.

    ⚠️ `described` counts DOMAINS entries, which is not the same as "columns with values".
    Nine entries are described with an EMPTY `values` tuple — examined, every writer traced,
    and found to declare no literal at all (pure vendor passthroughs). That is a real finding,
    not a gap, and `source` is what distinguishes it from a column nobody has looked at.
    """
    described = sum(1 for d in DOMAINS.values() if d.get("source"))
    return {
        "described": described,
        "with_values": sum(1 for d in DOMAINS.values() if d.get("source") and d.get("values")),
        "closed": sum(1 for d in DOMAINS.values() if d.get("closed")),
    }


def enrich_columns(table: str, columns: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Attach `value_domain` to each column dict of a schema payload. Additive, in place."""
    for col in columns:
        name = col.get("column") or col.get("name")
        if name:
            col["value_domain"] = domain_for(table, str(name))
    return columns


__all__ = [
    "DOMAINS", "UNDESCRIBED", "coverage", "domain_for", "enrich_columns", "is_described",
]
