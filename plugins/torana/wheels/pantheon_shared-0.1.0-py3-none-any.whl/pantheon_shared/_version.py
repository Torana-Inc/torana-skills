"""
Auto-generated build provenance.

Written by build_version.py at build time and NOT tracked in git.
Do not edit manually -- your changes will be overwritten by the next build.
"""

VERSION = "0.1.0"
COMMIT_SHA = "c6bd30945c9fc7a5d97bc2c03f0763404e36541c"
COMMIT_TIME = "2026-09-09T21:56:02+05:30"
BRANCH = "main"
DIRTY = False
