# `pantheon_shared.domain_properties` — the DATA-plane property registry

What an **entity IS** (`asset_team`, `public_access`, `criticality_name`) — governed per tenant,
resolved over the entity graph.

## ⛔ TWO PLANES — confusing them is the main hazard here

| Plane | Governs | Registry | Placeholder |
|---|---|---|---|
| **DATA** *(this package)* | what an **entity** is | `registry.py` + `vm.py` | none — resolved on the graph |
| **POLICY** *("vocabulary")* | what a **word** means for this tenant (`severity_floor = High`) | `pantheon-agent-builder/src/services/vm_policy/vocabulary_registry.py` | `{{vocab:vm.<cat>.<sub>.<key>}}` |

⭐ **"Is this image ours?" is a DATA-plane property.** It is an attribute of a thing.
⭐ **"What counts as Critical here?" is a POLICY-plane word.** It is a definition.

⚠️ A change here is **not** a vocabulary change and needs none of the vocabulary regeneration
(`generate_vocabulary_catalog.py`, the 4 generated destinations, the prompt bootstrap-reload).
The reverse is also true. Establish which plane you are on **before** editing anything.

## ⭐ ADDING A PROPERTY — it is not done until all FIVE surfaces declare it

An entry here alone is invisible to the things that write SQL. Claude Code build skills and Torana
agents author from the **declared** surfaces, so a property declared here and nowhere else is
governed, resolvable, and never queried — and nothing fails to tell you.

| # | Surface | File |
|---|---|---|
| 1 | Sink schema — the physical column + its meaning | [`../datalake/schemas/`](../datalake/schemas/) |
| 2 | Value domain — which values are legal | [`../datalake/value_domain.py`](../datalake/value_domain.py) |
| 3 | ⭐ Semantic model — **`synonyms`, how a question finds the column** | [`../datalake/schemas/torana_security_mesh_semantic_model_updated.yaml`](../datalake/schemas/torana_security_mesh_semantic_model_updated.yaml) |
| 4 | This registry — the governance + resolution contract | [`vm.py`](vm.py) |
| 5 | ⛔ **The resolution TARGET** — where the resolver writes and consumers join | [`../datalake/schemas/entity_properties_resolved.py`](../datalake/schemas/entity_properties_resolved.py) |

⛔ **Surface 5 fails SILENTLY when omitted** — the upsert strips keys with no physical column, so the
write logs success and every consumer reads the default forever. Measured 2026-09-07 with
`image_ownership`. ⭐ **A governed property appears TWICE**: on its sink table AND here.

Full rules and the drift warnings: [`../datalake/schemas/CLAUDE.md`](../datalake/schemas/CLAUDE.md).

## ⛔ `provenance_class` decides where a value may come from — get this right first

```python
OBSERVED   = "observed"     # a source emits it; an ETL mapping derives it
DECLARED   = "declared"     # a HUMAN governs it (deployment form / governance push)
COMPUTED   = "computed"     # policy x data; materialized at transform time
PROPAGATED = "propagated"   # inherited over entity-graph edges
```

⛔ **If a human must decide it, it is `DECLARED` — never infer it at ingest.**
⭐ **The worked example, and the reason this warning exists:** `#374`. Container-registry provenance
was inferred from the registry host. But a first-party build and a mirrored third-party image sit in
the SAME registry under the SAME host — and a customer's own Chainguard base images are third-party
content at a first-party host. The inference was a **policy guess frozen into ingest, where it is
invisible and unfalsifiable**. It is the same class of error as a hardcoded constant.

⚠️ **A fully-populated column that carries one value is WORSE than an empty one.** It passes every
fill-rate check and discriminates nothing. Measured examples: `#374` (`'gcp'` on 100% of rows),
`#376` (`vulnerability_category` 99.7% `VULNERABILITY`), `artifacts.vm_scan_analyzers` (136 rows,
`COUNT(DISTINCT) = 1`). ⭐ **Always report `COUNT(*)`, `COUNT(col)` AND `COUNT(DISTINCT col)`** — a
population figure alone cannot tell "written but wrong" from "written but useless".

## Verify against the CODE, not the tracker

```bash
python3 -c "
import sys; sys.path.insert(0,'src')
from pantheon_shared.domain_properties.registry import get_registry
for p in get_registry(): print(p.key, p.entity, p.provenance_class.value, p.column)"
```

⚠️ Spec G's § 4 checkboxes read **42 unticked / 0 ticked** while this registry is in fact **built and
live with 9 properties**. The tracker is stale; the import is authoritative.

## Related

- [`09_SpecG_Domain_Property_Registry.md`](../../../../pantheon-program-framework/docs/VM/09_SpecG_Domain_Property_Registry.md) — the spec for this package
- [`11_SpecF_Image_Ownership_And_MET003.md`](../../../../pantheon-program-framework/docs/VM/11_SpecF_Image_Ownership_And_MET003.md) — § 3.3.1, the four-surface walkthrough
- [`../datalake/CLAUDE.md`](../datalake/CLAUDE.md) — which layer writes which column (`reachability.py`)
