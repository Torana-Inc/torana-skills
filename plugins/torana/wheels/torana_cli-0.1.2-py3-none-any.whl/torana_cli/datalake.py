"""torana datalake — datalake query and table management commands."""

import json
import re

import shutil
import textwrap

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.confirm import confirm as _confirm

_TABLE_COLS = [
    ("name", "TABLE", 40),
    ("type_label", "TYPE", 12),
    # STATE sits next to TYPE because the two answer different questions that are
    # easy to conflate: TYPE is what KIND of table it is (Base vs Transformer),
    # STATE is whether it actually EXISTS for this tenant.
    ("state", "STATE", 13),
    # COLS is the DECLARED column count (len of the registry schema), not a count
    # read back from the database — so for a `declared` row it describes the shape
    # the table WOULD have. That is only honest because STATE sits beside it.
    ("column_count", "COLS", 6),
    ("description", "DESCRIPTION", 35),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


# ── The ONE scope contract, shared by every column surface ──────────────────
#
# ⛔ REQUIRED, NEVER DEFAULTED. Four commands previously each had their own
# contract and their own default, and the same word meant different things:
#   reachable-columns   --scope defaulted to TENANT
#   schema table        --scope defaulted to TENANT, plus a separate --tenant-id
#   all-columns         --scope accepted but INERT without --reachable (measured:
#                       489 columns either way — the flag looked like it worked)
#   supply columns      --tenant-id only, no --scope at all
# A reader who omitted it got a tenant answer on one command and a platform
# answer on another, with nothing on screen saying which.
#
# ⭐ WHY AN ENUM AND A SEPARATE --tenant-id, rather than `--scope tenant:<UUID>`:
# discovery. Click renders a Choice as `--scope [platform|tenant]`, so the valid
# set is IN THE SIGNATURE — visible to an LLM session that discovers by running
# `--help`, and enforced with a naming error on a wrong value. A UUID is not a
# closed set, so `tenant:<UUID>` degrades the option to `--scope TEXT` and the
# enum disappears into prose. Measured contrast on a bad value:
#   --scope tenant:abc  -> "Error: ... is not one of 'tenant', 'platform'."
#   --tenant-id abc     -> an HTTP 502 naming pantheon-auth — the wrong subsystem
SCOPE_CHOICE = click.Choice(["platform", "tenant"])

_SCOPE_HELP = (
    "REQUIRED. 'platform': every pipeline Torana ships, identical for every "
    "tenant. 'tenant': only what THIS tenant's connected integrations can "
    "write — resolved from TORANA_PROFILE, so no id is needed. The two differ "
    "by hundreds of columns (measured: 441 vs 314), so there is deliberately "
    "no default."
)

_TENANT_ID_HELP = (
    "⚠️ SUPER-ADMIN ONLY, and rarely needed. `--scope tenant` already resolves "
    "the tenant from TORANA_PROFILE — prefer `TORANA_PROFILE=T1 ... --scope "
    "tenant`. Use this ONLY as SA reading a tenant you are not. A tenant "
    "profile passing it gets a 403 naming its own tenant."
)


def scope_options(fn):
    """Attach the shared `--scope` / `--tenant-id` pair to a command."""
    fn = click.option("--tenant-id", "tenant_id", default=None, metavar="UUID",
                      help=_TENANT_ID_HELP)(fn)
    fn = click.option("--scope", "scope", type=SCOPE_CHOICE, default=None,
                      help=_SCOPE_HELP)(fn)
    return fn


def resolve_scope(scope, tenant_id):
    """Validate the pair and return `(scope, tenant_id)`.

    ⛔ Exits with a USAGE error naming all three forms rather than picking one.
    Guessing here is the whole failure this contract removes.
    """
    if scope is None:
        raise click.UsageError(
            "--scope is required. One of:\n"
            "  --scope platform   every pipeline Torana ships, same for every tenant\n"
            "  --scope tenant     ⭐ the tenant of TORANA_PROFILE — the usual form\n"
            "                     e.g. TORANA_PROFILE=T1 torana datalake ... --scope tenant\n"
            "  --scope tenant --tenant-id <UUID>\n"
            "                     SUPER-ADMIN reading a tenant it is not. Rarely\n"
            "                     needed: set TORANA_PROFILE instead where you can."
        )
    if tenant_id and scope != "tenant":
        # ⚠️ An ERROR, not a silent ignore. Accepting `--scope platform
        # --tenant-id X` and returning the platform answer looks like a
        # per-tenant result and is the most convincing possible way to be wrong.
        raise click.UsageError(
            f"--tenant-id is meaningless with --scope {scope}. "
            "Use `--scope tenant` (the tenant comes from TORANA_PROFILE), or "
            "`--scope tenant --tenant-id <UUID>` as super-admin."
        )
    return scope, tenant_id


@click.group()
def datalake():
    """Query and manage the datalake.

    \b
    Examples:
      torana datalake query --sql "SELECT * FROM assets LIMIT 10"
      torana datalake generate --prompt "Show critical vulnerabilities in production"
      torana datalake tables list
      torana datalake tables get assets
    """


@datalake.command(name="query")
@click.option("--sql", required=True, help="SQL query to execute.")
@click.option("--limit", default=None, type=int, help="Max rows to return.")
@click.pass_context
def datalake_query(ctx, sql, limit):
    """Execute a SQL query against the datalake.

    \b
    Example:
      torana datalake query --sql "SELECT * FROM assets WHERE severity = 'critical' LIMIT 50"
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    if not sql.strip().upper().startswith(("SELECT", "WITH")):
        click.echo("ERROR: SQL must be a SELECT query or CTE (starting with SELECT or WITH).",
                   err=True)
        import sys
        sys.exit(6)

    # The /query endpoint (ExecuteQueryRequest) accepts ONLY the `query` field.
    # It has no server-side limit; if the caller wants a row cap they must put
    # LIMIT in the SQL (or use `datalake query-execute`, which supports --limit).
    if limit is not None:
        click.echo(
            "NOTE: `datalake query` has no server-side limit; add LIMIT to your SQL "
            "or use `datalake query-execute --limit`. Ignoring --limit.",
            err=True,
        )

    body = {"query": sql}

    client = _client(ctx)
    try:
        data = client.post("/query", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@datalake.command(name="generate")
@click.option("--prompt", required=True, help="Natural language query to convert to SQL.")
@click.option("--execute", is_flag=True, default=False, help="Execute the generated SQL.")
@click.pass_context
def datalake_generate(ctx, prompt, execute):
    """Generate SQL from a natural language prompt (text-to-SQL).

    \b
    Examples:
      torana datalake generate --prompt "Show critical vulnerabilities in production"
      torana datalake generate --prompt "Count assets by type" --execute
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {"prompt": prompt, "execute": execute}

    client = _client(ctx)
    try:
        data = client.post("/query/generate", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        if isinstance(data, dict):
            sql = data.get("sql") or data.get("query")
            if sql:
                click.echo("Generated SQL:")
                click.echo(sql)
            if execute and data.get("results"):
                click.echo("\nResults:")
                output({"items": data["results"]}, fmt="text", columns=[])
            elif not sql:
                import json
                click.echo(json.dumps(data, indent=2, default=str))
        else:
            click.echo(str(data))


def _attach_transformer_singular():
    """Attach `torana datalake transformer <ID>` (imported late — circular dep)."""
    from torana_cli.transformer import transformer as _transformer_group
    datalake.add_command(_transformer_group)


@datalake.group(name="transformers")
def datalake_transformers():
    """Manage transformer OUTPUT TABLES in the datalake.

    These are the materialized tables transformers write into — the same
    datalake namespace as the sink tables, so they live here alongside
    `tables`, `clear-all`, and `drop-all`.

    \b
    Transformer DEFINITIONS (the SQL recipes) live under this same group:
      torana datalake transformers list          — the definitions
      torana datalake transformer <UUID> ...     — one definition (get/update/delete)

    \b
    Examples:
      torana datalake transformers list
      torana datalake transformers execute-all
    """


def _fetch_all_transformers(client, workspace_id=None):
    """Fetch every transformer definition (paginated to exhaustion).

    Returns a list of dicts. The endpoint returns `{transformers, total, ...}`
    and uses offset/limit (not skip/limit); trailing slash 404s via nginx.
    """
    all_items, offset, limit = [], 0, 100
    while True:
        params = {"offset": offset, "limit": limit}
        if workspace_id:
            params["workspace_id"] = workspace_id
        data = client.get("transformers", params=params)
        if isinstance(data, dict):
            items = data.get("transformers", data.get("items", []))
            total = data.get("total", len(items))
        else:
            items = data if isinstance(data, list) else []
            total = len(items)
        all_items.extend(items)
        if not items or len(all_items) >= total:
            break
        offset += limit
    return all_items


def _dedupe_by_destination(items):
    """Collapse transformers that share a destination_table.

    Destination tables are bare names in the tenant schema — they are NOT
    namespaced per workspace. When several definitions target the same table
    they overwrite each other, so the last one executed silently wins. For a
    rebuild we run each destination exactly once and report the collisions
    rather than letting execution order decide the outcome.

    Returns (unique_items, collisions) where collisions maps
    destination_table -> [names of the definitions that were skipped].
    """
    seen, unique, collisions = {}, [], {}
    for t in items:
        dest = t.get("destination_table")
        if not dest:
            continue
        if dest in seen:
            collisions.setdefault(dest, []).append(t.get("name") or t.get("id"))
        else:
            seen[dest] = t
            unique.append(t)
    return unique, collisions


@datalake_transformers.command(name="execute-all")
@click.option("--workspace-id", default=None, help="Only run transformers in this workspace.")
@click.option("--timeout", default=300, show_default=True, type=int,
              help="Max seconds to wait for each transformer.")
@click.option("--passes", default=2, show_default=True, type=int,
              help="Retry passes. Transformers that read other transformers' output "
                   "fail until their input exists, so a later pass picks them up.")
@click.option("--include-duplicates", is_flag=True, default=False,
              help="Run every definition, including several targeting the same table "
                   "(last one wins). Default runs each destination table once.")
@click.option("--full-refresh", is_flag=True, default=False,
              help="Truncate each output table before running its transformer, so the "
                   "result is a true rebuild rather than an upsert onto existing rows.")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def datalake_transformers_execute_all(ctx, workspace_id, timeout, passes, include_duplicates,
                                      full_refresh, yes):
    """Run each transformer's SQL (upsert semantics).

    \b
    ⚠️  This does NOT reset the output tables. Transformers are incremental and
    upsert-based, so rows already in an output table SURVIVE a plain run — a
    report of "Materialized 25/25" does not mean the outputs match a fresh
    materialization. Use --full-refresh to truncate each output first, which
    is what makes a rebuild actually rebuild.

    \b
    Transformers read FROM the datalake sink tables, so those must hold data
    first; otherwise every run fails with 'relation does not exist'.

    \b
    Examples:
      torana datalake transformers execute-all
      torana datalake transformers execute-all --full-refresh --yes
      torana datalake transformers execute-all --workspace-id <UUID> --passes 3
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        items = _fetch_all_transformers(client, workspace_id=workspace_id)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if not items:
        click.echo("No transformers found.")
        return

    collisions = {}
    if include_duplicates:
        targets = [t for t in items if t.get("destination_table")]
    else:
        targets, collisions = _dedupe_by_destination(items)

    if not targets:
        click.echo("No transformers with a destination_table to execute.")
        return

    if not yes:
        click.echo(f"This will execute {len(targets)} transformer(s), "
                   f"up to {passes} pass(es), {timeout}s timeout each.")
        if full_refresh:
            click.echo(f"--full-refresh: ALL ROWS in {len(targets)} output table(s) "
                       f"will be DELETED before their transformer runs.")
        if collisions:
            skipped = sum(len(v) for v in collisions.values())
            click.echo(
                f"\n{len(collisions)} destination table(s) are claimed by more than one "
                f"definition; {skipped} duplicate definition(s) will be SKIPPED so "
                f"execution order does not decide the result:"
            )
            for dest, names in sorted(collisions.items()):
                click.echo(f"  {dest}: skipping {', '.join(names)}")
            click.echo("  (use --include-duplicates to run them all instead)")
        _confirm("Proceed?", yes=False)
    # --full-refresh: truncate every output table up front, before ANY transformer
    # runs. Doing it per-transformer inside the pass loop would wipe a table that an
    # earlier transformer in the same pass had already populated.
    truncated, truncate_failed = [], []
    if full_refresh:
        for t in targets:
            dest = t.get("destination_table")
            if not dest:
                continue
            try:
                client.post(f"transformer-tables/{dest}/clear/")
                truncated.append(dest)
            except (APIError, AuthError) as e:
                truncate_failed.append({"destination_table": dest, "error": str(e)})
                if fmt == "text":
                    click.echo(f"  \u2717 could not clear {dest}: {e}", err=True)
        if fmt == "text":
            click.echo(f"--full-refresh: cleared {len(truncated)}/{len(targets)} "
                       f"output table(s).")

    # Track outcome per destination table; a later pass can flip failed -> success.
    results = {}
    pending = list(targets)

    for pass_num in range(1, passes + 1):
        if not pending:
            break
        if fmt == "text" and pass_num > 1:
            click.echo(f"\n--- pass {pass_num} ({len(pending)} remaining) ---")

        still_failing = []
        for t in pending:
            tid, dest = t.get("id"), t.get("destination_table")
            try:
                data = client.post(f"transformers/{tid}/execute-and-wait",
                                   json={}, params={"timeout": timeout})
                status = (data or {}).get("status") if isinstance(data, dict) else None
                error = (data or {}).get("error_message") if isinstance(data, dict) else None
            except (APIError, AuthError) as e:
                status, error = "failed", str(e)

            ok = status == "success"
            results[dest] = {
                "destination_table": dest, "transformer_id": tid,
                "name": t.get("name"), "status": status or "unknown",
                "error": None if ok else _first_error_line(error),
            }
            if not ok:
                still_failing.append(t)
            if fmt == "text":
                click.echo(f"  {'OK  ' if ok else 'FAIL'}  {dest}")
        pending = still_failing

    succeeded = [r for r in results.values() if r["status"] == "success"]
    failed = [r for r in results.values() if r["status"] != "success"]

    if fmt != "text":
        output({
            "items": list(results.values()),
            "total": len(results),
            "succeeded": len(succeeded),
            "failed": len(failed),
            "skipped_duplicates": collisions,
        }, fmt=fmt, fields=fields)
        if failed:
            ctx.exit(1)
        return

    click.echo(f"\nMaterialized {len(succeeded)}/{len(results)} table(s).")
    if failed:
        click.echo(f"\n{len(failed)} failed:")
        for r in sorted(failed, key=lambda x: x["destination_table"]):
            click.echo(f"  {r['destination_table']}: {r['error'] or r['status']}")
        click.echo("\nIf these read from sink tables, confirm the sink data is "
                   "ingested first — transformers cannot build from empty sources.")
        # Non-zero so CI/scripts can detect a partial rebuild.
        ctx.exit(1)


def strip_ansi(text):
    """Remove ANSI colour escapes so dbt output is readable in a plain terminal / pipe.

    dbt colours its log unconditionally; piping it to a file or grep otherwise
    leaves `\x1b[0m` noise around every line.
    """
    return re.sub(r"\x1b\[[0-9;]*m", "", str(text or ""))


def _first_error_line(error):
    """Pull the most useful single line out of a multi-line dbt error blob.

    dbt reports a failure as a "Database Error in model <name> (<path>)" header
    followed by the ACTUAL cause on a later line (e.g. 'relation "x" does not
    exist'). The header names the file, not the problem, so prefer the cause and
    fall back to the header only when nothing better is present.
    """
    if not error:
        return None
    # Strip ANSI colour codes dbt emits, then drop timestamp prefixes ("08:04:09  ").
    text = strip_ansi(error)
    lines = []
    for raw in text.splitlines():
        ln = re.sub(r"^\d{2}:\d{2}:\d{2}\s+", "", raw.strip())
        if ln:
            lines.append(ln)

    # Highest-value: the concrete database cause.
    for ln in lines:
        low = ln.lower()
        if ("does not exist" in low or "syntax error" in low
                or "permission denied" in low or "column" in low and "not" in low):
            return ln
    # Next: the dbt header (names the model, at least).
    for ln in lines:
        if "database error" in ln.lower():
            return ln
    return lines[0] if lines else None


#: Canonical materialization vocabulary — ONE set of tokens shared by
#: `transformers list`, `transformer <ID> status`, and `tables list`.
#:
#: Every token is a distinct, self-describing word so a single row remains
#: unambiguous when grepped out of context. Deliberately NOT yes/no/true/false:
#: `grep NO` matches nothing meaningful and `grep yes` collides with any word
#: containing it, so a boolean cannot be filtered out of the output at all —
#: which is the whole reason an operator reads these listings.
#:
#: Tokens are hyphenated (never spaces) so `awk`/`cut` on whitespace keeps each
#: state in one field, and no token is a substring of another, so
#: `grep not-materialized` can never match a materialized row.
STATE_MATERIALIZED = "materialized"      # definition exists AND its table is built
STATE_FAILED = "failed"                  # has run, last run errored, table absent
STATE_NEVER_RUN = "never-run"            # defined, never executed
STATE_STALE = "stale"                    # table exists but the last run errored
#: Declared-but-absent, for tables that have no execution concept (base tables).
STATE_DECLARED = "declared"              # schema declares it; not physically present

#: Widest token above, so a column sizes to its content without truncation.
_STATE_WIDTH = max(len(s) for s in (
    STATE_MATERIALIZED, STATE_FAILED, STATE_NEVER_RUN, STATE_STALE, STATE_DECLARED))


def resolve_materialization_state(*, is_built, last_status, has_runs):
    """Map (table exists?, last run outcome) onto one canonical token.

    A single MATERIALIZED yes/no flattens two very different situations into the
    same answer: a transformer that was never executed and one that ran and
    FAILED both report "not materialized". The first is merely pending; the
    second is broken and needs a human. Distinguishing them on the list row is
    what makes a 57-row listing actionable without drilling into each one.

    `stale` is the fourth case, and the easiest to miss: the output table IS
    present (from an earlier good run) but the most recent run errored, so the
    data is real yet silently out of date. Reporting that as plain
    `materialized` would assert freshness the run history contradicts.
    """
    failed_last = str(last_status or "").lower() in ("failed", "error")
    if is_built:
        return STATE_STALE if failed_last else STATE_MATERIALIZED
    if not has_runs:
        return STATE_NEVER_RUN
    return STATE_FAILED if failed_last else STATE_NEVER_RUN


def _enrich_transformer_usage(ctx, items):
    """Add USED BY (apps) and REFS (shared refcount) to each transformer row.

    ⛔ TWO SOURCES, DELIBERATELY NOT RECONCILED.

    `refcount` comes from data-transformers (`vm_transformer_materialization`) and counts
    references to a SHARED vm-catalog relation. `used_by` comes from program-framework
    (`build_v2_artifacts`) and NAMES the apps that deployed it. Neither is computed from the
    other, and they can legitimately disagree:

      · A refcounted relation's `workspace_id` is the sentinel `"vm-catalog"`, so
        data-transformers physically cannot name its consumers — only count them.
      · The refcount has MEASURED drift (it has climbed across repeated deploys without a
        matching release). Verified 2026-09-15: all 18 materialization rows in this stack
        point at transformers that no longer exist, still reading `refcount` 1-2 / `ready`.

    So when REFS=3 and USED BY names one app, that gap IS the finding — a leaked reference,
    not a rendering bug. Deriving one column from the other would erase the only evidence
    that the refcount is wrong.

    Best-effort: a failure here leaves the columns as "—" and never breaks the listing.
    """
    ids = [str(i.get("id")) for i in items if i.get("id")]
    consumers = {}
    if ids:
        try:
            client = _client(ctx)
            # Chunked: the id list goes in the query string, and a few hundred UUIDs would
            # overrun practical URL limits.
            for start in range(0, len(ids), 50):
                chunk = ids[start:start + 50]
                qs = "&".join(f"deployed_artifact_id={i}" for i in chunk)
                data = client.get(
                    "workspaces/build-v2/internal/artifact-consumers"
                    f"?{qs}&artifact_type=transformer")
                consumers.update((data or {}).get("consumers") or {})
        except Exception:  # noqa: BLE001 — supplementary column, never fatal
            consumers = {}

    for item in items:
        tid = str(item.get("id"))
        info = consumers.get(tid) or {}
        names = info.get("workspaces") or []
        item["used_by_display"] = ", ".join(names) if names else "—"
        item["used_by_count"] = info.get("count", 0)
        rc = item.get("refcount")
        # None => not a shared/refcounted relation at all. Rendered "—", never 0: a 0 would
        # assert "no program references this", which for a private transformer is false and
        # is exactly the claim someone would act on before deleting it.
        item["refcount_display"] = "—" if rc is None else str(rc)


_TRANSFORMER_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 26),
    ("destination_table", "DEST TABLE", 24),
    ("state", "STATE", _STATE_WIDTH),
    # WHICH APPS USE THIS. The question the data-management page exists to answer before
    # anyone deletes or edits a transformer.
    ("used_by_display", "USED BY (APPS)", 30),
    # SHARED-catalog reference count. "—" (not 0) when the transformer is not refcounted —
    # see _enrich_transformer_usage for why the distinction is load-bearing.
    ("refcount_display", "REFS", 6),
    ("source_tables_display", "SOURCE TABLES", 26),
]


def list_transformers_core(ctx, *, workspace_id=None, search=None,
                           page=1, page_size=None, fetch_all=False):
    """Shared transformers-list routine.

    `torana datalake transformers list` and `torana workspace <id> transformers
    list` both call this — identical endpoint/columns; the workspace form just
    pre-binds `workspace_id`. Single source of truth; do not fork a parallel
    list path.

    Every row carries STATE — materialized / stale / failed / never-run —
    resolved by intersecting each definition's destination_table with the tables
    that physically exist AND its most recent execution's outcome. A definition
    is only useful once its table is built, so "does it exist yet, and if not
    why" belongs on the same row as the definition rather than in a separate
    command. See resolve_materialization_state() for what each token means.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    # NOTE: GET /api/v1/transformers (no trailing slash — a trailing slash 404s
    # via nginx) uses offset/limit, not skip/limit.
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"offset": (page - 1) * effective_page_size, "limit": effective_page_size}
    if workspace_id:
        params["workspace_id"] = workspace_id
    # NOTE: no `state` param — the transformers API has no state field. State is
    # derived client-side from table existence + run history, so filtering by it
    # goes through _list_transformers_filtered(), not a server query param.
    if search:
        params["search"] = search

    client = _client(ctx)
    try:
        if fetch_all:
            items = _fetch_all_transformers(client, workspace_id=workspace_id)
            total = len(items)
            page, effective_page_size = 1, len(items)
        else:
            data = client.get("transformers", params=params)
            if isinstance(data, dict):
                items = data.get("transformers", data.get("items", []))
                total = data.get("total", len(items))
            else:
                items = data if isinstance(data, list) else []
                total = len(items)
        materialized = set(_fetch_transformer_table_names(client))
        last_runs = _fetch_last_run_by_transformer(client)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    for item in items:
        if not isinstance(item, dict):
            continue
        srcs = item.get("source_tables") or []
        item["source_tables_display"] = ", ".join(srcs) if srcs else "—"
        dest = item.get("destination_table")
        run = last_runs.get(item.get("id")) or {}
        item["state"] = resolve_materialization_state(
            is_built=bool(dest and dest in materialized),
            last_status=run.get("status"),
            has_runs=bool(run),
        )
        # Keep the raw signals on the row so --format json consumers can
        # re-derive or explain the state without a second round-trip.
        item["last_run_status"] = run.get("status")
        item["last_run_at"] = run.get("started_at")
        item["last_error"] = _first_error_line(run.get("error_message"))

    _enrich_transformer_usage(ctx, items)

    result = {"items": items, "total": total, "page": page,
              "page_size": effective_page_size}
    output(result, fmt=fmt, raw=raw, fields=fields, columns=_TRANSFORMER_COLS)

    if fmt == "text" and items:
        # Tally every state present, so a listing dominated by `failed` reads as
        # broken rather than merely "not built yet" — the distinction the old
        # two-way materialized/not count could not express.
        counts = {}
        for i in items:
            if isinstance(i, dict):
                counts[i.get("state")] = counts.get(i.get("state"), 0) + 1
        summary = ", ".join(f"{counts[s]} {s}" for s in
                            (STATE_MATERIALIZED, STATE_STALE, STATE_FAILED, STATE_NEVER_RUN)
                            if counts.get(s))
        click.echo(f"\n{summary} (of {len(items)} shown).")
        if counts.get(STATE_FAILED) or counts.get(STATE_STALE):
            click.echo("Run `torana datalake transformer <ID> status` for the failing error.")
        truncated = _last_run_scan_truncated(last_runs)
        if truncated:
            click.echo(f"Note: scanned the {_EXEC_SCAN_LIMIT} most recent of {truncated} "
                       f"executions — a transformer whose last run is older than that "
                       f"window is shown as {STATE_NEVER_RUN}.")


@datalake_transformers.command(name="list")
@click.option("--workspace-id", default=None, help="Filter by workspace UUID.")
@click.option("--state", default=None,
              type=click.Choice([STATE_MATERIALIZED, STATE_STALE, STATE_FAILED,
                                 STATE_NEVER_RUN], case_sensitive=False),
              help="Show only transformers in this materialization state.")
@click.option("--search", default=None, help="Search by name.")
@click.option("--materialized", "materialized_filter",
              type=click.Choice(["yes", "no"], case_sensitive=False), default=None,
              help="Show only transformers whose table is built (yes) or absent (no). "
                   "For a specific state use --state.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False,
              help="Auto-paginate and return all results.")
@click.pass_context
def datalake_transformers_list(ctx, workspace_id, state, search, materialized_filter,
                               page, page_size, fetch_all):
    """List every transformer with the STATE of its output table.

    A transformer DEFINITION and its output TABLE are two different facts:
    creating a transformer stores the definition, but the table only exists once
    a run succeeds. STATE reports both at once:

    \b
      materialized  definition exists AND the table is built
      stale         table is built, but the most recent run FAILED (data is old)
      failed        no table — it ran and errored (broken; needs a human)
      never-run     no table — defined but never executed (merely pending)

    Values are words, not yes/no, so a row stays unambiguous when grepped out of
    context and no token is a substring of another:

    \b
      torana datalake transformers list | grep failed
      torana datalake transformers list --state failed

    Note: the API's own `materialized` field is the BUILD MODE (table vs view),
    a stored config flag that stays true even when every run fails — it is NOT
    this state. Use STATE for what actually exists.
    """
    # Both filters test a CLIENT-resolved state (the server has no such field),
    # so they need the whole set in hand before paging.
    if materialized_filter or state:
        _list_transformers_filtered(
            ctx, workspace_id=workspace_id, search=search,
            want=materialized_filter.lower() if materialized_filter else None,
            state=state.lower() if state else None)
        return
    list_transformers_core(ctx, workspace_id=workspace_id, search=search,
                           page=page, page_size=page_size, fetch_all=fetch_all)


def _list_transformers_filtered(ctx, *, workspace_id, search, want=None, state=None):
    """List rows matching an exact `state`, or the built/not-built `want` split.

    Resolves STATE through the SAME resolve_materialization_state() the unfiltered
    list uses, so a row cannot report one state here and another there. `want`
    filters on whether the output table physically exists — `stale` counts as
    built (the table IS there, it is merely out of date), which is why the filter
    tests the state token rather than re-deriving `is_built` independently.

    Both filters are applied CLIENT-side: the transformers API exposes no state
    field (it is derived from table existence + run history), so there is nothing
    to push down to the server.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        items = _fetch_all_transformers(client, workspace_id=workspace_id)
        materialized = set(_fetch_transformer_table_names(client))
        last_runs = _fetch_last_run_by_transformer(client)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if search:
        needle = search.lower()
        items = [t for t in items if needle in (t.get("name") or "").lower()]

    built_states = (STATE_MATERIALIZED, STATE_STALE)
    kept = []
    for item in items:
        dest = item.get("destination_table")
        run = last_runs.get(item.get("id")) or {}
        resolved = resolve_materialization_state(
            is_built=bool(dest and dest in materialized),
            last_status=run.get("status"),
            has_runs=bool(run),
        )
        if state and resolved != state:
            continue
        if want and (want == "yes") != (resolved in built_states):
            continue
        srcs = item.get("source_tables") or []
        item["source_tables_display"] = ", ".join(srcs) if srcs else "—"
        item["state"] = resolved
        item["last_run_status"] = run.get("status")
        item["last_run_at"] = run.get("started_at")
        item["last_error"] = _first_error_line(run.get("error_message"))
        kept.append(item)

    _enrich_transformer_usage(ctx, kept)

    output({"items": kept, "total": len(kept), "page": 1, "page_size": len(kept)},
           fmt=fmt, raw=raw, fields=fields, columns=_TRANSFORMER_COLS)
    if fmt == "text":
        counts = {}
        for i in kept:
            counts[i.get("state")] = counts.get(i.get("state"), 0) + 1
        summary = ", ".join(f"{counts[s]} {s}" for s in
                            (STATE_MATERIALIZED, STATE_STALE, STATE_FAILED, STATE_NEVER_RUN)
                            if counts.get(s))
        click.echo(f"\n{summary or '0 rows'}.")


@datalake.group(name="tables")
def datalake_tables():
    """Manage datalake tables.

    \b
    Examples:
      torana datalake tables list
      torana datalake tables get assets
    """


def _extract_tables(data):
    """Normalize the several envelope shapes /tables/names may return to a list."""
    if isinstance(data, dict):
        return data.get("items") or data.get("tables") or []
    return data if isinstance(data, list) else []


@datalake_tables.command(name="list")
@click.option("--search", default=None, help="Search tables by name.")
@click.option("--include-transformers", is_flag=True, default=False,
              help="Include transformer output tables (default: only datalake tables).")
@click.option("--only-existing", is_flag=True, default=False,
              help=f"Show only tables that physically exist (hide {STATE_DECLARED} ones).")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def tables_list(ctx, search, include_transformers, only_existing, page, page_size):
    """List datalake tables with the STATE of each.

    A table being DECLARED and a table EXISTING are two different facts. The
    platform's schema registry declares a fixed set of tables (assets, findings,
    …), but a given tenant only has the ones physically created for it — so a
    listing that shows the registry alone reads as "we hold this data" when it
    may only mean "we could".

    \b
      materialized  the table physically exists in this tenant's schema
      declared      the schema declares it, but it does not exist here yet

    Values are words, not yes/no, so a row stays unambiguous when grepped out of
    context:

    \b
      torana datalake tables list | grep declared
      torana datalake tables list --only-existing

    By default lists ingested datalake tables only; --include-transformers also
    shows transformer output tables (whose STATE always reads materialized —
    they are DISCOVERED from the database, so an absent one simply is not
    listed. For unbuilt transformers see `datalake transformers list`).
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if search:
        params["search"] = search

    client = _client(ctx)
    try:
        # list_table_names. Returns names + light metadata (NOT row counts).
        data = client.get("/tables/names", params=params)
        tables = _extract_tables(data)

        # Second call with only_existing=true gives the tables that PHYSICALLY
        # exist. Differencing the two is what separates declared from real —
        # the default listing mixes code-declared base tables with
        # DB-discovered transformer tables and cannot distinguish them alone.
        try:
            present = {
                t.get("name") for t in
                _extract_tables(client.get("/tables/names",
                                           params={**params, "only_existing": True}))
            }
        except (APIError, AuthError):
            present = None      # unavailable → state omitted rather than guessed

        # Normalize category to "Transformer" or "Base"
        for table in tables:
            if table.get("category") == "Transformed Data":
                table["type_label"] = "Transformer"
            else:
                table["type_label"] = "Base"
            table["state"] = (
                "—" if present is None
                else STATE_MATERIALIZED if table.get("name") in present
                else STATE_DECLARED
            )

        if only_existing and present is not None:
            tables = [t for t in tables if t.get("state") == STATE_MATERIALIZED]

        # Filter by type unless --include-transformers is set
        if not include_transformers:
            tables = [t for t in tables if t.get("type_label") == "Base"]
        else:
            # Sort: Base tables first (alphabetical), then Transformer tables (alphabetical)
            base_tables = sorted([t for t in tables if t.get("type_label") == "Base"], key=lambda x: x.get("name", "").lower())
            transformer_tables = sorted([t for t in tables if t.get("type_label") == "Transformer"], key=lambda x: x.get("name", "").lower())
            tables = base_tables + transformer_tables

        result = {
            "items": tables,
            "total": len(tables),
            "page": page, "page_size": effective_page_size
        }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_TABLE_COLS)

    if fmt == "text" and tables:
        counts = {}
        for t in tables:
            counts[t.get("state")] = counts.get(t.get("state"), 0) + 1
        summary = ", ".join(f"{counts[s]} {s}" for s in (STATE_MATERIALIZED, STATE_DECLARED)
                            if counts.get(s))
        if summary:
            click.echo(f"\n{summary} (of {len(tables)} shown).")
        if counts.get(STATE_DECLARED):
            click.echo(f"{STATE_DECLARED} = the schema defines it, but it does not exist for "
                       f"this tenant yet (no data synced into it).")


@datalake_tables.command(name="get")
@click.argument("table_name", metavar="TABLE_NAME")
@click.pass_context
def tables_get(ctx, table_name):
    """Get schema (columns + types) for a specific datalake table.

    Alias for `torana datalake schema <table>` — both read the table's
    columns via /tables/{t}/columns. (The legacy /tables/{t}/ endpoint this
    used to call was removed server-side; it returned 404 for every table.)
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"/tables/{table_name}/columns")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@datalake_tables.command(name="create")
@click.argument("table_name", metavar="TABLE_NAME")
@click.option("--schema", default=None, metavar="JSON",
              help="JSON schema definition for the table.")
@click.option("--file", "input_file", default=None, metavar="FILE",
              help="JSON/YAML file with table definition.")
@click.pass_context
def tables_create(ctx, table_name, schema, input_file):
    """Create a new datalake table."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    from torana_cli.rules import _load_input_file
    body = {"name": table_name}
    if input_file:
        body.update(_load_input_file(input_file))
    elif schema:
        import json
        try:
            body["schema"] = json.loads(schema)
        except json.JSONDecodeError as exc:
            click.echo(f"ERROR: Invalid JSON in --schema: {exc}", err=True)
            import sys
            sys.exit(6)

    client = _client(ctx)
    try:
        data = client.post("/tables/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created table: {table_name}")


@datalake_tables.command(name="delete")
@click.argument("table_name", metavar="TABLE_NAME")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def tables_delete(ctx, table_name, yes):
    """Delete a datalake table."""
    _confirm(f"Delete table {table_name}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"/tables/{table_name}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted table: {table_name}")


@datalake_tables.command(name="show")
@click.option("--tenant-id", "tenant_id", required=True, metavar="TENANT_ID",
              help="REQUIRED. The tenant whose table data to show.")
@click.pass_context
def tables_show(ctx, tenant_id):
    """Show per-table row counts for a tenant, split by source (SDG vs other).

    \b
    Example:
      torana datalake tables show --tenant-id <uuid>

    Requires the sdg:purge permission (super-admin only).
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)

    try:
        data = client.get("/tables/row-stats-by-source", params={"tenant_id": tenant_id})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, fields=fields)
        return

    # Text render: aligned TABLE / TOTAL / SDG / OTHER columns.
    tables = data.get("tables", []) if isinstance(data, dict) else []
    click.echo(f"Tenant {data.get('tenant_id', tenant_id)}")
    click.echo(f"{'TABLE':<20} {'TOTAL':>10} {'SDG':>10} {'OTHER':>10}")
    for row in tables:
        click.echo(
            f"{row.get('table', ''):<20} {row.get('total', 0):>10} "
            f"{row.get('sdg', 0):>10} {row.get('other', 0):>10}"
        )
    click.echo(
        f"{'TOTAL':<20} {data.get('total', 0):>10} "
        f"{data.get('total_sdg', 0):>10} {data.get('total_other', 0):>10}"
    )
    errs = data.get("errors") if isinstance(data, dict) else None
    if errs:
        click.echo("Errors:", err=True)
        for e in errs:
            click.echo(f"  {e}", err=True)


@datalake_tables.command(name="clear-sdg-data")
@click.option("--tenant-id", "tenant_id", required=True, metavar="TENANT_ID",
              help="REQUIRED. The tenant whose SDG data to purge. SDG data lives "
                   "in per-tenant schemas, so the target must be stated explicitly.")
@click.option("--dry-run", is_flag=True, default=False,
              help="Show how much SDG data exists; delete nothing.")
@click.option("--force", is_flag=True, default=False,
              help="Skip the confirmation prompt and delete immediately.")
@click.option("--dataset", "dataset_tag", default=None, metavar="DATASET_TAG",
              help="Scope to a single dataset (dataset_tag / manifest id). "
                   "Omit to target ALL SDG data for the tenant.")
@click.pass_context
def tables_clear_sdg_data(ctx, tenant_id, dry_run, force, dataset_tag):
    """Clear SDG-seeded data (created_via='sdg_replay') from the sink tables.

    By default this first counts the SDG data present across all sink tables for
    the target tenant, shows the per-table breakdown, and asks for confirmation
    before deleting.

    \b
    Examples:
      torana datalake tables clear-sdg-data --tenant-id <uuid> --dry-run
      torana datalake tables clear-sdg-data --tenant-id <uuid>
      torana datalake tables clear-sdg-data --tenant-id <uuid> --force
      torana datalake tables clear-sdg-data --tenant-id <uuid> --dataset my-dataset-id --dry-run

    \b
    Requires the sdg:purge permission (super-admin only). The target tenant must
    be named explicitly via --tenant-id.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)

    def _call(do_dry_run):
        params = {"tenant_id": tenant_id, "dry_run": str(do_dry_run).lower()}
        if dataset_tag:
            params["dataset_tag"] = dataset_tag
        return client.post("/tables/clear-sdg-data", json={}, params=params)

    def _render(data, deleted):
        """Render the per-table breakdown for the text format."""
        scope = f" in tenant {tenant_id}"
        if dataset_tag:
            scope += f" for dataset '{dataset_tag}'"
        total = data.get("total_rows", 0) if isinstance(data, dict) else 0
        per_table = data.get("per_table", {}) if isinstance(data, dict) else {}
        verb = "Deleted" if deleted else "SDG data found"
        click.echo(f"{verb}{scope}: {total} row(s)")
        for tbl in sorted(per_table):
            count = per_table[tbl]
            if count:
                click.echo(f"  {tbl:<20} {count}")
        errs = data.get("errors") if isinstance(data, dict) else None
        if errs:
            click.echo("Errors:", err=True)
            for e in errs:
                click.echo(f"  {e}", err=True)

    try:
        # --- dry-run: count only, no delete, no confirmation ---
        if dry_run:
            data = _call(do_dry_run=True)
            if fmt != "text":
                output(data, fmt=fmt, fields=fields)
            else:
                _render(data, deleted=False)
            return

        # --- normal path: count first so the user knows the blast radius ---
        if not force:
            preview = _call(do_dry_run=True)
            total = preview.get("total_rows", 0) if isinstance(preview, dict) else 0
            if total == 0:
                click.echo("No SDG data found. Nothing to delete.")
                return
            if fmt == "text":
                _render(preview, deleted=False)
            _confirm(f"Delete {total} SDG row(s)?", yes=False)
        # --- delete ---
        data = _call(do_dry_run=False)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, fields=fields)
    else:
        _render(data, deleted=True)


@datalake.command(name="playground-execute")
@click.option("--sql", "sql", required=True, help="SQL query to execute")
@click.option("--limit", "limit", default=100, help="Maximum number of rows to return")
@click.pass_context
def playground_execute(ctx, sql, limit):
    """Execute SQL query in playground."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "/playground/execute"
    body = {}
    body["sql"] = sql
    if limit is not None:
        body["limit"] = limit

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@datalake.command(name="history")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def playground_history(ctx, page, page_size, fetch_all):
    """Get recent query history."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "/playground/history"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@datalake.command(name="history-clear")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def datalake_history_clear(ctx, yes):
    """Clear playground query history."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = "/playground/history"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@datalake.command(name="playground-health")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def playground_health(ctx, page, page_size, fetch_all):
    """Check health of playground service."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "/playground/health"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@datalake.command(name="query-execute")
@click.option("--sql-query", "sql_query", required=True, help="SQL query to execute")
@click.option("--validate-only", "validate_only", type=bool, default=False,
              help="Only validate syntax without executing (true/false).")
@click.option("--limit", "limit", type=int, default=100,
              help="Max rows to return (default 100, protects LLM context)")
@click.option("--return-all", "return_all", type=bool, default=False,
              help="Return all rows, ignore limit (true/false).")
@click.pass_context
def query_execute(ctx, sql_query, validate_only, limit, return_all):
    """Execute SQL query against the data lake with safety checks.

    \b
    Examples:
      torana datalake query-execute --sql-query "SELECT 1 AS one" --limit 1
      torana datalake query-execute --sql-query "SELECT * FROM vulnerabilities" --validate-only true
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    # Endpoint is POST /api/v1/query/execute (operation_id query_data).
    # Starts with "api/" so the client uses it verbatim (no extra /api/v1 prepend).
    path = "api/v1/query/execute"
    body = {"sql_query": sql_query}
    if validate_only is not None:
        body["validate_only"] = validate_only
    if limit is not None:
        body["limit"] = limit
    if return_all is not None:
        body["return_all"] = return_all

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@datalake.command(name="semantic")
@click.option("--query", "query", required=True, help="Natural language search query")
@click.option("--max-results", "max_results", default=10, help="Maximum number of results")
@click.option("--tables", "tables", default=None, help="Specific tables to search")
@click.pass_context
def search_semantic(ctx, query, max_results, tables):
    """Perform semantic search over security data."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "search/semantic"
    body = {}
    body["query"] = query
    if max_results is not None:
        body["max_results"] = max_results
    if tables is not None:
        body["tables"] = tables

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@datalake.command(name="search-health")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def search_health(ctx, page, page_size, fetch_all):
    """Check health of search services."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "search/health"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@datalake.command(name="reload")
@click.pass_context
def semantic_model_reload(ctx):
    """Reload Semantic Model."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "semantic-model/reload"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ⛔ NOT `@datalake.command(name="schema")` — that name is a GROUP (declared below), and
# registering a command under the same name made this silently unreachable: Click kept
# whichever object was bound last. It is attached to the group as `schema table` at the
# bottom of this module, once the group exists.
@click.command(name="table")
@click.argument("TABLE_NAME", metavar="TABLE_NAME")
@click.option("--detail", "detail", default="full",
              type=click.Choice(["terse", "compact", "full"]),
              help="Column render level: terse (collapsed types) | compact | full.")
@click.option("--columns", "columns_glob", default=None,
              help="Only show columns whose name matches one of these comma-separated glob "
                   "patterns (fnmatch, e.g. 'crit*,*scan*,asset_owner'). Case-insensitive. "
                   "Filters wide tables client-side so you don't dump 145 columns and grep.")
@click.option("--reachable", is_flag=True, default=False,
              help="Show ONLY columns a pipeline can write. OFF by default — enabling it "
                   "changes which columns you get back, and omits the full CREATE TABLE "
                   "(which would still list every declared column). Says nothing about "
                   "whether data has landed (see `reachable-columns`).")
@scope_options
@click.option("--writers", is_flag=True, default=False,
              help="ANNOTATE each column with HOW it is written — ETL mapping, API seam, "
                   "ingestor, decoration, platform stamp, push route, extractor — and by "
                   "which integration. ⭐ Unlike --reachable this HIDES NOTHING: a column "
                   "no pipeline writes is listed with 'nothing writes this', which is "
                   "exactly what you are looking for.")
@click.pass_context
def tables_schema(ctx, table_name, detail, columns_glob, reachable, scope,
                  writers, tenant_id):
    """Get a table's columns (names + types).

    \b
    ⚠️ The DECLARED schema is identical for every tenant (measured: 446 columns
    either way). --scope changes only the WRITER annotation and --reachable.

    \b
    ⭐ SEE ALSO:
      --writers                            add WHO writes each column (this table)
      torana datalake reachable-columns    the writer map for EVERY table at once
      torana datalake schema transformers  the tenant's derived tables
    ⚠️ --writers is a VIEW of `reachable-columns`, not a second answer — one
    fetch backs both, so they cannot drift.
    """
    scope, tenant_id = resolve_scope(scope, tenant_id)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    # get_table_columns (was get_table_schema /tables/{t}/schema?format=).
    path = f"/tables/{table_name}/columns"
    params = {}
    if detail is not None:
        params["detail"] = detail
    if reachable:
        params["reachable"] = "true"
        params["scope"] = scope

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if columns_glob:
        data = _filter_schema_columns(data, columns_glob)

    # ⚠️ `create_sql` is the FULL declared DDL — every column, always. Under
    # --reachable (or --columns) the caller asked for a SUBSET, so showing the
    # complete CREATE TABLE next to a 7-column schema states two different
    # answers to one question and reads as a bug. Drop it on any filtered view,
    # in EVERY format: a JSON consumer is misled by the contradiction just as a
    # human is. Unfiltered output keeps it — there it is simply the DDL.
    if isinstance(data, dict) and (reachable or columns_glob):
        data.pop("create_sql", None)

    # ⭐ THE JOIN: declared schema (types) + writer map (how it is written).
    # Neither endpoint carries the other's half — `/tables/{t}/columns` has
    # data_type and no writers, `reachable-columns` has writers and no
    # data_type — so answering "does every column have a writer, and what
    # writes it" previously meant joining two outputs by hand.
    # ⭐ JSON IS ALWAYS COMPLETE; THE FLAG IS A TEXT CONTROL.
    #
    # ⛔ A flag-shaped payload is a correctness hazard, not a saving. Without
    # --writers a consumer sees no `written_by` key — INDISTINGUISHABLE from
    # "this column has no writers". `has_writer: false` stated explicitly cannot
    # be misread; an absent key can, and that absence-reads-as-a-negative-answer
    # bug has bitten this surface repeatedly.
    #
    # ⚠️ The cost argument is gone: the writer map is cached server-side (300s),
    # so measured wall-clock was 0.67s with writers vs 0.63s without — noise.
    # Text still hides it behind --writers because a human scanning a terminal
    # is served by less; a program parsing JSON selects what it needs.
    wmap = None
    if fmt != "text" or writers:
        wmap = _fetch_writer_map(ctx, table_name, scope=scope, tenant_id=tenant_id)
        data = _annotate_schema_writers(data, wmap)
        if isinstance(data, dict):
            # Stamp the lens the annotation was computed under, so a SAVED
            # payload can never be misattributed to the other scope.
            data["writer_scope"] = scope
            if tenant_id:
                data["writer_tenant_id"] = tenant_id

    if fmt == "text" and isinstance(data, dict) and isinstance(data.get("schema"), dict):
        _render_schema_text(data, reachable=reachable, scope=scope)
        if writers:
            _render_writer_annotations(data, wmap, tenant_id=tenant_id, scope=scope)
        return

    output(data, fmt=fmt, fields=fields)


#: THE one place the reachability endpoint is called from this module.
#:
#: ⛔ TWO CALL SITES BUILDING THEIR OWN PARAMS IS THE DEFECT THIS REMOVES.
#: `reachable-columns` and `schema table --writers` answer the SAME question
#: ("who writes this column") against the SAME endpoint, so a difference in the
#: params one of them sends — `include_unreachable`, `explain`, the table filter
#: — makes the two surfaces disagree about the platform while both look correct.
#: That is the two-authorities-for-one-fact defect `load_system_columns` in the
#: text-to-sql gate carries a long comment about; it belongs here too.
#:
#: ⛔ Fetched from the API, NEVER parsed locally. The writer map is populated by
#: IMPORT inside pantheon-integration (`write_seam.WRITERS` fills when the
#: package loads); a host-side parse of the same sources reported 19 unwritten
#: columns where the API says 5.
_REACHABILITY_PATH = "datalake/reachable-columns"


def fetch_reachability(ctx, *, scope, tenant_id=None, tables=(),
                       explain=True, include_unreachable=True,
                       include_filtered=False):
    """Raw `reachable-columns` payload. Raises APIError/AuthError to the caller.

    ⭐ `include_filtered` — also return columns hidden by SCHEMA_SERVICES_FILTER, each
    stamped `filtered_out=true` + `filtered_by=[providers]`. Off by default, so the
    ordinary answer stays "what can I build on".
    """
    params = {"scope": scope, "explain": str(bool(explain)).lower()}
    if include_unreachable:
        params["include_unreachable"] = "true"
    if include_filtered:
        params["include_filtered"] = "true"
    if tables:
        params["table"] = list(tables)
    if tenant_id:
        params["tenant_id"] = tenant_id
    return _client(ctx).get(_REACHABILITY_PATH, params=params)


def _fetch_writer_map(ctx, table_name: str, *, scope: str,
                      tenant_id: str = None) -> dict:
    """`{column: [writer, ...]}` for ONE table — a VIEW of `fetch_reachability`.

    ⭐ `schema table --writers` is deliberately not a second implementation: it
    is this projection of the same payload `reachable-columns` returns, so the
    two can never drift.
    """
    try:
        payload = fetch_reachability(ctx, scope=scope, tenant_id=tenant_id,
                                     tables=(table_name,))
    except (APIError, AuthError):
        # ⚠️ Degrade loudly, never silently: returning {} here would annotate
        # every column "nothing writes this" — the most alarming possible way to
        # be wrong. The renderer checks for None and says the annotation is
        # unavailable instead.
        return None
    out = {}
    for c in payload.get("columns") or []:
        if c.get("table") == table_name:
            out[c.get("column")] = c.get("writers") or []
    # ⛔ MUST fold in `system_columns` — they are published OUTSIDE `columns[]` and
    # are stamped by the adapter on EVERY insert into EVERY table. Reading only
    # `columns` made this surface report `is_deleted` as "nothing writes this",
    # which is the documented regression that killed two cook runs: the build agent
    # was told the column did not exist and GAPed, while the platform's own reviewed
    # catalog SQL filters on it. Same trap the server-side `reachable_key_set`
    # docstring names — hit again here because this map is built independently.
    for sysname in payload.get("system_columns") or []:
        out.setdefault(sysname, [{"kind": "system", "source": "datalake_adapter"}])
    # ⚠️ Carry the filter state out with the map. The SCHEMA payload does not have
    # it (verified: its keys are create_sql/primary_key/schema/table_name/
    # writer_scope), so the renderer cannot read it from `data` — and a check
    # against `data` would silently always be False, printing the very
    # build-defect claim this is meant to suppress.
    out["__provider_filter__"] = payload.get("provider_filter") or {}
    return out


def _annotate_schema_writers(data: dict, wmap) -> dict:
    """Attach `written_by` to every column in the schema payload (JSON path)."""
    if wmap is None or not isinstance(data, dict):
        return data
    schema = data.get("schema")
    if not isinstance(schema, dict):
        return data
    # ⚠️ `schema` is FLAT — {column: {data_type, category, ...}} — NOT grouped by
    # category. Walking it as {category: {column: ...}} annotates the METADATA
    # KEYS (`data_type`, `category`, `semantic_description`) and reports them as
    # columns nothing writes. The text renderer groups by `category` itself.
    for name, meta in schema.items():
        if not isinstance(meta, dict):
            continue
        if name == "__provider_filter__":
            continue
        ws = wmap.get(name)
        meta["written_by"] = sorted({w.get("kind") for w in (ws or []) if w.get("kind")})
        meta["written_by_integrations"] = sorted(
            {w.get("integration") for w in (ws or []) if w.get("integration")}
        )
        meta["has_writer"] = bool(ws)
    return data


def _render_writer_annotations(data: dict, wmap, *, tenant_id=None,
                               scope: str = "platform") -> None:
    """Print the per-column writer annotation under the schema listing."""
    if wmap is None:
        click.echo("\n  ⚠️  Writer annotation unavailable — the reachability API "
                   "could not be read.\n      Types above are still correct; "
                   "'how it is written' is UNKNOWN, not 'nothing'.")
        return

    pfilter = wmap.get("__provider_filter__") or {}
    schema = data.get("schema") if isinstance(data, dict) else None
    # ⚠️ FLAT payload: the keys of `schema` ARE the column names.
    names = sorted(schema) if isinstance(schema, dict) else sorted(
        k for k in wmap if k != "__provider_filter__")

    lens = "platform — any integration Torana ships"
    if tenant_id:
        lens = f"tenant {tenant_id}"
    elif scope == "tenant":
        lens = "this tenant's connected integrations"
    click.echo(f"\n  HOW EACH COLUMN IS WRITTEN  ({lens})\n")

    width = max((len(n) for n in names), default=10)
    unwritten = []
    for n in names:
        ws = wmap.get(n) or []
        if not ws:
            unwritten.append(n)
            click.echo(f"    {n.ljust(width)}  ⚠️ nothing writes this")
            continue
        kinds = "+".join(sorted({_WRITER_KIND_LABEL.get(w.get("kind"), w.get("kind"))
                                 for w in ws if w.get("kind")}))
        ints = sorted({w.get("integration") for w in ws if w.get("integration")})
        via = f"   via {', '.join(ints)}" if ints else ""
        click.echo(f"    {n.ljust(width)}  {kinds}{via}")

    # ⛔ The count a reader is actually after: columns declared with NO writer.
    # Say it plainly rather than leaving them to scan for the ⚠️ lines.
    if unwritten:
        click.echo(f"\n    ⚠️  {len(unwritten)} of {len(names)} columns have NO writer "
                   f"in this scope.")
        if not tenant_id and scope == "platform":
            # ⛔ Under SCHEMA_SERVICES_FILTER this claim is FALSE for the hidden
            # columns: a pipeline exists and is simply not validated yet. Calling
            # that "a build defect nothing Torana ships can ever fill" names the
            # wrong owner and the wrong fix — the same conflation the Data Supply
            # page shipped (it rendered 109 defects where the true figure is 5).
            # The filter's own state is the only thing that tells the two apart.
            if pfilter.get("active"):
                click.echo("        ⚠️  SCHEMA_SERVICES_FILTER is ACTIVE, so this list "
                           "MIXES two different things:\n"
                           "          • a genuine build defect — nothing Torana ships "
                           "writes it; and\n"
                           "          • a column whose provider is simply not validated "
                           "yet (a pipeline\n"
                           "            EXISTS). Those have opposite owners and opposite "
                           "fixes.\n"
                           "        `torana datalake all-columns --reachable` splits them."
                           )
            else:
                click.echo("        At PLATFORM scope that is a build defect — the column "
                           "is declared and\n        nothing Torana ships can ever fill "
                           "it.")
        else:
            click.echo("        At TENANT scope that is usually a connection to make, "
                       "NOT a build defect.\n        Re-run with --scope platform to "
                       "tell the two apart.")
    else:
        click.echo(f"\n    ✅ All {len(names)} columns have at least one writer in "
                   f"this scope.")


# ── Shared text rendering for the two schema surfaces ───────────────────────
# `datalake schema <t>` and `datalake all-columns` return DIFFERENT payload
# shapes (one table with rich per-column metadata vs many tables with a flat
# name->type map), but they answer the same question and must never disagree
# about what "reachable" means or how a column list looks. The three helpers
# below are the single source of that shared behaviour.

def _reachability_caption(reachable: bool, scope: str) -> str:
    """The parenthetical that makes a column count interpretable.

    Never print a reachable count without the scope: `vulnerabilities` is 7 at
    tenant scope and 99 at platform scope, and the bare number invites comparing
    two different questions.
    """
    return f"(reachable, scope={scope})" if reachable else "(declared)"


def _echo_column_list(columns: dict, *, type_of, category_of=None) -> None:
    """Print `name  TYPE`, optionally grouped by category, aligned on one width.

    `type_of` / `category_of` adapt the two payload shapes: `schema` carries
    dicts ({data_type, category, ...}), `all-columns` carries a bare type string.
    """
    if not columns:
        return
    width = max(len(str(c)) for c in columns)

    if category_of is None:
        for name in sorted(columns):
            click.echo(f"  {name:<{width}}  {type_of(columns[name])}")
        return

    by_cat: dict = {}
    for name, meta in columns.items():
        by_cat.setdefault(category_of(meta) or "Uncategorized", []).append(name)
    for cat in sorted(by_cat):
        click.echo(f"\n{cat}")
        for name in sorted(by_cat[cat]):
            click.echo(f"  {name:<{width}}  {type_of(columns[name])}")


def _echo_reachable_footer(reachable: bool, scope: str) -> None:
    """The reachable≠populated warning, identical on both surfaces."""
    if not reachable:
        return
    click.echo("\n⚠️  reachable = a pipeline EXISTS that writes the column — NOT that "
               "data has landed.")
    if scope == "tenant":
        click.echo("    scope=tenant: only THIS tenant's connected integrations. "
                   "Use --scope platform to ask whether any shipped integration could.")


def _render_schema_text(data, *, reachable: bool, scope: str) -> None:
    """Render `datalake schema` as readable text.

    Replaces dumping the raw `schema` dict as one 43KB JSON line — which is what
    made `schema | wc -l` and `schema --reachable | wc -l` both report 195 and
    look identical, hiding a 181 -> 7 column difference.
    """
    schema = data.get("schema") or {}
    click.echo(f"TABLE        {data.get('table_name', '?')}")
    click.echo(f"PRIMARY KEY  {data.get('primary_key', '?')}")
    click.echo(f"COLUMNS      {len(schema)}  {_reachability_caption(reachable, scope)}")

    if not schema:
        click.echo("\nNo columns match.")
        if reachable and scope == "tenant":
            click.echo("Nothing this tenant's connected integrations can write. "
                       "Try --scope platform to ask whether ANY shipped "
                       "integration could.")
        return

    _echo_column_list(
        schema,
        type_of=lambda m: (m or {}).get("data_type", "") if isinstance(m, dict) else str(m),
        category_of=lambda m: (m or {}).get("category") if isinstance(m, dict) else None,
    )
    _echo_reachable_footer(reachable, scope)


def _filter_schema_columns(data, columns_glob):
    """Keep only schema columns whose name matches one of the comma-separated glob patterns.

    The columns endpoint returns `{table_name, primary_key, schema: {colname: {...}}}`. We filter
    the `schema` dict (case-insensitive fnmatch) so a wide table (145 cols) can be projected to the
    handful you care about — replacing the dump-to-file-and-grep pattern. Non-matching shapes pass
    through untouched (defensive: never hide data because the envelope changed).
    """
    import fnmatch
    if not isinstance(data, dict):
        return data
    schema = data.get("schema")
    if not isinstance(schema, dict):
        return data
    patterns = [p.strip().lower() for p in columns_glob.split(",") if p.strip()]
    if not patterns:
        return data
    kept = {
        name: meta for name, meta in schema.items()
        if any(fnmatch.fnmatch(str(name).lower(), pat) for pat in patterns)
    }
    out = dict(data)
    out["schema"] = kept
    return out


@datalake.command(name="summary")
@click.option("--include-transformers", "include_transformers", type=bool, default=False,
              help="Include transformer output tables in the summary.")
@click.pass_context
def tables_summary(ctx, include_transformers):
    """Get all tables summary (row counts + freshness per sink table)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    # get_all_table_row_stats (was get_all_tables_summary /tables/summary).
    path = "/tables/row-stats"
    params = {}
    if include_transformers is not None:
        params["include_transformers"] = include_transformers

    client = _client(ctx)
    try:
        # /tables/row-stats returns a single summary object (not a paginated
        # envelope), so skip/limit/fetch_all don't apply — one GET is enough.
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # json/yaml stay lossless; text/table get a per-table row listing so the
    # nested `tables` dict isn't JSON-dumped onto one line.
    if fmt in ("json", "yaml"):
        output(data, fmt=fmt, fields=fields, raw=raw)
        return

    def _row(name, stats, kind):
        # SOURCES — distinct source_system values among the active rows, i.e. the
        # systems that actually wrote here. `source_count` is None (rendered "-")
        # when the backend could not measure it; 0 is a real answer meaning
        # nothing has written to the table yet, so it must not collapse to "-".
        source_count = stats.get("source_count")
        return {
            "table": name,
            "kind": kind,
            "exists": stats.get("exists"),
            "count": stats.get("count", 0),
            "sources": "-" if source_count is None else source_count,
            "source_names": ", ".join(stats.get("sources") or []) or "-",
            "latest_update": stats.get("latest_update") or "-",
        }

    tables = data.get("tables", {}) if isinstance(data, dict) else {}
    items = [_row(name, stats, "sink") for name, stats in tables.items()]

    # `transformer_tables` came back as a full dict of {name: stats} and was only ever
    # COUNTED — the header claimed N transformer tables and the body listed none of
    # them, so an operator was told a number they could not enumerate. Render them.
    txf = data.get("transformer_tables")
    txf_rows = []
    if isinstance(txf, dict):
        txf_rows = [_row(name, stats, "transformer")
                    for name, stats in txf.items()
                    # Migration bookkeeping, not a transformer output. Counting it is the
                    # whole 38-vs-37 disagreement with `all-columns`, which excludes it.
                    if name != "alembic_version"]
    items.extend(txf_rows)

    # Highest row counts first; empty tables sink to the bottom.
    items.sort(key=lambda r: (r["count"] or 0), reverse=True)

    print(f"TOTAL TABLES     {data.get('total_tables', len(tables))}")
    print(f"EXISTING TABLES  {data.get('existing_tables', '')}")
    print(f"TOTAL RECORDS    {data.get('total_records', '')}")
    if txf_rows:
        print(f"TRANSFORMER TBLS {len(txf_rows)}")
    print()

    output(
        {"items": items, "total": len(items)},
        fmt=fmt,
        fields=fields,
        raw=raw,
        columns=[
            ("table", "TABLE", 24),
            ("kind", "KIND", 12),
            ("count", "ROWS", 10),
            ("sources", "SRCS", 6),
            ("source_names", "SOURCE SYSTEMS", 34),
            ("exists", "EXISTS", 7),
            ("latest_update", "LATEST UPDATE", 30),
        ],
    )


@datalake.command(name="table-summary")
@click.argument("TABLE_NAME", metavar="TABLE_NAME")
@click.pass_context
def datalake_table_summary(ctx, table_name):
    """Get a table's row count + freshness."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    # get_table_row_stats (was get_datalake_table_summary /tables/{t}/summary).
    path = f"/tables/{table_name}/row-stats"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@datalake.command(name="join-health")
@click.option("--measure", is_flag=True, default=False,
              help="Re-run the measurement (EXPENSIVE — runs every declared join).")
@click.option("--dry-run", "dry_run", is_flag=True, default=False,
              help="With --measure: compute verdicts but do NOT store them.")
@click.pass_context
def datalake_join_health(ctx, measure, dry_run):
    """Which declared joins actually connect — measured, not asserted.

    \b
    Reads the stored verdict for every join the semantic model declares. Measured on
    Classie 2026-09-14, 3 of the 8 declared joins matched 8% or fewer of the rows that
    ask for a partner, while rendering IDENTICALLY to the 3 that work. That is what
    makes an empty result unreadable: "there are none" and "this join has never
    connected" arrive looking the same.

    \b
    Verdicts:
      RELY        the join connects (orphan rate at or below 1%)
      DEGRADED    works for most rows, silently drops the rest
      NORELY      rows name partners that do not exist — an empty result is NOT
                  evidence of absence
      UNMEASURED  nobody has checked. NEVER read this as "fine".

    \b
    ⚠️ The orphan rate's denominator is JOINABLE rows (non-NULL keys), not all rows.
    A NULL key is not an orphan — the row never claimed a partner. Counting it as one
    makes an UNUSED join indistinguishable from a BROKEN one.

    \b
    Examples:
      torana datalake join-health
      torana datalake join-health --format json
      torana datalake join-health --measure --dry-run
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        # ⚠️ NO leading slash. `_build_url` treats a path starting with "/" as ABSOLUTE and
        # skips the `/api/v1/` prefix — so "/datalake/join-health" silently requests
        # `<base>/datalake/join-health`, which nginx falls through to the SPA as a 404. The
        # 404 then reads as "this capability does not exist", which is the most misleading
        # error this surface can produce. Every sibling here passes "datalake/...".
        if measure:
            path = "datalake/join-health/measure"
            if dry_run:
                path += "?dry_run=true"
            data = client.post(path, json={})
        else:
            data = client.get("datalake/join-health")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    except ValueError:
        # ⚠️ A non-JSON body reaching `client.get()`'s `resp.json()`. On this route it
        # means ONE thing in practice: the environment is running a datalake build from
        # before this endpoint existed, so nginx falls through to the SPA and returns
        # HTML with a 200. Rendering that as a JSON decode traceback blames the wrong
        # layer — it reads as a broken command rather than an un-deployed route.
        click.echo(
            "⛔ join-health is not available on this environment.\n"
            "   The endpoint returned a non-JSON body, which on this route means the\n"
            "   datalake service predates it. Needs: the s18_0006_join_trust migration\n"
            "   applied, then a restart of pantheon-datalake.",
            err=True,
        )
        raise SystemExit(1)

    if fmt != "text":
        output(data, fmt=fmt, fields=fields)
        return

    rows = data.get("results") if isinstance(data, dict) else data
    if not rows:
        click.echo("No declared joins found.")
        return

    if isinstance(data, dict):
        summary = data.get("summary") or {}
        click.echo(
            f"Measured {data.get('measured', 0)} joins in "
            f"{data.get('total_duration_ms', 0)} ms  "
            + "  ".join(f"{k}={v}" for k, v in sorted(summary.items()))
        )
        if data.get("tripwires_fired"):
            click.echo(f"⚠️  R3 tripwires fired: {', '.join(data['tripwires_fired'])}")
        if not data.get("persisted"):
            click.echo("⚠️  dry run — nothing was stored")
        click.echo("")

    for r in rows:
        trust = r.get("trust") or "UNMEASURED"
        # ⚠️ Every state carries a GLYPH as well as the word — never colour alone.
        mark = {
            "RELY": "✅ RELY",
            "NORELY": "⛔ NORELY",
            "DEGRADED": "⚠️  DEGRADED",
            "UNMEASURED": "·  UNMEASURED",
        }.get(trust, trust)
        name = r.get("relationship_name") or r.get("on") or "?"
        rate = r.get("orphan_rate")
        bits = [mark]
        if rate is not None:
            bits.append(f"orphan {float(rate):.1%}")
        if r.get("joinable_rows") is not None:
            bits.append(f"{r.get('matched_rows')}/{r.get('joinable_rows')} matched")
        if trust == "UNMEASURED" and r.get("unmeasured_reason"):
            bits.append(f"({r['unmeasured_reason']})")
        click.echo(f"{name:36} " + "  ".join(bits))
        diag = (r.get("diagnosis") or "").strip()
        if diag and trust != "RELY":
            click.echo(f"    └ {diag}")


@datalake.command(name="list-existing")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def tables_list_existing(ctx, page, page_size, fetch_all):
    """List existing tables."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    # Folded into list_table_names with only_existing=true (was list_existing_tables
    # /tables/list-existing).
    path = "/tables/names"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size,
              "only_existing": True}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@datalake.command(name="initialize")
@click.pass_context
def tables_initialize(ctx):
    """Initialize all tables."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "/tables/initialize"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@datalake.command(name="clear")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("TABLE_NAME", metavar="TABLE_NAME")
@click.pass_context
def tables_clear(ctx, table_name, yes):
    """Clear all data from a table (table structure is kept)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)

    if not yes:
        try:
            stats = client.get(f"/tables/{table_name}/row-stats")
            count = stats.get("count", stats.get("row_count")) if isinstance(stats, dict) else None
        except (APIError, AuthError):
            count = None
        if count is not None:
            click.echo(f"This will delete all {count:,} row(s) from {table_name}.")
        else:
            click.echo(f"This will delete all rows from {table_name}.")
        _confirm("Proceed?", yes=False)
    path = f"/tables/{table_name}/clear"
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@datalake.command(name="drop")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("TABLE_NAME", metavar="TABLE_NAME")
@click.pass_context
def tables_drop(ctx, table_name, yes):
    """Drop table."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"/tables/{table_name}/drop"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


def _fetch_table_row_counts(client):
    """Return (rows_by_table, total_rows) for sink tables that currently hold data.

    Uses /tables/row-stats. Returns ({}, 0) if the preview can't be fetched so the
    caller can still proceed (the confirmation just won't show numbers).
    """
    try:
        stats = client.get("/tables/row-stats")
    except (APIError, AuthError):
        return {}, 0
    tables = stats.get("tables", {}) if isinstance(stats, dict) else {}
    rows_by_table = {
        name: info.get("count", 0)
        for name, info in tables.items()
        if isinstance(info, dict) and info.get("count", 0)
    }
    total = stats.get("total_records") if isinstance(stats, dict) else None
    if total is None:
        total = sum(rows_by_table.values())
    return rows_by_table, total


@datalake.command(name="clear-all")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def tables_clear_all(ctx, yes):
    """Clear all data from every sink table (table structure is kept).

    Shows the per-table row counts and asks for confirmation before deleting,
    unless --yes is passed.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)

    if not yes:
        rows_by_table, total_rows = _fetch_table_row_counts(client)
        if not rows_by_table:
            click.echo("No sink tables currently contain data. Nothing to clear.")
            return
        click.echo(f"This will delete ALL rows from {len(rows_by_table)} table(s):")
        for name in sorted(rows_by_table):
            click.echo(f"  {name:<40} {rows_by_table[name]:>12,} rows")
        click.echo(f"  {'TOTAL':<40} {total_rows:>12,} rows")
        _confirm("Proceed with clearing all tables?", yes=False)
    path = "/tables/clear-all"
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


def _fetch_sink_table_names(client):
    """Return the datalake SINK table names (assets, vulnerabilities, …).

    Read from the datalake itself rather than hardcoded, so a newly added sink
    table is excluded automatically. Returns an empty set if unavailable — the
    caller must then fall back to metadata-backed transformer tables only,
    never to an unfiltered list.
    """
    try:
        data = client.get("/tables/names", params={"skip": 0, "limit": 200})
    except (APIError, AuthError):
        return set()
    rows = []
    if isinstance(data, dict):
        rows = data.get("items") or data.get("tables") or []
    elif isinstance(data, list):
        rows = data
    names = set()
    for r in rows:
        if isinstance(r, dict):
            # Anything not produced by a transformer is a sink table.
            if r.get("category") != "Transformed Data" and r.get("name"):
                names.add(r["name"])
    return names


def _fetch_transformer_table_names(client):
    """Return the list of transformer OUTPUT table names for this tenant.

    Includes orphaned tables (tables whose transformer metadata is gone) so a
    teardown does not silently leave them behind — but NEVER sink tables.

    In unified-Postgres mode sink tables and transformer outputs share one
    tenant schema, and `include_orphaned=true` means "every table in the schema
    with no transformer metadata" — which sweeps in all 11 sinks. Passing that
    straight through made `drop-all --include-transformers` try to clear the
    sinks (11 x HTTP 404, reported as partial_success). Subtract the sinks.

    Returns [] if the list can't be fetched.
    """
    try:
        # No trailing slash — the route is registered at "" and a trailing slash 404s.
        data = client.get("transformer-tables", params={"include_orphaned": "true"})
    except (APIError, AuthError):
        return []
    if isinstance(data, dict):
        names = data.get("tables") or data.get("items") or []
    elif isinstance(data, list):
        names = data
    else:
        names = []
    # The endpoint returns bare names; tolerate dict rows in case it ever changes.
    resolved = {
        n.get("name") if isinstance(n, dict) else n
        for n in names
        if (n.get("name") if isinstance(n, dict) else n)
    }

    sinks = _fetch_sink_table_names(client)
    if sinks:
        return sorted(resolved - sinks)

    # Sink list unavailable: fall back to the metadata-backed (non-orphaned)
    # list, which never contains sinks. Better to miss an orphan than to hand
    # a caller sink tables to clear or drop.
    try:
        safe = client.get("transformer-tables")
    except (APIError, AuthError):
        return []
    if isinstance(safe, dict):
        backed = safe.get("tables") or safe.get("items") or []
    else:
        backed = safe if isinstance(safe, list) else []
    return sorted(
        n.get("name") if isinstance(n, dict) else n
        for n in backed
        if (n.get("name") if isinstance(n, dict) else n)
    )


#: Bulk-executions page size. The endpoint caps `limit` at 500 and orders by
#: started_at DESC, so one call covers the most recent runs across ALL
#: transformers — the alternative (one /transformers/<id>/executions call per
#: row) would be 57+ round-trips to render a single listing.
_EXEC_SCAN_LIMIT = 500


def _fetch_last_run_by_transformer(client):
    """Return {transformer_id: most-recent-execution} for this tenant.

    Powers the STATE column: whether a definition is `failed` rather than merely
    `never-run` is only answerable from run history, which the transformers-list
    payload does not carry.

    Because rows arrive newest-first, the FIRST row seen for a transformer is its
    latest run — later rows for the same id are older and skipped.

    Best-effort by design: on any error this returns {} and every transformer
    falls back to `never-run`/`materialized`. A listing that loses the failed/
    never-run distinction is degraded but still truthful; one that fails outright
    because run history was unavailable is worse.

    Known bound: only the most recent _EXEC_SCAN_LIMIT executions tenant-wide are
    scanned, so a transformer whose last run is older than that window reports
    `never-run`. That understates breakage rather than inventing it, and the
    caller surfaces the cap via _last_run_scan_truncated().
    """
    try:
        data = client.get("transformer-executions", params={"limit": _EXEC_SCAN_LIMIT})
    except (APIError, AuthError):
        return {}
    if isinstance(data, dict):
        rows = data.get("executions") or data.get("items") or []
        total = data.get("total")
    elif isinstance(data, list):
        rows, total = data, len(data)
    else:
        return {}

    latest = {}
    for row in rows:
        if not isinstance(row, dict):
            continue
        tid = row.get("transformer_id")
        if tid and tid not in latest:      # newest-first: first seen wins
            latest[tid] = row
    if isinstance(total, int) and total > len(rows):
        latest["__truncated__"] = total
    return latest


def _last_run_scan_truncated(last_runs):
    """Total tenant executions when the scan window did not cover them all, else None.

    Never silently cap: a listing that scanned only part of the history must say
    so, or `never-run` reads as fact when it is really "not in the window".
    """
    return last_runs.get("__truncated__") if isinstance(last_runs, dict) else None


def _apply_to_transformer_tables(client, table_names, destructive):
    """Clear (DELETE FROM) or drop (DROP TABLE) each transformer table.

    There is no bulk transformer endpoint — transformer tables are owned by
    pantheon-data-transformers, not the datalake service — so this fans out over
    the existing per-table routes.

    Clearing is the default because it matches what `drop-all` effectively does
    to SINK tables: the datalake service owns sink schemas in code and recreates
    them, so a dropped sink table comes back empty. Transformer tables have no
    such owner — only a dbt re-run recreates them — so dropping them is durable
    and breaks every dashboard/rule querying them with "relation does not exist".
    Clearing keeps the schema and yields empty results instead.
    """
    verb = "drop" if destructive else "clear"
    done, errors = [], []
    for name in table_names:
        try:
            if destructive:
                # Route is DELETE /transformer-tables/{name}/drop
                client.delete(f"transformer-tables/{name}/drop")
            else:
                # Route is POST /transformer-tables/{name}/clear
                client.post(f"transformer-tables/{name}/clear")
            done.append(name)
        except (APIError, AuthError) as e:
            errors.append(f"Failed to {verb} transformer table {name}: {e}")
    return done, errors


@datalake.command(name="drop-all")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.option("--include-transformers", is_flag=True, default=False,
              help="Also CLEAR transformer output tables (keeps their schema, empties rows).")
@click.option("--drop-transformer-tables", is_flag=True, default=False,
              help="DESTRUCTIVE: drop transformer tables outright. They stay gone until "
                   "their transformers are re-executed. Implies --include-transformers.")
@click.pass_context
def tables_drop_all(ctx, yes, include_transformers, drop_transformer_tables):
    """Drop all tables.

    By default, drops only the datalake sink tables (assets, findings, etc.).
    Those are recreated empty by the datalake service, so they stay queryable.

    \b
    --include-transformers      also CLEARS transformer output tables (schema kept)
    --drop-transformer-tables   DROPS them instead — durable until a dbt re-run

    Transformer tables have no schema owner, so dropping them is permanent until
    the transformers are re-executed; anything querying them fails with
    "relation does not exist" in the meantime. Clearing is the safe default.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    # The destructive flag implies transformer scope — no need to pass both.
    if drop_transformer_tables:
        include_transformers = True

    client = _client(ctx)

    # Resolve the transformer table list BEFORE touching anything, so the
    # confirmation names exactly what is affected.
    transformer_names = _fetch_transformer_table_names(client) if include_transformers else []

    if not yes:
        if include_transformers:
            verb = "DROP" if drop_transformer_tables else "CLEAR"
            if transformer_names:
                click.echo(
                    f"This will drop all sink tables AND {verb} "
                    f"{len(transformer_names)} transformer output table(s):"
                )
                for name in transformer_names:
                    click.echo(f"  {name}")
                if drop_transformer_tables:
                    click.echo(
                        "\n!! DROP: these tables will be GONE — schema and data both.\n"
                        "   They do NOT come back on their own. Anything querying them\n"
                        "   (dashboards, widgets, detection rules) will FAIL with\n"
                        "   \"relation does not exist\" until you re-execute their\n"
                        "   transformers to rebuild them."
                    )
                else:
                    click.echo(
                        "\n-- CLEAR: the DATA will be gone, but the tables REMAIN.\n"
                        "   Schemas stay intact, so queries keep working and simply\n"
                        "   return no rows. Re-execute the transformers to refill them."
                    )
            else:
                click.echo(
                    "This will drop all sink tables. No transformer output tables were found."
                )
        _confirm("Are you sure?", yes=False)
    path = "/tables/drop-all"

    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if include_transformers:
        done, errors = _apply_to_transformer_tables(
            client, transformer_names, destructive=drop_transformer_tables
        )
        if isinstance(data, dict):
            key = ("transformer_tables_dropped" if drop_transformer_tables
                   else "transformer_tables_cleared")
            data[key] = done
            if errors:
                data["errors"] = list(data.get("errors") or []) + errors
                data["status"] = "partial_success"

    output(data, fmt=fmt, fields=fields)


# --all pages to exhaustion. Bound it: a server that ignores `offset` would otherwise
# return a full page forever. 500 pages x 100 rows = 50k rows before we stop and say so.
MAX_PAGES = 500


@datalake.command(name="data")
@click.argument("TABLE_NAME", metavar="TABLE_NAME")
@click.option("--limit", default=None, type=int,
              help="Rows to return (server default 100).")
@click.option("--offset", default=None, type=int, help="Row offset for paging.")
@click.option("--all", "fetch_all", is_flag=True, default=False,
              help="Auto-paginate to exhaustion and return ALL rows + a true total.")
@click.pass_context
def tables_data(ctx, table_name, limit, offset, fetch_all):
    """Query table data.

    The API paginates (limit/offset) but exposes NO total: its `count` is the length of the
    page you were handed, not the row count. So a bare call returning `count: 100` means
    "here are 100 rows", NOT "there are 100 rows" — use --all when you need a real total.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"/tables/{table_name}/data"
    client = _client(ctx)

    def _page(lim, off):
        params = {}
        if lim is not None:
            params["limit"] = lim
        if off is not None:
            params["offset"] = off
        return client.get(path, params=params or None)

    try:
        if not fetch_all:
            data = _page(limit, offset)
            # Flag the ambiguity rather than let a page masquerade as a count.
            if isinstance(data, dict) and data.get("count") == data.get("limit"):
                data["count_is_page"] = True
                data["hint"] = "Full page returned; total unknown. Re-run with --all for a true total."
        else:
            page_size = limit or 100
            rows, off, pages, truncated = [], offset or 0, 0, False
            seen_first = None
            while True:
                chunk = _page(page_size, off)
                got = chunk.get("data", []) if isinstance(chunk, dict) else (chunk or [])
                # If the server ignored `offset`, page 2 repeats page 1 forever. Detect it
                # rather than spin: compare the first row of consecutive pages.
                if pages == 1 and got and seen_first is not None and got[0] == seen_first:
                    raise click.ClickException(
                        "--all aborted: the server returned an identical page for offset "
                        f"{off} — `offset` appears to be ignored. Paginate manually with "
                        "--limit/--offset and verify.")
                if pages == 0 and got:
                    seen_first = got[0]
                rows.extend(got)
                pages += 1
                if len(got) < page_size:      # short page => last page => total is now known
                    break
                if pages >= MAX_PAGES:        # hard bound; never spin forever
                    truncated = True
                    break
                off += page_size
            data = {"data": rows, "count": len(rows), "count_is_page": truncated,
                    "pages_fetched": pages}
            if truncated:
                data["hint"] = (f"Stopped at the {MAX_PAGES}-page safety bound "
                                f"({len(rows)} rows); total is >= this and still unknown.")
            else:
                data["total"] = len(rows)     # exhausted => this IS the true total
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@datalake.command(name="table-data")
@click.argument("TABLE_NAME", metavar="TABLE_NAME")
@click.option("--filters", default=None,
              help='JSON filter body, e.g. \'{"severity": "critical"}\'. This is the ONLY '
                   'reason to prefer table-data over `data`.')
@click.option("--limit", default=None, type=int, help="Rows to return (server default 100).")
@click.option("--offset", default=None, type=int, help="Row offset for paging.")
@click.pass_context
def datalake_table_data(ctx, table_name, filters, limit, offset):
    """Query table data via POST — use when you need a JSON filter body.

    Same endpoint path as `datalake data`, different HTTP verb: the POST form accepts a
    filter/SQL body. Prefer `datalake data` for plain reads; reach for this only when you
    need --filters. (Previously this posted an empty body, making it an undocumented alias
    of `data` with no way to actually use the POST endpoint's filtering.)
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = {}
    if filters:
        try:
            body = json.loads(filters)
        except json.JSONDecodeError as e:
            raise click.BadParameter(f"--filters must be valid JSON: {e}")
    if limit is not None:
        body["limit"] = limit
    if offset is not None:
        body["offset"] = offset

    path = f"/tables/{table_name}/data"
    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if isinstance(data, dict) and data.get("count") == data.get("limit"):
        data["count_is_page"] = True
        data["hint"] = "Full page returned; total unknown (the API exposes no total)."

    output(data, fmt=fmt, fields=fields)


def _render_query_hints(data: dict) -> None:
    """Render the query-hints overlay as readable text, not raw JSON.

    ⛔ WHY THIS EXISTS. `output(data, fmt="text")` fell through to a JSON dump: measured
    2026-08-27, a bare `torana datalake query-hints` printed **129.6 KB in one blob** —
    every synonym list, every enum, and every multi-line `enum_source` provenance string
    inline. That is not a surface a person or a skill reads; it is a surface they pipe
    somewhere else.

    ⭐ ONE PAYLOAD, TWO RENDERERS — and the other one was already good. The platform harness
    turns the SAME `field_hints` into a `COLUMN MEANING` block
    (`pantheon-agent-builder/src/utils/schema_context_injector.py::_format_query_hints`).
    So the agent path saw well-shaped grounding while the skill path — `torana-vm` and
    `torana-text-to-sql`, which are TOLD to run this command — got the blob. This closes
    that asymmetry; it changes no data, only how it is shown.

    ⚠️ `--format json` is untouched and remains the machine-readable contract.
    """
    tables = data.get("tables") or {}
    flat = data.get("joins") or []

    # ⭐ MEASURES FIRST (Phase 3) — WHAT TO COUNT, before how tables join. Deliberately at
    # the top: measured on a live tenant, "how many vulnerable packages do we have?" has
    # three honest readings spanning 2,271x (92 / 741 / 208,920) and "how many
    # vulnerabilities?" spans 317x. Picking the wrong grain makes every downstream join
    # detail irrelevant, so the grain decision belongs before them.
    measures = data.get("measures") or []
    if measures:
        click.echo("MEASURES (WHAT TO COUNT — pick one and NAME it in a SQL comment):")
        for m in measures:
            click.echo(f"  {m.get('name')}")
            grain = (m.get("grain") or "").strip()
            if grain:
                click.echo(f"      grain: {grain}")
            definition = " ".join((m.get("definition") or "").split())
            if definition:
                click.echo(f"      {definition}")
            hint = (m.get("sql_hint") or "").strip()
            if hint:
                click.echo(f"      SQL:   {hint}")
            # ⭐ THE EMPTY CASE — measured by the E7 ablation as the ONE kind of sentence a
            # minimal measure statement loses (83% of the lift survives without it; the
            # missing 17% is entirely this). Printed BEFORE the trap because it changes what
            # the SQL must do, not merely what to avoid.
            empty = " ".join((m.get("empty_case") or "").split())
            if empty:
                click.echo(f"      empty: {empty}")
            trap = " ".join((m.get("trap") or "").split())
            if trap:
                # ⚠️ The trap is the half that changes behaviour — it names the plausible
                # WRONG reading, which is the one a reader would otherwise pick.
                click.echo(f"      ⚠️ {trap}")
        click.echo("  ⛔ If no measure fits the question, say so and ASK — do not invent a "
                   "grain silently.")
        click.echo("")

    if flat:
        # ⭐ TRUST IS MEASURED, NOT ASSERTED (Phase 1). Measured on Classie 2026-09-14,
        # 3 of the 8 declared joins match ≤8% of the rows that ask for a partner — and they
        # rendered IDENTICALLY to the 3 that work. That is the defect: an empty result from
        # a broken join and an empty result from a genuinely empty answer looked the same.
        click.echo("JOIN RELATIONSHIPS (trust is MEASURED per tenant; never guess a join):")
        seen = set()
        for j in flat:
            on = j.get("on")
            if not on or on in seen:
                continue
            seen.add(on)
            # ⚠️ Absent cardinality renders NOTHING, never a guessed default — an unstated
            # cardinality is honest, a wrong one is the fan-out bug this field exists to warn about.
            card = j.get("relationship_type")
            line = f"  {on}" + (f"   [{card}]" if card else "")
            trust = j.get("trust")
            if trust:
                # ⛔ The ⛔/⚠️ markers are paired with the WORD, never carried by colour
                # alone — the same reason every state badge in this platform pairs its
                # colour with a glyph.
                mark = {"NORELY": "⛔ NORELY", "DEGRADED": "⚠️ DEGRADED"}.get(trust, trust)
                rate = j.get("orphan_rate")
                bits = [mark]
                if rate is not None:
                    bits.append(f"orphan {rate:.1%}")
                if trust == "UNMEASURED":
                    reason = j.get("unmeasured_reason")
                    if reason:
                        bits.append(f"({reason})")
                measured = j.get("measured_at")
                if measured:
                    bits.append(f"measured {str(measured)[:19]}")
                line += "   " + "  ".join(bits)
            click.echo(line)
            # ⭐ The diagnosis is the half a human acts on. "0 of 568" says the join is
            # broken; only the sentence says WHY — and for the UNUSED-vs-BROKEN pair
            # (both read as no usable rows) the sentence is the ONLY thing that separates
            # them.
            diag = (j.get("diagnosis") or "").strip()
            if diag and trust and trust != "RELY":
                click.echo(f"      └ {diag}")
        click.echo("")

    for name in sorted(tables):
        meta = tables[name] or {}
        etypes = meta.get("edge_types")
        if not etypes:
            continue
        phys = meta.get("physical_table") or name.lower()
        click.echo(f"ENTITY GRAPH — table `{phys}` (adjacency list, many_to_many):")
        note = meta.get("join_note")
        if note:
            click.echo(f"  {note}")
        click.echo("  edge_type values (ALWAYS filter on one):")
        for et, spec in sorted(etypes.items()):
            click.echo(f"    {et:<14} {spec.get('from_key_prefix')} -> {spec.get('to_key_prefix')}")
        # ⭐ PHASE 2 — where a namespace's keys can actually be JOINED. Without this the only
        # way back from the graph to the rows is to guess, and a model guessed
        # `substring(from_key from 7)` — right only while every prefix is 6 characters.
        # ⚠️ A LIST, strongest first, with coverage: `image:` resolves in three columns on a
        # real tenant (100% / 39% / 7%), so naming one would point at the wrong table.
        nsmap = meta.get("namespaces")
        if nsmap:
            click.echo("  key RESOLUTION — where each namespace's keys can be joined "
                       "(measured on this tenant, best first):")
            for ns, spec in sorted(nsmap.items(),
                                   key=lambda kv: -(kv[1].get("graph_keys") or 0)):
                locs = spec.get("resolves_to") or []
                if not locs:
                    click.echo(f"    {ns:<11} ⛔ resolves NOWHERE — these keys exist only in "
                               f"`entity_edges`; do NOT join them to a sink table")
                    continue
                shown = "  ".join(
                    f"{l['table']}.{l['column']}"
                    + (f" ({l['coverage']:.0%})" if l.get("coverage") is not None else "")
                    for l in locs
                )
                click.echo(f"    {ns:<11} {shown}")
        click.echo("")

    standalone = sorted(n for n, m in tables.items() if (m or {}).get("standalone"))
    if standalone:
        click.echo("STANDALONE TABLES (no join relationship — do NOT join them):")
        click.echo("  " + ", ".join(t.lower() for t in standalone))
        click.echo("")

    # ⭐ COLUMN MEANING — the half that was buried. Grouped by table so a reader can scan
    # one table's vocabulary; the harness emits a flat list because it feeds a model, not a person.
    for name in sorted(tables):
        hints = (tables[name] or {}).get("field_hints") or {}
        rows = []
        for col, hint in sorted(hints.items()):
            desc = (hint.get("description") or "").strip()
            agg = (hint.get("aggregation") or "").strip()
            enum = hint.get("enum") or []
            if not desc and not agg and not enum:
                continue
            line = f"  {col}"
            if agg:
                line += f"  [aggregate with {agg.upper()}]"
            rows.append(line)
            if desc:
                rows.append(f"      {desc}")
            if enum:
                # ⚠️ `closed` is load-bearing: "these are the ONLY legal values" and "these are
                # the ones we know about" license different SQL. An author treating an OPEN
                # domain as closed writes a filter that silently drops rows.
                closed = "closed" if hint.get("enum_closed") else "OPEN — more values possible"
                shown = ", ".join(str(v) for v in enum[:12])
                more = f" … (+{len(enum) - 12} more)" if len(enum) > 12 else ""
                rows.append(f"      values [{closed}]: {shown}{more}")
        if rows:
            click.echo(f"COLUMN MEANING — {name} ({len(hints)} columns)")
            for r in rows:
                click.echo(r)
            click.echo("")


@datalake.command(name="query-hints")
@click.option(
    "--table",
    "tables",
    multiple=True,
    help="Filter to specific table name(s) (case-insensitive). Repeatable.",
)
@click.pass_context
def datalake_query_hints(ctx, tables):
    """Get query hints (synonyms, enums, join relationships) for the datalake.

    \b
    Returns the MEANING overlay only — synonyms, enum values, join keys, and
    standalone-table markers. It does NOT return columns/types; use
    `torana datalake schema <table>` or `torana datalake all-columns` for those.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    # get_query_hints (was get_semantic_model). Meaning only — no format/transformers knobs.
    params = {}
    if tables:
        params["tables"] = list(tables)

    client = _client(ctx)
    try:
        data = client.get("query-hints", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # ⭐ Text is the DEFAULT and therefore the surface most callers actually see — render it.
    # json/yaml stay the machine contract and go through `output()` unchanged, so anything
    # parsing this command is unaffected. A `--fields` selection also falls through to
    # `output()`: the caller has asked for specific keys, not for the readable shape.
    if fmt == "text" and not fields:
        _render_query_hints(data)
    else:
        output(data, fmt=fmt, fields=fields)


@datalake.command(name="model-conformance")
@click.option("--table", "table", default=None,
              help="Filter to one table (case-insensitive). Omit for all.")
@click.option("--severity", "severity", default="all",
              type=click.Choice(["error", "warn", "all"]),
              help="Filter findings by severity.")
@click.option("--probe-data/--no-probe-data", default=True,
              help="Run checks 3/4/5, which read distinct values. --no-probe-data = static only.")
@click.pass_context
def datalake_model_conformance(ctx, table, severity, probe_data):
    """Does the semantic model match the live schema and the live data?

    \b
    Five checks (Torana_Datalake_Fixes.md § 3.3):
      1  every declared primary key / dimension exists on the table
      2  every physical column appears in the model
      3  a declared enum covers the values actually STORED
      4  a dimension holds >= 2 distinct values
      5  a documented column holds >= 1 non-NULL row

    \b
    REPORTS, never refuses. ERROR is reserved for tenant-INVARIANT defects of the
    model file itself — a ghost primary key (feeds the join projection, so the SQL
    errors or joins wrong) and an enum disjoint from the data (SILENT ZERO: valid
    SQL, no rows, no error). Everything else is WARN because it depends on THIS
    tenant's data: one distinct value here may be five elsewhere, and an empty
    column may fill next week.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {"severity": severity, "probe_data": str(probe_data).lower()}
    if table:
        params["table"] = table

    client = _client(ctx)
    try:
        data = client.get("datalake/model-conformance", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, fields=fields)
        return

    # ⚠️ Severity is carried by a TEXT LABEL and a glyph, never by colour alone —
    # a red/green dot is unreadable to a red-green colour-blind reader.
    errors = data.get("errors", 0)
    warnings = data.get("warnings", 0)
    click.echo(f"TABLES CHECKED  {data.get('tables_checked', 0)}")
    click.echo(f"DATA PROBED     {data.get('probed_data')}")
    click.echo(f"\u2716 ERRORS        {errors}")
    click.echo(f"\u26a0 WARNINGS      {warnings}")
    if errors == 0 and warnings == 0:
        click.echo("\nNo findings.")
        return

    click.echo("")
    for f in data.get("findings") or []:
        glyph = "\u2716 ERROR" if f.get("severity") == "ERROR" else "\u26a0 WARN "
        col = f".{f['column']}" if f.get("column") else ""
        click.echo(f"{glyph}  {f.get('code', ''):22} {f.get('table', '')}{col}")
        d = f.get("detail") or {}
        if d.get("declared"):
            click.echo(f"           declared: {', '.join(map(str, d['declared']))}")
        if d.get("observed"):
            click.echo(f"           observed: {', '.join(map(str, d['observed'][:12]))}")
        if d.get("undeclared"):
            click.echo(f"           UNDECLARED IN MODEL: {', '.join(map(str, d['undeclared'][:12]))}")
        if d.get("case_mismatch_only"):
            click.echo("           ^ case mismatch only — fix the CASE, do not add members")
        if d.get("distinct") is not None:
            click.echo(f"           distinct non-NULL values: {d['distinct']}")
        if d.get("physical_candidates"):
            click.echo(f"           real key candidates: {', '.join(d['physical_candidates'])}")


@datalake.command(name="semantic-model", hidden=True)
@click.option("--table", "tables", multiple=True, help="Filter to specific table name(s).")
@click.pass_context
def datalake_semantic_model(ctx, tables):
    """DEPRECATED alias for `query-hints`. Use `torana datalake query-hints`."""
    ctx.invoke(datalake_query_hints, tables=tables)


@datalake.command(name="all-columns")
@click.option(
    "--detail", "detail", default="terse",
    type=click.Choice(["terse", "compact", "full"]),
    help="Column render level: terse (collapsed types) | compact | full.",
)
@click.option(
    "--table", "tables", multiple=True,
    help="Filter to specific table name(s) (case-insensitive). Repeatable. Omit for all tables.",
)
@click.option(
    "--include-transformers/--no-include-transformers", default=False,
    help="ALSO show the tenant's live transformer/aggregator output tables. OFF by "
         "default: the canonical SINK tables are the platform schema — identical for "
         "every tenant and the portable surface to author SQL against. Transformer "
         "tables are DERIVED outputs one tenant's own models built, so including them "
         "by default mixed a per-tenant artifact into the answer to 'what is the "
         "schema'. For transformers alone use `datalake schema transformers`.",
)
@click.option(
    "--reachable", is_flag=True, default=False,
    help="Show ONLY columns a pipeline can write. OFF by default — enabling it changes "
         "which columns you get back. Transformer tables are left intact (their columns "
         "come from SQL, not an ingest pipeline). Says nothing about whether data landed.",
)
@scope_options
@click.option(
    "--value-domains", is_flag=True, default=False,
    help="Show each column's DECLARED value domain (§ 4.7) — what it can hold, and the file "
         "that declares it. ⚠️ Declared, never observed: no tenant rows are read.",
)
@click.pass_context
def datalake_all_columns(ctx, detail, tables, include_transformers, reachable, scope,
                         tenant_id, value_domains):
    """Get columns + types for ALL tables in one call (bulk).

    \b
    get_all_table_columns — the bulk schema endpoint. Returns the column truth
    (names + types) for every table (canonical + transformer) in a single call.
    Pair with `query-hints` for synonyms/enums/joins.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {"detail": detail}
    if tables:
        params["tables"] = list(tables)
    # ⚠️ Send the flag EXPLICITLY either way. The server's own default is to
    # include, so omitting the param on the off path would silently re-include.
    params["include_transformers"] = "true" if include_transformers else "false"
    # ⛔ Validate ALWAYS, not only under --reachable. `--scope` used to be
    # accepted and silently INERT without it — measured, 489 columns for both
    # platform and tenant — so a caller who passed it believed they had scoped
    # the answer and had not.
    scope, tenant_id = resolve_scope(scope, tenant_id)
    if reachable:
        params["reachable"] = "true"
        params["scope"] = scope
        if tenant_id:
            params["tenant_id"] = tenant_id

    client = _client(ctx)
    try:
        data = client.get("/tables/schema", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # These two fields are meaningful ONLY on the --reachable path. The response
    # model always carries them, so drop the nulls rather than render
    # "REACHABLE SCOPE None" on an ordinary schema dump.
    if isinstance(data, dict) and not reachable:
        data.pop("reachable_scope", None)
        data.pop("reachable_note", None)
        data.pop("reachable_summary", None)

    if fmt == "text" and isinstance(data, dict) and isinstance(data.get("tables"), dict):
        # `reachable_summary` / `reachable_note` are rendered below by
        # _echo_reachability_summary in a readable box. Echoing the raw dicts
        # first would state the same numbers twice, in a worse format.
        _render_all_columns_text(data, reachable=reachable, scope=scope,
                                 value_domains=value_domains)
    else:
        output(data, fmt=fmt, fields=fields)

    # A raw table count cannot answer "how much of the schema can I build on".
    # Print the COLUMN arithmetic, the integrations that define scope=tenant, and
    # what was excluded — so the number is interpretable without re-deriving a
    # denominator the filtered payload no longer contains.
    #
    # ⚠️ TEXT ONLY. This box is decorative ASCII; emitting it after a --format
    # json payload made stdout invalid JSON ("Extra data: line 98"), so every
    # programmatic consumer of `all-columns --reachable --format json` failed to
    # parse. The same numbers are already in the payload's `reachable_summary`.
    if reachable and fmt == "text" and isinstance(data, dict):
        _echo_reachability_summary(
            data.get("reachable_summary"),
            transformer_excluded=(data.get("reachable_summary") or {}).get(
                "transformer_tables_excluded"),
        )


def _render_all_columns_text(data, *, reachable: bool, scope: str,
                             value_domains: bool = False) -> None:
    """Render `datalake all-columns` as readable text.

    Replaces dumping the whole `tables` map as one 39KB JSON line. Two reasons
    that shape was wrong, both user-visible:

      - `all-columns` and `all-columns --reachable` were indistinguishable at a
        glance (5 lines vs 31) even though the column counts differ ~60x.
      - On the --reachable path the raw blob printed ABOVE the summary box that
        explains it, so the first thing on screen was the least interpretable.

    `COUNT` is deliberately labelled `TABLES SHOWN` against `CANONICAL COUNT`:
    under --reachable, tables whose every column was filtered out disappear
    entirely, and a bare "6" next to a declared 11 reads as data loss.
    """
    tables = data.get("tables") or {}
    canonical = data.get("canonical_count")
    transformer = data.get("transformer_count")

    click.echo(f"TABLES SHOWN  {len(tables)}  {_reachability_caption(reachable, scope)}")
    if canonical is not None:
        click.echo(f"CANONICAL     {canonical}   platform schema — identical for every tenant")
    if transformer:
        click.echo(f"TRANSFORMER   {transformer}   ⚠️ PER-TENANT — derived tables this "
                   f"tenant's own models built")
    # ⛔ SAY WHICH SCHEMA THIS IS. Without transformers the answer is a PLATFORM
    # fact (13 canonical tables, byte-identical for SA and any tenant); with them
    # it is a TENANT fact (measured: SA 18 transformer tables, T1 just 1). The
    # same command answering two different questions with no label is how a
    # per-tenant artifact gets quoted as the platform schema.
    elif canonical is not None:
        click.echo("              --include-transformers ALSO shows this tenant's "
                   "derived tables.")

    total_cols = 0
    for tname in sorted(tables):
        meta = tables[tname] if isinstance(tables[tname], dict) else {}
        cols = meta.get("columns") or {}
        total_cols += len(cols)
        pk = meta.get("primary_key") or []
        pk_txt = ", ".join(pk) if isinstance(pk, list) else str(pk)
        click.echo(f"\n{tname}  ({len(cols)} columns)"
                   + (f"   pk: {pk_txt}" if pk_txt else ""))
        # all-columns returns a flat name->type map, so no category grouping.
        _echo_column_list(cols, type_of=lambda t: t)

        # ⭐ § 4.7 — what each column CAN HOLD, and WHICH FILE says so.
        #
        # ⚠️ Opt-in: two lines per column would bury the type list it annotates.
        # ⛔ UNDESCRIBED columns are printed too, not skipped — the backlog is only
        # actionable if it is visible, and a reader who sees only the described ones
        # concludes the model is complete.
        if value_domains:
            vds = meta.get("value_domains") or {}
            if not vds:
                click.echo("    (this server does not serve value_domains yet)")
            for cname in sorted(cols):
                vd = vds.get(cname) or {}
                src = vd.get("source")
                if not src:
                    click.echo(f"    {cname:34} - not yet described")
                    continue
                kind = "closed" if vd.get("closed") else "open"
                vals = ", ".join(vd.get("values") or []) or "(none)"
                click.echo(f"    {cname:34} [{kind}] {vals}")
                click.echo(f"    {'':34}   declared by: {src}")

    click.echo(f"\nTotal columns shown: {total_cols}")
    _echo_reachable_footer(reachable, scope)


@datalake.command(name="generate-query")
@click.option("--input", "input_file", default=None, help="JSON/YAML with query generation request.")
@click.option("--question", default=None, help="Natural language question to generate a query for.")
@click.pass_context
def datalake_generate_query(ctx, input_file, question):
    """Generate a datalake query from natural language."""
    from torana_cli.rules import _load_input_file
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = _load_input_file(input_file) if input_file else {}
    if question:
        body["question"] = question

    client = _client(ctx)
    try:
        data = client.post("/query/generate", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# Attach the transformer sub-commands defined in sibling modules. Imported at the
# END of this module (not the top) because those modules import `datalake_transformers`
# from here — a top-level import either way would be circular.
def _attach_transformer_commands():
    import torana_cli.transformers  # noqa: F401  (registers plural verbs on the group)
    _attach_transformer_singular()



# ── Decoration layer (DECORATION_LAYER_SPEC.md § 3.12) ──────────────────────

_DECORATION_REGISTRY_COLS = [
    ("name", "DECORATION", 14),
    ("decorates", "SINK", 18),
    ("subject", "SUBJECT", 12),
    ("scope", "SCOPE", 8),
    ("columns", "COLUMNS WRITTEN", 60),
]
_DECORATION_STATUS_COLS = [
    ("decoration", "DECORATION", 14),
    ("namespace", "NAMESPACE", 12),
    ("status", "STATUS", 10),
    # "never" (not 0s) when nothing has applied — unbound is not fresh.
    ("staleness", "AGE", 8),
    ("pending_apply", "PENDING", 9),
    ("error", "ERROR", 40),
]
_JOB_COLS = [
    ("decoration", "DECORATION", 14),
    ("state", "STATE", 11),
    ("attempt", "ATTEMPT", 9),
    ("rows_updated", "ROWS", 9),
    ("enqueued_at", "ENQUEUED", 20),
    ("error", "ERROR", 40),
]


def _age(seconds):
    """Human staleness. `None` renders as `never`, NOT `0s`.

    A decoration that has never applied is *unbound*, not *fresh* — showing 0s would
    be the confident-wrong answer this whole layer exists to remove.
    """
    if seconds is None:
        return "never"
    s = float(seconds)
    if s < 90:
        return f"{int(s)}s"
    if s < 5400:
        return f"{int(s // 60)}m"
    if s < 172800:
        return f"{int(s // 3600)}h"
    return f"{int(s // 86400)}d"


@datalake.group(name="decorations")
def datalake_decorations():
    """Decoration health and provenance.

    A decoration is a platform-asserted fact (CVE threat intel, an SLA policy)
    applied to datalake rows WITH provenance — so a reader can tell what wrote a
    number and whether it is current.

    \b
    Examples:
      torana datalake decorations list
      torana datalake decorations status
      torana datalake decorations jobs --state abandoned
      torana datalake decorations refresh cve_intel
      torana datalake decorations retry "cve_intel|t|n|123"
    """


@datalake_decorations.command(name="list")
@click.pass_context
def decorations_list(ctx):
    """The registry: what the platform can decorate, and how.

    Read from the live registry, so it can never drift from what the apply job
    actually writes.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("decorations")
    except APIError as e:
        handle_api_error(e); return
    except AuthError as e:
        handle_auth_error(e); return

    rows = []
    for d in data.get("decorations", []):
        rows.append({
            "name": d.get("name"),
            "decorates": d.get("decorates"),
            "subject": d.get("subject_column"),
            "scope": d.get("scope"),
            "columns": ", ".join(p.get("column") for p in d.get("provides", [])),
        })
    output({"items": rows, "total": len(rows)}, fmt=fmt, raw=raw, fields=fields,
           columns=_DECORATION_REGISTRY_COLS)


@datalake_decorations.command(name="status")
@click.option("--decoration", default=None, help="Filter to one decoration.")
@click.pass_context
def decorations_status(ctx, decoration):
    """Health per decoration: is my data current, and did the last apply succeed?

    \b
    Three states, and they are NOT three flavours of the same thing:
      ok        facts landed and applied
      unbound   no facts — this tenant never configured it. NOT an error.
      error     the producer or apply failed; previous values stand

    A multi-namespace tenant shows one line per namespace beneath its decoration.
    The GROUP status is the WORST of its children, so a failing namespace can
    never hide behind a healthy one.

    EXIT 1 when any decoration is `error`. `unbound` is not a failure — exiting
    non-zero for "you never configured this" would make the check unusable in CI.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    params = {"decoration": decoration} if decoration else None
    try:
        data = client.get("decorations/status", params=params)
    except APIError as e:
        handle_api_error(e); return
    except AuthError as e:
        handle_auth_error(e); return

    # A `global`-scope decoration's facts are not tenant data (CISA KEV / FIRST EPSS
    # are public facts about a CVE), so its namespace-less row is the FEED status.
    # A tenant-scoped decoration's namespace-less row is a TENANT-WIDE roll-up.
    # Rendering both as "global" hid the difference between "the feed is healthy"
    # and "this tenant was visited" — so they are named apart, matching the FE.
    scope_of = {}
    try:
        reg = client.get("decorations")
        scope_of = {d["name"]: d.get("scope") for d in reg.get("decorations", [])}
    except (APIError, AuthError):
        pass          # label degrades to the generic form; never blocks the status

    rows, has_error = [], False
    for d in data.get("decorations", []):
        if d.get("status") == "error":
            has_error = True
        name = d.get("decoration")
        blank = "feed" if scope_of.get(name) == "global" else "tenant-wide"
        namespaces = d.get("namespaces") or []
        if not namespaces:
            rows.append({"decoration": name, "status": d.get("status"),
                         "namespace": "—", "staleness": "never",
                         "pending_apply": "—", "error": ""})
            continue
        for ns in namespaces:
            rows.append({
                "decoration": name,
                "status": ns.get("status"),
                "namespace": (ns.get("namespace_id") or "")[:8] or blank,
                "staleness": _age(ns.get("staleness_seconds")),
                "pending_apply": "yes" if ns.get("pending_apply") else "no",
                "error": (ns.get("error") or "")[:60],
            })

    output({"items": rows, "total": len(rows)}, fmt=fmt, raw=raw, fields=fields,
           columns=_DECORATION_STATUS_COLS)

    if has_error:
        if fmt == "text":
            click.echo("\nOne or more decorations are in ERROR — see the error column.", err=True)
        ctx.exit(1)


@datalake_decorations.command(name="jobs")
@click.option("--state", default=None,
              help="pending|claimed|succeeded|failed|abandoned")
@click.option("--decoration", default=None, help="Filter to one decoration.")
@click.option("--limit", default=50, show_default=True, type=int)
@click.option("--offset", default=0, show_default=True, type=int)
@click.pass_context
def decorations_jobs(ctx, state, decoration, limit, offset):
    """Apply-job history — the state machine, made visible.

    This is the t0 -> t1 -> t2 trace: what was enqueued, what claimed it, how many
    attempts it took, how many rows changed, and the error if it failed. Without
    it, "my data is stale" has no observable cause.

    `failed`/`abandoned` jobs are never auto-deleted, so an unapplied retraction
    always has a visible owner here.

    EXIT 1 when any listed job is `abandoned` — that is terminal until an operator
    acts, and it means a row somewhere holds a value whose fact no longer exists.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {"limit": min(limit, 100), "offset": offset}
    if state:
        params["state"] = state
    if decoration:
        params["decoration"] = decoration

    client = _client(ctx)
    try:
        data = client.get("decorations/jobs", params=params)
    except APIError as e:
        handle_api_error(e); return
    except AuthError as e:
        handle_auth_error(e); return

    jobs = data.get("jobs", [])
    rows = [{
        "decoration": j.get("decoration"),
        "state": j.get("state"),
        "attempt": f"{j.get('attempt')}/{j.get('max_attempts')}",
        "rows_updated": j.get("rows_updated"),
        "enqueued_at": str(j.get("enqueued_at") or "")[:19],
        "error": (j.get("error") or "")[:50],
        "job_key": j.get("job_key"),
    } for j in jobs]

    output({"items": rows, "total": data.get("total", len(rows))},
           fmt=fmt, raw=raw, fields=fields, columns=_JOB_COLS)

    if any(j.get("state") == "abandoned" for j in jobs):
        if fmt == "text":
            click.echo("\nAbandoned job(s) present — retry with: "
                       "torana datalake decorations retry <JOB_KEY>", err=True)
        ctx.exit(1)


@datalake_decorations.command(name="refresh")
@click.argument("name")
@click.pass_context
def decorations_refresh(ctx, name):
    """Force a producer run for NAME, then an apply.

    Returns as soon as the run is ACCEPTED — the cve_intel producer reads 353k
    CVEs and lands ~710k facts (measured: ~2 minutes), so it runs in the
    background. Watch `decorations status` for the new source_version and
    `decorations jobs` for the apply.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    client = _client(ctx)
    try:
        data = client.post(f"decorations/{name}/refresh", json={})
    except APIError as e:
        handle_api_error(e); return
    except AuthError as e:
        handle_auth_error(e); return

    if fmt == "text" and not raw:
        click.echo(f"Refresh accepted for '{name}'.")
        click.echo("  torana datalake decorations status   # watch source_version")
        click.echo("  torana datalake decorations jobs     # watch the apply")
    else:
        output(data, fmt=fmt, raw=raw)


@datalake_decorations.command(name="retry")
@click.argument("job_key")
@click.pass_context
def decorations_retry(ctx, job_key):
    """Re-arm an abandoned (or failed) job: back to pending, attempt reset to 0.

    `abandoned` is terminal but NOT permanent — this is the transition that makes
    that true.

    JOB_KEY is the pipe-joined natural key from `decorations jobs`, e.g.
    "cve_intel|<tenant>|<namespace>|<generation>". Quote it — the shell treats a
    bare pipe as a pipeline.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    client = _client(ctx)
    try:
        data = client.post(f"decorations/jobs/{job_key}/retry", json={})
    except APIError as e:
        handle_api_error(e); return
    except AuthError as e:
        handle_auth_error(e); return

    if fmt == "text" and not raw:
        click.echo(f"Job re-armed: {job_key}")
        click.echo("  state=pending  attempt=0 — the next tick will claim it.")
    else:
        output(data, fmt=fmt, raw=raw)

_attach_transformer_commands()


_COVERAGE_COLS = [
    ("table", "TABLE", 34),
    ("columns", "COLUMNS", 9),
    ("described", "DESCRIBED", 11),
]


@datalake.command(name="schema-coverage")
@click.option("--table", "table_name", default=None, metavar="TABLE",
              help="Report one table instead of all.")
@click.option("--undescribed", is_flag=True, default=False,
              help="List the column names still missing a description.")
@click.pass_context
def datalake_schema_coverage(ctx, table_name, undescribed):
    """Report how many columns carry a written meaning.

    A column's TYPE says how it is stored; it does not say what it means. The
    schema carries an optional description per column, and this reports how much
    of it is written — per table, so the gap is visible where it matters rather
    than as one platform-wide number.

    This REPORTS; it never fails on a low count. Coverage is authored over time,
    and a command that exits non-zero at 4% would only teach people to stop
    running it.

    \b
      torana datalake schema-coverage
      torana datalake schema-coverage --table packages --undescribed
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW) if ctx.obj else False

    client = _client(ctx)
    try:
        if table_name:
            payload = {table_name: client.get(
                f"/tables/{table_name}/columns", params={"detail": "compact"})}
        else:
            data = client.get("/tables/schema", params={"detail": "compact"})
            payload = data.get("tables") or data.get("schemas") or data or {}
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    rows, missing = [], {}
    for name, tbl in sorted((payload or {}).items()):
        # The two endpoints disagree on the key: /tables/schema (bulk) nests the
        # columns under "columns", /tables/{t}/columns under "schema". Read both
        # rather than picking one and silently reporting zeros for the other.
        cols = (tbl or {}).get("columns") or (tbl or {}).get("schema") or {}
        if not isinstance(cols, dict):
            continue
        # detail=compact returns a dict per column; terse returns a bare string,
        # which cannot carry a description. Treat a non-dict as undescribed so a
        # wrong detail level reads as 0 rather than crashing.
        bare = [c for c, m in cols.items()
                if not isinstance(m, dict) or not m.get("semantic_description")]
        rows.append({"table": name,
                     "columns": len(cols),
                     "described": len(cols) - len(bare)})
        if bare:
            missing[name] = sorted(bare)

    total_cols = sum(r["columns"] for r in rows)
    total_desc = sum(r["described"] for r in rows)

    if fmt == "json" or raw:
        body = {"tables": rows,
                "totals": {"columns": total_cols, "described": total_desc}}
        if undescribed:
            body["undescribed"] = missing
        output(body, fmt="json", raw=raw)
        return

    rows.sort(key=lambda r: (-r["columns"], r["table"]))
    output(rows, fmt=fmt, columns=_COVERAGE_COLS)
    noun = "table" if len(rows) == 1 else "tables"
    click.echo(f"\n{total_desc} of {total_cols} columns described "
               f"across {len(rows)} {noun}.")

    if undescribed:
        for name in sorted(missing):
            click.echo(f"\n{name} — not yet described:")
            for col in missing[name]:
                click.echo(f"  {col}")



# ---------------------------------------------------------------------------
# Column reachability — "can any pipeline write this column?"
#
# Design: pantheon-datalake/docs/Torana_Shadow_Columns.md.
#
# ⚠️ reachable is NOT populated. `reachable` says a pipeline EXISTS that writes
# the column; it says nothing about whether data has landed. A reachable-but-
# empty column is an integration that has not synced yet (a sync state), while an
# unreachable column is a build defect. The two have different owners and
# different fixes, so the CLI never merges them into one word.
# ---------------------------------------------------------------------------

def _echo_reachability_summary(summary, *, transformer_excluded=None):
    """ONE summary renderer, shared by `reachable-columns` and `all-columns
    --reachable`, so the two surfaces can never drift into different numbers or
    different wording for the same fact.

    The load-bearing distinction it makes: an unreachable column is EITHER
      * connectable — a shipped integration writes it, this tenant has not
        enabled that integration. A config gap; connect it and the column works
        with no code change.
      * shadow — NO pipeline anywhere on the platform writes it. A real defect,
        identical for every tenant; needs an ETL written or the column deleted.
    Collapsing both into "no pipeline writes them" is what lets a reader conclude
    "impossible" about something merely not-bought (or the reverse). They have
    opposite owners and opposite fixes.
    """
    if not summary:
        return

    declared = summary.get("columns_declared") or 0
    reach = summary.get("columns_reachable") or 0
    connectable = summary.get("columns_filtered_connectable") or 0
    shadow = summary.get("columns_filtered_shadow") or 0
    pct = summary.get("pct_reachable")
    ints = summary.get("integrations_enabled") or []
    scope = summary.get("scope", "tenant")
    # ⛔ NEVER `declared - reach`. That silently absorbs the columns hidden by
    # SCHEMA_SERVICES_FILTER and reports them as "no pipeline anywhere writes these" —
    # a validation judgement about OUR testing, rendered as a platform build defect.
    # Measured: it printed 109 where the true figure is 5. Read the server's count,
    # which subtracts the filtered set; fall back only for an older backend.
    hidden = summary.get("columns_hidden_by_filter") or 0
    unreach = summary.get("columns_unreachable")
    if unreach is None:
        unreach = max(declared - reach - hidden, 0)

    W = 68

    def row(label, value, note=""):
        """One aligned line. Notes are kept SHORT so nothing ever wraps."""
        click.echo(f"  {label:<26}{value:>9}   {note}".rstrip())

    click.echo("")
    click.echo("═" * W)
    click.echo("  REACHABILITY SUMMARY")
    click.echo("═" * W)

    scope_note = ("all shipped integrations" if scope == "platform"
                  else "only enabled integrations")
    row("Scope", scope, scope_note)
    row("Integrations enabled", len(ints))
    if ints:
        click.echo(f"  {'':<26}{'':>9}   {', '.join(ints)}")

    click.echo("  " + "─" * (W - 2))
    t_decl = summary.get("sink_tables_declared")
    if t_decl is not None:
        row("Sink tables declared", t_decl)
        row("Sink tables returned", summary.get("sink_tables_returned") or 0)
        dropped = summary.get("sink_tables_dropped") or []
        row("Sink tables dropped", len(dropped),
            ", ".join(dropped) if dropped else "")
    if transformer_excluded:
        row("Transformer tables", transformer_excluded, "excluded (SQL-derived)")

    click.echo("  " + "─" * (W - 2))
    row("Columns declared", declared)
    row("Columns reachable", reach,
        f"{pct}% of declared" if pct is not None else "")
    row("Columns unreachable", unreach)
    row("  ├─ connectable", connectable, "an integration would fix these")
    row("  └─ shadow", shadow, "no pipeline anywhere writes these")
    non_sink = summary.get("columns_in_non_sink_tables") or 0
    if non_sink:
        names = ", ".join(summary.get("non_sink_tables") or [])
        # Sits under UNREACHABLE, not under the filter line — these columns are not
        # hidden by anything, they live in tables that make no reachability claim.
        row("  └─ non-sink tables", non_sink, f"no claim made: {names}")
    # ⭐ THE THIRD BUCKET, stated separately — never folded into "unreachable".
    # A hidden column HAS a writer; we have just never run that pipeline against a
    # real endpoint. Different owner, different fix, opposite conclusion.
    if hidden:
        row("Columns hidden by filter", hidden, "provider not yet validated")
    # ⭐ RECONCILE THE TWO SURFACES. `all-columns --reachable` folds `is_deleted` into
    # every table, while `reachable-columns` publishes system fields separately — so the
    # two report different totals for the same platform (measured: 362 vs 351, the gap
    # being exactly is_deleted x 11 tables). Both are right; saying nothing left an
    # author to discover an unexplained 11-column discrepancy between the schema they
    # browsed and the gate that refused their SQL.
    # ⭐ Columns in tables that carry NO reachability claim. Without this line the
    # remainder shows as "unreachable" with connectable=0 AND shadow=0 — a count
    # with no bucket explaining it, which reads as a bug in the report rather than
    # as "these were never candidates". Measured: 32 of the 37 remainder.
    lifecycle = summary.get("lifecycle_columns_included") or []
    if lifecycle:
        n_tables = summary.get("sink_tables_returned") or 0
        row("  incl. lifecycle", len(lifecycle) * n_tables,
            f"{', '.join(lifecycle)} x {n_tables} tables")
        click.echo(f"  {'':<26}{'':>9}   `reachable-columns` reports "
                   f"{reach - len(lifecycle) * n_tables} — it counts these separately")
    click.echo("═" * W)

    click.echo("  connectable  a shipped integration writes it — connect it and the "
               "SQL works")
    click.echo("               unchanged. A config gap, not a defect.")
    click.echo("  shadow       nothing on the platform writes it. Needs an ETL, or "
               "the column")
    click.echo("               deleted. Same for every tenant.")
    click.echo("  reachable    a pipeline EXISTS that writes it — NOT that data has "
               "landed.")
    click.echo("")


_REACHABLE_COLS = [
    ("table", "TABLE", 22),
    ("column", "COLUMN", 38),
    ("writers", "WRITTEN BY", 60),
]


def _fmt_writers(writers):
    """Render the writer provenance list as `kind:source` pairs."""
    out = []
    for w in writers or []:
        src = str(w.get("source", ""))
        # Trim the common prefix so the column stays readable in a table.
        src = src.replace("mappings/", "").replace("etl/operators/", "")
        out.append(f"{w.get('kind', '?')}:{src}")
    return ", ".join(out)


def _echo_integration_context(data):
    """Print WHICH integrations the reachability answer was computed against.

    Without this the number is uninterpretable: '243 reachable columns' means
    something completely different for a 2-integration tenant than a 6-integration
    one, and scope=tenant is defined entirely by that set.
    """
    info = data.get("integrations") or {}
    enabled = info.get("enabled") or []
    scope = data.get("scope", "tenant")
    scope_label = scope

    if scope == "platform":
        click.echo("\nScope: PLATFORM — every integration Torana ships, whether or not "
                   "this tenant has connected it.")
    else:
        click.echo(f"\nScope: TENANT — computed against {len(enabled)} enabled "
                   f"integration(s): {', '.join(enabled) if enabled else '(none)'}")

    detail = info.get("detail") or []
    if detail:
        click.echo("\nIntegrations on this tenant:")
        for row in sorted(detail, key=lambda r: str(r.get("provider") or "")):
            state = "enabled" if row.get("enabled") else "DISABLED"
            ds = row.get("enabled_data_sources") or []
            # last SUCCESSFUL sync — a failed run must not read as fresh data.
            last = row.get("last_successful_sync") or "never synced successfully"
            status = row.get("last_sync_status") or "-"
            click.echo(f"  {str(row.get('provider') or '?'):<14} {state:<9} "
                       f"{len(ds):>2} data source(s)   last good sync: {last} "
                       f"({status})")

    method = data.get("method") or {}
    if method.get("parse_errors"):
        click.echo(f"\n⚠️  {len(method['parse_errors'])} mapping(s) failed to parse — "
                   f"their columns are MISSING from this answer:")
        for err in method["parse_errors"][:5]:
            click.echo(f"     {err}")
    # Only warn about mappings that could actually affect THIS answer. The
    # platform-wide list is kept in the payload for anyone who wants it, but
    # surfacing an okta caveat to a tenant with no okta integration invites the
    # reader to discount a result that is not in fact qualified.
    nsd = method.get("not_statically_derivable") or []
    if nsd:
        where = ("any integration Torana ships" if scope_label == "platform"
                 else "your enabled integrations")
        click.echo(f"\n⚠️  {len(nsd)} mapping(s) among {where} write columns that "
                   f"cannot be derived statically (unpack of a runtime JSON blob), "
                   f"so those columns may be under-reported: {', '.join(nsd)}")
    click.echo("\n⚠️  'reachable' means a pipeline EXISTS that writes the column — NOT "
               "that data has landed.\n    reachable=false means no writer was found by "
               "this parse, not that no pipeline can ever write it.")


@datalake.command(name="reachable-columns")
@scope_options
@click.option("--table", "tables", multiple=True,
              help="Restrict to specific table name(s). Repeatable. Omit for all tables.")
@click.option("--explain", is_flag=True, default=False,
              help="Show WHO writes each column (kind + source file/registry key).")
@click.option("--include-unreachable", is_flag=True, default=False,
              help="ALSO list the declared columns nothing writes, each with a "
                   "verdict: 'shadow' (no pipeline anywhere writes it — needs an "
                   "ETL, or the column should not exist) or 'connectable' (a "
                   "shipped integration writes it; connect it and the SQL works "
                   "unchanged). Off by default so the payload stays the answer "
                   "to 'what can I build on'.")
@click.pass_context
def datalake_reachable_columns(ctx, scope, tables, explain, include_unreachable,
                               tenant_id):
    """List columns a pipeline can actually write.

    \b
    ⭐ SEE ALSO — the two halves of one picture, and they are NOT the same set:
      torana datalake schema table <t> --scope …   types + descriptions (DDL)
      torana datalake reachable-columns --scope …  WHO can write it (this)
      torana datalake schema table <t> --writers   BOTH, joined, one table
    ⚠️ `schema` also carries non-sink tables and system fields, so it declares
    MORE columns than this reports (measured: 489 vs 446). Neither is a subset
    view of the other.

    \b
    The datalake declares far more columns than any pipeline fills. This answers
    "can this column ever hold data for me?" so SQL is not authored against a
    column that will never light up.

    \b
    ⚠️ 'shadow' and 'connectable' are NOT the same thing and have different
    owners: connectable is a config gap (connect the integration); shadow means
    nothing on the platform writes it for ANY tenant. --include-unreachable
    labels each one so the two are never conflated.

    \b
    Examples:
      torana datalake reachable-columns
      torana datalake reachable-columns --explain
      torana datalake reachable-columns --scope platform
      torana datalake reachable-columns --scope platform --include-unreachable
      torana datalake reachable-columns --table vulnerabilities --explain
      torana datalake reachable-columns --format json
      torana datalake reachable-columns --tenant-id <uuid>   # SA: another tenant
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    scope, tenant_id = resolve_scope(scope, tenant_id)
    try:
        # ⭐ The SAME fetch `schema table --writers` uses — one caller of the
        # endpoint, so the two surfaces cannot disagree about who writes what.
        data = fetch_reachability(ctx, scope=scope, tenant_id=tenant_id,
                                  tables=tables, explain=explain,
                                  include_unreachable=include_unreachable)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt == "json" or raw:
        output(data, fmt="json", raw=raw)
        return

    rows = []
    for c in data.get("columns", []):
        row = {"table": c.get("table"), "column": c.get("column")}
        if include_unreachable:
            # ⛔ Rendered as its own column, never merged into a single
            # reachable/unreachable flag: 'shadow' and 'connectable' have
            # different owners and different fixes, and collapsing them is the
            # exact conflation this flag exists to prevent.
            row["verdict"] = c.get("verdict") or "reachable"
        if explain:
            row["writers"] = _fmt_writers(c.get("writers"))
        rows.append(row)

    # ⚠️ The verdict must reach the TEXT surface, not just JSON. A human running
    # this to decide "is this column worth building on" is the primary reader,
    # and a verdict only in --format json is a capability the default surface
    # does not have.
    cols = list(_REACHABLE_COLS) if explain else list(_REACHABLE_COLS[:2])
    if include_unreachable:
        cols.insert(2, ("verdict", "VERDICT", 13))
    output(rows, fmt=fmt, fields=fields, columns=cols)

    _echo_reachability_summary(data.get("summary"))
    _echo_integration_context(data)
    _echo_provider_filter(data)


def _echo_provider_filter(data: dict) -> None:
    """Report what SCHEMA_SERVICES_FILTER hid — never let a narrowed answer be silent.

    ⛔ A filtered count with nothing naming the filter is the worst of both worlds: the
    reader takes 351 for the platform's full capability and has no way to tell that 104
    columns were withheld by a judgement about OUR testing, not about the platform.
    """
    pf = data.get("provider_filter") or {}
    if not pf.get("active"):
        return

    excluded = pf.get("excluded_columns") or 0
    validated = pf.get("validated") or []
    click.echo(f"\n  ⚠️  SCHEMA_SERVICES_FILTER is ACTIVE — {excluded} column(s) hidden.")
    click.echo(f"      Showing only providers validated against a real endpoint: "
               f"{', '.join(validated)}")

    # ⛔ NO FLAG REVEALS THE HIDDEN COLUMNS, AND NONE MAY BE ADDED.
    #
    # The filter exists so that an author asking this platform for its schema sees
    # ONLY validated providers' columns. A flag that hands back the excluded set —
    # `--show-excluded` did exactly this, returning all 455 — defeats the feature at
    # the one surface it was built to protect: whoever holds the flag is the same
    # person who would then author SQL against an unvalidated pipeline.
    #
    # ⚠️ The count stays. Silence would be worse than either extreme: the reader
    # would take 351 for the platform's full capability with nothing signalling that
    # a judgement about OUR testing had narrowed it. Naming the count and the
    # validated set is the honest disclosure; naming the columns is the leak.
    #
    # To widen the schema, widen SCHEMA_SERVICES_FILTER — that is the ONLY control,
    # and it is deliberately the one that also makes the data real.
    click.echo("      To include another provider, validate it against a real "
               "endpoint and add it to SCHEMA_SERVICES_FILTER.")


# ─────────────────────────────────────────────────────────────────────────────
# Supply Graph — SUPPLY_GRAPH_SPEC.md § 3.10 (three-surface parity).
#
# ⛔ THESE ARE CONSUMERS OF THE ONE SERVER-SIDE RESOLVER (§ 3.4.0), never a
# second traversal. They parse SQL locally where they must and call
# GET /datalake/supply/{diagnosis,forward} for every verdict.
#
# ⚠️ Building the verbs first — with their own walk — would mean writing a
# second copy of the verdict table that then has to be deleted. Four copies of
# that table is the exact drift disease § 3.1 exists to prevent.
# ─────────────────────────────────────────────────────────────────────────────

#: ⛔ CUSTOMER-FACING TEXT. § 3.4.5 rule 1: never say "bridge", "declared
#: writer", "write seam", "reachability", or a BRIDGE-* id. Those are OUR
#: internal mechanics — say what the reader can DO.
#:
#: ⚠️ The templates are deliberately SHAPES, filled from live evidence, because
#: § 3.4.6 makes the category-vs-vendor choice depend on WHAT WE KNOW:
#:   guessing at an absent stack  -> category  ("connect a vulnerability scanner")
#:   reading their own config back -> vendor    ("Tenable is connected, but ...")
_VERDICT_HEADLINE = {
    "UNREACHABLE": "Torana does not collect this yet.",
    # ⛔ A DIFFERENT QUESTION from UNREACHABLE, and it must not borrow its
    # sentence. UNREACHABLE means "this exists and nothing writes it" — which
    # implies we might one day. This means the column IS NOT THERE, so there is
    # nothing to collect and nobody to ask.
    #
    # ⚠️ We deliberately do NOT say "removed". A caller cannot act on our schema
    # history, and "removed" leaks an internal decision onto a tenant surface;
    # from where they stand, removed and mistyped are the same fact.
    "NO_SUCH_COLUMN": "No such column on this table.",
    # ⛔ NOT "None recorded yet" — see the P15 #5 note at the NEEDS_CALLER
    # branch below: nothing tracks when a declared caller last ran (GAP-7).
    "NEEDS_CALLER": "Filled when someone records it.",
    # ⛔ THE P15 CHAIN POSITIONS (supply.py § 3.18). ⚠️ These were ABSENT here
    # while the server has emitted them since P15, so any column the chain walk
    # answered rendered as the bare token `UPSTREAM_UNDECLARED` with no owner
    # tag — an internal name shown to a tenant, which is exactly what rule 1
    # forbids. It stayed invisible only because the walk never fired on the
    # tenants anyone looked at; the moment it did (2026-08-20, epss_score) it
    # printed the verdict name twice and said nothing.
    #
    # ⛔ Wording is COPIED VERBATIM from `VERDICTS` in supply.py. This map is a
    # second copy of the server's and the drift above is what that costs — if
    # the diagnosis payload ever carries `message`/`owner`, delete both maps
    # and render those instead rather than reconciling them by hand again.
    "PRODUCER_NEVER_RAN": "The job that fills this has never run.",
    "PRODUCER_STALE": "The job that fills this is overdue.",
    "APPLY_PENDING": "New values are ready but have not been written yet.",
    "UPSTREAM_UNDECLARED": "Nothing upstream records this for your account yet.",
    "DOCUMENT_ONLY": "Populated by uploading a scan or inventory document.",
    "CATEGORY_MISSING": "To populate this, connect a tool of the right kind.",
    "PEER_GAP": "Your tool does not report this; other tools of the same kind do.",
    "SOURCE_DISABLED": "Connected, but the collector that fills this is off.",
    "SYNC_FAILING": "The sync that fills this is failing.",
    "SUPPLIED": "Supplied — data should be arriving.",
    "UNRESOLVED": "We could not trace this one. (Our gap, not yours.)",
    "LINEAGE_AMBIGUOUS": "We could not trace this one. (Our gap, not yours.)",
}


def _describe(verdict: str, evidence: dict) -> str:
    """Turn ONE verdict + its evidence into a line a human can act on.

    ⛔ § 3.4.6 — the category-vs-vendor choice depends on what we KNOW:
      * `CATEGORY_MISSING` → CATEGORY only. Naming a vendor guesses a stack the
        customer may not have ("connect Tenable" is wrong if they run Rapid7).
      * `PEER_GAP` → BOTH. The category frames it, the example makes it
        actionable — "your scanner does not report this; scanners such as X do".
      * connected-but-broken → VENDOR BY NAME. We are reading their own config
        back to them; there is no guessing involved, and refusing to name it
        would be evasive.
    """
    ev = evidence or {}
    if verdict in ("SOURCE_DISABLED", "SYNC_FAILING", "SUPPLIED"):
        via = ev.get("via") or []
        if via:
            v = via[0]
            vendor = v.get("vendor") or v.get("integration")
            collector = v.get("data_source")
            if verdict == "SOURCE_DISABLED":
                return f"{vendor} is connected, but its {collector} collector is off."
            if verdict == "SYNC_FAILING":
                return f"Your {vendor} sync is failing ({v.get('last_sync_status')})."
            return f"Supplied by {vendor} ({collector})."
    if verdict == "CATEGORY_MISSING":
        cats = ev.get("categories") or []
        if cats:
            return "To populate this, connect " + " or ".join(
                _humanise_category(c) for c in cats) + "."
    if verdict == "PEER_GAP":
        # ⚠️ BARE noun here, NOT `_humanise_category` — "Your <category>" already
        # supplies the determiner, and adding the article produced "Your a
        # security scanner does not report this". The two call sites need
        # different grammar: CATEGORY_MISSING says "connect a security scanner"
        # (article), PEER_GAP says "your security scanner" (no article).
        cats = [str(c).replace("_", " ").strip() for c in (ev.get("categories") or [])]
        peers = ev.get("peer_examples") or []
        # ⚠️ NAME the tool they actually run. "Your security scanner does not
        # report this" left a reader unable to tell WHICH scanner — so they could
        # neither confirm the claim nor act on it. ⛔ This is not the vendor
        # GUESSING § 3.4.6 forbids: these come from their own connected
        # integrations, which that section explicitly permits naming.
        yours = ev.get("connected_peers") or []
        kind = cats[0] if cats else "tool"
        if yours:
            owned = ", ".join(yours[:3])
            more = f" (+{len(yours) - 3} more)" if len(yours) > 3 else ""
            head = f"Your {kind}{'s' if len(yours) > 1 else ''} ({owned}{more}) do not report this" \
                if len(yours) > 1 else f"Your {kind} ({owned}) does not report this"
        else:
            head = f"Your {kind} does not report this"
        # ⚠️ Cap the examples and never imply they are the only options — the
        # writer list is what Torana supports today, not the market.
        if peers:
            return f"{head}; tools such as {', '.join(peers[:3])} do."
        return head + "."
    if verdict == "NEEDS_CALLER":
        callers = ev.get("callers") or []
        name = (callers[0] or {}).get("name") if callers else None
        # ⛔ § 3.4.5 rule 3: state ONLY what the trigger field records. An
        # invented "this fills after each scan" that turns out false costs more
        # trust than the empty panel did.
        when = ""
        triggers = ev.get("triggers") or []
        if "scheduled" in triggers:
            when = " This refreshes automatically."
        elif "human" in triggers:
            when = " Someone on your team records this."
        # ⛔ P15 #5 (§ 3.18.1b) — DO NOT SAY "None recorded yet".
        #
        # ⚠️ That asserts nothing has EVER been recorded, which is exactly what
        # the platform cannot tell us: nothing tracks when a `declared` caller
        # last ran (GAP-7). The verdict means the column is EMPTY FOR THIS
        # QUERY's scope, not that the caller has never run — and on a column
        # some rows do carry, the old sentence was simply false.
        #
        # ⛔ The row's update time is NOT a substitute: it is a sync watermark
        # overwritten by the next sync, so it would give a confident wrong
        # answer.
        last_run = ev.get("last_run") or {}
        if name:
            unknown = "" if last_run.get("known") else (
                " We do not track when it last ran.")
            return f"Filled when {name} runs.{when}{unknown}"
    return _VERDICT_HEADLINE.get(verdict, verdict)


def _humanise_category(cat: str) -> str:
    """`security_scanner` → `a security scanner`. ⛔ Never render a raw slug."""
    words = str(cat).replace("_", " ").strip()
    article = "an" if words[:1].lower() in "aeiou" else "a"
    return f"{article} {words}"


@datalake.group(name="supply", invoke_without_command=True)
@click.option("--column", "columns", multiple=True,
              help="table.column to diagnose — 'why is this empty for this tenant?' "
                   "Repeatable. (Alias for `supply column`.)")
@click.option("--verbose", is_flag=True, default=False,
              help="Also show what the diagnosis was resolved against (column-set size, connected integrations).")
@click.option("--integration", default="",
              help="Integration name — blast radius: what breaks if it disconnects. "
                   "(Alias for `supply integration`.)")
@click.pass_context
def datalake_supply(ctx, columns, integration, verbose):
    """Why is a column empty, what breaks if an integration goes, and what can I ask?

    ⛔ Bare `supply` prints THIS HELP and exits 0. It used to print only an
    error — telling the reader what they did wrong and not how to find a valid
    value, which is the "accurate but unactionable" failure the Supply Graph
    exists to remove, turned on its own CLI.

    \b
    Start here if you don't know a name:
      torana datalake supply integrations      what can I ask about?
      torana datalake supply columns           what columns exist, and are they lit?
      torana datalake supply verdicts          what does each answer MEAN, and who fixes it?

    \b
    Then ask:
      torana datalake supply column vulnerabilities.cvss4_base_score
      torana datalake supply integration tenable
      torana datalake supply questions         which questions can't be answered, and why?
      torana datalake supply graph             the whole graph, for a UI or a diff
    """
    ctx.ensure_object(dict)
    # ⛔ BACKWARDS COMPATIBILITY (§ 2, review c20). `--column` / `--integration`
    # ship in P7 and appear in the spec's own examples. ⚠️ Turning a
    # positional-less command into a Click group is EXACTLY where those aliases
    # silently stop working, so they are handled here explicitly and there is a
    # regression test for both.
    if ctx.invoked_subcommand is not None:
        if columns or integration:
            click.echo("ERROR: --column/--integration are aliases for the "
                       "`column`/`integration` subcommands; do not combine them "
                       "with a subcommand.", err=True)
            raise SystemExit(2)
        return

    if not columns and not integration:
        # ⛔ D1/D2 — help, EXIT 0. The listing is the entry point, so a reader
        # with no name gets the map instead of a rejection.
        click.echo(ctx.get_help())
        return

    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    if bool(columns) and bool(integration):
        click.echo(
            "ERROR: pass EITHER --column (backward: why is this empty) OR "
            "--integration (forward: what breaks if it goes), not both.", err=True)
        raise SystemExit(2)

    if integration:
        _supply_integration_core(ctx, integration, fmt)
    else:
        _supply_column_core(ctx, columns, fmt, verbose)


# ─────────────────────────────────────────────────────────────────────────────
# ⛔ ONE core per direction, called by BOTH the subcommand and the P7 alias.
#
# ⚠️ Two call sites executing the same request is exactly how the alias and the
# subcommand drift into answering differently — the failure c20 warns about, one
# level down from the Click-group refactor itself.
# ─────────────────────────────────────────────────────────────────────────────


def _supply_integration_core(ctx, integration: str, fmt: str,
                             questions: bool = False) -> None:
    """Forward walk — what breaks if this goes, or what connecting it is worth."""
    client = _client(ctx)
    params = {"integration": integration}
    if questions:
        params["questions"] = "true"
    try:
        data = client.get("datalake/supply/forward", params=params)
    except APIError as e:
        # ⛔ § 4.5 — an unknown integration must ERROR and NAME the valid set.
        # The generic handler prints the detail dict raw, which renders the
        # 28-name list as a Python repr; this renders it as an answer.
        if _render_unknown_integration(e, fmt):
            raise SystemExit(e.exit_code)
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
        return
    _render_forward(data)


def _supply_column_core(ctx, columns, fmt: str, verbose: bool,
                        fill: bool = False, values: bool = False,
                        shape: bool = False) -> None:
    """Backward walk — why is this column empty for this tenant?

    ⛔ The `values ⊃ shape ⊃ ...` implication is resolved SERVER-SIDE, not
    here. Duplicating it locally would mean a native agent calling the API
    directly got a different payload from a skill running the same query.
    """
    client = _client(ctx)
    params = {"columns": ",".join(columns)}
    if fill:
        params["fill"] = "true"
    if values:
        params["values"] = "true"
    if shape:
        params["shape"] = "true"
    try:
        data = client.get("datalake/supply/diagnosis", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
        return
    _render_diagnosis(data, verbose=verbose)


@datalake_supply.command(name="column")
@click.argument("reference", nargs=-1, required=True, metavar="TABLE.COLUMN...")
@click.option("--verbose", is_flag=True, default=False,
              help="Also show what the diagnosis was resolved against.")
@click.option("--fill", is_flag=True, default=False,
              help="Also show how many rows actually carry a value. ⛔ A "
                   "SECOND AXIS — it never changes the verdict.")
@click.option("--shape", "shape_flag", is_flag=True, default=False,
              help="Classify the column — enum / constant / high cardinality "
                   "— from Postgres statistics. FREE: no scan of the data. "
                   "⚠️ Describes ALL rows including soft-deleted ones, so it "
                   "classifies but is never the exact number.")
@click.option("--values", "values_flag", is_flag=True, default=False,
              help="Also show WHAT values it holds, with the distribution. "
                   "⛔ IMPLIES --shape and --fill. A THIRD AXIS: `--fill` "
                   "cannot tell a sparse column from one that has only ever "
                   "held a single value.")
@click.pass_context
def datalake_supply_column(ctx, reference, verbose, fill, values_flag,
                           shape_flag):
    """Why is this column empty for this tenant?

    \b
    Three depths, cheapest first — --values implies the other two:
      --shape    what KIND of column is this?   (free, no scan)
      --fill     how many rows carry a value?   (one count per column)
      --values   what values, in what mix?      (one scan per listable column)

    \b
    Examples:
      torana datalake supply column vulnerabilities.cvss4_base_score
      torana datalake supply column vulnerabilities.severity --shape
      torana datalake supply column vulnerabilities.severity --values
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    _supply_column_core(ctx, list(reference), fmt, verbose, fill=fill,
                        values=values_flag, shape=shape_flag)


@datalake_supply.command(name="integration")
@click.argument("name", metavar="NAME")
@click.option("--questions", is_flag=True, default=False,
              help="X2 — which of the questions you care about would connecting "
                   "this unblock?")
@click.pass_context
def datalake_supply_integration(ctx, name, questions):
    """What breaks if this integration goes — or what would connecting it light?

    ⛔ An unknown name ERRORS and names the valid set; it never answers "0".

    \b
    Examples:
      torana datalake supply integration tenable
      torana datalake supply integration tenable --questions
      torana datalake supply integration gcp
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    _supply_integration_core(ctx, name, fmt, questions=questions)


@datalake_supply.command(name="export")
@scope_options
@click.option("--table", "tables", multiple=True,
              help="Restrict to specific table name(s). Repeatable. Omit for all 11.")
# ⚠️ NO `-o` short flag: the ROOT group already binds -o to --format, so
# adding it here shadowed a global and made `-o file.xlsx` fail with a
# confusing "not one of text, json, yaml, table".
@click.option("--output", "output_path", default=None,
              help="Where to write the .xlsx. Defaults to the filename the server "
                   "chose, in the current directory.")
@click.option("--include-unreachable/--no-include-unreachable", default=True,
              help="Include declared columns NOTHING writes. ON by default: an "
                   "export is a schema inventory, and a column nothing can write "
                   "is exactly what an auditor opens the file to find.")
@click.pass_context
def datalake_supply_export(ctx, scope, tables, output_path, include_unreachable,
                           tenant_id):
    """Download the whole Data Supply picture as an .xlsx workbook.

    \b
    TWO SHEETS, AND THEY HAVE DIFFERENT ROW COUNTS BY DESIGN:
      Columns   one row per datalake column        (~446)
      Writers   one row per column x writer        (~1,636)

    \b
    They join on Table+Column. Writers fan out hard — `assets.torana_entity_id`
    is written by 38 mappings across 19 integrations — so a single flattened
    sheet would inflate every count ~4x, worst for exactly the columns with the
    most writers. Keeping the grains apart means each sheet's row count means
    one thing.

    \b
    ⚠️ The Columns sheet's `Writer count` reconciles the two: it equals that
    column's row count on the Writers sheet.

    \b
    Examples:
      torana datalake supply export --scope platform
      torana datalake supply export --scope platform --output /tmp/supply.xlsx
      torana datalake supply export --table vulnerabilities --table assets
    """
    scope, tenant_id = resolve_scope(scope, tenant_id)
    params = {"scope": scope, "include_unreachable": str(include_unreachable).lower()}
    if tables:
        params["table"] = list(tables)
    if tenant_id:
        params["tenant_id"] = tenant_id

    _write_supply_workbook(ctx, params, output_path)


def _write_supply_workbook(ctx, params: dict, output_path: str = "") -> None:
    """Fetch the two-sheet .xlsx and write it to disk.

    ⭐ Shared by `supply export` and `supply columns --export`, so the two can
    never drift into producing different workbooks for the same question.
    """
    client = _client(ctx)
    try:
        # ⚠️ A generous timeout: the server joins the writer map against the
        # declared schema for every column, and a cold writer-map cache makes
        # the first call materially slower than the rest.
        content, server_name = client.get_bytes(
            "datalake/supply/export", params=params, timeout=180.0,
        )
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    path = output_path or server_name or "torana-data-supply.xlsx"
    try:
        with open(path, "wb") as fh:
            fh.write(content)
    except OSError as e:
        click.echo(f"Could not write {path}: {e}", err=True)
        raise SystemExit(1)

    click.echo(f"\n  Wrote {path} ({len(content):,} bytes)")
    click.echo("    Sheet 'Columns' — one row per column")
    click.echo("    Sheet 'Writers' — one row per column x writer "
               "(they join on Table+Column)")


@datalake_supply.command(name="graph")
@click.option("--verdict", multiple=True, help="Filter by verdict (repeatable).")
@click.option("--table", multiple=True, help="Filter by table (repeatable).")
@click.option("--integration", multiple=True,
              help="V3 — the subgraph around one integration (repeatable).")
@click.option("--dark", is_flag=True, default=False, help="V2 — the dark half only.")
@click.option("--lit", "lit_flag", is_flag=True, default=False, help="Lit half only.")
@click.option("--edge-kind", multiple=True,
              help="Which edges to include: writes | belongs_to.")
@click.pass_context
def datalake_supply_graph(ctx, verdict, table, integration, dark, lit_flag,
                          edge_kind):
    """The whole graph — nodes + edges in one payload. (V1-V3)

    ⛔ Covers the RESOLVABLE graph: columns something can write, plus the tools
    that write them. Columns nothing writes are a different question with a
    different owner — `supply columns --unreachable`.

    ⚠️ Use --format json for the payload; text mode prints a summary, because a
    thousand edges is not something to read in a terminal.

    \b
    Examples:
      torana datalake supply graph --format json > graph.json      V1
      torana datalake supply graph --dark --format json            V2
      torana datalake supply graph --integration tenable           V3
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    if dark and lit_flag:
        click.echo("ERROR: --dark and --lit are opposites; pass at most one.",
                   err=True)
        raise SystemExit(2)

    params = []
    for v in verdict:
        params.append(("verdict", v))
    for t in table:
        params.append(("table", t))
    for i in integration:
        params.append(("integration", i))
    for k in edge_kind:
        params.append(("edge_kind", k))
    if dark:
        params.append(("lit", "false"))
    if lit_flag:
        params.append(("lit", "true"))

    client = _client(ctx)
    try:
        data = client.get("datalake/supply/graph", params=params)
    except APIError as e:
        if _render_unknown_integration(e, fmt) or _render_invalid_choice(e, fmt):
            raise SystemExit(e.exit_code)
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
        return

    c = data.get("counts") or {}
    click.echo(f"\n  {c.get('nodes', 0)} nodes, {c.get('edges', 0)} edges "
               f"({', '.join(data.get('edge_kinds') or [])})")
    click.echo(f"    {c.get('columns', 0)} columns "
               f"({c.get('lit', 0)} lit), "
               f"{c.get('integrations', 0)} integrations")
    rc = data.get("resolved_context") or {}
    # ⛔ § 4.1 — state whose graph this is. The same column resolves differently
    # per tenant, so an unattributed dump is wrong for everyone.
    click.echo(f"\n  tenant: {data.get('tenant')}")
    # ⚠️ § 4.3 — the hash is over the RESOLVED INPUT, so two dumps can be
    # compared: same hash and a different rendering is OUR bug; different hash
    # means the tenant's world moved and the diff is real.
    click.echo(f"  input:  {str(data.get('input_hash'))[:16]}…")
    if rc.get("unreachable_column_count"):
        click.echo(f"\n  ({rc['unreachable_column_count']} declared columns have no "
                   f"writer at all and are NOT in this graph —\n   see "
                   f"`supply columns --unreachable`.)")
    click.echo("\n  Use --format json for the nodes and edges themselves.\n")


@datalake_supply.command(name="questions")
@click.option("--id", "question_id", default="",
              help="X1 — why can't THIS question be answered? e.g. EM-001")
@click.option("--verdict", multiple=True,
              help="X3 — blocked on a human (NEEDS_CALLER) vs a purchase.")
@click.option("--use-case", multiple=True, help="Filter by use case.")
@click.option("--domain", multiple=True,
              help="Filter by question domain, e.g. exposure_management. "
                   "Omit for ALL domains — per-domain totals are shown either way.")
@click.option("--integration", "sole_integration", default="",
              help="Only questions this integration is a SOLE writer for — i.e. "
                   "nothing else YOU HAVE CONNECTED writes them. NOT 'touched "
                   "by', which barely discriminates for some tools.")
@click.option("--blocking", is_flag=True, default=False,
              help="X4 — the work queue: which columns block the MOST questions.")
@click.option("--group-by", default="",
              help="X6 — use_case | persona | decision_level | verdict.")
@click.option("--blocked", "blocked_only", is_flag=True, default=False,
              help="Only questions that cannot run as written.")
@click.option("--limit", default=25, show_default=True, help="Rows to print.")
@click.pass_context
def datalake_supply_questions(ctx, question_id, verdict, use_case, domain,
                              sole_integration, blocking, group_by,
                              blocked_only, limit):
    """Why can't Torana answer MY question? (X1-X6)

    ⛔ The question a user actually arrives with. Nobody opens this to inspect a
    graph — they open it because a panel they care about came back empty.

    \b
    Examples:
      torana datalake supply questions --blocked              which can't run
      torana datalake supply questions --id EM-001            X1: why not this one
      torana datalake supply questions --verdict NEEDS_CALLER X3: waiting on a human
      torana datalake supply questions --blocking             X4: the work queue
      torana datalake supply questions --group-by use_case    X6: worst-served outcome
      torana datalake supply questions --domain exposure_management   one domain
      torana datalake supply questions --integration gitlab   what breaks without it
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    params = []
    if question_id:
        params.append(("id", question_id))
    for v in verdict:
        params.append(("verdict", v))
    for u in use_case:
        params.append(("use_case", u))
    for d in domain:
        params.append(("domain", d))
    if blocking:
        params.append(("blocking", "true"))
    if group_by:
        params.append(("group_by", group_by))
    if blocked_only:
        params.append(("blocked_only", "true"))

    client = _client(ctx)
    try:
        data = client.get("datalake/supply/questions", params=params)
    except APIError as e:
        if _render_corpus_unavailable(e, fmt) or _render_invalid_choice(e, fmt):
            raise SystemExit(e.exit_code)
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if sole_integration:
        data = _filter_by_sole_writer(data, sole_integration)

    if fmt != "text":
        output(data, fmt=fmt)
        return

    if blocking:
        _render_blocking_queue(data, limit=limit)
    elif group_by:
        _render_question_groups(data)
    else:
        _render_questions(data, limit=limit)


def _filter_by_sole_writer(data: dict, integration: str) -> dict:
    """Keep only questions `integration` is a SOLE writer for.

    ⛔ SOLE-contribution, never "touched by". Measured over the parseable
    answerable questions: `gcp` and `gitlab` are each TOUCHED BY 47 of 47,
    because every question reads severity / torana_entity_id / is_deleted.
    On the sole measure they separate — gitlab is **6**. ⚠️ If a filter on an
    integration returns nearly everything, the wrong measure is wired.

    ⚠️ Questions with no committed provenance record carry
    `attribution_available: false`. They are reported SEPARATELY rather than
    silently dropped — "this tool is not a sole writer here" and "we never
    measured this question" are opposite statements, and collapsing them into
    one empty list is the confident-wrong-answer shape (§ 1.7).
    """
    items = data.get("items") or []
    want = integration.strip().lower()
    matched, unmeasured = [], 0
    for q in items:
        if not q.get("attribution_available"):
            unmeasured += 1
            continue
        if want in [w.lower() for w in (q.get("sole_writers") or [])]:
            matched.append(q)
    out = dict(data)
    out["items"] = matched
    out["total"] = len(matched)
    out["sole_writer_filter"] = integration
    out["unmeasured_questions"] = unmeasured
    return out


def _render_corpus_unavailable(e: APIError, fmt: str = "text") -> bool:
    """⛔ § 1.7 — say the platform does not track this; never answer empty."""
    detail = e.detail if isinstance(e.detail, dict) else None
    if not detail:
        return False

    # ⛔ An unknown question id ERRORS and shows the id SHAPE — the thing the
    # reader actually got wrong (ids are `EM-001`, not `Q-001`).
    if e.status_code == 404 and detail.get("question_count"):
        if fmt != "text":
            output(detail, fmt=fmt)
            return True
        click.echo(f"\nERROR: {detail.get('error')}", err=True)
        click.echo(f"\n  {detail['question_count']} questions are tracked, e.g. "
                   f"{', '.join(detail.get('example_ids') or [])}", err=True)
        click.echo("  Run `supply questions --blocked` to see them.\n", err=True)
        return True

    if e.status_code != 503 or not detail.get("unavailable"):
        return False
    if fmt != "text":
        output(detail, fmt=fmt)
        return True
    click.echo(f"\nERROR: {detail.get('error')}", err=True)
    click.echo("  (This is a platform gap, not an answer — no questions were "
               "checked.)\n", err=True)
    return True


def _render_questions(data: dict, limit: int = 25) -> None:
    items = data.get("items") or []
    sole = data.get("sole_writer_filter")
    if sole:
        # ⛔ SOLE writer — "would break without this", never "touched by".
        click.echo(f"\n  {len(items)} question(s) would break without "
                   f"'{sole}'.")
        unmeasured = data.get("unmeasured_questions") or 0
        if unmeasured:
            # ⚠️ Never let "not measured" read as "no match".
            click.echo(f"  ⚠️  {unmeasured} question(s) carry no attribution "
                       f"record, so they were not considered either way.")
    else:
        click.echo(f"\n  {data.get('blocked_count', 0)} of "
                   f"{data.get('total_questions', 0)} questions cannot run as written.")

    # ⛔ PER-DOMAIN, always — domains are not fungible, so a blended total
    # describes no one's estate. "can answer", not "answers": the supply chain
    # being intact is not a claim that anyone ran the query.
    for d in (data.get("by_domain") or []):
        line = (f"  {d['domain'].replace('_', ' ')}: can answer "
                f"{d['can_answer']} of {d['mapped']} mapped")
        if d.get("unmapped"):
            # ⚠️ The denominator a reader assumes is the CATALOGUE, not the
            # mapped subset. Say both or the line claims coverage it lacks.
            line += f" · {d['unmapped']} not yet mapped"
        click.echo(line)

    bug = data.get("demand_side_bug_count") or 0
    if bug:
        # ⛔ X5 — a DIFFERENT owner. Every blocker is supplied, so the data is
        # arriving and the query still returns nothing: our bug, not a missing
        # tool. Reporting these as supply gaps sends the customer shopping.
        click.echo(f"  ⚠️  {bug} of them are blocked only by columns that ARE "
                   f"supplied — those are our bug, not a tool you are missing.")
    click.echo()
    # ⚠️ A question can carry SEVERAL SQL candidates (EM-001 has Q-001 and
    # Q-001b), each with its own verdict. Showing only the question id makes
    # that look like the same question listed twice with different answers — a
    # bug in the tool, to a reader. Name the candidate when there is more than
    # one.
    seen_q = {}
    for q in items:
        seen_q[q["question_id"]] = seen_q.get(q["question_id"], 0) + 1

    for q in items[:limit]:
        # ⚠️ No supply verdict means NO BLOCKING COLUMNS — the question is not
        # waiting on supply at all. Show the corpus verdict instead of a dash,
        # which reads as "unknown" when the truth is "nothing is blocking it".
        v = q.get("verdict") or q.get("corpus_verdict") or "—"
        label = q["question_id"]
        if seen_q.get(q["question_id"], 0) > 1 and q.get("query_id"):
            label = f"{q['question_id']} ({q['query_id']})"
        click.echo(f"  {label}  [{v}]  {q.get('use_case', '')}")
        text = q.get("question") or ""
        if text:
            for line in textwrap.wrap(text, width=92, initial_indent="      ",
                                      subsequent_indent="      "):
                click.echo(line)
        cols = [c["column"] for c in (q.get("columns") or [])
                if c["verdict"] != "SUPPLIED"]
        if cols:
            shown = ", ".join(cols[:3])
            more = f" (+{len(cols) - 3} more)" if len(cols) > 3 else ""
            click.echo(f"      waiting on: {shown}{more}")
        click.echo()
    if len(items) > limit:
        click.echo(f"    … and {len(items) - limit} more "
                   f"(--limit N, or --format json for all)\n")


def _render_blocking_queue(data: dict, limit: int = 25) -> None:
    """X4 — the ETL work queue, ranked by QUESTIONS BLOCKED.

    ⚠️ Ranked by question-hits rather than column count: a column blocking 18
    questions is not equal to one blocking a single question, and the work queue
    only makes sense in units of user pain.
    """
    items = data.get("items") or []
    click.echo(f"\n  {len(items)} columns block at least one question, "
               f"of {data.get('total_questions', 0)} questions checked.\n")
    width = max((len(c["column"]) for c in items[:limit]), default=10)
    click.echo(f"    {'column'.ljust(width)}  {'questions':>9}  verdict")
    for c in items[:limit]:
        click.echo(f"    {c['column'].ljust(width)}  {c['questions']:>9}  "
                   f"{c['verdict']}")
    if len(items) > limit:
        click.echo(f"\n    … and {len(items) - limit} more")
    click.echo()


def _render_question_groups(data: dict) -> None:
    items = data.get("items") or []
    key = data.get("group_by")
    click.echo(f"\n  Questions by {key} "
               f"({data.get('total_questions', 0)} checked):\n")
    click.echo(f"    {str(key):<24} {'blocked':>8} {'of':>5}")
    for g in items:
        click.echo(f"    {str(g['group']):<24} {g['blocked']:>8} {g['total']:>5}")
    click.echo()


@datalake_supply.command(name="category")
@click.argument("name", metavar="CATEGORY")
@click.pass_context
def datalake_supply_category(ctx, name):
    """What do I get from a KIND of tool, before I pick a vendor? (B7)

    ⛔ Answered from the category contract, never by unioning what its members
    happen to write — that overstates the realistic outcome ~2x, because it is
    true only if you connect every one of them.

    ⚠️ A "required" field is what the contract DEMANDS, not a promise every tool
    delivers, so the known exceptions are named. Saying "you will certainly get
    cve_id" is wrong for a reader who then connects GitLab.

    \b
    Examples:
      torana datalake supply category security_scanner
      torana datalake supply category vcs
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.get("datalake/supply/category", params={"category": name})
    except APIError as e:
        if _render_unknown_category(e, fmt):
            raise SystemExit(e.exit_code)
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
        return
    _render_category(data)


def _render_unknown_category(e: APIError, fmt: str = "text") -> bool:
    detail = e.detail if isinstance(e.detail, dict) else None
    if not detail or e.status_code not in (404, 503):
        return False
    if fmt != "text":
        output(detail, fmt=fmt)
        return True
    click.echo(f"\nERROR: {detail.get('error') or e}", err=True)
    if detail.get("valid_categories"):
        click.echo(f"\n  Valid categories: "
                   f"{', '.join(detail['valid_categories'])}", err=True)
    click.echo(err=True)
    return True


def _render_category(data: dict) -> None:
    """⛔ The B7 sentence — vendor-INDEPENDENT, which is what a buyer needs
    before they have chosen a tool.
    """
    cat = str(data.get("category") or "").replace("_", " ")
    if not data.get("has_contract"):
        # ⛔ Say what is true; NEVER fall back to a union of members (§ 3.16.5),
        # which would reintroduce the overstatement precisely where there is no
        # contract to correct it.
        click.echo("\n  We have no contract for this kind of tool yet.")
        why = data.get("why") or ""
        # ⚠️ Only add the reason when it says something the headline does not —
        # a degraded lookup is a DIFFERENT state from "genuinely no contract",
        # and the reader must be able to tell them apart.
        if why and "no contract" not in why:
            click.echo(f"  ({why})")
        gain = data.get("member_gain") or {}
        if gain:
            # ⚠️ The TOOL-level answer needs no contract and still works.
            click.echo("\n  What we CAN tell you — what each specific tool would light:")
            for m, n in sorted(gain.items(), key=lambda kv: -kv[1]):
                click.echo(f"    {m:<16} {n:>4}")
        click.echo()
        return

    req = data.get("required") or []
    opt = data.get("optional") or []
    click.echo(f"\n  Connect any {cat} and you will get "
               f"{len(req)} field(s) it is required to provide:\n")
    for f in req:
        if f.get("exceptions"):
            # ⛔ NAME THE EXCEPTIONS. "You will certainly get cve_id" is false
            # for a reader who then connects one of these.
            click.echo(f"    {f['column']:<32} every one except "
                       f"{', '.join(f['exceptions'])}")
        else:
            click.echo(f"    {f['column']:<32} every one")

    if opt:
        click.echo(f"\n  Depending which you pick, you may also get up to "
                   f"{len(opt)} more, e.g.:")
        for f in opt[:5]:
            who = ", ".join(f.get("written_by") or []) or "—"
            click.echo(f"    {f['column']:<32} {who}")
        if len(opt) > 5:
            click.echo(f"    … and {len(opt) - 5} more (--format json for all)")

    gain = data.get("member_gain") or {}
    if gain:
        # ⚠️ B8-adjacent, and honest: this is per-tool gain against what the
        # tenant already has, not a ranking of the market.
        click.echo("\n  For YOUR estate, what each would light today:")
        for m, n in sorted(gain.items(), key=lambda kv: -kv[1])[:8]:
            click.echo(f"    {m:<16} {n:>4}")
    click.echo()


@datalake_supply.command(name="verdicts")
@click.pass_context
def datalake_supply_verdicts(ctx):
    """What does each answer MEAN, and who owns the fix? (D4)

    ⛔ Served from the resolver's own verdict table, never a copy — adding a
    verdict stays a one-place edit.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.get("datalake/supply/verdicts")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
        return

    items = data.get("items") or []
    click.echo("\n  Every answer the Supply Graph can give, worst first.")
    click.echo("  'Owner' is the question a reader actually has: is this mine to fix?\n")
    for v in items:
        rank = v.get("rank")
        # ⚠️ SUPPLIED is ranked but renders NOTHING to a customer (§ 3.4.4);
        # the two rank-less verdicts mean "we could not trace this" — ours.
        badge = f"#{rank}" if rank is not None else " —"
        click.echo(f"  {badge}  {v['verdict']:<18} [{v.get('owner', '')}]")
        click.echo(f"        {v.get('message', '')}")
        if v.get("what_to_do"):
            click.echo(f"        → {v['what_to_do']}")
        click.echo()


@datalake_supply.command(name="artifact")
@click.argument("kind", type=click.Choice(["rule", "transformer", "widget"]))
@click.argument("artifact_id")
@click.pass_context
def datalake_supply_artifact(ctx, kind, artifact_id):
    """Will this deployed rule/transformer/widget ever return anything?

    ⛔ Diagnoses what is DEPLOYED, by id — the query is read server-side, so the
    answer is about what is running rather than about a copy you pasted in.

    ⚠️ THE DISTINCTION THIS EXISTS FOR — both look identical from outside:

      permanently unanswerable   something it depends on is not supplied. A
                                 configuration defect; it will never fire until
                                 someone changes something.
      quiet estate               everything is supplied; nothing matches today.
                                 Healthy. Nobody needs to do anything.

    \b
    Examples:
      torana datalake supply artifact rule 9abb96c2-751b-4c0b-aa86-a66c06c723a3
      torana datalake supply artifact widget <id>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.get(f"datalake/supply/artifact/{kind}/{artifact_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
        return

    answer = data.get("answerable")
    # ⚠️ A WORD, not a colour — this has to read the same in a pipe, a CI log
    # and a terminal that strips styling.
    headline = {
        "permanently_unanswerable": "WILL NOT FIRE",
        "quiet_estate": "HEALTHY — nothing matches today",
        "undetermined": "COULD NOT TELL",
    }.get(answer, str(answer))

    click.echo(f"\n  {data.get('artifact_name')}  [{data.get('artifact_label')}]")
    click.echo(f"  {headline}")
    click.echo(f"  {data.get('why', '')}")
    click.echo(f"  Owner: {data.get('owner', '—')}")

    # ⛔ SPLIT BY WHO CAN CLOSE THE GAP (S7 § 3.2). Measured on T1: 75% of
    # blocking columns are ours, so a bare "your setup is broken" would be
    # wrong three times out of four.
    split = data.get("owner_split") or {}
    if split.get("blocking_total"):
        click.echo(f"    of {split['blocking_total']} blocking column(s): "
                   f"{split.get('torana', 0)} ours (we do not collect it yet), "
                   f"{split.get('customer', 0)} your setup")
    click.echo()

    blocking = data.get("blocking") or []
    if blocking:
        # ⛔ § 6.2 rule 2 — THE LABEL STATES ITS OWN POPULATION, and the
        # population DIFFERS BY ANSWER. ⚠️ Measured defect: on the
        # `undetermined` path `blocking` carries UNTRACEABLE columns while
        # `blocking_count` is 0, so the old single header rendered
        # "Not supplied (0 of 3 fields it reads)" above a list of 3 — a count
        # that was right about a different population than the rows beneath it.
        if answer == "undetermined":
            click.echo(f"  Could not trace ({len(blocking)} of "
                       f"{data.get('column_count')} fields it reads):")
        else:
            click.echo(f"  Not supplied ({data.get('blocking_count')} of "
                       f"{data.get('column_count')} fields it reads):")
        for b in blocking:
            click.echo(f"    {b['table']}.{b['column']:<28} {b['verdict']}")
        # ⚠️ Only the blocking path has a capped remainder; the untraceable
        # list is already the capped slice and has no separate total.
        if answer != "undetermined":
            more = (data.get("blocking_count") or 0) - len(blocking)
            if more > 0:
                click.echo(f"    ...and {more} more")
        click.echo()

    # ⛔ Say what we could NOT check. A partial check reported as a clean one is
    # the confident-wrong-answer bug.
    limits = data.get("sql_limits") or {}
    if limits.get("caveat"):
        click.echo(f"  ⚠️  {limits['caveat']}")
        click.echo(f"     ({limits.get('unqualified_columns_skipped')} "
                   f"column name(s) not checked)\n")


@datalake_supply.command(name="workspace")
@click.argument("workspace_id")
@click.option("--kind", multiple=True,
              type=click.Choice(["rule", "transformer", "widget"]),
              help="Limit to these kinds (repeatable). Default: all three.")
@click.option("--only-broken", is_flag=True, default=False,
              help="List only the artifacts that cannot return anything.")
@click.pass_context
def datalake_supply_workspace(ctx, workspace_id, kind, only_broken):
    """Which parts of this app can produce a result on this tenant?

    ⛔ The acceptance check for an app BEFORE deploying it, rather than
    discovering case by case afterwards which parts have nothing behind them.

    \b
      torana datalake supply workspace <id>
      torana datalake supply workspace <id> --only-broken
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    params = [("kind", k) for k in kind] if kind else None
    try:
        data = client.get(f"datalake/supply/workspace/{workspace_id}",
                          params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
        return

    s = data.get("summary") or {}
    total = data.get("artifact_count") or 0
    click.echo(f"\n  {total} artifact(s) checked in this app\n")
    click.echo(f"    {s.get('quiet_estate', 0):>4}  can return data "
               f"(nothing matches today is normal)")
    click.echo(f"    {s.get('permanently_unanswerable', 0):>4}  will NOT return "
               f"anything — something they need is not supplied")
    click.echo(f"    {s.get('undetermined', 0):>4}  could not be checked\n")

    rows = data.get("artifacts") or []
    if only_broken:
        rows = [a for a in rows if a.get("answerable") == "permanently_unanswerable"]
    for a in rows:
        mark = {"permanently_unanswerable": "✗", "quiet_estate": "✓"}.get(
            a.get("answerable"), "?")
        name = str(a.get("artifact_name") or a.get("artifact_id"))[:44]
        click.echo(f"    {mark} {a.get('artifact_kind'):<12} {name:<44} "
                   f"{a.get('blocking_count') or 0}/{a.get('column_count') or 0}")

    # ⛔ An incomplete sweep must SAY it is incomplete — a partial result
    # rendered as a full one is the confident-wrong-answer bug.
    if data.get("unavailable_note"):
        click.echo(f"\n  ⚠️  {data['unavailable_note']}")
    if data.get("truncated_note"):
        click.echo(f"  ⚠️  {data['truncated_note']}")
    click.echo()


@datalake_supply.command(name="self-test")
@click.pass_context
def datalake_supply_self_test(ctx):
    """Produce every verdict deliberately, and show which ones worked.

    ⛔ A capability that has never returned a given answer has not been shown
    to be able to. Six verdicts never occur on a healthy tenant — a collector
    switched off, a failing sync, and the four enrichment-chain states — so
    this drives each one through the REAL resolver and reports whether it came
    out.

    ⚠️ Reads no tenant data and changes nothing.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.get("datalake/supply/self-test")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
        return

    items = data.get("items") or []
    click.echo(f"\n  {len(items)} verdict(s) exercised through the live resolver\n")
    for r in items:
        # ⚠️ A glyph AND the verdict name — never colour alone.
        mark = "✓" if r.get("produced") else "✗"
        click.echo(f"    {mark} {r['verdict']:<22} {r['scenario']}")
        if not r.get("produced"):
            click.echo(f"        ⛔ produced {r.get('actual')} instead")
    # ⛔ Say plainly whether anything is UNCOVERED — a verdict the code can
    # return but that nothing here exercises.
    nc = data.get("not_covered") or []
    if nc:
        click.echo(f"\n  ⚠️  Not exercised at all: {', '.join(nc)}")
    click.echo(f"\n  All produced: {data.get('all_produced')}\n")


@datalake_supply.command(name="scope")
@click.pass_context
def datalake_supply_scope(ctx):
    """What this can and CANNOT answer (the operational-store boundary).

    ⛔ The graph covers datalake columns. Alerts, routing executions, playbook
    runs, remediations and controls are OUT OF SCOPE with no equivalent
    diagnosis. ⚠️ Surfaced as its own verb so the limit is discoverable BEFORE
    you reach for the capability, not after.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.get("datalake/supply/scope")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
        return

    click.echo(f"\n  The Supply Graph covers {data.get('covers')}.\n")
    click.echo("  IN SCOPE")
    for s in data.get("in_scope") or []:
        click.echo(f"    ✓ {s}")
    click.echo("\n  OUT OF SCOPE — no diagnosis exists for these")
    for s in data.get("out_of_scope") or []:
        click.echo(f"    ✗ {s}")
    click.echo(f"\n  {data.get('out_of_scope_note', '')}\n")


@datalake_supply.command(name="chains")
@click.pass_context
def datalake_supply_chains(ctx):
    """Where on the supply chain did it stop? (decoration + governance)

    ⛔ Before this, everything that was not an integration collapsed into one
    answer — 'a caller must run'. So a column empty because a job never fired,
    one empty because the write lagged, and one empty because nothing was
    declared upstream all read the same, with three different owners.

    ⚠️ Governance link 3 (did the sweep reach THIS key namespace?) is reported
    as GAP-6 — the platform does not track it yet, and it is never guessed from
    the tenant-wide figure.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.get("datalake/supply/chains")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
        return

    dec = data.get("decoration") or {}
    click.echo("\n  ENRICHMENT — the jobs that add values to existing rows\n")
    if not dec.get("available"):
        # ⛔ Never render an unreachable surface as "nothing to report".
        click.echo(f"    Not available: {dec.get('why', 'unknown')}\n")
    elif not dec.get("items"):
        click.echo("    None configured.\n")
    else:
        for it in dec["items"]:
            # ⚠️ State the position on the chain, not the raw field values.
            if it.get("never_ran"):
                state = "HAS NEVER RUN"
            elif it.get("pending_apply"):
                state = "values ready, not written yet"
            elif it.get("stale"):
                state = "OVERDUE"
            else:
                state = "healthy"
            click.echo(f"    {it['decoration']:<14} {state}")
            click.echo(f"                   last ran: {it.get('last_success_at') or 'never'}")
            # ⛔ SA-only surface — say it is not visible, never imply fresh.
            click.echo("                   upstream feed: not visible to you\n")

    gov = data.get("governance") or {}
    click.echo("  GOVERNANCE — ownership, criticality and environment\n")
    if not gov.get("available"):
        click.echo(f"    Not available: {gov.get('why', 'unknown')}\n")
        return
    click.echo(f"    Last resolved: {gov.get('sweep_last_ran_at') or 'never'} "
               f"({gov.get('sweep_rows')} records, whole account)\n")
    for d in gov.get("declarations_by_namespace") or []:
        if d.get("governable"):
            mark = "✓" if d.get("governed") else "·"
            detail = f"{d.get('governed')} of {d.get('total')} governed"
        else:
            mark = "✗"
            detail = f"{d.get('total')} present — {d.get('note') or 'not governable'}"
        click.echo(f"    {mark} {str(d.get('key_namespace')):<10} {detail}")
        # ⛔ Link 3 — when the sweep last reached THIS namespace (GAP-6, closed).
        # ⚠️ `None` is printed as "never reached", NOT omitted: a missing line
        # would read as "fine", which is the confident-wrong answer the gap was
        # filed to avoid. Only rendered when the upstream reports per-namespace
        # freshness at all — see `reached_this_key_namespace`.
        if gov.get("reached_this_key_namespace") == "per_namespace" \
                and d.get("governable"):
            when = d.get("last_resolved_at") or "never reached"
            click.echo(f"                 last reached: {when}")

    gap = gov.get("gap") or {}
    if gap:
        # ⛔ NAME the gap. Never print 0 or an empty list for something the
        # platform cannot answer — that is the bug this surface exists to remove.
        click.echo(f"\n    ⚠️  Not tracked yet: {gap.get('what')}")
        click.echo(f"        {gap.get('detail', '')}")
    click.echo()


@datalake_supply.command(name="columns")
@click.option("--verdict", multiple=True,
              help="Filter by verdict (repeatable). Unknown values ERROR — see "
                   "`supply verdicts`.")
@click.option("--table", multiple=True, help="Filter by table (repeatable).")
@click.option("--integration", multiple=True,
              help="Columns this integration writes (repeatable).")
@click.option("--writer-kind", multiple=True,
              help="How it is written: mapping, declared, ingestor, decoration, "
                   "operator, system, extractor. Unknown values ERROR.")
@click.option("--dark", is_flag=True, default=False,
              help="Unlit but SUPPLIABLE. ⚠️ Excludes columns nothing can write "
                   "— those are --unreachable.")
@click.option("--lit", "lit_flag", is_flag=True, default=False,
              help="Lit only (worst verdict is SUPPLIED).")
@click.option("--sole-writer", is_flag=True, default=False,
              help="Only columns exactly ONE connected integration writes — the "
                   "real blast radius.")
@click.option("--unreachable", is_flag=True, default=False,
              help="⛔ E5 — the columns NOTHING writes. A different question with "
                   "a different owner; not part of --dark.")
@click.option("--group-by", default="",
              help="Aggregate instead of listing: table|verdict|integration|"
                   "writer_kind|owner.")
@click.option("--count", "count_only", is_flag=True, default=False,
              help="Just the number of distinct (table, column) pairs.")
@click.option("--limit", default=40, show_default=True,
              help="Rows to print in text mode (--format json returns all).")
@scope_options
@click.option("--export", "export_path", is_flag=False, flag_value="", default=None,
              metavar="[PATH]",
              help="ALSO write the two-sheet .xlsx. The terminal split is still "
                   "printed — this adds the spreadsheet, it does not replace it. "
                   "Give a PATH or omit it to use the server's own filename, "
                   "which records the scope and timestamp.")
@click.pass_context
def datalake_supply_columns(ctx, verdict, table, integration, writer_kind, dark,
                            lit_flag, sole_writer, unreachable, group_by,
                            count_only, limit, scope, tenant_id, export_path):
    """What columns exist, and are they lit? (D2/D3, T1-T4, E3, E5)

    ⛔ 'lit' means the worst verdict is SUPPLIED — read from the one resolver,
    never re-derived from which integrations write it. A writer-set test is
    wrong in BOTH directions: it calls self-filling columns dark, and inverting
    it marks caller-dependent columns "supplied" when nobody has ever run the
    caller.

    ⚠️ Filters COMPOSE.

    \b
    Examples:
      torana datalake supply columns --dark --group-by verdict        T2
      torana datalake supply columns --dark --table vulnerabilities   T2 ∩ T3
      torana datalake supply columns --verdict NEEDS_CALLER           T4
      torana datalake supply columns --sole-writer --count            T5
      torana datalake supply columns --unreachable --table assets     E5
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    if dark and lit_flag:
        click.echo("ERROR: --dark and --lit are opposites; pass at most one.",
                   err=True)
        raise SystemExit(2)

    # ⛔ `supply columns` had --tenant-id and NO --scope at all, so it was the one
    # column surface with no way to state "platform" explicitly. Same contract as
    # the rest now.
    scope, tenant_id = resolve_scope(scope, tenant_id)
    params = []
    for v in verdict:
        params.append(("verdict", v))
    for t in table:
        params.append(("table", t))
    for i in integration:
        params.append(("integration", i))
    for k in writer_kind:
        params.append(("writer_kind", k))
    if dark:
        params.append(("lit", "false"))
    if lit_flag:
        params.append(("lit", "true"))
    if sole_writer:
        params.append(("sole_writer", "true"))
    if unreachable:
        params.append(("unreachable", "true"))
    if group_by:
        params.append(("group_by", group_by))
    if tenant_id:
        params.append(("tenant_id", tenant_id))

    client = _client(ctx)
    try:
        data = client.get("datalake/supply/columns", params=params)
    except APIError as e:
        # ⛔ An unknown --verdict / --writer-kind / --group-by must name the
        # valid set, not return empty (§ 5.2 mutation 3).
        if _render_invalid_choice(e, fmt):
            raise SystemExit(e.exit_code)
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
        return

    if count_only:
        # ⛔ THE UNIT IS DISTINCT (table, column) PAIRS (review c15).
        n = data.get("distinct_total", data.get("total", 0))
        click.echo(f"{n}")
        return
    if group_by:
        _render_column_groups(data)
    elif any([verdict, table, integration, writer_kind, dark, lit_flag,
              sole_writer, unreachable]):
        _render_column_rows(data, limit=limit)
    else:
        _render_column_list(data)

    # ⭐ SHOW **AND** EXPORT — the spreadsheet is an ADDITION, never a
    # replacement. ⚠️ These were early `return`s; an export flag would have been
    # silently skipped on every path but the last.
    if export_path is not None:
        xparams = {"scope": "tenant" if tenant_id else "platform",
                   "include_unreachable": "true"}
        if table:
            xparams["table"] = list(table)
        if tenant_id:
            xparams["tenant_id"] = tenant_id
        _write_supply_workbook(ctx, xparams, export_path)


def _render_invalid_choice(e: APIError, fmt: str = "text") -> bool:
    """⛔ An invalid filter value ERRORS and names the valid set (c8/c21).

    ⚠️ The failure this prevents is silent: an unknown `--verdict` that returns
    an empty list is indistinguishable from "no columns have that verdict".
    """
    detail = e.detail if isinstance(e.detail, dict) else None
    if e.status_code != 422 or not detail or "error" not in detail:
        return False
    if fmt != "text":
        output(detail, fmt=fmt)
        return True
    click.echo(f"\nERROR: {detail['error']}", err=True)
    for key, label in (("valid_verdicts", "Valid verdicts"),
                       ("valid_writer_kinds", "Valid writer kinds"),
                       ("valid_group_by", "Valid --group-by values")):
        if detail.get(key):
            click.echo(f"\n  {label}: {', '.join(detail[key])}", err=True)
    click.echo(err=True)
    return True


def _render_column_groups(data: dict) -> None:
    """⛔ Carry BOTH totals (review c15).

    ⚠️ A column has up to 36 writers, so grouping by integration double-counts —
    and a reader who takes the sum as coverage is badly wrong. Say the distinct
    total, and say plainly when the sum exceeds it.
    """
    items = data.get("items") or []
    key = data.get("group_by")
    click.echo(f"\n  {data.get('distinct_total', 0)} columns, by {key}:\n")
    click.echo(f"    {key:<28} {'columns':>8} {'lit':>6} {'dark':>6}")
    for g in items:
        click.echo(f"    {str(g['group']):<28} {g['count']:>8} "
                   f"{g['lit']:>6} {g['dark']:>6}")
    if data.get("double_counted"):
        # ⛔ Never let the reader take the sum as coverage.
        click.echo(f"\n  ⚠️  Rows sum to {data.get('group_total')}, more than the "
                   f"{data.get('distinct_total')} distinct columns — a column with "
                   f"several {key}s\n      appears under each. The distinct count "
                   f"is the coverage figure.")
    _echo_supply_footer(data)
    click.echo()


#: How each writer mechanism reads to a human.
#:
#: ⚠️ MUST MATCH pantheon-fe's `data-supply.vocab.ts` KIND_LABEL. The raw kind
#: names are internal (`declared` is the API seam, `operator` is a push route),
#: and two surfaces naming the same mechanism differently is how a reader
#: concludes they are looking at two different facts.
_WRITER_KIND_LABEL = {
    "mapping": "ETL mapping",
    "declared": "API seam",
    "system": "Platform stamp",
    "operator": "Push route",
    "ingestor": "Ingestor",
    "decoration": "Decoration",
    "extractor": "Extractor",
}


#: What each mechanism MEANS for whether data will ever arrive on its own.
#: ⭐ This is the sentence that stops "reachable but empty" reading as a bug.
#: ⚠️ Mirrors pantheon-fe's KIND_NOTE — keep the two in step.
_KIND_NOTE = {
    "mapping": "arrives when that integration syncs",
    "declared": "⚠️ fills only on an external call — no sync ever will",
    "system": "stamped by the platform on every row",
    "operator": "filled when an operator or service pushes to the API",
    "ingestor": "filled by a bulk ingest path",
    "decoration": "joined at read time — not stored on the row",
    "extractor": "filled by an extractor pipeline",
}


#: Mechanisms whose writers carry an INTEGRATION, and are therefore gated on
#: what the tenant connected. Everything else is a platform path that is always
#: available, so scoring it by `connected_writers` is meaningless.
#:
#: ⚠️ MEASURED, not assumed — writers carrying an `integration` field, platform
#: scope: mapping 1440/1440, ingestor 14/24, extractor 1/2; declared 0/129,
#: decoration 0/27, system 0/11, operator 0/3.
_INTEGRATION_BACKED_KINDS = {"mapping", "ingestor", "extractor"}


def _writer_mechanisms(col: dict) -> str:
    """The mechanism(s) that write one column, as a human reads them.

    ⚠️ A column can have several — `assets.torana_entity_id` is written by both
    a mapping and the API seam — so this joins rather than picking one. Picking
    one would silently hide the path the reader is asking about.
    """
    kinds = col.get("writer_kinds") or []
    if not kinds:
        return "nothing"
    return "+".join(_WRITER_KIND_LABEL.get(k, k) for k in kinds)


def _render_column_rows(data: dict, limit: int = 40) -> None:
    items = data.get("items") or []
    if data.get("unreachable"):
        click.echo(f"\n  {len(items)} columns nothing writes.")
        # ⛔ § 4.2b — state the hedge before the list, not after.
        click.echo(f"  {data.get('caveat', '')}\n")
    else:
        click.echo(f"\n  {len(items)} columns "
                   f"({data.get('lit_count', 0)} lit, "
                   f"{data.get('dark_count', 0)} dark):\n")
    shown = items[:limit]
    width = max((len(f"{c['table']}.{c['column']}") for c in shown), default=10)
    # ⭐ WHO WRITES IT is the second half of the answer and used to be missing:
    # the row named the verdict but never the MECHANISM, so "why is this empty"
    # could not be told apart from "what would fill it". `writer_kinds` is on
    # every row of the payload already — this only stops discarding it.
    vwidth = max((len(c.get("verdict", "")) for c in shown), default=8)
    mwidth = max((len(_writer_mechanisms(c)) for c in shown), default=7)
    click.echo(f"    {'COLUMN'.ljust(width)}  {'ANSWER'.ljust(vwidth)}  "
               f"{'WRITTEN BY'.ljust(mwidth)}  DETAIL")
    for c in shown:
        ref = f"{c['table']}.{c['column']}"
        sole = c.get("sole_among_connected")
        extra = f"only {sole} writes it" if sole else ""
        hedge = "  ⚠️ not proven" if c.get("hedged") else ""
        click.echo(f"    {ref.ljust(width)}  {c['verdict'].ljust(vwidth)}  "
                   f"{_writer_mechanisms(c).ljust(mwidth)}  {extra}{hedge}".rstrip())
    if len(items) > limit:
        click.echo(f"\n    … and {len(items) - limit} more "
                   f"(--limit N, or --format json for all)")
    _echo_supply_footer(data)
    click.echo()




def _available_here(col: dict, tenant_lens: bool) -> bool:
    """Can THIS tenant actually get this column?

    ⚠️ Two different tests, by mechanism. An integration-backed writer needs the
    integration CONNECTED; a platform path (API seam, decoration, stamps, push
    routes) is always on. Using one test for all seven scored always-available
    columns as unreachable — measured, that reported 96 API-seam columns as 37.
    """
    if not tenant_lens:
        return True
    kinds = set(col.get("writer_kinds") or [])
    if not kinds:
        return False
    if kinds - _INTEGRATION_BACKED_KINDS:
        return True                      # has at least one always-on path
    # ⚠️ `connected_any`, NOT `connected_writers`. The latter is mapping-only
    # (it drives the per-collector SOURCE_DISABLED hop), so an EXTRACTOR writer's
    # integration is absent from it — measured, that dropped
    # `repositories.teams` and reported 313 where the FE said 314 for the same
    # tenant. Falls back for an older server that does not send the field.
    if "connected_any" in col:
        return bool(col.get("connected_any"))
    return bool(col.get("connected_writers"))


def _render_column_list(data: dict) -> None:
    items = data.get("items") or []
    lit = sum(1 for c in items if c.get("lit"))
    rc = data.get("resolved_context") or {}

    # ⛔ SAY WHOSE NUMBER THIS IS. `items` is every column SOME Torana pipeline
    # can write — a platform fact, the same 441 for every tenant. Printing it
    # bare under a tenant heading reads as "this tenant can reach 441", which is
    # false: on T2 only 314 are reachable HERE. The FE shows 314 for exactly
    # this reason, and two surfaces disagreeing on one tenant's number is worse
    # than either being wrong alone.
    connected = rc.get("connected_integrations") or []
    here = sum(1 for c in items if _available_here(c, bool(connected)))
    if connected:
        click.echo(f"\n  {here} of {len(items)} columns are reachable for THIS "
                   f"tenant; {lit} are lit, {here - lit} are dark.")
        click.echo(f"  ({len(items)} is the PLATFORM figure — what Torana ships "
                   f"a writer for, the same for every tenant.)")
    else:
        click.echo(f"\n  {len(items)} columns can be given an answer; "
                   f"{lit} are lit, {len(items) - lit} are dark.")
    unreachable = rc.get("unreachable_column_count")
    if unreachable:
        # ⛔ § 4.2a — the unreachable set is a DIFFERENT question with a
        # different owner. Folding it into 'dark' would put a purchase
        # suggestion on a column no tool can fill.
        click.echo(f"  ({unreachable} more are declared but nothing writes them — "
                   f"a Torana gap, not a connection you can make.)")
    click.echo()

    by_verdict = {}
    for c in items:
        by_verdict.setdefault(c["verdict"], []).append(c)
    click.echo("  By answer:")
    for verdict, group in sorted(by_verdict.items(),
                                 key=lambda kv: (kv[1][0].get("rank") is None,
                                                 kv[1][0].get("rank") or 0)):
        click.echo(f"    {verdict:<18} {len(group):>4}")

    # ⭐ WHO WRITES THEM — the other half of the picture, and the half the FE's
    # Data Supply page shows as mechanism cards. Without it the summary says how
    # many columns can be answered but never by what path, so a reader cannot
    # tell a column that fills on the next sync from one that needs somebody to
    # call an API.
    by_kind = {}
    here = {}
    tenant_lens = bool(rc.get("connected_integrations"))
    for c in items:
        # ⛔ TWO DIFFERENT FACTS, and merging them is the bug this surface exists
        # to prevent. EXISTS = a pipeline Torana ships can write it (platform
        # fact). AVAILABLE HERE = this tenant can actually get it.
        #
        # ⚠️ THE TEST DIFFERS BY MECHANISM, and using one test for all seven is
        # wrong — I shipped that first. Only INTEGRATION-BACKED mechanisms are
        # gated on what the tenant connected; the rest are platform paths that
        # are always available. Measured on T2: `artifacts.created_via` is
        # written by the API seam alone, so `connected_writers` is [] — scoring
        # it "not available" reported 96 API-seam columns as 37 and implied a
        # tenant must connect something to reach an endpoint that is always up.
        for k in (c.get("writer_kinds") or []):
            by_kind[k] = by_kind.get(k, 0) + 1
            avail = (bool(c.get("connected_writers"))
                     if k in _INTEGRATION_BACKED_KINDS else True)
            if avail:
                here[k] = here.get(k, 0) + 1
    if by_kind:
        if tenant_lens:
            click.echo("\n  By mechanism (who writes them):")
            click.echo(f"    {'':<18} {'EXISTS':>6} {'HERE':>6}")
        else:
            click.echo("\n  By mechanism (who writes them):")
        for kind, n in sorted(by_kind.items(), key=lambda kv: -kv[1]):
            label = _WRITER_KIND_LABEL.get(kind, kind)
            if tenant_lens:
                click.echo(f"    {label:<18} {n:>6} {here.get(kind, 0):>6}"
                           f"   {_KIND_NOTE.get(kind, '')}")
            else:
                click.echo(f"    {label:<18} {n:>4}   {_KIND_NOTE.get(kind, '')}")
        total = sum(by_kind.values())
        if total > len(items):
            # ⛔ Never let the reader take the sum as coverage — a column with
            # two mechanisms appears under both.
            click.echo(f"\n    ⚠️  Sums to {total}, more than the {len(items)} "
                       f"columns — a column with several mechanisms\n        "
                       f"appears under each.")
        if tenant_lens:
            click.echo("\n    EXISTS = a pipeline Torana ships can write it "
                       "(identical for every tenant).\n    HERE   = available to "
                       "THIS tenant. For ETL mapping / ingestor / extractor that "
                       "means the\n             integration is connected; the "
                       "other four are platform paths, always on.\n    ⚠️ A gap "
                       "is a connection to make, NOT a build defect.")

    click.echo("\n  `supply verdicts` explains each answer and who owns the fix.")
    _echo_method_limits(data)
    _echo_supply_footer(data)
    click.echo()


def _echo_method_limits(data: dict) -> None:
    """⛔ HEDGE `UNREACHABLE` (§ 4.2b, review c13) — the most dangerous item.

    ⚠️ The payload states verbatim that *"reachable=False means no writer was
    found by this parse, NOT that no pipeline can ever write it"*: 99 of 102
    mappings default to `on_extra_field=keep`, so a vendor field matching a
    column name is written with no pipeline step naming it.

    ⛔ Rendering that as "Torana does not collect this" — rank 1, the verdict
    that says no customer action helps — is § 4.5's bug INVERTED, over 920
    columns, on values that may already be populating.
    """
    nsd = (data.get("method_limits") or {}).get("not_statically_derivable") or []
    if nsd:
        click.echo(f"\n  ⚠️  'Nothing writes this' is not proof: we could not find a "
                   f"writer by reading\n      the pipelines, but some pipelines write "
                   f"fields we cannot see in advance\n      ({len(nsd)} known: "
                   f"{', '.join(nsd[:3])}{' …' if len(nsd) > 3 else ''}).")


@datalake_supply.command(name="integrations")
@click.option("--connected/--disconnected", "connected", default=None,
              help="⛔ B4 ('am I paying for a tool that adds nothing unique?') "
                   "needs --connected: a tool you do not own is trivially the "
                   "sole writer of 0.")
@click.option("--category", multiple=True,
              help="Only integrations in this category (repeatable).")
@click.option("--count", "count_only", is_flag=True, default=False,
              help="Just the number of integrations.")
@click.option("--validation", "validation",
              type=click.Choice(["validated", "unvalidated", "push_path"]),
              default=None,
              help="Only integrations with this validation status. "
                   "⚠️ 'push_path' (sarif/asset/trivy/entity_edge) is NOT a provider "
                   "anyone connects — it is never filtered and never greyed.")
@click.pass_context
def datalake_supply_integrations(ctx, connected, category, count_only, validation):
    """What can I ask about? (D1 — the entry point; B1, B2, B4, T6)

    ⛔ Without this a reader must already know a valid name to use the forward
    walk. That was the gap that prompted P13.

    ⚠️ Sole-writer is reported as the TENANT-SCOPED measure: the only CONNECTED
    writer is a real single point of failure even when a tool you do not own
    also writes the column.

    \b
    Examples:
      torana datalake supply integrations                 D1
      torana datalake supply integrations --connected     B4, T6
      torana datalake supply integrations --disconnected  B1, B2
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    params = []
    if connected is not None:
        params.append(("connected", "true" if connected else "false"))
    for c in category:
        params.append(("category", c))

    client = _client(ctx)
    try:
        data = client.get("datalake/supply/integrations", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # ⛔ CLIENT-SIDE, like `--connected` above and unlike `--category`. The endpoint
    # must return the FULL roster (it is the unfiltered platform-capability surface),
    # so a server-side param would buy nothing and add API surface.
    if validation:
        items = [i for i in (data.get("items") or [])
                 if (i.get("validation_status") or "validated") == validation]
        data = {**data, "items": items, "total": len(items)}

    if fmt != "text":
        output(data, fmt=fmt)
        return
    if count_only:
        click.echo(f"{data.get('total', 0)}")
        return
    _render_integration_list(data)


def _render_integration_list(data: dict) -> None:
    items = data.get("items") or []
    # ⛔ PUSH PATHS ARE NOT INTEGRATIONS — split them out BEFORE anything else.
    #
    # They were appearing under "NOT CONNECTED — what connecting one would light",
    # which is not merely confusing but WRONG ADVICE: there is nothing to connect. No
    # credentials, no endpoint, no sync. `asset` in particular reads like a vendor and is
    # actually a human governance document (owner, environment, data sensitivity) pushed
    # by the torana-asset-inventory skill — facts no scanner can discover.
    #
    # ⚠️ Different question, different action. For tenable you buy and connect a scanner;
    # for `asset` somebody fills in an inventory. One list asked the reader to tell those
    # apart from the name alone, and the name does not say.
    push = [i for i in items if i.get("validation_status") == "push_path"]
    connectable = [i for i in items if i.get("validation_status") != "push_path"]
    connected = [i for i in connectable if i.get("connected")]
    dark = [i for i in connectable if not i.get("connected")]

    click.echo(f"\n  {len(connected)} connected, {len(connectable)} integrations known "
               f"to the platform.")

    # ⭐ VALIDATION STATUS — which of these pipelines we have actually run against a
    # real endpoint. An unvalidated provider's columns are HIDDEN from the reachable
    # schema (SCHEMA_SERVICES_FILTER), so a reader deciding what to build on needs the
    # distinction here, next to the blast-radius numbers they are reading.
    unval = [i for i in connectable if i.get("validation_status") == "unvalidated"]
    if unval:
        click.echo(f"\n  ⚠️  {len(unval)} UNVALIDATED — mapping exists, never run against a "
                   f"real endpoint.\n      Their columns are hidden from the reachable "
                   f"schema. Blast-radius numbers below are still platform-wide truth.")
        click.echo(f"      {', '.join(sorted(i['integration'] for i in unval))}")
    click.echo()
    if connected:
        click.echo("  CONNECTED — what you would lose:")
        click.echo(f"    {'integration':<16} {'at risk':>8}  {'writes':>7}")
        for i in sorted(connected, key=lambda x: -x.get("sole_among_connected_count", 0)):
            # ⛔ 'at risk' is sole_among_connected — the columns that go dark for
            # THIS tenant if it disconnects. Not the platform-wide figure, which
            # understates it (measured 3x on gcp).
            click.echo(f"    {i['integration']:<16} "
                       f"{i.get('sole_among_connected_count', 0):>8}  "
                       f"{i.get('writes_count', 0):>7}")
        click.echo("\n    'at risk' = columns nothing else you have connected writes.")
    if dark:
        click.echo("\n  NOT CONNECTED — what connecting one would light:")
        click.echo(f"    {'integration':<16} {'would light':>11}")
        ranked = sorted(dark, key=lambda x: -x.get("would_light_count", 0))
        for i in ranked[:12]:
            click.echo(f"    {i['integration']:<16} {i.get('would_light_count', 0):>11}")
        if len(ranked) > 12:
            click.echo(f"    … and {len(ranked) - 12} more (--format json for all)")
        # ⚠️ An honest zero is a real answer, not a gap — say so, because the
        # reader is deciding whether to buy something.
        zero = [i["integration"] for i in ranked if not i.get("would_light_count")]
        if zero:
            click.echo(f"\n    {len(zero)} would light nothing new: "
                       f"{', '.join(zero[:6])}"
                       f"{' …' if len(zero) > 6 else ''}")
    _render_push_paths(push)
    _echo_supply_footer(data)
    click.echo()


#: What actually fills each push path — because the NAME does not say.
#: ⚠️ `asset` reads like a vendor and is a human governance document; `sarif` is a
#: FORMAT, not a tool. A reader cannot decode either from the name alone.
_PUSH_PATH_WHAT = {
    "asset": "governance somebody records — owner, environment, data sensitivity "
             "(torana-asset-inventory skill)",
    "sarif": "any scanner's SARIF 2.1.0 output, posted to /ingest/sarif",
    "trivy": "trivy's native JSON — CVE + package identity SARIF cannot carry",
    "entity_edge": "graph edges the platform derives as sources converge",
    "entity_edges": "graph edges the platform derives as sources converge",
}


def _render_push_paths(push: list) -> None:
    """The second list — paths that fill when something SENDS data, not when you connect.

    ⛔ Deliberately NOT ranked by `would_light_count` like the connectable list above.
    That number answers "what would buying this get me?", and none of these is something
    you buy. Ranking them the same way invites the same (wrong) reading.
    """
    if not push:
        return
    click.echo("\n  PUSHED TO TORANA — nothing to connect; these fill when data is SENT in:")
    width = max(len(i["integration"]) for i in push)
    for i in sorted(push, key=lambda x: x["integration"]):
        name = i["integration"]
        what = _PUSH_PATH_WHAT.get(name, "filled when something sends data in")
        n = i.get("writes_count", 0)
        click.echo(f"    {name:<{width}}  {n:>4} col{'' if n == 1 else 's'}   {what}")
    click.echo()


def _echo_supply_footer(data: dict) -> None:
    """⛔ State the TENANT (§ 4.1) and warn when the category layer is degraded.

    ⚠️ The same column resolves differently per tenant (PEER_GAP on T1,
    CATEGORY_MISSING on SA), so an unattributed listing is wrong for everyone.
    """
    rc = data.get("resolved_context") or {}

    # ⭐ WHOSE ESTATE IS THIS? The same column is SUPPLIED for a tenant that
    # connected the tool and CATEGORY_MISSING for one that did not, so an
    # unattributed listing is wrong for everyone reading it. The connected set
    # IS the context: empty means the platform view (what Torana ships), a
    # populated list means one tenant's actual estate.
    connected = rc.get("connected_integrations") or []
    if connected:
        click.echo(f"\n  Tenant context — {len(connected)} connected: "
                   f"{', '.join(sorted(connected))}.")
        # ⚠️ Say precisely WHICH numbers moved. Verdicts are resolved against
        # this estate; the mechanism EXISTS counts are platform facts and did
        # NOT move — claiming otherwise overstates the estate.
        click.echo("  Verdicts are resolved against THIS estate. The mechanism "
                   "EXISTS counts are platform\n  facts and are identical for "
                   "every tenant — HERE is the per-tenant column.")
    else:
        click.echo("\n  Platform context — everything Torana ships, no tenant "
                   "lens applied.")
        click.echo("  Pass --tenant-id <uuid> to resolve against one tenant's "
                   "connected integrations.")

    if rc.get("category_layer") == "unavailable":
        # ⛔ § 4.6(b) — a degraded layer must never emit a "connect a …"
        # sentence, and the degradation must be LOUD, never silent.
        click.echo("\n  ⚠️  tool-category information was unavailable, so "
                   "'connect a …' advice is degraded.", err=True)


def _render_unknown_integration(e: APIError, fmt: str = "text") -> bool:
    """⛔ THE CONFIDENT-WRONG-ANSWER FIX, customer side (§ 4.5 / § 3.16.1).

    Returns True if this error WAS an unknown-integration 404 and has been
    rendered here; False to fall through to the ordinary handler.

    ⚠️ Why this needs its own renderer rather than the generic one: the payload
    carries `valid_integrations` (28 names on T1), and the generic handler
    prints ``key: value`` per detail key — which emits the whole list as a
    Python repr on one line. The point of the fix is that a reader who typed a
    wrong name can SEE the right ones, so the list has to be readable.

    ⛔ The old behaviour was not an ugly error — it was a confident WRONG
    ANSWER: `--integration nonexistent` reported "not connected; 0 columns would
    light up", the same sentence `splunk` earns honestly. A reader could not
    tell a typo from a tool that adds nothing.
    """
    detail = e.detail if isinstance(e.detail, dict) else None
    if e.status_code != 404 or not detail or detail.get("known") is not False:
        return False

    if fmt != "text":
        output(detail, fmt=fmt)
        return True

    valid = detail.get("valid_integrations") or []
    connected = set(detail.get("connected_integrations") or [])
    click.echo(f"\nERROR: {detail.get('error') or e}", err=True)
    if valid:
        # ⚠️ Mark which are connected. A reader looking for a name is usually
        # also asking "which of these do I already have?", and the answer is
        # already in the payload.
        click.echo(f"\n  Valid integrations ({len(valid)}) — "
                   f"✓ marks the {len(connected)} you have connected:", err=True)
        for i in range(0, len(valid), 4):
            row = "  ".join(
                f"{'✓' if n in connected else ' '} {n}".ljust(22)
                for n in valid[i:i + 4]
            )
            click.echo(f"    {row.rstrip()}", err=True)
        click.echo("\n  Or run: torana datalake supply integrations", err=True)
    click.echo(err=True)
    return True


def _render_forward(data: dict) -> None:
    """⛔ SOLE-writes is the blast radius, and the distinction is the whole point.

    `cve_id` has seven writers; losing one changes nothing. Leading with TOTAL
    writes overstates the radius by >2x (measured: tenable 115 vs 48), which is
    the difference between an accurate risk statement and an alarming one.
    """
    name = data.get("integration")
    connected = data.get("connected")
    click.echo(f"\n{name}  ({'connected' if connected else 'not connected'})\n")
    if connected:
        click.echo(f"  If it disconnects: {data.get('sole_writes_count', 0)} column(s) "
                   f"go dark — nothing else writes them.")
        click.echo(f"  (It writes {data.get('writes_count', 0)} in total; the rest have "
                   f"other writers and would keep filling.)")
    else:
        click.echo(f"  If you connect it: {data.get('would_light_count', 0)} column(s) "
                   f"that are dark today would start filling.")
        click.echo(f"  It writes {data.get('writes_count', 0)} column(s), "
                   f"{data.get('sole_writes_count', 0)} of which nothing else writes.")
    by_table = data.get("would_light_by_table") or {}
    if by_table and not connected:
        # ⚠️ B6 — "50 of tenable's 62 are vulnerabilities" IS the answer; a bare
        # 62 tells a buyer nothing about whether it is the 62 they need.
        parts = ", ".join(f"{n} {t}" for t, n in list(by_table.items())[:4])
        click.echo(f"  Where: {parts}")

    sole = data.get("sole_writes") or []
    if sole:
        click.echo("\n  Columns only this integration writes:")
        for c in sole[:20]:
            click.echo(f"    {c}")
        if len(sole) > 20:
            click.echo(f"    … and {len(sole) - 20} more")

    # ⛔ X2 — the EM half: not "how many columns" but "which of MY questions".
    if data.get("questions_unavailable"):
        click.echo("\n  ⚠️  We cannot say which questions this would unblock — "
                   "the question corpus is not available here.")
    elif "questions_unblocked_count" in data:
        n = data["questions_unblocked_count"]
        total = data.get("questions_total", 0)
        click.echo(f"\n  Questions it would unblock: {n} of {total}")
        for q in (data.get("questions_unblocked") or [])[:8]:
            click.echo(f"    {q['question_id']}  {q.get('use_case', '')}")
            for line in textwrap.wrap(q.get("question") or "", width=88,
                                      initial_indent="        ",
                                      subsequent_indent="        "):
                click.echo(line)
        if n > 8:
            click.echo(f"    … and {n - 8} more")
        if n == 0:
            # ⚠️ An honest zero, and it must not read like a failure: it means
            # every blocked question needs something else as well.
            click.echo("    (Every question it touches is also blocked by "
                       "something this tool does not write.)")
    click.echo()


#: Verdict -> a one-word owner tag. ⚠️ NOT decoration: the first question a
#: reader has is "is this mine to fix?", and the verdict name alone does not
#: answer it — CATEGORY_MISSING and UNREACHABLE look equally like our fault.
_VERDICT_OWNER = {
    "SUPPLIED": "ok",
    "UNREACHABLE": "torana",
    #: ⛔ Not an owner at all — there is no supply problem to own.
    "NO_SUCH_COLUMN": "no such column",
    "NEEDS_CALLER": "action needed",
    # ⛔ The P15 chain positions — see the matching note in _VERDICT_HEADLINE.
    # ⚠️ Three of the four are OURS. That is the whole reason the chain was
    # split out of NEEDS_CALLER: a stalled enrichment job is not something a
    # tenant can act on, and tagging it "you can fix" would send them to buy a
    # tool that changes nothing.
    "PRODUCER_NEVER_RAN": "torana",
    "PRODUCER_STALE": "torana",
    "APPLY_PENDING": "torana",
    "UPSTREAM_UNDECLARED": "action needed",
    "CATEGORY_MISSING": "you can fix",
    "PEER_GAP": "you can fix",
    "DOCUMENT_ONLY": "you can fix",
    "SOURCE_DISABLED": "you can fix",
    "SYNC_FAILING": "you can fix",
    "UNRESOLVED": "untraceable",
    "LINEAGE_AMBIGUOUS": "untraceable",
}


def _render_diagnosis(data: dict, verbose: bool = False) -> None:
    cols = data.get("columns") or []
    q = data.get("query") or {}
    click.echo()

    # ⚠️ ONE column and the query verdict is the SAME verdict — printing both is
    # the same sentence twice. Measured on the single-column case, which is the
    # common invocation: the old output said "PEER_GAP: your scanner does not
    # report this" and then "Overall: PEER_GAP — your scanner does not report
    # this". Repetition trains a reader to skip the summary, which is exactly
    # the line that matters when there ARE several columns.
    single = len(cols) == 1

    # ⚠️ Wrap to the REAL terminal, not a fixed 96. A hardcoded width either
    # overflows a narrow window or wastes a wide one; both make the sentence
    # that tells a reader what to do harder to read.
    term = shutil.get_terminal_size((100, 24)).columns
    width = max((len(f"{c['table']}.{c['column']}") for c in cols), default=0)

    # ⛔ ONE column needs NO alignment column — there is nothing to align WITH.
    # The hanging indent exists so several findings line up; on a single column
    # it only pushed the sentence 36 chars right and forced a 2-line wrap of
    # text that fits on one. Indent 4 instead.
    hang = 4 if single else width + 4

    for c in cols:
        ref = f"{c['table']}.{c['column']}"
        owner = _VERDICT_OWNER.get(c["verdict"], "")
        tag = f"  [{owner}]" if owner else ""
        click.echo(f"  {ref.ljust(0 if single else width)}  {c['verdict']}{tag}")
        # ⚠️ WRAPPED, not truncated — an evidence string naming several
        # integrations runs past any terminal, and a mid-word break is how
        # "tools such as tenable do" becomes unreadable at exactly the moment it
        # is telling the reader what to buy.
        indent = " " * hang
        for line in textwrap.wrap(_describe(c['verdict'], c.get('evidence')),
                                  width=max(40, term - 2), initial_indent=indent,
                                  subsequent_indent=indent) or [indent]:
            click.echo(line)
        # ⛔ P15 #6 — OBSERVED FILL, on its OWN LINE, never merged into the
        # sentence above. ⚠️ The two say different things: the verdict is about
        # the CHAIN, the fill is about what came down it. Merging them into one
        # sentence is the same conflation the API refuses structurally.
        f = c.get("observed_fill")
        if f:
            if f.get("known"):
                pct = f.get("percent")
                pct_s = f"{pct}%" if pct is not None else "—"
                click.echo(f"{indent}Rows with a value: "
                           f"{f['rows_with_a_value']} of {f['rows']} ({pct_s})")
            elif f.get("why"):
                # ⛔ Say it was NOT measured. Silence reads as "measured, empty".
                click.echo(f"{indent}Rows with a value: not measured — {f['why']}")

        # ── The THIRD axis: WHAT values, not how many rows ──────────────────
        # ⛔ Rendered separately from fill for the same reason fill is separate
        # from the verdict: they answer different questions. A column can be
        # 100% filled and still hold one value forever.
        # ⚠️ Tier 1 first: it is present whenever --shape OR --values was asked,
        # and it is the ONLY answer when the column is too wide to list.
        cs = c.get("column_shape")
        cv = c.get("column_values")
        if cs and not (cv or {}).get("known"):
            if cs.get("known"):
                est = cs.get("n_distinct_estimate")
                # ⚠️ pg_stats reports n_distinct as a NEGATIVE RATIO of rows
                # when it scales with table size — rendering that raw would
                # print "-0.7 distinct values".
                est_s = (f"~{int(est)} distinct"
                         if isinstance(est, (int, float)) and est > 0
                         else "scales with row count")
                nf = cs.get("null_frac")
                nf_s = f", {round(float(nf) * 100, 1)}% null" if nf else ""
                click.echo(f"{indent}Shape: {str(cs.get('shape')).upper()} — "
                           f"{est_s}{nf_s}"
                           f"   [estimated, ALL rows incl. deleted]")
                if (cv or {}).get("why"):
                    click.echo(f"{indent}  values not listed — {cv['why']}")
            elif cs.get("why"):
                click.echo(f"{indent}Shape: not classified — {cs['why']}")
        if cv:
            if cv.get("known"):
                n = cv.get("distinct")
                click.echo(f"{indent}Shape: {str(cv.get('shape')).upper()} — "
                           f"{n} distinct value{'' if n == 1 else 's'}"
                           f"   [exact, live rows]")
                for b in (cv.get("values") or []):
                    v = b.get("value")
                    label = "(null)" if v is None else str(v)
                    pct = b.get("percent")
                    pct_s = f"{pct}%" if pct is not None else "—"
                    click.echo(f"{indent}  {label[:40]:<40} "
                               f"{b.get('rows'):>8}  {pct_s:>6}")
                # ⛔ The warning IS the product here — a constant column is
                # invisible under --fill and breaks every predicate that
                # excludes its one value.
                if cv.get("warning"):
                    click.echo(f"{indent}  ⚠ {cv['warning']}")
                # ⚠️ Surface a Tier1/Tier2 disagreement rather than hiding it:
                # pg_stats counts DELETED rows too, so a large gap means the
                # soft-deleted rows differ from the live ones.
                est = (cs or {}).get("n_distinct_estimate")
                if (isinstance(est, (int, float)) and est > 0 and n
                        and abs(est - n) > max(2, 0.25 * n)):
                    click.echo(f"{indent}  ⚠ pg_stats estimated {int(est)} "
                               f"(all rows incl. deleted)")
        if not single:
            click.echo()

    # ⛔ § 3.4.4 — when everything is SUPPLIED there is NOTHING to say. A query
    # returns 0 rows for a perfectly healthy reason: the filters matched nothing.
    if q.get("customer_facing") and not single:
        click.echo(f"  Overall: {q['verdict']} — "
                   f"{_describe(q['verdict'], (q.get('columns') or [{}])[0].get('evidence'))}")
        if q.get("more_count"):
            click.echo(f"  (and {q['more_count']} more column(s) with the same cause)")
        click.echo()

    rc = data.get("resolved_context") or {}
    # ⛔ THE FOOTER IS DIAGNOSTIC CONTEXT, NOT AN ANSWER — so it goes behind
    # --verbose, and by default we print nothing.
    #
    # ⚠️ It used to print unconditionally: "checked against 397 known columns;
    # connected: gcp, github, gitlab, jira, kubernetes, slack". Both halves
    # answered questions the reader had not asked:
    #   * "397 known columns" is an INTERNAL scale figure. It exists because the
    #     count moved four times in one day (384→389→395→397) and a verdict is
    #     only interpretable against the set it was resolved on — a real concern,
    #     but OURS when reproducing a diagnosis, not the reader's when acting on
    #     one.
    #   * The full integration list is not relevant to ONE column. For a
    #     PEER_GAP the only integrations that matter are the peers, and those are
    #     now named IN the sentence. Listing Slack and Jira under a CVSS question
    #     invites the reader to hunt for a connection between them; there is none.
    if verbose:
        click.echo(f"  resolved against {rc.get('reachable_column_count')} known columns; "
                   f"connected: "
                   f"{', '.join(rc.get('connected_integrations') or []) or 'none'}")
    if rc.get("category_layer") == "unavailable":
        click.echo("  ⚠️  tool-category information was unavailable, so 'connect a …' "
                   "advice is degraded to 'we could not trace this'.", err=True)
    click.echo()


@datalake.command(name="check-intent")
@click.option("--file", "intent_file", default="",
              help="File containing the semantic_description / intent text.")
@click.option("--text", default="", help="The intent text itself.")
@click.option("--artifact-type", default="",
              help="Artifact type, for the error message only (widget | rule | transformer …).")
@click.pass_context
def datalake_check_intent(ctx, intent_file, text, artifact_type):
    """Is this `semantic_description` a regeneration-grade INTENT, or just a description?

    ⛔ S12 / row 20z. An artifact's source of truth is its INTENT, not its SQL:
    SQL → English is lossy, so SQL cannot be regenerated from itself. This checks
    the five-part contract — question · grain · semantics · scope · fallback.

    ⚠️ EXISTS BECAUSE A SKILL MAY NOT IMPORT PLATFORM CODE. The
    `torana-text-to-sql` skill documents the contract in its SKILL.md and has no
    way to enforce it: `skills/CLAUDE.md` forbids importing `pantheon_shared`,
    and vendoring a copy of the rule is the drift this subsystem exists to
    prevent. So the rule stays in `pantheon_shared.datalake.artifact_intent` and
    reaches the skill the only way anything reaches a skill — over this CLI.

    \b
    Exit codes: 0 = conforming · 1 = not an intent · 2 = usage error.

    \b
    Examples:
      torana datalake check-intent --file intent.txt
      torana datalake check-intent --text "$(cat sd.md)" --artifact-type widget
    """
    if bool(intent_file) == bool(text):
        click.echo("ERROR: pass exactly one of --file or --text.", err=True)
        raise SystemExit(2)
    if intent_file:
        try:
            with open(intent_file, "r", encoding="utf-8") as fh:
                text = fh.read()
        except OSError as e:
            click.echo(f"ERROR: could not read {intent_file}: {e}", err=True)
            raise SystemExit(2)

    try:
        from pantheon_shared.datalake.artifact_intent import (
            validate_intent, parse_intent, INTENT_PARTS)
    except Exception as exc:  # noqa: BLE001
        # ⛔ Say the check could not run. Silence would read as a pass — the
        # row 35 failure mode, where a gate that cannot execute prints a clean
        # bill of health.
        click.echo(f"ERROR: the intent rule could not be loaded ({type(exc).__name__}). "
                   f"This is NOT a pass — install/upgrade pantheon-shared.", err=True)
        raise SystemExit(2)

    verdict = validate_intent(text, artifact_type=artifact_type)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    if fmt != "text":
        intent = parse_intent(text)
        output({"ok": verdict.ok, "missing": verdict.missing,
                "too_short": verdict.too_short, "problems": verdict.problems,
                "parts": intent.parts(), "grain_signature": intent.grain_signature()},
               fmt=fmt)
        raise SystemExit(0 if verdict.ok else 1)

    if verdict.ok:
        intent = parse_intent(text)
        click.echo("  ✅ regeneration-grade intent")
        for part in INTENT_PARTS:
            value = " ".join(getattr(intent, part).split())
            click.echo(f"     {part:<10} {value[:88]}{'…' if len(value) > 88 else ''}")
        raise SystemExit(0)

    click.echo("  ❌ NOT an intent — this is a description")
    for part in verdict.missing:
        click.echo(f"     missing   {part}")
    for part in verdict.too_short:
        click.echo(f"     too short {part}")
    for problem in verdict.problems:
        click.echo(f"     ⚠ {problem}")
    click.echo()
    click.echo("  The bar: could two competent generators, given only this text and the")
    click.echo("  current schema, produce queries that disagree on a row count?")
    raise SystemExit(1)


@datalake.command(name="check-sql")
@click.option("--file", "sql_file", default="", help="File containing the SQL.")
@click.option("--sql", default="", help="SQL text.")
@click.option("--verbose", is_flag=True, default=False,
              help="Also show what the diagnosis was resolved against (column-set size, connected integrations).")
@click.pass_context
def datalake_check_sql(ctx, sql_file, sql, verbose):
    """Diagnose every column a SQL file reads — without a repo checkout.

    ⚠️ Closes a REAL, pre-existing parity gap: the reachability gate is run as
    `python <skill-path>/scripts/reachability_gate.py`, which nobody without the
    source tree can do. This verb makes the same diagnosis reachable from a
    terminal against production (constraint C2).

    ⛔ It parses column references locally and calls the § 3.4.0 supply API for
    the verdicts — it does NOT vendor a copy of the gate.

    \b
    Examples:
      torana datalake check-sql --file widget.sql
      torana datalake check-sql --sql "SELECT cve_id FROM vulnerabilities"
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    if bool(sql_file) == bool(sql):
        click.echo("ERROR: pass exactly one of --file or --sql.", err=True)
        raise SystemExit(2)
    if sql_file:
        try:
            with open(sql_file, "r", encoding="utf-8") as fh:
                sql = fh.read()
        except OSError as e:
            click.echo(f"ERROR: cannot read {sql_file}: {e}", err=True)
            raise SystemExit(2)

    refs = _extract_column_refs(sql)
    if not refs:
        click.echo("No table-qualified column references found. "
                   "This verb resolves `alias.column` references against the tables "
                   "in the query's FROM/JOIN clauses.", err=True)
        raise SystemExit(2)

    client = _client(ctx)
    try:
        data = client.get("datalake/supply/diagnosis",
                          params={"columns": ",".join(f"{t}.{c}" for t, c in refs)})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
        return
    click.echo(f"\n{len(refs)} column reference(s) resolved from the SQL:")
    _render_diagnosis(data, verbose=verbose)


#: SQL keywords that can follow a table name in FROM/JOIN and must never be
#: mistaken for an alias.
_NOT_AN_ALIAS = {
    "on", "where", "group", "order", "having", "limit", "join", "inner", "left",
    "right", "full", "outer", "cross", "union", "select", "using", "and", "or",
    "qualify", "window", "offset", "fetch",
}


def _extract_column_refs(sql: str):
    """Resolve `alias.column` references to `(table, column)` pairs.

    ⚠️ DELIBERATELY CONSERVATIVE, and the conservatism is the design. This is a
    regex pass, not a parser — it runs where `sqlglot` may not be installed, so
    it resolves only what it can prove:

      * a qualifier that maps to a real table via a FROM/JOIN alias, or
      * a qualifier that IS a table name.

    Anything else is SKIPPED rather than guessed. ⛔ An unqualified column
    silently attributed to the wrong table would produce a confident, wrong
    verdict about a column the query never reads — worse than reporting nothing,
    because nobody investigates a confident answer. The authoring-time gate
    (which does have a parser) is the surface that resolves unqualified names.
    """
    text = re.sub(r"--[^\n]*", " ", sql)
    text = re.sub(r"/\*.*?\*/", " ", text, flags=re.S)

    aliases = {}
    tables = set()
    for m in re.finditer(r"\b(?:from|join)\s+([a-zA-Z_][\w]*)\s*(?:as\s+)?([a-zA-Z_][\w]*)?",
                         text, flags=re.I):
        table = m.group(1).lower()
        alias = (m.group(2) or "").lower()
        tables.add(table)
        aliases[table] = table
        if alias and alias not in _NOT_AN_ALIAS:
            aliases[alias] = table

    seen, out = set(), []
    for m in re.finditer(r"\b([a-zA-Z_][\w]*)\.([a-zA-Z_][\w]*)\b", text):
        qual, col = m.group(1).lower(), m.group(2).lower()
        table = aliases.get(qual)
        if not table:
            continue          # unresolvable qualifier — skip, never guess
        key = (table, col)
        if key not in seen:
            seen.add(key)
            out.append(key)
    return out


# ⛔ SURFACE PARITY — `torana datalake transformers health <id>`.
from torana_cli.supply_health import health_command  # noqa: E402
datalake_transformers.add_command(health_command("transformer"))


# ---------------------------------------------------------------------------
# ⛔ SURFACE PARITY (S17 § 7B.5) — schema version + live data migration.
#
# The root CLAUDE.md rule: every capability is reachable from the API, the CLI and
# the FE, and the three ship together. These mirror
#   POST /internal/tenants/{id}/migrate-data
#   GET  /internal/tenants/{id}/migration-status
# and the SA administration FE surface.
#
# Grouped under `torana datalake schema ...` rather than added as loose top-level
# verbs — the house rule is that new commands live under a semantic parent.
# ---------------------------------------------------------------------------


class _SchemaGroup(click.Group):
    """`schema` used to take a table positionally (`datalake schema <table>`).

    It is a group now, so the old form fails with `No such command '<table>'` — an
    error that reads as a MISSING TABLE rather than a moved verb, sending the reader
    to look for the table instead of the new spelling. Name the replacement instead.
    """

    def resolve_command(self, ctx, args):
        try:
            return super().resolve_command(ctx, args)
        except click.UsageError:
            name = args[0] if args else ""
            if name and not name.startswith("-") and name not in self.commands:
                ctx.fail(
                    f"No such command '{name}'.\n"
                    f"`datalake schema` is a command group now — it no longer takes a "
                    f"table positionally.\n"
                    f"Did you mean:  torana datalake schema table {name}\n"
                    f"           or: torana datalake schema shape --tables {name}"
                )
            raise


@datalake.group(name="schema", cls=_SchemaGroup)
def datalake_schema():
    """The datalake schema: its SHAPE, its version, and whether it is described accurately.

    ⛔ Declared ONCE. This group previously existed TWICE under the same function name;
    Python rebound the name and Click only ever saw the last one, so four commands were
    silently unreachable. Add commands here — never re-declare the group.

    \b
      torana datalake schema audit               is every surface DESCRIBING it accurate?
      torana datalake schema shape               live (table, column) -> data_type
      torana datalake schema revision            current DDL head revision
      torana datalake schema status              this tenant's revision + pending work
      torana datalake schema migrate-data        apply pending DATA migrations
      torana datalake schema drift               every tenant's state (super-admin)

    Data migrations are NOT applied at service startup — a backfill inside a
    multi-worker boot is unsafe. They run via the migration container on a rebuild,
    or here, deliberately, against a live tenant.
    """


def _resolve_tenant_id(ctx, tenant_id):
    """Explicit --tenant-id, else the profile's own tenant from `auth me`."""
    if tenant_id:
        return tenant_id
    client = _client(ctx)
    try:
        # Bare path — the client resolves the service, same as `torana auth me`.
        me = client.get("auth/me")
    except Exception:
        return None
    return (me or {}).get("tenant_id")


@datalake_schema.command(name="status")
@click.option("--tenant-id", default=None,
              help="Tenant to inspect. Defaults to the profile's own tenant.")
@click.pass_context
def datalake_schema_status(ctx, tenant_id):
    """Show this tenant's schema revision and any pending data migrations.

    `data_pending: true` means the schema (DDL) is current but a DATA migration has
    not run — the state a plain service restart deliberately leaves behind.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    tid = _resolve_tenant_id(ctx, tenant_id)
    if not tid:
        click.echo("Could not resolve a tenant id. Pass --tenant-id.", err=True)
        raise SystemExit(2)

    client = _client(ctx)
    try:
        data = client.get(f"datalake/tenants/{tid}/migration-status")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt, fields=fields)


@datalake_schema.command(name="migrate-data")
@click.option("--tenant-id", default=None,
              help="Tenant to migrate. Defaults to the profile's own tenant.")
@click.option("--wait/--no-wait", default=True,
              help="Wait for completion (default) or return a job id immediately.")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation.")
@click.pass_context
def datalake_schema_migrate_data(ctx, tenant_id, wait, yes):
    """Apply pending DATA migrations to a LIVE tenant.

    \b
    A per-schema advisory lock means a second concurrent call is REFUSED (HTTP 409)
    rather than running twice — safe to invoke even if you are unsure whether someone
    else already started one.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    tid = _resolve_tenant_id(ctx, tenant_id)
    if not tid:
        click.echo("Could not resolve a tenant id. Pass --tenant-id.", err=True)
        raise SystemExit(2)

    client = _client(ctx)

    if not yes:
        try:
            status = client.get(f"datalake/tenants/{tid}/migration-status")
            pending = [p.get("revision") for p in status.get("pending_data_revisions", [])]
        except Exception:
            pending = None
        if pending == []:
            click.echo(f"No pending data migrations for tenant {tid}. Nothing to do.")
            return
        if pending:
            click.echo(f"Tenant {tid} has {len(pending)} pending data migration(s):")
            for rev in pending:
                click.echo(f"  {rev}")
            click.echo(
                "\nData migrations rewrite ROWS, not just schema. They are not "
                "automatically reversible."
            )
        _confirm("Run them now?", yes=False)
    try:
        data = client.post(
            f"datalake/tenants/{tid}/migrate-data",
            {},
            params={"wait": "true" if wait else "false"},
        )
    except APIError as e:
        # 409 is the advisory lock refusing a concurrent run — a correct outcome, so
        # report it plainly instead of as an unexpected failure.
        if getattr(e, "status_code", None) == 409:
            click.echo(
                "Refused: a data migration is already running for this tenant "
                "(per-schema advisory lock). Nothing was started."
            )
            raise SystemExit(1)
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt, fields=fields)


@datalake_schema.command(name="drift")
@click.pass_context
def datalake_schema_drift(ctx):
    """Schema state for EVERY tenant (super-admin).

    \b
    States:
      CURRENT       schema exists, at head, no column drift
      MISSING       tenant exists in auth but has NO datalake schema
      DATA_PENDING  DDL applied, data migrations outstanding
      BEHIND        not at the latest revision
      ORPHANED      stamped at a revision this tree does not contain

    Enumerates from pantheon-auth, so a tenant with no schema is REPORTED rather
    than being invisible.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("datalake/schema-drift")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt, fields=fields)
        return

    click.echo(
        f"declared: {data.get('declared_tables')} tables / "
        f"{data.get('declared_columns')} columns   "
        f"ddl head: {data.get('ddl_head')}   from: {data.get('source')}"
    )
    click.echo("-" * 78)
    for t in data.get("tenants", []):
        drift = []
        if t.get("extra_column_count"):
            drift.append(f"+{t['extra_column_count']} cols")
        if t.get("missing_column_count"):
            drift.append(f"-{t['missing_column_count']} cols")
        if t.get("extra_tables"):
            drift.append(f"+{len(t['extra_tables'])} tables")
        if t.get("missing_tables"):
            drift.append(f"-{len(t['missing_tables'])} tables")
        click.echo(
            f"{t.get('state',''):12s} {t.get('schema','')}  rev={t.get('revision')}  "
            f"{t.get('physical_tables')}t/{t.get('physical_columns')}c  "
            f"[{', '.join(drift) if drift else 'matches declared'}]"
        )
        if t.get("pending_data"):
            click.echo(f"             pending data: {', '.join(t['pending_data'])}")
    if data.get("missing_count"):
        click.echo(
            f"\n{data['missing_count']} tenant(s) have NO datalake schema. "
            f"Restart the service or run the migration container to converge them."
        )


# ── S19 row 49 — schema SHAPE + the bundle staleness check ───────────────────────
#
# ⭐ Grouped under `datalake schema` (a semantic parent), never as loose top-level
# verbs: these three answer one question — "what shape does the schema have, and does
# a bundle still fit it?"

# ⛔ MERGED — this was a SECOND `@datalake.group(name="schema")` with the SAME function
# name as the one above. Python rebinds `datalake_schema`, so every command registered on
# the FIRST group (`status`, `migrate-data`, `drift`) attached to an object Click never
# saw, and `datalake schema <table>` (a third definition, a COMMAND, further up) was
# overwritten too. Four commands were silently unreachable; only the last group's
# subcommands worked.
#
# ⚠️ Nothing failed loudly — `torana datalake schema status` printed the GROUP usage, which
# reads like a user error rather than a missing command. Measured 2026-08-18.
#
# The group is now declared ONCE, above. This block only adds commands to it.
def _schema_shape_docs():
    """Inspect the datalake SCHEMA SHAPE and check bundles against it.

    \b
    The SHAPE is what a bundle's SQL depends on: which columns exist and what TYPE
    each one has. A bundle goes stale when that shape changes incompatibly — a
    column it reads is REMOVED, or its type changes in a way that alters meaning
    (`numeric` -> `text` turns `epss_score > 0.6` into a STRING comparison, where
    '0.09' > '0.6' is TRUE, so the query returns wrong rows without failing).

    \b
    Examples:
      torana datalake schema revision
      torana datalake schema shape --tables vulnerabilities

    \b
    To check a BUNDLE against this shape, see `torana build bundles schema-check`
    — it lives with the other bundle verbs rather than here, so bundle operations
    stay in one place.
    """


@datalake_schema.command(name="revision")
@click.pass_context
def datalake_schema_revision(ctx):
    """Show the datalake's current DDL head revision.

    \b
    ⚠️ The revision is a TRIGGER, never a verdict. A version delta alone REPORTS; only
    a broken column REFUSES an install. "Your version is old" is unactionable — the
    refusal has to name a column.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get("/api/v1/datalake/schema/revision")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt == "text":
        rev = data.get("revision")
        click.echo(f"DDL head: {rev or '(none)'}")
        if data.get("is_fixture_revision"):
            click.echo(
                "\n⚠️  This is a FIXTURE revision (S17's demo DDL, guarded to a table no\n"
                "    real tenant has). It is reported, never acted on — no decision binds\n"
                "    to it."
            )
        if not data.get("available"):
            click.echo(f"\nReason: {data.get('reason', 'unavailable')}")
        return
    output(data, fmt=fmt, fields=fields)


@datalake_schema.command(name="shape")
@click.option("--tables", "--table", "tables", default=None,
              help="Comma-separated tables; defaults to the 11 sink tables. "
                   "(`--table` is accepted too, matching `all-columns`.)")
@click.option("--column", default=None, help="Filter to columns whose name contains this.")
@click.pass_context
def datalake_schema_shape(ctx, tables, column):
    """Show the live (table, column) -> data_type shape for your tenant.

    \b
    Examples:
      torana datalake schema shape --tables vulnerabilities
      torana datalake schema shape --tables vulnerabilities --column epss
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    path = "/api/v1/datalake/schema/shape"
    if tables:
        path += f"?tables={tables}"
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    cols = data.get("columns") or []
    if column:
        cols = [c for c in cols if column.lower() in str(c.get("column", "")).lower()]

    if fmt == "text":
        click.echo(f"tables present : {', '.join(data.get('tables_present') or []) or '(none)'}")
        absent = data.get("tables_absent") or []
        if absent:
            click.echo(f"tables ABSENT  : {', '.join(absent)}")
        click.echo(f"columns        : {len(cols)}\n")
        for c in cols:
            click.echo(f"  {c['table']:<20} {c['column']:<40} {c['data_type']}")
        return
    output({**data, "columns": cols}, fmt=fmt, fields=fields)


# ⚠️ `torana datalake schema` is DEFINED TWICE in this module (the earlier group at
# "Schema version and migrations" is shadowed by the later "schema SHAPE" one, so
# `schema status` / `migrate-data` / `drift` are currently unreachable). This command
# is attached to the SURVIVING group deliberately. Merging the two groups is a
# separate change with its own blast radius and is NOT done here.
@datalake_schema.command(name="audit")
@click.option("--include-by-design", is_flag=True, default=False,
              help="Also list findings classified `by_design` (the 9 injected system "
                   "fields). Off by default so the output is the ANSWER, not a list "
                   "the reader has to filter.")
@click.option("--direction", default=None,
              type=click.Choice(["describes_but_absent", "present_but_undescribed"]),
              help="Filter to ONE reconciliation direction.")
@click.option("--surface", default=None,
              help="Filter to one surface (write_seam, semantic_overlay, live_db).")
@click.pass_context
def datalake_schema_audit(ctx, include_by_design, direction, surface):
    """⭐ Reconcile every surface that DESCRIBES the schema against the schema.

    ⛔ EXITS NON-ZERO on drift, so it is usable as a standing check. That is the
    whole point: the last cleanup left residue precisely because nothing re-ran
    afterwards, and a report nobody executes is the failure mode, not the fix.

    \b
    Reconciles BOTH directions — one alone hides half the drift:
      describes-but-absent      a surface names a column the schema does not have
      present-but-undescribed   the live DB has a column no surface declares

    \b
    Verdicts:
      drift             a real disagreement. Fix it.
      archived_residue  described/present, but ARCHIVED in the § 1.3 collapse.
                        ⛔ Resolution is always REMOVAL — never re-add it.
      known_owed        declared, no writer, and the owed writer is NAMED.
                        Still fails: debt stays visible until it is paid.
      by_design         system fields injected per-table. Never drift.

    \b
    ⚠️ Reports at PLATFORM scope. At tenant scope ~126 columns are legitimately
    unwritable because this tenant has not connected the integration that writes
    them (`connectable` — a config gap, not drift). Reporting those would be ~126
    false positives on every run and the check would be ignored inside a week.

    \b
    Examples:
      torana datalake schema audit
      torana datalake schema audit --direction present_but_undescribed
      torana datalake schema audit --format json | jq '.findings[] | select(.verdict=="drift")'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    path = "/api/v1/datalake/schema/audit"
    if include_by_design:
        path += "?include_by_design=true"
    try:
        data = client.get(path)
    except APIError as e:
        # ⛔ EXIT NON-ZERO. A standing check that cannot RUN must not look like a
        # standing check that PASSED — `handle_api_error` prints and returns, which
        # would exit 0 and let CI go green on a 503. "Could not verify" is a
        # failure, and the backend deliberately 503s rather than guessing (an
        # unavailable writer map would libel written columns as unwritten).
        handle_api_error(e)
        ctx.exit(2)
        return
    except AuthError as e:
        handle_auth_error(e)
        ctx.exit(2)
        return

    findings = data.get("findings") or []
    if direction:
        findings = [f for f in findings if f.get("direction") == direction]
    if surface:
        findings = [f for f in findings if surface in str(f.get("surface", ""))]

    if fmt != "text":
        output({**data, "findings": findings}, fmt=fmt, fields=fields)
    else:
        counts = data.get("counts") or {}
        click.echo(f"scope              : {data.get('scope')}")
        click.echo(f"declared columns   : {counts.get('declared_columns')}")
        click.echo(f"platform-reachable : {counts.get('reachable_platform')}")
        click.echo(f"surfaces reconciled: {len(data.get('surfaces_reconciled') or [])}")
        for s in data.get("surfaces_reconciled") or []:
            click.echo(f"    - {s}")
        if not data.get("live_schema_read"):
            # ⚠️ Degrade LOUDLY. Without the live read the audit cannot see a column
            # that exists only in the DB — which is exactly how `severity_score`
            # survived its own removal for five days.
            click.echo(f"\n⚠️  LIVE SCHEMA NOT READ — the present-but-undescribed "
                       f"direction was NOT checked.\n    {data.get('live_schema_error')}",
                       err=True)
        click.echo("")
        if not findings:
            click.echo("✅ no findings — every described surface agrees with the schema.")
        for f in findings:
            click.echo(f"  [{f.get('verdict'):17}] {f.get('table')}.{f.get('column')}")
            click.echo(f"      surface  : {f.get('surface')}  ({f.get('direction')})")
            click.echo(f"      {f.get('detail')}")
        click.echo("")
        click.echo(f"  {'DRIFT (fails)':22} {data.get('drift_total')}")
        click.echo(f"  {'  of which NEW':22} {data.get('new_drift_total')}")
        click.echo(f"  {'  of which known-owed':22} {data.get('known_owed_total')}")

    # ⛔ EXIT NON-ZERO ON DRIFT — the deliverable. Mirrors
    # `entity-graph contract violations`.
    #
    # ⚠️ The status reflects WHAT WAS ASKED FOR, not the standing baseline: filtering
    # to a clean direction must not exit 1 while printing nothing wrong. A command
    # that fails while showing nothing wrong teaches people to ignore its exit code,
    # which is the one thing a standing check cannot survive.
    drifting = [f for f in findings if f.get("verdict") != "by_design"]
    if drifting:
        new = sum(1 for f in drifting if f.get("verdict") != "known_owed")
        owed = len(drifting) - new
        msg = f"\n⛔ {len(drifting)} schema drift finding(s)"
        if owed:
            msg += f" — {new} new, {owed} known-owed (named writer outstanding)"
        click.echo(msg + ".", err=True)
        ctx.exit(1)


@datalake_schema.command(name="semantics")
@click.option("--table", default=None,
              help="Restrict the report to ONE sink table.")
@click.option("--failing", is_flag=True, default=False,
              help="List every column that fails the Q1-Q6 quality bar, plus the "
                   "cross-table name collisions. Off by default so the output is the "
                   "ANSWER (the metrics), not a list the reader has to aggregate.")
@click.pass_context
def datalake_schema_semantics(ctx, table, failing):
    """⭐ Can a machine author UNDERSTAND each column? (descriptions, collisions, domains)

    ⛔ The sibling `schema audit` reconciles column PRESENCE — does every surface agree
    this column exists? This asks the orthogonal question: does the author know what
    the column MEANS? A wrong column name errors in seconds; a wrong MEANING deploys,
    runs green, and lies.

    \b
    The quality bar (Q1-Q6), all script-checkable:
      Q1  >= 40 characters                   below this it is a restatement
      Q2  not a restatement of the name      "the asset name" adds nothing
      Q3  carries >= 1 new token             forces new information
      Q4  a COLLISION column states its      the rule that fixes `asset_name`
          grain, or draws a contrast          on `assets` vs `findings`
      Q5  does not enumerate its domain      the domain is the authority
      Q6  no vendor name on a neutral column

    \b
    ⚠️ Q1-Q6 catch BAD descriptions; they cannot certify good ones. A fluent, wrong
    sentence passes all six — measured error rate on a 10% human sample was 5.6%.

    \b
    ⚠️ Collisions do NOT go to zero, and should not. A collision is a name whose
    descriptions differ across tables; for a DISTINCT_GRAIN column they SHOULD differ
    (`assets.asset_name` is not `findings.asset_name`). The metric driven to zero is
    `quality_fail`. Verdicts live in docs/corpus/schema_collisions.csv.

    \b
    ⛔ The two live metrics are NOT served here. They need a SELECT DISTINCT per
    candidate column, so they are reported as `null` — which means NOT MEASURED and
    must never be read as zero.

    \b
    Examples:
      torana datalake schema semantics
      torana datalake schema semantics --table findings --failing
      torana datalake schema semantics --format json | jq '.counts'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    path = "/api/v1/datalake/schema/semantics"
    params = []
    if table:
        params.append(f"table={table}")
    if failing:
        params.append("failing=true")
    if params:
        path += "?" + "&".join(params)
    try:
        data = client.get(path)
    except APIError as e:
        # ⛔ EXIT NON-ZERO, same discipline as `schema audit`: a check that cannot RUN
        # must never be indistinguishable from a check that PASSED.
        handle_api_error(e)
        ctx.exit(2)
        return
    except AuthError as e:
        handle_auth_error(e)
        ctx.exit(2)
        return

    if fmt != "text":
        output(data, fmt=fmt, fields=fields)
    else:
        counts = data.get("counts") or {}
        click.echo(f"scope     : {data.get('scope')}")
        click.echo(f"{'table':18}{'cols':>6}{'desc':>6}{'miss':>6}{'thin':>6}")
        for t, v in sorted((data.get("tables") or {}).items()):
            click.echo(f"{t:18}{v['columns']:6}{v['described']:6}"
                       f"{v['missing']:6}{v['thin']:6}")
        click.echo("-" * 42)
        click.echo(f"  described               {counts.get('described')} / {counts.get('columns')}")
        click.echo(f"  missing                 {counts.get('missing')}")
        click.echo(f"  thin (<40 chars)        {counts.get('thin')}")
        click.echo(f"  quality_fail (Q1-Q6)    {counts.get('quality_fail')}")
        click.echo(f"  collisions              {counts.get('collisions')}")
        click.echo(f"  domains_declared        {counts.get('domains_declared')}")
        click.echo("  domain_candidates       null  (live-only; run with --live)")
        click.echo("  domain_conformance_fail null  (live-only; run with --live)")
        for t, err in (data.get("table_errors") or {}).items():
            # ⛔ A table that failed to load is reported, never counted as 0 —
            # a dropped table reading as "perfect" is the failure this guards.
            click.echo(f"⛔ TABLE ERROR {t}: {err}", err=True)
        if failing:
            fails = data.get("quality_failures") or []
            if fails:
                click.echo(f"\nQuality failures ({len(fails)}):")
                for f in fails:
                    click.echo(f"  {f['table']}.{f['column']:34} {f['rule']}  {f['detail']}")
            cols = data.get("collisions") or []
            if cols:
                click.echo(f"\nCollisions ({len(cols)}) — verdicts in "
                           f"docs/corpus/schema_collisions.csv:")
                for c in cols:
                    click.echo(f"  {c['column']:30} {' '.join(c['tables'])}")

    if not data.get("ok"):
        click.echo("\n⛔ schema semantics gate FAILED "
                   "(missing/thin/quality_fail is non-zero).", err=True)
        ctx.exit(1)


# ── Late registration (§ 4.7 follow-up) ────────────────────────────────────────────────
# `tables_schema` is declared far above, before `datalake_schema` exists, so it cannot use
# `@datalake_schema.command(...)` as a decorator. Attaching it here is the fix for the
# three-way name collision that made four commands unreachable.
#
# ⚠️ Registered as `schema table <TABLE>`, NOT `schema <TABLE>`: a bare argument on a group
# is ambiguous with its subcommand names — `schema audit` would be indistinguishable from a
# table literally named "audit".
datalake_schema.add_command(tables_schema)

@datalake_schema.command(name="transformers")
@click.option("--table", "tables", multiple=True,
              help="Only these transformer tables (repeatable).")
@click.option("--columns", "columns_glob", default=None,
              help="Only columns matching these comma-separated globs.")
@click.option("--detail", default="full",
              type=click.Choice(["terse", "compact", "full"]),
              help="Column render level.")
@click.pass_context
def datalake_schema_transformers(ctx, tables, columns_glob, detail):
    """The tenant's TRANSFORMER output tables — a SEPARATE schema from the sinks.

    \b
    ⛔ TWO DIFFERENT SCHEMAS, AND CONFLATING THEM IS THE POINT OF SPLITTING THEM:
      sink tables         the 11 canonical tables integrations write into.
                          Platform-declared, identical for every tenant.
      transformer tables  DERIVED outputs a tenant's own dbt models build ON TOP
                          of the sinks. Per-tenant, and they come and go as
                          programs are built and retired.

    \b
    ⚠️ A transformer column has NO WRITER in the reachability sense — nothing in
    the ETL writes it, a MODEL computes it. So `schema table <t> --writers` does
    not apply here, and a "nothing writes this" verdict against a transformer
    column would be meaningless rather than a defect.

    \b
    ⭐ AUTHORING SQL? Prefer the SINK tables. A transformer table exists because
    one tenant's program built it; SQL written against it is not portable to a
    tenant that never built that program. `datalake schema table <t>` is the
    portable surface.

    \b
    Examples:
      torana datalake schema transformers
      torana datalake schema transformers --table vm_open_findings
      torana datalake schema transformers --columns '*severity*'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("/tables/schema",
                          params={"detail": detail, "include_transformers": "true"})
        # ⛔ DERIVE the sink set from the server, never hardcode it. The payload
        # carries `transformer_count` but no canonical NAME list, and a
        # hand-written sink list disagreed with the server immediately — it
        # scored 20 transformer tables where the server said 18. Asking the same
        # endpoint with transformers OFF gives the authoritative sink names.
        sinks = client.get("/tables/schema",
                           params={"detail": "terse", "include_transformers": "false"})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    all_tables = (data or {}).get("tables") or {}
    canonical = set((sinks or {}).get("tables") or {})
    keep = {t: v for t, v in all_tables.items() if t not in canonical}
    if tables:
        want = {t.lower() for t in tables}
        keep = {t: v for t, v in keep.items() if t.lower() in want}
    data = dict(data or {})
    data["tables"] = keep
    data["transformer_tables"] = sorted(keep)

    if columns_glob:
        data = _filter_schema_columns(data, columns_glob)

    if fmt == "text":
        if not keep:
            click.echo("\n  No transformer tables for this tenant.")
            click.echo("  ⚠️ That is a normal state, NOT an error — it means no "
                       "program has built one yet.\n")
            return
        # ⚠️ TWO SHAPES from this endpoint. A transformer table nests its columns
        # under a `columns` key ({primary_key, columns:{...}}); a sink table is
        # the flat {column: meta} map. Reading the outer dict blindly prints the
        # METADATA KEYS (`columns`, `primary_key`, `value_domains`) as if they
        # were columns — 3 "columns" for a table that has 3 real ones, which
        # looks plausible and is entirely wrong.
        def _cols(v):
            if isinstance(v, dict) and isinstance(v.get("columns"), dict):
                return v["columns"]
            return v if isinstance(v, dict) else {}

        total = sum(len(_cols(v)) for v in keep.values())
        click.echo(f"\n  {len(keep)} transformer tables, {total} columns.")
        click.echo("  ⚠️ DERIVED outputs, built by this tenant's own models — NOT "
                   "the platform sink schema.\n     They are per-tenant and may "
                   "not exist elsewhere; prefer sink tables for portable SQL.\n")
        for t in sorted(keep):
            cols = _cols(keep[t])
            click.echo(f"  {t}  ({len(cols)} columns)")
            width = max((len(c) for c in cols), default=10)
            for c in sorted(cols):
                meta = cols[c]
                dt = meta.get("data_type") if isinstance(meta, dict) else meta
                click.echo(f"    {c.ljust(width)}  {dt}")
            click.echo()
        return

    output(data, fmt=fmt, fields=fields)



