"""torana version — build identity for the CLI and the services it talks to.

⛔ WHY THIS COMMAND IS LOAD-BEARING, not cosmetic (CLI-44 / CLI-51 / CLI-52).

Three filed defects are one defect with three faces: **nothing tells you which build
you are running, or which build answered you.**

  * CLI-44 — `--version` reported `0.1.2` for builds with materially DIFFERENT command
    surfaces. A test engineer and a test architect verified the same command on two
    `0.1.2` builds and reached OPPOSITE conclusions; the engineer's sweep concluded a
    WORKING capability was a missing surface. Establishing what was actually installed
    required hashing the wheel by hand.
  * CLI-51 — a 404 from a STALE DEPLOYMENT is byte-identical to a 404 from a capability
    that was never built. A checkout 31 commits behind produced three wrong findings
    (CLI-42, CLI-43 and a test-plan blocker), all filed against routes that worked
    upstream.
  * CLI-52 — the wheels in `dist/` lag their source with no marker, so the documented
    setup path installs a build that cannot run current work. It cost a full test-plan
    run and generated false findings in BOTH directions.

The common cause is that a VERSION STRING cannot distinguish two builds. A COMMIT can.
So every surface here reports the commit, and says plainly when it cannot.
"""

import click

from torana_cli import __version__, __commit_sha__, __dirty__, __built_at__
from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FORMAT, CTX_PROFILE

#: Per-service version endpoints, as ACTUALLY routed by nginx.
#:
#: ⛔ THE PATH SHAPE IS `/api/v1/version/<service>`, NOT `/api/v1/<service>/version`.
#: This map previously held the inverted form for all ten services, so EVERY entry 404'd
#: and `torana version --services` reported `unavailable` for the entire platform —
#: measured 2026-08-14, 10 of 10. That is the CLI-51 failure mode occurring inside the
#: very command meant to diagnose it: a caller could not tell "the service is down" from
#: "the CLI asked the wrong URL", and the command silently answered the second question
#: while looking like it answered the first.
#:
#: ⚠️ Verify against nginx, never against intuition:
#:     grep -oE '\\^/api/v1/version/[a-z-]+' \
#:       pantheon-deploy/config/localhost/nginx/conf/localhost.conf
SERVICE_VERSION_PATHS = {
    "auth": "/api/v1/version/auth",
    "admin": "/api/v1/version/admin",
    "detection": "/api/v1/version/detection",
    "program": "/api/v1/version/program",
    "workflow": "/api/v1/version/workflow",
    "integration": "/api/v1/version/integration",
    "datalake": "/api/v1/version/datalake",
    "transformers": "/api/v1/version/transformers",
    "agent-builder": "/api/v1/version/agent-builder",
    "viz": "/api/v1/version/viz",
    "rag": "/api/v1/version/rag",
    "playground": "/api/v1/version/playground",
}


def _short(sha) -> str:
    """First 8 chars of a commit SHA — enough to identify a build, short enough to read."""
    s = str(sha or "").strip()
    return s[:8] if s and s != "unknown" else "unknown"


def cli_build_identity() -> dict:
    """This CLI's build identity. Shared with the skill bootstrap's surface check."""
    return {
        "version": __version__,
        "commit": __commit_sha__,
        "commit_short": _short(__commit_sha__),
        "dirty": bool(__dirty__),
        "built_at": __built_at__,
    }


def source_staleness() -> dict:
    """Compare the INSTALLED build against the pantheon-cli source tree, when reachable.

    ⭐ THIS IS THE CLI-52 SIGNAL. Its whole complaint is *"the wheels are stale against
    source, and NOTHING SIGNALS IT."* A staleness field that is merely available is not a
    signal; this is printed unprompted by the default `torana version`.

    Returns a dict with `checked` False whenever the source tree is not reachable (an
    installed-from-wheel user, an operator on a box with no checkout). ⚠️ Not-checked is
    reported as UNKNOWN, never as up-to-date — claiming currency we did not verify is the
    same false-confidence this command exists to remove.
    """
    import subprocess
    from pathlib import Path

    out = {"checked": False, "reason": "", "stale": None, "commits_behind": None,
           "source_commit": None}

    installed = str(__commit_sha__ or "").strip()
    if not installed or installed == "unknown":
        out["reason"] = "installed build carries no commit stamp (built before CLI-44)"
        return out

    # Walk up from this file looking for the pantheon-cli checkout this package came from.
    # An editable install lands inside the repo; a wheel install does not, and that is a
    # normal, expected outcome rather than an error.
    here = Path(__file__).resolve()
    repo = None
    for parent in here.parents:
        if (parent / ".git").exists() and (parent / "torana_cli").is_dir():
            repo = parent
            break
    if repo is None:
        out["reason"] = "no pantheon-cli source checkout alongside the installed package"
        return out

    def _git(*args):
        return subprocess.run(["git", "-C", str(repo), *args],
                              capture_output=True, text=True, timeout=10)

    try:
        head = _git("rev-parse", "HEAD")
        if head.returncode != 0:
            out["reason"] = "source checkout is not a readable git repo"
            return out
        source_commit = head.stdout.strip()
        out["source_commit"] = source_commit
        out["source_commit_short"] = _short(source_commit)

        if source_commit == installed:
            out.update(checked=True, stale=False, commits_behind=0)
            return out

        # Is the installed build an ANCESTOR of source HEAD? If so we can count exactly
        # how far behind it is. If not, the two have diverged (installed from a different
        # branch) — still stale-worthy, but the count is meaningless, so we don't invent one.
        anc = _git("merge-base", "--is-ancestor", installed, "HEAD")
        if anc.returncode == 0:
            cnt = _git("rev-list", "--count", f"{installed}..HEAD")
            behind = int(cnt.stdout.strip()) if cnt.returncode == 0 and cnt.stdout.strip() else None
            out.update(checked=True, stale=True, commits_behind=behind)
        else:
            out.update(checked=True, stale=True, commits_behind=None,
                       reason="installed build is not an ancestor of source HEAD "
                              "(different branch or rebased)")
        return out
    except (subprocess.SubprocessError, OSError, ValueError) as exc:
        out["reason"] = f"staleness check failed: {type(exc).__name__}: {exc}"
        return out


@click.command(name="version")
@click.option("--services", is_flag=True, default=False,
              help="Also fetch build identity from every backend service.")
@click.pass_context
def version(ctx, services):
    """Show CLI build identity (version + commit) and optionally service builds.

    \b
    Examples:
      torana version
      torana version --services
      torana version --services --format json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    build = cli_build_identity()
    staleness = source_staleness()

    data = {
        "cli": build["version"],
        "commit": build["commit"],
        "dirty": build["dirty"],
        "built_at": build["built_at"],
        "base_url": settings.base_url,
        "source_staleness": staleness,
    }

    if services:
        client = ToranaClient(base_url=settings.base_url)
        versions = {}
        for svc, path in SERVICE_VERSION_PATHS.items():
            try:
                resp = client.get(path)
                # pantheon-shared's version_router answers {"status", "data": {...}}.
                payload = resp.get("data", resp) if isinstance(resp, dict) else {}
                versions[svc] = {
                    "version": payload.get("version", "unknown"),
                    "commit": payload.get("service_commit_sha", "unknown"),
                    "commit_short": _short(payload.get("service_commit_sha")),
                    "branch": payload.get("service_branch"),
                    "dirty": payload.get("service_dirty"),
                }
            except (APIError, AuthError, Exception) as exc:
                # ⚠️ Say WHY it is unavailable. A bare "unavailable" is the same
                # undiagnosable answer CLI-51 is about — the caller cannot tell a
                # down service from an unroutable path.
                versions[svc] = {"version": "unavailable",
                                 "error": f"{type(exc).__name__}: {exc}"[:120]}
        data["services"] = versions

    if fmt == "json":
        import json
        click.echo(json.dumps(data, indent=2))
        return
    if fmt == "yaml":
        import yaml
        click.echo(yaml.dump(data, sort_keys=False))
        return

    dirty_note = "  ⚠️ DIRTY (uncommitted changes at build time)" if build["dirty"] else ""
    click.echo(f"torana CLI {build['version']}")
    click.echo(f"  commit    {build['commit_short']}{dirty_note}")
    click.echo(f"  built     {build['built_at']}")
    click.echo(f"  base URL  {settings.base_url}")

    # CLI-52: staleness is REPORTED, never silent.
    if staleness.get("checked") and staleness.get("stale"):
        behind = staleness.get("commits_behind")
        how_far = f"{behind} commit(s) behind" if behind else "diverged from"
        click.echo("")
        click.echo(f"  ⚠️ STALE BUILD — installed CLI is {how_far} the source tree "
                   f"({staleness.get('source_commit_short', '?')}).")
        click.echo("     A command that appears missing may simply be absent from THIS "
                   "build.")
        click.echo("     Rebuild:  $TORANA_ROOT/pantheon-deploy/scripts/update-dist.sh")
    elif staleness.get("checked"):
        click.echo("  source    up to date with the local checkout")
    else:
        click.echo(f"  source    not checked ({staleness.get('reason', 'unknown')})")

    if "services" in data:
        click.echo("\nService builds:")
        for svc, info in data["services"].items():
            if info.get("version") == "unavailable":
                click.echo(f"  {svc.ljust(16)} unavailable")
            else:
                d = " (dirty)" if info.get("dirty") else ""
                br = f" [{info['branch']}]" if info.get("branch") else ""
                click.echo(f"  {svc.ljust(16)} {str(info['version']).ljust(8)} "
                           f"{info['commit_short']}{d}{br}")
