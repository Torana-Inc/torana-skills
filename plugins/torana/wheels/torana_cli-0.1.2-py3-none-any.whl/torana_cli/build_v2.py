"""torana build — the build_v2 cooking subsystem CLI (Spec A § 3.4.3).

The driver-agnostic surface: every build_v2 API capability has a CLI command here, so an
external driver (a Claude skill, CI, or a human) can step the same proposal/artifact
state machine that the VM Expert v2 agent drives — `torana build proposal <id> …`.

Two entry points, **verb-for-verb identical** instance surfaces:
  - top-level singular group (workspace-agnostic — the proposal id resolves the workspace
    server-side):
      torana build proposal <ID> show | status | provenance | lifecycle | cookable
      torana build proposal <ID> blueprint start|save|approve|show|run
      torana build proposal <ID> cook start|run|finalize
      torana build proposal <ID> artifact add|validate|edit
      torana build proposal <ID> deploy | deploy-status
  - workspace-scoped mirror (registered onto `workspace` via `register_workspace_build_v2()`):
      torana workspace <WS> build proposals list
      torana workspace <WS> build proposals create --intent … --title …
      torana workspace <WS> build proposals from-system <SYSTEM_PROPOSAL_ID>
      torana workspace <WS> build proposal <ID> show | status | … (full verb set)

Both instance groups share ONE set of `_core` routines (below) so the two surfaces can
never drift — the workspace-scoped verbs delegate to exactly the same endpoints as the
top-level ones. The only endpoint that needs the workspace id is `cookable`; every other
instance verb keys off the proposal id alone.

The mandatory build path (INDEX #19): intent → blueprint start → blueprint save →
blueprint approve → cook start → artifact add (with --source-step) → validate →
cook finalize → deploy. There is no intent→cook bypass.
"""

import json
import sys

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE
from torana_cli.output import output
from torana_cli.confirm import confirm as _confirm

_PROPOSAL_COLS = [
    ("id", "ID", 36),
    ("title", "TITLE", 40),
    ("kind", "KIND", 8),
    ("state", "STATE", 12),
    ("version", "VERSION", 12),
    ("action", "ACTION", 14),
]


def _anchor_cell(item) -> str:
    """Compact app-version anchor for the proposals-list VERSION column: 'v2' once deployed,
    'v1→v2' predicted (anchored on v1, deploys as v2), '→v2' predicted-genesis, else '—'.
    A STALE candidate (anchored behind current live — must re-anchor before deploy) is marked
    with a '!' after the anchored-on version, e.g. 'v1!→v2' (BUILD_V2_ANCHOR_STALENESS_GATE_SPEC
    § 3.4.4). The '!' is a non-colour cue so it reads on any terminal."""
    a = item.get("version_anchor") if isinstance(item, dict) else None
    if not isinstance(a, dict) or not a:
        return "—"
    if a.get("status") == "deployed" and a.get("version_number") is not None:
        return f"v{a.get('version_number')}"
    da = a.get("deploys_as_version")
    if da is not None:
        on = a.get("anchored_on_version")
        stale = "!" if a.get("is_stale") else ""
        return f"v{on}{stale}→v{da}" if on is not None else f"→v{da}"
    return "—"

_ARTIFACT_STATUS_COLS = [
    ("artifact_key", "KEY", 24), ("artifact_type", "TYPE", 14),
    ("state", "STATE", 12), ("rejection_reason", "REASON", 40),
]

_DEPLOY_STATUS_COLS = [
    ("artifact_key", "KEY", 24), ("artifact_type", "TYPE", 14),
    ("state", "STATE", 12), ("deployed_artifact_id", "DEPLOYED_ID", 36),
    # WHY the artifact is in that state. The server has always returned
    # `rejection_reason` (+ a `validation` dict) on every artifact, but this column
    # set dropped both — so a failed deploy rendered as a bare `validated`/
    # `rolled_back` row with no reason, and the only way to learn the cause was
    # raw service logs (impossible for a customer/skill). See CLI-22.
    ("reason", "REASON", 60),
]

_VERSION_COLS = [
    ("version_number", "VERSION", 8),
    # LIVE vs UNINSTALLED. A word, not a tick or a colour: an uninstalled version stays in the
    # timeline as provenance, and "v4 is still listed" must never be mistaken for "v4 is still
    # installed". Rendered from the server's derived `is_live` so CLI and FE cannot disagree.
    ("live_display", "STATE", 14),
    ("deployed_at", "DEPLOYED_AT", 26),
    ("deployed_by", "DEPLOYED_BY", 22),
    ("artifact_count", "ARTIFACTS", 10),
    ("description", "SUMMARY", 40),
]


def _enrich_versions(data):
    """Add the client-side STATE word to each version row.

    `is_live` arrives as a bool; a bare True/False column would read as a flag whose polarity
    the reader has to remember. LIVE / UNINSTALLED says it outright.
    """
    items = data.get("items") if isinstance(data, dict) else data
    for row in (items or []):
        if isinstance(row, dict):
            row["live_display"] = "LIVE" if row.get("is_live", True) else "UNINSTALLED"
    return data


def _uninstall_core(ctx, workspace_id: str, versions: tuple, dry_run: bool, yes: bool):
    """Shared by the top-level and workspace-scoped `versions uninstall` commands.

    ONE implementation so the two surfaces cannot drift — the same reason
    `reset_cursors_core` is shared between the singular and plural integration forms.
    """
    vlist = sorted(set(int(v) for v in versions))
    # The preview ALWAYS runs, even with --yes: --yes skips the PROMPT, not the preview, so a
    # scripted uninstall still leaves a record of what it removed.
    plan = _call(ctx, "POST",
                 f"workspaces/{workspace_id}/build-v2/versions/uninstall",
                 body={"versions": vlist, "dry_run": True})
    if plan is None:
        return
    _render_uninstall_plan(plan, dry_run=True)
    if dry_run:
        click.echo("  Preview only — nothing was removed. "
                   "Re-run with --no-dry-run to apply.\n")
        return
    if not (plan.get("counts") or {}).get("delete") and not (plan.get("counts") or {}).get("restore"):
        click.echo("  Nothing to remove.\n")
        return
    _confirm(
        f"PERMANENTLY uninstall version(s) {vlist}? The app returns to "
        f"v{plan.get('live_version_after')}. The proposal(s) become TERMINAL — they cannot be "
        f"redeployed, only rebuilt from their intent. This cannot be undone.",
        yes=yes,
    )
    result = _call(ctx, "POST",
                   f"workspaces/{workspace_id}/build-v2/versions/uninstall",
                   body={"versions": vlist, "dry_run": False})
    if result is not None:
        _render_uninstall_plan(result, dry_run=False)


def _render_uninstall_plan(plan: dict, dry_run: bool):
    counts = plan.get("counts") or {}
    head = "WOULD UNINSTALL" if dry_run else "UNINSTALLED"
    click.echo(f"\n{head} — app version(s) {plan.get('versions_requested')}")
    click.echo(f"  live version: v{plan.get('live_version_before')} -> "
               f"v{plan.get('live_version_after')}"
               + ("   (v0 = app alive, no artifacts)"
                  if plan.get("live_version_after") == 0 else ""))
    rows = plan.get("to_delete") or []
    if rows:
        click.echo(f"\n  {'ARTIFACT':<40}{'TYPE':<14}{'SHARED':<8}")
        for r in rows:
            shared = "yes" if r.get("shared_catalog_entry") else "-"
            click.echo(f"  {str(r.get('artifact_key'))[:38]:<40}"
                       f"{str(r.get('artifact_type')):<14}{shared:<8}")
    for r in (plan.get("to_restore") or []):
        click.echo(f"  RESTORE {r.get('artifact_key')} — {r.get('reason')}")
    click.echo(f"\n  total: {counts.get('delete', 0)} to remove, "
               f"{counts.get('restore', 0)} to restore")
    # A SHARED row is refcount-released, never dropped — say so, because "uninstalled 15
    # artifacts" otherwise implies 15 things were destroyed.
    if any(r.get("shared_catalog_entry") for r in rows):
        click.echo("  SHARED rows are refcount-released (torn down only at zero), not deleted.")
    orphans = plan.get("orphans") or []
    if orphans:
        click.echo(f"\n  ⚠ {len(orphans)} downstream item(s) could NOT be removed and need "
                   f"manual cleanup: {', '.join(orphans)}")
    if not dry_run:
        click.echo("  The uninstalled proposal(s) are TERMINAL — rebuild from intent to "
                   "reinstate them.")
    click.echo("")


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    return ToranaClient(base_url=get_settings(profile).base_url)


def _fmt(ctx) -> str:
    return ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"


def _fields(ctx):
    return ctx.obj.get(CTX_FIELDS) if ctx.obj else None


def _wid(ctx) -> str:
    return ctx.obj.get("_workspace_id", "") if ctx.obj else ""


def _pid(ctx) -> str:
    return ctx.obj.get("_bv2_proposal_id", "") if ctx.obj else ""


def _load_definition(definition, definition_file) -> dict:
    """Resolve an artifact definition from --definition JSON or --definition-file."""
    if definition_file:
        with open(definition_file) as fh:
            return json.load(fh)
    if definition:
        return json.loads(definition)
    raise click.UsageError("provide --definition '<json>' or --definition-file <path>")


def _load_semantic_description(semantic_description, semantic_description_file) -> str:
    """Resolve the artifact INTENT from --semantic-description or --semantic-description-file.

    A conforming five-part intent runs ~1,400 characters over multiple lines, which does not
    sit comfortably on a command line — hence the file variant. Returns "" when neither is
    given (the server then derives a rationale from the blueprint step; `_warn_if_not_intent`
    is what makes that visible rather than silent).
    """
    if semantic_description and semantic_description_file:
        raise click.UsageError(
            "pass at most one of --semantic-description / --semantic-description-file.")
    if semantic_description_file:
        with open(semantic_description_file, encoding="utf-8") as fh:
            return fh.read()
    return semantic_description or ""


def _warn_if_not_intent(text: str, artifact_type: str) -> None:
    """⛔ Close the SILENT-DROP class, not just the missing-flag instance.

    S15 row 43. The defect measured in row 40 was not that `--semantic-description` was
    missing — it was that omitting the intent produced a healthy-looking artifact with a
    derived rationale, and NOTHING said so. Adding a flag nobody passes reproduces exactly
    that state, so the absence has to be audible.

    WARN, not reject. `ARTIFACT_INTENT_SPEC.md` § 7.4 is signed off: producers mandatory,
    HUMANS EXEMPT — and `torana build … artifact add` is a human surface as well as the one
    the `torana-vm` skill drives. Refusing here would block the exempt case the sign-off
    deliberately preserved. A warning on stderr keeps exit 0 (so scripts and the skill's own
    flow are unaffected) while making the gap impossible to not see.

    ⚠️ It fires on BOTH failure modes, which is the point:
      * no intent supplied      -> the server will derive one; say so and name check-intent.
      * an intent that does NOT conform -> the more dangerous case. A non-conforming intent
        is ACCEPTED and stored verbatim (the server only checks it traces to its step), so it
        ships looking authored. Naming the missing parts here is the only place that is cheap.
    """
    if not (text or "").strip():
        click.echo(
            "! no --semantic-description given — the server will DERIVE a rationale from the "
            "blueprint step.\n"
            "  A derived rationale is not a regeneration-grade intent and can never be "
            "five-part.\n"
            "  Author one (question / grain / semantics / scope / fallback) and check it with:\n"
            "      torana datalake check-intent --file <intent.txt> "
            f"--artifact-type {artifact_type}",
            err=True)
        return
    try:
        from pantheon_shared.datalake.artifact_intent import validate_intent
    except Exception:  # noqa: BLE001
        # ⛔ Say the check could not run. Silence would read as a pass — the same failure
        # mode `datalake check-intent` guards against.
        click.echo("! could not load the intent rule (pantheon-shared) — the supplied "
                   "semantic_description was NOT checked.", err=True)
        return
    verdict = validate_intent(text, artifact_type=artifact_type)
    if verdict.ok:
        return
    problems = ", ".join(
        [f"missing {p}" for p in verdict.missing] + [f"too short {p}" for p in verdict.too_short])
    click.echo(
        f"! the supplied --semantic-description is NOT a regeneration-grade intent "
        f"({problems or 'see check-intent'}).\n"
        f"  It will be stored as-is and the artifact will look authored. Verify with:\n"
        f"      torana datalake check-intent --file <intent.txt> --artifact-type {artifact_type}",
        err=True)


def _call(ctx, method, path, body=None):
    client = _client(ctx)
    try:
        if method == "GET":
            return client.get(path)
        if method == "POST":
            return client.post(path, json=body or {})
        if method == "PUT":
            return client.put(path, json=body or {})
        if method == "DELETE":
            return client.delete(path)
    except APIError as e:
        handle_api_error(e)
    except AuthError as e:
        handle_auth_error(e)
    return None


def _soft_get(ctx, path):
    """GET that returns None on ANY error and never exits.

    `_call`/`_try_get` route failures through `handle_api_error`, which calls
    `sys.exit`. A preflight must report every check, so one unreachable surface
    cannot be allowed to abort the run before the others are read.
    """
    try:
        return _client(ctx).get(path)
    except (APIError, AuthError):
        return None


def _try_get(ctx, path):
    """GET that returns None on 404 WITHOUT printing an error.

    Needed where a uuid argument is ambiguous (a workspace id and a job id are both uuids and
    cannot be told apart by shape): probe one, fall back to the other, and only report a
    failure once BOTH have missed — never leak the probe's 404 to the user.
    """
    try:
        return _client(ctx).get(path)
    except APIError as e:
        if getattr(e, "status_code", None) == 404:
            return None
        handle_api_error(e)
    except AuthError as e:
        handle_auth_error(e)
    return None


# ═══════════════════════════════════════════════════════════════════════════
# Shared instance-verb cores — the ONE implementation each of the two proposal
# instance groups (top-level `bv2_proposal` and workspace-scoped `ws_bv2_proposal`)
# delegates to, so the two surfaces can never drift. Every core keys off `_pid(ctx)`;
# `cookable` additionally reads `_wid(ctx)`.
# ═══════════════════════════════════════════════════════════════════════════

def _proposal_show_core(ctx):
    # Use the unified /detail (anyDetail) endpoint, not the plain proposal GET, so the payload
    # carries the rich Advisor narrative (`overview`) at EVERY state — mirroring the FE detail
    # page. The build_v2 branch still nests proposal/blueprint/artifacts, so the existing
    # steps/artifacts renderer is unchanged; a bare system (intent_only) row has overview only.
    data = _call(ctx, "GET", f"workspaces/build-v2/proposals/{_pid(ctx)}/detail")
    if data is None:
        return
    # json/yaml → raw dump (unchanged). text → readable state + blueprint⇄cook + artifacts.
    if _fmt(ctx) in ("json", "yaml"):
        # Apply the SAME state fallback the text renderer uses (CLI-16). Previously
        # only `_render_proposal_text` fell back to overview.status, so a payload with
        # a null `proposal.state` rendered fine as text but came out null in --json —
        # two renderers disagreeing about the same field. Fill it in rather than
        # leaving a machine consumer to reimplement the fallback (or trust the null).
        if isinstance(data, dict):
            p = data.get("proposal")
            ov = data.get("overview") or {}
            if isinstance(p, dict) and not p.get("state"):
                fallback = ov.get("status") if isinstance(ov, dict) else None
                if fallback:
                    p["state"] = fallback
        output(data, fmt=_fmt(ctx), fields=_fields(ctx))
        return
    _render_proposal_text(ctx, data)


def _render_proposal_text(ctx, data):
    """Readable proposal view (Spec E § 3.5.3): the rich Intent narrative (Advisor overview) +
    state header + the blueprint plan paired to the cook outcome per step (did each step run?
    validated / running / pending / failed) + artifacts. This is the CLI mirror of the detail
    page. Handles both anyDetail kinds: 'build_v2' (proposal + blueprint + artifacts + overview)
    and 'system' (overview only, intent_only rows not yet built)."""
    data = data if isinstance(data, dict) else {}
    p = data.get("proposal") or {}
    bp = data.get("blueprint") or {}
    arts = data.get("artifacts") or []
    ov = data.get("overview") or {}
    cs = p.get("cook_state") if isinstance(p.get("cook_state"), dict) else {}

    # State header — title/id/state fall back to the overview for a bare system row (no proposal).
    click.echo(f"Proposal : {p.get('title') or ov.get('title') or _pid(ctx)}")
    click.echo(f"  id     : {p.get('id') or _pid(ctx)}")
    click.echo(f"  state  : {p.get('state') or ov.get('status')}"
               f"   blueprint: {p.get('blueprint_state') or 'none'}"
               f" (v{p.get('blueprint_version') or 0})")
    if cs.get("failed_reason"):
        click.echo(f"  note   : {cs.get('failed_reason')}")
    anchor_line = _format_version_anchor(data.get("version_anchor"))
    if anchor_line:
        click.echo(f"  version: {anchor_line}")

    # "What's next" — the verbs legal from THIS state, derived server-side from the one canonical
    # FSM table the guards enforce (so the hint can never disagree with what actually succeeds).
    # Read-only verbs (show/status/lifecycle/…) are always available and omitted here on purpose.
    aa = data.get("allowed_actions") if isinstance(data.get("allowed_actions"), dict) else None
    if aa:
        allowed = aa.get("allowed") or []
        if allowed:
            click.echo("\nNext steps (allowed from this state):")
            for a in allowed:
                click.echo(f"  → {a.get('label') or a.get('verb')}")
        else:
            click.echo("\nNext steps: none at the proposal level — this proposal is "
                       f"'{aa.get('state')}'. Act at the app/version level (deploy a new build).")

    _render_overview_block(ov)
    lease = cs.get("lease") if isinstance(cs.get("lease"), dict) else None
    if lease:
        alive = lease.get("running")
        click.echo(f"  runner : {'ALIVE' if alive else 'idle'}"
                   f"{' (' + str(lease.get('runner_id')) + ')' if lease.get('runner_id') else ''}"
                   f"   heartbeat={lease.get('heartbeat') or '—'}")

    # Pair blueprint steps (the plan) to cook_state steps (the outcome) by step_id.
    bsteps = bp.get("steps") or []
    cook_by_id = {}
    for s in (cs.get("steps") or []):
        if s.get("step_id") is not None:
            cook_by_id[str(s.get("step_id"))] = s
    if bsteps:
        validated = sum(1 for s in bsteps
                        if _cook_status(cook_by_id.get(str(s.get("step_id")))) == "validated")
        click.echo(f"\nSteps ({validated}/{len(bsteps)} validated):")
        _GLYPH = {"validated": "✓", "running": "◐", "failed": "✗", "pending": "○"}
        for i, s in enumerate(bsteps, start=1):
            sid = str(s.get("step_id"))
            c = cook_by_id.get(sid)
            st = _cook_status(c)
            title = (s.get("title") or "").strip()
            at = s.get("artifact_type") or ""
            line = f"  {_GLYPH.get(st, '○')} {i}. [{sid}] {title}  ({at}) — {st}"
            if c and c.get("attempts"):
                line += f", {c.get('attempts')} attempt(s)"
            if c and c.get("artifact_id"):
                line += f", artifact {str(c.get('artifact_id'))[:8]}"
            click.echo(line)
            if c and c.get("reason"):
                click.echo(f"       reason: {c.get('reason')}")
    else:
        click.echo("\nSteps: (no blueprint yet)")

    # Reconciliation against the advisor's "WILL CREATE" promise — what happened to each promised
    # artifact (kept/renamed/dropped) + any grounded additions. Dropped items lead so a promise
    # NOT kept is never silent.
    recon = bp.get("outline_reconciliation") or []
    # `outline_reconciliation` is a LIST OF DICTS when the advisor reconciles a promised
    # outline, but a blueprint authored directly (CLI/skill, no advisor outline to reconcile
    # against) may carry a plain STRING explaining the plan's shape. Rendering that as dicts
    # raised `AttributeError: 'str' object has no attribute 'get'` and killed `show` AFTER
    # printing the steps -- so the command looked half-successful and the traceback read as a
    # platform failure. Same defect class as D-R15, one field over.
    if isinstance(recon, str):
        if recon.strip():
            click.echo(f"\nPlan shape: {recon.strip()}")
        recon = []
    elif isinstance(recon, dict):
        recon = recon.get("items") or []
    recon = [r for r in recon if isinstance(r, dict)]
    if recon:
        dropped = [r for r in recon if r.get("status") == "dropped"]
        if dropped:
            click.echo(f"\n⚠ Promised items NOT built ({len(dropped)}):")
            for r in dropped:
                click.echo(f"  - {r.get('outline_item')} — {r.get('reason') or 'no reason given'}")
        others = [r for r in recon if r.get("status") != "dropped"]
        if others:
            click.echo("\nReconciled with what you were shown:")
            for r in others:
                click.echo(f"  [{(r.get('status') or 'kept').upper():<7}] {r.get('outline_item')}"
                           + (f" — {r.get('reason')}" if r.get('reason') else ""))

    if arts:
        click.echo(f"\nArtifacts ({len(arts)}):")
        for a in arts:
            line = (f"  - {a.get('artifact_key')} ({a.get('artifact_type')}) "
                    f"state={a.get('state')} from_step={a.get('source_blueprint_step_id')}")
            # Dependency wiring — depends_on/bound_refs are ARTIFACT_KEYS (e.g. 'transformer_1'),
            # not ids. Showing them makes a "depends_on '<x>' does not exist" rejection legible:
            # if <x> is a UUID here, the ref is wrong (it should be a sibling's artifact_key).
            deps = a.get("depends_on") or []
            refs = a.get("bound_refs") or []
            if deps:
                line += f"  depends_on={deps}"
            if refs:
                line += f"  bound_refs={refs}"
            click.echo(line)


def _format_version_anchor(anchor) -> str:
    """One-line human phrasing of the app-version anchor (build_version_anchor payload from the
    API). Mirrors the FE card/detail wording so CLI and UI never diverge. Returns '' when there's
    no anchor (pre-deployable states)."""
    if not isinstance(anchor, dict) or not anchor:
        return ""
    if anchor.get("status") == "deployed":
        v = anchor.get("version_number")
        parent = anchor.get("anchored_on_version")
        if parent:
            return f"deployed as v{v} (built on v{parent})"
        return f"deployed as v{v} (initial version)"
    # predicted — not deployed yet
    deploys_as = anchor.get("deploys_as_version")
    on = anchor.get("anchored_on_version")
    if anchor.get("is_stale"):
        # Stale: anchored behind current live — must re-anchor before it can deploy.
        base = f"v{on}" if on else "an earlier version"
        return (f"STALE — anchored on {base} but the app is now at v{deploys_as - 1}; "
                f"re-anchor on v{deploys_as - 1} before deploying")
    if on:
        return f"anchored on v{on} → will deploy as v{deploys_as}"
    return f"will deploy as v{deploys_as} (initial version)"


def _render_overview_block(ov) -> None:
    """Render the rich Advisor narrative (Intent) — the CLI mirror of the FE detail page's Intent
    section. Prints only the fields that are present so a lean (user-origin) proposal with no
    narrative stays quiet. `ov` is the anyDetail `overview` object."""
    if not isinstance(ov, dict) or not ov:
        return
    # Narrative beats — matched to the FE's "Why / What you'll see / How this helps / What you'd miss".
    beats = [
        ("Intent", ov.get("pitch")),
        ("Why this matters", ov.get("rationale")),
        ("What you'll see", ov.get("expected_view")),
        ("How this helps", ov.get("value_for_user")),
        ("What you'd miss", ov.get("gap_if_skipped")),
    ]
    beats = [(label, val) for label, val in beats if val]
    fit = ov.get("fit_score")
    if beats or fit is not None:
        click.echo("\nIntent")
        if fit is not None:
            gran = ov.get("granularity")
            click.echo(f"  fit    : {round(fit * 100)}%" + (f"   granularity: {gran}" if gran else ""))
        for label, val in beats:
            click.echo(f"  {label}: {str(val).strip()}")

    # "Will create" — artifact_outline maps a category → list of names.
    outline = ov.get("artifact_outline")
    if isinstance(outline, dict) and outline:
        click.echo("\nWill create:")
        for category, names in outline.items():
            if isinstance(names, list):
                for name in names:
                    click.echo(f"  - {category}: {name}")
            elif names:
                click.echo(f"  - {category}: {names}")

    # Grounding — data / policy dependencies + required integrations.
    grounding = [
        ("data", ov.get("data_dependencies")),
        ("policy", ov.get("policy_dependencies")),
        ("integrations", ov.get("required_integrations")),
    ]
    grounding = [(label, vals) for label, vals in grounding if isinstance(vals, list) and vals]
    if grounding:
        click.echo("\nGrounding:")
        for label, vals in grounding:
            click.echo(f"  {label:<12}: {', '.join(str(v) for v in vals)}")

    # Evidence — citations (list of dicts; render a compact one-liner each). Citation shape is
    # {type, ref, excerpt} — e.g. type='data_lake', ref='vulnerabilities', excerpt='46378 open…'.
    citations = ov.get("citations")
    if isinstance(citations, list) and citations:
        click.echo("\nEvidence:")
        for c in citations:
            if isinstance(c, dict):
                src = c.get("type") or c.get("source") or c.get("title") or "citation"
                ref = c.get("ref")
                head = f"{src}: {ref}" if ref else src
                excerpt = c.get("excerpt") or c.get("detail") or c.get("summary") or ""
                click.echo(f"  - {head}" + (f" — {str(excerpt).strip()}" if excerpt else ""))
            else:
                click.echo(f"  - {c}")


def _cook_status(cook) -> str:
    """Derive a step's cook status, tolerating old rows (prefer emitted `status`, fall back to
    the legacy `validated` bool; missing cook entry → pending)."""
    if not isinstance(cook, dict):
        return "pending"
    if cook.get("status"):
        return str(cook.get("status"))
    if cook.get("validated") is True:
        return "validated"
    return "pending"


def _proposal_cancel_core(ctx):
    data = _call(ctx, "POST", f"workspaces/build-v2/proposals/{_pid(ctx)}/cancel")
    if data is not None:
        output(data, fmt=_fmt(ctx))


def _proposal_cookable_core(ctx, workspace_id=None):
    # Top-level group has no workspace in ctx → an explicit --workspace-id is passed.
    # Workspace-scoped group derives it from ctx (_wid). Explicit wins when given.
    wid = workspace_id or _wid(ctx)
    data = _call(ctx, "GET",
                 f"workspaces/{wid}/build-v2/proposals/{_pid(ctx)}/cookable")
    if data is not None:
        output(data, fmt=_fmt(ctx))


def _proposal_status_core(ctx):
    data = _call(ctx, "GET", f"workspaces/build-v2/proposals/{_pid(ctx)}")
    if data is not None:
        # Text view leads with the app-version anchor (from the unified detail payload) so the
        # ledger table is framed by "which version this proposal is/will be". json/yaml skip it —
        # the anchor is a first-class field on `show`/detail for machine consumers.
        if _fmt(ctx) not in ("json", "yaml"):
            detail = _call(ctx, "GET", f"workspaces/build-v2/proposals/{_pid(ctx)}/detail")
            anchor_line = _format_version_anchor(
                (detail or {}).get("version_anchor") if isinstance(detail, dict) else None)
            if anchor_line:
                click.echo(f"Version: {anchor_line}\n")
        arts = {"items": data.get("artifacts", []) if isinstance(data, dict) else []}
        output(arts, fmt=_fmt(ctx), columns=_ARTIFACT_STATUS_COLS)


def _proposal_advisories_core(ctx):
    """BG2 (Spec E § 3.9) — critic advisories to review before deploying a deployable proposal."""
    data = _call(ctx, "GET", f"workspaces/build-v2/proposals/{_pid(ctx)}")
    if data is not None:
        # GET …/proposals/{id} returns {proposal, blueprint, artifacts} — advisories live on
        # the nested ProposalOut. (Reading the wrapper's top level silently showed [] for
        # every proposal; keep the flat read only as a back-compat fallback.)
        items = []
        if isinstance(data, dict):
            prop = data.get("proposal")
            items = (prop.get("advisories") if isinstance(prop, dict) else None) \
                or data.get("advisories") or []
        output({"items": items}, fmt=_fmt(ctx),
               columns=[("severity", "SEVERITY", 10), ("stage", "STAGE", 12), ("message", "MESSAGE", 80)])


def _proposal_provenance_core(ctx):
    data = _call(ctx, "GET", f"workspaces/build-v2/proposals/{_pid(ctx)}/provenance")
    if data is not None:
        output(data, fmt=_fmt(ctx))


def _proposal_lifecycle_core(ctx):
    data = _call(ctx, "GET", f"workspaces/build-v2/proposals/{_pid(ctx)}/lifecycle")
    if data is not None:
        output(data, fmt=_fmt(ctx))


_COMPLETENESS_COLS = [("rule", "RULE", 4), ("field", "FIELD", 28), ("message", "MESSAGE", 60)]


def _validate_completeness_core(ctx, phase=None, downstream=False):
    """Phase 4 (TORANA_BUILD_V2_SKILL_CONVERGENCE § 4.12.2) — run the platform's deterministic
    completeness checks (C1–C6) against this proposal and report pass/fail. Read-only: no state
    change. On failures the process EXITS NON-ZERO (6, validation) so a caller/script can gate on
    it; a clean pass exits 0. json/yaml dump the raw `{valid, failures[]}` payload.

    With downstream=True, appends ?downstream=true so the platform ALSO dry-runs each artifact
    against its owning service (Tier-2), merging {downstream:{valid,failures}} into the payload."""
    q = []
    if phase:
        q.append(f"phase={phase}")
    if downstream:
        q.append("downstream=true")
    path = f"workspaces/build-v2/proposals/{_pid(ctx)}/validate"
    if q:
        path += "?" + "&".join(q)
    data = _call(ctx, "POST", path)
    if data is None:
        return  # _call already surfaced the API/auth error + exited
    if _fmt(ctx) in ("json", "yaml"):
        output(data, fmt=_fmt(ctx), fields=_fields(ctx))
    else:
        failures = data.get("failures") or []
        scope = data.get("phase") or "all"
        # Completeness verdict keys on COMPLETENESS failures only (downstream is a separate layer).
        if not failures:
            click.echo(f"✓ complete — no completeness failures (phase: {scope}).")
        else:
            click.echo(f"✗ INCOMPLETE — {len(failures)} completeness failure(s) (phase: {scope}):\n")
            output({"items": failures}, fmt="text", columns=_COMPLETENESS_COLS)
        # Render the downstream (Tier-2) result separately so it's clear which layer failed.
        if downstream:
            ds = data.get("downstream") or {}
            ds_failures = ds.get("failures") or []
            if ds.get("valid"):
                click.echo("✓ downstream — all artifact payloads validate against their services.")
            else:
                click.echo(f"\n✗ DOWNSTREAM — {len(ds_failures)} artifact payload(s) rejected by "
                           f"their owning service:\n")
                for f in ds_failures:
                    click.echo(f"  • {f}")
    # Non-zero exit on failure so scripts/skills can gate. Exit code 6 = validation (per CLI spec).
    if not data.get("valid"):
        sys.exit(6)


def _blueprint_run_core(ctx, workspace_id):
    # _resolve_wid, not the raw arg: under `torana workspace <id> build proposal <pid> …` the
    # workspace is ALREADY in the command path, so re-typing --workspace-id is redundant. The
    # option stays as an override for the top-level form. (This mirrors _cook_run_core, which
    # got it right; blueprint run/refine and rebase run did not.)
    data = _call(ctx, "POST", f"agents/build-v2/proposals/{_pid(ctx)}/blueprint/run",
                 {"workspace_id": _resolve_wid(ctx, workspace_id)})
    if data is not None:
        output(data, fmt=_fmt(ctx))


def _blueprint_refine_core(ctx, workspace_id, instruction):
    data = _call(ctx, "POST", f"agents/build-v2/proposals/{_pid(ctx)}/blueprint/refine",
                 {"workspace_id": _resolve_wid(ctx, workspace_id),
                  "instruction": instruction})
    if data is not None:
        output(data, fmt=_fmt(ctx))


def _proposal_rebase_run_core(ctx, workspace_id):
    """Launch the SERVER-SIDE rebase driver (background) — the Torana-FE-facade path. The platform
    re-runs the build (re-blueprint + diff + selective re-cook) and STOPS at deployable/superseded.
    NEVER deploys. Poll `lifecycle` / `show` for the reuse/recook/drop outcome. Use this when you
    want the platform to drive; a Claude skill self-drives via `rebase diff` + `rebase apply`."""
    data = _call(ctx, "POST", f"agents/build-v2/proposals/{_pid(ctx)}/rebase",
                 {"workspace_id": _resolve_wid(ctx, workspace_id)})
    if data is not None:
        output(data, fmt=_fmt(ctx))


def _proposal_rebase_diff_core(ctx, blueprint_json, blueprint_file):
    """DETERMINISTIC rebase diff (no LLM) — the self-drive path. You (Claude) re-author the blueprint
    against the live system, pass it here, and get back {reuse[], recook[], drop[], diff_token,
    outcome_preview}: which steps are unchanged (reuse), changed/new (recook), or gone (drop).
    Read-only — no state change. Then call `rebase apply` with the SAME blueprint + diff_token."""
    if blueprint_file:
        with open(blueprint_file) as fh:
            blueprint = json.load(fh)
    elif blueprint_json:
        blueprint = json.loads(blueprint_json)
    else:
        raise click.UsageError("provide --blueprint '<json>' or --blueprint-file <path>")
    data = _call(ctx, "POST", f"workspaces/build-v2/proposals/{_pid(ctx)}/rebase",
                 {"fresh_blueprint": blueprint})
    if data is not None:
        output(data, fmt=_fmt(ctx))


def _proposal_rebase_apply_core(ctx, blueprint_json, blueprint_file, diff_token):
    """Apply the rebase (§ 3.3.3): save the fresh blueprint, drop absent steps, re-pin the anchor,
    and either mark SUPERSEDED (nothing to build) or seed the changed steps for re-cook → COOKING.
    Then drive the cook (`cook run`) to re-cook ONLY those steps → deployable. 409 rebase_stale_diff
    if the token is stale (a deploy raced in) — re-run `rebase diff`. NEVER deploys."""
    if blueprint_file:
        with open(blueprint_file) as fh:
            blueprint = json.load(fh)
    elif blueprint_json:
        blueprint = json.loads(blueprint_json)
    else:
        raise click.UsageError("provide --blueprint '<json>' or --blueprint-file <path>")
    data = _call(ctx, "POST", f"workspaces/build-v2/proposals/{_pid(ctx)}/rebase/apply",
                 {"fresh_blueprint": blueprint, "diff_token": diff_token})
    if data is not None:
        output(data, fmt=_fmt(ctx))


def _blueprint_start_core(ctx):
    data = _call(ctx, "POST", f"workspaces/build-v2/proposals/{_pid(ctx)}/blueprint/start")
    if data is not None:
        output(data, fmt=_fmt(ctx))


def _blueprint_save_core(ctx, blueprint_json, blueprint_file):
    if blueprint_file:
        with open(blueprint_file) as fh:
            blueprint = json.load(fh)
    elif blueprint_json:
        blueprint = json.loads(blueprint_json)
    else:
        raise click.UsageError("provide --blueprint '<json>' or --blueprint-file <path>")
    data = _call(ctx, "POST", f"workspaces/build-v2/proposals/{_pid(ctx)}/blueprint",
                 {"blueprint": blueprint})
    if data is not None:
        output(data, fmt=_fmt(ctx))


def _blueprint_approve_core(ctx):
    data = _call(ctx, "POST", f"workspaces/build-v2/proposals/{_pid(ctx)}/blueprint/approve")
    if data is not None:
        output(data, fmt=_fmt(ctx))


def _blueprint_show_core(ctx):
    data = _call(ctx, "GET", f"workspaces/build-v2/proposals/{_pid(ctx)}/blueprint")
    if data is None:
        return
    fmt = _fmt(ctx)
    # json/yaml → full raw dump (machine parity). text → a readable plan + DEPENDENCY view.
    if fmt in ("json", "yaml"):
        output(data, fmt=fmt)
        return
    bp = data.get("blueprint") if isinstance(data, dict) else None
    if not isinstance(bp, dict) or not bp.get("steps"):
        output(data, fmt=fmt)
        return
    _render_blueprint_text(ctx, data, bp)


def _render_blueprint_text(ctx, data, bp):
    """Human-readable blueprint: header + one block per step showing type/title, produces,
    consumes, and the DEPENDS-ON chain (the step→step dependency graph)."""
    click.echo(f"BLUEPRINT STATE    {data.get('blueprint_state', '—')}")
    click.echo(f"BLUEPRINT VERSION  {data.get('blueprint_version', '—')}")
    if bp.get("transformation_story"):
        click.echo(f"\n{bp['transformation_story']}")
    steps = bp.get("steps") or []
    click.echo(f"\nThe plan — {len(steps)} steps  (dependency order):\n")
    for s in steps:
        sid = s.get("step_id", "?")
        deps = s.get("depends_on") or []
        dep_str = ("after " + ", ".join(str(d) for d in deps)) if deps else "foundation (no deps)"
        click.echo(f"  [{sid}] {(s.get('artifact_type') or '').upper():12} {s.get('title') or ''}")
        click.echo(f"        depends on : {dep_str}")
        if s.get("produces"):
            click.echo(f"        produces   : {s.get('produces')}")
        consumes = s.get("consumes") or []
        if consumes:
            click.echo(f"        consumes   : {', '.join(str(c) for c in consumes)}")
        click.echo("")
    # Compact dependency map at the end (step → its dependents), so the DAG is scannable.
    by_dep: dict = {}
    for s in steps:
        for d in (s.get("depends_on") or []):
            by_dep.setdefault(str(d), []).append(str(s.get("step_id")))
    if by_dep:
        click.echo("Dependency map (step → steps that depend on it):")
        for s in steps:
            sid = str(s.get("step_id"))
            children = by_dep.get(sid)
            if children:
                click.echo(f"  {sid} → {', '.join(children)}")


def _cook_start_core(ctx):
    data = _call(ctx, "POST", f"workspaces/build-v2/proposals/{_pid(ctx)}/cook/start")
    if data is not None:
        output(data, fmt=_fmt(ctx))


# P4. `cook step --wait` already spends exit 2 on "timed out - the build is STILL
# RUNNING" (see the --wait help text documenting 0/1/2). Click's UsageError also exits 2 by
# default, so a script could not tell:
#     "you forgot --workspace-id"   (nothing ran)
# from
#     "your build is still running" (everything ran, and continues to)
# - opposite meanings, one code. Give usage its own: 64 == EX_USAGE from sysexits(3).
EXIT_USAGE = 64


class _WorkspaceUsageError(click.UsageError):
    """A usage error that exits 64 (EX_USAGE) instead of Click's default 2.

    Exit 2 is NOT free here - `--wait` uses it for "timed out, still running". Overloading
    it makes the two indistinguishable to a caller, which is the P4 defect."""

    exit_code = EXIT_USAGE


def _resolve_wid(ctx, workspace_id):
    """Workspace-scoped group already has the workspace in its path (_wid); the top-level group
    does not. Explicit --workspace-id wins; otherwise derive from ctx. Same pattern as
    `_proposal_cookable_core`. Raises a clean usage error only when neither is available.

    Exits 64 (EX_USAGE), not Click's default 2 - see `_WorkspaceUsageError`."""
    wid = workspace_id or _wid(ctx)
    if not wid:
        raise _WorkspaceUsageError(
            "workspace id required — run under `torana workspace <id> build-v2 …` "
            "or pass --workspace-id.")
    return wid


def _cook_run_core(ctx, workspace_id=None, reset=False, reset_hard=False):
    wid = _resolve_wid(ctx, workspace_id)
    body = {"workspace_id": wid}
    if reset:
        body["reset"] = True
    if reset_hard:
        body["reset_hard"] = True
    data = _call(ctx, "POST", f"agents/build-v2/proposals/{_pid(ctx)}/cook/run", body)
    if data is not None:
        output(data, fmt=_fmt(ctx))


#: Columns for the STEP verdict — the question a build loop actually asks ("is this step
#: done, and did it succeed?"), which no existing command answered.
_STEP_STATUS_COLS = [
    ("seq", "#", 4), ("step_id", "STEP", 30), ("artifact_type", "TYPE", 14),
    ("status", "STATUS", 11), ("attempts", "TRIES", 6), ("reason", "REASON", 60),
]

#: A step is finished when it reaches one of these. `pending` and `running` are not.
_STEP_TERMINAL = {"validated", "failed", "rejected", "skipped", "gap"}


def _cook_steps(ctx):
    """The per-step ledger from `cook_state.steps`, or [] when no cook has started.

    ⭐ WHY THIS EXISTS. A step that returns a GAP creates NO ARTIFACT — so `artifact list`
    shows nothing, `lifecycle` shows the run as `running`/`completed`, and the ONLY surface
    that told the truth was the FE. Measured 2026-08-20: a caller polling artifact counts
    cannot distinguish "still working" from "failed with a GAP", and waits out its loop.
    The platform has the answer all along, in `cook_state.steps[]`.
    """
    data = _call(ctx, "GET", f"workspaces/build-v2/proposals/{_pid(ctx)}")
    if not data:
        return []
    prop = data.get("proposal") or data
    return ((prop.get("cook_state") or {}).get("steps")) or []


def _wait_for_step(ctx, timeout_seconds: int, poll_seconds: int = 6):
    """Block until every step reaches a terminal state, or `timeout_seconds` elapses.

    ⛔ CLIENT-SIDE ON PURPOSE. The API stays 202-and-poll: an authoring step is a full LLM
    cycle (minutes) and a synchronous HTTP call would be at the mercy of every proxy and
    idle timeout between here and the agent. Waiting in the CLI keeps the existing verb
    untouched and lets a dropped response be retried by the next poll rather than failing
    the build.

    Returns (steps, timed_out).
    """
    import time as _time
    deadline = _time.monotonic() + max(1, int(timeout_seconds))
    steps = []
    while True:
        steps = _cook_steps(ctx)
        if steps and all(str(s.get("status") or "").lower() in _STEP_TERMINAL for s in steps):
            return steps, False
        # A step in flight — `current_step` is set, or some step is not yet terminal.
        if _time.monotonic() >= deadline:
            return steps, True
        _time.sleep(max(1, int(poll_seconds)))


def _echo_step_verdict(ctx, steps, timed_out=False):
    """Print the VERDICT, not the raw payload. ⛔ States the outcome in words, because a
    table of statuses still leaves a caller to work out whether the build advanced."""
    if _fmt(ctx) in ("json", "yaml"):
        output({"items": steps}, fmt=_fmt(ctx))
        return
    output({"items": steps}, fmt=_fmt(ctx), columns=_STEP_STATUS_COLS)
    done = [s for s in steps if str(s.get("status") or "").lower() == "validated"]
    bad = [s for s in steps if str(s.get("status") or "").lower() in ("failed", "rejected", "gap")]
    pend = [s for s in steps if str(s.get("status") or "").lower() not in _STEP_TERMINAL]
    click.echo("")
    if timed_out:
        click.echo(f"⏱  TIMED OUT waiting — {len(done)}/{len(steps)} validated, "
                   f"{len(pend)} still running. The build is NOT cancelled; re-run with "
                   f"--wait to keep waiting, or check `show`.")
    elif bad:
        click.echo(f"✗ {len(bad)} step(s) did NOT build — {len(done)}/{len(steps)} validated.")
        for s in bad:
            click.echo(f"    {s.get('step_id')}: {str(s.get('reason') or 'no reason recorded')[:300]}")
    elif pend:
        click.echo(f"… {len(done)}/{len(steps)} validated, {len(pend)} still pending.")
    else:
        click.echo(f"✓ all {len(steps)} step(s) validated.")


def _cook_step_core(ctx, workspace_id=None, wait=False, timeout=900):
    """Cook the ONE next-pending step then stop (Spec E — step-by-step testing). Background 202;
    poll `status`/`show` for the step result. 409 if a cook session is already in progress."""
    wid = _resolve_wid(ctx, workspace_id)
    data = _call(ctx, "POST", f"agents/build-v2/proposals/{_pid(ctx)}/cook/step",
                 {"workspace_id": wid})
    if data is None:
        return
    if not wait:
        output(data, fmt=_fmt(ctx))
        return
    if _fmt(ctx) == "text":
        click.echo(f"Step launched — waiting up to {timeout}s for it to finish…")
    steps, timed_out = _wait_for_step(ctx, timeout)
    _echo_step_verdict(ctx, steps, timed_out)
    if timed_out:
        ctx.exit(2)
    if any(str(x.get("status") or "").lower() in ("failed", "rejected", "gap") for x in steps):
        ctx.exit(1)


def _recook_step_core(ctx, step_id, workspace_id=None):
    """Re-cook ONLY the given blueprint step, leaving every other validated step untouched — the
    surgical fix for one broken step (e.g. a widget the cook-fidelity check rejected). Two calls:
      1. PF prepare: reset the target step's artifact(s) + dependents → draft, seed cook_state so
         only the target is pending, proposal → cooking.
      2. agent-builder single-step cook: the driver skips the seeded (validated) steps and cooks
         exactly the target, then stops. Background (202) — poll `status`/`show` for the result."""
    wid = _resolve_wid(ctx, workspace_id)
    prep = _call(ctx, "POST", f"workspaces/build-v2/proposals/{_pid(ctx)}/cook/recook-step",
                 {"step_id": step_id})
    if prep is None:
        return
    if _fmt(ctx) not in ("json", "yaml"):
        tgt = ", ".join(prep.get("target_artifact_keys") or []) or "(none)"
        casc = ", ".join(prep.get("cascaded_keys") or [])
        click.echo(f"Prepared step {step_id} for re-cook — resetting {tgt}"
                   + (f" (+ cascaded: {casc})" if casc else "") + ". Launching single-step cook…")
    step = _call(ctx, "POST", f"agents/build-v2/proposals/{_pid(ctx)}/cook/step",
                 {"workspace_id": wid})
    if step is not None:
        output(step, fmt=_fmt(ctx))


def _cook_finalize_core(ctx):
    data = _call(ctx, "POST", f"workspaces/build-v2/proposals/{_pid(ctx)}/cook/finalize")
    if data is not None:
        # CONFIRM THE TRANSITION. finalize's payload renders as the artifact table, whose
        # rows all read `validated` both before AND after the call — so the output looked
        # identical whether the proposal reached `deployable` or not, and a caller had to
        # issue a second `show` to find out. A state transition must be legible from the
        # command that performed it. (`state` is nested under `proposal`, which is also
        # why a top-level grep for it finds nothing.)
        if _fmt(ctx) == "text":
            _state = (data.get("proposal") or {}).get("state") or data.get("state")
            if _state:
                click.echo(f"State: {_state}")
        output(data, fmt=_fmt(ctx))


def _cook_reset_core(ctx, hard=False):
    """Standalone soft/hard reset of a failed/wedged cook → blueprint_ready (approved blueprint
    kept). SOFT: artifacts→draft + cook_state cleared. HARD: also drop produced transformer tables.
    Unlike `run --reset` (which resets THEN cooks in one call), this only resets — follow with
    `cook run` to re-cook. This is the standalone endpoint the FE Retry button uses."""
    body = {"hard": True} if hard else {}
    data = _call(ctx, "POST", f"workspaces/build-v2/proposals/{_pid(ctx)}/cook/reset", body)
    if data is not None:
        output(data, fmt=_fmt(ctx))


def _reset_to_intent_core(ctx):
    """DEEP reset → intent_only: drops the authored blueprint AND the cook (artifacts removed,
    cook_state cleared). Only intent_text survives — re-run `blueprint start` afterwards. Unlike
    `cook reset` (keeps the approved blueprint at blueprint_ready), this discards the blueprint."""
    data = _call(ctx, "POST", f"workspaces/build-v2/proposals/{_pid(ctx)}/reset-to-intent")
    if data is not None:
        output(data, fmt=_fmt(ctx))


def _iterations_core(ctx):
    """SA cross-tenant: the proposal's build→critique iterations. Each phase-run (blueprint|cook)
    is one iteration with its Builder(author/gen) + Critic(review) invokes and the critic verdict.
    Requires super_admin (uses the /admin/build-v2 surface)."""
    data = _call(ctx, "GET", f"admin/build-v2/proposals/{_pid(ctx)}/iterations")
    if data is None:
        return
    if _fmt(ctx) in ("json", "yaml"):
        output(data, fmt=_fmt(ctx))
        return
    # text: one line per iteration — index, phase, status, verdict, invoke count.
    click.echo(f"PROPOSAL {data.get('proposal_id')}  state={data.get('state')}  "
               f"iterations={data.get('total_iterations')}")
    for it in data.get("iterations", []):
        verdict = it.get("critic_verdict") or "—"
        click.echo(f"  #{it.get('iteration_index'):>2}  {it.get('phase'):9}  "
                   f"{str(it.get('status')):11}  critic={verdict:12}  "
                   f"invokes={it.get('invoke_count')}")
        for inv in it.get("invokes", []):
            iv = f" ({inv.get('verdict')})" if inv.get("verdict") else ""
            click.echo(f"        {inv.get('role'):7} {inv.get('agent_name') or '—'}"
                       f"  [{inv.get('execution_status')}]{iv}")


def _artifact_add_core(ctx, artifact_type, artifact_key, definition, definition_file,
                       depends_on, source_blueprint_step_id, description, emit=True,
                       semantic_description=None, semantic_description_file=None,
                       catalog_entry_id=None, catalog_decision_id=None,
                       required_integrations=None, question_id=None):
    # S15 row 43. `semantic_description` is a FIRST-CLASS request field the API has always
    # accepted (AddArtifactRequest) — it was simply never sent, so a conforming 1,403-char
    # intent authored by the skill was dropped with no error and the artifact shipped
    # non-conforming while looking healthy. ⚠️ It is NOT the same field as
    # definition.semantic_description: every gate, producer and reader uses the COLUMN, and
    # row 40 measured 1,395 chars sitting in the definition while the column held 265.
    intent = _load_semantic_description(semantic_description, semantic_description_file)
    _warn_if_not_intent(intent, artifact_type)
    body = {
        "artifact_type": artifact_type,
        "artifact_key": artifact_key,
        "definition": _load_definition(definition, definition_file),
        "description": description,
    }
    # Send only when authored: "" means DERIVE, and the server's derive path is the
    # documented default for an artifact that genuinely has nothing more to say than its step.
    if intent.strip():
        body["semantic_description"] = intent
    if source_blueprint_step_id:
        body["source_blueprint_step_id"] = source_blueprint_step_id
    if depends_on:
        body["depends_on"] = [k.strip() for k in depends_on.split(",") if k.strip()]
    # § 3.4.5 — the CALLER-owned fields. Sent only when supplied so an omitted flag keeps the
    # server's own default rather than overwriting it with an empty value.
    if catalog_entry_id:
        body["catalog_entry_id"] = catalog_entry_id
    if catalog_decision_id:
        body["catalog_decision_id"] = catalog_decision_id
    if required_integrations:
        body["required_integrations"] = [
            k.strip() for k in required_integrations.split(",") if k.strip()
        ]
    # § 3.11.3.1 item 1 — the corpus question this artifact answers. Omitted when the need did
    # not resolve: UNRESOLVED is a first-class result recorded as demand (§ 3.6.1), and sending
    # an empty string would look like a resolution that failed rather than a question nobody
    # has added to the corpus yet.
    if question_id:
        body["question_id"] = question_id
    data = _call(ctx, "POST", f"workspaces/build-v2/proposals/{_pid(ctx)}/artifacts", body)
    if data is not None and emit:
        output(data, fmt=_fmt(ctx))
    return data


def _artifact_validate_core(ctx, artifact_id, emit=True):
    data = _call(ctx, "POST", f"workspaces/build-v2/artifacts/{artifact_id}/validate")
    if data is not None and emit:
        output(data, fmt=_fmt(ctx))
    return data


def _artifact_edit_core(ctx, artifact_id, definition, definition_file,
                        semantic_description=None, semantic_description_file=None):
    """Edit a deposited artifact's definition, its INTENT, or both.

    \u26d4 `semantic_description` is editable here because `edit` is the documented repair
    path, and the intent is the field most likely to need repair. Measured 2026-08-18
    (`d6e52fe1`): a build deposited a transformer before attaching its intent, so the
    server-DERIVED text stuck \u2014 edit took only `--definition`, and re-adding 409s on the
    unique key. The artifact shipped with intent nobody wrote, and the session had to
    report it as an uncorrectable caveat.
    """
    body = {}
    if definition or definition_file:
        body["definition"] = _load_definition(definition, definition_file)
    if semantic_description or semantic_description_file:
        body["semantic_description"] = _load_semantic_description(
            semantic_description, semantic_description_file)
    if not body:
        raise click.UsageError(
            "nothing to change. Pass --definition/--definition-file, "
            "--semantic-description/--semantic-description-file, or both.")
    data = _call(ctx, "PUT", f"workspaces/build-v2/artifacts/{artifact_id}", body)
    if data is not None:
        output(data, fmt=_fmt(ctx))


# ⭐ DEPLOY IS NOW 202-AND-POLL (F3 § 3.2 / § 3.7), so this bounds the SUBMIT, not the work.
#
# It used to be 900 s, because the POST awaited the entire deploy: every transformer
# materialized inline, and a 44-artifact CISO build ran for minutes. Measured on the current
# build, that POST now returns in **0.17 s** — it admits the deploy, claims the proposal
# `deploying`, and hands the run to a detached server-side task.
#
# ⚠️ Not zero-length, though: the submit still does real synchronous work on the retry path —
# a `rolled_back` proposal is auto-reset first, which reaps the previous attempt's orphans over
# HTTP. 60 s is generous for that and short enough that a genuinely unreachable service is
# reported in a minute rather than a quarter of an hour.
_DEPLOY_SUBMIT_TIMEOUT = 60  # seconds — bounds the 202 handshake only
_DEPLOY_TIMEOUT = _DEPLOY_SUBMIT_TIMEOUT  # back-compat alias; the old name meant the whole run

# How long to follow a detached deploy before handing the user back the poll command. The
# deploy keeps running server-side regardless — this bounds only how long the CLI watches.
# Matches the server's orphan-reaper window (BUILD_V2_DEPLOY_ORPHAN_STALE_SECONDS, default
# 1800): past that point the server itself would treat the run as a dead runner, so there is
# nothing useful left for the client to wait for.
_DEPLOY_WATCH_TIMEOUT = 1800  # seconds
# Poll cadence, shared with `_wait_for_step` (F3 § 3.7 bounds it at 3–6 s).
_DEPLOY_POLL_SECONDS = 6

# Terminal artifact states — used to decide whether a post-timeout poll found a
# settled deploy or one still running.
_DEPLOY_DONE_STATES = {"deployed", "rolled_back", "failed", "rejected"}


def _report_deploy_outcome_after_timeout(ctx, err):
    """The deploy POST died at the transport layer — report what ACTUALLY happened.

    A timeout says nothing about the deploy's fate: the server may have finished
    successfully, may still be working, or may have failed. Previously the CLI
    announced `ERROR: Cannot reach …/deploy: timed out` and exited non-zero, which
    reported a *successful* deploy as a failure — and tempted a retry that risks a
    double-apply / 409 (CLI-12). So: poll `deploy/status` once and report the truth.
    """
    click.echo(f"\n! The deploy request did not return in time ({err}).", err=True)
    click.echo("  This does NOT mean the deploy failed — checking actual server state...",
               err=True)

    try:
        data = _client(ctx).get(
            f"workspaces/build-v2/proposals/{_pid(ctx)}/deploy/status")
    except (APIError, AuthError) as poll_err:
        # Couldn't confirm either way. Say exactly that, and do NOT imply failure.
        click.echo(f"\n✗ Could not read deploy status to confirm ({poll_err}).", err=True)
        click.echo("  The deploy may still have succeeded — check before retrying:", err=True)
        click.echo(f"    torana build proposal {_pid(ctx)} deploy-status", err=True)
        click.echo("  Do NOT blindly re-run deploy: if the first one succeeded, a retry can "
                   "double-apply or 409.", err=True)
        ctx.exit(1)
        return

    arts = data.get("artifacts", []) if isinstance(data, dict) else []
    states = [a.get("state") for a in arts if isinstance(a, dict)]
    deployed = [s for s in states if s == "deployed"]
    pending = [s for s in states if s not in _DEPLOY_DONE_STATES]

    if arts and len(deployed) == len(states):
        # Every artifact made it. The deploy SUCCEEDED — report success, exit 0.
        click.echo(f"\n✓ Deploy actually SUCCEEDED — all {len(states)} artifact(s) are deployed.")
        click.echo("  (The request timed out, but the server completed the work.)")
        return

    if pending:
        click.echo(f"\n… Deploy is still RUNNING — {len(pending)} of {len(states)} artifact(s) "
                   f"not yet in a terminal state.")
        click.echo(f"  Poll it: torana build proposal {_pid(ctx)} deploy-status")
        click.echo("  Do NOT re-run deploy while it is still in progress.")
        return

    # Settled, but not all deployed → a real failure. Show which and why.
    click.echo(f"\n✗ Deploy FAILED — {len(deployed)} of {len(states)} artifact(s) deployed.",
               err=True)
    rows = []
    for a in arts:
        if isinstance(a, dict) and a.get("state") != "deployed":
            rows.append({**a, "reason": _artifact_reason(a)})
    if rows:
        output({"items": rows}, fmt=_fmt(ctx), columns=_DEPLOY_STATUS_COLS)
    ctx.exit(1)


def _deploy_terminal_state(data) -> str:
    """The proposal's deploy state from a `deploy/status` payload, '' if unreadable."""
    if not isinstance(data, dict):
        return ""
    prop = data.get("proposal") if isinstance(data.get("proposal"), dict) else {}
    return str(prop.get("state") or "")


def _watch_deploy(ctx, deploy_run_id: str,
                  timeout_seconds: int = _DEPLOY_WATCH_TIMEOUT,
                  poll_seconds: int = _DEPLOY_POLL_SECONDS):
    """Follow a DETACHED deploy to a terminal proposal state by polling `deploy/status`.

    ⛔ POLLING IS THE PRIMARY PATH NOW (F3 § 3.7), not the salvage path it used to be. Before
    this, the CLI awaited the deploy over one long HTTP call and only polled `deploy/status`
    if that call died at the transport layer — so the happy path depended on a minutes-long
    request surviving every proxy and idle timeout between here and the server. Now the
    server returns 202 immediately and the run is server-side; the poll IS how the CLI learns
    what happened, and a dropped poll simply retries on the next tick instead of failing the
    build.

    ⚠️ This deliberately does NOT call `_wait_for_step`, which the spec suggested reusing:
    that helper polls `cook_state.steps[]` on a different endpoint with a different terminal
    set — it watches COOK, not deploy. What is reused is its shape and its 6 s cadence.

    Returns (status_payload, timed_out).
    """
    import time as _time
    deadline = _time.monotonic() + max(1, int(timeout_seconds))
    data, last_line = None, ""
    while True:
        try:
            data = _client(ctx).get(
                f"workspaces/build-v2/proposals/{_pid(ctx)}/deploy/status")
        except (APIError, AuthError) as poll_err:
            # A single failed poll is not a failed deploy — the run is server-side. Say so
            # and try again on the next tick; only the deadline ends the watch.
            click.echo(f"  … poll failed ({poll_err}); retrying", err=True)
            data = None
        if data is not None:
            state = _deploy_terminal_state(data)
            arts = data.get("artifacts") or []
            done = sum(1 for a in arts if isinstance(a, dict) and a.get("state") == "deployed")
            line = f"  … {state}  ({done}/{len(arts)} artifact(s) deployed)"
            if line != last_line:          # only narrate real movement
                click.echo(line)
                last_line = line
            if state in _DEPLOY_DONE_STATES:
                return data, False
        if _time.monotonic() >= deadline:
            return data, True
        _time.sleep(max(1, int(poll_seconds)))


def _report_deploy_result(ctx, data) -> None:
    """Render a settled deploy from its final `deploy/status` payload, and set the exit code."""
    state = _deploy_terminal_state(data)
    arts = data.get("artifacts") or [] if isinstance(data, dict) else []
    deployed = [a for a in arts if isinstance(a, dict) and a.get("state") == "deployed"]
    if state == "deployed":
        click.echo(f"\n✓ Deployed — {len(deployed)}/{len(arts)} artifact(s) live.")
        return
    prop = data.get("proposal") if isinstance(data, dict) else None
    reason = (prop or {}).get("failure_reason") or ""
    click.echo(f"\n✗ Deploy ended '{state}' — {len(deployed)}/{len(arts)} artifact(s) deployed.",
               err=True)
    if reason:
        click.echo(f"  {reason}", err=True)
    rows = [{**a, "reason": _artifact_reason(a)}
            for a in arts if isinstance(a, dict) and a.get("state") != "deployed"]
    if rows:
        output({"items": rows}, fmt=_fmt(ctx), columns=_DEPLOY_STATUS_COLS)
    if state == "rolled_back":
        click.echo(f"\n  Retry with: torana build proposal {_pid(ctx)} deploy", err=True)
        click.echo("  (a rolled_back proposal auto-resets on the next deploy; "
                   "`deploy-reset` remains the explicit escape hatch)", err=True)
    ctx.exit(1)


def _deploy_core(ctx, upsert: bool = False):
    # Intercept the anchor-staleness 409 (BUILD_V2_ANCHOR_STALENESS_GATE_SPEC § 3.4.2) BEFORE the
    # generic error handler, so the user gets a clean, actionable message — not a raw traceback
    # ([[feedback_clean_cli_errors_not_tracebacks]]). The message points at REBASE (the safe path),
    # not a naive reanchor: reanchor only RE-VALIDATES (§ 3.6.10.1) and is blind to duplicate
    # transformers / name-collisions / rule-ordering vs the live manifest, so recommending it as
    # THE fix is unsafe. A full rebase (re-evaluate the frozen intent against the live system,
    # rebuild only what's needed) is the coming capability; until it lands the safe move is to
    # rebuild the program fresh against the current live app.
    try:
        # SUBMIT — expected to return 202 in well under a second (F3 § 3.2). The long
        # deadline this used to carry existed only because the POST awaited the whole
        # deploy; that is gone, so the handshake gets a short, honest bound.
        data = _client(ctx).post(
            f"workspaces/build-v2/proposals/{_pid(ctx)}/deploy", json={},
            params={"upsert": "true"} if upsert else None,
            timeout=_DEPLOY_SUBMIT_TIMEOUT)
    except APIError as e:
        # status_code 0 == transport-level failure (timeout / connection drop), NOT a
        # server rejection. The deploy may well have completed; the response just never
        # arrived. Ask the server what actually happened before reporting anything —
        # announcing failure on a successful deploy is the exact silent lie being fixed.
        if e.status_code == 0:
            _report_deploy_outcome_after_timeout(ctx, e)
            return
        detail = e.detail if isinstance(getattr(e, "detail", None), dict) else {}
        if e.status_code == 409 and detail.get("error") == "stale_anchor":
            rv = detail.get("required_version")
            av = detail.get("anchored_on")
            click.echo(
                f"✗ This build is stale — it was grounded when the app was on "
                f"v{av if av is not None else '(earlier)'}, but the app is now on v{rv} "
                f"(other program(s) have since deployed).")
            click.echo(
                "  Deploying it as-is could duplicate or conflict with what's already live, so the "
                "deploy is blocked.")
            click.echo(
                "  The safe path is a REBASE — re-evaluate the intent against the current live app "
                "and rebuild only what's needed. That capability is coming; until it lands, rebuild "
                "the program fresh against the live app.")
            click.echo(
                f"  (Advanced/at-your-own-risk: `torana build proposal {_pid(ctx)} reanchor` re-"
                f"validates the artifacts against v{rv} and advances the anchor — but it does NOT "
                f"check for duplication or ordering conflicts with the live manifest.)")
            ctx.exit(1)
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if data is None:
        return

    # ── 202 accepted → FOLLOW IT (the primary path, F3 § 3.7) ────────────────────────
    if isinstance(data, dict) and data.get("accepted"):
        if _fmt(ctx) in ("json", "yaml"):
            # A scripted caller asked for the raw envelope: hand back the 202 (which carries
            # deploy_run_id + status_url) and let it drive its own poll. Blocking here would
            # be the CLI deciding a machine's wait policy for it.
            output(data, fmt=_fmt(ctx))
            return
        run_id = data.get("deploy_run_id") or "?"
        click.echo(f"Deploy accepted (run {run_id}) — running server-side; following it…")
        status, timed_out = _watch_deploy(ctx, run_id)
        if timed_out:
            # ⚠️ NOT a failure. The run is server-side and unaffected by the CLI giving up.
            click.echo(f"\n! Still running after {_DEPLOY_WATCH_TIMEOUT}s — the CLI stopped "
                       f"watching; the deploy has NOT been cancelled.", err=True)
            click.echo(f"  Check it: torana build proposal {_pid(ctx)} deploy-status", err=True)
            click.echo("  Do NOT re-run deploy while it is still in progress.", err=True)
            return
        if status is None:
            click.echo("\n! Could not read the final deploy status.", err=True)
            click.echo(f"  Check it: torana build proposal {_pid(ctx)} deploy-status", err=True)
            return
        _report_deploy_result(ctx, status)
        return

    # ── legacy INLINE server (pre-F3): the POST already carries the finished result ──
    # torana-cli ships independently of the services, so a newer CLI can meet an older
    # program-framework that still awaits the deploy and returns 200 + the result body.
    # Render it the way this command always did rather than mis-reporting it.
    output(data, fmt=_fmt(ctx))


def _proposal_reanchor_core(ctx):
    """Re-anchor a stale deployable candidate onto the workspace's current live version
    (BUILD_V2_ANCHOR_STALENESS_GATE_SPEC § 3.4.3). On conflict prints the per-artifact conflict
    table; on success the from→to version line."""
    data = _call(ctx, "POST", f"workspaces/build-v2/proposals/{_pid(ctx)}/reanchor")
    if data is None:
        return
    if _fmt(ctx) in ("json", "yaml"):
        output(data, fmt=_fmt(ctx))
        return
    if data.get("reanchored"):
        frm = data.get("from_version")
        to = data.get("to_version")
        note = f" ({data['note']})" if data.get("note") else ""
        click.echo(f"✓ Re-anchored: v{frm if frm else 'genesis'} → v{to}{note}. "
                   f"This build can now deploy as v{(to or 0) + 1}.")
    else:
        click.echo(f"✗ Cannot re-anchor — {len(data.get('conflicts') or [])} conflict(s) against "
                   f"v{data.get('to_version')}. Edit the listed artifact(s), then re-anchor again:")
        output({"items": data.get("conflicts") or []}, fmt=_fmt(ctx),
               columns=[("artifact_key", "ARTIFACT", 28), ("reason", "REASON", 60)])


def _artifact_reason(a: dict) -> str:
    """Best available explanation for an artifact's current state.

    `rejection_reason` is the explicit one; when it is absent a failed artifact still
    usually carries the cause inside the `validation` dict. Surfacing '' rather than
    guessing keeps a healthy artifact's row clean.
    """
    if not isinstance(a, dict):
        return ""
    reason = a.get("rejection_reason")
    if reason:
        return str(reason)
    v = a.get("validation")
    if isinstance(v, dict):
        # Common shapes: {"error": "..."} / {"message": "..."} / {"errors": [...]}
        for key in ("error", "message", "detail", "reason"):
            if v.get(key):
                return str(v[key])
        errs = v.get("errors")
        if isinstance(errs, list) and errs:
            return "; ".join(str(e) for e in errs[:3])
        if isinstance(errs, str) and errs:
            return errs
    elif isinstance(v, str) and v:
        return v
    return ""


def _deploy_status_core(ctx):
    data = _call(ctx, "GET", f"workspaces/build-v2/proposals/{_pid(ctx)}/deploy/status")
    if data is None:
        return
    raw = data.get("artifacts", []) if isinstance(data, dict) else []
    # Text/table renderers need a flat `reason`; JSON/YAML keep the full server
    # payload (validation dict included) so nothing is lost to a machine consumer.
    fmt = _fmt(ctx)
    if fmt in ("json", "yaml"):
        output({"items": raw}, fmt=fmt)
        return

    items = []
    for a in raw:
        row = dict(a) if isinstance(a, dict) else a
        if isinstance(row, dict):
            row["reason"] = _artifact_reason(a)
        items.append(row)
    output({"items": items}, fmt=fmt, columns=_DEPLOY_STATUS_COLS)

    # Proposal-level state was fetched and thrown away. On a failed deploy it is the
    # single most useful line (e.g. why the whole proposal rolled back), so surface it.
    prop = data.get("proposal") if isinstance(data, dict) else None
    if isinstance(prop, dict):
        pstate = prop.get("state") or prop.get("status")
        if pstate:
            click.echo(f"\nProposal state: {pstate}")
        for key in ("rejection_reason", "failure_reason", "error"):
            if prop.get(key):
                click.echo(f"  {key}: {prop[key]}")
                break


def _deploy_reset_core(ctx):
    data = _call(ctx, "POST", f"workspaces/build-v2/proposals/{_pid(ctx)}/deploy/reset")
    if data is not None:
        output(data, fmt=_fmt(ctx))


_DEPLOY_ORPHANS_COLS = [
    ("type", "TYPE", 16),
    ("id", "ID", 36),
    ("deploy_run_id", "ATTEMPT", 16),
]


def _deploy_orphans_core(ctx):
    """Downstream artifacts a prior failed/rolled-back deploy attempt left behind (tagged to this
    proposal but never reaped). Each is keyed to the deploy_run_id (attempt) that created it."""
    data = _call(ctx, "GET", f"workspaces/build-v2/proposals/{_pid(ctx)}/deploy/orphans")
    if data is not None:
        orphans = {"items": data.get("orphans", []) if isinstance(data, dict) else []}
        output(orphans, fmt=_fmt(ctx), columns=_DEPLOY_ORPHANS_COLS)


def _fold_attempts(runs):
    """Fold a lifecycle `runs[]` list into the DEPLOY-ATTEMPT SERIES.

    A deploy and its rollback share the same `dp_…` phase_run_id → one attempt. A `reset`
    run (own `rs_…` id) is the transition between attempt N and N+1 → rendered as a marker
    between attempts. Non deploy/rollback/reset phases (blueprint, cook) are ignored — this
    is the DEPLOY series only. Order is preserved from the (time-ordered) runs list."""
    attempts = []           # ordered list of {phase_run_id, deploy, rollback, reset}
    by_id = {}              # phase_run_id → attempt dict (for merging deploy+rollback)
    for r in runs or []:
        phase = r.get("phase")
        if phase in ("deploy", "rollback"):
            key = r.get("phase_run_id")
            att = by_id.get(key)
            if att is None:
                att = {"phase_run_id": key, "deploy": None, "rollback": None, "reset": None}
                by_id[key] = att
                attempts.append(att)
            att[phase] = r
        elif phase == "reset":
            # A reset is its own marker entry in the series (transition between attempts).
            attempts.append({"phase_run_id": r.get("phase_run_id"),
                             "deploy": None, "rollback": None, "reset": r})
    return attempts


def _attempt_summary(att):
    """Derive an attempt's headline status + duration from its deploy/rollback runs."""
    deploy = att.get("deploy") or {}
    rollback = att.get("rollback") or {}
    # Rolled back if a rollback run exists; else use the deploy run's own status.
    if rollback:
        status = "rolled_back"
    else:
        status = deploy.get("status") or "unknown"
    failure = deploy.get("failure_reason") or rollback.get("failure_reason")
    # Duration: prefer the deploy run's; a running attempt may not have one yet.
    dur = deploy.get("duration_seconds")
    if dur is None:
        dur = rollback.get("duration_seconds")
    return status, failure, dur


def _attempts_core(ctx):
    """Fold the proposal's lifecycle runs into the deploy-attempt series and render it."""
    data = _call(ctx, "GET", f"workspaces/build-v2/proposals/{_pid(ctx)}/lifecycle")
    if data is None:
        return
    runs = data.get("runs", []) if isinstance(data, dict) else []
    attempts = _fold_attempts(runs)
    if _fmt(ctx) in ("json", "yaml"):
        output({"attempts": attempts}, fmt=_fmt(ctx))
        return
    # text → a readable series (not a raw table).
    _GLYPH = {"deployed": "✓", "completed": "✓", "rolled_back": "✗",
              "running": "◐", "unknown": "•"}
    click.echo(f"Deploy attempts for proposal {_pid(ctx)}"
               f"   (state: {data.get('state', '—')})")
    if not attempts:
        click.echo("  (no deploy attempts yet)")
        return
    ordinal = 0
    for att in attempts:
        if att.get("reset"):
            rs = att["reset"]
            summary = rs.get("summary") or rs.get("failure_reason") or "reset"
            click.echo(f"    ↳ reset · {summary}")
            continue
        ordinal += 1
        status, failure, dur = _attempt_summary(att)
        glyph = _GLYPH.get(status, "•")
        line = f"  {glyph} Attempt {ordinal}: {status}"
        if dur is not None:
            line += f"  ({dur}s)"
        click.echo(line)
        if failure:
            click.echo(f"      reason: {failure}")


def _proposal_delete_core(ctx, yes=False):
    """Discard a proposal (soft-delete — sets is_deleted so the card leaves the list). Refused
    (409) while deploying/deployed — surfaced as a clean message, not a traceback."""
    pid = _pid(ctx)
    if not yes:
        # P6. Both ways of NOT deleting must exit the same. Interactive "n" used to
        # `return` (exit 0 - indistinguishable from a successful delete), while a non-TTY
        # EOF raised Click's Abort (exit 1). Same outcome, two codes, and the 0 was the
        # dangerous one: a script reading exit 0 concludes the proposal is gone.
        # Now BOTH decline paths exit 1, and only an actual delete exits 0.
        try:
            confirmed = _confirm(f"Discard proposal {pid}?", yes=False)
        except click.Abort:
            # Non-interactive with no answer available (EOF). Not a crash - a decline.
            click.echo("Aborted - no confirmation available (non-interactive). "
                       "Pass --yes to discard without prompting.", err=True)
            ctx.exit(1)
        if not confirmed:
            click.echo("Aborted.", err=True)
            ctx.exit(1)
    data = _call(ctx, "DELETE", f"workspaces/build-v2/proposals/{pid}")
    if data is not None:
        click.echo(f"Discarded proposal {pid}")


# ── artifacts.yaml import / export (TYPED_ARTIFACT_DEFINITION spec § 3.4.6) ──────────────────
# Export is DEPLOY-INDEPENDENT: `proposal <ID> export` works the moment cook is done, deployed
# or NOT. `version`/`deployment export` reuse the identical serializer against the frozen manifest.

def _import_yaml_core(ctx, workspace_id, file, built_via=None):
    """POST a raw artifacts.yaml as a new proposal (import). Reads the file, sends {yaml: ...}.
    built_via stamps the created proposal's build-surface badge (e.g. claude_skill)."""
    try:
        with open(file) as fh:
            yaml_text = fh.read()
    except OSError as exc:
        raise click.UsageError(f"cannot read --file {file}: {exc}")
    body = {"yaml": yaml_text}
    if built_via:
        body["built_via"] = built_via
    data = _call(ctx, "POST",
                 f"workspaces/{workspace_id}/build-v2/proposals/import-yaml",
                 body)
    if data is not None:
        output(data, fmt=_fmt(ctx))


def _emit_yaml(ctx, data, out):
    """Write an export response's `yaml` to --out (or stdout). `data` is {yaml, ...}."""
    if data is None:
        return
    yaml_text = data.get("yaml") if isinstance(data, dict) else None
    if yaml_text is None:
        output(data, fmt=_fmt(ctx))
        return
    if out:
        with open(out, "w") as fh:
            fh.write(yaml_text)
        click.echo(f"wrote {len(yaml_text)} bytes to {out}")
    else:
        click.echo(yaml_text)


def _export_proposal_core(ctx, out):
    """Serialize this proposal's cooked artifacts → artifacts.yaml (deploy-independent)."""
    data = _call(ctx, "GET", f"workspaces/build-v2/proposals/{_pid(ctx)}/export-yaml")
    _emit_yaml(ctx, data, out)


def _register_proposal_instance_verbs(proposal_group, *, workspace_scoped: bool) -> None:
    """Attach the full instance-verb surface (show/status/provenance/lifecycle/cookable,
    blueprint·cook·artifact sub-groups, deploy/deploy-status) onto a proposal instance
    group. Called for BOTH the top-level `bv2_proposal` and the workspace-scoped
    `ws_bv2_proposal` groups so they stay verb-for-verb identical.

    Every command body is a thin wrapper over the shared `_core` routines above — one
    implementation, two registrations, zero drift.

    `workspace_scoped` toggles the single genuine asymmetry: `cookable` needs a workspace
    id, which the workspace-scoped group has in ctx (`_wid`) but the top-level group does
    not — so the top-level `cookable` takes a required `--workspace-id` option instead.
    """

    @proposal_group.command(name="show")
    @click.pass_context
    def _show(ctx):
        """Show a proposal: state, the blueprint plan paired to the cook outcome per step
        (did each step run — validated/running/pending/failed), and its artifacts. Use
        --json / --yaml for the raw detail payload."""
        _proposal_show_core(ctx)

    @proposal_group.command(name="cancel")
    @click.pass_context
    def _cancel(ctx):
        """Request a graceful cancel of a running build (blueprinting/cooking). Cooperative stop;
        the cook returns to blueprint_ready (blueprint→intent_only). No-op if not running."""
        _proposal_cancel_core(ctx)

    @proposal_group.command(name="reset-to-intent")
    @click.pass_context
    def _reset_to_intent(ctx):
        """DEEP reset → intent_only: DROP the authored blueprint AND the cook (artifacts removed,
        cook_state cleared). Only the intent survives — re-run `blueprint start` to rebuild from
        scratch. Contrast `cook reset` which KEEPS the blueprint. Refused while a cook is live."""
        _reset_to_intent_core(ctx)

    @proposal_group.command(name="iterations")
    @click.pass_context
    def _iterations(ctx):
        """SA: the proposal's build→critique iterations — each Blueprint/Cook run with its
        Builder(author/gen) + Critic(review) invokes and the critic verdict. Shows the
        build→critique→(refine) loop. Requires super_admin."""
        _iterations_core(ctx)

    if workspace_scoped:
        @proposal_group.command(name="cookable")
        @click.pass_context
        def _cookable_ws(ctx):
            """Deterministic precondition check (no LLM) — is this proposal buildable/cookable?

            Resolves the id (build_v2 OR system) and returns {cookable, build_v2_id, reason}.
            Use before triggering a cook so an un-cookable/bogus id never reaches the agent
            (Spec D § 3.10). Works for a system-proposal id too (ensures it is mirrored first)."""
            _proposal_cookable_core(ctx)
    else:
        @proposal_group.command(name="cookable")
        @click.option("--workspace-id", "workspace_id", required=True,
                      help="Workspace the proposal belongs to (needed to ensure-mirror a system id).")
        @click.pass_context
        def _cookable_top(ctx, workspace_id):
            """Deterministic precondition check (no LLM) — is this proposal buildable/cookable?

            Resolves the id (build_v2 OR system) and returns {cookable, build_v2_id, reason}.
            Use before triggering a cook so an un-cookable/bogus id never reaches the agent
            (Spec D § 3.10). Works for a system-proposal id too (ensures it is mirrored first)."""
            _proposal_cookable_core(ctx, workspace_id=workspace_id)

    @proposal_group.command(name="status")
    @click.pass_context
    def _status(ctx):
        """Show per-artifact state (the deploy/cook ledger)."""
        _proposal_status_core(ctx)

    @proposal_group.command(name="advisories")
    @click.pass_context
    def _advisories(ctx):
        """Show critic advisories to review before deploying (BG2, Spec E § 3.9)."""
        _proposal_advisories_core(ctx)

    @proposal_group.command(name="provenance")
    @click.pass_context
    def _provenance(ctx):
        """Show the provenance chain: intent → blueprint → step → artifacts (INDEX #13/#20)."""
        _proposal_provenance_core(ctx)

    @proposal_group.command(name="lifecycle")
    @click.pass_context
    def _lifecycle(ctx):
        """Show the lifecycle chain: all phase-runs (blueprint / cook / deploy) time-ordered,
        each with its status + otel_trace_id (the SA lifecycle view's data)."""
        _proposal_lifecycle_core(ctx)

    @proposal_group.command(name="validate")
    @click.option("--phase", type=click.Choice(["intent", "blueprint", "program"]), default=None,
                  help="Scope the checks: intent (C1–C2) | blueprint (C3–C5) | program (C6). "
                       "Omit to run every rule the proposal's data supports.")
    @click.option("--downstream", is_flag=True, default=False,
                  help="ALSO validate each artifact's create payload against its downstream "
                       "service (Tier-2 dry-run) — catches payload/schema drift the completeness "
                       "check can't (e.g. a bad cron, a display_config the widget service rejects). "
                       "Read-only, nothing is created.")
    @click.pass_context
    def _validate(ctx, phase, downstream):
        """Check this proposal's COMPLETENESS against the platform's deterministic rules (C1–C6):
        intent is a real promise (not the title / not too thin), the blueprint was grounded, each
        step produces a real name + names its policy, and the built set is a program. Read-only —
        no state change. Exits non-zero if incomplete, so a build script/skill can gate on it.

        With --downstream, additionally dry-runs each artifact against its owning service so a
        payload the downstream would reject surfaces here instead of at deploy."""
        _validate_completeness_core(ctx, phase, downstream=downstream)

    @proposal_group.group(name="rebase", invoke_without_command=True)
    @click.pass_context
    def _rebase(ctx):
        """REBASE a STALE or SUPERSEDED candidate onto the current live system — re-derive the HOW
        against what's now live, rebuilding ONLY what changed, and STOP at deployable (or
        superseded). NEVER deploys. Two ways to drive it:

          • `rebase run`  — the platform drives (server-side re-blueprint + diff + re-cook). One
                            call; poll `lifecycle` for the outcome. (What the Torana UI button does.)
          • `rebase diff` + `rebase apply` — YOU (a Claude skill) drive: re-author the blueprint,
                            get the deterministic diff, apply it, then `cook run` the changed steps.

        The safe alternative to `reanchor` for a stale candidate: reanchor only re-validates and is
        blind to duplication/re-planning; rebase re-derives the HOW."""
        if ctx.invoked_subcommand is None:
            click.echo(ctx.get_help())

    @_rebase.command(name="run")
    @click.option("--workspace-id", "workspace_id", required=False, default=None,
                  help="Workspace the proposal belongs to. Optional under `workspace <id>` "
                       "(derived from the path); required only from the top-level form.")
    @click.pass_context
    def _rebase_run(ctx, workspace_id):
        """Platform-driven rebase (background): the server re-blueprints, diffs, and re-cooks only
        what changed → deployable/superseded. Poll `lifecycle`/`show` for the outcome. NEVER
        deploys. (This is the Torana FE facade path — one call, no in-session re-blueprint.)"""
        _proposal_rebase_run_core(ctx, workspace_id)

    @_rebase.command(name="diff")
    @click.option("--blueprint", "blueprint_json", default=None, help="Fresh blueprint JSON.")
    @click.option("--blueprint-file", "blueprint_file", default=None,
                  help="Path to a JSON file with the fresh (re-authored) blueprint.")
    @click.pass_context
    def _rebase_diff(ctx, blueprint_json, blueprint_file):
        """DETERMINISTIC diff (no LLM) of your re-authored blueprint vs the candidate's current one:
        {reuse[], recook[], drop[], diff_token, outcome_preview}. Read-only. Self-drive path — pass
        the same blueprint + diff_token to `rebase apply`."""
        _proposal_rebase_diff_core(ctx, blueprint_json, blueprint_file)

    @_rebase.command(name="apply")
    @click.option("--blueprint", "blueprint_json", default=None, help="Fresh blueprint JSON.")
    @click.option("--blueprint-file", "blueprint_file", default=None,
                  help="Path to a JSON file with the fresh (re-authored) blueprint.")
    @click.option("--diff-token", "diff_token", required=True,
                  help="The diff_token returned by `rebase diff` (guards against a racing deploy).")
    @click.pass_context
    def _rebase_apply(ctx, blueprint_json, blueprint_file, diff_token):
        """Apply the rebase: save the fresh blueprint, drop absent steps, re-pin the anchor, and
        either mark SUPERSEDED or seed the changed steps → COOKING. Then run `cook run` to re-cook
        ONLY those steps → deployable. 409 rebase_stale_diff if the token is stale. NEVER deploys."""
        _proposal_rebase_apply_core(ctx, blueprint_json, blueprint_file, diff_token)

    # ---- blueprint sub-group: … blueprint start|save|approve|show|run ----

    @proposal_group.group(name="blueprint", invoke_without_command=True)
    @click.pass_context
    def _blueprint(ctx):
        """Blueprint lifecycle: start | save | approve | show | run.

        The grounded, structured plan that converges intents + system proposals before
        cooking. Mandatory — the cook cannot start until the blueprint is approved."""
        if ctx.invoked_subcommand is None:
            click.echo(ctx.get_help())

    @_blueprint.command(name="run")
    @click.option("--workspace-id", "workspace_id", required=False, default=None,
                  help="Workspace the proposal belongs to. Optional under `workspace <id>` "
                       "(derived from the path); required only from the top-level form.")
    @click.pass_context
    def _blueprint_run(ctx, workspace_id):
        """[PLATFORM-AGENT AUTHORING — Torana harness] Launch the Program Blueprinter in the
        background to author + save a grounded blueprint (leaves it blueprint_ready for
        approval). Poll `blueprint show` for the result. An EXTERNAL authoring harness (e.g. a
        Claude session driving the torana-build skill) should NOT use this — author the
        blueprint itself and submit via `blueprint save`."""
        _blueprint_run_core(ctx, workspace_id)

    @_blueprint.command(name="refine")
    @click.option("--workspace-id", "workspace_id", required=False, default=None,
                  help="Workspace the proposal belongs to. Optional under `workspace <id>` "
                       "(derived from the path); required only from the top-level form.")
    @click.option("--instruction", "instruction", required=True,
                  help="How to refine, e.g. 'drop the dashboard step' or 'add a Slack step for P0'.")
    @click.pass_context
    def _blueprint_refine(ctx, workspace_id, instruction):
        """Refine the EXISTING blueprint (grounded re-author, NOT a free-hand edit) per the
        instruction; bumps the version, leaves it blueprint_ready. Poll `blueprint show`."""
        _blueprint_refine_core(ctx, workspace_id, instruction)

    @_blueprint.command(name="start")
    @click.pass_context
    def _blueprint_start(ctx):
        """intent_only → blueprinting (begin the Blueprinting stage).

        No --workspace-id: this verb posts to a `workspaces/…` route, which resolves the
        workspace from the proposal id itself. (The `agents/…` verbs — `run`, `refine`,
        `step` — DO need it, because those routes do not.)"""
        _blueprint_start_core(ctx)

    @_blueprint.command(name="save")
    @click.option("--blueprint", "blueprint_json", default=None,
                  help="Blueprint JSON, e.g. '{\"steps\":[{\"step_id\":\"1.1\",...}]}'.")
    @click.option("--blueprint-file", default=None, help="Path to a JSON file with the blueprint.")
    @click.pass_context
    def _blueprint_save(ctx, blueprint_json, blueprint_file):
        """Save the authored blueprint (shape-validated): blueprinting → blueprint_ready."""
        _blueprint_save_core(ctx, blueprint_json, blueprint_file)

    @_blueprint.command(name="approve")
    @click.pass_context
    def _blueprint_approve(ctx):
        """Freeze the blueprint as the cook's input: blueprint_state ready → approved."""
        _blueprint_approve_core(ctx)

    @_blueprint.command(name="show")
    @click.pass_context
    def _blueprint_show(ctx):
        """Show the blueprint JSON + its state."""
        _blueprint_show_core(ctx)

    # ---- cook sub-group: … cook start|run|finalize ----

    @proposal_group.group(name="cook", invoke_without_command=True)
    @click.pass_context
    def _cook(ctx):
        """Cook lifecycle: start | run | finalize."""
        if ctx.invoked_subcommand is None:
            click.echo(ctx.get_help())

    @_cook.command(name="start")
    @click.pass_context
    def _cook_start(ctx):
        """blueprint_ready → cooking (requires an approved blueprint — no intent→cook bypass).

        No --workspace-id: this verb posts to a `workspaces/…` route, which resolves the
        workspace from the proposal id itself. (The `agents/…` verbs — `run`, `refine`,
        `step` — DO need it, because those routes do not.)"""
        _cook_start_core(ctx)

    @_cook.command(name="run")
    @click.option("--workspace-id", "workspace_id", required=False, default=None,
                  help="Workspace the proposal belongs to. Optional under `workspace <id>` "
                       "(derived from the path); required only from the top-level form.")
    @click.option("--reset", is_flag=True, default=False,
                  help="Force a clean re-cook: reset all artifacts→draft + clear cook_state "
                       "(approved blueprint kept) before cooking, so EVERY step re-cooks. Use "
                       "when a 'validated' step's output table is gone and `run` keeps skipping it.")
    @click.option("--reset-hard", is_flag=True, default=False,
                  help="Like --reset, but ALSO drop the produced transformer tables — a true "
                       "'nothing built' start.")
    @click.pass_context
    def _cook_run(ctx, workspace_id, reset, reset_hard):
        """[PLATFORM-AGENT AUTHORING — Torana harness] Launch the CODE cook driver in the
        background to cook the APPROVED blueprint to deployable (author→validate→refine per
        step, hard-capped). Poll `provenance`/`status` for progress. Requires the proposal be
        blueprint_ready + approved. An EXTERNAL authoring harness (e.g. a Claude session
        driving the torana-build skill) should NOT use this — author each step itself via
        `cook start` → `artifact add` → `artifact validate` → `cook finalize`."""
        _cook_run_core(ctx, workspace_id, reset=reset, reset_hard=reset_hard)

    @_cook.command(name="step")
    @click.option("--workspace-id", "workspace_id", required=False, default=None,
                  help="Workspace the proposal belongs to. Optional under `workspace <id>` "
                       "(derived from the path); required only from the top-level form.")
    @click.option("--wait", is_flag=True, default=False,
                  help="Block until the step finishes and print a VERDICT. Polls "
                       "client-side: the API stays 202-and-poll, so a dropped "
                       "response is retried, not fatal. Exit 0=all validated, "
                       "1=a step failed/GAPped, 2=timed out (the build is STILL "
                       "RUNNING), 64=usage error (nothing ran).")
    @click.option("--timeout", "timeout", default=900, show_default=True, type=int,
                  help="With --wait: give up after this many seconds. The build is "
                       "NOT cancelled on timeout - only the waiting stops.")
    @click.pass_context
    def _cook_step(ctx, workspace_id, wait, timeout):
        """[PLATFORM-AGENT AUTHORING — Torana harness] Cook the ONE next-pending blueprint step,
        then stop (step-by-step testing). Same core path as `run`, bounded to a single step;
        state stays `cooking` until the last step (→ deployable). Background — a step is a full
        LLM cycle (minutes); poll `status`/`show` for the result. Rejected (409) if a cook
        session (step OR full cook) is already running."""
        _cook_step_core(ctx, workspace_id, wait=wait, timeout=timeout)

    @_cook.command(name="steps")
    @click.option("--wait", is_flag=True, default=False,
                  help="Block until every step reaches a terminal state.")
    @click.option("--timeout", "timeout", default=900, show_default=True, type=int,
                  help="With --wait: give up after this many seconds.")
    @click.pass_context
    def _cook_steps_cmd(ctx, wait, timeout):
        """The per-step VERDICT: which blueprint steps validated, which did not, and WHY.

        The one command that answers "is this build actually progressing?". Reads
        `cook_state.steps[]`, which records EVERY step - including one that returned a GAP
        and therefore produced NO artifact. `artifact list` cannot show those (there is
        nothing to list), so a GAP was invisible from the CLI and only the FE told the truth.

        Exit 0 = all validated, 1 = a step failed or GAPped, 2 = timed out (--wait only)."""
        if wait:
            steps, timed_out = _wait_for_step(ctx, timeout)
        else:
            steps, timed_out = _cook_steps(ctx), False
        if not steps:
            if _fmt(ctx) == "text":
                click.echo("No build has started for this proposal (no step ledger yet).")
            else:
                output({"items": []}, fmt=_fmt(ctx))
            return
        _echo_step_verdict(ctx, steps, timed_out)
        if timed_out:
            ctx.exit(2)
        if any(str(x.get("status") or "").lower() in ("failed", "rejected", "gap")
               for x in steps):
            ctx.exit(1)

    @_cook.command(name="recook-step")
    @click.argument("step_id", metavar="STEP_ID")
    @click.option("--workspace-id", "workspace_id", required=False, default=None,
                  help="Workspace the proposal belongs to. Optional under `workspace <id>`.")
    @click.pass_context
    def _cook_recook_step(ctx, step_id, workspace_id):
        """Re-cook ONLY blueprint step STEP_ID (e.g. '3.3'), leaving every other validated step
        untouched — the surgical fix for one broken step (e.g. a widget the cook-fidelity check
        rejected). Resets that step's artifact(s) + dependents to draft, then the LLM re-authors
        just that step. Background — poll `status`/`show`. Rejected (409) if a cook is already
        running or STEP_ID is not in the approved blueprint."""
        _recook_step_core(ctx, step_id, workspace_id)

    @_cook.command(name="reset")
    @click.option("--hard", is_flag=True, default=False,
                  help="Also drop the produced transformer tables (a true 'nothing built' start). "
                       "Default (soft) keeps tables, just un-validates artifacts + clears cook_state.")
    @click.pass_context
    def _cook_reset(ctx, hard):
        """Reset a failed/wedged cook → blueprint_ready (approved blueprint kept), so it can be
        re-cooked from a clean ledger. Follow with `cook run`. Refused while a peer cook is live."""
        _cook_reset_core(ctx, hard=hard)

    @_cook.command(name="finalize")
    @click.pass_context
    def _cook_finalize(ctx):
        """cooking → deployable (rejected unless every artifact is validated)."""
        _cook_finalize_core(ctx)

    @_cook.command(name="fail")
    @click.option("--reason", required=True, help="Why the cook failed (budget breach / unresolvable step).")
    @click.option("--stage", "failed_stage", default="cook",
                  type=click.Choice(["blueprint", "cook", "deploy"]),
                  help="Which stage failed (default: cook).")
    @click.pass_context
    def _cook_fail(ctx, reason, failed_stage):
        """Record a clean cook abort: cooking → failed with a reason. Used when a driver
        (e.g. the torana-build skill) hits its per-artifact refine cap and stops rather than
        looping — so the proposal doesn't linger stuck in 'cooking'."""
        body = {"reason": reason, "failed_stage": failed_stage}
        data = _call(ctx, "POST", f"workspaces/build-v2/proposals/{_pid(ctx)}/cook/fail", body)
        if data is not None:
            output(data, fmt=_fmt(ctx))

    # ---- artifact sub-group: … artifact list|add|validate|edit ----

    @proposal_group.group(name="artifact", invoke_without_command=True)
    @click.pass_context
    def _artifact(ctx):
        """Artifacts of this proposal: list | add | validate | edit."""
        if ctx.invoked_subcommand is None:
            click.echo(ctx.get_help())

    @_artifact.command(name="list")
    @click.pass_context
    def _artifact_list(ctx):
        """List this proposal's artifacts + their states (draft|validated|rejected|deployed).
        A cheap dedicated read for a cook loop to see which steps are done and which to retry.

        ⚠️ This does NOT return each artifact's `definition` (the SQL body), and that is
        deliberate — full SQL on every row of a list read balloons the payload for a view
        whose job is "which steps are done?". To READ THE COOKED SQL use:

            torana build proposal <PID> export          # artifacts.yaml, full definitions

        ⭐ Documented here because its absence reads as "the SQL is unreachable". It is not:
        `export` is deploy-independent and returns the definition byte-identical to what is
        stored (verified 2026-08-27). There is no `artifact show` verb; `export` is the surface."""
        data = _call(ctx, "GET", f"workspaces/build-v2/proposals/{_pid(ctx)}/artifacts")
        if data is None:
            return
        items = data if isinstance(data, list) else (data.get("items") or [])

        # PLANNED-BUT-UNBUILT STEPS ARE SHOWN TOO. A step that returns a GAP creates NO
        # artifact, so listing only artifacts made "failed" and "still running" look
        # identical — measured 2026-08-20: a caller polling this endpoint waited out its
        # whole loop for a row that could never appear, while the FE showed the step as
        # FAILED all along. The step ledger has it; surface it here rather than making
        # every caller cross-reference `show`.
        try:
            built = {str(a.get("source_blueprint_step_id") or "") for a in items}
            for st in _cook_steps(ctx):
                sid = str(st.get("step_id") or "")
                status = str(st.get("status") or "").lower()
                if not sid or sid in built or status == "validated":
                    continue
                items.append({
                    "artifact_key": f"({sid})",
                    "artifact_type": st.get("artifact_type") or "-",
                    # NOT_BUILT is deliberately distinct from any artifact state: it means
                    # no artifact exists, which is a different fact from one that exists
                    # and was rejected.
                    "state": "NOT_BUILT" if status in ("failed", "gap") else status.upper(),
                    "rejection_reason": st.get("reason") or "",
                })
        except Exception:
            pass  # never let the enrichment break the primary listing

        output({"items": items}, fmt=_fmt(ctx), columns=_ARTIFACT_STATUS_COLS)

    @_artifact.command(name="add")
    @click.option("--type", "artifact_type", required=True,
                  help="transformer|rule|dashboard|widget|kpi|attention_card|route|playbook|scheduler")
    @click.option("--key", "artifact_key", required=True, help="Stable key, unique within the proposal.")
    @click.option("--definition", default=None, help="Definition JSON, e.g. '{\"sql\":\"SELECT ...\"}'.")
    @click.option("--definition-file", default=None, help="Path to a JSON file with the definition.")
    @click.option("--depends-on", default=None, help="Comma-separated artifact_key dependencies.")
    @click.option("--source-step", "source_blueprint_step_id", default=None,
                  help="The blueprint step_id this artifact came from. REQUIRED once the "
                       "proposal's blueprint is approved (provenance by construction).")
    @click.option("--description", default="", help="Short human-facing blurb (NOT the intent).")
    @click.option("--semantic-description", default=None,
                  help="The artifact INTENT — the five-part question/grain/semantics/scope/"
                       "fallback block a regeneration reads. Omit to have the server derive a "
                       "rationale from the blueprint step (warns).")
    @click.option("--semantic-description-file", default=None,
                  help="Path to a file holding the intent. Prefer this: a conforming intent is "
                       "multi-line and ~1,400 chars.")
    # § 3.4.5 / § 3.12.1 — the three CALLER-owned fields. Without these flags a skill can
    # ADJUDICATE the catalog but cannot RECORD its decision, so the catalog gate stays
    # unsatisfiable from the CLI path exactly as it was from the agent path.
    @click.option("--catalog-entry-id", "catalog_entry_id", default=None,
                  help="The catalog entry this artifact REUSES (drop the SQL when set).")
    @click.option("--catalog-decision-id", "catalog_decision_id", default=None,
                  help="The recorded miss id when NO entry fit — from `vm transformers "
                       "catalog record-miss '<need>'`.")
    @click.option("--required-integrations", "required_integrations", default=None,
                  help="Comma-separated integrations this artifact needs CONNECTED. Reconciled "
                       "server-side against what the SQL reads; a mismatch is recorded, not "
                       "overwritten.")
    @click.option("--question-id", "question_id", default=None, metavar="EM-NNN",
                  help="The canonical corpus question this artifact answers, from "
                       "`torana admin question-resolve '<ask>'`. RESOLVE FIRST — before any "
                       "schema probe. Omit it when the ask did not resolve; UNRESOLVED is a "
                       "result recorded as demand, never an error.")
    @click.option("--validate", "do_validate", is_flag=True, default=False,
                  help="Immediately validate the artifact after adding it (add → validate in one "
                       "step). Prints the validation result instead of the add result.")
    @click.pass_context
    def _artifact_add(ctx, artifact_type, artifact_key, definition, definition_file, depends_on,
                      source_blueprint_step_id, description, semantic_description,
                      semantic_description_file, catalog_entry_id, catalog_decision_id,
                      required_integrations, question_id, do_validate):
        """Add a draft artifact to this proposal.

        \b
        ⛔ --description and --semantic-description are DIFFERENT FIELDS. `description` is a
        short blurb; `semantic_description` is the regeneration-grade INTENT. Putting the
        intent inside --definition does NOT work either — that writes
        definition.semantic_description, which no gate or reader looks at.
        """
        if not do_validate:
            _artifact_add_core(ctx, artifact_type, artifact_key, definition, definition_file,
                               depends_on, source_blueprint_step_id, description,
                               semantic_description=semantic_description,
                               semantic_description_file=semantic_description_file,
                               catalog_entry_id=catalog_entry_id,
                               catalog_decision_id=catalog_decision_id,
                               required_integrations=required_integrations,
                               question_id=question_id)
            return
        # add --validate: chain the two existing endpoints (no combined backend endpoint exists).
        added = _artifact_add_core(ctx, artifact_type, artifact_key, definition, definition_file,
                                   depends_on, source_blueprint_step_id, description, emit=False,
                                   semantic_description=semantic_description,
                                   semantic_description_file=semantic_description_file,
                                   catalog_entry_id=catalog_entry_id,
                                   catalog_decision_id=catalog_decision_id,
                                   required_integrations=required_integrations,
                                   question_id=question_id)
        if not added:
            return  # add failed; _call already surfaced the error
        artifact_id = added.get("id") or added.get("artifact_id")
        if not artifact_id:
            # Can't chain without the new id — fall back to showing the add result.
            output(added, fmt=_fmt(ctx))
            return
        _artifact_validate_core(ctx, artifact_id)

    @_artifact.command(name="validate")
    @click.argument("artifact_id", metavar="ARTIFACT_ID")
    @click.pass_context
    def _artifact_validate(ctx, artifact_id):
        """Validate an artifact: draft → validated | rejected."""
        _artifact_validate_core(ctx, artifact_id)

    @_artifact.command(name="edit")
    @click.argument("artifact_id", metavar="ARTIFACT_ID")
    @click.option("--definition", default=None, help="New definition JSON.")
    @click.option("--definition-file", default=None, help="Path to a JSON file with the new definition.")
    @click.option("--semantic-description", default=None,
                  help="Replace the artifact INTENT (the five-part "
                       "question/grain/semantics/scope/fallback block).")
    @click.option("--semantic-description-file", default=None,
                  help="Path to a file holding the new intent. A conforming intent runs "
                       "~1,400 characters, which does not sit on a command line.")
    @click.pass_context
    def _artifact_edit(ctx, artifact_id, definition, definition_file,
                       semantic_description, semantic_description_file):
        """Edit an artifact (validated → draft; cascades dependents to draft).

        Pass --definition/--definition-file to change the SQL or config, and/or
        --semantic-description[-file] to repair the INTENT. An intent-only edit does not
        re-run the definition gates and does not cascade dependents — nothing downstream
        depends on the prose.
        """
        _artifact_edit_core(ctx, artifact_id, definition, definition_file,
                            semantic_description, semantic_description_file)

    # ---- deploy verbs ----

    @proposal_group.command(name="deploy")
    @click.option("--upsert", is_flag=True, default=False,
                  help="Adopt an already-live artifact whose name collides instead of "
                       "failing the whole deploy with a 409. Use when re-deploying a fix "
                       "over a program that is already live.")
    @click.pass_context
    def _deploy(ctx, upsert):
        """Deploy a deployable proposal → creates the real artifacts (Spec C).

        deployable → deploying → deployed | rolled_back. Whole-manifest atomic:
        pre-flight re-validates, applies topo-ordered, rolls back on any failure."""
        _deploy_core(ctx, upsert=upsert)

    @proposal_group.command(name="reanchor")
    @click.pass_context
    def _reanchor(ctx):
        """Re-anchor a STALE deployable candidate onto the app's current live version.

        A build cooked against v1 becomes stale once another build deploys v2 — deploy is then
        blocked until you re-anchor. Re-anchor re-validates every artifact against the new base;
        on a clean pass the build can deploy, on a conflict it lists the artifact(s) to fix
        (BUILD_V2_ANCHOR_STALENESS_GATE_SPEC § 3.4.3)."""
        _proposal_reanchor_core(ctx)

    @proposal_group.command(name="deploy-status")
    @click.pass_context
    def _deploy_status(ctx):
        """Per-artifact deploy ledger + overall proposal state (Spec C)."""
        _deploy_status_core(ctx)

    @proposal_group.command(name="deploy-reset")
    @click.pass_context
    def _deploy_reset(ctx):
        """Reset a rolled_back proposal → deployable so a fixed deploy can retry.

        Reaps any artifact a prior failed attempt left downstream (tagged to this
        proposal), then resets the ledger to 'deployable' and clears the failure
        reason. A 'reset' lifecycle event is recorded for the attempt trail."""
        _deploy_reset_core(ctx)

    @proposal_group.command(name="deploy-orphans")
    @click.pass_context
    def _deploy_orphans(ctx):
        """List downstream artifacts a prior failed/rolled-back deploy left behind.

        Each orphan is keyed to the deploy attempt (deploy_run_id) that created it — the
        rows `deploy-reset` would reap. TYPE / ID / ATTEMPT columns."""
        _deploy_orphans_core(ctx)

    @proposal_group.command(name="attempts")
    @click.pass_context
    def _attempts(ctx):
        """Show the deploy-attempt series (folded from the lifecycle runs).

        A deploy and its rollback fold into one attempt; a reset between two attempts is
        shown as a '↳ reset' marker. Each attempt shows status (deployed ✓ / rolled_back
        ✗ / running ◐), failure reason, and duration. --json emits the folded structure."""
        _attempts_core(ctx)

    @proposal_group.command(name="delete")
    @click.option("--yes", "--force", "yes", is_flag=True, default=False,
                  help="Skip the confirmation prompt (non-interactive discard). "
                       "--force is an alias.")
    @click.pass_context
    def _delete(ctx, yes):
        """Discard (soft-delete) this proposal so it leaves the list. Prompts unless --yes.

        Refused (409) while the proposal is deploying or already deployed (undeploy/roll
        back first)."""
        _proposal_delete_core(ctx, yes=yes)

    @proposal_group.command(name="export")
    @click.option("--out", "out", default=None,
                  help="Write artifacts.yaml to this path (default: print to stdout).")
    @click.pass_context
    def _export(ctx, out):
        """Export this proposal's cooked artifacts as artifacts.yaml.

        DEPLOY-INDEPENDENT: works the moment cook produced artifacts — whether or not the
        proposal was ever deployed (exportable ⇔ deployable, not deployed)."""
        _export_proposal_core(ctx, out)


# ═══════════════════════════════════════════════════════════════════════════
# Top-level singular group:  torana build proposal <ID> …
# ═══════════════════════════════════════════════════════════════════════════

@click.group(name="build")
def build_v2():
    """Build programs — deployable proposals & their artifacts.

    \b
    The lifecycle is a STATE MACHINE, not four independent verbs:
      proposal → blueprint → cook → deploy
    A proposal collects intent; a blueprint plans it; cook generates the artifacts;
    deploy makes them live. You cannot skip a step, and a stage only accepts input
    when the one before it has completed.

    \b
    ⛔ `blueprint run` and `cook run|step` launch the platform's OWN authoring
    agents. They are hook-blocked and reserved for explicit requests to exercise
    that path — driving them from a skill produces ungrounded programs that deploy
    green and return nothing.

    \b
    Start here:
      torana build capabilities                    what this platform's driver supports
      torana build proposals list --workspace-id <WID>
      torana build proposal <PID> show             one proposal, all its facets

    \b
    Examples:
      torana build proposals list --workspace-id <WID> --json
      torana build proposal <PID> show
      torana build blueprints list --workspace-id <WID>
      torana build versions list --workspace-id <WID>
      torana build deployment <DID> get
    """


@build_v2.command(name="capabilities")
@click.pass_context
def bv2_capabilities(ctx):
    """Show the platform's build_v2 driver capabilities: the artifact-definition schema (fetched
    from the platform — never bundled), the artifact-type list, and the two versions a driver
    gates on (definition_schema_version + fsm_contract_version). Use --json for the full payload
    a skill consumes; the default prints a compact human summary."""
    data = _call(ctx, "GET", "workspaces/build-v2/capabilities")
    if data is None:
        return
    fmt = _fmt(ctx)
    if fmt in ("json", "yaml"):
        output(data, fmt=fmt)
        return
    # Compact human summary (the full schema is large — show it only via --json).
    click.echo(f"definition_schema_version : {data.get('definition_schema_version')}")
    click.echo(f"fsm_contract_version      : {data.get('fsm_contract_version')}")
    types = data.get("artifact_types", [])
    click.echo(f"artifact_types ({len(types)})       : {', '.join(types)}")
    fsm = data.get("fsm", {})
    click.echo(f"proposal_states ({len(fsm.get('proposal_states', []))})       : "
               f"{', '.join(fsm.get('proposal_states', []))}")
    click.echo(f"artifact_states ({len(fsm.get('artifact_states', []))})        : "
               f"{', '.join(fsm.get('artifact_states', []))}")
    click.echo(f"terminal_states           : {', '.join(fsm.get('terminal_proposal_states', []))}")
    click.echo("(use --json for the full definition_schema payload)")


@build_v2.command(name="preflight")
@click.option("--workspace-id", "workspace_id", required=True, metavar="UUID",
              help="Workspace the build will target.")
@click.pass_context
def bv2_preflight(ctx, workspace_id):
    """Read-only: can a build succeed here, BEFORE any SQL is authored?

    \b
    Four conditions block a build and are otherwise only discoverable by hitting
    them mid-cook — each costing a reset, a full revalidation, or an interrupt:

    \b
      policy        ratification state — a rejected artifact deep in the cook loop
      vocabulary    the BINDABLE key set — the registry and the listing disagree,
                    so a documented key can still reject at deposit
      catalog       entry health — a catalog_entry_id can validate clean and then
                    roll back the whole proposal at deploy
      integrations  reachability — a 404 mid-build
      schema        the DDL revision the SQL will be authored against

    \b
    Nothing here writes. Exits non-zero if any check is BLOCKED, so a build
    script can gate on it.
    """
    fmt = _fmt(ctx)
    checks = []

    def _check(name, detail, ok, note=""):
        checks.append({"check": name, "status": "ok" if ok else "BLOCKED",
                       "detail": detail, "note": note})

    # --- policy conformance + ratification -------------------------------
    pol = _soft_get(ctx, "vm/policy/conformance")
    if isinstance(pol, dict):
        ok = bool(pol.get("passed"))
        violations = pol.get("violations") or []
        _check("policy",
               "conformance PASSED" if ok
               else f"{len(violations)} conformance violation(s)",
               ok,
               "" if ok else "; ".join(str(v) for v in violations[:3])
               or "ratify or rebind the policy before authoring")
    else:
        _check("policy", "could not read vm/policy/conformance", False,
               "run `torana vm policy conformance` for the detail")

    # --- vocabulary: the BINDABLE set, not the documented one -------------
    vocab = _soft_get(ctx, "vm/policy/vocabulary")
    keys = vocab if isinstance(vocab, list) else (vocab or {}).get("items", [])
    bindable = [k for k in keys if isinstance(k, dict) and not k.get("deprecated")]
    deprecated = [k.get("key") for k in keys
                  if isinstance(k, dict) and k.get("deprecated")]
    _check("vocabulary", f"{len(bindable)} bindable of {len(keys)} listed key(s)",
           bool(bindable),
           ("deprecated (do NOT bind): " + ", ".join(str(d) for d in deprecated[:5]))
           if deprecated else "")

    # --- catalog health ---------------------------------------------------
    cat = _soft_get(ctx, "vm/transformers/catalog")
    entries = cat if isinstance(cat, list) else (cat or {}).get("items", [])
    _check("catalog", f"{len(entries)} entry(ies) readable", bool(entries),
           "" if entries else "catalog unreadable — author privately and record the miss")

    # --- integrations reachability ---------------------------------------
    integ = _soft_get(ctx, "/api/v1/integrations")
    rows = (integ if isinstance(integ, list)
            else (integ or {}).get("integrations") or (integ or {}).get("items") or [])
    _check("integrations", f"{len(rows)} integration(s) reachable", integ is not None,
           "" if integ is not None else "integrations endpoint returned nothing")

    # --- schema revision ---------------------------------------------------
    rev = _soft_get(ctx, "/api/v1/datalake/schema/revision")
    head = (rev or {}).get("revision") if isinstance(rev, dict) else None
    _check("schema", f"DDL head: {head}" if head else "revision unavailable", bool(head))

    blocked = [c for c in checks if c["status"] != "ok"]
    result = {"workspace_id": workspace_id, "checks": checks,
              "blocked": len(blocked), "ok": not blocked}

    if fmt in ("json", "yaml"):
        output(result, fmt=fmt)
    else:
        click.echo(f"BUILD PREFLIGHT — workspace {workspace_id}\n")
        for c in checks:
            mark = "\u2713" if c["status"] == "ok" else "\u2717"
            click.echo(f"  {mark} {c['check']:<13} {c['detail']}")
            if c["note"]:
                click.echo(f"    {'':<15}{c['note']}")
        click.echo()
        if blocked:
            click.echo(f"BLOCKED — {len(blocked)} check(s) would fail a build. "
                       f"Resolve them before authoring SQL.")
        else:
            click.echo("READY — nothing here blocks a build.")

    if blocked:
        import sys
        sys.exit(1)


@build_v2.group(name="blueprints", invoke_without_command=True)
@click.pass_context
def bv2_blueprints(ctx):
    """Blueprints across a workspace's proposals. Use `list`."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@bv2_blueprints.command(name="list")
@click.option("--workspace-id", "workspace_id", required=True, help="Workspace to list blueprints in.")
@click.option("--status", "status", default=None,
              help="Filter by blueprint_state: authoring | ready | approved | none.")
@click.pass_context
def bv2_blueprints_list(ctx, workspace_id, status):
    """List proposals in a workspace with their blueprint_state (authoring = currently being
    built, ready = awaiting approval, approved = cooking-eligible). This is the 'what blueprints
    exist / are running' view."""
    data = _call(ctx, "GET", f"workspaces/{workspace_id}/build-v2/proposals")
    if data is None:
        return
    items = data.get("items", []) if isinstance(data, dict) else []
    rows = [i for i in items if i.get("kind") == "build_v2"
            and (i.get("blueprint_state") or "none") != "none"]
    if status:
        rows = [i for i in rows if (i.get("blueprint_state") or "none") == status]
    output({"items": rows}, fmt=_fmt(ctx), fields=_fields(ctx), columns=[
        ("id", "ID", 36), ("title", "TITLE", 36),
        ("state", "STATE", 14), ("blueprint_state", "BLUEPRINT", 12),
    ])


@build_v2.group(name="versions", invoke_without_command=True)
@click.pass_context
def bv2_versions(ctx):
    """App versions (deployment snapshots) of a workspace. Use `list` / `show`."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@bv2_versions.command(name="list")
@click.option("--workspace-id", "workspace_id", required=True, help="Workspace (app) to list versions of.")
@click.option("--limit", "limit", default=100, type=int, help="Max versions to return (<=100).")
@click.pass_context
def bv2_versions_list(ctx, workspace_id, limit):
    """List a workspace's app versions, newest first — each version is an immutable snapshot
    of everything deployed at that deploy. Top-level equivalent of
    `torana workspace <WS> build versions list`."""
    data = _call(ctx, "GET", f"workspaces/{workspace_id}/build-v2/deployments?limit={limit}")
    if data is not None:
        output(_enrich_versions(data), fmt=_fmt(ctx), fields=_fields(ctx),
               columns=_VERSION_COLS)


@bv2_versions.command(name="uninstall")
@click.option("--workspace-id", "workspace_id", required=True, help="Workspace (app).")
@click.argument("versions", metavar="VERSION...", nargs=-1, required=True, type=int)
@click.option("--dry-run/--no-dry-run", default=True, show_default=True,
              help="Preview only. --no-dry-run actually removes.")
@click.option("--yes", "-y", is_flag=True, default=False,
              help="Skip the confirmation prompt (the preview is still printed).")
@click.pass_context
def bv2_versions_uninstall(ctx, workspace_id, versions, dry_run, yes):
    """Uninstall app version(s) — newest first, removing what they installed.

    \b
    Versions MUST be a contiguous suffix of the live stack: with v1-v4 live, `4`, `3 4` and
    `1 2 3 4` are legal; `1 4`, `2` and `1 2` are refused, because removing a version while a
    later one still stands on what it installed would strip that foundation.

    \b
    Uninstalling every live version returns the app to v0 — alive, with no artifacts.

    \b
    ⛔ IRREVERSIBLE. The proposals become `uninstalled`, which is TERMINAL: they cannot be
    redeployed, only rebuilt from their (preserved) intent.

    \b
    Examples:
      torana build versions uninstall --workspace-id <WS> 4                  # preview
      torana build versions uninstall --workspace-id <WS> 4 --no-dry-run     # prompts
      torana build versions uninstall --workspace-id <WS> 3 4 --no-dry-run -y
    """
    _uninstall_core(ctx, workspace_id, versions, dry_run, yes)


@bv2_versions.command(name="show")
@click.option("--workspace-id", "workspace_id", required=True, help="Workspace (app).")
@click.argument("version_number", metavar="VERSION", type=int)
@click.pass_context
def bv2_versions_show(ctx, workspace_id, version_number):
    """Show one app version's full manifest — its frozen artifacts, their intents, and the
    blueprint each was built from."""
    data = _call(ctx, "GET",
                 f"workspaces/{workspace_id}/build-v2/deployments/{version_number}")
    if data is not None:
        output(data, fmt=_fmt(ctx))


@bv2_versions.command(name="export")
@click.option("--workspace-id", "workspace_id", required=True, help="Workspace (app).")
@click.argument("version_number", metavar="VERSION", type=int)
@click.option("--out", "out", default=None, help="Write app.yaml to this path (default: stdout).")
@click.pass_context
def bv2_versions_export(ctx, workspace_id, version_number, out):
    """Export a live app version's frozen manifest as artifacts.yaml. Same serializer as
    `proposal export`; the loader reads the immutable deployment snapshot."""
    data = _call(ctx, "GET",
                 f"workspaces/{workspace_id}/build-v2/versions/{version_number}/export-yaml")
    _emit_yaml(ctx, data, out)


@build_v2.group(name="deployment", invoke_without_command=True)
@click.argument("deployment_id", metavar="DEPLOYMENT_ID")
@click.pass_context
def bv2_deployment(ctx, deployment_id):
    """Operate on a single deployment (app version) by ID. Use `export`."""
    ctx.ensure_object(dict)
    ctx.obj["_bv2_deployment_id"] = deployment_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@bv2_deployment.command(name="export")
@click.option("--out", "out", default=None, help="Write app.yaml to this path (default: stdout).")
@click.pass_context
def bv2_deployment_export(ctx, out):
    """Export this deployment's frozen manifest as artifacts.yaml (identical serializer)."""
    did = ctx.obj.get("_bv2_deployment_id", "") if ctx.obj else ""
    data = _call(ctx, "GET", f"workspaces/build-v2/deployments/{did}/export-yaml")
    _emit_yaml(ctx, data, out)


@build_v2.group(name="proposals", invoke_without_command=True)
@click.pass_context
def bv2_proposals(ctx):
    """build_v2 proposals across a workspace (collection). Use `list` / `create` / `from-system`."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@bv2_proposals.command(name="list")
@click.option("--workspace-id", "workspace_id", required=True, help="Workspace to list proposals in.")
@click.option("--state", "state", default=None,
              help="Filter by proposal state: intent_only|blueprinting|blueprint_ready|cooking|deployable|deployed|failed|rolled_back.")
@click.option("--origin", "origin", default=None, type=click.Choice(["user", "advisor"]),
              help="Filter by origin: user (typed in chat) | advisor (mirrored system proposal).")
@click.pass_context
def bv2_proposals_list(ctx, workspace_id, state, origin):
    """List build_v2 proposals in a workspace (unified table; user + mirrored system,
    time-ordered).

    Top-level equivalent of `torana workspace <WS> build proposals list` — same data,
    reachable without the workspace group."""
    path = f"workspaces/{workspace_id}/build-v2/proposals"
    if origin:
        path += f"?origin={origin}"
    data = _call(ctx, "GET", path)
    if data is None:
        return
    items = data.get("items", []) if isinstance(data, dict) else []
    if state:
        items = [i for i in items if i.get("state") == state]
    for i in items:
        i["version"] = _anchor_cell(i)
    output({"items": items}, fmt=_fmt(ctx), fields=_fields(ctx), columns=_PROPOSAL_COLS)


@bv2_proposals.command(name="create")
@click.option("--workspace-id", "workspace_id", required=True, help="Workspace to create the proposal in.")
@click.option("--intent", "intent_text", required=True, help="The build intent.")
@click.option("--title", required=True, help="Display title.")
@click.option("--description", default="", help="Semantic description.")
@click.option("--built-via", "built_via", default=None,
              type=click.Choice(["claude_skill", "platform_agent", "cli", "ui"]),
              help="Which surface is creating this (drives the card 'Built with Claude' badge).")
@click.pass_context
def bv2_proposals_create(ctx, workspace_id, intent_text, title, description, built_via):
    """Create a user proposal (intent_only). Top-level equivalent of the workspace-scoped create."""
    body = {"intent_text": intent_text, "title": title, "description": description}
    if built_via:
        body["built_via"] = built_via
    data = _call(ctx, "POST", f"workspaces/{workspace_id}/build-v2/proposals", body)
    if data is not None:
        output(data, fmt=_fmt(ctx))


@bv2_proposals.command(name="from-system")
@click.option("--workspace-id", "workspace_id", required=True, help="Workspace the system proposal belongs to.")
@click.argument("system_proposal_id", metavar="SYSTEM_PROPOSAL_ID")
@click.pass_context
def bv2_proposals_from_system(ctx, workspace_id, system_proposal_id):
    """Convert a system (Advisor) proposal into a deployable build_v2 child."""
    data = _call(ctx, "POST",
                 f"workspaces/{workspace_id}/build-v2/proposals/from-system/{system_proposal_id}")
    if data is not None:
        output(data, fmt=_fmt(ctx))


@bv2_proposals.command(name="import")
@click.option("--workspace-id", "workspace_id", required=True, help="Workspace to import the proposal into.")
@click.option("--file", "file", required=True, help="Path to an artifacts.yaml to import.")
@click.option("--built-via", "built_via", default=None,
              help="Surface that drove the import (e.g. claude_skill) — stamps the card badge.")
@click.pass_context
def bv2_proposals_import(ctx, workspace_id, file, built_via):
    """Import an artifacts.yaml → a new proposal (blueprint + draft artifacts). Atomic: a
    malformed block fails the whole import with a per-block error list."""
    _import_yaml_core(ctx, workspace_id, file, built_via)


@build_v2.group(name="proposal", invoke_without_command=True)
@click.argument("proposal_id", metavar="PROPOSAL_ID")
@click.pass_context
def bv2_proposal(ctx, proposal_id):
    """Operate on a single build_v2 proposal by ID.

    \b
    Examples:
      torana build proposal <ID> show
      torana build proposal <ID> cook start
      torana build proposal <ID> artifact add --type transformer --key base --definition '{"sql":"..."}'
      torana build proposal <ID> artifact <AID> validate
      torana build proposal <ID> cook finalize
    """
    ctx.ensure_object(dict)
    ctx.obj["_bv2_proposal_id"] = proposal_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


# Attach the full instance-verb surface to the top-level proposal group.
_register_proposal_instance_verbs(bv2_proposal, workspace_scoped=False)


# ═══════════════════════════════════════════════════════════════════════════
# Workspace-scoped commands, registered onto the `workspace` singular group:
#   torana workspace <WS> build proposals list|create|from-system
#   torana workspace <WS> build proposal <ID> <full verb set>
# ═══════════════════════════════════════════════════════════════════════════

def register_workspace_build_v2(workspace_group) -> None:
    """Attach the workspace-scoped build-v2 commands to the `workspace <id>` group."""

    @workspace_group.group(name="build", invoke_without_command=True)
    @click.pass_context
    def ws_build_v2(ctx):
        """Build programs for this workspace (proposals → blueprint → cook → deploy)."""
        ctx.ensure_object(dict)
        if ctx.invoked_subcommand is None:
            click.echo(ctx.get_help())

    # ---- bundles: the SAME callbacks as the top-level group, with the workspace supplied ----
    # Discovery path: a user who has a workspace in hand finds these under
    # `workspace <id> build bundles`, without needing to know the top-level `build bundles`
    # group exists. These delegate to the top-level command CALLBACKS (not copies), so the
    # two surfaces cannot drift.
    @ws_build_v2.group(name="bundles", invoke_without_command=True)
    @click.pass_context
    def ws_bv2_bundles(ctx):
        """App bundles for this workspace: install, resume, and inspect progress."""
        ctx.ensure_object(dict)
        if ctx.invoked_subcommand is None:
            click.echo(ctx.get_help())

    @ws_bv2_bundles.command(name="list")
    @click.option("--type", "workspace_type", default=None,
                  help="Override the type filter (defaults to THIS workspace's type).")
    @click.option("--all", "show_all", is_flag=True, default=False,
                  help="Every bundle, including ones that do not fit this workspace's type.")
    @click.pass_context
    def ws_bundles_list(ctx, workspace_type, show_all):
        """Bundles installable into THIS workspace (filtered to its type).

        A bundle whose type does not match the workspace is REJECTED at install, so the
        default filter is this workspace's own type — the list you see is the list you can
        actually install. Use --all to see everything.
        """
        if not show_all and not workspace_type:
            # ⚠️ The workspace payload calls this `type`, NOT `workspace_type` (which is the
            # BUNDLE's field name). Reading the wrong key yields None → an unfiltered list.
            ws = _call(ctx, "GET", f"workspaces/{_wid(ctx)}")
            workspace_type = (ws or {}).get("type")
        ctx.invoke(bundles_list, workspace_type=workspace_type)

    @ws_bv2_bundles.command(name="show")
    @click.argument("bundle_id")
    @click.option("--version", type=int, default=None)
    @click.pass_context
    def ws_bundles_show(ctx, bundle_id, version):
        """Show a bundle + its per-link summaries."""
        ctx.invoke(bundles_show, bundle_id=bundle_id, version=version)

    @ws_bv2_bundles.command(name="install")
    @click.argument("bundle_id")
    @click.option("--version", type=int, default=None)
    @click.option("--no-wait", is_flag=True, default=False,
                  help="Submit + print the job_id, don't poll.")
    @click.pass_context
    def ws_bundles_install(ctx, bundle_id, version, no_wait):
        """Install a bundle here — safe to re-run; RESUMES a failed try."""
        ctx.invoke(bundles_install, bundle_id=bundle_id, workspace_id=_wid(ctx),
                   version=version, no_wait=no_wait)

    @ws_bv2_bundles.command(name="install-resume")
    @click.pass_context
    def ws_bundles_install_resume(ctx):
        """(Explicit resume — `install` already does this automatically.)"""
        ctx.invoke(bundles_install_resume, target=_wid(ctx), no_wait=False)

    @ws_bv2_bundles.command(name="install-status")
    @click.pass_context
    def ws_bundles_install_status(ctx):
        """Status + per-link progress of THIS workspace's latest install."""
        ctx.invoke(bundles_install_status, target=_wid(ctx))

    @ws_bv2_bundles.command(name="install-detail")
    @click.option("--limit", default=100, show_default=True, type=click.IntRange(1, 200))
    @click.pass_context
    def ws_bundles_install_detail(ctx, limit):
        """What was installed into THIS workspace, and how did it go?"""
        ctx.invoke(bundles_install_detail, workspace_id=_wid(ctx), limit=limit)

    # ---- proposals collection: list ----
    @ws_build_v2.group(name="proposals", invoke_without_command=True)
    @click.pass_context
    def ws_bv2_proposals(ctx):
        """build_v2 proposals in this workspace. Use `list`."""
        ctx.ensure_object(dict)
        if ctx.invoked_subcommand is None:
            click.echo(ctx.get_help())

    @ws_bv2_proposals.command(name="list")
    @click.option("--origin", "origin", default=None, type=click.Choice(["user", "advisor"]),
                  help="Filter by origin: user (typed in chat) | advisor (mirrored system proposal).")
    @click.pass_context
    def ws_bv2_proposals_list(ctx, origin):
        """List build_v2 proposals in this workspace (unified table; user + mirrored system)."""
        path = f"workspaces/{_wid(ctx)}/build-v2/proposals"
        if origin:
            path += f"?origin={origin}"
        data = _call(ctx, "GET", path)
        if data is not None:
            for i in (data.get("items", []) if isinstance(data, dict) else []):
                i["version"] = _anchor_cell(i)
            output(data, fmt=_fmt(ctx), fields=_fields(ctx), columns=_PROPOSAL_COLS)

    # ---- versions collection: list / show (workspace-scoped mirror of the top-level group) ----
    @ws_build_v2.group(name="versions", invoke_without_command=True)
    @click.pass_context
    def ws_bv2_versions(ctx):
        """App versions (deployment snapshots) of this workspace. Use `list` / `show`."""
        ctx.ensure_object(dict)
        if ctx.invoked_subcommand is None:
            click.echo(ctx.get_help())

    @ws_bv2_versions.command(name="list")
    @click.option("--limit", "limit", default=100, type=int, help="Max versions to return (<=100).")
    @click.pass_context
    def ws_bv2_versions_list(ctx, limit):
        """List this workspace's app versions, newest first."""
        data = _call(ctx, "GET",
                     f"workspaces/{_wid(ctx)}/build-v2/deployments?limit={limit}")
        if data is not None:
            output(_enrich_versions(data), fmt=_fmt(ctx), fields=_fields(ctx),
                   columns=_VERSION_COLS)

    @ws_bv2_versions.command(name="uninstall")
    @click.argument("versions", metavar="VERSION...", nargs=-1, required=True, type=int)
    @click.option("--dry-run/--no-dry-run", default=True, show_default=True,
                  help="Preview only. --no-dry-run actually removes.")
    @click.option("--yes", "-y", is_flag=True, default=False,
                  help="Skip the confirmation prompt (the preview is still printed).")
    @click.pass_context
    def ws_bv2_versions_uninstall(ctx, versions, dry_run, yes):
        """Uninstall this app's version(s) — newest first, removing what they installed.

        \b
        Versions MUST be a contiguous suffix of the live stack (4 / 3 4 / 1 2 3 4). Removing
        every live version returns the app to v0 — alive, with no artifacts.

        \b
        ⛔ IRREVERSIBLE: the proposals become TERMINAL and must be rebuilt from intent.

        \b
        Examples:
          torana workspace <WS> build versions uninstall 4
          torana workspace <WS> build versions uninstall 3 4 --no-dry-run --yes
        """
        _uninstall_core(ctx, _wid(ctx), versions, dry_run, yes)

    @ws_bv2_versions.command(name="show")
    @click.argument("version_number", metavar="VERSION", type=int)
    @click.pass_context
    def ws_bv2_versions_show(ctx, version_number):
        """Show one app version's full manifest."""
        data = _call(ctx, "GET",
                     f"workspaces/{_wid(ctx)}/build-v2/deployments/{version_number}")
        if data is not None:
            output(data, fmt=_fmt(ctx))

    # ---- collection-style creators live on the PLURAL `proposals` group (no id needed),
    #      per the CLAUDE.md hierarchy rule (create/create-from belong on the collection).
    #      This keeps the singular `proposal` group free to take a REQUIRED id positional
    #      and chain instance verbs — Click cannot chain a subcommand after an *optional*
    #      positional, which is why these creators must not sit on the singular group.
    @ws_bv2_proposals.command(name="create")
    @click.option("--intent", "intent_text", required=True, help="The build intent.")
    @click.option("--title", required=True, help="Display title.")
    @click.option("--description", default="", help="Semantic description.")
    @click.option("--built-via", "built_via", default=None,
                  type=click.Choice(["claude_skill", "platform_agent", "cli", "ui"]),
                  help="Which surface is creating this (drives the card 'Built with Claude' badge).")
    @click.pass_context
    def ws_bv2_proposals_create(ctx, intent_text, title, description, built_via):
        """Create a user proposal (intent_only)."""
        body = {"intent_text": intent_text, "title": title, "description": description}
        if built_via:
            body["built_via"] = built_via
        data = _call(ctx, "POST", f"workspaces/{_wid(ctx)}/build-v2/proposals", body)
        if data is not None:
            output(data, fmt=_fmt(ctx))

    @ws_bv2_proposals.command(name="from-system")
    @click.argument("system_proposal_id", metavar="SYSTEM_PROPOSAL_ID")
    @click.pass_context
    def ws_bv2_proposals_from_system(ctx, system_proposal_id):
        """Convert a system (Advisor) proposal into a deployable build_v2 child."""
        data = _call(ctx, "POST",
                     f"workspaces/{_wid(ctx)}/build-v2/proposals/from-system/{system_proposal_id}")
        if data is not None:
            output(data, fmt=_fmt(ctx))

    @ws_bv2_proposals.command(name="import")
    @click.option("--file", "file", required=True, help="Path to an artifacts.yaml to import.")
    @click.option("--built-via", "built_via", default=None,
                  help="Surface that drove the import (e.g. claude_skill) — stamps the card badge.")
    @click.pass_context
    def ws_bv2_proposals_import(ctx, file, built_via):
        """Import an artifacts.yaml → a new proposal in this workspace (blueprint + draft
        artifacts). Atomic: a malformed block fails the whole import."""
        _import_yaml_core(ctx, _wid(ctx), file, built_via)

    @ws_bv2_versions.command(name="export")
    @click.argument("version_number", metavar="VERSION", type=int)
    @click.option("--out", "out", default=None, help="Write app.yaml to this path (default: stdout).")
    @click.pass_context
    def ws_bv2_versions_export(ctx, version_number, out):
        """Export a live app version's frozen manifest as artifacts.yaml."""
        data = _call(ctx, "GET",
                     f"workspaces/{_wid(ctx)}/build-v2/versions/{version_number}/export-yaml")
        _emit_yaml(ctx, data, out)

    # ---- proposal (workspace-scoped instance): REQUIRED id + full verb set ----
    @ws_build_v2.group(name="proposal", invoke_without_command=True)
    @click.argument("proposal_id", metavar="PROPOSAL_ID")
    @click.pass_context
    def ws_bv2_proposal(ctx, proposal_id):
        """Operate on a single build_v2 proposal in this workspace by ID.

        \b
        Examples:
          torana workspace <WS> build proposal <ID> show
          torana workspace <WS> build proposal <ID> cookable
          torana workspace <WS> build proposal <ID> blueprint approve
          torana workspace <WS> build proposal <ID> cook start
          torana workspace <WS> build proposal <ID> deploy

        \b
        Create/convert (no id) live on the plural group:
          torana workspace <WS> build proposals create --intent … --title …
          torana workspace <WS> build proposals from-system <SYSTEM_PROPOSAL_ID>
        """
        ctx.ensure_object(dict)
        ctx.obj["_bv2_proposal_id"] = proposal_id
        if ctx.invoked_subcommand is None:
            click.echo(ctx.get_help())

    # Attach the SAME full instance-verb surface used by the top-level group, so
    # `torana workspace <WS> build proposal <ID> <verb>` is verb-for-verb identical to
    # `torana build proposal <ID> <verb>`. The `cookable` verb reads the workspace id
    # from ctx (present here); all others key off the proposal id alone.
    _register_proposal_instance_verbs(ws_bv2_proposal, workspace_scoped=True)


# ── App Bundles (Spec E § 3.8.2) — chained-proposal use-case delivery ─────────
# `torana build bundles …` — browse / validate / import / install / export bundles.
# A bundle installs as N real proposals + N versions (indistinguishable from hand-built).

@build_v2.group(name="bundles")
def bundles():
    """App Bundles — pre-built multi-link use-case apps (Spec E). Install one to get N
    real proposals + N versions, exactly as if you'd hand-built the app."""


@bundles.command(name="list")
@click.option("--type", "workspace_type", default=None, help="Filter by workspace type.")
@click.pass_context
def bundles_list(ctx, workspace_type):
    """List installable bundles (system + this tenant's)."""
    path = "workspaces/build-v2/bundles"
    if workspace_type:
        path += f"?workspace_type={workspace_type}"
    data = _call(ctx, "GET", path)
    if data is None:
        return
    output(data, fmt=_fmt(ctx), fields=_fields(ctx), columns=[
        # width=None → NEVER truncate. `id` and `workspace_type` are both values a user
        # pastes verbatim into the next command (`install <id>`, `workspaces create --type
        # <type>`); a clipped `vulnerability_management_…` cannot be copied or grepped.
        ("id", "ID", None), ("name", "NAME", None), ("version", "VER", None),
        ("workspace_type", "TYPE", None), ("link_count", "LINKS", None),
        ("is_system", "SYSTEM", None),
    ])


@bundles.command(name="show")
@click.argument("bundle_id")
@click.option("--version", type=int, default=None)
@click.pass_context
def bundles_show(ctx, bundle_id, version):
    """Show a bundle + its per-link summaries (intents, artifact/reuse counts)."""
    path = f"workspaces/build-v2/bundles/{bundle_id}"
    if version:
        path += f"?version={version}"
    data = _call(ctx, "GET", path)
    if data is None:
        return
    if _fmt(ctx) in ("json", "yaml"):
        output(data, fmt=_fmt(ctx))
        return
    click.echo(f"{data.get('name')} (v{data.get('version')}) — {data.get('link_count')} links"
               f"  [{'system' if data.get('is_system') else 'tenant'}]")
    click.echo(f"  {data.get('description', '')}")
    for ln in data.get("links", []):
        click.echo(f"  [{ln['order']}] {ln['link_id']:<16} {ln['artifact_count']} artifacts, "
                   f"{ln['reuse_count']} reuse(s)")
        click.echo(f"        intent: {ln['intent_text'][:90]}")


@bundles.command(name="schema-check")
@click.argument("bundle_id", required=False)
@click.option("--version", type=int, default=None)
@click.option("--all", "check_all", is_flag=True,
              help="Sweep EVERY installable bundle instead of naming one. ⭐ The only way "
                   "to ask 'is anything broken?' without already knowing what to suspect.")
@click.option("--type", "workspace_type", default=None,
              help="With --all: restrict the sweep to one workspace type.")
@click.pass_context
def bundles_schema_check(ctx, bundle_id, version, check_all, workspace_type):
    """⛔ Does this bundle still FIT your tenant's live schema? (S19 row 49)

    \b
    Two things refuse an install, and both name a COLUMN:
      • a column the bundle READS was REMOVED
      • its TYPE changed incompatibly (`numeric` -> `text` turns `epss_score > 0.6`
        into a STRING comparison, where '0.09' > '0.6' is TRUE — the SQL returns
        WRONG ROWS rather than failing, so an existence-only check misses it)

    \b
    ⚠️ A stale REVISION alone never refuses; it only reports. The verdict is always
    the shape, per ARTIFACT — one DDL change touching one table invalidates only the
    artifacts reading THAT table.

    \b
    Exit code 1 when the bundle is refused, 0 when it installs. With --all, exit 1 if
    ANY bundle is refused — so it works as a CI/monitoring gate.

    \b
    ⚠️ This checks a bundle DEFINITION against the live schema. It does NOT tell you
    whether an app you ALREADY INSTALLED is still current: bundles install into many
    workspaces and tenants migrate independently. That question is workspace-scoped and
    is not answerable here yet.

    \b
    Examples:
      torana build bundles schema-check ciso_posture
      torana build bundles schema-check --all
      torana build bundles schema-check --all --type vulnerability_management_v2
    """
    import sys

    if check_all:
        if bundle_id:
            click.echo("ERROR: pass a BUNDLE_ID or --all, not both.", err=True)
            sys.exit(2)
        _bundles_schema_check_all(ctx, workspace_type)
        return
    if not bundle_id:
        click.echo("ERROR: give a BUNDLE_ID, or --all to sweep every bundle.", err=True)
        sys.exit(2)
    if workspace_type:
        click.echo("ERROR: --type only applies with --all.", err=True)
        sys.exit(2)

    path = f"workspaces/build-v2/bundles/{bundle_id}/schema-check"
    if version:
        path += f"?version={version}"
    data = _call(ctx, "GET", path)
    if data is None:
        return
    if _fmt(ctx) in ("json", "yaml"):
        output(data, fmt=_fmt(ctx), fields=_fields(ctx))
    else:
        click.echo(data.get("summary") or "(no summary)")
        broken = [v for v in (data.get("verdicts") or []) if not v.get("ok")]
        if broken:
            click.echo("")
            for v in broken:
                click.echo(f"  artifact: {v.get('artifact_key')} (link {v.get('link_id')})")
                if v.get("unverifiable"):
                    click.echo(f"    COULD NOT VERIFY: {v['unverifiable']}")
                for b in (v.get("breaks") or []):
                    click.echo(f"    {b.get('message')}")
        else:
            click.echo(f"\n{data.get('artifacts_checked', 0)} artifact(s) checked, none broken.")
    if data.get("refused"):
        sys.exit(1)


def _bundles_schema_check_all(ctx, workspace_type):
    """Sweep every installable bundle. ⭐ Answers "is ANYTHING broken?".

    ⛔ FAILS CLOSED, deliberately. A bundle whose check could not be reached is reported
    as UNKNOWN and exits non-zero — never silently counted as fine. A sweep that reports
    "all clear" because it could not reach half the bundles is worse than no sweep: it
    manufactures the very confidence it was built to earn. (S20 shipped a gate that
    failed open in the one service where it ran, and a fabricated id passed.)
    """
    import sys

    list_path = "workspaces/build-v2/bundles"
    if workspace_type:
        list_path += f"?workspace_type={workspace_type}"
    listing = _call(ctx, "GET", list_path)
    if listing is None:
        click.echo("ERROR: could not list bundles — refusing to report a sweep result.",
                   err=True)
        sys.exit(1)

    rows = listing if isinstance(listing, list) else (listing.get("items") or [])
    ids = [r.get("id") for r in rows if r.get("id")]
    if not ids:
        # ⚠️ Not a pass. "Nothing to check" and "everything is fine" are different
        # answers, and only one of them is evidence.
        click.echo("No bundles found — nothing was checked.")
        sys.exit(1)

    results, refused, unknown = [], [], []
    for bid in ids:
        data = _call(ctx, "GET", f"workspaces/build-v2/bundles/{bid}/schema-check")
        if data is None:
            unknown.append(bid)
            results.append({"bundle_id": bid, "state": "UNKNOWN", "refused": None,
                            "artifacts_checked": None, "summary": "check unreachable"})
            continue
        is_refused = bool(data.get("refused"))
        if is_refused:
            refused.append(bid)
        results.append({
            "bundle_id": bid,
            "state": "REFUSED" if is_refused else "OK",
            "refused": is_refused,
            "artifacts_checked": data.get("artifacts_checked"),
            "summary": data.get("summary"),
            "verdicts": data.get("verdicts"),
        })

    if _fmt(ctx) in ("json", "yaml"):
        output({"checked": len(ids), "refused": len(refused), "unknown": len(unknown),
                "results": results}, fmt=_fmt(ctx))
    else:
        for r in results:
            mark = {"OK": "ok ", "REFUSED": "REFUSED", "UNKNOWN": "UNKNOWN"}[r["state"]]
            n = r.get("artifacts_checked")
            click.echo(f"  {mark:<8} {r['bundle_id']:<26} "
                       f"{'' if n is None else str(n) + ' artifact(s)'}")
            for v in (r.get("verdicts") or []):
                if v.get("ok"):
                    continue
                click.echo(f"             {v.get('artifact_key')} (link {v.get('link_id')})")
                for b in (v.get("breaks") or []):
                    click.echo(f"               {b.get('message')}")
        click.echo("")
        click.echo(f"{len(ids)} bundle(s) checked · {len(refused)} refused · "
                   f"{len(unknown)} unknown")
        if unknown:
            click.echo("⛔ UNKNOWN is not a pass — those bundles were NOT verified.")

    if refused or unknown:
        sys.exit(1)


@bundles.command(name="regeneration-plan")
@click.argument("bundle_id")
@click.option("--version", type=int, default=None)
@click.pass_context
def bundles_regeneration_plan(ctx, bundle_id, version):
    """⭐ The schema moved — WHAT must be regenerated, and what follows? (S21 row 51)

    \b
    `schema-check` says which COLUMNS broke. This says what to DO about it, by splitting
    the broken artifacts three ways:

    \b
      ORIGINS     read a SINK TABLE directly — where the break actually is.
                  ⭐ These are the ones you regenerate.
      INHERITORS  read a bundle relation an origin produces.
                  ⛔ Do NOT rewrite them. Fixing the origin fixes them; rewriting an
                  inheritor papers over the origin, which keeps emitting the broken
                  column.
      IMPOSSIBLE  the intent needs a table that no longer exists.
                  ⛔ STOP — a partial regeneration is worse than a refusal.

    \b
    ⛔ THIS PLANS, IT NEVER APPLIES. A bundle installs into MANY tenants, so an
    automatic regeneration ships a wrong answer everywhere at once. The repair is done
    by the `torana-app-bundle` skill in REGENERATE mode, which regenerates each origin
    FROM ITS INTENT (never from the broken SQL) via `torana-text-to-sql` at PLATFORM
    scope.

    \b
    Exit code 1 when the plan cannot fully succeed (something is IMPOSSIBLE), 0
    otherwise. ⚠️ A bundle with no breaks exits 1 too — with nothing to regenerate there
    is no plan to act on; use `schema-check` to ask whether it installs.

    \b
    Example:
      torana build bundles regeneration-plan remediation_ops
    """
    path = f"workspaces/build-v2/bundles/{bundle_id}/regeneration-plan"
    if version:
        path += f"?version={version}"
    data = _call(ctx, "GET", path)
    if data is None:
        return
    if _fmt(ctx) in ("json", "yaml"):
        output(data, fmt=_fmt(ctx), fields=_fields(ctx))
    else:
        click.echo(data.get("summary") or "(no summary)")
        for t in (data.get("origins") or []):
            click.echo("")
            click.echo(f"  REGENERATE  {t.get('artifact_key')} "
                       f"({t.get('artifact_type')}, link {t.get('link_id')})")
            click.echo(f"    question : {t.get('question', '')[:160]}")
            click.echo(f"    grain    : {t.get('grain', '')[:160]}")
            click.echo("    ^ the grain MUST survive the regeneration — a changed grain "
                       "is a different artifact.")
            for b in (t.get("breaks") or []):
                click.echo(f"    broke on : {b.get('message')}")
        for t in (data.get("impossible") or []):
            click.echo("")
            click.echo(f"  CANNOT REGENERATE  {t.get('artifact_key')}")
            click.echo(f"    {t.get('blocked_reason')}")
    if not data.get("possible"):
        import sys
        sys.exit(1)


@bundles.command(name="validate")
@click.option("--file", "input_file", required=True, metavar="FILE", help="Bundle JSON document.")
@click.pass_context
def bundles_validate(ctx, input_file):
    """Dry-run the compile-time validator (B1–B6) against a bundle file."""
    import json
    with open(input_file) as fh:
        document = json.load(fh)
    data = _call(ctx, "POST", "workspaces/build-v2/bundles/validate", {"document": document})
    if data is None:
        return
    if data.get("valid"):
        click.echo("✓ bundle is valid (B1–B6 pass)")
    else:
        click.echo("✗ bundle failed validation:", err=True)
        for e in data.get("errors", []):
            click.echo(f"  [{e.get('check')}/{e.get('link_id', '')}] {e.get('message')}", err=True)
        import sys
        sys.exit(6)


@bundles.command(name="import")
@click.option("--file", "input_file", required=True, metavar="FILE", help="Bundle JSON document.")
@click.pass_context
def bundles_import(ctx, input_file):
    """Validate + store a bundle (as a tenant bundle)."""
    import json
    with open(input_file) as fh:
        document = json.load(fh)
    data = _call(ctx, "POST", "workspaces/build-v2/bundles", {"document": document})
    if data is None:
        return
    click.echo(f"Stored bundle: {data.get('id')} v{data.get('version')} ({data.get('link_count')} links)")


@bundles.command(name="install")
@click.argument("bundle_id")
@click.option("--workspace-id", "workspace_id", required=True, metavar="WS")
@click.option("--version", type=int, default=None)
@click.option("--no-wait", is_flag=True, default=False,
              help="Submit + print the job_id, don't poll (check later with `bundles install-status`).")
@click.pass_context
def bundles_install(ctx, bundle_id, workspace_id, version, no_wait):
    """Install a bundle into a workspace — RESUMES automatically if a previous try failed.

    ASYNC serial replay → N real proposals + N versions. Submits the install (returns instantly)
    and polls the job, printing per-link progress as each link deploys. Use --no-wait to just get
    the job_id back.

    \b
    Re-running this command is SAFE. If an earlier install of the same bundle failed partway,
    this resumes it — re-running ONLY the links that did not deploy — instead of re-cooking the
    ones that already landed (the expensive part) and minting duplicate versions.

    \b
    Examples:
      torana build bundles install ciso_posture --workspace-id <ws>
      torana workspace <ws> build bundles install ciso_posture
    """
    import sys
    # ── Re-run safety ────────────────────────────────────────────────────────────────────
    # The SERVER's install has no re-install guard: it submits unconditionally, so a second
    # `install` after a failure re-cooks every already-deployed link and mints duplicate
    # versions. Rather than expose that as a second verb the user must know to reach for,
    # detect the state here and route to resume. One verb, one intent.
    prior = _latest_install_job(ctx, workspace_id) if workspace_id else None
    if prior and prior.get("bundle_id") == bundle_id:
        st = prior.get("status")
        if st == "failed":
            done = len(prior.get("links_deployed") or [])
            click.echo(f"A previous install of '{bundle_id}' failed after {done}/"
                       f"{prior.get('total_links')} links — resuming it instead of "
                       f"reinstalling (already-deployed links are kept).")
            ctx.invoke(bundles_install_resume, target=workspace_id, no_wait=no_wait)
            return
        if st in ("running", "queued"):
            click.echo(f"An install of '{bundle_id}' is already {st} "
                       f"({len(prior.get('links_deployed') or [])}/"
                       f"{prior.get('total_links')} links). Watching it rather than "
                       f"starting a second one.")
            if no_wait:
                return
            _poll_install_job(ctx, prior["job_id"], bundle_id,
                              prior.get("total_links") or 0,
                              workspace_id=workspace_id)
            return
        if st == "succeeded":
            click.echo(f"'{bundle_id}' is already installed in this workspace "
                       f"({len(prior.get('links_deployed') or [])}/"
                       f"{prior.get('total_links')} links). Nothing to do.")
            return
    path = f"workspaces/{workspace_id}/build-v2/bundles/{bundle_id}/install"
    if version:
        path += f"?version={version}"
    sub = _call(ctx, "POST", path, {})
    if sub is None:
        return
    job_id = sub.get("job_id")
    total = sub.get("total_links", 0)
    if not job_id:
        click.echo("ERROR: install did not return a job_id.", err=True)
        sys.exit(1)
    if no_wait:
        click.echo(f"Submitted install job {job_id} ({total} links). "
                   f"Check: torana build bundles install-status {job_id}")
        return
    if _fmt(ctx) in ("json", "yaml"):
        output(sub, fmt=_fmt(ctx))
        return

    click.echo(f"Installing {bundle_id} ({total} links) — job {job_id}")
    _poll_install_job(ctx, job_id, bundle_id, total, workspace_id=workspace_id)


def _poll_install_job(ctx, job_id, bundle_id, total, *, already_deployed=None,
                      workspace_id=None):
    """Poll a bundle-install job to terminal, narrating each link as it lands.

    Shared by `install` and `install-resume` so both narrate identically. `already_deployed`
    pre-seeds the 'seen' set on a RESUME: those links were deployed by the earlier attempt and
    are reported as skipped rather than announced as freshly deployed.

    Exits 1 on a failed install (so scripts and CI see the failure).
    """
    import sys
    import time
    seen = set(already_deployed or ())
    jpath = f"workspaces/build-v2/bundle-install-jobs/{job_id}"
    while True:
        job = _call(ctx, "GET", jpath)
        if job is None:
            return
        for lid in job.get("links_deployed", []):
            if lid not in seen:
                seen.add(lid)
                click.echo(f"  ✓ link {len(seen)}/{total} {lid} … deployed")
        st = job.get("status")
        if st == "succeeded":
            click.echo(f"✓ installed {bundle_id} → version {job.get('final_version')} "
                       f"({len(seen)} links)")
            return
        if st == "failed":
            click.echo(f"✗ install stopped at link '{job.get('failed_link_id')}' "
                       f"(stage: {job.get('failed_stage')})", err=True)
            click.echo(f"  {job.get('error')}", err=True)
            click.echo(f"  workspace left at version {job.get('final_version')} "
                       f"({len(seen)} prior link(s) are valid versions)", err=True)
            # Prefer the WORKSPACE id in the hint — that is the id the user has; the job
            # id is internal and is derived by install-resume itself.
            click.echo(f"  resume (re-runs ONLY what did not deploy): "
                       f"torana build bundles install-resume "
                       f"{workspace_id or job_id}", err=True)
            sys.exit(1)
        cur = job.get("current_link_id")
        if cur and cur not in seen:
            click.echo(f"  … installing {cur}", err=True)
        time.sleep(4)


def _looks_like_uuid(v):
    """Both a workspace id and a job id are UUIDs, so shape cannot tell them apart."""
    import re
    return bool(re.fullmatch(r"[0-9a-fA-F-]{32,36}", (v or "").strip()))


def _latest_install_job(ctx, workspace_id):
    """The workspace's most recent bundle-install job, or None.

    The job id is an INTERNAL handle: a user has the workspace in hand, not a job. This
    derives it so `install-resume <workspace>` works without anyone copying a uuid out of
    `--json` output.
    """
    detail = _call(ctx, "GET",
                   f"workspaces/{workspace_id}/build-v2/bundle-install-detail?limit=1")
    if not detail:
        return None
    return detail.get("job") or None


@bundles.command(name="install-resume")
@click.argument("target")
@click.option("--no-wait", is_flag=True, default=False,
              help="Submit + print the new job_id, don't poll.")
@click.pass_context
def bundles_install_resume(ctx, target, no_wait):
    """Resume a FAILED bundle install — re-run ONLY the links that did not deploy.

    An install is serial and fail-fast with no whole-chain rollback: the links BEFORE the
    failure are real, valid app-versions. So resume carries on from the failure point instead
    of reinstalling from scratch (which would re-cook every earlier link — the expensive part —
    and mint duplicate versions).

    TARGET is the WORKSPACE id (preferred — the job is derived for you) or, if you have one,
    a job id. Nothing is deleted: the failed attempt is kept as the audit record.

    \b
    Examples:
      # Resume by workspace — the normal path, no job id needed anywhere.
      torana build bundles install-resume b371348f-9f30-43af-b503-5d21a6af20ad
    \b
      # See what failed first, then resume.
      torana build bundles install-detail b371348f-9f30-43af-b503-5d21a6af20ad
      torana build bundles install-resume b371348f-9f30-43af-b503-5d21a6af20ad
    \b
      # Submit and come back later instead of watching it.
      torana build bundles install-resume <workspace-id> --no-wait
    """
    import sys
    # Accept a workspace id (preferred) or a job id. Try the workspace reading first: it is
    # the id a user actually has, and it also tells us whether resuming makes sense at all.
    job_id = target
    if _looks_like_uuid(target):
        job = _latest_install_job(ctx, target)
        if job and job.get("job_id"):
            if job.get("status") == "succeeded":
                click.echo(f"Nothing to resume — {job.get('bundle_id')} installed cleanly "
                           f"({len(job.get('links_deployed') or [])}/{job.get('total_links')} "
                           f"links).")
                return
            job_id = job["job_id"]
            click.echo(f"Resuming the latest install for workspace {target} "
                       f"(job {job_id}).", err=True)
    sub = _call(ctx, "POST", f"workspaces/build-v2/bundle-install-jobs/{job_id}/resume", {})
    if sub is None:
        return
    new_job = sub.get("job_id")
    if not new_job:
        click.echo("ERROR: resume did not return a job_id.", err=True)
        sys.exit(1)
    total = sub.get("total_links", 0)
    skipped = sub.get("skipped_link_ids") or []
    bundle_id = sub.get("bundle_id")
    if _fmt(ctx) in ("json", "yaml"):
        output(sub, fmt=_fmt(ctx))
        return
    if no_wait:
        click.echo(f"Submitted resume job {new_job} (skipping {len(skipped)} of {total} links). "
                   f"Check: torana build bundles install-status {new_job}")
        return
    click.echo(f"Resuming {bundle_id} — job {new_job} (resumed from {job_id})")
    for lid in skipped:
        click.echo(f"  ⏭ {lid} … already deployed, skipped")
    click.echo(f"  restarting at '{sub.get('restarting_at_link_id')}'")
    _poll_install_job(ctx, new_job, bundle_id, total, already_deployed=skipped,
                      workspace_id=sub.get("workspace_id"))


@bundles.command(name="install-status")
@click.argument("target")
@click.pass_context
def bundles_install_status(ctx, target):
    """Check a bundle install's status + per-link progress.

    TARGET is a WORKSPACE id (the latest install for it) or a JOB id. A job id is printed by
    `install`/`install-resume` and by `install-detail`; you never have to hold on to one.

    \b
    Examples:
      torana build bundles install-status b371348f-9f30-43af-b503-5d21a6af20ad
      torana build bundles install-status 32570978-8c55-4862-b6ce-97b01748f0f3
    """
    import sys
    # Probe as a JOB id first (exact handle wins), then fall back to WORKSPACE → latest job.
    job = _try_get(ctx, f"workspaces/build-v2/bundle-install-jobs/{target}")
    if job is None:
        job = _latest_install_job(ctx, target)
        if job is None:
            click.echo(f"No bundle install found for '{target}' — it is neither an install "
                       f"job id nor a workspace installed from a bundle.", err=True)
            sys.exit(1)
    output(job, fmt=_fmt(ctx))


@bundles.command(name="install-detail")
@click.argument("workspace_id")
@click.option("--limit", default=100, show_default=True, type=click.IntRange(1, 200),
              help="Max bundle versions to return.")
@click.pass_context
def bundles_install_detail(ctx, workspace_id, limit):
    """What was installed into THIS workspace, and how did it go? (row 36)

    \b
    ⚠️ Different from `install-status`, which follows one async JOB by its id.
    This is workspace-scoped and answers the question afterwards: which bundle,
    which versions, and the per-link outcome — without needing a job id you no
    longer have.

    \b
    ⛔ An empty job + empty versions means the workspace was never installed
    from a bundle. That is a real answer, not a failure.

    \b
    Example:
      torana build bundles install-detail 7e161c5a-f947-4cf0-af34-8f0ecbf285c1
    """
    data = _call(ctx, "GET",
                 f"workspaces/{workspace_id}/build-v2/bundle-install-detail?limit={limit}")
    if data is None:
        return
    if _fmt(ctx) in ("json", "yaml"):
        output(data, fmt=_fmt(ctx), fields=_fields(ctx))
        return

    # ⚠️ The raw payload is one enormous JSON blob per version. Dumping it as
    # text is technically the data and practically unreadable, so text mode
    # summarises and points at --json for the full artifact list.
    job = data.get("job") or {}
    versions = data.get("versions") or []
    if not job and not versions:
        click.echo("This workspace was not installed from a bundle.")
        return
    if job:
        click.echo(f"bundle   : {job.get('bundle_id')} v{job.get('bundle_version')}")
        click.echo(f"status   : {job.get('status')}  "
                   f"({len(job.get('links_deployed') or [])}/{job.get('total_links')} links)")
        # Resume derives the job itself, but PRINT it: it is the handle for `install-status`
        # and the id to quote when correlating logs or discussing one specific run.
        click.echo(f"job      : {job.get('job_id')}")
        # ⚠️ Report the failure whenever the job FAILED — not only when a link is named.
        # A worker killed mid-install (service restart) fails with failed_link_id=None, and
        # gating this block on that field silently swallowed the only error text there was.
        if job.get("status") == "failed":
            if job.get("failed_link_id"):
                click.echo(f"⛔ failed : link '{job.get('failed_link_id')}' "
                           f"at stage '{job.get('failed_stage')}'")
            else:
                click.echo("⛔ failed : no link was blamed — the install did not stop "
                           "cleanly (e.g. the worker was killed mid-run)")
            if job.get("error"):
                click.echo(f"   {job['error']}")
            click.echo(f"\n   resume (re-runs ONLY what did not deploy):\n"
                       f"     torana build bundles install-resume {workspace_id}")
    if versions:
        click.echo("")
        for v in versions:
            arts = v.get("artifacts") or []
            done = sum(1 for a in arts if a.get("state") == "deployed")
            # Pad to 34 for alignment but NEVER cut: `[:34]` silently dropped the tail of a
            # long link title with no ellipsis, so the loss was invisible.
            click.echo(f"  v{v.get('version_number'):<3} {str(v.get('title')):<34} "
                       f"{str(v.get('status')):<10} {done}/{len(arts)} artifact(s) deployed")
        click.echo("\n(--json for the full per-artifact detail)")


@bundles.command(name="export")
@click.option("--workspace-id", "workspace_id", required=True, metavar="WS")
@click.option("--bundle-id", "bundle_id", default="captured_bundle", help="Id for the captured bundle.")
@click.option("--out", "out_file", required=True, metavar="FILE", help="Write the bundle JSON here.")
@click.pass_context
def bundles_export(ctx, workspace_id, bundle_id, out_file):
    """Complete-capture export: turn a workspace's versions into a faithful bundle document."""
    import json
    path = f"workspaces/{workspace_id}/build-v2/bundles/export?bundle_id={bundle_id}"
    data = _call(ctx, "GET", path)
    if data is None:
        return
    with open(out_file, "w") as fh:
        json.dump(data.get("document", {}), fh, indent=2, default=str)
    doc = data.get("document", {})
    click.echo(f"Exported {len(doc.get('links', []))}-link bundle → {out_file}")
