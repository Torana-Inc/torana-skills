"""torana asset-graph — read the CAASM asset graph (AG0 § 3.4.3).

Subcommands
-----------
  edges list                       List edges (filterable, paginated).
  neighbors <key>                  Forward/reverse adjacency of one node.
  reachable <from_key>             Bounded lineage/reachability from a node.
  reconcile                        Run A6 reconciliation (O1 § 3.5) for this tenant.
  packages list                    List SBOM packages (filterable, paginated).

Wraps the read endpoints in pantheon-integration (§ 3.4.2). Grouped under a
single semantic parent per the CLI grouping convention — no new top-level groups.
"""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import (
    APIError,
    ToranaClient,
    handle_api_error,
    handle_auth_error,
)
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output


_EDGE_COLS = [
    ("from_key", "FROM", 36),
    ("edge_type", "TYPE", 14),
    ("to_key", "TO", 36),
    ("confidence", "CONF", 14),
    ("source_system", "SOURCE", 18),
    ("created_via", "VIA", 16),
]
_PKG_COLS = [
    ("purl", "PURL", 40),
    ("package_manager", "MANAGER", 12),
    ("version", "VERSION", 14),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    return ToranaClient(base_url=get_settings(profile).base_url)


def _ctx(ctx):
    return (
        ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text",
        ctx.obj.get(CTX_RAW, False) if ctx.obj else False,
        ctx.obj.get(CTX_FIELDS) if ctx.obj else None,
    )


# ─── parent group ─────────────────────────────────────────────────────────────

@click.group(name="asset-graph")
def asset_graph():
    """Read the CAASM asset graph (edges, adjacency, lineage, packages).

    \b
    Examples:
      torana asset-graph edges list --type builds
      torana asset-graph neighbors service:prod/billing --direction both
      torana asset-graph reachable repo:github.com/acme/billing-api --via builds,packaged_in
      torana asset-graph packages list --manager maven
    """


# ─── edges (collection group) ─────────────────────────────────────────────────

@asset_graph.group(name="edges", invoke_without_command=True)
@click.pass_context
def edges(ctx):
    """Asset-graph edges. Use `list` to list them."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@edges.command(name="list")
@click.option("--from-key", default=None, help="Filter by source node key.")
@click.option("--to-key", default=None, help="Filter by target node key.")
@click.option("--type", "edge_type", default=None, help="Filter by edge_type.")
@click.option("--confidence", default=None, help="Filter by confidence.")
@click.option("--source", "source_system", default=None, help="Filter by source_system (e.g. torana-asset-graph).")
@click.option("--created-via", "created_via", default=None,
              help="Filter by producer kind: manifest_parse | etl_derivation | sdg_replay.")
@click.option("--include-deleted", is_flag=True, default=False, help="Include tombstoned edges.")
@click.option("--limit", default=100, type=int, help="Max rows (<=100).")
@click.option("--offset", default=0, type=int, help="Pagination offset.")
@click.pass_context
def edges_list(ctx, from_key, to_key, edge_type, confidence, source_system, created_via,
               include_deleted, limit, offset):
    """List asset-graph edges (filterable, paginated)."""
    fmt, raw, fields = _ctx(ctx)
    params = {"limit": limit, "offset": offset}
    if from_key:
        params["from_key"] = from_key
    if to_key:
        params["to_key"] = to_key
    if edge_type:
        params["edge_type"] = edge_type
    if confidence:
        params["confidence"] = confidence
    if source_system:
        params["source_system"] = source_system
    if created_via:
        params["created_via"] = created_via
    if include_deleted:
        params["include_deleted"] = "true"

    client = _client(ctx)
    try:
        data = client.get("asset-graph/edges", params=params)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    # Normalize {edges:[...]} -> {items:[...]} for the formatter.
    data = {"items": data.get("edges", []), "total": data.get("count", 0),
            "page": 1, "page_size": limit}
    output(data, fmt=fmt, raw=raw, fields=fields, columns=_EDGE_COLS)


# ─── neighbors ────────────────────────────────────────────────────────────────

@asset_graph.command(name="neighbors")
@click.argument("key")
@click.option("--type", "edge_type", default=None, help="Restrict to one edge_type.")
@click.option("--direction", default="both",
              type=click.Choice(["forward", "reverse", "both"]),
              help="Adjacency direction.")
@click.option("--include-deleted", is_flag=True, default=False)
@click.pass_context
def neighbors(ctx, key, edge_type, direction, include_deleted):
    """Forward/reverse adjacency of one node KEY."""
    fmt, raw, fields = _ctx(ctx)
    params = {"key": key, "direction": direction}
    if edge_type:
        params["edge_type"] = edge_type
    if include_deleted:
        params["include_deleted"] = "true"

    client = _client(ctx)
    try:
        data = client.get("asset-graph/neighbors", params=params)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


# ─── reachable ────────────────────────────────────────────────────────────────

@asset_graph.command(name="reachable")
@click.argument("from_key")
@click.option("--via", default=None,
              help="Comma-separated edge types to follow (e.g. builds,packaged_in).")
@click.option("--max-depth", default=8, type=int, help="Depth cap (1..16).")
@click.option("--include-deleted", is_flag=True, default=False)
@click.pass_context
def reachable(ctx, from_key, via, max_depth, include_deleted):
    """Bounded reachability/lineage from FROM_KEY."""
    fmt, raw, fields = _ctx(ctx)
    params = {"from_key": from_key, "max_depth": max_depth}
    if via:
        params["via"] = via
    if include_deleted:
        params["include_deleted"] = "true"

    client = _client(ctx)
    try:
        data = client.get("asset-graph/reachable", params=params)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


# ─── reconcile (A6 — O1 light-up § 3.5) ─────────────────────────────────────────

@asset_graph.command(name="reconcile")
@click.option("--max-depth", default=8, type=int,
              help="Reachability depth cap for the image→service→cloud walk (1..16).")
@click.pass_context
def reconcile(ctx, max_depth):
    """Run A6 reconciliation for the current tenant.

    Derives the cross-resource OBSERVED edges (service ──exposed_via──▶ public
    cloud LB) and writes shadow / drift / reachable findings. Synchronous and
    idempotent. Returns a summary of what the sweep produced. This is the
    on-demand trigger for the same work the scheduled A6 sweep performs.
    """
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.post("asset-graph/reconcile", params={"max_depth": max_depth})
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


def _render_manifest(path, flavor, values):
    """Render a repo's deployment manifests with the NATIVE tool → plain k8s YAML.

    The client renders (it has the repo + tools + creds); the server interprets
    (Deployment_Object_and_Runtime_Provenance.md § 2.6). Returns (rendered, error).
    """
    import glob
    import os
    import shutil
    import subprocess

    cwd = None
    if flavor == "kustomize":
        if shutil.which("kustomize"):
            cmd = ["kustomize", "build", path]
        elif shutil.which("kubectl"):
            cmd = ["kubectl", "kustomize", path]
        else:
            return None, "neither `kustomize` nor `kubectl` found on PATH — cannot render kustomize"
    elif flavor == "helm":
        if not shutil.which("helm"):
            return None, "`helm` not found on PATH — cannot render a Helm chart"
        cmd = ["helm", "template", path]
        for v in values:
            cmd += ["-f", v]
    elif flavor == "compose":
        # `docker compose config` resolves ${VAR} from .env + merges → the plain compose.
        # Run in the compose file's dir so its .env resolves.
        cwd = os.path.dirname(os.path.abspath(path)) or "."
        base = os.path.basename(path)
        if shutil.which("docker"):
            cmd = ["docker", "compose", "-f", base, "config"]
        elif shutil.which("docker-compose"):
            cmd = ["docker-compose", "-f", base, "config"]
        else:
            return None, "`docker` (compose) not found on PATH — cannot render compose"
    else:  # k8s-raw — no rendering, read the plain YAML file(s)
        try:
            if os.path.isdir(path):
                docs = [open(f, encoding="utf-8").read()
                        for f in sorted(glob.glob(os.path.join(path, "*.y*ml")))]
                return ("\n---\n".join(docs), None) if docs else (None, "no *.yaml in dir")
            return open(path, encoding="utf-8").read(), None
        except Exception as exc:
            return None, str(exc)

    try:
        res = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=180)
    except Exception as exc:
        return None, f"{cmd[0]} failed to run: {exc}"
    if res.returncode != 0:
        return None, (res.stderr or res.stdout or "render failed").strip()[:600]
    return res.stdout, None


@asset_graph.command(name="parse-manifests")
@click.option("--path", required=True, type=click.Path(exists=True),
              help="Manifest to render: a kustomize overlay dir, a helm chart, or a raw-k8s file/dir.")
@click.option("--flavor", type=click.Choice(["kustomize", "helm", "k8s-raw", "compose"]),
              default="kustomize", help="Renderer to use (default kustomize).")
@click.option("--deployment", "deployment_id", default=None,
              help="A `manifest` Deployment id — the governance + env source of record (§ 2.6).")
@click.option("--env", "env_label", default=None,
              help="Env label → service:<env>/<name>. Required unless --deployment supplies it.")
@click.option("--values", multiple=True, help="helm only: values file(s) passed as -f (repeatable).")
@click.option("--criticality", default=None, help="Inline governance (when no --deployment).")
@click.option("--owner", default=None, help="Inline governance (when no --deployment).")
@click.option("--has-customer-data", "has_customer_data", is_flag=True, default=False,
              help="Inline governance (when no --deployment).")
@click.pass_context
def parse_manifests(ctx, path, flavor, deployment_id, env_label, values,
                    criticality, owner, has_customer_data):
    """Render a repo's deployment manifests and push the DECLARED asset graph.

    Runs the NATIVE renderer (`kustomize build` / `helm template` / raw read) locally,
    then POSTs the plain rendered k8s YAML to /ingest/manifests. The server interprets
    it into `service:` nodes + digest-keyed `deployed_as` edges + exposure — keyed
    identically to the live-cluster path so declared ⋈ observed converge. This is the
    code-side / shift-left / no-cluster-access producer (§ 2.6). Governance comes from
    the referenced `manifest` Deployment (--deployment), else from the inline flags.
    """
    import sys
    fmt, raw, fields = _ctx(ctx)

    if not env_label and not deployment_id:
        click.echo("ERROR: provide --env <label> or --deployment <id>", err=True)
        sys.exit(2)

    rendered, err = _render_manifest(path, flavor, values)
    if rendered is None:
        click.echo(f"ERROR: render failed ({flavor}): {err}", err=True)
        sys.exit(1)

    body = {
        "schema_version": "manifest_ingest.v1",
        "source": "torana-asset-graph",
        "env_label": env_label or "prod",
        "flavor": flavor,
        "manifest_ref": str(path),
        "rendered": rendered,
    }
    if deployment_id:
        body["deployment_id"] = deployment_id
    else:
        if criticality:
            body["criticality"] = criticality
        if owner:
            body["owner"] = owner
        if has_customer_data:
            body["has_customer_data"] = True

    client = _client(ctx)
    try:
        receipt = client.post("ingest/manifests", json=body)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(receipt, fmt=fmt, raw=raw, fields=fields)


# ─── packages (collection group) ──────────────────────────────────────────────

@asset_graph.group(name="packages", invoke_without_command=True)
@click.pass_context
def packages(ctx):
    """SBOM packages. Use `list` to list them."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@packages.command(name="list")
@click.option("--manager", "package_manager", default=None, help="Filter by package_manager.")
@click.option("--purl-prefix", default=None, help="Filter by purl prefix (left-anchored).")
@click.option("--include-deleted", is_flag=True, default=False)
@click.option("--limit", default=100, type=int, help="Max rows (<=100).")
@click.option("--offset", default=0, type=int, help="Pagination offset.")
@click.pass_context
def packages_list(ctx, package_manager, purl_prefix, include_deleted, limit, offset):
    """List SBOM packages (filterable, paginated)."""
    fmt, raw, fields = _ctx(ctx)
    params = {"limit": limit, "offset": offset}
    if package_manager:
        params["package_manager"] = package_manager
    if purl_prefix:
        params["purl_prefix"] = purl_prefix
    if include_deleted:
        params["include_deleted"] = "true"

    client = _client(ctx)
    try:
        data = client.get("packages", params=params)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    data = {"items": data.get("packages", []), "total": data.get("count", 0),
            "page": 1, "page_size": limit}
    output(data, fmt=fmt, raw=raw, fields=fields, columns=_PKG_COLS)


# ─── health (ingestion freshness per producer) ──────────────────────────────

_HEALTH_COLS = [
    ("source", "SOURCE", 24),
    ("received_at", "LAST_INGEST", 28),
    ("edges", "EDGES", 8),
    ("status", "STATUS", 10),
]


@asset_graph.command(name="health")
@click.pass_context
def health(ctx):
    """Ingestion health per edge producer (last ingest receipt).

    Mirrors the FE 'Ingestion Health' surface (CLI-parity rule). Discovers
    producers by scanning a page of edges for distinct source_system, then looks
    up each one's last ingest receipt (scan_id='asset-edges:<source>').
    """
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        edges = client.get("asset-graph/edges", params={"limit": 100}).get("edges", [])
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    sources = sorted({e.get("source_system") for e in edges if e.get("source_system")})
    rows = []
    for src in sources:
        try:
            rec = client.get(f"ingest/receipts/asset-edges:{src}")
            rows.append({
                "source": src,
                "received_at": rec.get("received_at"),
                "edges": (rec.get("counts") or {}).get("asset_edges"),
                "status": "ok",
            })
        except APIError:
            rows.append({"source": src, "received_at": None, "edges": None, "status": "no-receipt"})

    output({"items": rows, "total": len(rows), "page": 1, "page_size": len(rows) or 1},
           fmt=fmt, raw=raw, fields=fields, columns=_HEALTH_COLS)


# ─── candidates (AG3a edge-derivation diagnostic ledger) ────────────────────

_CANDIDATE_COLS = [
    ("edge_type", "TYPE", 14),
    ("reason", "REASON", 24),
    ("missing_side", "MISSING", 8),
    ("candidate_value", "VALUE", 40),
    ("occurrence_count", "N", 5),
    ("status", "STATUS", 10),
]


@asset_graph.command(name="candidates")
@click.option("--status", "status_", default=None, help="open | promoted | dismissed | needs_job.")
@click.option("--reason", default=None, help="Filter by reason.")
@click.option("--type", "edge_type", default=None, help="Filter by edge_type.")
@click.option("--ingest-receipt", "ingest_receipt_id", default=None, help="Filter by ingest pass.")
@click.option("--include-deleted", is_flag=True, default=False)
@click.option("--limit", default=100, type=int, help="Max rows (<=100).")
@click.option("--offset", default=0, type=int, help="Pagination offset.")
@click.pass_context
def candidates(ctx, status_, reason, edge_type, ingest_receipt_id,
               include_deleted, limit, offset):
    """Asset-edge derivation candidates — edges that could NOT be keyed (§ 4.9.2).

    The diagnostic ledger: every derivation attempt that failed to compute one
    endpoint's key, with the reason and the raw value that wouldn't normalize. The
    after-every-ingest "why didn't my edge appear?" surface.
    """
    fmt, raw, fields = _ctx(ctx)
    params = {"limit": limit, "offset": offset}
    if status_:
        params["status"] = status_
    if reason:
        params["reason"] = reason
    if edge_type:
        params["edge_type"] = edge_type
    if ingest_receipt_id:
        params["ingest_receipt_id"] = ingest_receipt_id
    if include_deleted:
        params["include_deleted"] = "true"

    client = _client(ctx)
    try:
        data = client.get("asset-graph/candidates", params=params)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    data = {"items": data.get("candidates", []), "total": data.get("count", 0),
            "page": 1, "page_size": limit}
    output(data, fmt=fmt, raw=raw, fields=fields, columns=_CANDIDATE_COLS)


# ─── metrics (AG3a derivation metrics — per-pass rollups) ───────────────────

_METRIC_COLS = [
    ("created_at", "WHEN", 26),
    ("edge_type", "TYPE", 14),
    ("source_system", "SOURCE", 14),
    ("edges_derived", "DERIVED", 8),
    ("candidates_written", "FAILED", 7),
    ("duration_ms", "MS", 7),
]


@asset_graph.command(name="metrics")
@click.option("--since", default=None,
              help="Window, e.g. '1 hour', '24 hours', '7 days'.")
@click.option("--type", "edge_type", default=None, help="Filter by edge_type.")
@click.option("--source", "source_system", default=None, help="Filter by source_system.")
@click.option("--limit", default=100, type=int, help="Max rows (<=100).")
@click.option("--offset", default=0, type=int, help="Pagination offset.")
@click.pass_context
def metrics(ctx, since, edge_type, source_system, limit, offset):
    """Asset-graph derivation metrics — per-pass rollups (§ 4.9.7).

    Counters (edges derived / failed), confidence histogram, and timing per ingest
    pass per edge_type. Use --since to window: `--since '1 hour'`.
    """
    fmt, raw, fields = _ctx(ctx)
    params = {"limit": limit, "offset": offset}
    if since:
        params["since"] = since
    if edge_type:
        params["edge_type"] = edge_type
    if source_system:
        params["source_system"] = source_system

    client = _client(ctx)
    try:
        data = client.get("asset-graph/metrics", params=params)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    data = {"items": data.get("metrics", []), "total": data.get("count", 0),
            "page": 1, "page_size": limit}
    output(data, fmt=fmt, raw=raw, fields=fields, columns=_METRIC_COLS)
