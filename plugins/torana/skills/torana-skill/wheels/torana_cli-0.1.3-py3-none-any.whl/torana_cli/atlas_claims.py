"""torana atlas claims | learning — what Atlas has learned (pantheon-knowledge BLOCK_2_STORE.md § 3.4.3, § 3.8.6).

`claims list|explain|resolve` read the learned claims of a tenant (atlas:read; --tenant is SA only).
`learning summary|events|event|ingests` is the super-admin journal of the learning work: without --tenant, `summary`
prints the fleet table and `events` the cross-tenant feed.

The server writes every state and every sentence (`{state, glyph, words}`); these commands print them verbatim and
derive none. Glyphs carry the state beside the words, never colour alone.
"""

import json

import sys

import click

from torana_cli.atlas import MAX_PAGE_SIZE, _call, _client, _fmt, _params, human_time, since_to_iso
from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_PROFILE
from torana_cli.output import output



# ── shared rendering ──────────────────────────────────────────────────────────

def _starts_with_word(text: str, word: str) -> bool:
    """`text` begins with `word` as a whole word ("evidenced, …" yes; "evidencedness" no)."""
    return text.startswith(word) and (len(text) == len(word) or not (text[len(word)].isalnum() or text[len(word)] == "_"))


def words_line(w: dict | None) -> str:
    """`glyph state — words`, verbatim from the server's Words; '?' where a part is absent. When the words already begin
    with the state word (a conviction's words begin with its tier: "evidenced, 2 independent sources, current"), prints
    `glyph words` so the state is not said twice. A state the words do not begin with (contradicted, unsupported, a
    tenant's learning state) keeps its own word: nothing is dropped."""
    if not isinstance(w, dict):
        return "? (no state)"
    words = w.get("words") or ""
    if w.get("state") and _starts_with_word(words, w["state"]):
        return f"{w.get('glyph') or '?'} {words}"
    return f"{w.get('glyph') or '?'} {w.get('state') or '?'} — {words}".rstrip(" —")


def _compact(d) -> str:
    """A dict as `k=v, k=v` (identity, counts); anything else as given."""
    if not isinstance(d, dict):
        return "" if d is None else str(d)
    return ", ".join(f"{k}={{{_compact(v)}}}" if isinstance(v, dict) else f"{k}={v}" for k, v in d.items())


def claim_line(c: dict) -> str:
    """One claim: `glyph state — words · claim_type · identity`, then its frame words when the read was in an
    environment's or a commit's frame (BLOCK_D § 3.4.2 `frame_words`, server-written, e.g. "not deployed in
    production"; null in `main`, so nothing trails)."""
    conviction = (c.get("conviction") or {}).get("words")
    out = f"{words_line(conviction)} · {c.get('claim_type', '?')} · {_compact(c.get('identity') or {})}"
    fw = c.get("frame_words")
    if isinstance(fw, dict) and fw.get("words"):
        out += f" · {fw.get('glyph') + ' ' if fw.get('glyph') else ''}{fw['words']}"
    if c.get("source_words"):                       # BLOCK_3A § 3.5: server words, e.g. "model · inferred · unverified"
        out += f" · ? {c['source_words']}"
    return out


def frame_footer(data: dict) -> str:
    """The claims page's frame (BLOCK_D `frame_detail`): the frame read, the repositories not deployed in it (left out
    of every current/stale count by the server) and those running two commits at once. '' in `main` or when absent."""
    fd = data.get("frame_detail")
    if not isinstance(fd, dict) or not fd.get("frame") or fd["frame"] == "main":     # always sent; {frame: main} says nothing
        return ""
    parts = [f"frame {fd['frame']}"]
    if fd.get("not_deployed"):
        parts.append("not deployed: " + ", ".join(fd["not_deployed"]))
    if fd.get("multi_commit"):
        parts.append("running more than one commit: " + ", ".join(fd["multi_commit"]))
    also = fd.get("also_running")                                                    # explain only (ExplainFrameDetail)
    if isinstance(also, dict) and also:
        parts.append("also running: " + "; ".join(f"{repo} {', '.join(str(c)[:12] for c in shas)}"
                                                  for repo, shas in also.items()))
    return " · ".join(parts)


def sighting_line(s: dict) -> str:
    """One sighting: `tier freshness · persona v<n> · source_id · evidence kind root locator · "quote"`. Freshness is
    the server's word as given (`unwatched` included); an object locator (`{file, line}`) prints as `k=v`."""
    ev = s.get("evidence") or {}
    where = " ".join(_compact(ev.get(k)) if isinstance(ev.get(k), dict) else str(ev.get(k))
                     for k in ("kind", "root", "locator") if ev.get(k) not in (None, ""))
    quote = ev.get("quote")
    withheld = ev.get("quote_words") if ev.get("redacted_at") and not quote else None   # FIX_CONSENT D4: server words
    out = f"{s.get('tier') or '-'} {s.get('freshness') or '-'}"
    if s.get("persona"):
        out += f" · {s['persona']}" + (f" v{s['persona_version']}" if s.get("persona_version") is not None else "")
    out += f" · {s.get('source_id', '?')}"
    if s.get("stance") and s.get("stance") != "supports":
        out = f"[{s['stance']}] " + out
    out += f" · {where}" if where else ""
    out += f' · "{quote}"' if quote else ""
    out += f" · ⊘ {withheld}" if withheld else ""
    return out


#: 7a § 3.2.5: the three lists of a sighting's `agreement`, in print order, with the word each line starts with
AGREEMENT_LISTS = (("by", "agrees"), ("against", "contradicts"), ("unaligned", "other version"))


def agreement_lines(agreement) -> list[str]:
    """7a § 3.2.5: one "↳" line per corroborator the server listed. The sentence about them is the server's `words`,
    printed above; these lines only name each claim so it can be explained in turn. Nothing is re-derived."""
    if not isinstance(agreement, dict):
        return []
    out = []
    for key, word in AGREEMENT_LISTS:
        for e in agreement.get(key) or []:
            line = (f"         ↳ {word}: {e.get('claim_type') or '?'} {e.get('claim_id') or '?'} "
                    f"({e.get('source_class') or '?'}, {e.get('tier') or '-'})")
            if key == "unaligned":
                line += f" built from {str(e['version'])[:12] if e.get('version') else 'unknown'}"
            out.append(line)
    return out


def render_claims_page(data: dict) -> str:
    items = data.get("items") or []
    if not items:
        footer = frame_footer(data)
        return "No claims." + (f"\n{footer}" if footer else "")
    lines = [f"{claim_line(c)}   [{c.get('id')}]" for c in items]
    lines.append(f"{len(items)} of {data.get('total', len(items))} claims · page {data.get('page', 1)}")
    footer = frame_footer(data)
    return "\n".join(lines + ([footer] if footer else []))


def render_explain(data: dict) -> str:
    c = data.get("claim") or {}
    lines = [claim_line(c), f"subject {c.get('subject', '?')} ({c.get('subject_kind', '?')}) · domain "
             f"{c.get('domain', '?')} ({c.get('domain_method', '?')}) · "
             f"{c.get('modality_words') or 'modality ' + str(c.get('modality', '?'))}"]     # F37: labelled
    if data.get("rules"):
        lines.append("Rules:")
        lines += [f"  {r}" for r in data["rules"]]
    sightings = data.get("sightings") or []
    total = data.get("sightings_total", len(sightings))
    lines.append(f"Sightings ({len(sightings)} of {total}, newest first):")
    for s in sightings:
        lines.append(f"  {sighting_line(s)}")
        if s.get("words"):                          # BLOCK_3A § 3.2.10: a model sighting's sentence, verbatim
            lines.append(f"       {s['words']}")
        if (s.get("basis") or {}).get("words"):     # § 3.2.12: the server's Basis line, verbatim
            lines.append(f"       {s['basis']['words']}")
        if s.get("atlas_ref"):
            lines.append(f"       anchor {s['atlas_ref']} · learned {human_time(s.get('learned_at'))}")
        lines += agreement_lines(s.get("agreement"))
    lines += verdicts_block(data.get("verdicts") or [])
    from torana_cli.atlas_questions import questions_block                       # 6d.1: server words
    lines += questions_block(data.get("questions") or [])
    if isinstance(data.get("credibility"), dict):
        lines += credibility_block(data["credibility"])
    footer = frame_footer(data)
    return "\n".join(lines + ([footer] if footer else []))


# ── #8 verdicts and credibility (pantheon-knowledge BLOCK_8_VERDICTS.md § 3.4.2-3.4.3; server words verbatim) ──

def verdict_line(v: dict) -> str:
    """One verdict: `glyph words · claim_type · rule_key   [id]`. The server's `words` already carry the outcome, the
    event's op and date and the status suffix ("· pending until …"); nothing is re-assembled here."""
    return (f"{v.get('glyph') or '?'} {v.get('words') or v.get('outcome') or '?'} · {v.get('claim_type') or '?'} · "
            f"{v.get('rule_key') or '?'}   [{v.get('id')}]")


def verdicts_block(verdicts: list) -> list:
    """explain's "Verdicts (track record):" block, always printed (§ 3.4.3)."""
    if not verdicts:
        return ["Verdicts (track record): none yet"]
    return ["Verdicts (track record):"] + [f"  {verdict_line(v)}" for v in verdicts]


def producer_label(r: dict) -> str:
    """Who a credibility row is about: the producer's source id (and persona version), else the origin kind."""
    p = r.get("producer") or {}
    if p.get("source_id"):
        return p["source_id"] + (f" v{p['persona_version']}" if p.get("persona_version") is not None else "")
    if r.get("origin_kind"):
        return f"origin {r['origin_kind']}"
    return str(r.get("producer_key_sha") or "?")[:12]


def credibility_row_line(r: dict) -> str:
    return (f"{r.get('glyph') or '?'} {r.get('words') or '?'} · {r.get('ledger') or '?'} · "
            f"{r.get('claim_type') or '?'} · {producer_label(r)}")


def credibility_block(c: dict) -> list:
    """explain --credibility: "Credibility:" (producers, then pairs with no row yet), "Origin:" and the server's
    "shown, not used" note."""
    lines = ["Credibility:"]
    rows = [f"  {credibility_row_line(r)}" for r in c.get("producers") or []]
    rows += [f"  {r.get('glyph') or '?'} {r.get('words') or '?'} · "
             f"{producer_label(r) if (r.get('producer') or {}).get('source_id') else str(r.get('producer_key_sha') or '?')[:12]}"
             for r in c.get("no_record") or []]
    lines += rows or ["  —"]
    lines.append("Origin:")
    lines += [f"  {credibility_row_line(r)}" for r in c.get("origins") or []] or ["  —"]
    if c.get("note"):
        lines.append(f"  ({c['note']})")
    return lines


def render_verdicts_page(data: dict) -> str:
    items = data.get("items") or []
    if not items:
        return "No verdicts."
    lines = [verdict_line(v) for v in items]
    lines.append(f"{len(items)} of {data.get('total', len(items))} verdicts · page {data.get('page', 1)}")
    return "\n".join(lines)


def event_versions(ev: dict) -> str:
    """`version <subject>@<rev12> (<basis>)` per entry of the event's versions, as the server stored them."""
    versions = ev.get("versions") or {}
    if not isinstance(versions, dict) or not versions:
        return "version —"
    parts = []
    for subject, e in versions.items():
        e = e if isinstance(e, dict) else {"revision": e}
        rev = str(e.get("revision") or "?")[:12]
        parts.append(f"version {subject}@{rev}" + (f" ({e['basis']})" if e.get("basis") else ""))
    return "; ".join(parts)


def render_verdict(v: dict) -> str:
    """`verdicts get` (§ 3.4.3): the server's words, then rule, claim, event, alignment, attribution, direction, the
    side rows (each its server line) and status."""
    lines = [f"Verdict (track record): {v.get('glyph') or '?'} {v.get('words') or '?'}",
             f"Rule: {v.get('persona') or '?'} v{v.get('persona_version', '?')} {v.get('rule_key') or '?'}"]
    c = v.get("claim") or {}
    if c:
        ident = f" {_compact(c['identity'])}" if c.get("identity") else ""
        where = str(v.get("claim_id") or c.get("id"))
        if c.get("merged_into"):
            where += f"; merged into {c['merged_into']}"
        lines.append(f"Claim: {c.get('claim_type') or v.get('claim_type') or '?'} {c.get('subject') or '?'}{ident} "
                     f"({where})")
    else:
        lines.append(f"Claim: {v.get('claim_type') or '?'} ({v.get('claim_id') or 'anonymised'})")
    ev = v.get("event") or {}
    lines.append(f"Event: {ev.get('op') or '?'} at {ev.get('at') or '?'}, first observed {ev.get('observed_at') or '?'}, "
                 f"{event_versions(ev)}")
    lines.append(f"Alignment: {v.get('alignment_words') or v.get('align') or '?'}")
    if v.get("attribution"):
        lines.append(f"Attribution: {v.get('attribution_words') or v['attribution']}"
                     + (f" (step {v['attribution_step']})" if v.get("attribution_step") is not None else "")
                     + (f" · {v['attribution_note']}" if v.get("attribution_note") else ""))
    if v.get("direction"):
        lines.append(f"Direction: {v['direction']}")
    sides = v.get("sightings") or []
    lines.append("Sightings:" + ("" if sides else " —"))
    lines += [f"  {s.get('words') or s.get('stored') or '?'}" for s in sides]
    lines.append(f"Status: {v.get('status_words') or v.get('status') or '?'}")   # server words; the code if absent
    for key, label in (("corrects", "Corrects"), ("corrected_by", "Corrected by"), ("supersedes", "Supersedes"),
                       ("superseded_by", "Superseded by")):
        if v.get(key):
            lines.append(f"{label}: {v[key]}")
    return "\n".join(lines)


def render_credibility(data: dict) -> str:
    """`learning credibility`: one row per (ledger, claim type, producer or origin), the server's glyph and words."""
    items = data.get("items") or []
    note = data.get("note")
    if not items:
        return "No credibility rows (no record yet)." + (f"\n({note})" if note else "")
    head = ("LEDGER", "CLAIM TYPE", "PRODUCER / ORIGIN", "CLASS", "N", "TRACK RECORD")
    rows = [(r.get("ledger") or "?", r.get("claim_type") or "?", producer_label(r), _or_dash(r.get("producer_class")),
             r.get("n", 0), f"{r.get('glyph') or '?'} {r.get('words') or '?'}") for r in items]
    widths = [max(len(str(x)) for x in col) for col in zip(head, *rows)]
    fmt = "  ".join(f"{{:<{w}}}" for w in widths)
    lines = [fmt.format(*map(str, r)).rstrip() for r in [head, *rows]]
    lines.append(f"{len(items)} of {data.get('total', len(items))} rows · scope {data.get('scope', '?')}")
    if note:
        lines.append(f"({note})")
    return "\n".join(lines)


def render_settle(data: dict) -> str:
    steps = data.get("steps") or {}
    lines = [f"settled now for {data.get('tenant_id', '?')}"]
    for name, st in (steps.items() if isinstance(steps, dict) else []):
        w = st.get("words") if isinstance(st, dict) and isinstance(st.get("words"), dict) else None
        lines.append(f"  {name}: " + (f"{w.get('glyph') or ''} {w.get('words') or ''}".strip() if w
                                      else _compact(st)))
    return "\n".join(lines)


def render_dry_run(data: dict) -> str:
    """The dry-run's request row: status, then (complete) the journal row's counts; (failed) the error."""
    opts = data.get("options") or {}
    status = data.get("status") or "?"
    lines = [f"dry-run {data.get('request_id', '?')}: status {status}"]
    if opts.get("error"):
        lines.append(f"  error: {opts['error']}" + (f": {opts['message']}" if opts.get("message") else ""))
    ev = data.get("event") or {}
    if ev:
        lines.append(f"  journal {ev.get('id')} · {ev.get('kind')} {ev.get('outcome')} · "
                     f"{ev.get('ms')} ms · {human_time(ev.get('created_at')) or '?'}")
        for k, v in (ev.get("counts") or {}).items():
            lines.append(f"    {k}: {_compact(v) if isinstance(v, dict) else v}")
    elif status in ("accepted", "running"):
        lines.append("  not finished: run `verdicts dry-run get` again")
    return "\n".join(lines)


def render_resolve(data: dict) -> str:
    sel = data.get("ref") or f"{data.get('digest')} {data.get('purl')}"
    claims = data.get("claims") or []
    footer = frame_footer(data)
    if not claims:
        return f"{sel}: no claim ({data.get('reason') or 'no reason given'})" + (f"\n{footer}" if footer else "")
    return "\n".join([f"{sel}: {len(claims)} claim(s)"] + [f"  {claim_line(c)}   [{c.get('id')}]" for c in claims]
                     + ([footer] if footer else []))


def render_about(data: dict) -> str:
    """`claims about KEY`: the server's summary line, then one line per claim with where it names the key (the
    server's `matched_on[].words`, e.g. "names it in its identity (workload)"), then the page. Nothing re-derived."""
    items = data.get("items") or []
    lines = [data.get("words") or f"{data.get('total', 0)} claims name {data.get('key')}"]
    for c in items:
        where = "; ".join(m.get("words") or m.get("where", "?") for m in c.get("matched_on") or [])
        lines.append(f"  {claim_line(c)} · subject {c.get('subject', '?')} · {where}   [{c.get('id')}]")
    if items:
        lines.append(f"{len(items)} of {data.get('total', len(items))} claims · page {data.get('page', 1)}")
    footer = frame_footer(data)
    return "\n".join(lines + ([footer] if footer else []))


def consent_banner(data) -> str:
    """FIX_CONSENT D5: a reader whose consent read failed hides everything and says so (`consent_unavailable`,
    the server's `consent_words`); '' otherwise."""
    if not isinstance(data, dict) or not data.get("consent_unavailable"):
        return ""
    return f"⚠ {data.get('consent_words') or 'consent_unavailable'}"


def consent_error_words(e: APIError):
    """FIX_CONSENT D5: explain answers 503 `consent_unavailable` when the consent state cannot be read; the server's
    `consent_words` ride in the error (at the top of `detail` or in its nested `detail`). None for any other error."""
    d = e.detail if isinstance(e.detail, dict) else {}
    inner = d.get("detail") if isinstance(d.get("detail"), dict) else {}
    flagged = "consent_unavailable" in (d.get("error"), d.get("code")) or bool(
        d.get("consent_unavailable") or inner.get("consent_unavailable"))
    if e.status_code != 503 or not flagged:
        return None
    return d.get("consent_words") or inner.get("consent_words") or d.get("message") or "consent_unavailable"


def _emit(ctx, data, render):
    fmt, _, _ = _fmt(ctx)
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt)
        return
    banner = consent_banner(data)
    if banner:
        click.echo(banner)
    click.echo(render(data))


# ── torana atlas claims ───────────────────────────────────────────────────────

@click.group(name="claims", invoke_without_command=True)
@click.pass_context
def atlas_claims(ctx):
    """What Atlas has learned about a tenant's estate: one claim per fact, its conviction in words, and every
    sighting that supports or contradicts it. Free, no model.

    \b
    Examples:
      torana atlas claims list --node code/acme/api
      torana atlas claims list --subject image:sha256:… --type image.component
      torana atlas claims explain 6f1c…
      torana atlas claims resolve --ref 'atlas:code/acme/api@s9#a:171'
      torana atlas claims about service:<cluster>/<ns>/<workload>
      torana atlas claims list --node code/acme/api --as-of env:production
    """
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@atlas_claims.command(name="list")
@click.option("--node", default=None, metavar="PATH", help="Claims about this node's subject (and images built from it).")
@click.option("--subject", default=None, metavar="KEY", help="One subject, e.g. repo:github.com/acme/api or image:sha256:….")
@click.option("--type", "claim_type", default=None, metavar="CLAIM_TYPE", help="One claim type, e.g. image.component.")
@click.option("--domain", default=None, help="One domain.")
@click.option("--source", "source_class", default=None, metavar="CLASS",
              help="Only claims with a live sighting of this source class, e.g. model (a model's beliefs, unverified).")
@click.option("--page", type=click.IntRange(1), default=1, show_default=True)
@click.option("--page-size", type=click.IntRange(1, MAX_PAGE_SIZE), default=50, show_default=True)
@click.option("--tenant", default=None, help="Another tenant's claims (SA only).")
@click.option("--as-of", "as_of", default=None, metavar="FRAME",
              help="The frame: main (default), env:<environment> or commit:<sha>; sent as given, the server validates.")
@click.pass_context
def claims_list(ctx, node, subject, claim_type, domain, source_class, page, page_size, tenant, as_of):
    """List claims, one line each: `glyph state — words · claim_type · identity`."""
    data = _call(_client(ctx).get, "atlas/claims", params=_params(
        node=node, subject=subject, claim_type=claim_type, domain=domain, page=page, page_size=page_size, tenant=tenant,
        as_of=as_of, source_class=source_class))
    _emit(ctx, data, render_claims_page)


@atlas_claims.command(name="explain")
@click.argument("claim_id")
@click.option("--tenant", default=None, help="Another tenant's claim (SA only).")
@click.option("--as-of", "as_of", default=None, metavar="FRAME",
              help="The frame: main (default), env:<environment> or commit:<sha>; sent as given, the server validates.")
@click.option("--credibility", is_flag=True, default=False,
              help="Also the track record of the producers and origins behind the sightings (shown, not used).")
@click.pass_context
def claims_explain(ctx, claim_id, tenant, as_of, credibility):
    """One claim: its line, the rules that set its conviction, each sighting (newest first, up to 100), then its
    verdicts ("Verdicts (track record):", always). --credibility adds "Credibility:" and "Origin:" (shown, not
    used: nothing decides on these numbers yet). CLAIM_ID may be a unique prefix of 8+ hex characters.

    \b
    Examples:
      torana atlas claims explain 66119495
      torana atlas claims explain 66119495 --credibility
    """
    try:
        data = _client(ctx).get(f"atlas/claims/{claim_id}/explain", params=_params(
            tenant=tenant, as_of=as_of, include="credibility" if credibility else None))
    except AuthError as e:
        handle_auth_error(e)
    except APIError as e:
        words = consent_error_words(e)
        if words is None:
            handle_api_error(e)
        click.echo(f"⚠ {words}", err=True)       # everything is hidden while consent cannot be read (fail closed)
        sys.exit(e.exit_code)
    _emit(ctx, data, render_explain)


@atlas_claims.command(name="erase-sightings")
@click.argument("claim_id")
@click.option("--source", "source_class", required=True, metavar="CLASS",
              help="Whose sightings to erase, e.g. model (a model's wrong reading).")
@click.option("--confirm", required=True, metavar="CLAIM_ID", help="The claim id again: a deliberate step.")
@click.option("--reason", required=True, help="Why (journalled with who).")
@click.option("--tenant", default=None, help="The claim's tenant (SA; also pass the global --act-as-tenant/--act-as-reason).")
@click.pass_context
def claims_erase_sightings(ctx, claim_id, source_class, confirm, reason, tenant):
    """SA only: delete ONE claim's sightings of one source class, so Atlas no longer answers from them (the claim row is
    pruned later). For another tenant: `torana --act-as-tenant T --act-as-reason "…" atlas claims erase-sightings …`;
    the server audits it.

    \b
    Example:
      torana --act-as-tenant 83fe… --act-as-reason "wrong model claim" atlas claims erase-sightings 6611… \\
        --tenant 83fe… --source model --confirm 6611… --reason "tag_set_at copied a wrong platform pointer"
    """
    if confirm.strip() != claim_id:
        raise click.UsageError("--confirm must be the claim id")
    data = _call(_client(ctx).post, f"atlas/claims/{claim_id}/erase-sightings", params=_params(tenant=tenant),
                 json={"source_class": source_class, "confirm": confirm.strip(), "reason": reason})
    fmt, _, _ = _fmt(ctx)
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt)
        return
    n = data.get("erased", 0)
    click.echo(f"erased {n} {data.get('source_class')} sighting{'' if n == 1 else 's'} of claim {data.get('claim_id')} "
               f"(by {data.get('by')}): {data.get('reason')}")


@atlas_claims.command(name="resolve")
@click.option("--ref", default=None, metavar="REF", help="An anchor ref, atlas:<path>@s<seq>#a:<n>.")
@click.option("--digest", default=None, metavar="D", help="An image digest (with --purl).")
@click.option("--purl", default=None, metavar="P", help="A package URL (with --digest).")
@click.option("--tenant", default=None, help="Another tenant's claims (SA only).")
@click.option("--as-of", "as_of", default=None, metavar="FRAME",
              help="The frame: main (default), env:<environment> or commit:<sha>; sent as given, the server validates.")
@click.pass_context
def claims_resolve(ctx, ref, digest, purl, tenant, as_of):
    """Which claims an anchor (--ref) or an image component (--digest + --purl) supports. An empty answer says why:
    unknown_ref, stale_ref, not_a_claim or not_ingested (the server's word, printed as given)."""
    if not ((ref and not digest and not purl) or (not ref and digest and purl)):
        raise click.UsageError("give --ref REF, or --digest D with --purl P (exactly one form)")
    data = _call(_client(ctx).get, "atlas/claims/resolve", params=_params(ref=ref, digest=digest, purl=purl, tenant=tenant,
                                                                          as_of=as_of))
    _emit(ctx, data, render_resolve)


@atlas_claims.command(name="about")
@click.argument("key")
@click.option("--page", type=click.IntRange(1), default=1, show_default=True)
@click.option("--page-size", type=click.IntRange(1, MAX_PAGE_SIZE), default=50, show_default=True)
@click.option("--tenant", default=None, help="Another tenant's claims (SA only).")
@click.option("--as-of", "as_of", default=None, metavar="FRAME",
              help="The frame: main (default), env:<environment> or commit:<sha>; sent as given, the server validates.")
@click.pass_context
def claims_about(ctx, key, page, page_size, tenant, as_of):
    """Which claims NAME a key, by subject or in their identity (a `deploy.runs` names its workload and image digest in
    identity, so `list --subject service:…` misses it). Each line says where the key sits, in the server's words.

    \b
    Examples:
      torana atlas claims about service:bhakta-ubuntu-k3s/torana/pantheon-rag
      torana atlas claims about image:sha256:b116…
    """
    data = _call(_client(ctx).get, "atlas/claims/about", params=_params(key=key, page=page, page_size=page_size,
                                                                        tenant=tenant, as_of=as_of))
    _emit(ctx, data, render_about)


# ── torana atlas learning (super admin) ───────────────────────────────────────

def _base_url(ctx) -> str:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    return get_settings(profile).base_url.rstrip("/")


def trace_link(base: str, e: dict) -> str:
    """The event's Jaeger link: the server's `links.trace` when given, else the platform's Jaeger proxy path (the
    convention of pantheon-knowledge `services/runs.py`). '' without a trace id."""
    tid = e.get("trace_id")
    if not tid:
        return ""
    path = (e.get("links") or {}).get("trace") or f"/api/v1/jaeger/trace/{tid}"
    return f"{base}{path}"


def logs_query(e: dict) -> str:
    tid = e.get("trace_id")
    if not tid:
        return ""
    return (e.get("links") or {}).get("logs_query") or f'{{service=~".+"}} |= "{tid}"'


def _where_event(e: dict) -> str:
    if e.get("label"):                          # F42: the server's words (an image tick names the sre watch)
        return str(e["label"])
    where = e.get("node_path") or e.get("subject") or (str(e["node_id"]) if e.get("node_id") else "")
    if where and e.get("snapshot_seq") is not None:
        where += f"@s{e['snapshot_seq']}"
    return where


def event_line(base: str, e: dict, with_tenant: bool) -> str:
    parts = [human_time(e.get("created_at")) or "?"]
    if with_tenant:
        parts.append(e.get("tenant_name") or e.get("tenant_id") or "?")
    glyph = "✗ " if e.get("kind") == "error" or e.get("outcome") == "failed" else ""
    parts.append(f"{glyph}{e.get('kind', '?')} {e.get('outcome', '?')}")
    for p in (_where_event(e), _compact(e.get("counts") or {}),
              f"{e['ms']} ms" if e.get("ms") is not None else "",
              f"{e.get('error_class')}" if e.get("error_class") else ""):
        if p:
            parts.append(p)
    out = " · ".join(parts) + f"   [{e.get('id')}]"
    link = trace_link(base, e)
    return out + (f"\n    trace {link}" if link else "")


def render_events(base: str, data: dict, with_tenant: bool) -> str:
    items = data.get("items") or []
    if not items:
        return "No events."
    lines = [event_line(base, e, with_tenant) for e in items]
    lines.append(f"{len(items)} of {data.get('total', len(items))} events · page {data.get('page', 1)}")
    return "\n".join(lines)


def render_event(base: str, e: dict) -> str:
    lines = [event_line(base, e, with_tenant=bool(e.get("tenant_id")))]
    if e.get("counts"):
        lines.append("Counts:")
        lines += [f"  {k}: {_compact(v) if isinstance(v, dict) else v}" for k, v in e["counts"].items()]
    if e.get("detail"):
        lines.append("Detail:")
        lines += ["  " + ln for ln in json.dumps(e["detail"], indent=2, ensure_ascii=False, default=str).splitlines()]
    if e.get("error") or e.get("error_class"):
        lines.append(f"Error: ✗ {e.get('error_class') or ''}")
        lines += [f"  {ln}" for ln in str(e.get("error") or "").splitlines()]
    if e.get("trace_id"):
        lines.append(f"Trace: {trace_link(base, e)}")
        lines.append(f"Logs:  {logs_query(e)}   (Grafana Explore > Loki)")
    return "\n".join(lines)


def glyph_words(w: dict | None) -> str:
    """`glyph words`, verbatim from the server (F27 LAST PASS); '—' when absent."""
    if not isinstance(w, dict) or not w.get("words"):
        return "—"
    return f"{w.get('glyph') or '?'} {w['words']}"


def render_fleet(data: dict) -> str:
    f = data.get("fleet") or {}
    tail = f"{f.get('stalled', 0)} stalled · refusal rate {share_stale_text(f.get('refusal_rate'))}"
    if f.get("words"):              # F27: the server's fleet line, verbatim
        lines = [f"Fleet: {f['words']} · {tail}"]
    else:
        lines = [f"Fleet: {f.get('tenants_on', 0)} tenants with learning on · {f.get('errors_24h', 0)} errors (24 h) · "
                 + tail]
    rows = data.get("tenants") or []
    f27 = any("last_pass" in t for t in rows)
    head = ("STATE", "TENANT", "LEARNING", "CLAIMS", "SIGHTINGS", "LAST INGEST",
            *(("LAST PASS", "RECENT (24 H)") if f27 else ("ERRORS 24H",)), "WORDS")
    table = [(f"{(t.get('state') or {}).get('glyph', '?')} {(t.get('state') or {}).get('state', '?')}",
              t.get("tenant_name") or t.get("tenant_id") or "?", "on" if t.get("enabled") else "off",
              t.get("claims", 0), t.get("sightings", 0), human_time(t.get("last_ingest_at")) or "never",
              *((glyph_words(t.get("last_pass")), (t.get("recent") or {}).get("words") or "—") if f27
                else (t.get("errors_24h", 0),)),
              (t.get("state") or {}).get("words", "")) for t in rows]
    if table:
        widths = [max(len(str(x)) for x in col) for col in zip(head, *table)]
        fmt = "  ".join(f"{{:<{w}}}" for w in widths)
        lines += [fmt.format(*map(str, r)).rstrip() for r in [head, *table]]
    else:
        lines.append("No tenants.")
    return "\n".join(lines)


def render_tenant_summary(data: dict) -> str:
    """One tenant: its state line, counts per table, last event per kind, errors (24 h), knobs in force."""
    lines = []
    st = data.get("state")
    if isinstance(st, dict):
        lines.append(f"Learning: {words_line(st)}")
    if isinstance(data.get("last_pass"), dict):        # F27: the latest pass alone, then the 24 h history
        lines.append(f"Last pass: {glyph_words(data['last_pass'])}")
    if isinstance(data.get("recent"), dict):
        lines.append(f"Recent (24 h): {data['recent'].get('words') or '—'}")
    if "enabled" in data:
        lines.append(f"Enabled: {'on' if data['enabled'] else 'off'}")
    if data.get("counts"):
        lines.append("Counts: " + _compact(data["counts"]))
    last = data.get("last_event_by_kind") or data.get("last_events") or {}
    if last:
        lines.append("Last event per kind:")
        for kind, e in last.items():
            e = e or {}
            lines.append(f"  {kind}: {human_time(e.get('created_at')) or 'never'}"
                         + (f" ({e.get('outcome')})" if e.get("outcome") else ""))
    if "errors_24h" in data and not isinstance(data.get("recent"), dict):
        lines.append(f"Errors (24 h): {data['errors_24h']}")
    knobs = data.get("knobs") or {}
    if knobs:
        lines.append("Knobs in force: " + _compact(knobs))
    repos = data.get("repositories") or []
    if repos:
        lines.append("Repositories (newest ingest first):")
        lines += ["  " + ln for ln in render_repositories(repos).splitlines()]
        total = data.get("repositories_total")
        if total and total > len(repos):
            lines.append(f"  {len(repos)} of {total} repositories")
    watches = data.get("watches") or []
    if watches:
        lines.append("Persona watches (newest ingest per watch):")
        lines += ["  " + ln for ln in render_watches(watches).splitlines()]
        total = data.get("watches_total")
        if total and total > len(watches):
            lines.append(f"  {len(watches)} of {total} watches")
    return "\n".join(lines) or json.dumps(data, indent=2, default=str)


def render_watches(watches: list) -> str:
    """One row per persona + version + watch (BLOCK_C tenant summary `watches`): the server's numbers as given."""
    head = ("WATCH", "OP", "LAST INGEST", "ITEMS", "INSERTED", "CLOSED", "REFUSED", "MS", "CYCLE")
    rows = [(w.get("label") or (f"{w.get('persona', '?')}"          # F42: the server's label; composed for old servers
                                + (f" v{w['persona_version']}" if w.get("persona_version") is not None else "")
                                + (f" · {w['watch_key']}" if w.get("watch_key") else "")), _or_dash(w.get("op")),
             human_time(w.get("last_ingest_at")) or "never", _or_dash(w.get("items")), _or_dash(w.get("inserted")),
             _or_dash(w.get("closed")), _or_dash(w.get("refused")), _or_dash(w.get("ms")),
             # C-amend § 3.2.5: the server's cycle cell, glyph + words ("cycle 3: 2 pages, 2500 items, SLOW")
             (f"{(w.get('cycle') or {}).get('glyph') or ''} {w['cycle']['words']}".strip()
              if isinstance(w.get("cycle"), dict) and w["cycle"].get("words") else "—")) for w in watches]
    widths = [max(len(str(x)) for x in col) for col in zip(head, *rows)]
    fmt = "  ".join(f"{{:<{w}}}" for w in widths)
    return "\n".join(fmt.format(*map(str, r)).rstrip() for r in [head, *rows])


def share_stale_text(v) -> str:
    """The server's 0..1 share as a percentage; '—' when it gave none (never computed here)."""
    return "—" if v is None else f"{float(v) * 100:.0f}%"


def render_repositories(repos: list) -> str:
    head = ("REPOSITORY", "LAST INGEST", "SNAPSHOT", "CLAIMS", "REFUSALS", "SHARE STALE")
    rows = [(ingest_where(r), human_time(r.get("last_ingest_at")) or "never",
             f"s{r['snapshot_seq']}" if r.get("snapshot_seq") is not None else "—", r.get("claims", 0),
             _or_dash(r.get("refusals")), share_stale_text(r.get("share_stale"))) for r in repos]   # F32: never → —
    widths = [max(len(str(x)) for x in col) for col in zip(head, *rows)]
    fmt = "  ".join(f"{{:<{w}}}" for w in widths)
    return "\n".join(fmt.format(*map(str, r)).rstrip() for r in [head, *rows])


def ingest_where(i: dict) -> str:
    """What an ingest read: the server's `label` (F42), else its node, or for a declarative persona (no node, BLOCK_C)
    `persona v<n> · <watch_key>` (a server older than F42)."""
    if i.get("label"):
        return str(i["label"])
    if i.get("node_path") or i.get("node_id"):
        return str(i.get("node_path") or i.get("node_id"))
    if i.get("persona"):
        who = i["persona"] + (f" v{i['persona_version']}" if i.get("persona_version") is not None else "")
        key = i.get("watch_key") or i.get("op")
        return who + (f" · {key}" if key else "")
    return "—"


def _or_dash(v) -> str:
    return "—" if v is None else str(v)


def render_ingests(data: dict) -> str:
    items = data.get("items") or []
    if not items:
        return "No ingests."
    head = ("LEARNED", "WHAT", "SEQ", "SOURCE", "MS", "COUNTS")
    rows = [(human_time(i.get("learned_at")) or "?", ingest_where(i),
             f"s{i['snapshot_seq']}" if i.get("snapshot_seq") is not None else "—", _or_dash(i.get("source")),
             _or_dash(i.get("ms")), _compact(i.get("counts") or {})
             + (f", roots_seen={i['roots_seen']}"
                if i.get("roots_seen") is not None and "roots_seen" not in (i.get("counts") or {}) else ""))
            for i in items]
    widths = [max(len(str(x)) for x in col) for col in zip(head, *rows)]
    fmt = "  ".join(f"{{:<{w}}}" for w in widths)
    lines = [fmt.format(*map(str, r)).rstrip() for r in [head, *rows]]
    lines.append(f"{len(items)} of {data.get('total', len(items))} ingests · page {data.get('page', 1)}")
    return "\n".join(lines)


@click.group(name="learning", invoke_without_command=True)
@click.pass_context
def atlas_learning(ctx):
    """The learning journal (super admin): every ingest, backfill, image tick, prune, consent cascade, read and
    error. Without --tenant, `summary` is the fleet and `events` the feed across tenants. The track record
    (`verdicts list|get`, `credibility`) is also a tenant read of its own workspace; `verdicts settle|dry-run|
    anonymise` are super-admin test hooks.

    \b
    Examples:
      torana atlas learning summary
      torana atlas learning summary --tenant <TENANT_ID>
      torana atlas learning events --kind error --since 24h
      torana atlas learning event <EVENT_ID>
      torana atlas learning ingests --tenant <TENANT_ID> --node code/acme/api
      torana atlas learning verdicts list --outcome overturned
      torana atlas learning credibility --node code/acme/api
    """
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@atlas_learning.command(name="summary")
@click.option("--tenant", default=None, help="One tenant (default: the whole fleet).")
@click.option("--page", type=click.IntRange(1), default=None, help="Fleet table page.")
@click.option("--page-size", type=click.IntRange(1, MAX_PAGE_SIZE), default=None)
@click.pass_context
def learning_summary(ctx, tenant, page, page_size):
    """Fleet: tenants with learning on, errors (24 h), stalled, refusal rate, and one row per tenant sorted
    failing → stalled → healthy → off. One tenant: counts per table, last event per kind, errors, the knobs."""
    data = _call(_client(ctx).get, "atlas/learning/summary", params=_params(tenant=tenant, page=page, page_size=page_size))
    _emit(ctx, data, render_tenant_summary if tenant else render_fleet)


@atlas_learning.command(name="events")
@click.option("--tenant", default=None, help="One tenant (default: the latest across tenants).")
@click.option("--kind", default=None, metavar="KIND",
              help="One event kind, sent as given (the server validates): ingest, backfill, error, read, persona_*, …")
@click.option("--outcome", default=None, metavar="OUTCOME",
              help="One outcome, sent as given (the server filters on it exactly): ok, failed, refused, … "
                   "`torana atlas learning summary --tenant T` shows each kind's last outcome.")
@click.option("--node", default=None, metavar="PATH", help="One node.")
@click.option("--since", default=None, help="24h, 7d, 30m, or an ISO time.")
@click.option("--page", type=click.IntRange(1), default=1, show_default=True)
@click.option("--page-size", type=click.IntRange(1, MAX_PAGE_SIZE), default=50, show_default=True)
@click.option("--hide-reads", is_flag=True, default=False,
              help="Leave out `read` events (one per claims read); the server excludes them, so paging stays right.")
@click.pass_context
def learning_events(ctx, tenant, kind, outcome, node, since, page, page_size, hide_reads):
    """The event timeline, newest first; each event's trace id as a Jaeger link."""
    if hide_reads and kind == "read":
        raise click.UsageError("--hide-reads and --kind read contradict each other")
    data = _call(_client(ctx).get, "atlas/learning/events", params=_params(
        tenant=tenant, kind=kind, outcome=outcome, node=node, since=since_to_iso(since), page=page, page_size=page_size,
        exclude_kind=["read"] if hide_reads else None))
    base = _base_url(ctx)
    _emit(ctx, data, lambda d: render_events(base, d, with_tenant=not tenant))


@atlas_learning.command(name="event")
@click.argument("event_id")
@click.pass_context
def learning_event(ctx, event_id):
    """One event with its detail: counts, refusal samples, step timings, the full error, Jaeger and Loki.
    EVENT_ID may be a unique prefix of 8+ hex characters."""
    data = _call(_client(ctx).get, f"atlas/learning/events/{event_id}")
    base = _base_url(ctx)
    _emit(ctx, data, lambda d: render_event(base, d))


@atlas_learning.command(name="ingests")
@click.option("--tenant", default=None, help="One tenant (SA).")
@click.option("--node", default=None, metavar="PATH", help="One node.")
@click.option("--page", type=click.IntRange(1), default=1, show_default=True)
@click.option("--page-size", type=click.IntRange(1, MAX_PAGE_SIZE), default=50, show_default=True)
@click.pass_context
def learning_ingests(ctx, tenant, node, page, page_size):
    """One row per ingested snapshot: when, node, seq, source (index | backfill), ms and counts."""
    data = _call(_client(ctx).get, "atlas/learning/ingests", params=_params(
        tenant=tenant, node=node, page=page, page_size=page_size))
    _emit(ctx, data, render_ingests)


# ── torana atlas learning verdicts | credibility (#8, BLOCK_8_VERDICTS.md § 3.4.3) ──

VERDICT_OUTCOMES = ("confirmed", "overturned", "unknown")
VERDICT_STATUSES = ("pending", "settled", "cancelled", "corrected", "superseded")
LEDGERS = ("origin_truth", "origin_governance", "reader_faith", "reader_judgement", "unresolved")


@atlas_learning.group(name="verdicts", invoke_without_command=True)
@click.pass_context
def learning_verdicts(ctx):
    """The track record: one verdict per later event that confirmed or overturned what Atlas had learned (a person's
    relabel, an image that ships a pinned version, …), in the server's words. `list` and `get` are tenant reads of
    its own workspace (--tenant: SA). `settle`, `dry-run` and `anonymise` are SA test hooks on the learning pass:
    each is a declared act-as on the tenant, so give the global --act-as-tenant/--act-as-reason.

    \b
    Examples:
      torana atlas learning verdicts list --outcome overturned --since 7d
      torana atlas learning verdicts list --claim <CLAIM_ID>
      torana atlas learning verdicts get <VERDICT_ID>
      TORANA_PROFILE=SA torana --act-as-tenant <TENANT_ID> --act-as-reason "<why>" atlas learning verdicts settle --tenant <TENANT_ID>
      TORANA_PROFILE=SA torana --act-as-tenant <TENANT_ID> --act-as-reason "<why>" atlas learning verdicts dry-run start --tenant <TENANT_ID>
      TORANA_PROFILE=SA torana atlas learning verdicts dry-run get <REQUEST_ID> --tenant <TENANT_ID>
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@learning_verdicts.command(name="list")
@click.option("--tenant", default=None, help="Another tenant's verdicts (SA only).")
@click.option("--claim", "claim_id", default=None, metavar="CLAIM_ID", help="One claim's verdicts.")
@click.option("--node", default=None, metavar="PATH", help="The verdicts of this node's claims (path or subject).")
@click.option("--type", "claim_type", default=None, metavar="CLAIM_TYPE", help="One claim type, e.g. allergy.label.")
@click.option("--rule", default=None, metavar="RULE_KEY", help="One rule, e.g. image_confirms_pins.")
@click.option("--persona", default=None, help="One rule persona, e.g. sre.")
@click.option("--outcome", type=click.Choice(VERDICT_OUTCOMES), default=None)
@click.option("--status", type=click.Choice(VERDICT_STATUSES), default=None, help="Default: every status.")
@click.option("--attribution", default=None, metavar="WHO",
              help="Who an overturn is attributed to (reader, origin, unresolved); sent as given.")
@click.option("--since", default=None, help="24h, 7d, 30m, or an ISO time (by when the verdict was written).")
@click.option("--page", type=click.IntRange(1), default=1, show_default=True)
@click.option("--page-size", type=click.IntRange(1, MAX_PAGE_SIZE), default=50, show_default=True)
@click.pass_context
def verdicts_list(ctx, tenant, claim_id, node, claim_type, rule, persona, outcome, status, attribution, since, page,
                  page_size):
    """Verdicts, newest first, one line each: `glyph words · claim_type · rule_key   [id]`. The words are the
    server's ("confirmed by <op> on <date>", "overturned by <op> on <date>: <who>", "not decided: <why>", then
    "· pending until <date>" and the like)."""
    data = _call(_client(ctx).get, "atlas/learning/verdicts", params=_params(
        tenant=tenant, claim_id=claim_id, node=node, claim_type=claim_type, rule=rule, persona=persona,
        outcome=outcome, status=status, attribution=attribution, since=since_to_iso(since), page=page,
        page_size=page_size))
    _emit(ctx, data, render_verdicts_page)


@learning_verdicts.command(name="get")
@click.argument("verdict_id")
@click.option("--tenant", default=None, help="Another tenant's verdict (SA only).")
@click.pass_context
def verdicts_get(ctx, verdict_id, tenant):
    """One verdict: its words, the rule, the claim (and the claim it merged into), the event, the alignment, who an
    overturn is attributed to, the direction, each scored sighting (stored | pruned | anonymised) and the status.

    \b
    Example:
      torana atlas learning verdicts get 0b5e9c1a-…
    """
    data = _call(_client(ctx).get, f"atlas/learning/verdicts/{verdict_id}", params=_params(tenant=tenant))
    _emit(ctx, data, render_verdict)


@learning_verdicts.command(name="settle")
@click.option("--tenant", "tenant_id", required=True, help="The tenant (also the global --act-as-tenant).")
@click.pass_context
def verdicts_settle(ctx, tenant_id):
    """SA only. Cancel, settle and refresh the tenant's verdicts NOW (the leader's verdict steps; no image is read).
    Refused at once (409 learning_pass_running) while a learning pass holds the tenant: retry.

    \b
    Example:
      TORANA_PROFILE=SA torana --act-as-tenant <TENANT_ID> --act-as-reason "<why>" atlas learning verdicts settle --tenant <TENANT_ID>
    """
    data = _call(_client(ctx).post, "atlas/learning/verdicts/settle", json={"tenant_id": tenant_id})
    _emit(ctx, data, render_settle)


@learning_verdicts.group(name="dry-run", invoke_without_command=True)
@click.pass_context
def verdicts_dry_run(ctx):
    """SA only. Evaluate one tick's items WITHOUT writing verdict rows, in the background: `start` answers with a
    request id at once, `get` reads its status and, when complete, the journal row's counts.

    \b
    Examples:
      TORANA_PROFILE=SA torana --act-as-tenant <TENANT_ID> --act-as-reason "<why>" atlas learning verdicts dry-run start --tenant <TENANT_ID>
      TORANA_PROFILE=SA torana atlas learning verdicts dry-run get <REQUEST_ID> --tenant <TENANT_ID>
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@verdicts_dry_run.command(name="start")
@click.option("--tenant", "tenant_id", required=True, help="The tenant (also the global --act-as-tenant).")
@click.pass_context
def dry_run_start(ctx, tenant_id):
    """SA only. Start a dry run (202); prints the request id to read with `dry-run get`.

    \b
    Example:
      TORANA_PROFILE=SA torana --act-as-tenant <TENANT_ID> --act-as-reason "<why>" atlas learning verdicts dry-run start --tenant <TENANT_ID>
    """
    data = _call(_client(ctx).post, "atlas/learning/verdicts/dry-run", json={"tenant_id": tenant_id})
    fmt, _, _ = _fmt(ctx)
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt)
        return
    rid = data.get("request_id", "?")
    click.echo(f"dry-run {rid}: status {data.get('status', '?')}")
    click.echo(f"read it: torana atlas learning verdicts dry-run get {rid} --tenant {tenant_id}")


@verdicts_dry_run.command(name="get")
@click.argument("request_id")
@click.option("--tenant", default=None, help="The tenant the dry run was for (SA).")
@click.pass_context
def dry_run_get(ctx, request_id, tenant):
    """SA only. A dry run's status (accepted, running, complete, failed) and, once complete, the counts of its
    `verdicts_dry_run` journal row (per rule and outcome, provenance calls, timings, lock hold).

    \b
    Example:
      TORANA_PROFILE=SA torana atlas learning verdicts dry-run get <REQUEST_ID> --tenant <TENANT_ID>
    """
    data = _call(_client(ctx).get, f"atlas/learning/verdicts/dry-run/{request_id}", params=_params(tenant=tenant))
    _emit(ctx, data, render_dry_run)


@learning_verdicts.command(name="anonymise")
@click.option("--tenant", "tenant_id", required=True, help="The tenant (also the global --act-as-tenant).")
@click.option("--roots", "roots", multiple=True, metavar="ROOT",
              help="An event root to anonymise (repeat): image:<sha256> digests or datalake row roots.")
@click.option("--source", "source_id", default=None, metavar="SOURCE_ID",
              help="Every verdict whose event evidence came from this source, e.g. image_scan:gcp.")
@click.pass_context
def verdicts_anonymise(ctx, tenant_id, roots, source_id):
    """SA only. Anonymise the verdicts whose event came from the listed roots, or from one source: the counts stay,
    nothing links back. Give --roots (repeatable) or --source, not both. Journalled.

    \b
    Examples:
      TORANA_PROFILE=SA torana --act-as-tenant <TENANT_ID> --act-as-reason "<why>" atlas learning verdicts anonymise --tenant <TENANT_ID> --roots image:sha256:ab…
      TORANA_PROFILE=SA torana --act-as-tenant <TENANT_ID> --act-as-reason "<why>" atlas learning verdicts anonymise --tenant <TENANT_ID> --source image_scan:gcp
    """
    if bool(roots) == bool(source_id):
        raise click.UsageError("give --roots ROOT (repeatable) or --source SOURCE_ID, exactly one")
    body = {"tenant_id": tenant_id, **({"roots": list(roots)} if roots else {"source_id": source_id})}
    data = _call(_client(ctx).post, "atlas/learning/verdicts/anonymise", json=body)
    fmt, _, _ = _fmt(ctx)
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt)
        return
    click.echo(f"anonymised for {data.get('tenant_id', tenant_id)}: {_compact(data.get('counts') or {}) or 'nothing'}")


@atlas_learning.command(name="credibility")
@click.option("--tenant", default=None, help="Another tenant's table (SA only).")
@click.option("--ledger", type=click.Choice(LEDGERS), default=None)
@click.option("--claim-type", "claim_type", default=None, metavar="CLAIM_TYPE")
@click.option("--producer", default=None, metavar="PRODUCER", help="One producer, sent as given.")
@click.option("--class", "klass", default=None, metavar="CLASS", help="One producer class, e.g. model, integration.")
@click.option("--node", default=None, metavar="PATH",
              help="Only the producers and origins seen on this node's claims (path or subject).")
@click.option("--claim", "claim_ids", multiple=True, metavar="CLAIM_ID",
              help="Only the producers and origins seen on this claim (repeatable).")
@click.pass_context
def learning_credibility(ctx, tenant, ledger, claim_type, producer, klass, node, claim_ids):
    """The tenant's credibility table: per ledger, claim type and producer (or origin), how often later events bore
    it out, in the server's words ("<c>/<n> right, lower bound <lb>", "no record yet"). Shown, not used: nothing
    decides on these numbers yet.

    \b
    Examples:
      torana atlas learning credibility
      torana atlas learning credibility --ledger reader_faith --claim-type image.component
      torana atlas learning credibility --node code/acme/api
    """
    data = _call(_client(ctx).get, "atlas/learning/credibility", params=_params(
        tenant=tenant, ledger=ledger, claim_type=claim_type, producer=producer, **{"class": klass}, node=node,
        claim_ids=",".join(claim_ids) if claim_ids else None))
    _emit(ctx, data, render_credibility)
