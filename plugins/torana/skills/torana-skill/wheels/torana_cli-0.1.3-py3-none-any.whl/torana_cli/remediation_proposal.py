"""Pure builders behind `torana remediation-plans propose` and `torana remediation-plan <id> open-pr`.

FIX_PR_SPEC.md § 3.4.7 and § 3.4.3. No network and no click here, so every rule is unit-tested on files alone.

    planner plan.json + findings.json + apply probe.json  →  one PlanProposal per (target repository, lock)

⭐ LABELS BECOME KEYS. The planner names each tree by a label (the path from `--repo`'s parent, e.g.
`pantheon-deploy/base-image`) and each file relative to that tree. The platform names a repository by its key
(`repo:github.com/<org>/<repo>`) and a file relative to the repository's top level. `scope_keys` resolves every
label once; `rewrite` applies it to EVERY label and path in groups and rows, so nothing stored on a plan carries a
checkout path.

⭐ ONE PROBE SUMMARY. `probe_summary` turns an apply report into the `{packages, edits, downgrades, co_movers}`
the server fingerprints. propose and open-pr both call it, so the two always describe the same edit.
"""

from __future__ import annotations

import os
import re
import subprocess
from typing import Any, Dict, List, Optional, Tuple

SCHEMA = "torana.remediation_plan.v1"
GO_PROBE_STATUSES = ("gates_passed", "needs_human")

_SCP_LIKE = re.compile(r"^(?P<user>[^/@]+)@(?P<host>[^:/]+):(?P<path>.+)$")
_SCHEME = re.compile(r"^[a-z][a-z0-9+.\-]*://")
_USERINFO = re.compile(r"^[^/@]+@")
#: SPT (M1): the platform's forge web-path trim, the same as the scan pack's `repo_key_of`: a verb segment after
#: host/org/repo starts a web path (`…/images/tree/main/x` is the repository `…/images`), never part of the key
_WEB_PATH_VERBS = frozenset({
    "-", "tree", "blob", "raw", "blame", "commit", "commits", "compare", "releases",
    "tags", "branches", "pull", "pulls", "merge_requests", "issues", "wiki", "actions",
    "src",
})
_MIN_IDENTITY_SEGMENTS = 3


class ProposalError(Exception):
    """The inputs cannot make a proposal (exit 2: a usage error, never a guess)."""


# ── repository keys ────────────────────────────────────────────────────────────────

def asset_key(reference: str) -> str:
    """`host/org/repo` from a git remote: lowercase, scp form or scheme stripped, userinfo and `.git` dropped.

    ⚠️ The CLI and the scan pack ship separately and cannot import each other, so the scan pack's normaliser
    (`skills/torana-scan/references/reachability_pass.py` `git_repo_key`, which remediation_apply.py imports) has
    this one twin. `tests/test_remediation_plans_cli.py::test_the_cli_and_the_scan_pack_derive_the_same_key` pins
    the two to the same key on every remote form; change both or neither."""
    key = (reference or "").strip().lower()
    scp = _SCP_LIKE.match(key)
    key = f"{scp.group('host')}/{scp.group('path')}" if scp else _SCHEME.sub("", key)
    key = _USERINFO.sub("", key).strip("/")
    if key.endswith(".git"):
        key = key[:-4]
    key = re.sub(r"/{2,}", "/", key)
    parts = [p for p in key.split("/") if p]
    for i, seg in enumerate(parts):
        if i >= _MIN_IDENTITY_SEGMENTS and seg in _WEB_PATH_VERBS:
            key = "/".join(parts[:i])
            break
    if "/" not in key:
        raise ProposalError(f"cannot derive a repository key from {reference!r}")
    return key


def _git(path: str, *args: str) -> Optional[str]:
    try:
        p = subprocess.run(["git", "-C", path, *args], capture_output=True, text=True)
    except OSError:
        return None
    return (p.stdout or "").strip() if p.returncode == 0 else None


def toplevel(path: str) -> str:
    return _git(path, "rev-parse", "--show-toplevel") or os.path.abspath(path)


def key_of_checkout(path: str) -> Optional[str]:
    remote = _git(path, "remote", "get-url", "origin")
    return "repo:" + asset_key(remote) if remote else None


def scope_keys(plan: Dict[str, Any], repo_key: Optional[str], with_keys: Dict[str, str],
               resolve_git=key_of_checkout, resolve_top=toplevel) -> Dict[str, Tuple[str, str]]:
    """label → (key, prefix). key = `--with-key LABEL=KEY`, else `--repo-key` for scope[0], else `repo:` + the
    origin remote; prefix = the tree's path inside its repository. No key → ProposalError (exit 2)."""
    out: Dict[str, Tuple[str, str]] = {}
    for i, s in enumerate(plan.get("scope") or []):
        label, path = s["repo"], s.get("path") or ""
        key = with_keys.get(label) or (repo_key if i == 0 else None)
        # ⛔ LOWERCASED LIKE `asset_key` (F62 (b)). An explicit `--repo-key repo:github.com/Acme/Svc` was stored
        # verbatim while every remote-derived key, alert and fix-scope answer is lowercase, and DF compares subjects
        # exactly (the CI member check, `list --subject-repository`, refusals, the per-subject merge).
        key = key.strip().lower() if key else key
        top = resolve_top(path) if path and os.path.isdir(path) else path
        if not key and path and os.path.isdir(path):
            key = resolve_git(path)
        if not key:
            raise ProposalError(f"no repository key for scope entry {label!r}: pass --with-key {label}=repo:<host>/"
                                f"<org>/<repo>" + (" or --repo-key" if i == 0 else ""))
        prefix = os.path.relpath(os.path.realpath(path), os.path.realpath(top)) if path and top else "."
        out[label] = (key, "" if prefix == "." else prefix)
    if not out:
        raise ProposalError("the plan has no scope")
    return out


def _path(prefix: str, rel: str) -> str:
    return os.path.normpath(os.path.join(prefix, rel)) if prefix else os.path.normpath(rel)


def rewrite(obj: Any, keys: Dict[str, Tuple[str, str]]) -> Any:
    """Every `{repo: <label>, file: <path>}` (resolve, locks[], edits[]) → `{repo: <key>, file: <repo-relative>}`.
    A `compiled_from` beside a `file` is a path in the same tree and moves with it."""
    if isinstance(obj, list):
        return [rewrite(x, keys) for x in obj]
    if not isinstance(obj, dict):
        return obj
    out = {k: rewrite(v, keys) for k, v in obj.items()}
    label = obj.get("repo")
    if isinstance(label, str) and label in keys and ("file" in obj or "lock_format" in obj):
        key, prefix = keys[label]
        out["repo"] = key
        for f in ("file", "compiled_from"):
            if isinstance(obj.get(f), str):
                out[f] = _path(prefix, obj[f])
    return out


# ── the probe ──────────────────────────────────────────────────────────────────────

def probe_groups(probe: Any) -> Dict[int, Dict[str, Any]]:
    """apply's `--json` output (`{groups: [...]}`), one group report, or a list of them → by group index."""
    if isinstance(probe, dict) and "groups" in probe:
        probe = probe["groups"]
    if isinstance(probe, dict):
        probe = [probe]
    return {int(g.get("group", 0)): g for g in probe or []}


def _lock_name(lk: Dict[str, Any]) -> str:
    return f"{lk['repo']}/{lk['file']}"


def probe_summary(report: Dict[str, Any], classes: Dict[str, int], repo: Optional[str] = None,
                  lock_names: Optional[set] = None) -> Dict[str, Any]:
    """What the server fingerprints (§ 3.4.3): packages `{package, class, target, removal?}`, edits
    `{file, line, action, from, to}`, downgrades `{package, from, to}`, co_movers `{package, from, to}`.
    `repo` keeps the edits landing there; `lock_names` keeps gate 2 of those locks only. A split-out package
    (class 5) is not in the edit."""
    split = {x["package"] for x in report.get("split_out") or []}
    pk = [{"package": p["package"], "class": int(classes.get(p["package"], report.get("class") or 2)),
           "target": p.get("target"), **({"removal": True} if p.get("removal") else {})}
          for p in report.get("packages") or [] if p["package"] not in split]
    edits = [{k: e.get(k) for k in ("file", "line", "action", "from", "to")}
             for e in report.get("edits") or [] if e.get("package") not in split
             and (repo is None or e.get("repo") == repo)]
    moved = [m for g in report.get("gate_2_blast_radius") or []
             if lock_names is None or g.get("lock") in lock_names for m in g.get("moved") or []]
    downgrades = sorted(({"package": m["package"], "from": m.get("from"), "to": m.get("to")}
                         for m in moved if m.get("downgrade")), key=lambda d: d["package"])
    co_movers = sorted(({"package": m["package"], "from": m.get("from"), "to": m.get("to")}
                        for m in moved if not m.get("downgrade")), key=lambda d: d["package"])
    out = {"packages": pk, "edits": edits, "downgrades": _dedupe(downgrades), "co_movers": _dedupe(co_movers)}
    # ⭐ B1: `[[file, sha256_after], …]` from THIS RUN's codemod, for the push lane's `plan_stale`
    # test. The lane asks "does this run reproduce the approved edit?", and for a class-4 plan the
    # rewrite IS part of that edit — so a re-run that produces different bytes must not pass.
    # ⛔ ONLY WHEN NON-EMPTY, matching the server's `_core`: an always-present `codemod_files: []`
    # would move every class-2/3 fingerprint ever stored (measured, spec § 3.3.2).
    files = sorted([f["file"], f["sha256_after"]]
                   for f in ((report.get("codemod") or {}).get("files") or [])
                   if f.get("file") and f.get("sha256_after"))
    if files:
        out["codemod_files"] = files
    return out


def co_mover_api_diffs(report: Dict[str, Any], lock_names: Optional[set] = None) -> List[Dict[str, Any]]:
    """Gate 2's co-movers that carry an API answer (FIX_KNOWLEDGE_CONVERGENCE § 3.6.7 (e), W3-14), as the
    package-level `co_mover_api_diff: [{package, from, to, api_diff}]` DF stores per subject. Kept out of
    `probe_summary`, whose shape other callers compare."""
    out = [{"package": m["package"], "from": m.get("from"), "to": m.get("to"), "api_diff": m["api_diff"]}
           for g in report.get("gate_2_blast_radius") or []
           if lock_names is None or g.get("lock") in lock_names
           for m in g.get("moved") or [] if isinstance(m.get("api_diff"), dict)]
    return _dedupe(sorted(out, key=lambda d: (d["package"], str(d.get("from")), str(d.get("to")))))


def _dedupe(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for r in rows:
        if r not in out:
            out.append(r)
    return out


# ── proposals ──────────────────────────────────────────────────────────────────────

def _short(key: str) -> str:
    return key.rsplit("/", 1)[-1]


def _members(findings: List[Dict[str, Any]], row: Dict[str, Any], subject: str) -> List[Dict[str, Any]]:
    want = set(row.get("alert_ids") or [])
    out, seen = [], set()
    for f in findings:
        aid = f.get("alert_id")
        if not aid or aid in seen or (want and aid not in want):
            continue
        same = (str(f.get("ecosystem") or "").lower() == row["ecosystem"]
                and _norm(row["ecosystem"], f.get("package") or "") == row["package"]
                and str(f.get("installed") or "") == str(row.get("installed") or ""))
        if same:
            seen.add(aid)
            out.append({"alert_id": aid, "package": row["package"], "installed": row.get("installed"),
                        "fixed": f.get("fixed"), "subject_repository": subject})
    return out


def _norm(eco: str, name: str) -> str:
    """PEP 503 for pypi (the planner's `normalize`), the name as written elsewhere."""
    return re.sub(r"[-_.]+", "-", name).lower() if eco == "pypi" else name


def _release(v: Any) -> Tuple[str, ...]:
    """A dotted version without trailing `.0`s, so `23.12` and `23.12.0` compare equal."""
    parts = str(v or "").strip().split(".")
    while len(parts) > 1 and parts[-1] == "0":
        parts.pop()
    return tuple(parts)


def installed_as_written(installed: Any, edits: List[Dict[str, Any]]) -> Any:
    """The installed version as the file spells it, when an exact-pin edit names the same release.

    The planner canonicalises versions (PEP 440 drops trailing zeros), so a file pinning `black==23.12.0`
    reports `23.12`. A title or PR body shown to a reviewer must match the line they will read in the diff.
    """
    for e in edits or []:
        m = re.fullmatch(r"\s*===?\s*(\S+)\s*", str(e.get("from") or ""))
        if m and installed and _release(m.group(1)) == _release(installed):
            return m.group(1)
    return installed


def _description(target: str, resolve_repo: str, resolve_file: str, packages: List[Dict[str, Any]],
                 edits: List[Dict[str, Any]]) -> str:
    moves = ", ".join(f"{p['package']} {installed_as_written(p.get('installed'), edits) or '?'} → "
                      f"{p.get('target') or 'removed'}" for p in packages)
    if target == resolve_repo and edits and {e["file"] for e in edits} == {resolve_file}:
        # A pinned requirements file is both the declaration and the lock: it is edited in place and nothing is
        # recompiled, so "Recompile X after editing X" would describe a step that never runs.
        verb = f"Edit {resolve_file} in {_short(target)}"
    elif target == resolve_repo:
        verb = f"Recompile {resolve_file} in {_short(target)}"
        if edits:
            verb += f" after editing {', '.join(sorted({e['file'] for e in edits}))}"
    else:
        verb = f"Edit {', '.join(sorted({e['file'] for e in edits})) or 'declarations'} in {_short(target)}"
    return f"{verb}: {moves}"


def _rows_index(rows: List[Dict[str, Any]]) -> Dict[Tuple[str, str, str], Dict[str, Any]]:
    return {(r["ecosystem"], r["package"], str(r.get("installed") or "")): r for r in rows}


def _row_of(rows_by: Dict[Tuple[str, str, str], Dict[str, Any]], gp: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """The planner row a group's package entry stands for: same ecosystem, package AND installed version. A group
    entry with no installed version (an older plan) takes the row only when the package has exactly one."""
    row = rows_by.get((gp["ecosystem"], gp["package"], str(gp.get("installed") or "")))
    if row is not None or gp.get("installed"):
        return row
    same = [r for (e, p, _), r in rows_by.items() if (e, p) == (gp["ecosystem"], gp["package"])]
    return same[0] if len(same) == 1 else None


def build_proposals(plan: Dict[str, Any], findings: List[Dict[str, Any]], probe: Any,
                    keys: Dict[str, Tuple[str, str]], refresh: Optional[Tuple[str, str]] = None
                    ) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """(proposals, skipped). One proposal per (target repository, resolve lock): every class-2/3 group whose
    resolve is that lock and whose probe status is gates_passed or needs_human, split by the repository each
    edit or lock lands in (a PR set gives one proposal per repository). `refresh` = (plan_id, lock_key)."""
    reports = probe_groups(probe)
    subject = keys[plan["scope"][0]["repo"]][0]
    commits = {}
    for s in plan.get("scope") or []:
        commits.setdefault(keys[s["repo"]][0], s.get("commit"))
    # ⛔ KEYED BY (ecosystem, package, INSTALLED), never by package alone (F63). One package at three installed versions
    # is three rows, each with its own locks and members (certifi: datalake uv.lock 2025.7.14, base-image lock
    # 2025.1.31, program-framework uv.lock 2025.10.5). Keyed by package, the LAST row won, so the base-image group's
    # proposal took datalake's target, `uv.lock` and Dependabot alert: plan 2cc36f8f.
    rows_by = _rows_index(plan.get("rows") or [])
    acc: Dict[Tuple[str, str, str], Dict[str, Any]] = {}
    skipped: List[Dict[str, Any]] = []
    class4: List[Dict[str, Any]] = []

    for gi, g in enumerate(plan.get("groups") or []):
        if str(g.get("class")) == "4":
            # ⛔ ITS OWN PROPOSAL, AND NEVER PROBED. A class-4 package is the one upgrade this
            # classification exists to refuse: it needs a human to edit code, so it carries NO edits and no
            # command, and the `GO_PROBE_STATUSES` filter below must not apply to it — a class-4 group is
            # never handed to the probe, so requiring a probe report would drop it silently and the finding
            # would vanish from the plan rather than appear as work for a person.
            # ⚠️ The TARGET is the subject repository, not the resolve repo: the code that has to change is
            # the code that calls the moved API, which is what `group()` records as `repos = {primary}`.
            pkg = next((x for x in g.get("packages") or [] if x.get("package")), None)
            if pkg is None:
                continue
            row4 = _row_of(rows_by, pkg) or {}
            resolve4 = rewrite(g["resolve"], keys) if g.get("resolve") else {}
            # ⭐ PHASE 5: THE CODEMOD, AND THE BUMP THAT MUST RIDE WITH IT.
            #
            # ⛔ WITHOUT THIS THE WHOLE PHASE-5 RUNNER WAS UNREACHABLE FROM THE PLATFORM. The
            # applier rewrote the call sites, gated the result with Gate B and measured which
            # rewritten lines the suite ran — and then this function dropped every byte of it, so
            # the stored plan said "a person must change the code" about work already done and
            # checked, and was unapprovable for ever. Measured 2026-10-31, runbook § 1b.
            report4 = reports.get(gi) or {}
            codemod4 = report4.get("codemod") if isinstance(report4.get("codemod"), dict) else None
            usable4 = (codemod4 or {}).get("state") in ("complete", "partial")
            # ⚠️ THE EDITS GO WITH THE CODEMOD OR NOT AT ALL, and the server enforces the same rule
            # (422 `class4_edits_without_codemod`). A bump with no usable rewrite would upgrade past
            # an API this repository still calls — exactly what class 4 exists to refuse — while a
            # rewrite with no bump fixes nothing, because the vulnerable version still resolves.
            edits4 = rewrite(list(report4.get("edits") or []), keys) if usable4 else []
            entry4 = {"package": pkg["package"], "class": 4, "installed": pkg.get("installed"),
                      "target": pkg.get("target"), "flaws": pkg.get("flaws") or 0,
                      "no_fix": pkg.get("no_fix") or 0}
            for k in ("origin", "api_diff"):
                if row4.get(k):
                    entry4[k] = row4[k]
            out4 = {
                "schema": SCHEMA, "engine_version": str(plan.get("engine") or ""),
                "subject_repository": subject, "subject_commit": commits.get(subject) or "",
                "target_repository": subject, "target_commit": commits.get(subject) or "",
                "ecosystem": pkg["ecosystem"],
                "resolve_repository": resolve4.get("repo") or subject,
                "resolve_file": resolve4.get("file") or "",
                "lock_format": resolve4.get("lock_format") or "",
                "class4_package": pkg["package"],
                "packages": [entry4], "members": _members(findings, row4, subject),
                # ⛔ EMPTY UNLESS A USABLE CODEMOD CAME BACK (phase 5). `group()` moved the row's edits to
                # `blocked_edits` because, with no way to change the code, an edit here would recompile the
                # lock this package was classified AWAY from. With the rewrite in hand the bump is not that
                # any more — it is the other half of one fix — so it is sent, and `codemod` is sent with it.
                # ⛔ FILE PATHS, NOT LOCK OBJECTS. `PlanProposal.locks` is `List[str]` and the class-2/3
                # path appends `lk["file"]`; this branch sent the whole rewritten `{repo, file, line,
                # lock_format, compiled_from}` dicts, which pydantic refuses before any service logic runs
                # — and `check_paths` then reports the stringified dict as a path that is not a manifest.
                # ⚠️ PRE-EXISTING, found 2026-10-31 by posting the first class-4 proposal that had a lock
                # to send: until phase 5 the lane was only ever exercised with none.
                "edits": edits4,
                "locks": [lk["file"] for lk in rewrite(row4.get("locks") or [], keys)
                          if isinstance(lk, dict) and lk.get("file")],
                # ⚠️ Sent even when NOT usable (`refused`, `unavailable`, `not_run`), because a decline is
                # an answer a person needs: it says the rewrite was attempted and why it did not land.
                # `None` only when the runner reported nothing at all, which stays NULL in the column.
                **({"codemod": codemod4} if codemod4 else {}),
                "downgrades": [], "co_movers": [],
                # ⛔ `blocked_edits` and `why` ARE NOT SENT AT TOP LEVEL. `PlanProposal` is
                # `extra="forbid"`, so a proposal carrying them is refused 422 `extra_forbidden`
                # BEFORE any service logic runs — the whole class-4 lane, every time. MEASURED
                # against the live API 2026-10-26: the lane had only ever been exercised against a
                # synthetic plan, so nothing had posted one.
                # ⭐ Nothing is lost: `row4` already carries both, and it is sent verbatim in
                # `planner_rows` below (`remediation_plan.py` sets `row["blocked_edits"]` when it
                # moves the edits off a class-4 row). The top-level copies were duplicates.
                "evidence": g.get("evidence") or [],
                "planner_group": {"groups": [gi]},
                "planner_rows": [rewrite(row4, keys)] if row4 else [],
                "refresh_plan_id": None, "blocked_by_locks": [],
                "description": ((f"Code change: {pkg['package']} {pkg.get('installed') or '?'} → "
                                 f"{pkg.get('target') or '?'} changes an API this repository calls; "
                                 f"{len((codemod4 or {}).get('files') or [])} file(s) migrated")
                                if usable4 else
                                (f"Code change needed: {pkg['package']} "
                                 f"{pkg.get('installed') or '?'} → {pkg.get('target') or '?'} changes an API "
                                 f"this repository calls")),
            }
            class4.append(out4)
            continue
        if str(g.get("class")) not in ("2", "3") or not g.get("resolve"):
            continue
        rep = reports.get(gi)
        if rep is None or rep.get("status") not in GO_PROBE_STATUSES:
            skipped.append({"group": gi, "status": (rep or {}).get("status") or "not_probed",
                            "why": (rep or {}).get("why") or "the probe has no report for this group"})
            continue
        split = {x["package"] for x in rep.get("split_out") or []}
        by_pkg = {p["package"]: p for p in rep.get("packages") or []}
        rep_edits = {(e.get("package"), e["repo"], e["file"], e["line"]): e for e in rep.get("edits") or []}
        resolve = rewrite(g["resolve"], keys)
        cls = int(g["class"])
        for gp in g["packages"]:
            if gp["package"] in split:
                continue
            row = _row_of(rows_by, gp)
            if row is None:
                continue
            probed = by_pkg.get(gp["package"], {})
            locks_k = rewrite(row.get("locks") or [], keys)
            row_edits = row.get("edits") or []
            edits_k = rewrite([rep_edits.get((gp["package"], e["repo"], e["file"], e["line"]), e)
                               for e in row_edits], keys)
            repos = sorted({lk["repo"] for lk in locks_k} | {e["repo"] for e in edits_k})
            for target in repos:
                lk_key = f"{target}|{resolve['repo']}|{resolve['file']}"
                p = acc.setdefault((target, resolve["repo"], resolve["file"]), {
                    "schema": SCHEMA, "engine_version": str(plan.get("engine") or ""),
                    "subject_repository": subject, "subject_commit": commits.get(subject) or "",
                    "target_repository": target, "target_commit": commits.get(target) or "",
                    "ecosystem": gp["ecosystem"], "resolve_repository": resolve["repo"],
                    "resolve_file": resolve["file"], "lock_format": resolve.get("lock_format") or "",
                    "packages": [], "members": [], "edits": [], "locks": [], "downgrades": [], "co_movers": [],
                    "evidence": [], "planner_group": {"groups": []}, "planner_rows": [],
                    "refresh_plan_id": refresh[0] if refresh and refresh[1] == lk_key else None,
                    "blocked_by_locks": [], "_lock_names": set(), "_groups": set()})
                entry = {"package": gp["package"], "class": cls, "installed": gp.get("installed"),
                         "target": probed.get("target", gp.get("target")), "flaws": gp.get("flaws") or 0,
                         "no_fix": gp.get("no_fix") or 0}
                for k in ("partial", "requested_target", "open_alert_ids"):
                    if probed.get(k):
                        entry[k] = probed[k]
                for k in ("removal", "falls_out_with", "blocked_on"):
                    if gp.get(k):
                        entry[k] = gp[k]
                # ⭐ FROM THE ROW, not from `gp`. `group()` copies a fixed field list onto its packages and
                # `origin` / `api_diff` are not in it, so reading `gp` would silently drop both and every
                # entry would look like the question was never asked. The row is the planner's full record.
                # ⛔ CARRIED EVEN WHEN NOTHING WAS FOUND. `{"state": "not_requested"}` and an ABSENT block
                # are different claims — "nobody looked" versus "this plan predates the question" — and the
                # approve dialog's `api_diff_unknown` acknowledgement turns on telling them apart.
                # `api_question` (FIX_KNOWLEDGE_CONVERGENCE § 3.6.7 (b)) and `move_scope` (§ 3.4.6, R6) follow the
                # same rule: DF derives the acknowledgements and the `member_out_of_scope` blocker from them.
                # `target_line`, `parents_admit` and `override_forced` (B54/B55) are the planner's measurements of
                # the target and its parents' ranges; DF words a forced override in the PR body from them.
                for k in ("origin", "api_diff", "api_question", "move_scope", "target_line", "parents_admit",
                          "override_forced"):
                    if row.get(k):
                        entry[k] = row[k]
                if all(x["package"] != entry["package"] for x in p["packages"]):
                    p["packages"].append(entry)
                for m in _members(findings, row, subject):
                    if all(x["alert_id"] != m["alert_id"] for x in p["members"]):
                        p["members"].append(m)
                for e in edits_k:
                    if e["repo"] != target:
                        continue
                    ed = {k: e[k] for k in ("file", "line", "action", "from") if k in e}
                    if e.get("to") is not None:
                        ed["to"] = e["to"]
                    if e.get("needs_human"):
                        ed["needs_human"] = e["needs_human"]
                    if ed not in p["edits"]:
                        p["edits"].append(ed)
                for lk, orig in zip(locks_k, row.get("locks") or []):
                    if lk["repo"] == target:
                        if lk["file"] not in p["locks"]:
                            p["locks"].append(lk["file"])
                        p["_lock_names"].add(_lock_name(orig))
                for b in probed.get("blocked_by_locks") or []:
                    bk = rewrite({"repo": b["repo"], "file": b["file"]}, keys)
                    item = {"lock_key": f"{bk['repo']}|{bk['repo']}|{bk['file']}", "reason": b.get("reason") or ""}
                    if item not in p["blocked_by_locks"]:
                        p["blocked_by_locks"].append(item)
                if gi not in p["_groups"]:
                    p["_groups"].add(gi)
                    p["evidence"] += [x for x in g.get("evidence") or [] if x not in p["evidence"]]
                    p["planner_group"]["groups"].append(rewrite(g, keys))
                rk = rewrite(row, keys)
                if rk not in p["planner_rows"]:
                    p["planner_rows"].append(rk)
                p.setdefault("_reports", []).append(rep)

    out = []
    for p in acc.values():
        classes = {x["package"]: x["class"] for x in p["packages"]}
        co_api: List[Dict[str, Any]] = []
        for rep in p.pop("_reports"):
            s = probe_summary(rep, classes, lock_names=p["_lock_names"])
            p["downgrades"] = _dedupe(sorted(p["downgrades"] + s["downgrades"], key=lambda d: d["package"]))
            p["co_movers"] = _dedupe(sorted(p["co_movers"] + s["co_movers"], key=lambda d: d["package"]))
            co_api = _dedupe(co_api + co_mover_api_diffs(rep, p["_lock_names"]))
        if co_api:
            # The co-movers belong to the lock's resolve, so every package this plan moves on it carries them.
            for x in p["packages"]:
                x["co_mover_api_diff"] = co_api
        p.pop("_lock_names")
        p.pop("_groups")
        p["description"] = _description(p["target_repository"], p["resolve_repository"], p["resolve_file"],
                                        p["packages"], p["edits"])
        out.append(p)
    # ⚠️ Appended AFTER the class-2/3 proposals, so a reader meets the fixable work first and the one
    # package that needs a person last. They are separate proposals, never members of each other.
    return out + class4, skipped


def drop_packages(proposal: Dict[str, Any], names: List[str]) -> Dict[str, Any]:
    """A 409 `refused_change`: drop the named packages from packages, members, edits AND planner_rows (§ 3.4.7)."""
    gone = set(names)
    p = dict(proposal)
    p["packages"] = [x for x in p["packages"] if x["package"] not in gone]
    p["members"] = [x for x in p["members"] if x["package"] not in gone]
    p["planner_rows"] = [r for r in p["planner_rows"] if r.get("package") not in gone]
    keep_lines = {(e["file"], e["line"]) for r in p["planner_rows"] for e in r.get("edits") or []}
    dropped_lines = {(e["file"], e["line"]) for r in proposal["planner_rows"] if r.get("package") in gone
                     for e in r.get("edits") or []}
    p["edits"] = [e for e in p["edits"] if (e["file"], e["line"]) not in dropped_lines - keep_lines]
    return p


# ── open-pr ────────────────────────────────────────────────────────────────────────

_DIFF_FILE = re.compile(r"^\+\+\+ (?:b/)?(?P<path>\S.*?)\s*$")
MAX_FILES = 32
MAX_FILE_BYTES = 4 * 1024 * 1024
MAX_TOTAL_BYTES = 8 * 1024 * 1024
MAX_EVIDENCE = 40_000


def diff_paths(diff_text: str, target_repository: str) -> List[str]:
    """The repo-relative paths a `changes.diff` touches in the target repository. apply writes headers as
    `b/<repo>/<file>` where `<repo>` is the label (a local plan) or the key (`--plan-id`); a header for another
    repository is not this plan's file and is left out."""
    prefixes = [target_repository + "/", target_repository.removeprefix("repo:") + "/"]
    out: List[str] = []
    for ln in diff_text.splitlines():
        m = _DIFF_FILE.match(ln)
        if not m or m.group("path") == "/dev/null":
            continue
        path = m.group("path")
        for pre in prefixes:
            if path.startswith(pre):
                rel = path[len(pre):]
                if rel not in out:
                    out.append(rel)
                break
    return out


def evidence_markdown(report: Dict[str, Any]) -> str:
    """Gates 1–3 as the PR body's evidence (DF fences it and strips `Torana-` lines)."""
    # EM D-23 S2 (m-L1-9): `gates_passed` means gates 1–3 (resolve, blast radius, lane), never build and tests,
    # which the PR's own CI runs: "Probe status: gates_passed" beside "Build and tests: NOT CHECKED" read as a contradiction.
    status = report.get("status")
    lines = [f"Checks before the PR (gates 1–3): {'passed' if status == 'gates_passed' else status}"]
    for g in report.get("gate_1_resolve") or []:
        landed = ", ".join(f"{k} {v.get('from')} → {v.get('to')}" for k, v in (g.get("landed") or {}).items())
        lines.append(f"Gate 1 (resolve) {g.get('lock')}: {'ok' if g.get('ok') else 'FAIL'}"
                     + (f" — {landed}" if landed else "") + (f" — {g['why']}" if g.get("why") else ""))
    for g in report.get("gate_2_blast_radius") or []:
        moved = ", ".join(f"{m['package']} {m.get('from')} → {m.get('to')}"
                          + (" (DOWNGRADE)" if m.get("downgrade") else "") for m in g.get("moved") or [])
        lines.append(f"Gate 2 (blast radius) {g.get('lock')}: {moved or 'no other package moved'}")
    g3 = report.get("gate_3_lane") or {}
    if g3:
        lines.append(f"Gate 3 (lane): {'ok' if g3.get('ok') else 'FAIL ' + ', '.join(g3.get('outside_lane') or [])}")
    for r in report.get("resolver") or []:
        if r.get("cmd") is None:
            # I-84: no resolver ran (a pinned requirements file is edited in place). Say so, in the applier's own
            # words: "$ None (rc 0)" read as a command that ran and passed, and an omitted absence reads as a pass.
            why = re.sub(r"^no resolver:\s*", "", str(r.get("note") or r.get("output") or "no command"))
            lines.append(f"No resolver ran: {why}")
            continue
        lines.append(f"$ {r.get('cmd')}  (rc {r.get('rc')})")
    text = "\n".join(lines)
    return text[:MAX_EVIDENCE]
