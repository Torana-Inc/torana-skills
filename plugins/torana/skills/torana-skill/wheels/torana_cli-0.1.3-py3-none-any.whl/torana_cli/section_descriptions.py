"""What each Inbox card shows, for `--help`.

The platform owns these texts and returns each one as `description` on its section, so the CLI prints the server's own words whenever
it reads a section. `--help` cannot call the server, so this list is the help's copy of them. `tests/fixtures/section_descriptions.json`
holds the same texts, and a test fails when this list drifts from it. Keys are the CLI's `--section` keys.
"""
import inspect
import re
import textwrap

import click

SECTION_DESCRIPTIONS = {
    "item": {
        "overview": "Torana's level for this item and the ranking's reason for it.",
        "about": "What this item is. For an entry: what one change does and how many findings it clears, how many vulnerabilities it covers and where, the most urgent one, their weakness types and what it does not cover, with every CVE and CWE folded below. For a finding: its description, the CVEs and CWEs it covers and the code in GitHub where it has them.",
        "exposure-path": "The proof for this item: what it connects to, as a graph, and the claims that back each connection.",
        "verdict": "Whether the findings are real and, once decided, who decided and why.",
        "provenance": "What code analysis shows about this finding, four rows: whether the vulnerable version ships, whether it is running, whether the vulnerable code is reachable, and who owns it. Each row is known, partly known or not yet known, and says why; the card says when it was last verified.",
        "atlas": "What code analysis shows about this finding, four rows: whether the vulnerable version ships, whether it is running, whether the vulnerable code is reachable, and who owns it. Each row is known, partly known or not yet known, and says why; the card says when it was last verified.",
        "reachability": "Whether the vulnerable code is actually used in the repository that was measured, at which commit, and what the answer did to this item's priority.",
        "how-to-fix": "The fix when there is one, or the mitigation when there is no fixed version.",
        "fix-pr-ci": "The CI of the fix PR's current commit as Torana last read it: whether it failed, is running or passed, the failing checks with their step and first error, and when GitHub was last asked.",
        "clears": "The open findings this one fix resolves, and how many are already closed when some are.",
        "affected": "The findings grouped under this entry.",
        "reported-by": "Which scanners and rules reported these findings, and when they were first and last seen.",
        "why-here": "Why this item is where it is: why it was closed, reopened or moved, when that has happened.",
        "history": "What happened to this item over time, when anything has.",
        "path": "The path this item took through the platform, from the data change that raised it to now: for an entry, its own events and its findings grouped by the path each one went through, groups whose review is pending first; for a finding, every step in time order with the service that ran it and its trace.",
    },
    "cve": {
        "about": "What this vulnerability is: its severity, how likely it is to be exploited, whether it is on CISA's Known Exploited list (with its fix-by date if it is), and links to the advisories when the record has them.",
        "where-found": "Every place this vulnerability is found today: repositories, images and running services, with counts.",
        "blast-radius": "The services and images running the affected package version, and which of them face the internet.",
        "verdict": "Whether these findings are real, who decided (the triage agent, a rule or a person), and how many are open or closed. It warns when findings for the same vulnerability were decided differently.",
        "how-to-fix": "The fix for each affected package: the installed and fixed versions. With no fixed version it points to the Inbox entry that tracks the mitigation.",
        "reported-by": "The scanners that reported these findings, with how many findings each reported.",
        "history": "What happened over time, week by week: findings first seen, closed and reopened.",
    },
    "cwe": {
        "about": "What this weakness is: its name, description and a link to MITRE.",
        "where-found": "Every place this weakness is found today: code findings and the package CVEs that carry it, with counts.",
        "location": "The files where this weakness is reported, with the findings and verdicts in each, and a link to the file in GitHub where it can be located.",
        "verdict": "What was decided earlier on code findings for this weakness: who decided, what, and when.",
        "reported-by": "The rules that reported code findings for this weakness, with the verdicts on each.",
        "related": "The package CVEs in this app that carry this weakness.",
    },
    # The cards of an app's Home (`torana app <ID> ai-home get --section`), in page order. The server's copy is
    # pantheon_shared.proof.home_sections._CARD; tests/test_ai_home_sections.py compares these with the recorded page.
    "home": {
        "act-first": "The few things to do before anything else on this page.",
        "summary": "The page in one sentence, its headline counts, and how the run came down to them.",
        "what-matters": "The questions this app answers for you, each with its current answer.",
        "trust": "What could make this page wrong, said only when something could.",
        "health": "Whether the app itself is working: its data syncs, checks, agents and alert routing.",
        "needs-you": "The decisions waiting on a person, one card per decision.",
        "handled": "What the app closed or acted on without you in this window.",
        "rules": "Whether the app's checks ran, what they matched, and how the alert list is moving.",
        "dashboards": "The app's own figures, grouped by dashboard, with what each one says.",
        "blind": "What this app needs but does not have: the figures it cannot compute and the settings or data it is missing.",
    },
    # A widget card (`dashboard <ID> render`, `widget <ID> render`). pantheon-viz owns these
    # texts (services/card_wording.py SECTIONS) and returns each on `card.sections`.
    "widget": {
        "about": "What this widget shows and how to read it, in its author's words.",
        "health": "Whether every field this widget reads is being supplied, and who can fix it when one is not.",
        "freshness": "How old the data behind this widget is, whether that is stale, and what to do about it.",
        "empty": "Why this widget shows nothing: a supply gap, no matching rows, or a failed query.",
        "data": "The rows, series or value the widget shows.",
    },
}


def sections_block(surface: str) -> str:
    """The `--help` list of one command's --section keys with their descriptions, wrapped under a hanging indent."""
    items = SECTION_DESCRIPTIONS[surface]
    width = max(len(k) for k in items) + 2
    out = []
    for key, text in items.items():
        wrapped = textwrap.wrap(text, 104 - width)
        out.append(f"{key:<{width}}{wrapped[0]}")
        out.extend(f"{'':<{width}}{w}" for w in wrapped[1:])
    return "\n".join(out)


def fill_help_marker(help_text: str, marker: str, block: str) -> str:
    """Replace the line holding only `{marker}` with `block`, indented like that line.

    Matches the marker at ANY indent (B-55). Python 3.13 strips a docstring's common indentation at compile time
    (3.12 does not), so a replace keyed on a fixed number of spaces found the marker on 3.12 and never on 3.13:
    `--help` then printed a literal `{SECTIONS}` / `{START_HERE}`. `block` is dedented docstring-style first
    (`inspect.cleandoc`), then given the marker line's own indent, so the result reads the same on both.
    """
    lines = inspect.cleandoc(block)
    return re.sub(r"(?m)^([ \t]*)\{" + re.escape(marker) + r"\}[ \t]*$",
                  lambda m: textwrap.indent(lines, m.group(1)), help_text)


def with_sections_help(command, surface: str):
    """Fill the `{SECTIONS}` marker in a command's help with its keys and descriptions."""
    command.help = fill_help_marker(command.help, "SECTIONS", sections_block(surface))
    return command


def all_reasons_option(f):
    """`--all-reasons` on a command that prints sections: lines fold their individual reasons behind a hint unless it is given."""
    return click.option("--all-reasons", "all_reasons", is_flag=True, default=False,
                        help="Print the reasons the screen folds behind \"Show all reasons (N)\" (text format only).")(f)
