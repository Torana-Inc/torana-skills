"""torana govern — set human-judgment governance on assets (EM C4).

Governance is the facts no scanner can discover: how critical a service is, who
owns it, and which datastore holds customer data. These drive A6 shadow detection
(the GOVERNED set) and the C6 prioritization rule (the customer-data clause).

The setting verbs write POLICY ENTRIES (PUT /api/v1/vm/policy/bindings/{key}/entries):
`criticality_overrides`, `customer_data_overrides` and `ownership_routing`. A value a
person sets is policy, never a source value; the asset's own labels or tags stay its
source values, and the app shows both (DS2 § 3.3.7).

Subcommands
-----------
  service   <service-key>   --criticality … --owner … --env …
  datastore <store-key>     --classification … [--pii]
  repo      <repo-ref>      --criticality … --owner … --env …
  show      <entity-key>    read current governance on a node

Grouped under a single semantic parent (`govern`) per the CLI grouping convention.
"""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import (
    APIError,
    ToranaClient,
    handle_api_error,
    handle_auth_error,
)
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    return ToranaClient(base_url=get_settings(profile).base_url)


def _ctx(ctx):
    return (
        ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text",
        ctx.obj.get(CTX_RAW, False) if ctx.obj else False,
        ctx.obj.get(CTX_FIELDS) if ctx.obj else None,
    )


# ─── parent group ───────────────────────────────────────────────────────────────

@click.group(name="govern")
def govern():
    """Set governance (criticality / owner / data-classification) on assets.

    \b
    Governance is the facts NO SCANNER CAN KNOW — who owns a thing, how critical
    it is, what class of data it holds. The graph supplies the topology; this
    supplies the judgment, and exposure scoring needs both.

    \b
    Examples:
      torana govern show service:prod/billing-api
      torana govern service service:prod/billing-api \\
          --criticality High --owner payments-team --customer-data
      torana govern repo repo:github.com/acme/billing-api --criticality High
      torana govern datastore datastore:aws/dynamodb/<acct>/<region>/orders --pii
      torana govern history service:prod/billing-api      who changed what, when
    """


# ─── policy entries ─────────────────────────────────────────────────────────────

#: Which policy setting each business-context flag writes (DS2 § 3.3.7).
_CUSTOMER_DATA = {"customer-data": True, "pii": True, "phi": True, "confidential": True,
                  "restricted": True, "internal": False, "public": False,
                  "not-customer-data": False}


def put_entry(client, key: str, selector: str, value, reason: str = "") -> dict:
    """Set one selector's entry of a policy map (PUT vm/policy/bindings/{key}/entries)."""
    return client.put(f"vm/policy/bindings/{key}/entries",
                      json={"selector": selector, "value": value, "reason": reason or ""})


def _moved(flag: str, why: str) -> None:
    click.echo(f"moved: {flag} is no longer stored ({why})", err=True)


def _write_entries(ctx, selector: str, entries, reason):
    """Write each (key, value) entry for one selector and render what was stored."""
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    results = []
    try:
        for key, value in entries:
            out = put_entry(client, key, selector, value, reason or "")
            results.append({"key": key, "selector": out.get("selector", selector),
                            "value": value, "status": out.get("status", "set"),
                            "effect_note": out.get("effect_note") or ""})
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    if not results:
        click.echo("nothing to set: no business-context flag was given", err=True)
        return
    output(results, fmt=fmt, raw=raw, fields=fields,
           columns=[("key", "SETTING", 26), ("selector", "SELECTOR", 48), ("value", "VALUE", 12),
                    ("effect_note", "NOTE", 40)])


# ─── service ────────────────────────────────────────────────────────────────────

@govern.command(name="service")
@click.argument("service_key")
@click.option("--criticality", type=click.Choice(["Critical", "High", "Medium", "Low"]), default=None)
@click.option("--owner", default=None, help="Owning team or handle (an ownership_routing entry).")
@click.option("--customer-data/--no-customer-data", "customer_data", default=None,
              help="Whether the service holds customer data.")
@click.option("--owner-email", default=None, hidden=True)
@click.option("--env", "environment", default=None, hidden=True)
@click.option("--name", "name", default=None, hidden=True)
@click.option("--desc", "description", default=None, hidden=True)
@click.option("--reason", default=None, help="Why (recorded on each entry).")
@click.pass_context
def govern_service(ctx, service_key, criticality, owner, customer_data, owner_email, environment,
                   name, description, reason):
    """Set a SERVICE's criticality, customer data or owning team as policy entries.

    \b
    Sets a policy entry for this service; the values are not stored on the service.
    The service's own labels or tags stay its source values, and the app shows both.
    """
    if environment is not None:
        _moved("--env", "the environment is read from the source's own label or tag")
    for flag, value in (("--owner-email", owner_email), ("--name", name), ("--desc", description)):
        if value is not None:
            _moved(flag, "it has no consumer")
    entries = []
    if criticality is not None:
        entries.append(("criticality_overrides", criticality))
    if customer_data is not None:
        entries.append(("customer_data_overrides", customer_data))
    if owner is not None:
        entries.append(("ownership_routing", owner))
    _write_entries(ctx, service_key, entries, reason)


# ─── datastore ──────────────────────────────────────────────────────────────────

@govern.command(name="datastore")
@click.argument("store_key")
@click.option("--classification", "data_classification",
              type=click.Choice(sorted(_CUSTOMER_DATA)), default=None,
              help="customer-data|pii|phi|confidential|restricted mean it holds customer data.")
@click.option("--engine", default=None, hidden=True)
@click.option("--provider", default=None, hidden=True)
@click.option("--sensitivity", "data_sensitivity", default=None, hidden=True)
@click.option("--pii", is_flag=True, default=False, help="Mark the store as holding customer data.")
@click.option("--owner", default=None, hidden=True)
@click.option("--steward", "data_steward", default=None, hidden=True)
@click.option("--desc", "description", default=None, hidden=True)
@click.option("--reason", default=None, help="Why (recorded on the entry).")
@click.pass_context
def govern_datastore(ctx, store_key, data_classification, engine, provider, data_sensitivity,
                     pii, owner, data_steward, description, reason):
    """Say whether a DATASTORE holds customer data, as a policy entry.

    \b
    STORE_KEY is the store's name, its scoped tail, or its full datastore: key; a name or tail
    resolves to the one current store that has it (several: the command lists them and sets nothing).
    A store's own tag or label stays its source value.
    """
    for flag, value in (("--engine", engine), ("--provider", provider),
                        ("--sensitivity", data_sensitivity), ("--owner", owner),
                        ("--steward", data_steward), ("--desc", description)):
        if value is not None:
            _moved(flag, "it has no consumer")
    selector = store_key if store_key.startswith("datastore:") else f"datastore:{store_key}"
    value = True if pii else (_CUSTOMER_DATA.get(data_classification) if data_classification else None)
    _write_entries(ctx, selector, [("customer_data_overrides", value)] if value is not None else [],
                   reason)


# ─── repo ─────────────────────────────────────────────────────────────────────--

@govern.command(name="repo")
@click.argument("repo_ref")
@click.option("--criticality", type=click.Choice(["Critical", "High", "Medium", "Low"]), default=None)
@click.option("--owner", default=None, help="Owning team (an ownership_routing entry).")
@click.option("--customer-data/--no-customer-data", "customer_data", default=None)
@click.option("--owner-email", default=None, hidden=True)
@click.option("--env", "environment", default=None, hidden=True)
@click.option("--desc", "description", default=None, hidden=True)
@click.option("--reason", default=None, help="Why (recorded on each entry).")
@click.pass_context
def govern_repo(ctx, repo_ref, criticality, owner, customer_data, owner_email, environment,
                description, reason):
    """Set a REPOSITORY's criticality, customer data or owning team as policy entries."""
    if environment is not None:
        _moved("--env", "the environment is read from the source's own label or tag")
    for flag, value in (("--owner-email", owner_email), ("--desc", description)):
        if value is not None:
            _moved(flag, "it has no consumer")
    selector = repo_ref if repo_ref.startswith("repo:") else f"repo:{repo_ref}"
    entries = []
    if criticality is not None:
        entries.append(("criticality_overrides", criticality))
    if customer_data is not None:
        entries.append(("customer_data_overrides", customer_data))
    if owner is not None:
        entries.append(("ownership_routing", owner))
    _write_entries(ctx, selector, entries, reason)


# ─── show ─────────────────────────────────────────────────────────────────────--

#: How a subject `state` reads to a human. The whole point of CLI-19: an edge-less
#: node used to render EXACTLY like a non-existent one (`EDGES [] / NODES []`), so the
#: reader could not tell "this repo is not on the platform" from "this repo is on the
#: platform and simply has no edges yet". Those are different problems with different
#: owners, and the CLI now says which one it is.
_SUBJECT_VERDICT = {
    "resolved": ("EXISTS", "backed by an inventory row in {home}"),
    "referenced": (
        "NOT IN INVENTORY",
        "no row in its home table — an onboarded integration could have produced "
        "one but has not (an ingestion gap worth chasing)",
    ),
    "unclaimed": (
        "NOT IN INVENTORY",
        "no row in its home table, and nothing onboarded claims authority for it "
        "(expected — not a defect)",
    ),
}


def _print_subject(entity_key, subject, edge_count):
    """Render the subject verdict, then the edge count, in that order.

    ⛔ The verdict comes FIRST and is stated in words, not inferred from an empty
    list. A reader who sees `EDGES []` alone cannot distinguish absence-of-node from
    absence-of-edges; that ambiguity IS CLI-19.
    """
    state = (subject or {}).get("state")
    home = (subject or {}).get("home_table") or "its home table"
    verdict, detail = _SUBJECT_VERDICT.get(
        state, ("UNKNOWN", "the server did not report a subject state"),
    )
    click.echo(f"KEY       {entity_key}")
    click.echo(f"SUBJECT   {verdict}  ({detail.format(home=home)})")
    if edge_count:
        click.echo(f"EDGES     {edge_count}")
    elif verdict == "EXISTS":
        click.echo("EDGES     0 — the node exists but nothing connects it yet "
                   "(no governance can be inherited through the graph)")
    else:
        click.echo("EDGES     0")


#: The policy maps `torana govern` writes, with the words `govern show` prints for each.
_GOVERNANCE_KEYS = (("criticality_overrides", "CRITICALITY"), ("customer_data_overrides", "CUSTOMER DATA"),
                    ("ownership_routing", "OWNER"))


def _entry_for(value, entity_key: str):
    """(found, entry) for `entity_key` in one policy map (selector -> value). The selector is stored in its canonical (lower-case)
    form, so the match ignores case; a bare key also matches its `repo:` / `datastore:` form."""
    if not isinstance(value, dict):
        return False, None
    want = entity_key.strip().lower()
    for sel, val in value.items():
        s = str(sel).strip().lower()
        if s == want or s.split(":", 1)[-1] == want:
            return True, val
    return False, None


def _read_resolved(client, entity_key: str):
    """The platform's RESOLVED values for the node and where each came from (GET properties/resolve/<key>, the resolution
    the Inbox and Service Provenance read, `torana vm properties resolve`). The CLI does not re-implement the matching.
    None when the platform has no row for the key (404); {"error": ...} when it could not be read."""
    try:
        from urllib.parse import quote
        return client.get(f"properties/resolve/{quote(entity_key, safe='/:@')}") or {}
    except APIError as exc:
        status = getattr(exc, "status_code", None)
        if status == 404:
            return None
        if status == 403:
            return {"error": "no permission to read resolved values (deployment:read)"}
        return {"error": str(exc)[:120]}
    except AuthError as exc:
        return {"error": str(exc)[:120]}


def _read_governance(client, entity_key: str) -> dict:
    """What the platform says about this node: {"resolved": <resolve row or None>, "policy_entries": {setting: {"set", "value"}}}.

    `resolved` has the values in force (criticality, customer data, team, owner) with their provenance. `policy_entries` is the
    tenant's policy entry for THIS EXACT KEY (GET vm/policy/bindings/<key>, selector matched ignoring case): the override a person
    set, which is a different fact from the value in force. A setting that could not be read is {"error": "..."}, never "not set"."""
    entries = {}
    for key, _label in _GOVERNANCE_KEYS:
        try:
            binding = client.get(f"vm/policy/bindings/{key}") or {}
        except (AuthError, APIError) as exc:
            entries[key] = {"error": str(exc)[:120]}
            continue
        found, val = _entry_for(binding.get("value"), entity_key)
        entries[key] = {"set": found, "value": val}
    return {"resolved": _read_resolved(client, entity_key), "policy_entries": entries}


def _owner_words(val) -> str:
    """An ownership entry as words: a team or owner name, or `team: x, owner: y` for a map. Never a Python repr."""
    if isinstance(val, dict):
        return ", ".join(f"{k}: {v}" for k, v in val.items() if v not in (None, "")) or "no owner recorded"
    if isinstance(val, (list, tuple)):
        return ", ".join(str(v) for v in val if v not in (None, ""))
    return str(val)


def _entry_words(key: str, val) -> str:
    if key == "customer_data_overrides":
        return "holds customer data" if val is True else "holds no customer data" if val is False else str(val)
    if key == "ownership_routing":
        return _owner_words(val)
    return str(val)


#: Resolved column(s) behind each printed setting, and how a value reads.
_RESOLVED_COLUMNS = {"criticality_overrides": ("criticality_name",), "customer_data_overrides": ("has_customer_data",),
                     "ownership_routing": ("asset_team", "asset_owner")}


def _resolved_words(key: str, resolved: dict) -> tuple:
    """(value words, source words) in force for one setting, or (None, None) when the platform resolved nothing for it."""
    prov = resolved.get("provenance") or {}
    if isinstance(prov, str):
        import json as _json
        try:
            prov = _json.loads(prov)
        except ValueError:
            prov = {}
    cols = _RESOLVED_COLUMNS[key]
    vals = [(c, resolved.get(c)) for c in cols if resolved.get(c) not in (None, "")]
    if not vals:
        return None, None
    if key == "criticality_overrides":
        lvl = resolved.get("criticality_level")
        text = f"{vals[0][1]}" + (f" (level {lvl})" if lvl is not None else "")
    elif key == "customer_data_overrides":
        text = _entry_words(key, vals[0][1])
    else:
        text = _owner_words({("team" if c == "asset_team" else "owner"): v for c, v in vals})
    src = prov.get(vals[0][0]) if isinstance(prov.get(vals[0][0]), dict) else {}
    source = src.get("rule") or src.get("source") or ""
    return text, source


def _print_governance(governance: dict) -> None:
    """The values `govern show` promises, one block per setting, after the subject and edges: the value IN FORCE with its source
    (the platform's resolution), then the policy entry for this exact key when a person set one."""
    resolved = governance.get("resolved")
    entries = governance.get("policy_entries") or {}
    for key, label in _GOVERNANCE_KEYS:
        entry = entries.get(key) or {}
        if isinstance(resolved, dict) and not resolved.get("error"):
            text, source = _resolved_words(key, resolved)
            line = f"{text}" + (f"  (source: {source})" if source else "") if text else ""
        else:
            line = ""
        if entry.get("error"):
            policy = f"policy entry could not be read ({entry['error']})"
        elif entry.get("set"):
            policy = f"policy entry for this exact key: {_entry_words(key, entry.get('value'))}"
        else:
            policy = ""
        if not line and not policy:
            if isinstance(resolved, dict) and resolved.get("error"):
                line = f"could not be read ({resolved['error']})"
            else:
                line = "no policy entry for this node: the source's value applies, else the policy default"
        click.echo(f"{label:<14}{line}")
        if policy:
            click.echo(f"{'':<14}{policy}")


@govern.command(name="show")
@click.argument("entity_key")
@click.pass_context
def govern_show(ctx, entity_key):
    """Show the current governance on a node (criticality/owner/classification).

    Reads the entity-graph node by key. (The change HISTORY — who changed what,
    old→new — is `torana govern history <key>`: the policy events for that key.)

    ⭐ CLI-19 — the SUBJECT verdict is printed before the edges. Previously an
    edge-less node rendered `KEY … / EDGES [] / NODES []`, which looks like a
    populated record and is indistinguishable from a key that does not exist at
    all. The server now resolves the subject against its home inventory table
    (#67), and this prints that verdict in words.
    """
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.get("entity-graph/neighbors", params={"key": entity_key, "direction": "both"})
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    governance = _read_governance(client, entity_key)
    # json/raw callers get the envelope untouched — `subject` and `governance` are additive, so any
    # existing script reading edges/nodes is unaffected.
    if fmt != "text" or raw:
        if isinstance(data, dict):
            data = {**data, "governance": governance}
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    subject = (data or {}).get("subject")
    edges = (data or {}).get("edges") or []
    if subject is None:
        # Older server without #67 — say so rather than silently rendering the
        # ambiguous shape this row exists to kill.
        click.echo(f"KEY       {entity_key}")
        click.echo("SUBJECT   UNKNOWN  (server did not return a subject — "
                   "upgrade pantheon-integration for the #67 resolution)")
        _print_governance(governance)
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    _print_subject(entity_key, subject, len(edges))
    _print_governance(governance)
    if edges:
        click.echo("")
        output({"items": edges}, fmt=fmt, raw=raw, fields=fields)


# ─── history (the policy events for one key) ───────────────────────────────────

def history_rows(events: list, entity_key: str) -> list:
    """The `policy` events whose selector is `entity_key`, rolled-up repeats flattened, newest first."""
    flat = [e for it in events for e in [it, *(it.get("members") or [])]]
    rows = []
    for e in flat:
        d = e.get("detail") or {}
        if d.get("selector") != entity_key:
            continue
        rows.append({"when": e.get("created_at"), "key": d.get("key"),
                     "previous": d.get("previous_value"), "new": d.get("new_value"),
                     "actor": e.get("actor_id") or "", "reason": d.get("reason") or ""})
    return sorted(rows, key=lambda r: r["when"] or "", reverse=True)


#: Pages of 100 policy events read for one key before `govern history` stops and says so.
_HISTORY_MAX_PAGES = 50


@govern.command(name="history")
@click.argument("entity_key")
@click.option("--limit", default=100, type=int, help="Max history rows for this key (newest first); pages the policy events until it has them.")
@click.option("--offset", default=0, type=int, hidden=True)
@click.pass_context
def govern_history(ctx, entity_key, limit, offset):
    """Show the governance CHANGE HISTORY for a node: every policy entry edit whose
    selector is this key — who, which setting, old→new, when, and why (the `policy`
    platform events, the same history the entity-graph panel shows)."""
    from datetime import datetime, timedelta, timezone
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    since = (datetime.now(timezone.utc) - timedelta(days=365)).isoformat()
    rows, cursor, more = [], None, False
    try:
        for _ in range(_HISTORY_MAX_PAGES):
            params = {"producer": "policy", "since": since, "limit": 100}
            if cursor:
                params["cursor"] = cursor
            data = client.get("events", params=params) or {}
            rows = sorted(rows + history_rows(data.get("items") or [], entity_key), key=lambda r: r["when"] or "", reverse=True)
            cursor = data.get("next_cursor")
            if not cursor:
                break
            if len(rows) >= limit:
                more = True
                break
        else:
            more = bool(cursor)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    if len(rows) > limit:
        rows, more = rows[:limit], True
    if more:
        click.echo(f"showing the {len(rows)} most recent; older history exists (raise --limit to read more).", err=True)
    output({"items": rows}, fmt=fmt, raw=raw, fields=fields)
