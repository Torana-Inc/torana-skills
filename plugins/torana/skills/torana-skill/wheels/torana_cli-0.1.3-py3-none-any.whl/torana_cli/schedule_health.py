"""EM B-02 S4: schedule health — expected fires of scheduled jobs against the runs that started.

ONE core for the two per-service commands (SA only, cross-tenant):

  torana integrations schedule-health list   → pantheon-integration  GET /api/v1/admin/etl/schedule-health
  torana schedulers schedule-health list     → pantheon-workflow     GET /api/v1/scheduler/schedule-health

Both read rows the service leader stores every SCHEDULE_HEALTH_INTERVAL_SECONDS, so the CLI, the SA page
and the Grafana missed-fire rule agree. JSON is the API's collection shape plus its sidecars:
`{service, computed_at, stale, window_hours, summary, tenants, items, total, page, page_size}`.
"""
from __future__ import annotations

from typing import Optional

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output

ETL_PATH = "api/v1/admin/etl/schedule-health"
WORKFLOW_PATH = "api/v1/scheduler/schedule-health"

_COLS = [
    ("tenant_short", "TENANT", 8),
    ("name", "JOB", 34),
    ("schedule", "SCHEDULE", 22),
    ("expected", "EXPECTED", 8),
    ("actual", "RAN", 5),
    ("missed", "MISSED", 6),
    ("last_run_at", "LAST RUN", 20),
    ("next_fire_at", "NEXT FIRE", 20),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    return ToranaClient(base_url=get_settings(profile).base_url)


def header_lines(data: dict) -> list:
    """The words above the table: what was measured, and whether it can be trusted now."""
    s = data.get("summary") or {}
    hours = data.get("window_hours")
    lines = [f"Schedule health — {data.get('service', '?')}, last {hours:g} h, "
             f"computed {data.get('computed_at') or 'never'}" if isinstance(hours, (int, float))
             else f"Schedule health — {data.get('service', '?')}, computed {data.get('computed_at') or 'never'}"]
    if data.get("stale"):
        lines.append("⚠ STALE: the last compute is too old (or none ran), so these numbers are NOT current. "
                     "Check that the service's scheduler leader is running.")
    lines.append(f"{s.get('tenants', 0)} tenant(s), {s.get('jobs', 0)} job(s): expected {s.get('expected', 0)}, "
                 f"ran {s.get('actual', 0)}, missed {s.get('missed', 0)} "
                 f"({s.get('jobs_with_missed', 0)} job(s) with a missed fire)")
    return lines


def schedule_health_list_core(ctx, path: str, *, tenant_id: Optional[str], missed_only: bool,
                              page: int, page_size: Optional[int]) -> None:
    """Fetch one page of one service's schedule health and print it."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    params = {"page": page, "page_size": min(page_size or get_settings(profile).page_size, 100)}
    if tenant_id:
        params["tenant_id"] = tenant_id
    if missed_only:
        params["missed_only"] = "true"
    try:
        data = _client(ctx).get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt in ("text", "table") and not fields and isinstance(data, dict):
        for line in header_lines(data):
            click.echo(line)
        for item in data.get("items") or []:
            item["tenant_short"] = str(item.get("tenant_id") or "")[:8]
            if item.get("missed"):
                fires = item.get("missed_fires") or []
                item["name"] = f"{item.get('name')}  ✗ {len(fires)} missed"
    output(data, fmt=fmt, raw=raw, fields=fields, columns=_COLS)


def schedule_health_options(fn):
    """The options both commands take."""
    fn = click.option("--page-size", default=None, type=int, help="Rows per page (max 100).")(fn)
    fn = click.option("--page", default=1, show_default=True, type=int)(fn)
    fn = click.option("--missed-only", is_flag=True, default=False,
                      help="Only jobs with at least one missed fire.")(fn)
    fn = click.option("--tenant", "tenant_id", default=None, help="Only this tenant (UUID).")(fn)
    return fn
