"""torana atlas environments | environment map | correlation | learning correlations — where code runs and which
findings that makes live (pantheon-knowledge docs/learning-framework/specs/BLOCK_D_DEPLOYMENTS.md § 3.4.2, § 3.4.3).

`environments` lists the tenant's environments (the cluster's `env_label`, as the Deployments page names it);
`environment map ENV` is the deployment map (workload → image → repository @ commit, since → until);
`correlation FINDING_ID` is a finding's stored verdict per environment, with its chain; `correlation list --env ENV`
the findings with one verdict in one environment; `learning correlations [changes]` the super admin's view of the
correlator and its change list.

Nothing here computes a verdict, a state or a sentence: every verdict, reason and `{state, glyph, words}` is the
server's, printed verbatim. Glyphs carry the state beside the words, never colour alone. Lists are paged by the server
(≤ 100) and never filtered here.
"""

import click

from torana_cli.atlas import MAX_PAGE_SIZE, _call, _client, _params, human_time, since_to_iso
from torana_cli.atlas_claims import _emit, words_line

VERDICTS = ("affected", "not_affected", "not_known")


# ── shared rendering ──────────────────────────────────────────────────────────

def _dash(v) -> str:
    return "—" if v in (None, "", []) else str(v)


def _sha(v) -> str:
    """A commit as its first 12 characters (the spec's `<sha12>`); '—' when absent."""
    return str(v)[:12] if v else "—"


def _table(head: tuple, rows: list) -> list[str]:
    widths = [max(len(str(x)) for x in col) for col in zip(head, *rows)]
    fmt = "  ".join(f"{{:<{w}}}" for w in widths)
    return [fmt.format(*map(str, r)).rstrip() for r in [head, *rows]]


def _page_footer(data: dict, n: int, noun: str) -> str:
    return f"{n} of {data.get('total', n)} {noun} · page {data.get('page', 1)}"


def environment_line(e: dict) -> str:
    """`env · clusters … · namespaces … · N workloads · N repositories · N commits · last seen …`."""
    return " · ".join([
        str(e.get("env") or "?"),
        "clusters " + _dash(", ".join(e.get("clusters") or [])),
        "namespaces " + _dash(", ".join(e.get("namespaces") or [])),
        f"{_dash(e.get('workloads'))} workloads",
        f"{_dash(e.get('repositories'))} repositories",
        f"{_dash(e.get('commits'))} commits",
        last_seen_text(e),
    ] + ([verdict_counts(e["counts"])] if isinstance(e.get("counts"), dict) else []))


def last_seen_text(e: dict) -> str:
    """The server's `last_seen_words` (D29: `glyph words`, verbatim; last_seen may be null); the raw time only when an
    older server sends no words."""
    w = e.get("last_seen_words")
    if isinstance(w, dict) and w.get("words"):
        return f"{w.get('glyph') + ' ' if w.get('glyph') else ''}{w['words']}"
    return "last seen " + (human_time(e.get("last_seen")) or "—")


def verdict_counts(c: dict) -> str:
    """The server's per-verdict finding counts as `affected N, not_affected N, not_known N` (§ 3.4.2 pinned)."""
    return "findings " + ", ".join(f"{v} {_dash(c.get(v))}" for v in VERDICTS)


def render_environments(data: dict) -> str:
    envs = data.get("environments") or []
    lines = [environment_line(e) for e in envs] or ["No environments."]
    unmapped = data.get("unmapped") or []
    if unmapped:
        lines.append("Unmapped clusters (no deployment registered for them):")
        lines += [f"  {u.get('cluster', '?')} · {_dash(u.get('workloads'))} workloads" for u in unmapped]
    return "\n".join(lines)


MAP_HEAD = ("WORKLOAD", "IMAGE", "REPOSITORY", "COMMIT", "COMMIT FROM", "SINCE", "UNTIL")


def map_row(i: dict) -> tuple:
    return (_dash(i.get("workload")), _dash(i.get("image")), _dash(i.get("repository")), _sha(i.get("commit")),
            _dash(i.get("commit_src")), human_time(i.get("since")) or "—", human_time(i.get("until")) or "—")


def render_map(data: dict) -> str:
    items = data.get("items") or []
    head = f"Deployment map of {data.get('env') or '?'}"
    calls = calls_text(data["calls"]) if isinstance(data.get("calls"), dict) else []
    if not items:
        return "\n".join([f"{head}: no workloads.", *calls])
    return "\n".join([f"{head}:", *_table(MAP_HEAD, [map_row(i) for i in items]),
                      _page_footer(data, len(items), "workloads"), *calls])


def calls_text(calls: dict) -> list[str]:
    """The map's `calls` section (`atlas/calls.v1`): every line is the server's words, verbatim, then the three claims
    it stands on; unresolved setting names follow with the server's reason. Nothing is resolved or worded here."""
    res = calls.get("resolver") or {}
    out = ["", f"Calls declared in code ({res.get('name', '?')} v{res.get('version', '?')}):",
           f"  {_dash(calls.get('words'))}", f"  {_dash(calls.get('basis_words'))}"]
    for line in calls.get("lines") or []:
        out.append(f"- {_dash(line.get('words'))}")
        for c in line.get("stands_on") or []:
            out.append(f"    {_dash(c.get('type'))} {_dash(c.get('claim'))}: {_dash(c.get('words'))}")
        also = line.get("also_declared_in") or []
        if also:
            out.append(f"    also declared in: {', '.join(_dash(a.get('file')) for a in also)}")
    unresolved = calls.get("unresolved") or []
    if unresolved:
        out.append("Unresolved setting names:")
        for u in unresolved:
            out.append(f"- {_dash(u.get('setting'))} (read by {', '.join(u.get('from_names') or []) or '—'}): "
                       f"{_dash(u.get('words'))}")
    return out


def chain_text(chain: dict | None) -> str:
    """`workload → image → deployed <sha12> · finding commit <sha12> · also running …`; absent parts left out."""
    c = chain or {}
    path = " → ".join(str(c[k]) for k in ("workload", "image") if c.get(k))
    if c.get("deployed_commit"):
        path = (path + " → " if path else "") + f"deployed {_sha(c['deployed_commit'])}"
    parts = [path] if path else []
    if c.get("finding_commit"):
        parts.append(f"finding commit {_sha(c['finding_commit'])}")
    if c.get("also_running"):
        parts.append("also running " + ", ".join(_sha(s) for s in c["also_running"]))
    for key, label in (("repository", "repository"), ("package", "package"), ("pinned_version", "pins"),
                       ("pin_file", "in"), ("workloads", "workloads")):
        v = c.get(key)
        if v not in (None, "", []):
            parts.append(f"{label} {', '.join(map(str, v)) if isinstance(v, list) else v}")
    if c.get("claim_ids"):
        parts.append("claims " + ", ".join(c["claim_ids"]))
    return " · ".join(parts)


def correlation_row_line(r: dict) -> str:
    """`environment: glyph state — words · reason · chain · computed …`, the server's words verbatim."""
    out = f"{r.get('environment', '?')}: {words_line(r.get('words'))} · {r.get('reason') or '?'}"
    chain = chain_text(r.get("chain"))
    out += f" · {chain}" if chain else ""
    return out + f" · computed {human_time(r.get('computed_at')) or '—'}"


def render_correlation(data: dict) -> str:
    rows = data.get("rows") or []
    head = f"Finding {data.get('finding_id', '?')} ({data.get('finding_kind') or '?'})"
    if not rows:
        return f"{head}: no verdict stored."
    return "\n".join([head, *[f"  {correlation_row_line(r)}" for r in rows]])


def _subject_of(i: dict) -> str:
    return _dash(i.get("repository") or i.get("image"))


def render_correlation_list(data: dict) -> str:
    items = data.get("items") or []
    head = f"{data.get('verdict') or '?'} in {data.get('environment') or '?'}"
    if not items:
        return f"{head}: no findings."
    rows = [(_dash(i.get("finding_id")), _dash(i.get("finding_kind")), words_line(i.get("words")), _subject_of(i),
             human_time(i.get("computed_at")) or "—") for i in items]
    return "\n".join([f"{head}:", *_table(("FINDING", "KIND", "VERDICT", "REPOSITORY / IMAGE", "COMPUTED"), rows),
                      _page_footer(data, len(items), "findings")])


def _verdict_reason(v: dict | None) -> str:
    """`verdict/reason`; '—' for no previous verdict (a finding's first)."""
    if not isinstance(v, dict) or not v.get("verdict"):
        return "—"
    return f"{v['verdict']}/{v.get('reason') or '?'}"


def change_line(c: dict) -> str:
    """`finding · env · from → to · at` (§ 3.4.3)."""
    return (f"{c.get('finding_id', '?')} · {c.get('environment', '?')} · {_verdict_reason(c.get('from'))} → "
            f"{_verdict_reason(c.get('to'))} · {human_time(c.get('changed_at')) or '—'}")


def render_changes(data: dict) -> str:
    items = data.get("items") or []
    if not items:
        return "No verdict changes."
    return "\n".join([change_line(c) for c in items] + [_page_footer(data, len(items), "changes")])


def render_learning_correlations(data: dict) -> str:
    """The SA observability body (`atlas/learning-correlations.v1`, § 3.4.2 pinned): last run, churn, the sweep's
    words, counts by (environment, verdict, reason), then the two gap lists."""
    run = data.get("last_run")
    lines = [f"Correlator for {data.get('tenant_id', '?')}",
             "Last run: " + (f"{human_time(run.get('at')) or '?'} · {_dash(run.get('outcome'))} · {_dash(run.get('ms'))} ms"
                             if isinstance(run, dict) else "never"),
             f"Verdict changes (24 h): {_dash(data.get('churn_24h'))}"]
    sweep = data.get("sweep")
    if isinstance(sweep, dict):
        lines.append(f"Full sweep: {'due' if sweep.get('due') else 'not due'}"
                     + (f" — {sweep['words']}" if sweep.get("words") else ""))
    counts = data.get("counts") or []
    if counts:
        lines.append("Counts:")
        lines += ["  " + ln for ln in _table(("ENVIRONMENT", "VERDICT", "REASON", "N"), [
            (_dash(c.get("environment")), _dash(c.get("verdict")), _dash(c.get("reason")), _dash(c.get("n")))
            for c in counts])]
    else:
        lines.append("Counts: none")
    gaps = data.get("gaps") or {}
    unmapped = gaps.get("unmapped_clusters") or []
    lines.append("Unmapped clusters:" + ("" if unmapped else " none"))
    lines += [f"  {u.get('cluster', '?')} · {_dash(u.get('workloads'))} workloads" for u in unmapped]
    unindexed = gaps.get("unindexed_repositories") or []
    lines.append("Deployed repositories not indexed:" + ("" if unindexed else " none"))
    lines += [f"  {r.get('repository', '?')} · {r.get('environment', '?')} · {words_line(r.get('selection'))}"
              for r in unindexed]
    return "\n".join(lines)


# ── torana atlas environments ─────────────────────────────────────────────────

@click.command(name="environments")
@click.option("--tenant", default=None, help="Another tenant's environments (SA only).")
@click.pass_context
def atlas_environments(ctx, tenant):
    """The tenant's environments, one line each: clusters, namespaces, live workloads, repositories and commits, last
    seen. An environment is the cluster's env label on the Deployments page; clusters with no deployment registered
    are listed as unmapped.

    \b
    Examples:
      torana atlas environments
      torana atlas environments --tenant <TENANT_ID> --json
    """
    data = _call(_client(ctx).get, "atlas/environments", params=_params(tenant=tenant))
    _emit(ctx, data, render_environments)


@click.group(name="environment", invoke_without_command=True)
@click.pass_context
def atlas_environment(ctx):
    """One environment: its deployment map.

    \b
    Examples:
      torana atlas environment map production
      torana atlas environment map production --history
      torana atlas environment map production --calls
    """
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@atlas_environment.command(name="map")
@click.argument("env")
@click.option("--history", is_flag=True, default=False, help="Include closed intervals (what ran before).")
@click.option("--page", type=click.IntRange(1), default=1, show_default=True)
@click.option("--page-size", type=click.IntRange(1, MAX_PAGE_SIZE), default=50, show_default=True)
@click.option("--calls", is_flag=True, default=False,
              help="Add the calls declared in code between this environment's workloads (not observed traffic).")
@click.option("--tenant", default=None, help="Another tenant's map (SA only).")
@click.pass_context
def environment_map(ctx, env, history, page, page_size, calls, tenant):
    """The deployment map, one line per workload: image, repository, commit (and where the commit came from), since
    and until. The gap between intervals is time nothing was observed. `--calls` adds which workload's code names
    which other workload's service setting, each line with the three claims it stands on."""
    data = _call(_client(ctx).get, f"atlas/environments/{env}/map", params=_params(
        history="true" if history else None, page=page, page_size=page_size, calls="true" if calls else None,
        tenant=tenant))
    _emit(ctx, data, render_map)


# ── torana atlas correlation ──────────────────────────────────────────────────

class _FindingOrSubcommand(click.Group):
    """`correlation FINDING_ID` reads one finding; `correlation list …` lists. A first word that is not a subcommand
    is a finding id, routed to the hidden `show`."""

    def parse_args(self, ctx, args):
        if args and args[0] not in self.commands and not args[0].startswith("-"):
            args = ["show", *args]
        return super().parse_args(ctx, args)


@click.group(name="correlation", cls=_FindingOrSubcommand, invoke_without_command=True)
@click.pass_context
def atlas_correlation(ctx):
    """Is a finding affected in each environment? The verdict is computed before anyone asks and stored, with its
    reason and chain; this reads it. A verdict never closes a finding.

    \b
    Examples:
      torana atlas correlation <FINDING_ID>
      torana atlas correlation list --env production --verdict affected
    """
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@atlas_correlation.command(name="show", hidden=True)
@click.argument("finding_id")
@click.option("--tenant", default=None, help="Another tenant's finding (SA only).")
@click.pass_context
def correlation_show(ctx, finding_id, tenant):
    """One finding: one line per environment, `glyph state — words · reason · chain`."""
    data = _call(_client(ctx).get, "atlas/correlation", params=_params(finding=finding_id, tenant=tenant))
    _emit(ctx, data, render_correlation)


@atlas_correlation.command(name="list")
@click.option("--env", "environment", required=True, help="The environment, e.g. production.")
@click.option("--verdict", type=click.Choice(VERDICTS), default="affected", show_default=True)
@click.option("--page", type=click.IntRange(1), default=1, show_default=True)
@click.option("--page-size", type=click.IntRange(1, MAX_PAGE_SIZE), default=50, show_default=True)
@click.option("--tenant", default=None, help="Another tenant's findings (SA only).")
@click.pass_context
def correlation_list(ctx, environment, verdict, page, page_size, tenant):
    """The findings with one verdict in one environment (default: affected), paged by the server."""
    data = _call(_client(ctx).get, "atlas/correlation", params=_params(
        environment=environment, verdict=verdict, page=page, page_size=page_size, tenant=tenant))
    _emit(ctx, data, render_correlation_list)


# ── torana atlas learning correlations (super admin) ─────────────────────────

@click.group(name="correlations", invoke_without_command=True)
@click.option("--tenant", default=None, help="The tenant (required unless a subcommand is given).")
@click.pass_context
def learning_correlations(ctx, tenant):
    """The correlator (super admin): counts by environment, verdict and reason, the last run, churn, whether a sweep
    is due, and the gaps (unmapped clusters, deployed repositories not yet indexed). `changes` lists every verdict
    change.

    \b
    Examples:
      torana atlas learning correlations --tenant <TENANT_ID>
      torana atlas learning correlations changes --tenant <TENANT_ID> --since 7d
    """
    if ctx.invoked_subcommand is not None:
        return
    if not tenant:
        raise click.UsageError("--tenant is required")
    data = _call(_client(ctx).get, "atlas/learning/correlations", params=_params(tenant=tenant))
    _emit(ctx, data, render_learning_correlations)


@learning_correlations.command(name="changes")
@click.option("--tenant", required=True, help="The tenant.")
@click.option("--since", default=None, help="24h, 7d, 30m, or an ISO time.")
@click.option("--page", type=click.IntRange(1), default=1, show_default=True)
@click.option("--page-size", type=click.IntRange(1, MAX_PAGE_SIZE), default=50, show_default=True)
@click.pass_context
def correlations_changes(ctx, tenant, since, page, page_size):
    """Every verdict change, newest first, one line each: `finding · env · from → to · at`."""
    data = _call(_client(ctx).get, "atlas/learning/correlations/changes", params=_params(
        tenant=tenant, since=since_to_iso(since), page=page, page_size=page_size))
    _emit(ctx, data, render_changes)
