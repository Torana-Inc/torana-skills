"""torana atlas personas — the persona registry of the learning framework (pantheon-knowledge BLOCK_C_CONTRACTS.md § 3.4).

A persona is a versioned plugin that decides what Atlas learns for a tenant. Reads (`list`, `show`, `catalogue`) are open
to a tenant for its own workspace; every action (install, shadow, compare, promote, rollback, enable, disable, erase,
retire, proposals) is super admin. Each state verb sends the state's `--revision` (optimistic concurrency): a stale one
is refused with 409 `stale_revision` and the current revision.

The server writes every state and sentence (`{state, glyph, words}`) and validates every spec: this command prints the
words verbatim, sends a spec as given (YAML or JSON) and never pre-validates it.
"""

import json
import sys

import click

from torana_cli.atlas import MAX_PAGE_SIZE, _client, _fmt, _params, human_time, state_line
from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, handle_api_error, handle_auth_error
from torana_cli.output import output


# ── calls and errors ──────────────────────────────────────────────────────────

def validation_errors(detail) -> list:
    """The `{code, path, message}` items of a spec check: the dry-run's `errors` list, a 422's `detail.errors`
    (`persona_spec_invalid`), or one `{code, path}` object. Every failing rule, as the server listed them."""
    if isinstance(detail, list):
        return [d for d in detail if isinstance(d, dict)]
    if isinstance(detail, dict) and isinstance(detail.get("errors"), list):
        return [d for d in detail["errors"] if isinstance(d, dict)]
    if isinstance(detail, dict) and detail.get("code") and "path" in detail:
        return [detail]
    return []


def rule_line(i: dict) -> str:
    return f"✗ {i.get('code')} at {i.get('path') or '(spec)'}" + (f": {i['message']}" if i.get("message") else "")


def error_lines(e: APIError) -> list:
    """The server's error in its own words: `code at path` per validation item, else `message (code, HTTP n)` and the
    other keys (`current_revision`, `required`, `fleet_min`, …) one per line."""
    items = validation_errors(e.detail)
    if e.status_code == 422 and items:
        d = e.detail if isinstance(e.detail, dict) else {}
        head = [f"ERROR: {d['message']} ({d.get('code')}, HTTP 422)"] if d.get("message") else []
        return head + [rule_line(i) for i in items]
    d = e.detail if isinstance(e.detail, dict) else {}
    code = d.get("code") or d.get("error")
    head = d.get("message") or (str(e.detail) if e.detail else str(e))
    lines = [f"ERROR: {head}" + (f" ({code}, HTTP {e.status_code})" if code else f" (HTTP {e.status_code})")]
    lines += [f"  {k}: {v}" for k, v in d.items() if k not in ("code", "error", "message", "errors")]
    return lines


def _call(fn, *args, **kwargs):
    """One client call; an error prints the server's words (above) to stderr and exits with the contract's code."""
    try:
        return fn(*args, **kwargs)
    except AuthError as e:
        handle_auth_error(e)
    except APIError as e:
        if isinstance(e.detail, (dict, list)):
            for line in error_lines(e):
                click.echo(line, err=True)
            sys.exit(e.exit_code)
        handle_api_error(e)


def _emit(ctx, data, render):
    fmt, _, _ = _fmt(ctx)
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt)
        return
    click.echo(render(data))


# ── rendering (server words verbatim) ─────────────────────────────────────────

def _words(st: dict | None) -> str:
    """`glyph state — words` from a persona state's `state` object."""
    w = (st or {}).get("state") if isinstance((st or {}).get("state"), dict) else None
    if not w:
        return "? (no state)"
    return f"{w.get('glyph') or '?'} {w.get('state') or '?'} — {w.get('words') or ''}".rstrip(" —")


def vlabel(version, sha=None) -> str:
    """`v<n> · <sha12>`: the environment-local number beside the identity (C § 3.2.4); `v<n>` when no sha came."""
    return f"v{version}" + (f" · {str(sha)[:12]}" if sha else "")


def version_arg(selector: str):
    """A version selector as typed: digits → the number; anything else (`sha:<hex>`, `@sha:<hex>`) is passed through
    verbatim. Never checked here: the server resolves it (404 `version_unknown`, 422 `version_selector_invalid`)."""
    text = str(selector).strip()
    return int(text) if text.isdigit() else text


def state_label(st: dict | None) -> str:
    """`glyph state — words · v<promoted> · <sha12> (shadow v<s> · <sha12> <mode>) · revision N`."""
    if not st:
        return "no state"
    out = _words(st)
    pv = st.get("promoted_version")
    out += f" · {vlabel(pv, st.get('promoted_sha'))}" if pv else " · none promoted"
    if st.get("shadow_version"):
        out += (f" (shadow {vlabel(st['shadow_version'], st.get('shadow_sha'))}"
                + (f" {st['shadow_mode']}" if st.get("shadow_mode") else "") + ")")
    if st.get("revision") is not None:
        out += f" · revision {st['revision']}"
    if st.get("migrating_to") is not None and st.get("migrating_words"):
        out += f"\n  ◐ {st['migrating_words']}"
    return out


def promotion_line(r: dict) -> str:
    """One promotions-ledger row: `<at>  promote v1 → v2  by <who>`."""
    frm = f"v{r['from_version']}" if r.get("from_version") else "—"
    return (f"{human_time(r.get('at')) or '?'}  {r.get('verb', '?')} {frm} → v{r.get('to_version', '?')}"
            + (f"  by {r['by']}" if r.get("by") else ""))


def promotion_lines(st: dict | None, indent: str = "  ") -> list:
    rows = (st or {}).get("promotions") or []
    return ([f"{indent}Promotions:"] + [f"{indent}  {promotion_line(r)}" for r in rows]) if rows else []


def suspended_rule_lines(st: dict | None, indent: str = "  ") -> list:
    """#8 § 3.4.3: a state's suspended verdict rules, each `⚠ <words>` as the server wrote it."""
    rows = [r for r in (st or {}).get("suspended_rules") or [] if isinstance(r, dict)]
    return ([f"{indent}Suspended rules:"]
            + [f"{indent}  {r.get('glyph') or '⚠'} {r.get('words') or r.get('rule_key') or '?'}" for r in rows]
            if rows else [])


def persona_line(p: dict) -> str:
    """`glyph state — name v<promoted> (shadow v<s>) · summary` (§ 3.4.3); without a tenant state the name leads."""
    st = p.get("state")
    name = p.get("name", "?")
    if isinstance(st, dict):
        w = st.get("state") if isinstance(st.get("state"), dict) else {}
        head = f"{w.get('glyph') or '?'} {w.get('state') or '?'} — {name}"
        if st.get("promoted_version"):
            head += f" {vlabel(st['promoted_version'], st.get('promoted_sha'))}"
        if st.get("shadow_version"):
            head += f" (shadow {vlabel(st['shadow_version'], st.get('shadow_sha'))})"
    else:
        head = name
    return head + (f" · {p['summary']}" if p.get("summary") else "")


def render_list(data: dict) -> str:
    items = data.get("items") or []
    if not items:
        return "No personas."
    lines = []
    for p in items:
        lines.append(persona_line(p))
        if isinstance(p.get("state"), dict) and p["state"].get("state", {}).get("words"):
            lines.append(f"  {state_line('State', p['state']['state'])}")
        for st in p.get("states") or []:      # SA without --tenant: every tenant with a state row
            lines.append(f"  {st.get('tenant_id', '?')}: {state_label(st)}")
    lines.append(f"{len(items)} of {data.get('total', len(items))} personas")
    return "\n".join(lines)


def version_line(v: dict) -> str:
    when = human_time(v.get("installed_at")) if v.get("installed_at") else None
    out = (f"{vlabel(v.get('version', '?'), v.get('sha'))}  {v.get('status', '?')}  {v.get('kind', '?')}"
           f"  requires code {v.get('requires_code', '?')}")
    if when:
        out += f"  installed {when}" + (f" by {v['installed_by']}" if v.get("installed_by") else "")
    if v.get("proposed_by"):
        out += f"  proposed by {v['proposed_by']}"
    return out + (f"\n      {v['summary']}" if v.get("summary") else "")


def render_show(p: dict) -> str:
    lines = [f"{p.get('name', '?')} ({p.get('kind', '?')})" + (f" · {p['summary']}" if p.get("summary") else "")]
    if p.get("fleet_min_code") is not None:
        lines.append(f"Fleet code version: {p['fleet_min_code']} (the oldest worker)")
    if isinstance(p.get("state"), dict):
        lines.append(f"State: {state_label(p['state'])}")
        if p["state"].get("params"):
            lines.append(f"  params: {json.dumps(p['state']['params'], separators=(',', ':'))}")
        if p["state"].get("since"):
            lines.append(f"  since {human_time(p['state']['since'])}" + (f" by {p['state']['by']}" if p['state'].get('by') else ""))
        lines += promotion_lines(p["state"], indent="")
        lines += suspended_rule_lines(p["state"], indent="")
    if p.get("versions"):
        lines.append("Versions:")
        lines += [f"  {version_line(v)}" for v in p["versions"]]
    if p.get("states"):
        lines.append("Tenants:")
        for st in p["states"]:
            lines.append(f"  {st.get('tenant_id', '?')}: {state_label(st)}")
            if st.get("params"):
                lines.append(f"      params: {json.dumps(st['params'], separators=(',', ':'))}")
            lines += promotion_lines(st, indent="    ")
            lines += suspended_rule_lines(st, indent="    ")
    return "\n".join(lines)


def render_claim_types(v: dict) -> str:
    """A version's effective claim types, as installed (C-amend D3): one row per type."""
    cols = ("CLAIM TYPE", "OWNER", "IDENTITY", "OPTIONAL", "CARDINALITY", "VALUE FIELDS", "NORMALISERS")
    rows = [(t.get("name", "?"), t.get("owner", "?"), ", ".join(t.get("identity") or []) or "—",
             ", ".join(t.get("optional_identity") or []) or "—", t.get("cardinality") or "?",
             ", ".join(t.get("value_fields") or []) or "—",
             ", ".join(f"{k}={n}" for k, n in sorted((t.get("normalisers") or {}).items())) or "—")
            for t in v.get("claim_types_effective") or []]
    head = f"{v.get('name', '?')} {vlabel(v.get('version', '?'), v.get('sha'))}: claim types as installed"
    if not rows:
        return head + "\n  (none recorded)"
    widths = [max(len(str(x)) for x in col) for col in zip(cols, *rows)]
    fmt = "  ".join(f"{{:<{w}}}" for w in widths)
    return "\n".join([head] + [fmt.format(*map(str, x)).rstrip() for x in [cols, *rows]])


def render_state(st: dict) -> str:
    """A verb's answer: the persona state after it."""
    return f"{st.get('persona', '?')} for {st.get('tenant_id', '?')}: {state_label(st)}"


def _fmt_int(n) -> str:
    return f"{int(n or 0):,}"


def render_compare(r: dict) -> str:
    """Two columns per claim type (promoted vs shadow), the totals row, then the server's sentence."""
    head = (f"compare {r.get('persona', '?')} for {r.get('tenant_id', '?')}: promoted v{r.get('promoted_version', '?')}"
            f" vs shadow v{r.get('shadow_version', '?')}" + (f" ({r['shadow_mode']})" if r.get("shadow_mode") else ""))
    cols = ("CLAIM TYPE", "SAME", "MERGED", "ONLY PROMOTED", "ONLY SHADOW", "CHANGED", "REFUSED", "ROWS READ", "MS")
    rows = []
    for b in r.get("by_claim_type") or []:
        refused = ", ".join(f"{k} {v}" for k, v in (b.get("refused_by_reason") or {}).items()) or "—"
        rows.append((b.get("claim_type", "?"), _fmt_int(b.get("same")), _fmt_int(b.get("merged")),
                     _fmt_int(b.get("only_in_promoted")),
                     _fmt_int(b.get("only_in_shadow")), _fmt_int(b.get("changed")), refused,
                     _fmt_int(b.get("rows_read")), _fmt_int(b.get("ms_parse_learn"))))
    t = r.get("totals") or {}
    rows.append(("TOTAL", _fmt_int(t.get("same")), _fmt_int(t.get("merged")), _fmt_int(t.get("only_in_promoted")), _fmt_int(t.get("only_in_shadow")),
                 _fmt_int(t.get("changed")), "", _fmt_int(t.get("rows_read")), _fmt_int(t.get("ms_parse_learn"))))
    widths = [max(len(str(x)) for x in col) for col in zip(cols, *rows)]
    fmt = "  ".join(f"{{:<{w}}}" for w in widths)
    lines = [head] + [fmt.format(*map(str, x)).rstrip() for x in [cols, *rows]]
    diff = r.get("spec_diff") or {}
    if any(diff.get(k) for k in ("added", "removed", "changed")):
        lines.append("Spec changes:")
        lines += [f"  + {p}" for p in diff.get("added") or []]
        lines += [f"  - {p}" for p in diff.get("removed") or []]
        lines += [f"  ~ {c.get('path')}: {c.get('from')} → {c.get('to')}" for c in diff.get("changed") or []]
    if diff.get("conviction_changed"):
        lines.append("Conviction changes:")
        lines += [f"  ~ {c.get('message') or ''}".rstrip() for c in diff["conviction_changed"]]
    if r.get("migrations_pending"):
        lines.append("Migrations at promote:")
        lines += [f"  v{m.get('version', '?')} {m.get('claim_type', '?')}: {m.get('rule', '?')}"
                  for m in r["migrations_pending"]]
    if isinstance(r.get("one_way"), dict) and r["one_way"].get("words"):
        lines.append(f"⚠ {r['one_way']['words']}")
    would = r.get("verdicts_would_write")
    if isinstance(would, dict):                       # #8 § 3.4.3: the shadow's own verdict rows, counted nowhere yet
        lines.append(f"Would write: {_fmt_int(would.get('total'))} verdict rows (the shadow's; counted once promoted)")
        lines += [f"  {b.get('rule_key', '?')}: confirmed {_fmt_int(b.get('confirmed'))}, overturned "
                  f"{_fmt_int(b.get('overturned'))}, unknown {_fmt_int(b.get('unknown'))}"
                  for b in would.get("by_rule") or []]
    words = r.get("words") if isinstance(r.get("words"), dict) else None
    if words:
        lines.append(f"{words.get('glyph') or '?'} {words.get('state') or '?'} — {words.get('words') or ''}")
    if r.get("generated_at"):
        lines.append(f"generated {human_time(r['generated_at'])}")
    return "\n".join(lines)


def render_catalogue(c: dict) -> str:
    lines = ["Ops:"]
    for op in c.get("ops") or []:
        lines.append(f"  {op.get('id', '?')}  ({op.get('effect', '?')}, {op.get('world', '?')}, "
                     f"${float(op.get('cost_usd') or 0):.2f}) · evidence {op.get('evidence_kind', '?')} · source "
                     f"{op.get('source_class', '?')}")
        if op.get("description"):
            lines.append(f"      {op['description']}")
        if op.get("item_columns"):
            lines.append(f"      columns: {', '.join(op['item_columns'])}")
        if op.get("consent"):
            lines.append(f"      consent: {', '.join(op['consent'])}")
        if op.get("params_schema"):
            lines.append(f"      params: {json.dumps(op['params_schema'], separators=(',', ':'))}")
    for key, label in (("normalisers", "Normalisers"), ("resolvers", "Resolvers"), ("comparators", "Comparators")):
        lines.append(f"{label}: {', '.join(c.get(key) or []) or '—'}")
    rules = c.get("rekey_rules") or []
    lines.append("Re-key rules:" + ("" if rules else " —"))
    lines += [f"  {r.get('id', '?')}  params: {json.dumps(r.get('params_schema') or {}, separators=(',', ':'))}" for r in rules]
    prefixes = c.get("prefixes") or []
    if prefixes:                                      # C-amend § 3.2.6: who resolves each subject prefix
        lines.append("Prefixes:")
        rows = [("PREFIX", "RESOLVER", "OWNER")] + [(p.get("prefix", "?"), p.get("resolver", "?"), p.get("owner", "?"))
                                                    for p in prefixes]
        widths = [max(len(str(x)) for x in col) for col in zip(*rows)]
        lines += ["  " + "  ".join(f"{str(v):<{w}}" for v, w in zip(r, widths)).rstrip() for r in rows]
    uses = c.get("use_sources") or []                 # #8 § 3.4.2: what a verdict rule's `use:` may name
    if uses:
        lines.append("Use sources:")
        for u in uses:
            lines.append(f"  {u.get('id', '?')}  key: {', '.join(u.get('key') or []) or '—'}")
            if u.get("description"):
                lines.append(f"      {u['description']}")
    if "predicates" in c:
        lines.append(f"Predicates: {', '.join(c.get('predicates') or []) or '—'}")
    for name, values in (c.get("constants") or {}).items():
        lines.append(f"Constant {name}: {', '.join(map(str, values or [])) or '—'}")
    return "\n".join(lines)


def render_proposals(data: dict) -> str:
    items = data.get("items") or []
    if not items:
        return "No proposals."
    lines = []
    for v in items:
        p = v.get("proposal") or {}
        unfit = ", ".join(f"{k} {n}" for k, n in (p.get("unfit_facts") or {}).items()) or "—"
        lines.append(f"{v.get('name', '?')} {vlabel(v.get('version', '?'), v.get('sha'))} · proposed by {p.get('by') or v.get('proposed_by') or '?'}"
                     f" since {human_time(p.get('since')) or '?'} · unfit facts: {unfit}")
        if v.get("summary"):
            lines.append(f"  {v['summary']}")
    lines.append(f"{len(items)} of {data.get('total', len(items))} proposals")
    return "\n".join(lines)


def spec_yaml(spec) -> str:
    import yaml
    return yaml.safe_dump(spec, sort_keys=False, allow_unicode=True)


def read_spec(path: str):
    """A spec file as data, YAML or JSON (JSON is YAML); sent as read, never checked here."""
    import yaml
    with open(path, encoding="utf-8") as fh:
        text = fh.read()
    try:
        return yaml.safe_load(text)
    except yaml.YAMLError as e:
        raise click.UsageError(f"{path} is neither YAML nor JSON: {e}")


# ── commands ──────────────────────────────────────────────────────────────────

tenant_opt = click.option("--tenant", default=None, help="The tenant (SA: any tenant; a tenant user: its own).")
def params_opts(f):
    """`--params JSON` or `--params-file PATH` (YAML or JSON): the tenant's params, keyed by watch key or recipe id,
    sent as given (§ 3.2.14); the server validates them."""
    f = click.option("--params-file", "params_file", type=click.Path(exists=True, dir_okay=False), default=None,
                     help="The tenant's params from a YAML or JSON file.")(f)
    return click.option("--params", "params_json", default=None, metavar="JSON",
                        help="The tenant's params as JSON, keyed by watch key or recipe id (the server validates).")(f)


def read_params(params_json, params_file):
    """The params to send, or None when neither flag is given. Parsed only to build the body, never checked here."""
    if params_json and params_file:
        raise click.UsageError("give --params or --params-file, not both")
    if params_json:
        try:
            return json.loads(params_json)
        except json.JSONDecodeError as e:
            raise click.UsageError(f"--params is not JSON: {e}")
    if params_file:
        return read_spec(params_file)
    return None


revision_opt = click.option("--revision", type=int, required=True,
                            help="The state's revision you read (show/list); a stale one is refused with the current one.")


@click.group(name="personas", invoke_without_command=True)
@click.pass_context
def atlas_personas(ctx):
    """The personas that decide what Atlas learns: which watch a workspace, at which version; install, shadow,
    compare and promote a version (super admin).

    \b
    Examples:
      torana atlas personas list --tenant <TENANT_ID>
      torana atlas personas show developer --tenant <TENANT_ID>
      torana atlas personas install developer-v2.yaml --dry-run
      torana atlas personas install developer-v2.yaml --if-absent
      torana atlas personas version developer sha:ab12cd34ef56
      torana atlas personas shadow developer 2 --tenant <TENANT_ID> --revision 3
      torana atlas personas compare developer --tenant <TENANT_ID>
      torana atlas personas promote developer --tenant <TENANT_ID> --revision 4
      torana atlas personas promote developer --tenant <TENANT_ID> --revision 4 --yes --wait
      torana atlas personas promote developer --abandon --tenant <TENANT_ID> --revision 5
      torana atlas personas show developer --version 2 --claim-types
    """
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@atlas_personas.command(name="list")
@tenant_opt
@click.option("--page", type=click.IntRange(1), default=1, show_default=True)
@click.option("--page-size", type=click.IntRange(1, MAX_PAGE_SIZE), default=50, show_default=True)
@click.pass_context
def personas_list(ctx, tenant, page, page_size):
    """One line per persona: `glyph state — name v<promoted> (shadow v<s>) · summary`; without --tenant (SA), every
    tenant's state under it."""
    data = _call(_client(ctx).get, "atlas/personas", params=_params(tenant=tenant, page=page, page_size=page_size))
    _emit(ctx, data, render_list)


@atlas_personas.command(name="show")
@click.argument("name")
@tenant_opt
@click.option("--version", "version", default=None, metavar="VERSION",
              help="With --claim-types: the version (a number or sha:<12+ hex>).")
@click.option("--claim-types", "claim_types", is_flag=True, default=False,
              help="The version's claim types as installed: owner, identity, optional, cardinality, value fields, "
                   "normalisers.")
@click.pass_context
def personas_show(ctx, name, tenant, version, claim_types):
    """One persona: its versions (status, sha, required code version), the fleet's code version, and its states;
    with --tenant, the tenant's promotions and, while a promote migrates, its progress."""
    if claim_types:
        if version is None:
            raise click.UsageError("--claim-types needs --version")
        _emit(ctx, _call(_client(ctx).get, f"atlas/personas/{name}/versions/{version}"), render_claim_types)
        return
    if version is not None:
        raise click.UsageError("--version is used with --claim-types (for a version's spec: personas version)")
    _emit(ctx, _call(_client(ctx).get, f"atlas/personas/{name}", params=_params(tenant=tenant)), render_show)


@atlas_personas.command(name="version")
@click.argument("name")
@click.argument("version")
@click.pass_context
def personas_version(ctx, name, version):
    """One version's full spec, as YAML (--json for the whole row). VERSION: a number, or sha:<12+ hex> (also
    @sha:<hex>), the same spec in every environment."""
    data = _call(_client(ctx).get, f"atlas/personas/{name}/versions/{version}")
    fmt, _, _ = _fmt(ctx)
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt)
        return
    click.echo(f"# {version_line(data)}".replace("\n", "\n# "))
    click.echo(spec_yaml(data.get("spec") or {}).rstrip())


@atlas_personas.command(name="install")
@click.argument("file", type=click.Path(exists=True, dir_okay=False))
@click.option("--dry-run", is_flag=True, default=False, help="Validate only: the server lists every rule the spec breaks.")
@click.option("--if-absent", is_flag=True, default=False,
              help="Install only when no version has this spec's sha (deploy-time, idempotent): an existing one is "
                   "reported, nothing written.")
@click.pass_context
def personas_install(ctx, file, dry_run, if_absent):
    """Install a persona version from a YAML or JSON spec, sent as written (the server validates it). The server
    assigns this environment's number; the sha is the version's identity everywhere."""
    body = read_spec(file)
    data = _call(_client(ctx).post, "atlas/personas", json=body, params=_params(dry_run=dry_run, if_absent=if_absent))
    fmt, _, _ = _fmt(ctx)
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt)
        return
    if dry_run:   # always 200 `atlas/persona-validation.v1`; nothing written
        for line in warning_lines(data):
            click.echo(line)
        errs = validation_errors(data.get("errors"))
        for i in errs:
            click.echo(rule_line(i))
        if data.get("ok") and not errs:
            click.echo("✓ valid: nothing was installed (dry run)")
        elif errs:
            click.echo(f"{len(errs)} rule(s) failed; nothing was installed (dry run)")
            sys.exit(1)
        return
    if data.get("words"):     # the server's sentence: "installed as v2 (sha …)" / "already installed as …" / retired
        click.echo(f"{data.get('name', '?')}: {data['words']}")
        click.echo(f"  {version_line(data)}")
    else:
        click.echo(f"Installed {data.get('name', '?')} {vlabel(data.get('version', '?'), data.get('sha'))}: "
                   f"{version_line(data)}")
    for line in warning_lines(data):
        click.echo(line)


def warning_lines(data: dict) -> list:
    """The server's `warnings`, verbatim: `⚠ code: message` (e.g. `version_reassigned`); a `conviction_changed`
    warning is `Warning: <message>` (C-amend § 3.6, G-8)."""
    return [(f"Warning: {w.get('message') or ''}" if w.get("code") == "conviction_changed"
             else f"⚠ {w.get('code')}: {w.get('message') or ''}".rstrip(": "))
            for w in data.get("warnings") or [] if isinstance(w, dict)]


def _verb(ctx, name: str, path: str, body: dict):
    data = _call(_client(ctx).post, path, json=body)
    _emit(ctx, data, render_state)


@atlas_personas.command(name="shadow")
@click.argument("name")
@click.argument("version")
@click.option("--tenant", required=True)
@revision_opt
@params_opts
@click.pass_context
def personas_shadow(ctx, name, version, tenant, revision, params_json, params_file):
    """Run VERSION (a number, or sha:<12+ hex>) beside the promoted one for a tenant, without changing what it reads.
    --params sets the tenant's params for it."""
    body = {"tenant_id": tenant, "revision": revision}
    params = read_params(params_json, params_file)
    if params is not None:
        body["params"] = params
    _verb(ctx, name, f"atlas/personas/{name}/versions/{version}/shadow", body)


@atlas_personas.command(name="compare")
@click.argument("name")
@click.option("--tenant", required=True)
@click.pass_context
def personas_compare(ctx, name, tenant):
    """Promoted vs shadow, per claim type: same, only in each, changed, refused, rows read, time; then "Would
    write:" the shadow's own verdict rows per rule (confirmed, overturned, unknown), counted nowhere until promoted."""
    _emit(ctx, _call(_client(ctx).get, f"atlas/personas/{name}/compare", params=_params(tenant=tenant)), render_compare)


@atlas_personas.command(name="discard")
@click.argument("name")
@click.option("--tenant", required=True)
@revision_opt
@click.option("--yes", is_flag=True, default=False, help="Do not ask (for scripts).")
@click.pass_context
def personas_discard(ctx, name, tenant, revision, yes):
    """Drop the shadow version for a tenant: the promoted one stays, the shadow's results are discarded."""
    from torana_cli.confirm import confirm
    confirm(f"Discard the {name} shadow for {tenant}?", yes=yes)
    _verb(ctx, name, f"atlas/personas/{name}/shadow/discard", {"tenant_id": tenant, "revision": revision})


#: `promote --wait` polls the state this often (C-amend § 3.4.3).
WAIT_POLL_S = 5


def _one_way(client, name: str, tenant: str) -> dict | None:
    """The compare's `one_way` words, or None. A failing compare is left to the promote, which says why."""
    try:
        r = client.get(f"atlas/personas/{name}/compare", params=_params(tenant=tenant))
    except (APIError, AuthError):
        return None
    w = r.get("one_way") if isinstance(r, dict) else None
    return w if isinstance(w, dict) and w.get("words") else None


def _wait_promote(ctx, client, name: str, tenant: str) -> None:
    """Poll the tenant's state until the migration finishes (exit 0) or is stuck (exit 1), printing the server's
    progress words each time they change."""
    import time
    last = None
    while True:
        time.sleep(WAIT_POLL_S)
        st = (_call(client.get, f"atlas/personas/{name}", params=_params(tenant=tenant)) or {}).get("state") or {}
        if st.get("migrating_to") is None:
            _emit(ctx, {**st, "tenant_id": st.get("tenant_id") or tenant}, render_state)
            sys.exit(0)
        words = st.get("migrating_words")
        if words and words != last:
            click.echo(f"◐ {words}")
            last = words
        if (st.get("migrating_progress") or {}).get("stuck"):
            sys.exit(1)


@atlas_personas.command(name="promote")
@click.argument("name")
@click.option("--tenant", required=True)
@revision_opt
@click.option("--version", "expected", default=None, metavar="VERSION",
              help="The shadow you expect (a number or sha:<12+ hex>); another shadow is refused (409 shadow_mismatch).")
@click.option("--yes", is_flag=True, default=False,
              help="Confirm a one-way promote (one that re-keys claims; rollback below it is then refused).")
@click.option("--wait", is_flag=True, default=False,
              help="When the promote re-keys claims (202), wait until it finishes (exit 0) or is stuck (exit 1).")
@click.option("--abandon", is_flag=True, default=False,
              help="Abandon a promote that is re-keying, while no batch has moved claims.")
@click.pass_context
def personas_promote(ctx, name, tenant, revision, expected, yes, wait, abandon):
    """Make the shadow version the one the tenant reads. A shadow whose versions declare migrations re-keys the
    tenant's claims: the server answers 202 and finishes it in the background (--wait follows it)."""
    body = {"tenant_id": tenant, "revision": revision}
    client = _client(ctx)
    if abandon:
        if expected is not None or wait:
            raise click.UsageError("--abandon takes only --tenant and --revision")
        _verb(ctx, name, f"atlas/personas/{name}/promote/abandon", body)
        return
    if expected is not None:
        body["version"] = version_arg(expected)
    one_way = _one_way(client, name, tenant)
    if one_way:
        from torana_cli.confirm import confirm
        click.echo(f"⚠ {one_way['words']}", err=True)
        confirm(f"Promote {name} for {tenant}?", yes=yes)
    data = _call(client.post, f"atlas/personas/{name}/promote", json=body)
    _emit(ctx, data, render_state)
    if wait and isinstance(data, dict) and data.get("accepted"):
        _wait_promote(ctx, client, name, tenant)


@atlas_personas.command(name="rollback")
@click.argument("name")
@click.option("--tenant", required=True)
@click.option("--to", "to_version", required=True, metavar="VERSION",
              help="A version once promoted for this tenant: a number or sha:<12+ hex>.")
@revision_opt
@click.pass_context
def personas_rollback(ctx, name, tenant, to_version, revision):
    """Go back to a version this tenant had promoted before."""
    _verb(ctx, name, f"atlas/personas/{name}/rollback", {"tenant_id": tenant, "revision": revision, "to_version": version_arg(to_version)})


@atlas_personas.command(name="enable")
@click.argument("name")
@click.option("--tenant", required=True)
@revision_opt
@params_opts
@click.pass_context
def personas_enable(ctx, name, tenant, revision, params_json, params_file):
    """Turn the persona on for a tenant. --params sets the tenant's params."""
    body = {"tenant_id": tenant, "revision": revision}
    params = read_params(params_json, params_file)
    if params is not None:
        body["params"] = params
    _verb(ctx, name, f"atlas/personas/{name}/enable", body)


@atlas_personas.command(name="disable")
@click.argument("name")
@click.option("--tenant", required=True)
@revision_opt
@click.pass_context
def personas_disable(ctx, name, tenant, revision):
    """Turn the persona off for a tenant (what it learned stays until erased)."""
    _verb(ctx, name, f"atlas/personas/{name}/disable", {"tenant_id": tenant, "revision": revision})


@atlas_personas.command(name="erase")
@click.argument("name")
@click.option("--tenant", required=True)
@revision_opt
@click.option("--confirm", "confirm_name", required=True, metavar="NAME", help="The persona's name again.")
@click.pass_context
def personas_erase(ctx, name, tenant, revision, confirm_name):
    """Delete what a disabled persona learned for a tenant. Needs --confirm NAME."""
    _verb(ctx, name, f"atlas/personas/{name}/erase", {"tenant_id": tenant, "revision": revision, "confirm": confirm_name})


@atlas_personas.command(name="retire")
@click.argument("name")
@click.argument("version")
@click.pass_context
def personas_retire(ctx, name, version):
    """Retire a version platform-wide (no tenant can shadow or promote it again). VERSION: a number or sha:<12+ hex>."""
    data = _call(_client(ctx).post, f"atlas/personas/{name}/versions/{version}/retire", json={})
    _emit(ctx, data, lambda v: f"Retired {v.get('name', name)} {vlabel(v.get('version', version), v.get('sha'))}: "
                               f"{version_line(v)}"
          if v.get("version") is not None else render_state(v))


@atlas_personas.command(name="proposals")
@click.option("--page", type=click.IntRange(1), default=1, show_default=True)
@click.option("--page-size", type=click.IntRange(1, MAX_PAGE_SIZE), default=50, show_default=True)
@click.pass_context
def personas_proposals(ctx, page, page_size):
    """Versions a persona proposed (status proposed), with the facts it could not fit."""
    _emit(ctx, _call(_client(ctx).get, "atlas/personas/proposals", params=_params(page=page, page_size=page_size)),
          render_proposals)


@atlas_personas.command(name="catalogue")
@tenant_opt
@click.pass_context
def personas_catalogue(ctx, tenant):
    """What a spec may name: ops (with their params schema), normalisers, resolvers, comparators, re-key rules, and
    what a verdict rule may name: use sources (with their key), predicates, constants."""
    _emit(ctx, _call(_client(ctx).get, "atlas/personas/catalogue", params=_params(tenant=tenant)), render_catalogue)
