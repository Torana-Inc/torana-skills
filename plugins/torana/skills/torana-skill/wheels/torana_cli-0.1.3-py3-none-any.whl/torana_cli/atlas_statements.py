"""torana atlas statements | persons, and `atlas claims curate|curations`: a person's own statements and curations
(pantheon-knowledge docs/learning-framework/specs/BLOCK_6A_STATEMENTS.md § 3.4).

A tenant user (`atlas:state`) states a fact, unanchored or anchored on a line of a repository the tenant consents to
read; confirms or corrects a claim (`atlas:curate`; Confirm is code-only); retires their own statement (a tenant admin
may retire anyone's); and can erase everything they ever stated or curated (`atlas persons forget-me`). A super admin
may read (`--tenant`) but every write answers 403 `tenant_owned` with the server's words.

The server writes every word: the outcome sentence (`words`, glyph and tier included), each row's `glyph`, `state` and
`state_words`, who said it (`by`: a label or "a former user") and every refusal. These commands print them verbatim and
derive none: a state is the server's glyph beside its word (never colour alone, § 3.5).
"""

import json
import sys

import click

from torana_cli.atlas import MAX_PAGE_SIZE, _client, _fmt, _params, human_time
from torana_cli.atlas_claims import consent_banner, consent_error_words
from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, echo_reference, handle_api_error, handle_auth_error
from torana_cli.output import output

#: the extra fields a 6a refusal carries (§ 3.6), printed under the server's sentence
REFUSAL_EXTRAS = ("type", "statable", "root_kind", "reason", "limit", "used",
                  "field", "required", "optional", "candidates")       # 6d.1: a Decision refusal names its way out


def state_of(r: dict) -> str:
    """`glyph state` as the server sent them (no glyph → the word alone; nothing is looked up here)."""
    return f"{r.get('glyph') or ''} {r.get('state') or '?'}".strip()


def statement_line(r: dict) -> str:
    """One statement: `glyph state · claim_type · subject · anchored · by X (you) · "their words"   [id]`."""
    who = r.get("by") or "?"
    if r.get("mine"):
        who += " (you)"
    out = f"{state_of(r)} · {r.get('claim_type') or '?'} · {r.get('subject') or '?'}"
    out += " · anchored" if r.get("anchored") else ""
    out += f" · by {who}"
    if r.get("words"):
        out += f' · "{r["words"]}"'
    out += f"   [{r.get('id')}]"
    return out


def statement_detail(r: dict) -> list[str]:
    """`statements get` and the row under a write's outcome: the line, then claim, sighting, supersedes, retired."""
    lines = [statement_line(r)]
    if r.get("state_words"):
        lines.append(f"  {r['state_words']}")
    lines += [f"  claim {r.get('claim_id') or '—'} · sighting {r.get('sighting_id') or '— (none)'}"
             f" · stated {human_time(r.get('created_at')) or '?'}" + (f" · tier {r['tier']}" if r.get("tier") else "")]
    if r.get("supersedes"):
        lines.append(f"  supersedes {r['supersedes']}")
    if r.get("retired_at"):
        lines.append(f"  ended {human_time(r['retired_at'])}" + (f": {r['retired_reason']}" if r.get("retired_reason")
                                                                  else ""))
    return lines


def curation_line(r: dict) -> str:
    """One curation: `glyph state · verdict · by X (you) · "their words" · at   [id]`."""
    who = (r.get("by") or "?") + (" (you)" if r.get("mine") else "")
    out = f"{state_of(r)} · {r.get('verdict') or '?'} · by {who}"
    if r.get("words"):
        out += f' · "{r["words"]}"'
    out += f" · {human_time(r.get('at')) or '?'}   [{r.get('id')}]"
    return out


def render_write(data: dict) -> str:
    """A write's answer: `result: server words` (the server's words carry the glyph and tier), then the row."""
    head = f"{data.get('result') or '?'}: {data.get('words') or ''}".rstrip(": ")
    row = data.get("statement") or data.get("curation")
    lines = [head]
    if isinstance(row, dict):
        lines += statement_detail(row) if "statement" in data else ["  " + curation_line(row)]
    return "\n".join(lines)


def render_statements_page(data: dict) -> str:
    items = data.get("items") or []
    if not items:
        return "No statements."
    lines = [statement_line(r) for r in items]
    lines.append(f"{len(items)} of {data.get('total', len(items))} statements · page {data.get('page', 1)}")
    return "\n".join(lines)


def render_curations_page(data: dict) -> str:
    items = data.get("items") or []
    if not items:
        return "No curations."
    lines = [curation_line(r) for r in items]
    lines.append(f"{len(items)} of {data.get('total', len(items))} curations · page {data.get('page', 1)}")
    return "\n".join(lines)


def render_forget(data: dict) -> str:
    counts = data.get("counts") or {}
    lines = [data.get("words") or "forgotten"]
    lines += [f"  {k}: {v}" for k, v in counts.items()]
    return "\n".join(lines)


def _refusal(e: APIError, extras: tuple = REFUSAL_EXTRAS) -> None:
    """Print a 6a refusal: the server's sentence first with its code, then the fields that name the way out (the
    statable types, the root kind, the budget). A 503 `consent_unavailable` prints its consent words. Exits."""
    words = consent_error_words(e)
    if words is not None:
        click.echo(f"⚠ {words}", err=True)          # nothing was read or written (fail closed); retryable
        echo_reference(e)
        sys.exit(e.exit_code)
    d = e.detail if isinstance(e.detail, dict) else {}
    if not d.get("message") or not d.get("error"):
        handle_api_error(e)                         # FastAPI 422 body shape and anything else: the generic printer
    click.echo(f"\nERROR: {d['message']} ({d['error']}, HTTP {e.status_code})", err=True)
    inner = d.get("detail") if isinstance(d.get("detail"), dict) else {}
    for k in extras:
        v = d.get(k, inner.get(k))
        if v not in (None, "", []):
            click.echo(f"  {k}: {', '.join(map(str, v)) if isinstance(v, list) else v}", err=True)
    if d.get("retryable") or inner.get("retryable"):
        click.echo("  This can be retried.", err=True)
    echo_reference(e)
    sys.exit(e.exit_code)


def _send(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except AuthError as e:
        handle_auth_error(e)
    except APIError as e:
        _refusal(e)


def _emit(ctx, data, render):
    fmt, _, _ = _fmt(ctx)
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt)
        return
    banner = consent_banner(data)
    if banner:
        click.echo(banner)
    click.echo(render(data))


def _json_object(text: str | None, flag: str) -> dict:
    """`--value-json`: one JSON object (its values keep their JSON types); anything else is a UsageError."""
    if not text:
        return {}
    try:
        v = json.loads(text)
    except ValueError as e:
        raise click.UsageError(f"{flag} is not valid JSON: {e}")
    if not isinstance(v, dict):
        raise click.UsageError(f"{flag} takes one JSON object, got {type(v).__name__}")
    return v


def _pairs(values, flag: str) -> dict:
    """`k=v` options as a dict (values stay strings; the server validates them against the claim type)."""
    out = {}
    for v in values or ():
        k, sep, val = v.partition("=")
        if not sep or not k.strip():
            raise click.UsageError(f"{flag} takes key=value, got {v!r}")
        out[k.strip()] = val
    return out


def parse_anchor(anchor: str) -> dict:
    """`repo:<host>/<org>/<repo>:<file>:<line>` → the API's file_line anchor (repository, file, line)."""
    if not anchor.startswith("repo:"):
        raise click.UsageError("--anchor must look like repo:github.com/acme/api:src/app.py:12")
    rest = anchor[len("repo:"):]
    repo, sep, tail = rest.partition(":")
    file, sep2, line = tail.rpartition(":")
    if not (sep and sep2 and repo and file and line.isdigit() and int(line) >= 1):
        raise click.UsageError("--anchor must look like repo:github.com/acme/api:src/app.py:12 (line ≥ 1)")
    return {"kind": "file_line", "repository": f"repo:{repo}", "file": file, "line": int(line)}


def _idem(key):
    return {"Idempotency-Key": key} if key else None


# ── torana atlas statements ───────────────────────────────────────────────────

@click.group(name="statements", invoke_without_command=True)
@click.pass_context
def atlas_statements(ctx):
    """A person's own statements about the estate: stored even when they disagree with what code says, shown beside
    it, never changing a verdict. Needs atlas:state (tenant users and admins; a super admin may only read).

    \b
    Examples:
      torana atlas statements add --subject repo:github.com/acme/api --type code.owner_rule \\
        --identity path=src/billing --value owner=team-payments --words "Payments owns billing since October"
      torana atlas statements add --subject repo:github.com/acme/api --type code.build_step \\
        --identity step=test --anchor repo:github.com/acme/api:.github/workflows/ci.yml:41 --words "CI runs pytest here"
      torana atlas statements list --mine
      torana atlas statements retire 1b2c… --reason "the team moved"
    """
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@atlas_statements.command(name="add")
@click.option("--subject", required=True, metavar="KEY", help="What it is about, e.g. repo:github.com/acme/api.")
@click.option("--type", "claim_type", required=True, metavar="CLAIM_TYPE",
              help="A statable claim type; a refusal lists the statable ones.")
@click.option("--identity", multiple=True, metavar="K=V", help="An identity field of the claim (repeatable).")
@click.option("--value", multiple=True, metavar="K=V", help="A value field of the claim (repeatable).")
@click.option("--value-json", "value_json", default=None, metavar="JSON",
              help="The value as one JSON object, merged over --value (for nested or typed values, e.g. a "
                   "decision.rule's checkable_as).")
@click.option("--words", required=True, help="Your statement in your own words (1-2000 characters).")
@click.option("--anchor", default=None, metavar="repo:HOST/ORG/REPO:FILE:LINE",
              help="Cite a line of a repository (its contents must be consented to be read).")
@click.option("--anchor-version", default=None, metavar="SHA",
              help="The commit the line is read at (7-64 hex); default: the repository's current snapshot.")
@click.option("--quote", default=None, help="The cited line's text; default: read by the server at that commit.")
@click.option("--valid-from", default=None, metavar="ISO", help="Since when it holds (sent as given).")
@click.option("--idempotency-key", default=None, metavar="KEY",
              help="Send the same key to retry safely: the same body answers the same statement.")
@click.pass_context
def statements_add(ctx, subject, claim_type, identity, value, value_json, words, anchor, anchor_version, quote,
                   valid_from, idempotency_key):
    """State a fact. Prints the server's outcome (`stored` or `unchanged`) and the statement.

    \b
    A Decision (a checkable rule; needs the tenant's decision authority, by default a tenant admin):
      torana atlas statements add --type decision.rule --subject repo:github.com/acme/api \\
        --identity rule_key=min-node --words "We run Node 20 or later" \\
        --value-json '{"rule": "Node 20+", "rationale": "LTS", "checkable_as": {"claim_type": "code.runtime",
          "subject": "$subject", "identity": {}, "when": [{"column": "version", "op": "ge", "value": "20",
          "normaliser": "ordinal_semver"}]}}'
    """
    if (anchor_version or quote) and not anchor:
        raise click.UsageError("--anchor-version and --quote need --anchor")
    body = {"subject": subject, "claim_type": claim_type, "identity": _pairs(identity, "--identity"),
            "value": {**_pairs(value, "--value"), **_json_object(value_json, "--value-json")}, "words": words}
    if valid_from:
        body["valid_from"] = valid_from
    if anchor:
        a = parse_anchor(anchor)
        if anchor_version:
            a["version"] = anchor_version
        if quote:
            a["quote"] = quote
        body["anchor"] = a
    data = _send(_client(ctx).post, "atlas/statements", json=body, extra_headers=_idem(idempotency_key))
    _emit(ctx, data, render_write)


@atlas_statements.command(name="list")
@click.option("--mine", is_flag=True, default=False, help="Only your own statements.")
@click.option("--claim", "claim_id", default=None, metavar="CLAIM_ID", help="Only statements on this claim.")
@click.option("--page", type=click.IntRange(1), default=1, show_default=True)
@click.option("--page-size", type=click.IntRange(1, MAX_PAGE_SIZE), default=50, show_default=True)
@click.option("--tenant", default=None, help="Another tenant's statements (SA only, read-only).")
@click.pass_context
def statements_list(ctx, mine, claim_id, page, page_size, tenant):
    """List statements, newest first: `glyph state · claim_type · subject · by · "words"   [id]`.

    \b
    Example:
      torana atlas statements list --claim 6611…
    """
    data = _send(_client(ctx).get, "atlas/statements", params=_params(
        mine="true" if mine else None, claim_id=claim_id, page=page, page_size=page_size, tenant=tenant))
    _emit(ctx, data, render_statements_page)


@atlas_statements.command(name="get")
@click.argument("statement_id")
@click.option("--tenant", default=None, help="Another tenant's statement (SA only, read-only).")
@click.pass_context
def statements_get(ctx, statement_id, tenant):
    """One statement: its line, claim, sighting, what it supersedes and when it ended.

    \b
    Example:
      torana atlas statements get 1b2c…
    """
    data = _send(_client(ctx).get, f"atlas/statements/{statement_id}", params=_params(tenant=tenant))
    _emit(ctx, data, lambda d: "\n".join(statement_detail(d.get("statement") or {})))


@atlas_statements.command(name="retire")
@click.argument("statement_id")
@click.option("--reason", required=True, help="Why it no longer holds (1-500 characters).")
@click.pass_context
def statements_retire(ctx, statement_id, reason):
    """End a statement: yours, or anyone's if you are a tenant admin. It stays visible as retired.

    \b
    Example:
      torana atlas statements retire 1b2c… --reason "the team moved"
    """
    data = _send(_client(ctx).post, f"atlas/statements/{statement_id}/retire", json={"reason": reason})
    _emit(ctx, data, render_write)


# ── torana atlas claims curate | curations (registered on the claims group) ───

@click.command(name="curate")
@click.argument("claim_id")
@click.option("--verdict", required=True, type=click.Choice(["confirm", "correct", "misread", "stale"]),
              help="confirm (code claims only), correct (shown beside the claim, changes nothing), or settle a "
                   "Question: misread (this reading is wrong) / stale (it was true once).")
@click.option("--value", multiple=True, metavar="K=V", help="With correct: the value you say is right (repeatable).")
@click.option("--words", required=True, help="Why, in your own words.")
@click.option("--idempotency-key", default=None, metavar="KEY", help="Send the same key to retry safely.")
@click.pass_context
def claims_curate(ctx, claim_id, verdict, value, words, idempotency_key):
    """Confirm or correct a claim, or settle its Question (needs atlas:curate). A Confirm sits on the code it confirms
    and goes stale with it; misread / stale settle a Question (`torana atlas questions list`) and are never a side.

    \b
    Examples:
      torana atlas claims curate 6611… --verdict confirm --words "Checked: CI runs this step"
      torana atlas claims curate 6611… --verdict correct --value owner=team-core --words "Core owns it now"
      torana atlas claims curate 6611… --verdict misread --words "The parser read the wrong file"
    """
    if value and verdict != "correct":
        raise click.UsageError("--value goes with --verdict correct only")
    body = {"verdict": verdict, "words": words}
    if value:
        body["value"] = _pairs(value, "--value")
    data = _send(_client(ctx).post, f"atlas/claims/{claim_id}/curate", json=body, extra_headers=_idem(idempotency_key))
    _emit(ctx, data, render_write)


@click.command(name="curations")
@click.argument("claim_id")
@click.option("--page", type=click.IntRange(1), default=1, show_default=True)
@click.option("--page-size", type=click.IntRange(1, MAX_PAGE_SIZE), default=50, show_default=True)
@click.option("--tenant", default=None, help="Another tenant's claim (SA only, read-only).")
@click.pass_context
def claims_curations(ctx, claim_id, page, page_size, tenant):
    """Every confirm and correct on a claim, newest first.

    \b
    Example:
      torana atlas claims curations 6611…
    """
    data = _send(_client(ctx).get, f"atlas/claims/{claim_id}/curations", params=_params(
        page=page, page_size=page_size, tenant=tenant))
    _emit(ctx, data, render_curations_page)


# ── torana atlas persons ──────────────────────────────────────────────────────

@click.group(name="persons", invoke_without_command=True)
@click.pass_context
def atlas_persons(ctx):
    """You as a person who states and curates.

    \b
    Example:
      torana atlas persons forget-me --confirm
    """
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@atlas_persons.command(name="forget-me")
@click.option("--confirm", is_flag=True, default=False, help="Required: erasing cannot be undone.")
@click.pass_context
def persons_forget_me(ctx, confirm):
    """Erase everything you stated or curated, in one step. Later reads say "a former user said …". Cannot be undone.

    \b
    Example:
      torana atlas persons forget-me --confirm
    """
    if not confirm:
        raise click.UsageError("forget-me erases everything you stated or curated and cannot be undone: pass --confirm")
    data = _send(_client(ctx).delete, "atlas/persons/me")
    _emit(ctx, data or {}, render_forget)
