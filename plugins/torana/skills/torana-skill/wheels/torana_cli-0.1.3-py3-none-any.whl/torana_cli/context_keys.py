"""The click context keys the root command sets (main.py) and every command group reads. Their own module, so a command
module can import them without importing main.py, which registers every command (an import cycle for
`import torana_cli.atlas` on its own)."""

CTX_FORMAT = "format"
CTX_RAW = "raw"
CTX_FIELDS = "fields"
CTX_PROFILE = "profile"
#: 6b follow-up #5: True when `--json` / `--format json` was on the command line (never from the config default);
#: `confirm` then refuses a prompt unless `--yes` was given.
CTX_JSON_REQUESTED = "json_requested"
