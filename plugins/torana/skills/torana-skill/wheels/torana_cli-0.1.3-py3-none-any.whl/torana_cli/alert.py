"""torana alert <ALERT_ID> — instance-scoped alert commands."""

import re
import sys

import click

from torana_cli import served_words as sw
from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.severity_words import severity_word as _severity_word
from torana_cli.team_words import team_words
from torana_cli.time_util import day_words, local_day
from torana_cli.section_descriptions import all_reasons_option, with_sections_help
from torana_cli.confirm import confirm as _confirm
from torana_cli.fix_plan_words import fix_plan_line


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    tenant = ctx.obj.get(_READ_TENANT) if ctx.obj else None
    if tenant:
        return _TenantReadClient(tenant, base_url=settings.base_url)
    return ToranaClient(base_url=settings.base_url)


_READ_TENANT = "_read_tenant"


class _TenantReadClient(ToranaClient):
    """I-62: a super admin reading ANOTHER tenant's item. Every GET carries `tenant_id`, which the server
    honours only for a cross-tenant caller and records in the security audit log, like `alerts list --tenant`.

    ⛔ Reads only. Anything else refuses here, so `--tenant` can never turn into a cross-tenant write."""

    def __init__(self, tenant_id, **kw):
        super().__init__(**kw)
        self._tenant_id = tenant_id

    def get(self, path, params=None, *args, **kwargs):
        return super().get(path, {**(params or {}), "tenant_id": self._tenant_id}, *args, **kwargs)

    def _refuse(self, *_a, **_k):
        raise click.UsageError("--tenant is for reading another tenant's item; this command does not write with it.")

    post = put = patch = delete = _refuse


def _store_read_tenant(ctx, _param, value):
    if value:
        ctx.ensure_object(dict)[_READ_TENANT] = value
    return value


def _tenant_read_option(f):
    """`--tenant` on the commands that READ one item (get, view, members, activities, cve-intel, triage-context, proof,
    assessment)."""
    return click.option(
        "--tenant", "tenant_id", default=None, metavar="TENANT_ID", expose_value=False,
        callback=_store_read_tenant,
        help="Super admin only: read this item in THIS tenant (your own tenant is used otherwise). Recorded in the "
             "security audit log (`torana audit-logs`), like `alerts list --tenant`.")(f)


def _aid(ctx) -> str:
    return ctx.obj.get("_alert_id", "") if ctx.obj else ""


@click.group(name="alert", invoke_without_command=True)
@click.argument("alert_id", metavar="ALERT_ID")
@click.pass_context
def alert(ctx, alert_id):
    """One item of the Inbox, by ID: read it, decide it, assign it.

    \b
    Start here:
      Read the item as the Inbox shows it   torana alert <UUID> view
      One section only                      torana alert <UUID> view --section verdict
      The findings an entry's fix clears    torana alert <UUID> members
      The evidence behind it                torana alert <UUID> proof
      Every place a package fix must change torana alert <UUID> fix-scope
      Set a verdict, close, reopen, assign  verdict, close, reopen, assign (below)

    \b
    Examples:
      torana alert <UUID> view
      torana alert <UUID> view --section why-here --section history
      torana alert <UUID> get
      torana alert <UUID> close --reason wont_fix
      torana alert <UUID> reopen --message "still reported"
      torana alert <UUID> keep-closed
      torana alert <UUID> assign --assigned-to <user-id>
      torana alert <UUID> verdict --triage-verdict true_positive
      torana alert <UUID> delete --yes
    """
    ctx.ensure_object(dict)
    ctx.obj["_alert_id"] = alert_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def code_read_detail(extra):
    """What a `code_read` activity's `extra_data` adds to its line: what was asked, how much came back and at which commit,
    e.g. "lines 148, 370 · 2 locations, 1,800 chars · at 7acd0a2". Never code: the record holds none. Empty for any other
    shape."""
    if not isinstance(extra, dict) or extra.get("tool") != "read_code":
        return ""
    req = extra.get("request") or {}
    kind = str(req.get("kind") or "")
    arg = {"lines": ", ".join(str(x) for x in req.get("lines") or []), "function": req.get("function"),
           "callers_of": req.get("callers_of"), "range": req.get("range")}.get(kind)
    asked = " ".join(x for x in [kind.replace("_", " "), str(arg) if arg else ""] if x)
    sizes = extra.get("sizes") or {}
    got = (f"{sizes.get('locations', 0)} location{'' if sizes.get('locations') == 1 else 's'}, "
           f"{int(sizes.get('chars') or 0):,} chars") if sizes else ""
    commit = f"at {str(extra['commit'])[:7]}" if extra.get("commit") else "on the default branch (not pinned)"
    status = str(extra.get("status") or "")
    return " · ".join(x for x in [asked, got if status == "ok" else status.replace("_", " "), commit] if x)


def _activity_actor(row) -> str:
    """`actor_type` plus a short id — who did this, in one column."""
    kind = (row.get("actor_type") or "").lower()
    who = row.get("actor_id") or row.get("user_id") or ""
    extra = (row.get("extra_data") or {}) if isinstance(row.get("extra_data"), dict) else {}
    if kind == "system" and extra.get("rule_id"):
        return "the ranking"
    if not kind:
        return ""
    return f"{kind}:{str(who)[:8]}" if who else kind


#: What a person needs to see about a member: is it done, and what was decided.
_MEMBER_COLS = [
    ("id", "ID", 36),
    # Review pending, or who decided it (the platform's badge words), and the finding's short name.
    ("path_badge_label", "BADGE", 15),
    ("path_label", "FINDING", 48),
    ("name", "NAME", 40),
    ("finding_severity_label", "FINDING SEVERITY", 16),
    ("triage_priority", "PRIO", 6),
    ("state", "STATE", 7),
    ("box", "BOX", 15),
    ("status", "STATUS", 20),
    ("triage_verdict", "VERDICT", 15),
    ("reason_code", "REASON", 24),
    # The entity-graph node the member is about, only when the graph has it (API `graph_nodes=true`); '—' otherwise.
    ("graph_node_key", "GRAPH NODE", 48),
]


def band_text(band, fmt, alert_id=None) -> str:
    """The status band as one line: the platform's template with its dates in the reader's zone, a marker for the tone and,
    when a person must act, the command that re-runs triage. Never colour alone: the words say the state."""
    text = str(band.get("template") or "")
    for i, d in enumerate(band.get("dates") or []):
        text = text.replace("{%d}" % i, fmt(d) if d else "")
    mark = "!" if band.get("tone") == "warning" else "i"
    line = f"[{mark}] {text}"
    if band.get("rerun"):
        line += f"  (re-run: torana alert {alert_id or '<id>'} triage)"
    return line


def clears_phrase(data) -> str:
    """" — clears N finding(s)" for a root, with how many are at or above the tenant's severity floor when that differs
    ("clears 36 (35 at or above your severity floor)"). One number when the two are equal, or when the platform does not say
    (`findings_cleared_above_floor` is null when not known; it is never guessed). Empty when nothing is declared."""
    cleared = (data or {}).get("findings_cleared")
    if cleared is None:
        return ""
    floor = (data or {}).get("findings_cleared_above_floor")
    unknown = (data or {}).get("findings_floor_unknown")
    if isinstance(floor, int) and not isinstance(floor, bool) and floor != cleared:
        return f" — clears {cleared} finding(s) ({floor} at or above your severity floor)"
    if isinstance(unknown, int) and not isinstance(unknown, bool) and unknown > 0:
        return f" — clears {cleared} finding(s) ({unknown} not classified against your severity floor)"
    return f" — clears {cleared} finding(s)"


def facts_changed_rows(data) -> list:
    """The rows saying a fact this item stands on has changed. The text is the platform's own sentence for each change;
    nothing is composed here.

    ⛔ TWO DIFFERENT THINGS WEAR THIS MARKER, and saying the wrong one is a false statement to a customer. A FINDING is
    waiting to go back to the agent. An UPGRADE or MITIGATION row has no verdict of its own and is never sent to an
    agent: it was already re-worked in place, so "since the verdict" names a verdict it does not have and "is
    re-triaged automatically" promises something that cannot happen for it. The platform says which in
    `facts_changed_kind`; never infer it here.
    """
    if not (data or {}).get("facts_changed_at"):
        return []
    changes = data.get("facts_changed") or []
    since = str(data["facts_changed_at"])[:19].replace("T", " ")
    texts = "; ".join([c.get("text") for c in changes if c.get("text")]) or "not recorded"
    if (data.get("facts_changed_kind") or "") == "entry_reevaluated":
        return [("", f"⚠ what this covers changed ({since} UTC): {texts}"),
                ("", "  It was re-worked with the new facts; see `torana alert <id> activities`.")]
    return [("", f"⚠ facts changed since the verdict ({since} UTC): {texts}"),
            ("", "  The item is re-triaged automatically when the change has held; see `torana alert <id> activities`.")]


def dedupe_adjacent(bits: list) -> list:
    """`bits` without a word that repeats the one before it (case aside): the box and the status are both "closed" on a closed
    item and the header read "closed · closed". The words are the platform's, stored as they are; only the print drops the repeat."""
    out: list = []
    for b in bits:
        if out and str(out[-1]).strip().lower() == str(b).strip().lower():
            continue
        out.append(b)
    return out


def lifecycle_evidence_rows(ev) -> list:
    """The rows for the lifecycle's last decision on an item. The evidence is the LAST decision, which may be a reopen: calling
    that "closed because" on an open item reads as a contradiction, so the label follows what the lifecycle did."""
    if not ev:
        return []
    rows = []
    label = "REOPENED BECAUSE" if str(ev.get("outcome") or "").lower() == "reopen" else "CLOSED BECAUSE"
    reason = ev.get("resolution_reason") or ""
    sentence = ev.get("reason_sentence") or ev.get("reason_label") or ev.get("why") or ""
    seen = (ev.get("observed_at") or "")[:19].replace("T", " ")
    line = reason + (f" — {sentence}" if sentence else "")
    if seen:
        line += f"  (read at {seen})"
    rows.append((label, line or "(no reason recorded)"))
    rels = ev.get("relations") or []
    if rels:
        rows.append(("READ FROM", "; ".join(
            f"{r.get('table')} built {(r.get('built_at') or '')[:19].replace('T', ' ')}"
            for r in rels[:4])))
    return rows


def code_links_rows(links):
    """The rows for a code finding's links to GitHub (the platform's `code_links`): "<path> L148, L370 at 7acd0a2", or
    "... on the default branch (not pinned to the scanned commit)" when no commit is known, then the file's URL. No code
    is printed: the links are where to read it. Empty for a finding with none."""
    if not links:
        return []
    from urllib.parse import unquote
    url = str(links.get("file_url") or "")
    path = unquote(url.split("/blob/", 1)[1].split("/", 1)[1]) if "/blob/" in url and "/" in url.split("/blob/", 1)[1] else ""
    lines = ", ".join(f"L{loc.get('line')}" for loc in links.get("locations") or [] if loc.get("line"))
    where = (f"at {str(links.get('commit'))[:7]}" if links.get("pinned") and links.get("commit")
             else "on the default branch (not pinned to the scanned commit)")
    first = " ".join(x for x in [path or "file", lines, where] if x)
    return [("CODE IN GITHUB", first), ("", url)] if url else [("CODE IN GITHUB", first)]


def _with_severity_labels(rows, text_view):
    """Member rows for a table: the finding's severity in words ("Not recorded" when the finding stated none), never the rule's constant.
    JSON stays exactly what the platform sent."""
    if text_view and isinstance(rows, list):
        for m in rows:
            if isinstance(m, dict) and not m.get("finding_severity_label"):
                m["finding_severity_label"] = _severity_word(m.get("finding_severity")) or "Not recorded"
    return rows


def _level_bits(head) -> list:
    """The headline's level word: the app's level (`level_label`: its deadline class) when the platform sends one, with the scanner's word kept as a
    labelled detail ("scanner: Critical") when it differs; else the scanner's word, as before."""
    scanner = head.get("finding_severity_label") or _header_severity(head)
    level = str(head.get("level_label") or "").strip()
    if not level:
        return [scanner]
    return [level] + ([f"scanner: {scanner}"] if scanner and scanner.lower() != level.lower() else [])


def _header_severity(head) -> str:
    """The severity the item view's header shows, worded as the screen words it ("Critical", "Not recorded").

    The platform states the item's severity as `severity_shown`; when it sends that key and it is empty, the item has no
    severity of its own and the header says so. It must NOT fall back to `severity`, which is the declaring rule's one
    constant for every item the rule raises (it read "medium" on an item whose finding has none)."""
    if "severity_shown" in head:
        shown = str(head.get("severity_shown") or "").strip()
        return (shown[:1].upper() + shown[1:]) if shown else "Not recorded"
    shown = str(head.get("finding_severity") or head.get("severity") or "").strip()
    return (shown[:1].upper() + shown[1:]) if shown else "Not recorded"


def _print_alert_head(data, fix_decider=None) -> None:
    """The six things a person opens an alert to find, before the raw keys.

    `fix_decider`: the name of the person who approved the fix plan, when `fix_plan.decided_by` is not `system`."""
    verdict = data.get("triage_verdict") or "(not yet judged)"
    code = data.get("reason_code")
    # Who decided is the platform's sentence (`verdict_source_detail`, T1-15), else its short word; the CLI words nothing itself.
    decided_by = data.get("verdict_source_detail") or data.get("verdict_source_label") or ""
    verdict_line = verdict + (f"  [{code}]" if code else "") + (f"  — by {decided_by}" if decided_by else "")

    fix = data.get("proposed_fix") or data.get("remediation_summary") or ""
    # Whether a fix is OFFERED is the platform's answer (`proposed_fix_offered`, DS4e § 3.2.4), the one the screen reads. The CLI derives
    # nothing from the verdict; a server that does not send the flag (older) shows the stored fix as it is.
    if data.get("proposed_fix_offered") is False:
        fix = ""
    fix_src = sw.fix_source_word(data)
    if fix and fix_src:
        fix = f"{fix}  ({fix_src})"

    _box = sw.box_word(data)
    # Row 3.24 — "Was: <verdict>" when a platform closure changed it.
    kept = data.get("verdict_before_close") or {}
    if kept and data.get("status") in ("closed", "resolved"):
        verdict_line += f"  (was {kept.get('verdict') or 'no verdict'})"
    status_line = data.get("status") or ""
    if data.get("closed_by_line"):
        # The platform's own sentence ("Closed by Jay Shah: False positive"), with the day it closed; the lines below are the older server's.
        status_line += f"  — {data['closed_by_line']}" + (f" · {local_day(data.get('closed_at'))}" if data.get("closed_at") else "")
    elif data.get("closed_by_display_name"):
        # Row 3.23: who closed it and why, on every closed row.
        status_line += f"  — by {data['closed_by_display_name']}"
        if data.get("resolution_reason"):
            status_line += f" ({data['resolution_reason']})"
    rows = [
        ("NAME", data.get("name") or ""),
        # Both, each labelled: the finding's (what the Inbox shows) and the declaring rule's (one value for every item of the rule).
        # The item's ONE severity (what the Inbox, its SLA and its routing use), when the platform sends it.
        # the level the app gives it (its deadline class) when it ranks the item; the scanner's word stays below, labelled
        *([("LEVEL", data["level_label"])] if data.get("level_label") else
          [("SEVERITY", data["entry_severity_label"])] if data.get("entry_severity_label") else []),
        ("FINDING SEVERITY", data.get("finding_severity_label") or _severity_word(data.get("finding_severity")) or "Not recorded"),
        ("RULE SEVERITY", "Not declared" if data.get("rule_severity_declared") is False
         else (data.get("rule_severity_label") or _severity_word(data.get("severity")) or "")),
        ("BOX", _box),
        ("WHY", data.get("why_label") or "—"),
        ("STATUS", status_line),
        ("VERDICT", verdict_line),
    ]
    # ⭐ THE DEADLINE, AND WHY IT IS WHAT IT IS, in the platform's own words (DS4c § 3.2.4).
    # `deadline_basis` is a server-built sentence, so this prints it rather than composing one:
    # an item that came back from a reopen already overdue reads "reopened; first detected <date>"
    # identically here, on the screen and in the Inbox view. ⚠️ Only when present, so an item with
    # no deadline prints no row.
    _sla = _sla_bit(data).removeprefix('SLA: ')
    if _sla:
        rows.append(("DEADLINE", _sla + (f"  — {data['deadline_basis']}"
                                         if data.get("deadline_basis") else "")))
    elif data.get("deadline_basis"):
        rows.append(("DEADLINE", str(data["deadline_basis"])))
    # ⭐ THE EXPLOIT SIGNALS, in the platform's words (DS4d § 3.2.3). The server serves a label per
    # signal; this prints them and writes nothing itself.
    # ⚠️ A SIGNAL THAT IS NOT KNOWN IS PRINTED AS SUCH, not left out, because here — unlike a list
    # row — the absence of a line is indistinguishable from a signal nobody measured, and a person
    # reading one item deserves to know which it is.
    _signals = data.get("exploit_signals") or {}
    _sig_bits = [_signals[f"{k}_label"] for k in ("known_exploited", "fix_available")
                 if _signals.get(f"{k}_label")]
    if _sig_bits:
        rows.append(("SIGNALS", " · ".join(_sig_bits)))
    # Where the work is (the platform's lists; an entry can span several).
    for _label, _key in (("REPOSITORY", "repositories"), ("CLOUD", "clouds")):
        _vals = data.get(_key) or []
        if _vals:
            rows.append((_label, ", ".join(str(v) for v in _vals)))
    # What the agent found and where, for a closure on evidence the platform does not
    # hold. Only shown when present, so an ordinary alert's output is unchanged.
    if data.get("verdict_evidence"):
        rows.append(("EVIDENCE", data["verdict_evidence"]))
    if data.get("remediation_action"):
        _rem = data["remediation_action"] + (
            f" {data['remediation_target_type']}" if data.get("remediation_target_type") else "")
        if data.get("remediation_target_version"):
            _rem += f" to {data['remediation_target_version']}"
        rows.append(("REMEDIATION", _rem))
        rows.append(("ENTRY KEY", data.get("remediation_key")
                     or "(not built: a fact the policy needs is missing)"))
    # B11 — the item's fix plan in one line, from the API's `fix_plan` (null = no plan, no row).
    _fix_line = fix_plan_line(data.get("fix_plan"), fix_decider)
    if _fix_line:
        rows.append(("FIX PLAN", _fix_line))
    # I-90 — the PR merged and the item is still open: has a scan looked since? The platform's own lines, dates in your zone.
    _fs = data.get("fix_status")
    if isinstance(_fs, dict) and _fs.get("lines"):
        _fl = [_line_value(x) for x in _fs["lines"]]
        rows.append(("FIX STATUS", " ".join([_fl[0].rstrip(".") + ".", *_fl[1:]])))
    if str(data.get("assignee_type") or "").lower() == "team" and data.get("assigned_to"):
        # I-31 (Bhakta 2026-10-21): the platform's default owner when nobody was named.
        rows.append(("ASSIGNED TO", f"team {data['assigned_to']} (the owning team). Nobody is notified and it is "
                     "in nobody's \"assigned to me\"; a person on the team takes it with `assign`"))
    if data.get("assignee_chosen_by_person"):
        rows.append(("OWNER CHOICE", "chosen by a person"
                     + (f" at {data['assignee_chosen_at']}" if data.get("assignee_chosen_at") else "")
                     + "; no automatic step overrides it"))
    if data.get("cve_fixes"):
        rows.append(("CVE FIXES", "; ".join(
            f"{c['cve']}: " + (f"{c['fixed_version']}" if c.get("fixed_version")
                               else "versions differ (" + ", ".join(c.get("versions") or []) + ")")
            for c in data["cve_fixes"])))
    if data.get("follow_up_actions"):
        rows.append(("FOLLOW-UP", "; ".join(str(a) for a in data["follow_up_actions"])))
    if data.get("continuity_note"):
        rows.append(("CONTINUITY NOTE", data["continuity_note"]))
    # T-3 — the last triage attempt FAILED. Shown only then: "(not yet judged)" above
    # reads the same for an alert never triaged and one whose triage crashed.
    tf = data.get("triage_failure") or {}
    if tf.get("state") == "failed":
        when = str(tf.get("at") or "")[:16].replace("T", " ")
        hint = ("a requeue should work" if tf.get("recoverable")
                else "fix the cause before re-running")
        rows.append(("TRIAGE", f"FAILED after {tf.get('attempts')}/{tf.get('max_attempts')} "
                               f"attempts at {when} UTC ({tf.get('error_kind')}); will not "
                               f"retry on its own — {hint}: {tf.get('error') or ''}"))
    elif tf.get("state") == "retrying":
        when = str(tf.get("at") or "")[:16].replace("T", " ")
        nxt = f"next ~{when} UTC" if when else "retrying now"
        rows.append(("TRIAGE", f"failed {tf.get('attempts')}/{tf.get('max_attempts')}, "
                               f"retrying ({nxt}): {tf.get('error') or ''}"))
    # F-o01-1/F-o01-2 — what this verdict RELIED ON at runtime, and whether it still
    # runs. Only shown when the platform recorded a place, so an ordinary alert's output
    # is unchanged. ⛔ The ⚠ glyph and the words carry the state: no colour, and the
    # stale line says "verdict unchanged" because this is an observation, not a
    # re-decision.
    if data.get("verdict_runtime_key"):
        _f = data.get("verdict_runtime_facts") or {}
        _bits = [str(data["verdict_runtime_key"]).split("/")[-1] or data["verdict_runtime_key"]]
        if _f.get("services") is not None:
            _svc = f"{_f['services']} services"
            if _f.get("internet_facing_services") is not None:
                _svc += f" ({_f['internet_facing_services']} internet-facing)"
            _bits.append(_svc)
        _seen = data.get("verdict_runtime_last_seen_at") or data.get("verdict_runtime_seen_at")
        if _seen:
            _bits.append(f"seen {_view_time(_seen)}")                  # the reader's zone, with its name
        rows.append(("RUNTIME", " · ".join(_bits)))
        if data.get("verdict_runtime_stale"):
            # ⚠️ "last seen" is omitted when unknown rather than printed as "None": a
            # record adopted from a finding_key carries a place but no observation time,
            # and "last seen None" reads as a bug to an operator. Measured on T1.
            _since = local_day(data.get("verdict_runtime_stale_at"))
            _tail = f" — last seen {local_day(_seen)}" if _seen else ""
            rows.append(("", f"⚠ not running since {_since}{_tail}; verdict unchanged"))
    rows += facts_changed_rows(data)
    rows += [
        ("PROPOSED FIX", fix or "(none)"),
        *code_links_rows(data.get("code_links")),
        ("DESCRIPTION", (data.get("description") or "").strip()),
    ]
    # ⭐ WHY IT CLOSED, when the LIFECYCLE closed it. An operator who finds work gone from
    # their queue has no other record of what removed it — the reason code alone is a
    # word, not an account. Only shown when the lifecycle acted, so an ordinary alert's
    # output is unchanged.
    rows += lifecycle_evidence_rows(data.get("lifecycle_evidence"))

    # Fix-grain WP4 — what this alert IS in its group. Only shown when it is part of one,
    # so an ordinary finding's output is unchanged.
    if (data.get("group_role") or "member") == "root":
        total = data.get("member_count")
        settled = data.get("members_settled")
        if not total:
            progress = "no linked items yet"
        else:
            progress = f"{settled or 0} of {total} linked item(s) settled"
            if (settled or 0) >= total:
                progress += "  — the fix is done"
        # ⛔ ONE NUMBER, from the platform: `findings_cleared` = what the rule declares plus the
        # items linked to it. Null means the rule declares no count, and then NOTHING is said
        # about how many findings it clears. It used to print the linked-item count, which is 0
        # for a root whose findings were never raised as items: "clears 0" beside a title that
        # said 2.
        clears = clears_phrase(data)
        rows.append(("GROUP", f"root{clears};  {progress}"))
    elif data.get("parent_alert_id"):
        rows.append(("GROUP", f"member of {data['parent_alert_id']}  "
                              f"(torana alert {data['parent_alert_id']} get)"))
    # Row 3.36: the actions the platform will accept on this item right now.
    if isinstance(data.get("allowed_actions"), list):
        rows.append(("ACTIONS", ", ".join(data["allowed_actions"]) or "(none)"))
    for label, value in rows:
        click.echo(f"{label:<14} {value}")
    click.echo("")


@alert.command(name="get")
@_tenant_read_option
@click.pass_context
def alert_get(ctx):
    """The item's raw record: status, severity, verdict, assignee, owner, SLA and timestamps.

    The deadline line prints the platform's own `deadline_basis` sentence when there is one, so the
    reason a deadline is what it is — including "reopened; first detected <date>" on an item that
    came back already overdue — reads the same here as on the screen and in the Inbox view.

    Use this when you need the stored fields as the API holds them (for a script, or to check one field). To read the item
    the way the Inbox shows it, with the reasons and the fix, use `inbox` instead.

    \b
    Output:
      One record. Add --json for every field, or --fields id,status,severity to pick some.

    \b
    Related:
      torana alert <UUID> view         the item as the Inbox shows it
      torana alert <UUID> activities    what happened to it, in order

    \b
    Examples:
      torana alert 550e8400-e29b-41d4-a716-446655440000 get
      torana alert 550e8400-e29b-41d4-a716-446655440000 get --fields id,status,severity
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    client = _client(ctx)
    try:
        data = client.get(f"alerts/{aid}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # In text mode, lead with the answer. `get` printed every key the API returns in
    # whatever order it returned them, each cut at 20 characters — so the verdict, who
    # reached it and what to do about it were somewhere in a wall of ids.
    if fmt == "text" and not fields and isinstance(data, dict):
        _print_alert_head(data, fix_decider=_fix_plan_decider(client, data.get("fix_plan")))

    output(data, fmt=fmt, fields=fields)


_UUID = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I)


def _fix_plan_decider(client, fp):
    """The name of the person who approved the fix plan (`decided_by` a user id), or None: `system`, no plan, or a
    lookup that failed (the line then shows the id)."""
    who = (fp or {}).get("decided_by") if isinstance(fp, dict) else None
    if not who or who == "system" or not _UUID.match(str(who)):
        return None
    try:
        row = client.get(f"users/{who}") or {}
    except (APIError, AuthError):
        return None
    return row.get("display_name") or row.get("name") or row.get("email")


#: The server's page size for `alerts/{id}/members`, and how many pages the default walk takes before it stops.
_MEMBERS_PAGE = 100
_MEMBERS_MAX_PAGES = 50


def _members_params(limit, skip, include_closed):
    """One page in the Inbox list's order (`order=path`): stuck first, each row with its badge."""
    params = {"limit": limit, "skip": skip, "graph_nodes": "true", "order": "path"}
    if include_closed:
        params["include_closed"] = "true"
    return params


def _fetch_all_members(client, aid, include_closed=False):
    """Every member of an entry, by paging until a short page (cap `_MEMBERS_MAX_PAGES`, with a warning).

    ⛔ A single call returns at most 100 rows and says nothing, so an entry with 205 members looked complete at 100.
    Returns (rows, truncated)."""
    rows = []
    for page in range(_MEMBERS_MAX_PAGES):
        chunk = client.get(f"alerts/{aid}/members", params=_members_params(_MEMBERS_PAGE, page * _MEMBERS_PAGE, include_closed))
        if not isinstance(chunk, list):
            return chunk, False                 # not the list shape: hand it back untouched
        rows.extend(chunk)
        if len(chunk) < _MEMBERS_PAGE:
            return rows, False
    return rows, True


@alert.command(name="members")
@_tenant_read_option
@click.option("--limit", type=int, default=None,
              help="Return ONE page of at most this many members (max 100). Without --limit and --offset every "
                   "member is returned, paging for you.")
@click.option("--offset", type=int, default=None, help="Rows to skip; returns ONE page from here.")
@click.option("--include-closed", is_flag=True, default=False,
              help="Also list the findings already closed (after the open ones). Without it, open findings only.")
@click.pass_context
def alert_members(ctx, limit, offset, include_closed):
    """The findings this alert's fix clears (the rows behind "What this fix clears").

    Use this to list an entry's findings; the headline counts are in `alert <UUID> view --section clears`.

    A ROOT alert stands for one action — an upgrade, a base-image rebuild — and owns the
    findings it clears. This lists its OPEN findings in the Inbox list's order: the ones whose
    triage review is pending first (the agent replied with no verdict recorded, a dead triage
    job, a request nobody answered), then by priority. BADGE says "Review pending", or
    who decided it (Rule decided, Agent confirmed, Agent decided, Person decided, Platform,
    Not decided yet); JSON `path_badge_note` says what the platform is doing about a pending
    review (retrying it, or that you need to re-run triage). --include-closed adds the closed
    ones after.
    It pages through the server's 100-row pages itself (up to 50 pages, with a warning if
    there are more).
    Pass --limit or --offset to get a single page instead. An ordinary alert owns nothing
    and prints an empty list rather than failing.

    \b
    Examples:
      torana alert 550e8400-e29b-41d4-a716-446655440000 members
      torana alert 550e8400-e29b-41d4-a716-446655440000 members --limit 50 --offset 100
      torana alert 550e8400-e29b-41d4-a716-446655440000 members --include-closed
      torana alert 550e8400-e29b-41d4-a716-446655440000 members --format json

    Related: `alert <UUID> view`, `alerts list`.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    aid = _aid(ctx)
    client = _client(ctx)
    try:
        if limit is None and offset is None:
            data, truncated = _fetch_all_members(client, aid, include_closed)
            if truncated:
                click.echo(f"WARNING: stopped after {_MEMBERS_MAX_PAGES * _MEMBERS_PAGE} members "
                           f"({_MEMBERS_MAX_PAGES} pages); there are more. Use --offset "
                           f"{_MEMBERS_MAX_PAGES * _MEMBERS_PAGE} to continue.", err=True)
        else:
            size, skip = min(limit if limit is not None else _MEMBERS_PAGE, _MEMBERS_PAGE), offset or 0
            data = client.get(f"alerts/{aid}/members", params=_members_params(size, skip, include_closed))
            if isinstance(data, list) and size and len(data) >= size:
                click.echo(f"showing {skip + 1}-{skip + len(data)}; more may exist, use --offset {skip + len(data)}",
                           err=True)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt == "text" and not fields and isinstance(data, list) and not data:
        click.echo("No members — this alert does not stand for a group.")
        return
    output(_with_severity_labels(data, fmt == "text" and not fields), fmt=fmt, raw=raw, fields=fields, columns=_MEMBER_COLS)
    if fmt == "text" and not fields and isinstance(data, list):
        hint = _graph_hint(data)
        if hint:
            click.echo(hint)


def _graph_hint(rows) -> str:
    """How many members have a node in the entity graph, and how to open one. Empty when none does."""
    keyed = [r["graph_node_key"] for r in rows if isinstance(r, dict) and r.get("graph_node_key")]
    if not keyed:
        return ""
    return (f"\n{len(keyed)} of {len(rows)} member(s) have a node in the entity graph. Open one:\n"
            f"  torana entity-graph neighbors {keyed[0]} --direction both\n"
            f"  UI: /entity-graph/explore?seed={keyed[0]}")


#: What a person scans for first about a CVE: how bad, how likely, is it being exploited.
_CVE_INTEL_COLS = [
    ("cve_id", "CVE", 16),
    ("cvss", "CVSS", 6),
    ("epss", "EPSS", 7),
    ("kev", "KEV", 34),
    ("cwe", "CWE", 22),
    ("published", "PUBLISHED", 10),
    ("summary", "DESCRIPTION", 60),
]


def _cve_intel_row(item):
    """The columns derived for the table view (the record's own fields are untouched, for --format json)."""
    def num(v, places):
        return "—" if not isinstance(v, (int, float)) or isinstance(v, bool) else f"{v:.{places}f}"
    if not item.get("known"):
        return {**item, "cvss": "—", "epss": "—", "kev": "—", "cwe": "—", "published": "—",
                "summary": "not in the threat-intel table"}
    # FX-005: "checked, not listed" and "unknown" are two different answers (the drawer's words, services/drill_wording.py).
    listed = item.get("kev_listed")
    if listed is True:
        kev = "KEV" + (f" (due {item['kev_due_date']})" if item.get("kev_due_date") else "")
    else:
        kev = "not on CISA KEV" if listed is False else "not available"
    if listed is True and item.get("kev_known_ransomware") not in (None, "", False, "Unknown", "unknown"):
        kev += " ransomware"
    desc = " ".join(str(item.get("description") or "").split())
    return {**item, "cvss": num(item.get("cvss3_base_score"), 1),
            "epss": num(item.get("epss_score"), 3) if item.get("epss_score") is not None else "—",
            "kev": kev, "cwe": str(item.get("cwe_ids") or item.get("cwe_id") or "—"),
            "published": str(item.get("published_date") or "—")[:10],
            "summary": desc[:57] + "..." if len(desc) > 60 else (desc or "—")}


@alert.command(name="cve-intel")
@_tenant_read_option
@click.pass_context
def alert_cve_intel(ctx):
    """What the platform holds about the CVEs on this item.

    One row per CVE: CVSS, EPSS, whether it is on the CISA KEV list (and ransomware use), its CWE, the
    description and dates. A single finding shows its own CVE; an ENTRY shows the distinct CVEs across its
    members, the worst CVSS first, at most 50 (`total` in --format json says how many there are). A CVE the
    threat-intel table does not hold is listed as "not in the threat-intel table", not an error.

    \b
    Examples:
      torana alert 550e8400-e29b-41d4-a716-446655440000 cve-intel
      torana alert 550e8400-e29b-41d4-a716-446655440000 cve-intel --format json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    aid = _aid(ctx)
    client = _client(ctx)
    try:
        data = client.get(f"alerts/{aid}/cve-intel")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    items = data.get("items") if isinstance(data, dict) else None
    if fmt in ("text", "table") and not raw and isinstance(items, list):
        if not items:
            click.echo("No CVE on this item.")
            return
        data = {**data, "items": [_cve_intel_row(i) for i in items]}
        output(data, fmt=fmt, raw=raw, fields=fields, columns=_CVE_INTEL_COLS)
        if data.get("truncated"):
            click.echo(f"Showing {len(items)} of {data.get('total')} CVEs (worst CVSS first).", err=True)
        return
    output(data, fmt=fmt, raw=raw, fields=fields, columns=_CVE_INTEL_COLS)


_FACT_AGE_HINT = {
    "pre_w1": "The stored answer is older than the set: it names one place only. It is refreshed in the background.",
    "none": "No stored answer: the Atlas has not been asked about this item (or it is not a pypi package finding).",
}


@alert.command(name="fix-scope")
@click.option("--json", "as_json", is_flag=True, default=False,
              help="Print the route's JSON as it comes (the shape the fix-PR planner reads).")
@click.pass_context
def alert_fix_scope(ctx, as_json):
    """Everything that must move together to fix this item's package, from the stored Atlas answer.

    One package version is often set in more than one place (a base-image lock, a shared library's pin, this
    repository's own pin). This prints every place that must change together, each with the reason, plus build
    steps that patch the package (to review). It reads the answer stored on the alert: free, no model, nothing
    recomputed. The fix-PR planner reads the same answer to know which repositories its plan must cover.

    \b
    `fact_age` says what the stored answer is:
      current   the set is there
      pre_w1    an older answer naming one place only (refreshed in the background)
      none      nothing stored for this item

    \b
    A CI token may call it only for an alert of the repository it is bound to (403 otherwise). The answer names
    other repositories' files, lines and specs in your tenant, never their content.

    \b
    Examples:
      torana alert 550e8400-e29b-41d4-a716-446655440000 fix-scope
      torana alert 550e8400-e29b-41d4-a716-446655440000 fix-scope --json
    """
    from torana_cli.move_set_words import move_set_lines

    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    try:
        data = _client(ctx).get(f"alerts/{_aid(ctx)}/fix-scope")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if as_json or raw or fmt not in ("text", "table") or not isinstance(data, dict):
        output(data, fmt="json" if as_json else fmt, raw=raw, fields=ctx.obj.get(CTX_FIELDS) if ctx.obj else None)
        return
    repo = str(data.get("repository") or "").removeprefix("repo:")
    click.echo(f"{data.get('package') or '?'} in {repo or '?'}  (stored answer: {data.get('fact_age') or '?'})")
    lines = move_set_lines(data.get("move_together"), data.get("pins"))
    if lines:
        click.echo("\n".join(lines))
    elif data.get("fact_age") in _FACT_AGE_HINT:
        click.echo(_FACT_AGE_HINT[data["fact_age"]])
    for a in data.get("as_of") or []:
        where = a.get("node_path") or str(a.get("repository") or "").removeprefix("repo:")
        click.echo(f"As of: snapshot {a.get('snapshot')} of {where} at {str(a.get('commit') or '')[:7]}")


@alert.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def alert_delete(ctx, yes):
    """Delete an item from the Inbox for good (it does not close it).

    Use `status` to close an item and keep its history. Delete is for an item that should never have existed, such as one
    created by mistake. It cannot be undone. Asks for confirmation unless you pass --yes.

    \b
    Output:
      The platform's confirmation.

    \b
    Related:
      torana alert <UUID> close --reason wont_fix    close it and keep the history

    \b
    Examples:
      torana alert <UUID> delete
      torana alert <UUID> delete --yes
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    aid = _aid(ctx)
    path = f"alerts/{aid}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="priority")
@click.option("--undo-learned", "undo_learned", is_flag=True, default=False,
              help="Undo a priority the triage agent lowered on Atlas facts (the 'Lower priority (learned)' group).")
@click.pass_context
def alert_priority(ctx, undo_learned):
    """Change who holds an item's priority.

    --undo-learned takes back a lowering the triage agent made on Atlas facts. The item gets YOUR placement at the rule's
    own number (else the priority it had before the lowering, else its severity's default), the cited facts are cleared,
    and one history line is written. A person's placement is never moved by a later re-rate. It works whether or not the
    lowering is still verified.

    \b
    Output:
      outcome: undone (with priority_before / priority_after) or not_learned (the item has no learned lowering; nothing
      was written), and `words`: the one fixed sentence for that outcome, printed as is in text mode.

    \b
    Related:
      torana alerts list                           the learned group is listed last, with its reason
      torana alert <UUID> view --section atlas     the Atlas facts the lowering cited

    \b
    Examples:
      torana alert <UUID> priority --undo-learned
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    if not undo_learned:
        raise click.UsageError("Say what to change: --undo-learned.")
    client = _client(ctx)
    try:
        data = client.post(f"alerts/{_aid(ctx)}/priority/undo-learned", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt == "text" and isinstance(data, dict) and data.get("words"):
        click.echo(data["words"])            # the server's fixed sentence, verbatim (same words as the FE)
        return
    # No sentence from the server (an older platform): its answer as data. The CLI never words an outcome itself.
    output(data, fmt=fmt, fields=fields)


@alert.command(name="activities")
@_tenant_read_option
@click.option("--thread-id", "thread_id", default=None)
@click.pass_context
def alert_activities(ctx, thread_id):
    """What happened to this item: who did what, and when.

    Use this to see decisions and events as a list: verdicts, assignments, comments, questions and answers, closures, reopens
    and the agent's reads of the code. The Inbox shows the same record as the History section of `inbox`.

    \b
    Output:
      One row per event: WHEN, ACTOR, WHAT, DETAIL. --thread-id keeps only the events of one question thread.

    \b
    Related:
      torana alert <UUID> view --section history    the same history, as the Inbox words it
      torana alert <UUID> comment --comment "..."     add to it

    \b
    Examples:
      torana alert <UUID> activities
      torana alert <UUID> activities --thread-id <THREAD>
      torana alert <UUID> activities --json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/activities"
    params = {}
    if thread_id is not None:
        params["thread_id"] = thread_id

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Explicit columns. Without them `output` printed every field of the first activity
    # cut at 20 characters, which truncated `message` — the only column worth reading.
    items = data.get("items", data) if isinstance(data, dict) else data
    if isinstance(items, list):
        for row in items:
            if isinstance(row, dict):
                row["actor"] = _activity_actor(row)
                if row.get("activity_type") == "code_read" and code_read_detail(row.get("extra_data")):
                    row["message"] = f"{row.get('message')} [{code_read_detail(row.get('extra_data'))}]"
    cols = [("timestamp", "WHEN", 20), ("actor", "ACTOR", 24),
            ("activity_type", "WHAT", 22), ("message", "DETAIL", 100)]
    output(data, fmt=fmt, fields=fields, columns=cols)


#: The Inbox's own section headings, in the order `order` names them. `header` and `activity` are
#: printed by this command; `clears` / `affected` / `closure` are member and closure content the
#: dedicated sub-commands already serve, so they are named in the footer rather than re-rendered.
_VIEW_HEADINGS = {
    "about": "ABOUT", "exposure_path": "EXPOSURE PATH", "verdict": "VERDICT", "atlas": "WHAT ATLAS KNOWS",
    "provenance": "WHERE IT COMES FROM",
    "reachability": "CODE REACHABILITY", "how_to_fix": "HOW TO FIX", "fix_pr_ci": "FIX PR CI",
    "clears": "WHAT THIS FIX CLEARS", "affected": "AFFECTED ITEMS", "reported_by": "REPORTED BY",
    "why_here": "WHY IT'S HERE", "history": "HISTORY", "path": "EVENT PATH",
    # the keys of the previous API, for a platform that has not been updated yet
    "description": "ABOUT", "fix": "HOW TO FIX", "reported": "REPORTED BY", "closure": "WHY IT'S HERE", "activity": "HISTORY",
}

#: The sections `alert <id> view --section` accepts, by their CLI key (the API key with `_` written `-`), in screen order.
#: `clears` and `affected` are the same section (the platform names it by the kind of item). The platform checks each key
#: against the kind of item and answers an unknown one with the list of valid keys.
VIEW_SECTION_KEYS = ("overview", "about", "exposure-path", "verdict", "atlas", "provenance", "reachability", "how-to-fix", "fix-pr-ci", "clears", "affected", "reported-by", "why-here", "history", "path")


#: The Atlas section's body (pantheon-detection-framework `services/atlas_section.py`). The platform also answers the old
#: key `provenance` with it, so the body's schema decides the heading and the printer, never the key asked for.
ATLAS_SECTION_SCHEMA = "detection/atlas-section.v1"


def _is_atlas_section(body) -> bool:
    return isinstance(body, dict) and body.get("schema") == ATLAS_SECTION_SCHEMA


def _view_heading(sid: str, body) -> str:
    if _is_atlas_section(body):
        return _VIEW_HEADINGS["atlas"]
    return _VIEW_HEADINGS.get(sid, sid.upper())


def _print_atlas_section(body: dict) -> None:
    """What Atlas knows: the four fixed rows, then the note, how fresh the answer is and the re-check action. Every word
    is the server's, printed verbatim (the state word, the row's words, each missing line, the note, the freshness
    words, the action's label). A row without a `state_word` is not printed (the screen drops it too)."""
    for r in body.get("rows") or []:
        if not isinstance(r, dict) or not r.get("state_word"):
            continue
        head = f"    {r.get('glyph') or ''} {r.get('title') or r.get('key') or ''} ({r['state_word']})".rstrip()
        click.echo(f"{head}: {r['words']}" if r.get("words") else head)
        for m in r.get("missing") or []:
            if isinstance(m, dict) and m.get("words"):     # the server writes the words; a raw code is never printed
                click.echo(f"      Missing: {m['words']}")
    if body.get("note"):
        click.echo(f"    Note: {body['note']}")
    fresh = (body.get("freshness") or {}).get("words")
    if fresh:
        click.echo(f"    {fresh}")
    rc = body.get("recheck") or {}
    if rc.get("label"):
        click.echo(f"    ↻ {rc['label']}")
        if rc.get("words"):
            click.echo(f"      ({rc['words']})")


def _api_section_key(key: str) -> str:
    return key.strip().lower().replace("-", "_")


def _print_section_body(sid: str, body: dict) -> None:
    """One section as text: a platform note (`empty`, `unavailable`), the exposure path (a proof record), or its lines."""
    if not body:
        return
    if body.get("empty") or body.get("unavailable"):
        click.echo(f"    {body.get('empty') or body.get('unavailable')}")
        return
    if _is_atlas_section(body):
        _print_atlas_section(body)
        return
    if sid == "provenance":
        _print_provenance(body)
        return
    if sid == "fix_pr_ci":
        from torana_cli.fix_pr_ci_view import print_fix_pr_ci
        print_fix_pr_ci(body, indent="    ")
        return
    if sid == "path":
        from torana_cli import event_path_view
        event_path_view.print_path(body, _view_time, all_groups=_all_reasons())
        return
    if sid == "exposure_path" and body.get("record"):
        from torana_cli import proof_view
        for line in proof_view.graph_lines((body["record"] or {}).get("item") or {}):
            click.echo(line.lstrip("\n") if line else "")
        return
    for row in body.get("lines") or []:
        _print_view_line(row)
    for f in body.get("followUps") or []:
        click.echo(f"    → {f}")
    detail = body.get("detail") if sid == "about" else None
    if isinstance(detail, dict) and not _all_reasons():
        # An entry's About is the platform's summary; the full CVE and CWE blocks are folded, as on the screen.
        click.echo(f"    ↳ {detail.get('label') or 'Show the details'}: add --all-reasons")
        _print_notes(body)
        return
    for row in (detail or {}).get("lines") or []:
        _print_view_line(row)
    table = (detail or {}).get("table") or []
    if table:
        # One row per vulnerability, most urgent first; the long text is `torana alerts cve <CVE>`.
        click.echo(f"    {'VULNERABILITY':<22} {'CVSS':>5} {'EPSS':>6} {'KEV':>4} {'FINDINGS':>8}  WEAKNESS")
        for t in table:
            click.echo(f"    {t.get('id', ''):<22} {t.get('cvss', ''):>5} {t.get('epss', ''):>6} {t.get('kev', ''):>4} "
                       f"{t.get('findings', ''):>8}  {t.get('weakness', '')}")
        click.echo("    (each CVE in full: torana alerts cve <CVE> --workspace-id <APP_ID>)")
        _print_notes(body)
        return
    for block in (body.get("cves") or []) + (body.get("others") or []):
        _print_identifier_block(block)
    _print_notes(body)


#: Atlas's also-not-read gaps printed before "and N more" (all of them with --all-reasons).
_PROVENANCE_GAPS_SHOWN = 3


def _state_line(label: str, part, indent: str = "    ") -> None:
    """`Label: <glyph> <words>` from a platform state ({state, glyph, words}); nothing when the platform sent none."""
    if isinstance(part, dict) and (part.get("words") or part.get("state")):
        glyph = f"{part['glyph']} " if part.get("glyph") else ""
        click.echo(f"{indent}{label}: {glyph}{part.get('words') or part.get('state')}")


def _link_lines(part, indent: str = "      ") -> None:
    if isinstance(part, dict):
        where = " ".join(x for x in (part.get("location"), f"→ {part['url']}" if part.get("url") else None) if x)
        if where:
            click.echo(f"{indent}{where}")


def _print_provenance(body: dict) -> None:
    """Atlas's package provenance card (`provenance`), printed as the platform worded it. A server that sends the v2 card
    (`answer`, …; pantheon-knowledge PACKAGE_PROVENANCE.md § "Inbox card") gets it in the screen's order; an older one
    gets the older layout below."""
    if isinstance(body.get("answer"), dict):
        _print_provenance_card(body)
        return
    _print_provenance_v1(body)


def _print_provenance_card(body: dict) -> None:
    """The v2 card, in the order the Inbox shows it: answer, origin, fix, what Atlas could not see, cautions, then "How we
    know" (expanded: a terminal has no fold), then the status line and the re-check action. Every word is the server's."""
    a = body["answer"]
    click.echo(f"    {a.get('glyph') or ''} {a.get('label') or a.get('state')}".rstrip())
    if a.get("words"):
        click.echo(f"      {a['words']}")
    if body.get("rows"):
        _print_provenance_rows(body["rows"])
    else:
        _print_provenance_body(body)
    for c in body.get("cautions") or []:
        if isinstance(c, dict) and c.get("words"):
            click.echo(f"      {c.get('glyph') or ''} {c['words']}".rstrip())
    how = body.get("how") or {}
    if how.get("label"):
        click.echo(f"    {how['label']}:")
        for s in how.get("steps") or []:
            click.echo(f"      {s.get('n')}. {s.get('words') or ''}")
            if s.get("url"):
                click.echo(f"         → {s['url']}")
        for n in how.get("not_read") or []:
            click.echo(f"      • {n.get('words')}")
        for key in ("image", "read_from"):
            if how.get(key):
                click.echo(f"      {how[key]}")
    st = body.get("status") or {}
    rc = body.get("recheck") or {}
    footer = " · ".join(x for x in (f"{st.get('glyph') or ''} {st.get('words') or ''}".strip(), st.get("checked")) if x)
    if footer or rc.get("label"):
        click.echo(f"    {footer}" + (f"    ↻ {rc['label']}" if rc.get("label") else ""))
    if rc.get("words"):
        click.echo(f"      ({rc['words']})")
    if st.get("tooltip"):
        click.echo(f"      ({st['tooltip']})")


def _print_provenance_rows(rows: list) -> None:
    """The card body as the server's labelled rows, labels aligned. Backticks (the screen's code font) are dropped: a
    terminal has no code font. A row's link goes on its own line."""
    rows = [r for r in rows if isinstance(r, dict) and r.get("words")]
    width = max((len(str(r.get("label") or "")) for r in rows), default=0)
    for r in rows:
        click.echo(f"      {str(r.get('label') or ''):<{width}}  {str(r['words']).replace('`', '')}")
        if r.get("url"):
            click.echo(f"      {'':<{width}}  → {r['url']}")


def _print_provenance_body(body: dict) -> None:
    """The body before rows (an older server): origin, fix, and what Atlas could not see, one sentence each."""
    origin = body.get("origin") or {}
    if origin.get("words"):
        click.echo(f"      {origin['words']}")
    fix = body.get("fix") or {}
    if fix.get("location"):
        change = f"    {fix['change_words']}" if fix.get("change_words") else ""
        label = f"{fix['label']}: " if fix.get("label") else ""
        click.echo(f"      {label}{fix['location']}{change}")
        if fix.get("url"):
            click.echo(f"        → {fix['url']}")
    if fix.get("words"):
        click.echo(f"      {fix['words']}")
    u = body.get("unknown") or {}
    for key in ("could_not_see", "did_see", "next_step"):
        if u.get(key):
            click.echo(f"      {u[key]}")


def _print_provenance_v1(body: dict) -> None:
    """The older layout (a server without the v2 card): the verdict, the reported file, what ships, the fix location, the
    proof steps with their GitHub links, what Atlas could not read, and when it was computed."""
    _state_line("Verdict", body.get("verdict"))
    rf = body.get("reported_file")
    if isinstance(rf, dict) and rf.get("words"):
        click.echo(f"    Reported file: {rf['words']}")
        if rf.get("url"):
            click.echo(f"      → {rf['url']}")
    for sh in body.get("ships") or []:
        click.echo(f"    Ships: {sh.get('words')}")
        _link_lines(sh)
    fix = body.get("fix_at")
    if isinstance(fix, dict) and fix.get("words"):
        # The server's label (FIX_KNOWLEDGE_CONVERGENCE § 3.3.5 C1), never our own; an older server sends none.
        click.echo(f"    {fix['label']}: {fix['words']}" if fix.get("label") else f"    {fix['words']}")
        _link_lines(fix)
    _state_line("Running", body.get("running"))
    obs = body.get("observed")
    if isinstance(obs, dict) and obs.get("basis") == "observed_image" and obs.get("words"):
        click.echo(f"    Image read: {obs['words']}" + (f" ({obs['image']})" if obs.get("image") else ""))
    _state_line("Knowledge", body.get("knowledge"))
    steps = [s for s in body.get("steps") or [] if isinstance(s, dict)]
    if steps:
        click.echo("    How Atlas knows:")
        for s in steps:
            kind = f"[{s.get('kind')}] " if s.get("kind") else ""
            click.echo(f"      {s.get('n')}. {kind}{s.get('claim') or ''}")
            _link_lines(s, indent="         ")
            if s.get("quote"):
                click.echo(f"         “{s['quote']}”")
    missing = body.get("missing") or {}
    head = missing.get("headline")
    # The platform says when the verdict sentence already states the headline gap: print it once.
    if isinstance(head, dict) and head.get("words") and not missing.get("headline_in_verdict"):
        click.echo(f"    Not read: {head['words']}")
    also = [g for g in missing.get("also") or [] if isinstance(g, dict)]
    if also:
        click.echo(f"    {missing.get('also_label') or f'Also not read ({len(also)})'}:")
        shown = also if _all_reasons() else also[:_PROVENANCE_GAPS_SHOWN]
        for g in shown:
            click.echo(f"      • {g.get('words') or g.get('code')}")
        if len(shown) < len(also):
            click.echo(f"      … and {len(also) - len(shown)} more (--all-reasons shows them)")
    as_of = ", ".join(f"{a.get('repository')} @ {a.get('commit')} (snapshot {a.get('snapshot')})"
                      for a in body.get("as_of") or [] if isinstance(a, dict))
    when = _view_time(body["fetched_at"]) if body.get("fetched_at") else None
    if when or as_of:
        click.echo("    Computed: " + " · ".join(x for x in (when, f"from {as_of}" if as_of else None) if x))


def _view_time(iso) -> str:
    """An ISO timestamp in the caller's own timezone.

    ⚠️ The API sends these UNFORMATTED on purpose (lines flagged `iso`): the server cannot know the
    viewer's timezone, and the Inbox renders them in the VIEWER's. Formatting here is the CLI's half
    of that contract — print the raw value and a terminal reader silently reads UTC as local.
    """
    import datetime as _dt
    # A DATE (no time of day: a KEV listing or due date) is a day, not a moment. Converting it to the reader's zone
    # invented a clock time and, west of UTC, moved it to the day before ("fix by 10 May, 17:00" for a CISA due date
    # of 11 May; CB-60). It is printed as the day it is.
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(iso or "")):
        return _view_date(iso)
    try:
        t = _dt.datetime.fromisoformat(str(iso).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return str(iso or "")
    if t.tzinfo is None:
        t = t.replace(tzinfo=_dt.timezone.utc)
    local = t.astimezone()
    return f"{day_words(local)}, {local.strftime('%H:%M %Z')}"      # the month comes from _MONTHS, never from the host's LC_TIME


def _view_date(iso) -> str:
    """A DATE (no clock) as the Inbox writes it: "Sep 6, 2026". Used for CVE publication and KEV
    dates, which are days, not moments — unlike `_view_time`, which carries a time of day."""
    import datetime as _dt
    try:
        t = _dt.datetime.fromisoformat(str(iso).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return str(iso or "")
    return day_words(t)


def _line_value(row) -> str:
    """A line's text for a terminal. Dates are the CLI's to format (the platform cannot know the reader's zone): `iso` is one moment,
    `template` + `dates` is a sentence with `{0}`, `{1}` for days or moments. "Seen" is the item's sighting count: its `iso` is the last
    sighting, not the value."""
    if row.get("template") and row.get("dates"):
        return re.sub(r"\{(\d+)\}", lambda m: _view_time(row["dates"][int(m.group(1))]), row["template"])
    if row.get("iso") is True:                      # the value IS the moment (the item view's earlier shape)
        return _view_time(row.get("value"))
    if row.get("label") == "Seen" and row.get("iso"):
        return f"{row.get('value')} times, last seen {_view_time(row['iso'])}"
    return row.get("value") or ""


def _print_view_line(row, indent="  ") -> None:
    """One `Label: value` line of a section, with its links, bullets and folded extras beneath it."""
    label = row.get("label") or ""
    value = _line_value(row)
    muted = f"  {row['muted']}" if row.get("muted") else ""
    if row.get("label") == "Took over" and row.get("iso"):
        muted = f"  moved here {_view_time(row['iso'])}"
    if row.get("level") == "warning":
        indent = f"{indent}⚠ "
    if label and value:
        click.echo(f"{indent}{label}: {value}{muted}")
    elif label:
        click.echo(f"{indent}{label}:{muted}" if muted else f"{indent}{label}:")
    elif value:
        click.echo(f"{indent}{value}{muted}")
    indent = indent.replace("⚠ ", "")
    for link in row.get("links") or []:
        click.echo(f"{indent}  → {link.get('text')}  {link.get('url') or link.get('drill') or link.get('alert_id') or link.get('inbox_filter') or ''}".rstrip())
    if row.get("links_more"):                       # "and 2 more": after the links it is about, not beside the sentence
        click.echo(f"{indent}  {row['links_more']}")
    tables = _line_tables(row.get("tables"))
    if tables:                                      # the same reasons and tallies as the platform's tables: printed instead of the bullets and `more`
        for t in tables:
            _print_line_table(t, f"{indent}  ")
    for b in [] if tables else row.get("bullets") or []:
        click.echo(f"{indent}  • {b}")
    # `wording` and `notes` are folded behind a toggle in the UI; the CLI has no toggle, so they are
    # printed under their own label rather than silently dropped.
    if row.get("wording"):
        click.echo(f"{indent}  ↳ in the ranking's words: {row['wording']}")
    if row.get("notes"):
        click.echo(f"{indent}  ↳ agent's notes: {row['notes']}")
    more = row.get("more")
    if isinstance(more, dict) and more.get("bullets") and not tables:
        if _all_reasons():
            for b in more["bullets"]:
                click.echo(f"{indent}  – {b}")
        else:
            click.echo(f"{indent}  ↳ {more.get('label') or 'Show all reasons'}: rerun with --all-reasons")


def _line_tables(raw) -> list:
    """A line's `tables` ({title, columns: [{field, header}], rows, footnotes}) with every cell as text; [] from an older platform."""
    out = []
    for t in raw if isinstance(raw, list) else []:
        cols = [c for c in (t.get("columns") or []) if isinstance(c, dict) and c.get("field")] if isinstance(t, dict) else []
        if not cols:
            continue
        rows = [[str(r.get(c["field"]) if r.get(c["field"]) is not None else "") for c in cols]
                for r in (t.get("rows") or []) if isinstance(r, dict)]
        out.append({"title": str(t.get("title") or ""), "headers": [str(c.get("header") or "") for c in cols], "rows": rows,
                    "footnotes": [str(n) for n in (t.get("footnotes") or []) if n]})
    return out


def _print_line_table(t, indent) -> None:
    """One table of a line, the platform's words as they come: its title, the headers, the rows aligned in columns, then its footnotes."""
    if t["title"]:
        click.echo(f"{indent}{t['title']}")
    widths = [max(len(x) for x in [h] + [r[i] for r in t["rows"]]) for i, h in enumerate(t["headers"])]
    for cells in [t["headers"], ["-" * w for w in widths]] + t["rows"]:
        click.echo(f"{indent}  " + "  ".join(c.ljust(w) for c, w in zip(cells, widths)).rstrip())
    for n in t["footnotes"]:
        click.echo(f"{indent}  {n}")
    click.echo("")


def _all_reasons() -> bool:
    """Whether `--all-reasons` was given: the lines' folded `more` bullets are printed instead of a hint."""
    ctx = click.get_current_context(silent=True)
    return bool(ctx and ctx.meta.get("torana_all_reasons"))


def _print_notes(body, indent="  ") -> None:
    """A section's `notes` (what its counts are over, caps, caveats), muted, under the section, as the screen shows them."""
    notes = body.get("notes") if isinstance(body, dict) else None
    for n in ([notes] if isinstance(notes, str) else notes or []):
        if n:
            click.echo(f"{indent}{n}")


def _view_assignee(head) -> str:
    """Who holds the item, as the Inbox header says it: "Assigned to team X", "Assigned to <name>", or "Unassigned"."""
    kind = str(head.get("assignee_type") or "").lower()
    who = head.get("assigned_to")
    if kind == "team" and who:
        return f"Assigned to team {who}"
    if kind == "agent" and who:
        return "Assigned to the triage agent"
    if who:
        return f"Assigned to {head.get('assignee_display_name') or who}"
    return "Unassigned"


def _view_meta_bits(head) -> list:
    """The Inbox header's other facts, from the view's `header` (EM A-03, 2026-11-03): priority, assignee, created, last
    changed (only when it moved more than an hour after creation, as the Inbox), and a parent. Never the rule's severity:
    the header does not show it (`alert <id> get` keeps its RULE SEVERITY row)."""
    import datetime as _dt
    bits = []
    if head.get("triage_priority") is not None:
        bits.append(f"P{head['triage_priority']}")
        if head.get("priority_source_label"):      # who set it, in the platform's words ("Set by the ranking, reviewed by the agent")
            bits.append(str(head["priority_source_label"]))
    bits.append(_view_assignee(head))
    if head.get("created_at"):
        bits.append(f"Created {_view_time(head['created_at'])}")
    try:
        created = _dt.datetime.fromisoformat(str(head.get("created_at")).replace("Z", "+00:00"))
        updated = _dt.datetime.fromisoformat(str(head.get("updated_at")).replace("Z", "+00:00"))
        if (updated - created).total_seconds() > 3600:
            bits.append(f"Last changed {_view_time(head['updated_at'])}")
    except (TypeError, ValueError):
        pass
    if head.get("parent_alert_id"):
        bits.append("1 parent")
    return bits


def _sla_bit(head) -> str:
    """"SLA: breached (due 11 Oct 2026, 14:20)" from the server's `sla_state` and `sla_due_at`; empty when the item has none (no deadline, or closed).
    The state is the platform's; this only words it and renders the moment in the reader's zone."""
    word = sw.sla_word(head or {})
    if not word:
        return ""
    due = (head or {}).get("sla_due_at")
    return f"SLA: {word}" + (f" (due {_view_time(due)})" if due else "")


def _print_description(body, indent="  ") -> None:
    """A section's `description` (what the card shows), muted, under its heading. Present on every section the platform sends."""
    if isinstance(body, dict) and body.get("description"):
        click.echo(f"{indent}{body['description']}")

def _intel_value(row) -> str:
    """An intel row's text, with any dates in it rendered in the caller's timezone.

    ⚠️ A row holding dates sends `template` ("Published {0} · updated {1}") plus the ISO `dates`;
    its `value` has the ISO strings already substituted, for a reader that does not format them.
    Printing `value` here showed "Published 2026-09-06T18:17:20.553000" where the Inbox shows
    "Published Sep 6, 2026".
    """
    template = row.get("template")
    dates = row.get("dates")
    if not template or not dates:
        return row.get("value") or ""
    out = template
    for idx, iso in enumerate(dates):
        out = out.replace("{%d}" % idx, _view_date(iso))
    return out


def _print_identifier_block(block) -> None:
    """A CVE or CWE block: its heading, what is known about it, and its description."""
    heading = block.get("heading") or ""
    name = f" — {block['name']}" if block.get("name") else ""
    click.echo(f"    {heading}{name}")
    for r in block.get("rows") or []:
        lbl = r.get("label") or ""
        click.echo(f"      {lbl + ': ' if lbl else ''}{_intel_value(r)}")
    if block.get("text"):
        click.echo(f"      {block['text']}")


def history_more_line(history, aid) -> str:
    """The line under a History page that has older events: how many, and the command that reads them. '' on the last page
    or from a platform that sends every event at once (no `has_more`)."""
    if not isinstance(history, dict) or not history.get("has_more") or not history.get("next_before"):
        return ""
    n = history.get("older")
    older = f"{n:,} older event{'' if n == 1 else 's'}" if isinstance(n, int) and n > 0 else "Older events"
    return f"  … {older}: torana alert {aid} view --section history --history-before '{history['next_before']}'"


@alert.command(name="view")
@_tenant_read_option
@click.option("--section", "sections_wanted", multiple=True, type=click.Choice(VIEW_SECTION_KEYS, case_sensitive=False),
              help="Show only this section (repeatable). Without it, every section of the item. A key the item's kind does not "
                   "have (`clears` vs `affected`) is answered with the keys that kind does.")
@click.option("--activity/--no-activity", "show_activity", default=True,
              help="Include the item's history (on by default, as the Inbox shows it).")
@click.option("--history-limit", type=click.IntRange(1, 100), default=None,
              help="History events per page (the platform's default is 50). A run of per-finding lines is one summary line.")
@click.option("--history-before", default=None, metavar="CURSOR",
              help="Show the history older than this cursor (printed under the history when there is more).")
@all_reasons_option
@click.pass_context
def alert_inbox(ctx, sections_wanted, show_activity, history_limit, history_before, all_reasons):
    """The item exactly as the Inbox shows it, whole or one section at a time.

    Use this to read one item: why it is here, the verdict and who decided it, the fix, what the
    fix clears, where it was reported from and its history. To work through the Inbox use
    `torana alerts list`; to see one CVE or CWE across the app use `torana alerts cve` or
    `torana alerts cwe`.
    CODE REACHABILITY is one of those sections, and it is absent on any finding
    nothing has measured — an image-layer finding shows it only where the entity graph
    traces the image back to a repository that builds it.

    The platform builds the sections (`GET /alerts/{id}/view`) and this command only prints them,
    so the CLI and the Inbox word an item the same way. A section with nothing to say is left out
    of the whole view; asked for by name it prints the reason it is empty. `Not recorded` means the
    source never gave the value. `get` is the operator view with the runtime and triage detail the
    Inbox leaves out.

    \b
    --section keys, with what each card shows (the platform sends the same text as `description` on every section):
      {SECTIONS}

    \b
    To act on how-to-fix: make the change, then `torana remediations create --alert-id <UUID> --pr-url <URL>`;
    `torana alert <UUID> remediation --help` says what recording a plan does and does not do. `clears` and `affected` are one
    card: an entry of one remediation has `clears`, a situation entry has `affected`.

    \b
    Examples:
      torana alert 550e8400-e29b-41d4-a716-446655440000 view
      torana alert 550e8400-e29b-41d4-a716-446655440000 view --section verdict
      torana alert 550e8400-e29b-41d4-a716-446655440000 view --section verdict --section how-to-fix --format json
      torana alert 550e8400-e29b-41d4-a716-446655440000 view --section atlas
      torana alert 550e8400-e29b-41d4-a716-446655440000 view --section exposure-path
      torana alert 550e8400-e29b-41d4-a716-446655440000 view --section path
      torana alert 550e8400-e29b-41d4-a716-446655440000 view --section verdict --all-reasons
      torana alert 550e8400-e29b-41d4-a716-446655440000 view --section history --history-limit 20
      torana alert 550e8400-e29b-41d4-a716-446655440000 view --section history --history-before '<cursor>'

    Related: `alert <id> members` (the findings behind an entry), `alert <id> proof`, `alerts list`.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    ctx.meta["torana_all_reasons"] = all_reasons

    aid = _aid(ctx)
    client = _client(ctx)
    wanted = [_api_section_key(k) for k in sections_wanted]
    params = {"section": wanted} if wanted else {}
    if history_limit:
        params["history_limit"] = history_limit
    if history_before:
        params["history_before"] = history_before
    try:
        data = client.get(f"alerts/{aid}/view", params=params or None)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text" or fields or not isinstance(data, dict):
        output(data, fmt=fmt, fields=fields)
        return

    head = data.get("header") or {}
    sections = data.get("sections") or {}
    # A platform that has not been updated sends only the previous keys: read those.
    order = data.get("order_v2") or data.get("order") or []

    click.echo("")
    click.echo(head.get("name") or "")
    bits = [b for b in [
        # ⚠️ The FINDING's severity when the platform records one — that is what the Inbox shows
        # (`findingSeverity()`); the alert's own `severity` can differ ("high" vs "Critical").
        # The platform's own words when it sends them (the screen's labels); else the previous output.
        *_level_bits(head),
        head.get("verdict_label"),
        sw.box_word(head),
        head.get("status_label") or head.get("status"),
        _sla_bit(head),
        team_words(head),
    ] if b]
    bits = dedupe_adjacent(bits)
    if bits:
        click.echo("  ·  ".join(str(b) for b in bits))
    if head.get("closed_by_line"):                 # who closed it and why, in the platform's words, with the day
        click.echo(str(head["closed_by_line"]) + (f"  ·  {local_day(head.get('closed_at'))}" if head.get("closed_at") else ""))
    # Where the deadline comes from, in the platform's words ("High deadline: 30 days, from the app's priority 12"); nothing when it states none.
    if head.get("deadline_basis"):
        click.echo(str(head["deadline_basis"]))
    # The status band (the platform's words): a finding's triage retry, or an entry's summary of its findings' retries.
    for band in (head.get("retry"), head.get("retries")):
        if isinstance(band, dict) and band.get("template"):
            click.echo(band_text(band, _view_time, aid))
    # The rest of the Inbox header (EM A-03): priority, who holds it, when it was made and last changed.
    meta = _view_meta_bits(head)
    if meta:
        click.echo("  ·  ".join(meta))
    # The fix plan in one line, and once its PR merged whether a scan has looked since (I-90): the Inbox header shows both.
    fix_line = fix_plan_line(head.get("fix_plan"), _fix_plan_decider(client, head.get("fix_plan")))
    if fix_line:
        click.echo(fix_line)
    _fs = head.get("fix_status")
    if isinstance(_fs, dict) and _fs.get("lines"):
        _fl = [_line_value(x) for x in _fs["lines"]]
        click.echo(" ".join([_fl[0].rstrip(".") + ".", *_fl[1:]]))

    for sid in order:
        if sid in ("header", "activity", "history"):
            continue
        body = sections.get(sid)
        if not body:
            continue
        # The decider / proposer is the section's header, never repeated as a line (release T1-19).
        attribution = f"  — {body['attribution']}" if body.get("attribution") else ""
        click.echo("")
        click.echo(f"{_view_heading(sid, body)}{attribution}")
        _print_description(body)
        _print_section_body(sid, body)

    if not data.get("cve_intel_available", True):
        click.echo("")
        click.echo("  (the threat-intel table could not be read: CVE details are missing)")

    activity = data.get("activity") or []
    history = sections.get("history")
    if show_activity and ("history" in order or "activity" in order) and (activity or history):
        click.echo("")
        click.echo(f"{_VIEW_HEADINGS['history']}")
        _print_description(history)
        if history and not history.get("empty"):
            for row in history.get("lines") or []:
                _print_view_line(row)
        # The events as the server words them (history.events); an older server sends only the raw activity rows.
        events = (history or {}).get("events") if isinstance(history, dict) else None
        if events is None:
            events = [{"at": r.get("timestamp") or r.get("created_at"), "who": _activity_actor(r),
                       "what": r.get("activity_type") or "", "text": (r.get("message") or "").replace("\n", " ")}
                      for r in activity]
        for ev in events:
            if ev.get("sentence"):
                # The platform words the line (one map, the screen's words): who by source, then the sentence.
                line = " ".join(str(ev["sentence"]).split())            # one line; the full text is in --format json
                line = line if len(line) <= 160 else line[:159].rstrip() + "…"
                click.echo(f"  {_view_time(ev.get('at')):<18} {ev.get('actor_label') or ev.get('who') or '':<18} {line}")
                continue
            click.echo(f"  {_view_time(ev.get('at')):<18} {ev.get('who') or '':<18} {ev.get('what') or '':<20} {(ev.get('text') or '')[:90]}")
        more = history_more_line(history, aid)
        if more:
            click.echo(more)

    total = data.get("members_total") or 0
    if total and not wanted:
        click.echo("")
        click.echo(f"  {total} finding(s) in this group — torana alert {aid} members")
    click.echo("")


with_sections_help(alert_inbox, "item")


@alert.command(name="graph")
@click.pass_context
def alert_graph(ctx):
    """Alert context graph — the entities this alert references, and their relationships.

    \b
      torana alert <UUID> graph
      torana alert <UUID> entities    # just the entity summary, no relationships
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"api/graph/alert/{_aid(ctx)}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="entities")
@click.pass_context
def alert_entities(ctx):
    """Alert entity summary — which entities this alert's results reference.

    \b
      torana alert <UUID> entities
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"api/graph/alert/{_aid(ctx)}/entities")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="proof")
@_tenant_read_option
@click.option("--claim", "claim_id", default=None, metavar="CLAIM_ID",
              help="Trace one claim: every row, selection, column meaning and rule output behind it.")
@click.option("--save", "save_path", default=None, metavar="FILE", type=click.Path(dir_okay=False),
              help="Also write the proof record (JSON) to FILE, for `torana datalake proof verify|replay`.")
@click.pass_context
def alert_proof(ctx, claim_id, save_path):
    """Show the proof for this alert: each claim and the rows, rules and meanings behind it.

    Every value in a claim points at what it was read from (a datalake row, a selection, a column
    meaning, the build clock, or a rule output), so it can be traced, replayed and re-verified. The header
    line names the item type. Modelled: vuln_in_image (a CVE finding on a container image), fix_entry and
    mitigation_entry (also an Inbox entry "Upgrade X" / "Mitigate X" for one package), threat_signal,
    posture_summary, code_finding (a SAST, IaC or secrets finding in one file of a repository: its state, lines,
    rule, whether the code ships to running services, and its owner), group_check (an alert that stands for a group its
    rule declared: how many rows it covers and how many are open); each also carries the alert's own facts.
    Any other item answers "No proof model for this item type yet" (not modelled, not "no evidence"). Read-only.

    \b
    Examples:
      torana alert <UUID> proof
      torana alert <UUID> proof --claim stale
      torana alert <UUID> proof --save /tmp/proof.json
      torana alert <UUID> proof --format json
      torana alert <UUID> proof --tenant <TENANT_ID> --save /tmp/proof.json   # super admin, another tenant
    """
    from torana_cli import proof_view

    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        rec = client.get(f"datalake/proof/alerts/{_aid(ctx)}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if save_path:
        proof_view.save(save_path, rec)
    if claim_id and claim_id not in proof_view.claim_ids(rec):
        click.echo(f"ERROR: no claim '{claim_id}' on this item. Claims: "
                   f"{', '.join(proof_view.claim_ids(rec)) or '(none)'}", err=True)
        ctx.exit(2)
    if fmt not in ("text", "table"):
        output(rec, fmt=fmt)
    elif claim_id:
        proof_view.echo(proof_view.claim_lines(rec, claim_id))
    else:
        proof_view.echo(proof_view.record_lines(rec))


@alert.command(name="assessment")
@_tenant_read_option
@click.pass_context
def alert_assessment(ctx):
    """Show this item's assessments: the effort estimate, and how strong the evidence behind it is.

    An assessment answers a question about the item that no row states. Today the question is effort: a range of
    days for an upgrade (fix_entry) or a code finding (code_finding), computed by the platform from rows it already
    holds. It is marked "◈ assessed": an estimate, never a proven fact. Under the line: "Based on N checks. K more are
    not available yet."; "How we got this", one row per part (edit, review, test, rollout) with its reason and days, their sum, and
    one sentence on why it is a range; "What it rests on", the checks that are in; "Not checked yet:", the missing checks, each
    with what is not known ("*" marks the ones that matter most to accuracy). The platform cannot run those yet: an
    instruction is printed only under "What you can do now", when there is something you can act on.

    The estimate is the platform's. Quote it as printed; never restate, round or recompute it. An item type with no
    assessment yet (a mitigation, a vulnerability in an image) prints so and exits 3. Read-only.

    \b
    Examples:
      torana alert <UUID> assessment
      torana alert <UUID> assessment --format json
      torana alert <UUID> assessment --tenant <TENANT_ID>   # super admin, another tenant
    """
    from torana_cli import assessment_view

    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        body = client.get(f"datalake/proof/alerts/{_aid(ctx)}/assessment")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt not in ("text", "table"):
        output(body, fmt=fmt)
    elif not body.get("assessments"):
        click.echo(assessment_view.no_assessment(body))
    else:
        click.echo("\n".join(assessment_view.body_lines(body)))
    if not body.get("assessments"):
        ctx.exit(3)


def _brief_run(ctx, workspace_id, write, wait):
    """Show the AI brief for this alert, or with `write` write a new one (and with `wait` wait for it)."""
    from torana_cli import brief_view

    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    aid = _aid(ctx)
    try:
        ws = workspace_id or (ctx.obj or {}).get("_workspace_id") or brief_view.alert_workspace(client, aid)
        if not ws:
            click.echo("ERROR: this alert has no workspace; pass --workspace <WORKSPACE_ID>.", err=True)
            ctx.exit(2)
        if write:
            started = brief_view.write(client, ws, aid)
            if not wait:
                click.echo(f"Writing brief {started['brief_id']}. Show it with: torana alert {aid} brief")
                return
            row = brief_view.wait(client, ws, aid, started["brief_id"])
            latest = {"latest_ready": row if row["status"] == "ready" else None, "in_flight": None, "latest": row}
        else:
            latest = brief_view.latest(client, ws, aid)
            if latest is None:
                click.echo(f"No brief yet. Write one with: torana alert {aid} brief write --wait")
                ctx.exit(3)
        check = brief_view.check(client, ws, aid, latest)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt not in ("text", "table"):
        output({**latest, "staleness": check}, fmt=fmt)
    else:
        click.echo("\n".join(brief_view.lines(latest, check, aid)))


_BRIEF_WORKSPACE = click.option("--workspace", "workspace_id", default=None, metavar="WORKSPACE_ID",
                                help="The app (workspace) the item belongs to. Default: the alert's own workspace.")


def _brief_flag_moved(value, flag):
    """`brief --write` and `brief --wait` are gone: reading a brief never writes one. Exit 2 and say where the write went."""
    if value:
        raise click.UsageError(f"`brief {flag}` no longer exists: `brief` only reads. To write a new brief use `brief write` "
                               "(add `--wait` there to wait for it).")
    return value


@alert.group(name="brief", invoke_without_command=True)
@_BRIEF_WORKSPACE
@click.option("--write", "write", is_flag=True, hidden=True, expose_value=False, callback=lambda c, p, v: _brief_flag_moved(v, "--write"))
@click.option("--wait", "wait", is_flag=True, hidden=True, expose_value=False, callback=lambda c, p, v: _brief_flag_moved(v, "--wait"))
@click.pass_context
def alert_brief(ctx, workspace_id):
    """Show the AI brief for this alert: proven claims in prose, each sentence with the claims it cites.

    Reading a brief changes nothing. To write a new one (one AI call, about a minute) use `brief write`.

    A brief is written by one AI call over this item's proven claims only, and checked by code: every
    number, id and name in a sentence must appear in a claim it cites. Shown against the item's proof as
    it is NOW: a sentence whose claims changed since it was written is marked "◇ claims changed since
    written"; one whose claim only aged (e.g. "37.9 hours ago") is dated "as of <build time>".

    \b
    Examples:
      torana alert <UUID> brief
      torana alert <UUID> brief --format json
      torana alert <UUID> brief write --wait
    """
    if ctx.invoked_subcommand is not None:
        ctx.meta["torana_brief_workspace"] = workspace_id
        return
    _brief_run(ctx, workspace_id, False, False)


@alert_brief.command(name="get")
@_BRIEF_WORKSPACE
@click.pass_context
def alert_brief_get(ctx, workspace_id):
    """Show the latest AI brief for this alert (the same as `brief`). Changes nothing."""
    _brief_run(ctx, workspace_id or ctx.meta.get("torana_brief_workspace"), False, False)


@alert_brief.command(name="write")
@_BRIEF_WORKSPACE
@click.option("--wait", "wait", is_flag=True,
              help="Check every 5 s until the brief is ready or failed (up to 10 minutes).")
@click.pass_context
def alert_brief_write(ctx, workspace_id, wait):
    """Write a NEW AI brief for this alert: one AI call over its proven claims (about a minute).

    This starts work and stores a new brief, which is why it is its own command; `brief` only reads.

    \b
    Examples:
      torana alert <UUID> brief write
      torana alert <UUID> brief write --wait
    """
    _brief_run(ctx, workspace_id or ctx.meta.get("torana_brief_workspace"), True, wait)


@alert.command(name="status")
@click.option("--status", "status", type=click.Choice(["closed", "resolved"], case_sensitive=False),
              required=True,
              help="Close the item: closed or resolved. This command only closes. To reopen "
                   "use `reopen`; to escalate, `escalate`; to give a verdict, `verdict`; "
                   "to send it to the agent, `assign --assignee-type agent`.")
@click.option("--resolution-reason", "resolution_reason",
              # Rows 3.2 / 3.27: a person's six. auto_resolved is the platform's default
              # for a closure given no reason, and the API refuses it from a person.
              callback=lambda _c, _p, v: v.strip().lower() if v else v,
              default=None,
              help="Reason for alert closure. Recorded on the Alert row; typically set together with --status closed. "
                   "The platform checks it and a wrong one names the reasons it accepts; `torana alerts labels` lists them with their words.")
@click.option("--message", "message", default=None)
@click.pass_context
def alert_status(ctx, status, resolution_reason, message):
    """Close an item, recording you as who closed it.

    The item moves to the Closed box. The finding itself is not changed. A closed item
    is refused with the reason (HTTP 409). `torana alert <id> close --reason <reason>` does the
    same thing under a plainer name.

    \b
    Examples:
      torana alert <id> status --status closed --resolution-reason accepted_risk --message "Compensating control in place"
      torana alert <id> status --status resolved --resolution-reason fixed
      torana alert <id> status --status closed --resolution-reason false_positive
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/status"
    body = {}
    body["status"] = status
    if resolution_reason is not None:
        body["resolution_reason"] = resolution_reason
    if message is not None:
        body["message"] = message

    client = _client(ctx)
    try:
        data = client.put(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="close")
@click.option("--reason", "resolution_reason", required=True,
              callback=lambda _c, _p, v: v.strip().lower() if v else v,
              help="Why it is closed. Recorded on the item and shown as the reason it is closed. The platform checks it and a wrong one "
                   "names the reasons it accepts; `torana alerts labels` lists them (person_close_reasons) with their words.")
@click.option("--message", "message", default=None, help="A note recorded with the closure.")
@click.pass_context
def alert_close(ctx, resolution_reason, message):
    """Close an item, recording you as who closed it and why.

    The plain form of `torana alert <id> status --status closed --resolution-reason <reason>`: the same
    permission, the same history line, the same result. The item moves to the Closed box; the finding
    itself is not changed. To open it again use `reopen`.

    \b
    Examples:
      torana alert <id> close --reason wont_fix
      torana alert <id> close --reason accepted_risk --message "Compensating control in place"
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    body = {"status": "closed", "resolution_reason": resolution_reason}
    if message is not None:
        body["message"] = message
    client = _client(ctx)
    try:
        data = client.put(f"alerts/{_aid(ctx)}/status", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields)


def _person_action(ctx, verb: str, message):
    """POST alerts/<id>/<verb> with an optional note, and print the item it returns."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    body = {"message": message} if message is not None else {}
    client = _client(ctx)
    try:
        data = client.post(f"alerts/{_aid(ctx)}/{verb}", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt == "text" and not fields and isinstance(data, dict):
        _print_alert_head(data)
        return
    output(data, fmt=fmt, fields=fields)


@alert.command(name="reopen")
@click.option("--message", "message", default=None, help="Why, for the item's history.")
@click.pass_context
def alert_reopen(ctx, message):
    """Reopen a closed item.

    It goes back to Active. The verdict a platform closure replaced comes back,
    and the item is pending_remediation when that verdict is true positive, otherwise
    open. Reopening a platform closure stops the platform closing it again for the same
    reason. The closure stays in its history. Refused (HTTP 409) on an item that is not
    closed.

    \b
    Example:
      torana alert <id> reopen --message "Still reported by the scanner"
    """
    _person_action(ctx, "reopen", message)


@alert.command(name="ask-atlas")
@click.option("--refresh", is_flag=True, default=False,
              help="Re-check where this comes from, for ONE finding, even when it already has Atlas's answer: Atlas "
                   "reads its stored code facts again (no AI model runs, nothing is charged). If the answer has "
                   "changed it replaces the stored one and the item's history records old → new; otherwise the "
                   "stored answer stays. Refused on a fix row.")
@click.pass_context
def alert_ask_atlas(ctx, refresh):
    """Ask Atlas now where a package finding's version comes from, without a triage.

    On a fix row (an entry, e.g. "Upgrade aiohttp to 3.14.4") it asks for the row's open
    findings that have no Atlas answer yet; on a finding, for that finding. Pypi package
    findings only, at most 100 per call (`remaining` says how many are left: run it again).
    Free and model-free; nothing else changes (no verdict, status or remediation). The
    answers fill the row's "Where the shipped version is set" (`view --section how-to-fix`). The platform
    also asks on its own within a few minutes; this is for "now".

    \b
    Example:
      torana alert <entry id> ask-atlas
      torana alert <entry id> view --section how-to-fix
      torana alert <finding id> ask-atlas --refresh        # re-check a stored answer
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    try:
        kw = {"params": {"refresh": "true"}} if refresh else {}
        data = _client(ctx).post(f"alerts/{_aid(ctx)}/ask-atlas", json={}, **kw)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt == "text" and not fields and isinstance(data, dict):
        click.echo(data.get("words") or "")         # the platform's sentence, verbatim
        return
    output(data, fmt=fmt, fields=fields)


@alert.command(name="keep-closed")
@click.option("--message", "message", default=None, help="Why, for the item's history.")
@click.pass_context
def alert_keep_closed(ctx, message):
    """Agree with a closure the platform made, so it becomes yours.

    Status, reason and verdict stay as they are, and the platform never reopens it. Refused (HTTP 409) on an open item and on one a person
    already closed.

    \b
    Example:
      torana alert <id> keep-closed --message "Confirmed decommissioned"
    """
    _person_action(ctx, "keep-closed", message)


@alert.command(name="severity")
@click.option("--severity", "severity", type=click.Choice(["low", "medium", "high", "critical"], case_sensitive=False), required=True)
@click.option("--message", "message", default=None)
@click.pass_context
def alert_severity(ctx, severity, message):
    """Change an item's severity (low, medium, high or critical) and record why.

    Use this when the severity the platform computed is wrong for this item and a person has judged it. The change is recorded in
    the item's history with your name and the message. It changes the item's urgency and SLA, not its verdict or status.

    \b
    Output:
      The updated item.

    \b
    Related:
      torana alert <UUID> verdict    say whether the finding is real
      torana alerts sla-policy get   the hours each severity allows

    \b
    Examples:
      torana alert <UUID> severity --severity high --message "Internet-facing in production"
      torana alert <UUID> severity --severity low
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/severity"
    body = {}
    body["severity"] = severity
    if message is not None:
        body["message"] = message

    client = _client(ctx)
    try:
        data = client.put(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="assign")
@click.option("--assigned-to", "assigned_to", required=True)
@click.option("--assignee-type", "assignee_type", type=click.Choice(["user", "agent", "unassigned"], case_sensitive=False), default=None, help="Type of assignee (user or agent).")
@click.option("--assignee-display-name", "assignee_display_name", default=None, help="Human-readable name of the assignee, stored alongside UUID for display")
@click.option("--message", "message", default=None)
@click.pass_context
def alert_assign(ctx, assigned_to, assignee_type, assignee_display_name, message):
    """Assign this alert to a person or to an agent.

    A person is a USER IN THIS TENANT, given as their UUID or their email address; the
    platform stores the UUID. Anything else (a team or queue name, another tenant's address)
    is refused with 422 and the valid forms. To clear the assignee use `unassign`.

    \b
    Examples:
      torana alert <UUID> assign --assigned-to jay@acme.com
      torana alert <UUID> assign --assigned-to <user-uuid> --message "taking this one"
      torana alert <UUID> assign --assigned-to <agent-uuid> --assignee-type agent
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/assign"
    body = {}
    body["assigned_to"] = assigned_to
    if assignee_type is not None:
        body["assignee_type"] = assignee_type
    if assignee_display_name is not None:
        body["assignee_display_name"] = assignee_display_name
    if message is not None:
        body["message"] = message

    client = _client(ctx)
    try:
        data = client.put(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


def _move_member(ctx, entry_id):
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.put(f"alerts/{_aid(ctx)}/entry", json={"entry_id": entry_id})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields)


@alert.command(name="move")
@click.argument("entry_id")
@click.pass_context
def alert_move(ctx, entry_id):
    """Move this member to another Inbox entry.

    The choice stays until a person changes it: no later sighting or grouping change undoes it.
    Both entries are recomputed (severity, priority, version, title, status) in the same step,
    and each side records an activity line.

    \b
    Example:
      torana alert <member-UUID> move <entry-UUID>
    """
    _move_member(ctx, entry_id)


@alert.command(name="split")
@click.pass_context
def alert_split(ctx):
    """Split this member out of its entry so it is its own Inbox entry.

    The choice stays until a person changes it. The member takes the owner of the entry it left
    (unless a person chose its owner), and both are recomputed.

    \b
    Example:
      torana alert <member-UUID> split
    """
    _move_member(ctx, None)


@alert.command(name="unassign")
@click.option("--message", "message", default=None,
              help="Why, recorded in the item's activity.")
@click.pass_context
def alert_unassign(ctx, message):
    """Clear this alert's assignee, leaving it unassigned.

    Sends assignee_type=unassigned with an empty assignee, which the platform stores as no
    assignee (NULL). The item's status and verdict are not changed.

    \b
    Examples:
      torana alert <UUID> unassign
      torana alert <UUID> unassign --message "back to the queue"
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    body = {"assigned_to": "", "assignee_type": "unassigned"}
    if message is not None:
        body["message"] = message

    client = _client(ctx)
    try:
        data = client.put(f"alerts/{aid}/assign", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="comment")
@click.option("--comment", "comment", required=True)
@click.pass_context
def alert_comment(ctx, comment):
    """Leave a comment on an item, shown in its history under your name.

    Use this for a note to whoever opens the item next: what you checked, why you decided, what is still unknown. A comment does
    not change the item's status, verdict or assignee. Write plain words; a person reads it.

    \b
    Output:
      The new history entry.

    \b
    Related:
      torana alert <UUID> activities               read the comments and everything else
      torana alert <UUID> question --question ...  ask the item's agent something instead

    \b
    Examples:
      torana alert <UUID> comment --comment "Checked with the owner: this service is retired next month"
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/comments"
    body = {}
    body["comment"] = comment

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


def entry_verdict_lines(data, verdict: str):
    """The text for a verdict that was applied to an ENTRY's open members: how many findings took
    it, then each refused finding with its reason (never silent). None when `data` is not that."""
    if not isinstance(data, dict) or data.get("status") != "applied_to_members":
        return None
    n = int(data.get("applied") or 0)
    words = verdict.replace("_", " ")
    lines = [f"Confirmed {n} finding{'' if n == 1 else 's'} as {words}."]
    refused = data.get("refused") or []
    if refused:
        lines.append(f"{len(refused)} finding{' was' if len(refused) == 1 else 's were'} refused:")
        lines += [f"  {str(r.get('member_id', ''))[:8]}: {r.get('reason', '')}" for r in refused]
    return lines


@alert.command(name="verdict")
@click.option("--triage-verdict", "triage_verdict", required=True,
              type=click.Choice(["true_positive", "false_positive", "benign", "inconclusive"],
                                case_sensitive=False),
              help="Triage classification verdict.")
@click.option("--triage-summary", "triage_summary", default=None,
              help="Summary of triage findings")
@click.option("--message", "message", default=None,
              help="Optional message to record with the verdict")
@click.option("--reason-code", "reason_code", default=None,
              help="WHY this verdict was reached — one code from `torana alerts reason-codes` (run it to see every ground, "
                   "the verdicts each accompanies and what each says). Optional for a person; the triage agent must supply one "
                   "once guards are on. A code that does not accompany this verdict is refused, naming the ones that do. "
                   "The grounds that say the AGENT read the code or the record (agent_confirmed_by_analysis, "
                   "agent_confirmed_from_record) describe the agent's own work: they are for the triage agent, so as a person "
                   "give the ground you actually rest on and put what you found in --verdict-evidence.")
@click.option("--proposed-fix", "proposed_fix", default=None,
              help="One sentence a developer can act on, e.g. 'Upgrade lodash 4.17.20 to 4.17.21'. "
                   "Shown on the alert; NOT the same field as remediation_summary, which the "
                   "remediation service overwrites with the pull-request reference.")
@click.option("--verdict-evidence", "verdict_evidence", default=None,
              help="What you found and where (the document, the control, the precondition). "
                   "Required when the reason code closes on evidence the platform does not "
                   "hold (ground `new_evidence` in `torana alerts reason-codes`); omit it "
                   "otherwise. Shown on the alert for a person to judge.")
@click.option("--resolution-reason", "resolution_reason", default=None,
              type=click.Choice(["fixed", "accepted_risk", "false_positive", "benign",
                                 "duplicate", "wont_fix", "auto_resolved"],
                                case_sensitive=False),
              help="Override the default resolution reason on a closing verdict.")
@click.option("--remediation-action", "remediation_action", default=None,
              help="WHAT to do about a confirmed finding (true_positive only): upgrade, "
                   "roll_back (a downgrade to an older version), mitigate, fix, configure, "
                   "rotate, rebuild, accept or none. accept and none "
                   "are recorded and take no target (they close nothing). See `torana alerts remediation-vocabulary`.")
@click.option("--remediation-target-type", "remediation_target_type", default=None,
              help="WHAT it is done to: package, code_location, service, image, config_setting "
                   "or secret. Which types each action takes is in the vocabulary. The platform "
                   "takes the target's identity from the finding; do not supply it.")
@click.option("--remediation-target-version", "remediation_target_version", default=None,
              help="The version to move to. Only for upgrade, roll_back and rebuild.")
@click.option("--follow-up-action", "follow_up_actions", multiple=True,
              help="One plain-word action the verdict asks of people: who should act and what "
                   "they do. Repeat for several. Allowed on any verdict.")
@click.option("--continuity-note", "continuity_note", default=None,
              help="Three to five sentences for the next triage of this finding: what decided "
                   "this verdict and what new fact would change it. Allowed on any verdict.")
@click.option("--assign-to", "--assignee", "assignee", default=None,
              help="On a true-positive verdict: the person who should own the finding (a user "
                   "UUID or email in this tenant). Omit it and the tenant admin owns it.")
@click.pass_context
def alert_verdict(ctx, triage_verdict, triage_summary, message, reason_code, proposed_fix,
                  verdict_evidence, resolution_reason, remediation_action,
                  remediation_target_type, remediation_target_version, follow_up_actions,
                  continuity_note, assignee):
    """Set the triage verdict on this alert.

    \b
    Examples:
      torana alert <UUID> verdict --triage-verdict true_positive \\
        --reason-code exposed_and_fixable \\
        --proposed-fix "Upgrade lodash 4.17.20 to 4.17.21"
      torana alerts reason-codes          # the grounds a verdict may cite
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/verdict"
    body = {}
    body["triage_verdict"] = triage_verdict
    if triage_summary is not None:
        body["triage_summary"] = triage_summary
    if message is not None:
        body["message"] = message
    if reason_code is not None:
        body["reason_code"] = reason_code
    if proposed_fix is not None:
        body["proposed_fix"] = proposed_fix
    if verdict_evidence is not None:
        body["verdict_evidence"] = verdict_evidence
    if resolution_reason is not None:
        body["resolution_reason"] = resolution_reason.lower()
    if follow_up_actions:
        body["follow_up_actions"] = list(follow_up_actions)
    if continuity_note is not None:
        body["continuity_note"] = continuity_note
    if assignee is not None:
        body["assignee"] = assignee
    for _k, _v in (("remediation_action", remediation_action),
                   ("remediation_target_type", remediation_target_type),
                   ("remediation_target_version", remediation_target_version)):
        if _v is not None:
            body[_k] = _v

    client = _client(ctx)
    try:
        data = client.put(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # The platform may RECORD the verdict rather than apply it, when the tenant's
    # triage-autonomy policy says a person decides. That is a success, not a failure —
    # say so plainly instead of printing a bare {"status": "recommended"}.
    if fmt == "text" and isinstance(data, dict) and data.get("status") == "recommended":
        click.echo(f"Recommended (autonomy level {data.get('autonomy_level', 'Manual')}); "
                   f"a person must confirm it.")
        return

    # A verdict on an ENTRY is applied to its open members: say how many, and name every refusal.
    entry_lines = entry_verdict_lines(data, triage_verdict) if fmt == "text" else None
    if entry_lines:
        for line in entry_lines:
            click.echo(line)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="invoke")
@click.pass_context
def alert_invoke(ctx):
    """Invoke Triage."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/triage/invoke"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # ⚠️ TEXT ONLY, and the asymmetry is deliberate. The response model carries every field
    # so JSON keeps a stable shape, but an outcome legitimately holds fewer facts than the
    # model can — `already_recorded` has no verdict and no priority at all — and a reader
    # shown "PRIORITY KEPT BY  None" reads None as the answer rather than as "this outcome
    # has no such fact". Measured on demo: a second write at the same commit printed four.
    if fmt == "text" and isinstance(data, dict):
        data = {k: v for k, v in data.items() if v is not None}

    output(data, fmt=fmt, fields=fields)


#: The item states in which a triage run is already in flight: asking again changes nothing.
_TRIAGE_IN_FLIGHT = ("triaging", "queued")
#: The platform's own "a run is in flight" sentences (detection-framework `decide_action` RERUN_TRIAGE: "this item is
#: already triaging|queued for the agent"; the invoke route: "Triage already running for this alert"). Matched exactly:
#: "a person has already judged this item" also contains "already" and is a REFUSAL, never a state (review BLOCKER).
_IN_FLIGHT_WORDS = re.compile(r"\balready (triaging|queued|running)\b", re.I)
#: The grants that let a caller cross tenants, copied from the platform's one rule
#: (pantheon-shared `iam/context.py` CROSS_TENANT_ROLES / CROSS_TENANT_PERMISSIONS). The rule's other half, "and the
#: caller's HOME tenant is the platform tenant" (OI-28), is the server's: a customer tenant's own super_admin is sent
#: through the same `--tenant` + act-as ceremony, which the platform accepts for its own tenant and does not audit.
_CROSS_TENANT_ROLES = frozenset({"super_admin", "system_admin"})
_CROSS_TENANT_PERMISSIONS = frozenset({"tenants:read_all", "users:read_all", "users:manage_all", "system:admin"})


def _has_cross_tenant_grant(client) -> bool:
    """Whether the logged-in identity holds a grant that crosses tenants (the roles and permissions `torana auth me`
    prints), judged by the platform's own list. The server decides for real on every request."""
    me = client.get("auth/me") or {}                # same path `torana auth me` uses
    roles = set(me.get("roles") or []) if isinstance(me.get("roles"), list) else set()
    perms = set(me.get("permissions") or []) if isinstance(me.get("permissions"), list) else set()
    return bool(roles & _CROSS_TENANT_ROLES or perms & _CROSS_TENANT_PERMISSIONS)


def _in_flight_state(status: str) -> str:
    return "already_queued" if "queued" in (status or "").lower() else "already_running"


@alert.command(name="triage")
@click.option("--tenant", "tenant_id", default=None, metavar="TENANT_ID",
              help="Super admin only, and REQUIRED for a super admin: the tenant that holds this item. Declare the write "
                   "too: `torana --act-as-tenant <TENANT_ID> --act-as-reason \"<why>\" alert <ID> triage --tenant "
                   "<TENANT_ID>`. A tenant user never names a tenant: its own items only.")
@click.pass_context
def alert_triage(ctx, tenant_id):
    """Ask the workspace's triage agent to look at this item, now (the Inbox's "Re-run triage").

    Idempotent against the item's state: a run already queued or running is reported, not started twice; a closed
    item, a platform entry (triage runs on its members) and an item a person already judged are refused with the
    platform's own sentence. The run is queued and answers at once; its outcome lands on the item (`view`, `activities`).
    The item is read first; a job enqueued but not yet claimed (the item still reads open) is caught by the platform's
    own dedup, which answers "already queued" to a second ask.

    \b
    Who may run it:
      A tenant user   its own tenant's items only; naming another tenant is refused by the platform (403).
      A super admin   must name the tenant (--tenant) AND declare the write with the root flags
                      --act-as-tenant / --act-as-reason, which the platform audits (`torana audit-logs`).
                      (A grant the platform confines to its own tenant goes through the same ceremony; the platform
                      accepts it for that tenant and refuses any other.)

    \b
    Exit codes:
      0  started, or already queued / running (nothing changed)
      1  refused by the platform (closed, an entry, a person's verdict stands, no triage agent)
      2  usage: a super admin without --tenant, or --tenant without the matching --act-as-tenant
      4  a tenant user named a tenant
      other codes: the standard table (3 no such item in that tenant, 5 not logged in)

    \b
    Examples:
      torana alert 550e8400-e29b-41d4-a716-446655440000 triage
      TORANA_PROFILE=SA torana --act-as-tenant <TENANT_ID> --act-as-reason "customer asked" \\
          alert 550e8400-e29b-41d4-a716-446655440000 triage --tenant <TENANT_ID>
    """
    from torana_cli.client.base import EXIT_PERMISSION, EXIT_USAGE, _act_as

    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    aid = _aid(ctx)
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    client = ToranaClient(base_url=get_settings(profile).base_url)
    params = {"tenant_id": tenant_id} if tenant_id else None

    try:
        # ── who is asking: the rules are the platform's; the CLI states them before sending anything ──
        if _has_cross_tenant_grant(client):
            if not tenant_id:
                click.echo("Error: an account that may cross tenants (a super admin) must name the tenant that holds "
                           "this item: --tenant <TENANT_ID>, with `torana --act-as-tenant <TENANT_ID> --act-as-reason "
                           "\"<why>\"` in front.", err=True)
                sys.exit(EXIT_USAGE)
            declared, reason = _act_as()
            if declared != tenant_id or not (reason or "").strip():
                click.echo(f"Error: triage changes tenant {tenant_id}: declare it with "
                           f"`torana --act-as-tenant {tenant_id} --act-as-reason \"<why>\" alert {aid} triage "
                           f"--tenant {tenant_id}`.", err=True)
                sys.exit(EXIT_USAGE)
        elif tenant_id:
            click.echo("Error: --tenant is for a super admin. A tenant user may only ask for triage on its own "
                       "tenant's items: run it without --tenant.", err=True)
            sys.exit(EXIT_PERMISSION)

        # ── the item's state first: a run in flight is reported, never started twice ──
        current = client.get(f"alerts/{aid}", params=params) or {}
        status = str(current.get("status") or "").lower()
        if current.get("triage_running") or status in _TRIAGE_IN_FLIGHT:
            word = status if status in _TRIAGE_IN_FLIGHT else "running"
            data = {"alert_id": aid, "status": _in_flight_state(word),
                    "message": f"Triage is already {word} for this item; nothing was changed."}
            if fmt == "text":
                click.echo(data["message"])
            else:
                output(data, fmt=fmt, fields=fields)
            return

        data = client.post(f"alerts/{aid}/triage/invoke", json={}, params=params)
    except APIError as e:
        # The platform's own "already in flight" answer (a run queued between the read and the write) is a state,
        # not a failure: the same words and exit code as the pre-check.
        words = e.detail.get("message") if isinstance(e.detail, dict) else e.detail
        hit = _IN_FLIGHT_WORDS.search(str(words or "")) if e.status_code == 409 else None
        if hit:
            text = f"{str(words).rstrip('.')}; nothing was changed."
            if fmt == "text":
                click.echo(text)
            else:
                output({"alert_id": aid, "status": _in_flight_state(hit.group(1)), "message": text}, fmt=fmt, fields=fields)
            return
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt == "text" and isinstance(data, dict):
        state = data.get("status")
        words = {"accepted": "Triage started: the workspace's triage agent will look at this item; its outcome lands "
                             "on the item (`view`, `activities`).",
                 "already_queued": "Triage is already queued for this item; nothing was changed."}.get(state)
        click.echo(words or data.get("message") or str(data))
        return
    output(data, fmt=fmt, fields=fields)


@alert.command(name="cancel")
@click.pass_context
def alert_cancel(ctx):
    """Cancel Triage."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/triage/cancel"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="question")
@click.option("--question", "question", required=True, help="Question to ask about the alert")
@click.option("--thread-id", "thread_id", default=None, help="Optional thread ID to group related questions")
@click.option("--parent-activity-id", "parent_activity_id", default=None, help="Optional parent activity ID for reply threading")
@click.pass_context
def alert_question(ctx, question, thread_id, parent_activity_id):
    """Ask the item's triage agent a question; the answer arrives in the item's history.

    Use this to ask why the agent decided as it did, or to ask it to look again. The question is recorded at once and the answer
    is produced afterwards, so this returns before the answer exists. Read it with `activities`, or in the History section of
    `inbox`. The agent answers only when the item is assigned to one; otherwise the question waits as a note.

    \b
    Output:
      The ids of the recorded question (activity_id and thread_id). Use the thread_id to follow up.

    \b
    Related:
      torana alert <UUID> activities --thread-id <THREAD>   read the answer
      torana alert <UUID> comment --comment "..."            leave a note without asking anything

    \b
    Examples:
      torana alert <UUID> question --question "Why is this reachable from the internet?"
      torana alert <UUID> question --question "And in staging?" --thread-id <THREAD>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/question"
    body = {}
    body["question"] = question
    if thread_id is not None:
        body["thread_id"] = thread_id
    if parent_activity_id is not None:
        body["parent_activity_id"] = parent_activity_id

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="remediation")
@click.option("--remediation-instructions", "remediation_instructions", required=True, help="Instructions or description of remediation actions to take")
@click.option("--auto-remediate", "auto_remediate", type=bool, default=False, help="Whether to attempt automatic remediation")
@click.pass_context
def alert_remediation(ctx, remediation_instructions, auto_remediate):
    """Record the plan for fixing an item, in the item's history. It does not open a pull request or change the item's status.

    Use this to write down what is being done about the item and by whom, so the next person sees it in the History section.
    The text is saved as the item's remediation summary and a "remediation started" entry is added to its history.
    --auto-remediate is recorded with the entry; nothing acts on it yet.

    \b
    What starts the fix itself:
      The proposed fix is in `torana alert <UUID> view --section how-to-fix` (the upgrade or the change, and what it clears).
      Make the change, open the pull request, then link it with `torana remediations create --alert-id <UUID> --pr-url <URL>`.
      That moves the item to pending remediation. `torana remediation <ID> set-state` follows the pull request to merged.

    \b
    Output:
      {"status": "success"}

    \b
    Related:
      torana alert <UUID> view --section how-to-fix   what to change, and what the change clears
      torana remediations create --alert-id <UUID> --pr-url <URL>   link the pull request
      torana remediations list --alert-id <UUID>        the pull requests already linked

    \b
    Examples:
      torana alert <UUID> remediation --remediation-instructions "Upgrade pyjwt to 2.15.0 in services/auth; PR by Friday"
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/remediation"
    body = {}
    body["remediation_instructions"] = remediation_instructions
    if auto_remediate is not None:
        body["auto_remediate"] = auto_remediate

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="escalate")
@click.option("--escalation-reason", "escalation_reason", required=True, help="Reason for escalation")
@click.option("--escalate-to", "escalate_to", default=None, help="Optional specific user/agent/team to escalate to")
@click.pass_context
def alert_escalate(ctx, escalation_reason, escalate_to):
    """Hand an item to a person because it cannot be decided here, and say why.

    Use this when the evidence is inconclusive and a person must judge. Do not use it for a confirmed finding: a confirmed
    finding is already "to be fixed". It does not change the assignee; use `assign` as well if a person or queue should own it.
    Allowed on an open item only: a closed or already-escalated item is refused (HTTP 409); reopen it first.

    \b
    Output:
      The updated item, now escalated.

    \b
    Related:
      torana alert <UUID> assign --assigned-to <USER>    give it an owner
      torana alert <UUID> verdict --triage-verdict ...    decide it instead

    \b
    Examples:
      torana alert <UUID> escalate --escalation-reason "Cannot tell if the endpoint is reachable from outside"
      torana alert <UUID> escalate --escalation-reason "Needs the service owner" --escalate-to payments-team
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/escalate"
    body = {}
    body["escalation_reason"] = escalation_reason
    if escalate_to is not None:
        body["escalate_to"] = escalate_to

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="compress-context")
@click.pass_context
def alert_compress_context(ctx):
    """Compress Context."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/compress-context"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="provenance")
@click.pass_context
def alert_provenance(ctx):
    """Show how this alert came to exist — full provenance + pipeline trace.

    \b
    Walks bottom→top: the originating RULE and how it was triggered (manual /
    scheduled / suite), the rule run, the alert (finding), and every pipeline
    stage it passed through — each with status + timing. Backed by
    GET /api/v1/pipeline/trace/by-alert/{id}.

    \b
    Example:
      torana alert <UUID> provenance
      torana alert <UUID> provenance --json
    """
    # Shared renderer/fetch lives in pipeline.py (single owner of the trace
    # endpoint + provenance formatting). Imported lazily to avoid any import cycle.
    from torana_cli.pipeline import provenance_by_alert_core
    provenance_by_alert_core(ctx, _aid(ctx))


@alert.command(name="triage-context")
@_tenant_read_option
@click.option("--rendered", is_flag=True, default=False,
              help="Also print the message the triage agent saw on its last run "
                   "and the one it would receive now.")
@click.pass_context
def alert_triage_context(ctx, rendered):
    """What the triage agent was given to decide this item: the facts it saw, and how it looked up the evidence.

    Use this to check why the agent decided as it did: what the platform put in front of it. Add --rendered to see the actual
    message of its last run and the one it would get if run now.

    \b
    With --rendered (text format), prints the first message of the agent's
    last run under "Last run", then the message it would receive if invoked
    now under "If invoked now". JSON/YAML carry both as fields.

    \b
    Output:
      The context record (JSON-like). With --rendered in text format, the two messages under "Last run" and "If invoked now".

    \b
    Related:
      torana alert <UUID> view --section verdict    the verdict and the reasons, as the Inbox shows them
      torana alert <UUID> proof                      the evidence behind each claim

    \b
    Examples:
      torana alert <UUID> triage-context
      torana alert <UUID> triage-context --rendered
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/triage-context"

    client = _client(ctx)
    try:
        data = client.get(path, params={"rendered": "true"} if rendered else None)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if rendered and fmt == "text" and isinstance(data, dict) and (
            data.get("last_run_message") or data.get("rendered_message")):
        _echo_triage_messages(data)
        return
    output(data, fmt=fmt, fields=fields)


def _echo_triage_messages(data: dict) -> None:
    """Print the last run's first message, then the one the agent would get now."""
    sections = [("Last run", data.get("last_run_message")),
                ("If invoked now", data.get("rendered_message"))]
    first = True
    # How the posture-record lookup went (found / not_found / failed / not_posture): a `failed` one is why the prompt
    # fell back to the rule's matched row, so it is said first, with the datalake's error.
    lookup = data.get("posture_lookup")
    if isinstance(lookup, dict) and lookup.get("status"):
        click.echo(f"Posture lookup: {lookup['status']}" + (f" ({lookup['error']})" if lookup.get("error") else ""))
        first = False
    for header, message in sections:
        if not message:
            continue
        if not first:
            click.echo("")
        click.echo(f"=== {header} ===")
        click.echo(message)
        first = False


@alert.command(name="reachability")
@click.option("--verdict", "verdict", required=False,
              type=click.Choice(["not_imported", "build_only", "no_path_from_entry_point",
                                 "reachable", "imported_transitively", "inconclusive"],
                                case_sensitive=False),
              help="What a deterministic read of the repository found. Every verdict is recorded "
                   "as a fact on the item; none moves its priority.")
@click.option("--commit", "commit", required=False, metavar="SHA",
              help="The commit the analysis read. ⛔ REQUIRED: without it 'not imported' and "
                   "'not imported as of last Tuesday' read identically, and the platform's "
                   "rule is that an unmeasured answer must never look like a measured one.")
@click.option("--analyzer", "analyzer", required=False, metavar="NAME",
              help="Which engine said it, e.g. 'import-index/2' or 'callgraph/3'. A verdict "
                   "outlives the version that produced it.")
@click.option("--repository", "repository", required=False, metavar="REPO_KEY",
              help="⛔ REQUIRED. The repo:<host>/<org>/<repo> you measured. The write is "
                   "REFUSED (422) unless this alert's finding key is bound to that same "
                   "repository — a source scan read one tree and may only speak for that "
                   "tree. An Inbox entry, and a member found in a built image, are bound to "
                   "no repository and so cannot be answered this way at all.")
@click.option("--evidence-file", "evidence_file", default=None, metavar="FILE",
              help="JSON/YAML holding the rest of the evidence this verdict needs ('-' reads "
                   "stdin). not_imported: files_scanned. build_only: files_scanned, scopes. "
                   "no_path_from_entry_point: function, entry_points_considered. reachable: "
                   "function, path. imported_transitively: via (the requirement chain from a "
                   "package this code imports). inconclusive: reason.")
@click.pass_context
def alert_reachability(ctx, verdict, commit, analyzer, repository, evidence_file):
    """Record a measured code-reachability verdict as a fact on the item. The CI reachability pass
    (torana-scan reachability_pass.py) is what measures it; the platform does not.

    This is where a measurement is recorded on the item, at a named commit (the Atlas can also
    measure reachability: `torana atlas reachability`).

    A measurement never moves the item's priority. It is recorded as a fact, shown in History
    and on the CODE REACHABILITY card, and the triage agent may weigh it when it sets a confirmed
    finding's priority. Idempotent per (alert, commit, kind of measurement): a repeat returns
    `already_recorded` and writes nothing, so an at-least-once cron is safe. A new commit is a
    new fact and does append.

    ⛔ The answer may not leave the tree it was measured in: `--repository` must name the
    repository this alert's finding is bound to, or the write is refused.

    \b
    Examples:
      # in the lockfile, in no import statement — the strongest absence claim
      echo '{"files_scanned":71}' > ev.json
      torana alert <UUID> reachability --verdict not_imported --commit a1b2c3d --analyzer import-index/2 --repository repo:github.com/acme/api --evidence-file ev.json
    \b
      # imported by nothing here, but required by a package this code imports
      echo '{"files_scanned":71,"via":["fastapi","starlette","anyio"]}' > ev.json
      torana alert <UUID> reachability --verdict imported_transitively --commit a1b2c3d --analyzer import-index/2 --repository repo:github.com/acme/api --evidence-file ev.json
    \b
      # a SAST finding whose function nothing calls from an entry point
      echo '{"function":"check_redirect_uri","entry_points_considered":101}' > ev.json
      torana alert <UUID> reachability --verdict no_path_from_entry_point --commit a1b2c3d --analyzer callgraph/3 --repository repo:github.com/acme/api --evidence-file ev.json
    \b
      # confirmation — recorded as a fact. '-' reads stdin, for a cron.
      echo '{"function":"decode_jwt_token","path":["oauth_token","decode_jwt_token"]}' | torana alert <UUID> reachability --verdict reachable --commit a1b2c3d --analyzer callgraph/3 --repository repo:github.com/acme/api --evidence-file -
    \b
      # read back what is recorded
      torana alert <UUID> view --section reachability
    """  # noqa: E501 — Click renders a \b block verbatim, so an example must not be wrapped
    from torana_cli.rules import _load_input_file

    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    # ⚠️ Required: a usage error NAMING the missing flag, never a 422 about evidence.
    for flag, value in (("--verdict", verdict), ("--commit", commit), ("--analyzer", analyzer),
                        ("--repository", repository)):
        if not value:
            raise click.UsageError(f"Missing option '{flag}'.")

    evidence = _load_input_file(evidence_file) if evidence_file else {}
    if not isinstance(evidence, dict):
        click.echo("ERROR: --evidence-file must hold an object, not a list or scalar.", err=True)
        sys.exit(2)
    # ⚠️ The three universals are FLAGS, not file keys, so a missing one fails here with a
    # usage error naming it rather than reaching the API as a 422 about evidence. They are
    # merged in (and win) so the file cannot disagree with what was asked for on the command
    # line — and `repository` in particular decides whether the write is allowed at all.
    evidence = {**evidence, "commit": commit, "analyzer": analyzer, "repository": repository}

    aid = _aid(ctx)
    path = f"alerts/{aid}/reachability"

    client = _client(ctx)
    try:
        data = client.post(path, json={"verdict": verdict.lower(), "evidence": evidence})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


#: Operator commands: callable as before, out of the default listing (INBOX_SECTIONS_SPEC § 3.4.3.4; see
#: `skills/torana-skill/references/detection.md`, "Operator commands").
for _name in ("invoke", "cancel", "compress-context"):
    if alert.commands.get(_name) is not None:
        alert.commands[_name].hidden = True


def _hidden_alias(group, command, old_name):
    """Register `command` under its older spelling too, hidden from `--help`, so existing scripts and skills keep working."""
    import copy
    alias = copy.copy(command)
    alias.name, alias.hidden = old_name, True
    group.add_command(alias, name=old_name)


_hidden_alias(alert, alert_inbox, "inbox")             # `alert <ID> inbox` is now `alert <ID> view`
