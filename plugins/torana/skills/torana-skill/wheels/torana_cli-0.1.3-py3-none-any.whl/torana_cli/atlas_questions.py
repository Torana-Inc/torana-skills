"""torana atlas questions | decisions — learning Questions and Decisions (pantheon-knowledge BLOCK_6D1_DESIGN_NOTE.md § 5).

A Question is a disagreement inside one claim family (two readings of one thing), COMPUTED on every read for the
caller, never stored: it has a handle `<family_key>:<kind>`, not an id. States: open (✗ contradiction, ⚑ drift,
⛔ violation) and settled (◐, after a person rules a side `misread` / `stale` with `torana atlas claims curate`).
A Decision is a person's checkable rule (`decision.rule`), stated with `torana atlas statements add`.

The server writes every glyph and sentence; these commands print them verbatim and derive none. Nothing acts on a
Question (it never changes a finding or a verdict).
"""

import click

from torana_cli.atlas import MAX_PAGE_SIZE, _call, _client, _params
from torana_cli.atlas_claims import _emit, _fmt

KINDS = ["contradiction", "drift", "violation"]


def side_line(sd: dict) -> str:
    stale = " · stale" if sd.get("stale") else ""
    return f"  - {sd.get('words', '')}  ({sd.get('source_class', '?')}, {sd.get('tier') or '-'}{stale})"


def question_line(q: dict) -> str:
    return f"{q.get('glyph', '')} {q.get('words', '')}".strip()


def questions_block(questions: list) -> list:
    """explain's "Questions:" block: one line per Question with its sides (printed only when there is one)."""
    if not questions:
        return []
    lines = ["Questions:"]
    for q in questions:
        lines.append(f"  {question_line(q)}")
        lines += [f"  {side_line(sd)}" for sd in q.get("sides") or []]
        lines.append(f"      handle {q.get('handle', '?')}")
    return lines


def render_questions_page(data: dict) -> str:
    """One line per Question: `glyph words  [handle]`, then where the scan stopped. The scan is bounded: a short page
    with a cursor is not the end (BLOCK_6D1 § 6)."""
    items = data.get("items") or []
    lines = [f"{question_line(q)}  [{q.get('handle', '?')}]" for q in items]
    if not items:
        lines.append("no learning Questions on this page" if data.get("cursor") else "no learning Questions")
    scanned = data.get("scanned")
    if data.get("cursor"):
        lines.append(f"(scanned {scanned} families; more may follow: --cursor {data['cursor']})")
    elif scanned is not None:
        lines.append(f"(scanned {scanned} families; end of the scan)")
    return "\n".join(lines)


def render_question(q: dict) -> str:
    out = [question_line(q), f"  {q.get('kind', '?')} · {q.get('state', '?')} · {q.get('subject', '?')} · "
                             f"{q.get('claim_type', '?')}"]
    out += [side_line(sd) for sd in q.get("sides") or []]
    out.append(f"  handle {q.get('handle', '?')}")
    return "\n".join(out)


@click.group(name="questions", invoke_without_command=True)
@click.pass_context
def atlas_questions(ctx):
    """Learning Questions: two readings of one thing that disagree (a contradiction, a drift, a Decision violation),
    computed now for you. Settle one with `torana atlas claims curate ID --verdict misread|stale`. Nothing acts on a
    Question. (Not `torana atlas inquire`: an inquiry asks a model to look; a Question is a disagreement already held.)

    \b
    Examples:
      torana atlas questions list --state open
      torana atlas questions list --subject repo:github.com/acme/api --kind drift
      torana atlas questions list --root doc:runbook.md
      torana atlas questions list --cursor <the cursor the last page printed>
      torana atlas questions get <family_key>:drift
    """
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@atlas_questions.command(name="list")
@click.option("--subject", default=None, metavar="KEY", help="One subject, e.g. repo:github.com/acme/api.")
@click.option("--claim", "claim_id", default=None, metavar="CLAIM_ID", help="The Questions of this claim's family.")
@click.option("--kind", type=click.Choice(KINDS), default=None)
@click.option("--state", type=click.Choice(["open", "settled"]), default=None,
              help="open (asked, not ruled) or settled (a person ruled a side misread/stale).")
@click.option("--root", default=None, metavar="doc:NAME",
              help="Only Questions with a side read from this document, e.g. doc:runbook.md.")
@click.option("--cursor", default=None, metavar="CURSOR", help="Continue the scan where the last page stopped.")
@click.option("--limit", type=click.IntRange(1, MAX_PAGE_SIZE), default=50, show_default=True)
@click.option("--tenant", default=None, help="Another tenant's Questions (SA only).")
@click.pass_context
def questions_list(ctx, subject, claim_id, kind, state, root, cursor, limit, tenant):
    """List Questions, one line each: `glyph words [handle]`. A page can be short and still not the last: follow the
    printed --cursor until the scan ends. With --root the list is called filtered only when the server echoes the
    filter back (6d.5 R12): an older server ignores it and returns every Question."""
    if root is not None and not root.startswith("doc:"):
        raise click.BadParameter("must start with doc:, e.g. doc:runbook.md", param_hint="--root")
    data = _call(_client(ctx).get, "atlas/questions", params=_params(subject=subject, claim_id=claim_id, kind=kind,
                                                                      state=state, root=root, cursor=cursor,
                                                                      limit=limit, tenant=tenant))
    _emit(ctx, data, lambda d: render_filter_line(d, root) + render_questions_page(d))
    if root is not None and not echoed_root(data) and _fmt(ctx)[0] != "text":
        click.echo(NOT_FILTERED_WORDS, err=True)


NOT_FILTERED_WORDS = "⚠ not filtered: this server does not filter by document, so this list is every Question"


def echoed_root(data) -> str | None:
    """The document filter the server says it applied (`filter.root`), or None. Absent = unfiltered (6d.5 R12)."""
    if not isinstance(data, dict):
        return None
    f = data.get("filter")
    return f.get("root") if isinstance(f, dict) else None


def render_filter_line(data: dict, asked_root: str | None) -> str:
    """The first line of a --root list: what the server filtered by, or that it did not. Glyph + words, never colour."""
    echoed = echoed_root(data)
    if echoed:
        return f"▼ filtered: only Questions with a side from {echoed}\n"
    if asked_root is not None:
        return NOT_FILTERED_WORDS + "\n"
    return ""


@atlas_questions.command(name="get")
@click.argument("handle")
@click.option("--tenant", default=None, help="Another tenant's Question (SA only).")
@click.pass_context
def questions_get(ctx, handle, tenant):
    """One Question by its handle `<family_key>:<kind>`, with its sides. A handle that no longer computes is 404."""
    data = _call(_client(ctx).get, f"atlas/questions/{handle}", params=_params(tenant=tenant))
    _emit(ctx, data, render_question)


def decision_line(d: dict) -> str:
    return f"{d.get('glyph', '')} {d.get('words', '')}".strip()


def render_decisions(data: dict) -> str:
    items = data.get("items") or []
    lines = []
    for d in items:
        lines.append(f"{decision_line(d)}  [{str(d.get('claim_id', '?'))[:8]} on {d.get('subject', '?')}]")
    if not items:
        lines.append("no Decisions in force")
    return "\n".join(lines)


@click.group(name="decisions", invoke_without_command=True)
@click.pass_context
def atlas_decisions(ctx):
    """Decisions in force: a person's checkable rules (`decision.rule` statements) and whether each holds now
    (✓ holds, ⛔ violated, ? unknown). State one with
    `torana atlas statements add --type decision.rule --subject repo:… --identity rule_key=… --value-json '{…}'`."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@atlas_decisions.command(name="list")
@click.option("--tenant", default=None, help="Another tenant's Decisions (SA only).")
@click.pass_context
def decisions_list(ctx, tenant):
    """List Decisions, one line each: the server's words (outcome and held value included)."""
    data = _call(_client(ctx).get, "atlas/decisions", params=_params(tenant=tenant))
    _emit(ctx, data, render_decisions)
