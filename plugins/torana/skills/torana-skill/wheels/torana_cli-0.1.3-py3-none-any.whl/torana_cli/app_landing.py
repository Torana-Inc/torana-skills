"""`torana app <APP_ID> engagement | outcomes | policies`: the App Landing Page's sections, from the CLI (design note
APP_LANDING_PAGE_DESIGN_NOTE.md, D8, D10, D11). The page, the FE and this CLI read the same API responses.

  engagement                       App Intent (with what the app does at each stage) and App Goals, read-only (platform-computed: nothing here edits them)
  outcomes                         App Outcomes, the last 30 days
  policies                         every setting the app uses, with its default and the value in force
  policies set <key> <value>       change one (tenant-wide); --default returns it to the platform default

Reads GET context-lake/app-engagement (agent-builder), workspaces/{id}/outcomes (PPF), vm/policy/workspaces/{id} (agent-builder).
Unknown is shown as unknown: an unreadable figure prints "could not be read", never 0 (I1).
"""
from __future__ import annotations

import json

import click

from torana_cli.ai_home import _ctx
from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, handle_api_error, handle_auth_error
from torana_cli.output import output

UNREADABLE = "could not be read"
SOURCE_WORDS = {"default": "default", "your_policy": "your policy", "policy_document": "from your policy document",
                "unresolved": "could not be decided"}


def _when(iso) -> str:
    from torana_cli.alert import _view_time
    return _view_time(iso) if iso else ""


def _num(v) -> str:
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    return str(v)


def engagement_lines(data: dict) -> list:
    """App Intent, then App Goals (targets as text, never as a measured value), then the as-of line."""
    out = []
    out.append("App Intent")
    # D9: a body that lacks the key is a read that failed, never "nothing yet". Only an explicit null is "No intent yet".
    if "intent" not in data:
        out.append(f"  The intent {UNREADABLE}.")
    elif isinstance(data["intent"], dict) and (data["intent"].get("statement") or "").strip():
        intent = data["intent"]
        out.append(f"  {intent['statement'].strip()}")
        if (intent.get("description") or "").strip():
            out.append(f"  {intent['description'].strip()}")
        # What the app does at each stage (Assess, Triage, Prioritize, Remediate, Verify), in the server's order.
        # None stored (the model failed, or the app serves no stage): nothing is printed.
        stages = [s for s in (intent.get("stages") or []) if isinstance(s, dict)
                  and (s.get("stage") or "").strip() and (s.get("text") or "").strip()]
        if stages:
            out.append("")
            for s in stages:
                out.append(f"  {s['stage'].strip()}: {s['text'].strip()}")
    else:
        out.append("  No intent yet.")
    out.append("")
    out.append("App Goals")
    goals = data.get("goals") if "goals" in data else False
    if goals is False or not isinstance(goals, list):
        out.append(f"  The goals {UNREADABLE}.")
    elif not goals:
        out.append("  No goals yet.")
    else:
        for i, g in enumerate(goals, 1):
            out.append(f"  {i}. {(g.get('statement') or '').strip()}")
            if g.get("rationale"):
                out.append(f"     Why: {g['rationale'].strip()}")
            if g.get("target"):
                out.append(f"     Target: {str(g['target']).strip()}")     # a target to work towards, not a current value
    if data.get("as_of"):
        out.append("")
        out.append(f"As of {_when(data['as_of'])}")
    return out


def _fig_value(f: dict) -> str:
    v = f.get("value")
    if v is None:
        # D11 / I1: "not measured" (the app declares no funnel) is a different statement from "could not be read".
        reason = f.get("reason")
        if f.get("reason_text"):                      # the server says it ("No findings yet" for findings, else "Nothing to measure yet")
            return str(f["reason_text"])
        return {"not_declared": "Not measured for this app", "nothing_to_measure": "Nothing to measure yet"}.get(reason, UNREADABLE)
    return _num(v) + (f" {f['unit']}" if f.get("unit") else "")


def outcomes_lines(data: dict) -> list:
    """The funnel figures (current state) first, then the last-30-days figures. Each value is a number, "could not be read"
    or "Not measured for this app"; never a silent 0."""
    figs = data.get("figures") if isinstance(data.get("figures"), list) else []
    days = data.get("window_days") or 30
    if not figs:
        return ["App Outcomes", f"  The figures {UNREADABLE}."]
    width = max(len(f.get("label") or "") for f in figs)

    def block(title, rows):
        return ([title] + [f"  {(f.get('label') or '').ljust(width)}  {_fig_value(f)}" for f in rows]) if rows else []

    now = [f for f in figs if f.get("window") == "current"]
    window = [f for f in figs if f.get("window") != "current"]
    out = block("App Outcomes, as of now", now)
    if now and window:
        out.append("")
    out += block(f"App Outcomes, the last {days} days", window)
    if data.get("as_of"):
        out.append("")
        out.append(f"As of {_when(data['as_of'])}")
    return out


def _source(p: dict) -> str:
    return SOURCE_WORDS.get(str(p.get("source") or "").lower(), "could not be decided")


def _show(v) -> str:
    """A `{value, label}` pair prints its label (plain words, never the raw value); anything else prints as is."""
    if isinstance(v, dict) and "label" in v and "value" in v:
        v = v["label"]
    return v if isinstance(v, str) else json.dumps(v)


def _rows(data):
    return (data.get("rows") if isinstance(data, dict) else data) or []


def policy_lines(data: dict) -> list:
    rows = _rows(data)
    if not rows:
        return ["This app uses no settings you can change."]
    out = []
    rc = (data.get("recompute") or {}) if isinstance(data, dict) else {}
    if rc.get("state") == "updating":
        out += ["The app is updating after a change.", ""]
    elif rc.get("state") == "unknown":
        out += ["Could not tell whether the app has finished updating.", ""]
    elif rc.get("finished_at"):
        out += [f"Updated {_when(rc['finished_at'])}", ""]
    for p in rows:
        out.append(f"{p.get('name') or p.get('key')}")
        if p.get("explanation"):
            out.append(f"  {p['explanation']}")
        forced = "could not be decided" if p.get("in_force") is None else f"{_show(p['in_force'])} ({_source(p)})"
        out.append(f"  Default: {_show(p.get('default'))}    In force: {forced}")
        others = p.get("used_by") or []
        if others:
            out.append(f"  Also used by: {', '.join(str(o) for o in others)}")
        if p.get("note"):
            out.append(f"  {p['note']}")
        if p.get("choices"):
            out.append("  Choices: " + ", ".join(str(c.get("label")) for c in p["choices"]))
        if p.get("security_critical"):
            out.append("  A change to this one needs a second approval before it applies.")
        out.append(f"  Key: {p.get('key')}")
        out.append("")
    return out[:-1]


def register(workspace_group, client_factory):
    """Attach `engagement`, `outcomes` and `policies` to the `workspace <id>` group (also `app <id>`)."""

    def _read(ctx, path, **params):
        fmt, raw, fields = _ctx(ctx)
        wid = ctx.obj.get("_workspace_id", "") if ctx.obj else ""
        try:
            data = client_factory(ctx).get(path.format(wid=wid), params=params or None) or {}
        except APIError as e:
            handle_api_error(e)
            return None
        except AuthError as e:
            handle_auth_error(e)
            return None
        return fmt, raw, fields, wid, data

    @workspace_group.command(name="engagement")
    @click.pass_context
    def app_engagement(ctx):
        """Show what this app is for (App Intent) and what it aims at (App Goals). Read-only: the platform works both out
        from how the app was built, and refreshes them whenever the app is deployed or upgraded. Goals are targets, not
        measured results.

        \b
        Examples:
          torana app <APP_ID> engagement
          torana app <APP_ID> engagement --json
        """
        wid = ctx.obj.get("_workspace_id", "") if ctx.obj else ""
        r = _read(ctx, "context-lake/app-engagement", workspace_id=wid)
        if r is None:
            return
        fmt, raw, fields, _, data = r
        if fmt in ("json", "yaml"):
            output(data, fmt=fmt, raw=raw, fields=fields)
        else:
            click.echo("\n".join(engagement_lines(data)))

    @workspace_group.command(name="outcomes")
    @click.pass_context
    def app_outcomes(ctx):
        """Show what this app has done for you in the last 30 days: issues raised, closed automatically and by a person
        or agent, closed by a fix, fixes proposed, merged and verified, median time to fix, and what is overdue now. First, how
        many findings the app looked at and how many it set aside as noise (right now, not the 30 days).

        A figure that cannot be read says so; it is never shown as 0.

        \b
        Examples:
          torana app <APP_ID> outcomes
          torana app <APP_ID> outcomes --json
        """
        r = _read(ctx, "workspaces/{wid}/outcomes")
        if r is None:
            return
        fmt, raw, fields, _, data = r
        if fmt in ("json", "yaml"):
            output(data, fmt=fmt, raw=raw, fields=fields)
        else:
            click.echo("\n".join(outcomes_lines(data)))

    @workspace_group.group(name="policies", invoke_without_command=True)
    @click.pass_context
    def app_policies(ctx):
        """Show how this app decides: every setting it uses, with its default, the value in force and where that value
        came from (default, your policy, or your policy document). Use `set` to change one.

        \b
        Examples:
          torana app <APP_ID> policies
          torana app <APP_ID> policies set <KEY> <VALUE>
          torana app <APP_ID> policies set <KEY> --default
        """
        if ctx.invoked_subcommand is not None:
            return
        r = _read(ctx, "vm/policy/workspaces/{wid}")
        if r is None:
            return
        fmt, raw, fields, _, data = r
        if fmt in ("json", "yaml"):
            output(data, fmt=fmt, raw=raw, fields=fields)
        else:
            click.echo("\n".join(policy_lines(data)))

    @app_policies.command(name="set")
    @click.argument("key")
    @click.argument("value", required=False)
    @click.option("--default", "use_default", is_flag=True, default=False,
                  help="Return the setting to the platform default. Your own value is removed (no copy of the default "
                       "is written), so a later change to the default still reaches the app.")
    @click.option("--yes", "-y", "confirmed", is_flag=True, default=False,
                  help="Do not ask when other apps use the same setting.")
    @click.pass_context
    def app_policies_set(ctx, key, value, use_default, confirmed):
        """Change one setting, or return it to its default with --default.

        Settings are shared by every app in your tenant: when others use this one they are named first, and you are asked
        to confirm (--yes skips the question).
        """
        if use_default == (value is not None):
            raise click.UsageError("Give a VALUE, or --default, not both and not neither.")
        r = _read(ctx, "vm/policy/workspaces/{wid}")
        if r is None:
            return
        _, _, _, wid, listed = r
        row = next((p for p in _rows(listed) if key in (p.get("key"), p.get("name"))), None)
        if row is None:
            raise click.ClickException(f"This app does not use a setting \"{key}\". List them:  torana app {wid} policies")
        real_key = row.get("key") or key
        if value is not None and row.get("value_type") == "map":
            raise click.ClickException("This setting is a list of entries, not one value. Use --default, or set entries with "
                                       "`torana vm policy set-entry`.")
        others = row.get("used_by") or []
        if others and not confirmed:
            click.echo(f"This setting is shared. Other apps that use it: {', '.join(str(o) for o in others)}.", err=True)
            click.confirm("Change it for all of them?", abort=True, err=True)
        from torana_cli.vm_policy import _BASE, _parse_value
        client = client_factory(ctx)
        try:
            if use_default:
                client.delete(f"{_BASE}/bindings/{real_key}")
            else:
                client.put(f"{_BASE}/bindings/{real_key}", json={"value": _parse_value(value), "scope": ""})
        except APIError as e:
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return
        click.echo(f"{row.get('name') or real_key}: back to the default ({_show(row.get('default'))})." if use_default
                   else f"{row.get('name') or real_key}: set to {_show(_parse_value(value))}. The app updates on its own.")
