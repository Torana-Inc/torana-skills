"""torana workspace <ID> — instance-scoped workspace commands."""

import datetime
import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.rules import _load_input_file, list_rules_core
from torana_cli.workflows import list_workflows_core
from torana_cli.playbooks import list_playbooks_core
from torana_cli.alert_routes import list_alert_routes_core
from torana_cli.alerts import (ACTION_HELP, DECIDED_BY_CHOICES, VERDICT_HELP, VERDICT_CHOICES, WHY_CHOICES, CommaChoice, box_option, entries_option,
                               extra_list_options, list_alerts_core, overdue_option, signal_options, sla_state_option, team_option,
                               time_options)
from torana_cli.alert import alert as _alert_group
from torana_cli.datalake import (list_transformers_core, _list_transformers_filtered,
                                 STATE_MATERIALIZED, STATE_LIVE, STATE_STALE, STATE_FAILED,
                                 STATE_NEVER_RUN)
from torana_cli.plans import list_plans_core
from torana_cli.dashboards import list_dashboards_core
from torana_cli.widgets import app_widgets_list_options, list_app_widgets_core
from torana_cli.schedulers import list_schedulers_core
from torana_cli.time_util import format_next_run
from torana_cli.confirm import confirm as _confirm

_PROPOSAL_COLS = [
    ("id", "ID", 36),
    ("title", "TITLE", 40),
    ("status", "STATUS", 12),
    ("created_at", "CREATED", 20),
]


def _forecast_line(inbox: dict) -> str:
    """One rule's Inbox forecast in the platform's own terms: ENTRIES are what the Inbox lists, finding ROWS are what the rule's query returns.
    Nothing is composed from a count the platform did not send; a missing number reads "?"."""
    def n(key):
        v = inbox.get(key)
        return "?" if v is None else str(v)
    now = f"{n('open_entries_now')} open entries ({n('member_rows_now')} findings)"
    after = f"{n('entries_after')} entries from {n('finding_rows_after')} finding rows"
    return (f"{now} now -> {after} after "
            f"({n('stay_open_items')} stay open, {n('new_items')} new, {n('leaving_items')} leave the result)")


def _added_forecast_line(inbox: dict) -> str:
    """What a rule the upgrade ADDS would find on its first run. Same rule as _forecast_line: a missing number is "?"."""
    def n(key):
        v = inbox.get(key)
        return "?" if v is None else str(v)
    return f"new rule: {n('entries_after')} entries from {n('finding_rows_after')} finding rows on its first run"


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _wid(ctx) -> str:
    return ctx.obj.get("_workspace_id", "") if ctx.obj else ""


# ---------------------------------------------------------------------------
# Root group — takes WORKSPACE_ID as positional argument
# ---------------------------------------------------------------------------

@click.group(name="workspace", invoke_without_command=True)
@click.argument("workspace_id", metavar="WORKSPACE_ID")
@click.pass_context
def workspace(ctx, workspace_id):
    """Manage a single workspace by ID.

    \b
    Examples:
      torana workspace <UUID> get
      torana workspace <UUID> proposals list
      torana workspace <UUID> proposal <PROPOSAL_ID> status
      torana workspace <UUID> advisor bootstrap
      torana workspace <UUID> sweeps list
    """
    ctx.ensure_object(dict)
    ctx.obj["_workspace_id"] = workspace_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


# ---------------------------------------------------------------------------
# Basic instance operations
# ---------------------------------------------------------------------------

@workspace.command(name="get")
@click.pass_context
def workspace_get(ctx):
    """Get workspace details.

    \b
    Examples:
      torana workspaces list                   # find the id
      torana workspace <WORKSPACE_ID> get
      torana workspace <WORKSPACE_ID> --help   # everything scoped to this workspace
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    wid = _wid(ctx)

    client = _client(ctx)
    try:
        data = client.get(f"workspaces/{wid}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workspace.command(name="show")
@click.pass_context
def workspace_show(ctx):
    """Show a workspace's deployment state and current app version.

    Composes the workspace identity, its CURRENT deployed app version (the newest
    build_v2 deployment — version number, when, artifact count, triggering proposal),
    and a count of proposals by state (deployable / rolled_back / etc.). Use `get` for
    the raw workspace record; this is the human-readable "what's deployed" view."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    wid = _wid(ctx)
    client = _client(ctx)

    def _safe_get(path):
        try:
            return client.get(path)
        except (APIError, AuthError):
            return None

    ws = _safe_get(f"workspaces/{wid}")
    if ws is None:
        click.echo("ERROR: workspace not found.", err=True)
        return
    deployments = _safe_get(f"workspaces/{wid}/build-v2/deployments?limit=50") or {}
    versions = deployments.get("items", deployments) if isinstance(deployments, dict) else (deployments or [])
    proposals = _safe_get(f"workspaces/{wid}/build-v2/proposals") or {}
    prows = proposals.get("items", proposals) if isinstance(proposals, dict) else (proposals or [])

    current = versions[0] if versions else None  # deployments come newest-first
    state_counts = {}
    for p in (prows or []):
        st = p.get("state") or "unknown"
        state_counts[st] = state_counts.get(st, 0) + 1

    if fmt != "text":
        output({
            "workspace": ws,
            "current_version": current,
            "version_count": len(versions),
            "proposals_by_state": state_counts,
        }, fmt=fmt)
        return

    # Flat, stable, COLUMN-ALIGNED `key : value` pairs — one value per line, no prose, so a
    # script can `grep '^current_version '` (key still leftmost) while a human reads aligned
    # columns. Booleans lowercase; absent values are "-".
    rows = [
        ("workspace_id", ws.get('id') or wid),
        ("workspace_name", ws.get('name')),
        ("workspace_type", ws.get('type') or ws.get('workspace_type')),
        ("workspace_state", ws.get('state')),
        ("is_default", str(bool(ws.get('is_default', False))).lower()),
        ("deployed", str(bool(current)).lower()),
        ("current_version", current.get('version_number') if current else 0),
        ("version_count", len(versions)),
        ("deployed_proposal_id", current.get('trigger_proposal_id') if current else None),
        ("deployed_at", current.get('deployed_at') if current else None),
        ("deployed_by", current.get('deployed_by') if current else None),
        ("deploy_run_id", current.get('deploy_run_id') if current else None),
        ("artifact_count", current.get('artifact_count') if current else 0),
        ("version_summary", current.get('description') if current else None),
        ("proposal_count", len(prows or [])),
    ]
    # Per-state proposal counts as their own keys (e.g. `proposals_deployed : 1`).
    for st in sorted(state_counts):
        rows.append((f"proposals_{st}", state_counts[st]))

    width = max(len(k) for k, _ in rows)
    for key, val in rows:
        shown = val if val not in (None, "") else "-"
        click.echo(f"{key.ljust(width)} : {shown}")


@workspace.command(name="update")
@click.option("--file", "input_file", default=None, metavar="FILE",
              help="JSON/YAML file with update body.")
@click.option("--enable-v2", is_flag=True, default=False,
              help="Put this workspace on the Build-V2 vertical "
                   "(sets type=vulnerability_management_v2).")
@click.option("--name", default=None, help="New workspace name (see also: `rename`).")
@click.pass_context
def workspace_update(ctx, input_file, enable_v2, name):
    """Update workspace from a JSON/YAML file.

    \b
    Examples:
      torana workspace <UUID> update --file body.json
      torana workspace <UUID> update --name "New Name"
      torana workspace <UUID> update --enable-v2
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    wid = _wid(ctx)

    body = _load_input_file(input_file) if input_file else {}
    if name:
        body["name"] = name
    if enable_v2:
        # `build_v2_enabled` is DERIVED from workspace type, not a stored column
        # (program-framework `_is_build_v2_enabled`): a workspace is V2 iff its type is
        # vulnerability_management_v2. Sending `build_v2_enabled: true` therefore does
        # nothing — the field isn't writable and never was (CLI-24 filed it as a
        # silently-dropped write). Set the real lever, and give it a discoverable flag
        # so callers don't have to know the type mapping.
        body["type"] = "vulnerability_management_v2"

    if not body:
        click.echo("ERROR: pass --name <name>, --file <body.json>, or --enable-v2.", err=True)
        ctx.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"workspaces/{wid}", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated workspace: {wid}")


@workspace.command(name="delete")
@click.option("--yes", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def workspace_delete(ctx, yes):
    """Delete a workspace.

    Interactive by default — pass --yes to skip the confirmation prompt
    (required in scripts and non-interactive shells).

    \b
    Examples:
      torana workspace <UUID> delete
      torana workspace <UUID> delete --yes
    """
    wid = _wid(ctx)
    _confirm(f"Delete workspace {wid}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"workspaces/{wid}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted workspace: {wid}")


@workspace.command(name="activate")
@click.pass_context
def workspace_activate(ctx):
    """Activate a workspace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    wid = _wid(ctx)

    client = _client(ctx)
    try:
        data = client.post(f"workspaces/{wid}/activate", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Activated workspace: {wid}")


@workspace.command(name="archive")
@click.pass_context
def workspace_archive(ctx):
    """Archive a workspace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    wid = _wid(ctx)

    client = _client(ctx)
    try:
        data = client.post(f"workspaces/{wid}/archive", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Archived workspace: {wid}")


_BUNDLE_UPGRADE_COLS = [
    ("artifact_type", "TYPE", 16),
    ("artifact_key", "KEY", 48),
    ("change", "CHANGE", 10),
    ("fields", "FIELDS", 40),
    ("result", "RESULT", 10),
]


@workspace.command(name="upgrade-bundle")
@click.option("--to", "target_version", default=None, type=int,
              help="Bundle version to upgrade to. Omit for the latest version the "
                   "code serves (older versions are not served).")
@click.option("--apply", "apply_", is_flag=True, default=False,
              help="Perform the upgrade. Without this flag, shows the dry-run report "
                   "and changes nothing.")
@click.option("--partial", is_flag=True, default=False,
              help="Apply what can be updated in place and skip the rest, each with its "
                   "reason, instead of refusing the whole upgrade (F-upgrade-2). The "
                   "installed version does not move while anything is skipped.")
@click.option("--status", "show_status", is_flag=True, default=False,
              help="Show where this workspace's latest upgrade is (dry run or apply) and exit.")
@click.option("--wait/--no-wait", default=True,
              help="Follow the upgrade until it finishes (default), or print its job id and return at once.")
@click.pass_context
def workspace_upgrade_bundle(ctx, target_version, apply_, partial, show_status, wait):
    """Upgrade this workspace's installed bundle in place (F-upgrade-1).

    Dry run by default: shows what would change, per artifact, and — for a changed
    rule — the inbox forecast (how many standing entries stay open, move, or close,
    and why). Nothing is changed until you pass --apply. --apply asks no further
    confirmation; it IS the confirmation. An upgrade that cannot be safely applied
    (a removed artifact, an added one it cannot create, a rule identity change, a
    downgrade, or a concurrent upgrade of the same workspace) reports `refused` and
    writes nothing, even with --apply. --partial applies what it can and lists each
    skipped artifact with its reason.

    \b
    A rule, scheduler, widget or route the new version ADDS is created in the live
    app, dependencies first (a rule before its scheduler), and recorded as part of the
    install; the dry run lists it under "Would add", a new rule with what it would find.
    Other added types (transformer, dashboard, playbook, inline dashboard widget) are
    refused. The version moves only when every add and change landed; after a failure,
    run the same command again to finish (a piece already created is reused, never
    created twice).

    \b
    The upgrade runs in the background on the server: this command prints the server's
    status sentence each time it moves (the rule being forecast, Inbox pages read, the
    phase), then the report. Ctrl-C stops following, not the upgrade. A second upgrade of
    the same workspace is refused while one runs.

    \b
    Examples:
      torana workspace <UUID> upgrade-bundle
      torana workspace <UUID> upgrade-bundle --status             # where the latest upgrade is
      torana workspace <UUID> upgrade-bundle --apply --no-wait    # start it and return
      torana workspace <UUID> upgrade-bundle --to 7
      torana workspace <UUID> upgrade-bundle --to 7 --apply
      torana workspace <UUID> upgrade-bundle --partial            # what a partial upgrade would do
      torana workspace <UUID> upgrade-bundle --partial --apply

    \b
    Each changed rule, widget and inline dashboard widget is judged on three versions: what
    the install recorded, the bundle, and what runs now. A field a person edited is never
    overwritten: it is listed under "Kept" (the bundle also changed it) or "Edited" (it did
    not). The first upgrade of an older install can list inline widget changes earlier
    upgrades did not detect (NOTE line); they are applied only with --apply.

    \b
    After --apply, each added rule, and each rule whose SQL or alert-shaping config
    changed, runs ONCE (members first, then group roots), so its alerts carry the new
    values now instead of at its next scheduled run. The dry run lists them as "Would re-run". A failed run is
    listed and never fails the upgrade.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    wid = _wid(ctx)
    client = _client(ctx)
    status_path = f"workspaces/{wid}/bundle/upgrade/status"

    try:
        if show_status:
            st = client.get(status_path)
            if fmt != "text":
                output(st, fmt=fmt, raw=raw, fields=fields)
            else:
                _print_upgrade_status(st)
            return

        body = {"apply": apply_, "partial": partial, "background": True}
        if target_version is not None:
            body["target_version"] = target_version
        data = client.post(f"workspaces/{wid}/bundle/upgrade", json=body)

        # An older server ignores `background` and answers with the report itself: print it as before.
        if data.get("job_id") and "artifacts" not in data and "bundle_id" not in data:
            if not wait:
                if fmt != "text":
                    output(data, fmt=fmt, raw=raw, fields=fields)
                else:
                    click.echo(f"Started upgrade job {data['job_id']} on workspace {wid}.")
                    click.echo(f"  follow: torana workspace {wid} upgrade-bundle --status")
                return
            if fmt == "text":
                click.echo(f"Started upgrade job {data['job_id']} on workspace {wid} "
                           f"({'apply' if apply_ else 'dry run'}); following it (Ctrl-C stops following, "
                           f"not the upgrade).")
            st = _follow_upgrade(client, status_path, data["job_id"], echo=(fmt == "text"))
            if st.get("status") in ("succeeded", "refused") and not st.get("stalled"):
                full = client.get(status_path, params={"include_report": "true"})
                data = full.get("report_full") or {}
            else:
                data = {}
            if not data:
                if fmt != "text":
                    output(st, fmt=fmt, raw=raw, fields=fields)
                ctx.exit(1 if st.get("status") == "failed" or st.get("stalled") else 0)
                return
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    verb = ("Upgraded (partial)" if data.get("partial") else "Upgraded") if data.get("applied") else (
        "Dry run (partial):" if data.get("partial") else "Dry run:")
    click.echo(f"{verb} workspace {wid} — bundle {data.get('bundle_id')} "
              f"v{data.get('installed_version')} -> v{data.get('target_version')}")
    if data.get("refused"):
        click.echo(f"REFUSED: {data['refused']}")
    summary = data.get("summary") or {}
    if summary:
        click.echo("  " + ", ".join(f"{k}={v}" for k, v in summary.items()))
    if data.get("notice"):
        click.echo(f"  NOTE: {data['notice']}")

    rows = []
    # Unchanged rows are noise in a bundle of dozens of artifacts; a row a person edited is shown even when nothing
    # will be written to it, so the edit is visible.
    for art in data.get("artifacts", []):
        if art.get("change") == "same" and not (art.get("edited") or art.get("already")):
            continue
        row = dict(art)
        row["fields"] = ", ".join(art.get("fields") or [])
        rows.append(row)
    output({"items": rows}, fmt=fmt, raw=raw, fields=fields, columns=_BUNDLE_UPGRADE_COLS)

    # The inbox forecast is the operator-critical number this command exists to
    # surface — print it per changed rule rather than burying it in a FIELDS cell.
    for art in data.get("artifacts", []):
        inbox = art.get("inbox")
        if not inbox:
            continue
        click.echo()
        line = _added_forecast_line(inbox) if art.get("change") == "added" else _forecast_line(inbox)
        if inbox.get("summary"):
            # The server's like-with-like sentence (rows after, already alerted, new) leads; entries stay as detail.
            click.echo(f"  {art.get('artifact_key')} — inbox: {inbox['summary']}")
            click.echo(f"    entries: {line}")
        else:
            click.echo(f"  {art.get('artifact_key')} — inbox: {line}")
        leaving = inbox.get("leaving_outcome") or {}
        for reason, count in leaving.items():
            click.echo(f"    {count} {reason}")
        if inbox.get("entries_after_note") and inbox.get("entries_after") is None:
            click.echo(f"    entries after: not computed ({inbox['entries_after_note']})")
        if inbox.get("lifecycle_note"):
            click.echo(f"    lifecycle: {inbox['lifecycle_note']}")
        if inbox.get("note"):
            click.echo(f"    note: {inbox['note']}")
        if inbox.get("error"):
            click.echo(f"    error: {inbox['error']}")

    # ⛔ A person's edit is never overwritten: say which ones the bundle also changed (kept as they are).
    conflicts = [a for a in data.get("artifacts", []) if a.get("conflicts")]
    if conflicts:
        click.echo()
        click.echo(f"  Kept ({len(conflicts)}): edited by a person and also changed by the bundle; NOT overwritten:")
        for art in conflicts:
            click.echo(f"    - {art['artifact_key']}: {', '.join(art['conflicts'])}")
    edited = [a for a in data.get("artifacts", []) if a.get("edited")]
    if edited:
        click.echo()
        click.echo(f"  Edited by a person, unchanged in the bundle ({len(edited)}), kept:")
        for art in edited:
            click.echo(f"    - {art['artifact_key']}: {', '.join(art['edited'])}")

    # Pieces the new version adds: created in the live app (apply) or what would be (dry run).
    adds = [a for a in data.get("artifacts", []) if a.get("change") == "added" and not a.get("skip_reason")
            and (a.get("result") in ("added", "failed") if data.get("apply") else not data.get("refused"))]
    if adds:
        click.echo()
        click.echo(f"  {'Added' if data.get('apply') else 'Would add'} ({len(adds)}):")
        for art in adds:
            how = ""
            if art.get("result") == "added":
                how = f" -> {art.get('live_id')}" + (" (created by an earlier attempt, now recorded)"
                                                     if art.get("adopted") else "")
            elif art.get("result") == "failed":
                how = f" FAILED: {art.get('error')}"
            click.echo(f"    - {art.get('artifact_type')} {art.get('artifact_key')}{how}")

    skipped = [a for a in data.get("artifacts", []) if a.get("skip_reason")]
    if skipped:
        click.echo()
        click.echo(f"  Skipped ({len(skipped)}), not applied in place:")
        for art in skipped:
            click.echo(f"    - {art['skip_reason']}")

    # The changed rules run once, so their open alerts carry the new values now rather than at the next schedule.
    reruns = data.get("rules_reexecuted") or []
    if reruns:
        click.echo()
        head = "Would re-run" if not data.get("apply") else "Re-ran"
        click.echo(f"  {head} {len(reruns)} changed or added rule(s) once (members first, then roots):")
        for r in reruns:
            extra = f", {r['result_count']} rows" if r.get("result_count") is not None else ""
            line = (f"    - {r.get('artifact_key')} [{r.get('group_role')}] {r.get('status')}{extra}"
                    f"  ({', '.join(r.get('fields') or [])})")
            if r.get("status") == "running" and r.get("execution_log_id"):
                line += f"  poll: torana rule {r['rule_id']} status {r['execution_log_id']}"
            click.echo(line)
            if r.get("error"):
                click.echo(f"        error: {r['error']}")

    for err in data.get("errors", []):
        click.echo(f"  ERROR {err.get('artifact_key')}: {err.get('error')}")


def _upgrade_poll_seconds() -> float:
    import os
    try:
        return max(float(os.getenv("TORANA_UPGRADE_POLL_S", "10")), 1.0)
    except ValueError:
        return 10.0


def _upgrade_sleep(seconds: float) -> None:
    import time
    time.sleep(seconds)


def _follow_upgrade(client, status_path: str, job_id: str, echo: bool) -> dict:
    """Poll the status until job `job_id` finishes or reads as stalled; print each NEW sentence. Returns the last status.

    The words are the server's (`status_text`): this never rebuilds them."""
    last_text = None
    while True:
        st = client.get(status_path) or {}
        if st.get("job_id") and st.get("job_id") != job_id:
            st = {**st, "status": "failed",
                  "status_text": f"Upgrade job {job_id} was replaced by job {st.get('job_id')}: {st.get('status_text')}"}
        text = st.get("status_text")
        if echo and text and text != last_text:
            click.echo(f"  {text}")
            last_text = text
        if st.get("stalled") or st.get("status") not in ("queued", "running"):
            return st
        _upgrade_sleep(_upgrade_poll_seconds())


def _print_upgrade_status(st: dict) -> None:
    """`--status`: the server's sentence, then the fields an operator checks."""
    click.echo(st.get("status_text") or "No status.")
    if not st.get("job_id"):
        return
    p = st.get("progress") or {}
    bits = [f"job {st['job_id']}", f"status {st.get('status')}", f"phase {st.get('phase') or '-'}"]
    if st.get("heartbeat_age_s") is not None:
        bits.append(f"heartbeat {st['heartbeat_age_s']} s ago")
    if p.get("pages_read_total"):
        bits.append(f"{p['pages_read_total']} Inbox pages read in all")
    if st.get("started_by"):
        bits.append(f"started by {st['started_by']} at {st.get('started_at')}")
    click.echo("  " + " · ".join(bits))
    if st.get("stalled"):
        click.echo("  STALLED: no heartbeat for 10 min; a new upgrade may be started.")


@workspace.command(name="set-default")
@click.pass_context
def workspace_set_default(ctx):
    """Set workspace as the default workspace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    wid = _wid(ctx)

    client = _client(ctx)
    try:
        data = client.post(f"workspaces/{wid}/set-default", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Set default workspace: {wid}")


@workspace.group(name="plans", invoke_without_command=True)
@click.pass_context
def workspace_plans(ctx):
    """Plans associated with a workspace. Use `list` to list them."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@workspace_plans.command(name="list")
@click.option("--search", default=None, help="Search by name.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def workspace_plans_list(ctx, search, page, page_size):
    """List plans in this workspace (shares plans.list_plans_core)."""
    list_plans_core(ctx, workspace_id=_wid(ctx), search=search, page=page,
                    page_size=page_size)


# ---------------------------------------------------------------------------
# Schedulers — collection group (`list`) + singular `scheduler <id>` group.
# ---------------------------------------------------------------------------

@workspace.group(name="schedulers", invoke_without_command=True)
@click.pass_context
def workspace_schedulers(ctx):
    """Schedulers in this workspace. Use `list` to list them."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@workspace_schedulers.command(name="list")
@click.option("--status", default=None, help="Filter by status (active, paused).")
@click.option("--task-type", "task_type", default=None,
              help="Filter by task type (workflow, suite, rule, transformer).")
@click.option("--search", default=None, help="Search in name and description.")
@click.option("--page", default=1, show_default=True)
@click.option("--size", default=20, show_default=True, help="Items per page.")
@click.option("--all", "fetch_all", is_flag=True, default=False,
              help="Auto-paginate and return all results.")
@click.pass_context
def workspace_schedulers_list(ctx, status, task_type, search, page, size, fetch_all):
    """List schedulers in this workspace.

    Convenience form of `torana schedulers list --workspace-id <this workspace>`.
    Shares schedulers.list_schedulers_core — same endpoint/columns. Text output
    shows a NEXT RUN column (e.g. "in 2 hours (2026-06-25 18:00 UTC)").
    """
    list_schedulers_core(ctx, workspace_id=_wid(ctx), status=status, task_type=task_type,
                         search=search, page=page, size=size, fetch_all=fetch_all)


@workspace.group(name="scheduler", invoke_without_command=True)
@click.argument("scheduler_id", metavar="SCHEDULER_ID")
@click.pass_context
def workspace_scheduler(ctx, scheduler_id):
    """Operate on a single scheduler (by ID) in this workspace.

    \b
    Examples:
      torana workspace <UUID> scheduler <SCHEDULER_ID> get
      torana workspace <UUID> scheduler <SCHEDULER_ID> execute
      torana workspace <UUID> scheduler <SCHEDULER_ID> pause
      torana workspace <UUID> scheduler <SCHEDULER_ID> resume
      torana workspace <UUID> scheduler <SCHEDULER_ID> executions
    """
    ctx.ensure_object(dict)
    ctx.obj["_scheduler_id"] = scheduler_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _sched_id(ctx) -> str:
    return ctx.obj.get("_scheduler_id", "") if ctx.obj else ""


@workspace_scheduler.command(name="get")
@click.pass_context
def workspace_scheduler_get(ctx):
    """Get a scheduler by ID.

    Text mode shows a NEXT RUN line (relative + exact UTC).
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    sid = _sched_id(ctx)
    client = _client(ctx)
    try:
        data = client.get(f"scheduler/tasks/{sid}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt in ("text", "table") and isinstance(data, dict):
        data["next_run_display"] = format_next_run(data.get("next_execution_at"))
    output(data, fmt=fmt, fields=fields)


@workspace_scheduler.command(name="execute")
@click.pass_context
def workspace_scheduler_execute(ctx):
    """Trigger immediate execution of a scheduler."""
    sid = _sched_id(ctx)
    client = _client(ctx)
    try:
        client.post(f"scheduler/tasks/{sid}/execute")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    click.echo(f"Executed scheduler: {sid}")


@workspace_scheduler.command(name="pause")
@click.pass_context
def workspace_scheduler_pause(ctx):
    """Pause a scheduler."""
    sid = _sched_id(ctx)
    client = _client(ctx)
    try:
        client.post(f"scheduler/tasks/{sid}/pause")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    click.echo(f"Paused scheduler: {sid}")


@workspace_scheduler.command(name="resume")
@click.pass_context
def workspace_scheduler_resume(ctx):
    """Resume a paused scheduler."""
    sid = _sched_id(ctx)
    client = _client(ctx)
    try:
        client.post(f"scheduler/tasks/{sid}/resume")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    click.echo(f"Resumed scheduler: {sid}")


@workspace_scheduler.command(name="executions")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--size", default=20, show_default=True, help="Items per page.")
@click.option("--status", default=None, help="Filter by status.")
@click.pass_context
def workspace_scheduler_executions(ctx, page, size, status):
    """List execution logs for a scheduler."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    sid = _sched_id(ctx)
    params = {"page": page, "size": size}
    if status:
        params["status"] = status
    client = _client(ctx)
    try:
        data = client.get(f"scheduler/tasks/{sid}/executions", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields)


@workspace.command(name="artifacts")
@click.option("--type", "artifact_type", default=None,
              help="Filter to a single artifact type (e.g. rule, alert, dashboard).")
@click.pass_context
def workspace_artifacts(ctx, artifact_type):
    """List all artifacts belonging to a workspace, across every service.

    Aggregates rules, queries, alerts, alert-routing, dashboards, widgets,
    suites, detection workflows, playbooks, event subscriptions, transformers,
    workspace widgets, pinned dashboards, plans, programs, agent plans, app
    goals and app intents — each fetched from its owning service by workspace_id.

    \b
    text/table : flat list of artifacts with type, name and id (plus a summary).
    json/yaml  : full aggregator payload — {total, by_type, artifacts, errors}.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    wid = _wid(ctx)

    client = _client(ctx)
    try:
        data = client.get(f"workspaces/{wid}/artifacts")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    artifacts = data.get("artifacts", []) if isinstance(data, dict) else []
    if artifact_type:
        artifacts = [a for a in artifacts if a.get("artifact_type") == artifact_type]

    # json / yaml: emit the full structured payload (filtered if --type given).
    if fmt in ("json", "yaml"):
        payload = dict(data) if isinstance(data, dict) else {"artifacts": artifacts}
        if artifact_type:
            payload["artifacts"] = artifacts
            payload["total"] = len(artifacts)
            payload["by_type"] = {artifact_type: len(artifacts)} if artifacts else {}
        output(payload, fmt=fmt, raw=raw, fields=fields)
        return

    # text / table: render the flat artifact list with useful columns.
    output(
        {"items": artifacts, "total": len(artifacts)},
        fmt=fmt, raw=raw, fields=fields,
        columns=[
            ("artifact_type", "TYPE", 22),
            ("name", "NAME", 40),
            ("service", "SERVICE", 22),
            ("id", "ID", 36),
        ],
    )

    # Footer: per-type counts and any per-service fetch errors.
    if isinstance(data, dict):
        if artifact_type:
            by_type = {artifact_type: len(artifacts)} if artifacts else {}
        else:
            by_type = data.get("by_type") or {}
        if by_type:
            summary = "  ".join(f"{k}={v}" for k, v in sorted(by_type.items()))
            click.echo(f"\nBy type: {summary}")
        errors = data.get("errors") or {}
        if errors:
            err_summary = "  ".join(f"{k}: {v}" for k, v in sorted(errors.items()))
            click.echo(f"Unavailable: {err_summary}")


@workspace.command(name="builds")
@click.option("--since", default=None, help="Only builds created at/after this ISO timestamp.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", "page_size", default=None, type=int)
@click.pass_context
def workspace_builds(ctx, since, page, page_size):
    """List program builds for this workspace (Build Observability).

    Each build is one program build (agent_intent), with the proposed-vs-built rollup
    ("M built · K failed"). Drill into one with: torana workspace <id> build <build-id> artifacts
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    wid = _wid(ctx)
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {
        "workspace_id": wid,
        "limit": effective_page_size,
        "offset": (page - 1) * effective_page_size,
    }
    if since:
        params["since"] = since

    client = _client(ctx)
    try:
        data = client.get("observability/builds", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    builds = data.get("builds", [])
    for b in builds:
        r = b.get("rollup") or {}
        built, failed = r.get("built", 0), r.get("failed", 0)
        b["rollup_summary"] = f"{built} built · {failed} failed" if failed else f"{built} built"

    output(
        {"items": builds, "total": data.get("total", len(builds))},
        fmt=fmt, raw=raw, fields=fields,
        columns=[
            ("id", "ID", 36),
            ("goal", "GOAL", 50),
            ("state", "STATE", 10),
            ("rollup_summary", "ARTIFACTS", 22),
            ("created_by", "BUILT BY", 38),
        ],
    )


@workspace.group(name="legacy-build", invoke_without_command=True)
@click.argument("build_id", metavar="BUILD_ID")
@click.pass_context
def workspace_build(ctx, build_id):
    """Inspect a single LEGACY (v1) program build by its intent ID.

    Legacy v1 build path — the finalized build experience is `torana workspace <id> build`
    (proposals → blueprint → cook → deploy). This is kept for existing v1 builds.

    \b
    Examples:
      torana workspace <ws-id> legacy-build <build-id> get
      torana workspace <ws-id> legacy-build <build-id> artifacts
    """
    ctx.ensure_object(dict)
    ctx.obj["_build_id"] = build_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _bid(ctx) -> str:
    return ctx.obj.get("_build_id", "") if ctx.obj else ""


@workspace_build.command(name="get")
@click.pass_context
def workspace_build_get(ctx):
    """Get the build's forensic detail + full ledger (planned + built)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get(f"observability/builds/{_bid(ctx)}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields)


@workspace_build.command(name="artifacts")
@click.pass_context
def workspace_build_artifacts(ctx):
    """List this build's artifacts — proposed-vs-built, with the verbatim error per failure."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get(f"observability/builds/{_bid(ctx)}/artifacts")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    artifacts = data.get("artifacts", [])
    output(
        {"items": artifacts, "total": len(artifacts)},
        fmt=fmt, raw=raw, fields=fields,
        columns=[
            ("type", "TYPE", 14),
            ("name", "NAME", 44),
            ("status", "STATUS", 9),
            ("artifact_id", "ARTIFACT ID", 36),
            ("error", "ERROR", 60),
        ],
    )


@workspace.command(name="summary")
@click.pass_context
def workspace_summary(ctx):
    """Get a summary of the workspace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    wid = _wid(ctx)

    client = _client(ctx)
    try:
        data = client.get(f"workspaces/{wid}/summary")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workspace.command(name="activities")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def workspace_activities(ctx, page, page_size):
    """List activities for a workspace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    wid = _wid(ctx)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        data = client.get(f"workspaces/{wid}/activities", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


def list_timeline_core(client, *, workspace_id, since=None, window=None, limit=50, cursor=None):
    """One page of an app's activity timeline: `{items, next_cursor, anchor, window}`. THE one read of it, for
    `workspace <ID> timeline list` and `app <ID> ai-home events`. Raises APIError / AuthError; the caller reports."""
    params = {"limit": min(limit, 100)}
    if since:
        params["since"] = since
    if window:
        params["window"] = window
    if cursor:
        params["cursor"] = cursor
    return client.get(f"workspaces/{workspace_id}/timeline", params=params)


@workspace.group(name="timeline", invoke_without_command=True)
@click.pass_context
def workspace_timeline(ctx):
    """Homepage 'While You Were Away' timeline. Use `list` to list events."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@workspace_timeline.command(name="list")
@click.option("--since", default=None,
              help="Window start (ISO timestamp). Overrides the last-active anchor.")
@click.option("--window", default=None,
              type=click.Choice(["1h", "6h", "24h", "7d"]),
              help="Convenience preset window instead of the last-active anchor.")
@click.option("--limit", default=50, show_default=True, type=int)
@click.option("--cursor", default=None, help="Opaque pagination cursor.")
@click.pass_context
def workspace_timeline_list(ctx, since, window, limit, cursor):
    """List the ranked, rolled-up homepage timeline for this workspace.

    With no --since / --window, resolves the caller's last-meaningful-interaction
    anchor ("since you were last active"), falling back to the last 24 hours.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    wid = _wid(ctx)

    client = _client(ctx)
    try:
        data = list_timeline_core(client, workspace_id=wid, since=since, window=window, limit=limit, cursor=cursor)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Response is {items, next_cursor, anchor, window}. For text/table, surface the
    # anchor line then the items; json/yaml emit the full envelope.
    if fmt in ("json", "yaml"):
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    anchor = (data or {}).get("anchor") or {}
    if anchor:
        src = anchor.get("source")
        kind = anchor.get("kind")
        label = ("Since last active" if src == "last_interaction" else "Last 24 hours")
        suffix = f" (kind: {kind})" if kind else ""
        click.echo(f"⏱  {label}{suffix} — from {anchor.get('at')}")
    items = (data or {}).get("items", [])
    wrapped = {"items": items, "total": len(items), "page": 1, "page_size": len(items)}
    output(wrapped, fmt=fmt, raw=raw, fields=fields, columns=[
        ("line_type", "TYPE", 8),
        ("producer", "PRODUCER", 14),
        ("title", "TITLE", 60),
        ("rolled_up_count", "×", 3),
        ("created_at", "WHEN", 20),
    ])


@workspace.command(name="runtime-stats")
@click.option("--hours", type=int, default=24, show_default=True,
              help="Look-back window. Run counts follow it; per-rule last run, last success, "
                   "currently_failing and the failure streak do not.")
@click.option("--view", type=click.Choice(["full", "compact"]), default="full", show_default=True,
              help="compact: totals, per-rule status with streaks, up to 10 failures (errors "
                   "truncated) and recent activity as counts instead of rows.")
@click.pass_context
def workspace_runtime_stats(ctx, hours, view):
    """Get runtime statistics for a workspace.

    \b
    Examples:
      TORANA_PROFILE=T1 torana workspace <WS_ID> runtime-stats --hours 72
      TORANA_PROFILE=T1 torana workspace <WS_ID> runtime-stats --hours 72 --view compact --format json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    wid = _wid(ctx)

    client = _client(ctx)
    try:
        data = client.get(f"workspaces/{wid}/runtime-stats", params={"hours": hours, "view": view})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workspace.group(name="dashboards", invoke_without_command=True)
@click.pass_context
def workspace_dashboards(ctx):
    """The dashboards of this app. Use `list` to list them."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@workspace_dashboards.command(name="list")
@click.pass_context
def workspace_dashboards_list(ctx):
    """List the dashboards of this app, in the order the screen shows them.

    \b
    Prints: ID, NAME, WIDGETS (how many widgets are on it), DESCRIPTION.
    Next:   torana dashboard <ID> render

    \b
    Examples:
      torana app <APP_ID> dashboards list
      torana app <APP_ID> dashboards list --json
    """
    list_dashboards_core(ctx, app_id=_wid(ctx))


# ---------------------------------------------------------------------------
# widgets — every widget in the app, swept in one go (health, freshness, status).
# The whole body is `list_app_widgets_core` in widgets.py; one widget's commands are
# on `torana widget <ID>`.
# ---------------------------------------------------------------------------

@workspace.group(name="widgets", invoke_without_command=True)
@click.pass_context
def workspace_widgets(ctx):
    """The widgets of this app. Use `list` to sweep them: health, freshness, status."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@workspace_widgets.command(name="list")
@app_widgets_list_options
@click.pass_context
def workspace_widgets_list(ctx, no_render, refresh, fail_on):
    """List every widget of this app with its health, freshness and status.

    The sweep for "which widgets are stale or broken". One row per widget:

    \b
      HEALTH     whether every field it reads is supplied (the chip on the card):
                 healthy / degraded / blocked (yours or ours) / unknown
      STATUS     what this run returned: success / no_data / error
      FRESHNESS  fresh / stale / unknown / pushed
    HEALTH and STATUS are different questions: a degraded widget still returns rows,
    and a widget with no_data can be perfectly healthy.

    \b
    Exit codes, for scripts:
      exit 0   every widget rendered and nothing matched --fail-on
      exit 1   a widget failed to render, or a widget matched --fail-on

    \b
    Next, for one widget from the list:
      torana widget <ID> render --section empty --section health

    \b
    Examples:
      torana app <APP_ID> widgets list
      torana app <APP_ID> widgets list --fail-on stale --fail-on error
      torana app <APP_ID> widgets list --refresh --fail-on stale --fail-on empty --fail-on error
      torana app <APP_ID> widgets list --no-render        # health only, faster
      torana app <APP_ID> widgets list --json
    """
    list_app_widgets_core(ctx, _wid(ctx), no_render=no_render, refresh=refresh, fail_on=fail_on)


# ---------------------------------------------------------------------------
# landing-config — raw landing-page config object (GET/PUT round-trip)
# ---------------------------------------------------------------------------

@workspace.group(name="landing-config")
@click.pass_context
def workspace_landing_config(ctx):
    """Get or replace the raw landing-page config.

    \b
    The config object (zones, grid) is the same body for GET and PUT — a clean
    round-trip: dump it, edit the file, set it back.

    \b
    Examples:
      torana workspace <UUID> landing-config get
      torana workspace <UUID> landing-config get --file home.json
      torana workspace <UUID> landing-config set --file home.json
    """


@workspace_landing_config.command(name="get")
@click.option("--file", "out_file", default=None, type=click.Path(dir_okay=False, writable=True),
              help="Write the config JSON to this file instead of stdout.")
@click.pass_context
def workspace_landing_config_get(ctx, out_file):
    """Get the landing-page config for this workspace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    wid = _wid(ctx)

    client = _client(ctx)
    try:
        data = client.get(f"workspaces/{wid}/landing-page/config")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if out_file:
        import json as _json
        with open(out_file, "w") as f:
            _json.dump(data, f, indent=2, default=str)
        click.echo(f"Wrote landing-page config to {out_file}")
        return

    # Nested config object; default text to json.
    output(data, fmt=fmt if fmt != "text" else "json")


@workspace_landing_config.command(name="set")
@click.option("--file", "in_file", required=True, type=click.Path(exists=True, dir_okay=False, readable=True),
              help="JSON/YAML file with the landing-page config (same body GET returns).")
@click.pass_context
def workspace_landing_config_set(ctx, in_file):
    """Replace the landing-page config from a file (PUT)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    wid = _wid(ctx)

    body = _load_input_file(in_file)

    client = _client(ctx)
    try:
        data = client.put(f"workspaces/{wid}/landing-page/config", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt == "json":
        import json as _json
        click.echo(_json.dumps(data, indent=2, default=str))
    else:
        click.echo(f"Updated landing-page config for workspace {wid}")


# ---------------------------------------------------------------------------
# home — the app landing page: inspect + edit (CLI equivalent of the UI builder)
# ---------------------------------------------------------------------------

def _load_landing_config(client, wid):
    """Return (workspace_dict, config_dict). config is parsed from JSON if needed."""
    import json as _json
    ws = client.get(f"workspaces/{wid}")
    cfg = ws.get("config")
    if isinstance(cfg, str):
        try:
            cfg = _json.loads(cfg)
        except (ValueError, TypeError):
            cfg = {}
    return ws, (cfg or {})


def _pinned_zone(cfg, create=False):
    """Find the canonical pinned_widgets zone. If multiple exist, return the one
    with the most real (non-empty) widgets and treat the rest as junk to drop.
    Returns (zone_dict_or_None, junk_zone_ids_list)."""
    zones = (cfg.get("landing_page") or {}).get("zones") or []
    pinned = [z for z in zones if z.get("type") == "pinned_widgets"]
    if not pinned:
        if not create:
            return None, []
        zone = {
            "type": "pinned_widgets",
            "label": "Dashboard Widgets",
            "position": {"col": 0, "row": 11, "col_span": 48, "row_span": 8},
            "config": {"pinned_widgets": []},
        }
        cfg.setdefault("landing_page", {}).setdefault("zones", []).append(zone)
        return zone, []
    # Pick the zone with the most real widgets as canonical; others are junk.

    def _real_count(z):
        return len([w for w in (z.get("config") or {}).get("pinned_widgets") or []
                    if w.get("widget_id")])

    pinned.sort(key=_real_count, reverse=True)
    canonical = pinned[0]
    junk_ids = [z.get("id") for z in pinned[1:]]
    return canonical, junk_ids


def _save_landing_config(client, wid, cfg, drop_zone_ids=None):
    """PUT the updated config back, optionally dropping junk zones by id."""
    if drop_zone_ids:
        zones = (cfg.get("landing_page") or {}).get("zones") or []
        cfg["landing_page"]["zones"] = [
            z for z in zones if z.get("id") not in set(drop_zone_ids)
        ]
    file_body = {"config": cfg}
    client.put(f"workspaces/{wid}", json=file_body)


@workspace.group(name="home", invoke_without_command=True)
@click.pass_context
def workspace_home(ctx):
    """Inspect or edit the app home (landing) page.

    \b
    Sub-commands:
      list      Inspect zones, pinned widgets, grid coordinates, and live render state
      pin       Pin a widget to the home page
      unpin     Remove a widget from the home page
      reorder   Change a pinned widget's display order
      config    Inspect or replace the raw landing_page JSON
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@workspace_home.command(name="list")
@click.option("--no-render", is_flag=True, default=False,
              help="Skip the per-widget viz render check (faster; omits STATUS/cached_at).")
@click.pass_context
def home_list(ctx, no_render):
    """Inspect the app home page.

    Prints zones, pinned widgets, their grid coordinates, and live render state.
    """
    ctx.obj["_home_no_render"] = no_render
    _home_inspect(ctx, no_render)


def _home_inspect(ctx, no_render):
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    wid = _wid(ctx)
    client = _client(ctx)
    try:
        _ws, cfg = _load_landing_config(client, wid)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    zones = (cfg.get("landing_page") or {}).get("zones") or []
    rows = []
    for zone in zones:
        if zone.get("type") != "pinned_widgets":
            continue
        pos = zone.get("position") or {}
        coords = (
            f"col {pos.get('col', 0)} row {pos.get('row', 0)} "
            f"({pos.get('col_span', '?')}x{pos.get('row_span', '?')})"
        )
        for w in (zone.get("config") or {}).get("pinned_widgets") or []:
            rows.append({
                "widget_id": w.get("widget_id") or "(empty)",
                "title": w.get("title") or "(untitled)",
                "position": w.get("position"),
                "grid": coords,
                "zone_id": zone.get("id"),
            })

    if not no_render:
        for row in rows:
            widget_id = row["widget_id"]
            if widget_id == "(empty)":
                row["status"] = "NOT_FOUND"
                row["cached_at"] = None
                row["data_as_of"] = None
                row["freshness"] = None
                continue
            try:
                r = client.get(f"render/widget/{widget_id}")
                row["status"] = r.get("status", "?")
                # Query time (kept, but no longer labelled "last refreshed" — that
                # was misleading) plus true data age + freshness verdict (Feature A).
                row["cached_at"] = r.get("cached_at")
                row["data_as_of"] = r.get("data_as_of")
                row["freshness"] = (r.get("freshness") or "").upper() or None
            except APIError as e:
                row["status"] = "NOT_FOUND" if getattr(e, "status_code", None) == 404 else "ERROR"
                row["cached_at"] = None
                row["data_as_of"] = None
                row["freshness"] = None
            except AuthError as e:
                handle_auth_error(e)
                return

    if fmt == "text" and rows:
        cols = [
            ("title", "WIDGET", 34),
            ("widget_id", "WIDGET_ID", 38),
            ("grid", "GRID", 26),
        ]
        if not no_render:
            cols += [
                ("status", "STATUS", 10),
                ("data_as_of", "DATA AS OF", 28),
                ("freshness", "FRESH?", 9),
                ("cached_at", "QUERY RAN", 28),
            ]
        output({"items": rows, "total": len(rows), "page": 1, "page_size": len(rows)},
               fmt=fmt, columns=cols)
    else:
        output({"items": rows, "total": len(rows), "page": 1, "page_size": len(rows)}, fmt=fmt)


@workspace_home.command(name="pin")
@click.option("--widget-id", required=True, help="Widget UUID to pin.")
@click.option("--title", default=None, help="Display title (defaults to the widget's name).")
@click.option("--position", "position", type=int, default=None,
              help="Display order (0-indexed). Appended at the end if omitted.")
@click.pass_context
def home_pin(ctx, widget_id, title, position):
    """Pin a widget to the home page's dashboard-widgets zone."""
    wid = _wid(ctx)
    client = _client(ctx)
    try:
        _ws, cfg = _load_landing_config(client, wid)
        # Resolve a title from the widget if not given.
        if not title:
            try:
                w = client.get(f"widgets/{widget_id}")
                title = w.get("name") or w.get("title") or widget_id
            except APIError:
                title = widget_id
        zone, junk = _pinned_zone(cfg, create=True)
        pinned = zone["config"].setdefault("pinned_widgets", [])
        # Drop any empty entries while we're here (junk cleanup).
        pinned = [w for w in pinned if w.get("widget_id")]
        if any(w.get("widget_id") == widget_id for w in pinned):
            click.echo(f"Widget {widget_id} is already pinned.")
            return
        pos = position if position is not None else len(pinned)
        pinned.append({"widget_id": widget_id, "title": title, "position": pos})
        # Renumber positions to keep them contiguous and ordered.
        pinned.sort(key=lambda w: w.get("position", 0))
        for i, w in enumerate(pinned):
            w["position"] = i
        zone["config"]["pinned_widgets"] = pinned
        _save_landing_config(client, wid, cfg, drop_zone_ids=junk)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    click.echo(f"Pinned '{title}' ({widget_id}). Home now has {len(pinned)} widget(s).")


@workspace_home.command(name="unpin")
@click.option("--widget-id", required=True, help="Widget UUID to remove from the home page.")
@click.pass_context
def home_unpin(ctx, widget_id):
    """Remove a widget from the home page."""
    wid = _wid(ctx)
    client = _client(ctx)
    try:
        _ws, cfg = _load_landing_config(client, wid)
        zone, junk = _pinned_zone(cfg, create=False)
        if zone is None:
            click.echo("No pinned widgets zone on this home page.")
            return
        pinned = [w for w in zone["config"].get("pinned_widgets", []) if w.get("widget_id")]
        new_pinned = [w for w in pinned if w.get("widget_id") != widget_id]
        if len(new_pinned) == len(pinned):
            click.echo(f"Widget {widget_id} was not pinned.")
            return
        for i, w in enumerate(new_pinned):
            w["position"] = i
        zone["config"]["pinned_widgets"] = new_pinned
        _save_landing_config(client, wid, cfg, drop_zone_ids=junk)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    click.echo(f"Unpinned {widget_id}. Home now has {len(new_pinned)} widget(s).")


@workspace_home.command(name="reorder")
@click.option("--widget-id", required=True, help="Widget UUID to move.")
@click.option("--position", "position", type=int, required=True,
              help="New 0-indexed position.")
@click.pass_context
def home_reorder(ctx, widget_id, position):
    """Change a pinned widget's display order."""
    wid = _wid(ctx)
    client = _client(ctx)
    try:
        _ws, cfg = _load_landing_config(client, wid)
        zone, junk = _pinned_zone(cfg, create=False)
        if zone is None:
            click.echo("No pinned widgets zone on this home page.")
            return
        pinned = [w for w in zone["config"].get("pinned_widgets", []) if w.get("widget_id")]
        target = next((w for w in pinned if w.get("widget_id") == widget_id), None)
        if target is None:
            click.echo(f"Widget {widget_id} is not pinned.")
            return
        pinned = [w for w in pinned if w.get("widget_id") != widget_id]
        position = max(0, min(position, len(pinned)))
        pinned.insert(position, target)
        for i, w in enumerate(pinned):
            w["position"] = i
        zone["config"]["pinned_widgets"] = pinned
        _save_landing_config(client, wid, cfg, drop_zone_ids=junk)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    click.echo(f"Moved {widget_id} to position {position}.")


@workspace_home.group(name="config", invoke_without_command=True)
@click.pass_context
def home_config(ctx):
    """Inspect or replace the raw landing_page JSON.

    \b
    Sub-commands:
      dump      Print the current landing_page config
      set       Replace the landing_page from a JSON/YAML file
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@home_config.command(name="dump")
@click.pass_context
def home_config_dump(ctx):
    """Print the current landing_page config."""
    fmt = ctx.obj.get(CTX_FORMAT, "json") if ctx.obj else "json"
    wid = _wid(ctx)
    client = _client(ctx)
    try:
        _ws, cfg = _load_landing_config(client, wid)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(cfg.get("landing_page") or {}, fmt=fmt if fmt != "text" else "json")


@home_config.command(name="set")
@click.option("--file", "input_file", required=True, metavar="FILE",
              help="JSON/YAML file with a new landing_page (or full config). Replaces the current one.")
@click.pass_context
def home_config_set(ctx, input_file):
    """Replace the landing_page from a file.

    \b
    The file may contain either {"landing_page": {...}}, {"config": {...}},
    or a bare landing_page object.
    """
    wid = _wid(ctx)
    client = _client(ctx)
    try:
        _ws, cfg = _load_landing_config(client, wid)
        new_data = _load_input_file(input_file)
        # Accept either a wrapped {"landing_page": {...}} / {"config": {...}} or bare.
        if "config" in new_data and isinstance(new_data["config"], dict):
            cfg = new_data["config"]
        elif "landing_page" in new_data:
            cfg["landing_page"] = new_data["landing_page"]
        else:
            cfg["landing_page"] = new_data
        _save_landing_config(client, wid, cfg)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    click.echo("Home landing_page config updated.")


# ---------------------------------------------------------------------------
# Workspace-scoped collections — group + `list` (NEVER a bare dump command).
# Bare `torana workspace <id> <resources>` shows help and prints nothing.
# Use `... <resources> list` to list. See CLAUDE.md "Collections are groups".
# ---------------------------------------------------------------------------

@workspace.group(name="rules", invoke_without_command=True)
@click.pass_context
def workspace_rules(ctx):
    """Rules associated with a workspace. Use `list` to list them."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@workspace_rules.command(name="list")
@click.option("--severity", default=None,
              type=click.Choice(["low", "medium", "high", "critical"], case_sensitive=False),
              help="Filter by severity.")
@click.option("--state", default=None,
              type=click.Choice(["active", "inactive", "draft"], case_sensitive=False),
              help="Filter by state.")
@click.option("--search", default=None, help="Search by name or description.")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", default=None, type=int,
              help="Results per page (max 100, default from config).")
@click.option("--all", "fetch_all", is_flag=True, default=False,
              help="Auto-paginate and return all results.")
@click.option("--validate-sql", "validate_sql", is_flag=True, default=False,
              help="Dry-run each rule's SQL against the datalake (EXPLAIN).")
@click.pass_context
def workspace_rules_list(ctx, severity, state, search, page, page_size, fetch_all, validate_sql):
    """List rules in this workspace.

    Convenience form of `torana rules list --workspace-id <this workspace>`.
    Shares the exact same routine (rules.list_rules_core) — same endpoint,
    columns, filters, and pagination; only the workspace filter is pre-bound.
    """
    list_rules_core(ctx, severity=severity, state=state, workspace_id=_wid(ctx),
                    search=search, page=page, page_size=page_size, fetch_all=fetch_all,
                    validate_sql=validate_sql)


@workspace.group(name="rule", invoke_without_command=True)
@click.argument("rule_id", metavar="RULE_ID")
@click.pass_context
def workspace_rule(ctx, rule_id):
    """Operate on a single rule (by ID) in the context of this workspace.

    \b
    Rule IDs are global; these verbs delegate to the top-level rule resource.
    Examples:
      torana workspace <UUID> rule <RULE_ID> get
      torana workspace <UUID> rule <RULE_ID> execute
    """
    ctx.ensure_object(dict)
    ctx.obj["_rule_id"] = rule_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _ws_rule_id(ctx) -> str:
    return ctx.obj.get("_rule_id", "") if ctx.obj else ""


@workspace_rule.command(name="get")
@click.pass_context
def workspace_rule_get(ctx):
    """Get a rule by ID."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    rid = _ws_rule_id(ctx)
    client = _client(ctx)
    try:
        data = client.get(f"rules/{rid}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields)


@workspace_rule.command(name="execute")
@click.pass_context
def workspace_rule_execute(ctx):
    """Execute a rule by ID. Prints the queued execution-log/job id.

    Check progress with: torana workspace <id> rule <RID> status <LOG_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    rid = _ws_rule_id(ctx)
    client = _client(ctx)
    try:
        data = client.post(f"rules/{rid}/execute", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt)


@workspace_rule.command(name="status")
@click.argument("LOG_ID", metavar="LOG_ID")
@click.pass_context
def workspace_rule_status(ctx, log_id):
    """Get the status of a rule execution.

    LOG_ID is the id printed by `rule <id> execute` (a queue-job id) OR a real
    execution-log id — the status endpoint accepts both. The rule id is taken
    from context, so no --rule-id is needed.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    rid = _ws_rule_id(ctx)
    client = _client(ctx)
    try:
        data = client.get(f"rules/{rid}/executions/{log_id}/status")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields)


@workspace.group(name="workflows", invoke_without_command=True)
@click.pass_context
def workspace_workflows(ctx):
    """Workflows associated with a workspace. Use `list` to list them."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@workspace_workflows.command(name="list")
@click.option("--state", default=None, help="Filter by state (active, draft, archived).")
@click.option("--search", default=None, help="Search by name.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.pass_context
def workspace_workflows_list(ctx, state, search, page, page_size, fetch_all):
    """List workflows in this workspace (shares workflows.list_workflows_core)."""
    list_workflows_core(ctx, workspace_id=_wid(ctx), state=state, search=search,
                        page=page, page_size=page_size, fetch_all=fetch_all)


@workspace.group(name="playbooks", invoke_without_command=True)
@click.pass_context
def workspace_playbooks(ctx):
    """Playbooks associated with a workspace. Use `list` to list them."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@workspace_playbooks.command(name="list")
@click.option("--state", default=None, help="Filter by state.")
@click.option("--search", default=None, help="Search by name.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.pass_context
def workspace_playbooks_list(ctx, state, search, page, page_size, fetch_all):
    """List playbooks in this workspace (shares playbooks.list_playbooks_core)."""
    list_playbooks_core(ctx, workspace_id=_wid(ctx), state=state, search=search,
                        page=page, page_size=page_size, fetch_all=fetch_all)


@workspace.group(name="alert-routes", invoke_without_command=True)
@click.pass_context
def workspace_alert_routes(ctx):
    """Alert routes associated with a workspace. Use `list` to list them."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@workspace_alert_routes.command(name="list")
@click.option("--severity", default=None,
              type=click.Choice(["critical", "high", "medium", "low", "info"],
                                case_sensitive=False),
              help="Filter by severity.")
@click.option("--search", default=None, help="Search by name.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.pass_context
def workspace_alert_routes_list(ctx, severity, search, page, page_size, fetch_all):
    """List alert routes in this workspace (shares alert_routes.list_alert_routes_core)."""
    list_alert_routes_core(ctx, workspace_id=_wid(ctx), severity=severity, search=search,
                           page=page, page_size=page_size, fetch_all=fetch_all)


@workspace.group(name="transformers", invoke_without_command=True)
@click.pass_context
def workspace_transformers(ctx):
    """Transformers associated with a workspace. Use `list` to list them."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@workspace_transformers.command(name="list")
@click.option("--state", default=None,
              type=click.Choice([STATE_MATERIALIZED, STATE_LIVE, STATE_STALE, STATE_FAILED,
                                 STATE_NEVER_RUN], case_sensitive=False),
              help="Show only transformers in this materialization state.")
@click.option("--search", default=None, help="Search by name.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.pass_context
def workspace_transformers_list(ctx, state, search, page, page_size, fetch_all):
    """List transformers in this workspace, with the STATE of each output table.

    Same states and same resolution as `torana datalake transformers list` —
    this form only pre-binds the workspace. See that command for what each
    state token means.
    """
    # --state is resolved client-side (no server field), so it routes through the
    # filtered path exactly as the top-level list does. One derivation, both forms.
    if state:
        _list_transformers_filtered(ctx, workspace_id=_wid(ctx), search=search,
                                    state=state.lower())
        return
    list_transformers_core(ctx, workspace_id=_wid(ctx), search=search,
                           page=page, page_size=page_size, fetch_all=fetch_all)


@workspace.group(name="alerts", invoke_without_command=True)
@click.pass_context
def workspace_alerts(ctx):
    """Alerts associated with a workspace. Use `list` to list them."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@workspace_alerts.command(name="list")
@click.option("--severity", default=None,
              type=click.Choice(["low", "medium", "high", "critical"], case_sensitive=False),
              help="Filter by severity.")
@click.option("--state", default=None, help="Filter by state (e.g. open, closed, in_progress).")
@click.option("--rule-id", default=None, help="Filter by detection rule UUID.")
@click.option("--assigned-to", default=None, help="Filter by assigned user.")
@click.option("--status", "status_filter", default=None,
              help="Filter by status. Accepts comma-separated values, e.g. "
                   "'pending_remediation,escalated'. "
                   "Valid: open, triaging, awaiting_input, pending_remediation, "
                   "escalated, resolved, closed.")
@click.option("--page", default=None, type=int, help="Page number (1-indexed).")
@click.option("--page-size", default=None, type=int,
              help="Results per page (max 100). Alias of --limit.")
@click.option("--limit", default=None, type=int,
              help="Max results to return (alias of --page-size).")
@click.option("--offset", default=None, type=int,
              help="Results to skip (alias of (page-1)*page_size).")
@click.option("--decided-by", "decided_by", default=None, type=CommaChoice(DECIDED_BY_CHOICES),
              help="Who decided the verdict: system (a rule declared it), agent or "
                   "user. Comma-separated for several.")
@click.option("--finding-severity", "finding_severity", default=None,
              help="Severity of the matched FINDING (critical/high/medium/low). "
                   "Distinct from --severity, which is the RULE's.")
@click.option("--action", "action", default=None, help=ACTION_HELP)
@click.option("--category", "category", default=None,
              help="The rule-declared entry kind, e.g. posture. Comma-separated for "
                   "several. This is the KEY, not the label on the chip.")
@box_option
@click.option("--why", "why", default=None, type=CommaChoice(WHY_CHOICES),
              help="Why a closed item is closed: fixed, accepted_risk, wont_fix, "
                   "duplicate, false_positive, benign (a person's reason), closed, or "
                   "moved. Comma-separated for several.")
@click.option("--verdict", "verdict", default=None, type=CommaChoice(VERDICT_CHOICES), help=VERDICT_HELP)
@click.option("--reason", "reason", default=None,
              help="The exact closing reason (a person's or the platform's, e.g. "
                   "closed_at_source, no_longer_reported). Comma-separated for several.")
@entries_option("The list shows ENTRIES (roots and ungrouped items) by default, exactly what the Inbox lists; this says so "
                "explicitly. Not the same as --roots-only.")
@click.option("--include-members", "include_members", is_flag=True, default=False,
              help="Also list the members that belong inside an entry (diagnostics). A member "
                   "is normally seen only through `torana alert <entry-id> members`.")
@click.option("--all", "fetch_all", is_flag=True, default=False,
              help="Auto-paginate: fetch every PAGE of the list. It covers the ENTRIES (and ungrouped items) the filters match, which is what "
                   "the Inbox lists; the findings grouped inside entries are not part of it (add --include-members). The footer and "
                   "`members_not_included` in --format json say how many were left out.")
@overdue_option
@sla_state_option
@team_option
@signal_options
@extra_list_options
@time_options
@click.pass_context
def workspace_alerts_list(ctx, severity, state, status_filter, rule_id, assigned_to,
                          page, page_size, limit, offset, decided_by, finding_severity,
                          action, category, boxes, why, verdict, reason, inbox_rows,
                          include_members, fetch_all, overdue, sla_state, team, exploited, fix_available,
                          repository, cloud, likelihood_band, min_likelihood, group_by,
                          sort_by, since, date_from, date_to, cve, cwe, where, search):
    """List alerts in this workspace.

    Convenience form of `torana alerts list --workspace-id <this workspace>`.
    Shares the exact same routine (alerts.list_alerts_core) — same endpoint,
    columns, filters, and pagination; only the workspace filter is pre-bound.
    """
    list_alerts_core(ctx, severity=severity, state=state, status_filter=status_filter,
                     rule_id=rule_id, workspace_id=_wid(ctx), assigned_to=assigned_to,
                     page=page, page_size=page_size, limit=limit, offset=offset,
                     fetch_all=fetch_all, decided_by=decided_by,
                     finding_severity=finding_severity, action=action, category=category,
                     boxes=boxes, why=why, verdict=verdict, inbox_rows=inbox_rows,
                     include_members=include_members, reason=reason, overdue=overdue, sla_state=sla_state, team=team,
                     exploited=exploited, fix_available=fix_available, repository=repository, cloud=cloud,
                     likelihood_band=likelihood_band, min_likelihood=min_likelihood, group_by=group_by,
                     sort_by=sort_by, since=since, date_from=date_from, date_to=date_to, cve=cve, cwe=cwe, where=where, search=search)


@workspace.group(name="alert", invoke_without_command=True)
@click.argument("alert_id", metavar="ALERT_ID")
@click.pass_context
def workspace_alert(ctx, alert_id):
    """Operate on a single alert (by ID) in the context of this workspace.

    \b
    Alert IDs are global; these verbs delegate to the top-level alert resource
    (alert.py) — the SAME command objects, so behaviour can never drift.
    Examples:
      torana workspace <UUID> alert <ALERT_ID> get
      torana workspace <UUID> alert <ALERT_ID> status --status resolved
      torana workspace <UUID> alert <ALERT_ID> verdict --triage-verdict true_positive
    """
    ctx.ensure_object(dict)
    ctx.obj["_alert_id"] = alert_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


# Re-attach every verb from the top-level `alert` group (alert.py) onto the
# workspace-scoped singular group. The verbs read the alert id from
# ctx.obj["_alert_id"], which both groups set identically, so a single command
# definition serves both call sites with no duplication and no drift.
for _name, _cmd in _alert_group.commands.items():
    workspace_alert.add_command(_cmd, name=_name)


# ---------------------------------------------------------------------------
# Agents — workspace-agent ATTACHMENTS (program-framework), collection group
# (`list`) + singular `agent <ATTACHMENT_ID>` group (`get`, `detach`).
#
# NOTE: these are workspace *attachments* (the workspace_agents join rows), not
# agent-builder agents. The id used by `get`/`detach` is the ATTACHMENT id
# (the `id` field of each list item), NOT the underlying `agent_id`.
# ---------------------------------------------------------------------------

_WS_AGENT_COLS = [
    ("id", "ATTACHMENT ID", 36),
    ("agent_name", "AGENT NAME", 34),
    ("role", "ROLE", 12),
    ("agent_id", "AGENT ID", 36),
    ("autonomy_mode", "AUTONOMY", 18),
    ("attached_at", "ATTACHED", 20),
]


@workspace.group(name="agents", invoke_without_command=True)
@click.pass_context
def workspace_agents(ctx):
    """Agent attachments on this workspace. Use `list` to list them."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@workspace_agents.command(name="list")
@click.option("--role", default=None,
              help="Filter by role (e.g. builder, operator, triage).")
@click.pass_context
def workspace_agents_list(ctx, role):
    """List agent attachments on this workspace.

    Wraps GET /workspaces/{id}/agents (program-framework). The ATTACHMENT ID
    column is what `agent detach` operates on (distinct from the underlying
    agent-builder AGENT ID).
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    params = {}
    if role:
        params["role"] = role
    client = _client(ctx)
    try:
        data = client.get(f"workspaces/{_wid(ctx)}/agents", params=params or None)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    # Endpoint returns {total, items}; normalize to the standard list envelope.
    if isinstance(data, dict):
        items = data.get("items", [])
        data = {"items": items, "total": data.get("total", len(items)),
                "page": 1, "page_size": len(items)}
    output(data, fmt=fmt, raw=raw, fields=fields, columns=_WS_AGENT_COLS)


@workspace_agents.command(name="attach")
@click.option("--agent-name", "agent_name", required=True,
              help="Agent name (required by the API).")
@click.option("--role", required=True,
              type=click.Choice(["advisor", "builder", "operator", "triage"]),
              help="Attachment role.")
@click.option("--agent-id", "agent_id", default=None,
              help="Agent-builder agent UUID to bind. Omit to resolve by name.")
@click.option("--autonomy-mode", "autonomy_mode", default=None,
              type=click.Choice(["suggest_only", "human_in_the_loop",
                                 "autonomous_with_guardrails"]),
              help="Autonomy mode. NOTE: the fully-autonomous value is "
                   "`autonomous_with_guardrails` — there is no bare `autonomous`.")
@click.option("--responsibility", default=None, metavar="JSON",
              help="Responsibility object as JSON.")
@click.option("--file", "input_file", default=None, metavar="FILE",
              help="JSON/YAML file with the full attachment body.")
@click.pass_context
def workspace_agents_attach(ctx, agent_name, role, agent_id, autonomy_mode,
                            responsibility, input_file):
    """Attach an agent to this workspace.

    \b
    Examples:
      torana workspace <UUID> agents attach --agent-name "VM Expert" --role builder
      torana workspace <UUID> agents attach --agent-name X --role builder --agent-id <AGENT_UUID>
    """
    import json as _json
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    wid = _wid(ctx)

    body = {}
    if input_file:
        body.update(_load_input_file(input_file) or {})
    body["agent_name"] = agent_name
    body["role"] = role
    if agent_id:
        body["agent_id"] = agent_id
    if autonomy_mode:
        body["autonomy_mode"] = autonomy_mode
    if responsibility:
        try:
            body["responsibility"] = _json.loads(responsibility)
        except ValueError as exc:
            click.echo(f"ERROR: --responsibility is not valid JSON: {exc}", err=True)
            ctx.exit(6)

    client = _client(ctx)
    try:
        data = client.post(f"workspaces/{wid}/agents", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Attached agent: {(data or {}).get('id', '')}")


@workspace.group(name="agent", invoke_without_command=True)
@click.argument("attachment_id", metavar="ATTACHMENT_ID")
@click.pass_context
def workspace_agent(ctx, attachment_id):
    """Operate on a single agent ATTACHMENT (by attachment id) in this workspace.

    \b
    The ATTACHMENT_ID is the `id` from `agents list` — NOT the agent-builder
    agent_id. Examples:
      torana workspace <UUID> agent <ATTACHMENT_ID> get
      torana workspace <UUID> agent <ATTACHMENT_ID> detach
    """
    ctx.ensure_object(dict)
    ctx.obj["_attachment_id"] = attachment_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _att_id(ctx) -> str:
    return ctx.obj.get("_attachment_id", "") if ctx.obj else ""


@workspace_agent.command(name="get")
@click.pass_context
def workspace_agent_get(ctx):
    """Get a single agent attachment by attachment id."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get(f"workspaces/{_wid(ctx)}/agents/{_att_id(ctx)}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields)


@workspace_agent.command(name="update")
@click.option("--agent-id", "agent_id", default=None,
              help="Repoint this attachment at a different agent (recovers a stale agent_id).")
@click.option("--autonomy-mode", "autonomy_mode", default=None,
              type=click.Choice(["suggest_only", "human_in_the_loop",
                                 "autonomous_with_guardrails"]),
              help="New autonomy mode. NOTE: the fully-autonomous value is "
                   "`autonomous_with_guardrails` — there is no bare `autonomous`.")
@click.option("--state", default=None, type=click.Choice(["active", "disabled"]),
              help="Enable or disable this attachment.")
@click.option("--responsibility", default=None, metavar="JSON",
              help="Replacement responsibility object as JSON.")
@click.option("--file", "input_file", default=None, metavar="FILE",
              help="JSON/YAML file with fields to update.")
@click.pass_context
def workspace_agent_update(ctx, agent_id, autonomy_mode, state, responsibility, input_file):
    """Update an agent attachment — including repointing it at a different agent.

    Repointing preserves the attachment's identity and its responsibility /
    guardrails / autonomy config. Detach + re-attach loses all of it (CLI-5).

    \b
    Examples:
      torana workspace <UUID> agent <ATT_ID> update --agent-id <NEW_AGENT_UUID>
      torana workspace <UUID> agent <ATT_ID> update --state disabled
    """
    import json as _json
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body.update(_load_input_file(input_file) or {})
    if agent_id:
        body["agent_id"] = agent_id
    if autonomy_mode:
        body["autonomy_mode"] = autonomy_mode
    if state:
        body["state"] = state
    if responsibility:
        try:
            body["responsibility"] = _json.loads(responsibility)
        except ValueError as exc:
            click.echo(f"ERROR: --responsibility is not valid JSON: {exc}", err=True)
            ctx.exit(6)

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        ctx.exit(2)

    client = _client(ctx)
    try:
        data = client.patch(f"workspaces/{_wid(ctx)}/agents/{_att_id(ctx)}", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated agent attachment: {_att_id(ctx)}")


@workspace_agent.command(name="detach")
@click.option("--yes", "-y", is_flag=True, default=False,
              help="Skip the confirmation prompt.")
@click.pass_context
def workspace_agent_detach(ctx, yes):
    """Detach (soft-delete) an agent attachment from this workspace.

    Calls DELETE /workspaces/{id}/agents/{attachment_id} — a soft-detach
    (sets detached_at / is_deleted). Does NOT delete the underlying
    agent-builder agent.
    """
    att = _att_id(ctx)
    wid = _wid(ctx)
    _confirm(f"Detach agent attachment {att} from workspace {wid}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"workspaces/{wid}/agents/{att}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    click.echo(f"Detached agent attachment: {att}")


@workspace.command(name="config")
@click.pass_context
def workspace_config(ctx):
    """Get the landing page config for a workspace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    wid = _wid(ctx)

    client = _client(ctx)
    try:
        data = client.get(f"workspaces/{wid}/landing-page/config")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workspace.command(name="update-config")
@click.option("--file", "input_file", required=True, metavar="FILE",
              help="JSON/YAML file with config update body.")
@click.pass_context
def workspace_update_config(ctx, input_file):
    """Update the landing page config for a workspace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    wid = _wid(ctx)

    body = _load_input_file(input_file)

    client = _client(ctx)
    try:
        data = client.put(f"workspaces/{wid}/landing-page/config", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated landing page config for workspace: {wid}")


@workspace.command(name="sweep")
@click.pass_context
def workspace_sweep(ctx):
    """Trigger a landing page sweep for a workspace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    wid = _wid(ctx)

    client = _client(ctx)
    try:
        data = client.post(f"workspaces/{wid}/landing-page/sweep", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)

    # The sweep response carries `error` and `failures[]`, and the generic renderer
    # dumps them as an opaque field — so a sweep that failed, or that dropped
    # individual cards, read as a bare status line with no cause. Surface them.
    # (`status: partial` means soft failures: some cards evaluated, some did not.)
    if fmt == "text" and isinstance(data, dict):
        err = data.get("error")
        failures = data.get("failures") or []
        if err:
            click.echo(f"\nERROR: {err}", err=True)
        if failures:
            click.echo(f"\n{len(failures)} card(s) failed to evaluate:", err=True)
            for f in failures:
                if isinstance(f, dict):
                    who = f.get("title") or f.get("id") or f.get("kind") or "?"
                    why = f.get("error") or f.get("reason") or f.get("message") or f
                    click.echo(f"  \u2717 {who}: {why}", err=True)
                else:
                    click.echo(f"  \u2717 {f}", err=True)
        if err or failures:
            import sys
            sys.exit(1)


@workspace.command(name="rename")
@click.argument("new_name", metavar="NEW_NAME")
@click.pass_context
def workspace_rename(ctx, new_name):
    """Rename this workspace.

    \b
    Renaming previously required hand-writing a JSON body and passing --file,
    which is not guessable from the CLI's own help.

    \b
    Example:
      torana workspace <UUID> rename "Exposure Management"
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    wid = _wid(ctx)

    client = _client(ctx)
    try:
        data = client.put(f"workspaces/{wid}", json={"name": new_name})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        applied = data.get("name") if isinstance(data, dict) else None
        if applied and applied != new_name:
            click.echo(f"ERROR: rename was NOT applied — server kept '{applied}'.", err=True)
            import sys
            sys.exit(1)
        click.echo(f"Renamed workspace {wid} to: {applied or new_name}")


@workspace.command(name="reconcile-pins")
@click.pass_context
def workspace_reconcile_pins(ctx):
    """Backfill home-page pins for build_v2 dashboard/widget artifacts deployed
    before auto-pin-on-deploy existed (BUILD_V2_ARTIFACT_HOME_PIN_SPEC.md § 3.3.5).

    SA-only — the server endpoint this calls requires the super_admin role; the
    CLI itself carries no role check of its own, so a non-SA caller sees a 403
    from the API, same as any other admin/* endpoint.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    wid = _wid(ctx)

    client = _client(ctx)
    try:
        data = client.post(f"admin/workspace-sweeps/{wid}/reconcile-pins", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workspace.command(name="graph")
@click.option("--mermaid", is_flag=True, default=False,
              help="Render as a Mermaid diagram.")
@click.pass_context
def workspace_graph(ctx, mermaid):
    """Get the app-graph (nodes + edges) for a workspace.

    \b
    Examples:
      torana workspace <UUID> graph
      torana workspace <UUID> graph --json
      torana workspace <UUID> graph --mermaid | pbcopy
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    wid = _wid(ctx)

    client = _client(ctx)
    try:
        data = client.get(f"workspaces/{wid}/graph")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if mermaid:
        click.echo(_render_mermaid(data))
        return

    if fmt in ("json", "yaml"):
        output(data, fmt=fmt, fields=fields)
        return

    _render_text_summary(data)


def _render_text_summary(graph: dict) -> None:
    workspace_id = graph.get("workspace_id", "")
    nodes = graph.get("nodes", [])
    edges = graph.get("edges", [])
    counts = graph.get("counts", {})

    click.echo(f"App graph for workspace {workspace_id}")
    click.echo(f"  {len(nodes)} nodes · {len(edges)} edges")
    click.echo("")

    kinds_order = ["source", "datalake", "pipeline", "agent", "rule",
                   "route", "playbook", "outcome"]
    by_kind = {}
    for n in nodes:
        by_kind.setdefault(n.get("kind"), []).append(n)
    for kind in kinds_order:
        bucket = by_kind.get(kind) or []
        if not bucket:
            continue
        click.echo(f"  {kind.upper()}  ({counts.get(kind, len(bucket))})")
        for n in bucket:
            title = n.get("title") or n.get("id")
            stats = " · ".join(n.get("stats") or [])
            line = f"    • {title}"
            if stats:
                line += f"  [{stats}]"
            click.echo(line)
        click.echo("")

    if edges:
        click.echo(f"  EDGES ({len(edges)})")
        for e in edges:
            style = e.get("style") or "default"
            arrow = "==>" if style == "primary" else ("-.->" if style == "dashed" else "-->")
            label = f" :{e.get('label')}" if e.get("label") else ""
            click.echo(f"    {e.get('from')}  {arrow}  {e.get('to')}{label}")


def _render_mermaid(graph: dict) -> str:
    out = ["flowchart LR"]
    style_map = {
        "source":   "fill:#E2E8F0,stroke:#64748B",
        "datalake": "fill:#DCFCE7,stroke:#22C55E",
        "pipeline": "fill:#DBEAFE,stroke:#3B82F6",
        "agent":    "fill:#EDE9FE,stroke:#7C3AED",
        "rule":     "fill:#FEF3C7,stroke:#F59E0B",
        "route":    "fill:#FEF3C7,stroke:#F59E0B",
        "playbook": "fill:#DBEAFE,stroke:#3B82F6",
        "outcome":  "fill:#FEE2E2,stroke:#DC2626",
    }

    def _mid(node_id: str) -> str:
        return node_id.replace(":", "_").replace("-", "_")

    for n in graph.get("nodes", []):
        nid = _mid(n.get("id", ""))
        title = (n.get("title") or "").replace('"', "'")
        kind = (n.get("kind") or "").upper()
        out.append(f'  {nid}["<b>{kind}</b><br/>{title}"]')

    for n in graph.get("nodes", []):
        kind = n.get("kind")
        if kind and kind in style_map:
            out.append(f"  style {_mid(n.get('id', ''))} {style_map[kind]}")

    for e in graph.get("edges", []):
        frm = _mid(e.get("from", ""))
        to = _mid(e.get("to", ""))
        style = e.get("style") or "default"
        if style == "dashed":
            arrow = "-.->"
        elif style == "primary":
            arrow = "==>"
        else:
            arrow = "-->"
        label = e.get("label")
        if label:
            out.append(f"  {frm} {arrow}|{label}| {to}")
        else:
            out.append(f"  {frm} {arrow} {to}")

    return "\n".join(out)


# ---------------------------------------------------------------------------
# KPI cards
# ---------------------------------------------------------------------------

def _landing_zone_update(client, wid, zone_type, key, mutate):
    """Read-modify-write ONE zone's item list in the landing-page config, preserving
    every other zone and the grid.

    The landing config is the ``{grid, zones}`` shape; items live at
    ``zones[type==zone_type].config[key]``. Earlier add/remove commands read a flat
    ``config[key]`` (always empty) and PUT a flat ``{key: items}`` body — which
    CLOBBERED the entire landing page (all other KPIs/attention/pins + grid). This
    helper mutates only the target zone and writes the whole config back.

    ``mutate(items) -> new_items``. Creates the zone if absent; migrates a legacy
    flat config into a zone. Raises APIError/AuthError to the caller.
    """
    config = client.get(f"workspaces/{wid}/landing-page/config")
    if not isinstance(config, dict):
        config = {}
    zones = config.get("zones")
    if isinstance(zones, list):
        target = next((z for z in zones if z.get("type") == zone_type), None)
        if target is None:
            target = {"type": zone_type, "config": {}}
            zones.append(target)
        target.setdefault("config", {})
        target["config"][key] = mutate(list(target["config"].get(key, []) or []))
    else:  # legacy flat config → migrate into a proper zones structure
        config = {"grid": config.get("grid", {}),
                  "zones": [{"type": zone_type,
                             "config": {key: mutate(list(config.get(key, []) or []))}}]}
    client.put(f"workspaces/{wid}/landing-page/config", json=config)
    return config


@workspace.group(name="kpi")
def workspace_kpi():
    """Manage workspace KPI cards (landing page).

    \b
    Examples:
      torana workspace <UUID> kpi list
      torana workspace <UUID> kpi add --title "Open Criticals" --sql "SELECT count(*) FROM alerts"
      torana workspace <UUID> kpi remove --kpi-id <UUID>
    """


@workspace_kpi.command(name="list")
@click.pass_context
def workspace_kpi_list(ctx):
    """List KPI cards for the workspace landing page."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    wid = _wid(ctx)

    client = _client(ctx)
    try:
        config = client.get(f"workspaces/{wid}/landing-page/config")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # KPIs live in the landing-page config under zones[type=kpi_bar].config.kpis
    # (the {grid, zones} shape). Earlier code read a flat config["kpis"], which is
    # absent → always empty. Walk the zones; fall back to a legacy flat shape.
    items = []
    for _z in (config.get("zones", []) if isinstance(config, dict) else []):
        if _z.get("type") == "kpi_bar":
            items.extend((_z.get("config", {}) or {}).get("kpis", []) or [])
    if not items and isinstance(config, dict) and config.get("kpis"):
        items = config.get("kpis") or []
    result = {"items": items, "total": len(items), "page": 1, "page_size": len(items)}
    output(result, fmt=fmt, raw=raw, fields=fields,
           columns=[("id", "ID", 36), ("label", "LABEL", 30), ("format", "FORMAT", 12)])


@workspace_kpi.command(name="add")
@click.option("--title", "label", required=True, help="Display label for the KPI card.")
@click.option("--sql", "sql_command", required=True, help="SQL query returning the KPI value.")
@click.option("--description", default="", help="Semantic description of this KPI.")
@click.option("--format", "fmt_type", default="number",
              type=click.Choice(["number", "percent", "currency", "duration"]),
              show_default=True)
@click.option("--icon", default="chart-bar", show_default=True)
@click.pass_context
def workspace_kpi_add(ctx, label, sql_command, description, fmt_type, icon):
    """Add a KPI card to the workspace landing page."""
    import uuid
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    wid = _wid(ctx)

    client = _client(ctx)
    new_kpi = {
        "id": str(uuid.uuid4()),
        "label": label,
        "icon": icon,
        "color": "blue",
        "format": fmt_type,
        "trend_enabled": True,
        "description": description,
        "data_source": {"type": "sql", "query": sql_command},
        "color_rules": [],
    }
    try:
        _landing_zone_update(client, wid, "kpi_bar", "kpis",
                             lambda ks: ks + [new_kpi])
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(new_kpi, fmt=fmt)
    else:
        click.echo(f"Added KPI card: {new_kpi['id']}")


@workspace_kpi.command(name="update")
@click.option("--kpi-id", "kpi_id", required=True, help="KPI card UUID to update.")
@click.option("--title", "label", default=None, help="New display label.")
@click.option("--sql", "sql_command", default=None, help="New SQL query for the KPI value.")
@click.option("--description", default=None, help="New semantic description.")
@click.option("--format", "fmt_type", default=None,
              type=click.Choice(["number", "percent", "currency", "duration"]))
@click.option("--icon", default=None, help="New icon name.")
@click.option("--file", "input_file", default=None, metavar="FILE",
              help="JSON/YAML file with fields to merge into the card.")
@click.pass_context
def workspace_kpi_update(ctx, kpi_id, label, sql_command, description, fmt_type, icon,
                         input_file):
    """Update a KPI card in place, preserving its id.

    Fixing a shipped KPI previously meant remove + re-add, which minted a new id and
    lost the card's identity (CLI-13). This merges changes into the existing card, so
    anything referencing the id keeps working.

    \b
    Examples:
      torana workspace <UUID> kpi update --kpi-id <ID> --sql "SELECT count(*) FROM alerts"
      torana workspace <UUID> kpi update --kpi-id <ID> --title "Open Criticals"
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    wid = _wid(ctx)

    # Collect only the fields the caller actually supplied — an omitted flag must
    # leave the stored value alone, never reset it to a default.
    changes = {}
    if input_file:
        changes.update(_load_input_file(input_file) or {})
    if label is not None:
        changes["label"] = label
    if description is not None:
        changes["description"] = description
    if fmt_type is not None:
        changes["format"] = fmt_type
    if icon is not None:
        changes["icon"] = icon
    if sql_command is not None:
        # SQL lives nested under data_source; accept the flat --sql for usability.
        changes["data_source"] = {"type": "sql", "query": sql_command}

    if not changes:
        click.echo("ERROR: No fields to update.", err=True)
        ctx.exit(2)

    # A missing id must abort BEFORE the config is written back — otherwise an
    # unknown id would rewrite the landing page unchanged and still report an error,
    # which is a pointless write against live customer config. Raising out of the
    # mutator aborts _landing_zone_update ahead of its PUT.
    class _KpiNotFound(Exception):
        pass

    found = {"card": None}

    def _mutate(cards):
        out = []
        for card in cards:
            if card.get("id") == kpi_id:
                merged = {**card, **changes}
                found["card"] = merged
                out.append(merged)
            else:
                out.append(card)
        if found["card"] is None:
            raise _KpiNotFound()
        return out

    client = _client(ctx)
    try:
        _landing_zone_update(client, wid, "kpi_bar", "kpis", _mutate)
    except _KpiNotFound:
        click.echo(f"ERROR: No KPI card with id {kpi_id} on this workspace.", err=True)
        ctx.exit(3)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(found["card"], fmt=fmt)
    else:
        click.echo(f"Updated KPI card: {kpi_id}")


@workspace_kpi.command(name="remove")
@click.option("--kpi-id", "kpi_id", required=True, help="KPI card UUID to remove.")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def workspace_kpi_remove(ctx, kpi_id, yes):
    """Remove a KPI card from the workspace landing page."""
    _confirm(f"Remove KPI card {kpi_id}?", yes=yes)
    wid = _wid(ctx)
    client = _client(ctx)
    try:
        _landing_zone_update(client, wid, "kpi_bar", "kpis",
                             lambda ks: [k for k in ks if k.get("id") != kpi_id])
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Removed KPI card: {kpi_id}")


# ---------------------------------------------------------------------------
# Attention cards
# ---------------------------------------------------------------------------

@workspace.group(name="attention")
def workspace_attention():
    """Manage workspace attention card templates (landing page).

    \b
    Examples:
      torana workspace <UUID> attention list
      torana workspace <UUID> attention add --title "Unpatched CVEs" --condition "vuln_count > 0"
      torana workspace <UUID> attention remove --attention-id <UUID>
    """


@workspace_attention.command(name="list")
@click.pass_context
def workspace_attention_list(ctx):
    """List attention card templates for the workspace landing page."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    wid = _wid(ctx)

    client = _client(ctx)
    try:
        config = client.get(f"workspaces/{wid}/landing-page/config")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Attention cards live under zones[type=attention].config.attention_templates
    # (see the kpi list note). Walk zones; fall back to a legacy flat shape.
    items = []
    for _z in (config.get("zones", []) if isinstance(config, dict) else []):
        if _z.get("type") == "attention":
            items.extend((_z.get("config", {}) or {}).get("attention_templates", []) or [])
    if not items and isinstance(config, dict) and config.get("attention_templates"):
        items = config.get("attention_templates") or []
    # Deploy-written cards carry `default_severity`; CLI-written ones historically
    # carried only `severity`. Read EITHER, so a build-deposited card no longer
    # renders a blank SEVERITY column.
    for _t in items:
        if isinstance(_t, dict):
            _t["_severity"] = (_t.get("default_severity") or _t.get("severity") or "")

    result = {"items": items, "total": len(items), "page": 1, "page_size": len(items)}
    output(result, fmt=fmt, raw=raw, fields=fields,
           columns=[("id", "ID", 36), ("title", "TITLE", 40),
                    ("_severity", "SEVERITY", 10)])


@workspace_attention.command(name="add")
@click.option("--title", required=True, help="Attention card title.")
@click.option("--condition", default=None,
              help="The card's SQL query, e.g. \"SELECT COUNT(*) AS count FROM t WHERE …\". "
                   "Must be paired with --trigger-when.")
@click.option("--trigger-when", "trigger_when", default="count > 0", show_default=True,
              help="Expression over the query's result that fires the card, e.g. 'count > 0'.")
@click.option("--service", default="datalake", show_default=True,
              help="Service the query runs against.")
@click.option("--file", "input_file", default=None, metavar="FILE",
              help="JSON/YAML file holding the full condition object "
                   "({query, trigger_when, service}) or a whole card template.")
@click.option("--description", default="", help="Semantic description of this attention card.")
@click.option("--severity", default="medium",
              type=click.Choice(["critical", "high", "medium", "low"]),
              show_default=True)
@click.pass_context
def workspace_attention_add(ctx, title, condition, trigger_when, service, input_file,
                            description, severity):
    """Add an attention card template to the workspace landing page.

    \b
    ⛔ The landing-page sweep requires the OBJECT form of `condition`:
         {"query": "SELECT COUNT(*) AS count FROM …",
          "trigger_when": "count > 0", "service": "datalake"}
    A bare SQL string is rejected here rather than written — one malformed card
    makes the whole workspace sweep fail, which silently zeroes every OTHER
    card in the workspace.

    \b
    Examples:
      torana workspace <UUID> attention add --title "Open criticals" \\
        --condition "SELECT COUNT(*) AS count FROM prioritized_vulnerabilities" \\
        --trigger-when "count > 0"
      torana workspace <UUID> attention add --title "Open criticals" --file cond.json
    """
    import sys
    import uuid
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    wid = _wid(ctx)

    condition_obj = None
    if input_file:
        loaded = _load_input_file(input_file)
        if isinstance(loaded, dict):
            # Accept either the condition object itself or a whole card template.
            condition_obj = loaded.get("condition", loaded)
    elif condition:
        condition_obj = {"query": condition, "trigger_when": trigger_when, "service": service}

    # A condition whose query is not actually a query is the exact shape that breaks
    # the sweep — and the sweep failing zeroes every OTHER card in the workspace, with
    # no error anywhere. Catch it at write time instead of letting it land.
    query_text = (condition_obj or {}).get("query") if isinstance(condition_obj, dict) else None
    if isinstance(query_text, str) and query_text.strip() and not (
            query_text.lstrip().lower().startswith(("select", "with"))):
        click.echo(
            f"ERROR: --condition must be the card's SQL QUERY, not a bare expression.\n"
            f"       got: {query_text!r}\n"
            '       expected e.g. --condition "SELECT COUNT(*) AS count FROM t WHERE …" '
            '--trigger-when "count > 0"\n'
            "       The threshold belongs in --trigger-when; the query must SELECT the "
            "value it compares.\n"
            "       ⛔ Writing a non-query condition makes the workspace sweep fail, which "
            "silently\n"
            "          zeroes every other attention card in the workspace.",
            err=True)
        sys.exit(2)

    if not isinstance(condition_obj, dict) or not condition_obj.get("query"):
        click.echo(
            "ERROR: a condition is required, as the object form the landing-page sweep "
            "reads:\n"
            '       {"query": "SELECT COUNT(*) AS count FROM …", '
            '"trigger_when": "count > 0", "service": "datalake"}\n'
            "       Supply it with --condition <sql> [--trigger-when <expr>] "
            "[--service <svc>], or --file <json>.\n"
            "       ⛔ A bare SQL string is NOT accepted: a malformed card makes the "
            "workspace sweep fail,\n"
            "          which zeroes every other card in the workspace with no error.",
            err=True)
        sys.exit(2)

    condition_obj.setdefault("trigger_when", trigger_when)
    condition_obj.setdefault("service", service)

    client = _client(ctx)
    new_template = {
        "id": str(uuid.uuid4()),
        "title": title,
        "condition": condition_obj,
        # ⛔ Deploy writes `default_severity` and the landing-page sweep reads it; the CLI
        # historically wrote only `severity`, so a CLI-added card carried a severity the
        # sweep could not see. Write BOTH so either reader is satisfied.
        "default_severity": severity,
        "severity": severity,
        "description": description,
        "suggested_action": "",
        "icon": "alert-triangle",
        "cta_label": "Review",
        "cta_context": "",
    }
    try:
        _landing_zone_update(client, wid, "attention", "attention_templates",
                             lambda ts: ts + [new_template])
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(new_template, fmt=fmt)
    else:
        click.echo(f"Added attention card: {new_template['id']}")


@workspace_attention.command(name="remove")
@click.argument("attention_id_arg", metavar="ATTENTION_ID", required=False)
@click.option("--attention-id", "attention_id", default=None,
              help="Attention template UUID to remove (deprecated — pass it positionally).")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip the confirmation prompt.")
@click.pass_context
def workspace_attention_remove(ctx, attention_id_arg, attention_id, yes):
    """Remove an attention card template from the workspace landing page.

    \b
    Examples:
      torana workspace <WS> attention remove <ATTENTION_ID> --yes
    """
    # Positional is the CLI's documented instance-verb convention
    # (`torana <resource> <id> <verb>`); this verb previously took `--attention-id`
    # alone, which made the correct invocation unguessable. The flag still works.
    import sys
    attention_id = attention_id_arg or attention_id
    if not attention_id:
        click.echo("ERROR: an attention-card id is required, e.g.\n"
                   "       torana workspace <WS> attention remove <ATTENTION_ID> --yes",
                   err=True)
        sys.exit(2)

    _confirm(f"Remove attention card {attention_id}?", yes=yes)
    wid = _wid(ctx)
    client = _client(ctx)
    try:
        _landing_zone_update(client, wid, "attention", "attention_templates",
                             lambda ts: [t for t in ts if t.get("id") != attention_id])
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Removed attention card: {attention_id}")


# ---------------------------------------------------------------------------
# Pinned widgets
# ---------------------------------------------------------------------------

@workspace.group(name="pinned")
def workspace_pinned():
    """Manage workspace pinned widgets (landing page).

    \b
    Examples:
      torana workspace <UUID> pinned list
      torana workspace <UUID> pinned add --widget-id <UUID> --dashboard-id <UUID>
      torana workspace <UUID> pinned remove --widget-id <UUID>
    """


@workspace_pinned.command(name="list")
@click.pass_context
def workspace_pinned_list(ctx):
    """List pinned widgets for the workspace landing page."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    wid = _wid(ctx)

    client = _client(ctx)
    try:
        _ws, cfg = _load_landing_config(client, wid)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Pinned widgets live INSIDE the pinned_widgets zone (cfg.landing_page.zones[]),
    # never at the top level — read them via the canonical zone helper.
    zone, _junk = _pinned_zone(cfg, create=False)
    items = (zone.get("config") or {}).get("pinned_widgets", []) if zone else []
    result = {"items": items, "total": len(items), "page": 1, "page_size": len(items)}
    output(result, fmt=fmt, raw=raw, fields=fields,
           columns=[("widget_id", "WIDGET_ID", 36), ("title", "TITLE", 40), ("position", "POS", 4)])


@workspace_pinned.command(name="add")
@click.option("--widget-id", "widget_id", required=True, help="Widget UUID to pin.")
@click.option("--dashboard-id", "dashboard_id", required=True, help="Dashboard UUID the widget belongs to.")
@click.option("--description", default="", help="Semantic description of this pinned widget.")
@click.option("--title", "title", default=None, help="Display title (defaults to widget name).")
@click.pass_context
def workspace_pinned_add(ctx, widget_id, dashboard_id, description, title):
    """Pin a widget to the workspace landing page."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    wid = _wid(ctx)

    client = _client(ctx)
    try:
        _ws, cfg = _load_landing_config(client, wid)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Modify the canonical pinned_widgets zone in place, then save the whole config.
    zone, junk = _pinned_zone(cfg, create=True)
    pinned = [p for p in zone["config"].setdefault("pinned_widgets", [])
              if p.get("widget_id") and p.get("widget_id") != widget_id]
    new_pin = {
        "widget_id": widget_id,
        "dashboard_id": dashboard_id,
        "title": title or "",
        "description": description,
        "position": len(pinned),
    }
    pinned.append(new_pin)
    zone["config"]["pinned_widgets"] = pinned

    try:
        _save_landing_config(client, wid, cfg, drop_zone_ids=junk)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(new_pin, fmt=fmt)
    else:
        click.echo(f"Pinned widget: {widget_id}")


@workspace_pinned.command(name="remove")
@click.option("--widget-id", "widget_id", required=True, help="Widget UUID to unpin.")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def workspace_pinned_remove(ctx, widget_id, yes):
    """Unpin a widget from the workspace landing page."""
    _confirm(f"Unpin widget {widget_id}?", yes=yes)
    wid = _wid(ctx)
    client = _client(ctx)
    try:
        _ws, cfg = _load_landing_config(client, wid)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    zone, junk = _pinned_zone(cfg, create=False)
    if zone is not None:
        zone["config"]["pinned_widgets"] = [
            p for p in (zone.get("config") or {}).get("pinned_widgets", [])
            if p.get("widget_id") and p.get("widget_id") != widget_id
        ]
    try:
        _save_landing_config(client, wid, cfg, drop_zone_ids=junk)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Unpinned widget: {widget_id}")


# ---------------------------------------------------------------------------
# Build operations
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Proposals (plural — collection ops on this workspace)
# ---------------------------------------------------------------------------

@workspace.group(name="proposals")
def workspace_proposals():
    """List and inspect proposals for this workspace.

    \b
    Examples:
      torana workspace <UUID> proposals list
      torana workspace <UUID> proposals suppressed
    """


def _extract_proposals(data) -> list:
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        return data.get("proposals") or data.get("items") or []
    return []


def _format_snapshot_banner(snapshot: dict) -> str:
    if not snapshot:
        return ""
    status = snapshot.get("agent_status", "unknown")
    mode = snapshot.get("mode", "")
    started_at = snapshot.get("started_at")
    elapsed = ""
    if started_at and status == "in_progress":
        try:
            started = datetime.datetime.fromisoformat(started_at.replace("Z", "+00:00"))
            delta = datetime.datetime.now(datetime.timezone.utc) - started
            mins = int(delta.total_seconds() // 60)
            elapsed = f", {mins}m ago" if mins > 0 else ", just started"
        except Exception:
            pass
    mode_str = f" ({mode}{elapsed})" if mode else ""
    return f"Build status: {status}{mode_str}"


@workspace_proposals.command(name="list")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False,
              help="Auto-paginate and return all results.")
@click.pass_context
def workspace_proposals_list(ctx, page, page_size, fetch_all):
    """List Program Advisor proposals for the workspace.

    \b
    agent_status values:
      in_progress  — sweep is running; proposals may be incomplete
      success      — sweep completed successfully
      partial      — sweep completed with soft failures
      failed       — sweep failed
      missing      — workspace has never been swept (trigger bootstrap first)
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    wid = _wid(ctx)

    effective_page_size = min(page_size or settings.page_size, 100)

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            snapshot = {}
            while True:
                p = {"skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(f"workspaces/{wid}/build-attention", params=p)
                if not snapshot and isinstance(data, dict):
                    snapshot = data.get("snapshot") or {}
                items = _extract_proposals(data)
                all_items.extend(items)
                total = data.get("total", len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            result = {"snapshot": snapshot, "items": all_items, "total": len(all_items),
                      "page": 1, "page_size": len(all_items)}
        else:
            params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
            data = client.get(f"workspaces/{wid}/build-attention", params=params)
            snapshot = data.get("snapshot") or {} if isinstance(data, dict) else {}
            items = _extract_proposals(data)
            result = {"snapshot": snapshot, "items": items,
                      "total": data.get("total", len(items)) if isinstance(data, dict) else len(items),
                      "page": page, "page_size": effective_page_size}
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    snapshot = result.get("snapshot") or {}
    items_result = {k: v for k, v in result.items() if k != "snapshot"}

    if fmt == "text":
        banner = _format_snapshot_banner(snapshot)
        if banner:
            click.echo(banner)
        output(items_result, fmt=fmt, raw=raw, fields=fields, columns=_PROPOSAL_COLS)
    elif fmt == "json":
        import json
        out = {"snapshot": snapshot, **items_result}
        click.echo(json.dumps(out, indent=2, default=str))
    else:
        output(items_result, fmt=fmt, raw=raw, fields=fields, columns=_PROPOSAL_COLS)


@workspace_proposals.command(name="suppressed")
@click.pass_context
def workspace_proposals_suppressed(ctx):
    """List suppressed proposals for the workspace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    wid = _wid(ctx)

    client = _client(ctx)
    try:
        data = client.get(f"workspaces/{wid}/build-attention/suppressed")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


# ---------------------------------------------------------------------------
# Proposal (singular — instance ops on a specific proposal)
# ---------------------------------------------------------------------------

@workspace.group(name="proposal", invoke_without_command=True)
@click.argument("proposal_id", metavar="PROPOSAL_ID")
@click.pass_context
def workspace_proposal(ctx, proposal_id):
    """Manage a single proposal by ID.

    \b
    Examples:
      torana workspace <UUID> proposal <PROPOSAL_ID> status
      torana workspace <UUID> proposal <PROPOSAL_ID> status
      torana workspace <UUID> proposal <PROPOSAL_ID> approve
      torana workspace <UUID> proposal <PROPOSAL_ID> reject
      torana workspace <UUID> proposal <PROPOSAL_ID> mark-committed
      torana workspace <UUID> proposal <PROPOSAL_ID> reset-session   (SA only)
    """
    ctx.ensure_object(dict)
    ctx.obj["_proposal_id"] = proposal_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _pid(ctx) -> str:
    return ctx.obj.get("_proposal_id", "") if ctx.obj else ""


@workspace_proposal.command(name="legacy-build")
@click.pass_context
def workspace_proposal_build(ctx):
    """Open a chat session to build a proposal interactively (LEGACY v1 Build-in-Chat).

    Legacy v1 path — the finalized build experience is `torana build proposal <id> …`.
    Starts a new Build-in-Chat session for the proposal and prints the session URL.

    \b
    Example:
      torana workspace <UUID> proposal <PROPOSAL_ID> legacy-build
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    wid = _wid(ctx)
    pid = _pid(ctx)

    client = _client(ctx)
    try:
        data = client.post(
            f"workspaces/{wid}/build-attention/{pid}/build-in-chat", json={}
        )
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        if isinstance(data, dict):
            session_id = data.get("session_id") or data.get("id", "unknown")
            agent_id = data.get("agent_id")
            turn_id = data.get("turn_id")

            w = 14
            click.echo(f"{'Session:':<{w}} {session_id}")
            if agent_id:
                click.echo(f"{'Agent:':<{w}} {agent_id}")
            if turn_id:
                click.echo(f"{'Turn ID:':<{w}} {turn_id}")
            click.echo("")
            if agent_id and session_id:
                click.echo(f"{'Monitor:':<{w}} torana chat {session_id} history")
                click.echo(f"{'Continue:':<{w}} torana chat {session_id} send -m \"your message\"")
            click.echo(f"{'Detail:':<{w}} torana workspace {wid} proposal {pid} status")
        else:
            click.echo(str(data))


@workspace_proposal.command(name="status")
@click.pass_context
def workspace_proposal_status(ctx):
    """Show proposal detail, current claim state, and browser URL.

    \b
    Example:
      torana workspace <UUID> proposal <PROPOSAL_ID> status
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    wid = _wid(ctx)
    pid = _pid(ctx)

    client = _client(ctx)
    try:
        resp = client.get(f"workspaces/{wid}/build-attention")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    proposals = resp.get("proposals", []) if isinstance(resp, dict) else []
    data = next((p for p in proposals if str(p.get("id", "")) == pid), None)
    if data is None:
        click.echo(f"ERROR: Proposal {pid} not found in workspace {wid}.", err=True)
        return

    if fmt != "text":
        output(data, fmt=fmt)
        return

    w = 14
    click.echo(f"{'Title:':<{w}} {data.get('title', '')}")
    click.echo(f"{'Granularity:':<{w}} {data.get('granularity', '')}")
    fit = data.get('fit_score')
    click.echo(f"{'Fit score:':<{w}} {fit if fit is not None else '—'}")
    click.echo(f"{'Status:':<{w}} {data.get('status', '')}")
    click.echo(f"{'Proposal ID:':<{w}} {pid}")

    session_id = data.get("session_id")
    agent_id = data.get("agent_id")
    if session_id:
        click.echo("")
        click.echo(f"{'Session:':<{w}} {session_id}")
        if agent_id:
            click.echo(f"{'Agent:':<{w}} {agent_id}")
            click.echo("")
            click.echo(f"{'Monitor:':<{w}} torana chat {session_id} history")
            click.echo(f"{'Continue:':<{w}} torana chat {session_id} send -m \"your message\"")
            base = settings.base_url.rstrip("/")
            url = f"{base}/workspace/{wid}/agent/{agent_id}/session/{session_id}"
            click.echo(f"{'Browser:':<{w}} {url}")
    else:
        click.echo("")
        click.echo("No active chat session — run `proposal build` to start one.")


@workspace_proposal.command(name="approve")
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def workspace_proposal_approve(ctx, input_file):
    """Approve a proposal."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    wid = _wid(ctx)
    pid = _pid(ctx)

    body = _load_input_file(input_file) if input_file else {}

    client = _client(ctx)
    try:
        data = client.post(
            f"workspaces/{wid}/build-attention/{pid}/approve", json=body
        )
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Approved proposal: {pid}")


@workspace_proposal.command(name="reject")
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def workspace_proposal_reject(ctx, input_file):
    """Reject a proposal."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    wid = _wid(ctx)
    pid = _pid(ctx)

    body = _load_input_file(input_file) if input_file else {}

    client = _client(ctx)
    try:
        data = client.post(
            f"workspaces/{wid}/build-attention/{pid}/reject", json=body
        )
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Rejected proposal: {pid}")


@workspace_proposal.command(name="disposition")
@click.option("--file", "input_file", required=True, metavar="FILE",
              help="JSON/YAML file with disposition body.")
@click.pass_context
def workspace_proposal_disposition(ctx, input_file):
    """Set a custom disposition on a proposal."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    wid = _wid(ctx)
    pid = _pid(ctx)

    body = _load_input_file(input_file)

    client = _client(ctx)
    try:
        data = client.post(
            f"workspaces/{wid}/build-attention/{pid}/disposition", json=body
        )
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Disposition set for proposal: {pid}")


@workspace_proposal.command(name="mark-committed")
@click.pass_context
def workspace_proposal_mark_committed(ctx):
    """Mark a proposal as committed."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    wid = _wid(ctx)
    pid = _pid(ctx)

    client = _client(ctx)
    try:
        data = client.post(
            f"workspaces/{wid}/build-attention/{pid}/mark-committed", json={}
        )
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Marked committed: {pid}")


@workspace_proposal.command(name="reset-session")
@click.pass_context
def workspace_proposal_reset_session(ctx):
    """Reset a proposal's chat session so 'Build in Chat' becomes available again (SA only)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    wid = _wid(ctx)
    pid = _pid(ctx)

    client = _client(ctx)
    try:
        data = client.post(
            f"admin/advisor/workspaces/{wid}/proposals/{pid}/reset-session", json={}
        )
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Reset session for proposal {pid}.")


# ---------------------------------------------------------------------------
# Advisor lifecycle commands
# ---------------------------------------------------------------------------

@workspace.group(name="advisor")
def workspace_advisor():
    """Program Advisor operations for this workspace.

    \b
    Examples:
      torana workspace <UUID> advisor bootstrap
      torana workspace <UUID> advisor refresh
      torana workspace <UUID> advisor status
      torana workspace <UUID> advisor artifacts
      torana workspace <UUID> advisor environment-snapshot
      torana workspace <UUID> advisor invalidate-cache
      torana workspace <UUID> advisor reset-all-sessions    (SA only)
    """


@workspace_advisor.command(name="bootstrap")
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def workspace_advisor_bootstrap(ctx, input_file):
    """Trigger the Program Advisor in bootstrap mode."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    wid = _wid(ctx)

    body = _load_input_file(input_file) if input_file else {}

    client = _client(ctx)
    try:
        data = client.post(f"workspaces/{wid}/build-attention/bootstrap", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Advisor bootstrap triggered for workspace: {wid}")


@workspace_advisor.command(name="refresh")
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def workspace_advisor_refresh(ctx, input_file):
    """Trigger advisor refresh for the workspace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    wid = _wid(ctx)

    body = _load_input_file(input_file) if input_file else {}

    client = _client(ctx)
    try:
        data = client.post(f"workspaces/{wid}/build-attention/refresh", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Advisor refresh triggered for workspace: {wid}")


@workspace_advisor.command(name="status")
@click.option("--origin", default="builder", show_default=True,
              help="Origin filter (e.g. builder, advisor).")
@click.pass_context
def workspace_advisor_status(ctx, origin):
    """Show current advisor sweep status and proposal count for the workspace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    wid = _wid(ctx)

    client = _client(ctx)
    try:
        data = client.get(f"workspaces/{wid}/build-attention", params={"origin": origin})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if not isinstance(data, dict):
        output(data, fmt=fmt, fields=fields)
        return

    snapshot = data.get("snapshot") or {}
    raw_status = snapshot.get("agent_status") or data.get("last_run_status") or "unknown"
    is_running = raw_status == "in_progress"

    if fmt == "text" and not fields:
        running_line = "yes — sweep in progress" if is_running else "no"
        w = 18
        click.echo(f"{'CURRENTLY RUNNING':<{w}}  {running_line}")
        click.echo(f"{'LAST RUN STATUS':<{w}}  {raw_status if not is_running else '(in progress)'}")
        click.echo(f"{'STARTED AT':<{w}}  {snapshot.get('started_at') or '—'}")
        click.echo(f"{'COMPLETED AT':<{w}}  {snapshot.get('completed_at') or data.get('last_run_at') or '—'}")
        click.echo(f"{'MODE':<{w}}  {snapshot.get('mode') or '—'}")
        click.echo(f"{'TRIGGERED BY':<{w}}  {snapshot.get('triggered_by') or '—'}")
        click.echo(f"{'PROPOSALS':<{w}}  {len(data.get('proposals', []))}")
        errors = snapshot.get("signal_errors")
        if errors:
            click.echo(f"{'SIGNAL ERRORS':<{w}}  {errors}")
    else:
        status = {
            "running": is_running,
            "last_status": raw_status,
            "started_at": snapshot.get("started_at"),
            "completed_at": snapshot.get("completed_at") or data.get("last_run_at"),
            "mode": snapshot.get("mode"),
            "triggered_by": snapshot.get("triggered_by"),
            "proposal_count": len(data.get("proposals", [])),
            "signal_errors": snapshot.get("signal_errors"),
        }
        output(status, fmt=fmt, fields=fields)


@workspace_advisor.command(name="force-rebuild")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def workspace_advisor_force_rebuild(ctx, yes):
    """Force-rebuild all advisor proposals for the workspace."""
    wid = _wid(ctx)
    _confirm(f"Force-rebuild advisor for workspace {wid}?", yes=yes)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"workspaces/{wid}/build-attention/force-rebuild", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Force-rebuild triggered for workspace: {wid}")


@workspace_advisor.command(name="artifacts")
@click.pass_context
def workspace_advisor_artifacts(ctx):
    """List committed artifacts in the workspace (advisor inventory)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    wid = _wid(ctx)

    client = _client(ctx)
    try:
        data = client.get(f"workspaces/{wid}/advisor/artifacts")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@workspace_advisor.command(name="environment-snapshot")
@click.pass_context
def workspace_advisor_environment_snapshot(ctx):
    """Get the latest environment snapshot for the workspace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    wid = _wid(ctx)

    client = _client(ctx)
    try:
        data = client.get(f"workspaces/{wid}/environment-snapshot")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workspace_advisor.command(name="invalidate-cache")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def workspace_advisor_invalidate_cache(ctx, yes):
    """Invalidate all advisor tool cache entries for the workspace."""
    wid = _wid(ctx)
    _confirm(f"Invalidate advisor cache for workspace {wid}?", yes=yes)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"workspaces/{wid}/advisor-cache/invalidate", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Advisor cache invalidated for workspace: {wid}")


_ADVISOR_SESSION_COLS = [
    ("session_id", "SESSION_ID", 22),
    ("mode", "TYPE", 10),
    ("execution_status", "STATUS", 10),
    ("proposal_count", "PROPOSALS", 9),
    ("proposal_titles", "PRODUCED", 60),
    ("duration_ms", "MS", 7),
    ("execution_start_time", "STARTED", 26),
]


@workspace_advisor.command(name="sessions")
@click.option("--mode", type=click.Choice(["bootstrap", "refresh"]), default=None,
              help="Filter by sweep type.")
@click.option("--status", "execution_status", default=None,
              help="Filter by execution status (SUCCESS, FAILED, etc.).")
@click.option("--limit", "limit", type=int, default=None, help="Max results (default page_size).")
@click.option("--offset", "offset", type=int, default=0, show_default=True, help="Skip N results.")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate all results.")
@click.pass_context
def workspace_advisor_sessions(ctx, mode, execution_status, limit, offset, fetch_all):
    """List advisor invoke sessions for this workspace — bootstrap and refresh sweeps.

    Shows each sweep's type (bootstrap/refresh), status, how many proposals were produced,
    and their titles. Data is sourced from the invoke audit log.

    \b
    Examples:
      torana workspace <UUID> advisor sessions
      torana workspace <UUID> advisor sessions --mode bootstrap
      torana workspace <UUID> advisor sessions --status SUCCESS --format json
    """
    import json as _json

    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    wid = _wid(ctx)

    effective_limit = limit if limit is not None else settings.page_size
    params = {"workspace_id": wid, "limit": effective_limit, "offset": offset}
    if execution_status:
        params["execution_status"] = execution_status

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            cur_offset = offset
            while True:
                p = {**params, "offset": cur_offset, "limit": effective_limit}
                data = client.get("audit/invokes", params=p)
                items = data.get("items", data) if isinstance(data, dict) else data
                all_items.extend(items if isinstance(items, list) else [])
                total = data.get("total") if isinstance(data, dict) else None
                cur_offset += len(items) if isinstance(items, list) else 0
                if not items or (total is not None and cur_offset >= total):
                    break
            raw_items = all_items
        else:
            data = client.get("audit/invokes", params=params)
            raw_items = data.get("items", data) if isinstance(data, dict) else data
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Enrich each record: parse user_request for mode, parse agent_response for proposals
    # Run local validation matching the server's _validate_proposal logic so we can
    # annotate each proposal with whether it would be accepted or dropped and why.
    _REQUIRED_FIELDS = {"title", "fit_score", "granularity", "artifact_outline", "citations"}
    _VALID_GRANULARITIES = {"custom", "program", "sub_program", "artifact"}
    _CITATION_TYPE_SUBFIELD = {
        "data_lake": "table",
        "rag": "collection",
        "context_lake": "bucket",
        "program_framework": "subject",
        "detection_framework": "subject",
    }
    _LEGACY_CITATION_TYPES = {"policy", "data"}

    def _local_validate(p):
        """Return None if valid, drop-reason string if invalid."""
        if not isinstance(p, dict):
            return "invalid_structure"
        missing = _REQUIRED_FIELDS - p.keys()
        if missing:
            return f"missing_required_fields:{','.join(sorted(missing))}"
        if p.get("granularity") not in _VALID_GRANULARITIES:
            return f"invalid_granularity:{p.get('granularity')}"
        fit = p.get("fit_score")
        if not isinstance(fit, (int, float)) or not (0.0 <= fit <= 1.0):
            return f"invalid_fit_score:{fit}"
        citations = p.get("citations") or []
        risk_label = (p.get("risk") or {}).get("label", "low")
        if not citations and p.get("granularity") != "custom" and risk_label != "low":
            return "ungrounded_claim:citations is empty"
        for cit in citations:
            ctype = cit.get("type")
            ref = (cit.get("ref") or "").strip()
            excerpt = (cit.get("excerpt") or "").strip()
            if cit.get("bound_to_field") and not ref:
                return f"ungrounded_claim:citation bound_to_field={cit['bound_to_field']!r} has no ref"
            if ctype in _CITATION_TYPE_SUBFIELD:
                subfield = _CITATION_TYPE_SUBFIELD[ctype]
                if not (cit.get(subfield) or "").strip():
                    return (f"ungrounded_claim:citation type={ctype!r} missing sub-field "
                            f"{subfield!r}")
                if ctype in ("rag", "context_lake") and not excerpt:
                    return f"ungrounded_claim:citation type={ctype!r} missing verbatim excerpt"
            elif ctype not in _LEGACY_CITATION_TYPES and ctype:
                return f"invalid_citation_type:{ctype!r}"
        return None

    enriched = []
    for item in (raw_items if isinstance(raw_items, list) else []):
        try:
            req = _json.loads(item.get("user_request") or "{}")
        except Exception:
            req = {}
        item_mode = req.get("mode", "")
        if mode and item_mode != mode:
            continue

        try:
            resp = _json.loads(item.get("agent_response") or "{}")
        except Exception:
            resp = {}
        proposals = resp.get("proposals", []) if isinstance(resp, dict) else []

        annotated_proposals = []
        for p in proposals:
            if not isinstance(p, dict):
                continue
            drop_reason = _local_validate(p)
            annotated_proposals.append({
                "title": p.get("title", "(no title)"),
                "drop_reason": drop_reason,
            })

        ok_count = sum(1 for ap in annotated_proposals if ap["drop_reason"] is None)
        dropped_count = len(annotated_proposals) - ok_count

        enriched.append({
            "session_id": item.get("session_id", ""),
            "mode": item_mode,
            "execution_status": item.get("execution_status", ""),
            "proposal_count": len(annotated_proposals),
            "ok_count": ok_count,
            "dropped_count": dropped_count,
            "annotated_proposals": annotated_proposals,
            "duration_ms": item.get("duration_ms"),
            "execution_start_time": item.get("execution_start_time", ""),
            "model_name": item.get("model_name", ""),
            "input_tokens": item.get("input_tokens"),
            "output_tokens": item.get("output_tokens"),
        })

    result = {"items": enriched, "total": len(enriched)}

    if fmt == "text" and not raw and not fields:
        w_id, w_type, w_status, w_proposals, w_started = 22, 10, 10, 9, 26
        header = (f"{'SESSION_ID':<{w_id}}  {'TYPE':<{w_type}}  {'STATUS':<{w_status}}"
                  f"  {'PROPOSALS':>{w_proposals}}  {'STARTED':<{w_started}}")
        click.echo(header)
        click.echo("-" * len(header))
        if not enriched:
            click.echo("No advisor sessions found.")
        for row in enriched:
            ok_c = row["ok_count"]
            drop_c = row["dropped_count"]
            total_c = row["proposal_count"]
            if total_c == 0:
                proposals_cell = "0"
            elif drop_c == 0:
                proposals_cell = str(total_c)
            else:
                proposals_cell = f"{ok_c}/{total_c} ({drop_c} dropped)"
            click.echo(
                f"{row['session_id']:<{w_id}}  {row['mode']:<{w_type}}  "
                f"{row['execution_status']:<{w_status}}  "
                f"{proposals_cell:>{w_proposals}}  "
                f"{row['execution_start_time']:<{w_started}}"
            )
            indent = "  " + " " * (w_id + w_type + w_status + w_proposals + 8)
            for ap in row["annotated_proposals"]:
                if ap["drop_reason"] is None:
                    click.echo(f"{indent}↳ {ap['title']}")
                else:
                    click.echo(f"{indent}↳ [DROPPED: {ap['drop_reason']}] {ap['title']}")
        click.echo(f"\nTOTAL  {len(enriched)}")
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_ADVISOR_SESSION_COLS)


@workspace_advisor.command(name="reset-all-sessions")
@click.option("--yes", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def workspace_advisor_reset_all_sessions(ctx, yes):
    """Reset all proposal chat sessions for the workspace (SA only). Skips committed/rejected."""
    wid = _wid(ctx)
    _confirm(f"Reset all proposal sessions for workspace {wid}?", yes=yes)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(
            f"admin/advisor/workspaces/{wid}/proposals/reset-all-sessions", json={}
        )
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        count = data.get("proposals_reset", 0) if isinstance(data, dict) else 0
        click.echo(f"Reset {count} proposal session(s) for workspace {wid}.")


# ---------------------------------------------------------------------------
# Sweeps (workspace-scoped)
# ---------------------------------------------------------------------------

_SWEEP_LIST_COLS = [
    ("sweep_session_id", "SWEEP_ID", 36),
    ("workspace_name", "WORKSPACE", 20),
    ("tenant_name", "TENANT", 20),
    ("mode", "MODE", 10),
    ("agent_status", "STATUS", 12),
    ("proposals_count", "PROPOSALS", 9),
    ("started_at", "STARTED", 20),
]


@workspace.group(name="sweeps")
def workspace_sweeps():
    """Inspect Program Advisor sweeps for this workspace.

    \b
    Examples:
      torana workspace <UUID> sweeps list
      torana workspace <UUID> sweeps list --mode bootstrap --status success
      torana workspace <UUID> sweeps get <SWEEP_ID>
      torana workspace <UUID> sweeps diff --a <SWEEP_A> --b <SWEEP_B>
      torana workspace <UUID> sweeps retire <SWEEP_ID> --reason "stale"
    """


@workspace_sweeps.command(name="list")
@click.option("--mode", type=click.Choice(["bootstrap", "refresh"]), default=None)
@click.option("--status", "agent_status", default=None,
              help="Filter by agent_status (e.g. success, in_progress, failed).")
@click.option("--page", default=1, show_default=True, type=int)
@click.option("--page-size", default=None, type=int)
@click.option("--limit", default=None, type=int, help="Shorthand for --page-size.")
@click.pass_context
def workspace_sweeps_list(ctx, mode, agent_status, page, page_size, limit):
    """List sweeps for the workspace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    wid = _wid(ctx)

    effective = limit if limit is not None else (page_size or settings.page_size)
    effective = min(effective, 100)

    params = {"page": page, "page_size": effective, "workspace_id": wid}
    if mode:
        params["mode"] = mode
    if agent_status:
        params["agent_status"] = agent_status

    client = _client(ctx)
    try:
        data = client.get("admin/advisor/sweeps", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields, columns=_SWEEP_LIST_COLS)


@workspace_sweeps.command(name="get")
@click.argument("sweep_id", metavar="SWEEP_ID")
@click.option("--include-llm-calls", "include_llm_calls", is_flag=True, default=False)
@click.pass_context
def workspace_sweeps_get(ctx, sweep_id, include_llm_calls):
    """Get full sweep detail by sweep_session_id."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if include_llm_calls:
        params["include_llm_calls"] = "true"

    client = _client(ctx)
    try:
        data = client.get(f"admin/advisor/sweeps/{sweep_id}", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workspace_sweeps.command(name="diff")
@click.option("--a", "sweep_a", required=True, help="First sweep_session_id.")
@click.option("--b", "sweep_b", required=True, help="Second sweep_session_id.")
@click.pass_context
def workspace_sweeps_diff(ctx, sweep_a, sweep_b):
    """Diff two sweeps by sweep_session_id."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("admin/advisor/sweeps/diff",
                          params={"a": sweep_a, "b": sweep_b})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workspace_sweeps.command(name="retire")
@click.argument("sweep_id", metavar="SWEEP_ID")
@click.option("--reason", required=True, help="Mandatory reason for retirement.")
@click.option("--dry-run", is_flag=True, default=False,
              help="Preview without writing.")
@click.pass_context
def workspace_sweeps_retire(ctx, sweep_id, reason, dry_run):
    """Retire all proposals from a sweep (SA only)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    suffix = ":dry-run" if dry_run else ""
    path = f"admin/advisor/sweeps/{sweep_id}/retire{suffix}"

    client = _client(ctx)
    try:
        data = client.post(path, json={"reason": reason})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ---------------------------------------------------------------------------
# App versions — the CUMULATIVE, user-visible app snapshots of this workspace.
# Each version (v1, v2, …) is the COMPLETE app at that deploy (not a delta):
# `versions list` shows v1, v2, …; `version <vN> yaml` exports the full app.yaml
# a customer can check into their own repo. (Canonical of the build-v2 versions
# group — same endpoints, workspace-scoped positional id.)
# ---------------------------------------------------------------------------

from torana_cli.build_v2 import _VERSION_COLS  # noqa: E402  (reuse the column shape)


@workspace.group(name="versions", invoke_without_command=True)
@click.pass_context
def workspace_versions(ctx):
    """App versions (cumulative deployment snapshots) of this workspace. Use `list`."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@workspace_versions.command(name="list")
@click.option("--limit", "limit", default=100, type=int, help="Max versions to return (<=100).")
@click.pass_context
def workspace_versions_list(ctx, limit):
    """List this workspace's app versions, newest first — each is an immutable, CUMULATIVE
    snapshot of everything live at that deploy (v1, v2, v3, …)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    wid = _wid(ctx)
    client = _client(ctx)
    try:
        data = client.get(f"workspaces/{wid}/build-v2/deployments?limit={limit}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields, columns=_VERSION_COLS)


@workspace.group(name="version", invoke_without_command=True)
@click.argument("version_number", metavar="VERSION", type=int)
@click.pass_context
def workspace_version(ctx, version_number):
    """Operate on ONE app version (v1, v2, …) of this workspace.

    \b
    Examples:
      torana workspace <UUID> version 1 yaml                # dump complete app.yaml to screen
      torana workspace <UUID> version 2 yaml --save v2.yaml # save the complete app to a file
    """
    ctx.ensure_object(dict)
    ctx.obj["_version_number"] = version_number
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _ver(ctx) -> int:
    return ctx.obj.get("_version_number", 0) if ctx.obj else 0


@workspace_version.command(name="yaml")
@click.option("--save", "save_path", default=None,
              help="Write the app.yaml to this path. Without --save, it prints to the screen.")
@click.pass_context
def workspace_version_yaml(ctx, save_path):
    """Export this app version's COMPLETE (cumulative) manifest as artifacts.yaml — the whole app
    at vN, suitable to check into your own repository. Without --save, dumps to stdout."""
    wid = _wid(ctx)
    ver = _ver(ctx)
    client = _client(ctx)
    try:
        data = client.get(f"workspaces/{wid}/build-v2/versions/{ver}/export-yaml")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    yaml_text = data.get("yaml") if isinstance(data, dict) else None
    if yaml_text is None:
        fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
        output(data, fmt=fmt)
        return
    if save_path:
        with open(save_path, "w") as fh:
            fh.write(yaml_text)
        click.echo(f"wrote {len(yaml_text)} bytes to {save_path}")
    else:
        click.echo(yaml_text)


# ---------------------------------------------------------------------------
# AI Home — the generated operator home page.
# Registered from its own module so this file does not grow another ~300 lines;
# `torana workspace <id> ai-home ...`.
# ---------------------------------------------------------------------------
from torana_cli.ai_home import register as _register_ai_home  # noqa: E402

_register_ai_home(workspace, _client, list_timeline_core)
from torana_cli.app_profile import register as _register_app_profile  # noqa: E402
_register_app_profile(workspace, _client)
from torana_cli.app_health import register as _register_app_health  # noqa: E402
_register_app_health(workspace, lambda ctx: _client(ctx))   # looked up at call time
from torana_cli.app_landing import register as _register_app_landing  # noqa: E402
_register_app_landing(workspace, lambda ctx: _client(ctx))   # engagement | outcomes | policies (Landing Page)
