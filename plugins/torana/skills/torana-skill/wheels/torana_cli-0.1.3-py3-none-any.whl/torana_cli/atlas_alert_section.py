"""torana atlas alert-section — the Atlas rows on one alert: does the vulnerable version ship, is it running, who
owns the file (pantheon-knowledge ATLAS_ALERT_SECTION_CONTRACT.md). Free: stored knowledge, no build, no model.

The server writes every state and every sentence (`{state, glyph, words, missing[].words}`); this command prints them
verbatim and derives none. ⚠️ File output is `--out`, never `-o` (the root group lifts `-o` as the global format flag).
"""

import click

from torana_cli.atlas import _call, _client, _fmt, _params
from torana_cli.atlas_provenance import _repo_key
from torana_cli.output import output

ROWS = (("ships", "Ships"), ("running", "Running"), ("owner", "Owner"))


def render_alert_section(data: dict) -> str:
    """One item's rows as `glyph words`, each `missing[]` entry's words verbatim, then the item error if any."""
    items = data.get("items") or []
    lines = []
    for it in items:
        lines.append(f"alert-section  {it.get('key', '')}  (as of {data.get('as_of', '')})")
        err = it.get("error")
        if err:
            lines.append(f"  ✗ {err.get('code')}: {err.get('words', '')}")
            continue
        rows = it.get("rows") or {}
        for name, label in ROWS:
            r = rows.get(name)
            if not r:
                lines.append(f"{label}: (none)")
                continue
            # k3 A4: the server's state word always beside the glyph (never a glyph alone, never an invented '?')
            glyph, word = r.get("glyph"), r.get("state_word") or r.get("state") or ""
            lines.append(f"{label}: " + (f"{glyph} " if glyph else "") + f"{word} — {r.get('words', '')}")
            for m in r.get("missing") or []:
                lines.append(f"  ○ {m.get('code')}: {m.get('words', '')}")
    lines.append(f"request {data.get('request_id', '')}")
    return "\n".join(lines)


@click.command(name="alert-section")
@click.option("--repo", "repository", default=None, metavar="REPO",
              help="The repository the finding is in (repo:github.com/org/repo or github.com/org/repo).")
@click.option("--image", default=None, metavar="sha256:DIGEST", help="The image digest the finding was scanned in.")
@click.option("--file", "file_path", default=None, metavar="PATH", help="The finding's file, repository-relative.")
@click.option("--commit", default=None, metavar="SHA", help="The commit the finding was scanned at (40 hex).")
@click.option("--package", default=None, help="The package (SCA). Omit for a SAST finding.")
@click.option("--ecosystem", default="pypi", show_default=True, help="The package's ecosystem.")
@click.option("--reported", "version", default=None, metavar="VERSION", help="The version the scanner reported (words only).")
@click.option("--fixed", "fixed_versions", multiple=True, metavar="VERSION",
              help="The advisory's fixed version (repeat for several release lines).")
@click.option("--vulnerable", "vulnerable_range", default=None, metavar="SPEC", help="The advisory's vulnerable range.")
@click.option("--key", default="cli", show_default=True, help="The caller's item id, echoed back.")
@click.option("--tenant", default=None, help="Another tenant's knowledge (SA only).")
@click.pass_context
def atlas_alert_section(ctx, repository, image, file_path, commit, package, ecosystem, version, fixed_versions,
                        vulnerable_range, key, tenant):
    """The Atlas section on an alert, for one finding: three rows, each ✓ known · ◐ partly · ? not yet.

    \b
      Ships    does the vulnerable version reach the shipped image (package provenance)
      Running  is any image built from it running where Atlas can see (deployments, image scans)
      Owner    who owns the file (CODEOWNERS: the last matching rule wins)

    A ◐ row lists what Atlas cannot see; a ? row names why it cannot answer yet. Give --repo, --image or both.

    \b
    Examples:
      torana atlas alert-section --repo github.com/acme/api --package black --fixed 24.3.0 --file requirements.txt
      torana atlas alert-section --repo repo:github.com/acme/api --file src/app.py          # a SAST finding
      torana atlas alert-section --image sha256:<64 hex> --package urllib3 --vulnerable '<2.2.2' --json
    """
    fmt, _, _ = _fmt(ctx)
    if not repository and not image:
        raise click.UsageError("give --repo, --image or both")
    fixes = list(dict.fromkeys(v.strip() for v in fixed_versions if v and v.strip()))
    if package and fixes and vulnerable_range:
        raise click.UsageError("give the advisory as --fixed VERSION (repeatable) or --vulnerable SPEC, not both")
    item = {"key": key, "repository": _repo_key(repository) if repository else None, "image": image,
            "file": file_path, "commit": commit, "package": package, "ecosystem": ecosystem, "version": version,
            "fixed_version": fixes[0] if len(fixes) == 1 else None,
            "fixed_versions": fixes if len(fixes) > 1 else None, "vulnerable_range": vulnerable_range}
    body = {"schema": "atlas/alert-section-request.v1", "items": [{k: v for k, v in item.items() if v is not None}]}
    data = _call(_client(ctx).post, "atlas/alert-section", json=body, params=_params(tenant=tenant))
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt)
        return
    click.echo(render_alert_section(data))
