"""torana atlas documents: a tenant's uploaded texts (pantheon-knowledge docs/learning-framework/specs/
BLOCK_6B_DOCUMENTS.md § 3.2.2, § 3.4, § 5.5 item 4).

A holder of `atlas:document` uploads a UTF-8 text under a name (the name is its identity, the sha256 its version), lists
the tenant's documents, reads one back (the current text, a named version, or every version) and deletes one (every
version, and what Knowledge learned from it). Documents are served only while the tenant's `push:document` consent is
granted; it is granted and withdrawn with `torana integrations knowledge-consent pushed grant|revoke document`.

The server writes every word: the consent line (`consent.glyph` + `consent.words`), each row's `glyph`, `state` and
`words`, and every refusal. These commands print them verbatim and derive none (glyph beside word, never colour alone).
"""

from pathlib import Path
from urllib.parse import quote

import click

from torana_cli.atlas import MAX_PAGE_SIZE, _client, _fmt, human_time
from torana_cli.atlas_inquiries import _show, _wait_options, refused_types_line, wait_for_inquiry
from torana_cli.atlas_statements import _refusal
from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, handle_auth_error
from torana_cli.confirm import confirm
from torana_cli.output import output

#: the extra fields a 6b refusal carries (§ 3.6), printed under the server's sentence
DOCUMENT_REFUSAL_EXTRAS = ("purge_due_at", "max_bytes", "max")


def default_name(path: str) -> str:
    """§ 5.5 item 4: the path AS GIVEN, normalised by stripping leading `./` (so `./docs/a.md` → `docs/a.md`)."""
    name = path
    while name.startswith("./"):
        name = name[2:]
    return name


def _path(name: str) -> str:
    """The route path of a name (`/` kept: the route takes `{name:path}`)."""
    return f"atlas/documents/{quote(name, safe='/')}"


def state_of(r: dict) -> str:
    return f"{r.get('glyph') or ''} {r.get('state') or '?'}".strip()


def document_line(r: dict) -> str:
    """`glyph state · name · n version(s) · size bytes · media type · by X · when · sha256 <12>`."""
    out = f"{state_of(r)} · {r.get('name') or '?'}"
    if r.get("versions") is not None:
        out += f" · {r['versions']} version(s)"
    out += f" · {r.get('size', '?')} bytes · {r.get('media_type') or '?'}"
    out += f" · by {r.get('uploaded_by') or '?'} · {human_time(r.get('uploaded_at')) or '?'}"
    if r.get("sha256"):
        out += f" · sha256 {r['sha256'][:12]}"
    return out


def read_line(r: dict) -> str:
    """6c § 4: the read state of the version a row describes, the server's glyph + words (never colour alone)."""
    rd = r.get("read") or {}
    words = rd.get("words") or rd.get("state")
    return "read: " + " ".join(x for x in (rd.get("glyph"), words) if x) if words else ""


def read_detail(r: dict) -> list[str]:
    """`documents get`: the read state, the types refused, the estimate and whether a read may start (with words)."""
    rd = r.get("read") or {}
    out = [f"  {x}" for x in (read_line(r),) if x]
    if rd.get("refused_types"):
        out.append(f"  {refused_types_line(rd['refused_types'])}")
    if (rd.get("estimate") or {}).get("words"):
        out.append(f"  estimate: {rd['estimate']['words']}")
    act = rd.get("action") or {}
    if act:
        out.append(f"  {'▶ may read' if act.get('allowed') else '⊘ cannot read'}"
                   + (f": {act['words']}" if act.get("words") else ""))
    if rd.get("last_run_id"):
        out.append(f"  last run: torana atlas inquiry get {rd['last_run_id']}")
    return out


def consent_line(data: dict) -> str:
    c = data.get("consent") or {}
    return "Consent: " + " ".join(x for x in (c.get("glyph"), c.get("words") or c.get("state") or "?") if x)


def render_list(data: dict) -> str:
    lines = [consent_line(data)]
    docs = data.get("documents") or []
    if docs:
        for r in docs:
            lines.append(document_line(r))
            if read_line(r):
                lines.append(f"  {read_line(r)}")
        lines.append(f"{len(docs)} of {data.get('total', len(docs))} documents · page {data.get('page', 1)}")
    elif (data.get("consent") or {}).get("state") == "granted":
        lines.append("No documents.")
    if (data.get("purge_pending") or {}).get("words"):                  # 6b follow-up #6: count only, no names
        lines.append(data["purge_pending"]["words"])
    return "\n".join(lines)


def render_row(data: dict) -> str:
    """An upload's or a read-back's row: the line, then the server's state words (and `unchanged` words)."""
    lines = [document_line(data)]
    if data.get("unchanged") and data.get("unchanged_words"):
        lines.append(f"  {data['unchanged_words']}")
    if data.get("superseded") and data.get("superseded_words"):          # 6b follow-up #4: a re-upload replaced one
        lines.append(f"  {data['superseded_words']}")
    if data.get("words"):
        lines.append(f"  {data['words']}")
    if data.get("description"):
        lines.append(f"  description: {data['description']}")
    lines += read_detail(data)
    return "\n".join(lines)


def render_history(data: dict) -> str:
    items = data.get("items") or []
    lines = [f"{data.get('name') or '?'}: {len(items)} version(s), newest first"]
    for r in items:
        lines.append(f"{state_of(r)} · {r.get('sha256') or '?'} · {r.get('size', '?')} bytes · "
                     f"by {r.get('uploaded_by') or '?'} · {human_time(r.get('uploaded_at')) or '?'}")
        if r.get("words"):
            lines.append(f"  {r['words']}")
    return "\n".join(lines)


def render_delete(data: dict) -> str:
    lines = [f"{state_of(data)} · {data.get('name') or '?'} · {data.get('deleted_rows', 0)} version(s) deleted"]
    if data.get("words"):
        lines.append(f"  {data['words']}")
    for k, v in (data.get("erased") or {}).items():
        if v:
            lines.append(f"  {k}: {v}")
    return "\n".join(lines)


def _send(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except AuthError as e:
        handle_auth_error(e)
    except APIError as e:
        _refusal(e, DOCUMENT_REFUSAL_EXTRAS)


def _emit(ctx, data, render):
    fmt, raw, fields = _fmt(ctx)
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt, raw=raw, fields=fields)
        return
    click.echo(render(data))


@click.group(name="documents", invoke_without_command=True)
@click.pass_context
def atlas_documents(ctx):
    """A tenant's uploaded texts (runbooks, policies, notes) that Knowledge may learn from. Upload and delete need
    atlas:document; list and get need atlas:read. Served only while the tenant's document consent is granted
    (torana integrations knowledge-consent pushed grant document --scope model_processing --text-version 1).

    \b
    Examples:
      torana atlas documents upload docs/runbooks/deploy.md
      torana atlas documents upload notes.txt --name policies/retention.txt --description "Retention policy"
      torana atlas documents list
      torana atlas documents get docs/runbooks/deploy.md --history
      torana atlas documents get docs/runbooks/deploy.md --version <SHA256> --out deploy.v1.md
      torana atlas documents delete docs/runbooks/deploy.md --yes
    """
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@atlas_documents.command(name="upload")
@click.argument("file", type=click.Path(exists=True, dir_okay=False, readable=True))
@click.option("--name", default=None, help="The document's name (default: FILE as given, './' stripped).")
@click.option("--media-type", type=click.Choice(["text/plain", "text/markdown"]), default=None,
              help="Default: by suffix (.md → text/markdown, else text/plain), chosen by the server.")
@click.option("--description", default=None, help="What the document is (kept on the row).")
@click.pass_context
def documents_upload(ctx, file, name, media_type, description):
    """Upload FILE (UTF-8 text). The same text again changes nothing (`unchanged`); a new text supersedes the current
    version, which is kept so older quotes still read."""
    try:
        text = Path(file).read_text(encoding="utf-8")
    except UnicodeDecodeError:
        raise click.UsageError(f"{file} is not UTF-8 text; only text/plain and text/markdown documents are accepted")
    body = {"name": name or default_name(file), "text": text}
    if media_type:
        body["media_type"] = media_type
    if description is not None:
        body["description"] = description
    data = _send(_client(ctx).post, "atlas/documents", json=body)
    _emit(ctx, data, render_row)


@atlas_documents.command(name="list")
@click.option("--page", type=click.IntRange(min=1), default=1, show_default=True)
@click.option("--page-size", type=click.IntRange(1, MAX_PAGE_SIZE), default=50, show_default=True)
@click.pass_context
def documents_list(ctx, page, page_size):
    """The tenant's document consent, then its current documents, newest first (none unless consent is granted)."""
    data = _send(_client(ctx).get, "atlas/documents", params={"page": page, "page_size": page_size})
    _emit(ctx, data, render_list)


@atlas_documents.command(name="get")
@click.argument("name")
@click.option("--version", default=None, metavar="SHA256", help="A named version (its full sha256) instead of the current.")
@click.option("--history", is_flag=True, default=False, help="Every version of the name, newest first.")
@click.option("--out", type=click.Path(dir_okay=False, writable=True), default=None,
              help="Write the text to this file instead of printing it.")
@click.pass_context
def documents_get(ctx, name, version, history, out):
    """Read a document back: its row and text (the current version, or --version), or --history."""
    if history and (version or out):
        raise click.UsageError("--history lists the versions; it takes neither --version nor --out")
    params = {"history": "true"} if history else ({"version": version} if version else None)
    data = _send(_client(ctx).get, _path(name), params=params)
    fmt, _, _ = _fmt(ctx)
    if history or fmt != "text" or not isinstance(data, dict):
        _emit(ctx, data, render_history)
        return
    if out:
        Path(out).write_text(data.get("text") or "", encoding="utf-8")
        click.echo(render_row(data))
        click.echo(f"wrote {len((data.get('text') or '').encode('utf-8'))} bytes to {out}")
        return
    click.echo(render_row(data), err=True)          # the row on stderr: stdout is the text alone (pipe-safe)
    click.echo(data.get("text") or "", nl=False)


@atlas_documents.command(name="read")
@click.argument("name")
@click.option("--version", default=None, metavar="SHA256", help="Read this version (its full sha256), not the current.")
@click.option("--max-usd", type=click.FloatRange(min=0.01), default=None,
              help="Spend at most this much (clamped to the platform's per-session cap, $0.50 today).")
@click.option("--timeout", "timeout_s", type=click.IntRange(min=1), default=None, help="Seconds the session may run.")
@_wait_options
@click.pass_context
def documents_read(ctx, name, version, max_usd, timeout_s, wait, poll, wait_timeout):
    """Have a model read NAME section by section (paid; needs atlas:ask and the document consent). Each claim it
    finds is stored with a verbatim quote of its section at this version; every section it read is recorded, items or
    not. The same version again costs $0. A long document is read in slices of whole sections: ask again for the rest.

    \b
    Examples:
      torana atlas documents get docs/runbooks/deploy.md        # the read state and the estimate first
      torana atlas documents read docs/runbooks/deploy.md --wait
      torana atlas documents read docs/runbooks/deploy.md --version <SHA256> --max-usd 0.2
    """
    body = {"kind": "document", "document": name}
    if version:
        body["version"] = version
    budget = {k: v for k, v in (("max_usd", max_usd), ("timeout_s", timeout_s)) if v is not None}
    if budget:
        body["budget"] = budget
    client = _client(ctx)
    data = _send(client.post, "atlas/inquiries", json=body)
    if wait and isinstance(data, dict) and data.get("status") == "running":
        wait_for_inquiry(ctx, client, data["inquiry_id"], None, poll, wait_timeout)
        return
    _show(ctx, data)


@atlas_documents.command(name="delete")
@click.argument("name")
@click.option("--yes", is_flag=True, default=False, help="Do not ask for confirmation.")
@click.pass_context
def documents_delete(ctx, name, yes):
    """Delete EVERY version of NAME and erase what Knowledge learned from it. Cannot be undone; needs no consent."""
    # 6b follow-up #5: the shared helper refuses (exit 125, naming --yes) under --json or when stdin ends unanswered
    confirm(f"Delete every version of {name} and what Knowledge learned from it?", yes=yes)
    data = _send(_client(ctx).delete, _path(name))
    _emit(ctx, data, render_delete)
