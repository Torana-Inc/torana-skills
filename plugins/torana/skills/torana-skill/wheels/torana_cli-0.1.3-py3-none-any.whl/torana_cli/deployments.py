"""torana deployments — collection ops for Deployment objects (EM Deployment_Object_and_
Runtime_Provenance.md § 3.5.1).

Collection-only per the CLI plural/singular rule: `create`, `list`, plus the cross-cutting
`test-connection` (pre-create, no id) and `exposure-intelligence` (cross-deployment output).
Instance verbs (get/update/delete/status/workloads/sync) live in the singular `deployment`
group (deployment.py).

A Deployment is a tenant-scoped governance object pointing at a live cluster
(GKE/EKS/AKS/raw-k8s); on create it provisions a bound Kubernetes-cluster integration that
reads the running workloads/services and their image provenance.
"""

import json

import click

# Sourced from the domain-property registry, never hardcoded here: a surface
# with its own copy of the vocabulary is how a tenant ends up storing a value
# the filters do not recognise.
#
# WHY THE FALLBACK IS EMPTY, NOT A COPY OF THE LIST
# -------------------------------------------------
# The obvious fallback — restating ["production","staging","development"] — is
# the drift this whole change removes. It looks harmless because it matches
# TODAY; it becomes wrong silently the moment a value is added to the registry,
# and the CLI would then reject a value the API accepts, with no signal that the
# two disagreed.
#
# Empty means "this CLI cannot enumerate the vocabulary", which Click renders as
# an unconstrained string. The value still gets validated — by the API's schema
# and the service layer, both of which read the registry. So a bare-environment
# CLI loses the local pre-check and the tab-completion, never the correctness.
# Degrading to "ask the server" beats degrading to "guess, confidently".
try:
    from pantheon_shared.domain_properties import allowed_values_for
    ENVIRONMENTS = list(allowed_values_for("env_label"))
except Exception:  # pragma: no cover - shared lib absent
    ENVIRONMENTS = []

from torana_cli.client.auth import AuthError
from torana_cli.client.base import (
    APIError,
    ToranaClient,
    handle_api_error,
    handle_auth_error,
)
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW, CollectionGroup
from torana_cli.output import output


def _env_dash(data, fmt):
    """The human views show `—` for a Deployment with no environment label (a cluster one has none), never an empty cell.
    JSON is left exactly as served."""
    if fmt not in ("text", "table") or not isinstance(data, (dict, list)):
        return data
    def fix(row):
        return {**row, "env_label": row.get("env_label") or "—"} if isinstance(row, dict) else row
    if isinstance(data, list):
        return [fix(r) for r in data]
    if isinstance(data.get("items"), list):
        return {**data, "items": [fix(r) for r in data["items"]]}
    return fix(data)


DEPLOYMENT_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 16),
    ("cluster_host", "HOST", 8),          # gke|eks|aks|generic (the hosting cloud — a property)
    ("env_label", "ENV", 8),
    ("cluster_ref", "CLUSTER", 26),
    # api_server surfaces WHERE the cluster actually is — a user can tell a real endpoint from a
    # mock/replay one at a glance (a mock points at an internal host, not a real cloud API server).
    ("api_server", "API-SERVER", 40),
]

#: The list a super admin reads across tenants (`--all-tenants`) or for one named tenant
#: (`--tenant`): the same columns, led by the tenant the row belongs to.
TENANT_DEPLOYMENT_COLS = [("tenant_id", "TENANT", 36)] + DEPLOYMENT_COLS


#: The business-context fields whose workload label names a cluster Deployment sets.
LABEL_FIELDS = ("owner", "team", "criticality", "customer_data")


def label_names_body(owner_label, team_label, criticality_label, customer_data_label):
    """The API `label_names` map from the four --*-label flags (None when none was given)."""
    given = {"owner": owner_label, "team": team_label, "criticality": criticality_label,
             "customer_data": customer_data_label}
    out = {k: v for k, v in given.items() if v is not None}
    return out or None


def label_options(func):
    """The four --*-label flags (DS2 § 3.3.16)."""
    for field in reversed(LABEL_FIELDS):
        flag = "--" + field.replace("_", "-") + "-label"
        func = click.option(flag, f"{field}_label", default=None,
                            help=f"Workload label(s) holding {field.replace('_', ' ')} "
                                 "(comma-separated; '' restores the default).")(func)
    return func


def print_label_names(data):
    """A LABELS block: field, the names read, default or set."""
    names = (data or {}).get("label_names") or {}
    if not names:
        return
    click.echo("\nLABELS (business context is read from each workload's own labels)")
    for field in LABEL_FIELDS:
        v = names.get(field) or {}
        click.echo(f"  {field:<14} {', '.join(v.get('names') or []):<56} "
                   f"{'default' if v.get('default') else 'set'}")


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    return ToranaClient(base_url=get_settings(profile).base_url)


def _ctx(ctx):
    return (
        ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text",
        ctx.obj.get(CTX_RAW, False) if ctx.obj else False,
        ctx.obj.get(CTX_FIELDS) if ctx.obj else None,
    )


def parse_json_opt(value, label):
    """Parse a --json-ish option; raise a clear BadParameter on bad JSON. Shared with the
    singular group (deployment.py imports this)."""
    if value is None:
        return None
    try:
        return json.loads(value)
    except (ValueError, TypeError) as exc:
        raise click.BadParameter(f"{label} must be valid JSON: {exc}")


# The credential options shared by `create` and `test-connection`. A secret must be able to
# arrive WITHOUT being an argument: an argument lands in shell history and in `ps` for every
# local process to read. --auth stays for non-secret config; --auth-file / --access-token-stdin
# carry the secret (same contract as `deployment <id> credentials rotate`).
def auth_source_options(f):
    f = click.option("--access-token-stdin", "token_stdin", is_flag=True, default=False,
                     help="Read the bearer access_token from stdin and add it to the auth JSON "
                          "(--auth or --auth-file). Never put a token on the command line.")(f)
    f = click.option("--auth-file", "auth_file", default=None, metavar="FILE",
                     help="Read the auth JSON from FILE (`-` = stdin) instead of --auth, so a "
                          "secret never appears as an argument.")(f)
    return f


def resolve_auth(auth, auth_file, token_stdin) -> dict:
    """The auth object from --auth | --auth-file, plus --access-token-stdin's token. Error
    messages name the problem only, never the content (it may be a secret)."""
    import sys
    if auth is not None and auth_file:
        raise click.UsageError("Pass --auth or --auth-file, not both.")
    if auth_file == "-" and token_stdin:
        raise click.UsageError("--auth-file - and --access-token-stdin both read stdin: use one.")
    if auth_file:
        try:
            text = sys.stdin.read() if auth_file == "-" else open(auth_file, encoding="utf-8").read()
            obj = json.loads(text)
        except (OSError, ValueError) as e:
            raise click.UsageError(f"--auth-file: not readable JSON ({type(e).__name__}).")
    else:
        obj = parse_json_opt(auth, "--auth") or {}
    if not isinstance(obj, dict):
        raise click.UsageError("The auth JSON must be an object of credential/config fields.")
    if token_stdin:
        token = sys.stdin.read().strip()
        if not token:
            raise click.UsageError("No token on stdin.")
        obj = {**obj, "access_token": token}
    return obj


# ─── parent group ─────────────────────────────────────────────────────────────

@click.group(name="deployments", cls=CollectionGroup, singular="deployment")
def deployments():
    """Manage deployments (cluster targets + governance + runtime provenance).

    \b
    Collection ops: create, list, test-connection, exposure-intelligence.
    Instance ops (get/update/delete/status/workloads/sync): `torana deployment <id> ...`.

    \b
    Examples:
      torana deployments create --name prod --cluster-host gke \\
        --cluster-ref my-proj/prod-cluster/us-central1 --env-label production \\
        --auth '{"service_account_key":"...","project_id":"my-proj","location":"us-central1","gke_cluster_id":"prod-cluster"}'
      torana deployments list
      torana deployments test-connection --cluster-host gke --auth '{...}'
      kubectl -n <ns> create token <SA> | torana deployments create --name stg --cluster-host generic \
        --cluster-ref stg-k3s --env-label staging --auth '{"k8s_api_server":"https://h:6443"}' --access-token-stdin
      torana deployment <id> status
    """


# ─── create ───────────────────────────────────────────────────────────────────

@deployments.command(name="create")
@click.option("--name", required=True, help="Deployment name (unique among live deployments).")
@click.option("--source-type", type=click.Choice(["cluster", "manifest"]), default="cluster",
              help="cluster = bound live k8s integration (observed); manifest = declared, "
                   "rendered manifests pushed via `entity-graph parse-manifests` (no cluster/creds).")
@click.option("--cluster-host", default=None,
              type=click.Choice(["gke", "eks", "aks", "generic"]),
              help="Cluster host: where it runs (gke|eks|aks|generic). One Kubernetes integration; "
                   "the host is a property. `generic` = self-hosted / any API-server + token.")
@click.option("--cluster-type", default=None, type=click.Choice(["gke", "eks", "aks", "k8s"]),
              help="Deprecated alias for --cluster-host.")
@click.option("--cluster-ref", default=None, help="project/cluster/region or endpoint (cluster only).")
@click.option("--env-label", default=None,
              type=click.Choice(ENVIRONMENTS, case_sensitive=False) if ENVIRONMENTS else str,
              help="Manifest Deployments only: key segment that separates the Compose services "
                   "pushed under this Deployment (service:<value>/<name>). Not an environment: "
                   "each object's own `environment` label is read.")
@click.option("--description", default="", help="Semantic description of this deployment.")
@click.option("--provenance-label-map", default=None,
              help='JSON per-field OCI label-key overrides, e.g. \'{"commit":["com.acme.git.sha"]}\'.')
@click.option("--auth", default=None, help="JSON provider cluster credentials/config (cluster only).")
@auth_source_options
@label_options
@click.pass_context
def create(ctx, name, source_type, cluster_host, cluster_type, cluster_ref, env_label, description,
           provenance_label_map, auth, auth_file, token_stdin, owner_label, team_label, criticality_label,
           customer_data_label):
    """Create a deployment.

    source_type=cluster provisions a bound cluster integration reading the live cluster.
    source_type=manifest is a declared deployment (no cluster, no credentials) — feed it
    rendered manifests with `torana entity-graph parse-manifests --deployment <id>`.
    """
    fmt, raw, fields = _ctx(ctx)
    if source_type == "manifest" and not env_label:
        raise click.UsageError("--env-label is required for --source-type manifest")
    body = {
        "name": name,
        "source_type": source_type,
        "description": description,
        "provenance_label_map": parse_json_opt(provenance_label_map, "--provenance-label-map"),
        "auth": resolve_auth(auth, auth_file, token_stdin),
    }
    if env_label:
        body["env_label"] = env_label
    labels = label_names_body(owner_label, team_label, criticality_label, customer_data_label)
    if labels:
        body["label_names"] = labels
    # cluster identity only for cluster deployments; a manifest deployment has none.
    host = cluster_host or cluster_type   # --cluster-host preferred; --cluster-type is the alias
    if host:
        body["cluster_host"] = host
    if cluster_ref:
        body["cluster_ref"] = cluster_ref
    client = _client(ctx)
    try:
        data = client.post("deployments", json=body)
    except AuthError as e:
        handle_auth_error(e); return
    except APIError as e:
        handle_api_error(e); return
    output(_env_dash(data, fmt), fmt=fmt, raw=raw, fields=fields, columns=DEPLOYMENT_COLS)
    if fmt == "text":
        print_label_names(data)


# ─── list ─────────────────────────────────────────────────────────────────────

@deployments.command(name="list")
@click.option("--limit", default=100, type=int, help="Max rows (<=100).")
@click.option("--offset", default=0, type=int, help="Pagination offset.")
@click.option("--tenant", "tenant_id", default=None, metavar="TENANT_ID",
              help="Super admin only: list THIS tenant's deployments (read-only). Recorded in the "
                   "security audit log as a cross-tenant read (`torana audit-logs`).")
@click.option("--all-tenants", "all_tenants", is_flag=True, default=False,
              help="Super admin only: list every tenant's deployments, with a TENANT column. "
                   "Recorded as an all-tenants read.")
@click.pass_context
def list_deployments(ctx, limit, offset, tenant_id, all_tenants):
    """List deployments.

    Without an option this is the caller's own tenant. A super admin reads another tenant's
    deployments with --tenant (or every tenant's with --all-tenants); then use
    `torana deployment <ID> get|status|workloads --tenant <TENANT_ID>` on one of them.

    \b
    Examples:
      torana deployments list
      torana deployments list --tenant <TENANT_ID>     SA: one other tenant
      torana deployments list --all-tenants            SA: every tenant
    """
    if tenant_id and all_tenants:
        raise click.UsageError("--tenant and --all-tenants are exclusive: name one tenant or ask for all.")
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    params = {"limit": limit, "offset": offset}
    if tenant_id:
        params["tenant_id"] = tenant_id
    try:
        data = client.get("admin/deployments" if all_tenants else "deployments", params=params)
    except AuthError as e:
        handle_auth_error(e); return
    except APIError as e:
        handle_api_error(e); return
    data = {"items": data.get("deployments", []), "total": data.get("count", 0),
            "page": 1, "page_size": limit}
    cols = TENANT_DEPLOYMENT_COLS if (tenant_id or all_tenants) else DEPLOYMENT_COLS
    output(_env_dash(data, fmt), fmt=fmt, raw=raw, fields=fields, columns=cols)


@deployments.command(name="discoverable-clusters")
@click.pass_context
def discoverable_clusters(ctx):
    """On-demand: GKE clusters already ingested via the GCP integration, for create autofill.

    Read-only, nothing persisted. Each row prefills a new deployment (cluster identity only,
    NOT governance/credentials) and is flagged `already_added` if a deployment already exists
    for that cluster.
    """
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.get("deployments/discoverable-clusters")
    except AuthError as e:
        handle_auth_error(e); return
    except APIError as e:
        handle_api_error(e); return
    data = {"items": data.get("clusters", []), "total": data.get("count", 0),
            "page": 1, "page_size": len(data.get("clusters", []))}
    output(data, fmt=fmt, raw=raw, fields=fields, columns=[
        ("cluster_name", "CLUSTER", 24), ("cluster_ref", "REF", 36),
        ("control_plane_public", "CP-PUBLIC", 10), ("already_added", "ADDED", 6),
    ])


# ─── test-connection (collection-level: pre-create, no id) ─────────────────────

@deployments.command(name="test-connection")
@click.option("--cluster-host", default=None,
              type=click.Choice(["gke", "eks", "aks", "generic"]), help="Cluster host.")
@click.option("--cluster-type", default=None, type=click.Choice(["gke", "eks", "aks", "k8s"]),
              help="Deprecated alias for --cluster-host.")
@click.option("--auth", default=None, help="JSON provider cluster credentials/config.")
@auth_source_options
@click.pass_context
def test_connection(ctx, cluster_host, cluster_type, auth, auth_file, token_stdin):
    """Test a cluster connection without persisting anything (pre-create check)."""
    fmt, raw, fields = _ctx(ctx)
    body = {"cluster_host": cluster_host or cluster_type or "generic",
            "auth": resolve_auth(auth, auth_file, token_stdin)}
    client = _client(ctx)
    try:
        data = client.post("deployments/test-connection", json=body)
    except AuthError as e:
        handle_auth_error(e); return
    except APIError as e:
        handle_api_error(e); return
    output(data, fmt=fmt, raw=raw, fields=fields)


# ─── sync (instance: re-run the deployment's cluster sync) ─────────────────────

@deployments.command(name="sync")
@click.argument("deployment_id", metavar="DEPLOYMENT_ID")
@click.pass_context
def sync(ctx, deployment_id):
    """Trigger an on-demand sync of DEPLOYMENT_ID's cluster (workloads + services/ingresses).

    Re-runs the k8s extractors against the live cluster, refreshing service:/image: nodes,
    deployed_as/exposed_via edges, and per-service governance (e.g. public_access) on the
    existing asset rows. Use after changing a deployment's governance or the cluster's topology.
    """
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.post(f"deployments/{deployment_id}/sync", json={})
    except AuthError as e:
        handle_auth_error(e); return
    except APIError as e:
        handle_api_error(e); return
    output(data, fmt=fmt, raw=raw, fields=fields)


# ─── exposure-intelligence (cross-deployment output) ───────────────────────────

@deployments.command(name="exposure-intelligence")
@click.option("--severity", default=None,
              help="Comma-separated severities to surface, e.g. 'critical,high' "
                   "(backend default: critical,high). Not repeatable — pass one list.")
@click.option("--require-exposed/--no-require-exposed", "require_exposed", default=None,
              help="Only network-exposed services (backend default: on).")
@click.option("--require-customer-data/--no-require-customer-data", "require_customer_data",
              default=None, help="Only services handling customer data (backend default: off).")
@click.option("--write-findings", is_flag=True, default=False,
              help="Persist policy findings (requires deployment:update — 403 otherwise).")
@click.option("--limit", default=None, type=click.IntRange(1, 500),
              help="Max ranked rows (1..500 — this endpoint allows up to 500, not the usual 100).")
@click.pass_context
def exposure_intelligence(ctx, severity, require_exposed, require_customer_data,
                          write_findings, limit):
    """"Where must I act" — ranked exposure intelligence across deployments (Phase 8).

    \b
    Examples:
      torana deployments exposure-intelligence --severity critical,high --require-exposed
      torana deployments exposure-intelligence --write-findings   # needs deployment:update
    """
    fmt, raw, fields = _ctx(ctx)
    params = {}
    if severity:
        params["severity"] = severity           # comma-list passed through verbatim
    if require_exposed is not None:
        params["require_exposed"] = "true" if require_exposed else "false"
    if require_customer_data is not None:
        params["require_customer_data"] = "true" if require_customer_data else "false"
    if write_findings:
        params["write_findings"] = "true"
    if limit is not None:
        params["limit"] = limit                 # already validated to 1..500 (not clamped)

    client = _client(ctx)
    try:
        data = client.get("deployments/exposure-intelligence", params=params)
    except AuthError as e:
        handle_auth_error(e); return
    except APIError as e:
        handle_api_error(e); return             # 403 (needs deployment:update) → clean error
    output(data, fmt=fmt, raw=raw, fields=fields)
