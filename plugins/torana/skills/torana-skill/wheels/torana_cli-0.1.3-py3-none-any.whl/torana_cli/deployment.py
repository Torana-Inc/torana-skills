"""torana deployment <id> — instance ops for one Deployment (EM Deployment_Object_and_
Runtime_Provenance.md § 3.5.1).

Singular/instance group per the CLI plural/singular rule. Collection ops (create/list/
test-connection/exposure-intelligence) live in the plural `deployments` group.

  deployment <id> get
  deployment <id> update [--internet-facing/...] [--criticality ...] ...
  deployment <id> delete
  deployment <id> status
  deployment <id> workloads
  deployment <id> sync
  deployment <id> credentials rotate (--access-token-stdin | --file FILE)
"""

from typing import Optional

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import (
    APIError,
    ToranaClient,
    handle_api_error,
    handle_auth_error,
)
from torana_cli.config.settings import get_settings
from torana_cli.deployments import (
    DEPLOYMENT_COLS,
    label_names_body,
    label_options,
    parse_json_opt,
    print_label_names,
)
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output


_WORKLOAD_COLS = [
    ("service_name", "SERVICE", 22),
    ("service_application", "ENV", 10),
    ("container_image_id", "IMAGE", 44),
    ("public_access", "PUBLIC", 7),
    ("criticality_name", "CRIT", 9),
    ("asset_owner", "OWNER", 16),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    return ToranaClient(base_url=get_settings(profile).base_url)


def _ctx(ctx):
    return (
        ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text",
        ctx.obj.get(CTX_RAW, False) if ctx.obj else False,
        ctx.obj.get(CTX_FIELDS) if ctx.obj else None,
    )


def _did(ctx) -> str:
    return ctx.obj.get("_deployment_id", "") if ctx.obj else ""


def _remember_tenant(ctx, _param, value):
    if value:
        ctx.ensure_object(dict)
        ctx.obj["_deployment_tenant"] = value
    return value


def tenant_option(f):
    """`--tenant` on every `deployment <ID> ...` subcommand (a group option cannot follow the ID)."""
    return click.option(
        "--tenant", "_tenant", default=None, metavar="TENANT_ID", expose_value=False,
        callback=_remember_tenant, is_eager=True,
        help="Super admin only: the deployment belongs to THIS tenant. A read (get, status, "
             "workloads) is recorded as a cross-tenant read; a change (update, delete, sync) is "
             "refused (403 act_as_required) unless you also declare `torana --act-as-tenant "
             "<same id> --act-as-reason \"<why>\"`.")(f)


def _params(ctx, params: Optional[dict] = None) -> Optional[dict]:
    """`params` plus `tenant_id` when the group was given --tenant (the API's tenant swap)."""
    tenant = ctx.obj.get("_deployment_tenant") if ctx.obj else None
    if not tenant:
        return params
    return {**(params or {}), "tenant_id": tenant}


# ─── singular instance group ────────────────────────────────────────────────────

@click.group(name="deployment", invoke_without_command=True)
@click.argument("deployment_id", metavar="DEPLOYMENT_ID")
@click.pass_context
def deployment(ctx, deployment_id):
    """Operate on ONE deployment by id.

    \b
    A deployment owns a bound integration — so `delete` removes both, and `update`
    on its governance fires the graph repaint. Use `torana deployments list` to
    find the id. A super admin reaches another tenant's deployment with --tenant
    (find it with `torana deployments list --tenant <TENANT_ID>`).

    \b
    Examples:
      torana deployments list                        find the id
      torana deployment <DEPLOYMENT_ID> get
      torana deployment <DEPLOYMENT_ID> status       bound-integration sync health
      torana deployment <DEPLOYMENT_ID> workloads    observed service nodes
      torana deployment <DEPLOYMENT_ID> sync         on-demand cluster sync
      torana deployment <DEPLOYMENT_ID> status --tenant <TENANT_ID>   SA: another tenant's
    """
    ctx.ensure_object(dict)
    ctx.obj["_deployment_id"] = deployment_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@deployment.command(name="get")
@tenant_option
@click.pass_context
def get(ctx):
    """Get this deployment."""
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.get(f"deployments/{_did(ctx)}", params=_params(ctx))
    except AuthError as e:
        handle_auth_error(e); return
    except APIError as e:
        handle_api_error(e); return
    output(data, fmt=fmt, raw=raw, fields=fields, columns=DEPLOYMENT_COLS)
    if fmt == "text":
        print_label_names(data)


@deployment.command(name="update")
@tenant_option
@click.option("--description", default=None, help="Update description.")
@click.option("--provenance-label-map", default=None, help="JSON per-field OCI label-key overrides.")
@label_options
@click.pass_context
def update(ctx, description, provenance_label_map, owner_label, team_label, criticality_label,
           customer_data_label):
    """Update this deployment's description, provenance label map or workload label names.

    \b
    Business context is not a Deployment field: it is read from each workload's own labels
    (rename them with the --*-label flags), or set as a policy entry (`torana govern`).
    """
    fmt, raw, fields = _ctx(ctx)
    body = {}
    if description is not None:
        body["description"] = description
    if provenance_label_map is not None:
        body["provenance_label_map"] = parse_json_opt(provenance_label_map, "--provenance-label-map")
    labels = label_names_body(owner_label, team_label, criticality_label, customer_data_label)
    if labels:
        body["label_names"] = labels
    if not body:
        raise click.UsageError("Nothing to update — pass at least one field.")
    client = _client(ctx)
    try:
        data = client.put(f"deployments/{_did(ctx)}", json=body, params=_params(ctx))
    except AuthError as e:
        handle_auth_error(e); return
    except APIError as e:
        handle_api_error(e); return
    output(data, fmt=fmt, raw=raw, fields=fields, columns=DEPLOYMENT_COLS)
    if fmt == "text":
        print_label_names(data)
        if data.get("label_names_note"):
            click.echo(f"note: label names {data['label_names_note']}")


@deployment.group(name="credentials", invoke_without_command=True)
@click.pass_context
def credentials(ctx):
    """The deployment's cluster credential (held by its bound integration).

    \b
    Examples:
      kubectl -n argocd create token <SA> --duration=24h | \\
        torana deployment <DEPLOYMENT_ID> credentials rotate --access-token-stdin
      torana deployment <DEPLOYMENT_ID> credentials rotate --file new-auth.json
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@credentials.command(name="rotate")
@tenant_option
@click.option("--file", "input_file", default=None, metavar="FILE",
              help="JSON object of credential fields to replace, e.g. {\"access_token\": \"…\"}; "
                   "`-` reads it from stdin.")
@click.option("--access-token-stdin", "token_stdin", is_flag=True, default=False,
              help="Read a new access_token (bearer token) from stdin.")
@click.pass_context
def credentials_rotate(ctx, input_file, token_stdin):
    """Replace the cluster credential; the new one is tested before it is stored.

    \b
    Omitted fields keep their stored value. Identity (cluster_ref, env_label …) and
    governance fields are refused: use `update` for governance. A credential that fails
    the connection test is refused and the stored one keeps working. The secret is read
    from a file or stdin only (never an argument, which would land in shell history) and
    is never printed.

    \b
    Examples:
      kubectl -n argocd create token argocd-application-controller --duration=24h | \\
        torana deployment <DEPLOYMENT_ID> credentials rotate --access-token-stdin
      torana deployment <DEPLOYMENT_ID> credentials rotate --file new-auth.json
    """
    import json
    import sys

    if bool(input_file) == bool(token_stdin):
        raise click.UsageError("Pass exactly one of --file or --access-token-stdin.")
    if token_stdin:
        token = sys.stdin.read().strip()
        if not token:
            raise click.UsageError("No token on stdin.")
        auth = {"access_token": token}
    else:
        try:
            text = sys.stdin.read() if input_file == "-" else open(input_file, encoding="utf-8").read()
            auth = json.loads(text)
        except (OSError, ValueError) as e:
            raise click.UsageError(f"--file: not readable JSON ({type(e).__name__}).")
        if not isinstance(auth, dict) or not auth:
            raise click.UsageError("--file must hold a non-empty JSON object of credential fields.")
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.put(f"deployments/{_did(ctx)}/credentials", json={"auth": auth},
                          params=_params(ctx))
    except AuthError as e:
        handle_auth_error(e); return
    except APIError as e:
        handle_api_error(e); return
    if fmt == "text" and not raw and not fields:
        click.echo(data.get("words") or "credential rotated")
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@deployment.command(name="delete")
@tenant_option
@click.option("--dry-run", "dry_run", is_flag=True, default=False,
              help="Show what would be retired; delete nothing.")
@click.pass_context
def delete(ctx, dry_run):
    """Soft-delete this deployment (+ its bound integration).

    A `manifest` deployment also retires (tombstones) the rows its pushes created in its
    cluster; rows another source also contributes keep that source and stay live. Run it
    again on an already-deleted manifest deployment to retire rows it left behind.

    Examples:
      torana deployment <DEPLOYMENT_ID> delete --dry-run    what would be retired
      torana deployment <DEPLOYMENT_ID> delete
    """
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.delete(f"deployments/{_did(ctx)}",
                             params=_params(ctx, {"dry_run": "true"} if dry_run else None))
    except AuthError as e:
        handle_auth_error(e); return
    except APIError as e:
        handle_api_error(e); return
    data = data or {"status": "deleted", "id": _did(ctx)}
    retired = data.get("retired") if isinstance(data, dict) else None
    if fmt == "text" and not raw and not fields and isinstance(data, dict):
        click.echo(f"STATUS  {data.get('status')}\nID      {data.get('id')}")
        if isinstance(retired, dict):
            _echo_retired(retired)
    else:
        output(data, fmt=fmt, raw=raw, fields=fields)
    if isinstance(retired, dict) and retired.get("error"):
        ctx.exit(1)


def _echo_retired(retired: dict) -> None:
    """The pushed-row retirement of a manifest deployment, one line per table."""
    if retired.get("skipped"):
        click.echo(f"RETIRE  skipped: {retired['skipped']}")
        return
    if retired.get("error"):
        click.echo(f"RETIRE  FAILED: {retired['error']} (run delete again to retry)", err=True)
        return
    dry = retired.get("dry_run")
    click.echo(f"RETIRE  cluster {retired.get('cluster_ref')}, contributor "
               f"{retired.get('contributor')}" + ("  (dry run: nothing changed)" if dry else ""))
    for table, e in (retired.get("tables") or {}).items():
        if dry:
            click.echo(f"  {table:<24} would retire {e.get('to_retire', 0):>5}   "
                       f"strip key from {e.get('to_strip', 0):>5}")
        else:
            click.echo(f"  {table:<24} retired {e.get('retired', 0):>5}   "
                       f"key stripped from {e.get('stripped', 0):>5}")


@deployment.command(name="status")
@tenant_option
@click.pass_context
def status(ctx):
    """Show this deployment's bound-integration sync status / health."""
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.get(f"deployments/{_did(ctx)}/status", params=_params(ctx))
    except AuthError as e:
        handle_auth_error(e); return
    except APIError as e:
        handle_api_error(e); return
    output(data, fmt=fmt, raw=raw, fields=fields)


@deployment.command(name="workloads")
@tenant_option
@click.option("--limit", type=click.IntRange(1, 100), default=100,
              help="Page size (max 100).")
@click.option("--offset", type=click.IntRange(min=0), default=0,
              help="Rows to skip for paging.")
@click.pass_context
def workloads(ctx, limit, offset):
    """List this deployment's observed workloads (service nodes) + governance/exposure.

    Paginated — a real cluster has many workloads. Use --limit/--offset to page;
    `total` in the envelope is the full count.
    """
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.get(f"deployments/{_did(ctx)}/workloads",
                          params=_params(ctx, {"limit": limit, "offset": offset}))
    except AuthError as e:
        handle_auth_error(e); return
    except APIError as e:
        handle_api_error(e); return
    page_size = data.get("limit", limit) or limit
    off = data.get("offset", offset) or 0
    data = {"items": data.get("workloads", []),
            "total": data.get("total", data.get("count", 0)),
            "page": (off // page_size) + 1 if page_size else 1,
            "page_size": page_size}
    output(data, fmt=fmt, raw=raw, fields=fields, columns=_WORKLOAD_COLS)


@deployment.command(name="sync")
@tenant_option
@click.pass_context
def sync(ctx):
    """Trigger an on-demand sync of this deployment's cluster."""
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.post(f"deployments/{_did(ctx)}/sync", json={}, params=_params(ctx))
    except AuthError as e:
        handle_auth_error(e); return
    except APIError as e:
        handle_api_error(e); return
    output(data, fmt=fmt, raw=raw, fields=fields)
