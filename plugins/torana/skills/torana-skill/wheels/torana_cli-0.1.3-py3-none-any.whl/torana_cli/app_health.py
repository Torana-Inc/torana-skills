"""`torana app <APP_ID> health`: App Health, the one place that says what is not working in an app (design note
APP_HEALTH_DESIGN_NOTE.md, S3). The same snapshot the Home page's last section shows (D9): never recomputed here.

  health                      one line per row, in the fixed order (DataLake, Inbox Closed Items, ...)
  health --row "<name>"       one row with its parts (a row name, its key or its number)
  health --refresh [--wait]   ask for a fresh computation; --wait polls until it is done
  --json                      the server's snapshot as it is, for the plugin

Reads GET/POST workspaces/{id}/ai-home/health (PPF). Glyph AND word for every colour, never colour alone.
"""
from __future__ import annotations

import time

import click

from torana_cli.ai_home import _ctx
from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, handle_api_error, handle_auth_error
from torana_cli.output import output

#: Colour -> (glyph, word). `not_used` has no colour.
MARK = {"green": "●", "orange": "◐", "red": "✖", "grey": "○", "not_used": "–"}
#: The colour names: what a row falls back to when the server sent no `label` (an old snapshot).
COLOUR = {"green": "green", "orange": "orange", "red": "red", "grey": "grey", "not_used": "not used"}
#: The status words the screen shows. A row carries them as `label`; a part has none, so these words are used for it.
LABEL = {"green": "Operational", "orange": "Degraded", "red": "Outage", "grey": "Unknown", "not_used": "Not in use"}
NOT_CHECKED = "App Health has not been checked yet. Run:  torana app {app} health --refresh --wait"
POLL_S = 2.0


def _when(iso) -> str:
    from torana_cli.alert import _view_time
    return _view_time(iso) if iso else ""


def _status(item: dict, part: bool = False) -> str:
    """`● Operational`: the colour glyph and the server's `label` (the screen's word). A row without a label falls back to its
    colour name; a part never has one, so it takes the screen's words from its status."""
    st = item.get("status")
    word = item.get("label") or (LABEL if part else COLOUR).get(st, str(st))
    return f"{MARK.get(st, '○')} {word:<11}"


def health_lines(snap: dict, app: str) -> list:
    """One line per row, in the order the server sent (D4): `● green    1 Integrations   Working.`"""
    rows = snap.get("rows") or []
    out = []
    if snap.get("refreshing"):
        out.append("Refreshing now; run this again in a minute for the new result.")
    if not rows:
        out.append(NOT_CHECKED.format(app=app))
        return out
    summary = snap.get("summary") or {}
    if summary.get("sentence"):                 # the server's one line for the whole section, printed first
        out.append(str(summary["sentence"]))
    if snap.get("computed_at"):
        out.append(f"App Health as of {_when(snap['computed_at'])}")
    width = max(len(r.get("name") or "") for r in rows)
    for r in rows:
        line = f"{_status(r)}  {r.get('order', 0):>2}  {(r.get('name') or '').ljust(width)}  {r.get('sentence') or ''}"
        if r.get("status") in ("red", "orange", "grey") and r.get("since"):
            line += f" Since {_when(r['since'])}."
        out.append(line.rstrip())
    bad = [r for r in rows if r.get("status") in ("red", "orange")]
    grey = [r for r in rows if r.get("status") == "grey"]
    out.append("")
    # ⛔ Grey is never a reassurance: "Nothing needs attention." only when every row is green or not used.
    if bad:
        out.append(f"{len(bad)} of {len(rows)} rows need attention. Detail:  torana app {app} health --row \"<name>\"")
    if grey:
        names = ", ".join(r.get("name") or "" for r in grey)
        out.append(f"{len(grey)} {'row' if len(grey) == 1 else 'rows'} could not be checked: {names}. "
                   f"Try:  torana app {app} health --refresh --wait")
    if not bad and not grey:
        out.append("Nothing needs attention.")
    return out


def find_row(snap: dict, name: str):
    """A row by its name (any case), its key or its number; None when there is none."""
    want = str(name or "").strip().lower()
    for r in snap.get("rows") or []:
        if want in (str(r.get("name") or "").lower(), str(r.get("key") or "").lower(), str(r.get("order"))):
            return r
    return None


def row_lines(row: dict, snap: dict) -> list:
    out = [f"{_status(row)}  {row.get('order')}  {row.get('name')}", f"  {row.get('sentence') or ''}"]
    if row.get("status") in ("red", "orange", "grey"):
        if row.get("since"):
            out.append(f"  Since:       {_when(row['since'])}")
        if row.get("next_step"):
            out.append(f"  Next step:   {row['next_step']}")
        if row.get("support_code"):
            out.append(f"  Support code: {row['support_code']}")
    parts = row.get("parts") or []
    if parts:
        out.append("")
        out.append("  Parts:")
        for p in parts:
            since = f" Since {_when(p['since'])}." if p.get("since") and p.get("status") != "green" else ""
            out.append(f"    {_status(p, part=True)}  {p.get('name')}: {p.get('sentence') or ''}{since}")
    return out


def register(workspace_group, client_factory):
    """Attach `health` to the `workspace <id>` group (also `app <id>`), registered from workspace.py."""

    @workspace_group.command(name="health")
    @click.option("--row", "row_name", default=None, metavar="NAME",
                  help="Show one row with its parts: its name (Inbox Closed Items), its key (inbox_closed) or its number.")
    @click.option("--refresh", is_flag=True, default=False, help="Ask for a fresh computation. A refresh already running is joined, not repeated.")
    @click.option("--wait", is_flag=True, default=False, help="With --refresh: wait until the new result is ready (up to --timeout).")
    @click.option("--timeout", "timeout_s", default=120, show_default=True, type=int, help="Seconds --wait waits.")
    @click.pass_context
    def app_health(ctx, row_name, refresh, wait, timeout_s):
        """Show what is working and what is not in this app: one line per part of the app, with its colour, since when
        and what to do. The same rows as the last section of the app's Home page.

        \b
        Rows, in order: Integrations, DataLake, DataPipelines, Entity Graph, Dashboard Widgets, Inbox Filtered Items,
        Inbox Active Items, Inbox Closed Items, Home Top Priorities, Home Daily Briefing.
        Colours: red failing · orange degraded, out of date or partial · grey never run or could not be read ·
        green working. A row shows its worst part, so grey is never a reassurance. "Not used" means the app has none.
        Only things set up that stopped working are here. Things never set up (no access given, no alert route or
        triage agent) are the Landing Page's App Gaps section: torana app <APP_ID> ai-home get --section blind

        \b
        Examples:
          torana app <APP_ID> health
          torana app <APP_ID> health --row "Inbox Closed Items"
          torana app <APP_ID> health --refresh --wait
          torana app <APP_ID> health --json
        """
        fmt, raw, fields = _ctx(ctx)
        wid = ctx.obj.get("_workspace_id", "") if ctx.obj else ""
        client = client_factory(ctx)
        base = f"workspaces/{wid}/ai-home/health"
        try:
            snap = (client.post(f"{base}/refresh", {}) or {}) if refresh else (client.get(base) or {})
            if refresh and wait:
                snap = _wait(client, base, timeout_s)
        except APIError as e:
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return
        if row_name is not None:
            row = find_row(snap, row_name)
            if row is None:
                names = ", ".join(r.get("name") for r in snap.get("rows") or []) or "(not checked yet)"
                click.echo(f"No row \"{row_name}\". Rows: {names}", err=True)
                ctx.exit(1)
            if fmt in ("json", "yaml"):
                output({**{k: v for k, v in snap.items() if k != "rows"}, "row": row}, fmt=fmt, raw=raw, fields=fields)
            else:
                click.echo("\n".join(row_lines(row, snap)))
            return
        if fmt in ("json", "yaml"):
            output(snap, fmt=fmt, raw=raw, fields=fields)
            return
        click.echo("\n".join(health_lines(snap, wid)))


def _wait(client, base: str, timeout_s: int) -> dict:
    """Poll the snapshot until it is no longer refreshing, or the timeout passes (the last snapshot is returned)."""
    deadline = time.monotonic() + max(timeout_s, 1)
    snap = client.get(base) or {}
    while snap.get("refreshing") and time.monotonic() < deadline:
        time.sleep(POLL_S)
        snap = client.get(base) or {}
    return snap
