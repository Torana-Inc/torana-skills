"""Text rendering for proof records (`torana alert <ID> proof`, `torana datalake proof verify|replay`).

A proof record is what GET /api/v1/datalake/proof/alerts/{id} returns: claims whose every span carries a
pointer to the row, selection, column meaning, clock or rule output behind it. Spec:
pantheon-datalake/docs/PROOF_FRAMEWORK_SPEC.md § 3.4.2. JSON output passes the record through untouched;
everything here is presentation only.
"""
from __future__ import annotations

import json

import click

SECTION_TITLES = {"alert": "The alert", "state": "What is actually true", "deep": "Deep-dive", "tech": "Technical", "fix": "Remediation",
                  "group": "The check", "effort": "Effort"}
_MAX_VALUE = 120
_RULE_DEPTH = 3


def plain(spans) -> str:
    return "".join(s.get("text", "") for s in spans or [])


def _short(value) -> str:
    s = json.dumps(value, sort_keys=True, default=str, ensure_ascii=False)
    return s if len(s) <= _MAX_VALUE else s[:_MAX_VALUE - 1] + "…"


def _key(key) -> str:
    return json.dumps(key, sort_keys=True) if isinstance(key, (dict, list)) else str(key)


def _where(where) -> str:
    return " AND ".join(f"{c} {op} {_short(v)}" if op not in ("is_null", "not_null") else f"{c} {op}"
                        for c, op, v in where or [])


def record_lines(rec: dict) -> list:
    """The whole proof: a header, then each claim's question and its text, by section."""
    item, meta = rec.get("item") or {}, rec.get("meta") or {}
    claims = item.get("claims") or []
    unmodelled = [f"No proof model for this item type yet ({item.get('reason') or item.get('type')})."]
    if item.get("type") == "unmodelled" and not claims:
        return unmodelled + graph_lines(item)
    lines = [f"{plain(item.get('title'))} · {item.get('type')} · {len(claims)} claims · built {meta.get('now')} · "
             f"schema {meta.get('schema_version')}"]
    if item.get("type") == "unmodelled":
        lines += unmodelled                       # it still carries the alert's own claims (framework 0.2.0)
    sections = []
    for c in claims:
        if c.get("section") not in sections:
            sections.append(c.get("section"))
    for sec in sections:
        lines += ["", f"── {SECTION_TITLES.get(sec, sec)}"]
        for c in (c for c in claims if c.get("section") == sec):
            lines.append(f"[{c.get('kind')}] {c.get('q')}")
            lines.append(f"    {plain(c.get('spans'))}")
            if c.get("missing"):
                lines.append(f"    not recorded: {plain(c.get('missing'))}")
    lines += graph_lines(item)
    lines += ["", "Trace any claim:  torana alert <ID> proof --claim <CLAIM_ID>   "
                  f"(ids: {', '.join(c.get('id') for c in claims)})"]
    return lines


def _where_when(source, as_of) -> str:
    return ", ".join(x for x in (source, f"as of {as_of}" if as_of else None) if x)


def _panel_lines(n: dict) -> list:
    """A node's panel as the page shows it: its metadata rows, link-outs, and where and when it was read. Never a
    relationship, table, key or query."""
    m = n.get("meta") or {}
    lines = [f"      {k}: {v}" for k, v in m.get("rows") or []]
    lines += [f"      {i.get('label')}" + (f"  {i['url']}" if i.get("url") else "") for i in m.get("items") or []]
    lines += [f"      {l.get('label')}: {l.get('url')}" for l in m.get("links") or []]
    ws = _where_when(m.get("source"), m.get("as_of"))
    return lines + ([f"      Source: {ws}"] if ws else [])


def graph_lines(item: dict) -> list:
    """The item's exposure path (the page's Graph): each edge as `from —label→ to` with where and when it was read, then
    every node with its panel. Kinds with no platform path say why (the page hides the card)."""
    g = item.get("graph") or {}
    nodes, edges = g.get("nodes") or [], g.get("edges") or []
    if not nodes:
        return ["", f"── Exposure path: none ({g.get('note') or 'this item has no path'})"]
    name = {n.get("id"): f"{n.get('t1')} ({n.get('t2')})" if n.get("t2") else str(n.get("t1")) for n in nodes}
    # A group check's row draws ITS path (its check's evidence + the entity graph around it), not an exposure path.
    title = "Row path" if item.get("type") == "group_member" else "Exposure path"
    lines = ["", f"── {title} · {len(nodes)} nodes, {len(edges)} edges"]
    if g.get("note"):
        lines.append(f"  {g['note']}")
    lines += deployment_lines(nodes, edges, name)
    for e in edges:
        if e.get("folded"):
            continue                    # a collapsed deployment's own edge to an image: printed in its group above
        ws = _where_when(e.get("source"), e.get("as_of"))
        # How the link is known, as the page's legend says it: reported (plain), derived, heuristic (a match: "?").
        kind = {"derived": " (derived)", "heuristic": " (heuristic ?)"}.get(e.get("style") or "", "")
        lines.append(f"  {name.get(e.get('from'))} —{e.get('label') or ''}→ {name.get(e.get('to'))}{kind}"
                     + (f"   [{ws}]" if ws else ""))
    for n in nodes:
        lines += [f"  {name[n.get('id')]}"] + _panel_lines(n)
    return lines


def deployment_lines(nodes: list, edges: list, name: dict) -> list:
    """The path's DEPLOYMENTS, one group each (the page draws them collapsed; a terminal cannot fold, so every deployment is
    printed with what it runs): `production (gke-twin-x2yk48 · GKE · internet-facing via 136.117.99.230) · 13 services`, then
    each image its drawn services run, with those services, then its "+K more services". Empty when the path has none.
    A deployment reached through a gateway says so on this line, in the panel's own words (its "Through" row, from
    `path.exposure`): `internet-facing via 136.117.99.230 through pantheon-nginx (reverse proxy)`. No row, no words."""
    deps = [n for n in nodes if n.get("kind") == "deployment"]
    if not deps:
        return []
    by = {n.get("id"): n for n in nodes}
    out = ["  Deployments:"]
    for d in deps:
        rows = {k: v for k, v in ((d.get("meta") or {}).get("rows") or [])}
        parts = (d.get("t2") or "").split(" · ")
        exposed = "internet-facing" in parts
        addr = rows.get("Public address") if rows.get("Public address") not in (None, "unknown") else None
        gateway = rows.get("Through") if rows.get("Through") not in (None, "unknown") else None
        reach = ("internet-facing" + (f" via {addr}" if addr else "")
                 + (f" through {gateway}" if gateway else "")) if exposed else "not internet-facing"
        kind = rows.get("Kind") if rows.get("Kind") not in (None, "unknown") else None
        head = " · ".join(x for x in (d.get("cluster") or parts[0], kind, reach) if x)
        out.append(f"  {d.get('t1')} ({head}) · {parts[-1] if parts else ''}")
        kids = set(d.get("children") or [])
        for e in edges:
            if e.get("folded") != d.get("id"):
                continue
            runners = [by[x["from"]].get("t1") for x in edges if x.get("to") == e.get("to") and x.get("from") in kids
                       and x.get("label") == e.get("label")]
            out.append(f"      —{e.get('label')}→ {name.get(e.get('to'))}" + (f"   run by {', '.join(runners)}" if runners else ""))
        for c in d.get("children") or []:
            if c.endswith("-more") and c in by:
                out.append(f"      {by[c].get('t1')} services not drawn")
    return out


def claim_ids(rec: dict) -> list:
    return [c.get("id") for c in (rec.get("item") or {}).get("claims") or []]


def _pointers(claim: dict) -> list:
    """Every unique pointer behind a claim: its spans, its 'not recorded' spans, then its refs."""
    out, seen = [], set()
    ptrs = [s.get("p") for s in (claim.get("spans") or []) + (claim.get("missing") or [])]
    ptrs += [r.get("p") for r in claim.get("refs") or []]
    for p in ptrs:
        if not p:
            continue
        k = json.dumps(p, sort_keys=True, default=str)
        if k not in seen:
            seen.add(k)
            out.append(p)
    return out


def pointer_lines(rec: dict, p: dict, depth: int = 0, expanded: set | None = None) -> list:
    """One pointer, resolved against the record; a rule output expands into its inputs (to depth 3).
    A run is expanded once; later outputs of the same run point back to it (`expanded` is shared)."""
    expanded = set() if expanded is None else expanded
    pad = "    " * (depth + 1)
    queries = {q.get("q"): q for q in rec.get("queries") or []}
    k = p.get("k")
    if k == "cell":
        q = queries.get(p.get("q"))
        src = f"  ({p['q']}: {q.get('text', '')[:120]})" if q else ""
        return [f"{pad}{p.get('table')} · {_key(p.get('key'))} · {p.get('path')} = {_short(p.get('value'))}{src}"]
    if k == "sel":
        return [f"{pad}{p.get('table')} WHERE {_where(p.get('where'))}  → {len(p.get('keys') or [])} rows"]
    if k == "absent":
        return [f"{pad}{p.get('table')} {_key(p.get('key'))}: row not found"]
    if k == "meaning":
        return [f"{pad}{p.get('table')}.{p.get('column')}: {p.get('text')}"]
    if k == "now":
        return [f"{pad}clock {p.get('value')}"]
    if k == "rule":
        run = (rec.get("runs") or {}).get(p.get("run")) or {}
        value = (run.get("outputs") or {}).get(p.get("out"))
        lines = [f"{pad}rule {run.get('rule')} v{run.get('version')} ({p.get('run')}): {p.get('out')} = {_short(value)}"]
        if not run.get("inputs"):
            return lines
        if p.get("run") in expanded:
            lines.append(f"{pad}    (inputs of {p.get('run')} listed above)")
        elif depth + 1 < _RULE_DEPTH:
            expanded.add(p.get("run"))
            seen = set()
            for i in run["inputs"]:
                ik = json.dumps(i, sort_keys=True, default=str)
                if ik not in seen:
                    seen.add(ik)
                    lines += pointer_lines(rec, i, depth + 1, expanded)
        else:
            lines.append(f"{pad}    … {len(run['inputs'])} inputs (deeper than {_RULE_DEPTH} levels; --format json has all)")
        return lines
    if k == "llm":
        return [f"{pad}model text by {p.get('by')} (a label, not evidence)"]
    return [f"{pad}{_short(p)}"]


def claim_lines(rec: dict, claim_id: str) -> list:
    claim = next(c for c in (rec.get("item") or {}).get("claims") or [] if c.get("id") == claim_id)
    lines = [f"[{claim.get('kind')}] {claim.get('q')}", f"  {plain(claim.get('spans'))}"]
    if claim.get("missing"):
        lines.append(f"  not recorded: {plain(claim.get('missing'))}")
    lines.append("")
    lines.append("Behind it:")
    expanded: set = set()
    for p in _pointers(claim):
        lines += pointer_lines(rec, p, 0, expanded)
    return lines


def _reason(r: dict) -> str:
    kind = r.get("kind")
    if kind == "value_changed":
        return f"{kind}: {r.get('table')} · {_key(r.get('key'))} · {r.get('path')}: {r.get('then')} → {r.get('now')}"
    if kind == "membership_changed":
        return (f"{kind}: {r.get('table')} WHERE {_where(r.get('where'))}: {r.get('then')} → {r.get('now')} rows"
                f" (added {r.get('added')}, removed {r.get('removed')})")
    if kind == "row_gone":
        return f"{kind}: {r.get('table')} {_key(r.get('key'))}"
    if kind == "rule_changed":
        return f"{kind}: {r.get('rule')} v{r.get('then')} → v{r.get('now')} (or its code changed)"
    if kind == "clock_moved":
        return f"{kind}: {r.get('then')} → {r.get('now')}"
    rest = {k: v for k, v in r.items() if k != "kind" and v is not None}
    return f"{kind}: {_short(rest)}" if rest else str(kind)


def diff_lines(d: dict) -> list:
    counts = ", ".join(f"{n} {o}" for o, n in sorted((d.get("counts") or {}).items()))
    lines = [f"{counts or 'no claims'}  (then {d.get('then')} · now {d.get('now')})"]
    if d.get("then_schema") != d.get("now_schema"):
        lines.append(f"schema {d.get('then_schema')} → {d.get('now_schema')}")
    for cid, r in (d.get("claims") or {}).items():
        if r.get("outcome") == "unchanged":
            continue
        lines += ["", f"[{r.get('outcome')}] {cid}", f"    then: {r.get('then')}", f"    now:  {r.get('now')}"]
        lines += [f"    {_reason(x)}" for x in r.get("reasons") or []]
    return lines


def replay_line(res: dict) -> list:
    lines = [f"reproduced: {'yes' if res.get('reproduced') else 'no'} "
             f"({res.get('runs_replayed')}/{res.get('runs_then')} runs)"]
    fw = res.get("framework_changed")
    if fw:
        lines.append(f"framework changed: {fw.get('then')} → {fw.get('now')} (record built by an older proof framework)")
    for r in res.get("rules_changed") or []:
        lines.append(f"rule changed: {r.get('rule')} v{r.get('then')} → v{r.get('now')}")
    if res.get("error"):
        lines.append(f"error: {res['error']}")
    elif not res.get("reproduced"):
        lines.append(f"rule outputs identical: {res.get('rule_outputs_identical')} · "
                     f"claims: {res.get('claim_outcomes')}")
    return lines


def echo(lines) -> None:
    click.echo("\n".join(lines))


def read_record(path: str) -> dict:
    """A saved proof record (the JSON `torana alert <ID> proof --save FILE` wrote)."""
    try:
        with open(path) as f:
            rec = json.load(f)
    except ValueError as e:
        raise click.UsageError(f"{path} is not JSON: {e}")
    if not isinstance(rec, dict) or not isinstance(rec.get("meta"), dict) or not isinstance(rec.get("item"), dict):
        raise click.UsageError(f"{path} is not a proof record (needs meta and item; save one with "
                               "`torana alert <ID> proof --save FILE`)")
    return rec


def save(path: str, obj: dict) -> None:
    with open(path, "w") as f:
        json.dump(obj, f, indent=1, ensure_ascii=False)
    click.echo(f"saved {path}", err=True)
