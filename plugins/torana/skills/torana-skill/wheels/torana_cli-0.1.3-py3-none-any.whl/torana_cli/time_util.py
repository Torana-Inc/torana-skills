"""Time formatting helpers for human-readable CLI output."""

import datetime
import re


def _parse_iso(ts):
    """Parse an ISO-8601 timestamp string to an aware UTC datetime, or None.

    Accepts values with or without a trailing 'Z' and with or without an explicit
    offset. Naive timestamps are assumed to be UTC (the scheduler stores UTC).
    """
    if not ts or not isinstance(ts, str):
        return None
    raw = ts.strip()
    if raw.endswith("Z"):
        raw = raw[:-1] + "+00:00"
    try:
        dt = datetime.datetime.fromisoformat(raw)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=datetime.timezone.utc)
    return dt.astimezone(datetime.timezone.utc)


_MONTHS = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")     # the FE and server form: "%b %-d, %Y"


def day_words(d) -> str:
    """A date in the FE and server form: "Oct 1, 2026" (Python "%b %-d, %Y"). The CLI's one form for a day."""
    return f"{_MONTHS[d.month - 1]} {d.day}, {d.year}"


def local_day(ts) -> str:
    """The reader's calendar day ("Oct 1, 2026") for a moment, or the day itself for a date-only value; '' when empty.

    A moment is converted to the local zone first: slicing a UTC timestamp shows the next day for an evening west of UTC
    (a closure at 18:00 PDT is 01:00 UTC the next day). Naive timestamps are UTC, as everywhere in this module."""
    if not ts:
        return ""
    s = str(ts).strip()
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", s):
        return day_words(datetime.date.fromisoformat(s))
    t = _parse_iso(s)
    if t is None:
        return s[:10]
    return day_words(t.astimezone())


def _humanize_delta(seconds):
    """Render a signed second-delta as a coarse human string.

    Positive => future ("in 2 hours"); negative => past ("3 days ago").
    Picks the single largest sensible unit.
    """
    future = seconds >= 0
    s = abs(int(seconds))
    if s < 60:
        phrase = "less than a minute"
    else:
        units = (
            ("day", 86400),
            ("hour", 3600),
            ("minute", 60),
        )
        for name, size in units:
            if s >= size:
                n = s // size
                phrase = f"{n} {name}{'s' if n != 1 else ''}"
                break
    return f"in {phrase}" if future else f"{phrase} ago"


def format_relative(ts, now=None):
    """Return a compact relative time like '3 days ago' / 'in 2 hours'.

    `ts` is an ISO-8601 string. Returns '—' when ts is missing/unparseable.
    Unlike format_next_run(), this omits the absolute timestamp — suited to a
    narrow list column (e.g. when an alert fired). `now` is injectable for
    testing; defaults to the current UTC time.
    """
    dt = _parse_iso(ts)
    if dt is None:
        return "—"
    if now is None:
        now = datetime.datetime.now(datetime.timezone.utc)
    return _humanize_delta((dt - now).total_seconds())


def format_next_run(ts, now=None):
    """Return a 'in 2 hours (2026-06-25 18:00 UTC)' style string for a timestamp.

    `ts` is an ISO-8601 string (the scheduler's `next_execution_at`). Returns
    '—' when ts is missing/unparseable. `now` is injectable for testing; defaults
    to the current UTC time.
    """
    dt = _parse_iso(ts)
    if dt is None:
        return "—"
    if now is None:
        now = datetime.datetime.now(datetime.timezone.utc)
    delta = (dt - now).total_seconds()
    exact = f"{day_words(dt)}, {dt.strftime('%H:%M')} UTC"
    return f"{_humanize_delta(delta)} ({exact})"
