"""The Inbox's words, as the platform serves them (DS4b § 3.4, E-20.9).

The platform holds ONE set of words for levels, deadline states, boxes, who decided, where a fix came from and why an item is closed. It serves
them as `*_label` fields on every row and as one export (`GET api/v2/alerts/labels`). This module reads them; it never words anything itself, so
the screen, the API and this CLI cannot drift apart.

⛔ A WORD IS NEVER WRITTEN HERE. When the platform sends no word (an older server, or the export could not be read) the helpers return the code
the platform sent, or "" when it sent none; they do not substitute a local phrase. A local fallback is a copy, and a copy is how "Set aside by
policy" and "Below policy" came to name the same thing.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Optional

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError

LABELS_PATH = "api/v2/alerts/labels"

def fetch_labels(client) -> Dict[str, Any]:
    """The served export, or {} when it cannot be read (the callers then print the row's own `*_label` fields, or the raw code).

    One read per command run: each command calls this once and passes the result on. Nothing is cached between runs or between clients."""
    try:
        data = client.get(LABELS_PATH)
    except (APIError, AuthError):
        return {}
    return data if isinstance(data, dict) else {}


def served(labels: Optional[Dict[str, Any]], group: str, code: Any) -> str:
    """The word the export gives `code` in `group`, or "" when it gives none."""
    table = (labels or {}).get(group)
    if isinstance(table, dict) and code is not None:
        return str(table.get(str(code)) or "")
    return ""


def level_caption(labels: Optional[Dict[str, Any]], fallback: str) -> str:
    """The list's level column header: the served `level_label` caption, else `fallback` (the column's own name)."""
    return str((labels or {}).get("level_label") or "").strip() or fallback


def sla_word(item: Dict[str, Any], labels: Optional[Dict[str, Any]] = None) -> str:
    """The deadline state's word. "" for an item with no deadline (state `none`) or none sent."""
    state = item.get("sla_state")
    if not state or state == "none":
        return ""
    return str(item.get("sla_state_label") or "") or served(labels, "sla_state", state) or str(state)


def box_word(item: Dict[str, Any], labels: Optional[Dict[str, Any]] = None) -> str:
    """The box's word ("Active", "Closed")."""
    box = item.get("box")
    return (str(item.get("box_label") or "") or served(labels, "box", box)
            or ("Active" if box in ("active", "needs_attention") else str(box) if box else ""))


def fix_source_word(item: Dict[str, Any], labels: Optional[Dict[str, Any]] = None) -> str:
    """Where the stored fix came from ("from the ranking"...); "" when the item has no fix source."""
    src = item.get("proposed_fix_source")
    if not src:
        return ""
    return str(item.get("proposed_fix_source_label") or "") or served(labels, "fix_source", src)


def decider_word(item: Dict[str, Any], labels: Optional[Dict[str, Any]] = None, name_cache: Optional[dict] = None) -> str:
    """Who decided the verdict, in the platform's word for the source; a person or an agent is NAMED when the name is known.

    The source is the platform's `verdict_source` (`rule`, `platform`, `agent`, `person`...). The name cache turns an agent or a person into
    the name the caller resolved; without one the source word stands."""
    if item.get("verdict_source_label"):
        word = str(item["verdict_source_label"])
    else:
        word = served(labels, "verdict_source", item.get("verdict_source"))
    kind = str(item.get("verdict_actor_type") or "").lower()
    who = item.get("verdict_actor_id") or ""
    if kind in ("agent", "user") and who:
        named = (name_cache or {}).get(("agent" if kind == "agent" else "user", who))
        if named:
            return str(named)
    return word


def handling_word(item: Dict[str, Any], labels: Optional[Dict[str, Any]] = None) -> str:
    """Who has the item now (`handling_state_label`); "" for a closed item."""
    state = item.get("handling_state")
    if not state:
        return ""
    return str(item.get("handling_state_label") or "") or served(labels, "handling_state", state) or str(state)


def close_groups(labels: Optional[Dict[str, Any]]) -> Dict[str, List[str]]:
    """{group: [closing reason, ...]} from the export, in the platform's order."""
    groups = (labels or {}).get("close_groups")
    return {str(g): [str(r) for r in rs] for g, rs in groups.items()} if isinstance(groups, dict) else {}


def expand_close_groups(values: Iterable[str], labels: Optional[Dict[str, Any]]) -> List[str]:
    """A value that names a close group becomes that group's reasons; every other value is kept as the person typed it."""
    groups = close_groups(labels)
    out: List[str] = []
    for v in values:
        for r in groups.get(v, [v]):
            if r not in out:
                out.append(r)
    return out


def person_close_reasons(labels: Optional[Dict[str, Any]]) -> List[str]:
    """The person's closing reason codes the platform offers."""
    rows = (labels or {}).get("person_close_reasons")
    return [str(r.get("code")) for r in rows if isinstance(r, dict) and r.get("code")] if isinstance(rows, list) else []


def repair_sentences(data: Any) -> List[str]:
    """The finished sentences a repair (`regroup`, `reconcile-owners`, `reconcile-sla`) returned in `sentences`; [] when it sent none."""
    s = data.get("sentences") if isinstance(data, dict) else None
    return [str(x) for x in s if x] if isinstance(s, list) else []


def not_yet_applied(labels: Optional[Dict[str, Any]], key: str) -> str:
    """The served note for a policy setting the platform records but does not yet act on; "" when it is applied or the export says nothing.

    Only the platform knows (`policy_application`, read from its own flag at request time), so this never decides it."""
    entry = ((labels or {}).get("policy_application") or {}).get(key)
    if isinstance(entry, dict) and entry.get("applied") is False:
        return str(entry.get("note") or "Not yet applied")
    return ""
