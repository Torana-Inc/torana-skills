"""torana atlas inquire · atlas inquiry … · atlas learning writebacks (pantheon-knowledge BLOCK_3A_INVESTIGATE.md
§ 3.4.3): investigate the build steps an `unknown` provenance verdict could not read, follow it, and see what it
wrote back. A model's reading is a BELIEF (`?`, unverified): it never changes a verdict, a priority or a finding.

The server writes every label, statement and refusal reason; this module prints them verbatim and derives none.
⚠️ File output is `--out`, never `-o` (the root group lifts `-o` as the global format flag)."""

import sys
import time

import click

from torana_cli.atlas import _call, _client, _fmt, _params, human_time, since_to_iso
from torana_cli.client.base import EXIT_RUN_FAILED
from torana_cli.output import output


def _repo_key(value: str) -> str:
    v = (value or "").strip()
    return v if v.startswith("repo:") else f"repo:{v}"


def _usd(v) -> str:
    return f"${float(v or 0):.2f}"


def _counts(d: dict | None, keys) -> str:
    d = d or {}
    return " · ".join(f"{k.replace('_', ' ')} {d.get(k, 0)}" for k in keys)


def refused_types_line(refused: dict | None) -> str:
    """6c D-G: the claim types a document may not state, counted per type (the run's `refused_types`)."""
    if not refused:
        return ""
    return "not readable from documents: " + ", ".join(f"{k} {v}" for k, v in sorted(refused.items()))


def slice_words(indices, total) -> str:
    """The run's slice. The server sends the LIST of section indices the run read (not always contiguous: it picks
    the unread ones) plus `sections_total`: [1, 2, 3, 5] of 6 → "sections 1–3, 5 of 6"."""
    if not isinstance(indices, (list, tuple)):
        return ""
    idx = sorted({i for i in indices if isinstance(i, int)})
    if not idx:
        return ""
    runs, start = [], idx[0]
    for prev, cur in zip(idx, idx[1:] + [None]):
        if cur != prev + 1:
            runs.append(str(start) if start == prev else f"{start}–{prev}")
            start = cur
    head = "section " if len(idx) == 1 else "sections "
    return head + ", ".join(runs) + (f" of {total}" if total else "")


def document_block(data: dict) -> list[str]:
    """6c § 4: a document read's lines (kind `document`): the version, the read state in the server's words, the
    slice, then every section with whether it was read and how many items it gave. "Read, 0 items" is read, not
    "not stated" (D-E)."""
    d = data.get("document") or {}
    out = [f"document «{d.get('name') or '?'}» @ {str(d.get('sha') or '?')[:12]}"]
    if d.get("words"):
        out.append("  " + " ".join(x for x in (d.get("glyph"), d["words"]) if x))
    s = d.get("summary") or {}
    if s:
        out.append(f"  sections: {s.get('read', 0)} of {s.get('total', 0)} read · {s.get('with_items', 0)} with items")
    sl = slice_words(d.get("slice"), d.get("sections_total"))
    if sl:
        out.append(f"  slice: {sl}")
    for sec in d.get("sections") or []:
        mark = f"✓ read · {sec.get('items', 0)} item(s)" if sec.get("read") else "○ not read"
        out.append(f"  § {sec.get('index')} {sec.get('title') or '(untitled)'} "
                   f"(lines {sec.get('start_line')}–{sec.get('end_line')}) · {mark}")
    line = refused_types_line(data.get("refused_types"))
    if line:
        out.append("  " + line)
    return out


def render_inquiry(data: dict, steps: bool = False) -> str:
    """One inquiry (GET /atlas/inquiries/{id}, or the POST's answer), the server's words verbatim."""
    head = f"inquiry {data.get('inquiry_id')}  {data.get('status')}"
    if data.get("failure_kind"):
        head += f"  ({data['failure_kind']})"
    if data.get("cached"):
        head += f"  · cached: {data['cached']} (the same gaps at the same commits; $0)"
    lines = [head]
    if data.get("kind") == "document":
        lines += document_block(data)
    ans = data.get("answer") or {}
    reserved = f" (reserved {_usd(data['reserved_usd'])})" if data.get("reserved_usd") is not None else ""
    if ans:
        lines.append(f"answer: {ans.get('label')} · {_usd(data.get('cost_usd'))}{reserved}")
    else:
        lines.append(f"cost: {_usd(data.get('cost_usd'))}{reserved}")
    g = data.get("gaps") or {}
    if g:
        lines.append("gaps: " + _counts(g, ("total", "answerable", "known", "sent", "closed", "not_known")))
    for s in ans.get("statements") or []:
        mark = "known" if s.get("known") else "? a model believes"
        lines.append(f"  {mark}: {s.get('words', '')}")
    for q in ans.get("questions") or []:
        what = f"{q.get('code')}: {q.get('words')}" if q.get("code") else (q.get("subject") or "")
        lines.append(f"  open: {what} — {'; '.join(q.get('missing') or [])}".rstrip(" —"))
    wb = data.get("writeback") or {}
    if wb:
        refused = ", ".join(f"{k} {v}" for k, v in sorted((wb.get("refused") or {}).items())) or "none"
        lines.append(f"write-back: {wb.get('status')} · " + _counts(
            wb, ("stored", "unchanged", "confirmed_known", "insights")) + f" · refused: {refused}")
        dc = wb.get("document_consent") or {}
        if dc.get("words"):                                    # 6c R4: push:document revoked mid-run, in its words
            lines.append(f"  {dc.get('glyph') or '⊘'} document consent: {dc['words']}")
        for c in wb.get("claims") or []:                       # § 4.10: open one with `torana atlas claims explain <id>`
            lines.append(f"  claim {c.get('id')}  {c.get('result')}  {c.get('claim_type')}  "
                         f"{str(c.get('subject') or '').removeprefix('repo:')}")
    if data.get("prompted_with") is not None:
        lines.append(f"prompted with: {len(data.get('prompted_with') or [])} Atlas claims")
    exp = data.get("export") or {}
    if exp.get("repos"):
        lines.append("export: " + "; ".join(f"{r.get('dir')}/ = {r.get('repository')} at {str(r.get('commit'))[:12]}"
                                            for r in exp["repos"]))
    for d in exp.get("dropped") or []:
        lines.append(f"  dropped {d.get('repository')}: {d.get('reason')}")
    if steps:
        for st in data.get("steps") or []:
            lines.append(f"  step {st.get('n')}: {st.get('recipe') or ''} {st.get('effect') or ''} "
                         f"{st.get('outcome') or ''} {st.get('ms', 0)} ms {_usd(st.get('usd'))}".replace("  ", " "))
    if data.get("status") == "running":
        lines.append(f"Follow it: torana atlas inquiry get {data.get('inquiry_id')} --wait")
    if data.get("trace_id"):
        lines.append(f"trace {data['trace_id']}")
    if data.get("transcript_ref"):                   # § 3.2.12: the trail's reference (the server sends it to SA only)
        lines.append(f"trail: {data['transcript_ref']}")
    return "\n".join(lines)


def _show(ctx, data, steps=False):
    fmt, _, _ = _fmt(ctx)
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt)
        return
    click.echo(render_inquiry(data, steps=steps))


def wait_for_inquiry(ctx, client, inquiry_id: str, tenant, poll: float, timeout: float, steps: bool = False):
    """Poll GET until the inquiry leaves `running`: status on STDERR, the inquiry on stdout. Exit 0 complete, 8
    failed, cancelled or timed out. Ctrl-C stops watching, not the inquiry."""
    deadline, last, body = time.monotonic() + timeout, None, None
    try:
        while True:
            body = _call(client.get, f"atlas/inquiries/{inquiry_id}", params=_params(tenant=tenant) or None)
            if body.get("status") != last:
                last = body.get("status")
                click.echo(f"inquiry {inquiry_id}: {last}", err=True)
            if body.get("status") != "running":
                break
            if time.monotonic() >= deadline:
                click.echo(f"inquiry {inquiry_id} still running after {int(timeout)}s; stopped waiting "
                           f"(torana atlas inquiry get {inquiry_id})", err=True)
                _show(ctx, body, steps)
                sys.exit(EXIT_RUN_FAILED)
            time.sleep(poll)
    except KeyboardInterrupt:
        click.echo(f"\nstopped watching; the inquiry continues (torana atlas inquiry get {inquiry_id})", err=True)
        sys.exit(130)
    _show(ctx, body, steps)
    if body.get("status") != "complete":
        sys.exit(EXIT_RUN_FAILED)


def _wait_options(f):
    f = click.option("--wait-timeout", type=click.FloatRange(min=1), default=900.0, show_default=True,
                     help="With --wait: stop waiting after this many seconds (exit 8; the inquiry continues).")(f)
    f = click.option("--poll", type=click.FloatRange(min=1), default=5.0, show_default=True,
                     help="With --wait: seconds between status checks.")(f)
    return click.option("--wait", is_flag=True, default=False,
                        help="Follow it until it finishes: status on stderr, the inquiry on stdout; exit 0 complete, "
                             "8 failed, cancelled or timed out.")(f)


def provenance_options(repository, package, *, file_path=None, fixed_version=None, vulnerable_range=None,
                       ecosystem="pypi", commit=None) -> dict:
    if bool(fixed_version) == bool(vulnerable_range):
        raise click.UsageError("give the advisory as --fixed VERSION or --range SPEC (exactly one)")
    body = {"repository": _repo_key(repository), "package": package, "ecosystem": ecosystem}
    body.update({k: v for k, v in (("file", file_path), ("fixed_version", fixed_version),
                                   ("vulnerable_range", vulnerable_range), ("commit", commit)) if v})
    return body


# ── torana atlas inquire ──────────────────────────────────────────────────────

@click.command(name="inquire")
@click.option("--repo", "repository", required=True, help="The repository the verdict is about (repo:… or host/org/repo).")
@click.option("--package", required=True, help="The package the verdict is about.")
@click.option("--range", "vulnerable_range", default=None, metavar="SPEC", help="The advisory's range, e.g. '<24.3.0'.")
@click.option("--fixed", "fixed_version", default=None, metavar="VERSION", help="Or the advisory's fixed version.")
@click.option("--file", "file_path", default=None, metavar="PATH", help="The manifest the scanner reported.")
@click.option("--commit", default=None, metavar="SHA", help="The commit the finding was scanned at.")
@click.option("--ecosystem", default="pypi", show_default=True)
@click.option("--max-usd", type=click.FloatRange(min=0.01), default=None,
              help="Spend at most this much (clamped to the platform's per-inquiry bound).")
@click.option("--timeout", "timeout_s", type=click.IntRange(min=1), default=None, help="Seconds the session may run.")
@click.option("--tenant", default=None, help="Another tenant (SA only).")
@_wait_options
@click.pass_context
def atlas_inquire(ctx, repository, package, vulnerable_range, fixed_version, file_path, commit, ecosystem, max_usd,
                  timeout_s, tenant, wait, poll, wait_timeout):
    """Investigate the build steps an `unknown` provenance verdict could not read (a model reads the code; paid).

    Atlas first answers what its store already knows ($0), refuses a repository without model consent, and never
    pays twice for the same gaps at the same commits: a second request gets the first one (`cached`). The answer is
    labelled known · looked_up · not_known; what the model concluded is stored as `?` beliefs (unverified) that
    `torana atlas provenance … --beliefs` prints beside each missing link. The verdict itself never changes.

    \b
    Examples:
      torana atlas inquire --repo github.com/acme/api --package black --fixed 24.3.0 --wait
      torana atlas inquire --repo repo:github.com/acme/api --package requests --range '<2.32.0' --max-usd 0.3
    """
    body = {"persona": "developer",
            "options": provenance_options(repository, package, file_path=file_path, fixed_version=fixed_version,
                                          vulnerable_range=vulnerable_range, ecosystem=ecosystem, commit=commit)}
    budget = {k: v for k, v in (("max_usd", max_usd), ("timeout_s", timeout_s)) if v is not None}
    if budget:
        body["budget"] = budget
    client = _client(ctx)
    data = _call(client.post, "atlas/inquiries", json=body, params=_params(tenant=tenant) or None)
    if wait and isinstance(data, dict) and data.get("status") == "running":
        wait_for_inquiry(ctx, client, data["inquiry_id"], tenant, poll, wait_timeout)
        return
    _show(ctx, data)


# ── torana atlas inquiry … ────────────────────────────────────────────────────

@click.group(name="inquiry")
def atlas_inquiry():
    """Inquiries: get, list, cancel; the investigation cache (leases, SA)."""


@atlas_inquiry.command(name="get")
@click.argument("inquiry_id")
@click.option("--steps", is_flag=True, default=False, help="Also print every step with its time and cost.")
@click.option("--tenant", default=None, help="Another tenant's inquiry (SA only).")
@_wait_options
@click.pass_context
def inquiry_get(ctx, inquiry_id, steps, tenant, wait, poll, wait_timeout):
    """One inquiry: status, cost, the labelled answer, the write-back counts, the export and what it was shown.
    INQUIRY_ID may be a unique prefix of 8+ hex characters."""
    client = _client(ctx)
    if wait:
        wait_for_inquiry(ctx, client, inquiry_id, tenant, poll, wait_timeout, steps)
        return
    _show(ctx, _call(client.get, f"atlas/inquiries/{inquiry_id}", params=_params(tenant=tenant) or None), steps)


def render_list(data: dict) -> str:
    items = data.get("items") or []
    lines = [f"{data.get('total', len(items))} inquiries (page {data.get('page', 1)})"]
    for i in items:
        wb = i.get("writeback") or {}
        lines.append(f"{i.get('inquiry_id')}  {i.get('status'):<9} {str(i.get('label') or '-'):<10} "
                     f"{_usd(i.get('cost_usd'))}  {human_time(i.get('created_at'))}  {i.get('subject')} "
                     f"{i.get('package') or ''}" + (f"  write-back {wb.get('status')}" if wb.get("status") else "")
                     + ("  (auto)" if i.get("auto") else "") + (f"  tenant {i['tenant_id']}" if data.get("_all") else ""))
    return "\n".join(lines)


@atlas_inquiry.command(name="list")
@click.option("--status", type=click.Choice(["running", "complete", "failed", "cancelled"]), default=None)
@click.option("--subject", default=None, help="Only inquiries about this repository (repo:…).")
@click.option("--limit", type=click.IntRange(1, 100), default=50, show_default=True)
@click.option("--page", type=click.IntRange(min=1), default=1, show_default=True)
@click.option("--tenant", default=None, help="Another tenant (SA only).")
@click.option("--all", "all_", is_flag=True, default=False, help="Every tenant (SA only).")
@click.pass_context
def inquiry_list(ctx, status, subject, limit, page, tenant, all_):
    """The tenant's inquiries, newest first."""
    subject = _repo_key(subject) if subject else None
    data = _call(_client(ctx).get, "atlas/inquiries", params=_params(status=status, subject=subject, limit=limit,
                                                                     page=page, tenant=tenant, all=all_ and "true"))
    fmt, _, _ = _fmt(ctx)
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt)
        return
    click.echo(render_list({**data, "_all": all_}))


@atlas_inquiry.command(name="cancel")
@click.argument("inquiry_id")
@click.option("--tenant", default=None, help="Another tenant's inquiry (SA only).")
@click.pass_context
def inquiry_cancel(ctx, inquiry_id, tenant):
    """Stop a running inquiry (yours, or any with atlas:write); its lease is released for a retry. INQUIRY_ID may
    be a unique prefix of 8+ hex characters."""
    _show(ctx, _call(_client(ctx).post, f"atlas/inquiries/{inquiry_id}/cancel", params=_params(tenant=tenant) or None))


def render_leases(data: dict) -> str:
    items = data.get("items") or []
    lines = [f"{data.get('total', len(items))} leases"]
    for le in items:
        # § 3.2.12: the server sends transcript_ref to a bootstrap SA only; say whether it is kept, never the ref
        trail = ("  trail " + ("kept" if le.get("transcript_ref") else "none")) if "transcript_ref" in le else ""
        lines.append(f"{le.get('id')}  {le.get('status'):<9} tenant {le.get('tenant_id')}  holder {le.get('holder')}  "
                     f"{human_time(le.get('updated_at'))}{trail}")
        for g in le.get("gaps") or []:
            lines.append(f"    gap {g.get('code')} {str(g.get('repository') or '').removeprefix('repo:')} "
                         f"{g.get('dockerfile')}:{g.get('line')}")
        lines.append("    at " + "; ".join(f"{str(c.get('repository') or '').removeprefix('repo:')} "
                                         f"{str(c.get('commit'))[:12]}" for c in le.get("commits") or []))
    return "\n".join(lines)


@atlas_inquiry.command(name="leases")
@click.option("--tenant", default=None, help="One tenant (default: every tenant).")
@click.option("--status", type=click.Choice(["running", "complete", "failed", "cancelled"]), default=None)
@click.option("--limit", type=click.IntRange(1, 100), default=50, show_default=True)
@click.option("--page", type=click.IntRange(min=1), default=1, show_default=True)
@click.pass_context
def inquiry_leases(ctx, tenant, status, limit, page):
    """The investigation cache (SA): which gaps at which commits were investigated, by which inquiry."""
    data = _call(_client(ctx).get, "atlas/inquiries/leases",
                 params=_params(tenant=tenant, status=status, limit=limit, page=page))
    fmt, _, _ = _fmt(ctx)
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt)
        return
    click.echo(render_leases(data))


@atlas_inquiry.command(name="lease-release")
@click.argument("lease_id")
@click.pass_context
def inquiry_lease_release(ctx, lease_id):
    """Release a lease (SA): the next request for the same gaps investigates again (paid). Refused while running."""
    data = _call(_client(ctx).delete, f"atlas/inquiries/leases/{lease_id}")
    fmt, _, _ = _fmt(ctx)
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt)
        return
    click.echo(f"lease {data.get('id')} released by {data.get('released_by')} at {human_time(data.get('released_at'))};"
               " the next request for its gaps investigates again")


# ── torana atlas learning writebacks ──────────────────────────────────────────

def render_writebacks(data: dict) -> str:
    t = data.get("totals") or {}
    keys = ("items", "stored", "unchanged", "confirmed_known", "insights", "refused")
    lines = [f"{data.get('total', 0)} write-backs · " + _counts(t, keys)]
    if t.get("refused_by_reason"):
        lines.append("  refused by reason: " + ", ".join(f"{k} {v}" for k, v in t["refused_by_reason"].items()))
    for i in data.get("items") or []:
        lines.append(f"{human_time(i.get('at'))}  {i.get('session_kind')} {i.get('session_id')}  {i.get('outcome')}  "
                     + _counts(i.get("counts"), keys))
        if i.get("refused_by_reason"):
            lines.append("    refused: " + ", ".join(f"{k} {v}" for k, v in sorted(i["refused_by_reason"].items())))
        for s in (i.get("refusal_samples") or [])[:5]:
            lines.append(f"    sample: {s}")
    return "\n".join(lines)


@click.command(name="writebacks")
@click.option("--kind", "session_kind", type=click.Choice(["inquiry", "ask", "triage", "agent", "statement"]), default=None)
@click.option("--since", default=None, help="24h, 7d, 30m or an ISO time.")
@click.option("--limit", type=click.IntRange(1, 100), default=50, show_default=True)
@click.option("--page", type=click.IntRange(min=1), default=1, show_default=True)
@click.option("--tenant", default=None, help="Another tenant (SA only).")
@click.option("--all", "all_", is_flag=True, default=False, help="Every tenant (SA only).")
@click.pass_context
def learning_writebacks(ctx, session_kind, since, limit, page, tenant, all_):
    """What sessions wrote back to the store: stored · unchanged · confirmed known · insights · refused by reason."""
    data = _call(_client(ctx).get, "atlas/learning/writebacks",
                 params=_params(session_kind=session_kind, since=since_to_iso(since), limit=limit, page=page,
                                tenant=tenant, all=all_ and "true"))
    fmt, _, _ = _fmt(ctx)
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt)
        return
    click.echo(render_writebacks(data))


@click.command(name="rebuild-coverage")
@click.option("--tenant", required=True, help="The tenant whose coverage rows to rebuild (SA; also the global act-as).")
@click.option("--state-dir", "state_dir", required=True, type=click.Path(exists=True, file_okay=False),
              help="A copy of agent-builder's /tmp/atlas-sessions (one <session_id>.json per session).")
@click.option("--apply", is_flag=True, default=False, help="Write the rows (default: a dry run that writes nothing).")
@click.pass_context
def learning_rebuild_coverage(ctx, tenant, state_dir, apply):
    """SA, model-free: rebuild the § 3.2.12 coverage rows the old orphan prune deleted, from the sessions' own
    answers. Only rows whose recomputed key a sighting names are written; everything else is reported.

    \b
    Example:
      torana --act-as-tenant T --act-as-reason "rebuild coverage" atlas learning rebuild-coverage \\
        --tenant T --state-dir ~/Downloads/…/atlas-sessions            # dry run; add --apply to write
    """
    import json
    from pathlib import Path
    sessions = []
    for f in sorted(Path(state_dir).glob("*.json")):
        try:
            d = json.loads(f.read_text())
        except (OSError, ValueError):
            continue
        so = (d.get("result") or {}).get("structured_output")
        if d.get("tenant_id") == tenant and isinstance(so, dict):
            sessions.append({"session_id": f.stem, "structured_output": so})
    if not sessions:
        raise click.UsageError(f"no session of tenant {tenant} with a structured_output in {state_dir}")
    data = _call(_client(ctx).post, "atlas/learning/coverage/rebuild", params=_params(tenant=tenant),
                 json={"sessions": sessions, "dry_run": not apply})
    fmt, _, _ = _fmt(ctx)
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt)
        return
    lines = [("DRY RUN (nothing written; add --apply)" if data.get("dry_run") else "APPLIED")
             + f" · {len(sessions)} sessions · " + _counts(data.get("counts"), tuple(data.get("counts") or {}))]
    for x in data.get("sessions") or []:
        if x.get("status") != "replayed":
            lines.append(f"  session {x.get('session_id')}: {x.get('status')}")
    for k in data.get("keys") or []:
        lines.append(f"  {k.get('status')}  {str(k.get('repository') or '').removeprefix('repo:')} {k.get('file')} "
                     f"L{k.get('start')}–{k.get('end')} @{str(k.get('version') or '')[:12]}  {str(k.get('evidence_key') or '-')[:12]}")
    lines.append(f"not found (no session reproduced it): {len(data.get('not_found') or [])}")
    click.echo("\n".join(lines))


# ── torana atlas provenance … --beliefs ───────────────────────────────────────

def conviction_line(conviction) -> str:
    """A belief's served conviction words (`{state, glyph, words}`) as `glyph words`; empty when the server sent none."""
    cw = (conviction or {}).get("words") if isinstance(conviction, dict) else None
    if not isinstance(cw, dict) or not cw.get("words"):
        return ""
    return f"{cw.get('glyph') or '?'} {cw['words']}"


def belief_lines(beliefs: dict, inquire_cmd: str) -> list[str]:
    """Under the verdict: each missing link a model has a belief about, and how to investigate when Atlas may."""
    out = []
    held = [g for g in beliefs.get("gaps") or [] if g.get("belief")]
    if held:
        out.append("Beliefs (a model's reading, unverified; the verdict does not change):")
        for g in held:
            out.append(f"  ○ {g.get('code')}: {g.get('words', '')}")
            basis = (g["belief"].get("basis") or {}).get("reason") or ""
            first = basis.split(". ", 1)[0].rstrip(".") if basis else ""
            out.append(f"    ? a model believes: {g['belief'].get('words', '')} (unverified)"
                       + (f" · basis: {first}" if first else ""))
            cw = conviction_line(g["belief"].get("conviction"))
            if cw:                                  # 7a § 3.4.5 row 3: R2's count, the server's words verbatim
                out.append(f"      {cw}")
    asked = [g for g in beliefs.get("gaps") or [] if g.get("asked") and not g.get("belief")]
    if asked:                                       # F55: the server's words; already asked, so not asked again
        out.append("Already asked (no claim; the verdict does not change):")
        for g in asked:
            out.append(f"  ○ {g.get('code')}: {g.get('words', '')}")
            out.append(f"    asked: {g['asked']}")
    inq = beliefs.get("inquiry") or {}
    if inq.get("lease") == "running":
        out.append(f"Investigating: torana atlas inquiry get {inq.get('inquiry_id')} --wait")
    elif inq.get("available"):
        cost = f" ({inq['cost_words']})" if inq.get("cost_words") else ""       # the server's words: a cap
        out.append(f"Investigate{cost}: {inquire_cmd}")
    return out
