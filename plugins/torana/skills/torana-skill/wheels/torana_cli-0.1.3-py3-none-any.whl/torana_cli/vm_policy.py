"""torana vm policy — VM domain vocabulary, policy extraction & binding (Spec C).

Attaches the ``policy`` subgroup onto the shared ``torana vm`` parent via
``register_vm_subgroup`` (see vm.py) — this module never re-defines ``vm``, so
Specs A/B/C can be built in parallel without colliding.

Three-surface parity (R8): every capability here exists on the API and on the FE
Policy Coverage view. Extraction included — it is a first-class capability, not a
CLI-only operation.

Spec: pantheon-program-framework/docs/VM/03_SpecC_Domain_Vocabulary_and_Policy_Binding.md § 3.4.2
"""

import contextlib
import json

import click

from torana_cli import served_words as sw
from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.vm import register_vm_subgroup

# The policy domain slug — MUST match `DEFAULT_DOMAIN` in
# pantheon-agent-builder/src/services/vm_policy/extraction_target.py and the property
# registry's `domain` field (pantheon-shared/.../domain_properties/vm.py).
#
# Spec H § 3.13.4d renamed this `vulnerability_management` -> `exposure_management`. The BE
# rename landed; BOTH consumer surfaces (CLI + FE) kept sending the old slug and 400'd with
# "Unknown policy domain". One constant, so the next rename is one edit per surface.
#
# NOT the same string as the WORKSPACE TYPE `vulnerability_management` (workspaces.py,
# admin.py) — a different namespace, still correct. Do not bulk-rename.
POLICY_DOMAIN = "exposure_management"

_BASE = "vm/policy"

_COVERAGE_COLS = [
    ("key", "KEY", 32),
    ("category", "CATEGORY", 16),
    ("status", "STATUS", 12),
    ("value", "VALUE", 28),
    ("security_critical", "SEC-CRIT", 9),
    ("ratification_state", "RATIFY", 13),
    ("ratified_by", "RATIFIED-BY", 13),
]

_CATEGORY_COLS = [
    ("label", "CATEGORY", 24),
    ("vars", "VARS", 5),
    ("resolved", "RESOLVED", 9),
    ("defaulted", "DEFAULTED", 10),
    ("conflicted", "CONFLICTED", 11),
    ("department", "DEPARTMENT", 24),
    ("owner_role", "OWNER", 28),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@contextlib.contextmanager
def _as_tenant(ctx, tenant_id):
    """Yield a client acting as `tenant_id`, or the caller's own client when it is None.

    ⭐ SUPER-ADMIN writes to ANOTHER tenant's policy go through IMPERSONATION, the
    platform's audited cross-tenant path — the write routes themselves stay tenant-scoped
    from the token and grow no `?tenant=` override. Mint → act → exit, and the exit runs
    even when the action fails, so a failed `set` never leaves an impersonation open.
    """
    if not tenant_id:
        yield _client(ctx)
        return
    sa = _client(ctx)
    minted = sa.post("admin/impersonate", json={"tenant_id": tenant_id})
    token = (minted or {}).get("access_token")
    if not token:
        raise click.ClickException(
            f"impersonation of tenant {tenant_id} returned no access_token — "
            f"--tenant-id needs a super-admin profile (TORANA_PROFILE=SA)")
    as_tenant = ToranaClient(base_url=sa._base_url, access_token=token)
    try:
        yield as_tenant
    finally:
        try:
            as_tenant.post("admin/exit-impersonation", json={})
        except Exception as exc:  # noqa: BLE001 — report, never mask the action's own result
            click.echo(f"WARNING: could not exit the impersonation of {tenant_id}: {exc}",
                       err=True)


def _fmt(ctx) -> str:
    return ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"


def _parse_value(raw: str):
    """Parse a --value argument as JSON, falling back to a bare string.

    Lets the user pass typed values naturally:
      --value Medium          -> "Medium"   (string)
      --value 0.5             -> 0.5        (number)
      --value true            -> True       (bool)
      --value '["a","b"]'     -> list
      --value '{"Critical":7}'-> dict
    A bare word like ``Medium`` is not valid JSON, so it falls through to a
    string rather than erroring — which is what a user typing an enum expects.
    """
    try:
        return json.loads(raw)
    except (ValueError, TypeError):
        return raw


@click.group(name="policy")
def policy():
    """VM policy — extract from documents, review coverage, resolve conflicts, bind values.

    \b
    Typical flow:
      torana vm policy extract --document <id>     # read a policy document
      torana vm policy coverage                    # what resolved vs defaulted
      torana vm policy conflicts                   # where sources disagree
      torana vm policy resolve <key> --candidate <id>   # adjudicate
      torana vm policy ratify <key>                # approve a security-critical value
      torana vm policy conformance                 # would an install be blocked?
    """


# ---------------------------------------------------------------------------
# extract
# ---------------------------------------------------------------------------

@policy.command(name="extract")
@click.option("--document", "document_id", default=None,
              help="Policy document ID to extract from. Mutually exclusive with --collection.")
@click.option("--collection", "collection_name", default=None,
              help="Extract from EVERY policy document in this RAG collection "
                   "(by name, e.g. organization_policies). Mutually exclusive with --document.")
@click.option("--document-type", "document_type", default="policy", show_default=True,
              help="With --collection, only documents of this type. Pass '' for all types.")
@click.option("--dry-run", is_flag=True,
              help="With --collection, list the documents that would be extracted and exit.")
@click.option(
    "--layer", "precedence_layer", default="org",
    type=click.Choice(["org", "team", "personal"]),
    help="Policy layer this document represents. A lower layer may TIGHTEN a "
         "security-critical floor but never loosen it.",
)
@click.option("--domain", default=POLICY_DOMAIN, show_default=True,
              help="Extractor/domain filter. Only 'exposure_management' today.")
@click.pass_context
def policy_extract(ctx, document_id, collection_name, document_type, dry_run,
                   precedence_layer, domain):
    """Extract policy values from a document — or a whole COLLECTION — into the vocabulary.

    Idempotent per document: if a run is already in flight, its extraction_run_id
    is returned rather than starting a second run. That is what makes --collection safe
    to re-run after a partial failure.

    \b
    Onboarding a corpus exported from a GRC tool is three commands, no scripting:
      torana rag upload policy-packet.zip --collection organization_policies \\
        --document-type policy
      torana vm policy extract --collection organization_policies --layer org
      torana vm policy coverage
    """
    client = _client(ctx)

    if bool(document_id) == bool(collection_name):
        raise click.ClickException(
            "Pass exactly one of --document (a single document) or --collection "
            "(every policy document in that collection)."
        )

    # ── Batch: one client-side loop over the per-document call ──────────────
    # ⛔ There is NO bulk extract endpoint server-side, so this is a loop — and it uses
    # the platform's shared run_bulk so partial failure is VISIBLE and the exit code is
    # honest. A loop that stopped at the first error would leave a half-extracted corpus
    # with no record of which half; one that swallowed errors would report success for
    # documents that never extracted. See torana_cli/bulk.py.
    if collection_name:
        # Local imports: rag imports main, main registers vm_policy — a module-level
        # import here would close that cycle.
        from torana_cli.bulk import run_bulk
        from torana_cli.rag import list_documents_in_collection, resolve_collection_id

        try:
            cid = resolve_collection_id(client, collection_name)
        except APIError as e:
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return

        if not cid:
            raise click.ClickException(
                f"No collection named {collection_name!r}. "
                f"List them with: torana rag collections list"
            )

        try:
            docs = list_documents_in_collection(
                client, cid, document_type=(document_type or None))
        except APIError as e:
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return

        ids = [d["id"] for d in docs if d.get("id")]
        if not ids:
            type_note = f" of type {document_type!r}" if document_type else ""
            click.echo(f"No documents{type_note} in collection {collection_name!r} — "
                       f"nothing to extract.")
            return

        titles = {d["id"]: d.get("title", d["id"]) for d in docs if d.get("id")}
        if dry_run:
            click.echo(f"DRY RUN — would extract from {len(ids)} document(s) in "
                       f"{collection_name!r} at layer {precedence_layer!r}:")
            for i in ids:
                click.echo(f"  {titles[i]}  ({i})")
            return

        def _extract(doc_id):
            client.post(
                f"{_BASE}/extract",
                json={"document_id": doc_id, "precedence_layer": precedence_layer,
                      "domain": domain},
            )

        click.echo(f"Extracting from {len(ids)} document(s) in {collection_name!r} "
                   f"at layer {precedence_layer!r}...")
        run_bulk(ctx, ids, _extract, label="extract")
        click.echo("\nReview what bound with: torana vm policy coverage")
        return

    try:
        data = client.post(
            f"{_BASE}/extract",
            json={"document_id": document_id, "precedence_layer": precedence_layer, "domain": domain},
        )
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if fmt == "text":
        click.echo(f"Extraction run: {data.get('extraction_run_id')}")
        click.echo(f"Status        : {data.get('status')}")
        click.echo(f"Candidates    : {data.get('candidates_emitted', 0)}")
        if data.get("already_running"):
            click.echo("Note          : a run was already in flight for this document; "
                       "returned that run instead of starting a second one.")
        for err in data.get("errors") or []:
            click.echo(f"Error         : {err}")
        return
    output(data, fmt=fmt)


# ---------------------------------------------------------------------------
# coverage
# ---------------------------------------------------------------------------

@policy.command(name="runs")
@click.option("--status", "status_filter", default=None,
              type=click.Choice(["queued", "running", "succeeded", "failed"]),
              help="Filter by run status.")
@click.option("--document", "document_id", default=None, help="Filter to one document.")
@click.option("--all-tenants", is_flag=True,
              help="SUPER-ADMIN ONLY: runs across every tenant (operational diagnostics).")
@click.option("--limit", default=100, show_default=True, help="Max runs (max 100).")
@click.pass_context
def policy_runs(ctx, status_filter, document_id, all_tenants, limit):
    """List extraction runs — when they ran, what they produced, what they cost.

    Each run carries a trace_id: the SAME id appears on the run row, on every log
    line the run emitted, and on its trace — so it can be looked up directly in
    Loki (`{trace_id="..."}`) or Jaeger.

    --all-tenants shows run METADATA across tenants for operators; the quoted
    policy text is never included there (it stays with its tenant).
    """
    client = _client(ctx)
    params = {"limit": limit, "all_tenants": all_tenants}
    if status_filter:
        params["status"] = status_filter
    if document_id:
        params["document_id"] = document_id
    try:
        data = client.get(f"{_BASE}/extraction-runs", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if fmt != "text":
        output(data, fmt=fmt)
        return

    runs = data.get("runs", [])
    if not runs:
        click.echo("No extraction runs.")
        return

    rows = []
    for r in runs:
        cost = r.get("estimated_cost_usd")
        dur = r.get("duration_seconds")
        rows.append({
            "run": (r.get("extraction_run_id") or "")[:8],
            "tenant": (r.get("tenant_id") or "")[:8],
            "status": r.get("status"),
            "document": (r.get("document_id") or "")[:8],
            "emitted": r.get("candidates_emitted") if r.get("candidates_emitted") is not None else "-",
            "duration": f"{dur:.1f}s" if dur is not None else "-",
            "cost": f"${cost:.4f}" if cost is not None else "-",
            "trace_id": r.get("trace_id") or "-",
        })

    cols = [("run", "RUN", 10), ("status", "STATUS", 10), ("document", "DOC", 10),
            ("emitted", "EMITTED", 8), ("duration", "TIME", 8), ("cost", "COST", 10),
            ("trace_id", "TRACE_ID", 34)]
    if data.get("cross_tenant"):
        cols.insert(1, ("tenant", "TENANT", 10))

    output({"items": rows, "total": data.get("total", len(rows))}, fmt="text", columns=cols)


@policy.command(name="run")
@click.argument("extraction_run_id", metavar="RUN_ID")
@click.pass_context
def policy_run_detail(ctx, extraction_run_id):
    """Show one extraction run and the values it produced.

    Prints the trace_id with ready-to-run log and trace lookups.
    """
    client = _client(ctx)
    try:
        data = client.get(f"{_BASE}/extraction-runs/{extraction_run_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if fmt != "text":
        output(data, fmt=fmt)
        return

    r = data.get("run", {})
    click.echo(f"run          : {r.get('extraction_run_id')}")
    click.echo(f"document     : {r.get('document_id')}")
    click.echo(f"status       : {r.get('status')}")
    if r.get("triggered_by"):
        click.echo(f"triggered by : {r['triggered_by']}")
    if r.get("duration_seconds") is not None:
        click.echo(f"duration     : {r['duration_seconds']:.1f}s")
    if r.get("model"):
        click.echo(f"model        : {r['model']}")
    if r.get("input_tokens") is not None or r.get("output_tokens") is not None:
        click.echo(f"tokens       : in={r.get('input_tokens')} out={r.get('output_tokens')}")
    if r.get("estimated_cost_usd") is not None:
        click.echo(f"cost         : ${r['estimated_cost_usd']:.6f}")
    if r.get("budget_exceeded"):
        click.echo("note         : budget reached — this run recorded a PARTIAL result.")
    if r.get("error"):
        click.echo(f"error        : {r['error']}")

    if r.get("trace_id"):
        # The SAME id is on this row, on every log line the run emitted, and on
        # its span — so these two lookups both resolve. (Verified: the row's
        # trace_id retrieves that run's Loki streams.)
        click.echo(f"\ntrace_id     : {r['trace_id']}")
        click.echo(
            "  logs  : python3 $TORANA_ROOT/pantheon-deploy/scripts/query_loki.py "
            f"1h -g {r['trace_id']} --all-levels"
        )
        click.echo(f"  trace : http://localhost:16686/trace/{r['trace_id']}")

    cands = data.get("candidates", [])
    click.echo(f"\nvalues produced ({len(cands)}):")
    for c in cands:
        loc = c.get("locator") or {}
        mark = " (superseded)" if c.get("superseded") else ""
        click.echo(f"  {c.get('vocabulary_key'):32} = {json.dumps(c.get('value'))}{mark}")
        click.echo(f"      doc {str(c.get('document_id',''))[:8]} line {loc.get('line','?')}")


@policy.command(name="coverage")
@click.option("--category", default=None, help="Filter to one category.")
@click.option("--limit", default=100, show_default=True, help="Max variables to return (max 100).")
@click.option("--offset", default=0, show_default=True, help="Pagination offset.")
@click.pass_context
def policy_coverage(ctx, category, limit, offset):
    """Show the policy coverage report, by category.

    Reports which variables were resolved FROM YOUR POLICY and which fell back to
    a conservative platform default — never a single blunt percentage, which
    would penalise a lean-but-correct policy.
    """
    client = _client(ctx)
    params = {"limit": limit, "offset": offset}
    if category:
        params["category"] = category
    try:
        data = client.get(f"{_BASE}/coverage", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if fmt != "text":
        output(data, fmt=fmt, raw=ctx.obj.get(CTX_RAW, False) if ctx.obj else False,
               fields=ctx.obj.get(CTX_FIELDS) if ctx.obj else None)
        return

    click.echo("BY CATEGORY")
    cat_rows = []
    for c in data.get("categories", []):
        cat_rows.append({
            "label": c.get("label") or c.get("category"),
            "resolved": c.get("resolved", 0),
            "defaulted": c.get("defaulted", 0),
            "conflicted": c.get("conflicted", 0),
            "vars": c.get("variable_count", 0),
            "department": c.get("department") or "-",
            "owner_role": c.get("owner_role") or "-",
        })
    output({"items": cat_rows}, fmt="text", columns=_CATEGORY_COLS)
    click.echo("")
    click.echo("Each category has an OWNER — that is who an unresolved variable "
               "in it should be routed to.")
    click.echo("")
    click.echo("BY VARIABLE")
    rows = []
    for v in data.get("variables", []):
        # Short-form the ratifier id: accountability at a glance, full id via
        # `torana vm policy show <key>`. Blank for the unratified majority.
        rb = v.get("ratified_by") or ""
        rows.append({
            **v,
            "value": json.dumps(v.get("value")),
            "security_critical": "yes" if v.get("security_critical") else "",
            "ratified_by": (rb[:8] if rb else ""),
        })
    output({"items": rows, "total": data.get("total", len(rows))}, fmt="text", columns=_COVERAGE_COLS)

    # Retired keys that still have live rows for this tenant — cleanup outstanding.
    retired = data.get("retired") or []
    if retired:
        click.echo("")
        click.echo(f"RETIRED KEYS WITH LIVE ROWS ({len(retired)}) — run "
                   "`torana vm policy retire <key>` to clean up:")
        for r in retired:
            mark = " (was RATIFIED)" if r.get("ratified") else ""
            click.echo(f"  {r.get('key')}  {r.get('live_bindings', 0)} binding(s){mark}")
            if r.get("deprecated_reason"):
                click.echo(f"      {r['deprecated_reason']}")


# ---------------------------------------------------------------------------
# conflicts
# ---------------------------------------------------------------------------

@policy.command(name="conflicts")
@click.option("--limit", default=100, show_default=True, help="Max conflicts to return (max 100).")
@click.option("--offset", default=0, show_default=True, help="Pagination offset.")
@click.pass_context
def policy_conflicts(ctx, limit, offset):
    """List conflicted keys with ALL contributing sources.

    Where two sources disagree at the same scope, both are shown with their
    document and line — the platform never silently picks a winner. Conflicts
    marked BLOCKING prevent an install until adjudicated.
    """
    client = _client(ctx)
    try:
        data = client.get(f"{_BASE}/conflicts", params={"limit": limit, "offset": offset})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if fmt != "text":
        output(data, fmt=fmt)
        return

    conflicts = data.get("conflicts", [])
    if not conflicts:
        click.echo("No conflicts.")
        return

    click.echo(f"{data.get('total', len(conflicts))} conflict(s), "
               f"{data.get('blocking_count', 0)} blocking install.\n")
    for c in conflicts:
        mark = "[BLOCKING] " if c.get("blocking") else ""
        scope = f" @ {c['scope']}" if c.get("scope") else ""
        click.echo(f"{mark}{c['key']}{scope}"
                   f"{'  (security-critical)' if c.get('security_critical') else ''}")
        for cand in c.get("candidates", []):
            loc = cand.get("locator") or {}
            quote = (cand.get("quote") or "").strip()
            if len(quote) > 70:
                quote = quote[:67] + "..."
            click.echo(f"    {json.dumps(cand.get('value')):>22}  "
                       f"doc {cand.get('document_id', '')[:8]} line {loc.get('line', '?')}"
                       f"{'  ' + repr(quote) if quote else ''}")
        click.echo("")


@policy.command(name="apply")
@click.argument("vocabulary_key", nargs=-1)
@click.option("--workspace-id", "workspace_id", default=None,
              help="Only this workspace's installed apps. Omit → every install in the tenant.")
@click.option("--yes", "-y", "confirmed", is_flag=True, default=False,
              help="Actually write. Without it this is a DRY RUN that changes nothing.")
@click.option("--tenant-id", "--tenant", "target_tenant_id", default=None,
              help="SUPER-ADMIN ONLY: apply in ANOTHER tenant (via audited impersonation).")
@click.pass_context
def policy_apply(ctx, vocabulary_key, workspace_id, confirmed, target_tenant_id):
    """Apply your CURRENT policy values to the apps that are already installed.

    `impact` tells you which installed apps baked an OLD value; this is the step that
    fixes them. It re-renders each artifact's stored definition — which still holds the
    {{vocab:...}} placeholder — and rewrites the live SQL.

    ⛔ Nothing is written without --yes. A run reports:
      updated     the SQL was rewritten
      clear       already on the current value
      blocked     a value awaits ratification, or a placeholder cannot render
      shadowed    written, but another workspace's copy of the same table wins the
                  rebuild — apply to that workspace too, or deactivate the older copy
      unsupported an artifact type whose SQL this step does not rewrite (transformer,
                  rule, widget, kpi and attention_card ARE rewritten)
      failed      the write itself failed; the usage row is left so a re-run retries

    The data does not move at the moment of the write: a rebuild is QUEUED, and the
    derived-state drain rebuilds what changed and everything downstream of it.

    \b
    Examples:
      torana vm policy apply severity_floor              # dry run — what would change
      torana vm policy apply severity_floor --yes        # do it
      torana vm policy apply --workspace-id <UUID> --yes # one app
      TORANA_PROFILE=SA torana vm policy apply --tenant-id <UUID> --yes   # another tenant
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = {"dry_run": not confirmed}
    if vocabulary_key:
        body["vocabulary_keys"] = list(vocabulary_key)
    if workspace_id:
        body["workspace_id"] = workspace_id

    try:
        with _as_tenant(ctx, target_tenant_id) as client:
            data = client.post("workspaces/build-v2/vocab-usage/apply", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    if body["dry_run"]:
        click.echo("DRY RUN — nothing was written. Re-run with --yes to apply.\n")
    for bucket, title in (("updated", "Updated"), ("clear", "Already current"),
                          ("shadowed", "Shadowed"), ("blocked", "Blocked"),
                          ("unsupported", "Not supported"), ("failed", "Failed")):
        rows = (data or {}).get(bucket) or []
        if not rows:
            continue
        click.echo(f"{title} ({len(rows)}):")
        for r in rows:
            line = f"  {r.get('artifact_key')} [{r.get('artifact_type')}]"
            keys = r.get("keys") or []
            moved = [f"{k['key']}: {k['old']} → {k['new']}" for k in keys
                     if k.get("old") != k.get("new")]
            if moved:
                line += "  " + "; ".join(moved)
            if r.get("reason"):
                line += f"  — {r['reason']}"
            click.echo(line)
        click.echo("")

    rebuild = (data or {}).get("rebuild") or {}
    if rebuild.get("queued"):
        click.echo(f"Rebuild queued for: {', '.join(rebuild.get('reasons') or [])}")
        click.echo("The data moves when the derived-state drain next runs (~60s quiet period).")
    if rebuild.get("complete") is False:
        click.echo("⚠️  The transformer list could not be read in full; some readers may "
                   "not have been marked for rebuild, and the shadowed-copy check is "
                   "partial.")

    # A KPI / attention card's SQL is rewritten in the landing config, but its displayed
    # value is the LAST SWEEP's result until the workspace sweeps again.
    landing_ws = sorted({r.get("workspace_id") for r in (data or {}).get("updated") or []
                         if r.get("artifact_type") in ("kpi", "attention_card")
                         and r.get("workspace_id")})
    if landing_ws and not body["dry_run"]:
        click.echo("KPI / attention-card values refresh at the workspace's next sweep; "
                   "to refresh now: " + "; ".join(f"torana workspace {w} sweep"
                                                   for w in landing_ws))

    # What the bootstrap repair below re-renders (and which still run the OLD value).
    _echo_bootstrap_consumers((data or {}).get("bootstrap"))

    # ⛔ SEPARATE FROM `rebuild` ABOVE ON PURPOSE. `rebuild` covers INSTALLED-APP
    # artifacts this call just rewrote; it says nothing about the BOOTSTRAP set
    # (prioritize_*, posture_*, …) — those relations are transformer_refs with no
    # artifact row here at all, and a bundle standing entirely on them (this platform's
    # own precedent: exposure_prioritization, remediation_ops, threat_intel_priority)
    # would otherwise see NO indication this apply touched them at all.
    # ⚠️ `.get(...)`, not `[]` — an older server that has not deployed this trigger yet
    # simply omits the key, and printing nothing is the correct read of that: it cannot
    # promise something it never scheduled.
    boot = (data or {}).get("bootstrap_repair")
    if boot is not None:
        if boot.get("scheduled"):
            click.echo("Bootstrap-set repair scheduled for this tenant — prioritize_* / "
                       "posture_* relations that render this policy value will be "
                       "rewritten and rebuilt in the background.")
        elif boot.get("reason"):
            click.echo(f"⚠️  Could not schedule bootstrap-set repair: {boot['reason']}. "
                       f"Bootstrap relations reading this policy will pick it up at the "
                       f"next boot, or run `torana vm transformers definitions repair "
                       f"--apply` now.")


@policy.command(name="impact")
@click.argument("vocabulary_key", nargs=-1)
@click.option("--run", "extraction_run_id", default=None,
              help="Analyze the keys this extraction run changed (instead of naming keys).")
@click.option("--tenant", "target_tenant_id", default=None,
              help="SUPER-ADMIN ONLY: analyze another tenant. Omit → your own tenant.")
@click.pass_context
def policy_impact(ctx, vocabulary_key, extraction_run_id, target_tenant_id):
    """Which already-installed apps baked the OLD value of a changed vocabulary key.

    After a policy change moves a value (e.g. severity_floor Medium→High), the apps
    installed earlier still carry the OLD value baked into their SQL. This reports the
    IMPACTED apps (need re-rendering) vs the CLEAR ones (already match), per key.

      torana vm policy impact severity_floor                 # by key (your tenant)
      torana vm policy impact severity_floor sla_window_by_severity
      torana vm policy impact --run <RUN_ID> --tenant <UUID> # by run (SA, another tenant)
    """
    if not vocabulary_key and not extraction_run_id:
        click.echo("Provide at least one VOCABULARY_KEY or --run <RUN_ID>.", err=True)
        raise SystemExit(2)

    client = _client(ctx)
    params = []
    for k in vocabulary_key:
        params.append(("vocabulary_key", k))
    if extraction_run_id:
        params.append(("extraction_run_id", extraction_run_id))
    if target_tenant_id:
        params.append(("tenant", target_tenant_id))
    try:
        data = client.get(f"{_BASE}/impact", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if fmt != "text":
        output(data, fmt=fmt, raw=ctx.obj.get(CTX_RAW, False) if ctx.obj else False,
               fields=ctx.obj.get(CTX_FIELDS) if ctx.obj else None)
        return

    summary = data.get("summary", {})
    click.echo(f"IMPACT — tenant {data.get('tenant_id', '')[:8]}")
    click.echo(f"  Impacted apps:      {summary.get('impacted_apps', 0)}")
    click.echo(f"  Clear apps:         {summary.get('clear_apps', 0)}")
    click.echo(f"  Impacted artifacts: {summary.get('impacted_artifacts', 0)}")
    if summary.get("blocked_keys"):
        click.echo(f"  BLOCKED keys:       {summary['blocked_keys']} "
                   "(security-critical + unratified — re-render disallowed)")
    click.echo("")

    click.echo("KEYS")
    for k in data.get("keys", []):
        flags = []
        if k.get("security_critical"):
            flags.append("security-critical")
        if k.get("blocked"):
            flags.append("BLOCKED")
        if k.get("unknown"):
            flags.append("unknown")
        suffix = ("  [" + ", ".join(flags) + "]") if flags else ""
        click.echo(f"  {k.get('vocabulary_key')}  = {json.dumps(k.get('current_value'))}"
                   f"  (run {str(k.get('current_extraction_run_id') or '-')[:8]}){suffix}")
    click.echo("")

    impacted = data.get("impacted", [])
    if impacted:
        click.echo(f"IMPACTED APPS ({len(impacted)})")
        rows = []
        for app in impacted:
            rows.append({
                "workspace": str(app.get("workspace_name") or app.get("workspace_id"))[:32],
                "bundle": app.get("source_bundle_id") or "-",
                "artifacts": app.get("impacted_artifact_count", 0),
                "age_days": app.get("age_days", 0),
            })
        output({"items": rows}, fmt="text", columns=[
            ("workspace", "WORKSPACE", 32), ("bundle", "APP", 20),
            ("artifacts", "IMPACTED", 8), ("age_days", "AGE(d)", 6)])
    else:
        click.echo("No impacted apps — nothing baked the old value of these key(s).")
    click.echo("")

    clear = data.get("clear", [])
    if clear:
        click.echo(f"CLEAR APPS ({len(clear)}) — consumed the key(s) but already match the current value.")

    _echo_bootstrap_consumers(data.get("bootstrap"))


#: ⛔ Text glyph per render state, never colour alone (red/green colour blindness;
#: piped output loses ANSI). Mirrors vm_transformers._HEALTH_GLYPH's style.
_RENDER_GLYPH = {"stale": "[XX]", "current": "[ok]", "not_created": "[  ]",
                 "unknown": "[??]"}


def _echo_bootstrap_consumers(boot) -> None:
    """The PLATFORM-WIDE group: bootstrap relations that render the key(s).

    They have no usage rows, so they never appear under IMPACTED/CLEAR APPS; every app
    on the bootstrap set reads them. `policy apply` reaches them by scheduling a
    bootstrap repair, not by rewriting an app.
    """
    if boot is None:
        return  # an older server that does not report the group
    click.echo("")
    if not boot.get("checked"):
        # ⛔ Never print "none" for a lookup that failed — that is the empty-as-success lie.
        click.echo(f"BOOTSTRAP RELATIONS — NOT CHECKED ({boot.get('error')}). "
                   "Platform relations using these key(s) are unknown, not absent.")
        return
    consumers = boot.get("consumers") or []
    if not consumers:
        click.echo("BOOTSTRAP RELATIONS — none of the platform relations use these key(s).")
        return
    # ⛔ EVERY state counted (§ 4.7): "N, 0 stale" hid 8 not_created rows on Classie. The
    # server's `counts` when present; an older server's list counted here the same way.
    counts = boot.get("counts") or {}
    if not counts:
        for c in consumers:
            st = c.get("render_state") or "unknown"
            counts[st] = counts.get(st, 0) + 1
    stale = counts.get("stale", 0)
    parts = [f"{counts.get(k, 0)} {k.replace('_', ' ')}"
             for k in ("current", "stale", "not_created", "unknown")]
    click.echo(f"BOOTSTRAP RELATIONS ({len(consumers)}: {', '.join(parts)}) — platform-wide, "
               "read by every app on the bootstrap set:")
    for c in consumers:
        state = c.get("render_state") or "unknown"
        glyph = _RENDER_GLYPH.get(state, "[??]")
        keys = ", ".join(c.get("vocab_keys") or [])
        ws = c.get("workspace_id")
        owner = f"  [owned by app workspace {ws}]" if ws and ws != "bootstrap" else ""
        click.echo(f"  {glyph} {state:11} {c.get('name')}  ← {keys}{owner}")
        if c.get("render_error"):
            click.echo(f"        {c['render_error']}")
    if stale:
        click.echo("  stale = still running the OLD value. `policy apply` schedules the "
                   "bootstrap repair that re-renders them; or run "
                   "`torana vm transformers definitions repair --apply`.")
    if counts.get("not_created"):
        click.echo("  not created = this tenant has no row for that definition; repair creates "
                   "it (`torana vm transformers definitions repair --apply`).")
    if counts.get("unknown"):
        click.echo("  unknown = current/stale could not be determined (see the error on the "
                   "row); it is NOT the same as current.")


@policy.command(name="resolve")
@click.argument("key")
@click.option("--scope", default="", help="Scope ('' = global).")
@click.option("--candidate", "candidate_id", default=None, help="ID of the winning candidate.")
@click.option("--reextract", is_flag=True, help="Request re-extraction instead of choosing a winner.")
@click.pass_context
def policy_resolve(ctx, key, scope, candidate_id, reextract):
    """Adjudicate a conflict by choosing a winning source.

    Adjudication settles WHICH value; ratification separately settles THAT value —
    a security-critical key returns to 'pending' after adjudication.
    """
    if not candidate_id and not reextract:
        raise click.UsageError("Provide --candidate <id>, or --reextract.")
    if candidate_id and reextract:
        raise click.UsageError("--candidate and --reextract are mutually exclusive.")

    client = _client(ctx)
    body = {"scope": scope, "reextract": reextract}
    if candidate_id:
        body["winning_candidate_id"] = candidate_id
    try:
        data = client.post(f"{_BASE}/conflicts/{key}/resolve", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if fmt == "text":
        click.echo(f"{data.get('status')}: {key}" + (f" @ {scope}" if scope else ""))
        if data.get("detail"):
            click.echo(data["detail"])
        return
    output(data, fmt=fmt)


# ---------------------------------------------------------------------------
# bindings
# ---------------------------------------------------------------------------

class _AppliedNotes:
    """"(not yet applied)" for a setting the platform records but does not act on (DS4e § 3.2.6, D8; E-20.16).

    Only a key whose registry entry carries `applied_by` (a pointer to the service that applies it) is asked about, and the answer is the
    platform's, read from `policy_application` in the served labels export at request time: this class decides nothing. One export read per
    command, made the first time a key with `applied_by` is seen; a platform that does not serve it prints nothing extra."""

    def __init__(self, client):
        self._client = client
        self._labels = None

    def note(self, key, applied_by) -> str:
        if not applied_by:
            return ""
        if self._labels is None:
            self._labels = sw.fetch_labels(self._client)
        return sw.not_yet_applied(self._labels, str(key))

    def suffix(self, key, applied_by) -> str:
        return " (not yet applied)" if self.note(key, applied_by) else ""


@policy.command(name="show")
@click.argument("key")
@click.option("--scope", default="", help="Scope ('' = global).")
@click.pass_context
def policy_show(ctx, key, scope):
    """Show one binding and the sources it was drawn from."""
    client = _client(ctx)
    try:
        data = client.get(f"{_BASE}/bindings/{key}", params={"scope": scope})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if fmt != "text":
        output(data, fmt=fmt)
        return

    click.echo(f"key                : {data.get('key')}")
    if data.get("scope"):
        click.echo(f"scope              : {data['scope']}")
    click.echo(f"status             : {data.get('status')}")
    value = data.get("value")
    _applied = _AppliedNotes(client)
    _akey = data.get("key") or key
    if key in _ENTRY_KEYS and isinstance(value, dict):
        click.echo(f"value              :{_applied.suffix(_akey, data.get('applied_by'))}")
        _print_entries(value, data.get("entry_notes") or {})
    else:
        click.echo(f"value              : {json.dumps(value)}{_applied.suffix(_akey, data.get('applied_by'))}")
    if _applied.note(_akey, data.get("applied_by")):
        click.echo(f"applied            : {_applied.note(_akey, data.get('applied_by'))}")
    click.echo(f"default in effect  : {data.get('default_in_effect')}")
    click.echo(f"security-critical  : {data.get('security_critical')}")
    click.echo(f"ratification       : {data.get('ratification_state')}")

    # Audit trail (§3.7) — who touched this binding, and when. Answers
    # "who ratified this security-critical value?" — invisible before this.
    audit = data.get("audit") or {}
    if audit:
        click.echo("\naudit:")
        if audit.get("created_by"):
            click.echo(f"  created   : {audit['created_by']}  {audit.get('created_at','')}")
        if audit.get("updated_by"):
            click.echo(f"  updated   : {audit['updated_by']}  {audit.get('updated_at','')}")
        if audit.get("ratified_by"):
            click.echo(f"  ratified  : {audit['ratified_by']}  {audit.get('ratified_at','')}")
        else:
            click.echo("  ratified  : (not ratified)")

    cands = data.get("candidates") or []
    if cands:
        click.echo("\nsources:")
        for c in cands:
            loc = c.get("locator") or {}
            verified = loc.get("verified")
            click.echo(f"  {json.dumps(c.get('value')):>22}  doc {c.get('document_id','')[:8]} "
                       f"line {loc.get('line','?')}"
                       f"{'' if verified else ' (locator unverified)'}")
            if c.get("quote"):
                click.echo(f"      {c['quote'][:100]!r}")
    else:
        click.echo("\nsources: none — the platform default is in effect.")


@policy.command(name="set")
@click.argument("key")
@click.option("--value", required=True, help="New value (JSON, or a bare string for enums).")
@click.option("--scope", default="", help="Scope ('' = global).")
@click.option("--tenant-id", "--tenant", "target_tenant_id", default=None,
              help="SUPER-ADMIN ONLY: set it in ANOTHER tenant (via audited impersonation).")
@click.pass_context
def policy_set(ctx, key, value, scope, target_tenant_id):
    """Override a bound value.

    An override does NOT bypass policy: it is still subject to the conformance
    gate at install, and overriding a security-critical key returns it to
    'pending' for ratification.

    The tenant's platform relations that render this key are re-rendered by a
    background repair, scheduled by the override itself (minutes, not the next boot).

    \b
    Examples:
      torana vm policy set epss_escalate_threshold --value 0.5
      TORANA_PROFILE=SA torana vm policy set epss_escalate_threshold --value 0.5 --tenant-id <UUID>
    """
    try:
        with _as_tenant(ctx, target_tenant_id) as client:
            data = client.put(
                f"{_BASE}/bindings/{key}",
                json={"value": _parse_value(value), "scope": scope},
            )
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if fmt == "text":
        click.echo(f"{data.get('status')}: {key}"
                   + (f" @ {scope}" if scope else "")
                   + f" = {json.dumps(data.get('value'))}")
        if "repair_scheduled" in data:
            click.echo("platform relations: re-render "
                       + ("scheduled (background repair)" if data["repair_scheduled"]
                          else f"NOT scheduled — {data.get('repair_error') or 'unknown'}; "
                               "run `torana vm transformers definitions repair --apply`"))
        return
    output(data, fmt=fmt)


@policy.command(name="unset")
@click.argument("key")
@click.option("--scope", default="", help="Scope ('' = global).")
@click.option("--tenant-id", "--tenant", "target_tenant_id", default=None,
              help="SUPER-ADMIN ONLY: clear it in ANOTHER tenant (via audited impersonation).")
@click.pass_context
def policy_unset(ctx, key, scope, target_tenant_id):
    """Remove this tenant's own value of a setting, so the platform default applies again.

    Unlike `set --value <default>`, nothing is written: a later change to the platform default still reaches the app.
    Needs the policy:bind permission.

    \b
    Examples:
      torana vm policy unset epss_escalate_threshold
    """
    try:
        with _as_tenant(ctx, target_tenant_id) as client:
            data = client.delete(f"{_BASE}/bindings/{key}", params={"scope": scope} if scope else None)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    fmt = _fmt(ctx)
    if fmt == "text":
        click.echo(f"cleared: {key}" + (f" @ {scope}" if scope else "") + " (the platform default applies)")
        return
    output(data if data is not None else {"status": "cleared", "key": key}, fmt=fmt)


_ENTRY_KEYS = ("criticality_overrides", "customer_data_overrides", "ownership_routing")


def _print_entries(value: dict, notes: dict | None = None) -> None:
    """A selector → value map as a table: SELECTOR, VALUE, SET BY, SET AT, NOTE.

    `notes` is the binding's `entry_notes` ({selector: note}); an entry that carries its own `effect_note` wins."""
    notes = notes or {}
    click.echo(f"  {'SELECTOR':<52} {'VALUE':<10} {'SET BY':<24} {'SET AT':<26} NOTE")
    for sel in sorted(value):
        e = value[sel]
        if isinstance(e, dict):
            v, by, at, note = e.get("value"), e.get("set_by", ""), e.get("set_at", ""), e.get("effect_note") or notes.get(sel, "")
        else:
            v, by, at, note = e, "", "", notes.get(sel, "")
        click.echo(f"  {sel:<52} {json.dumps(v):<10} {str(by)[:24]:<24} {str(at)[:26]:<26} {note or ''}")


@policy.command(name="set-entry")
@click.argument("key", type=click.Choice(_ENTRY_KEYS))
@click.option("--selector", required=True,
              help="service:<key> | repo:<key> | datastore:<key> | account:<id> | env:<environment>")
@click.option("--value", required=True,
              help="Critical|High|Medium|Low (criticality_overrides), true|false "
                   "(customer_data_overrides), a team (ownership_routing).")
@click.option("--reason", default="", help="Why (recorded on the entry).")
@click.option("--tenant-id", "--tenant", "target_tenant_id", default=None,
              help="SUPER-ADMIN ONLY: set it in ANOTHER tenant (via audited impersonation).")
@click.pass_context
def policy_set_entry(ctx, key, selector, value, reason, target_tenant_id):
    """Set ONE selector's entry of a selector → value policy setting.

    A policy entry wins over a source value (a tag or label), and the app shows both.

    \b
    Examples:
      torana vm policy set-entry criticality_overrides --selector service:prod/payments-api --value Critical
      torana vm policy set-entry customer_data_overrides --selector env:production --value true
    """
    _edit_entry(ctx, key, selector, _parse_value(value), reason, remove=False,
                tenant_id=target_tenant_id)


@policy.command(name="unset-entry")
@click.argument("key", type=click.Choice(_ENTRY_KEYS))
@click.option("--selector", required=True, help="The selector to remove.")
@click.option("--tenant-id", "--tenant", "target_tenant_id", default=None,
              help="SUPER-ADMIN ONLY: in ANOTHER tenant (via audited impersonation).")
@click.pass_context
def policy_unset_entry(ctx, key, selector, target_tenant_id):
    """Remove ONE selector's entry."""
    _edit_entry(ctx, key, selector, None, "", remove=True, tenant_id=target_tenant_id)


def _edit_entry(ctx, key, selector, value, reason, remove, tenant_id=None):
    try:
        with _as_tenant(ctx, tenant_id) as client:
            if remove:
                data = client.delete(f"{_BASE}/bindings/{key}/entries", params={"selector": selector})
            else:
                data = client.put(f"{_BASE}/bindings/{key}/entries",
                                  json={"selector": selector, "value": value, "reason": reason})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    data = data or {}
    fmt = _fmt(ctx)
    if fmt == "text":
        click.echo(f"{data.get('status', 'removed' if remove else 'set')}: "
                   f"{key}[{data.get('selector', selector)}]"
                   + ("" if remove else f" = {json.dumps((data.get('entry') or {}).get('value', value))}"))
        if data.get("effect_note"):
            click.echo(f"note: {data['effect_note']}")
        return
    output(data, fmt=fmt)


@policy.command(name="ratify")
@click.argument("key")
@click.option("--scope", default="", help="Scope ('' = global).")
@click.pass_context
def policy_ratify(ctx, key, scope):
    """Ratify a security-critical value (the human gate).

    A security-critical binding cannot bind — and an install stays blocked —
    until a human confirms the extracted value against its source.
    """
    client = _client(ctx)
    try:
        data = client.post(f"{_BASE}/bindings/{key}/ratify", params={"scope": scope}, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if fmt == "text":
        click.echo(f"{data.get('status')}: {key}" + (f" @ {scope}" if scope else ""))
        return
    output(data, fmt=fmt)


# ---------------------------------------------------------------------------
# conformance + vocabulary
# ---------------------------------------------------------------------------

@policy.command(name="retire")
@click.argument("key")
@click.option("--dry-run", is_flag=True, help="Show what would be retired without changing anything.")
@click.pass_context
def policy_retire(ctx, key, dry_run):
    """Retire this tenant's rows for a DEPRECATED vocabulary key.

    The delete path for a vocabulary variable. The key must first be marked
    deprecated in the code registry — retiring an active key would strip a
    binding the conformance gate still depends on, so that is refused.

    Soft-delete only: rows remain for audit. A value a human ratified does not
    lose the record of that approval just because the variable was retired.
    """
    client = _client(ctx)
    try:
        data = client.post(f"{_BASE}/retire/{key}", params={"dry_run": dry_run}, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if fmt != "text":
        output(data, fmt=fmt)
        return

    status = data.get("status")
    if status == "dry_run":
        click.echo(f"DRY RUN — would retire '{key}':")
    else:
        click.echo(f"Retired '{key}':")
    click.echo(f"  bindings   : {data.get('bindings', 0)}")
    click.echo(f"  candidates : {data.get('candidates', 0)}")
    if data.get("was_ratified"):
        click.echo("  note       : this key had a RATIFIED value; the rows are soft-deleted "
                   "and retained for audit.")
    if data.get("deprecated_reason"):
        click.echo(f"  reason     : {data['deprecated_reason']}")
    if data.get("superseded_by"):
        click.echo(f"  superseded by: {data['superseded_by']}")


@policy.command(name="conformance")
@click.pass_context
def policy_conformance(ctx):
    """Check whether the bound policy would block an install.

    Evaluates the five conformance rules over the EFFECTIVE bound program — not
    each value in isolation — so a default that combines badly with a bound value
    is caught. Fails closed.
    """
    client = _client(ctx)
    try:
        data = client.get(f"{_BASE}/conformance")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if fmt != "text":
        output(data, fmt=fmt)
        return

    if data.get("passed"):
        click.echo("PASS — the bound policy satisfies all five conformance rules.")
        return
    violations = data.get("violations", [])
    click.echo(f"BLOCKED — {len(violations)} conformance violation(s):\n")
    for v in violations:
        scope = f" @ {v['scope']}" if v.get("scope") else ""
        click.echo(f"  rule {v.get('rule')} [{v.get('rule_name')}] {v.get('key')}{scope}")
        click.echo(f"    {v.get('detail')}")


@policy.command(name="vocabulary")
@click.option("--keys", "keys_only", is_flag=True, default=False,
              help="Flat, machine-parseable dump: one TAB-separated line per key "
                   "(key<TAB>qualified_path<TAB>shape<TAB>render_verbs<TAB>default<TAB>sec-crit). "
                   "Nothing is truncated — use this to author {{vocab:…}} placeholders.")
@click.pass_context
def policy_vocabulary(ctx, keys_only):
    """List the VM policy vocabulary (definitions, shapes, defaults)."""
    client = _client(ctx)
    try:
        data = client.get(f"{_BASE}/vocabulary")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Standard list envelope: {items, total, categories}. `variables` fallback keeps this working
    # against an older backend during the envelope-standardization rollout.
    variables = data.get("items")
    if variables is None:
        variables = data.get("variables", [])
    active = [v for v in variables if not v.get("deprecated")]
    retired = [v for v in variables if v.get("deprecated")]

    fmt = _fmt(ctx)

    # --keys: flat TAB-separated dump — the authoring surface. No column truncation (the table
    # view clipped the qualified-path/default columns, which are exactly what you author against).
    if keys_only:
        for v in active:
            verbs = v.get("valid_render_verbs") or []
            click.echo("\t".join([
                str(v.get("key") or ""),
                str(v.get("qualified_path") or "-"),
                str(v.get("shape") or ""),
                ("." + "/".join(verbs)) if verbs else "(bare)",
                json.dumps(v.get("conservative_default")),
                "sec-crit" if v.get("security_critical") else "",
            ]))
        return

    if fmt != "text":
        output(data, fmt=fmt)
        return

    rows = []
    _applied = _AppliedNotes(client)
    for v in active:
        verbs = v.get("valid_render_verbs") or []
        rows.append({
            "key": f"{v.get('key')}{_applied.suffix(v.get('key'), v.get('applied_by'))}",
            "qualified_path": v.get("qualified_path") or "-",
            "shape": v.get("shape"),
            "render_verbs": ("." + "/".join(verbs)) if verbs else "(bare)",
            "conservative_default": json.dumps(v.get("conservative_default")),
            "security_critical": "yes" if v.get("security_critical") else "",
        })
    output({"items": rows, "total": len(rows)}, fmt="text", columns=[
        ("key", "KEY", max([30] + [len(str(r["key"])) for r in rows])),     # wide enough for "(not yet applied)"
        ("qualified_path", "QUALIFIED PATH ({{vocab:<path>[.<verb>]}})", 56),
        ("shape", "SHAPE", 14),
        ("render_verbs", "RENDER VERBS", 22),
        ("conservative_default", "DEFAULT", 22),
        ("security_critical", "SEC-CRIT", 9),
    ])

    # Retired keys are listed separately, with WHY — a removal should never be
    # mysterious to whoever finds the key still on their tenant's bindings.
    if retired:
        click.echo("")
        click.echo(f"RETIRED ({len(retired)}) — no longer extracted or bound:")
        for v in retired:
            line = f"  {v.get('key')}"
            if v.get("superseded_by"):
                line += f"  → superseded by {v['superseded_by']}"
            click.echo(line)
            if v.get("deprecated_reason"):
                click.echo(f"      {v['deprecated_reason']}")


@policy.command(name="documents")
@click.option("--tenant", "target_tenant_id", default=None,
              help="SUPER-ADMIN ONLY: another tenant's policy documents.")
@click.option("--domain", default=POLICY_DOMAIN,
              help="Extractor/domain filter. Only 'exposure_management' today.")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", default=50, show_default=True, help="Rows per page (max 100).")
@click.pass_context
def policy_documents(ctx, target_tenant_id, domain, page, page_size):
    """List the tenant's policy documents with extraction status, grouped by layer."""
    client = _client(ctx)
    params = {"domain": domain, "page": page, "page_size": page_size}
    if target_tenant_id:
        params["tenant"] = target_tenant_id
    try:
        data = client.get(f"{_BASE}/documents", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if fmt != "text":
        output(data, fmt=fmt)
        return

    scope = f"tenant {data.get('tenant_id')}" if data.get("cross_tenant") else "your tenant"
    click.echo(f"POLICY DOCUMENTS — {scope} · domain={data.get('domain')} "
               f"· {data.get('total', 0)} total")
    # group by layer, with un-extracted docs last under 'Not yet extracted'
    groups: dict = {}
    for it in data.get("items", []):
        key = it.get("layer") or "Not yet extracted"
        groups.setdefault(key, []).append(it)
    for layer in [x for x in ("org", "team", "personal") if x in groups] + \
            [x for x in groups if x not in ("org", "team", "personal")]:
        click.echo(f"\n[{layer}]")
        for it in groups[layer]:
            mark = "✓ extracted" if it.get("extracted") else f"— {it.get('status') or 'not extracted'}"
            metrics = ""
            if it.get("extracted"):
                metrics = (f"  ({it.get('candidates_emitted', 0)} vars, "
                           f"{it.get('candidates_conflicted', 0)} conflicts, "
                           f"{(it.get('last_extracted_at') or '')[:10]})")
            click.echo(f"  {it.get('title'):40} {mark}{metrics}")


@policy.command(name="vocabulary-browse")
@click.option("--tenant", "target_tenant_id", default=None,
              help="SUPER-ADMIN ONLY: view another tenant's vocabulary.")
@click.option("--document", "document_id", default=None,
              help="Scope to ONE document's contributions.")
@click.option("--category", default=None, help="Filter to one category.")
@click.option("--origin", default=None,
              help="system_default|from_policy|conflicted|manually_set")
@click.pass_context
def policy_vocabulary_browse(ctx, target_tenant_id, document_id, category, origin):
    """Browse the PER-TENANT vocabulary: category/subcategory, origin, and provenance.

    Distinct from `vocabulary` (the tenant-neutral definitions). This shows what a
    tenant actually resolved — system default vs from policy vs conflicted — with a
    whole-vocabulary rollup and the source document behind each override.
    """
    client = _client(ctx)
    params = {}
    if target_tenant_id:
        params["tenant"] = target_tenant_id
    if document_id:
        params["document_id"] = document_id
    if category:
        params["category"] = category
    if origin:
        params["origin"] = origin
    try:
        data = client.get(f"{_BASE}/vocabulary/browse", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if fmt != "text":
        output(data, fmt=fmt)
        return

    _applied = _AppliedNotes(client)
    r = data.get("rollup", {})
    scope = f"tenant {data.get('tenant_id')}" if data.get("cross_tenant") else "your tenant"
    click.echo(f"DOMAIN VOCABULARY — {scope}")
    click.echo(
        f"  {r.get('total', 0)} variables · {r.get('system_default', 0)} system-default · "
        f"{r.get('from_policy', 0)} from policy · {r.get('manually_set', 0)} manual · "
        f"{r.get('conflicted', 0)} conflicted · {r.get('retired_live', 0)} retired"
    )
    for cat in data.get("categories", []):
        click.echo("")
        head = f"[{cat.get('label') or cat.get('key')}]"
        if cat.get("department") or cat.get("owner_role"):
            head += f"  — {cat.get('department') or '-'} · {cat.get('owner_role') or '-'}"
        click.echo(head)
        for sub in cat.get("subcategories", []):
            click.echo(f"  {sub.get('label') or sub.get('key')}:")
            for v in sub.get("variables", []):
                mark = " *" if v.get("security_critical") else ""
                mark += _applied.suffix(v.get("key"), v.get("applied_by"))
                click.echo(f"    {v.get('key'):32} {v.get('origin', ''):14} "
                           f"{json.dumps(v.get('value'))}{mark}")


@policy.command(name="vocabulary-show")
@click.argument("key")
@click.option("--tenant", "target_tenant_id", default=None,
              help="SUPER-ADMIN ONLY: read from another tenant.")
@click.pass_context
def policy_vocabulary_show(ctx, key, target_tenant_id):
    """Full provenance for ONE variable: layer · document · line · quote · run · ratifier."""
    client = _client(ctx)
    params = {"tenant": target_tenant_id} if target_tenant_id else {}
    try:
        data = client.get(f"{_BASE}/vocabulary/browse", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    match = None
    for cat in data.get("categories", []):
        for sub in cat.get("subcategories", []):
            for v in sub.get("variables", []):
                if v.get("key") == key:
                    match = v
                    break
    if match is None:
        click.echo(f"No variable '{key}' found for this tenant.")
        return

    fmt = _fmt(ctx)
    if fmt != "text":
        output(match, fmt=fmt)
        return

    click.echo(f"{match.get('key')}  ({match.get('shape')})")
    click.echo(f"  meaning : {match.get('meaning')}")
    click.echo(f"  origin  : {match.get('origin')}")
    click.echo(f"  value   : {json.dumps(match.get('value'))}  "
               f"(default {json.dumps(match.get('default_value'))})")
    _note = _AppliedNotes(client).note(match.get("key"), match.get("applied_by"))
    if _note:
        click.echo(f"  applied : (not yet applied) {_note}")
    if match.get("security_critical"):
        click.echo(f"  ratify  : {match.get('ratification_state')}"
                   + (f" by {match['ratified_by']} @ {match['ratified_at']}"
                      if match.get("ratified_by") else ""))
    prov = match.get("provenance")
    if prov:
        click.echo("  provenance:")
        click.echo(f"    layer   : {prov.get('precedence_layer')}")
        click.echo(f"    document: {prov.get('document_name') or '—'} "
                   f"({prov.get('document_id') or '—'})")
        click.echo(f"    line    : {prov.get('locator') or '—'}")
        click.echo(f"    quote   : {prov.get('quote') or '—'}")
        click.echo(f"    run     : {prov.get('extraction_run_id') or '—'}")
    else:
        click.echo("  provenance: — (system default in effect)")


# Attach onto the shared `torana vm` parent (import side effect).
register_vm_subgroup(policy)
