"""What a CI token proved, and what it may therefore touch — ONE implementation.

A CI token is minted only after a forge SIGNED a claim about which repository a
workflow is running in (GitHub's `repository`, GitLab's `project_path` — the same fact
under two names). The workflow cannot choose that value, which is the entire reason the
credential can be short-lived and unstored. This module is what makes the claim mean
something at a write path.

⛔ WHY IT IS HERE AND NOT IN A SERVICE. It started in `pantheon-integration`, guarding
the ingest routes. The reachability path needs exactly the same two answers in
`pantheon-detection-framework` — "which repository did this caller prove?" and "is this
route for a CI token at all?" — and a second copy of a security check is not a
duplicate, it is a BYPASS waiting to happen: the copies drift, and the half that drifts
is the half nobody is testing. The root rule is explicit that functionality used across
services belongs here.

⛔ TWO DIFFERENT QUESTIONS, AND BOTH ARE NEEDED.
    `enforce_ci_routes`  — is this route for a CI token AT ALL? (deny by default)
    `ref_matches_binding`— is this document/claim about YOUR repository?
A route with no notion of a repository can never answer the second, which is precisely
why it must fail the first. Measured on demo 2026-10-09, before the allow-list existed:
a token bound to one repository was refused on `/ingest/sarif` for another repo and
ACCEPTED on `/ingest/entity-edges` writing that same repo's provenance.

⚠️ EVERY FUNCTION HERE IS A NO-OP FOR A NON-CI CALLER. A human, SA or service token
carries no CI `token_kind`, so nothing is checked and nothing changes.
"""

from __future__ import annotations

import os
from typing import Any, Dict, FrozenSet, Optional

from fastapi import HTTPException, Request, status

from .identity import normalize_asset_key
from .logging import get_logger

logger = get_logger(__name__)

#: The `token_kind` values the identity exchanges ask auth to stamp. Anything else is
#: not a CI token and is left alone.
#:
#: ⛔ A CLOSED SET, NOT A PREFIX TEST. `startswith("ci_")` would admit any future kind
#: automatically — including one minted by a path that never validated a repository
#: binding — and the whole job here is to refuse a caller naming someone else's repo. A
#: new forge is added here deliberately, in the same change that adds its mint.
CI_TOKEN_KINDS: FrozenSet[str] = frozenset({"ci_github_oidc", "ci_gitlab_oidc"})


def bearer_token(request: Request) -> Optional[str]:
    """The presented bearer token, or None."""
    auth = request.headers.get("authorization") or ""
    if not auth.lower().startswith("bearer "):
        return None
    return auth.split(" ", 1)[1].strip() or None


def ci_claims(request: Request) -> Optional[Dict[str, Any]]:
    """The CI claims of the presenting token, or None when the caller is not CI.

    ⛔ VERIFIED, NOT just read. The IAM dependency has already validated this token to
    build the request's `IAMContext`, but re-decoding without verification here would
    mean the binding trusts an unverified payload — and the binding is a security check,
    so it must not rest on a claim anyone could have forged into the header.
    `IAMContext` does not preserve arbitrary claims (user/tenant/roles/permissions
    only), which is why the token is read again rather than passed through.

    ⚠️ Returns None on ANY decode problem. A caller whose token cannot be decoded is
    already being refused by the IAM dependency; this must never become a second,
    differently-behaved authentication path.
    """
    token = bearer_token(request)
    if not token:
        return None
    try:
        from .jwt import decode_jwt_token
        claims = decode_jwt_token(token, jwt_secret_key=os.getenv("JWT_SECRET_KEY"))
    except Exception:  # noqa: BLE001
        return None
    if not isinstance(claims, dict) or claims.get("token_kind") not in CI_TOKEN_KINDS:
        return None
    return claims


def bound_repository(request: Request) -> Optional[str]:
    """The repository this caller PROVED, or None when the caller is not CI."""
    claims = ci_claims(request)
    if claims is None:
        return None
    repo = str(claims.get("repository") or "").strip()
    return repo or None


def enforce_ci_routes(request: Request, allowed: FrozenSet[str], *, surface: str) -> None:
    """Refuse a CI token on any route of this surface that was not built for it.

    ⛔ AN ALLOW-LIST, NEVER A DENY-LIST, and the direction is the whole value: a route
    added tomorrow is off-limits to CI tokens until somebody deliberately lists it,
    rather than reachable until somebody remembers to forbid it.

    ⚠️ MOUNT IT AS A ROUTER DEPENDENCY, not a per-handler call. A per-handler call is a
    thing to forget, and the route somebody forgets is the one that matters — which is
    how the measured bypass above arose. At the router it also covers routes that do not
    exist yet.
    """
    repo = bound_repository(request)
    if repo is None:
        return                              # not a CI token — nothing to restrict
    # ⛔ MATCH THE ROUTE TEMPLATE AS WELL AS THE CONCRETE PATH. A route carrying an id
    # (`/alerts/{alert_id}/reachability`) has a different concrete path on every call,
    # so an exact-path allow-list could never list it — and the obvious workaround,
    # a prefix or substring test, is how an allow-list quietly becomes a deny-list with
    # extra steps. FastAPI already resolved the template; use it.
    candidates = {(request.url.path or "").rstrip("/")}
    route = request.scope.get("route") if hasattr(request, "scope") else None
    template = getattr(route, "path", None)
    if template:
        candidates.add(str(template).rstrip("/"))
    if candidates & set(allowed):
        return
    path = (request.url.path or "").rstrip("/")
    logger.error("ci route REFUSED: token for %s may not use %s", repo, path)
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail=(f"A CI token may not use {path}. It is issued for one repository "
                f"({repo}) and is accepted only on the {surface} routes designed for "
                f"a CI job."))


def ref_matches_binding(ref: str, bound: str) -> Optional[bool]:
    """Does a repository reference name the repo the token is bound to?

    Returns None when `ref` cannot be parsed at all, so the caller can leave a malformed
    value to its own error path and keep ONE error for it.

    ⛔ IT REPLACED A TWO-SEGMENT COMPARISON, AND THE BUG WAS ASYMMETRY, NOT TRUNCATION.
    The old code compared a RAW claim against a TRUNCATED reference. GitHub's claim is
    always exactly `owner/repo`, so both sides had two segments and it matched. A GitLab
    `project_path` nests arbitrarily:

        bound = torana-security/backend/svc
        got   = backend/svc                     -> REFUSED

    every legitimate call from a subgroup project. It failed SAFE (a loud false refusal)
    rather than admitting someone else's repo, but it was a hard break for any project
    not sitting directly under its group.

    ⚠️ The HOST is dropped, and EXACTLY ONE leading segment of it. `normalize_asset_key`
    yields `host/org/repo…` for a URL and `org/repo…` for a bare path, while the claim
    is always the bare path — so at most one segment separates them. Dropping "a leading
    host-looking segment" by pattern would mis-handle a group whose name contains a dot;
    dropping exactly one, and only when the remainder matches exactly, cannot.

    ⛔ NOT a suffix match. `got.endswith("/" + bound)` would accept
    `evil.com/x/torana-inc/billing-fn` for a token bound to `torana-inc/billing-fn`.
    Equality after dropping one segment refuses it.

    ⚠️ Host-insensitive by design: GitHub's claim carries no host, and a customer on
    GitHub Enterprise Server has a different host for the same logical repository.
    """
    try:
        key = str(normalize_asset_key(ref))
    except Exception:  # noqa: BLE001
        return None
    parts = [p for p in key.split("/") if p]
    if len(parts) < 2:
        return None
    full = "/".join(parts).lower()
    want = str(bound or "").strip().strip("/").lower()
    if not want:
        return None
    # Either the reference carries no host, or exactly its first segment is one.
    return full == want or "/".join(parts[1:]).lower() == want
