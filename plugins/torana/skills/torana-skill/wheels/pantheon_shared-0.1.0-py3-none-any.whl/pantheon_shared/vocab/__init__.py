"""Platform & domain VOCABULARY rendering — the one copy, shared across services.

⛔ WHY THIS LIVES IN pantheon-shared RATHER THAN IN ONE SERVICE.

A bootstrap transformer definition stores its SQL as a TEMPLATE carrying
`{{vocab:vm.<category>.<subcategory>.<key>[.<verb>]}}` placeholders, because the
values behind them are TENANT POLICY — what counts as "at or above the severity
floor", which statuses are actionable, what the SLA window is per severity. The
template is resolved per tenant before the relation is created.

Two callers now do that resolution:

    pantheon-program-framework   at BUNDLE INSTALL   (the original caller)
    pantheon-data-transformers   at REPAIR           (added 2026-09-22)

⛔ THEY MUST RENDER IDENTICALLY, AND A SECOND IMPLEMENTATION CANNOT GUARANTEE THAT.
If repair rendered `severity_floor.at_or_above` even slightly differently from
install — a different quoting rule, a different ordering, a different treatment of
an empty list — then the SAME relation would hold DIFFERENT rows depending on which
path happened to create it in that tenant. Nothing would error and nothing would
look empty; the numbers would simply disagree between two tenants, or between two
installs of the same bundle. That is the divergent-population failure the bootstrap
set exists to prevent, reintroduced one layer down.

So the renderer is not copied, it is MOVED here and imported by both.
`pantheon_program_framework.vm_content.vocab_render` now re-exports from this module
and holds no logic of its own.

⚠️ THE RESOLVER IS DELIBERATELY NOT HERE. Resolution is an HTTP call to
`/api/v1/vm/policy/resolve-and-gate`, owned by agent-builder, and each service
reaches it with its own client, settings and IAM context. Only the PURE part — the
part where a second implementation would silently disagree — is shared. This module
does no I/O: given artifacts and a bound-values map it returns rendered artifacts.
"""

from .render import (  # noqa: F401
    VERB_CONTRACT,
    VocabRenderError,
    extract_vocabulary_keys,
    extract_vocabulary_usages,
    render_artifacts,
    render_sql_verb,
    validate_vocabulary_references,
)

__all__ = [
    "VERB_CONTRACT",
    "VocabRenderError",
    "extract_vocabulary_keys",
    "extract_vocabulary_usages",
    "render_artifacts",
    "render_sql_verb",
    "validate_vocabulary_references",
]
