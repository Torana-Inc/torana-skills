"""Vocabulary placeholder extraction + typed SQL rendering — Spec A § 3.6.

App-template artifacts carry DOMAIN-QUALIFIED placeholders so nothing tenant-specific
is hardcoded — including values embedded inside artifact SQL:

    {{vocab:vm.<category>.<subcategory>.<key>}}            # scalar field
    {{vocab:vm.<category>.<subcategory>.<key>.<render>}}   # inside SQL, typed renderer
    {{vocab:vm.<category>.<subcategory>.<key>.lookup[<alias>.<column>]}}
                                                          # a key-map indexed per row

The path segments mirror the real `VocabularyEntry` fields (agent-builder
vocabulary_registry.py): vm (domain) · category · subcategory · key. This module:

  1. EXTRACTS every placeholder across a template's artifacts (fields + SQL bodies),
     resolving the qualified path to the BARE key for the resolve-and-gate call.
  2. RENDERS resolved values back into the artifacts — a TYPED renderer per render
     verb, never blind string interpolation (§ 3.6 SQL-injection safety). SQL renders
     consume the render-ready `expanded` list from resolve-and-gate (B1), so this
     module never needs the ordered domain (which lives single-source in agent-builder).

The renderer is PURE: no DB, no LLM, no I/O. Given a template's artifacts + the
`resolve-and-gate` response, it returns concrete artifacts ready for the materializer.
A render failure (unknown verb, missing value, non-scalar where scalar expected) raises
`VocabRenderError` — creation fails clean BEFORE any artifact is written.
"""

import json
import re
from typing import Any, Dict, List, Optional, Tuple


class VocabRenderError(ValueError):
    """A placeholder could not be rendered — fail-fast, name the gap (§ 3.6/§ 3.8)."""


#: Matches {{vocab:vm.<category>.<subcategory>.<key>[.<render>]}}. The dotted path is
#: captured whole (group 1); the extractor/renderer split it into (qualified_path, key,
#: render). The render verb, when present, is the LAST dotted segment and names a typed
#: renderer below. Whitespace inside the braces is tolerated.
#:
#: Group 2 is the ROW EXPRESSION of the one indexed verb, `lookup`:
#:
#:     {{vocab:vm.remediation.sla_windows.sla_window_by_severity.lookup[v.severity]}}
#:
#: ⛔ The index is a COLUMN REFERENCE, never an arbitrary expression: one to three
#: dot-separated SQL identifiers (`severity`, `v.severity`, `s.v.severity`). It is
#: author text copied into the SQL, so the grammar is kept to the one shape that cannot
#: carry an operator, a quote or a subquery. Anything else does not match here, is left
#: in the string, and `_render_string` refuses it by name (`_LOOSE_PLACEHOLDER_RE`).
_PLACEHOLDER_RE = re.compile(
    r"\{\{\s*vocab:([a-z0-9_.]+?)"
    r"(?:\[\s*([A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*){0,2})\s*\])?"
    r"\s*\}\}",
    re.IGNORECASE,
)

#: A `{{vocab:…[…]…}}` — an ATTEMPTED index, well-formed or not. After substitution a
#: surviving match is an index `_PLACEHOLDER_RE` refused (an operator, a quote, a
#: subquery). It is refused by name rather than left in the SQL, where it would surface
#: later as a Postgres syntax error with nothing pointing back at the placeholder.
#: ⚠️ Deliberately limited to the bracketed form: a non-indexed malformed placeholder
#: keeps its pre-existing behaviour (left as text), so no input that rendered before the
#: `lookup` verb renders differently now.
_LOOSE_PLACEHOLDER_RE = re.compile(r"\{\{\s*vocab:[^}\[]*\[[^}]*\}\}", re.IGNORECASE)

#: Render verbs that operate on SQL (consume the `expanded` list or a typed scalar).
#: A verb NOT in here is treated as a scalar substitution (no render suffix).
_SQL_RENDER_VERBS = frozenset({
    "at_or_above", "case_order", "not_in", "in", "gte", "lte", "gt", "lt", "eq", "flag",
    "lookup", "json_literal", "is_default",
})

#: The verbs that take a `[<row expression>]` index. Exactly these REQUIRE one, and no
#: other verb accepts one.
_INDEXED_VERBS = frozenset({"lookup"})

#: ⭐ THE VERB CONTRACT (#218) — verb → what it emits → the SQL construct you must wrap it in.
#:
#: Each verb emits a FRAGMENT, never a complete expression: the author writes the surrounding
#: construct. That is deliberate (one verb serves `IN`, `NOT IN`, `FILTER (WHERE …)`, a CASE
#: body, …), but it was undiscoverable — the emitted shape could only be learned by authoring
#: SQL, failing validate, and reading the Postgres error. This table is the answer, and
#: `VERB_CONTRACT` below is the machine-readable copy the error messages quote, so the mapping
#: can never drift from the renderer.
#:
#:   verb          emits                                  write it as
#:   ───────────   ────────────────────────────────────   ─────────────────────────────────────
#:   at_or_above   'A', 'B', 'C'      (bare member list)   severity IN ({{…at_or_above}})
#:   in            'A', 'B'           (bare member list)   severity IN ({{…in}})
#:   not_in        'A', 'B'           (bare member list)   severity NOT IN ({{…not_in}})
#:   case_order    WHEN 'A' THEN 1 … ELSE 4                CASE severity {{…case_order}} END
#:   gte/lte/…     >= 30              (operator + value)   age_days {{…gte}}
#:   flag          AND TRUE  (or empty)                    …on its own line in a WHERE
#:   lookup[x.c]   (CASE x.c WHEN 'K' THEN v … ELSE NULL   wherever a VALUE goes:
#:                  END)  — a whole expression, per row    ({{…lookup[v.severity]}})::int
#:   json_literal  '<json>'::jsonb  (a whole expression)    wherever a jsonb value goes
#:   is_default    TRUE | FALSE                            wherever a boolean goes
#:   (no verb)     the bare value                          a scalar literal; a map or list
#:                                                         inside quotes is refused
#:
#: `lookup` is the one verb that emits a complete expression rather than a fragment: it
#: indexes a KEY-MAP value (e.g. `sla_window_by_severity`) by a column of the current row.
#: A key absent from the map, or a NULL column, yields NULL. The CASE arms follow the
#: map's own key order and the whole CASE is parenthesised, so it composes inside any
#: arithmetic or cast. (It is the successor of the retired VM-catalog binder's
#: `{{key[t.column]}}` hole, and renders byte-identically to it.)
#:
#: ⛔ A bare member list is NOT an array literal. `= ANY(…)` and `UNNEST(…)` both require an
#: array and will NOT accept it — use `IN (…)`, or `ARRAY[{{…}}]` if you genuinely need an
#: array. `_assert_wrapping_construct` below catches exactly that misuse at render time and
#: names the correct idiom, instead of letting it surface later as a Postgres syntax error.
VERB_CONTRACT: Dict[str, Dict[str, str]] = {
    "at_or_above": {"emits": "'A', 'B', 'C' (bare quoted member list)",
                    "use_as": "<col> IN ({{...at_or_above}})"},
    "in":          {"emits": "'A', 'B' (bare quoted member list)",
                    "use_as": "<col> IN ({{...in}})"},
    "not_in":      {"emits": "'A', 'B' (bare quoted member list)",
                    "use_as": "<col> NOT IN ({{...not_in}})"},
    "case_order":  {"emits": "WHEN 'A' THEN 1 ... ELSE N (CASE body, no CASE/END; ranks only "
                             "the values at or above the floor, all others share the ELSE rank)",
                    "use_as": "CASE <col> {{...case_order}} END"},
    "gte":         {"emits": ">= <number>", "use_as": "<col> {{...gte}}"},
    "lte":         {"emits": "<= <number>", "use_as": "<col> {{...lte}}"},
    "gt":          {"emits": "> <number>",  "use_as": "<col> {{...gt}}"},
    "lt":          {"emits": "< <number>",  "use_as": "<col> {{...lt}}"},
    "eq":          {"emits": "= <number>",  "use_as": "<col> {{...eq}}"},
    "flag":        {"emits": "AND TRUE when on, empty when off",
                    "use_as": "on its own line inside a WHERE clause"},
    "lookup":      {"emits": "(CASE <col> WHEN 'K1' THEN v1 ... ELSE NULL END) "
                             "(a complete expression; a key-map indexed per row)",
                    "use_as": "({{...lookup[<alias>.<column>]}})::int — wherever a value goes"},
    "json_literal": {"emits": "'<json>'::jsonb (a complete expression; strings escaped so no "
                              "Jinja delimiter or quote can survive)",
                     "use_as": "{{...json_literal}} wherever a jsonb value goes; "
                               "({{...json_literal}})::text for display"},
    "is_default":  {"emits": "TRUE when the key's value is the registry default, else FALSE",
                    "use_as": "wherever a boolean goes: CASE WHEN {{...is_default}} THEN …"},
}

#: Constructs that need an ARRAY and therefore CANNOT consume a bare member list. Matched
#: against the text immediately preceding a list-verb placeholder.
_ARRAY_ONLY_CONSTRUCT_RE = re.compile(
    r"(=\s*ANY\s*\(|<>\s*ANY\s*\(|!=\s*ANY\s*\(|\bALL\s*\(|\bUNNEST\s*\()\s*$",
    re.IGNORECASE,
)


def _split_placeholder(path: str) -> Tuple[str, Optional[str]]:
    """Split a captured `vm.cat.subcat.key[.render]` path into (bare_key, render_verb).

    The bare KEY is the segment BEFORE a trailing render verb (if the last segment is a
    known SQL render verb), else the last segment. Everything before the key is the
    qualifier (vm.category.subcategory) — carried for CI validation (§ 3.15), not for
    resolution (resolve-and-gate takes the bare key).

    Examples:
      vm.prioritization.severity_thresholds.severity_floor.at_or_above
        -> ("severity_floor", "at_or_above")
      vm.prioritization.scope_gates.reachability_required
        -> ("reachability_required", None)
    """
    segs = path.split(".")
    if len(segs) < 2:
        raise VocabRenderError(
            f"vocab placeholder '{path}' is not domain-qualified — expected "
            f"vm.<category>.<subcategory>.<key>[.<render>]"
        )
    if segs[-1] in _SQL_RENDER_VERBS:
        if len(segs) < 3:
            raise VocabRenderError(
                f"vocab placeholder '{path}' has a render verb but no key path"
            )
        return segs[-2], segs[-1]
    return segs[-1], None


def _walk_strings(obj: Any):
    """Yield (container, key_or_index, string_value) for every string in a nested
    dict/list — so the extractor and renderer visit the SAME positions (incl. SQL)."""
    if isinstance(obj, dict):
        for k, v in obj.items():
            if isinstance(v, str):
                yield obj, k, v
            elif isinstance(v, (dict, list)):
                yield from _walk_strings(v)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            if isinstance(v, str):
                yield obj, i, v
            elif isinstance(v, (dict, list)):
                yield from _walk_strings(v)


def validate_vocabulary_references(
    artifacts: List[Dict[str, Any]],
    legal_keys: Optional[Any] = None,
    legal_verbs_by_key: Optional[Dict[str, List[str]]] = None,
) -> List[str]:
    """Offline ∈-registry gate — every {{vocab:...}} placeholder names a REAL key with a
    LEGAL render verb (§ 3.6). Returns a list of human-readable error strings (empty = clean).

    The closed key set + legal verbs come from the GENERATED allowlist
    (`vocabulary_keys.py`, emitted from the agent-builder registry by
    scripts/generate_vocabulary_catalog.py). program-framework cannot import the
    registry directly, so this snapshot is the only offline source. Used by the
    BundleValidator's B8 check and the bundle `_self_check`.

    Catches the failure class the exploration flagged: a hand-typed placeholder with a
    typo'd key (`severity_flor`) or a verb its shape doesn't permit (`sla_window_by_severity.gte`)
    used to sail through every offline check and only blow up at install when resolve-and-gate
    could not bind it, taking the whole install down.

    ⛔ THE ALLOWLIST IS A PARAMETER, AND IT IS REQUIRED (TORANA_SPEC_TRACKER § 10a D-11).
    Until 2026-09-28 this function imported `.vocabulary_keys` relative to ITSELF. When the
    renderer moved here from program-framework (2026-09-22), that became
    `pantheon_shared.vocab.vocabulary_keys` — a module that does not exist (the generated
    allowlist is program-framework's `vm_content/vocabulary_keys.py`) — and the `ImportError`
    branch returned `[]`. B8 and the build-v2 deposit gate then passed EVERY placeholder for
    six days, reporting clean. So the caller passes `legal_keys` (the key set) and
    `legal_verbs_by_key`, and a call without them RAISES: a gate that cannot see its allowlist
    must refuse, never report clean. program-framework passes its generated allowlist in
    `vm_content/vocab_render.py`.
    """
    if legal_keys is None or legal_verbs_by_key is None:
        raise VocabRenderError(
            "validate_vocabulary_references needs the vocabulary allowlist "
            "(legal_keys, legal_verbs_by_key) — e.g. program-framework's generated "
            "vm_content/vocabulary_keys.py (LEGAL_VOCAB_KEYS, LEGAL_RENDER_VERBS_BY_KEY). "
            "Without it the check cannot run, and it refuses rather than report clean."
        )
    LEGAL_VOCAB_KEYS = frozenset(legal_keys)
    LEGAL_RENDER_VERBS_BY_KEY = legal_verbs_by_key

    errors: List[str] = []
    seen: set = set()
    for art in artifacts:
        ak = art.get("artifact_key", "?")
        definition = art.get("definition", {})
        for field_path, s in _walk_strings_pathed(definition, "definition"):
            for m in _PLACEHOLDER_RE.finditer(s):
                dedup = (ak, field_path, m.group(0))
                if dedup in seen:
                    continue
                seen.add(dedup)
                try:
                    bare_key, verb = _split_placeholder(m.group(1))
                except VocabRenderError as exc:
                    errors.append(f"artifact '{ak}' ({field_path}): malformed placeholder {m.group(0)} — {exc}")
                    continue
                if bare_key not in LEGAL_VOCAB_KEYS:
                    errors.append(
                        f"artifact '{ak}' ({field_path}): unknown vocab key '{bare_key}' in {m.group(0)} "
                        f"— not in the vocabulary registry (would fail install-time resolve-and-gate)"
                    )
                    continue
                legal = LEGAL_RENDER_VERBS_BY_KEY.get(bare_key, [])
                if verb is not None and verb not in legal:
                    allowed = "/".join(legal) if legal else "(none — bare scalar only)"
                    errors.append(
                        f"artifact '{ak}' ({field_path}): vocab key '{bare_key}' does not permit "
                        f"render verb '.{verb}' in {m.group(0)} — legal verbs: {allowed}"
                    )
    return errors


def extract_vocabulary_keys(artifacts: List[Dict[str, Any]]) -> List[str]:
    """Every BARE vocabulary key referenced across a template's artifacts (§ 3.2 step 2).

    Walks each artifact's `definition` (top-level fields AND nested SQL bodies), parses
    `{{vocab:...}}` placeholders, resolves each qualified path to its bare key, dedupes.
    This is the set sent to resolve-and-gate."""
    keys: List[str] = []
    seen = set()
    for art in artifacts:
        definition = art.get("definition", {})
        for _, _, s in _walk_strings(definition):
            for m in _PLACEHOLDER_RE.finditer(s):
                bare_key, _ = _split_placeholder(m.group(1))
                if bare_key not in seen:
                    seen.add(bare_key)
                    keys.append(bare_key)
    return keys


def _walk_strings_pathed(obj: Any, prefix: str = ""):
    """Like `_walk_strings`, but also yields the dotted FIELD PATH to each string
    (e.g. 'definition.sql', 'definition.widgets.0.sql'). Used by the usage extractor to
    tell an operator WHERE inside an artifact a vocabulary placeholder sits — the
    plain walker discards this."""
    if isinstance(obj, dict):
        for k, v in obj.items():
            path = f"{prefix}.{k}" if prefix else str(k)
            if isinstance(v, str):
                yield path, v
            elif isinstance(v, (dict, list)):
                yield from _walk_strings_pathed(v, path)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            path = f"{prefix}.{i}" if prefix else str(i)
            if isinstance(v, str):
                yield path, v
            elif isinstance(v, (dict, list)):
                yield from _walk_strings_pathed(v, path)


def _snippet_around(s: str, start: int, end: int, pad: int = 40) -> str:
    """A short context window of `s` around the [start:end) placeholder match, with an
    ellipsis when truncated — so the UI can show the placeholder in the SQL/config it lives
    in without dumping the whole string."""
    lo = max(0, start - pad)
    hi = min(len(s), end + pad)
    snippet = s[lo:hi].replace("\n", " ").strip()
    if lo > 0:
        snippet = "…" + snippet
    if hi < len(s):
        snippet = snippet + "…"
    return snippet


def extract_vocabulary_usages(artifacts: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Every OCCURRENCE of a vocabulary placeholder across a bundle/template's artifacts,
    with WHERE and HOW it is used — the data the SA App-Bundles drill-down renders.

    Unlike `extract_vocabulary_keys` (a deduped bare-key set for resolve-and-gate), this
    returns one record PER OCCURRENCE, so the UI can show, per artifact, exactly which
    vocabulary variables it uses, in which field, and via which render verb (the semantic
    use: `case_order` = a severity-ordering CASE, `at_or_above`/`in` = an IN(...) list,
    `gte`/`lte`/... = a comparison, `flag` = a conditional AND, None = a scalar substitution).

    Each record:
      { "key": <bare vocab key>,
        "render": <render verb or None>,
        "artifact_key": <artifact_key>,
        "artifact_type": <transformer|dashboard|kpi|...>,
        "field_path": <dotted path inside definition, e.g. "definition.sql">,
        "snippet": <short context window showing the placeholder in situ>,
        "placeholder": <the full {{vocab:...}} text> }

    Malformed placeholders are skipped (never raises) — this is a read/inspect helper for
    the admin surface, not the install-time gate.
    """
    usages: List[Dict[str, Any]] = []
    for art in artifacts:
        ak = art.get("artifact_key")
        at = art.get("artifact_type")
        definition = art.get("definition", {})
        for field_path, s in _walk_strings_pathed(definition, "definition"):
            for m in _PLACEHOLDER_RE.finditer(s):
                try:
                    bare_key, render = _split_placeholder(m.group(1))
                except VocabRenderError:
                    continue  # inspect helper — skip malformed, don't fail
                usages.append({
                    "key": bare_key,
                    "render": render,
                    "artifact_key": ak,
                    "artifact_type": at,
                    "field_path": field_path,
                    "snippet": _snippet_around(s, m.start(), m.end()),
                    "placeholder": m.group(0),
                })
    return usages


# ---------------------------------------------------------------------------
# Typed SQL renderers (§ 3.6) — each VALIDATES then quotes; never blind interpolation.
# Inputs come from resolve-and-gate: `value` is the bound scalar, `expanded` is the
# render-ready list (B1) for ORDERED_ENUM / SELECTOR_LIST shapes.
# ---------------------------------------------------------------------------

def _sql_quote_str(v: str) -> str:
    """Single-quote a SQL string literal, escaping embedded quotes. Values come from
    Spec C's closed grammar, but we quote defensively regardless (§ 3.10)."""
    return "'" + str(v).replace("'", "''") + "'"


def _json_literal_text(value: Any) -> str:
    """JSON text of `value` with every string encoded on its own and its braces escaped.

    `json.dumps(s, ensure_ascii=True)` escapes `"` and every backslash of the value, so the
    `{`/`}` → `\\u007b`/`\\u007d` replacement inside one already-encoded string can never
    combine with a character of the value. Outside strings a brace cannot start a Jinja
    delimiter, so `{{`, `{%` and `{#` cannot appear in the rendered text (DS2 § 3.3.11a).
    """
    if isinstance(value, str):
        enc = json.dumps(value, ensure_ascii=True)
        return enc.replace("{", "\\u007b").replace("}", "\\u007d")
    if isinstance(value, dict):
        return "{" + ", ".join(f"{_json_literal_text(str(k))}: {_json_literal_text(v)}"
                               for k, v in sorted(value.items(), key=lambda kv: str(kv[0]))) + "}"
    if isinstance(value, (list, tuple)):
        return "[" + ", ".join(_json_literal_text(v) for v in value) + "]"
    return json.dumps(value)


def _unsafe_in_quotes(text: str) -> bool:
    """True when bare JSON text could close a surrounding SQL quote or start a Jinja delimiter."""
    return "'" in text or "{{" in text or "{%" in text or "{#" in text


def render_json_literal(value: Any) -> str:
    """`'<json>'::jsonb` — a complete SQL expression for a policy value."""
    return "'" + _json_literal_text(value).replace("'", "''") + "'::jsonb"


def _resolve_list(key: str, verb: str, value: Any, expanded: Optional[List[str]]) -> List[str]:
    """The member list for a list-render verb. Prefers `expanded` (ORDERED_ENUM at-or-above
    prefix, from resolve-and-gate B1); falls back to `value` when the bound value is ALREADY a
    list (SELECTOR_LIST — the value IS the set).

    An EMPTY resolved list is a LEGITIMATE, common value — it is the conservative default for
    `asset_exclusions` ([] = exclude nothing) and any tenant that hasn't set a selector. Returning
    `[]` here (rather than raising) lets `render_sql_verb` emit a direction-aware empty-set sentinel
    so the surrounding `IN (…)` / `NOT IN (…)` stays valid SQL (see render_sql_verb). Only a NON-list
    value (e.g. a bare scalar mis-used with a list verb) is a real error."""
    if expanded:
        return list(expanded)
    if isinstance(value, (list, tuple)):
        return list(value)          # may be [] — that is valid (empty set); handled by caller
    if value is None:
        return []                   # unresolved-to-null selector → empty set
    raise VocabRenderError(
        f"vocab key '{key}' render '{verb}' expects a list value, got a non-list {value!r}"
    )


def _render_number(key: str, value: Any) -> str:
    """Render a numeric scalar as a bare SQL literal (validated numeric)."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        try:
            value = float(value)
        except (TypeError, ValueError):
            raise VocabRenderError(
                f"vocab key '{key}' expects a numeric value, got {value!r}"
            )
    # int stays int; float stays float — no quoting (numeric literal).
    return str(value)


def _render_map_literal(key: str, v: Any) -> str:
    """One CASE-arm value of a `lookup`. Typed: a bool is TRUE/FALSE, a number is a bare
    literal, a string is quoted, None is NULL. A nested list/dict has no scalar SQL form
    and is refused."""
    if v is None:
        return "NULL"
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    if isinstance(v, (int, float)):
        return str(v)
    if isinstance(v, str):
        return _sql_quote_str(v)
    raise VocabRenderError(
        f"vocab key '{key}' render 'lookup': map value {v!r} is not a scalar, so it has "
        f"no SQL literal form"
    )


def _render_lookup(key: str, value: Any, index_expr: Optional[str]) -> str:
    """`key.lookup[<col>]` → `(CASE <col> WHEN 'K' THEN v … ELSE NULL END)`.

    ⛔ FAILS CLOSED. A non-map value, an empty map or a missing index raises — there is
    no executable CASE without a WHEN, and guessing one would render a policy the tenant
    never stated. `index_expr` has already been restricted to column-reference grammar
    by `_PLACEHOLDER_RE`; it is re-checked here because `render_sql_verb` is public.
    """
    if not index_expr:
        raise VocabRenderError(
            f"vocab key '{key}' render 'lookup' needs a row expression: write "
            f"{{{{vocab:….{key}.lookup[<alias>.<column>]}}}}"
        )
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*){0,2}", index_expr):
        raise VocabRenderError(
            f"vocab key '{key}' render 'lookup': index {index_expr!r} is not a column "
            f"reference (one to three dot-separated identifiers)"
        )
    if not isinstance(value, dict):
        raise VocabRenderError(
            f"vocab key '{key}' render 'lookup' expects a key-map value, got {value!r}"
        )
    if not value:
        raise VocabRenderError(
            f"vocab key '{key}' render 'lookup': the map is EMPTY, and a CASE with no WHEN "
            f"is not valid SQL. Set a value for the key; nothing was rendered."
        )
    whens = " ".join(
        f"WHEN {_sql_quote_str(k)} THEN {_render_map_literal(key, v)}"
        for k, v in value.items()
    )
    return f"(CASE {index_expr} {whens} ELSE NULL END)"


def render_sql_verb(key: str, verb: str, value: Any, expanded: Optional[List[str]],
                    index_expr: Optional[str] = None) -> str:
    """Render one `key.verb` placeholder to a SQL fragment. TYPED per verb.

    `index_expr` is the `[<row expression>]` of an indexed verb (`lookup`); it is
    refused for every other verb."""
    if verb in _INDEXED_VERBS:
        return _render_lookup(key, value, index_expr)
    if index_expr is not None:
        raise VocabRenderError(
            f"vocab key '{key}' render '{verb}' does not take an index "
            f"[{index_expr}]; only {sorted(_INDEXED_VERBS)} do"
        )
    if verb == "at_or_above" or verb == "in" or verb == "not_in":
        # Emit ONLY the quoted, comma-separated members — the caller writes the wrapping
        # `IN ( … )` / `NOT IN ( … )`. (`CASE <col> {{…case_order}} END`; `IN ({{…in}})`.)
        members = _resolve_list(key, verb, value, expanded)
        if not members:
            # EMPTY SET — a valid, common value (e.g. asset_exclusions=[] = exclude nothing). We must
            # still emit members so the surrounding IN(...) / NOT IN(...) is valid SQL, with the
            # DIRECTION-CORRECT semantics:
            #   • not_in  (exclusion): empty = exclude nothing = match ALL rows. `NOT IN ('')` excludes
            #     only the empty string, which no real value equals → excludes nothing. ✓
            #   • in / at_or_above (inclusion): empty = include nothing = match NO rows. `IN (NULL)`
            #     is never true in SQL (NULL comparison) → matches nothing. ✓
            return "''" if verb == "not_in" else "NULL"
        return ", ".join(_sql_quote_str(m) for m in members)
    if verb == "case_order":
        # Emit ONLY the WHEN…THEN… clauses (+ ELSE), NOT a wrapping CASE/END. The caller
        # writes `CASE <col> {{…case_order}} END`, so the renderer fills the ordering body.
        members = _resolve_list(key, verb, value, expanded)
        if not members:
            # No ordering members → every value falls to the ELSE tier. `CASE <col> ELSE 1 END`
            # is valid SQL (all rows tier 1). Emit just the ELSE.
            return "ELSE 1"
        whens = " ".join(
            f"WHEN {_sql_quote_str(m)} THEN {i + 1}" for i, m in enumerate(members)
        )
        return f"{whens} ELSE {len(members) + 1}"
    if verb in ("gte", "lte", "gt", "lt", "eq"):
        op = {"gte": ">=", "lte": "<=", "gt": ">", "lt": "<", "eq": "="}[verb]
        return f"{op} {_render_number(key, value)}"
    if verb == "flag":
        # BOOL gate placed STANDALONE in a WHERE (the caller writes it on its own line as an
        # optional gate). The vocab entry does not carry the column the gate reads, so the
        # renderer cannot synthesize a `<col> = true` predicate. Contract: `flag` emits a
        # WHERE-safe no-op — an appended `AND TRUE` when the gate is ON (documents intent,
        # never narrows), and empty when OFF. A template that needs a REAL column gate must
        # inline it as `AND <col> = {{…flag}}` (which would use a scalar render, not this).
        truthy = value is True or str(value).lower() in ("true", "1", "yes")
        return "AND TRUE" if truthy else ""
    # Name the whole contract, not just the rejection — the emitted shape of every verb is
    # otherwise undiscoverable without triggering a failure (#218).
    known = "; ".join(
        f"{v}: emits {c['emits']} → use as `{c['use_as']}`"
        for v, c in VERB_CONTRACT.items()
    )
    raise VocabRenderError(
        f"unknown SQL render verb '{verb}' for vocab key '{key}'. Known verbs — {known}"
    )


def _render_scalar(key: str, value: Any) -> str:
    """Render a bare (verb-less) placeholder to its literal substitution.

    Two cases:
      • Scalars (str / int / float / bool) — direct typed substitution, the raw value as a
        string. Used for non-SQL fields (e.g. a rule's `severity`) and inline scalar literals.
      • Dicts / lists (KEY_MAP / SCOPE_MAP resolved values consumed bare as data) — serialized
        as **valid JSON** (double-quoted) so the result drops cleanly into a `'…'::jsonb` literal
        or a JSON config field. `str(value)` was WRONG here: it emitted Python repr with single
        quotes (`{'High': 30}`), which is invalid JSON and collides with SQL single-quoted string
        literals. `json.dumps` yields `{"High": 30}`.
    """
    if value is None:
        # A null-resolving key (e.g. an unset tenant knob, or a KEY_MAP with no configured value)
        # cannot be a bare literal. The author must reference it another way (policy_basis) or the
        # tenant must set it. Message names the remedy so the failure is self-explanatory.
        raise VocabRenderError(
            f"vocab key '{key}' resolved to null but is used as a bare scalar/data literal — "
            f"this key is unset for the tenant. Reference it by policy key (not as a literal), "
            f"or set a tenant value. See the render-safety flag in `vm policy vocabulary-browse`."
        )
    if isinstance(value, (dict, list)):
        # Deterministic key order so the rendered SQL is stable across turns/workers.
        return json.dumps(value, sort_keys=True)
    return str(value)


def render_artifacts(
    artifacts: List[Dict[str, Any]],
    bound: Dict[str, Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Substitute resolved vocabulary into every artifact placeholder (§ 3.6, step 4).

    `bound` maps bare key -> {"value": <scalar>, "expanded": <list|None>}, built from
    the resolve-and-gate response (§ 3.5). Returns NEW artifact dicts (originals
    untouched — templates are frozen). Raises VocabRenderError on any unrenderable
    placeholder BEFORE returning, so a failure aborts creation with nothing written.
    """
    import copy

    rendered: List[Dict[str, Any]] = []
    for art in artifacts:
        art_copy = copy.deepcopy(art)
        definition = art_copy.get("definition", {})
        for container, ckey, s in _walk_strings(definition):
            new_s = _render_string(s, bound)
            if new_s != s:
                container[ckey] = new_s
        rendered.append(art_copy)
    return rendered


def _assert_wrapping_construct(s: str, start: int, key: str, verb: str) -> None:
    """Refuse a list verb placed in a construct that needs an ARRAY, not a member list (#218).

    `at_or_above` / `in` / `not_in` emit `'A', 'B', 'C'` — valid inside `IN (…)`, but NOT
    inside `= ANY(…)` or `UNNEST(…)`, which require an array literal. Left alone, that
    mistake surfaces much later as a Postgres syntax error against fully-rendered SQL, where
    the placeholder is gone and nothing points back at the verb. Catching it here — with the
    correct idiom named — turns a debugging session into a one-line correction, which matters
    because there is otherwise no way to learn a verb's emitted shape short of triggering the
    failure.
    """
    # ⛔ QUOTED PLACEHOLDER — refuse it HERE, with the idiom named.
    # A list verb already emits its OWN quotes (`'A', 'B', 'C'`), so wrapping the
    # placeholder in quotes yields `IN (''A', 'B', 'C'')` and Postgres fails with
    # `syntax error at or near "A"` — against FULLY-RENDERED SQL, where the placeholder
    # is gone and nothing points back at the quotes. Same reasoning as the array check
    # below: catch it while the placeholder is still visible.
    #
    # ⚠️ MEASURED 2026-09-06 on Classie. Once the cook prompt was fixed to bind
    # placeholders at all, the authoring agent's FIRST mistake was to quote them —
    # `severity IN ('{{vocab:….at_or_above}}')` — twice in a row, across a prompt
    # revision that named the error explicitly. A gate that states the fix beats another
    # paragraph of prompt the model may not follow.
    # ⚠️ `start` is the placeholder's OWN start offset, so the text after it begins with
    # `{{`. Skip past the placeholder to see what FOLLOWS it — an earlier version looked
    # at `s[start:]` and so never saw the closing quote, and the guard never fired.
    _end = s.find("}}", start)
    _after = s[_end + 2:] if _end != -1 else ""
    _quote_before = s[:start].rstrip().endswith(("'", '"'))
    _quote_after = _after.lstrip().startswith(("'", '"'))
    if _quote_before and _quote_after:
        contract = VERB_CONTRACT.get(verb, {})
        raise VocabRenderError(
            f"vocab key '{key}' render '{verb}' is wrapped in quotes. It emits "
            f"{contract.get('emits', 'a bare member list')} — its OWN quoting — so "
            f"`IN ('{{{{vocab:….{verb}}}}}')` renders as `IN (''A', 'B'')`, which is a "
            f"syntax error. Drop the surrounding quotes: write "
            f"`{contract.get('use_as', '<col> IN ({{...}})')}`."
        )

    if not _ARRAY_ONLY_CONSTRUCT_RE.search(s[:start]):
        return
    construct = _ARRAY_ONLY_CONSTRUCT_RE.search(s[:start]).group(1).strip()
    contract = VERB_CONTRACT.get(verb, {})
    raise VocabRenderError(
        f"vocab key '{key}' render '{verb}' emits {contract.get('emits', 'a bare member list')}, "
        f"which is not valid inside `{construct}…)` — that construct needs an ARRAY literal. "
        f"Write it as `{contract.get('use_as', '<col> IN ({{...}})')}`, or use "
        f"`ARRAY[{{{{vocab:….{verb}}}}}]` if an array is genuinely required."
    )


def _render_string(s: str, bound: Dict[str, Dict[str, Any]]) -> str:
    """Replace all placeholders in one string with their rendered SQL/scalar."""
    def _sub(m: re.Match) -> str:
        bare_key, verb = _split_placeholder(m.group(1))
        index_expr = m.group(2)
        if index_expr is not None and verb not in _INDEXED_VERBS:
            raise VocabRenderError(
                f"vocab placeholder {m.group(0)} carries an index but its verb is "
                f"{verb!r}; only {sorted(_INDEXED_VERBS)} take one"
            )
        if verb in ("at_or_above", "in", "not_in"):
            _assert_wrapping_construct(s, m.start(), bare_key, verb)
        entry = bound.get(bare_key)
        if entry is None:
            raise VocabRenderError(
                f"vocab key '{bare_key}' referenced by a placeholder was not resolved "
                f"(missing from resolve-and-gate bound_values)"
            )
        value = entry.get("value")
        expanded = entry.get("expanded")
        if verb == "json_literal":
            return render_json_literal(value)
        if verb == "is_default":
            if "default_in_effect" not in entry:
                raise VocabRenderError(
                    f"vocab key '{bare_key}' render 'is_default': the bound value does not say "
                    f"whether it is the default (no default_in_effect); nothing was rendered")
            return "TRUE" if entry["default_in_effect"] else "FALSE"
        if verb is None:
            if (isinstance(value, (dict, list)) and s[:m.start()].rstrip().endswith("'")
                    and _unsafe_in_quotes(json.dumps(value, sort_keys=True))):
                # A map placed inside quotes is safe only while its text cannot close the
                # quote or open a Jinja delimiter; a tenant value that could is refused
                # (benign values keep rendering byte-identically to before).
                raise VocabRenderError(
                    f"vocab key '{bare_key}': render map/list keys with .json_literal, not "
                    f"inside quotes")
            return _render_scalar(bare_key, value)
        return render_sql_verb(bare_key, verb, value, expanded, index_expr=index_expr)

    out = _PLACEHOLDER_RE.sub(_sub, s)
    leftover = _LOOSE_PLACEHOLDER_RE.search(out)
    if leftover:
        raise VocabRenderError(
            f"malformed indexed vocab placeholder {leftover.group(0)} — the index must be "
            f"a column reference: {{{{vocab:….<key>.lookup[<alias>.<column>]}}}}"
        )
    return out
