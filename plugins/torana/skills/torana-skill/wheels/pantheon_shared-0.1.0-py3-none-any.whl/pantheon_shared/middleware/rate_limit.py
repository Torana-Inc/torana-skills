"""Token-bucket rate-limit middleware for Pantheon services.

Configuration via ``RATE_LIMIT_RULES`` environment variable (JSON):

    RATE_LIMIT_RULES='{"default": {"capacity": 100, "refill_rate": 10.0}}'

Each bucket key is an arbitrary string (e.g. ``"tenant:<id>:user:<id>"``).
``refill_rate`` is expressed in tokens-per-second.

Usage::

    from pantheon_shared.middleware.rate_limit import TokenBucket

    bucket = TokenBucket("tenant:abc:user:xyz")
    allowed, retry_after = bucket.consume()
    if not allowed:
        raise HTTPException(status_code=429, headers={"Retry-After": str(retry_after)},
                            detail={"error_code": "refresh_rate_limited"})
"""

import json
import os
import time
from dataclasses import dataclass, field
from threading import Lock
from typing import Optional


def _load_rules() -> dict:
    raw = os.environ.get("RATE_LIMIT_RULES", "{}")
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {}


_DEFAULTS = {"capacity": 100, "refill_rate": 10.0}


@dataclass
class _BucketState:
    tokens: float
    last_refill: float = field(default_factory=time.monotonic)


class TokenBucket:
    """Thread-safe token-bucket rate-limiter keyed on an arbitrary string.

    Args:
        key:         Unique string identifying this bucket (e.g. tenant+user).
        capacity:    Maximum tokens the bucket can hold.  If *None* the value
                     from ``RATE_LIMIT_RULES`` (key ``"default".capacity``) is
                     used, falling back to 100.
        refill_rate: Tokens added per second.  If *None* the value from
                     ``RATE_LIMIT_RULES`` (key ``"default".refill_rate``) is
                     used, falling back to 10.0.
    """

    # Module-level registry so multiple callsites sharing the same key share
    # the same bucket state.
    _registry: dict[str, "_BucketState"] = {}
    _registry_lock: Lock = Lock()

    def __init__(
        self,
        key: str,
        capacity: Optional[float] = None,
        refill_rate: Optional[float] = None,
    ) -> None:
        rules = _load_rules()
        rule = rules.get(key, rules.get("default", {}))
        self.key = key
        self.capacity = float(capacity if capacity is not None else rule.get("capacity", _DEFAULTS["capacity"]))
        self.refill_rate = float(refill_rate if refill_rate is not None else rule.get("refill_rate", _DEFAULTS["refill_rate"]))

        with self._registry_lock:
            if key not in self._registry:
                self._registry[key] = _BucketState(tokens=self.capacity)

    def consume(self, tokens: float = 1.0) -> tuple[bool, Optional[int]]:
        """Try to consume *tokens* from the bucket.

        Returns:
            ``(allowed, retry_after_seconds)`` — if *allowed* is ``True``,
            ``retry_after_seconds`` is ``None``.  If *allowed* is ``False``,
            ``retry_after_seconds`` is the integer number of seconds until
            the next token becomes available.
        """
        with self._registry_lock:
            state = self._registry[self.key]
            now = time.monotonic()
            elapsed = now - state.last_refill
            state.tokens = min(self.capacity, state.tokens + elapsed * self.refill_rate)
            state.last_refill = now

            if state.tokens >= tokens:
                state.tokens -= tokens
                return True, None

            deficit = tokens - state.tokens
            retry_after = int(deficit / self.refill_rate) + 1
            return False, retry_after

    @classmethod
    def reset(cls, key: str) -> None:
        """Remove a bucket from the registry (test helper)."""
        with cls._registry_lock:
            cls._registry.pop(key, None)
