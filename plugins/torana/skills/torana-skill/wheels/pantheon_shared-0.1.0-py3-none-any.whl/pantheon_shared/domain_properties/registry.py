"""Domain Property Registry — the semantic-plane contract (Spec G § 3.3.1).

WHAT THIS IS
------------
The platform governs three planes. Two already have a contract:

  * the DATA plane      — ETL mappings + sink schema (pantheon-integration)
  * the POLICY plane    — `vocabulary_registry.py` (Spec C): what a domain WORD
                          means and what this tenant ratified for it
  * the SEMANTIC plane  — **this registry**: which decoration PROPERTIES entities
                          must carry, which single column holds each, who may
                          supply it, how it propagates, and how covered it is

Before this registry existed, semantic-plane expectations lived only as implicit
reads buried in bundle SQL. Nothing declared that `assets.asset_team` had to be
supplied by anyone — so nothing did (0 writers platform-wide), and five CISO
widgets rendered `no_data` on 80,899 real vulnerabilities. Worse, the write side
had standardized on `assets.public_access` while every reader used
`assets.publicly_accessible` — two real columns, one concept, zero arbitration.

DESIGN MIRRORS THE VOCABULARY REGISTRY (deliberately)
-----------------------------------------------------
Entries are code-registered, platform-authored, tenant-neutral, version
controlled, and reviewed in a PR. Adding a property needs NO migration. Only
per-tenant VALUES are data (`entity_properties_resolved` in the lake). This is
the same shape as `vm_policy/vocabulary_registry.py` and
`context_lake/preference_registry.py`, so nobody has to learn a third pattern.

THE FOUR PROVENANCE CLASSES
---------------------------
`provenance_class` is the property's PRIMARY (authoritative) birth mode. It
decides which machinery owns materialization, and — when a property is empty —
where the fix goes:

  OBSERVED   the source emits it. Materializes in an ETL mapping `derive`.
             Empty => the data genuinely does not exist yet. NOT fixable in
             code; report it honestly (coverage) instead of faking a value.
  DECLARED   a human asserts it for THIS entity at a boundary (the Deployments
             form). Stamped onto entity rows by the repaint + the resolution
             builder. Empty => a human has not declared it; the UI must say so.
  POLICY     a human stated a RULE, in PROSE, that assigns the value to MANY
             entities ("database findings go to the platform team"). Extracted
             from a policy document onto the closed vocabulary and bound, then
             applied by the resolution builder's selector match. NOT a DSL — the
             tenant never writes a selector; {selector: target} is the
             extractor's OUTPUT shape. Ranks BELOW DECLARED (a rule is less
             specific than an assertion about one entity) and ABOVE a derived
             guess. Empty => the tenant has not stated such a rule, OR stated one
             the vocabulary cannot express (see Spec H "read but not applied").
  COMPUTED   policy x observed data. Materializes at TRANSFORM time (never
             stamped at ingest) so a policy edit re-judges every row on the
             next materialization instead of leaving stale stamps behind.
             Empty => nobody built the computation.
  PROPAGATED inherited over entity-graph edges (e.g. an `image:` inherits its
             `service:`'s governance via `deployed_as`). Materializes in the
             resolution builder's edge walk. Empty => nobody walked the edges.

`supply_chain` may MIX classes even though `provenance_class` is single-valued:
`public_access` is DECLARED-primary (the human's checkbox is authoritative) but
also accepts OBSERVED corroboration (k8s topology actually seeing a
LoadBalancer), merged per `conflict_rule`. Class answers "where does the fix
go?"; supply chain answers "what is allowed to fill it, in what order?".

THE SUPPLY SIDE — WHO IS ALLOWED TO FILL A PROPERTY
----------------------------------------------------
Each `supply_chain` entry names a SOURCE. The sources themselves are enumerated
as `SupplySource` records in `vm.py` (`SUPPLY_SOURCES`) — the source-side census
that answers "where do these values actually come from, and what does each one
contribute?" without reverse-engineering it from mappings. `validate_registry()`
asserts every supply_chain entry names a known source id, so the census cannot
silently drift from the chains that reference it.

ADDING A NEW SUPPLY SOURCE (read this before you touch a supply_chain)
-----------------------------------------------------------------------
!! A `supply_chain` string is DOCUMENTATION. Nothing parses it. !!

The ResolutionBuilder does not read these strings — it has hand-written reads
(`_service_assets`, `_edges`, `_repo_owners` in
`torana_mesh/services/property_resolution.py`) and hand-written precedence. So
appending "wiz.exposure" to a supply chain changes NOTHING at runtime; the entry
reads as if a source exists that does not. That is the same honest-emptiness
failure this whole registry exists to prevent — do not reintroduce it one layer
up. Wiring a new source takes all five steps:

  1. `SUPPLY_SOURCES` in `vm.py` — add the source (id, nature, system, writes,
     anchor). This is the census, not the wiring.
  2. The property's `supply_chain` — insert the source id at the right
     PRECEDENCE position (first wins; later entries fill only what is NULL).
  3. The materializer — teach the code that actually writes the value:
       * DECLARED at the deployment boundary -> `_governance_columns()` in
         `deployment_repaint.py` AND the resolver's seed step;
       * OBSERVED from a sync -> the ETL mapping `derive` for that source;
       * PROPAGATED -> the edge walk in `property_resolution.py`;
       * COMPUTED -> the consuming transformer SQL (never at ingest).
  4. `conflict_rule` — a second supplier means a possible disagreement. State
     who wins. For SECURITY properties prefer the unsafe-biased merge (OR, max),
     never "latest wins": a stale "not public" must not be able to hide an
     observed LoadBalancer.
  5. A test proving the new source actually lands a value
     (`pantheon-tests`, `DISABLE_CLEANUP=true`).

Skip step 3 and the entry is a lie that reviews well. Skip step 4 and you have
last-writer-wins, silently.

WHAT QUALIFIES — the admission criterion
----------------------------------------
Before this was written down, entries were added only AFTER something broke, and
nobody could say whether a given column belonged. The rule, ratified 2026-08-03:

  A column belongs in this registry if its value CANNOT BE DERIVED FROM THE
  ARTIFACT ITSELF. That happens in exactly two ways:

    HUMAN JUDGEMENT   no scanner can emit it, because it is an assertion about
                      consequence or org structure rather than an observation.
                      `asset_team` (cloud carries no team label), `criticality_name`
                      (how much this matters if it breaks), `has_customer_data`.

    ARBITRATION       more than one real column claims the same concept, so a
                      canonical one must be named or writers and readers drift
                      apart. `public_access` vs `publicly_accessible` — the split
                      that created this registry.

  A column a scanner emits ABOUT THE THING IT SCANNED is NOT governance:
  `severity`, `cvss_base_score`, `cloud_region` fill themselves, one column holds
  them, they reach every row. Neither is a derived roll-up
  (`vm_critical_vulnerability_count`) or a tool's confidence in its own output.

HOW THE RULE WAS TESTED (do not weaken it without re-testing)
-------------------------------------------------------------
Applied blind to 93 candidate columns found by name-matching across all 16 sink
schemas: 91 of 93 sorted cleanly (97%), against a >=90% bar. The load-bearing
result is the CONTROL — the criterion independently called 7 of 7 ALREADY-REGISTERED
`assets` columns `governance`, with no reference to this file. It reproduces the
judgement that produced the existing entries, which is stronger evidence than the
sort rate alone.

The 2 that would not sort were both `business_metadata` (on `datastores` and
`artifacts`) — free-form bags whose SHAPE must be decided before any verdict is
possible. That is a real limit of the rule, not a failure of it.

Corpus and full per-column reasoning:
`pantheon-datalake/docs/corpus/governance_candidates.csv`.

THE LARGEST OPEN GAP (measured by the same pass)
------------------------------------------------
`datastores` carries 33 candidate columns and ZERO entries here — including FOUR
columns all claiming internet exposure (`publicly_accessible`, `public_read_access`,
`public_write_access`, `exposed_to_internet`) and FOUR claiming ownership (`owner`,
`data_owner`, `data_steward`, `business_contact`). That is the `public_access`
split-brain repeating, unarbitrated, in the most governance-dense table in the lake.
Arbitration costs one PR while a single writer exists; once three integrations each
populate a different column it costs forensics.

HOW TO ADD A PROPERTY
---------------------
1. Add a `PropertyEntry` to `vm.py` (key, entity, column, meaning,
   provenance_class, supply_chain, propagation, consumed_by, conflict_rule).
2. `key` MUST equal the canonical column's bare name so the CI contract check
   can bind reads/writes to it unambiguously.
3. That's it — coverage reporting, the CI lint, the resolution builder, and the
   install-time gate all iterate this registry. No DB migration.

RETIRING A PROPERTY (the delete path)
-------------------------------------
DO NOT delete the entry. A hard delete orphans any tenant rows and — worse for
this registry — silently disarms the CI lint that keeps a dead column name from
coming back. Instead mark it:

    deprecated=True,
    deprecated_reason="Superseded by public_access (2026-07-25).",
    superseded_by="public_access",

A deprecated entry stops being an obligation (`get_registry()` excludes it) but
stays visible to the lint as a FORBIDDEN ALIAS — which is exactly how the
`publicly_accessible` split-brain is prevented from recurring.

DROPPING THE DEAD COLUMN (a SEPARATE, LATER step)
--------------------------------------------------
Deprecating an entry does NOT drop the physical column, and the two must not be
done together. Installed workspaces hold FROZEN copies of transformer SQL
(Spec G § 2.6.1), so a tenant who has not yet upgraded is still running SQL that
selects the dead name. Today that returns NULL — cosmetically wrong, but the
status quo. Drop the column while that SQL is live and every such tenant gets a
hard `column "..." does not exist` error: five quietly-empty widgets become five
broken ones. Additive-first (§ 3.8.1) exists precisely to avoid that window.

The drop is therefore gated on a CHECKABLE precondition, recorded per entry in
`drop_precondition` and flipped via `column_dropped=True` once done:

    1. every consumer in `consumed_by` (plus any scripts) reads the canonical
       name — enforced from then on by the CI lint;
    2. every bundle carrying the old read has had its `version` bumped;
    3. NO installed workspace still holds a frozen transformer selecting the
       dead name (the real gate — check installs, not source);
    4. only then: an Alembic/lake migration drops the column, and the entry
       flips to `column_dropped=True`.

KEEP THE ENTRY EVEN AFTER THE COLUMN IS GONE. `deprecated_aliases()` is what
arms the lint; delete the entry and the dead name becomes free for someone to
reintroduce, which is exactly how the split-brain happened the first time.
`column_dropped=True` tells the coverage reporter to stop querying a column that
no longer exists while the lint keeps guarding the name — forever, and cheaply.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, Iterable, List, Optional


class ProvenanceClass(str, Enum):
    """How a property's value comes into existence (see module docstring)."""

    OBSERVED = "observed"
    DECLARED = "declared"
    POLICY = "policy"
    COMPUTED = "computed"
    PROPAGATED = "propagated"


#: Sink entity families a property may attach to. Kept closed so a typo in
#: `entity` fails the contract check rather than creating an orphan group the
#: coverage report cannot render.
ENTITY_FAMILIES = ("asset", "vulnerability", "repository")


class Severity(str, enum.Enum):
    """The ONE canonical security-severity vocabulary — HOW MUCH HARM IS POSSIBLE.

    Severity answers *"how much harm is possible if this is exploited"*. It is a
    property of the FLAW, is the same everywhere that flaw appears, and is
    **platform-owned** — tenant-neutral, so two customers' data stays comparable.

    ⛔ POLICY MUST NOT INFLUENCE SEVERITY. A tenant re-rating CVE-2026-1234 as
    "Low" because they do not care makes their data incomparable with every other
    tenant's and destroys any cross-tenant benchmark or shared intel. To
    de-prioritise it, use `Priority` — that is exactly what priority is for.

    WORDING — deliberately not "how badly it breaks the system"
    -----------------------------------------------------------
    That phrasing imports a functional-defect frame that does not transfer: a
    leaked secret breaks no functionality, a public S3 bucket breaks nothing, and
    both can be Critical. "How much harm is possible if this is exploited" covers
    functional breakage, data loss and unauthorized access under one idea.

    ⛔ THIS IS NOT A LOG LEVEL. A log-level ``severity: warning`` on an event
    table is a DIFFERENT vocabulary and is out of scope — as is the platform-
    events ``severity: critical`` field. Harm-if-exploited is not log level.
    Do not widen this enum to cover them; that recreates the very conflation
    this vocabulary exists to remove.

    ⚠️ CASE IS TITLE CASE, and it is load-bearing. Every reader already assumes
    it: the detection SQL validator, ``query_service``, the sibling
    ``vulnerability_status`` enum, and the asset-inventory criticality enum.

    ⛔ DECLARED IN THREE PLACES — CHANGE ALL THREE IN LOCKSTEP:
        1. here (the vocabulary of record)
        2. ``torana_mesh/etl/normalize.py::CANONICAL_SEVERITIES`` (the
           alias-folding front door every ingest path funnels through)
        3. ``pantheon-detection-framework .../query_service.py::_SEVERITY_CANONICAL``
           and ``vm_catalog/_vocabulary_snapshot.py`` — neither IMPORTS from
           here, so they will not follow a change made only in this file. Ingest
           and the SQL validator then disagree silently.

    ⚠️ ``Info`` and ``Unknown`` ARE members; ``None`` is NOT. Some older prose
    describes the band as ``Critical|High|Medium|Low|None`` — that was always
    wrong against the shipped normalizer, which emits ``Unknown`` for an
    unrecognised value and returns SQL NULL for a genuinely absent one.
    """

    CRITICAL = "Critical"
    HIGH     = "High"
    MEDIUM   = "Medium"
    LOW      = "Low"
    INFO     = "Info"
    UNKNOWN  = "Unknown"

    @classmethod
    def values(cls) -> List[str]:
        """The wire/storage values, for API enums, CLI choices and FE dropdowns."""
        return [e.value for e in cls]

    @classmethod
    def is_valid(cls, value: Optional[str]) -> bool:
        return value in cls._value2member_map_ if value else False


class Priority(str, enum.Enum):
    """The tenant's answer to HOW URGENTLY MUST WE FIX IT.

    Priority is the counterpart to `Severity` and the two must never be
    conflated:

    ==============  ===================================  =========================
    ..              Severity                             Priority
    ==============  ===================================  =========================
    Question        how much harm is possible            how urgently must we fix
    Scope           the FLAW — same everywhere           the INSTANCE (vuln, asset)
    Owner           ⭐ platform — tenant-neutral          ⭐ tenant — policy decides
    Inputs          impact + exploitability              severity + asset
                                                         criticality + exposure
                                                         + KEV/EPSS
    Changes when    NVD/CNA rescores the flaw            policy or asset context
    ==============  ===================================  =========================

    ⭐ POLICY SHOULD FULLY DETERMINE PRIORITY. That is exactly what priority is:
    the tenant-specific answer. The policy lives in the ``escalation`` category
    of the VM vocabulary registry (``kev_auto_escalate``,
    ``epss_escalate_threshold``, ``internet_facing_escalates``,
    ``customer_data_escalates``, and four more), expressed as toggles and
    thresholds rather than weights.

    WHY WORDS AND NOT ``P0..P4``
    ----------------------------
    Every closed vocabulary this platform ships uses human-readable words; none
    uses coded tiers. Two further reasons decided it:

      * ACCESSIBILITY. A band is rendered as a coloured badge, and the argument
        that P-notation makes a mixed-up column "obvious on sight" is a VISUAL
        argument. ``"P1"`` carries no meaning without the colour; ``"High"`` is
        self-describing. A reader who cannot use the colour has only the label,
        so the label must carry the meaning.
      * The registry rule that a vocabulary starts DELIBERATELY SMALL and grows
        on demand (see `Environment`).

    ⛔ THERE IS NO FIFTH "won't fix / accepted" MEMBER. That is a DISPOSITION,
    not a priority band, and it is already owned by ``is_risk_accepted``,
    ``is_suppressed``, ``business_justification`` and
    ``ResolutionReason.ACCEPTED_RISK`` — each carrying an approval role, a
    compensating control, a 90-day expiry and an audit trail that a bare enum
    member would not. Routing "de-prioritise this" here would create a second,
    weaker path to risk acceptance that ``exclude_risk_accepted`` cannot see.

    ⚠️ DISAMBIGUATION IS CARRIED BY THE COLUMN NAME + ``priority_source``, not by
    the value spelling. The collision risk is real and measured: a Jira mapping
    once fabricated ``findings.severity`` from Jira priority and landed 98
    tickets as ``severity=Critical``. The answer is that the priority column
    records WHY it holds its value, not that the two vocabularies look different.
    """

    CRITICAL = "Critical"
    HIGH     = "High"
    MEDIUM   = "Medium"
    LOW      = "Low"

    @classmethod
    def values(cls) -> List[str]:
        """The wire/storage values, for API enums, CLI choices and FE dropdowns."""
        return [e.value for e in cls]

    @classmethod
    def is_valid(cls, value: Optional[str]) -> bool:
        return value in cls._value2member_map_ if value else False


#: Every real-world priority spelling a tracker emits, mapped to its canonical
#: value. Jira is the only writer of `issues.priority` today and passes its own
#: field names through verbatim — which is why `"Highest"` is live on 98 rows
#: and matches no Torana vocabulary. A rule filtering
#: `priority IN ('Critical','High')` silently drops every one of them.
#:
#: ⚠️ Jira's five-level scale folds onto a four-level one: BOTH `Low` and
#: `Lowest` map to `Low`. That is deliberate — see `Priority`'s note on why
#: there is no fifth member. A "Lowest" ticket that is genuinely not being
#: fixed is a risk-acceptance decision, not a priority band.
_PRIORITY_ALIASES = {
    # Jira (the measured live source)
    "highest": "Critical",
    "high": "High",
    "medium": "Medium",
    "low": "Low",
    "lowest": "Low",
    # Common synonyms
    "critical": "Critical",
    "urgent": "Critical",
    "blocker": "Critical",
    "major": "High",
    "normal": "Medium",
    "moderate": "Medium",
    "minor": "Low",
    "trivial": "Low",
    # ServiceNow ("1 - Critical") and bare numeric tiers. `0` and `1` both mean
    # "most urgent": P0-style scales are 0-based, ServiceNow's is 1-based, and
    # collapsing them here is what lets one vocabulary serve both.
    "1 - critical": "Critical",
    "2 - high": "High",
    "3 - moderate": "Medium",
    "4 - low": "Low",
    "5 - planning": "Low",
    "p0": "Critical",
    "p1": "High",
    "p2": "Medium",
    "p3": "Low",
    "p4": "Low",
    "0": "Critical",
    "1": "Critical",
    "2": "High",
    "3": "Medium",
    "4": "Low",
    "5": "Low",
}


def normalize_priority(value: Any) -> Optional[str]:
    """Coerce any tracker's priority spelling to the ONE canonical value.

    Mirrors ``normalize_severity``'s contract exactly, because a second
    normalizer with different edge-case behaviour is how the two vocabularies
    drift apart:

      * ``None`` / empty  -> ``None``. A genuinely-absent priority stays SQL NULL
        rather than becoming ``"Medium"`` noise. ⛔ Never default an absent
        priority to a middle band — that fabricates a tenant decision nobody made.
      * unrecognised       -> ``"Medium"``, never an exception. A normalizer that
        raises turns one novel spelling into a failed sync for the whole batch.

    ⚠️ The unrecognised fallback differs from ``normalize_severity``'s, and the
    difference is deliberate. Severity has an ``Unknown`` member because "we do
    not know how bad this flaw is" is a true and useful statement. `Priority`
    has no such member: every instance HAS an urgency once policy is applied, so
    the honest fallback is the middle band plus a ``priority_source`` that says
    the value was not derived from policy.
    """
    if value is None:
        return None
    key = str(value).strip().lower()
    if not key:
        return None
    return _PRIORITY_ALIASES.get(key, Priority.MEDIUM.value)


@dataclass(frozen=True)
class SupplySource:
    """One system that is allowed to fill domain properties — the SUPPLY side.

    `PropertyEntry` answers "what must this entity carry?". `SupplySource`
    answers the question you hit next: "who is allowed to fill it, what is that
    system, and what does it contribute?" Before this existed the answer could
    only be reconstructed by grepping mappings and reading supply_chain prose.

    Census only — declaring a source here wires NOTHING. See "ADDING A NEW
    SUPPLY SOURCE" in the module docstring for the five steps that do.
    """

    id: str
    """Stable short id referenced from `PropertyEntry.supply_chain` (validated:
    an unknown id fails `validate_registry()`)."""

    nature: "ProvenanceClass"
    """How this source comes by its values. DECLARED sources need a human;
    OBSERVED ones need the source system to actually emit the field."""

    system: str
    """Owning service + storage, e.g.
    ``"pantheon-integration :: deployments (Alembic, service-owned)"``.
    Says WHICH PLANE — service DB vs datalake sink — which decides how any
    other service is allowed to read it."""

    writes: tuple = ()
    """Field names this source contributes, in ITS OWN vocabulary (e.g. the
    deployment's ``internet_facing``, which lands in ``assets.public_access``).
    Deliberately source-side names — the property key is the destination."""

    anchor: str = ""
    """file:line of the code that actually reads/writes it. The thing a future
    session needs and a prose doc always loses."""

    notes: str = ""
    """Caveats: reach limits, gaps, why the precedence is what it is."""


def get_supply_sources() -> List[SupplySource]:
    """The supply-source census (VM content). Deferred import per the
    machinery/content split — see `get_registry`."""
    from pantheon_shared.domain_properties.vm import SUPPLY_SOURCES

    return list(SUPPLY_SOURCES)


def get_supply_source(source_id: str) -> Optional[SupplySource]:
    """One source by id, or None."""
    return next((s for s in get_supply_sources() if s.id == source_id), None)


class Environment(str, enum.Enum):
    """The platform's closed vocabulary for deployment environments.

    WHY THIS EXISTS
    ---------------
    `deployments.env_label` was free text doing two incompatible jobs at once:

      * IDENTITY — it is passed to ``service_key(env_label, name)``, producing
        ``service:production/pantheon-nginx``. Changing it is a primary-key
        change requiring a drop-and-resync, so it can never be normalised in
        place.
      * FILTERING — consumers ask "is this production?", which needs a stable
        CLASS, not a label.

    With free text those diverge silently. A tenant wrote ``prod``; four
    CISO-posture filters tested ``= 'production'``; the widget read 0 while
    4,633 qualifying vulnerabilities sat behind it — no error, because a column
    compared to a literal that never occurs simply matches nothing.

    A closed vocabulary chosen at deployment time removes the class of bug
    rather than one instance of it: identity and filtering read the SAME value,
    so they cannot drift. This mirrors `criticality`, which has been a closed
    set (low|medium|high|critical) all along — environment was the only
    governance property left as free text, which is why it was the one that
    broke.

    DELIBERATELY SMALL
    ------------------
    Three values, not an exhaustive taxonomy. `test`, `sandbox`, `qa`,
    `pre-prod` and friends are all defensible, and each one added now would be a
    guess about a tenant we have not met. Adding a member later is additive and
    safe; removing one after tenants have selected it is not. Start where the
    evidence is and grow on demand.
    """

    PRODUCTION  = "production"
    STAGING     = "staging"
    DEVELOPMENT = "development"

    @classmethod
    def values(cls) -> List[str]:
        """The wire/storage values, for API enums, CLI choices and FE dropdowns.

        One source of truth: a surface that hardcodes its own list is how the
        three drift apart again.
        """
        return [e.value for e in cls]

    @classmethod
    def is_valid(cls, value: Optional[str]) -> bool:
        return value in cls._value2member_map_ if value else False


@dataclass(frozen=True)
class PropertyEntry:
    """One canonical decoration property — the registry entry shape (§ 3.3.1)."""

    key: str
    """Canonical property name. MUST equal the bare column name in `column`
    (the CI check binds reads/writes by this name)."""

    entity: str
    """Sink entity family — one of ENTITY_FAMILIES."""

    column: str
    """THE one canonical column, as ``table.column``. This single field is what
    makes a split-brain (two columns, one concept) impossible to ship: the
    registry names exactly one, and the CI lint rejects the rest.

    COMPUTED properties may have no physical column; they use the sentinel form
    ``(computed in <where>)`` and are excluded from column-coverage queries."""

    meaning: str
    """Human semantics — what a value of this property asserts. A SENTENCE; see `label`
    for the noun phrase a tenant reads as the row's name."""

    provenance_class: ProvenanceClass
    """PRIMARY birth mode; decides which machinery materializes it."""

    supply_chain: List[str] = field(default_factory=list)
    """Ordered sources, FIRST WINS; later entries only fill what is still NULL.
    This is the declared, reviewable form of what used to be an unauditable
    ``COALESCE(...)`` buried inside bundle SQL. Entries are human-readable
    source descriptions — PROSE, parsed by nothing (see "ADDING A NEW SUPPLY
    SOURCE" in the module docstring). `sources` is the machine-checkable
    counterpart; keep the two in the SAME ORDER."""

    sources: tuple = ()
    """`SupplySource.id`s backing `supply_chain`, in the same precedence order.
    Machine-checkable: `validate_registry()` rejects an unknown id and a
    length mismatch against `supply_chain`, so the census cannot drift from the
    chains that cite it. Empty is legitimate for a dead alias (nothing supplies
    it) — that emptiness is the assertion."""

    propagation: Optional[str] = None
    """Edge walk that carries the value to inheriting entities, e.g.
    ``"service --deployed_as--> image (max wins)"``. None = does not propagate."""

    consumed_by: List[str] = field(default_factory=list)
    """Bundles / transformers / scripts that READ this property. Load-bearing:
    the install-time coverage gate uses this to decide which properties to
    measure for a bundle, because the installer cannot reach the
    transformer-materialization catalog in another service's DB."""

    label: str = ""
    """The noun phrase a tenant reads as the row's name (Spec H § 3.14.1).

    `meaning` is a SENTENCE and cannot serve as a label — rendering it where a name belongs
    prints prose in a table cell. The page previously showed the raw `key` (`asset_team`) and
    the storage path (`assets.asset_team`): it named the fact twice in machine terms and defined
    it zero times (Round-3 W3-8).

    A label is a NOUN PHRASE — never a sentence, never a column name, and never uses
    "property", "decoration", "entity", "resolved" or "column". Empty is legal only for entries
    a tenant never sees (deprecated aliases, numeric mirrors).
    """

    user_facing: bool = True
    """Render this as a FACT a tenant governs (Spec H § 3.5.0a).

    False for a stored-twice mirror — `criticality_level` is the numeric form of
    `criticality_name`, one fact the lake keeps in two columns for query
    convenience. Showing both would ask a tenant to govern "Business criticality"
    AND "Business criticality (numeric)" as separate things, which is our storage
    model leaking into their mental model. The API still returns every entry;
    only the tenant panel folds these in.
    """

    scope: str = "entity"
    """Whether this property describes an ENTITY (shared across domains) or is owned by
    ONE domain (Spec H § 3.10.3, § 4.8.1).

    "entity" — a fact about the entity itself (team, owner, criticality, exposure). Every
    domain that touches that entity consumes it, so it belongs on the platform-level
    Context/Policy page. This is the default because it is the common case.

    "domain" — meaningless outside one domain (`is_sla_breached` only means something to
    vulnerability management). These leave the tenant Level-2 page and live with their
    domain's workspace; they remain fully visible via the API, CLI and SA views.

    The test that decides: *would a second domain need this same fact about this same
    entity?* Yes -> entity. No -> domain.
    """

    domain: Optional[str] = None
    """Owning domain slug for `scope="domain"` entries (e.g. "vm"); None for entity-scoped.

    Free-form by design — there is no domain enum until a second domain exists, and
    inventing one now would be the premature abstraction Spec G's discipline warns against.
    Rendered on `/properties` and as the CLI `list` DOMAIN column, so the field has a
    reader the day it lands.
    """

    allowed_values: tuple = ()
    """Closed vocabulary for this property, or empty when the value is free text.

    Declared HERE so every surface derives its choices from one place: the API
    validator, the `torana` CLI's option choices, and the FE dropdown. A surface
    that hardcodes its own copy is exactly how a tenant ends up storing `prod`
    while a filter looks for `production`.

    Empty is a real assertion, not an omission: it says the value is genuinely
    open (an owner's name, a team) and consumers must not assume a fixed set.
    """

    consequences: Dict[str, str] = field(default_factory=dict)
    """`{domain_slug: what breaks if this value is wrong}` — Spec H § 3.13.5.

    Answers the tenant's real question about a shared fact: *why does governing this matter?*
    NOT derivable from anything — `consumed_by` names the BUNDLE that reads a property and says
    nothing about consequence, so this is authored copy, one clause per consuming domain.

    Write NAMED OUTCOMES, not mechanism: "SOC alerts route to the wrong on-call" (a tenant
    understands a broken pager), never "the ownership edge is unresolved" (a tenant does not
    understand a graph). Keys are domain slugs, so `len(consequences)` IS the consumers count
    the L1 row renders — one field serves both devices and they cannot drift apart.
    """

    composed_of: List[Dict[str, str]] = field(default_factory=list)
    """For a COMPUTED property: the inputs it is built from, in tenant language.

    `[{"input": "when it was found", "source_kind": "observed"},
      {"input": "your remediation window", "source_kind": "policy",
       "policy_key": "sla_window_by_severity"}]`

    WHY AUTHORED, NOT PARSED. `supply_chain` already carries the formula — but as ENGINEERING
    prose (`"COMPUTED: scan_first_detected_date + sla_window_by_severity[severity] < NOW()"`),
    and this module's own docstring states that a supply_chain string is DOCUMENTATION that
    nothing parses. Deriving tenant copy from it would both violate that contract and print
    column names at a reader.

    WHY IT MATTERS: when a computed value is wrong, the tenant must know WHICH INPUT to fix.
    A flat row cannot say that; "Past SLA = when it was found + your remediation window" can,
    and each input links to where it is governed (`policy_key` names the vocabulary key when
    the input is a policy value).
    """

    coverage_obligation: bool = True
    """Include in the per-tenant coverage report. False only for properties
    whose emptiness is meaningless to a tenant."""

    policy_keys: List[str] = field(default_factory=list)
    """Vocabulary keys whose BOUND value may supply this property (Spec H § 3.3.3).

    Empty = no tenant policy may decorate it. A key here is a CLAIM that the
    resolution builder reads that binding — validated by the CI contract check, so
    a typo cannot silently no-op. Precedence is fixed by `supply_chain`, not by
    this list: policy fills only what a per-entity assertion left unset.
    """

    conflict_rule: Optional[str] = None
    """How to merge when several sources (or several deployments) supply a
    value. Required whenever `propagation` is set, since inheritance is exactly
    where conflicts arise."""

    # --- Retirement (see "RETIRING A PROPERTY" in the module docstring) ------
    deprecated: bool = False
    deprecated_reason: str = ""
    superseded_by: Optional[str] = None

    # --- Physical drop (see "DROPPING THE DEAD COLUMN") ----------------------
    column_dropped: bool = False
    """True once the physical column no longer exists. The ENTRY stays forever
    (it arms the lint against the name coming back); this flag tells the
    coverage reporter to stop querying a column that is gone."""

    drop_precondition: str = ""
    """For a deprecated-but-still-present column: the checkable condition that
    must hold before the drop migration is written. Records WHY the column is
    still there, so the next session neither drops it early nor re-derives the
    reasoning. Empty once `column_dropped=True`."""

    @property
    def table(self) -> Optional[str]:
        """Sink table of `column`, or None for a COMPUTED sentinel."""
        if self.is_computed_sentinel:
            return None
        return self.column.split(".", 1)[0]

    @property
    def column_name(self) -> Optional[str]:
        """Bare column name of `column`, or None for a COMPUTED sentinel."""
        if self.is_computed_sentinel:
            return None
        parts = self.column.split(".", 1)
        return parts[1] if len(parts) == 2 else None

    @property
    def is_computed_sentinel(self) -> bool:
        """True when the property has no physical column (COMPUTED at transform
        time). Such entries are skipped by column-coverage queries and by the
        mapping-target lint, which have nothing to bind to."""
        return self.column.strip().startswith("(")


def get_registry(include_deprecated: bool = False) -> List[PropertyEntry]:
    """The ACTIVE property registry (deprecated entries excluded by default).

    Import is deferred so `registry.py` (machinery) carries no dependency on
    `vm.py` (content) at module load — the same split the vocabulary registry
    uses, which keeps the machinery domain-neutral for a future second domain.
    """
    from pantheon_shared.domain_properties.vm import VM_PROPERTIES

    if include_deprecated:
        return list(VM_PROPERTIES)
    return [p for p in VM_PROPERTIES if not p.deprecated]


def get_property(key: str, include_deprecated: bool = False) -> Optional[PropertyEntry]:
    """One entry by key, or None."""
    return next(
        (p for p in get_registry(include_deprecated=include_deprecated) if p.key == key),
        None,
    )


def properties_for_entity(entity: str) -> List[PropertyEntry]:
    """Active entries attached to one entity family (e.g. ``"asset"``)."""
    return [p for p in get_registry() if p.entity == entity]


# ---------------------------------------------------------------------------
# Closed-vocabulary enforcement
# ---------------------------------------------------------------------------
#
# WHY THESE LIVE HERE AND NOT ON EACH SURFACE
# -------------------------------------------
# `allowed_values` was declarative-only: the registry stated the vocabulary and
# every surface RESTATED it. `env_label` shipped that way — the API derived its
# enum from `Environment`, the CLI kept a hardcoded fallback list, and the FE
# hardcoded a third copy. Three literals for one vocabulary is the same shape as
# the bug the vocabulary was introduced to fix (a value stored as `prod` while
# the filter tested `production`); it just moves the drift from data to code.
#
# So the registry does the deciding. A surface asks "is this legal?" and renders
# choices from `allowed_values` — it never holds a list. Adding a closed-set
# property then costs one `allowed_values=` line and no new validation code,
# which is the property that makes `criticality` a data change rather than a
# fourth hand-written copy.
#
# NOT ENFORCED WHERE THERE IS NO VOCABULARY. An entry with empty
# `allowed_values` is open by design (free-text `owner`, `team`), so
# `validate_value` passes it. Silence means "not a closed set", never
# "closed set with nothing in it" — that distinction is what lets these be
# called unconditionally from a generic write path.


class PropertyValueError(ValueError):
    """A value is outside a property's declared `allowed_values`.

    Carries the parts a caller needs to build its own error shape (FastAPI 422,
    a CLI message) without re-deriving them: `key`, `value`, `allowed`.
    """

    def __init__(self, key: str, value: Any, allowed: tuple) -> None:
        self.key = key
        self.value = value
        self.allowed = allowed
        super().__init__(
            f"{key}: {value!r} is not one of "
            + ", ".join(repr(a) for a in allowed)
        )


def resolve_property_key(key: str) -> Optional[str]:
    """Map a WRITER's field name to the registry key it supplies, if any.

    A property is governed at the registry key (``asset_environment``) but
    written at a source's own column name (``deployments.env_label``). Both are
    the same vocabulary at two layers, and a validator that only knew the
    registry key would silently pass the very payload that needs checking —
    which is exactly how `env_label` shipped as free text while
    `asset_environment` was declared closed.

    Rather than a second alias map to keep in sync, this reads the link the
    registry ALREADY declares: `SupplySource.writes` names each source's fields,
    and the property's `supply_chain` names ``"<source>.<field>"``. So the
    mapping is derived, and a new writer is wired by declaring it once.

    Returns the registry key, `key` itself when it IS a registry key, or None.
    """
    if get_property(key) is not None:
        return key
    needle = f".{key}"
    for entry in get_registry():
        for supplier in entry.supply_chain:
            # supply_chain items look like "deployment.env_label" (and may carry
            # a trailing annotation, hence endswith on the whole token).
            token = supplier.split()[0] if supplier else ""
            if token.endswith(needle):
                return entry.key
    return None


def allowed_values_for(key: str) -> tuple:
    """The closed vocabulary for `key`, or ``()`` when it is not a closed set.

    The single source every surface reads: API enum, CLI choices, FE dropdown.
    Accepts either a registry key or a writer's field name (see
    `resolve_property_key`). An unknown key returns ``()`` rather than raising —
    callers iterate a heterogeneous payload and must not need to know which
    fields are governed.
    """
    resolved = resolve_property_key(key)
    entry = get_property(resolved) if resolved else None
    return tuple(entry.allowed_values) if entry else ()


def validate_value(key: str, value: Any, *, required: bool = False) -> None:
    """Raise `PropertyValueError` if `value` is outside `key`'s vocabulary.

    Passes when the property is not a closed set, or when `value` is None/absent
    and `required` is False — an update that omits a field must not be forced to
    resupply it. Pass ``required=True`` on a create path where the field must be
    present and legal.
    """
    allowed = allowed_values_for(key)
    if not allowed:
        return
    if value is None or value == "":
        if required:
            raise PropertyValueError(key, value, allowed)
        return
    if value not in allowed:
        raise PropertyValueError(key, value, allowed)


def validate_values(payload: Dict[str, Any], *, required: Iterable[str] = ()) -> None:
    """Validate every governed key present in `payload`, in registry order.

    The generic hook for a service-layer write: hand it the dict about to be
    persisted and any keys that must be present. Ungoverned keys are ignored, so
    it is safe to call on a whole request body. Raises on the FIRST offending
    key — callers surface one actionable error rather than a list the user must
    fix serially anyway.
    """
    required_set = set(required)
    for key, value in payload.items():
        validate_value(key, value, required=key in required_set)
    # A required key absent from the payload entirely is still a violation —
    # the loop above only sees keys that ARE present.
    for key in required_set - set(payload):
        validate_value(key, None, required=True)


def properties_consumed_by(consumer: str) -> List[PropertyEntry]:
    """Active entries whose `consumed_by` names this consumer.

    Matching is a case-insensitive substring test on each `consumed_by` item so
    a bundle id (``"ciso_posture"``) matches an annotated entry
    (``"ciso_posture (owning_team)"``). Used by the install-time coverage gate.
    """
    needle = consumer.strip().lower()
    if not needle:
        return []
    return [
        p for p in get_registry()
        if any(needle in c.lower() for c in p.consumed_by)
    ]


def deprecated_aliases() -> Dict[str, str]:
    """``{dead_column_name: canonical_key}`` for every deprecated entry that
    names a `superseded_by`.

    This is the CI contract check's forbidden list: any ETL mapping target or
    bundle SQL read of a dead column name (scoped to its table) fails the build.
    It is the mechanism that stops the `publicly_accessible` split-brain — and
    any future one — from being reintroduced after cleanup.
    """
    out: Dict[str, str] = {}
    for p in get_registry(include_deprecated=True):
        if p.deprecated and p.superseded_by and p.column_name:
            out[p.column_name] = p.superseded_by
    return out


def validate_registry() -> List[str]:
    """Self-check the registry's internal consistency; return error strings.

    Run by the CI contract check BEFORE it lints mappings/bundles, so a typo in
    the registry itself surfaces as a registry error rather than as a confusing
    cascade of false lint hits.
    """
    errors: List[str] = []
    seen: Dict[str, PropertyEntry] = {}
    canonical_columns: Dict[str, str] = {}

    # Supply-source census, checked first so rule 7 can bind against it.
    sources = get_supply_sources()
    known_sources = {s.id for s in sources}
    if len(known_sources) != len(sources):
        errors.append("duplicate id in SUPPLY_SOURCES")
    for s in sources:
        if not s.anchor:
            errors.append(f"supply source '{s.id}': no code anchor (file:line)")

    for p in get_registry(include_deprecated=True):
        # 1. Unique keys.
        if p.key in seen:
            errors.append(f"duplicate property key '{p.key}'")
        seen[p.key] = p

        # 2. Closed entity vocabulary.
        if p.entity not in ENTITY_FAMILIES:
            errors.append(
                f"'{p.key}': entity '{p.entity}' not in {ENTITY_FAMILIES}"
            )

        # 3. key must match the canonical column's bare name (the CI check
        #    binds reads/writes by key; a mismatch would silently unbind it).
        if not p.is_computed_sentinel:
            if p.column_name is None:
                errors.append(f"'{p.key}': column '{p.column}' is not 'table.column'")
            elif p.column_name != p.key:
                errors.append(
                    f"'{p.key}': key must equal the bare column name, got '{p.column_name}'"
                )

        # 4. ONE canonical column per concept: two ACTIVE entries may not claim
        #    the same table.column — that is the split-brain this registry exists
        #    to prevent, so it must be impossible inside the registry too.
        if not p.deprecated and not p.is_computed_sentinel:
            prior = canonical_columns.get(p.column)
            if prior:
                errors.append(
                    f"'{p.key}' and '{prior}' both claim canonical column '{p.column}'"
                )
            else:
                canonical_columns[p.column] = p.key

        # 5. Propagation implies a conflict rule (inheritance is where
        #    multi-source conflicts arise; an unstated rule is a silent
        #    last-writer-wins).
        if p.propagation and not p.conflict_rule:
            errors.append(f"'{p.key}': propagation set but no conflict_rule")

        # 5b. A property naming policy_keys MUST also list the policy source in its
        #     supply chain, and vice versa (Spec H). Otherwise the entry claims a
        #     tenant rule can supply it while the resolver never reads one — an entry
        #     that reads true and does nothing, the failure this registry prevents.
        _has_policy_source = any("policy" in str(src).lower() for src in p.sources)
        if p.policy_keys and not _has_policy_source:
            errors.append(
                f"'{p.key}': policy_keys set but no policy source in `sources` — "
                f"the resolver would never read the binding")
        if _has_policy_source and not p.policy_keys:
            errors.append(
                f"'{p.key}': names a policy source but no policy_keys — nothing "
                f"says WHICH vocabulary key supplies it")

        #  9. SCOPE/DOMAIN pairing (Spec H § 4.8.1). A domain-scoped property MUST name
        #     its owning domain, and an entity-scoped one MUST NOT — otherwise the
        #     Level-2 page cannot tell shared facts from one domain's private ones.
        if p.scope not in ("entity", "domain"):
            errors.append(
                f"'{p.key}': scope must be \"entity\" or \"domain\", got {p.scope!r}")
        if p.scope == "domain" and not (p.domain or "").strip():
            errors.append(f"'{p.key}': scope=\"domain\" requires a non-empty domain")
        if p.scope == "entity" and p.domain:
            errors.append(f"'{p.key}': scope=\"entity\" must not set domain")

        # 10. CONSEQUENCES (Spec H § 3.13.5). The keys ARE the consumers count the L1 row
        #     renders, so an empty dict silently renders "0 domains" — worse than absent.
        #     A domain-scoped property must at least name its OWN domain.
        # 11. LABEL (Spec H § 3.14.1). A user-facing property with no label renders its raw
        #     key — which is W3-8, the defect the field exists to remove.
        if p.user_facing and not p.deprecated and not (p.label or "").strip():
            errors.append(
                f"'{p.key}': user-facing but no label — the row would render the raw key")
        if (p.label or "").rstrip().endswith("."):
            errors.append(
                f"'{p.key}': label {p.label!r} ends in a period — a label is a NOUN PHRASE, "
                f"not a sentence (that is what `meaning` is for)")

        # 12. COMPOSITION (Spec H § 3.13.9.3). A COMPUTED property whose inputs are not named
        #     leaves a tenant with a wrong number and no idea which input to fix.
        if (p.provenance_class == ProvenanceClass.COMPUTED and p.user_facing
                and not p.deprecated and not p.composed_of):
            errors.append(
                f"'{p.key}': COMPUTED and user-facing but composed_of is empty — a tenant "
                f"cannot tell which input to fix when the value is wrong")
        for _c in (p.composed_of or []):
            if not (_c.get("input") or "").strip():
                errors.append(f"'{p.key}': composed_of entry with no `input` label")

        # A deprecated alias is never rendered (it exists only to arm the CI lint against the
        # dead name returning), so it owes no consequence copy.
        if not p.consequences and not p.deprecated:
            errors.append(
                f"'{p.key}': no consequences authored — the L1 row cannot say why governing "
                f"this matters, and its consumers count would render 0")
        for _dom, _txt in (p.consequences or {}).items():
            if not (_txt or "").strip():
                errors.append(f"'{p.key}': empty consequence text for domain '{_dom}'")
        if p.scope == "domain" and p.domain and p.domain not in (p.consequences or {}):
            errors.append(
                f"'{p.key}': scope=\"domain\" domain='{p.domain}' but no consequence is "
                f"authored for it")

        # 6. Retirement hygiene — a deprecated entry must explain itself.
        if p.deprecated and not p.deprecated_reason:
            errors.append(f"'{p.key}': deprecated but no deprecated_reason")

        # 7. Supply sources must be real and aligned with the prose chain.
        #    This is what stops the census in vm.py from drifting away from the
        #    chains that cite it — the drift a prose-only table always suffers.
        if p.sources:
            for sid in p.sources:
                if sid not in known_sources:
                    errors.append(
                        f"'{p.key}': supply source '{sid}' is not in SUPPLY_SOURCES"
                    )
            if len(p.sources) != len(p.supply_chain):
                errors.append(
                    f"'{p.key}': sources ({len(p.sources)}) and supply_chain "
                    f"({len(p.supply_chain)}) differ in length — they must be "
                    f"the same list in the same precedence order"
                )
        elif p.supply_chain:
            errors.append(
                f"'{p.key}': has supply_chain prose but no `sources` ids — the "
                f"chain is then unverifiable (see ADDING A NEW SUPPLY SOURCE)"
            )

        # 8. Drop-path hygiene. A dead column that is still physically present
        #    must say what gates its removal, or the next session either drops
        #    it early (breaking frozen transformer SQL in installed workspaces)
        #    or leaves it forever because nobody recorded the condition.
        if p.deprecated and not p.column_dropped and not p.is_computed_sentinel:
            if not p.drop_precondition:
                errors.append(
                    f"'{p.key}': deprecated column still present but no "
                    f"drop_precondition (see DROPPING THE DEAD COLUMN)"
                )
        if p.column_dropped and not p.deprecated:
            errors.append(
                f"'{p.key}': column_dropped=True but the entry is not deprecated"
            )
        if p.superseded_by and p.superseded_by not in {
            e.key for e in get_registry(include_deprecated=True)
        }:
            errors.append(
                f"'{p.key}': superseded_by '{p.superseded_by}' is not a registry key"
            )

    return errors
