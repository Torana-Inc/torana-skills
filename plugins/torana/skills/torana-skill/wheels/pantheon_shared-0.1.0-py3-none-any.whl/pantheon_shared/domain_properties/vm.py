"""VM domain property CONTENT — the seed registry (Spec G § 3.3.1).

Machinery lives in `registry.py`; this file is pure content, the same
machinery/content split the vocabulary registry uses. Every entry here was
derived from a MEASURED defect on tenant T1 (2026-07-25) — nine properties that
installed bundles provably consume today, plus one deprecated alias that arms
the CI lint. Same restraint as the vocabulary's 14-variable seed: register what
is provably consumed, grow by PR.

Anchors for the supply chains below (all verified against shipped code):
  * deployment governance model ...... torana_mesh/models/deployment.py:63-90
  * governance stamp (repaint) ....... torana_mesh/services/deployment_repaint.py:50-131
  * k8s sync stamp ................... torana_mesh/mappings/kubernetes/workloads.yaml:91-125
  * k8s topology exposure (GAP-A16) .. torana_mesh/etl/extractors/k8s.py:244-275
  * exposed_via flip (A6) ............ torana_mesh/services/reconciliation.py:6-13
  * declared-manifest exposure ....... torana_mesh/etl/manifest_interpret.py:181-197,290-293
  * GCP LB / public IP exposure ...... torana_mesh/mappings/gcp/forwarding_rules.yaml:48,
                                       torana_mesh/mappings/gcp/public_addresses.yaml:44
  * SLA policy window (vocabulary) ... vm_policy/vocabulary_registry.py:335
                                       (`vm.remediation.sla_windows.sla_window_by_severity`)
"""

from __future__ import annotations

from typing import List

from pantheon_shared.domain_properties.registry import (
    Environment,
    PropertyEntry,
    ProvenanceClass as P,
    SupplySource,
)

# =============================================================================
# SUPPLY SOURCES — the source-side census
# =============================================================================
# Every `supply_chain` entry below names one of these by id (enforced by
# `validate_registry()`). This answers the question the property entries do not:
# *where do these values actually come from?* — without grepping mappings.
#
#   id                nature     plane                       contributes
#   ----------------  ---------  --------------------------  --------------------
#   deployment        DECLARED   service DB (Alembic)        internet_facing,
#                                                            has_customer_data,
#                                                            team, owner,
#                                                            criticality, env_label
#   governance_push   DECLARED   asset_inventory.v1 -> lake  owner_name,
#                                                            criticality_name,
#                                                            environment
#   k8s_topology      OBSERVED   k8s sync -> lake            public_access
#   k8s_manifest      OBSERVED   declared manifests -> lake  public_access
#   gcp_network       OBSERVED   GCP sync -> lake            public_access
#   graph_exposed_via OBSERVED   entity graph (derived)      public_access
#   repo_vcs          OBSERVED   VCS sync -> lake            owner_login
#   scanner_lifecycle OBSERVED   scanner sync -> lake        resolution_date
#   vocab_policy      COMPUTED   vocabulary registry         sla_window_by_severity
#   derived_in_code   COMPUTED   in-process map              criticality_level,
#                                                            image_ownership
#
# !! Listing a source here wires NOTHING. See "ADDING A NEW SUPPLY SOURCE" in
#    registry.py — five steps, of which this census is only the first. !!
# =============================================================================

SUPPLY_SOURCES: List[SupplySource] = [
    SupplySource(
        id="deployment",
        nature=P.DECLARED,
        system="pantheon-integration :: `deployments` table (Alembic, service-owned)",
        writes=("internet_facing", "has_customer_data", "team", "owner",
                "criticality", "env_label"),
        anchor="torana_mesh/models/deployment.py:63-95",
        notes=(
            "A HUMAN types this (API / `torana deployments` / FE governance "
            "form) — no scanner can know an org chart, which is why team is "
            "DECLARED and was empty platform-wide before Spec G. First in every "
            "governance chain: the most specific assertion available. "
            "REACH LIMIT: governs only the `service:` rows matching BOTH "
            "container_cluster_id=cluster_ref AND service_application=env_label "
            "(deployment_repaint.py:111) — MEASURED 29 rows on T1. Everything "
            "beyond that is propagation, not supply. NOTE Deployment.to_dict() "
            "is hand-maintained: a new column needs model + migration + to_dict."
        ),
    ),
    SupplySource(
        id="governance_push",
        nature=P.DECLARED,
        system="`asset_inventory.v1` push -> lake `assets` (asset/assets mapping)",
        writes=("owner_name", "criticality_name", "environment"),
        anchor="torana_mesh/mappings/asset/assets.yaml",
        notes=(
            "The DECLARED door for things you describe rather than observe "
            "(e.g. a repo's criticality), pushed by the torana-asset-inventory "
            "skill. Ranks BELOW `deployment`, which is the more specific "
            "assertion. GAP: `team` is NOT in the v1 governance block yet "
            "(Spec G § 3.9.8, owner Bhakta) — so today only `deployment` "
            "supplies asset_team. Adding it means changing the push CONTRACT "
            "and the skill, not just this registry."
        ),
    ),
    SupplySource(
        id="k8s_topology",
        nature=P.OBSERVED,
        system="pantheon-integration :: k8s ETL extractor -> lake `assets`",
        writes=("public_access",),
        anchor="torana_mesh/etl/extractors/k8s.py:244-275",
        notes=(
            "Per-service exposure derived from REAL topology (LoadBalancer / "
            "Ingress backing, `_exposed_service_names`), per GAP-A16. Observed "
            "truth: this is what keeps a stale 'not public' checkbox from "
            "hiding a live LoadBalancer — hence the OR conflict rule."
        ),
    ),
    SupplySource(
        id="k8s_manifest",
        nature=P.OBSERVED,
        system="pantheon-integration :: declared-manifest interpretation -> lake",
        writes=("public_access",),
        anchor="torana_mesh/etl/manifest_interpret.py:181-197,290-293",
        notes=(
            "Exposure DECLARED in committed manifests (the AG1 declared side) "
            "rather than observed at runtime. Lower confidence than "
            "`k8s_topology`; converges with it on the same entity key."
        ),
    ),
    SupplySource(
        id="gcp_network",
        nature=P.OBSERVED,
        system="pantheon-integration :: GCP ETL mappings -> lake `assets`",
        writes=("public_access",),
        anchor=("torana_mesh/mappings/gcp/forwarding_rules.yaml:48, "
                "torana_mesh/mappings/gcp/public_addresses.yaml:44"),
        notes=(
            "Cloud-side exposure: a forwarding rule or a public address makes "
            "the asset internet-reachable regardless of what k8s reports."
        ),
    ),
    SupplySource(
        id="graph_exposed_via",
        nature=P.OBSERVED,
        system="pantheon-integration :: A6 reconcile pass (entity graph -> lake)",
        writes=("public_access",),
        anchor="torana_mesh/services/reconciliation.py:6-13",
        notes=(
            "Not a sync at all — DERIVED. Builds service --exposed_via--> cloud "
            "edges, then flips assets.public_access=true on any service with an "
            "inbound edge. The one-hop precedent the Spec G resolution builder "
            "generalizes; it runs in the same pass."
        ),
    ),
    SupplySource(
        id="policy_binding",
        nature=P.POLICY,
        system=("pantheon-agent-builder :: `vm_policy_binding` — read via "
                "POST /api/v1/vm/policy/resolve-and-gate over nginx"),
        writes=("ownership_routing", "sla_window_by_severity",
                "criticality_floor_by_data_class", "production_criticality_floor"),
        anchor=("vocabulary_registry.py:352 (ownership_routing); read path mirrors "
                "program-framework/services/vocab_resolution.py:29"),
        notes=(
            "The tenant's WRITTEN policy — prose in a document, extracted onto the "
            "closed vocabulary and bound. NOT a DSL: the tenant never writes a "
            "selector; {selector: target} is the extractor's OUTPUT shape "
            "(extraction_target.py:157). Ranks BELOW deployment/governance_push (a "
            "rule is less specific than an assertion about ONE entity) and ABOVE "
            "repo_vcs (a stated rule beats a derived guess). "
            "TRAP: an unbound key does NOT 404 — resolve-and-gate returns the "
            "conservative default with default_in_effect=true, so the resolver MUST "
            "drop defaulted values or every tenant silently inherits "
            "'_else: unassigned' as though they had authored it."
        ),
    ),
    SupplySource(
        id="repo_vcs",
        nature=P.OBSERVED,
        system="lake `repositories` (VCS sync / torana-asset-inventory)",
        writes=("owner_login",),
        anchor="torana_mesh/services/property_resolution.py :: _repo_owners()",
        notes=(
            "LAST-RESORT team fallback, reached over `builds_image` (repo -> "
            "image) and applied ONLY where asset_team is still NULL. A code "
            "owner is a decent proxy for an owning team, but a much weaker "
            "claim than a governed deployment — hence last."
        ),
    ),
    SupplySource(
        id="scanner_lifecycle",
        nature=P.OBSERVED,
        system="scanner ETL mappings -> lake `vulnerabilities`",
        writes=("vulnerability_resolution_date",),
        anchor="torana_mesh/mappings/snyk/vulnerabilities.yaml",
        notes=(
            "Only snyk writes closure dates today; T1 runs GCP + SARIF, so "
            "MEASURED 0 of 80,899. Genuinely unsuppliable, NOT a wiring bug — "
            "no code can invent closure history. The coverage report saying so "
            "out loud IS the handling (§ 3.6.3)."
        ),
    ),
    SupplySource(
        id="vocab_policy",
        nature=P.COMPUTED,
        system="pantheon-agent-builder :: VM vocabulary registry (Spec C)",
        writes=("sla_window_by_severity",),
        anchor="src/services/vm_policy/vocabulary_registry.py:335",
        notes=(
            "Not a data source — the POLICY input to a computation. Rendered "
            "into foundation SQL as a JSONB literal at transform time, so a "
            "tenant editing an SLA window re-judges all rows on the next "
            "materialization instead of leaving 80k stale ingest stamps. This "
            "is the seam where the policy plane meets the semantic plane."
        ),
    ),
    SupplySource(
        id="derived_in_code",
        nature=P.COMPUTED,
        system="pantheon-integration :: in-process derivation (no external source)",
        writes=("criticality_level", "image_ownership"),
        anchor="torana_mesh/services/deployment_repaint.py:44 (_CRIT_LEVEL)",
        notes=(
            "criticality_level: a pure function of another property "
            "(criticality_name -> 1..4), materialized wherever its parent is. "
            "Exists as a column only so SQL can ORDER BY / MAX() severity of "
            "business criticality. "
            "image_ownership: the DEFAULT under a missing declaration, derived "
            "from inventory backing (an `artifacts` row for the image) at "
            "torana_mesh/services/image_ownership.py. ⛔ It emits only "
            "`first_party` or `undetermined` — never `vendor`/`third_party`, "
            "which only a human can split. Both are total functions of data "
            "already in the lake, so every worker computes the same value."
        ),
    ),
]

#: Shared propagation spec — governance declared on a Deployment lands on its
#: `service:` nodes, and the images those services run inherit it. Written once
#: so every governance property propagates identically.
_SERVICE_TO_IMAGE = "service --deployed_as--> image"

#: Shared conflict rule for the identity-ish governance values (team/owner).
#: An image deployed by two governed services must resolve deterministically.
_MOST_CRITICAL_WINS = (
    "highest-criticality deployment wins; tie -> env_label='production'; "
    "tie -> lexicographic min deployment id"
)


VM_PROPERTIES: List[PropertyEntry] = [
    # ---------------------------------------------------------------- exposure
    PropertyEntry(
        key="public_access",
        label="Internet-facing",
        entity="asset",
        column="assets.public_access",
        meaning="Entity is reachable from the internet.",
        # DECLARED-primary: a human's governance checkbox is authoritative.
        # The chain also admits OBSERVED corroboration (topology actually seeing
        # a LoadBalancer/Ingress) — see the module docstring on mixed chains.
                consequences={
            "exposure_management":
                "internet-facing vulnerabilities stop being escalated, so remote-exploitable findings sit in the normal queue",
        },
        provenance_class=P.DECLARED,
        supply_chain=[
            "deployment.internet_facing (repaint + workloads mapping)",
            "k8s topology derivation (extractors/k8s.py GAP-A16)",
            "reconciliation exposed_via flip (reconciliation.py A6)",
            "declared manifest exposure (manifest_interpret.py)",
            "gcp forwarding_rules / public_addresses mappings",
        ],
        sources=("deployment", "k8s_topology", "graph_exposed_via",
                 "k8s_manifest", "gcp_network"),
        propagation=f"{_SERVICE_TO_IMAGE} (OR)",
        consumed_by=["ciso_posture", "remediation_ops", "threat_intel_priority"],
        # OR, never AND: for a security property a stale "not public" checkbox
        # must never be able to HIDE an observed LoadBalancer.
        conflict_rule="boolean OR across sources and deployments",
    ),
    PropertyEntry(
        key="publicly_accessible",
        entity="asset",
        column="assets.publicly_accessible",
        meaning=(
            "DEAD ALIAS of public_access. Registered solely so the CI contract "
            "check can reject reads/writes of this column name."
        ),
        provenance_class=P.DECLARED,
        supply_chain=[],
        consumed_by=[],
        coverage_obligation=False,
        deprecated=True,
        deprecated_reason=(
            "Split-brain with assets.public_access (Spec G § 2.5.1, § 3.3.4). "
            "MEASURED 2026-07-25 on tenant T1: public_access populated on 29/29 "
            "governed workload rows, publicly_accessible on 0 — it has ZERO "
            "writers platform-wide while public_access has eight live write "
            "paths. Canonical is public_access; the three bundles that read this "
            "name were flipped."
        ),
        superseded_by="public_access",
        # Column still PHYSICALLY PRESENT. See "DROPPING THE DEAD COLUMN" in
        # registry.py for why deprecating and dropping are separate steps.
        column_dropped=False,
        drop_precondition=(
            "Deprecated 2026-07-25; NOT yet droppable. Blocked on installed "
            "workspaces holding FROZEN transformer SQL that still selects this "
            "name (Spec G § 2.6.1) — today that yields NULL (status quo), but "
            "after a DROP it is a hard 'column does not exist' error, turning "
            "quietly-empty widgets into broken ones. Droppable when: (1) all "
            "three bundles + the two agent-builder scripts read public_access "
            "[DONE 2026-07-26, now lint-enforced]; (2) their versions are "
            "bumped [DONE]; (3) NO installed workspace still holds a frozen "
            "transformer selecting `publicly_accessible` — CHECK THE INSTALLS, "
            "not the source; this is the open gate. Then drop the column and "
            "set column_dropped=True, KEEPING this entry so the lint still "
            "guards the name."
        ),
    ),
    PropertyEntry(
        key="has_customer_data",
        label="Holds customer data",
        entity="asset",
        column="assets.has_customer_data",
        meaning="Entity stores or processes customer data.",
                consequences={
            "exposure_management":
                "findings on customer-data systems lose their escalation, and breach-notification scoping starts from the wrong asset list",
        },
        provenance_class=P.DECLARED,
        supply_chain=[
            "deployment.has_customer_data (repaint + workloads mapping)",
            "governance push (asset/assets mapping)",
        ],
        sources=("deployment", "governance_push"),
        propagation=f"{_SERVICE_TO_IMAGE} (OR)",
        consumed_by=["ciso_posture", "remediation_ops"],
        conflict_rule="boolean OR across sources and deployments",
    ),
    # -------------------------------------------------------------- ownership
    PropertyEntry(
        key="asset_team",
        label="Owning team",
        entity="asset",
        column="assets.asset_team",
        meaning="Owning team (organizational unit accountable for remediation).",
        # The property that started Spec G: MEASURED 0 of 1,321 assets populated,
        # ZERO writers anywhere in the platform, and live GCP carries no team
        # label at all (verified against project pantheon-468400). Team is an
        # organizational fact — it can only be DECLARED, never synced.
                consequences={
            "exposure_management":
                "remediation is assigned to nobody and ages in the backlog unowned",
        },
        provenance_class=P.DECLARED,
        supply_chain=[
            "deployment.team",
            "deployment.owner (fallback until team is set)",
            "governance push team field (asset_inventory.v1)",
            "policy rule: ownership_routing selector match (Spec H)",
            "repo owner_login via builds_image edge",
        ],
        # NOTE governance_push cannot supply team yet — `team` is absent from
        # the asset_inventory.v1 contract (§ 3.9.8). Listed at its intended
        # precedence so the gap is visible rather than forgotten.
        sources=("deployment", "deployment", "governance_push",
                 "policy_binding", "repo_vcs"),
        policy_keys=["ownership_routing"],
        propagation=f"{_SERVICE_TO_IMAGE}; repo --builds_image--> image",
        consumed_by=["ciso_posture (owning_team)", "remediation_ops"],
        conflict_rule=_MOST_CRITICAL_WINS,
    ),
    PropertyEntry(
        key="asset_owner",
        label="Accountable owner",
        entity="asset",
        column="assets.asset_owner",
        meaning="Accountable owner (person or org handle) — distinct from the team.",
                consequences={
            "exposure_management":
                "there is no accountable name when remediation stalls, so escalation has nowhere to go",
        },
        provenance_class=P.DECLARED,
        supply_chain=[
            "deployment.owner (repaint + workloads mapping)",
            "governance push owner_name",
        ],
        sources=("deployment", "governance_push"),
        propagation=_SERVICE_TO_IMAGE,
        consumed_by=["ciso_posture"],
        conflict_rule=_MOST_CRITICAL_WINS,
    ),
    PropertyEntry(
        key="image_ownership",
        label="Image ownership",
        entity="asset",
        column="assets.image_ownership",
        meaning=(
            "WHO controls the image this asset runs — and therefore who a vulnerability "
            "in it is addressable to. NOT which registry hosts it: a first-party build "
            "and a mirrored third-party image can sit in the same registry under the "
            "same host."
        ),
        # MEASURED on T2 2026-09-07: 46 distinct running images, 13 backed by an
        # `artifacts` row and 33 not. CAP-17 records the cost of not knowing —
        # 28 of those 46 have no proper home, so their findings either fill a queue
        # nobody can action or vanish from it, and the second is worse because it
        # is invisible.
        consequences={
            "exposure_management":
                "vulnerabilities in vendor-supplied images are routed to a developer who "
                "cannot fix them, or silently dropped — CAP-17, 28 of 46 running images",
        },
        provenance_class=P.DECLARED,
        allowed_values=("first_party", "vendor", "third_party", "undetermined"),
        supply_chain=[
            "tenant declaration (registry -> ownership), authoritative",
            "inventory backing: an `artifacts` row exists for this image "
            "(reconciliation.py:2131 `_supersede_inherited_build_edges`) -> first_party",
        ],
        sources=("governance_push", "derived_in_code"),
        # ⛔ propagation=None ON PURPOSE. `public_access` propagates
        # service --deployed_as--> image because exposure is a property of the
        # DEPLOYMENT. Ownership is a property of the IMAGE itself and is identical
        # wherever it runs, so propagating it would add no information while creating
        # a second path to a value that must have exactly one.
        propagation=None,
        consumed_by=["met_003"],
        # ⚠️ NOT boolean-OR like public_access. That rule is right for exposure, a
        # SAFETY property where the alarming reading should win. Ownership has no safe
        # direction: calling a vendor image first-party creates unfixable work, calling
        # a first-party image vendor hides real work. So the human's statement is
        # authoritative and nothing overrides it — that IS the #374 decision.
        conflict_rule=(
            "DECLARED wins outright. With no declaration, inventory backing yields "
            "`first_party`; its ABSENCE yields `undetermined`, NEVER `vendor`."
        ),
    ),
    # ------------------------------------------------------------ criticality
    PropertyEntry(
        key="criticality_name",
        label="Business criticality",
        entity="asset",
        column="assets.criticality_name",
        meaning="Business criticality label (low|medium|high|critical).",
                consequences={
            "exposure_management":
                "the remediation queue ranks by the wrong business impact — low-criticality work outranks critical systems",
        },
        provenance_class=P.DECLARED,
        supply_chain=[
            "deployment.criticality (repaint + workloads mapping)",
            "governance push criticality_name",
        ],
        sources=("deployment", "governance_push"),
        propagation=f"{_SERVICE_TO_IMAGE} (max by criticality_level)",
        consumed_by=["ciso_posture", "threat_intel_priority"],
        conflict_rule="max criticality_level wins",
    ),
    PropertyEntry(
        key="criticality_level",
        entity="asset",
        column="assets.criticality_level",
        meaning="Numeric mirror of criticality_name (1=low .. 4=critical).",
                consequences={
            "exposure_management":
                "numeric triage ordering silently uses the wrong rank",
        },
        provenance_class=P.COMPUTED,  # Spec H 4.8.1a: derived in code from criticality_name;
        # DECLARED made the tenant panel badge it "YOU SET IT", asserting a human
        # attestation that never happened (Round-2 R2-5a, GRC persona).
        supply_chain=[
            "derived from criticality_name via the _CRIT_LEVEL map "
            "(deployment_repaint.py:44)",
        ],
        sources=("derived_in_code",),
        propagation=f"{_SERVICE_TO_IMAGE} (max)",
        consumed_by=["ciso_posture (triage_priority)"],
        # A numeric mirror of criticality_name — same fact, second column. Folded
        # into its parent row in the tenant panel (Spec H § 3.5.0a).
        user_facing=False,
        conflict_rule="max wins (moves with criticality_name)",
    ),
    # ------------------------------------------------------------ environment
    PropertyEntry(
        key="asset_environment",
        label="Environment",
        entity="asset",
        column="assets.asset_environment",
        meaning="Deployment environment — one of Environment.values().",
        # Closed vocabulary: the API validator, CLI choices and FE dropdown all
        # derive from this, so a tenant cannot store `prod` while a filter looks
        # for `production` (which is exactly what happened).
        allowed_values=tuple(Environment.values()),
        # OBSERVED-primary: unlike team/criticality, cloud sources DO emit this
        # (verified: GCP resources carry an `environment` label).
        consequences={
            "exposure_management":
                "production findings are treated as staging, so SLA windows and escalation thresholds apply the wrong policy",
        },
        provenance_class=P.OBSERVED,
        supply_chain=[
            "source labels / env fields (per-source mappings)",
            "deployment.env_label",
            "governance push environment",
        ],
        sources=("k8s_topology", "deployment", "governance_push"),
        propagation=_SERVICE_TO_IMAGE,
        consumed_by=["ciso_posture", "remediation_ops"],
        conflict_rule="observed source wins; deployment env_label fills when NULL",
    ),
    # --------------------------------------------------- vulnerability-side
    PropertyEntry(
        key="is_sla_breached",
        label="Past SLA",
        entity="vulnerability",
        scope="domain",
        # "exposure_management", not "vm": the customer work-item evidence reclassifies 47
        # items into Exposure Management — VM core (24) plus asset/posture, runtime,
        # supply-chain and system-of-record items from adjacent domains. Roughly half is NOT
        # classic scanner-VM, so "vm" would under-describe the layer on day one and force a
        # rename once a second domain lands. Slug fixed now while it costs two literals.
        domain="exposure_management",
        # COMPUTED at transform time — deliberately NO lake column. Stamping it
        # at ingest would leave 80k stale rows the moment a tenant edits an SLA
        # window; computing it in the foundation SQL re-judges every row on the
        # next materialization.
        column="(computed in foundation SQL — no lake column)",
        meaning="Vulnerability is past its severity SLA window.",
                consequences={
            "exposure_management":
                "overdue counts and SLA-compliance reporting are wrong, and breach escalation never fires",
        },
        composed_of=[
            # Spec H § 3.14.4. In the tenant's words, not the formula's: the engineering form
            # is `scan_first_detected_date + sla_window_by_severity[severity] < NOW()`.
            {"input": "when it was found", "source_kind": "observed"},
            {"input": "your remediation window", "source_kind": "policy",
             "policy_key": "sla_window_by_severity"},
        ],
        provenance_class=P.COMPUTED,
        supply_chain=[
            "vulnerabilities.vulnerability_sla_breach_date when a source supplies it",
            "COMPUTED: scan_first_detected_date + "
            "sla_window_by_severity[severity] < NOW()",
        ],
        sources=("scanner_lifecycle", "vocab_policy"),
        # Per-row arithmetic — nothing to inherit from another entity.
        propagation=None,
        consumed_by=[
            "ciso_posture (overdue_count, sla_compliance_pct)",
            "remediation_ops",
        ],
        # The tenant's own SLA windows drive the breach test — the deadline is
        # policy, not an observation (Spec H § 3.3.3).
        policy_keys=["sla_window_by_severity"],
    ),
    PropertyEntry(
        key="vulnerability_resolution_date",
        label="Date fixed",
        entity="vulnerability",
        scope="domain",
        domain="exposure_management",
        column="vulnerabilities.vulnerability_resolution_date",
        meaning="When the finding was resolved/closed (drives MTTR).",
        # OBSERVED: MEASURED 0 of 80,899 on T1 because every finding is still
        # Open. That is data maturity, NOT a wiring defect — no code can invent
        # closure history. Kept in the registry precisely so the coverage report
        # can say so out loud instead of leaving MTTR silently empty.
                consequences={
            "exposure_management":
                "MTTR cannot be computed, so remediation-velocity reporting is unavailable",
        },
        provenance_class=P.OBSERVED,
        supply_chain=[
            "scanner lifecycle (snyk/vulnerabilities mapping today; other "
            "sources as they begin closing findings)",
        ],
        sources=("scanner_lifecycle",),
        consumed_by=["ciso_posture (MTTR widgets)"],
    ),
]
