"""Domain Property Registry — the semantic-plane contract (Spec G).

Declares which decoration PROPERTIES entities must carry, which single column
holds each, who may supply it, how it propagates over the entity graph, and how
covered it is per tenant. Sibling of the VM vocabulary registry (which governs
policy VALUES) and the preference registry — same code-registered, PR-reviewed,
no-migration lifecycle.

Consumed by three services, which is why it lives here rather than in any one of
them:
  * pantheon-integration      — the resolution builder materializes values
  * pantheon-program-framework— the install coverage gate + the CI contract check
  * the API/CLI surfaces      — browse the registry and per-tenant coverage

See `registry.py`'s module docstring for the four provenance classes and the
add/retire lifecycle.
"""

from pantheon_shared.domain_properties.registry import (
    ENTITY_FAMILIES,
    Environment,
    Priority,
    PropertyEntry,
    PropertyValueError,
    ProvenanceClass,
    Severity,
    SupplySource,
    allowed_values_for,
    deprecated_aliases,
    get_property,
    get_registry,
    get_supply_source,
    get_supply_sources,
    normalize_priority,
    properties_consumed_by,
    properties_for_entity,
    resolve_property_key,
    validate_registry,
    validate_value,
    validate_values,
)
from pantheon_shared.domain_properties.vm import SUPPLY_SOURCES, VM_PROPERTIES

__all__ = [
    "ENTITY_FAMILIES",
    "Environment",
    "Priority",
    "PropertyEntry",
    "PropertyValueError",
    "ProvenanceClass",
    "SUPPLY_SOURCES",
    "Severity",
    "SupplySource",
    "VM_PROPERTIES",
    "allowed_values_for",
    "deprecated_aliases",
    "get_property",
    "get_registry",
    "get_supply_source",
    "get_supply_sources",
    "normalize_priority",
    "properties_consumed_by",
    "properties_for_entity",
    "resolve_property_key",
    "validate_registry",
    "validate_value",
    "validate_values",
]
