"""CLI authorization policy, shared across services.

⭐ WHY THIS IS IN pantheon-shared AND NOT IN ONE SERVICE. Two callers now authorize `torana`
CLI invocations and they MUST agree:

  * pantheon-admin  — authorizes a command STRING before running it in-process (cli_runner).
  * pantheon-agent-builder — the sandbox broker authorizes PARSED ARGV at the egress
    boundary, because a string allowlist cannot survive a shell (`bash -c '...'`, `eval`,
    `$(...)`). See pantheon-agent-builder/docs/streams/STREAM_E_agent_shell.md § 3.2.0.

Both call `get_policy().decide(argv)`. One classification table, two call sites. A copy in
each service would be two tables that drift — the failure this repo has already hit twice
(a stale CLI wheel left admin running an old CLI; duplicated skill text drifted within hours).
"""
from pantheon_shared.cli.policy import (  # noqa: F401
    CommandPolicy,
    Decision,
    get_policy,
    walk_click_tree,
    REASON_ADMIN_SURFACE,
    REASON_DESTRUCTIVE,
    REASON_HUMAN_DEPLOY_GATE,
    REASON_UNCLASSIFIED,
)


def nonget_allowlist():
    """The admitted operations that are NOT GET — the only mutations a broker may forward.

    ⭐ GENERATED, not hand-written: cli_policy's admit set ∩ the API manifest. Of the
    admitted commands the manifest maps, 211 are GET and 9 are not — admitted work is read
    work — so enumerating the 9 exceptions is tractable where enumerating every leaf's
    endpoints was not (measured 25-53% coverage).

    ⚠️ A new admitted non-GET command that is missing here is REFUSED, never admitted. Fail
    closed, and visible as a refusal.
    """
    import json
    import os
    fp = os.path.join(os.path.dirname(os.path.abspath(__file__)), "nonget_allowlist.json")
    with open(fp) as fh:
        return json.load(fh) + _EXPLICIT_NONGET


#: ⛔ HAND-ADDED, because the generator CANNOT reach these — and a hand-added row in the
#: generated JSON would be silently deleted by the next regeneration.
#:
#: `nonget_allowlist.json` is `admit set ∩ api-manifest.yaml`. These three verbs are in the
#: admit set (`_EXPLICIT_READ_PATHS`) but absent from the manifest, which is generated from
#: the OpenAPI spec snapshots in `pantheon-tests/specs/`. Measured 2026-09-20: that snapshot
#: predates them — `policy-template` and `schema/ddl` are missing from it entirely. So the
#: intersection is empty for all three no matter how often the manifest is repopulated, and
#: the fix has to live in code until the spec snapshot is refreshed.
#:
#: ⚠️ WHY THEY BELONG HERE AT ALL. Each is a POST that READS: the broker's own refusal text
#: names "validate/preview/query endpoints" as the admitted non-GET shape, and these are
#: exactly that. They are POSTs only because they take a SQL statement in a body, which is
#: too large and too quote-heavy for a query string.
#:   - sql-reachability  judges SQL against reachable columns. Parses, never executes.
#:   - policy-template   names the tenant-policy literals in SQL. Its own route docstring:
#:                       "the SQL is parsed, never executed", no IAM, no DB session.
#:   - reuse-probe       similarity search over the definition store. Reads only.
#: None writes. Admitting them buys a caller nothing it could not already do with a GET.
#:
#: ⭐ REMOVE THIS LIST once `pantheon-tests/specs/pantheon_datalake-openapi.json` is
#: refreshed and `nonget_allowlist.json` regenerates with all three — then it is duplication,
#: and the duplicate is the copy that will drift.
_EXPLICIT_NONGET = [
    {"method": "POST", "path": "/api/v1/sql-reachability",
     "command": "torana datalake sql-reachability"},
    {"method": "POST", "path": "/api/v1/policy-template",
     "command": "torana datalake policy-template"},
    {"method": "POST", "path": "/api/v1/reuse-probe",
     "command": "torana datalake reuse-probe"},
]
