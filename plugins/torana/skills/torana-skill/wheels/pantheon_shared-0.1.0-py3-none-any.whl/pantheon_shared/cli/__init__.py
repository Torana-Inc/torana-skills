"""CLI authorization policy, shared across services.

⭐ WHY THIS IS IN pantheon-shared AND NOT IN ONE SERVICE. Two callers now authorize `torana`
CLI invocations and they MUST agree:

  * pantheon-admin  — authorizes a command STRING before running it in-process (cli_runner).
  * pantheon-agent-builder — the sandbox broker authorizes PARSED ARGV at the egress
    boundary, because a string allowlist cannot survive a shell (`bash -c '...'`, `eval`,
    `$(...)`). See pantheon-agent-builder/docs/streams/STREAM_E_agent_shell.md § 3.2.0.

Both call `get_policy().decide(argv)`. One classification table, two call sites. A copy in
each service would be two tables that drift — the failure this repo has already hit twice
(a stale CLI wheel left admin running an old CLI; duplicated skill text drifted within hours).
"""
from pantheon_shared.cli.policy import (  # noqa: F401
    CommandPolicy,
    Decision,
    get_policy,
    walk_click_tree,
    REASON_ADMIN_SURFACE,
    REASON_DESTRUCTIVE,
    REASON_HUMAN_DEPLOY_GATE,
    REASON_UNCLASSIFIED,
)


def nonget_allowlist():
    """The admitted operations that are NOT GET — the only mutations a broker may forward.

    ⭐ GENERATED, not hand-written: cli_policy's admit set ∩ the API manifest. Of the
    admitted commands the manifest maps, 211 are GET and 9 are not — admitted work is read
    work — so enumerating the 9 exceptions is tractable where enumerating every leaf's
    endpoints was not (measured 25-53% coverage).

    ⚠️ A new admitted non-GET command that is missing here is REFUSED, never admitted. Fail
    closed, and visible as a refusal.
    """
    import json
    import os
    fp = os.path.join(os.path.dirname(os.path.abspath(__file__)), "nonget_allowlist.json")
    with open(fp) as fh:
        return json.load(fh)
