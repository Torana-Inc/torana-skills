"""Which `torana` CLI commands a caller may run — generated, never hand-listed.

⛔ WHY THIS LIVES IN pantheon-admin AND NOT IN pantheon-cli.
**Policy lives in the admin layer. The CLI must never know it is being called by
an agent.** Three reasons, and the first is the whole stream's thesis:

1. The claim in the stream doc's § 1 — *"a tool that invokes the real CLI cannot
   drift, because there is nothing to drift from"* — holds only while there is
   ONE code path and ONE behaviour. Gating inside `torana_cli` makes that claim
   false on the day it merges: a laptop user and an agent would be running
   subtly different CLIs that happen to share a name.
2. Wrong blast radius. The CLI ships to laptops; a gating bug there hits every
   human on the platform. The same bug here hits one endpoint.
3. Policy varies by caller and the CLI has one identity. Today the caller is
   agent-builder; tomorrow program-framework, or a human-triggered deploy. Those
   want DIFFERENT policy against the SAME CLI, so policy belongs at the
   caller-facing boundary.

⚠️ Corollary: do NOT filter the Click tree. Every command stays discoverable in
`--help` even when it is not admitted — see REFUSAL_REASONS and the stream doc's
§ F4. Hiding a command means an agent cannot ask for it, so we never learn it was
wanted, and the refusal log is the instrument that tells us what to admit next.

── The shape ─────────────────────────────────────────────────────────────────
The admit set is DERIVED by walking `torana_cli.main:cli` to every leaf. It is
never a hand-written list of group or verb names, because a hand-written list is
exactly the drift this stream exists to eliminate: it goes stale the moment a
command is added, and it goes stale FAIL-OPEN.

Measured on the tree this was written against: 1,744 leaf commands → 686
admitted, 1,058 refused. 357 of those refusals (~20% of the tree) are commands
that are neither clearly read nor clearly mutating from their name and help.
That bucket is the design question, and the answer is DEFAULT-DENY — an
unclassified command is refused until someone admits it deliberately.

⛔ Verb-token matching, which Phase 1 used, is the WRONG SHAPE in both
directions. It admitted `datalake clear-all` (wipes 9 tables / 241,378 rows —
`clear-all` is not `delete`) while refusing nothing that mattered. And it cannot
express the distinction that matters most:

    build proposal cook reset       → blueprint_ready, artifacts KEPT   (recovery — ADMIT)
    build proposal reset-to-intent  → intent_only, artifacts DROPPED    (destruction — DENY)

Both contain the token `reset`. Any classifier matching verbs gets one wrong.
That pair is the reason authorization is per-COMMAND (the full leaf path).
"""

import json
import os
import re
import threading
from dataclasses import dataclass
from typing import Dict, FrozenSet, List, Optional, Tuple

from pantheon_shared import get_logger

logger = get_logger(__name__)


# ── Refusal reasons ───────────────────────────────────────────────────────────
# ⭐ Per-COMMAND, not per-category. `build proposal deploy` is withheld for a
# different reason than `datalake clear-all`, and an agent that can read the
# reason acts correctly — stop and hand off, versus change approach. A generic
# "not allowed" produces the retry-until-budget-death loop already measured on
# this platform.
REASON_ADMIN_SURFACE = "admin_surface"
REASON_HUMAN_DEPLOY_GATE = "human_deploy_gate"
REASON_DESTRUCTIVE = "destructive"
REASON_UNCLASSIFIED = "unclassified"

REFUSAL_REASONS: Dict[str, str] = {
    REASON_ADMIN_SURFACE: (
        "This is an operator/admin surface and is never available to this "
        "endpoint. It is excluded by policy, not by capability."
    ),
    REASON_HUMAN_DEPLOY_GATE: (
        "Deploying requires human confirmation (the build FSM's human DEPLOY "
        "gate). The command exists and is valid; it is withheld here. Stop at "
        "`deployable` and hand the proposal to a person."
    ),
    REASON_DESTRUCTIVE: (
        "This command deletes, drops or otherwise destroys data, and is not "
        "admitted. If you need the effect, ask a human to run it."
    ),
    REASON_UNCLASSIFIED: (
        "This command is not on the admit list. The allow policy is "
        "default-deny: a command is refused until it has been reviewed and "
        "admitted, so this is not a statement that the command is dangerous."
    ),
}


# ── Signals used to CLASSIFY (not to authorize) ───────────────────────────────
# ⚠️ These build the candidate sets; they are not the authorization mechanism.
# Authorization is the resulting per-leaf admit set. The distinction matters:
# a classifier may be imprecise because everything it cannot classify is DENIED.

# `admin` ANYWHERE in the leaf path — SEMANTIC, not structural.
#
# ⛔ Do not "fix" this to a top-level-group check. It is deliberately a token
# match at any depth, because `admin` marks an operator surface wherever it sits
# in the tree. Excluding only the top-level `admin` group would admit 35 nested
# leaves including `gateway admin proxy post` (an arbitrary POST through the
# gateway), `context-lake admin memory delete-all`, and `etl admin trigger`. One
# admitted leaf that can issue arbitrary writes makes every other exclusion in
# this file decorative.
# ⚠️ SUBSTRING, not an exact token match. An exact match on "admin" leaves 25
# operator leaves admitted, because the token is COMPOUND in three places:
#   advisor-admin flags list            (help: "across tenants", "SA only")
#   context-lake superadmin assembly stats
#   agent session messages-admin
# They are all reads, so nothing is currently destructive — but the ruling's
# intent is that operator surfaces are excluded, and "it happens to be a read
# today" is exactly the reasoning that admitted `datalake clear-all`.
#
# ⛔ Do not narrow this to a top-level-group check or an exact token match. It is
# deliberately a SUBSTRING at any depth, because `admin` marks an operator
# surface wherever it appears. Excluding only the top-level `admin` group would
# admit 35 nested leaves including `gateway admin proxy post` — an arbitrary
# POST through the gateway — which would make every other exclusion in this file
# decorative.
ADMIN_TOKEN = "admin"


def _is_admin_surface(tokens: List[str]) -> bool:
    """True if any path segment names an admin/operator surface."""
    return any(ADMIN_TOKEN in t.lower() for t in tokens)


_MUTATING_VERBS: FrozenSet[str] = frozenset({
    "create", "update", "delete", "destroy", "purge", "drop", "wipe", "clear",
    "prune", "reset", "remove", "retire", "revoke", "rollback", "truncate",
    "uninstall", "install", "deactivate", "activate", "disable", "enable",
    "cleanup", "logout", "login", "abort", "cancel", "kill", "stop", "start",
    "run", "execute", "trigger", "deploy", "apply", "set", "add", "edit",
    "save", "approve", "reject", "pin", "unpin", "attach", "detach", "import",
    "export", "seed", "replay", "sync", "refresh", "reload", "impersonate",
    "post", "send", "submit", "finalize", "step", "rebase", "reanchor",
    "upsert", "bind", "assign", "mark",
})

_READ_VERBS: FrozenSet[str] = frozenset({
    "list", "get", "show", "describe", "status", "view", "search", "inspect",
    "summary", "stats", "catalog", "vocabulary", "help", "diff", "preview",
    "check", "validate", "explain", "columns", "tables", "count", "history",
})

# Read intent stated by the command's OWN help, as its LEADING verb.
#
# Needed because a third of the tree names reads without a read verb in the path
# — `datalake list-existing`, `auth me`, `rule sql`, `alerts filter`. Denying
# those is safe but needlessly useless, and `auth me` is the first command any
# caller reaches for.
#
# ⚠️ The LEADING verb specifically, not "mentions a read word anywhere". A help
# string that merely contains "list" ("Delete a widget and list what was
# removed") must not be admitted, and anchoring at the start is what prevents
# that. This runs AFTER the mutating checks, so anything with destruction
# language in its help has already been refused regardless of how it opens.
_READ_HELP = re.compile(
    r"^\s*(list|show|get|display|return|fetch|view|inspect|report|summar|"
    r"describe|print|query|check|what|which|why|how)",
    re.IGNORECASE,
)

# Destruction language in a command's OWN help text. Catches leaves whose name
# looks harmless — e.g. `datalake clear-all`, whose help says "Clear all data
# from every sink table".
_MUTATING_HELP = re.compile(
    r"\b(delete|drop|purge|wipe|clear|prune|remove|destroy|retire|revoke|"
    r"truncate|reset|erase|uninstall|rollback|create|update|trigger|deploy|"
    r"impersonate|approve|reject|upsert)\b",
    re.IGNORECASE,
)


# ── Tier 2: author + validate a build ─────────────────────────────────────────
# ⛔ ENUMERATED, never prefix-matched. `build proposal *` holds 43 leaves and
# several are destructive, so a prefix match would admit `deploy` and `delete`.
#
# The three exclusions, each for a DIFFERENT reason:
#   deploy           → human deploy gate (a product decision, not policy tuning)
#   delete           → "Discard (soft-delete) this proposal"; nothing recovers it
#   reset-to-intent  → drops blueprint AND artifacts (contrast `cook reset`)
#
# Everything else under `build proposal` is author, validate, inspect or
# RECOVER. Recovery verbs are admitted deliberately: an agent that can author but
# cannot unwedge its own cook is stranded. `cook reset` returns a failed cook to
# `blueprint_ready` with all artifacts preserved — that is how a wedged build
# recovers at zero LLM cost.
#
# ⚠️ `deploy-reset` READS like a deploy verb and is not one: it moves a
# rolled-back proposal back TO deployable. Admitting it while excluding `deploy`
# is only expressible per-command.
_TIER2_EXCLUDED_TAILS: FrozenSet[str] = frozenset({
    "deploy", "delete", "reset-to-intent",
})

# ⛔ BOTH the singular and PLURAL build groups. The CLI's plural/singular split puts
# collection verbs on the plural noun — `build proposals create` is how EVERY build
# starts — while instance verbs live on the singular. Tier 2 originally listed only the
# singular, so `build proposals create` fell through to the destructive check and was
# refused as `create`. Measured 2026-08-28: torana-vm-v3 followed its skill correctly,
# reached the first real build step, and was refused BY POLICY — not by capability. An
# agent that can author but cannot open a proposal cannot build anything at all.
# ⛔ READS THE VERB HEURISTIC CANNOT SEE. Named explicitly by FULL leaf path, never by
# widening _READ_VERBS — `query` and `run` name mutations elsewhere in the tree, so
# admitting the VERB would admit far more than these.
#
# `datalake query` is the grounding primitive the torana-vm skill prescribes ("verify
# what you wrote against real data"). It was refused as `unclassified`, so v3 could not
# ground at all — while the SQL it carries is validated server-side and read-only by the
# datalake's own contract. Refusing it made the agent guess instead of check, which is
# the opposite of what this whole platform's grounding rules exist to enforce.
_EXPLICIT_READ_PATHS: FrozenSet[str] = frozenset({
    "datalake query",
    "datalake query-hints",
    "build capabilities",
    "build preflight",
    # ⭐ WIDENED FROM THE REFUSAL LOG, which is what F4 built it for. Each of these was
    # refused during a real build, was verifiably a READ, and blocked a discovery step
    # the skill prescribes. Exactly the "exclude now, widen from evidence" loop — not a
    # guess about what an agent might want.
    "vm policy vocabulary-browse",   # was: unclassified. Reads the tenant's resolved
                                     # policy values — the grounding C15 assumes exists.
                                     # Its --tenant flag is SA-only and enforced
                                     # server-side, so a tenant caller cannot cross over.
    "admin question-resolve",        # was: admin_surface, by the `admin` token alone.
                                     # "Resolve a phrasing to its canonical corpus
                                     # question" — a pure lookup that writes nothing.
})

_TIER2_PREFIXES: Tuple[str, ...] = ("build proposal", "build proposals")

# Back-compat alias — some callers/tests import the singular name.
_TIER2_PREFIX = "build proposal"


@dataclass(frozen=True)
class Decision:
    """Why a command was admitted or refused. `reason` is None when admitted."""
    admitted: bool
    reason: Optional[str] = None
    detail: Optional[str] = None


class CommandPolicy:
    """The admit set, derived from a Click tree.

    Build it once per process via `get_policy()`. Construction walks the whole
    CLI tree (~1,744 leaves), which costs a few milliseconds and must not happen
    per request.
    """

    def __init__(self, leaves: List[Tuple[str, str]]):
        """`leaves` is [(full leaf path, short help)] from the Click tree."""
        self._admitted: Dict[str, str] = {}   # path -> tier
        self._refused: Dict[str, str] = {}    # path -> reason
        self._all: FrozenSet[str] = frozenset(p for p, _ in leaves)

        for path, help_text in leaves:
            tokens = path.split()
            tier = None

            # 1. Admin surfaces, at ANY depth. Checked FIRST so nothing below
            #    can admit one.
            # ⚠️ ORDER MATTERS. The explicit-read list is checked BEFORE the admin
            # sweep, because two of its entries live under `admin` and would otherwise
            # never be reached — the sweep `continue`s. This is a NARROW exception by
            # FULL LEAF PATH, never by prefix: the admin sweep still refuses every other
            # `admin *` command, including anything added later. An entry earns its place
            # here only by being observed in the refusal log AND verified to write
            # nothing.
            if path in _EXPLICIT_READ_PATHS:
                self._admitted[path] = "read"
                continue

            if _is_admin_surface(tokens):
                self._refused[path] = REASON_ADMIN_SURFACE
                continue

            # 2. Tier 2 — the curated build-authoring set.
            _matched_prefix = next(
                (p for p in _TIER2_PREFIXES if path.startswith(p + " ")), None)
            if _matched_prefix:
                tail = path[len(_matched_prefix) + 1:]
                if tail in _TIER2_EXCLUDED_TAILS or tokens[-1] in _TIER2_EXCLUDED_TAILS:
                    self._refused[path] = (
                        REASON_HUMAN_DEPLOY_GATE
                        if tokens[-1] == "deploy"
                        else REASON_DESTRUCTIVE
                    )
                    # ⚠️ MUST continue. Without it the tier-1 branch below runs
                    # and OVERWRITES this reason with the generic
                    # REASON_DESTRUCTIVE — silently discarding the per-command
                    # reason F4 requires, which is the whole point of telling
                    # `deploy` apart from `clear-all`. Caught in review; the
                    # refusal still happened, only the REASON was wrong, which
                    # is exactly the kind of defect a refusal log would mask.
                    continue
                tier = "build"

            # 3. Tier 1 — reads. A read verb in the path, and NO mutating signal
            #    in either the path or the command's own help.
            if tier is None:
                mutating = bool(set(tokens) & _MUTATING_VERBS) or bool(
                    _MUTATING_HELP.search(help_text or "")
                )
                if mutating:
                    self._refused[path] = REASON_DESTRUCTIVE
                    continue
                if set(tokens) & _READ_VERBS or _READ_HELP.match(help_text or ""):
                    tier = "read"

            # 4. ⛔ DEFAULT-DENY. Neither clearly read nor clearly mutating —
            #    357 leaves on the current tree. Refusing them is the whole
            #    design: a command added next quarter is refused until someone
            #    admits it, rather than live to every caller the day it merges.
            if tier is None:
                self._refused[path] = REASON_UNCLASSIFIED
            else:
                self._admitted[path] = tier

    # ── Query ────────────────────────────────────────────────────────────────

    def decide(self, argv: List[str]) -> Decision:
        """Authorize one argv. Matches the LONGEST known leaf path as a prefix,
        so trailing arguments and flags do not defeat the lookup
        (`build proposal show <uuid> --json` → `build proposal show`)."""
        if not argv:
            return Decision(False, REASON_UNCLASSIFIED, "Empty command.")

        # ⭐ `--help` is ALWAYS admitted, for any command, admitted or not.
        # Required by the stream doc's § F4: every command must stay
        # DISCOVERABLE even when it is withheld. An agent that cannot see a
        # command cannot ask for it, so we never learn it was wanted — and the
        # refusal log is the instrument that tells us what to admit next.
        # Help renders text from an already-loaded Click tree; it reaches no
        # service and mutates nothing.
        if any(a in ("--help", "-h") for a in argv):
            return Decision(True)

        path = self._match_leaf(argv)
        if path is None:
            # Not a command the CLI has. Distinct from "exists but withheld" —
            # different problems, different remedies, so never conflate them.
            return Decision(
                False,
                REASON_UNCLASSIFIED,
                f"No such command: '{' '.join(argv[:3])}'.",
            )

        if path in self._admitted:
            return Decision(True)

        reason = self._refused.get(path, REASON_UNCLASSIFIED)
        return Decision(False, reason, self._refusal_text(path, reason))

    def _match_leaf(self, argv: List[str]) -> Optional[str]:
        """Longest known leaf path matching argv, skipping options AND embedded
        positional arguments.

        ⛔ A plain prefix match is WRONG for this CLI, and dangerously so. The
        real invocation puts the ID in the MIDDLE:

            torana build proposal <PROPOSAL_ID> deploy

        A prefix match stops at the UUID, so `deploy` is never seen and the
        command falls through to `unclassified` instead of `human_deploy_gate`.
        It still refuses — but with the wrong reason, which defeats § F4's
        per-command reasons; and every legitimate tier-2 command
        (`<ID> show`, `<ID> cook reset`) is refused too, breaking the whole
        build-authoring tier in real use. Caught by testing the REAL argv shape
        rather than the doc's shorthand.

        So candidates are built from the non-option words by dropping any single
        embedded segment that is not a known sub-command name at that position.
        """
        words = [a for a in argv if not a.startswith("-")]
        if not words:
            return None

        # Fast path: a straight prefix match (commands with no embedded ID).
        for n in range(len(words), 0, -1):
            candidate = " ".join(words[:n])
            if candidate in self._all:
                return candidate

        # Skip-a-positional path: walk the tree, and whenever the next word is
        # not a known child, treat it as an argument and try the word after it.
        best: Optional[str] = None
        for skip in range(1, len(words)):
            trimmed = words[:skip] + words[skip + 1:]
            for n in range(len(trimmed), 0, -1):
                candidate = " ".join(trimmed[:n])
                if candidate in self._all:
                    # Prefer the LONGEST match found across skips, so
                    # `<ID> cook reset` beats a shorter accidental match.
                    if best is None or len(candidate) > len(best):
                        best = candidate
                    break
        return best

    @staticmethod
    def _refusal_text(path: str, reason: str) -> str:
        return (
            f"Refused: '{path}' is not permitted here. "
            f"{REFUSAL_REASONS.get(reason, '')} "
            f"(reason={reason})"
        ).strip()

    # ── Introspection (tests, diagnostics, the write-back table) ─────────────

    @property
    def admitted(self) -> Dict[str, str]:
        return dict(self._admitted)

    @property
    def refused(self) -> Dict[str, str]:
        return dict(self._refused)

    def counts(self) -> Dict[str, int]:
        by_reason: Dict[str, int] = {}
        for reason in self._refused.values():
            by_reason[reason] = by_reason.get(reason, 0) + 1
        by_tier: Dict[str, int] = {}
        for tier in self._admitted.values():
            by_tier[f"admit_{tier}"] = by_tier.get(f"admit_{tier}", 0) + 1
        return {
            "total": len(self._all),
            "admitted": len(self._admitted),
            "refused": len(self._refused),
            **by_tier,
            **by_reason,
        }


# ── Tree walking ──────────────────────────────────────────────────────────────

def walk_click_tree(group) -> List[Tuple[str, str]]:
    """Every leaf command as (full path, short help)."""
    import click

    leaves: List[Tuple[str, str]] = []

    def _walk(cmd, path: List[str]) -> None:
        if isinstance(cmd, click.Group):
            for name, sub in cmd.commands.items():
                _walk(sub, path + [name])
        else:
            try:
                short = cmd.get_short_help_str(limit=400) or ""
            except Exception:
                short = ""
            leaves.append((" ".join(path), short))

    _walk(group, [])
    return leaves


_policy: Optional[CommandPolicy] = None
_policy_lock = threading.Lock()


def _snapshot_path() -> str:
    """Where the pre-derived leaf snapshot lives (next to this module)."""
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "leaves.json")


def build_snapshot() -> Dict[str, str]:
    """Derive {leaf path: short help} from the INSTALLED CLI. Requires torana_cli."""
    from torana_cli.main import cli
    return dict(walk_click_tree(cli))


def get_policy() -> CommandPolicy:
    """The process-wide policy.

    ⭐ TWO SOURCES, ONE TABLE — and the live tree ALWAYS wins.
    Where `torana_cli` is installed (pantheon-admin, the sandbox image, a laptop), the admit
    set is derived from the real Click tree, so it cannot drift from the commands that
    actually exist. That is the property this design was built for and it is preserved.

    ⛔ WHY A SNAPSHOT FALLBACK EXISTS. pantheon-agent-builder authorizes sandbox egress but
    deliberately does NOT ship the CLI — the CLI lives in the sandbox image, which is the
    whole point of the isolation (STREAM_E § 3.2.0). Without a fallback `get_policy()` raises
    ModuleNotFoundError there, the broker fails closed, and the sandbox can do nothing at all.
    The snapshot (leaves.json, ~63 KB, 1746 leaves) is generated from the live tree by
    `python -m pantheon_shared.cli.policy --write-snapshot` and refreshed by update-dist.sh.

    ⚠️ THE SNAPSHOT IS A FALLBACK, NOT A SECOND TABLE. It is *generated from* the live tree,
    never hand-edited. A stale snapshot can only be MISSING a new command (which is then
    refused as unclassified — fail closed, the safe direction); it can never admit something
    the real CLI refuses, because both classify with the same code below.
    """
    global _policy
    if _policy is None:
        with _policy_lock:
            if _policy is None:
                source = "live-tree"
                try:
                    leaves = list(build_snapshot().items())
                except Exception:
                    # No CLI here — fall back to the generated snapshot.
                    try:
                        with open(_snapshot_path()) as fh:
                            leaves = list(json.load(fh).items())
                        source = "snapshot"
                    except Exception as exc:
                        raise RuntimeError(
                            "cli policy unavailable: torana_cli is not importable and no "
                            f"leaf snapshot was found at {_snapshot_path()}. Run "
                            "`python -m pantheon_shared.cli.policy --write-snapshot` where "
                            "the CLI IS installed, or reinstall pantheon-shared."
                        ) from exc
                _policy = CommandPolicy(leaves)
                logger.info("cli_policy.built", source=source, **_policy.counts())
    return _policy


if __name__ == "__main__":  # pragma: no cover - operational entrypoint
    # Regenerate the snapshot from the installed CLI. Run wherever torana_cli exists.
    import sys
    if "--write-snapshot" in sys.argv:
        data = build_snapshot()
        with open(_snapshot_path(), "w") as fh:
            json.dump(data, fh, indent=0, sort_keys=True)
        print(f"wrote {_snapshot_path()} ({len(data)} leaves)")
