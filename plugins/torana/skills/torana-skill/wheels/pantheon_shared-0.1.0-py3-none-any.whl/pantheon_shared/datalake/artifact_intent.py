"""The artifact INTENT contract — one definition, one validator, every producer.

S12 (tracker row 20z). `ARTIFACT_INTENT_SPEC.md` § 3 and § 7.

⛔ THE INVERSION THIS EXISTS FOR
--------------------------------
Today an artifact's source of truth is its SQL. SQL records WHAT a query does and
never WHY those choices were made, so it cannot be regenerated from itself — you
would get the same SQL back. The intent is what a regeneration reads instead.

⛔ AND IT IS UNBACKFILLABLE. Versioning (row 20v) can recover old SQL; provenance
(row 20p) can be backfilled from a tag. Intent cannot: SQL -> English loses the
choice. Every artifact created without one needs its intent hand-written later by
someone guessing, which is why this row is ahead of everything in Part C.

⛔ WHY IT LIVES IN pantheon-shared
----------------------------------
§ 7.7 chose a shared core precisely so a new artifact type CANNOT BYPASS IT. Four
producers create artifacts — app bundles, the `torana-vm` skill, the build_v2
agents, and the `torana-text-to-sql` skill — across five services. A per-service
validator would make each new type a fresh opportunity to forget, which is how
this codebase ended up with two different things called "widget provenance".

⛔ WHAT THIS MODULE DOES NOT DO
-------------------------------
It does not regenerate anything, and it holds no opinion about SQL. Rows 20b/20c
own the trigger and the rewrite; this is the substrate they read.

⚠️ REPRESENTATION — the § 8.2 decision, and why (S12 § 3.1 left it to this session)
-----------------------------------------------------------------------------------
The brief allowed three shapes: a structured sub-object, sibling columns, or a
convention inside the text. This module implements **a convention inside the
existing `semantic_description` text**, strictly parsed. Measured reasons:

  * `semantic_description` exists on **12 models across 5 services** (S12 § 2 says
    eight; see § 8.6 — it missed `playbook` and `workflow`). Sibling columns would
    be 60 new columns and 12 migrations; a sub-object would be 12 migrations. A
    text convention is ZERO, and lands on every type at once.
  * ⛔ Every existing value keeps rendering. A JSON blob in a field that eight
    surfaces print as prose would show `{"question": ...}` to users.
  * ⛔ § 3.1 forbids a parallel `intent` field, and the corpus — which the brief
    says to FOLLOW, not reinvent — already carries `grain` as PROSE compared as a
    string (93/93 rows, median 125 chars). A prose grain is what "machine
    comparable" means here.

⚠️ The cost of this choice is that parsing is textual, so the parser must be
strict and must never guess. It anchors on `^<key>:` at line start and nothing
else — no fuzzy matching, no inference from prose.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional

#: § 3 — the five-part core, IDENTICAL across every artifact type (§ 7.7).
#: ⛔ Order is the authoring order, not an importance ranking.
INTENT_PARTS = ("question", "grain", "semantics", "scope", "fallback")

#: ⛔ `grain` is the one field a diff can check mechanically, and rows 20b/20c
#: depend on it. § 3.2: "A regeneration that changes the grain is a DIFFERENT
#: artifact, not a better one."
COMPARABLE_PART = "grain"

#: ⛔ S20 § 3.1 — the REDUCED contract, and the decision behind it.
#:
#: An artifact type that carries no query has no rows, so `grain` ("what is ONE
#: ROW") is not a weaker requirement for it — it is a MEANINGLESS one. Measured:
#: 45 of the 131 shipped bundle artifacts are `scheduler` (17), `route` (14) or
#: `playbook` (14), none of which produce a row set.
#:
#: ⛔ The choice was NOT between "apply" and "exclude". Excluding these types
#: outright was rejected: a route still encodes intent someone must understand to
#: regenerate it ("which findings go to whom, and why those"), and dropping the
#: requirement would lose exactly that. Requiring `grain` anyway was rejected for
#: the opposite reason — an author forced to state the row shape of a scheduler
#: writes filler, and filler that satisfies a gate is worse than no gate (§ 3.2).
#:
#: ⚠️ So the reduction is ONE part, on a CLOSED set of types, and every other part
#: of the contract still applies. This is deliberately not a general "optional
#: parts" mechanism: a per-type opt-out list is how a contract becomes advisory.
NON_ROW_ARTIFACT_TYPES = frozenset({"scheduler", "route", "playbook"})

#: The parts a non-row artifact must still carry. ⛔ Derived, never hand-listed —
#: a hand-written second tuple drifts the moment INTENT_PARTS changes.
REDUCED_INTENT_PARTS = tuple(p for p in INTENT_PARTS if p != COMPARABLE_PART)


def required_parts(artifact_type: str = "") -> tuple:
    """Which parts THIS artifact type must carry (§ 3.1).

    ⚠️ Normalises the type before comparing: the value arrives from a bundle
    document, a DB column and an API body, and a case/whitespace mismatch would
    silently apply the FULL contract to a scheduler — which reads as a bug in the
    intent rather than in the lookup.
    """
    if str(artifact_type or "").strip().lower() in NON_ROW_ARTIFACT_TYPES:
        return REDUCED_INTENT_PARTS
    return INTENT_PARTS

#: A part is present when its key appears at line start. ⚠️ Deliberately strict:
#: a parser that accepts `Grain -` or `**grain**` invites producers to drift into
#: near-misses that each need their own special case.
_PART_RE = re.compile(
    r"^(?P<key>" + "|".join(INTENT_PARTS) + r"):[ \t]*(?P<value>.*)$",
    re.IGNORECASE | re.MULTILINE,
)

#: ⚠️ NOT a style rule. Below this a part cannot carry a rule a generator could
#: bind — "open findings" is a phrase, not a scope. The corpus median grain is
#: 125 chars; this is a floor, set well under it so it rejects only stubs.
MIN_PART_CHARS = 12

#: ⛔ THE AUTHORING TRAP THIS CATCHES, hit twice while writing the first six
#: intents by hand. The parser gives each part everything up to the NEXT key, so
#: a part is unbounded — and an author who puts the key block ABOVE the existing
#: prose silently donates that entire paragraph to `fallback`. The result parses,
#: validates, and ships an intent whose last field is a paragraph about something
#: else. ⚠️ No real part comes close to this: the longest hand-authored one is
#: ~700 chars, and the corpus median grain is 125.
#: ⛔ The fix is ordering, not truncation — the intent block goes LAST.
MAX_PART_CHARS = 1200

#: ⛔ § 3.3 — `semantics` names CONCEPTS, never columns. "Use
#: vulnerabilities.severity" is an implementation choice that must stay free to
#: change when a better column appears, which is the entire point of
#: regenerating. A qualified column reference is the signal that a producer
#: wrote a binding instead of a meaning.
_COLUMN_REF_RE = re.compile(r"\b[a-z_][a-z0-9_]{2,}\.[a-z_][a-z0-9_]{2,}\b")


@dataclass
class Intent:
    """One artifact's regeneration-grade intent."""

    question: str = ""
    grain: str = ""
    semantics: str = ""
    scope: str = ""
    fallback: str = ""
    #: Free prose that preceded the first key. Kept so a producer can lead with a
    #: human sentence without it being mistaken for a missing part.
    preamble: str = ""

    def parts(self) -> Dict[str, str]:
        return {p: getattr(self, p) for p in INTENT_PARTS}

    def grain_signature(self) -> str:
        """Normalised `grain`, for the row 20b/20c diff.

        ⚠️ Normalises WHITESPACE AND CASE ONLY. It must not stem, reorder or drop
        words: `one row per (team, severity)` and `one row per team` are
        different artifacts, and a normaliser clever enough to call them equal
        would silently permit the grain change § 3.2 forbids.
        """
        return re.sub(r"\s+", " ", self.grain).strip().lower()


@dataclass
class IntentVerdict:
    """Why an intent was rejected — never a bare bool.

    ⚠️ § 5 of S4's rules, and the standing house rule: never return `0`/`[]`/False
    for an unanswerable case. A producer that gets `False` cannot fix anything;
    one that gets "grain is missing" can.
    """

    ok: bool
    missing: List[str] = field(default_factory=list)
    too_short: List[str] = field(default_factory=list)
    problems: List[str] = field(default_factory=list)

    def message(self) -> str:
        bits: List[str] = []
        if self.missing:
            bits.append("missing: " + ", ".join(self.missing))
        if self.too_short:
            bits.append("too short to bind: " + ", ".join(self.too_short))
        bits.extend(self.problems)
        return "; ".join(bits) or "ok"


class MissingIntentError(ValueError):
    """Raised when an artifact is created without a conforming intent.

    ⛔ § 7.4 — mandatory means ENFORCED, and `expected_caller` is the precedent in
    this same subsystem: optional and unenforced, with no test asserting it, so
    "the rule depended on someone remembering" and columns shipped without it.
    ⛔ There is deliberately NO grandfather list here. If one is ever added, a
    test must keep it empty.
    """


def parse_intent(text: Optional[str]) -> Intent:
    """Parse `semantic_description` into the five parts. Never raises.

    ⚠️ Returns an EMPTY Intent for unparseable input rather than guessing. A
    parser that inferred `question` from the first sentence would make every
    legacy one-line description look like a partial intent, and § 2's test would
    then pass on text that cannot regenerate anything.
    """
    if not text or not text.strip():
        return Intent()
    matches = list(_PART_RE.finditer(text))
    if not matches:
        return Intent(preamble=text.strip())
    out = Intent(preamble=text[: matches[0].start()].strip())
    for i, m in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        body = (m.group("value") + "\n" + text[m.end():end]).strip()
        setattr(out, m.group("key").lower(), body)
    return out


def validate_intent(text: Optional[str], *, artifact_type: str = "") -> IntentVerdict:
    """⛔ THE ONE VALIDATOR (§ 7.7). Every producer passes through this.

    ⚠️ The bar is § 2 of the spec, and it is not a length check:

        "Could two competent generators, given only this text and the current
         schema, produce queries that disagree on a row count?"

    That cannot be evaluated mechanically, so this enforces the STRUCTURAL
    proxies that make it answerable — all five parts present, each long enough to
    carry a rule, and `semantics` naming concepts rather than columns.
    """
    intent = parse_intent(text)
    # ⛔ § 3.1 — a non-row type is not asked for `grain`. Everything else is
    # unchanged, including the checks below, which run on whatever IS present.
    wanted = required_parts(artifact_type)
    missing = [p for p in wanted if not getattr(intent, p).strip()]
    too_short = [
        p for p in wanted
        if p not in missing and len(getattr(intent, p).strip()) < MIN_PART_CHARS
    ]
    problems: List[str] = []

    # ⛔ § 3.3 — a column reference in `semantics` is a BINDING, not a meaning.
    if intent.semantics and _COLUMN_REF_RE.search(intent.semantics.lower()):
        problems.append(
            "semantics names a column (table.column); name the CONCEPT and its "
            "rule instead — the binding must stay free to change when a better "
            "column appears, which is the point of regenerating"
        )
    # ⚠️ Advisory-shaped but enforced: a grain that does not say what one row IS
    # cannot be compared, and comparability is the whole reason the field exists.
    if intent.grain and "row" not in intent.grain.lower():
        problems.append(
            "grain must state what ONE ROW is (e.g. 'one row per owning team')"
        )
    # ⛔ The absorbed-trailing-prose guard — see MAX_PART_CHARS.
    for part in INTENT_PARTS:
        value = getattr(intent, part).strip()
        if len(value) > MAX_PART_CHARS:
            problems.append(
                f"{part} is {len(value)} chars — a part this long almost always "
                f"means the intent block was placed ABOVE existing prose and "
                f"swallowed it. Put the `question:`…`fallback:` block LAST"
            )
    return IntentVerdict(
        ok=not (missing or too_short or problems),
        missing=missing, too_short=too_short, problems=problems,
    )


def require_intent(text: Optional[str], *, artifact_type: str = "",
                   artifact_key: str = "") -> Intent:
    """Validate or RAISE. The enforcement entry point for a creation path.

    ⛔ § 7.4: "Any surface that tries to create an artifact without an intent
    FAILS. Not a warning, not a default, not a nullable column backfilled later."
    """
    verdict = validate_intent(text, artifact_type=artifact_type)
    if not verdict.ok:
        label = " ".join(x for x in (artifact_type, artifact_key) if x) or "artifact"
        raise MissingIntentError(
            f"{label}: intent is not regeneration-grade — {verdict.message()}. "
            f"Required parts: {', '.join(INTENT_PARTS)}."
        )
    return parse_intent(text)


def render_intent(intent: Intent) -> str:
    """The canonical text form a producer writes into `semantic_description`.

    ⚠️ One writer for the format. A producer that hand-builds the string will
    drift from the parser the first time a key is renamed.
    """
    lines: List[str] = []
    if intent.preamble.strip():
        lines.append(intent.preamble.strip())
        lines.append("")
    for part in INTENT_PARTS:
        value = getattr(intent, part).strip()
        if value:
            lines.append(f"{part}: {value}")
    return "\n".join(lines)


def grain_changed(before: Optional[str], after: Optional[str]) -> bool:
    """⭐ The row 20b/20c check: did a regeneration change the artifact's shape?

    ⛔ § 7.2 — a regeneration that produces a different grain is NOT APPLIED. The
    old SQL keeps serving and the artifact surfaces "a different shape is
    available". For a TRANSFORMER (§ 7.5) it is blocked outright: its grain is an
    interface to other SQL, so a change breaks unknown downstream consumers.
    """
    return parse_intent(before).grain_signature() != parse_intent(after).grain_signature()
