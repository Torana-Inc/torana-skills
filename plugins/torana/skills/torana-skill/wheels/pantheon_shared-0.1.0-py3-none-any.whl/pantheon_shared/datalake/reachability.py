"""Column reachability — which (table, column) pairs a pipeline can actually write.

`Torana_Shadow_Columns.md` records the defect this module answers: the datalake
declares 1,702 columns, 481 have ever held a value, and **nothing in the schema
says which ones a pipeline can write**. Every consumer — build agents, the SQL
catalog, app bundles — reads `information_schema`, sees 1,702 equally
authoritative columns, and authors SQL against columns that will never light up.
`EXPLAIN` passes, the table exists, the dashboard renders `0`.

Two words, kept strictly apart (§1.1 of the task, §4.2 of the source doc):

    reachable   A pipeline EXISTS that writes this column. Says nothing about data.
    populated   Data has actually landed. Observational; lags first sync.

Conflating them destroys the only signal separating **a build defect** (nothing
can ever write this) from **a sync state** (the writer exists, the data has not
arrived). A column is legitimately reachable-and-empty the day an integration is
enabled and before its first sync.

────────────────────────────────────────────────────────────────────────────────
The four ways a column gets written
────────────────────────────────────────────────────────────────────────────────

The source document names three (§4.2). Deriving the map found a fourth — the
system fields the platform injects into every table. Parsing only mechanism 1 is
what made an earlier attempt classify `cisa_kev_data` and `epss_score` as
unwritten *despite both being populated*:

    1. mapping     a mapping YAML pipeline step writes it
                   (`pantheon-integration/torana_mesh/mappings/<family>/*.yaml`)
    2. operator    ETL operator code writes it programmatically
                   (`torana_mesh/etl/operators/*.py`)
    3. decoration  the decoration registry declares it
                   (`pantheon_shared.datalake.decorations.DECORATIONS`)
    4. system      auto-injected into every table by the schema layer
                   (`schemas/system_fields.py` — tenant_id, created_at, …)
    5. ingestor    a PUSH ingestor shapes the record before any mapping runs
                   (`torana_mesh/etl/ingestors/*.py` — SARIF, asset, entity_edge)
    6. extractor   an extractor/service composes the column, and the mapping only
                   derives the key (`etl/extractors/*.py`, `services/*.py`)
    8. declared    an OUT-OF-BAND writer (API endpoint / service) that goes
                   through none of 1-6 and DECLARES its columns at the write site
                   (`pantheon_shared.datalake.write_seam.WRITERS` — imported)

(7 is validate-passthrough, below — observational, not a declared mechanism.)

Mechanisms 4–6 are NOT in the source document's list of three. Each was found by
running the §1.3 invariant and refusing to explain away a violation:

  * omitting 4 fails the invariant on seven columns per table that obviously
    hold data (`tenant_id`, `created_at`, …);
  * omitting 5 fails it on all of `packages` and `entity_edges` — push
    ingestors yield `(table, records)` directly, so no mapping op ever names
    those columns;
  * omitting 6 fails it on `repositories.teams` (the GitHub *extractor* fuses
    the Teams API with CODEOWNERS; `repo_teams.yaml` only derives the key) and
    on `findings.finding_subcategory` (written by
    `services/reconciliation.py`, no integration involved).

⚠️ **The source document's "three mechanisms" is therefore incomplete**, and a
map built to its list alone under-reports reachability by ~30 columns on this
tenant. That is the same class of error as the `cisa_kev_data` misclassification
it warns about — one layer further out.

⚠️ **Mechanism 1 is not a `target:` grep.** Of the 11 op types in the mapping
tree, five write columns and each writes them from a *different* part of the
step, so a single regex is wrong five ways:

    op          writes                                     shape
    ─────────   ────────────────────────────────────────   ──────────────────
    derive      params.target                              one column
    set         EVERY KEY of params                        constants dict
    rename      the VALUES of params.map                   src → dst
    pack        params.target                              JSON column
    combine     params.target                              templated string
    unpack      ⚠️ UNKNOWABLE — keys of a runtime JSON blob (see below)

`set` is the one that bites: its column names are the param *keys*
(`source_system: qualys` writes `source_system`), so a parser looking for
`target:` misses every constant the platform sets. `rename` inverts the same
trap — the column is the *value*, and reading the key yields the vendor's field
name, which is not a column at all.

────────────────────────────────────────────────────────────────────────────────
Stated limits — read before trusting a `False`
────────────────────────────────────────────────────────────────────────────────

⚠️ **`unpack` is statically unknowable.** It lifts the keys of a JSON blob to
top level; the key set exists only in the vendor's API response at runtime. Two
mappings use it (`okta/users`, `okta/groups`). Columns written only via `unpack`
are reported unreachable and would be **false negatives**. They are listed in
`UNPACK_MAPPINGS` so the gap is visible rather than silent.

⚠️⚠️ **PASSTHROUGH is the big one, and it bounds every `reachable=False`.**
The `validate` operator's `on_extra_field` defaults to `"keep"`, and **99 of the
102 mappings take that default** (only 3 set `drop_with_warn`). So a vendor
field whose name happens to match a schema column is written even though NO
pipeline step names it. Measured example: `identities.locked` holds data for 3
GitLab rows; `locked` appears nowhere in `gitlab/members.yaml` — GitLab's
`/members` API simply returns it and `validate` keeps it.

This cannot be derived statically: it depends on the vendor's live response
shape, which is exactly the payload this repo does not contain. The consequence
is precise and must be carried into any report built on this map:

    a column reported `reachable=True`  is TRUE — a named writer exists
    a column reported `reachable=False` means "no writer found by this parse",
                                        NOT "no pipeline can ever write it"

`reachable=False` is therefore an **upper bound on unreachability**. Treat it as
a strong signal, never as proof, and never quietly upgrade it to "impossible".

⚠️ **Reachability is per (table, column), never per column name.** A mapping
declares `destination_table`, so the same column name in two tables can have
completely different writers. Keying on the name alone merges them and reports
one table's writer as evidence for another's column.

⚠️ **`reachable=False` is a claim about the parse, not proof of impossibility.**
Anything this module cannot see (an `unpack`, a hand-run backfill, a direct
write) makes a genuinely-written column look unwritten. That is exactly why
`validate_against_populated()` exists and why the audit runs it FIRST: a
populated column with no writer is a **parse bug**, not a data anomaly.

════════════════════════════════════════════════════════════════════════════════
⛔ MAINTENANCE CONTRACT — READ THIS BEFORE CHANGING ANY ETL CODE
════════════════════════════════════════════════════════════════════════════════

**This module makes a claim about OTHER people's code, so other people's changes
can silently invalidate it.** A stale map does not crash — it reports a real
column as `reachable=False`, which reads as "this can never work" and is the most
convincing possible way to be wrong.

**What is DERIVED automatically (add these freely; nothing here needs editing):**

  ✅ a new integration shipped the normal way — mapping YAMLs under
     `mappings/<family>/` are walked and parsed, including `destination_table`
     and every column-writing op. A new family, a new data source, or a new
     column on an existing mapping is picked up with NO change here.
  ✅ tenant/platform mapping overrides stored in `etl_mapping_configs`
     (pass them via `collect_mapping_writers(extra_docs=…)`).
  ✅ a new decoration — `DECORATIONS` is IMPORTED, never regexed.
  ✅ a new system field — `system_fields.py` is imported.
  ✅ a new OUT-OF-BAND WRITER (an API endpoint or service that writes sink
     columns outside mechanisms 1-6) — it declares its own columns via
     `write_seam.register_writer()` next to the writing code, and
     `writers_from_declared_seam()` IMPORTS that registry. **Nothing here needs
     editing.** That is the anti-drift property, and the reason the seam exists
     rather than a tenth hand-written tuple below.

**What REQUIRES A CHANGE HERE (the hand-listed tuples below):**

  ⚠️ `_OPERATOR_WRITERS`   — you wrote a NEW ETL OPERATOR, or made an existing
                             one write a column in Python (`rec["col"] = …`)
                             rather than from mapping params.
  ⚠️ `_INGESTOR_WRITERS`   — you added a PUSH INGESTOR under `etl/ingestors/`,
                             or changed which columns an existing one shapes.
                             These bypass the mapping tree entirely.
  ⚠️ `_EXTRACTOR_WRITERS`  — an EXTRACTOR or a SERVICE composes a column while
                             the mapping only derives the key
                             (e.g. `repositories.teams`,
                             `findings.finding_subcategory`).
  ⚠️ `COLUMN_WRITING_OPS` + `_columns_written_by_step()`
                           — you added an op that writes columns, or changed
                             WHERE an existing op takes its column names from.
                             Each branch mirrors that operator's `compile()`;
                             if you change the operator, change the branch.

**If you skip this, here is exactly what breaks.** The audit that consumes this
map (`docs/corpus/REACHABILITY_AUDIT.md`) classifies SQL as 🔴 red — "can never
work, should never have been authored" — purely on `reachable=False`. A missing
writer entry therefore manufactures build defects that do not exist, and someone
will delete working SQL because of it.

**How you find out you got it wrong — run this, do not eyeball it:**

    validate_against_populated(rmap, populated)   # §1.3 invariant

Every column holding data MUST have a named writer. A violation names the exact
`(table, column)` and is a PARSE BUG, never a data anomaly. This is not
theoretical bookkeeping — mechanisms 5, 6 and 7 were ALL discovered by running
this check and refusing to explain away a violation. Run it after any ETL
change; wire it into CI if you want the guarantee to hold without discipline.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, FrozenSet, Iterable, List, Optional, Set, Tuple

__all__ = [
    "Writer",
    "ColumnReachability",
    "ReachabilityMap",
    "WriterKind",
    "SYSTEM_WRITTEN_COLUMNS",
    "UNPACK_MAPPINGS",
    "COLUMN_WRITING_OPS",
    "build_reachability_map",
    "writers_from_mapping_doc",
    "writers_from_decorations",
    "writers_from_operators",
    "writers_from_ingestors",
    "writers_from_extractors",
    "writers_from_declared_seam",
    "writers_from_observed_passthrough",
    "writers_from_system_fields",
    "InvariantResult",
    "validate_against_populated",
]


# ── Writer kinds ─────────────────────────────────────────────────────────────
# `kind` is part of the API contract (task §1.4). Kept as plain strings rather
# than an enum so the JSON surface and the dataclass never disagree.

WriterKind = str

KIND_MAPPING: WriterKind = "mapping"
KIND_OPERATOR: WriterKind = "operator"
KIND_DECORATION: WriterKind = "decoration"
KIND_SYSTEM: WriterKind = "system"
KIND_INGESTOR: WriterKind = "ingestor"
KIND_EXTRACTOR: WriterKind = "extractor"
KIND_PASSTHROUGH: WriterKind = "passthrough"
KIND_DECLARED: WriterKind = "declared"


# ── Mechanism 1: which mapping ops write a column, and from WHERE ────────────
#
# Derived by reading each operator's `compile()` in
# `torana_mesh/etl/operators/`, not by pattern-matching the YAML. The comment
# beside each entry names the line that proves it.
#
# The ops deliberately absent write NO column:
#   drop / filter             remove records or fields
#   validate / upsert         terminal; validate checks, upsert persists what
#                             earlier steps already wrote
#   derive_entity_edges       explicitly pass-through — "records ALWAYS pass
#                             through unchanged; this operator only side-effects"
#                             (it writes `entity_edges` via an HTTP ingest call,
#                             not via the record)
#   tee / route / audit_sample  routing/observability, no column authored
#   enrich                    merges a lookup dict whose keys are config-time
#                             data, handled via `_writers_from_enrich`

COLUMN_WRITING_OPS: FrozenSet[str] = frozenset(
    {"derive", "set", "rename", "pack", "combine", "unpack", "enrich"}
)

# Mappings using `unpack`, whose written columns cannot be known statically.
# Surfaced so the limit is auditable instead of invisible.
UNPACK_MAPPINGS: Tuple[str, ...] = ("okta/users", "okta/groups")


# ── Mechanism 4: system fields ───────────────────────────────────────────────
# `schemas/system_fields.py` injects these into EVERY table. They are written by
# the platform on every insert (`datalake_adapter.py` sets tenant_id,
# namespace_id, is_deleted, updated_at directly), so they are reachable
# everywhere and belong to no integration.
SYSTEM_WRITTEN_COLUMNS: FrozenSet[str] = frozenset(
    {
        "tenant_id",
        "namespace_id",
        "is_deleted",
        "created_at",
        "created_by",
        "updated_at",
        "updated_by",
    }
)


@dataclass(frozen=True)
class Writer:
    """One pipeline that can write one column, with the provenance to check it.

    `source` is a file path or registry key — task §1.4 requires provenance
    precisely so a wrong map is catchable by eye rather than by trusting the
    parser.
    """

    kind: WriterKind
    source: str
    integration: Optional[str] = None
    """Owning integration family (`gcp`, `github`, …). None for `system` and for
    global decorations, which belong to no single integration."""

    detail: str = ""
    """Free-text note — the op that wrote it, or why it is unconditional."""

    expected_caller: Optional[Dict[str, Any]] = None
    """For `kind=declared` ONLY: who is expected to call the writer, as
    ``{name, status, exists[, note]}`` (see `write_seam.ExpectedCaller`).

    ⚠️ The other seven kinds fill themselves — a mapping fills when an integration
    syncs, an operator when ETL runs. A `declared` writer fills ONLY when an
    external actor chooses to call it, so "is a column reachable" and "will it ever
    hold data" come apart exactly here, and nowhere else. Carried through the map so
    `--explain` can serve it over the API: a consumer that must answer *"is this
    question answerable AND self-filling?"* has no other portable source for it.

    `None` on a declared writer means UNDECLARED (nobody said), which is NOT the
    same as `status="none"` (somebody said there is no caller). Consumers must keep
    them distinct rather than collapsing both to "no caller"."""

    bridge_id: Optional[str] = None
    """For `kind=declared` ONLY: a REFERENCE to the bridge-registry entry holding
    the CALLABLE CONTRACT for this writer — method, path, a payload that would
    actually work, and (for a join key) the timing constraint.

    ⚠️ `expected_caller` names WHO should call and whether they exist. It cannot
    say HOW TO BECOME ONE, and `ExpectedCaller.note` explicitly refuses to carry
    that ("NEVER load-bearing"). Without this, a reader of an empty column has
    the name of a thing that does not exist and no way to act on it.

    A reference, never an inlined payload: one bridging action fills 6-19 columns,
    so inlining would repeat the contract per column and let the copies drift.
    Entries live in `pantheon-datalake/torana_datalake/corpus/bridge_registry.py`."""

    def as_dict(self) -> Dict[str, Any]:
        out: Dict[str, Any] = {"kind": self.kind, "source": self.source}
        if self.integration:
            out["integration"] = self.integration
        if self.detail:
            out["detail"] = self.detail
        if self.expected_caller:
            out["expected_caller"] = dict(self.expected_caller)
        if self.bridge_id:
            out["bridge_id"] = self.bridge_id
        return out


@dataclass
class ColumnReachability:
    """Reachability of ONE (table, column), with every writer that supports it."""

    table: str
    column: str
    writers: List[Writer] = field(default_factory=list)

    @property
    def reachable(self) -> bool:
        return bool(self.writers)

    @property
    def integrations(self) -> Set[str]:
        return {w.integration for w in self.writers if w.integration}

    def reachable_for(self, enabled: Optional[Set[str]]) -> bool:
        """Reachable given a tenant's enabled integration set.

        `enabled=None` means platform scope — any shipped integration counts.

        A writer with no integration (`system`, a global decoration) is
        unconditional: it does not depend on what the customer connected, so it
        counts in both scopes.
        """
        if enabled is None:
            return self.reachable
        for w in self.writers:
            if w.integration is None or w.integration in enabled:
                return True
        return False

    def writers_for(self, enabled: Optional[Set[str]]) -> List[Writer]:
        if enabled is None:
            return list(self.writers)
        return [
            w for w in self.writers
            if w.integration is None or w.integration in enabled
        ]


@dataclass
class ReachabilityMap:
    """The full (table, column) → writers map, plus what the parse could not see."""

    columns: Dict[Tuple[str, str], ColumnReachability] = field(default_factory=dict)
    parse_errors: List[str] = field(default_factory=list)
    unknowable: List[str] = field(default_factory=list)
    """Mappings whose written column set is not statically derivable (`unpack`)."""

    mappings_parsed: int = 0
    integrations_seen: Set[str] = field(default_factory=set)

    declared: Dict[str, Set[str]] = field(default_factory=dict)
    """`{table: {columns}}` from the schema registry. When populated, `add()`
    refuses any (table, column) the table does not declare — see
    `build_reachability_map`. Empty means "unconstrained", which over-reports."""

    dropped_undeclared: List[Tuple[str, str, str]] = field(default_factory=list)
    """`(table, column, writer_source)` rejected because the table does not
    declare the column. Kept rather than silently discarded: a long list here
    usually means a mapping writes a field its destination table drops at
    `validate` time — a real (separate) defect worth seeing."""

    def add(self, table: str, column: str, writer: Writer) -> None:
        if not table or not column:
            return
        # ⛔ A writer for a column the table does not declare is NOT reachability.
        # The record carries the field; `validate` drops it before the upsert, so
        # the column can never hold data. Counting it inflates the numerator
        # against a denominator that never contained it.
        if self.declared:
            cols = self.declared.get(table.lower())
            if cols is not None and column.lower() not in cols:
                self.dropped_undeclared.append((table.lower(), column.lower(), writer.source))
                return
        key = (table.lower(), column.lower())
        entry = self.columns.get(key)
        if entry is None:
            entry = ColumnReachability(table=table.lower(), column=column.lower())
            self.columns[key] = entry
        # Same writer twice (a mapping that sets then renames onto one column)
        # is one writer, not two — duplicates would inflate the provenance list.
        if not any(
            w.kind == writer.kind
            and w.source == writer.source
            and w.detail == writer.detail
            for w in entry.writers
        ):
            entry.writers.append(writer)
        if writer.integration:
            self.integrations_seen.add(writer.integration)

    def get(self, table: str, column: str) -> Optional[ColumnReachability]:
        return self.columns.get((table.lower(), column.lower()))

    def is_reachable(
        self, table: str, column: str, enabled: Optional[Set[str]] = None
    ) -> bool:
        entry = self.get(table, column)
        return bool(entry and entry.reachable_for(enabled))

    def for_table(self, table: str) -> List[ColumnReachability]:
        t = table.lower()
        return [c for c in self.columns.values() if c.table == t]


# ── Mechanism 1: mapping YAML ────────────────────────────────────────────────


def _writers_from_enrich(params: Dict[str, Any]) -> List[str]:
    """Columns an `enrich` step merges in.

    `fields` names the subset merged; without it the operator merges every key
    of the matched lookup value, which is only knowable when `lookup` is a
    literal in the YAML. Both are read; nothing is guessed.
    """
    cols: List[str] = []
    fields = params.get("fields")
    if isinstance(fields, list):
        cols.extend(str(f) for f in fields if f)
        return cols
    lookup = params.get("lookup")
    if isinstance(lookup, dict):
        for value in lookup.values():
            if isinstance(value, dict):
                cols.extend(str(k) for k in value)
    return cols


def _columns_written_by_step(step: Dict[str, Any]) -> Tuple[List[str], bool]:
    """Columns one pipeline step writes → `(columns, unknowable)`.

    `unknowable=True` marks a step whose written set cannot be derived
    statically (`unpack`), so the caller can record the gap rather than silently
    under-report.

    ⛔ EACH BRANCH MIRRORS THAT OPERATOR'S OWN `compile()` IN
    `torana_mesh/etl/operators/<op>.py`. See the MAINTENANCE CONTRACT at the top.

    If you add an operator that writes columns, or change WHERE an existing one
    takes its column names from, you MUST update the matching branch here and
    add the op to `COLUMN_WRITING_OPS`. This coupling is invisible from the
    operator's side — nothing in `operators/` points back at this file — so it is
    the easiest thing in the module to break by accident.
    """
    op = str(step.get("op") or "").strip()
    params = step.get("params")
    if not isinstance(params, dict):
        params = {}

    if op in ("derive", "pack", "combine"):
        # DeriveOperator/PackOperator/CombineOperator: `params.target`.
        target = params.get("target")
        return ([str(target)] if target else []), False

    if op == "set":
        # ⚠️ SetOperator does `new_rec.update(params)` — EVERY KEY is a column.
        # The `target:` grep misses all of these.
        return [str(k) for k in params], False

    if op == "rename":
        # ⚠️ RenameOperator writes the VALUES of `map` (src → dst). The keys are
        # the vendor's field names and are not columns.
        field_map = params.get("map")
        if isinstance(field_map, dict):
            return [str(v) for v in field_map.values() if v], False
        return [], False

    if op == "enrich":
        return _writers_from_enrich(params), False

    if op == "unpack":
        # ⚠️ Keys come from a runtime JSON blob. `fields` narrows it when given;
        # otherwise the set is genuinely unknowable.
        fields = params.get("fields")
        prefix = str(params.get("prefix") or "")
        if isinstance(fields, list) and fields:
            return [f"{prefix}{f}" for f in fields], False
        return [], True

    # drop / filter / validate / upsert / derive_entity_edges / tee / route /
    # audit_sample / cve_enrich — write no column via the record. cve_enrich is
    # handled as an operator writer (mechanism 2), not here.
    return [], False


def writers_from_mapping_doc(
    doc: Dict[str, Any],
    *,
    source_label: str,
    default_source: str = "",
) -> Tuple[str, List[Tuple[str, str]], bool, Optional[str]]:
    """Parse ONE mapping document → `(table, [(column, op)], unknowable, family)`.

    Reads the same `metadata.destination_table` / `pipeline` shape
    `mapping_loader.parse_mapping` reads, so this cannot drift from what the ETL
    actually executes.
    """
    meta = doc.get("metadata") if isinstance(doc.get("metadata"), dict) else {}
    table = str(
        meta.get("destination_table") or doc.get("destination_table") or ""
    ).strip()
    family = str(meta.get("source") or doc.get("source") or default_source).strip()

    pipeline = doc.get("pipeline")
    if not isinstance(pipeline, list):
        return table, [], False, (family or None)

    written: List[Tuple[str, str]] = []
    unknowable = False
    for step in pipeline:
        if not isinstance(step, dict):
            continue
        cols, step_unknowable = _columns_written_by_step(step)
        unknowable = unknowable or step_unknowable
        op = str(step.get("op") or "")
        for col in cols:
            col = col.strip()
            # Staging fields (`_provenance_repo`) never reach a table — the
            # validate step drops anything not in the schema.
            if col and not col.startswith("_"):
                written.append((col, op))

    return table, written, unknowable, (family or None)


def _iter_mapping_files(mappings_dir: Path) -> Iterable[Tuple[Path, str]]:
    for path in sorted(mappings_dir.glob("*/*.y*ml")):
        yield path, path.parent.name


def collect_mapping_writers(
    rmap: ReachabilityMap,
    mappings_dir: Path,
    *,
    extra_docs: Optional[Iterable[Tuple[str, str, Dict[str, Any]]]] = None,
) -> None:
    """Add mechanism-1 writers from the mapping tree (and any DB overrides).

    `extra_docs` carries `(family, data_source, doc)` triples for tenant/platform
    mapping overrides that live in `etl_mapping_configs` rather than on disk —
    resolution order per `mapping_loader`. Passing them keeps a tenant override
    from being invisible to reachability.
    """
    import yaml

    docs: List[Tuple[str, str, Dict[str, Any]]] = []

    if mappings_dir.is_dir():
        for path, family in _iter_mapping_files(mappings_dir):
            try:
                loaded = yaml.safe_load(path.read_text())
            except Exception as exc:  # a broken YAML must not hide the rest
                rmap.parse_errors.append(f"{family}/{path.name}: {exc}")
                continue
            if isinstance(loaded, dict):
                docs.append((family, path.stem, loaded))

    if extra_docs:
        docs.extend(extra_docs)

    for family, data_source, doc in docs:
        label = f"{family}/{data_source}"
        table, written, unknowable, parsed_family = writers_from_mapping_doc(
            doc, source_label=label, default_source=family
        )
        rmap.mappings_parsed += 1
        if unknowable:
            rmap.unknowable.append(label)
        if not table:
            # No destination_table → nothing lands in a sink table.
            continue
        for column, op in written:
            rmap.add(
                table,
                column,
                Writer(
                    kind=KIND_MAPPING,
                    source=f"mappings/{label}.yaml",
                    integration=parsed_family or family,
                    detail=f"op:{op}",
                ),
            )


# ── Mechanism 3: the decoration registry ─────────────────────────────────────


def writers_from_decorations(rmap: ReachabilityMap) -> None:
    """Add mechanism-3 writers by IMPORTING the registry (never regex).

    A decoration is a platform-asserted fact, so it depends on the decoration
    job running rather than on any one integration being connected —
    `integration=None` marks it unconditional in both scopes. That is what makes
    `cisa_kev_data` correctly reachable for a tenant with no scanner connected
    but CVE rows present.
    """
    try:
        from pantheon_shared.datalake.decorations import DECORATIONS
    except Exception as exc:
        rmap.parse_errors.append(f"decorations import failed: {exc}")
        return

    try:
        from pantheon_shared.datalake.decorations import (
            PROVENANCE_COLUMN,
            VERSION_COLUMN,
        )
    except Exception as exc:  # pragma: no cover - import guarded above
        rmap.parse_errors.append(f"decorations provenance import failed: {exc}")
        return

    for name, spec in DECORATIONS.items():
        table = getattr(spec, "decorates", "")
        provides = getattr(spec, "provides", {}) or {}
        # ⛔ The provenance PAIR is written by every decoration apply, on EVERY
        # sink it decorates — `runtime.py` stamps it alongside `provides` rather
        # than declaring it, so it appears in no `provides` dict anywhere.
        #
        # ⚠️ Deriving it here (rather than hand-listing it) is the whole point.
        # It was previously covered only by two hand-written `_OPERATOR_WRITERS`
        # entries naming `vulnerabilities`, so the moment a decoration landed on
        # a SECOND sink the pair went unreported for it: measured 2026-08-13,
        # `assets.decoration_provenance` / `decoration_version` reported
        # UNREACHABLE while holding 733 rows written by `governance_cluster`.
        # That is a reporting defect that renders as a build defect that does
        # not exist — and it recurs for every future sink unless it is derived.
        for column in list(provides) + [PROVENANCE_COLUMN, VERSION_COLUMN]:
            rmap.add(
                table,
                column,
                Writer(
                    kind=KIND_DECORATION,
                    source=f"DECORATIONS.{name}",
                    integration=None,
                    detail=f"scope:{getattr(spec, 'scope', '')}",
                ),
            )


# ── Mechanism 2: ETL operator code ───────────────────────────────────────────
#
# Columns written by operator CODE rather than by a mapping's params. Small and
# closed: found by grepping every `rec[...] = ` / `record[...] = ` assignment
# under `torana_mesh/etl/` and keeping the ones that land in a sink table.
#
# `cve_enrich` is registry-driven — `_fill_from_facts` iterates
# `DECORATIONS['cve_intel'].provides`, so those columns are already covered by
# mechanism 3. What is listed here is only what the operator writes BEYOND the
# registry: the two SLA columns computed by `_apply_sla` from the tenant's
# resolved policy, and the provenance pair stamped alongside them.
#
# ⛔ HAND-MAINTAINED — mechanism 2. See the MAINTENANCE CONTRACT at the top.
#
# ADD AN ENTRY HERE whenever an ETL operator writes a sink column from PYTHON
# rather than from mapping params (`rec["col"] = …`). Nothing derives this: the
# column name exists only in operator code, so a new operator that forgets this
# list makes its column report `reachable=False` — which the audit renders as a
# 🔴 build defect that does not exist.
#
# `validate_against_populated()` is the safety net, not a substitute: it catches
# the omission only once that column actually holds data in the tenant you check.

_OPERATOR_WRITERS: Tuple[Tuple[str, str, str, str], ...] = (
    # (table, column, source, detail)
    ("vulnerabilities", "vulnerability_due_date",
     "etl/operators/cve_enrich.py", "_apply_sla (policy window)"),
    ("vulnerabilities", "vulnerability_sla_breach_date",
     "etl/operators/cve_enrich.py", "_apply_sla (policy window)"),
    # ⛔ The `decoration_provenance` / `decoration_version` pair used to be listed
    # here for `vulnerabilities` ONLY. It is now DERIVED for every decorated sink
    # in `writers_from_decorations()` (mechanism 3), because a hand-written entry
    # covers exactly the tables someone remembered — which is how `assets` came to
    # report the pair UNREACHABLE while holding 733 decorated rows. Do not re-add
    # it here; adding a decoration to a new sink must not require an edit.
    ("artifacts", "container_image_id",
     "etl/manifest_interpret.py", "manifest interpretation"),
)

# `datalake_adapter.py` stamps these on EVERY record it writes, for every table.
_ADAPTER_WRITTEN: Tuple[str, ...] = (
    "tenant_id", "namespace_id", "is_deleted", "updated_at", "contributing_sources",
)


def writers_from_operators(rmap: ReachabilityMap, tables: Iterable[str]) -> None:
    """Add mechanism-2 writers (operator code) and the adapter's per-row stamps."""
    for table, column, source, detail in _OPERATOR_WRITERS:
        rmap.add(
            table,
            column,
            Writer(kind=KIND_OPERATOR, source=source, integration=None, detail=detail),
        )

    for table in tables:
        for column in _ADAPTER_WRITTEN:
            rmap.add(
                table,
                column,
                Writer(
                    kind=KIND_OPERATOR,
                    source="etl/datalake_adapter.py",
                    integration=None,
                    detail="stamped on every written record",
                ),
            )


# ── Mechanism 5: push ingestors ──────────────────────────────────────────────
#
# A push ingestor yields `(table, records)` straight to the datalake adapter, so
# its columns are named in PYTHON, never in a mapping. `sarif/packages.yaml`
# says so in its own header: "the SARIF ingestor already shaped
# torana_package_id / purl / name / version / package_manager".
#
# Read off the record literals in `torana_mesh/etl/ingestors/`. An ingestor is
# push-based (no scheduled sync, no connected integration), so `integration` is
# the ingest SOURCE — `sarif` for a scan push, `asset` for an inventory push.
#
# ⛔ HAND-MAINTAINED — mechanism 5. See the MAINTENANCE CONTRACT at the top.
#
# ADD AN ENTRY HERE whenever you add an ingestor under `etl/ingestors/`, or
# change which columns an existing one shapes. Ingestors yield `(table, records)`
# straight to the datalake adapter, so NO mapping op ever names their columns and
# nothing here can derive them.

_INGESTOR_WRITERS: Tuple[Tuple[str, Tuple[str, ...], str, Optional[str]], ...] = (
    (
        "packages",
        ("torana_package_id", "purl", "name", "version", "package_manager"),
        # Corrected 2026-08-06: this named `_pkg_record`, a symbol that has not
        # existed for some time — the method is `_package_record`. The count did
        # not change (the columns were right), which is exactly why nobody
        # noticed: a stale hand-written tuple does not fail, it just quietly
        # stops being checkable against the code it claims to describe.
        "etl/ingestors/sarif.py::SarifIngestor._package_record",
        "sarif",
    ),
    (
        # Added 2026-08-06: the third of three ingestors was absent entirely.
        # `asset.py` routes on `asset_kind` and yields to THREE different sink
        # tables. Most of its record keys are consumed by the mapping's rename /
        # derive steps (already mechanism 1) or are `_`-prefixed staging fields
        # that never reach a table; listed here are the columns the ingestor
        # itself names in Python, which no mapping op mentions.
        "assets",
        ("torana_entity_id", "service_name", "source_system", "description"),
        "etl/ingestors/asset.py::AssetIngestor._flatten_service",
        "asset",
    ),
    (
        "datastores",
        ("datastore_id", "pii_data", "source_system", "description"),
        "etl/ingestors/asset.py::AssetIngestor._flatten_datastore",
        "asset",
    ),
    (
        "repositories",
        ("source_system", "description", "reviewed", "field_provenance"),
        "etl/ingestors/asset.py::AssetIngestor._flatten",
        "asset",
    ),
    (
        "entity_edges",
        # ⚠️ `occurrence_count` was listed here until 2026-08-19 and is NOT a column on
        # `entity_edges` at all — it belongs to `entity_edge_candidates`, written by
        # `etl/entity_graph/candidate_writer.py`. It was inert (the map is constrained by
        # `declared`, so a writer for a non-existent column is dropped), but a claim about
        # the wrong TABLE is exactly the drift this list's MAINTENANCE CONTRACT warns about:
        # the next reader treats it as evidence the column exists. Removed.
        #
        # ⚠️ `created_via` / `first_seen` / `last_seen` are NOT shaped by this ingestor —
        # the module docstring is explicit that the stateful merge (first_seen preservation
        # et al.) runs in the API handler's fetch-merge path, not here. They are kept in this
        # tuple because the ingestor is still the ETL entry point that makes them reachable,
        # and their live seam verdict is NEEDS_CALLER (correct: an external producer must
        # POST the document). ⛔ Do not "tidy" them out without re-running the §1.3 invariant.
        ("from_key", "to_key", "edge_type", "confidence", "evidence",
         "description", "source_system", "created_via", "first_seen",
         "last_seen"),
        "etl/ingestors/entity_edge.py",
        None,   # edges converge from every source; not one integration's
    ),
)


def writers_from_ingestors(rmap: ReachabilityMap) -> None:
    """Add mechanism-5 writers (push ingestors that bypass the mapping tree)."""
    for table, columns, source, integration in _INGESTOR_WRITERS:
        for column in columns:
            rmap.add(
                table,
                column,
                Writer(
                    kind=KIND_INGESTOR,
                    source=source,
                    integration=integration,
                    detail="shaped by the ingestor before any mapping step",
                ),
            )


# ── Mechanism 6: extractor / service composition ─────────────────────────────
#
# The column is composed in extractor or service code while the mapping only
# derives the join key. Small and specific; each entry names the code site that
# proves it.
#
# ⛔ HAND-MAINTAINED — mechanism 6. See the MAINTENANCE CONTRACT at the top.
#
# ADD AN ENTRY HERE when an EXTRACTOR builds a column the mapping never names
# (the GitHub Teams extractor fusing Teams API + CODEOWNERS into
# `repositories.teams` is the reference case), or when a SERVICE writes rows
# directly (`services/reconciliation.py` → `findings.finding_subcategory`).
# Reading the mapping alone will always miss these.

_EXTRACTOR_WRITERS: Tuple[Tuple[str, str, str, Optional[str], str], ...] = (
    ("repositories", "teams", "etl/extractors/github.py::GitHubRepoTeamsExtractor",
     "github", "fuses Teams API + CODEOWNERS into repositories.teams"),
    ("findings", "finding_subcategory", "services/reconciliation.py",
     None, "asset-reconciliation findings written by the service"),
)


def writers_from_extractors(rmap: ReachabilityMap) -> None:
    """Add mechanism-6 writers (extractor/service-composed columns)."""
    for table, column, source, integration, detail in _EXTRACTOR_WRITERS:
        rmap.add(
            table,
            column,
            Writer(
                kind=KIND_EXTRACTOR,
                source=source,
                integration=integration,
                detail=detail,
            ),
        )


# ── Mechanism 7: validate-passthrough ────────────────────────────────────────
#
# `validate` defaults `on_extra_field="keep"`, so a vendor field whose name
# matches a schema column lands even though no step names it. Statically this is
# unknowable — it depends on the vendor's live response.
#
# Rather than hard-code the one column the invariant caught, the OBSERVED
# passthrough is supplied by the caller from live data: a (table, column) that
# holds data, has no other writer, and belongs to a mapping whose validate keeps
# extras. That keeps the map honest (the column IS written) without pretending
# the parse predicted it.


def writers_from_observed_passthrough(
    rmap: ReachabilityMap,
    observed: Iterable[Tuple[str, str, Optional[str]]],
) -> None:
    """Record columns proven written by passthrough, with `source_system` provenance.

    `observed` is `(table, column, source_system)` measured from live data. Only
    called for columns that have NO other writer — a passthrough writer never
    masks a real one, so the map still names the true pipeline where one exists.
    """
    for table, column, source_system in observed:
        if rmap.is_reachable(table, column, enabled=None):
            continue
        rmap.add(
            table,
            column,
            Writer(
                kind=KIND_PASSTHROUGH,
                source="etl/operators/validate.py (on_extra_field=keep)",
                integration=source_system,
                detail=(
                    "vendor field name matches a schema column; kept by validate. "
                    "Observed in live data — not statically derivable"
                ),
            ),
        )


# ── Mechanism 8: the declared write seam ─────────────────────────────────────
#
# ✅ DERIVED — nothing here is hand-maintained, and that is the entire point.
#
# An out-of-band write (an API endpoint merging caller-supplied fields into a row,
# a service writing findings directly) goes through NONE of mechanisms 1-7, so no
# amount of parsing can see it. Rather than add a tenth hand-written tuple to this
# module — the thing §1.2 of the spec is a report about — each such writer declares
# its own columns NEXT TO the code that writes them, via
# `pantheon_shared.datalake.write_seam.register_writer()`, and this function
# IMPORTS the resulting registry.
#
# ⛔ THE CONSEQUENCE THAT MATTERS: a new out-of-band writer appears in
# `--reachable` with NO EDIT TO THIS FILE. Same property that makes mechanisms 3
# and 4 undriftable — `DECORATIONS` and `system_fields` are imported, never
# regexed. A registry this module did NOT consume would be just another list to
# forget.
#
# The measured defect this closes: `PATCH /api/v1/ingest/vulnerabilities` writes
# `exploitability_status`, `exploit_evidence`, `exploit_verified_at` and
# `exploit_case_ref`, which NO other path writes — so this map reported them
# unreachable while the platform shipped the endpoint whose purpose is to write
# them, and 7 corpus questions were classified unanswerable on those grounds.


def writers_from_declared_seam(rmap: ReachabilityMap,
                               *, require_seam: bool = False) -> None:
    """Add mechanism-8 writers by IMPORTING the write-seam registry (never regex).

    Import is lazy and failure-tolerant for the same reason `writers_from_decorations`
    is: a broken/absent registry must degrade this map, never crash the caller that
    depends on it. A failure is recorded in `parse_errors` so it is visible rather
    than silently under-reporting.

    `integration=None` (the common case) marks the writer unconditional — an API
    endpoint or platform service does not depend on a customer having connected any
    integration, so it counts in BOTH tenant and platform scope.
    """
    try:
        from pantheon_shared.datalake.write_seam import WRITERS
    except Exception as exc:
        rmap.parse_errors.append(f"write_seam import failed: {exc}")
        return

    # ⭐ S22 (row 35). The registry is populated BY IMPORT, and the five modules that
    # call `register_writer()` live in `torana_mesh`. A process that cannot import them
    # — notably `pantheon-program-framework`, which is the ONLY process that has the app
    # bundles — sees an EMPTY registry here and would report ~12 written columns as
    # shadow. Measured: 20 registrations in pantheon-integration-dev, 0 in
    # pantheon-program-framework-dev, which is why B11/B13 had never once run on a
    # shipped bundle.
    #
    # So when the import produced nothing, FETCH the same facts over the reachability
    # API, which already serves every writer with its `kind`, `expected_caller` and
    # `bridge_id`. ⛔ The fetch RAISES rather than returning empty (see
    # `seam_source.SeamUnavailable`), so an unreachable registry still reaches the
    # callers as a refusal — never as a clean bill.
    #
    # ⚠️ Only when the import found NOTHING. Where the modules ARE importable the
    # in-process registry is first-hand and authoritative; a network read there could
    # only substitute a possibly-staler second-hand answer (workers cache their
    # registry, measured).
    #
    # ⛔ AND ONLY WHEN THE CALLER ASKED FOR IT (`require_seam=True`). This function is
    # the general-purpose map builder with many callers, most of which neither need
    # mechanism 8 nor can reach the network — a unit test on the host, a tenant-scope
    # query. Fetching unconditionally made `build_reachability_map` REQUIRE Docker DNS
    # and broke `test_new_registration_appears_in_reachable_without_editing_reachability`,
    # whose precondition is deliberately an EMPTY registry.
    #
    # ⭐ So the network call belongs to the VERDICT functions — `measure_shadow_set`,
    # `measure_caller_dependencies`, the shadow-column report — which are the ones that
    # would otherwise report written columns as shadow. They pass `require_seam=True`.
    if not WRITERS and require_seam:
        _fetch_declared_seam(rmap)
        return

    for reg in WRITERS.values():
        for column in reg.columns:
            rmap.add(
                reg.table,
                column,
                Writer(
                    kind=KIND_DECLARED,
                    source=f"{reg.source} [{reg.writer_id}]",
                    integration=reg.integration,
                    detail=reg.reason,
                    # The fact that makes `declared` different from the other seven:
                    # no sync will ever fill this column, so WHO is expected to call
                    # it decides whether "empty" means "not yet" or "never".
                    expected_caller=(
                        reg.expected_caller.as_dict()
                        if getattr(reg, "expected_caller", None) else None
                    ),
                    # ...and WHERE the callable contract for becoming that caller
                    # lives. Carried through so `--explain` (and the corpus rows
                    # derived from it) can hand a reader the actual call, not just
                    # the name of a caller that may not exist.
                    bridge_id=getattr(reg, "bridge_id", None),
                ),
            )


#: Set by `_fetch_declared_seam` when mechanism 8 came over the wire rather than by
#: import. ⚠️ Read by `measure_shadow_set` / `measure_caller_dependencies` so the count
#: they report is the count they actually SAW — a verdict that moves between runs is
#: only diagnosable if each run says where its inputs came from.
SEAM_ORIGIN_ATTR = "_seam_origin"


def _fetch_declared_seam(rmap: ReachabilityMap) -> None:
    """Populate mechanism 8 from the reachability API (S22 — see the caller's note).

    ⛔ Deliberately does NOT swallow `SeamUnavailable`. Every other writer-source in
    this module degrades to `parse_errors` because a missing mapping under-reports one
    integration; this one is different in kind — with mechanism 8 absent, ~12 columns
    that ARE written are reported as shadow, and `parse_errors` stays empty, so the
    wrongness is SILENT. That silence is the defect the whole row exists to remove, so
    the exception propagates to the caller, which turns it into a refusal.
    """
    from pantheon_shared.datalake.seam_source import (
        SeamUnavailable,
        fetch_seam_writers,
        seam_fetch_enabled,
    )

    if not seam_fetch_enabled():
        raise SeamUnavailable(
            "the write-seam registry is EMPTY and the fetch fallback is disabled "
            "(SEAM_FETCH_DISABLED). Mechanism 8 contributed no writers, so shadow and "
            "caller-dependency verdicts would be wrong — refusing rather than guessing."
        )

    snapshot = fetch_seam_writers()
    for (table, column), writers in snapshot.writers.items():
        for w in writers:
            rmap.add(table, column, Writer(
                kind=w.kind,
                source=w.source,
                integration=w.integration,
                detail=w.detail,
                expected_caller=w.expected_caller,
                bridge_id=w.bridge_id,
            ))
    # ⛔ The fetched payload supplied EVERY mechanism, so the local parse failures it
    # replaces are no longer defects in this map — chiefly "mapping tree not found",
    # which is the normal state wherever `torana_mesh` is absent. Leaving them would
    # make a complete map look degraded and invite a reader to distrust a correct
    # answer. Recorded as a note instead, so the substitution stays visible.
    rmap.parse_errors[:] = [
        e for e in rmap.parse_errors if "mapping tree not found" not in e
    ]
    rmap.parse_errors.append(
        f"mechanisms supplied by FETCH from {snapshot.origin} "
        f"({snapshot.registration_count} declared registrations) — the local process "
        f"cannot import torana_mesh, so no mechanism was parsed here"
    )
    setattr(rmap, SEAM_ORIGIN_ATTR, snapshot)


# ── Mechanism 4: system fields ───────────────────────────────────────────────


def writers_from_system_fields(rmap: ReachabilityMap, tables: Iterable[str]) -> None:
    """Add the auto-injected system fields for every table.

    Not in the source document's three mechanisms; without it the §1.3 invariant
    fails on seven obviously-populated columns per table.
    """
    for table in tables:
        for column in sorted(SYSTEM_WRITTEN_COLUMNS):
            rmap.add(
                table,
                column,
                Writer(
                    kind=KIND_SYSTEM,
                    source="datalake/schemas/system_fields.py",
                    integration=None,
                    detail="auto-injected into every table",
                ),
            )


# ── Assembly ─────────────────────────────────────────────────────────────────


def default_mappings_dir() -> Optional[Path]:
    """Locate the mapping tree.

    `TORANA_MAPPINGS_DIR` wins so the datalake container can mount or point at
    the tree it does not own. Otherwise fall back to an installed
    `torana_mesh` package, then to a sibling checkout.
    """
    env = os.getenv("TORANA_MAPPINGS_DIR")
    if env:
        p = Path(env)
        if p.is_dir():
            return p

    try:
        import torana_mesh  # type: ignore

        p = Path(torana_mesh.__file__).parent / "mappings"
        if p.is_dir():
            return p
    except Exception:
        pass

    here = Path(__file__).resolve()
    for parent in here.parents:
        candidate = parent / "pantheon-integration" / "torana_mesh" / "mappings"
        if candidate.is_dir():
            return candidate
    return None


def build_reachability_map(
    *,
    tables: Iterable[str],
    mappings_dir: Optional[Path] = None,
    extra_docs: Optional[Iterable[Tuple[str, str, Dict[str, Any]]]] = None,
    declared: Optional[Dict[str, Iterable[str]]] = None,
    require_seam: bool = False,
) -> ReachabilityMap:
    """Build the full (table, column) → writers map from all four mechanisms.

    `tables` is the canonical sink-table set; system fields and adapter stamps
    apply to each. Nothing here touches tenant data — the map is a PLATFORM
    fact. Tenant scope is applied afterwards by filtering on enabled
    integrations, which is what keeps `reachable` from drifting into
    `populated`.

    ⚠️ **Pass `declared` whenever you have it.** It is `{table: [columns]}` from
    the schema registry, and it CONSTRAINS the map to columns that actually
    exist on that table. Without it the map over-reports two ways, both measured:

      * system fields are stamped onto every table, including tables that do not
        declare them (`artifacts` has no `created_at`);
      * a mapping can `derive`/`set` a field the destination table does not
        declare (`goal`, `end_date`) — the `validate` step drops it before the
        upsert, so it is written to the RECORD but never to the TABLE.

    Both produce a writer for a column that cannot hold data, which inflates
    "reachable" against a denominator that never contained it. Measured on this
    tenant: 105 phantom pairs, 341 -> 236.
    """
    rmap = ReachabilityMap()
    tables = list(tables)
    if declared is not None:
        rmap.declared = {
            str(t).lower(): {str(c).lower() for c in cols}
            for t, cols in declared.items()
        }

    mdir = mappings_dir or default_mappings_dir()
    if mdir is None:
        rmap.parse_errors.append(
            "mapping tree not found; set TORANA_MAPPINGS_DIR "
            "(mechanism-1 writers are MISSING from this map)"
        )
    else:
        collect_mapping_writers(rmap, mdir, extra_docs=extra_docs)

    writers_from_decorations(rmap)
    writers_from_operators(rmap, tables)
    writers_from_ingestors(rmap)
    writers_from_extractors(rmap)
    writers_from_declared_seam(rmap, require_seam=require_seam)
    writers_from_system_fields(rmap, tables)
    return rmap


# ── The §1.3 invariant ───────────────────────────────────────────────────────


@dataclass
class InvariantResult:
    """Result of "every populated column has at least one writer"."""

    checked: int = 0
    violations: List[Tuple[str, str]] = field(default_factory=list)
    passthrough: List[Tuple[str, str]] = field(default_factory=list)
    """Columns whose ONLY writer is an observed passthrough. The invariant holds
    (data proves a write), but the parse did not predict it — reported
    separately so a statically-underivable write is never counted as a clean
    derivation."""

    @property
    def passed(self) -> bool:
        return not self.violations

    def summary(self) -> str:
        if not self.passed:
            return (
                f"FAIL — {len(self.violations)} of {self.checked} populated columns "
                f"have NO writer (parse bug, not a data anomaly)"
            )
        if self.passthrough:
            return (
                f"PASS — {self.checked} populated columns, all have a writer "
                f"({len(self.passthrough)} only via observed validate-passthrough, "
                f"which is not statically derivable)"
            )
        return f"PASS — {self.checked} populated columns, all have a writer"


def validate_against_populated(
    rmap: ReachabilityMap,
    populated: Iterable[Tuple[str, str]],
) -> InvariantResult:
    """Task §1.3: every column holding data MUST have at least one writer.

    A violation is a **parse bug** — the data proves a writer exists, so the map
    failed to find it. Fix the parse; never explain it away as a data anomaly.

    The converse is NOT checked and is NOT an error: a column with a writer and
    no data is legitimately reachable-but-empty (integration enabled, not yet
    synced).

    Checked against PLATFORM scope deliberately. A tenant-scope check would
    fail wherever data was loaded by a since-disabled integration or seeded
    outside the enabled set — which says nothing about whether the parse works.
    """
    result = InvariantResult()
    for table, column in populated:
        result.checked += 1
        entry = rmap.get(table, column)
        if entry is None or not entry.reachable:
            result.violations.append((table.lower(), column.lower()))
        elif all(w.kind == KIND_PASSTHROUGH for w in entry.writers):
            result.passthrough.append((table.lower(), column.lower()))
    return result
