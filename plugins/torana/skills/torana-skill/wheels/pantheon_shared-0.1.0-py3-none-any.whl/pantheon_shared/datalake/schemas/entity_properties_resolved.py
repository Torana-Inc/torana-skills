from typing import Dict, Any
from .base import TableSchema


class EntityPropertiesResolvedSchema(TableSchema):
    """Schema for the ``entity_properties_resolved`` table (S26 § 3.3.2).

    A **DERIVED, per-tenant** lookup — one row per governed or inheriting entity
    key — that carries governance asserted on a DEPLOYMENT (stamped onto
    ``service:`` asset rows) across to the entities that key differently
    (``image:`` nodes, on which the vulnerabilities hang). The two live in
    different entity namespaces, so the bundles' join goes through this table
    rather than a shared column that does not exist.

    ⚠️ ``kind="derived"``, NOT a sink — and that is a property of the TABLE, not
    of a caller's convenience (S26 § 3.3.1). It is fully rebuildable from sink
    data by ``ResolutionBuilder`` (pantheon-integration
    ``services/property_resolution.py``), so dropping it loses no information —
    it is recreated empty on the next reconcile and repopulated by the next
    rebuild. It therefore carries **NO reachability / write-seam claim**, and
    must never be added to the sink set: doing so would give it a contract it
    cannot honour (S26 § 3.6.6, constraint C2).

    ⛔ Declared here, and ONLY here. Until S26 this schema lived as a Python
    dict inside ``property_resolution._ensure_table``, in a different repo from
    the reconciler that owns tenant schema — so the table was created lazily on
    first rebuild, existed on some tenants and not others, and was
    **unmigratable** (Alembic cannot carry a revision for a table the reconciler
    never provisions). Declaring it makes it provisioned with every other
    per-tenant table and ALTERable like any of them.

    ⚠️ ``description`` is declared as a BUSINESS column deliberately. It is not
    one of the injected system fields, and the resolver writes it per row
    ("Resolved domain properties for <entity_key>"), matching the platform
    convention that every entity carries a semantic description. Do not remove
    it expecting ``get_full_schema()`` to supply one — it will not.

    ⭐ PRIMARY KEY ``entity_key`` is LOAD-BEARING (S26 constraint C5).
    ``upsert()`` writes ``ON CONFLICT (entity_key)``, which **fails outright**
    without a matching unique constraint. Lake tables are per-tenant-schema, so
    ``entity_key`` alone is unique.

    System fields (IAM, lifecycle, audit, trace, provenance) are injected by
    ``get_full_schema()`` — do NOT declare them here.
    """

    @property
    def table_name(self) -> str:
        return "entity_properties_resolved"

    @property
    def primary_key(self) -> str:
        return "entity_key"

    @property
    def description(self) -> str:
        return (
            "Resolved domain properties per entity key (one row per governed or "
            "inheriting entity): owning team, owner, environment, criticality, "
            "public-access and customer-data flags, with the provenance of each "
            "resolution. A DERIVED table, rebuilt from deployment governance + "
            "entity-graph edges — it carries no reachability claim of its own."
        )

    @property
    def category(self) -> str:
        return "Entity Graph"

    @property
    def timestamp_column(self) -> str:
        return "updated_at"

    @property
    def schema(self) -> Dict[str, Any]:
        return {
            # ⛔ PK — ON CONFLICT depends on it. See the class docstring (C5).
            "entity_key": {
                "data_type": "TEXT", "primary_key": True, "not_null": True,
                "category": "Core Identity",
            },
            "entity_kind": {"data_type": "TEXT", "category": "Core Identity"},
            # The resolved governance itself.
            "asset_team": {"data_type": "TEXT", "category": "Governance"},
            "asset_owner": {"data_type": "TEXT", "category": "Governance"},
            "asset_environment": {"data_type": "TEXT", "category": "Governance"},
            "criticality_name": {"data_type": "TEXT", "category": "Governance"},
            "criticality_level": {"data_type": "INTEGER", "category": "Governance"},
            "public_access": {"data_type": "BOOLEAN", "category": "Governance"},
            "has_customer_data": {"data_type": "BOOLEAN", "category": "Governance"},
            # ⛔ MUST be declared HERE as well as on `assets`. This table is the
            # RESOLUTION TARGET (`property_resolution.RESOLVED_TABLE`), so a governed
            # property missing from it is stripped by the upsert — the write logs a
            # successful row count against a column that does not exist, and every
            # consumer reads the default forever. MEASURED 2026-09-07: `image_ownership`
            # shipped on `assets` (5 schemas) and NOT here (0), and MET-003 (corpus
            # EM-101) — which joins this table — failed with HTTP 400.
            "image_ownership": {"data_type": "TEXT", "category": "Governance"},
            # How each value above was resolved (which deployment, via which edge).
            "provenance": {"data_type": "JSONB", "category": "Provenance"},
            # Generation stamp — rows from an older generation are tombstoned.
            "resolved_generation": {"data_type": "TEXT", "category": "Provenance"},
            # ⚠️ BUSINESS column, not a system field — see the class docstring.
            "description": {"data_type": "TEXT", "category": "Core Identity"},
        }
