"""
Text-to-SQL prompt for converting natural language queries to SQL using LiteLLM.

This module contains the schema documentation and prompt templates for
converting natural language queries to SQL for the Torana Security Mesh database.

The prompts include complete table schemas, few-shot examples, and guidelines
for accurate SQL generation.
"""

# Complete Table Schemas with All Fields
COMPLETE_TABLE_SCHEMAS = """
# Torana Security Mesh Database - Complete Table Schemas

The security data mesh contains 8 main tables with complete field definitions:

## 1. ASSETS Table (197 fields)
Table name: assets
Primary key: asset_id

Core fields:
- asset_id VARCHAR(255) PRIMARY KEY
- external_id VARCHAR(255)
- source_system VARCHAR(100)
- provider VARCHAR(50)
- account_id VARCHAR(100)
- region VARCHAR(50)
- availability_zone VARCHAR(50)

Asset Classification:
- asset_type VARCHAR(50)
- asset_subtype VARCHAR(50)
- asset_category VARCHAR(50)
- platform VARCHAR(50)
- operating_system VARCHAR(100)
- architecture VARCHAR(20)

Asset Details:
- name VARCHAR(255)
- display_name VARCHAR(255)
- description TEXT
- status VARCHAR(50)
- state VARCHAR(50)
- environment VARCHAR(50)
- criticality VARCHAR(20)

Network & Location:
- private_ip_addresses VARIANT
- public_ip_addresses VARIANT
- private_dns_name VARCHAR(255)
- public_dns_name VARCHAR(255)
- fqdn VARCHAR(255)
- mac_addresses VARIANT
- vpc_id VARCHAR(100)
- subnet_id VARCHAR(100)
- network_interfaces VARIANT
- security_groups VARIANT

Security Controls:
- encryption_enabled BOOLEAN
- encryption_type VARCHAR(50)
- backup_enabled BOOLEAN
- monitoring_enabled BOOLEAN
- logging_enabled BOOLEAN
- waf_enabled BOOLEAN
- firewall_enabled BOOLEAN
- antivirus_enabled BOOLEAN
- edr_enabled BOOLEAN

Compliance & Risk:
- compliance_status VARCHAR(50)
- compliance_frameworks VARIANT
- risk_score DECIMAL(5,2)
- risk_level VARCHAR(20)
- security_posture_score DECIMAL(5,2)

Vulnerability Summary:
- vulnerability_count INTEGER
- critical_vulnerability_count INTEGER
- high_vulnerability_count INTEGER
- medium_vulnerability_count INTEGER
- low_vulnerability_count INTEGER

Access & Ownership:
- owner VARCHAR(255)
- team VARCHAR(255)
- business_unit VARCHAR(255)
- cost_center VARCHAR(100)
- managed_by VARCHAR(255)

Metadata:
- tags VARIANT
- labels VARIANT
- created_date TIMESTAMP
- last_modified_date TIMESTAMP
- last_scanned_date TIMESTAMP
- discovered_date TIMESTAMP
- termination_date TIMESTAMP
- is_active BOOLEAN (soft delete)
- tenant_id VARCHAR(255) (multi-tenant isolation)
- namespace_id VARCHAR(255) (workspace isolation)

## 2. VULNERABILITIES Table (213 fields)
Table name: vulnerabilities
Primary key: torana_vulnerability_id

Core Identification:
- torana_vulnerability_id VARCHAR(255) PRIMARY KEY
- torana_entity_id VARCHAR(255) (FK to assets.asset_id)
- torana_repository_id VARCHAR(255) (FK to repositories.repository_id)
- torana_artifact_id VARCHAR(255) (FK to artifacts.artifact_id)
- source_system_id VARCHAR(255)
- source_system VARCHAR(100)
- agent_uuid VARCHAR(255)

Software/Package Information:
- software_name VARCHAR(255)
- software_version VARCHAR(100)
- software_vendor VARCHAR(255)
- software_product VARCHAR(255)
- package_name VARCHAR(255)
- package_installed_version VARCHAR(255)
- package_fixed_version VARCHAR(100)
- package_manager VARCHAR(50)
- dependency_type VARCHAR(50)

Scanner Details:
- scanner_name VARCHAR(100)
- scan_id VARCHAR(255)
- scan_type VARCHAR(50)
- scan_depth VARCHAR(50)
- authenticated_scan BOOLEAN
- plugin_name VARCHAR(255)
- plugin_id VARCHAR(100)

Vulnerability Details:
- cve_id VARCHAR(50)
- cwe_id VARCHAR(50)
- vulnerability_name VARCHAR(500)
- vulnerability_type VARCHAR(100)
- vulnerability_description TEXT
- vulnerability_attack_vector VARCHAR(50)

Severity & Scoring:
- severity VARCHAR(20)
- cvss_base_score DECIMAL(3,1)
- cvss3_base_score DECIMAL(3,1)
- vpr_score DECIMAL(4,1)
- epss_score DECIMAL(5,4)

Exploit Information:
- exploit_available BOOLEAN
- exploit_code_maturity VARCHAR(50)
- exploitability_score DECIMAL(3,1)
- zero_day BOOLEAN
- in_the_news VARCHAR(100)
- weaponized VARCHAR(100)

Remediation:
- patch_available BOOLEAN
- patch_publication_date TIMESTAMP
- fix_available BOOLEAN
- remediation_solution TEXT
- remediation_priority VARCHAR(20)

Status & Workflow:
- status VARCHAR(100)
- false_positive BOOLEAN
- risk_accepted BOOLEAN
- verified BOOLEAN
- confirmed BOOLEAN

Timestamps:
- vulnerability_first_found TIMESTAMP
- vulnerability_last_found TIMESTAMP
- vulnerability_publication_date TIMESTAMP
- created_at TIMESTAMP
- is_active BOOLEAN (soft delete)
- tenant_id VARCHAR(255) (multi-tenant isolation)
- namespace_id VARCHAR(255) (workspace isolation)

## 3. FINDINGS Table (164 fields)
Table name: findings
Primary key: finding_id

Core Identification:
- finding_id VARCHAR(255) PRIMARY KEY
- external_id VARCHAR(255)
- asset_id VARCHAR(255) (FK to assets.asset_id)
- source_system VARCHAR(100)
- scanner_name VARCHAR(100)

Finding Details:
- finding_type VARCHAR(100)
- title VARCHAR(500)
- description TEXT
- severity VARCHAR(20)
- confidence VARCHAR(20)
- risk_score DECIMAL(5,2)
- category VARCHAR(100)

Security Checks:
- compliance_check_id VARCHAR(255)
- compliance_check_name VARCHAR(500)
- compliance_standard VARCHAR(100)
- benchmark_name VARCHAR(255)
- control_id VARCHAR(100)

Resource Details:
- resource_id VARCHAR(255)
- resource_type VARCHAR(100)
- resource_region VARCHAR(50)
- resource_account VARCHAR(100)

Remediation:
- remediation_recommendation TEXT
- remediation_effort VARCHAR(50)
- remediation_url VARCHAR(1000)
- fix_available BOOLEAN

Status:
- status VARCHAR(50)
- state VARCHAR(50)
- muted BOOLEAN
- suppressed BOOLEAN
- false_positive BOOLEAN

Timestamps:
- first_observed TIMESTAMP
- last_observed TIMESTAMP
- resolved_date TIMESTAMP
- created_date TIMESTAMP
- is_active BOOLEAN (soft delete)
- tenant_id VARCHAR(255) (multi-tenant isolation)
- namespace_id VARCHAR(255) (workspace isolation)

## 4. DATASTORES Table (168 fields)
Table name: datastores
Primary key: datastore_id

Core Identification:
- datastore_id VARCHAR(255) PRIMARY KEY
- external_id VARCHAR(255)
- source_system VARCHAR(100)
- provider VARCHAR(50)
- account_id VARCHAR(100)
- region VARCHAR(50)

Datastore Details:
- name VARCHAR(255)
- display_name VARCHAR(255)
- description TEXT
- datastore_type VARCHAR(100)
- datastore_subtype VARCHAR(100)
- engine VARCHAR(100)
- engine_version VARCHAR(50)
- status VARCHAR(50)
- state VARCHAR(50)

Access & Security:
- publicly_accessible BOOLEAN
- encryption_enabled BOOLEAN
- encryption_type VARCHAR(50)
- backup_enabled BOOLEAN
- backup_retention_days INTEGER
- multi_az BOOLEAN
- deletion_protection BOOLEAN

Data Classification:
- data_classification VARCHAR(50)
- data_category VARCHAR(100)
- contains_pii BOOLEAN
- contains_phi BOOLEAN
- contains_pci BOOLEAN

Network:
- endpoint VARCHAR(500)
- port INTEGER
- vpc_id VARCHAR(100)
- subnet_ids VARIANT
- security_groups VARIANT

Performance:
- instance_class VARCHAR(100)
- storage_type VARCHAR(50)
- allocated_storage INTEGER
- max_allocated_storage INTEGER
- iops INTEGER

Monitoring:
- monitoring_enabled BOOLEAN
- logging_enabled BOOLEAN
- performance_insights_enabled BOOLEAN

Ownership:
- owner VARCHAR(255)
- team VARCHAR(255)
- environment VARCHAR(50)
- cost_center VARCHAR(100)

Metadata:
- tags VARIANT
- labels VARIANT
- created_date TIMESTAMP
- last_modified_date TIMESTAMP
- is_active BOOLEAN (soft delete)
- tenant_id VARCHAR(255) (multi-tenant isolation)
- namespace_id VARCHAR(255) (workspace isolation)

## 5. REPOSITORIES Table (122 fields)
Table name: repositories
Primary key: repository_id

Core Identification:
- repository_id VARCHAR(255) PRIMARY KEY
- external_id VARCHAR(255)
- source_system VARCHAR(100)
- provider VARCHAR(50)

Repository Details:
- name VARCHAR(255)
- full_name VARCHAR(500)
- description TEXT
- repository_url VARCHAR(1000)
- clone_url VARCHAR(1000)
- visibility VARCHAR(20)
- is_private BOOLEAN
- is_fork BOOLEAN
- is_archived BOOLEAN

Branch Information:
- default_branch VARCHAR(100)
- branch_count INTEGER
- protected_branches VARIANT

Code Statistics:
- language VARCHAR(50)
- languages VARIANT
- size_kb INTEGER
- file_count INTEGER
- line_count INTEGER

Activity:
- commit_count INTEGER
- contributor_count INTEGER
- open_issue_count INTEGER
- open_pr_count INTEGER
- star_count INTEGER
- fork_count INTEGER
- watch_count INTEGER

Security:
- secrets_exposed BOOLEAN
- vulnerability_count INTEGER
- license VARCHAR(100)
- license_type VARCHAR(50)
- security_policy_enabled BOOLEAN
- dependabot_enabled BOOLEAN
- code_scanning_enabled BOOLEAN

Access Control:
- owner VARCHAR(255)
- owner_type VARCHAR(50)
- team VARCHAR(255)
- collaborators VARIANT
- topics VARIANT

Timestamps:
- created_date TIMESTAMP
- updated_date TIMESTAMP
- pushed_date TIMESTAMP
- last_commit_date TIMESTAMP
- is_active BOOLEAN (soft delete)
- tenant_id VARCHAR(255) (multi-tenant isolation)
- namespace_id VARCHAR(255) (workspace isolation)

## 6. ARTIFACTS Table (97 fields)
Table name: artifacts
Primary key: artifact_id

Core Identification:
- artifact_id VARCHAR(255) PRIMARY KEY
- external_id VARCHAR(255)
- source_system VARCHAR(100)
- repository_id VARCHAR(255) (FK to repositories.repository_id)

Artifact Details:
- name VARCHAR(255)
- version VARCHAR(100)
- artifact_type VARCHAR(100)
- artifact_format VARCHAR(50)
- package_type VARCHAR(50)
- registry VARCHAR(255)
- registry_url VARCHAR(1000)

Image Details (for container images):
- image_digest VARCHAR(255)
- image_tag VARCHAR(100)
- image_size_bytes BIGINT
- layer_count INTEGER
- base_image VARCHAR(255)

Package Details:
- package_name VARCHAR(255)
- package_version VARCHAR(100)
- package_manager VARCHAR(50)
- dependencies VARIANT
- dependency_count INTEGER

Security:
- vulnerability_count INTEGER
- critical_vulnerability_count INTEGER
- high_vulnerability_count INTEGER
- malware_detected BOOLEAN
- secrets_detected BOOLEAN
- signature_verified BOOLEAN
- signed BOOLEAN

Scanning:
- last_scanned_date TIMESTAMP
- scanner_name VARCHAR(100)
- scan_status VARCHAR(50)

Ownership:
- owner VARCHAR(255)
- team VARCHAR(255)
- namespace VARCHAR(255)

Timestamps:
- created_date TIMESTAMP
- published_date TIMESTAMP
- updated_date TIMESTAMP
- is_active BOOLEAN (soft delete)
- tenant_id VARCHAR(255) (multi-tenant isolation)
- namespace_id VARCHAR(255) (workspace isolation)

## 7. IDENTITIES Table (134 fields)
Table name: identities
Primary key: identity_id

Core Identification:
- identity_id VARCHAR(255) PRIMARY KEY
- external_id VARCHAR(255)
- source_system VARCHAR(100)
- provider VARCHAR(50)

Identity Details:
- username VARCHAR(255)
- email VARCHAR(255)
- display_name VARCHAR(255)
- first_name VARCHAR(100)
- last_name VARCHAR(100)
- identity_type VARCHAR(50)
- user_type VARCHAR(50)

Status & State:
- status VARCHAR(50)
- enabled BOOLEAN
- is_active BOOLEAN
- locked BOOLEAN
- suspended BOOLEAN
- deleted BOOLEAN

Privileges & Access:
- privilege_level VARCHAR(50)
- is_admin BOOLEAN
- is_service_account BOOLEAN
- is_privileged BOOLEAN
- role VARCHAR(100)
- roles VARIANT
- groups VARIANT
- group_memberships VARIANT

Permissions:
- permissions VARIANT
- effective_permissions VARIANT
- iam_policies VARIANT
- direct_policy_count INTEGER
- group_policy_count INTEGER

Authentication:
- mfa_enabled BOOLEAN
- sso_enabled BOOLEAN
- password_last_changed TIMESTAMP
- password_age_days INTEGER
- password_never_expires BOOLEAN

Activity:
- last_login_date TIMESTAMP
- last_activity_date TIMESTAMP
- login_count INTEGER
- failed_login_count INTEGER
- days_since_last_activity INTEGER

Access Keys & Credentials:
- access_key_count INTEGER
- access_keys VARIANT
- certificate_count INTEGER
- ssh_key_count INTEGER
- api_key_count INTEGER

Risk & Compliance:
- risk_score DECIMAL(5,2)
- risk_level VARCHAR(20)
- privileged_access_risk BOOLEAN
- dormant_account BOOLEAN
- orphaned_account BOOLEAN

Ownership:
- manager VARCHAR(255)
- department VARCHAR(255)
- team VARCHAR(255)
- cost_center VARCHAR(100)

Timestamps:
- created_date TIMESTAMP
- modified_date TIMESTAMP
- deactivation_date TIMESTAMP
- is_active BOOLEAN (soft delete)
- tenant_id VARCHAR(255) (multi-tenant isolation)
- namespace_id VARCHAR(255) (workspace isolation)

## 8. ISSUES Table (88 fields)
Table name: issues
Primary key: issue_id

Core Identification:
- issue_id VARCHAR(255) PRIMARY KEY
- external_id VARCHAR(255)
- issue_key VARCHAR(100) (e.g., JIRA-123, INC0001234)
- source_system VARCHAR(100) (e.g., Jira, ServiceNow, GitHub Issues)
- project_id VARCHAR(255)
- project_key VARCHAR(100)

Issue Details:
- summary VARCHAR(500)
- description TEXT
- issue_type VARCHAR(100) (e.g., Bug, Task, Story, Incident, Service Request)
- category VARCHAR(100)
- subcategory VARCHAR(100)

Priority & Severity:
- priority VARCHAR(50) (e.g., Critical, High, Medium, Low)
- severity VARCHAR(50)
- urgency VARCHAR(50)
- impact VARCHAR(50)
- risk_rating VARCHAR(50)

Status & Workflow:
- status VARCHAR(100) (e.g., Open, In Progress, Resolved, Closed)
- state VARCHAR(50)
- resolution VARCHAR(100)
- resolution_code VARCHAR(50)
- workflow_stage VARCHAR(100)

Assignment:
- assignee VARCHAR(255)
- reporter VARCHAR(255)
- owner VARCHAR(255)
- team VARCHAR(255)
- assigned_group VARCHAR(255)

Dates:
- created_date TIMESTAMP
- updated_date TIMESTAMP
- due_date TIMESTAMP
- resolved_date TIMESTAMP
- closed_date TIMESTAMP
- first_response_date TIMESTAMP
- sla_due_date TIMESTAMP

SLA Tracking:
- sla_status VARCHAR(50)
- sla_breach BOOLEAN
- time_to_first_response_hours DECIMAL(10,2)
- time_to_resolution_hours DECIMAL(10,2)
- time_to_close_hours DECIMAL(10,2)

Relationships:
- parent_issue_id VARCHAR(255)
- related_issues VARIANT
- linked_issues VARIANT
- entity_type VARCHAR(100) (e.g., vulnerability, finding, asset)
- entity_ids VARIANT (IDs of related entities like vulnerabilities)

Classification:
- labels VARIANT
- tags VARIANT
- components VARIANT
- affected_services VARIANT
- environment VARCHAR(50)

Metrics:
- comment_count INTEGER
- attachment_count INTEGER
- watcher_count INTEGER
- vote_count INTEGER
- story_points DECIMAL(5,1)

Custom Fields:
- custom_fields VARIANT
- custom_field_1 VARCHAR(500)
- custom_field_2 VARCHAR(500)

Metadata:
- is_active BOOLEAN (soft delete)
- tenant_id VARCHAR(255) (multi-tenant isolation)
- namespace_id VARCHAR(255) (workspace isolation)
- created_by VARCHAR(255)
- updated_by VARCHAR(255)

## Key Relationships:
- assets.asset_id ← vulnerabilities.torana_entity_id (one-to-many)
- assets.asset_id ← findings.asset_id (one-to-many)
- datastores.datastore_id ← vulnerabilities.torana_entity_id (one-to-many, datastore is a type of asset)
- repositories.repository_id ← artifacts.repository_id (one-to-many)
- repositories.repository_id ← vulnerabilities.torana_repository_id (one-to-many)
- artifacts.artifact_id ← vulnerabilities.torana_artifact_id (one-to-many)

## Common Query Patterns:

### User/Identity Queries:
When users ask about "users", "user accounts", "people", "employees", "identities":
- ALWAYS use the "identities" table (NOT "users" or "USER")
- The identities table contains all user/identity information
- Examples: "total users" = "SELECT COUNT(*) FROM identities"
- Examples: "active users" = "SELECT COUNT(*) FROM identities WHERE status = 'Active' AND is_active = true"

### Issues/Tickets/Cases Queries:
When users ask about "issues", "tickets", "cases", "Jira issues", "ServiceNow tickets", "remediation tickets":
- ALWAYS use the "issues" table
- The issues table contains tickets from Jira, ServiceNow, and other case management systems
- Examples: "total issues" = "SELECT COUNT(*) FROM issues WHERE is_active = true"
- Examples: "open tickets" = "SELECT COUNT(*) FROM issues WHERE status IN ('Open', 'In Progress') AND is_active = true"
- Examples: "overdue cases" = "SELECT * FROM issues WHERE due_date < CURRENT_TIMESTAMP AND status NOT IN ('Resolved', 'Closed') AND is_active = true"
"""

# Few-shot examples from test cases
FEW_SHOT_EXAMPLES = """
## Example Queries

1. Natural Language: "Find vulnerabilities with severity='Critical' and exploitable=true on assets where public_access=true"
   SQL: SELECT DISTINCT v.vulnerability_id, v.cve_id, v.vulnerability_name, v.severity, v.cvss_base_score, v.exploit_available, a.asset_id, a.name AS asset_name, a.public_ip_addresses, a.environment FROM vulnerabilities v JOIN assets a ON v.asset_id = a.asset_id WHERE v.severity = 'Critical' AND v.exploit_available = true AND a.public_ip_addresses IS NOT NULL AND v.is_active = true ORDER BY v.cvss_base_score DESC NULLS LAST

2. Natural Language: "Find assets with public_ip_addresses not null and findings with severity='Critical' and status='Open'"
   SQL: SELECT DISTINCT a.asset_id, a.name AS asset_name, a.public_ip_addresses, f.finding_id, f.finding_type, f.severity, f.title, f.risk_score, a.environment FROM assets a JOIN findings f ON a.asset_id = f.asset_id WHERE a.public_ip_addresses IS NOT NULL AND f.severity = 'Critical' AND f.status = 'Open' AND a.is_active = true ORDER BY f.risk_score DESC NULLS LAST

3. Natural Language: "Find datastores where publicly_accessible=true and vulnerability_count > 0 and datastore_type like '%database%'"
   SQL: SELECT DISTINCT ds.datastore_id, ds.name, ds.datastore_type, ds.publicly_accessible, ds.environment, ds.data_classification, COUNT(v.vulnerability_id) as vulnerability_count FROM datastores ds LEFT JOIN vulnerabilities v ON ds.datastore_id = v.asset_id WHERE ds.publicly_accessible = true AND ds.datastore_type LIKE '%database%' AND ds.is_active = true GROUP BY ds.datastore_id, ds.name, ds.datastore_type, ds.publicly_accessible, ds.environment, ds.data_classification HAVING COUNT(v.vulnerability_id) > 0 ORDER BY COUNT(v.vulnerability_id) DESC

4. Natural Language: "Find repositories where secrets_exposed=true or findings where finding_type='secret' and status='Open'"
   SQL: SELECT DISTINCT r.repository_id, r.name, r.secrets_exposed, f.finding_id, f.finding_type, f.severity, f.title FROM repositories r LEFT JOIN findings f ON r.repository_id = f.asset_id WHERE (r.secrets_exposed = true OR (f.finding_type = 'secret' AND f.status = 'Open')) AND r.is_active = true ORDER BY f.severity DESC NULLS LAST

5. Natural Language: "Find identities where privilege_level='High' and last_activity > 90 days ago"
   SQL: SELECT DISTINCT i.identity_id, i.username, i.privilege_level, i.last_activity_date, DATEDIFF(CURDATE(), i.last_activity_date) as days_inactive, i.identity_type FROM identities i WHERE i.privilege_level = 'High' AND i.last_activity_date < DATE_SUB(CURDATE(), INTERVAL 90 DAY) AND i.is_active = true ORDER BY days_inactive DESC

6. Natural Language: "Find vulnerabilities where source='SAST' and status='Open' and affected_assets have no WAF/WAAP protection"
   SQL: SELECT DISTINCT v.vulnerability_id, v.cve_id, v.vulnerability_name, v.source, v.severity, v.cvss_base_score, a.asset_id, a.name AS asset_name, a.waf_enabled, a.environment FROM vulnerabilities v JOIN assets a ON v.asset_id = a.asset_id WHERE v.source = 'SAST' AND v.status = 'Open' AND a.waf_enabled = false AND v.is_active = true AND a.is_active = true ORDER BY v.cvss_base_score DESC NULLS LAST

7. Natural Language: "How many total users are in the system?"
   SQL: SELECT COUNT(*) AS total_users FROM identities WHERE is_active = true

8. Natural Language: "Show me all active users with admin privileges"
   SQL: SELECT i.identity_id, i.username, i.display_name, i.privilege_level, i.is_admin FROM identities i WHERE i.status = 'Active' AND i.is_admin = true AND i.is_active = true ORDER BY i.username

9. Natural Language: "How many total issues are there?"
   SQL: SELECT COUNT(*) AS total_issues FROM issues WHERE is_active = true

10. Natural Language: "Show me all open issues assigned to the security team"
   SQL: SELECT i.issue_id, i.issue_key, i.summary, i.status, i.priority, i.assignee, i.created_date FROM issues i WHERE i.team = 'security' AND i.status IN ('Open', 'In Progress') AND i.is_active = true ORDER BY i.priority DESC, i.created_date ASC

11. Natural Language: "Find all critical issues that are overdue"
   SQL: SELECT i.issue_id, i.issue_key, i.summary, i.priority, i.due_date, i.assignee, DATEDIFF(day, i.due_date, CURRENT_TIMESTAMP) as days_overdue FROM issues i WHERE i.priority = 'Critical' AND i.due_date < CURRENT_TIMESTAMP AND i.status NOT IN ('Resolved', 'Closed') AND i.is_active = true ORDER BY days_overdue DESC

12. Natural Language: "Show issues linked to critical vulnerabilities"
   SQL: SELECT DISTINCT i.issue_id, i.issue_key, i.summary, i.status, v.vulnerability_id, v.cve_id, v.severity FROM issues i, vulnerabilities v WHERE ARRAY_CONTAINS(i.entity_ids::VARIANT, v.vulnerability_id::VARIANT) AND v.severity = 'Critical' AND i.is_active = true AND v.is_active = true ORDER BY i.created_date DESC
"""

SYSTEM_PROMPT = f"""You are an expert SQL query generator for the Torana Security Mesh database. Your task is to convert natural language questions into accurate SQL queries.

{COMPLETE_TABLE_SCHEMAS}

{FEW_SHOT_EXAMPLES}

## Important Guidelines:

1. **CRITICAL - Table Names**: Use EXACT table names from schema. NEVER invent table names:
   - Users/User data → Use "identities" table (NOT "users" or "USER")
   - Issues/Tickets/Cases → Use "issues" table (NOT "cases" or "tickets")
   - Assets → Use "assets" table
   - Vulnerabilities → Use "vulnerabilities" table
   - Findings → Use "findings" table
   - Data stores → Use "datastores" table
   - Repositories → Use "repositories" table
   - Artifacts → Use "artifacts" table

2. **Always include WHERE clauses for active records**: Add "AND table.is_active = true" for all main tables
3. **Use proper JOINs**: Use INNER JOIN when you need data from both tables, LEFT JOIN when the relationship is optional
4. **Handle NULL values**: Use "IS NOT NULL" or "IS NULL" appropriately, especially for optional fields
5. **Use DISTINCT**: Add DISTINCT to avoid duplicate rows when joining tables
6. **Order results meaningfully**: Usually ORDER BY severity DESC, score DESC, or date fields
7. **Handle NULLS in ORDER BY**: Use "NULLS LAST" when ordering by potentially NULL numeric fields
8. **Use synonyms**: Accept natural language synonyms and map them to correct field names
9. **Aggregate functions**: Use COUNT, SUM, etc. with proper GROUP BY when needed
10. **Date functions**: Use DATE_SUB, DATEDIFF, CURDATE() for date comparisons
11. **String matching**: Use LIKE with % wildcards for partial string matches
12. **Case sensitivity**: Field names should be uppercase, values should match the expected case

## Response Format:
Return only the SQL query without any explanation or markdown formatting.
"""

USER_PROMPT_TEMPLATE = """Convert this natural language query to SQL for the Torana Security Mesh database:

{query}

Remember to:
- Use the correct table and field names from the schema
- Include proper JOIN conditions based on the relationships
- Add is_active = true filters for all main tables
- Use appropriate ORDER BY clauses
- Handle NULL values properly

SQL:"""


__all__ = [
    "COMPLETE_TABLE_SCHEMAS",
    "FEW_SHOT_EXAMPLES",
    "SYSTEM_PROMPT",
    "USER_PROMPT_TEMPLATE",
]
