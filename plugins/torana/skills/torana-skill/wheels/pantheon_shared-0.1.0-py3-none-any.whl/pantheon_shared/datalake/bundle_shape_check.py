"""The bundle staleness CHECK — per-artifact shape verdict (S19 / row 49).

⛔ THE VERSION IS THE TRIGGER, NEVER THE VERDICT. This is the design decision of the
row and the thing most easily got wrong, so it is stated once, here:

    same revision  → SKIP the whole check (fast path; nothing changed)
    delta          → resolve the SHAPE, then:
                       intact → INSTALL, and merely REPORT the delta
                       broken → REFUSE, naming the column and what changed about it

⛔ A VERSION CANNOT REFUSE ON ITS OWN, and this is measured rather than argued. All
three shipped bundles record `schema_revision='pre-versioning'`, and they came through
row 42's removal of 149 columns with only 3 B11 errors. A version-based refusal would
therefore refuse the entire shipped set on day one. Beyond that it would be
UNACTIONABLE: "your version is old" tells an operator nothing they can fix, whereas
"you read `vulnerabilities.epss_score`, whose type changed numeric → text" is a fix.

⛔ THE REFUSAL MUST NAME A COLUMN. Every `ShapeBreak` carries table, column, kind, and
both types, and `describe()` renders the sentence an operator acts on.

⚠️ GRANULARITY IS PER-ARTIFACT, and the bundle-level field cannot carry it. Measured
2026-08-10: `ciso_posture` reads SIX sink tables (entity_edges 3 · assets 3 ·
identities 3 · issues 2 · vulnerabilities 1 · repositories 1). One DDL change touching
`identities` invalidates 3 artifacts and is irrelevant to the other 56 — a bundle-level
verdict says "stale" for all 59, and a check that cries wolf gets routed around rather
than obeyed (S17 § 7A, a 37-false-positive guard).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Mapping, Optional, Set, Tuple

from .live_shape import EMPTY_NULL_FRAC, SINK_TABLES
from .schema_shape import ShapeBreak, compare_shape

#: ⛔ S20's sentinel for a bundle authored before schema versioning existed. Mirrored
#: (not imported) because this module lives in pantheon-shared and must not depend on
#: program-framework; the two are asserted equal by test.
PRE_VERSIONING_SCHEMA_REVISION = "pre-versioning"


@dataclass
class ArtifactShapeVerdict:
    """Per-artifact result. `unverifiable` is a REFUSAL, never a pass (see B11 posture)."""
    artifact_key: str
    link_id: str
    breaks: List[ShapeBreak] = field(default_factory=list)
    unverifiable: Optional[str] = None
    tables_read: List[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.breaks and not self.unverifiable

    def as_dict(self) -> Dict[str, Any]:
        return {
            "artifact_key": self.artifact_key,
            "link_id": self.link_id,
            "ok": self.ok,
            "tables_read": sorted(self.tables_read),
            "unverifiable": self.unverifiable,
            "breaks": [b.as_dict() for b in self.breaks],
        }


@dataclass
class BundleShapeReport:
    """Whole-bundle verdict. `refused` ⇒ do not install."""
    bundle_id: str
    recorded_revision: str
    live_revision: Optional[str]
    revision_delta: bool
    skipped: bool = False
    verdicts: List[ArtifactShapeVerdict] = field(default_factory=list)
    #: ⛔ THE THIRD AXIS, AND IT NEVER REFUSES. Columns the bundle's SQL uses as a ROW
    #: FILTER that hold no values on THIS tenant. Each entry:
    #:   {table, column, used_by[], message}
    #:
    #: ⚠️ WHY IT IS A WARNING WHILE THE OTHER TWO REFUSE — a category difference, not
    #: caution. A removed column and an incompatible type are PERMANENTLY broken: no
    #: action by the operator makes that install correct. EMPTY is a STATE. A tenant
    #: with no scanner today may connect one next week, at which point the same bundle
    #: is exactly right. Refusing would block a correct install.
    #:
    #: ⚠️ MEASURED, and this is the case it exists for: `mttr_by_severity` filters
    #: `WHERE vulnerability_resolution_date IS NOT NULL` on a column that is 0 of
    #: 86,696 on T2 (no scanner connected). The transformer runs green, the SQL is
    #: correct, the schema is correct, every existing gate passes — and the widget
    #: renders "No data available" forever.
    empty_predicate_columns: List[Dict[str, Any]] = field(default_factory=list)

    @property
    def broken(self) -> List[ArtifactShapeVerdict]:
        return [v for v in self.verdicts if not v.ok]

    @property
    def refused(self) -> bool:
        # ⛔ `empty_predicate_columns` is DELIBERATELY absent from this expression.
        # A populated warning must never turn into a refusal — see its field note.
        return bool(self.broken)

    def summary(self) -> str:
        if self.skipped:
            return (f"bundle '{self.bundle_id}': schema revision unchanged "
                    f"({self.recorded_revision!r}) — shape check skipped (fast path).")
        if not self.refused:
            note = ("the recorded revision differs from live "
                    f"({self.recorded_revision!r} → {self.live_revision!r}), but every "
                    f"column it reads is intact"
                    if self.revision_delta else "no revision delta")
            return (f"bundle '{self.bundle_id}': INSTALLS — {note}. "
                    f"{len(self.verdicts)} artifact(s) checked.")
        lines = [f"bundle '{self.bundle_id}': REFUSED — the schema it was authored "
                 f"against changed incompatibly."]
        for v in self.broken:
            if v.unverifiable:
                lines.append(f"  • artifact '{v.artifact_key}' (link {v.link_id}): "
                             f"COULD NOT VERIFY — {v.unverifiable}")
            for b in v.breaks:
                lines.append(f"  • artifact '{v.artifact_key}' (link {v.link_id}) reads "
                             f"{b.describe()}")
        return "\n".join(lines)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "bundle_id": self.bundle_id,
            "recorded_revision": self.recorded_revision,
            "live_revision": self.live_revision,
            "revision_delta": self.revision_delta,
            "skipped": self.skipped,
            "refused": self.refused,
            "artifacts_checked": len(self.verdicts),
            "artifacts_broken": len(self.broken),
            "verdicts": [v.as_dict() for v in self.verdicts],
            # ⛔ SEPARATE FROM `refused` AND FROM `verdicts`, on purpose. A consumer
            # rendering a red "this bundle cannot install" banner reads `refused`;
            # these are a non-blocking notice beside it. Folding them into `verdicts`
            # would make `artifacts_broken` count a bundle that installs fine.
            "empty_predicate_columns": list(self.empty_predicate_columns),
            "summary": self.summary(),
        }


def artifact_sql_texts(artifact: Mapping[str, Any]) -> List[str]:
    """Every SQL string an artifact carries — its own, plus each widget's.

    ⚠️ A dashboard holds its SQL PER-WIDGET, not at the artifact root. Reading only the
    root would silently check nothing for the artifact type that reads the most columns.
    """
    d = artifact.get("definition") or {}
    out = [d.get("sql") or d.get("custom_sql") or d.get("sql_command") or d.get("query") or ""]
    out += [(w or {}).get("sql") or ""
            for w in (d.get("widgets") or []) if isinstance(w, dict)]
    return [s for s in out if s and str(s).strip()]


def output_aliases(sql: str, *, dialect: str = "postgres") -> Set[str]:
    """Output-column ALIASES a statement defines (`… AS criticality_tier`), lower-cased.

    ⛔ WHY THIS EXISTS — a MEASURED false positive that would have shipped. The shared
    `columns_read_from` returns every `exp.Column` node it can tie to the table, and for
    a single-table query it attributes BARE identifiers to that table. A `GROUP BY` /
    `ORDER BY` that references an OUTPUT NAME therefore comes back looking like a column
    read. Measured 2026-08-10 on the real `ciso_posture`:

        SELECT COALESCE(criticality_name,'Unclassified') AS criticality_tier … FROM assets
          → columns_read_from = ['criticality_name', 'criticality_tier']
        SELECT COALESCE(status,'unknown') AS status, COUNT(*) AS ticket_count FROM issues
          → columns_read_from = ['status', 'ticket_count']

    `assets.criticality_tier` and `issues.ticket_count` DO NOT EXIST (assets has
    `criticality_level` / `criticality_name`), and neither is in the removed-columns
    archive — they were never columns at all. Without this subtraction the check
    REFUSED `ciso_posture` on two phantom columns.

    ⚠️ B11 is immune to this and that is why the bug is new here, not a bug there: B11
    compares against the SHADOW SET, which contains only real declared columns, so a
    phantom alias never matches anything. This check compares against the LIVE SCHEMA,
    where any name absent from the schema reads as "removed". Same helper, opposite
    exposure — worth knowing before reusing it a third time.

    ⛔ AND SUBTRACTING EVERY ALIAS NAME IS TOO WIDE — the second bug, caught by the test
    suite before it shipped. The commonest form of this idiom is SELF-NAMED:
    `COALESCE(status,'unknown') AS status` READS the real column `status` and names its
    output `status`. Dropping the name loses the genuine read. Measured across the three
    shipped bundles, an unconditional subtraction dropped **15 real column reads** —
    including `assets.has_customer_data`, `asset_environment`, `asset_team` and
    `criticality_level` — leaving the check blind to their removal while still reporting
    "INSTALLS".

    ⛔ THE ARBITER IS THE PARSE TREE, NOT THE LIVE SCHEMA. Using the schema (does a column
    by this name exist?) seems natural and is WRONG in exactly the case that matters: when
    a self-named alias's column is REMOVED, the schema no longer has it, so the name reads
    as a phantom and gets dropped — silently swallowing the very break the check exists to
    catch. The parse tree carries the distinction the schema cannot: a name is a phantom
    ONLY when it never appears inside an aliased expression, i.e. it occurs solely as a
    bare reference to an output name (`GROUP BY criticality_tier`). That is decidable from
    the SQL alone, needs no schema, and stays correct while the schema changes underneath.
    """
    import sqlglot
    from sqlglot import exp

    try:
        tree = sqlglot.parse_one(sql, read=dialect)
    except Exception:  # noqa: BLE001 — an unparseable statement is handled by the caller
        return set()

    aliases: Set[str] = set()
    for node in tree.find_all(exp.Alias):
        if node.alias:
            aliases.add(str(node.alias).lower())

    # Columns appearing INSIDE an aliased expression are genuine reads, even when the
    # alias renames them to their own name.
    inside: Set[str] = set()
    for node in tree.find_all(exp.Alias):
        subject = node.this
        if hasattr(subject, "find_all"):
            for col in subject.find_all(exp.Column):
                if col.name:
                    inside.add(str(col.name).lower())

    return aliases - inside


def resolve_reads(
    sql_texts: Iterable[str],
    known_tables: Iterable[str],
    *,
    scrub=None,
) -> Tuple[Set[Tuple[str, str]], Set[str], Optional[str]]:
    """Resolve SQL → `({(table, column)}, {tables_read}, unverifiable_reason)`.

    ⛔ FAILS CLOSED, copying B11. `columns_read_from` returns None for "cannot restrict"
    — a `SELECT *`, an unattributable column ref, OR a parse failure — and it does NOT
    distinguish them. So the reason string states what is KNOWN (the columns could not
    be determined) and lists the possibilities, rather than asserting a cause it has not
    established. A true measurement with a false cause is the failure mode this
    workstream keeps re-learning.

    ⚠️ Phantom output aliases are subtracted (see `output_aliases`), which is what keeps a
    `GROUP BY <output-name>` from reading as a column that was removed.
    """
    from ..sql.lineage import columns_read_from

    reads: Set[Tuple[str, str]] = set()
    tables_read: Set[str] = set()
    known = {t.lower() for t in known_tables}

    for raw in sql_texts:
        text = scrub(str(raw)) if scrub else str(raw)
        # ⛔ Subtracted per-STATEMENT, not globally: an alias defined in one artifact's
        # SQL says nothing about another's, and a bundle-wide alias set would suppress
        # a genuine break in an unrelated statement.
        aliases = output_aliases(text)
        for table in known:
            if not re.search(rf"\b{re.escape(table)}\b", text, re.IGNORECASE):
                continue
            tables_read.add(table)
            try:
                cols = columns_read_from(text, table)
            except Exception:  # noqa: BLE001 — treated as "cannot restrict"
                cols = None
            if cols is None:
                return reads, tables_read, (
                    f"reads `{table}` but the columns could not be determined: the SQL "
                    f"either projects `SELECT *`, references a column it cannot tie to a "
                    f"table, or does not parse. This check does not pass what it cannot "
                    f"verify — project the columns explicitly and keep the SQL parseable."
                )
            for c in cols:
                cname = str(c).lower()
                if cname in aliases:
                    continue
                reads.add((table, cname))
    return reads, tables_read, None


def check_bundle_shape(
    *,
    bundle_id: str,
    recorded_revision: str,
    links: Iterable[Any],
    live_shape: Mapping[Tuple[str, str], str],
    tables_present: Iterable[str],
    live_revision: Optional[str] = None,
    authored_shape: Optional[Mapping[Tuple[str, str], str]] = None,
    #: ⛔ OPTIONAL, and absent means SILENT — not "everything is populated".
    #: `{(table, column): null_frac}` from `read_live_null_frac`. When the caller
    #: cannot read pg_stats it passes nothing and no populated warning is emitted,
    #: which is the correct posture for a WARNING (see the field note on
    #: `BundleShapeReport.empty_predicate_columns`).
    live_null_frac: Optional[Mapping[Tuple[str, str], float]] = None,
    scrub=None,
) -> BundleShapeReport:
    """Run the staleness check over a bundle's links. See the module docstring.

    `links` are objects with `.link_id` and `.artifacts` (the `BundleLink` shape) or
    equivalent mappings. `live_shape` / `tables_present` come from `read_live_shape`.
    """
    delta = _is_delta(recorded_revision, live_revision)
    report = BundleShapeReport(
        bundle_id=bundle_id,
        recorded_revision=recorded_revision,
        live_revision=live_revision,
        revision_delta=delta,
    )

    # ⭐ FAST PATH — same revision means nothing changed, so there is nothing to
    # resolve. ⚠️ `pre-versioning` never takes it: it means "revision unknown", and an
    # unknown revision matching another unknown revision proves nothing.
    if not delta and recorded_revision != PRE_VERSIONING_SCHEMA_REVISION:
        report.skipped = True
        return report

    known = {t.lower() for t in tables_present} & {t.lower() for t in SINK_TABLES}
    #: {(table, column) -> {artifact_key}} for the populated axis (warn only).
    empty_hits: Dict[Tuple[str, str], Set[str]] = {}

    for ln in links:
        link_id = getattr(ln, "link_id", None) or (ln.get("link_id") if isinstance(ln, dict) else "")
        artifacts = getattr(ln, "artifacts", None) or (
            ln.get("artifacts") if isinstance(ln, dict) else []) or []
        for a in artifacts:
            texts = artifact_sql_texts(a)
            if not texts:
                continue
            reads, tables_read, unverifiable = resolve_reads(texts, known, scrub=scrub)
            if not tables_read and not unverifiable:
                # Reads no sink table at all — reads only the bundle's own outputs,
                # which carry no reachability claim and do not exist yet on a fresh
                # install. Out of scope by design (see SINK_TABLES).
                continue
            breaks = [] if unverifiable else compare_shape(
                reads, live_shape, authored_shape, known_tables=known)
            if breaks or unverifiable:
                report.verdicts.append(ArtifactShapeVerdict(
                    artifact_key=str(a.get("artifact_key") or ""),
                    link_id=str(link_id), breaks=breaks,
                    unverifiable=unverifiable, tables_read=sorted(tables_read)))
            else:
                report.verdicts.append(ArtifactShapeVerdict(
                    artifact_key=str(a.get("artifact_key") or ""),
                    link_id=str(link_id), tables_read=sorted(tables_read)))

            # ── the POPULATED axis (warn only) ────────────────────────────────
            # ⛔ PREDICATE COLUMNS ONLY, and the distinction is load-bearing. An
            # empty column in a SELECT list shows blanks in one cell; an empty
            # column in a WHERE clause REMOVES EVERY ROW. Only the second is
            # worth an operator's attention at install time.
            #
            # ⚠️ Conflating them is a measured failure, not a hypothetical: a
            # heuristic that treated `WHERE x IS NOT NULL` (drops rows) the same
            # as `COUNT(*) FILTER (WHERE x)` (keeps the row, yields 0)
            # mislabelled three WORKING widgets as "cannot return anything" and
            # had to be reverted. `row_filtered` is the parser's own answer to
            # exactly this question — do not re-derive it.
            if live_null_frac:
                for t, c in _predicate_columns(texts, known, scrub=scrub):
                    nf = live_null_frac.get((t, c))
                    # ⛔ `None` means NO STATISTICS, which must read as "no
                    # opinion" — never as "empty". pg_stats only has rows where
                    # ANALYZE has run, so absence is common.
                    if nf is None or nf < EMPTY_NULL_FRAC:
                        continue
                    empty_hits.setdefault((t, c), set()).add(
                        str(a.get("artifact_key") or ""))

    for (t, c), used_by in sorted(empty_hits.items()):
        report.empty_predicate_columns.append({
            "table": t,
            "column": c,
            "used_by": sorted(x for x in used_by if x),
            "message": (
                f"{t}.{c} holds no values on this account, and this bundle FILTERS "
                f"rows on it — the artifacts that read it will be empty until an "
                f"integration writes that column."
            ),
        })
    return report


def _predicate_columns(texts, known_tables, *, scrub=None):
    """`{(table, column)}` this SQL uses as a ROW FILTER.

    ⚠️ Uses the SHARED parser (`pantheon_shared.datalake.sql_columns`), which is where
    it lives precisely so this cannot drift from the supply graph's answer to the same
    question. Do not re-implement the parse here.

    Returns an empty set on any parse failure — silence, never a guess, because the
    only consumer emits a warning (see `BundleShapeReport.empty_predicate_columns`).
    """
    from .sql_columns import extract_sql_columns

    out = set()
    for text in texts or []:
        sql = scrub(text) if scrub else text
        if not sql or not str(sql).strip():
            continue
        try:
            _refs, limits = extract_sql_columns(str(sql))
        except Exception:  # noqa: BLE001 — a probe must never fail its caller
            continue
        for qualified in (limits or {}).get("row_filtered") or []:
            if "." not in str(qualified):
                continue
            t, _, c = str(qualified).partition(".")
            t, c = t.strip().lower(), c.strip().lower()
            # Sink tables only: pg_stats on a transformer output is meaningless at
            # install time — the relation does not exist yet.
            if t in known_tables:
                out.add((t, c))
    return out


def _is_delta(recorded: Optional[str], live: Optional[str]) -> bool:
    """Is there a revision delta? ⚠️ Unknown on EITHER side counts as a delta — the
    fast path is an optimisation and may only be taken on positive proof that nothing
    changed. Treating unknown as "same" would skip the check exactly when it is least
    safe to."""
    if not recorded or not live:
        return True
    if recorded == PRE_VERSIONING_SCHEMA_REVISION:
        return True
    return str(recorded) != str(live)
