"""
Type definitions for pantheon datalake backends.

This module defines all common data structures used across different datalake
backend implementations (DuckDB, Snowflake, PostgreSQL).
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from datetime import datetime, UTC


@dataclass
class QueryResult:
    """Standardized query result across all datalake backends.

    Attributes:
        columns: List of column names returned by the query.
        rows: List of row values (each row is a list of values).
        row_count: Total number of rows in the result (optional, calculated if not provided).
        execution_time_ms: Query execution time in milliseconds (optional).
    """
    columns: List[str]
    rows: List[List[Any]]
    row_count: Optional[int] = None
    execution_time_ms: Optional[float] = None

    def __post_init__(self):
        """Calculate row_count if not provided."""
        if self.row_count is None:
            self.row_count = len(self.rows)

    def to_dict_list(self) -> List[Dict[str, Any]]:
        """Convert rows to a list of dictionaries.

        Each row becomes a dict with column names as keys.

        Returns:
            List of dictionaries, one per row.
        """
        return [dict(zip(self.columns, row)) for row in self.rows]

    def to_dataframe(self):
        """Convert to pandas DataFrame (optional dependency).

        Returns:
            pandas.DataFrame with query results.

        Raises:
            ImportError: If pandas is not installed.
        """
        try:
            import pandas as pd
        except ImportError:
            raise ImportError(
                "pandas is required for to_dataframe(). Install with: pip install pandas"
            )

        return pd.DataFrame(self.rows, columns=self.columns)

    def is_empty(self) -> bool:
        """Check if result set is empty.

        Returns:
            True if no rows returned, False otherwise.
        """
        return self.row_count == 0

    def first_row(self) -> Optional[Dict[str, Any]]:
        """Get first row as a dictionary.

        Returns:
            First row as dict, or None if result is empty.
        """
        if self.is_empty():
            return None
        return dict(zip(self.columns, self.rows[0]))

    def __repr__(self) -> str:
        """String representation showing row count and columns."""
        return (
            f"QueryResult(rows={self.row_count}, columns={len(self.columns)}, "
            f"execution_time_ms={self.execution_time_ms})"
        )


@dataclass
class UpsertResult:
    """Result of an upsert (insert or update) operation.

    Attributes:
        success: True if operation completed without errors.
        inserted: Number of new records inserted.
        updated: Number of existing records updated.
        failed: Number of records that failed to process (default 0).
        errors: List of error messages for failed records (default empty list).
        execution_time_ms: Operation execution time in milliseconds (optional).
    """
    success: bool
    inserted: int
    updated: int
    failed: int = 0
    errors: List[str] = field(default_factory=list)
    execution_time_ms: Optional[float] = None

    @property
    def total_affected(self) -> int:
        """Total number of records affected (inserted + updated + failed)."""
        return self.inserted + self.updated + self.failed

    def add_error(self, error: str):
        """Add an error message to the errors list.

        Args:
            error: Error message to add.
        """
        self.errors.append(error)
        self.failed += 1

    def __repr__(self) -> str:
        """String representation showing operation summary."""
        return (
            f"UpsertResult(success={self.success}, inserted={self.inserted}, "
            f"updated={self.updated}, failed={self.failed}, "
            f"execution_time_ms={self.execution_time_ms})"
        )


@dataclass
class ColumnInfo:
    """Metadata for a table column.

    Attributes:
        name: Column name.
        type: Column data type (backend-specific type name).
        nullable: True if column allows NULL values.
        default: Default value for column (optional).
        max_length: Maximum length for string columns (optional).
    """
    name: str
    type: str
    nullable: bool = True
    default: Optional[Any] = None
    max_length: Optional[int] = None

    def __repr__(self) -> str:
        """String representation."""
        nullable_str = "NULL" if self.nullable else "NOT NULL"
        return f"ColumnInfo({self.name} {self.type} {nullable_str})"


@dataclass
class TableInfo:
    """Table metadata and statistics.

    Attributes:
        name: Table name (without schema prefix).
        schema: Schema name containing the table.
        row_count: Number of rows in the table (optional, may be expensive to compute).
        columns: List of column metadata (optional, populated if table was introspected).
        size_bytes: Approximate table size in bytes (optional).
        created_at: Table creation timestamp (optional).
        table_type: Type of table (e.g., 'BASE TABLE', 'VIEW') (optional).
    """
    name: str
    schema: str
    row_count: Optional[int] = None
    columns: List[ColumnInfo] = field(default_factory=list)
    size_bytes: Optional[int] = None
    created_at: Optional[datetime] = None
    table_type: Optional[str] = None

    @property
    def fully_qualified_name(self) -> str:
        """Get fully qualified table name (schema.table)."""
        return f"{self.schema}.{self.name}"

    @property
    def has_columns(self) -> bool:
        """Check if column metadata is available."""
        return len(self.columns) > 0

    def get_column_names(self) -> List[str]:
        """Get list of column names.

        Returns:
            List of column names, or empty list if columns not populated.
        """
        return [col.name for col in self.columns]

    def __repr__(self) -> str:
        """String representation."""
        return (
            f"TableInfo(name={self.name}, schema={self.schema}, "
            f"row_count={self.row_count}, columns={len(self.columns)})"
        )


@dataclass
class TenantContext:
    """Tenant isolation context for multi-tenant datalake operations.

    This class encapsulates the tenant identifier and optional namespace
    for enforcing multi-tenancy in datalake operations.

    Attributes:
        tenant_id: Unique tenant identifier (UUID).
        namespace_id: Optional namespace identifier within tenant.
        user_id: Optional user ID who initiated the operation (for audit).
    """
    tenant_id: str
    namespace_id: Optional[str] = None
    user_id: Optional[str] = None

    @classmethod
    def from_iam_context(cls, iam_context) -> 'TenantContext':
        """Create TenantContext from IAM context object.

        Args:
            iam_context: IAMContext object with tenant_id, namespace_id, user_id attributes.

        Returns:
            TenantContext instance with values from IAM context.

        Raises:
            ValueError: If tenant_id is not available in IAM context.
        """
        if not hasattr(iam_context, 'tenant_id') or not iam_context.tenant_id:
            raise ValueError("tenant_id is required from IAM context")

        return cls(
            tenant_id=iam_context.tenant_id,
            namespace_id=getattr(iam_context, 'namespace_id', None),
            user_id=getattr(iam_context, 'user_id', None)
        )

    def validate(self) -> bool:
        """Validate that tenant_id is present.

        Returns:
            True if tenant_id is present.

        Raises:
            ValueError: If tenant_id is missing.
        """
        if not self.tenant_id:
            raise ValueError("tenant_id is required for TenantContext")
        return True

    def __repr__(self) -> str:
        """String representation."""
        return f"TenantContext(tenant_id={self.tenant_id}, namespace_id={self.namespace_id})"


@dataclass
class ConnectionConfig:
    """Database connection configuration.

    Attributes:
        host: Database server hostname or IP address.
        port: Database server port number.
        database: Database name.
        user: Username for authentication.
        password: Password for authentication.
        schema: Default schema name (optional).
        pool_size: Maximum number of connections in pool (default 5).
        idle_timeout: Idle connection timeout in seconds before cleanup (default 300).
        ssl_mode: SSL connection mode (optional, backend-specific).
        connection_timeout: Connection timeout in seconds (optional).
    """
    host: str
    port: int
    database: str
    user: str
    password: str
    schema: Optional[str] = None
    pool_size: int = 5
    idle_timeout: int = 300
    ssl_mode: Optional[str] = None
    connection_timeout: Optional[int] = None

    def to_dict(self, hide_password: bool = True) -> Dict[str, Any]:
        """Convert configuration to dictionary.

        Args:
            hide_password: If True, replace password with asterisks.

        Returns:
            Dictionary representation of connection config.
        """
        result = {
            'host': self.host,
            'port': self.port,
            'database': self.database,
            'user': self.user,
            'schema': self.schema,
            'pool_size': self.pool_size,
            'idle_timeout': self.idle_timeout,
            'ssl_mode': self.ssl_mode,
            'connection_timeout': self.connection_timeout,
        }
        if hide_password:
            result['password'] = '*****'
        else:
            result['password'] = self.password
        return result

    def __repr__(self) -> str:
        """String representation (hides password)."""
        return f"ConnectionConfig({self.host}:{self.port}/{self.database}, user={self.user})"


@dataclass
class HealthStatus:
    """Health check result for a datalake backend.

    Attributes:
        healthy: True if backend is operational.
        message: Human-readable status message.
        latency_ms: Connection latency in milliseconds (optional).
        metadata: Additional backend-specific metadata (optional).
        checked_at: Timestamp of health check.
    """
    healthy: bool
    message: str
    latency_ms: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    checked_at: datetime = field(default_factory=lambda: datetime.now(UTC))

    def __repr__(self) -> str:
        """String representation."""
        status = "HEALTHY" if self.healthy else "UNHEALTHY"
        return f"HealthStatus({status}, message={self.message}, latency_ms={self.latency_ms})"
