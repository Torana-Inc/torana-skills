"""Is a failed datalake query the CALLER's fault or ours?

One answer, used for both the HTTP status (400 vs 500) and the log level (WARNING vs ERROR).

⛔ WHY THE LOG LEVEL DEPENDS ON IT: a query naming a column that does not exist is a bad
request, answered with a 400. Logging it at ERROR put every caller typo — an agent's draft SQL,
a probe, a user in the playground — beside real server faults, and anything alerting on ERROR
paged on them (Classie 2026-09-30: `SELECT vector_probe_col FROM vulnerabilities` produced two
ERROR lines for a correctly-refused query). ERROR is reserved for faults that are ours.
"""

#: SQLSTATE classes that mean the SQL itself was wrong: 42 = syntax error or access rule
#: violation (undefined column/table, ambiguous reference…), 22 = data exception (bad cast,
#: division by zero, out of range).
USER_SQL_SQLSTATE_CLASSES = ("42", "22")

#: Fallback for backends that do not surface a SQLSTATE (DuckDB, and psycopg2 errors that
#: arrive already stringified). Deliberately narrow: matching too eagerly would hide a real
#: server fault behind a 400, which is the worse direction to be wrong in.
USER_SQL_ERROR_MARKERS = (
    "does not exist",
    "syntax error",
    "ambiguous",
    "invalid input syntax",
    "cannot be cast",
    "division by zero",
    "out of range",
)


def _sqlstate(exc: BaseException) -> str | None:
    """The SQLSTATE on `exc` or anything it wraps (`.orig`, `__cause__`), if any.

    ⚠️ Walk the chain: the backends re-raise as `QueryError("Query failed: …") from e`, which
    carries no pgcode itself, so reading only the outer exception fell back to message text.
    """
    seen = set()
    cur: BaseException | None = exc
    while cur is not None and id(cur) not in seen:
        seen.add(id(cur))
        code = getattr(cur, "pgcode", None) or getattr(getattr(cur, "orig", None), "pgcode", None)
        if code:
            return str(code)
        cur = cur.__cause__
    return None


def is_user_sql_error(exc: BaseException) -> bool:
    """True when the failure is the CALLER's SQL rather than a server fault.

    Prefers the SQLSTATE (authoritative, language-independent); falls back to message
    matching only when no code is available anywhere in the chain.
    """
    code = _sqlstate(exc)
    if code:
        return code[:2] in USER_SQL_SQLSTATE_CLASSES
    msg = str(exc).lower()
    return any(m in msg for m in USER_SQL_ERROR_MARKERS)


def query_failure_log_level(exc: BaseException) -> int:
    """The level a backend logs a failed query at: ERROR for our faults, WARNING for a
    caller's bad SQL, and INFO when that caller is an LLM.

    ⛔ An LLM guessing a column is the expected cost of text-to-SQL, not a defect: the
    datalake route already reports it as one INFO `llm_sql_rejected` line (F6). The backend
    logging the same failure at WARNING kept every LLM guess in the warning scan (F6b).
    The origin comes from the request ContextVar (`x-pantheon-origin`), so code-origin and
    human CLI callers keep WARNING. A server fault stays ERROR whoever asked.
    """
    import logging

    if not is_user_sql_error(exc):
        return logging.ERROR
    from pantheon_shared.http.origin import current_origin, is_llm_origin
    return logging.INFO if is_llm_origin(current_origin()) else logging.WARNING
