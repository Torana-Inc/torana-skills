"""The decoration layer's own three tables, and their idempotent bootstrap.

Design: ``DECORATION_LAYER_SPEC.md`` § 3.3.1 (facts), § 3.3.2 (status), § 3.3.4 (jobs).

``pantheon-datalake`` has **no Alembic** (verified: no ``alembic/``, no ``alembic.ini``,
``alembic_version`` absent from the DB), so these tables are created by an explicit
**typed** ``create_table()`` call at layer startup. Typed matters: the untyped path
in ``postgres_backend`` creates every column as TEXT, which would silently turn
``generation`` into a string and break the ``bigint`` ordering the fence depends on.

All three live in ``public`` and are written with ``scope="global"``.
``_get_schema_name()`` returns only ``public`` / ``tenant_{id}`` / ``tenant_{id}_{...}``
— ``scope`` is a two-valued switch, not a schema name, so a dedicated schema is
unreachable by the write path. ``public`` is unconditionally on every tenant's
search_path.

.. warning::
   **Single-column PKs, and no CHECK / composite / partial index, are FORCED by the
   write path** — ``upsert()`` takes ``primary_key: str`` and ``create_table()`` is the
   only index-creating code in the layer, looping over single columns. Consequences,
   all deliberate:

   * Natural-key uniqueness is **by construction**: each ``*_key`` IS the ``|``-join of
     its components, so a duplicate natural key collides on the PK.
   * :func:`build_key` raises if any component contains ``|`` or the result exceeds the
     column width — silent truncation would merge two distinct facts.
   * ``status IN ('ok','error')`` is enforced in Python at the single write site.
"""

from __future__ import annotations

from typing import Any, Literal

from pantheon_shared.datalake.decorations import DECORATION_TABLES

__all__ = [
    "DECORATION_FACTS_SCHEMA",
    "DECORATION_STATUS_SCHEMA",
    "DECORATION_APPLY_JOBS_SCHEMA",
    "DECORATION_SCHEMAS",
    "KEY_MAX_LENGTH",
    "GLOBAL_TENANT",
    "JobState",
    "StatusValue",
    "build_key",
    "ensure_decoration_tables",
]

KEY_MAX_LENGTH = 512
"""Width of every ``*_key`` PK column. :func:`build_key` refuses to exceed it."""

GLOBAL_TENANT = ""
"""The sentinel for facts that are not tenant data (CISA KEV, FIRST EPSS).

**Never ``NULL``.** ``tenant_id``/``namespace_id`` are NOT NULL with ``''`` as the
global sentinel: a producer writing NULL lands facts that silently never match — the
same silent-join-loss class as the recorded ``is_false_positive`` incident.
"""

JobState = Literal["pending", "claimed", "succeeded", "failed", "abandoned"]
StatusValue = Literal["ok", "error"]


# ── § 3.3.1 ──────────────────────────────────────────────────────────────────

DECORATION_FACTS_SCHEMA: dict[str, Any] = {
    # decoration|tenant|namespace|subject|attribute
    "fact_key": {"data_type": "VARCHAR(512)", "primary_key": True},
    "decoration": {"data_type": "VARCHAR(64)", "not_null": True, "index": True},
    # '' = global (feed facts). NOT NULL — see GLOBAL_TENANT.
    "tenant_id": {"data_type": "VARCHAR(255)", "not_null": True, "index": True},
    "namespace_id": {"data_type": "VARCHAR(255)", "not_null": True},
    # What it decorates: a cve_id, a severity. NEVER '' — a ''-keyed fact can
    # never match a row.
    "subject_key": {"data_type": "VARCHAR(255)", "not_null": True, "index": True},
    # Which column it supplies: 'epss_score'.
    "attribute": {"data_type": "VARCHAR(128)", "not_null": True},
    # SCALAR, not a map. Read with #>> '{}', never ->> (which returns NULL for a
    # scalar — the very bug this layer exists to remove, reproduced inside its fix).
    "value": {"data_type": "JSONB", "not_null": True},
    # Producer's version stamp; lands on the decorated row.
    "source_version": {"data_type": "VARCHAR(100)", "not_null": True},
    # Fence for idempotent re-runs. bigint, NOT text — the untyped create path
    # would make this a string and break ordering.
    "generation": {"data_type": "BIGINT", "not_null": True},
    # Set by the apply that reversed a soft-deleted fact. A retracted fact is
    # purgeable ONLY once this is set, independent of the job sweep — so deleting
    # job history can never strand a value.
    "retracted_applied_generation": {"data_type": "BIGINT"},
    "description": {"data_type": "TEXT", "not_null": True, "default": ""},
    "is_deleted": {"data_type": "BOOLEAN", "not_null": True, "default": False},
    "created_at": {"data_type": "TIMESTAMP", "not_null": True},
    "updated_at": {"data_type": "TIMESTAMP", "not_null": True},
}


# ── § 3.3.2 ──────────────────────────────────────────────────────────────────

DECORATION_STATUS_SCHEMA: dict[str, Any] = {
    # decoration|tenant|namespace
    "status_key": {"data_type": "VARCHAR(512)", "primary_key": True},
    "decoration": {"data_type": "VARCHAR(64)", "not_null": True, "index": True},
    "tenant_id": {"data_type": "VARCHAR(255)", "not_null": True, "index": True},
    "namespace_id": {"data_type": "VARCHAR(255)", "not_null": True},
    # 'ok' | 'error' — enforced in Python at the single write site, because
    # create_table() cannot emit a CHECK.
    "status": {"data_type": "VARCHAR(20)", "not_null": True},
    # The staleness window's observable end.
    "last_success_at": {"data_type": "TIMESTAMP"},
    "last_attempt_at": {"data_type": "TIMESTAMP", "not_null": True},
    # Version of the facts currently LANDED.
    "source_version": {"data_type": "VARCHAR(100)"},
    # Version last APPLIED to the sink. A gap between these two is the backstop
    # sweep's trigger and the staleness signal the surfaces render.
    "applied_version": {"data_type": "VARCHAR(100)"},
    "error": {"data_type": "TEXT"},
    "description": {"data_type": "TEXT", "not_null": True, "default": ""},
    "is_deleted": {"data_type": "BOOLEAN", "not_null": True, "default": False},
    "created_at": {"data_type": "TIMESTAMP", "not_null": True},
    "updated_at": {"data_type": "TIMESTAMP", "not_null": True},
}


# ── § 3.3.4 ──────────────────────────────────────────────────────────────────

DECORATION_APPLY_JOBS_SCHEMA: dict[str, Any] = {
    # decoration|tenant|namespace|generation. Including `generation` is what makes
    # re-enqueuing for a NEWER fact generation create a new job while an identical
    # re-enqueue is idempotent (PK collision).
    "job_key": {"data_type": "VARCHAR(512)", "primary_key": True},
    "decoration": {"data_type": "VARCHAR(64)", "not_null": True, "index": True},
    "tenant_id": {"data_type": "VARCHAR(255)", "not_null": True, "index": True},
    "namespace_id": {"data_type": "VARCHAR(255)", "not_null": True},
    # WHICH JOB. NOT the same axis as source_version: `generation` fences which
    # job, `source_version` fences which facts. They move together when a producer
    # lands new facts and INDEPENDENTLY when a retraction's fallback bumps
    # generation without changing any fact value. That independence is load-bearing
    # — it is what makes "a generation bump alone does not trigger the backstop
    # sweep" true, since the sweep compares applied_version to source_version and
    # neither moved. Do not "simplify" one into the other.
    "generation": {"data_type": "BIGINT", "not_null": True},
    # pending|claimed|succeeded|failed|abandoned. With next_attempt_at, the only
    # fields the claim query reads.
    "state": {"data_type": "VARCHAR(20)", "not_null": True, "index": True},
    "attempt": {"data_type": "INTEGER", "not_null": True, "default": 0},
    "max_attempts": {"data_type": "INTEGER", "not_null": True, "default": 5},
    "claimed_by": {"data_type": "VARCHAR(128)"},
    "claimed_at": {"data_type": "TIMESTAMP"},
    # The facts version CAPTURED AT CLAIM. Without it the apply would read the
    # version at write time and could stamp a generation it did not apply.
    "source_version": {"data_type": "VARCHAR(100)"},
    # Refreshed by the RUNNING worker; drives the reaper. Keying the reaper on
    # claimed_at would reap slow-but-healthy jobs.
    "heartbeat_at": {"data_type": "TIMESTAMP"},
    "next_attempt_at": {"data_type": "TIMESTAMP", "not_null": True},
    "rows_updated": {"data_type": "BIGINT"},
    "error": {"data_type": "TEXT"},
    # Names the decoration whose fallback job this retraction still owes, so a
    # crash between the clear and the enqueue is recoverable rather than silent.
    "pending_fallback": {"data_type": "VARCHAR(64)"},
    "enqueued_at": {"data_type": "TIMESTAMP", "not_null": True},
    "started_at": {"data_type": "TIMESTAMP"},
    "finished_at": {"data_type": "TIMESTAMP"},
    "description": {"data_type": "TEXT", "not_null": True, "default": ""},
    "is_deleted": {"data_type": "BOOLEAN", "not_null": True, "default": False},
    "created_at": {"data_type": "TIMESTAMP", "not_null": True},
    "updated_at": {"data_type": "TIMESTAMP", "not_null": True},
}


DECORATION_SCHEMAS: dict[str, dict[str, Any]] = {
    "decoration_facts": DECORATION_FACTS_SCHEMA,
    "decoration_status": DECORATION_STATUS_SCHEMA,
    "decoration_apply_jobs": DECORATION_APPLY_JOBS_SCHEMA,
}


class KeyError_(ValueError):
    """A natural key could not be built safely."""


def build_key(*components: object) -> str:
    """Join key components with ``|``, refusing anything that could collide.

    Uniqueness of the natural key is **by construction** — the key IS the join, so a
    duplicate natural key collides on the PK. That only holds if the join is
    unambiguous, hence the two guards:

    * a component containing ``|`` would make two distinct keys parse identically;
    * a key longer than the column would be **silently truncated** by Postgres'
      varchar semantics on some paths, merging two distinct facts.

    Both raise rather than coerce.
    """
    parts: list[str] = []
    for c in components:
        s = "" if c is None else str(c)
        if "|" in s:
            raise KeyError_(
                f"key component {s!r} contains '|', which would make the natural "
                "key ambiguous"
            )
        parts.append(s)
    key = "|".join(parts)
    if len(key) > KEY_MAX_LENGTH:
        raise KeyError_(
            f"key of length {len(key)} exceeds {KEY_MAX_LENGTH}; truncation would "
            f"merge distinct rows: {key[:80]}..."
        )
    return key


def ensure_decoration_tables(client: Any) -> dict[str, bool]:
    """Create the three tables if absent. Idempotent; safe on every worker.

    Args:
        client: a ``DatalakeClient``. Written with ``scope="global"`` so all three
            land in ``public``.

    Returns:
        ``{table: created_ok}``.
    """
    results: dict[str, bool] = {}
    for table in DECORATION_TABLES:
        results[table] = client.create_table(
            table=table,
            schema=DECORATION_SCHEMAS[table],
            tenant_id=GLOBAL_TENANT,
            scope="global",
        )
    return results
