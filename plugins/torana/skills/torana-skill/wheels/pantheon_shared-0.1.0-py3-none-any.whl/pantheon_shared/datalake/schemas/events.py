from typing import Dict, Any
from .base import TableSchema


class EventsSchema(TableSchema):
    """Schema definition for the events table (I-63).

    One row per OBSERVED OCCURRENCE — a login, a SIEM correlation hit, an identity-provider
    system-log entry, a firewall threat-log line. Distinct from `findings`, which holds a
    RESULT (a detection, a scan outcome, a posture check) that someone triages.

    ⛔ WHY IT IS ITS OWN TABLE. Until I-63 these rows landed in `findings` with a
    `finding_type` ('authentication', 'security_event', 'threat_log') as the only thing
    keeping them out of every reader that means "security results". A reader that forgot
    the filter counted logins as findings. Measured 2026-10-21 on T3: 62 Splunk logins and
    27 SIEM hits sat in `findings`.

    ⛔ NOT the platform event timeline. `pantheon_shared.events` / `platform_events`
    (docs/PLATFORM_EVENTS.md) records what the PLATFORM did (a sync ran, a build finished).
    This table records what a customer's SOURCE observed in their estate.

    Writers: splunk/auth_events, splunk/security_events, okta/system_log,
    palo_alto/threat_logs. ⚠️ Every column below has at least one of them as its writer —
    a column with none is a shadow column and fails the shadow baseline.
    """

    @property
    def table_name(self) -> str:
        return "events"

    @property
    def primary_key(self) -> str:
        return "event_id"

    @property
    def description(self) -> str:
        return (
            "Security-relevant occurrences observed by a source: logins, SIEM correlation hits, "
            "identity-provider system-log entries and firewall threat logs. One row per occurrence"
        )

    @property
    def category(self) -> str:
        return "Security Data"

    @property
    def timestamp_column(self) -> str:
        """Return the timestamp column for this table."""
        return "updated_at"

    @property
    def schema(self) -> Dict[str, Any]:
        return {
            # ── Core Identity ────────────────────────────────────────────────
            "event_id": {"data_type": "VARCHAR(255)", "primary_key": True, "category": "Core Identity",
                "semantic_description": (
                    "Torana's stable id for one observed occurrence, built by the mapping from the "
                    "source's own log id or timestamp. Primary key; one row per occurrence. ⚠️ Kept "
                    "byte-identical to the `finding_id` these rows carried in `findings` before I-63, "
                    "so a moved row and a later re-sync of the same occurrence converge on one row."
                ),
            },
            "external_id": {"data_type": "VARCHAR(255)", "category": "Core Identity",
                "semantic_description": (
                    "The occurrence's id in the source that observed it (the Okta log uuid, the Palo "
                    "Alto threat id). NULL where the source has no per-event id."
                ),
            },
            "source_system": {"data_type": "VARCHAR(100)", "category": "Core Identity",
                "semantic_description": (
                    "The integration that reported this occurrence. ⚠️ Determines which other columns "
                    "are populated, since sources differ in what they expose."
                ),
            },
            "provider": {"data_type": "VARCHAR(50)", "category": "Core Identity",
                "semantic_description": (
                    "The vendor behind this occurrence, set as a mapping constant. One level coarser "
                    "than `source_system`."
                ),
            },
            # ── Classification ───────────────────────────────────────────────
            "event_category": {"data_type": "VARCHAR(50)", "category": "Event Classification",
                "semantic_description": (
                    "What KIND of occurrence this is: `authentication` (a logon attempt), "
                    "`security_event` (a SIEM correlation hit or an identity-provider security log "
                    "entry), `threat_log` (a firewall threat log line). The first filter for almost "
                    "every question — logins and SIEM hits answer different questions."
                ),
            },
            "event_type": {"data_type": "VARCHAR(100)", "category": "Event Classification",
                "semantic_description": (
                    "The source's own name for what happened in this occurrence: a logon action, an "
                    "identity provider's event type (`user.authentication.auth_via_mfa`), a SIEM "
                    "correlation category, a firewall threat subtype. Narrower than `event_category`, "
                    "and NOT normalised across sources."
                ),
            },
            "event_source": {"data_type": "VARCHAR(100)", "category": "Event Classification",
                "semantic_description": (
                    "Where inside the source the occurrence was recorded (the Splunk sourcetype). NULL "
                    "for sources that report a single stream."
                ),
            },
            "rule_name": {"data_type": "VARCHAR(255)", "category": "Event Classification",
                "semantic_description": (
                    "The correlation rule that raised this occurrence, for a SIEM hit. NULL for a raw "
                    "observation such as a login, which no rule produced."
                ),
            },
            "severity": {"data_type": "VARCHAR(20)", "category": "Event Classification",
                "semantic_description": (
                    "How serious the source rated this occurrence, normalised to the canonical "
                    "Title-Case vocabulary. ⚠️ A login carries `Info`: an observation has no severity "
                    "of its own, so ranking by this column ranks the SIEM hits and the threat logs."
                ),
            },
            "outcome": {"data_type": "VARCHAR(50)", "category": "Event Details",
                "semantic_description": (
                    "Whether the attempt succeeded, as the source reports it (`success` / `failure`, "
                    "lower-case). Set for authentication and identity-provider entries; NULL where the "
                    "source reports no outcome."
                ),
            },
            "title": {"data_type": "VARCHAR(500)", "category": "Event Details",
                "semantic_description": (
                    "Short human-readable summary of the occurrence, used as its headline."
                ),
            },
            "description": {"data_type": "TEXT", "category": "Event Details",
                "not_null": True, "default": "",
                "semantic_description": (
                    "Fuller explanation of the occurrence as the source worded it (the SIEM rule's "
                    "description, the Okta display message). Empty string, never NULL, when the source "
                    "gave none."
                ),
            },
            # ── Who and where ────────────────────────────────────────────────
            "event_time": {"data_type": "TIMESTAMP_NTZ", "category": "Timeline",
                "semantic_description": (
                    "When the occurrence happened, in the source's clock. ⚠️ Not `created_at`, which "
                    "is when Torana ingested the row — use this column for every 'when did it happen' "
                    "and 'in the last N days' question."
                ),
            },
            "actor_name": {"data_type": "VARCHAR(255)", "category": "Actor",
                "semantic_description": (
                    "The account that acted (the user who logged on, the Okta actor), as the source "
                    "spells it — may carry a domain (`alice@corp.example`)."
                ),
            },
            "is_privileged": {"data_type": "BOOLEAN", "category": "Actor",
                "semantic_description": (
                    "TRUE when the source flagged this logon as made with a privileged account. A fact "
                    "about this occurrence, not about the identity. NULL when the source does not say "
                    "— filter with `COALESCE(is_privileged, false)`."
                ),
            },
            "is_admin": {"data_type": "BOOLEAN", "category": "Actor",
                "semantic_description": (
                    "TRUE when the source flagged this logon as made with an administrator (domain "
                    "admin) account. Narrower than `is_privileged`. NULL when the source does not say."
                ),
            },
            "src_host": {"data_type": "VARCHAR(255)", "category": "Network",
                "semantic_description": (
                    "Hostname the occurrence came FROM (the machine a session was opened from)."
                ),
            },
            "src_ip": {"data_type": "VARCHAR(100)", "category": "Network",
                "semantic_description": (
                    "IP address the occurrence came FROM (the client of a logon, the source of a "
                    "flow)."
                ),
            },
            "dest_host": {"data_type": "VARCHAR(255)", "category": "Network",
                "semantic_description": (
                    "Hostname the occurrence was directed AT (the server logged on to). ⚠️ The join "
                    "towards `assets` is by name or IP; there is no entity key on this table yet."
                ),
            },
            "dest_ip": {"data_type": "VARCHAR(100)", "category": "Network",
                "semantic_description": (
                    "IP address the occurrence was directed AT. ⚠️ The usual join key towards "
                    "CMDB and scanner hosts, which key on IP."
                ),
            },
            # ── Raw + provenance ─────────────────────────────────────────────
            "custom_attributes": {"data_type": "VARIANT", "category": "Tags & Metadata",
                "semantic_description": (
                    "Raw source-specific fields for this occurrence, packed as JSON at ingest so "
                    "nothing the source returned is lost. ⛔ For investigation only — its keys vary by "
                    "source, so shipped SQL must read a declared column instead."
                ),
            },
            "created_via": {"data_type": "VARCHAR(100)", "category": "Audit & Tracking",
                "semantic_description": (
                    "The Torana mechanism that wrote this event row — an integration sync, a replay, "
                    "or a synthetic dataset load. ⛔ Provenance, not occurrence data: it separates "
                    "ingested rows from generated ones."
                ),
            },
            "dataset_tag": {"data_type": "VARCHAR(200)", "category": "Audit & Tracking",
                "semantic_description": (
                    "Marks this event row as seeded by a NAMED synthetic dataset, so such rows can be "
                    "purged as a set. NULL for a genuinely observed occurrence. ⛔ Filter it out when "
                    "measuring a real estate."
                ),
            },
        }
