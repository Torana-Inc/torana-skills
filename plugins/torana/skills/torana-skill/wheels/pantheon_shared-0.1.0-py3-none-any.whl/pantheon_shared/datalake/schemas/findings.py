from typing import Dict, Any
from .base import TableSchema


class FindingsSchema(TableSchema):
    """Schema definition for the findings table."""

    @property
    def table_name(self) -> str:
        return "findings"

    @property
    def primary_key(self) -> str:
        # ⛔ Returns "finding_id", NOT "torana_finding_id". This property used to name a
        # column that existed nowhere - not in the schema dict below, and not in
        # the live table - so the declared primary key of `findings` pointed at
        # nothing. Same defect class as #176 (`datastores`), found by the
        # semantic-model validator in datalake/schemas/validation.py.
        #
        # #176 fixed `datastores` by ADDING the column, because the entity graph
        # genuinely needed a `torana_*` pointer to key rows from. That reasoning
        # does NOT apply here: nothing reads "torana_finding_id" (grepped across
        # shared, integration and datalake - only prose mentions), and every
        # mapping that writes this table declares `primary_key: finding_id`.
        # Adding a column nothing writes would create exactly the shadow column
        # the reachability rules exist to prevent, so the property is corrected
        # to the column that is actually written instead.
        return "finding_id"

    @property
    def description(self) -> str:
        return "Security findings from multiple sources including SAST, DAST, cloud security, and compliance scans"

    @property
    def category(self) -> str:
        return "Security Data"

    @property
    def timestamp_column(self) -> str:
        """Return the timestamp column for this table."""
        return "updated_at"

    @property
    def schema(self) -> Dict[str, Any]:
        return {
            "finding_id": {"data_type": "VARCHAR(255)", "primary_key": True, "category": "Core Identity",
                "semantic_description": (
                    "Torana's stable id for one runtime finding. Distinct from a vulnerability: "
                    "a vulnerability is a flaw that EXISTS, a finding is something that "
                    "HAPPENED."
                ),
            },
            "external_id": {"data_type": "VARCHAR(255)", "category": "Core Identity",
                "semantic_description": (
                    "The finding's id in the tool that produced it."
                ),
            },
            "source_system": {"data_type": "VARCHAR(100)", "category": "Core Identity",
                "semantic_description": (
                    "The integration or internal producer that reported this finding row. ⚠️ Determines "
                    "which other columns are populated at all, since sources differ in what they expose, "
                    "and it is the first thing to check when two rows describe the same finding "
                    "differently."
                ),
            },
            "provider": {"data_type": "VARCHAR(50)", "category": "Core Identity",
                "semantic_description": (
                    "The vendor or platform family behind this finding, set as a mapping constant. ⚠️ One "
                    "level COARSER than `source_system`: several data sources of one vendor share a "
                    "provider value, so group by `provider` to ask about ecosystems and by `source_system` "
                    "to identify the feed."
                ),
            },
            "tool_name": {"data_type": "VARCHAR(100)", "category": "Core Identity",
                "semantic_description": (
                    "The specific tool that produced the finding (`gitlab_ci`, a scanner binary). ⚠️ NULL "
                    "for findings raised by Torana's own internal producers, so `tool_name IS NOT NULL` is "
                    "the practical filter for 'came from an external tool'."
                ),
            },
            "rule_name": {"data_type": "VARCHAR(255)", "category": "Finding Classification",
                "semantic_description": (
                    "Name of the detection rule or check that fired, as its tool names it. Identifies WHICH "
                    "check produced the finding, whereas `tool_name` identifies what ran it; a single tool "
                    "contributes many rule names."
                ),
            },
            "finding_type": {"data_type": "VARCHAR(50)", "category": "Finding Classification",
                "semantic_description": (
                    "The specific kind of finding, as its producer classifies it (`asset_reconciliation`, "
                    "`data_quality`, `ci_pipeline`). The narrower classification; `finding_category` groups "
                    "these into families."
                ),
            },
            "finding_category": {"data_type": "VARCHAR(50)", "category": "Finding Classification",
                "semantic_description": (
                    "Broader family this finding belongs to (`entity_graph` and similar), grouping several "
                    "`finding_type` values under one heading. ⚠️ Frequently NULL for externally-sourced "
                    "findings, so grouping by it silently drops rows unless NULL is handled explicitly."
                ),
            },
            "finding_subcategory": {"data_type": "VARCHAR(50)", "category": "Finding Classification",
                "semantic_description": (
                    "Finer classification within the category."
                ),
            },
            "severity": {"data_type": "VARCHAR(20)", "category": "Finding Classification",
                "semantic_description": (
                    "How serious this FINDING is judged to be by the tool that produced it. ⚠️ Distinct "
                    "from `vulnerabilities.severity`, which is a platform-owned property of the FLAW, and "
                    "from `issues.severity`, which is a human judgement on a ticket — three different "
                    "authorities that frequently disagree."
                ),
            },
            "confidence": {"data_type": "VARCHAR(20)", "category": "Finding Classification",
                "semantic_description": (
                    "How sure the tool is. Low-confidence runtime findings are where false "
                    "positives concentrate."
                ),
            },
            "status": {"data_type": "VARCHAR(50)", "category": "Finding Details",
                "semantic_description": (
                    "Where the finding stands in triage — `open`, `resolved`, and producer-specific states "
                    "such as `success` for pipeline findings. ⛔ The vocabulary is NOT uniform across "
                    "producers, so comparing status across `source_system` values without normalising "
                    "compares different state machines."
                ),
            },
            "state": {"data_type": "VARCHAR(50)", "category": "Finding Details",
                "semantic_description": (
                    "The finding's lifecycle state as its source reports it."
                ),
            },
            "title": {"data_type": "VARCHAR(500)", "category": "Finding Details",
                "semantic_description": (
                    "Short human-readable summary of what was detected, used as the headline when the "
                    "finding is rendered. ⚠️ Distinct from `identities.title`, which is a person's job "
                    "title — same column name, unrelated concept."
                ),
            },
            "description": {"data_type": "TEXT", "category": "Finding Details",
                "semantic_description": (
                    "Full explanation of what this FINDING reports, as its producer worded it. ⚠️ Not to be "
                    "confused with `issues.description` (a ticket body) or `datastores.description` (an "
                    "account of a data store) — same column name, unrelated content. NOTE this is a DATA "
                    "column; per-column meaning lives in `semantic_description` metadata, not here."
                ),
            },
            "asset_id": {"data_type": "VARCHAR(255)", "category": "Asset Association",
                "semantic_description": (
                    "The asset this was detected on. The join to the entity and its inherited "
                    "governance."
                ),
            },
            "asset_type": {"data_type": "VARCHAR(50)", "category": "Asset Association",
                "semantic_description": (
                    "What kind of asset the finding was raised against, recorded on the FINDING at "
                    "detection time. ⚠️ Not to be confused with `assets.asset_type`: this is the producer's "
                    "own label copied onto the finding, and it is not guaranteed to match the canonical "
                    "value on the corresponding `assets` row."
                ),
            },
            "asset_name": {"data_type": "VARCHAR(255)", "category": "Asset Association",
                "semantic_description": (
                    "Name of the asset this FINDING was raised against, copied from the producer at "
                    "detection time. ⛔ Distinct grain from `assets.asset_name`: there is one row per "
                    "finding, so this value repeats across every finding on the same host, and joining the "
                    "two tables on name changes the row count."
                ),
            },
            "file_path": {"data_type": "VARCHAR(1000)", "category": "File & Hash Information",
                "semantic_description": (
                    "Path of the file the finding was raised in, relative to its repository or image root. "
                    "⚠️ Distinct from `artifacts.file_path`, which locates a file inside a built artifact "
                    "rather than the place a finding was detected."
                ),
            },
            "url": {"data_type": "VARCHAR(2000)", "category": "Network Information",
                "semantic_description": (
                    "Web address associated with the finding — the resource that was tested, or the "
                    "producer's page for the finding. Populated only where the producer supplies one, and "
                    "its meaning varies by tool."
                ),
            },
            "event_type": {"data_type": "VARCHAR(100)", "category": "Event Information",
                "semantic_description": (
                    "The kind of event that triggered this finding, for producers that are event-driven "
                    "rather than scan-driven. Says what HAPPENED, whereas `finding_type` says what the "
                    "finding IS."
                ),
            },
            "event_source": {"data_type": "VARCHAR(100)", "category": "Event Information",
                "semantic_description": (
                    "Where the triggering event originated, for event-driven producers. Complements "
                    "`event_type` by identifying the emitter, and is NULL for findings produced by a "
                    "scheduled scan rather than an event."
                ),
            },
            "first_seen": {"data_type": "TIMESTAMP_NTZ", "category": "Timeline",
                "semantic_description": (
                    "When this finding was first observed by its producer. ⚠️ Distinct from "
                    "`entity_edges.first_seen`, which dates a relationship rather than a detection, and "
                    "from `detection_time` — `first_seen` survives re-detection while `detection_time` "
                    "reflects the reporting run."
                ),
            },
            "last_seen": {"data_type": "TIMESTAMP_NTZ", "category": "Timeline",
                "semantic_description": (
                    "When this FINDING was last detected by its producer. Still occurring is a different "
                    "state from historical. ⚠️ Distinct from `entity_edges.last_seen`, which dates a "
                    "relationship rather than a detection."
                ),
            },
            "detection_time": {"data_type": "TIMESTAMP_NTZ", "category": "Timeline",
                "semantic_description": (
                    "When the tool actually detected the condition on this run. ⚠️ Moves on each re-scan, "
                    "unlike `first_seen`, which is the earliest observation — measuring finding age from "
                    "this column resets the clock every scan and reports old findings as new."
                ),
            },
            "assigned_to": {"data_type": "VARCHAR(255)", "category": "Analysis",
                "semantic_description": (
                    "Who is investigating. Empty means nobody has picked it up."
                ),
            },
            "custom_attributes": {"data_type": "VARIANT", "category": "Tags & Metadata",
                "semantic_description": (
                    "Raw source-specific fields for this finding, packed as JSON at ingest so nothing the "
                    "source returned is lost. ⛔ For investigation only — its keys vary by source, so "
                    "shipped SQL must read a declared column instead."
                ),
            },
            "created_by": {"data_type": "VARCHAR(255)", "category": "Audit & Tracking",
                "semantic_description": (
                    "The Torana user or service principal that caused this finding row to be written. ⚠️ An "
                    "ingest-side actor, not the person responsible for remediating the finding."
                ),
            },
            "created_via": {"data_type": "VARCHAR(100)", "category": "Audit & Tracking",
                "semantic_description": (
                    "The Torana mechanism that wrote this finding row — an integration sync, a replay, a "
                    "manual push, or a synthetic dataset load. ⛔ Provenance, not finding data: it is what "
                    "separates genuinely ingested rows from generated ones, and a query measuring a real "
                    "estate should know which values are synthetic."
                ),
            },
            "dataset_tag": {"data_type": "VARCHAR(200)", "category": "Audit & Tracking",
                "semantic_description": (
                    "Marks this finding row as seeded by a NAMED synthetic dataset rather than a live "
                    "integration, so such rows can be purged as a set. NULL for genuinely ingested rows. ⛔ "
                    "Filter it out when measuring a real estate — counting demo rows as production finding "
                    "data is the error this column exists to prevent."
                ),
            },
            "created_date": {"data_type": "TIMESTAMP_NTZ", "category": "Audit & Tracking",
                "semantic_description": (
                    "When the finding record was created in its SOURCE system, as that system reports it. "
                    "⚠️ Not `created_at`, which is when Torana ingested the row, and not `first_seen`, "
                    "which is when the condition was first observed."
                ),
            },
            "last_modified_date": {"data_type": "TIMESTAMP_NTZ", "category": "Audit & Tracking",
                "semantic_description": (
                    "When the finding last changed in its source system. Provider-reported, so what counts "
                    "as a change varies by producer; use it for drift detection rather than as a precise "
                    "audit trail."
                ),
            },
            "closed_date": {"data_type": "TIMESTAMP_NTZ", "category": "Audit & Tracking",
                "semantic_description": (
                    "When the finding was closed in its source system. ⚠️ NULL means the finding is not "
                    "closed OR that the producer never reports closure — check `status` rather than "
                    "inferring open-ness from a NULL here."
                ),
            },
        }