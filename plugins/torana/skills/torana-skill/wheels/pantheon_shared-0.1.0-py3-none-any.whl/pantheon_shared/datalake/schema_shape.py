"""Schema SHAPE — the checkable contract behind the bundle staleness check (S19 / row 49).

⛔ WHAT THIS ANSWERS, AND WHAT IT DELIBERATELY DOES NOT.
`AppBundle.schema_revision` (S20) records PROVENANCE — *"what was this authored
against"*. This module supplies the CHECKABLE CONTRACT — *"does it still work?"*.
They are different questions and the first cannot answer the second: a bundle-level
revision is one string for a bundle whose artifacts read SIX different sink tables
(measured on `ciso_posture`, 2026-08-10), so one DDL change to `identities`
invalidates 3 artifacts and a bundle-level verdict condemns all 59. A check that
cries wolf gets routed around rather than obeyed (S17 § 7A: a 37-false-positive
guard).

⛔ THE REFUSAL CRITERION IS *SHAPE*, NOT EXISTENCE. Two axes, both first-class:

  A. REMOVAL      — a column the SQL reads is gone.
  B. TYPE CHANGE  — the column still exists under the same name, but its type
                    changed INCOMPATIBLY.

⚠️ AXIS B IS NOT AN EDGE CASE, AND AN EXISTENCE-ONLY CHECK PASSES IT SILENTLY.
Live types today (tenant `31ee89dc…`, measured 2026-08-10): `epss_score numeric(5)`,
`is_patch_available boolean`, `severity varchar(20)`. If `epss_score` became `text`,
`WHERE epss_score > 0.6` becomes a STRING comparison — `'0.09' > '0.6'` is TRUE — so
the query parses, EXPLAINs, runs, and returns the WRONG ROWS forever. Nothing renders
empty; nothing errors. That is precisely the failure class this workstream exists to
eliminate, so it is a first-class axis rather than a footnote.

⛔ WHAT "INCOMPATIBLE" MEANS — the decision this module records.
Compare type CATEGORIES, never type NAMES:

    numeric   ← numeric, decimal, integer, bigint, smallint, real, double precision
    string    ← character varying, character, text
    boolean   ← boolean
    temporal  ← timestamp (with/without tz), date, time
    json      ← json, jsonb
    uuid      ← uuid

Same category → COMPATIBLE regardless of width or precision. Different category →
INCOMPATIBLE. So `varchar(255) → text` is a harmless widening and passes; `numeric →
text` refuses; `boolean → varchar` refuses.

⚠️ NARROWING WITHIN A CATEGORY IS NOT FLAGGED (`text → varchar(50)`), and that is a
CHOICE, not an oversight. Bundle SQL essentially never depends on declared width, so
flagging it would manufacture false positives in exchange for a failure nobody has
observed — and the cost of a noisy gate is that it stops being obeyed. Recorded as a
known limit so the next person does not read the silence as a bug.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, Mapping, Optional, Tuple


class SchemaShapeUnavailable(RuntimeError):
    """The live shape could not be determined, so no verdict is possible.

    ⛔ Raised rather than returning an empty map, copying B11's posture exactly. An
    empty shape map is indistinguishable from "this tenant has no sink tables", and a
    check that reads that as "nothing to compare, therefore fine" passes every bundle
    in a degraded environment while looking healthy. A gate that fails open is worse
    than no gate, because it manufactures evidence (S20's `_catalog_entry_ids` did
    exactly this and let a fabricated catalog id through).
    """


#: Postgres `information_schema.columns.data_type` → coarse category.
#:
#: ⚠️ Keyed on the SQL-standard spelling `information_schema` reports (`character
#: varying`, not `varchar`; `timestamp without time zone`, not `timestamptz`), because
#: that is the string this module actually receives. `normalize_type` additionally
#: accepts the short aliases so an AUTHORED shape written by a human (`varchar`) lands
#: in the same bucket as the live one.
_TYPE_CATEGORIES: Dict[str, str] = {
    # numeric
    "numeric": "numeric", "decimal": "numeric", "integer": "numeric", "int": "numeric",
    "int2": "numeric", "int4": "numeric", "int8": "numeric", "smallint": "numeric",
    "bigint": "numeric", "real": "numeric", "double precision": "numeric",
    "float": "numeric", "float4": "numeric", "float8": "numeric", "money": "numeric",
    # string
    "character varying": "string", "varchar": "string", "character": "string",
    "char": "string", "bpchar": "string", "text": "string", "name": "string",
    "citext": "string",
    # boolean
    "boolean": "boolean", "bool": "boolean",
    # temporal
    "timestamp without time zone": "temporal", "timestamp with time zone": "temporal",
    "timestamp": "temporal", "timestamptz": "temporal", "date": "temporal",
    "time without time zone": "temporal", "time with time zone": "temporal",
    "time": "temporal", "interval": "temporal",
    # structured
    "json": "json", "jsonb": "json",
    "uuid": "uuid",
    "bytea": "binary",
    "inet": "network", "cidr": "network", "macaddr": "network",
    "array": "array", "ARRAY": "array",
}


def normalize_type(data_type: Optional[str]) -> str:
    """Map a Postgres type name to its comparison CATEGORY.

    An unrecognised type becomes its own category (the lower-cased base name), so an
    exotic type compares equal to itself and unequal to everything else. ⛔ It is never
    silently folded into a known bucket: guessing that an unknown type is "probably a
    string" is how a real incompatibility gets waved through.
    """
    if not data_type:
        return ""
    raw = str(data_type).strip().lower()
    # `numeric(5,2)` / `character varying(20)` → strip the width, which never affects
    # the category (that is the whole point of comparing categories).
    base = raw.split("(", 1)[0].strip()
    if base.endswith("[]"):
        return "array"
    return _TYPE_CATEGORIES.get(base, base)


def types_compatible(authored: Optional[str], live: Optional[str]) -> bool:
    """Is a column whose type was `authored` still safe to read now that it is `live`?

    True when the categories match (widths and precisions are ignored by design — see
    the module docstring). ⚠️ An UNKNOWN authored type (empty/None) returns True: the
    absence of a recorded type is not evidence of an incompatibility, and inventing one
    would refuse bundles for a fact nobody recorded. Removal is the other axis and is
    detected separately — a column with no live type at all never reaches here.
    """
    if not authored:
        return True
    return normalize_type(authored) == normalize_type(live)


@dataclass(frozen=True)
class ShapeBreak:
    """One column whose shape changed incompatibly. `kind` is `removed` or `type_changed`."""
    table: str
    column: str
    kind: str
    authored_type: Optional[str] = None
    live_type: Optional[str] = None

    def describe(self) -> str:
        """The operator-facing sentence. ⛔ Always NAMES THE COLUMN and what changed —
        "your version is old" is unactionable; this is a fix."""
        if self.kind == "removed":
            return (f"`{self.table}.{self.column}` — the column NO LONGER EXISTS in this "
                    f"tenant's schema (it was removed).")
        return (f"`{self.table}.{self.column}` — the column's type changed "
                f"{self.authored_type} → {self.live_type}, which is not a compatible "
                f"widening. Reads of it (comparisons, ordering, arithmetic) change "
                f"meaning silently: a numeric predicate on a string column compares "
                f"lexically, so `'0.09' > '0.6'` is TRUE and the SQL returns wrong rows "
                f"rather than failing.")

    def as_dict(self) -> Dict[str, Optional[str]]:
        return {"table": self.table, "column": self.column, "kind": self.kind,
                "authored_type": self.authored_type, "live_type": self.live_type,
                "message": self.describe()}


def compare_shape(
    reads: Iterable[Tuple[str, str]],
    live_shape: Mapping[Tuple[str, str], str],
    authored_shape: Optional[Mapping[Tuple[str, str], str]] = None,
    *,
    known_tables: Optional[Iterable[str]] = None,
) -> list:
    """Compare what an artifact READS against the LIVE shape. Returns `[ShapeBreak]`.

    `reads`         — `(table, column)` pairs the SQL references, lower-cased.
    `live_shape`    — `(table, column) -> data_type`, from `information_schema`.
    `authored_shape`— `(table, column) -> data_type` as it was when authored. When a
                      column is absent from it, only the REMOVAL axis is evaluated for
                      that column (no recorded type ⇒ no type claim to violate).
    `known_tables`  — tables the live shape actually covers. ⛔ A read of a table
                      OUTSIDE this set is SKIPPED, not reported removed: a bundle's own
                      transformer outputs do not exist on a fresh install, and reporting
                      them missing would refuse every first install.
    """
    authored_shape = authored_shape or {}
    known = {t.lower() for t in (known_tables or {t for t, _ in live_shape})}
    breaks = []
    for table, column in sorted(set(reads)):
        t, c = table.lower(), column.lower()
        if t not in known:
            continue
        live = live_shape.get((t, c))
        if live is None:
            breaks.append(ShapeBreak(table=t, column=c, kind="removed",
                                     authored_type=authored_shape.get((t, c))))
            continue
        authored = authored_shape.get((t, c))
        if authored and not types_compatible(authored, live):
            breaks.append(ShapeBreak(table=t, column=c, kind="type_changed",
                                     authored_type=authored, live_type=live))
    return breaks
