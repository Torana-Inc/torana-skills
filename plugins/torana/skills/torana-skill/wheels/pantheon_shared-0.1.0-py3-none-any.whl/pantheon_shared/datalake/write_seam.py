"""The declared write seam — every out-of-band sink-table write goes through here.

Design: ``pantheon-datalake/docs/DATALAKE_WRITE_SEAM_SPEC.md``.

════════════════════════════════════════════════════════════════════════════════
⛔ THE RULE THIS MODULE EXISTS TO ENFORCE — read before changing anything here
════════════════════════════════════════════════════════════════════════════════

**Never augment a datalake read.** Every value a user sees in a datalake column
must be PHYSICALLY STORED in that column, written through a declared path. Do not
attach, default, or compute column values on top of a query result.

**The reason, which matters more than the rule** — an augmented read makes the
reachability model *unfalsifiable*. `torana datalake all-columns --reachable`
answers *"can this column ever hold data?"*, and every SQL author, catalog entry
and build agent relies on it. If a value can appear in a result without any
writer, then a user seeing data in a column the platform calls unwritable has no
way to tell whether the model is wrong or an undeclared writer exists — and every
downstream verdict built on the model becomes unprovable. A rule whose reason is
missing gets waived by the next person with a deadline; this is the reason.

The decoration layer got this right and is the pattern to copy: it writes a real
``UPDATE`` and stamps ``decoration_provenance`` on the row, so the value is *in
the table and attributable*.

────────────────────────────────────────────────────────────────────────────────
What this module is for
────────────────────────────────────────────────────────────────────────────────

Reachability (``pantheon_shared.datalake.reachability``) derives its answer from
six write mechanisms — mapping YAML, ETL operator, decoration, system fields, push
ingestor, extractor/service. A write that goes through NONE of them (an API
endpoint merging caller-supplied fields into a row, a service writing findings
directly) is invisible to it. Measured consequence, and the reason this exists:
``PATCH /api/v1/ingest/vulnerabilities`` writes ``exploitability_status`` and three
sibling columns that **no other path writes**, so the platform reported them
unwritable while shipping the endpoint whose whole purpose is to write them.
``exploitability_status`` is the headline blocker of an entire corpus category.

So: an out-of-band writer **declares the columns it writes, next to the code that
writes them**, and reachability IMPORTS this registry. A new writer appears in
``--reachable`` with **no edit to reachability.py**.

────────────────────────────────────────────────────────────────────────────────
⚠️ A `declared` writer is a DEPENDENCY ON SOMEONE DOING SOMETHING
────────────────────────────────────────────────────────────────────────────────

The other seven mechanisms fill themselves — a mapping fills when an integration
syncs, an operator when ETL runs. **This one does not.** It fills only when an
external actor chooses to call the code. Registering a column therefore makes it
*reachable* and every gate then calls the question *answerable* — while the column
may stay empty forever.

Measured: the six human-triage columns on ``PATCH /ingest/vulnerabilities`` moved
the reachable count 389 → 395 and flipped two corpus questions from refused to
answerable, with ``count(is_confirmed) = 0 of 6,179 rows``. A dashboard renders
an empty panel and a reader concludes *"there are no lingering mitigations"*; the
truth is *"nobody has recorded one."* Those are opposite conclusions.

So every registration **names its expected caller** (``expected_caller=``), and
``status="none"`` says out loud that the column is dead on arrival until somebody
builds one. See ``ExpectedCaller``. ⛔ Since 2026-08-06 this is **REQUIRED** —
``register_writer`` raises ``MissingCallerError`` without it.

────────────────────────────────────────────────────────────────────────────────
⚠️ …AND `expected_caller` CANNOT SAY HOW TO BECOME THAT CALLER
────────────────────────────────────────────────────────────────────────────────

Naming the caller turns "this column is empty" into a work item. It does NOT make
the work item actionable: there is no method, no path, no payload, no timing
constraint — only the *name of a thing that does not exist*. And
``ExpectedCaller.note`` explicitly refuses to carry it ("NEVER load-bearing").

So a bridging registration also passes ``bridge_id=``, a REFERENCE into
``pantheon-datalake/torana_datalake/corpus/bridge_registry.py``, which holds the callable
contract. Reference and not payload: one action fills 6-19 columns, so inlining
would repeat it per column and let the copies drift, and HTTP-payload knowledge
does not belong in a datalake module.

⚠️ **The worse case the registry exists for is `correlation`** — a bridge column
is a JOIN KEY, writable only at creation time by whatever holds both ids, and
never retro-fittable. Its failure mode is not an empty column but a join that
parses, EXPLAINs, runs, and returns nothing forever — while both sides look
reachable, because the counterpart PK genuinely is. 18 of the 46 corpus refusals
turn on exactly this.

────────────────────────────────────────────────────────────────────────────────
⚠️ Why the allowlist is DERIVED from registrations, never hand-written centrally
────────────────────────────────────────────────────────────────────────────────

The strongest temptation is one central file listing the permitted (table, column)
pairs. **Resist it.** Reachability already carries nine hand-written tuples, and
they have already drifted: ``_INGESTOR_WRITERS`` names
``etl/ingestors/sarif.py::_pkg_record``, a symbol that no longer exists (the method
is ``_package_record``), and ``etl/ingestors/asset.py`` — a whole ingestor — is
absent. A bigger hand-written list drifts faster, and nothing fails when it does.

Registration is still hand-written, but ONCE, at the write site, where the person
adding a writer cannot miss it. This is exactly how mechanisms 3 and 4 work, and
precisely why they cannot drift: ``DECORATIONS`` declares its outputs per spec and
reachability imports the registry rather than parsing for it.

────────────────────────────────────────────────────────────────────────────────
Scope — deliberately narrow
────────────────────────────────────────────────────────────────────────────────

ONLY the 11 sink tables are gated. Everything else passes through untouched:

* non-sink tables (``vm_cve_metadata``, ``entity_edge_candidates``,
  ``entity_graph_derivation_metrics``, ``entity_properties_resolved``) carry no
  reachability claim — leave them unrestricted;
* DDL and truncation (``/tables/{name}/clear``, ``/drop``, ``/initialize``) destroy
  rows but write no column, so they cannot light one up;
* the six derived mechanisms keep working exactly as before — this seam is for
  what they structurally cannot see.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, FrozenSet, Iterable, Mapping, Optional, Sequence, Tuple

__all__ = [
    "SINK_TABLES",
    "CALLER_STATUSES",
    "CALLER_STATUS_WIRED",
    "CALLER_STATUS_NONE",
    "CALLER_STATUS_MANUAL",
    "ExpectedCaller",
    "WriteRegistration",
    "WRITERS",
    "register_writer",
    "registered_columns",
    "is_registered",
    "check_write",
    "enforce_write",
    "columns_without_caller",
    "writers_without_caller",
    "GRANDFATHERED_WITHOUT_CALLER",
    "UndeclaredWriteError",
    "MissingCallerError",
    "EmptyRegistryError",
    "registry_load_failures",
]


# ── The gated set ────────────────────────────────────────────────────────────
#
# The 11 sink tables that carry a reachability claim. Mirrors `_SINK_TABLES` in
# `torana_mesh/api/routes/reachability.py`, which is the set the map is built
# over. `pentest_cases` / `pentest_runs` are in the `DatalakeTables` enum but NOT
# in the reachability set, so they are deliberately NOT gated here: gating a table
# the map does not cover would refuse writes while lighting up nothing.

SINK_TABLES: FrozenSet[str] = frozenset({
    "artifacts", "assets", "controls", "datastores", "entity_edges", "findings",
    "identities", "issues", "packages", "repositories", "vulnerabilities",
})


# ── The expected caller ──────────────────────────────────────────────────────
#
# ⚠️ THE THING THAT MAKES `kind=declared` DIFFERENT FROM THE OTHER SEVEN.
#
# Seven mechanisms fill themselves: a mapping fills when an integration syncs, an
# operator when ETL runs, a system field on any insert. `declared` fills only when
# an EXTERNAL ACTOR CHOOSES TO CALL AN API. No sync will ever fill it.
#
# So a `declared` column is reachable and unpopulated in two completely different
# worlds, and `source`/`reason` cannot tell them apart:
#
#   a caller exists and is wired   -> unpopulated means "nobody has hit it YET"
#   no caller exists at all        -> unpopulated means "and never will be"
#
# The second is a column that is DEAD ON ARRIVAL: registering it flipped questions
# from ❌ refused to ✅ answerable, and they now return zero rows forever. A reader
# sees an empty dashboard panel and concludes "there are no lingering mitigations"
# when the truth is "nobody has recorded one" — opposite conclusions.
#
# ⛔ WHY THIS IS STRUCTURED AND NOT PROSE. `reason` is already free text, and
# "the triage agent will call this" is unqueryable — a machine cannot answer
# "which declared columns have no caller?" from it. The whole point of the field
# is that the question is answerable BY A MACHINE, so `status` is a closed
# vocabulary validated at registration.

CALLER_STATUS_WIRED = "wired"
"""A caller EXISTS and calls this endpoint today. Unpopulated means "not yet
exercised", which is a deployment/adoption fact, not a build defect."""

CALLER_STATUS_MANUAL = "manual"
"""No automated caller — a human drives it (a UI action, an operator running a
CLI). It CAN fill, but only when a person acts. Distinct from `wired` because
nothing will ever fill it unattended, and distinct from `none` because the path
to filling it exists and needs no engineering."""

CALLER_STATUS_NONE = "none"
"""⚠️ NO caller exists. The column is DEAD ON ARRIVAL: it is reachable, so every
gate says the question is answerable, and it will return zero rows until somebody
BUILDS the caller. This is the state worth surfacing loudest."""

CALLER_STATUSES: FrozenSet[str] = frozenset({
    CALLER_STATUS_WIRED, CALLER_STATUS_MANUAL, CALLER_STATUS_NONE,
})


@dataclass(frozen=True)
class ExpectedCaller:
    """WHO is expected to call the writer, and whether they exist yet.

    ``name`` is the actor — a skill (`torana-pentest`), a service, a UI surface.
    It is REQUIRED even when ``status="none"``: naming the caller that does not
    exist yet is what turns "this column is empty" into a work item somebody can
    pick up. A registration that cannot name one is a registration whose author
    has not decided what the column is for.
    """

    name: str
    """The actor expected to call this writer, e.g. ``torana-pentest``."""

    status: str
    """One of ``CALLER_STATUSES``. See each constant for what it licenses."""

    note: str = ""
    """Optional free text — a ticket, a caveat. NEVER load-bearing: everything a
    machine must answer is in ``name`` + ``status``."""

    @property
    def exists(self) -> bool:
        """True when SOMETHING can fill the column — automated or human.

        ⚠️ ``manual`` counts as existing. The question this answers is "can this
        column ever hold data without new engineering?", and a human-driven path
        can. "Will it fill unattended?" is a different question — ask ``status``.
        """
        return self.status in (CALLER_STATUS_WIRED, CALLER_STATUS_MANUAL)

    def as_dict(self) -> Dict[str, object]:
        out: Dict[str, object] = {"name": self.name, "status": self.status,
                                  "exists": self.exists}
        if self.note:
            out["note"] = self.note
        return out


def _coerce_caller(writer_id: str, value: object) -> Optional[ExpectedCaller]:
    """Accept an ``ExpectedCaller`` or a plain mapping; validate the status.

    A mapping is accepted so a registration reads as data at the call site
    without importing the class. It is validated exactly as strictly.
    """
    if value is None:
        return None
    if isinstance(value, ExpectedCaller):
        caller = value
    elif isinstance(value, Mapping):
        caller = ExpectedCaller(
            name=str(value.get("name", "")).strip(),
            status=str(value.get("status", "")).strip().lower(),
            note=str(value.get("note", "") or "").strip(),
        )
    else:
        raise ValueError(
            f"register_writer({writer_id!r}): `expected_caller` must be an "
            f"ExpectedCaller or a mapping, got {type(value).__name__}."
        )

    if caller.status not in CALLER_STATUSES:
        raise ValueError(
            f"register_writer({writer_id!r}): expected_caller.status="
            f"{caller.status!r} is not one of {sorted(CALLER_STATUSES)}. The "
            f"status is a CLOSED vocabulary on purpose — free text cannot answer "
            f"'which declared columns have no caller?', which is the only reason "
            f"this field exists."
        )
    if not caller.name:
        raise ValueError(
            f"register_writer({writer_id!r}): expected_caller.name is required, "
            f"even when status={caller.status!r}. Naming the caller that does "
            f"NOT exist yet is what turns 'this column is empty' into a work "
            f"item somebody can pick up."
        )
    return ExpectedCaller(name=caller.name, status=caller.status, note=caller.note)


# ── The grandfather set — DELIBERATELY EMPTY, and it must stay that way ──────
#
# ⛔ `expected_caller` is REQUIRED at registration (see `register_writer`). This
# set is the escape hatch for registrations that predate the requirement.
#
# ⚠️ MEASURED 2026-08-06, and it is the reason the rule could be turned on at all:
# all 10 live registrations ALREADY declare a caller, so the gap is ZERO and there
# is nothing to grandfather. The requirement therefore fails NOTHING today — it
# only binds the next person, which is the entire point.
#
# ⛔ DO NOT ADD TO THIS SET TO MAKE A NEW REGISTRATION PASS. A grandfather list
# that never shrinks is how drift gets legalised: a second rule with the same
# weakness as the first. It is `frozenset()` so that adding an entry is a visible,
# reviewable diff to THIS file with THIS comment attached to it — not a quiet
# keyword argument at a call site.
#
# The count is asserted by `pantheon-shared/tests/datalake/test_bridge_registry.py`
# (`test_grandfather_set_is_empty`), so growing it fails CI rather than passing
# silently.

GRANDFATHERED_WITHOUT_CALLER: FrozenSet[str] = frozenset()
"""Writer ids exempt from the ``expected_caller`` requirement. Empty by
measurement — see the comment above before ever adding one."""


class MissingCallerError(ValueError):
    """A registration did not name its ``expected_caller``.

    Its own type (not a bare ``ValueError``) so the one thing this rule is about
    — "somebody added a writer without saying who calls it" — is distinguishable
    in a log from a malformed table name or an empty column list.
    """


class UndeclaredWriteError(ValueError):
    """An out-of-band write named a (table, column) no writer registered.

    Deliberately a subclass of ``ValueError`` so an existing ``except ValueError``
    around a write path still catches it, and deliberately its own type so a caller
    that wants to distinguish "this column is not declared" from "this value is
    malformed" can.
    """


class EmptyRegistryError(RuntimeError):
    """⛔ The registry held NOTHING, so *"what can the platform write?"* has no answer.

    ⚠️ THE POINT, and it is not strictness for its own sake: the registry is
    populated **by side effect of import** — each writer module runs a top-level
    ``register_writer()``. So an empty ``WRITERS`` does not mean *"nothing is
    declared"*; it means *"this process happened to import nothing"*. Those are
    different facts and they used to produce the SAME value: ``0``.

    Measured, before this existed::

        $ python3 -c "from ...write_seam import registered_columns
                      print(len(registered_columns()))"                 # -> 0
        $ python3 -c "import torana_mesh.api.routes.ingest
                      from ...write_seam import registered_columns
                      print(len(registered_columns()))"                 # -> 66

    ⭐ **The strongest argument for raising: the current default is ALREADY a
    refusal, just an accidental one.** On an empty registry ``check_write`` finds
    nothing declared and reports EVERY column undeclared, so ``enforce_write``
    blocks a *legitimate* write. Raising does not add strictness — **it makes
    existing strictness legible**, and names the modules that failed to load
    instead of presenting an import accident as a fact about the platform.

    Its own type (not a bare ``RuntimeError`` message) so *"this process cannot see
    the registry"* is distinguishable from a genuine measurement failure — the same
    reason ``shadow_baseline.SeamRegistryEmpty`` exists. It is a ``RuntimeError``
    rather than a ``ValueError`` precisely so the ``except ValueError`` guards that
    wrap write paths do NOT swallow it: an unloadable registry is an environment
    fault, not a bad value.

    ⭐ The escape hatch is ``allow_empty=True`` — explicit and **greppable**, so a
    caller that legitimately has no writers says so in the source rather than
    inheriting the answer from an import nobody declared.
    """


def registry_load_failures() -> Tuple[str, ...]:
    """⭐ Which writer modules this process could NOT import. ``()`` means all loaded.

    ⛔ **PARTIAL is a THIRD state, and it is more dangerous than empty** — measured
    while building this row, and the brief for it did not name this case at all.

    On the host venv, ``torana_mesh`` IS importable but 5 of its 6 writer modules
    raise (they import service settings that validate a reachable ``DATABASE_URL``),
    while ``torana_mesh.etl.sdg_provenance`` imports cleanly. Result::

        load_write_seam_modules()   ->  5 of 6 FAILED
        len(WRITERS)                ->  10   (of the real 21)

    ⚠️ So ``bool(WRITERS)`` — the obvious guard, and the one the shadow gate's
    ``_seam_available()`` used — reports **True**. A partial registry passes an
    emptiness check while answering with HALF the platform: the shadow gate measured
    12 phantom shadow columns on a baseline of 0 and would have read as *"you
    declared 12 columns nothing writes"* when the truth was *"11 registrations
    failed to import."*

    ⛔ That is this row's failure class exactly, one level in: not *"a zero that
    reads as a fact"* but *"a non-zero that reads as a complete answer."* So the
    guard checks WHAT FAILED, never merely whether anything registered.

    Idempotent and cheap after the first call — ``importlib`` caches, so this is a
    ``sys.modules`` hit per module thereafter.
    """
    try:
        from pantheon_shared.datalake.shadow_baseline import load_write_seam_modules
    except Exception as exc:            # pragma: no cover - loader itself unimportable
        return (f"<loader unavailable: {exc}>",)
    return tuple(load_write_seam_modules())


def _load_and_require_registry(allow_empty: bool, caller: str) -> None:
    """⭐ AUTO-LOAD first, then refuse. Never refuse without having tried.

    ⛔ Refusing without loading would force every caller to remember the import —
    **which is the bug, restated**. ``load_write_seam_modules()`` already exists,
    is failure-tolerant, and returns the modules that failed, so the refusal can
    name *which* ones could not be imported rather than only *that* the registry
    is empty.

    ⛔ **The condition is "did anything fail to load", NOT "is WRITERS empty."** See
    ``registry_load_failures()`` for the measurement that forced that: a partial
    load leaves ``WRITERS`` truthy and half-wrong.

    Imported lazily inside the function: ``shadow_baseline`` imports from THIS
    module, so a module-level import would be circular.
    """
    if allow_empty:
        return

    # ⭐ An in-process registration SATISFIES the guard, and this is the load-bearing
    # asymmetry between the two states:
    #
    #   EMPTY   — nobody registered and nobody loaded. Nothing to answer from. REFUSE.
    #   PARTIAL — some registered, some modules failed to import. Ambiguous, so the
    #             tie-break is WHO put the entries there.
    #
    # ⛔ A writer module that ran `register_writer()` in THIS process has declared
    # itself explicitly — that is the seam working as designed, and refusing it would
    # break the write path this whole seam exists to protect (the five real callers
    # all register at module scope; see `enforce_write`). A registry populated ONLY by
    # the auto-loader, with failures alongside, is a different thing: nobody in this
    # process asked for those writers, they arrived by import accident, and the set is
    # provably incomplete. THAT is what must refuse.
    if _EXPLICIT_REGISTRATIONS:
        return

    failed = registry_load_failures()
    if not failed and WRITERS:
        return

    try:
        from pantheon_shared.datalake.shadow_baseline import WRITE_SEAM_MODULES
    except Exception:                   # pragma: no cover
        WRITE_SEAM_MODULES = ()         # type: ignore[assignment]

    if failed:
        state = "EMPTY" if not WRITERS else (
            f"PARTIAL — {len(WRITERS)} registration(s) loaded, which is WORSE than "
            f"empty because it looks like an answer"
        )
        detail = (
            f"{len(failed)} of {len(WRITE_SEAM_MODULES) or len(failed)} writer "
            f"module(s) FAILED to import:\n  - " + "\n  - ".join(failed)
        )
    else:
        state = "EMPTY"
        detail = (
            "the loader reported NO import failures, so the modules it knows about "
            "register nothing — the module list is stale:\n  - "
            + "\n  - ".join(WRITE_SEAM_MODULES or ("<empty list>",))
        )

    raise EmptyRegistryError(
        f"{caller}: the datalake write-seam registry is {state}.\n"
        f"\n"
        f"This is NOT the same as 'nothing is declared'. The registry is populated "
        f"by side effect of IMPORT — each writer module runs a top-level "
        f"register_writer() — so an incomplete registry means THIS PROCESS COULD "
        f"NOT IMPORT THE WRITERS. Auto-load was attempted and {detail}\n"
        f"\n"
        f"Answering anyway would hand you a confident number: on an empty registry "
        f"check_write() reports EVERY column undeclared, so enforce_write() blocks "
        f"legitimate writes, and every read-side consumer (reachability, shadow, "
        f"caller-dependency) is confidently wrong in the UNSAFE direction. On a "
        f"PARTIAL registry it is worse — the answer looks complete.\n"
        f"\n"
        f"Fix it by running where the writer modules are importable "
        f"(pantheon-integration-dev holds torana_mesh). If you legitimately have no "
        f"writers — an offline report, a unit test, a schema-only tool — pass "
        f"allow_empty=True, which is deliberately explicit and greppable so "
        f"'I meant this' is visible in the source."
    )


@dataclass(frozen=True)
class WriteRegistration:
    """One out-of-band writer and the sink columns it is permitted to write.

    Every field is provenance the reachability ``--explain`` surface renders, so a
    reader can see WHICH endpoint or service lights a column up, the same way they
    can see which mapping file does.
    """

    writer_id: str
    """Stable id, e.g. ``ingest.patch_vulnerability``. Appears in ``--explain``."""

    table: str
    """Sink table this registration covers."""

    columns: Tuple[str, ...]
    """Sink columns this writer may write. Lowercased on registration."""

    source: str
    """Code location, e.g. ``api/routes/ingest.py::_update_vulnerability_impl``.
    A path a reader can open — the whole point of provenance."""

    reason: str
    """WHY this writer exists outside the six derived mechanisms. Required: a
    registration without a reason is the start of a list nobody can audit."""

    integration: Optional[str] = None
    """Owning integration family, when the write belongs to one. ``None`` means
    unconditional — it does not depend on any customer integration being
    connected, so it counts in BOTH tenant and platform scope (same semantics as
    a system field or a global decoration)."""

    expected_caller: Optional[ExpectedCaller] = None
    """WHO is expected to call this writer, and whether they exist yet.

    ⚠️ ``None`` means UNDECLARED, which is NOT the same as "no caller". It is
    "nobody has said" — a registration written before this field existed, or one
    whose author skipped the question. Consumers must report it as unknown rather
    than assume either answer; `status="none"` is the way to say there is no
    caller, and it is a deliberate statement."""

    bridge_id: Optional[str] = None
    """⛔ A REFERENCE into the bridge registry — never an inlined contract.

    ``expected_caller`` says WHO should call this and whether they exist. It
    cannot say HOW to become that caller: the method, the path, a payload that
    would actually work, and — for a join key — the timing constraint that makes
    the write non-retro-fittable. That is what a reader of an empty column needs
    and what ``ExpectedCaller.note`` explicitly refuses to carry ("NEVER
    load-bearing").

    So the contract lives in ``pantheon-datalake/torana_datalake/corpus/bridge_registry.py``
    and this field points at it::

        bridge_id="BRIDGE-TRIAGE-001"

    ⚠️ **Reference, not payload.** One action fills 6-19 columns; inlining would
    repeat the contract per column and let the copies drift, and it would put
    HTTP-payload knowledge inside a datalake module that has no business holding
    it.

    ⛔ **The ordering rule:** the registry entry is written BEFORE the id is
    referenced here. A ``bridge_id`` naming no entry FAILS the registry's
    ``validate()`` — which is the point: it forces the contract to be written
    while the author still knows it."""

    def as_dict(self) -> Dict[str, object]:
        out: Dict[str, object] = {
            "writer_id": self.writer_id,
            "table": self.table,
            "columns": list(self.columns),
            "source": self.source,
            "reason": self.reason,
        }
        if self.integration:
            out["integration"] = self.integration
        if self.expected_caller is not None:
            out["expected_caller"] = self.expected_caller.as_dict()
        if self.bridge_id:
            out["bridge_id"] = self.bridge_id
        return out


# ── The registry ─────────────────────────────────────────────────────────────
#
# Populated by `register_writer()` calls that live NEXT TO the writing code, not
# here. This dict is the union of those registrations and nothing else — there is
# deliberately no literal (table, column) list in this file to drift.

WRITERS: Dict[str, WriteRegistration] = {}

# Writer ids registered OUTSIDE the auto-loader — i.e. a module in this process ran
# `register_writer()` on its own. ⭐ Used only by `_load_and_require_registry` to tell
# "somebody here declared this" from "the auto-loader scraped up what it could".
# Deliberately a separate set rather than a flag on the registration: it is a fact
# about THIS PROCESS, not about the writer, and the same writer is explicit in
# pantheon-integration and loader-supplied everywhere else.
_EXPLICIT_REGISTRATIONS: set = set()

# True only while `load_write_seam_modules()` is running, so registrations that arrive
# as its side effect are not counted as explicit.
_AUTOLOADING: bool = False


def _set_autoloading(value: bool) -> None:
    """Toggle the auto-load flag. Called by ``shadow_baseline.load_write_seam_modules``."""
    global _AUTOLOADING
    _AUTOLOADING = value


def register_writer(
    *,
    writer_id: str,
    table: str,
    columns: Iterable[str],
    source: str,
    reason: str,
    integration: Optional[str] = None,
    expected_caller: object = None,
    bridge_id: Optional[str] = None,
) -> WriteRegistration:
    """Declare that ``writer_id`` writes ``columns`` of ``table``.

    Call this at MODULE SCOPE in the module that performs the write, so the
    declaration is impossible to miss when the write changes and so importing the
    writer is enough to register it.

    ⛔ **``expected_caller`` is REQUIRED — this RAISES without it.** A
    ``declared`` column fills only when an external actor calls this code; no sync
    will ever fill it. So "who is expected to call it" is the fact that decides
    whether an empty column means "not yet exercised" or "dead on arrival", and a
    registration that omits it makes the seam's whole query — *"which declared
    columns have no caller?"* — return a third, useless answer ("nobody said").

    ⚠️ It was optional and unenforced until 2026-08-06, and that was the flaw
    worth fixing rather than repeating: documentation alone had been relied on,
    and no test asserted it. Measured before turning it on: all 10 live
    registrations already declared one, so requiring it broke nothing and
    ``GRANDFATHERED_WITHOUT_CALLER`` is empty. Pass an ``ExpectedCaller`` or a
    mapping::

        expected_caller={"name": "torana-pentest", "status": "wired"}
        expected_caller={"name": "triage agent", "status": "none",
                         "note": "no caller built yet — columns stay empty"}

    ⚠️ **If the caller does not exist, that is what ``status="none"`` is for.**
    Do not reach for the grandfather set to make this error go away — an honest
    ``none`` is a work item, and an exemption is a silent gap.

    ⛔ **Bridging actions also pass ``bridge_id``**, referencing an entry that
    ALREADY EXISTS in ``pantheon-datalake/torana_datalake/corpus/bridge_registry.py``.
    ``expected_caller`` names who should call; ``bridge_id`` points at HOW —
    method, path, working payload, and the timing constraint. Write the entry
    first; a dangling id fails the registry's ``validate()``.

    Re-registering the same ``writer_id`` with the same content is a no-op (module
    re-import under a different name is normal and must not raise). Re-registering
    it with DIFFERENT content raises: two writers silently sharing an id would make
    the provenance in ``--explain`` a lie.

    Raises:
        ValueError: unknown/non-sink ``table``, empty ``columns``, missing
            ``reason``, an ``expected_caller`` with an unknown status or no name,
            or a conflicting re-registration.
        MissingCallerError: no ``expected_caller`` and ``writer_id`` is not in
            ``GRANDFATHERED_WITHOUT_CALLER``.
    """
    table = str(table).strip().lower()
    if table not in SINK_TABLES:
        raise ValueError(
            f"register_writer: {table!r} is not a gated sink table. Only the 11 "
            f"sink tables carry a reachability claim, so only they are gated; "
            f"writers to any other relation need no registration and must not "
            f"add one. Gated: {sorted(SINK_TABLES)}"
        )
    cols = tuple(sorted({str(c).strip().lower() for c in columns if str(c).strip()}))
    if not cols:
        raise ValueError(
            f"register_writer({writer_id!r}): `columns` is empty. A registration "
            f"that declares nothing permits nothing and lights nothing up."
        )
    if not str(reason).strip():
        raise ValueError(
            f"register_writer({writer_id!r}): `reason` is required — it is what "
            f"makes the registry auditable rather than another list nobody can "
            f"evaluate."
        )

    caller = _coerce_caller(str(writer_id), expected_caller)

    # ⛔ REQUIRED, not advisory. Extends the existing refuse-at-registration
    # pattern (non-sink table, empty columns, missing reason, conflicting id)
    # rather than inventing a second kind of check — the spec's point being that
    # documentation alone demonstrably did not make anyone declare one.
    if caller is None and str(writer_id) not in GRANDFATHERED_WITHOUT_CALLER:
        raise MissingCallerError(
            f"register_writer({writer_id!r}): `expected_caller` is REQUIRED.\n"
            f"\n"
            f"A `declared` column fills ONLY when an external actor calls this "
            f"code — no sync will ever fill it. Without a declared caller, the "
            f"seam cannot answer 'which declared columns have no caller?', which "
            f"is the only reason it can distinguish an empty column meaning 'not "
            f"yet exercised' from one meaning 'dead on arrival'. Measured: six "
            f"triage columns flipped two corpus questions to ANSWERABLE while "
            f"returning 0 of 6,179 rows, forever.\n"
            f"\n"
            f"    expected_caller={{\"name\": \"torana-pentest\", \"status\": \"wired\"}}\n"
            f"\n"
            f"⚠️ If no caller exists yet, SAY SO — that is what status='none' is "
            f"for, and naming the caller that does not exist is what turns an "
            f"empty column into a work item:\n"
            f"\n"
            f"    expected_caller={{\"name\": \"<the thing that should call this> "
            f"(NOT BUILT)\", \"status\": \"none\"}}\n"
            f"\n"
            f"⛔ Do NOT add this writer to GRANDFATHERED_WITHOUT_CALLER to silence "
            f"this. That set is empty by measurement and exists only for "
            f"registrations predating the rule; growing it legalises the exact "
            f"drift this check removes, and a test asserts it stays empty."
        )

    reg = WriteRegistration(
        writer_id=str(writer_id),
        table=table,
        columns=cols,
        source=str(source),
        reason=str(reason).strip(),
        integration=integration,
        expected_caller=caller,
        bridge_id=(str(bridge_id).strip() or None) if bridge_id else None,
    )
    prior = WRITERS.get(reg.writer_id)
    if prior is not None and prior != reg:
        raise ValueError(
            f"register_writer: writer_id {reg.writer_id!r} is already registered "
            f"with different content ({prior.source} -> {reg.source}). Ids must be "
            f"unique: two writers sharing one id makes --explain provenance wrong."
        )
    WRITERS[reg.writer_id] = reg
    if not _AUTOLOADING:
        _EXPLICIT_REGISTRATIONS.add(reg.writer_id)
    return reg


def registered_columns(
    table: Optional[str] = None,
    *,
    allow_empty: bool = False,
) -> Dict[Tuple[str, str], Tuple[WriteRegistration, ...]]:
    """``{(table, column): (registrations,)}`` — the derived allowlist.

    This IS the allowlist: the union of registrations, computed on every call so a
    late import (a writer module loaded after the first check) is picked up rather
    than frozen out by a cached snapshot.

    ⛔ **On an empty registry this AUTO-LOADS and then RAISES**
    ``EmptyRegistryError`` — it does not return ``{}``. An empty registry means
    *"this process imported nothing"*, not *"nothing is declared"*, and returning
    ``{}`` made those two facts the same value. See ``EmptyRegistryError``.

    Args:
        table: restrict to one sink table.
        allow_empty: ⭐ the explicit, greppable opt-out. Return ``{}`` instead of
            raising, for a caller that legitimately has no writers.
    """
    _load_and_require_registry(allow_empty, "registered_columns()")
    want = table.strip().lower() if table else None
    out: Dict[Tuple[str, str], Tuple[WriteRegistration, ...]] = {}
    for reg in WRITERS.values():
        if want and reg.table != want:
            continue
        for col in reg.columns:
            key = (reg.table, col)
            out[key] = out.get(key, ()) + (reg,)
    return out


def columns_without_caller(
    table: Optional[str] = None,
    *,
    include_undeclared: bool = True,
    allow_empty: bool = False,
) -> Dict[Tuple[str, str], Tuple[WriteRegistration, ...]]:
    """``{(table, column): (registrations,)}`` for columns NOTHING will fill.

    ⛔ THE QUERY THIS WHOLE FIELD EXISTS TO ANSWER — *"which declared columns have
    no caller?"*, answered by a machine rather than by reading prose.

    A column is included when EVERY registration that writes it lacks a caller
    that could fill it. The quantifier is deliberate: two writers may declare the
    same column, and if ONE of them is wired the column can fill, so it is not
    dead. Reporting it would cry wolf, and a checker that cries wolf gets waived.

    ``include_undeclared`` controls whether a registration with
    ``expected_caller=None`` counts as "no caller". It defaults True because an
    undeclared caller is not evidence of a caller — but the two are genuinely
    different states ("nobody said" vs "somebody said there is none"), so a
    caller that wants only the DELIBERATE ``status="none"`` can ask for it.

    ⛔ **RAISES on an empty registry** (after auto-loading), because an empty answer
    here reads as *"no dead-on-arrival columns"* — a clean bill — when the truth is
    *"could not tell"*. ⭐ That is the same reasoning that made
    ``caller_dependency`` refuse in S22, and it matters more here than for a count:
    a clean bill nobody earned is worse than no answer.
    """
    out: Dict[Tuple[str, str], Tuple[WriteRegistration, ...]] = {}
    for key, regs in registered_columns(table, allow_empty=allow_empty).items():
        fillable = False
        for reg in regs:
            caller = reg.expected_caller
            if caller is None:
                if not include_undeclared:
                    fillable = True      # not asked to judge it — treat as fine
                continue
            if caller.exists:
                fillable = True
        if not fillable:
            out[key] = regs
    return out


def writers_without_caller() -> Tuple[WriteRegistration, ...]:
    """Registrations that named no ``expected_caller`` — the COUNTED gap.

    ⚠️ Distinct from ``columns_without_caller``, and the difference matters.
    That one answers *"which columns will nothing fill?"* (a data question, where
    ``status="none"`` is the interesting case). This one answers *"where did
    somebody skip the question entirely?"* (a process question, where the
    interesting case is ``expected_caller=None``).

    Since 2026-08-06 ``register_writer`` REFUSES a registration without one, so
    this can only ever return entries from ``GRANDFATHERED_WITHOUT_CALLER``. It
    returns ``()`` today because that set is empty.

    It exists anyway, and is not dead code: the spec's requirement is that a gap
    be **visible and counted** rather than silently grandfathered, so the count
    has to be queryable even when it is zero. A checker that only works once
    there is something to report cannot prove there is nothing to report.
    """
    return tuple(sorted(
        (r for r in WRITERS.values() if r.expected_caller is None),
        key=lambda r: r.writer_id,
    ))


def is_registered(table: str, column: str, *, allow_empty: bool = False) -> bool:
    """True if any writer declared ``(table, column)``.

    ⛔ **RAISES ``EmptyRegistryError`` on an empty registry** (after auto-loading).
    ⚠️ Yes, that means a function typed ``-> bool`` can raise, and that is the
    deliberate choice: **a membership test has nowhere to put a state.** Given an
    empty registry it can only answer ``False``, and ``False`` here means *"no
    writer declared this column"* — a claim about the platform. It would be
    asserting that on the strength of an import nobody declared.

    ⭐ A returned state (``loaded``/``partial``/``empty``) was considered and
    rejected for exactly this reason: a caller who is not reading carefully still
    gets the confident wrong answer. **Only a refusal survives that caller.**
    ``allow_empty=True`` is the explicit, greppable way to ask for the
    registry-blind answer.
    """
    key = (str(table).strip().lower(), str(column).strip().lower())
    return key in registered_columns(allow_empty=allow_empty)


def check_write(
    table: str,
    columns: Iterable[str],
    *,
    writer_id: Optional[str] = None,
    allow_empty: bool = False,
) -> Tuple[str, ...]:
    """Return the columns of ``table`` that no writer declared.

    Empty tuple means the write is fully declared. Non-sink tables always return
    empty — they carry no reachability claim, so gating them would refuse writes
    while lighting nothing up (§ scope above).

    ``writer_id`` narrows the check to ONE writer's declaration, which is what
    ``enforce_write`` uses: it stops writer A's registration from silently
    authorising writer B's column and keeps each writer's provenance honest.

    ⛔ **On an empty registry this AUTO-LOADS and then RAISES.** ⚠️ Measured, this
    is the case the refusal improves MOST, and the brief for this change got the
    reason for it wrong-way-round: on an empty registry ``check_write`` reports
    EVERY column undeclared::

        check_write('findings', ['finding_id', 'severity'])
        # before: ('finding_id', 'severity')   <- both, on a registry that saw nothing
        # now:    EmptyRegistryError, naming what failed to load

    So the old behaviour already refused the write — via ``enforce_write`` — it just
    refused it with a message blaming the *columns* for an *import* problem. The
    guard is placed before the ``writer_id`` branch too: that branch reads
    ``WRITERS`` directly and would otherwise answer "your own declared column is
    undeclared" on an unloaded registry.

    ``allow_empty=True`` is the explicit, greppable opt-out.
    """
    tbl = str(table).strip().lower()
    if tbl not in SINK_TABLES:
        return ()

    _load_and_require_registry(allow_empty, "check_write()")

    if writer_id is not None:
        reg = WRITERS.get(writer_id)
        allowed = set(reg.columns) if (reg and reg.table == tbl) else set()
    else:
        allowed = {c for (t, c) in registered_columns(tbl, allow_empty=allow_empty)}

    return tuple(sorted(
        c for c in {str(x).strip().lower() for x in columns if str(x).strip()}
        if c not in allowed
    ))


def enforce_write(
    table: str,
    records: Sequence[Mapping[str, object]],
    *,
    writer_id: str,
    ignore: Iterable[str] = (),
) -> None:
    """⛔ FAIL CLOSED. Raise unless every column in ``records`` is declared.

    **Never warn-and-write.** A warning is not a boundary: the row lands, the
    column holds data the reachability model says it cannot, and the model is
    unfalsifiable again — the exact failure this seam exists to remove. So this
    raises, and the caller does not write.

    ``ignore`` exempts columns that are written by an ALREADY-DERIVED mechanism and
    would otherwise have to be re-declared here. The system fields and adapter
    stamps are ignored by default (see ``_ALWAYS_IGNORED``) because reachability
    already derives them for every table from ``system_fields.py`` — re-declaring
    them per writer would be duplicate bookkeeping that can disagree with its
    source.

    Args:
        table: sink table being written.
        records: the records about to be written; their KEYS are the columns.
        writer_id: the registration to check against — must be the id this module
            registered, so a writer can only ever write what IT declared.
        ignore: extra column names to skip.

    Raises:
        UndeclaredWriteError: any column is not declared by ``writer_id``.
        EmptyRegistryError: the registry is empty even after auto-load, so the
            allowlist this checks against does not exist. ⭐ **The write-side blast
            radius of that raise is ZERO, and it is structural rather than luck:**
            you call ``enforce_write(..., writer_id=_MY_WRITER.writer_id)`` and
            ``_MY_WRITER`` comes from a module-level ``register_writer()`` in the
            same module — so you cannot REACH this function without having
            registered at least one writer. Verified across all five real callers
            (``ingest``, ``reconciliation``, ``graph_health_verdict``,
            ``deployment_repaint``, ``deployment_intelligence``).
    """
    tbl = str(table).strip().lower()
    if tbl not in SINK_TABLES:
        return

    skip = {str(c).strip().lower() for c in ignore} | _ALWAYS_IGNORED
    seen: set = set()
    for rec in records or ():
        for key in rec:
            k = str(key).strip().lower()
            # A staging field never reaches a table — `validate` drops anything the
            # schema does not declare before the upsert, so gating it would refuse a
            # write over a column that cannot exist.
            if k and not k.startswith("_") and k not in skip:
                seen.add(k)

    undeclared = check_write(tbl, seen, writer_id=writer_id)
    if not undeclared:
        return

    reg = WRITERS.get(writer_id)
    declared = ", ".join(reg.columns) if reg else "<writer_id not registered>"
    raise UndeclaredWriteError(
        f"Undeclared write to {tbl}: {list(undeclared)} (writer_id={writer_id!r}).\n"
        f"This writer declares: {declared}\n"
        f"\n"
        f"An out-of-band write must DECLARE the columns it writes, so "
        f"`--reachable` can see them. Add the column(s) to the register_writer() "
        f"call next to the writing code — NOT to a central list, and NOT to "
        f"reachability.py, which imports this registry.\n"
        f"\n"
        f"If the column genuinely should not be written here, the write is the "
        f"bug: fix the caller, do not widen the registration to make the error "
        f"go away."
    )


# Written by the datalake adapter / schema layer on EVERY record of EVERY table,
# and already derived by reachability mechanisms 2 and 4. Ignored so a writer
# does not re-declare platform bookkeeping it does not own.
#
# `contributing_sources` and `trace_id` are stamped by `datalake_adapter.py`
# alongside the IAM fields; `is_deleted` is flipped by tombstone/soft-delete paths
# on every table.
_ALWAYS_IGNORED: FrozenSet[str] = frozenset({
    "tenant_id", "namespace_id", "is_deleted", "created_at", "created_by",
    "updated_at", "updated_by", "contributing_sources", "trace_id",
})
