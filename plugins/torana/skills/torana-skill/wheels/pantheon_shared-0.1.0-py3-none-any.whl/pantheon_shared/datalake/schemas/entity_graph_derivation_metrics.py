from typing import Dict, Any
from .base import TableSchema


class EntityGraphDerivationMetricsSchema(TableSchema):
    """Schema for the entity_graph_derivation_metrics table
    (Torana_Asset_Graph_Design.md § 4.9.7).

    A **Postgres time-series table** recording per-pass edge-derivation metrics, so
    derivation health can be **correlated over time** ("how many edges derived /
    failed in the last hour, by edge type, with a confidence histogram"). The
    current observability stack is Vector → Loki → Grafana — Loki is a log store,
    not a metrics store, so scraped metrics have nowhere to land. Rather than stand
    up a TSDB, the derivation pass **writes metric samples directly to Postgres**
    (push, not scrape) and Grafana's Postgres datasource renders the dashboards.

    Granularity: **one rollup row per ingest pass per edge_type** (cheap — one
    insert per edge_type at end of pass, not per edge). "Last hour" is a
    ``created_at`` filter; trends are ``date_trunc`` at query time — no
    pre-bucketing.

    Forward-compatible: ``edge_type``/``source_system`` are this table's
    *dimensions* and the counters are its *measures* — the entity-graph-specific
    instance of a pattern that will later generalize into a consistent cross-service
    metrics mechanism. Keeping them explicit columns now is the right call for the
    first consumer (typed, indexable, clear).

    System fields (IAM, lifecycle, audit) are injected by ``get_full_schema()`` —
    do NOT declare them here. ``created_at`` (an audit field) is the time-window
    anchor for all "last N" / trend queries.
    """

    @property
    def table_name(self) -> str:
        return "entity_graph_derivation_metrics"

    @property
    def primary_key(self) -> str:
        return "id"

    @property
    def description(self) -> str:
        return (
            "Per-pass entity-graph edge-derivation metrics (one rollup row per ingest "
            "pass per edge_type): counters (derived/promoted/candidates/orphaned), a "
            "confidence histogram, timing, and a per-reason failure breakdown. A "
            "Postgres time-series table queried directly by the FE and Grafana's "
            "Postgres datasource — the table-based stand-in for a metrics pipeline."
        )

    @property
    def category(self) -> str:
        return "Entity Graph"

    @property
    def timestamp_column(self) -> str:
        return "created_at"

    @property
    def schema(self) -> Dict[str, Any]:
        return {
            "id": {"data_type": "VARCHAR(64)", "primary_key": True, "category": "Core Identity"},
            # What this row aggregates.
            "ingest_receipt_id": {"data_type": "VARCHAR(128)", "index": True, "category": "Dimensions"},
            "source_system": {"data_type": "VARCHAR(100)", "category": "Dimensions"},
            "edge_type": {"data_type": "VARCHAR(50)", "index": True, "category": "Dimensions"},
            # Counters (the "how many" view).
            "edges_derived": {"data_type": "INTEGER", "not_null": True, "category": "Counters"},
            "edges_promoted": {"data_type": "INTEGER", "not_null": True, "category": "Counters"},
            "candidates_written": {"data_type": "INTEGER", "not_null": True, "category": "Counters"},
            "edges_orphaned": {"data_type": "INTEGER", "not_null": True, "category": "Counters"},
            # Confidence histogram (sum over a window for the distribution).
            "conf_authoritative": {"data_type": "INTEGER", "not_null": True, "category": "Confidence Histogram"},
            "conf_high": {"data_type": "INTEGER", "not_null": True, "category": "Confidence Histogram"},
            "conf_medium": {"data_type": "INTEGER", "not_null": True, "category": "Confidence Histogram"},
            "conf_low": {"data_type": "INTEGER", "not_null": True, "category": "Confidence Histogram"},
            # Timing / throughput.
            "duration_ms": {"data_type": "INTEGER", "category": "Timing"},
            "records_in": {"data_type": "INTEGER", "category": "Timing"},
            # Failure decomposition — {"unkeyable_endpoint": 12, "ambiguous_match": 3, ...}.
            "reason_counts": {"data_type": "JSON", "category": "Diagnosis"},
        }
