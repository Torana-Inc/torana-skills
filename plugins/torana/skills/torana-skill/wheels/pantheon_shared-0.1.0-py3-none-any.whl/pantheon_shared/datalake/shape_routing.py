"""Shape routing — decide the value-axis DEPTH a column needs from HOW the SQL uses it.

S6 (SUPPLY_GRAPH_SPEC.md § 6 row 16). The value axis
(`SCHEMA_CONVERGENCE.md` § 2) ships three depths at three costs. A generator must
choose per column, and the choice is a property of the QUERY, not of the column:

    predicated against a literal  ->  values   (need the actual value list)
    counted / grouped / ordered   ->  shape    (cardinality is enough; free)
    existence only                ->  fill     (one aggregate)

⛔ WHY THIS LIVES IN pantheon-shared, NOT IN EITHER GENERATOR
-------------------------------------------------------------
There are TWO text-to-SQL surfaces (S6 § 5b): the platform agent
(pantheon-agent-builder) and the `torana-text-to-sql` Claude skill. If each
classified usage locally they would answer differently for the same question —
`SCHEMA_CONVERGENCE.md` § 3's "two harnesses hold different halves of the answer"
made permanent. One classifier, imported by both.

⛔ WHAT THIS MODULE DOES NOT DO
-------------------------------
It does NOT resolve the `values ⊃ shape ⊃ fill` implication. That is resolved
SERVER-SIDE by the supply API (`SCHEMA_CONVERGENCE.md` § 2.2) precisely so a
local resolution cannot drift. This module names the depth to ASK FOR; the server
decides what comes back.

It also holds no opinion about rows and issues no queries — it reads SQL text and
returns a routing decision. Fetching is the caller's job.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set

# The three depths, cheapest first. Ordered so `max()` over a set of depths
# yields the deepest one requested for a column used several ways.
DEPTH_FILL = "fill"
DEPTH_SHAPE = "shape"
DEPTH_VALUES = "values"

_DEPTH_ORDER: Dict[str, int] = {DEPTH_FILL: 0, DEPTH_SHAPE: 1, DEPTH_VALUES: 2}

#: Clause positions that DECIDE which rows come back. A CONSTANT column here is
#: a permanently-zero-row predicate; a CONSTANT column in a bare SELECT is fine.
#: Mirrors the STRUCTURAL/projection split the skill's reachability_gate already
#: makes for reachability — same clause taxonomy, different axis.
DECIDING_CLAUSES = frozenset({"where", "join", "having", "group_by", "order_by", "case"})


@dataclass
class ColumnUsage:
    """How one `table.column` is used across a single SQL statement.

    A column can be used several ways in one query (`WHERE severity = 'Critical'
    ... GROUP BY severity`). Every usage is recorded; `depth` is the deepest one
    required, and `warn_on_constant` is True if ANY usage is in a deciding clause.
    """

    column: str
    clauses: Set[str] = field(default_factory=set)
    compared_to_literal: bool = False
    literals: Set[str] = field(default_factory=set)

    @property
    def depth(self) -> str:
        """The value-axis depth this column's usage requires."""
        if self.compared_to_literal:
            # A predicate against a literal is the ONLY case that needs the
            # actual value list: a literal that does not occur returns zero rows
            # forever, and no cardinality figure can reveal that.
            return DEPTH_VALUES
        if self.clauses & {"group_by", "order_by", "aggregate", "join"}:
            # Cardinality is enough, and Tier 1 is free (one pg_stats read per
            # TABLE, no scan).
            return DEPTH_SHAPE
        return DEPTH_FILL

    @property
    def warn_on_constant(self) -> bool:
        """True when a CONSTANT shape on this column would be a real defect.

        ⛔ S6 § 4 rule 2: a CONSTANT column that is only SELECTed is FINE. Only
        a column that predicates, joins or groups can silently return zero rows.

        ⚠️ `case` and `order_by` alone are NOT enough. A CASE in a projection is
        a classifier — it changes labels, never membership — and ORDER BY only
        reorders rows it was already given. Measured on Q-026: a CASE classifier
        plus an ORDER BY over the same CASE produced a confident "returns ZERO
        rows, permanently" on a query whose emptiness came from an unrelated
        triage filter. A warning that fires on idiomatic SQL is how a reader
        learns to ignore the one that matters.

        ⛔ `group_by` STAYS a deciding clause even alone: bucketing by a constant
        is one bucket forever, regardless of any predicate.
        """
        if self.clauses & {"where", "join", "having", "group_by"}:
            return True
        # `case`/`order_by` count only alongside a clause that decides membership.
        return False


@dataclass
class ShapeRoute:
    """The routing decision for one SQL statement."""

    usages: Dict[str, ColumnUsage] = field(default_factory=dict)
    parse_error: Optional[str] = None

    def columns_for_depth(self, depth: str) -> List[str]:
        """Columns whose required depth is exactly `depth`."""
        return sorted(c for c, u in self.usages.items() if u.depth == depth)

    @property
    def values_columns(self) -> List[str]:
        return self.columns_for_depth(DEPTH_VALUES)

    @property
    def shape_columns(self) -> List[str]:
        return self.columns_for_depth(DEPTH_SHAPE)

    @property
    def fill_columns(self) -> List[str]:
        return self.columns_for_depth(DEPTH_FILL)

    def deepest_depth(self) -> Optional[str]:
        """The single deepest depth any column needs — what to ask the API for.

        ⛔ The API resolves `values ⊃ shape ⊃ fill` itself, so ONE call at the
        deepest depth answers every column. Asking per column would be N calls
        for a payload the server already returns whole.
        """
        if not self.usages:
            return None
        return max((u.depth for u in self.usages.values()), key=lambda d: _DEPTH_ORDER[d])


# ── SQL usage extraction ─────────────────────────────────────────────────────
#
# ⚠️ sqlglot, never a regex. A column can be a plain projection AND a reference
# inside a CASE in the same SELECT — the exact trap the skill's gate documents
# (SKILL.md § 5). A regex sees the projection and misses the CASE.


def _qualified(col, default_table: Optional[str], alias_map: Dict[str, str]) -> Optional[str]:
    """Render a sqlglot Column as `table.column`, resolving aliases. None if unresolvable.

    ⚠️ CONSERVATIVE, deliberately: an unqualified column in a multi-table query
    is SKIPPED rather than attributed to a guessed table. Mirrors the datalake
    supply endpoint's `columns_from_sql`, whose docstring states the same rule —
    a guessed attribution produces a confident wrong shape verdict.
    """
    name = col.name
    if not name:
        return None
    tbl = col.table or default_table
    if not tbl:
        return None
    tbl = alias_map.get(tbl.lower(), tbl)
    return f"{tbl.lower()}.{name.lower()}"


def _build_alias_map(tree, exp) -> tuple:
    """Return (alias -> real table, sole table name or None)."""
    alias_map: Dict[str, str] = {}
    tables: Set[str] = set()
    for t in tree.find_all(exp.Table):
        real = (t.name or "").lower()
        if not real:
            continue
        tables.add(real)
        alias = t.alias_or_name
        if alias:
            alias_map[alias.lower()] = real
    sole = next(iter(tables)) if len(tables) == 1 else None
    return alias_map, sole


def _comparison_sides(node, exp):
    """Split a comparison into (left_parts, right_parts), or None if not splittable.

    ⚠️ `exp.In` is not a binary node: its operand is `this` and its candidates are
    `expressions` (or a subquery, which we refuse by returning None).
    """
    if isinstance(node, exp.In):
        this = node.this
        items = node.args.get("expressions")
        if this is None or not items:
            return None
        return ([this], list(items))
    left = node.args.get("this")
    right = node.args.get("expression")
    if left is None or right is None:
        return None
    return ([left], [right])


def _literal_values(node, exp) -> Set[str]:
    """Literal values compared against within `node`."""
    out: Set[str] = set()
    for lit in node.find_all(exp.Literal):
        out.add(str(lit.this))
    for b in node.find_all(exp.Boolean):
        out.add(str(b.this))
    return out


def route_sql(sql: str, dialect: str = "postgres") -> ShapeRoute:
    """Classify every resolvable column reference in `sql` by required depth.

    Returns a ShapeRoute with `parse_error` set (and no usages) when the SQL
    cannot be parsed. ⛔ A parse failure is NEVER reported as "no columns need
    checking" — that is the confident-wrong-answer shape this subsystem exists
    to remove.
    """
    route = ShapeRoute()
    try:
        import sqlglot
        from sqlglot import exp
    except ImportError:
        route.parse_error = "sqlglot is not installed — cannot route shapes"
        return route

    try:
        tree = sqlglot.parse_one(sql, read=dialect)
    except Exception as err:
        route.parse_error = f"{type(err).__name__}: {err}"
        return route
    if tree is None:
        route.parse_error = "SQL parsed to nothing"
        return route

    alias_map, sole_table = _build_alias_map(tree, exp)

    def record(col_node, clause: str, literals: Optional[Set[str]] = None) -> None:
        ref = _qualified(col_node, sole_table, alias_map)
        if ref is None:
            return
        usage = route.usages.get(ref)
        if usage is None:
            usage = ColumnUsage(column=ref)
            route.usages[ref] = usage
        usage.clauses.add(clause)
        if literals:
            usage.compared_to_literal = True
            usage.literals |= literals

    # ── Comparisons against a literal — the `--values` trigger ───────────────
    # Every binary predicate and IN-list whose other side is a literal. This is
    # the only construct where a value that does not exist returns zero rows.
    comparison_types = (
        exp.EQ, exp.NEQ, exp.GT, exp.GTE, exp.LT, exp.LTE,
        exp.Like, exp.ILike, exp.In,
    )
    for node in tree.find_all(*comparison_types):
        clause = _enclosing_clause(node, exp)
        # ⛔ Attribute a literal ONLY to columns on the OTHER SIDE of the
        # comparison. `find_all` over the whole node walks BOTH operands, so the
        # old code recorded a cross-product: every column in the expression got
        # every literal in it.
        #
        # Measured on Q-026: `ORDER BY (CASE WHEN a.asset_team … THEN 'no_owner'
        # … ELSE 'complete' END = 'complete')` attributed 'no_ticket' — a label
        # from a branch that never tests asset_team — to asset_team, and the gate
        # then asserted the query "returns ZERO rows, permanently". It does not;
        # what actually empties it is an unrelated triage filter.
        #
        # ⚠️ This subsumes the narrower "THEN/ELSE values are not comparison
        # literals" rule: a THEN label is on the same side as its own column, so
        # side-awareness excludes it without special-casing CASE at all.
        sides = _comparison_sides(node, exp)
        if sides is None:
            # Not a two-sided comparison we can split (e.g. IN with a subquery).
            # Fall back to the old whole-node behaviour rather than lose the check.
            cols = list(node.find_all(exp.Column))
            lits = _literal_values(node, exp)
            if not cols or not lits:
                continue
            for c in cols:
                record(c, clause, literals=lits)
            continue
        for own, other in ((sides[0], sides[1]), (sides[1], sides[0])):
            cols = [c for part in own for c in part.find_all(exp.Column)]
            lits: Set[str] = set()
            for part in other:
                lits |= _literal_values(part, exp)
            if not cols or not lits:
                continue
            for c in cols:
                record(c, clause, literals=lits)

    # ── Structural clauses ───────────────────────────────────────────────────
    for group in tree.find_all(exp.Group):
        for c in group.find_all(exp.Column):
            record(c, "group_by")
    for order in tree.find_all(exp.Order):
        for c in order.find_all(exp.Column):
            record(c, "order_by")
    for join in tree.find_all(exp.Join):
        for c in join.find_all(exp.Column):
            record(c, "join")
    for where in tree.find_all(exp.Where):
        for c in where.find_all(exp.Column):
            record(c, "where")
    for having in tree.find_all(exp.Having):
        for c in having.find_all(exp.Column):
            record(c, "having")
    for case in tree.find_all(exp.Case):
        # A CASE inside a deciding clause already recorded above; a CASE in the
        # SELECT list is recorded as `case` so a CONSTANT input is still warned
        # about — a CASE arm that can never be taken is the MASKED failure the
        # skill ranks above BLOCKED.
        for c in case.find_all(exp.Column):
            record(c, "case")

    # ── Aggregates — cardinality is enough ───────────────────────────────────
    for agg in tree.find_all(exp.AggFunc):
        for c in agg.find_all(exp.Column):
            record(c, "aggregate")

    # ── Bare projections — existence only ────────────────────────────────────
    for select in tree.find_all(exp.Select):
        for projection in select.expressions:
            for c in projection.find_all(exp.Column):
                record(c, "select")

    return route


def _enclosing_clause(node, exp) -> str:
    """Name the clause a node sits in — the deciding/projection distinction."""
    parent = node.parent
    while parent is not None:
        if isinstance(parent, exp.Where):
            return "where"
        if isinstance(parent, exp.Join):
            return "join"
        if isinstance(parent, exp.Having):
            return "having"
        if isinstance(parent, exp.Group):
            return "group_by"
        if isinstance(parent, exp.Order):
            return "order_by"
        if isinstance(parent, exp.Case):
            return "case"
        parent = parent.parent
    return "select"


# ── Constant-column warnings ─────────────────────────────────────────────────


@dataclass
class ConstantWarning:
    """A CONSTANT or EMPTY column used in a deciding position.

    ⚠️ `kind` distinguishes the two, because they are different facts with
    different fixes and they must not be reported in the same words:

      * `"constant"` — the column holds exactly one value. A predicate on any
        other value returns zero rows, permanently.
      * `"empty"` — NOTHING has ever filled the column on this tenant. The SQL is
        valid; it simply cannot discriminate on it, and any `COALESCE(col, 0)`
        over it turns *never measured* into *measured zero*.
    """

    column: str
    value: str
    clauses: List[str]
    predicate_literals: List[str]
    predicate_matches_value: Optional[bool]
    kind: str = "constant"

    def render(self) -> str:
        """The user-facing warning. ⛔ It MUST name the value (S6 § 4 rule 3).

        *"only ever `False`"* is actionable; *"low cardinality"* is not.

        ⛔ It must NOT assert a consequence it cannot know. The old text said
        *"this returns ZERO rows, permanently"* on any non-matching predicate —
        true for a filter, FALSE for a projection, and measured wrong on Q-026
        where the CASE was a classifier that changed no membership at all. State
        the observation; let the reader draw the conclusion.
        """
        where = ", ".join(sorted(self.clauses))
        if self.kind == "empty":
            return (
                f"{self.column} is EMPTY — nothing has ever filled it on this "
                f"tenant — and this query uses it in {where}. The SQL is valid "
                f"but cannot discriminate on it. ⚠️ Check for COALESCE over it: "
                f"substituting a default turns 'never measured' into a measured "
                f"value and reports it as a fact."
            )
        base = (
            f"{self.column} holds only ever {self.value} — and this query uses it "
            f"in {where}."
        )
        decides = bool(set(self.clauses) & {"where", "join", "having"})
        if self.predicate_literals and self.predicate_matches_value is False:
            lits = ", ".join(repr(v) for v in sorted(self.predicate_literals))
            tail = (" — this returns ZERO rows, permanently."
                    if decides else
                    " — so that comparison is never true. This is a projection, "
                    "so it changes labels, not membership.")
            return (
                f"{base} The predicate compares it to {lits}, which the column "
                f"has never held{tail}"
            )
        if decides:
            return (
                f"{base} Any predicate on a value other than {self.value} returns "
                f"zero rows, permanently."
            )
        return (
            f"{base} It cannot distinguish between rows here."
        )


def _norm(value) -> str:
    return str(value).strip().strip("'\"").lower()


def constant_warnings(
    route: ShapeRoute,
    shapes: Dict[str, dict],
) -> List[ConstantWarning]:
    """Warn for every CONSTANT column the query DECIDES on.

    `shapes` maps `table.column` -> the supply API's `column_shape` /
    `column_values` payload. Shape verdicts are read from the payload and never
    cached (S6 § 6): a shape is a property of a DATASET AT A MOMENT, and can flip
    between CONSTANT and ENUM on one row.

    ⛔ Three rules from S6 § 4, all enforced here:
      1. ENUM is not CONSTANT — a skewed enum returns FEW rows, not zero.
      2. A CONSTANT column that is only SELECTed is fine — no warning.
      3. The warning names the value.
    """
    out: List[ConstantWarning] = []
    for ref, usage in sorted(route.usages.items()):
        payload = shapes.get(ref)
        if not payload:
            continue
        shape = str(payload.get("shape") or "").lower()

        # ⛔ EMPTY is checked BEFORE the `constant` test, and it is not a shape
        # value — `_render_shape()` derives it from `rows_with_a_value == 0` and
        # OVERRIDES whatever `shape` holds. So the SAME payload (shape="constant",
        # filled=0) rendered EMPTY in `generated_against` while warning NOTHING
        # here: one concept, two readers that disagreed.
        #
        # Measured on Q-079: `vulnerability_resolution_date` is EMPTY(0) and is a
        # LEFT JOIN's closing condition, so nothing ever left the campaign and a
        # burndown could only rise (0 of 90 day-transitions decreased) while the
        # gate reported ✅.
        # ⚠️ TWO independent signals, and BOTH are needed. `rows_with_a_value == 0`
        # is what `_render_shape()` keys on — but the supply API omits that field
        # entirely for a NEEDS_CALLER column ("fill is only measured for columns
        # an integration writes"), and reports `shape: "empty"` instead. Measured
        # on Q-026: is_confirmed / is_verified / is_triaged are all EMPTY and all
        # in the WHERE clause — the columns that ACTUALLY empty that query — and
        # keying on fill alone reported none of them.
        filled = payload.get("rows_with_a_value")
        if shape == "empty" or (isinstance(filled, int) and filled == 0):
            # Rule 2 applies identically: a projection cannot be broken by this.
            if not usage.warn_on_constant:
                continue
            out.append(ConstantWarning(
                column=ref,
                value="EMPTY",
                clauses=sorted(usage.clauses & DECIDING_CLAUSES),
                predicate_literals=sorted(usage.literals),
                predicate_matches_value=None,
                kind="empty",
            ))
            continue

        # Rule 1 — ONLY `constant`. A heavily-skewed ENUM is explicitly not this.
        if shape != "constant":
            continue
        # Rule 2 — only deciding positions.
        if not usage.warn_on_constant:
            continue
        value = _sole_value(payload)
        if value is None:
            continue
        matches: Optional[bool] = None
        if usage.literals:
            matches = any(_norm(v) == _norm(value) for v in usage.literals)
        elif usage.clauses & {"where", "join", "having"} and not (
            usage.clauses & {"group_by", "order_by"}
        ):
            # ⛔ FALSE ALARM GUARD, and the case that forced it: a filter with no
            # literal to compare against — `WHERE is_deleted IS NOT TRUE`. On a
            # False-only column that predicate correctly matches EVERY live row.
            # Measured: without this guard the gate warned on `is_deleted`, which
            # appears in nearly every real WHERE clause on this platform — and a
            # warning that fires on correct, idiomatic SQL is precisely how a
            # reader learns to ignore the one that matters (the
            # `is_false_positive = true` warning printed right beside it).
            #
            # ⚠️ GROUP BY / ORDER BY are deliberately NOT exempted: bucketing by a
            # constant is one bucket forever regardless of any literal.
            continue
        out.append(ConstantWarning(
            column=ref,
            value=value,
            clauses=sorted(usage.clauses & DECIDING_CLAUSES),
            predicate_literals=sorted(usage.literals),
            predicate_matches_value=matches,
        ))
    return out


def _sole_value(payload: dict) -> Optional[str]:
    """The single non-null value a CONSTANT column holds, as a display string.

    ⚠️ Reads the Tier 2 `values` list, which the supply API returns ONLY under
    `values=true`. Under `shape=true` alone the shape is known but the value is
    not — so a CONSTANT column routed to `--shape` yields no nameable value, and
    S6 § 4 rule 3 ("name the value") is why a predicated column is routed to
    `--values` in the first place.
    """
    for v in payload.get("values") or []:
        raw = v.get("value") if isinstance(v, dict) else v
        if raw is None:
            continue
        text = str(raw)
        if text.lower() in {"(null)", "null", "none"}:
            continue
        return text
    return None


# ── generated_against — the shape signature ──────────────────────────────────


def shape_signature(shapes: Dict[str, dict]) -> Dict[str, str]:
    """Build the `generated_against` signature (ARTIFACT_INTENT_SPEC.md § 4.1).

        {"severity": "ENUM(4)", "is_false_positive": "CONSTANT(False)",
         "epss_score": "EMPTY"}

    ⛔ CANDIDATE columns, not only REFERENCED ones. Pass the whole candidate set:
    a column the SQL does NOT use *because it was empty* is exactly the one whose
    becoming populated should trigger a regeneration. Recording only referenced
    columns makes the opportunity case undetectable.

    ⚠️ Written at generation time because it is recoverable later only by
    regenerating everything once (ARTIFACT_INTENT_SPEC.md § 5).
    """
    sig: Dict[str, str] = {}
    for ref, payload in sorted((shapes or {}).items()):
        sig[ref] = _render_shape(payload)
    return sig


def _render_shape(payload: dict) -> str:
    """Render one column's signature entry from the supply API payload.

    ⚠️ Keys are the LIVE contract measured against the running service, not a
    guess: Tier 2 (`column_values`) carries `distinct` + `values`; Tier 1
    (`column_shape`) carries `n_distinct_estimate`; fill carries
    `rows_with_a_value`. A `known: false` Tier 2 payload (a high-cardinality
    column that is "not a vocabulary") still carries its Tier 1 estimate.
    """
    if not payload:
        return "UNKNOWN"
    if payload.get("known") is False and "shape" not in payload:
        return "UNKNOWN"
    shape = str(payload.get("shape") or "unknown").upper()

    # EMPTY outranks the shape name: a column nothing has filled is the case
    # ARTIFACT_INTENT_SPEC.md § 4.1 most wants recorded, because it is the one
    # whose becoming populated should trigger a regeneration.
    filled = payload.get("rows_with_a_value")
    if isinstance(filled, int) and filled == 0:
        return "EMPTY"

    distinct = payload.get("distinct")
    if distinct is None:
        distinct = payload.get("n_distinct_estimate")

    if shape == "CONSTANT":
        value = _sole_value(payload)
        return f"CONSTANT({value})" if value is not None else "CONSTANT"
    if distinct is not None:
        try:
            return f"{shape}({int(float(distinct))})"
        except (TypeError, ValueError):
            return shape
    return shape


def shapes_from_diagnosis(payload: dict) -> Dict[str, dict]:
    """Flatten a `datalake/supply/diagnosis` response into `table.column -> shape`.

    The API returns THREE keys per column, one per depth
    (`SCHEMA_CONVERGENCE.md` § 2.2): `column_shape` (Tier 1, present under shape
    OR values), `observed_fill` (present under fill OR values), `column_values`
    (values only). This merges them into the one dict `constant_warnings()` and
    `shape_signature()` read, preferring the deepest tier that is `known`.

    ⛔ One adapter, in shared — so both harnesses read the payload identically.
    """
    out: Dict[str, dict] = {}
    for col in (payload or {}).get("columns", []) or []:
        table = str(col.get("table") or "").lower()
        name = str(col.get("column") or "").lower()
        if not table or not name:
            continue
        merged: Dict[str, object] = {}
        tier1 = col.get("column_shape")
        if isinstance(tier1, dict):
            merged.update(tier1)
        fill = col.get("observed_fill")
        if isinstance(fill, dict):
            # Only the fill count — do NOT let it overwrite `known`/`shape`.
            if "rows_with_a_value" in fill:
                merged["rows_with_a_value"] = fill["rows_with_a_value"]
        tier2 = col.get("column_values")
        if isinstance(tier2, dict) and tier2.get("known"):
            merged.update(tier2)
        if merged:
            out[f"{table}.{name}"] = merged
    return out


__all__ = [
    "DEPTH_FILL",
    "DEPTH_SHAPE",
    "DEPTH_VALUES",
    "DECIDING_CLAUSES",
    "ColumnUsage",
    "ShapeRoute",
    "ConstantWarning",
    "route_sql",
    "constant_warnings",
    "shape_signature",
    "shapes_from_diagnosis",
]
