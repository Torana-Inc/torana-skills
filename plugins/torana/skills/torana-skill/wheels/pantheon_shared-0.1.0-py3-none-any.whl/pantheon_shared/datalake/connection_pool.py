"""
Connection pooling for datalake backends.

This module provides connection pooling functionality to reuse connections
across requests, reducing connection overhead.

Key features:
- Thread-safe connection pool
- Automatic connection validation
- Idle connection cleanup
- Configurable pool size limits
"""

import time
import threading
from typing import Optional, Callable, Any, List
from collections import deque
from datetime import datetime, UTC

from .types import ConnectionConfig
from .exceptions import DatalakeError


class PoolExhaustedError(DatalakeError):
    """Raised when connection pool has no available connections.

    This occurs when all connections are in use and the pool has
    reached its maximum size limit.

    Attributes:
        message: Error message.
        pool_size: Current pool size.
        max_connections: Maximum allowed connections.
        active_count: Number of active connections.
    """

    def __init__(
        self,
        message: str,
        pool_size: int,
        max_connections: int,
        active_count: int
    ):
        super().__init__(message)
        self.pool_size = pool_size
        self.max_connections = max_connections
        self.active_count = active_count


class PoolClosedError(DatalakeError):
    """Raised when attempting to use a closed connection pool.

    Attributes:
        message: Error message.
    """

    def __init__(self, message: str = "Connection pool is closed"):
        super().__init__(message)


class PooledConnection:
    """
    Wrapper for a pooled connection that returns it to the pool when closed.

    This wrapper delegates all attribute/method access to the underlying
    connection and ensures it's returned to the pool when done.

    Example:
        conn = pool.get_connection()
        result = conn.execute("SELECT * FROM test")
        conn.close()  # Returns to pool automatically

        # Or use as context manager
        with pool.get_connection() as conn:
            result = conn.execute("SELECT * FROM test")
    """

    def __init__(self, connection: Any, pool: 'ConnectionPool'):
        """
        Initialize pooled connection wrapper.

        Args:
            connection: Underlying database connection.
            pool: Connection pool to return to.
        """
        object.__setattr__(self, '_connection', connection)
        object.__setattr__(self, '_pool', pool)

    @property
    def connection(self) -> Any:
        """Get the underlying connection."""
        return self._connection

    @property
    def pool(self) -> 'ConnectionPool':
        """Get the connection pool."""
        return self._pool

    def __getattr__(self, name: str) -> Any:
        """Delegate attribute access to underlying connection."""
        return getattr(self._connection, name)

    def close(self) -> None:
        """Return connection to pool instead of closing it."""
        self._pool.return_connection(self._connection)

    def __enter__(self) -> Any:
        """Context manager entry."""
        return self._connection

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit - return connection to pool."""
        self.close()


class _PooledConnectionInfo:
    """
    Metadata for a pooled connection.

    Tracks when a connection was created and last used to manage
    idle timeout cleanup.
    """

    def __init__(self, connection: Any):
        """
        Initialize pooled connection info.

        Args:
            connection: The database connection.
        """
        self.connection = connection
        self.created_at = datetime.now(UTC)
        self.last_used = datetime.now(UTC)
        self.in_use = False

    def mark_used(self) -> None:
        """Mark connection as in use."""
        self.in_use = True
        self.last_used = datetime.now(UTC)

    def mark_idle(self) -> None:
        """Mark connection as idle (available for reuse)."""
        self.in_use = False
        self.last_used = datetime.now(UTC)

    def is_expired(self, timeout_seconds: int) -> bool:
        """
        Check if connection has been idle longer than timeout.

        Args:
            timeout_seconds: Idle timeout in seconds.

        Returns:
            True if connection is expired.
        """
        idle_time = (datetime.now(UTC) - self.last_used).total_seconds()
        return idle_time > timeout_seconds


class ConnectionPool:
    """
    Thread-safe connection pool for database connections.

    Manages a pool of reusable connections to reduce connection
    overhead. Connections are created on demand up to pool_size,
    and can grow to max_connections under load.

    Example:
        factory = lambda: psycopg2.connect(conn_string)
        config = ConnectionConfig(...)
        pool = ConnectionPool(factory, config, pool_size=5)

        # Get connection
        conn = pool.get_connection()
        try:
            result = conn.execute("SELECT * FROM test")
        finally:
            conn.close()

        # Or use context manager
        with pool.get_connection() as conn:
            result = conn.execute("SELECT * FROM test")

        # Close pool when done
        pool.close()
    """

    def __init__(
        self,
        connection_factory: Callable[[], Any],
        config: ConnectionConfig,
        pool_size: int = 5,
        max_connections: Optional[int] = None,
        idle_timeout: int = 300
    ):
        """
        Initialize connection pool.

        Args:
            connection_factory: Callable that creates new connections.
            config: Connection configuration.
            pool_size: Target pool size (number of idle connections to maintain).
            max_connections: Maximum connections allowed (defaults to pool_size * 2).
            idle_timeout: Seconds before idle connections are eligible for cleanup.
        """
        self._factory = connection_factory
        self._config = config
        self._pool_size = pool_size
        self._max_connections = max_connections if max_connections is not None else pool_size
        self._idle_timeout = idle_timeout

        # Thread-safe storage for connections
        self._lock = threading.RLock()
        self._connections: deque[_PooledConnectionInfo] = deque()
        self._is_closed = False

    @property
    def pool_size(self) -> int:
        """Target pool size."""
        return self._pool_size

    @property
    def max_connections(self) -> int:
        """Maximum allowed connections."""
        return self._max_connections

    @property
    def idle_timeout(self) -> int:
        """Idle timeout in seconds."""
        return self._idle_timeout

    @property
    def is_closed(self) -> bool:
        """Check if pool is closed."""
        return self._is_closed

    @property
    def current_size(self) -> int:
        """Current number of connections in pool."""
        with self._lock:
            return len(self._connections)

    @property
    def idle_count(self) -> int:
        """Number of idle (available) connections."""
        with self._lock:
            return sum(1 for c in self._connections if not c.in_use)

    @property
    def active_count(self) -> int:
        """Number of active (in-use) connections."""
        with self._lock:
            return sum(1 for c in self._connections if c.in_use)

    def get_connection(self) -> PooledConnection:
        """
        Get a connection from the pool.

        Creates a new connection if no idle connections are available,
        up to the max_connections limit.

        Returns:
            PooledConnection wrapper.

        Raises:
            PoolClosedError: If pool is closed.
            PoolExhaustedError: If pool is at maximum capacity.
        """
        with self._lock:
            if self._is_closed:
                raise PoolClosedError()

            # Clean up expired idle connections
            self._cleanup_expired()

            # Try to get idle connection
            for conn_info in self._connections:
                if not conn_info.in_use:
                    if self._is_valid(conn_info.connection):
                        conn_info.mark_used()
                        return PooledConnection(conn_info.connection, self)
                    else:
                        # Invalid connection, remove it
                        self._connections.remove(conn_info)

            # No idle connections available
            # Check if we can create a new one
            if len(self._connections) >= self._max_connections:
                raise PoolExhaustedError(
                    f"Connection pool exhausted: {len(self._connections)} active "
                    f"(max: {self._max_connections})",
                    pool_size=len(self._connections),
                    max_connections=self._max_connections,
                    active_count=self.active_count
                )

            # Create new connection
            new_conn = self._factory()
            conn_info = _PooledConnectionInfo(new_conn)
            conn_info.mark_used()
            self._connections.append(conn_info)

            return PooledConnection(new_conn, self)

    def return_connection(self, connection: Any) -> None:
        """
        Return a connection to the pool.

        Args:
            connection: The connection to return.
        """
        with self._lock:
            if self._is_closed:
                # Pool is closed, just close the connection
                self._close_connection(connection)
                return

            # Find the connection in our pool
            for conn_info in self._connections:
                if conn_info.connection is connection:
                    # Check if connection is still valid
                    if not self._is_valid(connection):
                        # Invalid connection, remove and close it
                        self._connections.remove(conn_info)
                        self._close_connection(connection)
                    elif len(self._connections) > self._pool_size:
                        # Pool is over capacity, close excess connection
                        self._connections.remove(conn_info)
                        self._close_connection(connection)
                    else:
                        # Mark as idle for reuse
                        conn_info.mark_idle()
                    return

            # Connection not found in pool (was it created beyond pool_size?)
            # Just close it
            self._close_connection(connection)

    def close(self) -> None:
        """Close all connections in the pool and shut it down."""
        with self._lock:
            if self._is_closed:
                return

            self._is_closed = True

            # Close all connections
            for conn_info in self._connections:
                self._close_connection(conn_info.connection)

            self._connections.clear()

    def _is_valid(self, connection: Any) -> bool:
        """
        Check if a connection is valid and can be reused.

        Args:
            connection: The connection to validate.

        Returns:
            True if connection is valid.
        """
        try:
            # Try calling is_valid() if connection has it
            if hasattr(connection, 'is_valid'):
                return connection.is_valid()

            # Try a simple ping (e.g., SELECT 1)
            if hasattr(connection, 'execute'):
                connection.execute("SELECT 1")
                return True

            # Assume valid if no validation method available
            return True
        except Exception:
            return False

    def _close_connection(self, connection: Any) -> None:
        """
        Close a single connection.

        Args:
            connection: The connection to close.
        """
        try:
            if hasattr(connection, 'close'):
                connection.close()
        except Exception:
            pass  # Ignore errors during close

    def _cleanup_expired(self) -> None:
        """Remove expired idle connections from the pool."""
        now = datetime.now(UTC)

        # Find expired connections
        expired = [
            conn_info
            for conn_info in self._connections
            if not conn_info.in_use and conn_info.is_expired(self._idle_timeout)
        ]

        # Remove and close expired connections
        for conn_info in expired:
            self._connections.remove(conn_info)
            self._close_connection(conn_info.connection)

    def __repr__(self) -> str:
        """String representation."""
        with self._lock:
            return (
                f"ConnectionPool(active={self.active_count}, "
                f"idle={self.idle_count}, total={len(self._connections)}/{self._pool_size})"
            )
