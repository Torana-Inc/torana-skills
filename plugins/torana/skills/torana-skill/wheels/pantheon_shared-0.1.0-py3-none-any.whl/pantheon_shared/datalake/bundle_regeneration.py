"""The bundle REGENERATION PLAN — what a shape break requires, per artifact (S21 / row 51).

⛔ WHAT THIS MODULE IS, AND THE ONE THING IT REFUSES TO DO
----------------------------------------------------------
It PLANS a regeneration. It does not author SQL, and it never will — SQL authorship
belongs to `torana-text-to-sql` (S18), at PLATFORM scope, because a bundle installs into
many tenants and a tenant-scope answer condemns columns that are fine the moment an
integration connects.

So the output of this module is a `RegenerationPlan`: for each broken artifact, the
INTENT to regenerate from, the columns that broke, and a verdict saying whether a
regeneration is possible at all. A skill (or a human) turns that into SQL. Keeping the
authorship out means this module has no opinion that can rot when the schema moves.

⛔ REGENERATE FROM THE INTENT, NEVER FROM THE BROKEN SQL
--------------------------------------------------------
This is S20's rule and the heart of the row. `artifact_intent.py` states it in the
negative — "SQL records WHAT a query does and never WHY, so it cannot be regenerated
from itself; you would get the same SQL back." The positive form is the contract here:
`RegenerationTask.intent` is the input a generator reads, and the old SQL is carried
ONLY as `previous_sql`, for a human diff. ⚠️ A generator that reads `previous_sql` and
patches it preserves an approach the schema may no longer support — which is precisely
the failure the intent exists to prevent.

⭐ ORIGINS vs INHERITORS — the structural finding of this row
-------------------------------------------------------------
A shape break names the artifact that reads the SINK COLUMN. But bundle artifacts read
each other: a transformer reads `vulnerabilities`, and nine further artifacts read
THAT transformer. Regenerating an inheritor is not merely wasteful, it is WRONG — the
inheritor reads a bundle relation, not a sink table, so "fixing" it in place papers over
the origin while the origin keeps producing the broken column.

⛔ AND INHERITANCE IS TRANSITIVE, which the obvious two-level model misses. Measured
2026-08-10 on `remediation_ops.is_patch_available` (§ 7.3 of the brief records the
correction):

    remediation_base            ORIGIN    reads assets/repositories/vulnerabilities
      ├── aging_open_findings   depth 1   reads remediation_base
      │     ├── dash_hygiene_cleanup   depth 2   reads aging_open_findings
      │     └── rule_aging_tail        depth 2   reads aging_open_findings
      ├── team_overdue_detail   depth 1
      │     └── dash_team_backlog      depth 2
      └── … six more at depth 1

A depth-1-only walk finds 9 of the 11 inheritors and silently omits three artifacts that
a human would then have to notice by hand. `plan_regeneration` walks to a FIXED POINT.

⚠️ WHY A FIXED POINT AND NOT A RECURSION LIMIT. Bundle relation graphs are authored by
hand and nothing structurally forbids a cycle, so the walk is iterative with a `seen`
set rather than recursive — a cycle terminates instead of blowing the stack.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Mapping, Optional, Set, Tuple

from .artifact_intent import Intent, parse_intent, validate_intent
from .bundle_shape_check import ArtifactShapeVerdict, artifact_sql_texts
from .live_shape import SINK_TABLES
from .schema_shape import ShapeBreak

#: ⛔ A regeneration verdict is never a bare bool — the house rule from `IntentVerdict`.
#: These are the four outcomes, and the third is the one that matters most.
#:
#:   `regenerable`   — the intent is sound and the concepts it names still have columns.
#:   `inheritor`     — do NOT regenerate; fix the origin and this follows.
#:   `impossible`    — ⛔ the intent needs a concept NO column can express any more.
#:   `unregenerable` — the intent itself is not regeneration-grade (S20 should have
#:                     caught this at authoring; if it appears, the gate leaked).
VERDICT_REGENERABLE = "regenerable"
VERDICT_INHERITOR = "inheritor"
VERDICT_IMPOSSIBLE = "impossible"
VERDICT_UNREGENERABLE = "unregenerable"


@dataclass
class RegenerationTask:
    """One artifact's regeneration instruction.

    ⚠️ `previous_sql` is present for a HUMAN DIFF and is explicitly NOT the regeneration
    input. See the module docstring — a generator that patches it defeats the row.
    """

    artifact_key: str
    link_id: str
    artifact_type: str
    verdict: str
    intent: Optional[Intent] = None
    intent_problem: str = ""
    breaks: List[ShapeBreak] = field(default_factory=list)
    previous_sql: List[str] = field(default_factory=list)
    #: For an inheritor — the origin artifact(s) whose repair fixes this one.
    inherits_from: List[str] = field(default_factory=list)
    #: For an inheritor — how many relation hops from the origin (1 = direct reader).
    depth: int = 0
    #: For `impossible` — the concept that can no longer be expressed, and why.
    blocked_reason: str = ""

    @property
    def should_regenerate(self) -> bool:
        """⛔ ONLY an origin with a sound intent is regenerated. An inheritor is
        REPORTED. This property is the single place that rule is expressed."""
        return self.verdict == VERDICT_REGENERABLE

    def as_dict(self) -> Dict[str, Any]:
        return {
            "artifact_key": self.artifact_key,
            "link_id": self.link_id,
            "artifact_type": self.artifact_type,
            "verdict": self.verdict,
            "should_regenerate": self.should_regenerate,
            "grain": self.intent.grain if self.intent else "",
            "question": self.intent.question if self.intent else "",
            "intent_problem": self.intent_problem,
            "breaks": [b.as_dict() for b in self.breaks],
            "inherits_from": sorted(self.inherits_from),
            "depth": self.depth,
            "blocked_reason": self.blocked_reason,
        }


@dataclass
class RegenerationPlan:
    """The whole-bundle plan. ⛔ A PROPOSAL, never an application (see § 3.1 decision).

    The plan is inert: it names what must change and what it must preserve. Nothing here
    writes a bundle file. That separation is the safety property — a bundle installs into
    many tenants, so an automatic rewrite ships a wrong answer everywhere at once, while
    a proposal a human ratifies fails safe.
    """

    bundle_id: str
    recorded_revision: str
    live_revision: Optional[str]
    tasks: List[RegenerationTask] = field(default_factory=list)

    @property
    def origins(self) -> List[RegenerationTask]:
        return [t for t in self.tasks if t.verdict == VERDICT_REGENERABLE]

    @property
    def inheritors(self) -> List[RegenerationTask]:
        return [t for t in self.tasks if t.verdict == VERDICT_INHERITOR]

    @property
    def impossible(self) -> List[RegenerationTask]:
        return [t for t in self.tasks
                if t.verdict in (VERDICT_IMPOSSIBLE, VERDICT_UNREGENERABLE)]

    @property
    def possible(self) -> bool:
        """⛔ A plan with ANY impossible task is not a plan — it is a refusal.

        § 3.4: a silent PARTIAL regeneration is the worst outcome, because the bundle
        then installs while some artifact quietly answers a different question. So the
        whole plan fails when any single artifact cannot be regenerated."""
        return bool(self.tasks) and not self.impossible

    def summary(self) -> str:
        if not self.tasks:
            return (f"bundle '{self.bundle_id}': nothing to regenerate — no artifact "
                    f"has a shape break.")
        lines = [f"bundle '{self.bundle_id}': regeneration plan — "
                 f"{len(self.origins)} origin(s) to regenerate, "
                 f"{len(self.inheritors)} inheritor(s) that follow, "
                 f"{len(self.impossible)} blocked."]
        for t in self.origins:
            cols = ", ".join(f"{b.table}.{b.column}" for b in t.breaks)
            lines.append(f"  ⭐ REGENERATE '{t.artifact_key}' ({t.artifact_type}, "
                         f"link {t.link_id}) — broke on: {cols}")
            lines.append(f"      grain to preserve: {t.intent.grain if t.intent else '?'}")
        for t in self.inheritors:
            lines.append(f"  ↳ INHERITS (do NOT rewrite) '{t.artifact_key}' "
                         f"(depth {t.depth}, via {', '.join(sorted(t.inherits_from))})")
        for t in self.impossible:
            lines.append(f"  ⛔ CANNOT REGENERATE '{t.artifact_key}' — {t.blocked_reason}")
        return "\n".join(lines)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "bundle_id": self.bundle_id,
            "recorded_revision": self.recorded_revision,
            "live_revision": self.live_revision,
            "possible": self.possible,
            "origins": [t.as_dict() for t in self.origins],
            "inheritors": [t.as_dict() for t in self.inheritors],
            "impossible": [t.as_dict() for t in self.impossible],
            "summary": self.summary(),
        }


def _relation_names(links: Iterable[Any]) -> Dict[str, Tuple[str, str, str]]:
    """`artifact_key -> (link_id, artifact_type, relation_name)` for every artifact.

    ⚠️ The relation an artifact PRODUCES is what downstream artifacts read by name. For
    a transformer that is its output relation; for everything else the artifact key is
    used, which is harmless because nothing reads a dashboard.
    """
    out: Dict[str, Tuple[str, str, str]] = {}
    for ln in links:
        link_id = getattr(ln, "link_id", None) or (
            ln.get("link_id") if isinstance(ln, dict) else "") or ""
        artifacts = getattr(ln, "artifacts", None) or (
            ln.get("artifacts") if isinstance(ln, dict) else []) or []
        for a in artifacts:
            key = str(a.get("artifact_key") or "")
            if not key:
                continue
            d = a.get("definition") or {}
            relation = str(d.get("relation_name") or d.get("output_relation") or key)
            out[key] = (str(link_id), str(a.get("artifact_type") or ""), relation.lower())
    return out


def _reads_relation(artifact: Mapping[str, Any], relation: str) -> bool:
    """Does this artifact's SQL read `relation`? Word-boundary match on every statement."""
    import re
    pat = re.compile(rf"\b{re.escape(relation)}\b", re.IGNORECASE)
    return any(pat.search(s) for s in artifact_sql_texts(artifact))


def _names_any_column(artifact: Mapping[str, Any], columns: Set[str]) -> bool:
    """Does this artifact's SQL name any of `columns`? Word-boundary, case-insensitive.

    ⚠️ Bare column names, deliberately: a downstream artifact reads the column from a
    bundle RELATION, so it is never table-qualified with the sink table it came from.
    """
    import re
    if not columns:
        return False
    pat = re.compile(r"\b(" + "|".join(re.escape(c) for c in sorted(columns)) + r")\b",
                     re.IGNORECASE)
    return any(pat.search(s) for s in artifact_sql_texts(artifact))


def classify_origins(
    broken: Iterable[ArtifactShapeVerdict],
    links: Iterable[Any],
    *,
    affected_columns: Optional[Iterable[str]] = None,
) -> Tuple[Set[str], Dict[str, Tuple[Set[str], int]]]:
    """Split broken artifacts into ORIGINS and INHERITORS. See the module docstring.

    Returns `(origin_keys, {inheritor_key: (origin_keys_it_descends_from, depth)})`.

    ⛔ An ORIGIN is an artifact that reads a SINK TABLE. That is the definition, and it
    is not a heuristic: the sink tables are the only population carrying a reachability
    claim, so they are the only place a schema change can originate. Everything else an
    artifact reads is a relation the bundle itself builds.

    ⚠️ THE WALK IS TO A FIXED POINT, not depth-1 — see the module docstring for the
    measured case where depth-1 misses three artifacts.

    ⛔ `affected_columns` NARROWS THE CLOSURE, and leaving it out OVERSTATES the blast
    radius. Measured 2026-08-10 on `remediation_ops` with `is_patch_available` removed:
    **21** artifacts descend from `remediation_base` by relation, but only **11** name
    the broken column. The other 10 read the same relation for unrelated columns and are
    entirely unaffected. Reporting all 21 would tell an operator to inspect ten artifacts
    that nothing touched — and a report that cries wolf gets routed around rather than
    obeyed (the S17 § 7A lesson, restated by the shape check's own docstring).

    ⚠️ A DESCENDANT THAT DOES NOT NAME THE COLUMN IS STILL A DESCENDANT — it is dropped
    from the AFFECTED set, not from the graph, so a column that reappears downstream
    under an alias is still reached through its parent on the next hop.
    """
    links = list(links)
    meta = _relation_names(links)
    all_artifacts: List[Tuple[str, Mapping[str, Any]]] = []
    for ln in links:
        artifacts = getattr(ln, "artifacts", None) or (
            ln.get("artifacts") if isinstance(ln, dict) else []) or []
        for a in artifacts:
            all_artifacts.append((str(a.get("artifact_key") or ""), a))

    sinks = {t.lower() for t in SINK_TABLES}
    broken_keys = {v.artifact_key for v in broken}

    # An origin reads at least one sink table. `tables_read` on the verdict is already
    # restricted to sink tables by `check_bundle_shape`, so its non-emptiness IS the test.
    origins: Set[str] = set()
    for v in broken:
        if {t.lower() for t in v.tables_read} & sinks:
            origins.add(v.artifact_key)

    # ⭐ Fixed-point closure: anything reading a relation produced by a member of the
    # frontier joins the frontier, until nothing new is added.
    cols = {str(c).lower() for c in (affected_columns or ())}
    inheritors: Dict[str, Tuple[Set[str], int]] = {}
    frontier = set(origins)
    seen = set(origins)
    depth = 0
    while frontier:
        depth += 1
        relations = {meta[k][2] for k in frontier if k in meta}
        next_frontier: Set[str] = set()
        for key, artifact in all_artifacts:
            if not key or key in seen:
                continue
            hit = {r for r in relations if _reads_relation(artifact, r)}
            if not hit:
                continue
            parents = {k for k in frontier if k in meta and meta[k][2] in hit}
            # ⛔ Reached by relation, but AFFECTED only if it names a broken column.
            # See the docstring: 21 reached vs 11 affected on the measured case.
            if not cols or _names_any_column(artifact, cols):
                inheritors[key] = (parents, depth)
            next_frontier.add(key)
        seen |= next_frontier
        frontier = next_frontier

    # ⚠️ An artifact flagged broken that is NOT an origin and NOT reachable from one is
    # left to the caller as an origin-by-default: it broke on something, and calling it
    # an inheritor of nothing would silently drop it from the plan.
    for key in broken_keys - origins - set(inheritors):
        origins.add(key)

    return origins, inheritors


def plan_regeneration(
    *,
    bundle_id: str,
    recorded_revision: str,
    live_revision: Optional[str],
    links: Iterable[Any],
    broken: Iterable[ArtifactShapeVerdict],
    live_shape: Optional[Mapping[Tuple[str, str], str]] = None,
) -> RegenerationPlan:
    """Build the regeneration plan for a bundle whose shape check REFUSED.

    `broken` is `BundleShapeReport.broken`. `live_shape` is optional and is used only to
    answer § 3.4 — whether the concepts an intent names can still be expressed at all.
    """
    links = list(links)
    broken = list(broken)
    meta = _relation_names(links)
    by_key: Dict[str, Mapping[str, Any]] = {}
    for ln in links:
        artifacts = getattr(ln, "artifacts", None) or (
            ln.get("artifacts") if isinstance(ln, dict) else []) or []
        for a in artifacts:
            by_key[str(a.get("artifact_key") or "")] = a

    # ⛔ The columns that actually broke — used to narrow the inheritor closure from
    # "descends by relation" to "descends AND reads a broken column". See
    # `classify_origins`: 21 vs 11 on the measured case.
    affected = {b.column for v in broken for b in v.breaks}
    origins, inheritors = classify_origins(broken, links, affected_columns=affected)
    verdict_by_key = {v.artifact_key: v for v in broken}

    plan = RegenerationPlan(bundle_id=bundle_id, recorded_revision=recorded_revision,
                            live_revision=live_revision)

    for key in sorted(origins):
        artifact = by_key.get(key) or {}
        link_id, atype, _ = meta.get(key, ("", "", ""))
        verdict = verdict_by_key.get(key)
        breaks = list(verdict.breaks) if verdict else []
        text = artifact.get("semantic_description") or ""
        iv = validate_intent(text, artifact_type=atype)
        task = RegenerationTask(
            artifact_key=key, link_id=link_id, artifact_type=atype,
            verdict=VERDICT_REGENERABLE, intent=parse_intent(text),
            breaks=breaks, previous_sql=artifact_sql_texts(artifact),
        )
        if not iv.ok:
            # ⛔ S20's gate should make this unreachable for a shipped bundle. If it
            # fires, the intent gate leaked — say so rather than regenerating from a
            # description that cannot bind a rule.
            task.verdict = VERDICT_UNREGENERABLE
            task.intent_problem = iv.message()
            task.blocked_reason = (
                f"the artifact's intent is not regeneration-grade ({iv.message()}), so "
                f"there is nothing sound to regenerate FROM. Regenerating from the "
                f"broken SQL instead would preserve an approach the schema no longer "
                f"supports — fix the intent first (S20 § 3.1).")
        else:
            blocked = _blocked_reason(task, live_shape)
            if blocked:
                task.verdict = VERDICT_IMPOSSIBLE
                task.blocked_reason = blocked
        plan.tasks.append(task)

    for key in sorted(inheritors):
        parents, depth = inheritors[key]
        artifact = by_key.get(key) or {}
        link_id, atype, _ = meta.get(key, ("", "", ""))
        verdict = verdict_by_key.get(key)
        plan.tasks.append(RegenerationTask(
            artifact_key=key, link_id=link_id, artifact_type=atype,
            verdict=VERDICT_INHERITOR,
            intent=parse_intent(artifact.get("semantic_description") or ""),
            breaks=list(verdict.breaks) if verdict else [],
            inherits_from=sorted(parents), depth=depth,
        ))
    return plan


@dataclass
class AcceptanceVerdict:
    """Is a regenerated artifact allowed to REPLACE the original? (§ 3.3)

    ⛔ Never a bare bool — the caller needs the reason to act on it.
    """

    ok: bool
    reasons: List[str] = field(default_factory=list)
    grain_before: str = ""
    grain_after: str = ""

    def message(self) -> str:
        return "; ".join(self.reasons) or "accepted"

    def as_dict(self) -> Dict[str, Any]:
        return {"ok": self.ok, "reasons": list(self.reasons),
                "grain_before": self.grain_before, "grain_after": self.grain_after,
                "message": self.message()}


def accept_regenerated(
    *,
    artifact_type: str,
    intent_before: Optional[str],
    intent_after: Optional[str],
    new_sql_reads: Optional[Iterable[Tuple[str, str]]] = None,
    live_shape: Optional[Mapping[Tuple[str, str], str]] = None,
) -> AcceptanceVerdict:
    """⛔ THE GATE a regenerated artifact passes BEFORE it replaces the original (§ 3.3).

    Three checks, and the honest statement of what they do and do not prove:

    1. ⭐ THE GRAIN SURVIVED. `grain_changed` (S12) compares the normalised `grain`.
       § 7.2 of the intent spec: *"a regeneration that produces a different grain is NOT
       APPLIED"* — it is a different artifact, not a better one.

    2. THE NEW INTENT IS ITSELF REGENERATION-GRADE. A regeneration that degrades the
       intent makes the NEXT regeneration impossible, which is how a contract decays one
       acceptable-looking step at a time.

    3. THE NEW SQL READS ONLY LIVE COLUMNS. Regenerating onto a second dead column is
       the obvious failure and is cheap to exclude.

    ⚠️ WHAT THIS DOES NOT PROVE, stated because § 3.3 asks for it explicitly and because
    a gate trusted beyond its reach is worse than none. `grain_signature()` normalises
    WHITESPACE AND CASE ONLY (S12 is emphatic that it must not stem or reorder — that
    would silently permit the grain change § 3.2 forbids). So it catches a grain that was
    REWRITTEN; it cannot detect SQL that keeps the grain sentence while computing
    something semantically different. ⛔ Nothing mechanical can: that is why the § 3.1
    decision makes regeneration a PROPOSAL a human ratifies rather than an automatic
    rewrite. This gate narrows what a human must check; it does not replace them.
    """
    from .artifact_intent import grain_changed

    reasons: List[str] = []
    before = parse_intent(intent_before)
    after = parse_intent(intent_after)

    # ⚠️ A non-row type carries no grain by contract (S20 § 3.1), so comparing grains for
    # one would compare "" to "" and pass vacuously — correct, but say why it is skipped.
    from .artifact_intent import COMPARABLE_PART, required_parts
    grain_applies = COMPARABLE_PART in required_parts(artifact_type)

    if grain_applies and grain_changed(intent_before, intent_after):
        reasons.append(
            f"the GRAIN changed ({before.grain_signature()!r} → "
            f"{after.grain_signature()!r}). A regeneration that changes the grain is a "
            f"DIFFERENT artifact, not a better one (intent spec § 3.2/§ 7.2) — it is not "
            f"applied. Keep the old SQL serving and surface that a different shape is "
            f"available.")

    iv = validate_intent(intent_after, artifact_type=artifact_type)
    if not iv.ok:
        reasons.append(
            f"the regenerated intent is not itself regeneration-grade ({iv.message()}) — "
            f"accepting it would make the NEXT regeneration impossible.")

    if new_sql_reads is not None and live_shape is not None:
        live_tables = {t for t, _ in live_shape}
        dead = sorted({f"{t}.{c}" for t, c in new_sql_reads
                       if t in live_tables and (t, c) not in live_shape})
        if dead:
            reasons.append(
                f"the regenerated SQL reads column(s) that do not exist in the live "
                f"schema: {', '.join(dead)} — it was regenerated onto a dead column.")

    return AcceptanceVerdict(ok=not reasons, reasons=reasons,
                             grain_before=before.grain_signature(),
                             grain_after=after.grain_signature())


def _blocked_reason(task: RegenerationTask, live_shape) -> str:
    """§ 3.4 — can this intent still be expressed, or is regeneration IMPOSSIBLE?

    ⛔ THE HONEST ANSWER IS NARROW, and this is the design decision worth stating. It is
    tempting to ask "does any column still carry this concept?" — but that requires
    understanding the concept, which is exactly what a machine cannot do and why intents
    are prose. Guessing would produce a confident wrong answer in both directions.

    So the test is the one thing that IS decidable: a break of kind `removed` where the
    table itself is GONE leaves nothing to regenerate against — no column of that table
    can be named, whatever the intent says. A removed COLUMN in a surviving table stays
    `regenerable`, because the generator may well express the concept another way, and
    the removed-column archive carries the `semantic_description` that says what the
    column meant when it cannot.

    ⚠️ This deliberately UNDER-claims. A regeneration that then fails to find a column
    fails loudly at authorship (the generator says so) rather than being pre-judged here
    on a guess. An over-claiming check would refuse regenerations that would have worked.
    """
    if live_shape is None:
        return ""
    live_tables = {t for t, _ in live_shape}
    gone = sorted({b.table for b in task.breaks
                   if b.kind == "removed" and b.table not in live_tables})
    if not gone:
        return ""
    return (
        f"the intent requires table(s) {', '.join(gone)}, which no longer exist in the "
        f"live schema — no column of them can be named, whatever the intent says. This "
        f"is NOT regenerable: consult "
        f"`pantheon-datalake/docs/corpus/removed_columns_archive.csv`, which carries the "
        f"`semantic_description` recorded for the removed columns and is the honest "
        f"place to explain why this artifact cannot be rebuilt.")
