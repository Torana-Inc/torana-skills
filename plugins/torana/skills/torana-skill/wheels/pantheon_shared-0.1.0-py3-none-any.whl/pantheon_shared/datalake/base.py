"""
Abstract base class for datalake backends.

This module defines the DatalakeBackend abstract interface that all
backend implementations (DuckDB, Snowflake, PostgreSQL) must follow.
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional

from pantheon_shared.datalake.types import QueryResult, UpsertResult, TableInfo


class DatalakeBackend(ABC):
    """Abstract base class for datalake backend implementations.

    All backend implementations (DuckDB, Snowflake, PostgreSQL) must
    inherit from this class and implement all abstract methods.

    The interface provides a consistent API for:
    - Connection management
    - CRUD operations (create, read, update, delete)
    - Table management
    - Query execution
    - Text-to-SQL (where supported)
    - Health checks

    Multi-tenancy:
    - All methods that accept `tenant_id` parameter must enforce tenant isolation
    - Tenant isolation model varies by backend (files, schemas, row-level filtering)
    """

    @abstractmethod
    def connect(self, tenant_id: Optional[str] = None) -> bool:
        """Establish connection to the backend.

        Args:
            tenant_id: Optional tenant identifier. If provided, may connect to
                tenant-specific database/schema. If None, uses default connection.

        Returns:
            True if connection successful, False otherwise.

        Raises:
            ConnectionError: If connection fails.
        """
        pass

    @abstractmethod
    def disconnect(self) -> None:
        """Close connection and cleanup resources.

        Should close all open connections, clear connection pools,
        and release any held resources.
        """
        pass

    @abstractmethod
    def query(self, sql: str, tenant_id: str, params: Optional[Dict[str, Any]] = None) -> QueryResult:
        """Execute a read-only SQL query.

        Args:
            sql: SQL query string (typically SELECT).
            tenant_id: Tenant identifier for scoping the query.
            params: Optional query parameters for parameterized queries (prevents SQL injection).

        Returns:
            QueryResult with columns, rows, and metadata.

        Raises:
            QueryError: If query execution fails.
            TenantNotFoundError: If tenant database/schema doesn't exist.
            ConnectionError: If database connection fails.
        """
        pass

    @abstractmethod
    def upsert(
        self,
        table: str,
        data: List[Dict[str, Any]],
        primary_key: str,
        tenant_id: str,
        preserve_columns: Optional[List[str]] = None,
    ) -> UpsertResult:
        """Insert or update records (upsert operation).

        For each record:
        - If primary key exists, update the record
        - If primary key doesn't exist, insert the record

        Args:
            table: Table name (without schema prefix).
            data: List of records to upsert (each record is a dict).
            primary_key: Column name used as primary key.
            tenant_id: Tenant identifier for scoping the operation.
            preserve_columns: Columns that, on an UPDATE (conflict), keep their
                existing stored value instead of being overwritten by the
                incoming record. New rows (INSERT) still take the incoming
                value. Used to protect human-owned state (e.g. triage status)
                from being reset by an automated re-ingest.

        Returns:
            UpsertResult with counts of inserted/updated records.

        Raises:
            QueryError: If upsert operation fails.
            TableNotFoundError: If table doesn't exist.
            ValidationError: If data validation fails.
        """
        pass

    @abstractmethod
    def insert(self, table: str, data: List[Dict[str, Any]], tenant_id: str) -> UpsertResult:
        """Bulk insert records into a table.

        Args:
            table: Table name (without schema prefix).
            data: List of records to insert (each record is a dict).
            tenant_id: Tenant identifier for scoping the operation.

        Returns:
            UpsertResult with count of inserted records.

        Raises:
            QueryError: If insert operation fails.
            TableNotFoundError: If table doesn't exist.
            ValidationError: If data validation fails.
        """
        pass

    @abstractmethod
    def create_table(self, table: str, schema: Dict[str, Any], tenant_id: str) -> bool:
        """Create a table with the specified schema.

        Args:
            table: Table name (without schema prefix).
            schema: Dictionary mapping column names to schema definitions.
                Each definition can be:
                - A simple type string: "UUID" (for backwards compatibility)
                - A dict with metadata: {"data_type": "UUID", "primary_key": True, "not_null": False}
                Example: {"id": "UUID", "name": "VARCHAR", "created_at": "TIMESTAMP"}
                Or with metadata: {"id": {"data_type": "UUID", "primary_key": True}}
            tenant_id: Tenant identifier for scoping the operation.

        Returns:
            True if table created successfully, False if table already exists.

        Raises:
            QueryError: If table creation fails.
            ConnectionError: If database connection fails.
        """
        pass

    @abstractmethod
    def drop_table(self, table: str, tenant_id: str) -> bool:
        """Drop a table.

        Args:
            table: Table name (without schema prefix).
            tenant_id: Tenant identifier for scoping the operation.

        Returns:
            True if table dropped successfully, False if table doesn't exist.

        Raises:
            QueryError: If drop operation fails.
        """
        pass

    @abstractmethod
    def table_exists(self, table: str, tenant_id: str) -> bool:
        """Check if a table exists.

        Args:
            table: Table name (without schema prefix).
            tenant_id: Tenant identifier for scoping the check.

        Returns:
            True if table exists, False otherwise.
        """
        pass

    @abstractmethod
    def list_tables(self, tenant_id: str, db_type: Optional[str] = None) -> List[TableInfo]:
        """List all tables accessible to the tenant.

        Args:
            tenant_id: Tenant identifier.
            db_type: Optional database type filter ('source', 'transformers', or 'all').
                - 'source': Returns only source tables
                - 'transformers': Returns only transformer output tables
                - 'all': Returns both source and transformer tables
                - None: Defaults to 'source' for backward compatibility

                For DuckDB: Queries separate database files per type.
                For PostgreSQL: Filters by schema (tenant_xxx_source vs tenant_xxx_transformers).
                For Snowflake: Single shared database (all types return same result).

        Returns:
            List of TableInfo objects with table metadata.

        Raises:
            TenantNotFoundError: If tenant database/schema doesn't exist.
        """
        pass

    @abstractmethod
    def get_table_info(self, table: str, tenant_id: str) -> TableInfo:
        """Get detailed metadata for a specific table.

        Args:
            table: Table name (without schema prefix).
            tenant_id: Tenant identifier.

        Returns:
            TableInfo with schema, row count, column metadata.

        Raises:
            TableNotFoundError: If table doesn't exist.
        """
        pass

    @abstractmethod
    def text_to_sql(
        self,
        query: str,
        tenant_id: str,
        execute: bool = False
    ) -> Dict[str, Any]:
        """Convert natural language query to SQL using LLM.

        This is an optional capability. Backends that don't support it
        should raise NotImplementedError.

        Args:
            query: Natural language query (e.g., "show me all critical vulnerabilities").
            tenant_id: Tenant identifier for scoping.
            execute: If True, execute the generated SQL and include results.

        Returns:
            Dictionary with keys:
                - 'sql': Generated SQL query string.
                - 'result': QueryResult if execute=True, None otherwise.
                - 'model': LLM model used for generation.

        Raises:
            NotImplementedError: If backend doesn't support text-to-SQL.
            QueryError: If SQL generation or execution fails.
        """
        pass

    @abstractmethod
    def health_check(self) -> bool:
        """Check if backend is healthy and connections are working.

        Should verify:
        - Connection can be established
        - Simple query can be executed (e.g., SELECT 1)
        - Connection pool is operational (if using pooling)

        Returns:
            True if backend is healthy, False otherwise.
        """
        pass

    @classmethod
    @abstractmethod
    def from_env(cls) -> 'DatalakeBackend':
        """Create backend instance from environment variables.

        Each backend implementation reads its specific environment variables:

        DuckDB:
            - DATALAKE_BACKEND='duckdb'
            - DUCKDB_PATH (default: '/app/data')
            - DUCKDB_READ_ONLY (default: 'false')

        PostgreSQL:
            - DATALAKE_BACKEND='postgres'
            - POSTGRES_HOST (default: 'localhost')
            - POSTGRES_PORT (default: 5432)
            - POSTGRES_DATABASE (default: 'torana_datalake')
            - POSTGRES_USER (default: 'postgres')
            - POSTGRES_PASSWORD (required)
            - POSTGRES_POOL_SIZE (default: 10)

        Snowflake:
            - DATALAKE_BACKEND='snowflake'
            - SNOWFLAKE_ACCOUNT (required)
            - SNOWFLAKE_USER (required)
            - SNOWFLAKE_PASSWORD (required)
            - SNOWFLAKE_WAREHOUSE (required)
            - SNOWFLAKE_DATABASE (required)
            - SNOWFLAKE_SCHEMA (default: 'PUBLIC')

        Returns:
            Backend instance configured from environment variables.

        Raises:
            ConfigurationError: If required environment variables are missing.
        """
        pass

    # Optional capability methods (backends may or may not implement)

    def create_schema(self, schema_name: str, tenant_id: Optional[str] = None) -> bool:
        """Create a database schema (optional capability).

        Default implementation raises NotImplementedError.
        Backends that support schemas (PostgreSQL, Snowflake) should override.

        Args:
            schema_name: Schema name to create.
            tenant_id: Optional tenant identifier (for tenant-scoped schemas).

        Returns:
            True if schema created, False if already exists.
        """
        raise NotImplementedError(f"{self.__class__.__name__} does not support create_schema()")

    def drop_schema(self, schema_name: str, tenant_id: Optional[str] = None) -> bool:
        """Drop a database schema (optional capability).

        Default implementation raises NotImplementedError.
        Backends that support schemas should override.

        Args:
            schema_name: Schema name to drop.
            tenant_id: Optional tenant identifier.

        Returns:
            True if schema dropped, False if doesn't exist.
        """
        raise NotImplementedError(f"{self.__class__.__name__} does not support drop_schema()")

    def cleanup_tenant(self, tenant_id: str) -> Dict[str, Any]:
        """Clean up all tenant data (tables, schemas, files).

        This method is called during tenant hard delete to remove all tenant-specific
        data from the datalake. Each backend implementation handles cleanup differently:

        - PostgreSQL: Drops tenant schemas (tenant_{id}_source, tenant_{id}_transformers)
        - DuckDB: Drops all tables and removes database files (torana_source_{id}.duckdb, torana_transformers_{id}.duckdb)
        - Snowflake: Drops tenant schemas

        Args:
            tenant_id: Tenant UUID to clean up.

        Returns:
            Dict with cleanup results:
                - 'success': True if cleanup completed successfully
                - 'dropped_tables': List of table names dropped
                - 'dropped_schemas': List of schema names dropped (if applicable)
                - 'removed_files': List of file paths removed (if applicable)
                - 'errors': List of error messages (if any)

        Raises:
            ConnectionError: If database connection fails.
            QueryError: If cleanup operations fail.
        """
        raise NotImplementedError(f"{self.__class__.__name__} does not support cleanup_tenant()")

    def cleanup_orphaned(
        self,
        valid_tenant_ids: List[str],
        tenant_id: Optional[str] = None,
        dry_run: bool = False,
    ) -> Dict[str, Any]:
        """Clean up orphaned data for deleted tenants.

        This method is called during orphaned cleanup to remove data for tenants
        that no longer exist in pantheon-auth. Each backend implementation handles
        cleanup differently:

        - PostgreSQL: Drops schemas for tenant IDs not in valid_tenant_ids, AND
          scans surviving tenant schemas for rows with a dangling tenant_id
        - DuckDB: Removes database files for tenant IDs not in valid_tenant_ids
          (file granularity only — no row-level scan)
        - Snowflake: Not implemented (raises NotImplementedError)

        Args:
            valid_tenant_ids: List of valid tenant UUIDs from pantheon-auth.
            tenant_id: Optional tenant id — NARROWS results to orphans belonging
                to this tenant. Defaults to None (scan everything).
            dry_run: When True, report orphans without deleting. Defaults to False
                to preserve the historical delete-by-default behaviour.

        Returns:
            Dict with cleanup results:
                - 'success': True if cleanup completed successfully
                - 'orphaned_schemas': List of orphaned schema names found
                - 'orphaned_files': List of orphaned file paths found
                - 'dropped_schemas': List of schema names dropped
                - 'removed_files': List of file paths removed
                - 'orphaned_objects': List of canonical orphan dicts, each with
                  keys 'type', 'table', 'id', 'name', 'tenant_id'
                - 'orphaned_rows': Subset of orphaned_objects with type == 'row'
                - 'deleted_rows': Count of rows deleted (0 on a dry run)
                - 'errors': List of error messages (if any)

        Raises:
            ConnectionError: If database connection fails.
            QueryError: If cleanup operations fail.
            NotImplementedError: If backend doesn't support orphaned cleanup.
        """
        raise NotImplementedError(f"{self.__class__.__name__} does not support cleanup_orphaned()")

    def truncate_table(self, table: str, tenant_id: str) -> bool:
        """Truncate a table (remove all rows).

        Default implementation raises NotImplementedError.
        Backends that support TRUNCATE should override.

        Args:
            table: Table name.
            tenant_id: Tenant identifier.

        Returns:
            True if truncated successfully.
        """
        raise NotImplementedError(f"{self.__class__.__name__} does not support truncate_table()")

    def delete_rows(
        self,
        table: str,
        tenant_id: str,
        where: str,
        params: Optional[Dict[str, Any]] = None,
    ) -> int:
        """Delete rows matching a WHERE clause and return the count deleted.

        Unlike query(), this is a WRITE operation: it COMMITs the transaction
        and returns cursor.rowcount (query() never commits and always calls
        fetchall(), so it cannot be used for DELETE).

        Args:
            table: Table name (within the tenant's schema).
            tenant_id: Tenant identifier (scopes the search_path / schema).
            where: SQL WHERE clause WITHOUT the leading "WHERE" keyword.
            params: Optional bind parameters for the WHERE clause.

        Returns:
            Number of rows deleted.

        Raises:
            NotImplementedError: If the backend doesn't support filtered delete.
        """
        raise NotImplementedError(f"{self.__class__.__name__} does not support delete_rows()")

    def get_row_count(self, table: str, tenant_id: str) -> int:
        """Get the number of rows in a table.

        Args:
            table: Table name.
            tenant_id: Tenant identifier.

        Returns:
            Number of rows in the table.

        Raises:
            TableNotFoundError: If table doesn't exist.
        """
        result = self.query(f"SELECT COUNT(*) as count FROM {table}", tenant_id)
        if result.rows:
            return result.rows[0][0]
        return 0

    def __repr__(self) -> str:
        """String representation of backend."""
        return f"{self.__class__.__name__}()"
