"""
PostgreSQL backend implementation for the datalake.

This module provides a PostgreSQL-based backend using schema-based isolation
for multi-tenancy. Each tenant gets their own schema (tenant_<tenant_id>).

Supports two schema organization modes:
- Split mode (default): tenant_<tenant_id>_source and tenant_<tenant_id>_transformers
- Unified mode: tenant_<tenant_id> (single schema for all tables)
"""

import os
import time
from typing import List, Dict, Any, Optional, Sequence, Tuple
from contextlib import contextmanager

import httpx
import psycopg2
from psycopg2 import sql, pool
from psycopg2.extras import RealDictCursor

from pantheon_shared import get_logger
from pantheon_shared.pantheon_services import get_pantheon_service_url, PantheonService
from pantheon_shared.datalake.base import DatalakeBackend
from pantheon_shared.datalake.types import (
    ConnectionConfig,
    QueryResult,
    UpsertResult,
    TableInfo,
    ColumnInfo
)
from pantheon_shared.datalake.exceptions import (
    ConnectionError as DatalakeConnectionError,
    QueryError,
    ConfigurationError,
    TableNotFoundError,
    ValidationError
)
from pantheon_shared.http import PantheonClient

logger = get_logger(__name__)


class PostgreSQLBackend(DatalakeBackend):
    """PostgreSQL backend implementation using schema-based isolation for multi-tenancy.

    Multi-tenancy model (supports two modes):
    - Split mode (default): tenant_<tenant_id>_source and tenant_<tenant_id>_transformers
    - Unified mode: tenant_<tenant_id> (single schema for all tables)
    - Schema-based isolation provides strong separation
    - Tables are created within tenant-specific schemas

    Environment variables:
        DATALAKE_POSTGRES_HOST: Database host (required)
        DATALAKE_POSTGRES_PORT: Database port (default: 5432)
        DATALAKE_POSTGRES_DATABASE: Database name (required)
        DATALAKE_POSTGRES_USER: Database user (required)
        DATALAKE_POSTGRES_PASSWORD: Database password (required)
        DATALAKE_POSTGRES_POOL_SIZE: Connection pool size (default: 10)
        DATALAKE_AUTH_BASE_URL: Optional override for auth service URL
        PANTHEON_AUTH_SERVICE: Auth service hostname (default: "pantheon-auth")
        PANTHEON_AUTH_PORT: Auth service port (default: "8000")
        DISABLE_TENANT_SCHEMA_MODE_CACHE: Disable tenant schema mode caching (default: "false").
                                          Set to "true", "1", or "yes" to disable caching.
                                          Useful for debugging or emergency fixes.
    """

    # Cache for tenant schema modes: {tenant_id: ('split'|'unified', timestamp)}
    # Cached indefinitely since schema mode never changes for a tenant
    _tenant_schema_mode_cache: Dict[str, Tuple[str, float]] = {}

    # Environment variable to disable caching (for debugging/emergency fixes)
    # Set DISABLE_TENANT_SCHEMA_MODE_CACHE=true to bypass cache
    _disable_cache = os.getenv('DISABLE_TENANT_SCHEMA_MODE_CACHE', 'false').lower() in ('true', '1', 'yes')

    # ⚠️ Read timeout for the schema-mode lookup against pantheon-auth.
    # 5s was too tight at cluster bring-up: a COLD pantheon-auth answers
    # GET /api/v1/tenants/{id} in ~7.5s (measured on the GKE twin), so EVERY
    # lookup timed out. The cache above only stores SUCCESSES, so nothing was
    # ever cached and the datalake migration re-paid the full timeout once per
    # table (~16 tables x 3 retries = minutes of pure timeout), while silently
    # falling back to 'unified' for a tenant whose real mode was never read.
    _schema_mode_timeout = float(os.getenv('TENANT_SCHEMA_MODE_TIMEOUT', '30'))

    def __init__(self, config: ConnectionConfig):
        """Initialize PostgreSQL backend with connection pooling.

        Args:
            config: Connection configuration.
        """
        self.config = config
        self._pool: Optional[pool.ThreadedConnectionPool] = None
        self._current_tenant: Optional[str] = None
        # How long a caller waits for a free pooled connection before giving up.
        # See _acquire_waiting: this converts pool exhaustion from an immediate
        # ERROR into backpressure. Bounded so exhaustion can never become a hang.
        try:
            self._pool_acquire_timeout = float(
                os.getenv("DATALAKE_POOL_ACQUIRE_TIMEOUT", "10"))
        except (TypeError, ValueError):
            self._pool_acquire_timeout = 10.0
        # Use service registry to get auth service URL
        self._auth_base_url = get_pantheon_service_url(
            PantheonService.AUTH,
            url_env_var="DATALAKE_AUTH_BASE_URL"  # Allow override
        )
        self._initialize_pool()

    def _initialize_pool(self) -> None:
        """Initialize the connection pool."""
        try:
            minconn = 1
            maxconn = self.config.pool_size or 10

            import os as _os
            app_name = _os.getenv("APPLICATION_NAME", "pantheon-datalake")
            self._pool = pool.ThreadedConnectionPool(
                minconn=minconn,
                maxconn=maxconn,
                host=self.config.host,
                port=self.config.port,
                database=self.config.database,
                user=self.config.user,
                password=self.config.password,
                application_name=app_name,
            )
            logger.info(f"Initialized PostgreSQL connection pool (min={minconn}, max={maxconn}) for {self.config.host}")
        except Exception as e:
            logger.error(f"Failed to initialize connection pool: {e}")
            raise DatalakeConnectionError(f"Pool initialization failed: {e}") from e

    def _prepare_connection(self, conn, tenant_id: Optional[str]) -> None:
        """Validate a pooled connection is alive and set its tenant search_path.

        Pings the connection with `SELECT 1` first so a stale/closed connection
        handed out by the pool surfaces here (as a raise) rather than on the
        caller's first real query. Then sets the search_path for the tenant's
        schema (split or unified mode).

        Raises on a dead connection or a failed search_path SET — the caller
        discards the connection (close=True) and retries with a fresh one.
        """
        # Liveness ping — a pooled connection may have been silently dropped by
        # the server / network while idle. psycopg2's pool does not validate on
        # getconn(), so we validate here.
        cursor = conn.cursor()
        try:
            cursor.execute("SELECT 1")
        finally:
            cursor.close()

        # Set search_path for tenant if tenant_id provided.
        # Behavior differs based on tenant's datalake_schema_mode setting:
        # - Split mode: tenant_{id}_transformers, tenant_{id}_source, public
        # - Unified mode: tenant_{id}, public
        if tenant_id:
            mode = self._get_tenant_schema_mode(tenant_id)
            cursor = conn.cursor()
            try:
                if mode == 'split':
                    # Split mode: separate schemas for source and transformers.
                    source_schema = self._get_schema_name(tenant_id, db_type='source')
                    transformers_schema = self._get_schema_name(tenant_id, db_type='transformers')
                    # Transformers first so that if a table exists in both, the
                    # transformer version wins.
                    cursor.execute(
                        sql.SQL("SET search_path TO {}, {}, public").format(
                            sql.Identifier(transformers_schema),
                            sql.Identifier(source_schema)
                        )
                    )
                else:
                    # Unified mode: single schema for all tables.
                    unified_schema = self._get_schema_name(tenant_id)
                    cursor.execute(
                        sql.SQL("SET search_path TO {}, public").format(
                            sql.Identifier(unified_schema)
                        )
                    )
            finally:
                cursor.close()

    @staticmethod
    def _is_stale_connection_error(exc: Exception) -> bool:
        """True if `exc` looks like a dropped/dead pooled connection.

        These are the errors we recover from by discarding the connection and
        retrying with a fresh one. Genuine query/logic errors are NOT stale and
        must propagate unchanged.
        """
        return isinstance(exc, (psycopg2.OperationalError, psycopg2.InterfaceError))

    def _acquire_waiting(self):
        """getconn() that WAITS for a free connection instead of raising.

        ⛔ THE POINT: psycopg2's ThreadedConnectionPool.getconn() does NOT block
        when every connection is checked out — it raises PoolError("connection
        pool exhausted") immediately. That turns a moment of CONTENTION into a
        user-visible FAILURE, which is why concurrent widget rendering had to be
        reverted in pantheon-viz: making renders genuinely parallel overran the
        pool and turned healthy widgets into ERRORs (17/22 ok instead of 20/22),
        so the blocking datalake call was deliberately kept as the de-facto
        throttle. See widget_renderer.py and freshness_resolver.py.

        Waiting is the correct semantic for a pool under load: a caller that
        arrives when the pool is full should be SLOWED, not failed. With this in
        place a bounded concurrent fan-out degrades into queueing.

        ⚠️ Still bounded. If no connection frees within DATALAKE_POOL_ACQUIRE_TIMEOUT
        we raise PoolError as before — an unbounded wait would convert pool
        exhaustion into a hung request, which is worse than a fast failure.

        ⚠️ Polling, not a condition variable, deliberately: psycopg2's pool
        exposes no wait primitive and owns its own lock. Polling adds no
        coupling to its internals and costs one short sleep per retry only on
        the contended path — the uncontended path is a single getconn() call
        with no added latency.
        """
        deadline = time.monotonic() + self._pool_acquire_timeout
        delay = 0.005
        while True:
            try:
                return self._pool.getconn()
            except pool.PoolError as e:
                # Only "exhausted" is worth waiting on. Anything else (e.g. the
                # pool being closed) is terminal and must propagate immediately.
                if "exhausted" not in str(e).lower():
                    raise
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    logger.warning(
                        "datalake pool acquire timed out after %.1fs (max=%s) — "
                        "raising; consider raising DATALAKE_POSTGRES_POOL_SIZE or "
                        "lowering caller concurrency",
                        self._pool_acquire_timeout, self.config.pool_size,
                    )
                    raise
                time.sleep(min(delay, remaining))
                # Backoff caps at 50ms: long enough to stop busy-spinning, short
                # enough that a freed connection is picked up promptly.
                delay = min(delay * 2, 0.05)

    @contextmanager
    def _get_connection(self, tenant_id: Optional[str] = None):
        """Get a live connection from the pool (context manager).

        psycopg2's ThreadedConnectionPool does not validate connections on
        getconn(), so an idle connection that the server has since dropped is
        handed out as-is and fails on first use with "connection already
        closed" (an OperationalError/InterfaceError). To make callers resilient
        to this, we ping each pooled connection before yielding it; if the ping
        fails we discard that connection (putconn(close=True), so the pool
        physically drops it) and fetch another. This retries up to `maxconn`
        times so every dead connection lingering in the pool is drained before
        we give up.

        Args:
            tenant_id: Optional tenant ID to set search_path for tenant's schema.

        Yields:
            A validated database connection with search_path set if tenant_id
            provided.

        This is a context manager that automatically returns the connection to
        the pool.
        """
        if not self._pool:
            raise DatalakeConnectionError("Connection pool not initialized")

        conn = None
        # Bound the drain loop by pool size so we never spin forever; +1 covers
        # the freshly-created connection the pool opens once dead ones are gone.
        max_attempts = (self.config.pool_size or 10) + 1
        last_error: Optional[Exception] = None
        for attempt in range(max_attempts):
            candidate = self._acquire_waiting()
            try:
                self._prepare_connection(candidate, tenant_id)
            except Exception as prep_err:
                # Roll back any aborted transaction state, then decide whether
                # this is a recoverable stale connection or a real error.
                try:
                    candidate.rollback()
                except Exception:
                    pass

                if self._is_stale_connection_error(prep_err):
                    # Discard the dead connection so the pool drops it instead
                    # of recycling the corpse, then try another.
                    self._pool.putconn(candidate, close=True)
                    last_error = prep_err
                    logger.warning(
                        "Discarded stale datalake connection "
                        f"(attempt {attempt + 1}/{max_attempts}): {prep_err}"
                    )
                    continue

                # Not a stale-connection error — return the connection and
                # propagate (e.g. a bad search_path / missing schema).
                self._pool.putconn(candidate)
                raise

            conn = candidate
            break

        if conn is None:
            raise DatalakeConnectionError(
                "Could not obtain a live datalake connection after "
                f"{max_attempts} attempts"
            ) from last_error

        try:
            yield conn
        except Exception:
            try:
                conn.rollback()
            except Exception:
                pass
            raise
        finally:
            # If the connection died mid-use, drop it from the pool rather than
            # recycling it; otherwise return it for reuse.
            if getattr(conn, "closed", 0):
                self._pool.putconn(conn, close=True)
            else:
                self._pool.putconn(conn)

    def connect(self, tenant_id: Optional[str] = None) -> bool:
        """Set tenant context (connection pool is already initialized).

        Args:
            tenant_id: Optional tenant identifier for multi-tenancy context.

        Returns:
            True if pool is healthy, False otherwise.

        Note: This method now only sets tenant context. The connection pool
        is initialized in __init__ and connections are managed automatically.
        """
        if tenant_id:
            self._current_tenant = tenant_id

        # Test pool health; if stale connections cause failure, reinitialize and retry once
        for attempt in range(2):
            try:
                with self._get_connection() as conn:
                    cursor = conn.cursor()
                    cursor.execute("SELECT 1")
                    cursor.close()
                return True
            except Exception as e:
                logger.error(f"Connection pool health check failed: {e}")
                if attempt == 0:
                    logger.info("Reinitializing connection pool after health check failure")
                    try:
                        if self._pool:
                            self._pool.closeall()
                    except Exception:
                        pass
                    self._pool = None
                    try:
                        self._initialize_pool()
                    except Exception as reinit_err:
                        logger.error(f"Failed to reinitialize connection pool: {reinit_err}")
                        return False
        return False

    def disconnect(self) -> None:
        """Close all connections in the pool."""
        if self._pool:
            try:
                self._pool.closeall()
                logger.info("Closed all connections in PostgreSQL pool")
            except Exception as e:
                logger.warning(f"Error closing connection pool: {e}")
            finally:
                self._pool = None

        self._current_tenant = None

    def _ensure_connected(self) -> None:
        """Ensure backend has an initialized connection pool.

        Raises:
            DatalakeConnectionError: If pool not initialized.
        """
        if not self._pool:
            raise DatalakeConnectionError("Connection pool not initialized")

    def _get_tenant_schema_mode(self, tenant_id: str) -> str:
        """Get tenant's datalake schema mode from auth service.

        The schema mode is cached indefinitely since it never changes for a tenant.
        Cache can be disabled via DISABLE_TENANT_SCHEMA_MODE_CACHE environment variable
        for debugging or emergency fixes.

        Args:
            tenant_id: Tenant identifier.

        Returns:
            'split' or 'unified'. Defaults to 'unified' if lookup fails.
        """
        # Check cache first (unless caching is disabled)
        if not PostgreSQLBackend._disable_cache:
            if tenant_id in PostgreSQLBackend._tenant_schema_mode_cache:
                mode, _ = PostgreSQLBackend._tenant_schema_mode_cache[tenant_id]
                logger.debug(f"Using cached schema mode for tenant {tenant_id}: {mode}")
                return mode

        # Cache miss or caching disabled - fetch from auth service
        try:
            # ⛔ NOT `/api/v1/tenants/{tenant_id}` (issue #171). That route runs
            # validate_tenant_access(), which 403s a service JWT for every tenant
            # except the one the token itself belongs to -- MEASURED: forged header
            # 200, service JWT 403. This lookup is inherently cross-tenant.
            # `/api/v1/internal/cleanup/tenants` has no such check and already
            # returns datalake_schema_mode for EVERY tenant, so fetch the list and
            # select ours. (Same resolution as pantheon-datalake tables.py.)
            from pantheon_shared.http import PantheonSyncClient

            client = PantheonSyncClient(
                service_name=os.getenv("SERVICE_NAME", "pantheon-shared"),
                tenant_name=os.getenv("SERVICE_AUTH_TENANT_NAME")
                or os.getenv("BOOTSTRAP_TENANT_NAME", "Torana"),
                namespace_name=os.getenv("SERVICE_AUTH_TENANT_NS_NAME", "default"),
                debug=False,
            )
            try:
                response = client.get(
                    f"{self._auth_base_url}/api/v1/internal/cleanup/tenants",
                    timeout=PostgreSQLBackend._schema_mode_timeout,
                )
                response.raise_for_status()
                payload = response.json()
            finally:
                client.close()

            mode = 'unified'
            for row in payload.get('items', []):
                if str(row.get('id')) == str(tenant_id):
                    mode = row.get('datalake_schema_mode') or 'unified'
                    break

            # Update cache (indefinitely - no TTL since mode never changes)
            if not PostgreSQLBackend._disable_cache:
                current_time = time.time()
                PostgreSQLBackend._tenant_schema_mode_cache[tenant_id] = (mode, current_time)
                logger.debug(f"Fetched and cached schema mode for tenant {tenant_id}: {mode}")
            else:
                logger.debug(f"Fetched schema mode for tenant {tenant_id} (caching disabled): {mode}")
            return mode

        except Exception as e:
            logger.warning(f"Failed to fetch schema mode for tenant {tenant_id}, defaulting to 'unified': {e}")
            # Fallback to 'unified' as the new default
            return 'unified'

    def set_tenant_schema_mode(self, tenant_id: str, mode: str) -> None:
        """Pre-cache the tenant's schema mode to avoid callback to auth service.

        This is used during tenant initialization when the schema mode is already
        known from the tenant creation request, eliminating the need for a
        callback to pantheon-auth.

        Args:
            tenant_id: Tenant identifier.
            mode: Schema mode ('split' or 'unified').

        Raises:
            ValueError: If mode is not 'split' or 'unified'.
        """
        # BHAKTA DEBUG: Log method entry
        logger.info(
            "[BHAKTA] PostgreSQLBackend.set_tenant_schema_mode called",
            tenant_id=tenant_id,
            mode=mode,
            cache_disabled=PostgreSQLBackend._disable_cache
        )

        if mode not in ('split', 'unified'):
            raise ValueError(f"Invalid schema mode '{mode}'. Must be 'split' or 'unified'.")

        # Update cache (indefinitely - no TTL since mode never changes)
        if not PostgreSQLBackend._disable_cache:
            current_time = time.time()
            PostgreSQLBackend._tenant_schema_mode_cache[tenant_id] = (mode, current_time)
            # BHAKTA DEBUG: Log cache update
            logger.info(
                "[BHAKTA] Schema mode cached",
                tenant_id=tenant_id,
                mode=mode,
                cache_size=len(PostgreSQLBackend._tenant_schema_mode_cache)
            )
        else:
            logger.debug(f"Caching disabled, skipping pre-cache for tenant {tenant_id}")

    def _get_schema_name(self, tenant_id: str, db_type: Optional[str] = None, scope: Optional[str] = None) -> str:
        """Get schema name for tenant and database type.

        Args:
            tenant_id: Tenant identifier.
            db_type: 'source' or 'transformers' (default: 'source').

        Returns:
            Schema name based on tenant's datalake_schema_mode setting.
            Split mode:
                - For 'source': 'tenant_{tenant_id}_source'
                - For 'transformers': 'tenant_{tenant_id}_transformers'
            Unified mode:
                - For both: 'tenant_{tenant_id}'
            Global scope:
                - 'public' (shared, tenant-independent reference tables)
        """
        # Global reference tables (e.g. vm_cve_metadata) live in the shared `public`
        # schema; every tenant's search_path already includes public (see
        # _prepare_connection), so all tenants can READ them, while the feed writes a
        # single copy. scope="global" bypasses tenant routing entirely.
        if scope == "global":
            return "public"

        mode = self._get_tenant_schema_mode(tenant_id)

        if mode == 'split':
            # Split mode: separate schemas for source and transformers
            suffix = db_type if db_type in ('source', 'transformers') else 'source'
            return f"tenant_{tenant_id}_{suffix}"
        else:
            # Unified mode: single schema for all tables
            return f"tenant_{tenant_id}"

    def _ensure_schema_exists(self, schema_name: str) -> None:
        """Ensure schema exists, create if not.

        Args:
            schema_name: Schema name to ensure exists.
        """
        self._ensure_connected()

        with self._get_connection() as conn:
            cursor = conn.cursor()
            try:
                # Check if schema exists
                cursor.execute("""
                    SELECT schema_name FROM information_schema.schemata
                    WHERE schema_name = %s
                """, (schema_name,))

                if cursor.fetchone() is None:
                    # Create schema
                    cursor.execute(sql.SQL("CREATE SCHEMA {}").format(
                        sql.Identifier(schema_name)
                    ))
                    conn.commit()
                    logger.info(f"Created schema: {schema_name}")
            finally:
                cursor.close()

    def query(self, sql: str, tenant_id: str, params: Optional[Dict[str, Any]] = None) -> QueryResult:
        """Execute a read-only SQL query.

        Args:
            sql: SQL query string.
            tenant_id: Tenant identifier for scoping.
            params: Optional query parameters.

        Returns:
            QueryResult with columns, rows, and metadata.
        """
        self._ensure_connected()

        query_timeout_ms = int(os.environ.get("DATALAKE_QUERY_TIMEOUT_MS", "30000"))

        try:
            with self._get_connection(tenant_id) as conn:
                cursor = conn.cursor()
                try:
                    cursor.execute(f"SET LOCAL statement_timeout = {query_timeout_ms}")
                    if params:
                        cursor.execute(sql, params)
                    else:
                        cursor.execute(sql)

                    # Get column names
                    if cursor.description:
                        columns = [desc[0] for desc in cursor.description]
                    else:
                        columns = []

                    # Fetch all rows
                    rows = cursor.fetchall()

                    return QueryResult(
                        columns=columns,
                        rows=rows,
                        row_count=len(rows)
                    )

                finally:
                    cursor.close()

        except Exception as e:
            logger.error(f"Query execution failed: {e}")
            raise QueryError(f"Query failed: {e}") from e

    def explain_sql(self, sql: str, tenant_id: str) -> tuple[bool, str | None]:
        """Validate SQL by running EXPLAIN against the tenant schema.

        Parses and plans the query without executing it — zero rows read,
        no side effects. Column and table references are fully validated by
        the Postgres planner.

        Returns:
            (True, None) if the query is valid.
            (False, error_message) if the planner rejects it.
        """
        self._ensure_connected()
        try:
            with self._get_connection(tenant_id) as conn:
                cursor = conn.cursor()
                try:
                    cursor.execute(f"EXPLAIN {sql}")
                    return True, None
                except Exception as e:
                    msg = str(e).strip()
                    # Postgres prefixes the EXPLAIN statement in error context lines
                    # e.g. "LINE 1: EXPLAIN SELECT ..." — rewrite to the user's SQL.
                    msg = msg.replace("EXPLAIN SELECT ", "SELECT ").replace("EXPLAIN WITH ", "WITH ")
                    return False, msg
                finally:
                    # Roll back any implicit transaction so the connection
                    # stays clean for the pool.
                    conn.rollback()
                    cursor.close()
        except Exception as e:
            return False, str(e)

    def explain_sql_with_ephemeral_views(
        self,
        sql_to_check: str,
        upstream_views: List[Tuple[str, str]],
        tenant_id: str,
    ) -> Tuple[bool, Optional[str]]:
        """Validate `sql_to_check` for correctness (table/column references) WITHOUT
        materializing anything — by first creating each upstream transformer as a
        TEMPORARY VIEW (in dependency order), then EXPLAIN-ing the query against them,
        all inside ONE transaction that is ROLLED BACK.

        This is the cook-time correctness check for a DEPENDENT artifact (a widget/kpi/
        rule/chained-transformer whose SQL reads an UPSTREAM transformer's output table
        that is not materialized until deploy). A TEMP VIEW stores NO data and leaves NO
        object behind after the transaction — it exists only so the Postgres planner can
        resolve the dependent's column references against the upstream's real column
        signature. So the planner catches "column X does not exist" / "relation Y does
        not exist" at COOK, exactly as it would at deploy, but nothing is written to the
        datalake (materialization remains a deploy-only, user-gated concern).

        Args:
            sql_to_check: the dependent artifact's SQL.
            upstream_views: (view_name, view_sql) pairs, in DEPENDENCY ORDER — each is an
                upstream transformer whose output table `sql_to_check` may reference.
                They are created as temp views in the given order (so a chained upstream
                that itself reads an earlier one resolves).
            tenant_id: tenant schema scope (base tables resolve via the tenant search_path).

        Returns:
            (True, None)      if the planner resolved the whole query.
            (False, message)  with the planner's rejection (column/relation error).
        """
        self._ensure_connected()
        try:
            with self._get_connection(tenant_id) as conn:
                cursor = conn.cursor()
                try:
                    # Ensure temp views are searched FIRST, but keep the tenant schema + public
                    # on the path so BASE tables (vulnerabilities, packages, …) that an upstream
                    # view reads still resolve. _prepare_connection already SET the tenant path on
                    # this connection; read it back and PREPEND pg_temp so a temp view named the
                    # same as a (not-yet-materialized) output table wins over any real object.
                    cursor.execute("SHOW search_path")
                    current_path = cursor.fetchone()[0]
                    cursor.execute(f"SET search_path TO pg_temp, {current_path}")
                except Exception:
                    # If reading/setting the path fails, roll back the aborted txn and fall back to
                    # the connection's default path (pg_temp is implicitly searched first anyway).
                    conn.rollback()
                try:
                    for view_name, view_sql in upstream_views:
                        stmt = view_sql.rstrip().rstrip(";")
                        cursor.execute(
                            sql.SQL("CREATE TEMP VIEW {} AS {}").format(
                                sql.Identifier(view_name), sql.SQL(stmt)
                            )
                        )
                    cursor.execute(f"EXPLAIN {sql_to_check}")
                    return True, None
                except Exception as e:
                    msg = str(e).strip()
                    msg = msg.replace("EXPLAIN SELECT ", "SELECT ").replace("EXPLAIN WITH ", "WITH ")
                    return False, msg
                finally:
                    # Roll back: the temp views + everything vanish; nothing persisted.
                    conn.rollback()
                    cursor.close()
        except Exception as e:
            return False, str(e)

    def describe_sql_columns(
        self,
        sql_query: str,
        upstream_views: List[Tuple[str, str]],
        tenant_id: str,
    ) -> Tuple[Optional[List[str]], Optional[str]]:
        """Resolve the OUTPUT COLUMN NAMES of a SQL query WITHOUT reading or materializing ANY
        data — the highest-fidelity, zero-data way to know what columns a transformer produces.

        Mechanism (empirically verified zero-data): build each upstream transformer as a TEMP VIEW
        (in dependency order), build `sql` itself as a temp view, then read its resolved columns
        from `pg_attribute` (the Postgres catalog), and ROLLBACK. `CREATE VIEW` is a METADATA
        operation — it stores the query definition and lets the planner resolve the column
        signature from the catalog; it NEVER executes the query or reads a row (a 46k-row base
        table resolves in ~4ms, 0 bytes on disk). This correctly expands `SELECT *` and joins
        (the planner does it) — which static SQL parsing cannot do reliably. NOTHING is
        materialized; NO data is transferred.

        Args:
            sql: the query whose output columns to resolve (e.g. a transformer's SQL).
            upstream_views: (view_name, view_sql) pairs in DEPENDENCY ORDER — upstreams `sql`
                reads whose tables are not materialized. Built as temp views first.
            tenant_id: tenant schema scope.

        Returns:
            (column_names, None) on success — the ordered output column names.
            (None, error_message) if the SQL/upstream failed to resolve (e.g. a bad column ref).
        """
        self._ensure_connected()
        _probe = "_bv2_col_probe"
        try:
            with self._get_connection(tenant_id) as conn:
                cursor = conn.cursor()
                try:
                    cursor.execute("SHOW search_path")
                    current_path = cursor.fetchone()[0]
                    cursor.execute(f"SET search_path TO pg_temp, {current_path}")
                except Exception:
                    conn.rollback()
                try:
                    for view_name, view_sql in upstream_views:
                        stmt = view_sql.rstrip().rstrip(";")
                        cursor.execute(
                            sql.SQL("CREATE TEMP VIEW {} AS {}").format(
                                sql.Identifier(view_name), sql.SQL(stmt)
                            )
                        )
                    stmt = sql_query.rstrip().rstrip(";")
                    cursor.execute(
                        sql.SQL("CREATE TEMP VIEW {} AS {}").format(
                            sql.Identifier(_probe), sql.SQL(stmt)
                        )
                    )
                    # Read the resolved columns from the catalog — NO data touched.
                    cursor.execute(
                        "SELECT attname FROM pg_attribute "
                        "WHERE attrelid = %s::regclass AND attnum > 0 AND NOT attisdropped "
                        "ORDER BY attnum",
                        (_probe,),
                    )
                    cols = [r[0] for r in cursor.fetchall()]
                    return cols, None
                except Exception as e:
                    msg = str(e).strip()
                    msg = msg.replace("EXPLAIN SELECT ", "SELECT ").replace("EXPLAIN WITH ", "WITH ")
                    return None, msg
                finally:
                    conn.rollback()  # temp views vanish; nothing persisted, no data moved
                    cursor.close()
        except Exception as e:
            return None, str(e)

    def insert(self, table: str, data: List[Dict[str, Any]], tenant_id: str) -> UpsertResult:
        """Bulk insert records into a table.

        Args:
            table: Table name (without schema prefix).
            data: List of records to insert.
            tenant_id: Tenant identifier.

        Returns:
            UpsertResult with count of inserted records.
        """
        self._ensure_connected()

        if not data:
            return UpsertResult(success=True, inserted=0, updated=0)

        try:
            schema_name = self._get_schema_name(tenant_id)
            self._ensure_schema_exists(schema_name)

            with self._get_connection() as conn:
                cursor = conn.cursor()

                try:
                    # Get column names from first record
                    columns = list(data[0].keys())

                    # Build INSERT statement with schema qualification
                    table_ref = sql.SQL('{}.{}').format(
                        sql.Identifier(schema_name),
                        sql.Identifier(table)
                    )
                    columns_ref = sql.SQL(', ').join(map(sql.Identifier, columns))
                    placeholders = sql.SQL(', ').join(sql.Placeholder() * len(columns))

                    insert_sql = sql.SQL("INSERT INTO {} ({}) VALUES ({})").format(
                        table_ref,
                        columns_ref,
                        placeholders
                    )

                    # Prepare data - convert dict/list to JSON strings
                    import json

                    def adapt_json(value):
                        if isinstance(value, (dict, list)):
                            return json.dumps(value)
                        return value

                    rows = []
                    for record in data:
                        row = [adapt_json(record.get(col)) for col in columns]
                        rows.append(tuple(row))

                    cursor.executemany(insert_sql, rows)
                    conn.commit()

                    inserted = cursor.rowcount
                    logger.info(f"Inserted {inserted} records into {schema_name}.{table}")

                    return UpsertResult(success=True, inserted=inserted, updated=0)

                except Exception as e:
                    conn.rollback()
                    raise
                finally:
                    cursor.close()

        except Exception as e:
            logger.error(f"Insert failed: {e}")
            raise QueryError(f"Insert into {table} failed: {e}") from e

    def upsert(
        self,
        table: str,
        data: List[Dict[str, Any]],
        primary_key: str,
        tenant_id: str,
        preserve_columns: Optional[List[str]] = None,
        scope: Optional[str] = None,
    ) -> UpsertResult:
        """Insert or update records using ON CONFLICT.

        Args:
            table: Table name.
            data: List of records to upsert.
            primary_key: Primary key column name.
            tenant_id: Tenant identifier.
            preserve_columns: Columns excluded from the ON CONFLICT DO UPDATE
                SET clause, so existing rows keep their stored value while new
                rows still get the incoming value on first insert.

        Returns:
            UpsertResult with counts of inserted/updated records.
        """
        import json

        self._ensure_connected()

        if not data:
            return UpsertResult(success=True, inserted=0, updated=0)

        try:
            schema_name = self._get_schema_name(tenant_id, scope=scope)
            self._ensure_schema_exists(schema_name)

            with self._get_connection() as conn:
                # Register json adapter for dict/list values
                import json

                # Adapt dict/list to JSON strings for JSONB columns
                def adapt_json(value):
                    if isinstance(value, (dict, list)):
                        return json.dumps(value)
                    return value

                cursor = conn.cursor()

                try:
                    # Fetch table column names from information_schema so we can
                    # strip record keys that don't exist in the table.  This
                    # prevents "column X does not exist" errors when the pipeline
                    # passes raw API fields that weren't cleaned up by a drop/pack
                    # step.  Unknown keys are silently discarded.
                    cursor.execute(
                        sql.SQL(
                            "SELECT column_name FROM information_schema.columns "
                            "WHERE table_schema = %s AND table_name = %s"
                        ),
                        [schema_name, table],
                    )
                    table_columns = {row[0] for row in cursor.fetchall()}
                    if table_columns:
                        # Union keys across ALL records, not just data[0]. Batches can be
                        # heterogeneous (e.g. only 'Resolved' vulns carry
                        # vulnerability_resolution_date); keying off the first record alone
                        # silently drops any column absent from data[0] for the whole batch.
                        # Preserve first-seen order for stable, readable SQL.
                        seen = set()
                        ordered_keys = []
                        for rec in data:
                            for k in rec.keys():
                                if k not in seen:
                                    seen.add(k)
                                    ordered_keys.append(k)
                        columns = [k for k in ordered_keys if k in table_columns]
                    else:
                        # Table does not exist — create it on-the-fly with TEXT columns
                        # so operator-coverage tests that use custom destination_table
                        # names can proceed without pre-creating the schema.
                        columns = list(data[0].keys())
                        if columns:
                            # Ensure primary key column is first and always TEXT
                            pk_col = primary_key if primary_key in columns else (columns[0] if columns else "id")
                            col_defs = sql.SQL(", ").join(
                                [sql.SQL("{} TEXT PRIMARY KEY").format(sql.Identifier(pk_col))]
                                + [
                                    sql.SQL("{} TEXT").format(sql.Identifier(c))
                                    for c in columns
                                    if c != pk_col
                                ]
                            )
                            cursor.execute(
                                sql.SQL("CREATE TABLE IF NOT EXISTS {}.{} ({})").format(
                                    sql.Identifier(schema_name),
                                    sql.Identifier(table),
                                    col_defs,
                                )
                            )

                    if not columns:
                        return UpsertResult(success=True, inserted=0, updated=0)

                    # Find unique non-PK columns so we can evict stale rows
                    # (e.g. SDG rows with repo-<uuid> PKs but real full_name values)
                    # that would cause a secondary unique-constraint violation before
                    # the ON CONFLICT (primary_key) clause can fire.
                    # NOTE: must use pg_indexes (not information_schema.table_constraints)
                    # because the datalake creates UNIQUE INDEXes directly, not UNIQUE
                    # constraints, so information_schema returns nothing for them.
                    cursor.execute(
                        sql.SQL("""
                            SELECT a.attname
                            FROM pg_index ix
                            JOIN pg_class c ON c.oid = ix.indrelid
                            JOIN pg_namespace n ON n.oid = c.relnamespace
                            JOIN pg_attribute a ON a.attrelid = c.oid
                              AND a.attnum = ANY(ix.indkey)
                            WHERE ix.indisunique = true
                              AND ix.indisprimary = false
                              AND n.nspname = %s
                              AND c.relname = %s
                              AND array_length(ix.indkey, 1) = 1
                        """),
                        [schema_name, table],
                    )
                    unique_non_pk_cols = [
                        row[0] for row in cursor.fetchall()
                        if row[0] != primary_key and row[0] in columns
                    ]
                    # For each unique non-PK column, delete any existing rows whose
                    # value matches an incoming record but whose PK differs. This
                    # evicts stale rows (e.g. SDG-generated) before the real upsert.
                    if unique_non_pk_cols and primary_key in columns:
                        for unique_col in unique_non_pk_cols:
                            incoming_values = [
                                (record.get(unique_col), record.get(primary_key))
                                for record in data
                                if record.get(unique_col) is not None
                            ]
                            if incoming_values:
                                for uval, pkval in incoming_values:
                                    cursor.execute(
                                        sql.SQL(
                                            "DELETE FROM {}.{} WHERE {} = %s AND {} != %s"
                                        ).format(
                                            sql.Identifier(schema_name),
                                            sql.Identifier(table),
                                            sql.Identifier(unique_col),
                                            sql.Identifier(primary_key),
                                        ),
                                        [uval, pkval],
                                    )

                    # Build INSERT ... ON CONFLICT statement
                    table_ref = sql.SQL('{}.{}').format(
                        sql.Identifier(schema_name),
                        sql.Identifier(table)
                    )
                    columns_ref = sql.SQL(', ').join(map(sql.Identifier, columns))
                    placeholders = sql.SQL(', ').join(sql.Placeholder() * len(columns))

                    # Build UPDATE clause for ON CONFLICT
                    # Exclude created_at: it is set on first insert and must not be
                    # overwritten on subsequent upserts (preserves ingest timestamp).
                    # Also exclude any caller-declared preserve_columns so human-
                    # owned state (e.g. triage status) survives an automated re-ingest.
                    _preserve = set(preserve_columns or ())
                    # `contributing_sources` (viz provenance § 3.3.2) is ACCUMULATED,
                    # not replaced. It MUST be excluded from the generic
                    # `col = EXCLUDED.col` list below — otherwise that assignment
                    # would also be emitted and, since the last assignment for a
                    # column wins in Postgres, silently overwrite the merged map with
                    # just this run's single entry. This exclusion is the invisible
                    # blocker (spec R4).
                    _PROV = "contributing_sources"
                    update_columns = [
                        col for col in columns
                        if col not in (primary_key, 'created_at', _PROV) and col not in _preserve
                    ]
                    _assignments = [
                        sql.SQL("{} = EXCLUDED.{}").format(sql.Identifier(col), sql.Identifier(col))
                        for col in update_columns
                    ]
                    if _PROV in columns:
                        # Per-KEY merge, not `target || EXCLUDED`. A shallow `||`
                        # would replace a key present on both sides wholesale —
                        # resetting first_seen and pinning runs at 1. jsonb_object_agg
                        # over the union of keys keeps the stored first_seen and
                        # increments the stored runs (§ 3.3.5). Pure SQL, so it is
                        # atomic under the row lock (§ 3.8.4 R9.2).
                        _assignments.append(sql.SQL(
                            "{col} = ("
                            "  SELECT jsonb_object_agg(k, CASE"
                            "    WHEN old.v IS NULL THEN new.v"
                            "    WHEN new.v IS NULL THEN old.v"
                            "    ELSE new.v"
                            "         || jsonb_build_object('first_seen', old.v->>'first_seen')"
                            "         || jsonb_build_object('runs',"
                            "              COALESCE((old.v->>'runs')::int, 0)"
                            "              + COALESCE((new.v->>'runs')::int, 1))"
                            "  END)"
                            "  FROM (SELECT jsonb_object_keys("
                            "          COALESCE({tbl}.{col}, '{{}}'::jsonb)"
                            "          || COALESCE(EXCLUDED.{col}, '{{}}'::jsonb)) AS k) keys"
                            "  LEFT JOIN LATERAL (SELECT COALESCE({tbl}.{col}, '{{}}'::jsonb) -> keys.k AS v) old ON TRUE"
                            "  LEFT JOIN LATERAL (SELECT COALESCE(EXCLUDED.{col}, '{{}}'::jsonb) -> keys.k AS v) new ON TRUE"
                            ")"
                        ).format(col=sql.Identifier(_PROV), tbl=table_ref))
                    update_clause = sql.SQL(', ').join(_assignments)

                    insert_sql = sql.SQL("""
                        INSERT INTO {} ({}) VALUES ({})
                        ON CONFLICT ({}) DO UPDATE SET {}
                    """).format(
                        table_ref,
                        columns_ref,
                        placeholders,
                        sql.Identifier(primary_key),
                        update_clause
                    )

                    # Prepare data - convert dict/list to JSON strings
                    rows = []
                    for record in data:
                        row = [adapt_json(record.get(col)) for col in columns]
                        rows.append(tuple(row))

                    cursor.executemany(insert_sql, rows)
                    conn.commit()

                    rows_affected = cursor.rowcount
                    logger.info(f"Upserted {rows_affected} records into {schema_name}.{table}")

                    # PostgreSQL doesn't distinguish inserts vs updates in rowcount
                    return UpsertResult(success=True, inserted=rows_affected, updated=0)

                except Exception as e:
                    conn.rollback()
                    raise
                finally:
                    cursor.close()

        except Exception as e:
            logger.error(f"Upsert failed: {e}")
            raise QueryError(f"Upsert into {table} failed: {e}") from e

    # Type mapping from Snowflake/DuckDB to PostgreSQL
    _TYPE_MAPPING = {
        'TIMESTAMP_NTZ': 'TIMESTAMP',
        'TIMESTAMP_TZ': 'TIMESTAMPTZ',
        'VARIANT': 'JSONB',
        'OBJECT': 'JSONB',
        'ARRAY': 'JSONB',
        'BINARY': 'BYTEA',
    }

    def _convert_type(self, col_type: str) -> str:
        """
        Convert Snowflake/DuckDB types to PostgreSQL types.

        Args:
            col_type: Source column type (e.g., 'TIMESTAMP_NTZ', 'VARCHAR(255)')

        Returns:
            PostgreSQL-compatible type string
        """
        # Handle VARCHAR with length - keep as-is
        if col_type.startswith('VARCHAR'):
            return col_type

        # Handle DECIMAL with precision - keep as-is
        if col_type.startswith('DECIMAL'):
            return col_type

        # Map Snowflake-specific types to PostgreSQL
        return self._TYPE_MAPPING.get(col_type, col_type)

    def create_table(self, table: str, schema: Dict[str, Any], tenant_id: str, scope: Optional[str] = None) -> bool:
        """Create a table with the specified schema.

        Args:
            table: Table name.
            schema: Dictionary mapping column names to schema definitions.
                Can be simple type strings: {"id": "UUID", "name": "VARCHAR"}
                Or rich dicts: {"id": {"data_type": "UUID", "primary_key": True}}
            tenant_id: Tenant identifier.

        Returns:
            True if table created successfully.
        """
        self._ensure_connected()

        try:
            schema_name = self._get_schema_name(tenant_id, scope=scope)
            self._ensure_schema_exists(schema_name)

            with self._get_connection() as conn:
                cursor = conn.cursor()

                try:
                    # Build column definitions with support for rich schema metadata
                    columns = []
                    unique_cols = []
                    index_cols = []
                    for col_name, col_def in schema.items():
                        # Handle both simple type string and rich dict definitions
                        if isinstance(col_def, dict):
                            # Rich schema definition with metadata
                            col_type = col_def.get('data_type', 'VARCHAR(255)')
                            is_primary_key = col_def.get('primary_key', False)
                            is_not_null = col_def.get('not_null', False)
                        else:
                            # Simple type string (backwards compatibility)
                            col_type = col_def
                            is_primary_key = False
                            is_not_null = False

                        # Convert Snowflake/DuckDB types to PostgreSQL types
                        col_type = self._convert_type(col_type)

                        # Build column definition with type and constraints
                        col_sql = sql.SQL("{} {}").format(
                            sql.Identifier(col_name),
                            sql.SQL(col_type)
                        )

                        # Add PRIMARY KEY constraint if specified
                        if is_primary_key:
                            col_sql = sql.SQL("{} PRIMARY KEY").format(col_sql)
                        # Add NOT NULL constraint if specified (but not if already PRIMARY KEY)
                        elif is_not_null:
                            col_sql = sql.SQL("{} NOT NULL").format(col_sql)

                        columns.append(col_sql)
                        if isinstance(col_def, dict) and col_def.get('unique'):
                            unique_cols.append(col_name)
                        # Non-unique secondary index for columns marked index: True
                        # (e.g. entity_edges from_key/to_key/edge_type for traversal).
                        if isinstance(col_def, dict) and col_def.get('index'):
                            index_cols.append(col_name)

                    create_sql = sql.SQL("CREATE TABLE IF NOT EXISTS {}.{} ({})").format(
                        sql.Identifier(schema_name),
                        sql.Identifier(table),
                        sql.SQL(', ').join(columns)
                    )

                    cursor.execute(create_sql)

                    # Create unique indexes for columns marked unique: True
                    for unique_col in unique_cols:
                        idx_name = f"{table}_{unique_col}_key"
                        idx_sql = sql.SQL(
                            "CREATE UNIQUE INDEX IF NOT EXISTS {} ON {}.{} ({})"
                        ).format(
                            sql.Identifier(idx_name),
                            sql.Identifier(schema_name),
                            sql.Identifier(table),
                            sql.Identifier(unique_col),
                        )
                        cursor.execute(idx_sql)

                    # Create non-unique secondary indexes for columns marked index: True
                    for index_col in index_cols:
                        idx_name = f"{table}_{index_col}_idx"
                        idx_sql = sql.SQL(
                            "CREATE INDEX IF NOT EXISTS {} ON {}.{} ({})"
                        ).format(
                            sql.Identifier(idx_name),
                            sql.Identifier(schema_name),
                            sql.Identifier(table),
                            sql.Identifier(index_col),
                        )
                        cursor.execute(idx_sql)

                    conn.commit()
                    logger.info(f"Created table {schema_name}.{table}")

                    return True

                finally:
                    cursor.close()

        except Exception as e:
            logger.error(f"Table creation failed: {e}")
            raise QueryError(f"Failed to create table {table}: {e}") from e

    def drop_table(
        self,
        table: str,
        tenant_id: str,
        db_type: Optional[str] = None,
        cascade: bool = False,
    ) -> bool:
        """Drop a table or view.

        ⛔ `cascade` IS A DESTRUCTIVE CHOICE — make it deliberately, per call site.

        The VM catalog builds a DEPENDENCY CHAIN OF VIEWS (`finding_enriched` <-
        `open_finding_base` / `open_finding_with_ticket` / `exploited_finding`).
        That chain only exists since catalog entries began materializing as views;
        before that every relation was an independent table and neither failure
        mode below could fire. Both are now reachable, and they are OPPOSITE:

        - `cascade=True`  -> Postgres SILENTLY drops every dependent relation.
          Measured: dropping `vm_tf_finding_enriched CASCADE` destroyed
          `vm_tf_exploited_finding` and `vm_tf_open_finding_base` as a side
          effect. Nothing updates THEIR materialization rows, so they keep
          `status='ready'` while the relation is gone, and nothing is logged —
          which is why the removal is untraceable after the fact.
        - `cascade=False` -> Postgres RAISES `cannot drop ... because other
          objects depend on it`. The caller must treat that as a real failure;
          swallowing it retires the row and leaks the relation.

        ⚠️ Default is False — refusing loudly beats destroying silently. A caller
        that genuinely owns the dependents passes True explicitly.

        Args:
            table: Table (or view) name.
            tenant_id: Tenant identifier.
            db_type: Database type ('source' or 'transformers'). Defaults to 'source'.
                    Note: In unified mode, db_type is ignored.
            cascade: Drop dependent objects too. See the warning above.

        Returns:
            True if the relation was dropped (or was already absent).
        """
        self._ensure_connected()

        # Get tenant's schema mode
        mode = self._get_tenant_schema_mode(tenant_id)

        # In unified mode, db_type doesn't apply
        if mode == 'unified' and db_type:
            logger.debug(
                f"db_type='{db_type}' ignored in unified mode for tenant {tenant_id}. "
                f"Dropping table from unified schema."
            )

        try:
            schema_name = self._get_schema_name(tenant_id, db_type=db_type)

            with self._get_connection() as conn:
                cursor = conn.cursor()

                try:
                    # RELATION KIND MATTERS. `DROP TABLE IF EXISTS` on a VIEW
                    # does not no-op — Postgres raises
                    #     ERROR: "<name>" is not a table
                    # and IF EXISTS does not save it, because the error is about
                    # the kind, not the absence. Verified against live Postgres
                    # with a control: IF EXISTS DOES skip a genuinely missing
                    # relation, so this is specifically a view problem.
                    #
                    # Transformers can be either form (`Transformer.materialized`
                    # decides), so teardown must ask before it drops. Without
                    # this, deleting any view-backed transformer throws — which is
                    # why it had to be fixed BEFORE the first view is created,
                    # not after (Domain Primitives spec § 4.20.3).
                    cursor.execute(
                        "SELECT table_type FROM information_schema.tables "
                        "WHERE table_schema = %s AND table_name = %s",
                        (schema_name, table),
                    )
                    kind_row = cursor.fetchone()
                    # Absent relation -> fall through to DROP TABLE IF EXISTS,
                    # which correctly no-ops. Keeps "already gone" a success.
                    is_view = bool(kind_row) and kind_row[0] == "VIEW"

                    # ⚠️ CASCADE is appended only when the caller ASKED for it.
                    # Without it Postgres raises on a dependent relation, and that
                    # raise is the desired behaviour — see the `cascade` note on
                    # this method.
                    _suffix = " CASCADE" if cascade else ""
                    drop_sql = sql.SQL(
                        ("DROP VIEW IF EXISTS {}.{}" if is_view
                         else "DROP TABLE IF EXISTS {}.{}") + _suffix
                    ).format(
                        sql.Identifier(schema_name),
                        sql.Identifier(table)
                    )
                    cursor.execute(drop_sql)
                    conn.commit()
                    logger.info(
                        f"Dropped {'view' if is_view else 'table'} "
                        f"{schema_name}.{table}"
                    )

                    return True

                finally:
                    cursor.close()

        except Exception as e:
            logger.error(f"Table drop failed: {e}")
            raise QueryError(f"Failed to drop table {table}: {e}") from e

    def table_exists(self, table: str, tenant_id: str, db_type: Optional[str] = None) -> bool:
        """Check if a table exists.

        Args:
            table: Table name.
            tenant_id: Tenant identifier.
            db_type: Database type ('source' or 'transformers'). Defaults to 'source'.
                    Note: In unified mode, db_type is ignored.

        Returns:
            True if table exists, False otherwise.
        """
        self._ensure_connected()

        # Get tenant's schema mode
        mode = self._get_tenant_schema_mode(tenant_id)

        # In unified mode, db_type doesn't apply
        if mode == 'unified' and db_type:
            logger.debug(
                f"db_type='{db_type}' ignored in unified mode for tenant {tenant_id}. "
                f"Checking table existence in unified schema."
            )

        try:
            schema_name = self._get_schema_name(tenant_id, db_type=db_type)

            with self._get_connection() as conn:
                cursor = conn.cursor()

                try:
                    cursor.execute("""
                        SELECT COUNT(*) FROM information_schema.tables
                        WHERE table_schema = %s
                        AND table_name = %s
                    """, (schema_name, table))
                    result = cursor.fetchone()

                    return result[0] > 0 if result else False

                finally:
                    cursor.close()

        except Exception as e:
            logger.error(f"Table existence check failed: {e}")
            return False

    def _list_tables_in_schema(self, schema_name: str) -> List[TableInfo]:
        """Helper method to list all tables in a specific schema.

        Args:
            schema_name: Schema name to list tables from.

        Returns:
            List of TableInfo objects.
        """
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()

                try:
                    cursor.execute("""
                        SELECT table_name, table_type
                        FROM information_schema.tables
                        WHERE table_schema = %s
                        AND table_type = 'BASE TABLE'
                        ORDER BY table_name
                    """, (schema_name,))
                    rows = cursor.fetchall()

                    tables = []
                    for row in rows:
                        tables.append(TableInfo(
                            name=row[0],
                            schema=schema_name,
                            table_type=row[1],
                            row_count=0
                        ))

                    return tables

                finally:
                    cursor.close()

        except Exception as e:
            logger.error(f"List tables failed for schema {schema_name}: {e}")
            return []

    def list_tables(self, tenant_id: str, db_type: Optional[str] = None) -> List[TableInfo]:
        """List all tables accessible to the tenant.

        Args:
            tenant_id: Tenant identifier.
            db_type: Optional database type filter ('source', 'transformers', or 'all').
                    - 'source': Returns only source tables (split mode only)
                    - 'transformers': Returns only transformer output tables (split mode only)
                    - 'all': Returns both source and transformer tables
                    - None: Defaults to 'source' for backward compatibility
                    Note: In unified mode, db_type is ignored and all tables are returned.

        Returns:
            List of TableInfo objects.
        """
        self._ensure_connected()

        # Get tenant's schema mode
        mode = self._get_tenant_schema_mode(tenant_id)

        # In unified mode, db_type doesn't apply - return all tables
        if mode == 'unified':
            if db_type and db_type != 'all':
                logger.debug(
                    f"db_type='{db_type}' ignored in unified mode for tenant {tenant_id}. "
                    f"Returning all tables from unified schema."
                )
            schema_name = self._get_schema_name(tenant_id)
            return self._list_tables_in_schema(schema_name)

        # Split mode: db_type filtering works as expected
        # Handle 'all' - return both source and transformer tables
        if db_type == 'all':
            source_tables = self.list_tables(tenant_id, db_type='source')
            transformer_tables = self.list_tables(tenant_id, db_type='transformers')
            return source_tables + transformer_tables

        # Get schema name based on db_type
        schema_name = self._get_schema_name(tenant_id, db_type)
        return self._list_tables_in_schema(schema_name)

    def _table_in_schema(self, schema_name: str, table: str) -> bool:
        """Does `table` physically exist in `schema_name`?

        Best-effort by design: used only to CHOOSE between the tenant schema and the
        shared `public` one, and the caller's own query reports the real error. On any
        failure we answer False, which preserves the pre-existing behaviour (tenant
        schema) rather than rerouting on a transient probe failure.
        """
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                try:
                    cursor.execute(
                        "SELECT 1 FROM information_schema.tables "
                        "WHERE table_schema = %s AND table_name = %s LIMIT 1",
                        (schema_name, table),
                    )
                    return cursor.fetchone() is not None
                finally:
                    cursor.close()
        except Exception as e:  # noqa: BLE001 — see docstring
            logger.debug(f"table existence probe failed for {schema_name}.{table}: {e}")
            return False

    def get_table_info(self, table: str, tenant_id: str) -> TableInfo:
        """Get detailed metadata for a specific table.

        Args:
            table: Table name.
            tenant_id: Tenant identifier.

        Returns:
            TableInfo with schema, row count, column metadata.
        """
        self._ensure_connected()

        try:
            schema_name = self._get_schema_name(tenant_id)

            # ⚠️ GLOBAL reference tables (e.g. vm_cve_metadata) live once in `public`,
            # NOT in tenant_<uuid> — see _get_schema_name(scope="global"). Unlike the
            # read path, `get_table_info` qualifies every name with the tenant schema,
            # so a global table could never resolve here: it raised TableNotFoundError
            # while `SELECT * FROM <table>` succeeded via search_path. That asymmetry
            # made the Program_Blueprinter blind to KEV/EPSS on every build — it probed,
            # got "table not found", and silently fell back.
            #
            # Resolve by LOOKUP, not by a hardcoded name list, so any future global
            # table works without touching this method. The tenant schema is still
            # checked FIRST, so a tenant table always shadows a same-named global one
            # and no existing behaviour changes.
            if not self._table_in_schema(schema_name, table) and \
                    self._table_in_schema("public", table):
                schema_name = "public"

            with self._get_connection() as conn:
                cursor = conn.cursor()

                try:
                    # Get row count
                    count_sql = sql.SQL("SELECT COUNT(*) FROM {}.{}").format(
                        sql.Identifier(schema_name),
                        sql.Identifier(table)
                    )
                    cursor.execute(count_sql)
                    row_count = cursor.fetchone()[0]

                    # Get column info
                    cursor.execute("""
                        SELECT column_name, data_type, is_nullable
                        FROM information_schema.columns
                        WHERE table_schema = %s
                        AND table_name = %s
                        ORDER BY ordinal_position
                    """, (schema_name, table))
                    column_rows = cursor.fetchall()

                    columns = []
                    for col_row in column_rows:
                        columns.append(ColumnInfo(
                            name=col_row[0],
                            type=col_row[1],
                            nullable=col_row[2] == 'YES'
                        ))

                    return TableInfo(
                        name=table,
                        schema=schema_name,
                        table_type='BASE TABLE',
                        row_count=row_count,
                        columns=columns
                    )

                finally:
                    cursor.close()

        except Exception as e:
            logger.error(f"Get table info failed: {e}")
            raise TableNotFoundError(f"Table {table} not found: {e}") from e

    def text_to_sql(
        self,
        query: str,
        tenant_id: str,
        execute: bool = False
    ) -> Dict[str, Any]:
        """Convert natural language query to SQL using LLM.

        Note: This is a placeholder. Text-to-SQL should be implemented
        via pantheon-integration service with LLM integration.

        Args:
            query: Natural language query.
            tenant_id: Tenant identifier.
            execute: If True, execute the generated SQL.

        Returns:
            Dictionary with generated SQL and optional results.

        Raises:
            NotImplementedError: Always raised (use pantheon-integration).
        """
        raise NotImplementedError(
            "Text-to-SQL is not supported directly in PostgreSQLBackend. "
            "Use pantheon-integration service with LLM integration instead."
        )

    def health_check(self) -> bool:
        """Check if backend is healthy and connections are working.

        Returns:
            True if backend is healthy, False otherwise.
        """
        try:
            if not self._pool:
                return False

            with self._get_connection() as conn:
                cursor = conn.cursor()

                try:
                    cursor.execute("SELECT 1")
                    result = cursor.fetchone()
                    return result is not None and result[0] == 1

                finally:
                    cursor.close()

        except Exception as e:
            logger.warning(f"Health check failed: {e}")
            return False

    def create_schema(self, schema_name: str, tenant_id: Optional[str] = None) -> bool:
        """Create a database schema.

        Args:
            schema_name: Schema name to create.
            tenant_id: Optional tenant identifier.

        Returns:
            True if schema created, False if already exists.
        """
        self._ensure_connected()

        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()

                try:
                    cursor.execute(sql.SQL("CREATE SCHEMA IF NOT EXISTS {}").format(
                        sql.Identifier(schema_name)
                    ))
                    conn.commit()

                    logger.info(f"Created schema {schema_name}")
                    return True

                finally:
                    cursor.close()

        except Exception as e:
            logger.error(f"Schema creation failed: {e}")
            return False

    def drop_schema(self, schema_name: str, tenant_id: Optional[str] = None) -> bool:
        """Drop a database schema.

        Args:
            schema_name: Schema name to drop.
            tenant_id: Optional tenant identifier.

        Returns:
            True if schema dropped, False if doesn't exist.
        """
        self._ensure_connected()

        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()

                try:
                    cursor.execute(sql.SQL("DROP SCHEMA IF EXISTS {} CASCADE").format(
                        sql.Identifier(schema_name)
                    ))
                    conn.commit()

                    logger.info(f"Dropped schema {schema_name}")
                    return True

                finally:
                    cursor.close()

        except Exception as e:
            logger.error(f"Schema drop failed: {e}")
            return False

    def cleanup_tenant(self, tenant_id: str) -> Dict[str, Any]:
        """Clean up all tenant data by dropping tenant schemas.

        PostgreSQL uses schema-per-tenant isolation, so cleanup means dropping
        the tenant's source and transformers schemas with CASCADE.

        Args:
            tenant_id: Tenant UUID to clean up.

        Returns:
            Dict with cleanup results.
        """
        self._ensure_connected()

        dropped_schemas = []
        errors = []

        source_schema = self._get_schema_name(tenant_id, db_type='source')
        transformer_schema = self._get_schema_name(tenant_id, db_type='transformers')

        for schema_name in [source_schema, transformer_schema]:
            try:
                if self.drop_schema(schema_name):
                    dropped_schemas.append(schema_name)
                    logger.info(f"Dropped schema {schema_name} for tenant {tenant_id}")
                else:
                    # Schema might not exist, which is fine
                    logger.info(f"Schema {schema_name} did not exist for tenant {tenant_id}")
            except Exception as e:
                error_msg = f"Failed to drop schema {schema_name}: {str(e)}"
                errors.append(error_msg)
                logger.error(error_msg)

        return {
            'success': len(errors) == 0,
            'dropped_schemas': dropped_schemas,
            'dropped_tables': [],  # PostgreSQL drops tables via CASCADE
            'removed_files': [],
            'errors': errors
        }

    # Human-readable column to report as `name` for a row-level orphan, per sink
    # table. Falls back to the primary key when the table has no such column (or
    # when the column is absent from this particular tenant's schema).
    _ORPHAN_NAME_COLUMNS = {
        'identities': 'name',
        'repositories': 'name',
        'vulnerabilities': 'title',
        'assets': 'name',
        'datastores': 'name',
        'artifacts': 'name',
        'findings': 'title',
        'issues': 'title',
        'controls': 'name',
        'packages': 'name',
        'entity_edges': 'edge_type',
        'pentest_cases': 'name',
        'pentest_runs': 'name',
    }

    def _orphan_sink_tables(self) -> List[str]:
        """Sink tables scanned for row-level orphans.

        Sourced from the DatalakeTables enum so a new sink table is picked up
        automatically. Every sink table carries tenant_id via IAM_FIELDS.
        """
        from pantheon_shared.datalake.schemas.tables import DatalakeTables
        return [t.value for t in DatalakeTables]

    def _scan_schema_for_orphan_rows(
        self,
        cursor,
        schema_name: str,
        valid_tenant_set: set,
        tenant_id: Optional[str] = None,
        dry_run: bool = True,
    ) -> Tuple[List[Dict[str, Any]], List[str], int]:
        """Scan one SURVIVING tenant schema for rows with a dangling tenant_id.

        A row is orphaned when its tenant_id is not in valid_tenant_set — i.e. it
        references a tenant that no longer exists, even though the schema it
        lives in belongs to a tenant that does.

        Resilient by design: a sink table may not exist in a given schema (older
        tenants, partial initialization). Existence is checked against
        information_schema up front, so a missing table is skipped rather than
        aborting the scan. Any per-table failure is captured and the scan
        continues with the next table.

        Args:
            cursor: Open cursor to use for the scan.
            schema_name: The surviving tenant schema to scan.
            valid_tenant_set: Set of valid tenant UUIDs.
            tenant_id: Optional tenant id to NARROW results to.
            dry_run: When True, report only — never delete.

        Returns:
            Tuple of (orphaned_row_objects, errors, deleted_row_count).
        """
        orphaned_rows: List[Dict[str, Any]] = []
        errors: List[str] = []
        deleted_count = 0

        sink_tables = self._orphan_sink_tables()

        # One round trip: which of the sink tables actually exist in this schema,
        # and which columns each has. Everything else is driven off this map, so
        # a missing table or a missing name column can never raise.
        try:
            cursor.execute("""
                SELECT table_name, column_name
                FROM information_schema.columns
                WHERE table_schema = %s
                  AND table_name = ANY(%s)
            """, (schema_name, sink_tables))
            columns_by_table: Dict[str, set] = {}
            for row_table, row_column in cursor.fetchall():
                columns_by_table.setdefault(row_table, set()).add(row_column)
        except Exception as e:
            error_msg = f"Failed to introspect columns for schema {schema_name}: {str(e)}"
            errors.append(error_msg)
            logger.error(error_msg)
            return orphaned_rows, errors, deleted_count

        for table_name in sink_tables:
            columns = columns_by_table.get(table_name)

            # Table absent from this schema — skip, do not error.
            if not columns:
                logger.debug(f"Sink table {schema_name}.{table_name} not present; skipping row scan")
                continue

            # tenant_id is the orphan predicate. Without it there is nothing to test.
            if 'tenant_id' not in columns:
                logger.debug(f"Sink table {schema_name}.{table_name} has no tenant_id; skipping row scan")
                continue

            # Primary-key column for the reported `id`. Fall back to 'id' when the
            # conventional pk column is missing from this schema.
            pk_column = 'id' if 'id' in columns else None
            if pk_column is None:
                logger.debug(f"Sink table {schema_name}.{table_name} has no id column; skipping row scan")
                continue

            # Human-readable name column, when this schema actually has it.
            name_column = self._ORPHAN_NAME_COLUMNS.get(table_name)
            if name_column not in columns:
                name_column = pk_column

            try:
                # Identifiers are quoted via sql.Identifier (never interpolated);
                # values are bound as parameters.
                where_parts = [sql.SQL("{} IS NOT NULL").format(sql.Identifier('tenant_id'))]
                params: List[Any] = []

                if valid_tenant_set:
                    where_parts.append(
                        sql.SQL("NOT ({}::text = ANY(%s))").format(sql.Identifier('tenant_id'))
                    )
                    params.append(list(valid_tenant_set))

                # Scoped narrowing: the row must be BOTH orphaned AND belong to
                # the requested tenant.
                if tenant_id:
                    where_parts.append(
                        sql.SQL("{}::text = %s").format(sql.Identifier('tenant_id'))
                    )
                    params.append(tenant_id)

                where_clause = sql.SQL(" AND ").join(where_parts)

                select_stmt = sql.SQL(
                    "SELECT {pk}::text, {name}::text, {tenant}::text FROM {schema}.{table} WHERE {where}"
                ).format(
                    pk=sql.Identifier(pk_column),
                    name=sql.Identifier(name_column),
                    tenant=sql.Identifier('tenant_id'),
                    schema=sql.Identifier(schema_name),
                    table=sql.Identifier(table_name),
                    where=where_clause,
                )

                cursor.execute(select_stmt, params)
                rows = cursor.fetchall()

                for row_id, row_name, row_tenant in rows:
                    orphaned_rows.append({
                        # Canonical 4-field shape consumed by pantheon-admin's
                        # OrphanedObjectDetails. `type` is additive metadata.
                        'type': 'row',
                        'table': f"{schema_name}.{table_name}",
                        'id': row_id,
                        'name': row_name if row_name is not None else row_id,
                        'tenant_id': row_tenant,
                    })

                if rows:
                    logger.info(
                        f"Found {len(rows)} orphaned rows in {schema_name}.{table_name}"
                    )

                # Delete only when explicitly not a dry run.
                if rows and not dry_run:
                    delete_stmt = sql.SQL(
                        "DELETE FROM {schema}.{table} WHERE {where}"
                    ).format(
                        schema=sql.Identifier(schema_name),
                        table=sql.Identifier(table_name),
                        where=where_clause,
                    )
                    cursor.execute(delete_stmt, params)
                    deleted_count += cursor.rowcount or 0
                    logger.info(
                        f"Deleted {cursor.rowcount} orphaned rows from {schema_name}.{table_name}"
                    )

            except Exception as e:
                # One bad table must not abort the whole scan.
                error_msg = f"Row scan failed for {schema_name}.{table_name}: {str(e)}"
                errors.append(error_msg)
                logger.error(error_msg)
                continue

        return orphaned_rows, errors, deleted_count

    def cleanup_orphaned(
        self,
        valid_tenant_ids: List[str],
        tenant_id: Optional[str] = None,
        dry_run: bool = False,
    ) -> Dict[str, Any]:
        """Clean up orphaned schemas AND orphaned rows for deleted tenants.

        Two granularities are reported:

        1. SCHEMA-level — a whole tenant schema whose tenant no longer exists.
           Handles both split mode schemas (tenant_*_source, tenant_*_transformers)
           and unified mode schemas (tenant_*).
        2. ROW-level — rows inside a SURVIVING tenant's schema whose tenant_id
           references a tenant that no longer exists.

        Every reported object carries the canonical four keys consumed by
        pantheon-admin (`table`, `id`, `name`, `tenant_id`) plus an additive
        `type` key ('schema' or 'row') for callers that discriminate on it.

        Args:
            valid_tenant_ids: List of valid tenant UUIDs from pantheon-auth.
            tenant_id: Optional tenant id — NARROWS results to orphans belonging
                to this tenant, at both schema and row level.
            dry_run: When True, report orphans without dropping or deleting.

        Returns:
            Dict with cleanup results.
        """
        import re

        self._ensure_connected()

        orphaned_schemas = []
        dropped_schemas = []
        orphaned_objects: List[Dict[str, Any]] = []
        valid_schemas: List[str] = []
        errors = []
        deleted_rows = 0

        # Convert to set for faster lookup
        valid_tenant_set = set(valid_tenant_ids)

        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()

                try:
                    # Query for all schemas matching tenant_* pattern
                    # This includes both split mode (tenant_*_source, tenant_*_transformers)
                    # and unified mode (tenant_*) schemas
                    cursor.execute("""
                        SELECT schema_name
                        FROM information_schema.schemata
                        WHERE schema_name LIKE 'tenant_%%'
                        ORDER BY schema_name
                    """)

                    all_schemas = [row[0] for row in cursor.fetchall()]

                    # Patterns to match:
                    # Split mode: tenant_{uuid}_source or tenant_{uuid}_transformers
                    # Unified mode: tenant_{uuid} (but not matching split patterns)
                    split_pattern = re.compile(r'^tenant_([0-9a-f-]+)_(source|transformers)$')
                    unified_pattern = re.compile(r'^tenant_([0-9a-f-]+)$')

                    for schema_name in all_schemas:
                        # First check if it's a split mode schema
                        split_match = split_pattern.match(schema_name)
                        unified_match = None if split_match else unified_pattern.match(schema_name)
                        match = split_match or unified_match
                        if not match:
                            continue

                        schema_tenant_id = match.group(1)
                        kind = 'split' if split_match else 'unified'

                        if schema_tenant_id in valid_tenant_set:
                            # Surviving tenant — its schema is a row-scan target.
                            valid_schemas.append(schema_name)
                            continue

                        # Scoped run: only report the requested tenant's schema.
                        if tenant_id and schema_tenant_id != tenant_id:
                            continue

                        orphaned_schemas.append(schema_name)
                        orphaned_objects.append({
                            # A schema has no row id; the schema name IS its identity.
                            'type': 'schema',
                            'table': schema_name,
                            'id': schema_name,
                            'name': schema_name,
                            'tenant_id': schema_tenant_id,
                        })
                        logger.info(
                            f"Found orphaned {kind} schema: {schema_name} (tenant: {schema_tenant_id})"
                        )

                    # ROW-level scan across every SURVIVING tenant schema. A row
                    # whose tenant_id points at a deleted tenant is an orphan even
                    # though the schema hosting it is perfectly valid.
                    for schema_name in valid_schemas:
                        rows, row_errors, row_deleted = self._scan_schema_for_orphan_rows(
                            cursor,
                            schema_name,
                            valid_tenant_set,
                            tenant_id=tenant_id,
                            dry_run=dry_run,
                        )
                        orphaned_objects.extend(rows)
                        errors.extend(row_errors)
                        deleted_rows += row_deleted

                    if not dry_run:
                        conn.commit()

                    # Drop orphaned schemas (never during a dry run).
                    if not dry_run:
                        for schema_name in orphaned_schemas:
                            try:
                                if self.drop_schema(schema_name):
                                    dropped_schemas.append(schema_name)
                                    logger.info(f"Dropped orphaned schema: {schema_name}")
                                else:
                                    logger.warning(f"Failed to drop orphaned schema: {schema_name}")
                            except Exception as e:
                                error_msg = f"Failed to drop orphaned schema {schema_name}: {str(e)}"
                                errors.append(error_msg)
                                logger.error(error_msg)

                finally:
                    cursor.close()

        except Exception as e:
            error_msg = f"Error during orphaned cleanup: {str(e)}"
            errors.append(error_msg)
            logger.error(error_msg)

        return {
            'success': len(errors) == 0,
            'orphaned_schemas': orphaned_schemas,
            'dropped_schemas': dropped_schemas,
            'orphaned_files': [],  # PostgreSQL doesn't use files
            'removed_files': [],
            'orphaned_objects': orphaned_objects,
            'orphaned_rows': [o for o in orphaned_objects if o.get('type') == 'row'],
            'deleted_rows': deleted_rows,
            'errors': errors
        }

    def truncate_table(self, table: str, tenant_id: str) -> bool:
        """Truncate a table (remove all rows).

        Args:
            table: Table name.
            tenant_id: Tenant identifier.

        Returns:
            True if truncated successfully.
        """
        self._ensure_connected()

        try:
            schema_name = self._get_schema_name(tenant_id)

            with self._get_connection() as conn:
                cursor = conn.cursor()

                try:
                    truncate_sql = sql.SQL("TRUNCATE TABLE {}.{}").format(
                        sql.Identifier(schema_name),
                        sql.Identifier(table)
                    )
                    cursor.execute(truncate_sql)
                    conn.commit()

                    logger.info(f"Truncated table {schema_name}.{table}")
                    return True

                finally:
                    cursor.close()

        except Exception as e:
            logger.error(f"Table truncate failed: {e}")
            raise QueryError(f"Failed to truncate table {table}: {e}") from e

    def update_rows(
        self,
        table: str,
        tenant_id: str,
        set_clause: str,
        where: str,
        params: Optional[Dict[str, Any]] = None,
    ) -> int:
        """Apply a SET to rows matching a WHERE clause; commit and return rows updated.

        The UPDATE sibling of delete_rows, and the seam a caller needs when the
        correct action is to AMEND a row rather than remove it — e.g. stripping
        one contributor from a shared row's `contributing_sources` map, where
        deleting the row would destroy another integration's data.

        Mirrors delete_rows exactly: _get_connection(tenant_id) resolves the
        search_path to the tenant's schema (split or unified), the table is
        referenced unqualified, and the transaction is committed here (query()
        never commits and cannot run an UPDATE).

        Args:
            table: Table name (within the tenant's schema).
            tenant_id: Tenant identifier (scopes the search_path).
            set_clause: SQL SET body WITHOUT the leading "SET".
            where: SQL WHERE clause WITHOUT the leading "WHERE".
            params: Optional bind parameters.

        Returns:
            Number of rows updated.
        """
        self._ensure_connected()

        try:
            with self._get_connection(tenant_id) as conn:
                cursor = conn.cursor()
                try:
                    update_sql = (
                        sql.SQL("UPDATE {} SET ").format(
                            sql.Identifier(table)
                        ).as_string(conn) + set_clause + " WHERE " + where
                    )
                    cursor.execute(update_sql, params or {})
                    updated = cursor.rowcount
                    conn.commit()
                    logger.info(
                        f"Updated {updated} row(s) in {table} (tenant {tenant_id})"
                    )
                    return updated
                except Exception:
                    conn.rollback()
                    raise
                finally:
                    cursor.close()

        except Exception as e:
            logger.error(f"Filtered update failed for table {table}: {e}")
            raise QueryError(f"Failed to update rows in {table}: {e}") from e

    def _execute_write(
        self,
        statement: str,
        params: Optional[Dict[str, Any]] = None,
        tenant_id: Optional[str] = None,
        relations: Optional[Sequence[str]] = None,
    ) -> List[Dict[str, Any]]:
        """Execute a registry-generated write and return its RETURNING rows.

        **The decoration layer's write seam, and nothing else's.** The three
        existing methods provably cannot express the apply:

        * ``query()`` never commits and cannot run an UPDATE (its own docstring);
          it calls ``fetchall()`` unconditionally.
        * ``update_rows()`` concatenates ``UPDATE {table} SET … WHERE …`` with no
          slot for ``FROM (subquery)``, and returns ``rowcount`` — discarding the
          ``RETURNING`` the claim and the apply both depend on.
        * ``upsert()`` requires full rows; the apply amends columns of existing
          rows by join.

        This does NOT reopen the "no raw SQL on a private engine" rule: it goes
        *through* the same pool and the same ``_get_connection(tenant_id)``
        search_path routing that ``update_rows`` uses. The single-chokepoint
        property is preserved.

        **Scope is ENFORCED, not merely documented** — prose is not a boundary:

        * this method is underscore-private and deliberately **not** re-exported
          through ``DatalakeClient``'s public surface, so it is not reachable from
          another service;
        * ``relations`` must be supplied and every entry checked against the
          decoration allowlist (the registry's sink tables plus the three
          ``decoration_*`` tables). Anything else raises.

        Every statement it executes is built by the decoration generator from the
        registry — never from a caller-supplied string.

        Args:
            statement: The generated SQL.
            params: Bind parameters.
            tenant_id: Scopes the search_path, exactly as ``update_rows`` does.
            relations: The relations this statement writes. Required; validated.

        Returns:
            ``RETURNING`` rows as dicts, or ``[]`` when the statement returns none.

        Raises:
            ValidationError: if ``relations`` is missing or names a relation
                outside the decoration layer.
        """
        from pantheon_shared.datalake.decorations import (
            DECORATION_TABLES,
            DECORATIONS,
        )

        if not relations:
            raise ValidationError(
                "_execute_write requires `relations`: the allowlist is the "
                "enforcement boundary, so an unnamed target is refused"
            )

        # Catalog reads (information_schema / pg_catalog) are how the layer discovers
        # which tenant tables need the provenance columns. They are named explicitly
        # rather than waved through, so "this statement only inspects the catalog" is
        # a claim the allowlist checks instead of a comment nobody enforces.
        allowed = (
            set(DECORATION_TABLES)
            | {s.decorates for s in DECORATIONS.values()}
            | {"information_schema", "pg_catalog"}
        )
        disallowed = sorted(set(relations) - allowed)
        if disallowed:
            raise ValidationError(
                f"_execute_write refused relations {disallowed}: outside the "
                f"decoration layer. Allowed: {sorted(allowed)}"
            )

        self._ensure_connected()

        try:
            with self._get_connection(tenant_id) as conn:
                cursor = conn.cursor()
                try:
                    cursor.execute(statement, params or {})
                    rows: List[Dict[str, Any]] = []
                    # `description` is None for a statement with no RETURNING —
                    # calling fetchall() then raises, which is exactly why query()
                    # cannot be used for these writes.
                    if cursor.description is not None:
                        columns = [d[0] for d in cursor.description]
                        rows = [dict(zip(columns, r)) for r in cursor.fetchall()]
                    conn.commit()
                    return rows
                except Exception:
                    conn.rollback()
                    raise
                finally:
                    cursor.close()

        except Exception as e:
            logger.error(f"Decoration write failed on {list(relations)}: {e}")
            raise QueryError(f"Decoration write failed: {e}") from e

    def delete_rows(
        self,
        table: str,
        tenant_id: str,
        where: str,
        params: Optional[Dict[str, Any]] = None,
    ) -> int:
        """Delete rows matching a WHERE clause; commit and return rows deleted.

        Uses _get_connection(tenant_id) so the search_path resolves to the
        tenant's schema (handles both split and unified modes), then references
        the table unqualified — mirroring how query() reads from these tables.
        Commits the transaction (query() does not) and returns cursor.rowcount.

        Args:
            table: Table name (within the tenant's schema).
            tenant_id: Tenant identifier (scopes the search_path).
            where: SQL WHERE clause WITHOUT the leading "WHERE".
            params: Optional bind parameters for the WHERE clause.

        Returns:
            Number of rows deleted.
        """
        self._ensure_connected()

        try:
            with self._get_connection(tenant_id) as conn:
                cursor = conn.cursor()
                try:
                    delete_sql = sql.SQL("DELETE FROM {} WHERE ").format(
                        sql.Identifier(table)
                    ).as_string(conn) + where
                    cursor.execute(delete_sql, params or {})
                    deleted = cursor.rowcount
                    conn.commit()
                    logger.info(
                        f"Deleted {deleted} row(s) from {table} "
                        f"(tenant {tenant_id})"
                    )
                    return deleted
                except Exception:
                    conn.rollback()
                    raise
                finally:
                    cursor.close()

        except Exception as e:
            logger.error(f"Filtered delete failed for table {table}: {e}")
            raise QueryError(f"Failed to delete rows from {table}: {e}") from e

    @classmethod
    def from_env(cls) -> 'PostgreSQLBackend':
        """Create backend instance from environment variables.

        Environment variables:
            DATALAKE_POSTGRES_HOST: Database host (required)
            DATALAKE_POSTGRES_PORT: Database port (default: 5432)
            DATALAKE_POSTGRES_DATABASE: Database name (required)
            DATALAKE_POSTGRES_USER: Database user (required)
            DATALAKE_POSTGRES_PASSWORD: Database password (required)
            DATALAKE_POSTGRES_POOL_SIZE: Connection pool size (default: 10)

        Returns:
            Configured PostgreSQLBackend instance.

        Raises:
            ConfigurationError: If required environment variables are missing.
        """
        # Validate required environment variables
        missing_vars = []

        host = os.getenv('DATALAKE_POSTGRES_HOST')
        if not host:
            missing_vars.append('DATALAKE_POSTGRES_HOST')

        database = os.getenv('DATALAKE_POSTGRES_DATABASE')
        if not database:
            missing_vars.append('DATALAKE_POSTGRES_DATABASE')

        user = os.getenv('DATALAKE_POSTGRES_USER')
        if not user:
            missing_vars.append('DATALAKE_POSTGRES_USER')

        password = os.getenv('DATALAKE_POSTGRES_PASSWORD')
        if not password:
            missing_vars.append('DATALAKE_POSTGRES_PASSWORD')

        if missing_vars:
            raise ConfigurationError(
                f"Missing required environment variables for PostgreSQL backend: {', '.join(missing_vars)}"
            )

        # Get optional variables with defaults
        port = int(os.getenv('DATALAKE_POSTGRES_PORT', '5432'))
        pool_size = int(os.getenv('DATALAKE_POSTGRES_POOL_SIZE', '10'))

        config = ConnectionConfig(
            host=host,
            port=port,
            user=user,
            password=password,
            database=database,
            pool_size=pool_size
        )

        return cls(config)

    def __repr__(self) -> str:
        """String representation of backend."""
        return f"PostgreSQLBackend(host={self.config.host}, database={self.config.database})"
