"""
Snowflake backend implementation for the datalake.

This module provides a Snowflake-based backend using row-level security
for multi-tenancy. All tables must have a tenant_id column for isolation.
"""

import os
from typing import List, Dict, Any, Optional
import snowflake.connector

from pantheon_shared import get_logger
from pantheon_shared.datalake.base import DatalakeBackend
from pantheon_shared.datalake.types import (
    ConnectionConfig,
    QueryResult,
    UpsertResult,
    TableInfo,
    ColumnInfo
)
from pantheon_shared.datalake.exceptions import (
    ConnectionError as DatalakeConnectionError,
    QueryError,
    ConfigurationError,
    TableNotFoundError,
    ValidationError
)

logger = get_logger(__name__)


class SnowflakeBackend(DatalakeBackend):
    """Snowflake backend implementation using row-level security for multi-tenancy.

    Multi-tenancy model:
    - Single shared database/schema for all tenants
    - Row-level filtering via tenant_id column
    - All queries automatically include WHERE tenant_id = ? clause

    Environment variables:
        SNOWFLAKE_ACCOUNT: Snowflake account identifier (required)
        SNOWFLAKE_USER: Database user (required)
        SNOWFLAKE_PASSWORD: Database password (required)
        SNOWFLAKE_WAREHOUSE: Virtual warehouse (required)
        SNOWFLAKE_DATABASE: Database name (required)
        SNOWFLAKE_SCHEMA: Schema name (default: 'PUBLIC')

    ConnectionConfig mapping:
        host -> Snowflake account
        database -> Snowflake warehouse
        schema -> Snowflake database (additional mapping needed)
    """

    def __init__(self, config: ConnectionConfig, snowflake_database: Optional[str] = None):
        """Initialize Snowflake backend.

        Args:
            config: Connection configuration.
            snowflake_database: Snowflake database name (separate from warehouse).
        """
        self.config = config
        self._snowflake_database = snowflake_database
        self._connection: Optional[snowflake.connector.SnowflakeConnection] = None
        self._current_tenant: Optional[str] = None

    def connect(self, tenant_id: Optional[str] = None) -> bool:
        """Establish connection to Snowflake.

        Args:
            tenant_id: Optional tenant identifier for multi-tenancy context.

        Returns:
            True if connection successful, False otherwise.
        """
        try:
            self._connection = snowflake.connector.connect(
                user=self.config.user,
                password=self.config.password,
                account=self.config.host,
                warehouse=self.config.database,  # warehouse stored in database field
                database=self._snowflake_database or os.getenv('SNOWFLAKE_DATABASE', 'torana_datalake'),
                schema=self.config.schema or os.getenv('SNOWFLAKE_SCHEMA', 'PUBLIC')
            )

            if tenant_id:
                self._current_tenant = tenant_id

            logger.info(f"Connected to Snowflake account {self.config.host}")
            return True

        except Exception as e:
            logger.error(f"Failed to connect to Snowflake: {e}")
            raise DatalakeConnectionError(f"Connection failed: {e}") from e

    def disconnect(self) -> None:
        """Close connection and cleanup resources."""
        if self._connection:
            try:
                self._connection.close()
            except Exception as e:
                logger.warning(f"Error closing connection: {e}")
            finally:
                self._connection = None
                self._current_tenant = None

    def _ensure_connected(self) -> None:
        """Ensure backend is connected.

        Raises:
            DatalakeConnectionError: If not connected.
        """
        if not self._connection:
            raise DatalakeConnectionError("Not connected to Snowflake")

    def _inject_tenant_filter(self, sql: str, tenant_id: str) -> str:
        """Inject tenant_id filter into SQL query for row-level security.

        Args:
            sql: SQL query string.
            tenant_id: Tenant identifier.

        Returns:
            SQL query with tenant_id filter added.
        """
        sql = sql.strip()

        # Don't modify if already has tenant filter
        if 'tenant_id' in sql.lower():
            return sql

        # Basic injection for SELECT queries
        if sql.upper().startswith('SELECT'):
            # Find WHERE clause or add one
            if ' WHERE ' in sql.upper():
                # Append to existing WHERE
                return f"{sql} AND tenant_id = '{tenant_id}'"
            else:
                # Add WHERE clause before GROUP BY, ORDER BY, LIMIT, etc.
                clauses = ['GROUP BY', 'ORDER BY', 'LIMIT', 'OFFSET', 'HAVING']
                for clause in clauses:
                    if clause in sql.upper():
                        idx = sql.upper().index(clause)
                        return f"{sql[:idx]} WHERE tenant_id = '{tenant_id}' {sql[idx:]}"
                # No clauses found, append at end
                return f"{sql} WHERE tenant_id = '{tenant_id}'"

        return sql

    def query(self, sql: str, tenant_id: str, params: Optional[Dict[str, Any]] = None) -> QueryResult:
        """Execute a read-only SQL query.

        Args:
            sql: SQL query string.
            tenant_id: Tenant identifier for scoping.
            params: Optional query parameters.

        Returns:
            QueryResult with columns, rows, and metadata.
        """
        self._ensure_connected()

        try:
            # Inject tenant filter for row-level security
            filtered_sql = self._inject_tenant_filter(sql, tenant_id)

            cursor = self._connection.cursor()

            try:
                if params:
                    cursor.execute(filtered_sql, params)
                else:
                    cursor.execute(filtered_sql)

                # Get column names
                if cursor.description:
                    columns = [desc[0] for desc in cursor.description]
                else:
                    columns = []

                # Fetch all rows
                rows = cursor.fetchall()

                return QueryResult(
                    columns=columns,
                    rows=rows,
                    row_count=len(rows)
                )

            finally:
                cursor.close()

        except Exception as e:
            logger.error(f"Query execution failed: {e}")
            raise QueryError(f"Query failed: {e}") from e

    def insert(self, table: str, data: List[Dict[str, Any]], tenant_id: str) -> UpsertResult:
        """Bulk insert records into a table.

        Args:
            table: Table name.
            data: List of records to insert.
            tenant_id: Tenant identifier.

        Returns:
            UpsertResult with count of inserted records.
        """
        self._ensure_connected()

        if not data:
            return UpsertResult(success=True, inserted=0, updated=0)

        try:
            cursor = self._connection.cursor()

            try:
                # Get column names from first record
                columns = list(data[0].keys())

                # Add tenant_id if not present
                if 'tenant_id' not in columns:
                    columns.append('tenant_id')

                # Build INSERT statement
                placeholders = ', '.join(['%s'] * len(columns))
                insert_sql = f"INSERT INTO {table} ({', '.join(columns)}) VALUES ({placeholders})"

                # Prepare data with tenant_id
                rows = []
                for record in data:
                    row = [record.get(col) for col in data[0].keys()]
                    if 'tenant_id' not in data[0]:
                        row.append(tenant_id)
                    rows.append(tuple(row))

                # Execute batch insert
                cursor.executemany(insert_sql, rows)
                self._connection.commit()

                inserted = cursor.rowcount
                logger.info(f"Inserted {inserted} records into {table}")

                return UpsertResult(success=True, inserted=inserted, updated=0)

            except Exception as e:
                self._connection.rollback()
                raise
            finally:
                cursor.close()

        except Exception as e:
            logger.error(f"Insert failed: {e}")
            raise QueryError(f"Insert into {table} failed: {e}") from e

    def upsert(
        self,
        table: str,
        data: List[Dict[str, Any]],
        primary_key: str,
        tenant_id: str,
        preserve_columns: Optional[List[str]] = None,
    ) -> UpsertResult:
        """Insert or update records using MERGE statement.

        Args:
            table: Table name.
            data: List of records to upsert.
            primary_key: Primary key column name.
            tenant_id: Tenant identifier.

        Returns:
            UpsertResult with counts of inserted/updated records.
        """
        self._ensure_connected()

        if not data:
            return UpsertResult(success=True, inserted=0, updated=0)

        try:
            cursor = self._connection.cursor()

            try:
                # Get column names
                columns = list(data[0].keys())

                # Add tenant_id if not present
                if 'tenant_id' not in columns:
                    columns.append('tenant_id')

                # Create temporary table
                temp_table = f"{table}_temp_{os.getpid()}_{id(object())}"
                create_temp_sql = f"CREATE TEMPORARY TABLE {temp_table} ({', '.join(columns)})"
                cursor.execute(create_temp_sql)

                # Build INSERT for temp table
                placeholders = ', '.join(['%s'] * len(columns))
                insert_temp_sql = f"INSERT INTO {temp_table} ({', '.join(columns)}) VALUES ({placeholders})"

                # Prepare data with tenant_id
                rows = []
                for record in data:
                    row = [record.get(col) for col in data[0].keys()]
                    if 'tenant_id' not in data[0]:
                        row.append(tenant_id)
                    rows.append(tuple(row))

                cursor.executemany(insert_temp_sql, rows)

                # Build MERGE statement. Exclude preserve_columns from the
                # WHEN MATCHED UPDATE SET so existing rows keep their value.
                _preserve = set(preserve_columns or ())
                update_columns = [
                    col for col in columns
                    if col != primary_key and col not in _preserve
                ]
                set_clause = ', '.join([f"target.{col} = source.{col}" for col in update_columns])
                insert_values = ', '.join([f"source.{col}" for col in columns])

                merge_sql = f"""
                    MERGE INTO {table} AS target
                    USING {temp_table} AS source
                    ON target.{primary_key} = source.{primary_key} AND target.tenant_id = source.tenant_id
                    WHEN MATCHED THEN
                        UPDATE SET {set_clause}
                    WHEN NOT MATCHED THEN
                        INSERT ({', '.join(columns)})
                        VALUES ({insert_values})
                """

                cursor.execute(merge_sql)

                # Get rowcount (Snowflake doesn't return exact counts for MERGE)
                rows_affected = cursor.rowcount

                # Drop temp table
                cursor.execute(f"DROP TABLE {temp_table}")

                self._connection.commit()

                logger.info(f"Upserted {rows_affected} records into {table}")

                # Snowflake MERGE doesn't distinguish inserts vs updates accurately
                return UpsertResult(success=True, inserted=rows_affected, updated=0)

            except Exception as e:
                self._connection.rollback()
                raise
            finally:
                cursor.close()

        except Exception as e:
            logger.error(f"Upsert failed: {e}")
            raise QueryError(f"Upsert into {table} failed: {e}") from e

    def create_table(self, table: str, schema: Dict[str, Any], tenant_id: str) -> bool:
        """Create a table with the specified schema.

        Args:
            table: Table name.
            schema: Dictionary mapping column names to schema definitions.
                Can be simple type strings: {"id": "UUID", "name": "VARCHAR"}
                Or rich dicts: {"id": {"data_type": "UUID", "primary_key": True}}
            tenant_id: Tenant identifier (for logging only).

        Returns:
            True if table created successfully.
        """
        self._ensure_connected()

        try:
            cursor = self._connection.cursor()

            try:
                # Ensure tenant_id column is included (for backwards compatibility)
                # Note: Rich schemas from TableSchema already include tenant_id
                if 'tenant_id' not in schema:
                    schema = dict(schema)  # Make a copy to avoid mutating original
                    schema['tenant_id'] = 'VARCHAR'

                # Build column definitions with support for rich schema metadata
                columns = []
                for col_name, col_def in schema.items():
                    # Handle both simple type string and rich dict definitions
                    if isinstance(col_def, dict):
                        # Rich schema definition with metadata
                        col_type = col_def.get('data_type', 'VARCHAR')
                        is_primary_key = col_def.get('primary_key', False)
                        is_not_null = col_def.get('not_null', False)
                    else:
                        # Simple type string (backwards compatibility)
                        col_type = col_def
                        is_primary_key = False
                        is_not_null = False

                    # Build column definition
                    col_sql = f"{col_name} {col_type}"

                    # Add PRIMARY KEY constraint if specified
                    if is_primary_key:
                        col_sql += ' PRIMARY KEY'
                    # Add NOT NULL constraint if specified (but not if already PRIMARY KEY)
                    elif is_not_null:
                        col_sql += ' NOT NULL'

                    columns.append(col_sql)

                create_sql = f"CREATE TABLE IF NOT EXISTS {table} ({', '.join(columns)})"
                cursor.execute(create_sql)

                self._connection.commit()
                logger.info(f"Created table {table}")

                return True

            finally:
                cursor.close()

        except Exception as e:
            logger.error(f"Table creation failed: {e}")
            raise QueryError(f"Failed to create table {table}: {e}") from e

    def drop_table(self, table: str, tenant_id: str) -> bool:
        """Drop a table.

        Args:
            table: Table name.
            tenant_id: Tenant identifier (for logging only).

        Returns:
            True if table dropped successfully.
        """
        self._ensure_connected()

        try:
            cursor = self._connection.cursor()

            try:
                drop_sql = f"DROP TABLE IF EXISTS {table}"
                cursor.execute(drop_sql)

                self._connection.commit()
                logger.info(f"Dropped table {table}")

                return True

            finally:
                cursor.close()

        except Exception as e:
            logger.error(f"Table drop failed: {e}")
            raise QueryError(f"Failed to drop table {table}: {e}") from e

    def table_exists(self, table: str, tenant_id: str) -> bool:
        """Check if a table exists.

        Args:
            table: Table name.
            tenant_id: Tenant identifier (unused in Snowflake).

        Returns:
            True if table exists, False otherwise.
        """
        self._ensure_connected()

        try:
            cursor = self._connection.cursor()

            try:
                schema = self.config.schema or os.getenv('SNOWFLAKE_SCHEMA', 'PUBLIC')
                check_sql = """
                    SELECT COUNT(*)
                    FROM INFORMATION_SCHEMA.TABLES
                    WHERE TABLE_SCHEMA = %s
                    AND TABLE_NAME = %s
                """
                cursor.execute(check_sql, (schema.upper(), table.upper()))
                result = cursor.fetchone()

                return result[0] > 0 if result else False

            finally:
                cursor.close()

        except Exception as e:
            logger.error(f"Table existence check failed: {e}")
            return False

    def list_tables(self, tenant_id: str, db_type: Optional[str] = None) -> List[TableInfo]:
        """List all tables accessible to the tenant.

        Args:
            tenant_id: Tenant identifier (ignored for Snowflake).
            db_type: Optional database type filter ('source', 'transformers', or 'all').
                    Note: Snowflake uses a single shared database, so 'all' returns
                    the same result as 'source' or 'transformers'.

        Returns:
            List of TableInfo objects.
        """
        self._ensure_connected()

        try:
            cursor = self._connection.cursor()

            try:
                schema = self.config.schema or os.getenv('SNOWFLAKE_SCHEMA', 'PUBLIC')
                list_sql = """
                    SELECT TABLE_NAME, TABLE_TYPE
                    FROM INFORMATION_SCHEMA.TABLES
                    WHERE TABLE_SCHEMA = %s
                    AND TABLE_TYPE = 'BASE TABLE'
                    ORDER BY TABLE_NAME
                """
                cursor.execute(list_sql, (schema.upper(),))
                rows = cursor.fetchall()

                tables = []
                for row in rows:
                    tables.append(TableInfo(
                        name=row[0],
                        schema=schema,
                        table_type=row[1],
                        row_count=0  # Would require separate query per table
                    ))

                return tables

            finally:
                cursor.close()

        except Exception as e:
            logger.error(f"List tables failed: {e}")
            return []

    def get_table_info(self, table: str, tenant_id: str) -> TableInfo:
        """Get detailed metadata for a specific table.

        Args:
            table: Table name.
            tenant_id: Tenant identifier.

        Returns:
            TableInfo with schema, row count, column metadata.
        """
        self._ensure_connected()

        try:
            cursor = self._connection.cursor()

            try:
                schema = self.config.schema or os.getenv('SNOWFLAKE_SCHEMA', 'PUBLIC')

                # Get row count
                count_sql = f"SELECT COUNT(*) FROM {table}"
                filtered_count_sql = self._inject_tenant_filter(count_sql, tenant_id)
                cursor.execute(filtered_count_sql)
                row_count = cursor.fetchone()[0]

                # Get column info
                columns_sql = """
                    SELECT COLUMN_NAME, DATA_TYPE, IS_NULLABLE
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE TABLE_SCHEMA = %s
                    AND TABLE_NAME = %s
                    ORDER BY ORDINAL_POSITION
                """
                cursor.execute(columns_sql, (schema.upper(), table.upper()))
                column_rows = cursor.fetchall()

                columns = []
                for col_row in column_rows:
                    columns.append(ColumnInfo(
                        name=col_row[0],
                        type=col_row[1],
                        nullable=col_row[2] == 'YES'
                    ))

                return TableInfo(
                    name=table,
                    schema=schema,
                    table_type='BASE TABLE',
                    row_count=row_count,
                    columns=columns
                )

            finally:
                cursor.close()

        except Exception as e:
            logger.error(f"Get table info failed: {e}")
            raise TableNotFoundError(f"Table {table} not found: {e}") from e

    def text_to_sql(
        self,
        query: str,
        tenant_id: str,
        execute: bool = False
    ) -> Dict[str, Any]:
        """Convert natural language query to SQL using LLM.

        Note: This is a placeholder. Snowflake Cortex integration should be
        done via pantheon-integration service.

        Args:
            query: Natural language query.
            tenant_id: Tenant identifier.
            execute: If True, execute the generated SQL.

        Returns:
            Dictionary with generated SQL and optional results.

        Raises:
            NotImplementedError: Always raised (use pantheon-integration).
        """
        raise NotImplementedError(
            "Text-to-SQL is not supported directly in SnowflakeBackend. "
            "Use pantheon-integration service with Snowflake Cortex instead."
        )

    def health_check(self) -> bool:
        """Check if backend is healthy and connections are working.

        Returns:
            True if backend is healthy, False otherwise.
        """
        try:
            if not self._connection:
                return False

            cursor = self._connection.cursor()

            try:
                cursor.execute("SELECT 1")
                result = cursor.fetchone()
                return result is not None and result[0] == 1

            finally:
                cursor.close()

        except Exception as e:
            logger.warning(f"Health check failed: {e}")
            return False

    def create_schema(self, schema_name: str, tenant_id: Optional[str] = None) -> bool:
        """Create a database schema.

        Args:
            schema_name: Schema name to create.
            tenant_id: Optional tenant identifier (unused).

        Returns:
            True if schema created, False if already exists.
        """
        self._ensure_connected()

        try:
            cursor = self._connection.cursor()

            try:
                create_sql = f"CREATE SCHEMA IF NOT EXISTS {schema_name}"
                cursor.execute(create_sql)
                self._connection.commit()

                logger.info(f"Created schema {schema_name}")
                return True

            finally:
                cursor.close()

        except Exception as e:
            logger.error(f"Schema creation failed: {e}")
            return False

    def drop_schema(self, schema_name: str, tenant_id: Optional[str] = None) -> bool:
        """Drop a database schema.

        Args:
            schema_name: Schema name to drop.
            tenant_id: Optional tenant identifier (unused).

        Returns:
            True if schema dropped, False if doesn't exist.
        """
        self._ensure_connected()

        try:
            cursor = self._connection.cursor()

            try:
                drop_sql = f"DROP SCHEMA IF EXISTS {schema_name}"
                cursor.execute(drop_sql)
                self._connection.commit()

                logger.info(f"Dropped schema {schema_name}")
                return True

            finally:
                cursor.close()

        except Exception as e:
            logger.error(f"Schema drop failed: {e}")
            return False

    def truncate_table(self, table: str, tenant_id: str) -> bool:
        """Truncate a table (remove all rows).

        Args:
            table: Table name.
            tenant_id: Tenant identifier.

        Returns:
            True if truncated successfully.
        """
        self._ensure_connected()

        try:
            cursor = self._connection.cursor()

            try:
                # Snowflake TRUNCATE with tenant filter
                truncate_sql = f"TRUNCATE TABLE {table}"
                cursor.execute(truncate_sql)
                self._connection.commit()

                logger.info(f"Truncated table {table}")
                return True

            finally:
                cursor.close()

        except Exception as e:
            logger.error(f"Table truncate failed: {e}")
            raise QueryError(f"Failed to truncate table {table}: {e}") from e

    @classmethod
    def from_env(cls) -> 'SnowflakeBackend':
        """Create backend instance from environment variables.

        Returns:
            Configured SnowflakeBackend instance.

        Raises:
            ConfigurationError: If required environment variables are missing.
        """
        account = os.getenv('SNOWFLAKE_ACCOUNT')
        user = os.getenv('SNOWFLAKE_USER')
        password = os.getenv('SNOWFLAKE_PASSWORD')
        warehouse = os.getenv('SNOWFLAKE_WAREHOUSE')
        database = os.getenv('SNOWFLAKE_DATABASE')

        missing = []
        if not account:
            missing.append('SNOWFLAKE_ACCOUNT')
        if not user:
            missing.append('SNOWFLAKE_USER')
        if not password:
            missing.append('SNOWFLAKE_PASSWORD')
        if not warehouse:
            missing.append('SNOWFLAKE_WAREHOUSE')
        if not database:
            missing.append('SNOWFLAKE_DATABASE')

        if missing:
            raise ConfigurationError(
                f"Missing required Snowflake environment variables: {', '.join(missing)}"
            )

        config = ConnectionConfig(
            host=account,
            port=443,
            user=user,
            password=password,
            database=warehouse,  # warehouse stored in database field
            schema=os.getenv('SNOWFLAKE_SCHEMA', 'PUBLIC'),
            pool_size=10
        )

        return cls(config, snowflake_database=database)

    def __repr__(self) -> str:
        """String representation of backend."""
        return f"SnowflakeBackend(account={self.config.host})"
