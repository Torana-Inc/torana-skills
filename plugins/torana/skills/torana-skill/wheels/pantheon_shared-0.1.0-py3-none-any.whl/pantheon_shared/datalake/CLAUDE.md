# `pantheon_shared.datalake` — the shared datalake library

Schema definitions, the reachability/supply model, the write seam, value domains, and the
backend adapters every service reads the datalake through.

## ⭐ WHICH LAYER WRITES WHICH COLUMN — the answer is `reachability.py`, and it is DERIVED

> ⛔ **[`reachability.py`](reachability.py) IS THE SINGLE SOURCE OF TRUTH for "which layer
> writes which column" (ETL vs policy/decoration vs action/user).** There is **no central
> data file** holding this — the map is **COMPUTED** by parsing the real writers.

It builds `(table, column) → [Writer]`, where each `Writer` carries its mechanism, its
integration, and where it came from. **Eight mechanisms**, and they are what map onto the
layers a reader usually has in mind:

| # | Mechanism | Layer | Where the truth actually lives | Maintenance |
|---|---|---|---|---|
| 1 | `mapping` | **ETL** | `pantheon-integration/torana_mesh/mappings/<family>/*.yaml` | ✅ parsed from YAML |
| 2 | `operator` | **ETL** | `torana_mesh/etl/operators/*.py` | ⛔ **HAND-MAINTAINED** in `reachability.py` |
| 3 | `decoration` | **policy / domain vocabulary** | `pantheon_shared.datalake.decorations.DECORATIONS` | ✅ read from the registry |
| 4 | `system` | platform-injected | [`schemas/system_fields.py`](schemas/system_fields.py) | ✅ injected per table |
| 5 | `ingestor` | **ETL** (push) | `torana_mesh/etl/ingestors/*.py` | ⛔ **HAND-MAINTAINED** |
| 6 | `extractor` | **ETL** (composed) | `etl/extractors/*.py`, `services/*.py` | ⛔ **HAND-MAINTAINED** |
| 7 | *validate-passthrough* | — | nothing declares it | ⚠️ statically underivable |
| 8 | `declared` | **action / user** | [`write_seam.py`](write_seam.py) `register_writer()` **at the write site** | ✅ imported |

⭐ **Adding an out-of-band writer (mechanism 8) needs NO edit here.** Call
`register_writer()` at the write site; `reachability.py` imports the registry, so the column
appears in `--reachable` automatically.

⛔ **Mechanisms 2, 5 and 6 are the exception, and they are a live drift risk.** They are
hand-written lists inside `reachability.py` (see its MAINTENANCE CONTRACT). Add an ETL
operator, push ingestor or extractor that writes a new column and **nothing detects it** —
the column reports unreachable until someone edits the list.

⚠️ **Mechanism 1 is not a `target:` grep.** Five op types write columns and each writes them
from a different part of the step (`set` writes its param *keys*; `rename` writes the param
*values*). A single regex is wrong five ways. `unpack` is statically unknowable.

### Query it — do not re-derive it

```bash
TORANA_PROFILE=T2 torana datalake supply column vulnerabilities.severity  # one column + provenance
TORANA_PROFILE=T2 torana datalake supply columns --group-by writer_kind   # distribution by mechanism
TORANA_PROFILE=T2 torana datalake supply columns --unreachable            # what NOTHING writes
TORANA_PROFILE=T2 torana datalake supply graph --format json              # the whole graph
```

`--writer-kind` takes exactly the mechanism names above.

### Two things a reader gets wrong

⚠️ **`reachable=False` is an UPPER BOUND on unreachability, never proof.** 99 of 102
mappings default `validate.on_extra_field=keep`, so a vendor field whose name matches a
column is written with no pipeline step naming it. `reachable=True` is definite;
`reachable=False` means "no writer found by this parse".

⚠️ **Scope changes the answer, and merging the two destroys the signal.** `--scope platform`
= could **any** shipped integration write it (owner: platform engineering). `--scope tenant`
= can **this** customer's connected tools write it (owner: customer success). A column can be
platform-reachable and tenant-unreachable — that is `PEER_GAP`, not a schema defect.

⚠️ **`reachable` ≠ `populated`.** Reachable = a pipeline exists. Populated = data landed.

## ⛔ Changed what SQL AUTHORS are told? Update the skills that teach it

`query-hints` (joins, cardinality, `entity_edges` edge types) and the reachability payload are
the GROUNDING every SQL author reads. Platform agents get it injected
(`agent-builder/src/utils/schema_context_injector.py`); Claude sessions get it from the skills
that name the command — `torana-text-to-sql`, `torana-app-bundle`, `torana-domain-corpus`.
Add a layer or change a payload's shape and those three go stale silently: the SQL still
parses and answers a different question.

## Related

- [`schemas/CLAUDE.md`](schemas/CLAUDE.md) — where a column is added/changed/removed
- [`../../../../pantheon-datalake/CLAUDE.md`](../../../../pantheon-datalake/CLAUDE.md) — service-side reachability rules + the corpus revalidation gate
