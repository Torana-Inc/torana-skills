from typing import Dict, Any
from .base import TableSchema


class VulnerabilitySchema(TableSchema):
    """Schema definition for the vulnerabilities table."""

    @property
    def table_name(self) -> str:
        return "vulnerabilities"

    @property
    def primary_key(self) -> str:
        return "torana_vulnerability_id"

    @property
    def description(self) -> str:
        return "Security vulnerabilities from scanning tools with CVSS scores, severity ratings, exploitability data, and remediation status"

    @property
    def category(self) -> str:
        return "Security Data"

    @property
    def timestamp_column(self) -> str:
        """Return the timestamp column for this table."""
        return "updated_at"

    @property
    def schema(self) -> Dict[str, Any]:
        return {
            # ⛔ TEXT, not VARCHAR(n): the key embeds an image ref + a purl, and the purl has
            # no length bound — 255 silently dropped real CVEs (datalake s18_0007, P1 2026-09-18).
            "torana_vulnerability_id": {"data_type": "TEXT", "primary_key": True, "category": "Core Identity",
                "semantic_description": (
                    "Torana's stable id for one finding — one CVE on one entity from one "
                    "scanner. Two scanners reporting the same CVE on the same image produce two "
                    "rows, which is why deduplication is a real step and not an accident."
                ),
            },
            "torana_entity_id": {"data_type": "VARCHAR(255)", "category": "Core Identity",
                "semantic_description": (
                    "The thing the vulnerability was found ON — an image, host or cloud "
                    "resource. This is the join to assets, and the key governance (owner, "
                    "criticality, exposure) is inherited through."
                ),
            },
            "torana_repository_id": {"data_type": "VARCHAR(255)", "category": "Core Identity",
                "semantic_description": (
                    "Foreign key to the source REPOSITORY, when the finding came from code or from an image "
                    "built out of one. ⚠️ Empty for findings on infrastructure that has no repo, and a "
                    "foreign key rather than this table's own identity."
                ),
            },
            "torana_artifact_id": {"data_type": "TEXT", "category": "Core Identity",
                "semantic_description": (
                    "The build artifact (container image, package build) the finding sits in. "
                    "Distinct from the entity: one artifact can be deployed as many running "
                    "entities."
                ),
            },
            "torana_issue_id": {"data_type": "VARCHAR(255)", "category": "Core Identity",
                "semantic_description": (
                    "Foreign key to the TICKET tracking remediation of this vulnerability, once one exists. "
                    "⛔ Empty means nobody has opened work for this finding — a different state from 'open "
                    "and being worked', and the two must not be conflated in a backlog count."
                ),
            },
            # Triage-decision provenance — who decided, via which alert, and when.
            # NOT written by any scanner. decided_by_actor_type / decided_at are stamped by
            # `torana vulnerability <ID> triage` (T-48). decided_via_alert_id has NO writer:
            # its only producer, the detection-framework triage write-back, was removed in
            # 91ef01d (Phase 3 § 4.6: the decision lives on the alert item). Original design:
            # pantheon-detection-framework docs/TRIAGE_VERDICT_WRITEBACK.md.
            "decided_via_alert_id": {"data_type": "VARCHAR(36)", "category": "Status & Assessment",
                "semantic_description": (
                    "The alert whose triage verdict set this row's decision columns. "
                    "⛔ NOTHING WRITES THIS: the alert decision stays on the alert and is not copied "
                    "onto the finding, so this column is empty on every row. Empty does NOT mean no "
                    "alert was raised. To relate a finding to its alerts, join the alerts store on "
                    "the finding key instead."
                ),
            },
            "decided_by_actor_type": {"data_type": "VARCHAR(20)", "category": "Status & Assessment",
                "semantic_description": (
                    "Whether a PERSON, the triage AGENT, or a platform RULE set this row's verdict. "
                    "Distinct from ASSIGNED_TO, which names who owns the work rather than what kind "
                    "of actor decided. ⚠️ NULL means no recorded decision — note that the triage "
                    "boolean columns can also be set by scanner mappings, so a row with "
                    "IS_RISK_ACCEPTED true and this column NULL was decided IN THE SOURCE SYSTEM (an "
                    "alert dismissed there, or a scanner default), and the platform holds no record "
                    "of who decided or why. Filter on this column to answer 'what was decided on "
                    "the platform'."
                ),
            },
            "decided_at": {"data_type": "TIMESTAMP", "category": "Status & Assessment",
                "semantic_description": (
                    "When the verdict that set this row's decision columns was reached. "
                    "⛔ NOT the same as UPDATED_AT, which moves on every write including every "
                    "scanner sync — measured, 1,872 of 1,892 rows shared a single UPDATED_AT day. "
                    "⛔ NOT the same as VULNERABILITY_RESOLUTION_DATE, which is when the finding was "
                    "FIXED. With the alert's own creation time this gives time-to-decide; it is also "
                    "the monotonic guard that stops an out-of-order verdict overwriting a newer one."
                ),
            },
            # Asset-graph (AG0 § 3.3.2): SCA-vuln attach point to a packages row
            # (pkg:<purl>). Additive, nullable; populating producer is AG1.
            "torana_package_id": {"data_type": "VARCHAR(512)", "category": "Core Identity",
                "semantic_description": (
                    "For dependency findings, the third-party package this affects "
                    "(pkg:<purl>). The bridge from a CVE to the shared library it lives in, so "
                    "one package upgrade can be traced across every finding it closes."
                ),
            },
            "source_system_id": {"data_type": "VARCHAR(255)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "The VULNERABILITY's id in the scanner that reported it, kept verbatim so the finding "
                    "can be opened in that tool. ⛔ Not unique across scanners — two scanners can emit the "
                    "same id for different flaws — so it is never a join key. ⚠️ Same column name on four "
                    "other tables, each holding its own entity's source id."
                ),
            },
            "source_system": {"data_type": "VARCHAR(100)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "The integration or internal producer that reported this vulnerability row. ⚠️ "
                    "Determines which other columns are populated at all, since sources differ in what they "
                    "expose, and it is the first thing to check when two rows describe the same "
                    "vulnerability differently."
                ),
            },
            "cloud_account_id": {"data_type": "VARCHAR(100)", "category": "Cloud Provider-Specific Fields",
                "semantic_description": (
                    "The cloud account or subscription this row belongs to — a GCP project id, an "
                    "AWS account number, an Azure subscription. Often the real boundary between "
                    "teams or environments, so it is the natural grouping for 'show me X by "
                    "account'. ⚠️ NOT a Jira project and NOT a logical/product grouping: those "
                    "are separate concepts (see issues.project_key and the governance properties). "
                    "On a vulnerability it is the account of the image or resource the finding was "
                    "raised on (GCP Container Analysis and Security Command Center, AWS Inspector); "
                    "one row per finding, so it groups findings by the account that holds the "
                    "affected thing. NULL for findings from code and repository scanners."
                ),
            },
            "cloud_provider": {"data_type": "VARCHAR(50)", "category": "Cloud Provider-Specific Fields",
                "semantic_description": (
                    "Which cloud this runs in: AWS, Azure, GCP, OCI, or On-Premises. ⚠️ Distinct "
                    "from source_system, which says WHO reported the row — a Kubernetes connector "
                    "reporting a workload running in GCP writes source_system='kubernetes' and "
                    "cloud_provider='gcp'. Needed to disambiguate cloud_account_id, whose namespace "
                    "differs per provider."
                ),
            },
            "agent_uuid": {"data_type": "VARCHAR(255)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "The scanning agent installed on the host, when the finding came from an "
                    "agent rather than a network or registry scan."
                ),
            },
            "software_name": {"data_type": "VARCHAR(255)", "category": "Affected Software on Asset",
                "semantic_description": (
                    "The affected software as the scanner named it. Free text and inconsistent "
                    "between scanners — prefer package_name for dependency findings."
                ),
            },
            "software_version": {"data_type": "VARCHAR(100)", "category": "Affected Software on Asset",
                "semantic_description": (
                    "The version found installed. Compare against package_fixed_version to know "
                    "whether a fix is even available."
                ),
            },
            "software_vendor": {"data_type": "VARCHAR(255)", "category": "Affected Software on Asset",
                "semantic_description": (
                    "Publisher of the affected software. Sparse for open-source dependencies, "
                    "more reliable for commercial and OS packages."
                ),
            },
            "software_product": {"data_type": "VARCHAR(255)", "category": "Affected Software on Asset",
                "semantic_description": (
                    "Product name in CPE terms, where the scanner supplied a CPE match rather "
                    "than a package name."
                ),
            },
            "software_edition": {"data_type": "VARCHAR(100)", "category": "Affected Software on Asset",
                "semantic_description": (
                    "CPE edition qualifier — rarely populated outside commercial software."
                ),
            },
            "software_language": {"data_type": "VARCHAR(50)", "category": "Affected Software on Asset",
                "semantic_description": (
                    "CPE language qualifier. Rarely populated."
                ),
            },
            "software_edition_details": {"data_type": "VARCHAR(100)", "category": "Affected Software on Asset",
                "semantic_description": (
                    "Further CPE edition detail. Rarely populated."
                ),
            },
            "software_target_sw": {"data_type": "VARCHAR(100)", "category": "Affected Software on Asset",
                "semantic_description": (
                    "The platform the affected software runs on, in CPE terms (e.g. windows, "
                    "linux). Rarely populated."
                ),
            },
            "source_file_path": {"data_type": "VARCHAR(2048)", "category": "Affected Software on Asset",
                "semantic_description": (
                    "Path to the manifest or lockfile that declared the vulnerable dependency — "
                    "where a developer goes to change the version."
                ),
            },
            "source_commit_id": {"data_type": "VARCHAR(255)", "category": "Affected Software on Asset",
                "semantic_description": (
                    "The commit scanned. Lets a finding be tied to a point in history rather "
                    "than just 'the repo'."
                ),
            },
            "code_reachability": {"data_type": "VARCHAR(20)", "category": "Exploitability",
                "semantic_description": (
                    "What torana-scan's reachability pass found for this finding at "
                    "code_reachability_commit. For a code finding it says whether any path leads from an "
                    "entry point to the flagged code and whether the engine could follow every call; for a "
                    "dependency finding, whether the repository imports the package at all. A separate "
                    "answer means it could not prove either way. The domain lists the allowed values. NULL "
                    "means not measured, which is never an answer of no path. Written only by the SARIF "
                    "ingest."
                ),
            },
            "code_reachability_commit": {"data_type": "VARCHAR(64)", "category": "Exploitability",
                "semantic_description": (
                    "The commit the reachability answer was measured at. When it differs from "
                    "source_commit_id the answer is stale."
                ),
            },
            "code_reachability_evidence": {"data_type": "TEXT", "category": "Exploitability",
                "semantic_description": (
                    "JSON object: the engine's own verdict, certainty, count of calls it could not "
                    "follow, analyzer, engine version, reason and entry points considered. Never "
                    "source code. Always a complete JSON object."
                ),
            },
            "code_reachability_measured_at": {"data_type": "TIMESTAMP", "category": "Exploitability",
                "semantic_description": (
                    "When this answer was first measured at this commit (UTC). A later scan of the "
                    "same commit with the same answer keeps it; a new answer or a new commit "
                    "replaces it."
                ),
            },
            "dependency_type": {"data_type": "VARCHAR(50)", "category": "Affected Software on Asset",
                "semantic_description": (
                    "Whether the vulnerable package is one you depend on directly or one pulled "
                    "in beneath it (direct, transitive, dev). Transitive findings often cannot "
                    "be fixed without an upstream release."
                ),
            },
            "package_name": {"data_type": "VARCHAR(255)", "category": "Affected Software on Asset",
                "semantic_description": (
                    "The dependency's name in its ecosystem. For SCA findings this is the "
                    "reliable identifier, unlike software_name."
                ),
            },
            "package_installed_version": {"data_type": "VARCHAR(255)", "category": "Affected Software on Asset",
                "semantic_description": (
                    "The version actually present. The 'from' side of any upgrade."
                ),
            },
            "package_fixed_version": {"data_type": "VARCHAR(100)", "category": "Affected Software on Asset",
                "semantic_description": (
                    "The earliest version that resolves this vulnerability — the 'to' side. "
                    "Empty means no fix has been published, so the finding cannot be closed by "
                    "upgrading."
                ),
            },
            "package_manager": {"data_type": "VARCHAR(50)", "category": "Affected Software on Asset",
                "semantic_description": (
                    "Ecosystem the package comes from (npm, pypi, maven, go, and similar). ⚠️ Determines "
                    "how two version strings compare, so a version comparison that ignores it is wrong "
                    "across ecosystems. Identical in meaning on `packages` and `vulnerabilities`."
                ),
            },
            "os_release": {"data_type": "VARCHAR(50)", "category": "Affected Software on Asset",
                "semantic_description": (
                    "Distro release the OS packages came from, as `<distro>-<version>` "
                    "(`debian-12`, `ubuntu-22.04`, `alpine-3.19`, `wolfi-20230201`). ⛔ NOT an "
                    "ecosystem — `package_manager` holds the package FORMAT (deb/apk/rpm); this "
                    "holds the ADVISORY STREAM. OSV refuses an OS query without it: `gnutls28` "
                    "under `Debian:12` returns 21 advisories, and under `Debian`, `deb` or `os` "
                    "returns ZERO with a 200, so an unmapped ecosystem is indistinguishable from "
                    "a clean package. Use `normalize.osv_ecosystem(package_manager, os_release)` "
                    "to build the key rather than formatting it by hand. ⚠️ Describes the IMAGE's "
                    "base OS, so it is populated on PyPI/Go rows in a Debian image too — those "
                    "query OSV as `PyPI`/`Go`, never as `Debian:12`. Written at a precision that "
                    "is per-distro (Debian major, Ubuntu/Alpine major.minor) so Container "
                    "Analysis (`debian-12`) and Trivy (`debian-12.15`) land one value for one "
                    "image."
                ),
            },
            "scanner_name": {"data_type": "VARCHAR(100)", "category": "Scan Source Details",
                "semantic_description": (
                    "Which scanner produced the finding. The same CVE reported by two scanners "
                    "gives two rows that differ here — the starting point for deduplication."
                ),
            },
            "scan_id": {"data_type": "VARCHAR(255)", "category": "Scan Source Details",
                "semantic_description": (
                    "The scan run this came from. Groups every finding produced by one "
                    "execution."
                ),
            },
            "scan_type": {"data_type": "VARCHAR(50)", "category": "Scan Source Details",
                "semantic_description": (
                    "How the finding was produced: SAST, DAST, SCA, container image scan, CSPM, "
                    "secret scan, pentest. Determines what the finding can and cannot tell you "
                    "— and which scan types dominate depends entirely on which scanners a "
                    "customer has connected."
                ),
            },
            "plugin_name": {"data_type": "VARCHAR(255)", "category": "Scan Source Details",
                "semantic_description": (
                    "Name of the scanner check that fired, as the scanner names it. Identifies WHICH check "
                    "produced the finding; vendor-specific by nature, since each scanner names its checks "
                    "differently."
                ),
            },
            "plugin_id": {"data_type": "VARCHAR(100)", "category": "Scan Source Details",
                "semantic_description": (
                    "The scanner check's identifier. Stable within one scanner, meaningless "
                    "across scanners."
                ),
            },
            "plugin_type": {"data_type": "VARCHAR(50)", "category": "Scan Source Details",
                "semantic_description": (
                    "The kind of check that fired — the scanner's own classification of its plugin, such as "
                    "a remote check versus a local or credentialed one. Affects how much the result can be "
                    "trusted."
                ),
            },
            "plugin_version": {"data_type": "VARCHAR(50)", "category": "Scan Source Details",
                "semantic_description": (
                    "Version of the check. A finding from an old plugin may be stale."
                ),
            },
            "plugin_family": {"data_type": "VARCHAR(255)", "category": "Scan Source Details",
                "semantic_description": (
                    "The scanner's grouping for this check, collecting related plugins under one heading. "
                    "Useful for asking which classes of check produce the most findings."
                ),
            },
            "plugin_family_id": {"data_type": "VARCHAR(100)", "category": "Scan Source Details",
                "semantic_description": (
                    "Identifier of the scanner's plugin family, the stable key behind `plugin_family`'s "
                    "display name."
                ),
            },
            "finding_key": {"data_type": "VARCHAR(500)", "category": "Scan Source Details",
                "semantic_description": (
                    "The scanner's own deduplication key. Useful for matching rows to the "
                    "source tool."
                ),
            },
            "scan_output": {"data_type": "TEXT", "category": "Scan Source Details",
                "semantic_description": (
                    "Raw scanner output for this finding. The detail behind the verdict."
                ),
            },
            "cve_id": {"data_type": "VARCHAR(50)", "category": "Software Vulnerability Details",
                "semantic_description": (
                    "The public CVE identifier. The join key to threat intelligence — KEV "
                    "listing, EPSS score, published advisories. Absent for findings with no CVE "
                    "assigned, such as most SAST and secret-scanning results."
                ),
            },
            "cwe_id": {"data_type": "VARCHAR(50)", "category": "Software Vulnerability Details",
                "semantic_description": (
                    "The weakness class (e.g. CWE-79 for XSS) — what KIND of flaw this is, as "
                    "opposed to which instance. Useful for spotting recurring patterns rather "
                    "than chasing individual CVEs."
                ),
            },
            "vulnerability_name": {"data_type": "VARCHAR(500)", "category": "Software Vulnerability Details",
                "semantic_description": (
                    "The finding's title as the scanner phrased it. Human-readable, not an "
                    "identifier; do not group by it."
                ),
            },
            "vulnerability_type": {"data_type": "VARCHAR(100)", "category": "Software Vulnerability Details",
                "semantic_description": (
                    "Scanner's classification of the finding. Vocabulary varies by tool."
                ),
            },
            "vulnerability_category": {"data_type": "VARCHAR(100)", "category": "Software Vulnerability Details",
                "semantic_description": (
                    "Broader grouping above vulnerability_type. Also scanner-specific."
                ),
            },
            "vulnerability_description": {"data_type": "TEXT", "category": "Software Vulnerability Details",
                "semantic_description": (
                    "The scanner's prose explanation of the flaw. Long-form; useful when "
                    "triaging one finding, not for aggregation."
                ),
            },
            "vulnerability_synopsis": {"data_type": "TEXT", "category": "Software Vulnerability Details",
                "semantic_description": (
                    "One-line summary of the flaw as the scanner states it, shown as the headline before "
                    "the fuller description. Vendor-worded rather than normalised."
                ),
            },
            "vulnerability_attack_vector": {"data_type": "VARCHAR(50)", "category": "Software Vulnerability Details",
                "semantic_description": (
                    "How the flaw is reached — network, adjacent, local, or physical. "
                    "Network-reachable flaws on internet-facing assets are the ones that "
                    "escalate."
                ),
            },
            "vulnerability_attack_complexity": {"data_type": "VARCHAR(50)", "category": "Software Vulnerability Details",
                "semantic_description": (
                    "How difficult exploitation is beyond the attacker's control."
                ),
            },
            "vulnerability_privileges_required": {"data_type": "VARCHAR(50)", "category": "Software Vulnerability Details",
                "semantic_description": (
                    "What access an attacker needs first. 'None' means no foothold is required."
                ),
            },
            "cvss_vector_raw": {"data_type": "VARCHAR(100)", "category": "Software Vulnerability Details",
                "semantic_description": (
                    "The full CVSS vector string. Every scoring input in one field, for "
                    "recomputing a score under different environmental assumptions."
                ),
            },
            "cvss_temporal_vector_raw": {"data_type": "VARCHAR(100)", "category": "Software Vulnerability Details",
                "semantic_description": (
                    "The CVSS v2 temporal vector string exactly as the source supplied it, unparsed. ⛔ "
                    "Retained verbatim so the score can be recomputed or audited; read the parsed numeric "
                    "columns for filtering, never this string."
                ),
            },
            "cvss3_vector_raw": {"data_type": "VARCHAR(100)", "category": "Software Vulnerability Details",
                "semantic_description": (
                    "The CVSS v3 base vector string exactly as the source supplied it, unparsed. ⛔ Kept for "
                    "audit and recomputation; filter on the parsed score columns instead of "
                    "pattern-matching this text."
                ),
            },
            "cvss3_temporal_vector_raw": {"data_type": "VARCHAR(100)", "category": "Software Vulnerability Details",
                "semantic_description": (
                    "The CVSS v3 temporal vector string exactly as the source supplied it, unparsed. ⛔ Kept "
                    "for audit and recomputation, not for filtering."
                ),
            },
            "cvss4_vector_raw": {"data_type": "VARCHAR(100)", "category": "Software Vulnerability Details",
                "semantic_description": (
                    "The CVSS v4 base vector string exactly as the source supplied it, unparsed. ⛔ Kept for "
                    "audit and recomputation, not for filtering."
                ),
            },
            "cvss4_threat_vector_raw": {"data_type": "VARCHAR(100)", "category": "Software Vulnerability Details",
                "semantic_description": (
                    "The CVSS v4 threat vector string exactly as the source supplied it, unparsed. ⛔ Kept "
                    "for audit and recomputation, not for filtering."
                ),
            },
            "is_zero_day": {"data_type": "BOOLEAN", "category": "Threat Intelligence",
                "semantic_description": (
                    "Whether this was exploited before a fix existed."
                ),
            },
            "is_exploit_available": {"data_type": "BOOLEAN", "category": "Exploitability",
                "semantic_description": (
                    "Whether working exploit code is known to exist. A sharp escalation signal: "
                    "a Medium with a public exploit often outranks a Critical without one."
                ),
            },
            "exploit_code_maturity": {"data_type": "VARCHAR(50)", "category": "Exploitability",
                "semantic_description": (
                    "How developed the available exploit is, from theoretical through to "
                    "weaponized."
                ),
            },
            "exploitability_ease": {"data_type": "VARCHAR(100)", "category": "Exploitability",
                "semantic_description": (
                    "Narrative assessment of how easily the flaw can be exploited."
                ),
            },
            "exploit_framework_metasploit_data": {"data_type": "VARCHAR(100)", "category": "Exploitability",
                "semantic_description": (
                    "Whether a Metasploit module exists — the most widely available "
                    "exploitation tooling, so a strong practical signal."
                ),
            },
            "exploit_framework_d2_elliot_data": {"data_type": "VARCHAR(100)", "category": "Exploitability",
                "semantic_description": (
                    "True when a working exploit for this vulnerability exists in the D2 Elliot exploit "
                    "framework. Exploit-availability evidence for prioritisation; NULL means the source did "
                    "not report on that framework, not that no exploit exists."
                ),
            },
            "exploit_framework_exploithub_data": {"data_type": "VARCHAR(100)", "category": "Exploitability",
                "semantic_description": (
                    "Whether an exploit exists in ExploitHub."
                ),
            },
            "cisa_kev_data": {"data_type": "VARCHAR(100)", "category": "Exploitability",
                "semantic_description": (
                    "CISA Known Exploited Vulnerabilities listing details. Presence here means "
                    "the US government has observed active exploitation and, for federal "
                    "agencies, set a mandatory remediation deadline."
                ),
            },
            "exploit_chain": {"data_type": "VARCHAR(100)", "category": "Exploitability",
                "semantic_description": (
                    "How this flaw combines with others to reach greater impact. A Medium that "
                    "is a link in a chain to domain admin is not a Medium."
                ),
            },
            "exploited_by_malware": {"data_type": "VARCHAR(100)", "category": "Exploitability",
                "semantic_description": (
                    "Whether known malware families use this vulnerability — the strongest "
                    "signal that exploitation is not hypothetical."
                ),
            },
            "exploited_by_nessus": {"data_type": "VARCHAR(100)", "category": "Exploitability",
                "semantic_description": (
                    "Whether Nessus can actively exploit this to prove it."
                ),
            },
            "in_the_news": {"data_type": "VARCHAR(100)", "category": "Exploitability",
                "semantic_description": (
                    "Whether the vulnerability has significant public attention. Drives urgency "
                    "that the technical score alone does not explain."
                ),
            },
            "epss_score": {"data_type": "DECIMAL(5,4)", "category": "Exploitability",
                "semantic_description": (
                    "EPSS probability (0-1) that this CVE will be exploited in the wild in the "
                    "next 30 days. Evidence about attacker behaviour, unlike CVSS which "
                    "describes the flaw. Refreshed daily upstream."
                ),
            },
            "epss_percentile": {"data_type": "DECIMAL(5,4)", "category": "Exploitability",
                "semantic_description": (
                    "Where this CVE's EPSS score ranks against all others. Easier to reason "
                    "about than the raw probability."
                ),
            },
            # ── Instance-level exploitability verdict (T8 — proven in THIS deployment,
            #    distinct from the global KEV/EPSS intel above) ─────────────────
            "exploitability_status": {
                "data_type": "VARCHAR(50)", "category": "Exploitability",
                "semantic_description": (
                    "The platform's own verdict from ACTUALLY TESTING this finding against the real "
                    "deployment — evidence from an exploit run, not a score inherited from a threat feed. "
                    "The declared value domain is the authority for the permitted verdicts. ⚠️ NULL means "
                    "no test has been run, which is not the same as a finding being proven safe."
                ),
            },
            "exploit_evidence": {
                "data_type": "TEXT", "category": "Exploitability",
                "semantic_description": (
                    "What the exploitability test actually observed — proof-of-concept "
                    "output, markers, tool JSON. The evidence behind exploitability_status."
                ),
            },
            "exploit_verified_at": {"data_type": "TIMESTAMP", "category": "Exploitability",
                "semantic_description": (
                    "When exploitability was last verified by testing."
                ),
            },
            "exploit_case_ref": {
                "data_type": "VARCHAR(255)", "category": "Exploitability",
                "semantic_description": (
                    "The pentest case that produced the exploitability verdict — the "
                    "reproducible test, not just its result."
                ),
            },
            "severity": {"data_type": "VARCHAR(20)", "category": "Severity & Scoring",
                "semantic_description": (
                    "How much harm is possible if this VULNERABILITY is exploited. A property of the FLAW, "
                    "the same everywhere it appears, and platform-owned so two tenants' data stays "
                    "comparable; the declared value domain is the authority for permitted values. ⛔ Policy "
                    "must NOT influence it — to de-prioritise something use `priority`. ⚠️ Distinct from "
                    "`issues.severity` (a tracker judgement on a ticket) and `findings.severity` (the "
                    "producing tool's rating). Compare thresholds against this, never against the raw CVSS "
                    "number."
                ),
            },
            # ── Effective priority (SEVERITY_AND_PRIORITY_MODEL.md § 3.13) ──────────
            #
            # ⛔ `remediation_priority` WAS REMOVED FROM THIS TABLE (archive row 887,
            # 2026-08-10) as `shadow_and_referenced`: 13 readers, ZERO writers, NULL
            # forever. These three columns are that idea reinstated -- and the archive
            # rule is "either the reason has changed, say how, or you are re-creating a
            # shadow column". THE REASON HAS CHANGED, on both counts that mattered:
            #
            #   1. A WRITER SHIPS IN THE SAME CHANGE -- the priority recompute, step 3
            #      of `drain_tenant` (pantheon-integration/services/derived_state_drain).
            #   2. FRESHNESS TRIGGERS LANDED FIRST -- a policy edit, a property rebuild
            #      and an ETL sync each re-derive these. That was built as a PRECONDITION
            #      precisely because a stamped value with no trigger is worse than a NULL
            #      one: it looks correct while being wrong.
            #
            # ⛔ If the recompute is ever removed, REMOVE THESE COLUMNS WITH IT. A
            # priority column nothing writes is the exact defect the archive recorded.
            "priority": {"data_type": "VARCHAR(20)", "category": "Severity & Scoring",
                "semantic_description": (
                    "How urgently WE must fix this VULNERABILITY instance: the tenant's answer, computed "
                    "from their own policy — severity plus asset criticality, exposure, KEV and EPSS. ⚠️ "
                    "Distinct from `severity` (a property of the flaw, identical for every tenant) and from "
                    "`issues.priority` (the tracking system's own P1–P4 field). This is the column queues, "
                    "SLAs and dashboards rank on."
                ),
            },
            "priority_score": {"data_type": "DOUBLE PRECISION",
                "category": "Severity & Scoring",
                "semantic_description": (
                    "The raw numeric score `priority` was banded from. Kept because the "
                    "band alone cannot order a queue -- two Criticals need a tiebreak -- "
                    "and because a score that moves while the band does not is how a user "
                    "sees a policy change taking effect."
                ),
            },
            "priority_source": {"data_type": "VARCHAR(200)",
                "category": "Severity & Scoring",
                "semantic_description": (
                    "Which inputs actually CONTRIBUTED to `priority`, and whether a human "
                    "override won. Turns 'this is High' into 'this is High BECAUSE it is "
                    "internet-facing with EPSS 0.94', which is what lets a user challenge "
                    "the answer. It must name only terms that really contributed: a weight "
                    "applied to a NULL input contributes nothing, and silently implying "
                    "otherwise would make a tenant think their policy edit was ignored."
                ),
            },
            # ⛔ `severity_score` was REMOVED here (S27, 2026-08-13) and must not come
            # back without a writer that fills it with something cvss_base_score does
            # not already hold. It was a duplicate: sarif.py assigned it and
            # cvss_base_score from a character-identical expression, so one fact landed
            # in two columns. 0 of 86,696 rows held a value, and no row ever had it as
            # the sole carrier of a score. Use `cvss_base_score` for the number and
            # `cvss3_base_score` for the version-qualified form — a bare score with no
            # `cvss_version_primary` beside it is unscoped across CVSS v2/v3/v4.
            # See docs/corpus/removed_columns_archive.csv in pantheon-datalake.
            "cvss_version_primary": {"data_type": "VARCHAR(10)", "category": "Severity & Scoring",
                "semantic_description": (
                    "Which CVSS version the primary score uses. Scores from different versions "
                    "are not directly comparable."
                ),
            },
            "cvss_base_score": {"data_type": "DECIMAL(3,1)", "category": "Severity & Scoring",
                "semantic_description": (
                    "CVSS base score, 0.0-10.0 — how bad the flaw is in the abstract. It knows "
                    "nothing about YOUR environment, which is why exposure and asset "
                    "criticality matter alongside it."
                ),
            },
            "cvss_temporal_score": {"data_type": "DECIMAL(3,1)", "category": "Severity & Scoring",
                "semantic_description": (
                    "CVSS score adjusted for exploit maturity and fix availability at a point "
                    "in time."
                ),
            },
            "cvss3_base_score": {"data_type": "DECIMAL(3,1)", "category": "Severity & Scoring",
                "semantic_description": (
                    "CVSS v3 base score, the modern scale. Prefer this over cvss_base_score "
                    "when both are present."
                ),
            },
            "cvss3_temporal_score": {"data_type": "DECIMAL(3,1)", "category": "Severity & Scoring",
                "semantic_description": (
                    "CVSS v3 temporal score, which adjusts the base score for exploit maturity and "
                    "remediation availability. Lower than the base score by construction, and populated "
                    "only where the source supplies temporal metrics."
                ),
            },
            "cvss3_impact_score": {"data_type": "DECIMAL(3,1)", "category": "Severity & Scoring",
                "semantic_description": (
                    "The impact half of the v3 score — what an attacker gains. Pairs with "
                    "exploitability_score, which is how hard it is to get."
                ),
            },
            "cvss4_base_score": {"data_type": "DECIMAL(3,1)", "category": "Severity & Scoring",
                "semantic_description": (
                    "CVSS v4 base score, where the source supplies the newest scale."
                ),
            },
            "cna_severity": {"data_type": "VARCHAR(100)", "category": "Severity & Scoring",
                "semantic_description": (
                    "Severity as assigned by the CVE Numbering Authority — the assigning body's "
                    "own view, which can differ from NVD's."
                ),
            },
            "vpr_score": {"data_type": "DECIMAL(4,1)", "category": "Severity & Scoring",
                "semantic_description": (
                    "Vendor-calculated priority rating, where the scanner supplies one. "
                    "Vendor-specific and not comparable across tools."
                ),
            },
            "cvss_risk_rating": {"data_type": "INTEGER", "category": "Severity & Scoring",
                "semantic_description": (
                    "Risk band the source derived from its CVSS score. ⚠️ The VENDOR's banding, not "
                    "Torana's — different scanners cut the same numeric score into different bands, so "
                    "compare `severity` across sources rather than this column."
                ),
            },
            "business_risk_score": {"data_type": "INTEGER", "category": "Severity & Scoring",
                "semantic_description": (
                    "Risk adjusted for business context, where a source computes one. Not "
                    "populated by scanners that only see the technical flaw."
                ),
            },
            "is_workaround_available": {"data_type": "BOOLEAN", "category": "Remediation",
                "semantic_description": (
                    "Whether a mitigation exists that reduces risk without fixing the flaw. "
                    "Matters most when is_fix_available is false."
                ),
            },
            "workaround_type": {"data_type": "TEXT", "category": "Remediation",
                "semantic_description": (
                    "The kind of mitigation available — config change, network control, feature "
                    "disable."
                ),
            },
            "workaround_description": {"data_type": "TEXT", "category": "Remediation",
                "semantic_description": (
                    "What the mitigation actually is, in words."
                ),
            },
            "workaround_publication_date": {"data_type": "TIMESTAMP", "category": "Remediation",
                "semantic_description": (
                    "When a workaround or mitigation for this vulnerability was published. Distinct from a "
                    "fix being available: a workaround reduces exposure without remediating the flaw."
                ),
            },
            "is_patch_available": {"data_type": "BOOLEAN", "category": "Remediation",
                "semantic_description": (
                    "Whether the vendor has published a patch."
                ),
            },
            "patch_publication_date": {"data_type": "TIMESTAMP", "category": "Remediation",
                "semantic_description": (
                    "When the fix became available. The gap to resolution is time you had a fix "
                    "and had not applied it."
                ),
            },
            "is_fix_available": {"data_type": "BOOLEAN", "category": "Remediation",
                "semantic_description": (
                    "Whether any fix path exists — patch, version bump or configuration change. "
                    "When false, the only options are mitigation or acceptance, so it changes "
                    "what 'remediate' can even mean."
                ),
            },
            "remediation_solution": {"data_type": "TEXT", "category": "Remediation",
                "semantic_description": (
                    "The recommended fix, in words — usually the scanner's own guidance."
                ),
            },
            # TEXT, not VARCHAR(20). The 20 was almost certainly a typo — every sibling
            # free-text column here (remediation_solution, workaround_description) is TEXT,
            # and 20 characters cannot hold a resolution note: a PR URL alone overflows it,
            # leaving room for little more than "PR #11". The row then carries no usable
            # record of WHY or HOW a finding was resolved, so audit and review cannot
            # reconstruct the decision or find the fixing PR.
            #
            # ⚠ MIGRATION REQUIRED for already-provisioned tenants. The datalake applies
            # schema drift via `ALTER TABLE ... ADD COLUMN IF NOT EXISTS`, which creates
            # missing columns but will NOT widen an existing one — an existing tenant keeps
            # VARCHAR(20) until an explicit `ALTER TABLE ... ALTER COLUMN ... TYPE TEXT`
            # is run. New tenants get TEXT from this definition.
            "resolution_details": {"data_type": "TEXT", "category": "Remediation",
                "semantic_description": (
                    "How the finding was actually resolved, recorded after the fact."
                ),
            },
            "vulnerability_status": {"data_type": "VARCHAR(100)", "category": "Status & Assessment",
                "semantic_description": (
                    "Where the finding stands: Open, Fixed, Accepted, In Progress, Won't Fix, "
                    "Reopened, Mitigated, Deferred. Title-cased in the data, so a filter "
                    "written as 'open' matches nothing."
                ),
            },
            # Triage-decision flags — NULLABLE, and NULL is the meaningful state:
            # nobody has triaged this finding yet. ⛔ NULL and FALSE are DIFFERENT
            # claims. FALSE means a human looked and said "this is real / not
            # accepted / not suppressed"; NULL means no one has looked. Collapsing
            # them makes a finding nobody examined indistinguishable from one a
            # human confirmed, permanently and with no way to separate them after
            # the fact — so every metric built on "confirmed real" or
            # "false-positive rate" reports work that never happened.
            #
            # ⛔ DO NOT DECLARE THESE `NOT NULL DEFAULT false`. A default destroys
            # the NULL state at ingest, for every tenant, unrecoverably.
            #
            # ⚠️ Filter them with `IS NOT TRUE`, never `= false` — the latter drops
            # every untriaged row under SQL three-valued logic, which on one tenant
            # meant losing 99.5% of its findings with no error shown. That is a
            # property of the QUERY and is enforced there: `sql-reachability` flags
            # the bad form as a `nullable_boolean` finding, and the
            # `torana-text-to-sql` skill states the rule for generated SQL.
            "is_false_positive": {"data_type": "BOOLEAN", "category": "Status & Assessment",
                "semantic_description": (
                    "Triage decision that this finding is not real. NULLABLE — a filter written "
                    "as `= false` also drops every row nobody has triaged yet, which is usually "
                    "most of them. Use `IS NOT TRUE`."
                ),
            },
            "is_risk_accepted": {"data_type": "BOOLEAN", "category": "Status & Assessment",
                "semantic_description": (
                    "A human decided to live with this rather than fix it. Same NULL caution as "
                    "is_false_positive."
                ),
            },
            "risk_acceptance_expires_at": {"data_type": "TIMESTAMP",
                                           "category": "Status & Assessment",
                "semantic_description": (
                    "When this risk acceptance lapses and the finding must be reviewed again. "
                    "An acceptance with no expiry is permanent BY ACCIDENT: the decision was made "
                    "once, against a threat picture and a business context that both move, and "
                    "nothing ever brings it back. NULL means the acceptance never expires -- "
                    "which is a legitimate choice for a genuinely permanent exception, but it "
                    "should be a CHOICE, so read NULL as 'no review scheduled', never as "
                    "'reviewed and still valid'. Only meaningful when is_risk_accepted is true; "
                    "on any other row it is noise. A sweep reopens findings whose expiry has "
                    "passed, so a lapsed acceptance resurfaces in the queue rather than "
                    "silently suppressing a finding forever."
                ),
            },
            "is_suppressed": {"data_type": "BOOLEAN", "category": "Status & Assessment",
                "semantic_description": (
                    "Hidden from normal queues by a deliberate decision. Distinct from "
                    "false-positive: still real, just not shown."
                ),
            },
            "is_verified": {"data_type": "BOOLEAN", "category": "Status & Assessment",
                "semantic_description": (
                    "Whether the finding has been confirmed rather than taken on the scanner's "
                    "word."
                ),
            },
            "is_confirmed": {"data_type": "BOOLEAN", "category": "Status & Assessment",
                "semantic_description": (
                    "Whether a human has confirmed the finding is real, as opposed to accepting "
                    "the scanner's verdict."
                ),
            },
            "is_triaged": {"data_type": "BOOLEAN", "category": "Status & Assessment",
                "semantic_description": (
                    "Whether anyone has looked at this yet. Empty means untouched, which for a "
                    "large backlog is the default state."
                ),
            },
            "analyst_notes": {"data_type": "TEXT", "category": "Status & Assessment",
                "semantic_description": (
                    "Free-text notes from whoever triaged this."
                ),
            },
            "business_justification": {"data_type": "TEXT", "category": "Status & Assessment",
                "semantic_description": (
                    "Why an exception or risk acceptance was granted. The audit trail for a "
                    "decision not to fix."
                ),
            },
            "compensating_controls": {"data_type": "TEXT", "category": "Status & Assessment",
                "semantic_description": (
                    "Controls reducing the risk without fixing the flaw — the reason a finding "
                    "may stay open deliberately."
                ),
            },
            "cve_published_date": {"data_type": "TIMESTAMP", "category": "Lifecycle & Management",
                "semantic_description": (
                    "When the CVE became public. The gap between this and "
                    "scan_first_detected_date is detection lag — how long you were exposed "
                    "without knowing."
                ),
            },
            "cve_last_modified_date": {"data_type": "TIMESTAMP", "category": "Lifecycle & Management",
                "semantic_description": (
                    "When the CVE record last changed upstream. A moved score or added KEV "
                    "listing shows up here."
                ),
            },
            "scan_first_detected_date": {"data_type": "TIMESTAMP", "category": "Lifecycle & Management",
                "semantic_description": (
                    "When this finding was FIRST seen. The clock SLA age is measured from — not "
                    "the CVE publication date, which may be years earlier."
                ),
            },
            "scan_last_detected_date": {"data_type": "TIMESTAMP", "category": "Lifecycle & Management",
                "semantic_description": (
                    "The SOURCE's own latest timestamp for this finding, as it sent it: for "
                    "some sources the last scan that found it, for others only when the source "
                    "last changed its record. Not when the platform last observed it, and it "
                    "does not advance when a sync finds the finding unchanged. An old value "
                    "does NOT mean the finding is gone: a finding scans stopped reporting is "
                    "retired (is_deleted with closure_reason disappeared or decommissioned)."
                ),
            },
            "vulnerability_modified_date": {"data_type": "TIMESTAMP", "category": "Lifecycle & Management",
                "semantic_description": (
                    "When this finding's LIFECYCLE STATE last changed: status, open/closed, "
                    "closure reason or date, or a triage flag. Set when the finding first "
                    "arrives and moved only by a real state change — a re-scan that finds it "
                    "unchanged does not move it. Not the vendor's advisory-update date, and "
                    "not updated_at (which is the platform's last write). Written by the "
                    "shared upsert (datalake/lifecycle.py)."
                ),
            },
            "vulnerability_resolution_date": {"data_type": "TIMESTAMP", "category": "Lifecycle & Management",
                "semantic_description": (
                    "When the finding stopped being open work, for ANY reason: the closure "
                    "date, not the fix date. A Suppressed (dismissed, risk-accepted) row can "
                    "carry one, so filter on vulnerability_status as well to mean FIXED; with "
                    "that and scan_first_detected_date it gives time-to-remediate. Empty for "
                    "open findings and CLEARED when a closed finding is detected again. "
                    "STAMPED SERVER-SIDE by PATCH /ingest/vulnerabilities whenever "
                    "vulnerability_status moves to a terminal value and no explicit date is "
                    "supplied, so no caller can close a finding without a clock."
                ),
            },
            "closure_reason": {"data_type": "VARCHAR(32)", "category": "Lifecycle & Management",
                "semantic_description": (
                    "HOW a finding ended, not merely that it did. It separates a fix or a "
                    "mitigation from a decision to accept or dismiss the risk, and both from "
                    "closure by ABSENCE (scans stopped reporting it, or the asset was retired) or "
                    "by merging a duplicate. The values are the closed vocabulary in "
                    "value_domain.py (`('vulnerabilities', 'closure_reason')`). ⛔ The absence "
                    "reasons (`ABSENCE_CLOSURE_REASONS`) are written only by platform retirement "
                    "writers and are the only closures a re-observation may reverse; a person "
                    "cannot set them. Required by M-12 (outflow by reason) and R-CISO-04, which "
                    "demands 'closed by decommission' be separable from 'closed by fix' — a "
                    "backlog that shrinks entirely through decommissioning has not become "
                    "safer. vulnerability_status cannot express this, and resolution_details is "
                    "free text, so neither is groupable. NULL while open."
                ),
            },
            # ── Reopen memory (datalake/lifecycle.py rule L7). Written ONLY by the upsert rule,
            # in the statement that clears closure_reason and vulnerability_resolution_date.
            "reopened_at": {"data_type": "TIMESTAMP", "category": "Lifecycle & Management",
                "semantic_description": (
                    "When a closed finding last became open again: the source reported it "
                    "again, or a person set it back to open. NULL means the row has never "
                    "been reopened. Records the LAST reopen only, and stays set if the "
                    "finding is closed again afterwards; reopen_count says how many times."
                ),
            },
            "prior_resolution_date": {"data_type": "TIMESTAMP", "category": "Lifecycle & Management",
                "semantic_description": (
                    "The vulnerability_resolution_date the row carried just before its last "
                    "reopen: when it had been closed. Kept because reopening clears "
                    "vulnerability_resolution_date. reopened_at minus this is how long the "
                    "closure held. NULL when never reopened, or when the closed row had no date."
                ),
            },
            "prior_closure_reason": {"data_type": "VARCHAR(32)", "category": "Lifecycle & Management",
                "semantic_description": (
                    "The closure_reason the row carried just before its last reopen. "
                    "disappeared or decommissioned means the row had been retired because "
                    "scans stopped reporting it, and then it reappeared. NULL when never "
                    "reopened, and also when the closed row had no reason recorded, which is "
                    "usual for a status a scanner reported itself: read "
                    "prior_vulnerability_status for those."
                ),
            },
            "prior_vulnerability_status": {"data_type": "VARCHAR(100)", "category": "Lifecycle & Management",
                "semantic_description": (
                    "The vulnerability_status the row carried just before its last reopen, from "
                    "the same vocabulary as vulnerability_status. It says what the reopen undid: "
                    "a remediated status (`TERMINAL_STATUSES` in value_domain.py) is a fix that "
                    "came back; a suppressed one is a dismissal that was undone; an open-class "
                    "status (`OPEN_CLASS_STATUSES`) means the row was open when it was retired "
                    "for absence (see prior_closure_reason), so nothing was ever fixed. NULL when "
                    "never reopened. To select fixes that resurfaced, filter this column on the "
                    "remediated statuses, not reopened_at alone."
                ),
            },
            "reopen_count": {"data_type": "INTEGER", "category": "Lifecycle & Management",
                "semantic_description": (
                    "How many times this finding has gone from closed back to open since the "
                    "platform began recording reopens. NULL means never, not zero."
                ),
            },
            "assigned_to": {"data_type": "VARCHAR(255)", "category": "Lifecycle & Management",
                "semantic_description": (
                    "WHO took this finding — distinct from asset ownership, which answers who "
                    "owns the thing it sits on. Without it a 'critical vulns to fix this week' "
                    "screen is a report rather than a worklist, because no row can be routed "
                    "to a person. Derived ownership (assets.asset_team) remains the fallback."
                ),
            },
            "vulnerability_due_date": {"data_type": "TIMESTAMP", "category": "Lifecycle & Management",
                "semantic_description": (
                    "When remediation is due under policy. Compare against today to find "
                    "breaches."
                ),
            },
            "vulnerability_sla_breach_date": {"data_type": "TIMESTAMP", "category": "Lifecycle & Management",
                "semantic_description": (
                    "When the SLA was missed, once it has been."
                ),
            },
            "created_by": {
                "data_type": "VARCHAR(255)", "category": "Audit & Tracking",
                "semantic_description": (
                    "The Torana user or service principal that caused this vulnerability row to be written — in "
                    "practice the integration that ingested it (`github_integration`, `jira_integration`). "
                    "⚠️ An INGEST-side actor, NOT the owner of the thing described: do not read it as "
                    "'who is responsible for this'."
                ),
            },
            "created_via": {"data_type": "VARCHAR(100)", "category": "Audit & Tracking",
                "semantic_description": (
                    "The Torana mechanism that wrote this vulnerability row — an integration sync, a "
                    "replay, a manual push, or a synthetic dataset load. ⛔ Provenance, not vulnerability "
                    "data: it is what separates genuinely ingested rows from generated ones, and a query "
                    "measuring a real estate should know which values are synthetic."
                ),
            },
            "dataset_tag": {"data_type": "VARCHAR(200)", "category": "Audit & Tracking",
                "semantic_description": (
                    "Marks this vulnerability row as seeded by a NAMED synthetic dataset rather than a live "
                    "integration, so such rows can be purged as a set. NULL for genuinely ingested rows. ⛔ "
                    "Filter it out when measuring a real estate — counting demo rows as production "
                    "vulnerability data is the error this column exists to prevent."
                ),
            },
            # ── Decoration layer provenance (DECORATION_LAYER_SPEC.md § 3.9) ──
            # WHO last wrote the decorated columns on this row. Values:
            #   NULL                  — nothing has written them
            #   'decoration:<name>'   — the decoration layer's apply job
            #   'cve_enrich'          — the legacy ingest path (pre-layer)
            #   '<scanner id>'        — an observation from a real scanner
            # This is what makes OVERRIDE safe: the layer may replace its own
            # value or an absent one, but never a scanner's observation.
            "decoration_provenance": {
                "data_type": "VARCHAR(64)", "category": "Audit & Tracking",
                "semantic_description": (
                    "Per-property record of where each governance value on this vulnerability row came "
                    "from. NULL = unwritten; `decoration:<name>` = the apply job wrote it; anything else = "
                    "an observation the decoration layer must never overwrite."
                ),
            },
            # WHICH version of the source data produced the current values —
            # the producer's source_version, carried through the apply so a
            # reader can tell whether a row reflects the latest feed.
            "decoration_version": {
                "data_type": "VARCHAR(100)", "category": "Audit & Tracking",
                "semantic_description": (
                    "Version of the decoration pass that stamped this row."
                ),
            },
        }