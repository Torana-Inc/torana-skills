from typing import Dict, Any
from .base import TableSchema


class EntityEdgeCandidatesSchema(TableSchema):
    """Schema for the entity_edge_candidates table
    (Torana_Asset_Graph_Design.md § 4.9.2).

    The diagnostic ledger for edge-derivation attempts that **could not produce a
    valid edge** — typically because one endpoint's key could not be computed from
    the available structured data (no shared identifier; a value that won't
    normalize into a key). Such an attempt has **no valid ``torana_edge_id``** (you
    cannot hash a key you could not compute), so it is NOT an ``entity_edges`` row
    and gets its own table.

    Distinct from an *orphan edge* (both keys known, a node missing) which IS a
    valid edge and stays in ``entity_edges`` with ``is_deleted`` semantics. The
    dividing line: *can you compute a valid ``torana_edge_id``?* yes → entity_edges;
    no → entity_edge_candidates.

    This is a first-class **decision ledger + test-assertion surface**, NOT a queue
    — nothing drains it. Entries auto-promote (``status='promoted'``) when a later
    ETL pass learns the missing key, or are dismissed by an admin. The ``id`` is a
    surrogate PK precisely because the edge identity cannot be computed.

    System fields (IAM: tenant_id/namespace_id; lifecycle: is_deleted; audit:
    created_at/updated_at/...) are injected by ``get_full_schema()`` — do NOT
    declare them here.
    """

    @property
    def table_name(self) -> str:
        return "entity_edge_candidates"

    @property
    def primary_key(self) -> str:
        return "id"

    @property
    def description(self) -> str:
        return (
            "Diagnostic ledger of entity-graph edge derivations that could not be "
            "keyed (one endpoint's key was uncomputable from the structured data). "
            "Captures the side that WAS keyed, the reason, and the raw value that "
            "wouldn't normalize — for visibility, admin review, and test assertion. "
            "Auto-promotes when a later pass keys it. Edges that DID key live in "
            "entity_edges; this table holds the failures, never silently dropped."
        )

    @property
    def category(self) -> str:
        return "Entity Graph"

    @property
    def timestamp_column(self) -> str:
        return "updated_at"

    @property
    def schema(self) -> Dict[str, Any]:
        return {
            # Surrogate PK — NOT torana_edge_id (the whole point: it can't be computed).
            "id": {"data_type": "VARCHAR(64)", "primary_key": True, "category": "Core Identity"},
            # The edge we were trying to derive.
            "edge_type": {"data_type": "VARCHAR(50)", "not_null": True, "index": True, "category": "Edge"},
            # The endpoint(s): exactly one of from/to is typically set (the other is the gap).
            "from_key": {"data_type": "VARCHAR(512)", "category": "Edge"},
            "to_key": {"data_type": "VARCHAR(512)", "category": "Edge"},
            "missing_side": {"data_type": "VARCHAR(10)", "category": "Edge"},  # 'from' | 'to'
            # Why it couldn't become a real edge (the diagnostic payload).
            # enum: unkeyable_endpoint | missing_shared_identifier | ambiguous_match | invalid_endpoint_type
            "reason": {"data_type": "VARCHAR(50)", "not_null": True, "index": True, "category": "Diagnosis"},
            "expected_prefix": {"data_type": "VARCHAR(50)", "category": "Diagnosis"},  # e.g. 'service:'
            # The raw value we had but couldn't normalize into a key — the debugging money column.
            "candidate_value": {"data_type": "TEXT", "category": "Diagnosis"},
            "detail": {"data_type": "JSON", "category": "Diagnosis"},
            # Provenance — attribution for test + debugging.
            "source_system": {"data_type": "VARCHAR(100)", "category": "Provenance"},
            "ingest_receipt_id": {"data_type": "VARCHAR(128)", "index": True, "category": "Provenance"},
            "confidence_intended": {"data_type": "VARCHAR(20)", "category": "Provenance"},
            # Lifecycle / the decision ledger.
            # status: open | promoted | dismissed | needs_job
            "status": {"data_type": "VARCHAR(20)", "not_null": True, "index": True, "category": "Lifecycle"},
            "promoted_edge_id": {"data_type": "VARCHAR(64)", "category": "Lifecycle"},
            "resolved_at": {"data_type": "TIMESTAMP", "category": "Lifecycle"},
            "resolved_by": {"data_type": "VARCHAR(255)", "category": "Lifecycle"},  # 'rule:<name>' | user id
            # Same candidate seen N times → one row, count N (the pattern is the signal).
            "occurrence_count": {"data_type": "INTEGER", "not_null": True, "category": "Lifecycle"},
        }
