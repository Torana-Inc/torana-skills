from typing import Dict, Any
from .base import TableSchema
from .system_fields import LIFECYCLE_FIELDS, AUDIT_FIELDS


class VmCveMetadataSchema(TableSchema):
    """Schema for the ``vm_cve_metadata`` GLOBAL CVE-intel reference table
    (Threat-Intel Enrichment design, § 3.3.1).

    This is a **tenant-independent** reference table: CVE facts (CISA KEV, FIRST
    EPSS, NVD CVSS) are the same for every tenant, so a single copy lives in the
    shared ``public`` schema (written via ``scope="global"``; read by every
    tenant's transformer/operator because ``public`` is always on the
    search_path). It is the table behind ``POST /api/v1/ingest/cve-feed``.

    IMPORTANT — this table deliberately carries **no** ``tenant_id`` /
    ``namespace_id``: it is not owned by any tenant, and the feed write path
    bypasses IAM-field injection. ``get_full_schema()`` is therefore overridden to
    inject only the Lifecycle + Audit system fields, never the IAM fields (whose
    NOT NULL constraints would reject a tenant-less global write).
    """

    @property
    def table_name(self) -> str:
        return "vm_cve_metadata"

    @property
    def scope(self) -> str:
        """GLOBAL — one copy in the shared ``public`` schema, not per-tenant.

        Declaring it here is what puts the table into the ``torana_global`` dbt source
        group (derived in ``core/source_sync.py``), so ``{{ source('torana_global',
        'vm_cve_metadata') }}`` resolves. Without this it stayed invisible to dbt and any
        catalog entry joining CVE intel failed to compile — see ``TableSchema.scope``.
        """
        return "global"

    @property
    def primary_key(self) -> str:
        return "cve_id"

    @property
    def description(self) -> str:
        return (
            "Global CVE-intel reference cache — CISA KEV listing, FIRST EPSS score, "
            "and NVD CVSS per CVE. Tenant-independent (shared public schema); enriches "
            "tenant vulnerabilities at ingest and via the enriched_vulnerabilities view."
        )

    @property
    def category(self) -> str:
        return "Threat Intelligence"

    @property
    def timestamp_column(self) -> str:
        return "updated_at"

    @property
    def schema(self) -> Dict[str, Any]:
        return {
            "cve_id": {"data_type": "VARCHAR(50)", "primary_key": True, "category": "Identity"},
            # CVSS (NVD)
            "cvss3_base_score": {"data_type": "DECIMAL(3,1)", "category": "Scoring"},
            "cvss3_vector": {"data_type": "VARCHAR(100)", "category": "Scoring"},
            "cvss_version_primary": {"data_type": "VARCHAR(10)", "category": "Scoring"},
            # EPSS (FIRST) — score is 0.0000..1.0000; percentile 0.0000..1.0000
            "epss_score": {"data_type": "DECIMAL(5,4)", "category": "Exploitability"},
            "epss_percentile": {"data_type": "DECIMAL(5,4)", "category": "Exploitability"},
            # KEV (CISA)
            "kev_listed": {"data_type": "BOOLEAN", "category": "Exploitability"},
            "kev_date_added": {"data_type": "DATE", "category": "Exploitability"},
            "kev_due_date": {"data_type": "DATE", "category": "Exploitability"},
            "kev_known_ransomware": {"data_type": "BOOLEAN", "category": "Exploitability"},
            # NVD advisory dates. Named for the CACHE (CVE-scoped), not the
            # destination — the `cve_` prefix would stutter here; the mapping onto
            # vulnerabilities.cve_published_date / .cve_last_modified_date happens in
            # the `cve_intel` DecorationSpec's `provides`, not in the column name.
            #
            # ⛔ NULLABLE, deliberately. NVD is a SUPERSET of this cache (380,231 vs
            # 360,804 rows measured 2026-08-19), and the KEV/EPSS feeds insert CVE rows
            # NVD has not yet published — so a cached CVE carrying no dates is a normal
            # state, not a defect.
            #
            # ⚠️ The upsert path STRIPS record keys that are not physical columns
            # (postgres_backend._upsert: `columns = [k for k in ordered_keys if k in
            # table_columns]`), silently. So _refresh_nvd cannot write these until the
            # ALTER lands — which is why the column phase strictly precedes the fetcher.
            "published_date": {"data_type": "TIMESTAMP", "category": "Provenance"},
            "last_modified_date": {"data_type": "TIMESTAMP", "category": "Provenance"},
            # NVD weakness classification — the FLAW CLASS (#376).
            #
            # ⭐ WHY THIS IS SAFE where CPE→purl matching is not (#356): this is an EXACT
            # join on a primary key. NVD publishes the CWE *for that specific CVE id*;
            # there is no matching to get wrong. `vulnerability_category` cannot serve
            # this purpose — it classifies record KIND (99.7% the single value
            # `VULNERABILITY`), so grouping by it produces one bar.
            #
            # ⛔ NVD PLACEHOLDERS ARE NEVER WRITTEN HERE. `NVD-CWE-noinfo` (4,433 in 2024)
            # and `NVD-CWE-Other` (651) mean "NVD could not classify this" — they are
            # stored as NULL, not written through. Writing them would reproduce exactly
            # the defect this column is being added to fix: a high fill rate that
            # discriminates nothing.
            #
            # ⚠️ SINGLE-VALUED BY DECLARATION, and the truncation is DISCLOSED rather than
            # silent. 3,413 of the 36,759 classified 2024 CVEs (9%) carry more than one
            # distinct REAL CWE (the 17% figure counts placeholder pairs, which are
            # dropped before this column is written), so a
            # scalar column cannot hold the whole truth. `cwe_id` carries the PRIMARY
            # weakness (NVD's own `type: "Primary"` where present, else the lowest
            # CWE number for determinism) and `cwe_ids` carries the complete ordered set,
            # so a reader can always tell one-CWE from many. Taking `[0]` and saying
            # nothing is how single-valued columns get born (see #374).
            "cwe_id": {"data_type": "VARCHAR(32)", "category": "Classification"},
            "cwe_ids": {"data_type": "TEXT", "category": "Classification"},
            # provenance / freshness
            "source_version": {"data_type": "VARCHAR(64)", "category": "Provenance"},
            "description": {"data_type": "TEXT", "category": "Meta"},
        }

    def get_full_schema(self) -> Dict[str, Any]:
        """Override: a GLOBAL table injects Lifecycle + Audit, but NOT IAM fields.

        The default base injects tenant_id/namespace_id (NOT NULL), which would make
        the tenant-less feed write fail. This table is tenant-independent, so only
        is_deleted (Lifecycle) + created_at/updated_at/created_by/updated_by (Audit)
        are injected alongside the business columns.
        """
        return {**LIFECYCLE_FIELDS, **AUDIT_FIELDS, **self.schema}
