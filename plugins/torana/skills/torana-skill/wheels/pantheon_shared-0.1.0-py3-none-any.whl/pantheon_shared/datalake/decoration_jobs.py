"""The apply state machine's durable queue — enqueue, claim, heartbeat, reap.

Design: ``DECORATION_LAYER_SPEC.md`` § 3.6.1 (states), § 3.6.2 (enqueue + backstop),
§ 3.6.3 (claim), § 3.6.4 (restart recovery + retention).

**A job is a ROW, not an in-memory task.** That single decision is what makes restart
recovery possible: a worker that dies mid-apply leaves its row visible to the next
worker. Every statement here is built as SQL text and executed through the backend's
``_execute_write`` seam, because the claim and the apply both need ``RETURNING`` —
which ``update_rows`` discards and ``query`` cannot commit.

Concurrency model, stated once because it is the thing most easily got wrong:

* **The claim is the mutex.** ``FOR UPDATE SKIP LOCKED`` inside a CTE gives
  exactly-one-claimer under N gunicorn workers.
* **Idempotency is the safety property.** If a re-armed job is somehow applied twice,
  the apply derives everything from current fact state, so the result is identical.
  A concurrent duplicate is wasteful, never incorrect.
* **No advisory locks.** ``pg_advisory_lock`` is connection-scoped; returning a pooled
  connection silently releases it. That is the recorded ETL leader-election defect —
  four workers all believing they were leader with zero locks actually held.
"""

from __future__ import annotations

from typing import Any, Optional, Sequence

from pantheon_shared.datalake.decoration_store import GLOBAL_TENANT, build_key

__all__ = [
    "JOBS_TABLE",
    "STATUS_TABLE",
    "FACTS_TABLE",
    "DEFAULT_MAX_ATTEMPTS",
    "DEFAULT_CLAIM_TIMEOUT_SECONDS",
    "DEFAULT_HEARTBEAT_INTERVAL_SECONDS",
    "DEFAULT_BACKOFF_BASE_SECONDS",
    "DEFAULT_BACKOFF_CAP_SECONDS",
    "DEFAULT_RETENTION_DAYS",
    "enqueue_apply_job",
    "claim_next_job",
    "start_attempt",
    "heartbeat",
    "mark_succeeded",
    "mark_failed",
    "reap_stale_claims",
    "sweep_version_gaps",
    "sweep_retention",
    "retry_job",
    "backoff_seconds",
    "APPLY_NOTIFY_CHANNEL",
    "notify_apply_pending",
]

#: NOTIFY channel the datalake runtime listens on. Signalled whenever a job is
#: enqueued, so an apply starts in seconds instead of waiting for the poll.
#:
#: ⛔ NOTIFY is FIRE-AND-FORGET. A listener that is reconnecting misses it
#: entirely, and nothing recovers it. That is why the periodic tick still exists —
#: slowed to a safety net rather than the latency path. Deleting the poll because
#: "we have events now" would reintroduce the stale-forever failure this layer was
#: built to remove.
APPLY_NOTIFY_CHANNEL = "decoration_apply"

JOBS_TABLE = "decoration_apply_jobs"
STATUS_TABLE = "decoration_status"
FACTS_TABLE = "decoration_facts"

DEFAULT_MAX_ATTEMPTS = 5
DEFAULT_CLAIM_TIMEOUT_SECONDS = 300          # 5 min — a dead worker is detected within this
DEFAULT_HEARTBEAT_INTERVAL_SECONDS = 30
DEFAULT_BACKOFF_BASE_SECONDS = 2
DEFAULT_BACKOFF_CAP_SECONDS = 900            # 15 min
DEFAULT_RETENTION_DAYS = 30

_ALL = (JOBS_TABLE, STATUS_TABLE, FACTS_TABLE)


def backoff_seconds(
    attempt: int,
    base: int = DEFAULT_BACKOFF_BASE_SECONDS,
    cap: int = DEFAULT_BACKOFF_CAP_SECONDS,
) -> int:
    """``(2 ** attempt) * base``, capped. A failure without backoff is a hot loop."""
    if attempt < 0:
        attempt = 0
    # Bound the exponent before the shift so a runaway attempt cannot build a
    # multi-thousand-bit integer on the way to being capped.
    if attempt > 32:
        return cap
    return min((2 ** attempt) * base, cap)


# ── § 3.6.2 — enqueue ────────────────────────────────────────────────────────

def enqueue_apply_job(
    backend: Any,
    *,
    decoration: str,
    tenant_id: str,
    namespace_id: str,
    generation: int,
    description: str = "",
) -> bool:
    """Enqueue one apply job. **Collapsing: at most one live job per target.**

    ``job_key`` is ``(decoration, tenant_id, namespace_id)`` — deliberately WITHOUT
    ``generation``. A job's identity is its TARGET; the generation is the target's
    desired state, which advances in place. So a second fact arriving while a job is
    already pending folds into that row (raising ``generation`` to the newer value)
    instead of creating a second job.

    **Why this is the shape.** The obvious alternative — generation in the key, one
    row per trigger — was built first and measured: a simulated 12-source burst
    produced 12 jobs, 936,708 row-updates for ~78,059 distinct rows, 40 deadlocks,
    and 5 attempts on one job. Four workers each claimed different keys and ran
    concurrent full-table UPDATEs over the same rows. Collapsing cannot be done by
    delaying the drain (the queue still holds N claimable rows); it must happen at
    ENQUEUE, by key.

    A partial unique index (``UNIQUE ... WHERE state='pending'``) would express this
    more directly, but ``create_table()`` only builds single-column indexes — see the
    warning in ``decoration_store``. Uniqueness here is by construction, the same
    mechanism every other key in this layer uses.

    ``GREATEST`` guards ordering: two producers racing with different generations
    leave the NEWER one queued, never the older. A job already claimed or running is
    not modified — its own completion advances ``applied_version``, and any remaining
    gap re-triggers the backstop on the next tick.

    **Must be called AFTER the producer's fact writes commit, never inside that
    transaction.** A job claimed before its facts are visible would apply the previous
    generation.

    Returns:
        True if a new job row was inserted; False if it already existed.
    """
    job_key = build_key(decoration, tenant_id, namespace_id)
    # The conflict clause must RE-ARM terminal rows, not just advance pending ones.
    # A succeeded row keeps this job_key forever, so gating on state='pending' alone
    # would make every future enqueue a silent no-op and the decoration would stop
    # applying permanently — worse than the duplicate-job bug this replaces.
    #
    # 'claimed' is deliberately EXCLUDED from the state list: that row is mid-apply on
    # some worker, and resetting it under that worker would let a second worker claim
    # the same target concurrently — reintroducing the exact deadlock being fixed. The
    # in-flight apply advances applied_version to ITS generation; the newer generation
    # then shows as a version gap and the backstop re-enqueues on the next tick. Slower
    # by one tick, never lost.
    #
    # `EXCLUDED.generation > current` makes this monotonic: a late-arriving older
    # generation cannot rewind a target, and an identical re-enqueue is a no-op that
    # returns no row (so it wakes no listener).
    sql = f"""
INSERT INTO {JOBS_TABLE} (
    job_key, decoration, tenant_id, namespace_id, generation, state,
    attempt, max_attempts, next_attempt_at, enqueued_at, description,
    is_deleted, created_at, updated_at)
VALUES (
    %(job_key)s, %(decoration)s, %(tenant_id)s, %(namespace_id)s, %(generation)s,
    'pending', 0, %(max_attempts)s, now(), now(), %(description)s,
    false, now(), now())
ON CONFLICT (job_key) DO UPDATE
   SET generation      = EXCLUDED.generation,
       state           = 'pending',
       attempt         = 0,
       error           = NULL,
       claimed_by      = NULL,
       claimed_at      = NULL,
       finished_at     = NULL,
       rows_updated    = NULL,
       next_attempt_at = now(),
       enqueued_at     = now(),
       updated_at      = now()
 WHERE {JOBS_TABLE}.state IN ('pending', 'succeeded', 'failed', 'abandoned')
   AND EXCLUDED.generation > {JOBS_TABLE}.generation
RETURNING job_key"""
    rows = backend._execute_write(
        sql,
        {
            "job_key": job_key,
            "decoration": decoration,
            "tenant_id": tenant_id,
            "namespace_id": namespace_id,
            "generation": generation,
            "max_attempts": DEFAULT_MAX_ATTEMPTS,
            "description": description or f"Apply {decoration} for {tenant_id}",
        },
        tenant_id=GLOBAL_TENANT,
        relations=[JOBS_TABLE],
    )
    # True when a row was inserted OR an existing pending row advanced to a newer
    # generation. False when the conflicting row was already at/ahead of this
    # generation, or was claimed/running — in both cases the work is already covered.
    inserted = bool(rows)
    if inserted:
        notify_apply_pending(backend, decoration, tenant_id)
    return inserted


def notify_apply_pending(backend: Any, decoration: str, tenant_id: str) -> None:
    """Signal listeners that a job is waiting. Best-effort, never raises.

    Sent only when an INSERT actually happened — a duplicate enqueue collides on
    the PK and must not wake every worker for work that is already queued.

    The payload is advisory: a listener debounces and then drains whatever is
    pending, rather than trusting the payload to describe the work. That keeps a
    lost or coalesced notification harmless.
    """
    try:
        backend._execute_write(
            "SELECT pg_notify(%(chan)s, %(payload)s)",
            {"chan": APPLY_NOTIFY_CHANNEL, "payload": f"{decoration}|{tenant_id}"},
            tenant_id=GLOBAL_TENANT,
            relations=[JOBS_TABLE],
        )
    except Exception:
        # A missed signal costs latency, never correctness — the periodic sweep
        # still finds the job. Never let observability break the enqueue.
        pass


# ── § 3.6.3 — claim ──────────────────────────────────────────────────────────

def claim_next_job(
    backend: Any,
    *,
    worker: str,
    decorations: Optional[Sequence[str]] = None,
) -> Optional[dict[str, Any]]:
    """Claim exactly one runnable job, or return None.

    The **CTE form is required**. The intuitive shape —
    ``UPDATE … WHERE job_key = (SELECT … FOR UPDATE SKIP LOCKED LIMIT 1)`` — does NOT
    give exactly-one-claimer: the sub-SELECT's lock does not constrain the outer
    statement's snapshot, so a row whose ``state`` changed in between is still stomped.
    The CTE locks and updates the *same* row in one statement.

    **The claim sets ``heartbeat_at``.** It is nullable and the reaper's predicate is
    ``heartbeat_at < now() - :timeout``; under three-valued logic ``NULL < anything``
    is NULL, **not true**. A worker dying between claim and first beat would otherwise
    leave the row ``claimed`` forever, invisible to the reaper — precisely the stuck
    state the reaper exists to prevent, reintroduced by a NULL.

    ``attempt`` is deliberately **not** incremented here — see :func:`start_attempt`.
    """
    filt = ""
    params: dict[str, Any] = {"worker": worker}
    if decorations:
        filt = "     AND decoration = ANY(%(decorations)s)\n"
        params["decorations"] = list(decorations)

    sql = f"""
WITH claimed AS (
  SELECT job_key FROM {JOBS_TABLE}
   WHERE state = 'pending'
     AND next_attempt_at <= now()
     AND is_deleted IS NOT TRUE
{filt}   ORDER BY enqueued_at
   FOR UPDATE SKIP LOCKED
   LIMIT 1)
UPDATE {JOBS_TABLE} j
   SET state = 'claimed', claimed_by = %(worker)s, claimed_at = now(),
       heartbeat_at = now(), started_at = now(), updated_at = now()
  FROM claimed c
 WHERE j.job_key = c.job_key
RETURNING j.*"""
    rows = backend._execute_write(
        sql, params, tenant_id=GLOBAL_TENANT, relations=[JOBS_TABLE]
    )
    return rows[0] if rows else None


def start_attempt(backend: Any, job_key: str, source_version: Optional[str]) -> None:
    """Increment ``attempt`` and capture ``source_version`` as the apply's first act.

    **Incremented here, not at claim.** A job re-armed after a worker died would
    otherwise consume an attempt for work that never ran, so repeated crashes could
    ``abandon`` a perfectly healthy job without it ever failing on its own merits.
    ``attempt`` counts **executions**.

    ``source_version`` is captured now and stamped by the apply, so a producer landing
    newer facts mid-apply cannot have them attributed to this job.
    """
    backend._execute_write(
        f"""
UPDATE {JOBS_TABLE}
   SET attempt = attempt + 1, source_version = %(sv)s, updated_at = now()
 WHERE job_key = %(k)s
   -- Guarded on `claimed`: without it a job that already ran and was re-enqueued
   -- at the same key increments again, so `attempt` counts ENQUEUES rather than
   -- executions. Measured: 13 of 42 succeeded jobs showed attempt=2 with no
   -- error — a retry that never happened, which makes the column untrustworthy
   -- exactly where an operator needs to trust it.
   AND state = 'claimed'""",
        {"k": job_key, "sv": source_version},
        tenant_id=GLOBAL_TENANT,
        relations=[JOBS_TABLE],
    )


def heartbeat(backend: Any, job_key: str) -> None:
    """Refresh ``heartbeat_at``. Called by the RUNNING worker on an interval.

    This is what distinguishes *slow* from *dead* — the actual question. Keying the
    reaper on ``claimed_at`` instead would re-arm any apply exceeding the timeout
    **while it was still running**.
    """
    backend._execute_write(
        f"UPDATE {JOBS_TABLE} SET heartbeat_at = now(), updated_at = now() "
        f"WHERE job_key = %(k)s AND state = 'claimed'",
        {"k": job_key},
        tenant_id=GLOBAL_TENANT,
        relations=[JOBS_TABLE],
    )


# ── terminal transitions ─────────────────────────────────────────────────────

def mark_succeeded(backend: Any, job_key: str, rows_updated: int) -> None:
    """Terminal success. ``rows_updated`` must be the SINK's count.

    Not the driver's rowcount: the apply's outermost statement is
    ``UPDATE decoration_status``, which affects exactly one row. Recording that would
    show ``1`` for a 4,633-row refresh and — worse — break the event suppression rule
    (*emit only when an apply CHANGED rows*), making every routine tick emit.
    """
    backend._execute_write(
        f"""
UPDATE {JOBS_TABLE}
   SET state = 'succeeded', rows_updated = %(n)s, error = NULL,
       pending_fallback = NULL, finished_at = now(), updated_at = now()
 WHERE job_key = %(k)s""",
        {"k": job_key, "n": rows_updated},
        tenant_id=GLOBAL_TENANT,
        relations=[JOBS_TABLE],
    )


def mark_failed(backend: Any, job: dict[str, Any], error: str) -> str:
    """Record a failed attempt; re-arm with backoff or abandon.

    Returns the resulting state — ``'pending'`` or ``'abandoned'``. ``abandoned`` is
    terminal but **not permanent**: :func:`retry_job` resets it.
    """
    attempt = int(job.get("attempt") or 0)
    max_attempts = int(job.get("max_attempts") or DEFAULT_MAX_ATTEMPTS)

    if attempt >= max_attempts:
        backend._execute_write(
            f"""
UPDATE {JOBS_TABLE}
   SET state = 'abandoned', error = %(e)s, finished_at = now(), updated_at = now()
 WHERE job_key = %(k)s""",
            {"k": job["job_key"], "e": error},
            tenant_id=GLOBAL_TENANT,
            relations=[JOBS_TABLE],
        )
        return "abandoned"

    backend._execute_write(
        f"""
UPDATE {JOBS_TABLE}
   SET state = 'pending', error = %(e)s,
       next_attempt_at = now() + (%(backoff)s * INTERVAL '1 second'),
       claimed_by = NULL, claimed_at = NULL, updated_at = now()
 WHERE job_key = %(k)s""",
        {"k": job["job_key"], "e": error, "backoff": backoff_seconds(attempt)},
        tenant_id=GLOBAL_TENANT,
        relations=[JOBS_TABLE],
    )
    return "pending"


def retry_job(backend: Any, job_key: str) -> bool:
    """Operator action: reset a terminal job to ``pending`` with ``attempt = 0``.

    A state described as stuck-forever with a Retry button offering no transition
    would be a contradiction — this is that transition.
    """
    rows = backend._execute_write(
        f"""
UPDATE {JOBS_TABLE}
   SET state = 'pending', attempt = 0, error = NULL, next_attempt_at = now(),
       claimed_by = NULL, claimed_at = NULL, heartbeat_at = NULL,
       finished_at = NULL, updated_at = now()
 WHERE job_key = %(k)s AND state IN ('abandoned', 'failed')
RETURNING job_key""",
        {"k": job_key},
        tenant_id=GLOBAL_TENANT,
        relations=[JOBS_TABLE],
    )
    return bool(rows)


# ── § 3.6.4 — the reaper, and the two sweeps ─────────────────────────────────

def reap_stale_claims(
    backend: Any, claim_timeout_seconds: int = DEFAULT_CLAIM_TIMEOUT_SECONDS
) -> list[dict[str, Any]]:
    """Re-arm jobs whose worker stopped heartbeating. Runs at boot AND periodically.

    **On every worker, NOT leader-gated** — deliberately diverging from the ETL
    precedent, which gates its equivalent on ``if _scheduler.is_leader``. That gate is
    exactly the mechanism the recorded defect broke: a reaper only the leader runs does
    not run at all when leadership is wrong. This one is idempotent and its ``WHERE``
    is self-limiting, so N concurrent reapers are harmless — the worst case is two
    workers issuing the same no-op ``UPDATE``.

    Keyed on ``heartbeat_at``, never ``claimed_at``: the latter reaps slow-but-healthy
    jobs while they are still running.
    """
    return backend._execute_write(
        f"""
UPDATE {JOBS_TABLE}
   SET state = 'pending', claimed_by = NULL, claimed_at = NULL, updated_at = now()
 WHERE state = 'claimed'
   AND heartbeat_at < now() - (%(timeout)s * INTERVAL '1 second')
   AND is_deleted IS NOT TRUE
RETURNING job_key, decoration, tenant_id, namespace_id, attempt""",
        {"timeout": claim_timeout_seconds},
        tenant_id=GLOBAL_TENANT,
        relations=[JOBS_TABLE],
    )


def sweep_version_gaps(backend: Any) -> list[dict[str, Any]]:
    """Backstop: find tenants whose landed facts were never applied.

    Producer-commits-then-enqueue-fails is the one failure that reproduces the original
    defect exactly — facts landed, ``status='ok'``, no job, sink stale forever with no
    error surface. Enqueue cannot live in the fact transaction, so it **will**
    occasionally fail; this closes the window without distributed-transaction machinery.

    **Compares version to version, never version to generation.** ``source_version`` is
    a varchar producer stamp; ``generation`` is a bigint fence on fact rows. Comparing
    across the two is meaningless and the sweep would either fire constantly or never.

    Returns the ``(decoration, tenant, namespace)`` triples needing a job. The caller
    enqueues at a **fresh** generation.
    """
    return backend._execute_write(
        f"""
SELECT decoration, tenant_id, namespace_id, source_version, applied_version
  FROM {STATUS_TABLE}
 WHERE is_deleted IS NOT TRUE
   AND status = 'ok'
   AND source_version IS NOT NULL
   AND applied_version IS DISTINCT FROM source_version
   -- Only APPLY TARGETS (RowKind.APPLY_TARGET — see decorations.row_kind).
   -- A feed row or a tenant roll-up names NO sink rows, so a job for it could
   -- only ever report 0 rows updated. Measured: 10 of 42 jobs were these no-ops.
   --
   -- ⛔ The predicate below MUST stay equivalent to `is_apply_target()`. It is
   -- expressed in SQL because the filter runs in the database, but the Python
   -- classifier is the definition — `test_row_kind_sql_matches_python` asserts
   -- the two agree on every combination.
   AND tenant_id <> ''
   AND namespace_id <> ''""",
        {},
        tenant_id=GLOBAL_TENANT,
        relations=[STATUS_TABLE],
    )


def sweep_retention(
    backend: Any, retention_days: int = DEFAULT_RETENTION_DAYS
) -> int:
    """Soft-delete ``succeeded`` jobs older than the window.

    ``failed``/``abandoned`` rows are **never** auto-deleted — they are the audit trail
    the jobs endpoint exists to show, and an unapplied retraction must always have a
    visible owner.
    """
    rows = backend._execute_write(
        f"""
UPDATE {JOBS_TABLE}
   SET is_deleted = true, updated_at = now()
 WHERE state = 'succeeded'
   AND is_deleted IS NOT TRUE
   AND finished_at < now() - (%(days)s * INTERVAL '1 day')
RETURNING job_key""",
        {"days": retention_days},
        tenant_id=GLOBAL_TENANT,
        relations=[JOBS_TABLE],
    )
    return len(rows)
