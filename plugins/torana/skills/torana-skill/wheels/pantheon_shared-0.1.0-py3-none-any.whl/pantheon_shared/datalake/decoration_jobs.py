"""The apply state machine's durable queue — enqueue, claim, heartbeat, reap.

Design: ``DECORATION_LAYER_SPEC.md`` § 3.6.1 (states), § 3.6.2 (enqueue + backstop),
§ 3.6.3 (claim), § 3.6.4 (restart recovery + retention).

**A job is a ROW, not an in-memory task.** That single decision is what makes restart
recovery possible: a worker that dies mid-apply leaves its row visible to the next
worker. Every statement here is built as SQL text and executed through the backend's
``_execute_write`` seam, because the claim and the apply both need ``RETURNING`` —
which ``update_rows`` discards and ``query`` cannot commit.

Concurrency model, stated once because it is the thing most easily got wrong:

* **The claim is the mutex.** ``FOR UPDATE SKIP LOCKED`` inside a CTE gives
  exactly-one-claimer under N gunicorn workers.
* **Idempotency is the safety property.** If a re-armed job is somehow applied twice,
  the apply derives everything from current fact state, so the result is identical.
  A concurrent duplicate is wasteful, never incorrect.
* **No advisory locks.** ``pg_advisory_lock`` is connection-scoped; returning a pooled
  connection silently releases it. That is the recorded ETL leader-election defect —
  four workers all believing they were leader with zero locks actually held.
"""

from __future__ import annotations

from typing import Any, Optional, Sequence

from pantheon_shared.datalake.decoration_store import GLOBAL_TENANT, build_key

__all__ = [
    "JOBS_TABLE",
    "STATUS_TABLE",
    "FACTS_TABLE",
    "DEFAULT_MAX_ATTEMPTS",
    "DEFAULT_CLAIM_TIMEOUT_SECONDS",
    "DEFAULT_HEARTBEAT_INTERVAL_SECONDS",
    "DEFAULT_BACKOFF_BASE_SECONDS",
    "DEFAULT_BACKOFF_CAP_SECONDS",
    "DEFAULT_RETENTION_DAYS",
    "enqueue_apply_job",
    "claim_next_job",
    "start_attempt",
    "heartbeat",
    "mark_succeeded",
    "mark_failed",
    "reap_stale_claims",
    "sweep_version_gaps",
    "sweep_unapplied_rows",
    "sweep_retention",
    "retry_job",
    "backoff_seconds",
    "APPLY_NOTIFY_CHANNEL",
    "notify_apply_pending",
]

#: NOTIFY channel the datalake runtime listens on. Signalled whenever a job is
#: enqueued, so an apply starts in seconds instead of waiting for the poll.
#:
#: ⛔ NOTIFY is FIRE-AND-FORGET. A listener that is reconnecting misses it
#: entirely, and nothing recovers it. That is why the periodic tick still exists —
#: slowed to a safety net rather than the latency path. Deleting the poll because
#: "we have events now" would reintroduce the stale-forever failure this layer was
#: built to remove.
APPLY_NOTIFY_CHANNEL = "decoration_apply"

JOBS_TABLE = "decoration_apply_jobs"
STATUS_TABLE = "decoration_status"
FACTS_TABLE = "decoration_facts"

DEFAULT_MAX_ATTEMPTS = 5
DEFAULT_CLAIM_TIMEOUT_SECONDS = 300          # 5 min — a dead worker is detected within this
DEFAULT_HEARTBEAT_INTERVAL_SECONDS = 30
DEFAULT_BACKOFF_BASE_SECONDS = 2
DEFAULT_BACKOFF_CAP_SECONDS = 900            # 15 min
DEFAULT_RETENTION_DAYS = 30

_ALL = (JOBS_TABLE, STATUS_TABLE, FACTS_TABLE)


def backoff_seconds(
    attempt: int,
    base: int = DEFAULT_BACKOFF_BASE_SECONDS,
    cap: int = DEFAULT_BACKOFF_CAP_SECONDS,
) -> int:
    """``(2 ** attempt) * base``, capped. A failure without backoff is a hot loop."""
    if attempt < 0:
        attempt = 0
    # Bound the exponent before the shift so a runaway attempt cannot build a
    # multi-thousand-bit integer on the way to being capped.
    if attempt > 32:
        return cap
    return min((2 ** attempt) * base, cap)


# ── § 3.6.2 — enqueue ────────────────────────────────────────────────────────

def enqueue_apply_job(
    backend: Any,
    *,
    decoration: str,
    tenant_id: str,
    namespace_id: str,
    generation: int,
    description: str = "",
) -> bool:
    """Enqueue one apply job. **Collapsing: at most one live job per target.**

    ``job_key`` is ``(decoration, tenant_id, namespace_id)`` — deliberately WITHOUT
    ``generation``. A job's identity is its TARGET; the generation is the target's
    desired state, which advances in place. So a second fact arriving while a job is
    already pending folds into that row (raising ``generation`` to the newer value)
    instead of creating a second job.

    **Why this is the shape.** The obvious alternative — generation in the key, one
    row per trigger — was built first and measured: a simulated 12-source burst
    produced 12 jobs, 936,708 row-updates for ~78,059 distinct rows, 40 deadlocks,
    and 5 attempts on one job. Four workers each claimed different keys and ran
    concurrent full-table UPDATEs over the same rows. Collapsing cannot be done by
    delaying the drain (the queue still holds N claimable rows); it must happen at
    ENQUEUE, by key.

    A partial unique index (``UNIQUE ... WHERE state='pending'``) would express this
    more directly, but ``create_table()`` only builds single-column indexes — see the
    warning in ``decoration_store``. Uniqueness here is by construction, the same
    mechanism every other key in this layer uses.

    ``GREATEST`` guards ordering: two producers racing with different generations
    leave the NEWER one queued, never the older. A job already claimed or running is
    not modified — its own completion advances ``applied_version``, and any remaining
    gap re-triggers the backstop on the next tick.

    **Must be called AFTER the producer's fact writes commit, never inside that
    transaction.** A job claimed before its facts are visible would apply the previous
    generation.

    Returns:
        True if a new job row was inserted; False if it already existed.
    """
    job_key = build_key(decoration, tenant_id, namespace_id)
    # The conflict clause must RE-ARM terminal rows, not just advance pending ones.
    # A succeeded row keeps this job_key forever, so gating on state='pending' alone
    # would make every future enqueue a silent no-op and the decoration would stop
    # applying permanently — worse than the duplicate-job bug this replaces.
    #
    # 'claimed' is deliberately EXCLUDED from the state list: that row is mid-apply on
    # some worker, and resetting it under that worker would let a second worker claim
    # the same target concurrently — reintroducing the exact deadlock being fixed. The
    # in-flight apply advances applied_version to ITS generation; the newer generation
    # then shows as a version gap and the backstop re-enqueues on the next tick. Slower
    # by one tick, never lost.
    #
    # `EXCLUDED.generation > current` makes this monotonic: a late-arriving older
    # generation cannot rewind a target, and an identical re-enqueue is a no-op that
    # returns no row (so it wakes no listener).
    sql = f"""
INSERT INTO {JOBS_TABLE} (
    job_key, decoration, tenant_id, namespace_id, generation, state,
    attempt, max_attempts, next_attempt_at, enqueued_at, description,
    is_deleted, created_at, updated_at)
VALUES (
    %(job_key)s, %(decoration)s, %(tenant_id)s, %(namespace_id)s, %(generation)s,
    'pending', 0, %(max_attempts)s, now(), now(), %(description)s,
    false, now(), now())
ON CONFLICT (job_key) DO UPDATE
   SET generation      = EXCLUDED.generation,
       state           = 'pending',
       attempt         = 0,
       error           = NULL,
       claimed_by      = NULL,
       claimed_at      = NULL,
       finished_at     = NULL,
       rows_updated    = NULL,
       next_attempt_at = now(),
       enqueued_at     = now(),
       updated_at      = now()
 WHERE {JOBS_TABLE}.state IN ('pending', 'succeeded', 'failed', 'abandoned')
   AND EXCLUDED.generation > {JOBS_TABLE}.generation
RETURNING job_key"""
    rows = backend._execute_write(
        sql,
        {
            "job_key": job_key,
            "decoration": decoration,
            "tenant_id": tenant_id,
            "namespace_id": namespace_id,
            "generation": generation,
            "max_attempts": DEFAULT_MAX_ATTEMPTS,
            "description": description or f"Apply {decoration} for {tenant_id}",
        },
        tenant_id=GLOBAL_TENANT,
        relations=[JOBS_TABLE],
    )
    # True when a row was inserted OR an existing pending row advanced to a newer
    # generation. False when the conflicting row was already at/ahead of this
    # generation, or was claimed/running — in both cases the work is already covered.
    inserted = bool(rows)
    if inserted:
        notify_apply_pending(backend, decoration, tenant_id)
    return inserted


def notify_apply_pending(backend: Any, decoration: str, tenant_id: str) -> None:
    """Signal listeners that a job is waiting. Best-effort, never raises.

    Sent only when an INSERT actually happened — a duplicate enqueue collides on
    the PK and must not wake every worker for work that is already queued.

    The payload is advisory: a listener debounces and then drains whatever is
    pending, rather than trusting the payload to describe the work. That keeps a
    lost or coalesced notification harmless.
    """
    try:
        backend._execute_write(
            "SELECT pg_notify(%(chan)s, %(payload)s)",
            {"chan": APPLY_NOTIFY_CHANNEL, "payload": f"{decoration}|{tenant_id}"},
            tenant_id=GLOBAL_TENANT,
            relations=[JOBS_TABLE],
        )
    except Exception:
        # A missed signal costs latency, never correctness — the periodic sweep
        # still finds the job. Never let observability break the enqueue.
        pass


# ── § 3.6.3 — claim ──────────────────────────────────────────────────────────

def claim_next_job(
    backend: Any,
    *,
    worker: str,
    decorations: Optional[Sequence[str]] = None,
) -> Optional[dict[str, Any]]:
    """Claim exactly one runnable job, or return None.

    The **CTE form is required**. The intuitive shape —
    ``UPDATE … WHERE job_key = (SELECT … FOR UPDATE SKIP LOCKED LIMIT 1)`` — does NOT
    give exactly-one-claimer: the sub-SELECT's lock does not constrain the outer
    statement's snapshot, so a row whose ``state`` changed in between is still stomped.
    The CTE locks and updates the *same* row in one statement.

    **The claim sets ``heartbeat_at``.** It is nullable and the reaper's predicate is
    ``heartbeat_at < now() - :timeout``; under three-valued logic ``NULL < anything``
    is NULL, **not true**. A worker dying between claim and first beat would otherwise
    leave the row ``claimed`` forever, invisible to the reaper — precisely the stuck
    state the reaper exists to prevent, reintroduced by a NULL.

    ``attempt`` is deliberately **not** incremented here — see :func:`start_attempt`.
    """
    filt = ""
    params: dict[str, Any] = {"worker": worker}
    if decorations:
        filt = "     AND decoration = ANY(%(decorations)s)\n"
        params["decorations"] = list(decorations)

    sql = f"""
WITH claimed AS (
  SELECT job_key FROM {JOBS_TABLE}
   WHERE state = 'pending'
     AND next_attempt_at <= now()
     AND is_deleted IS NOT TRUE
{filt}   ORDER BY enqueued_at
   FOR UPDATE SKIP LOCKED
   LIMIT 1)
UPDATE {JOBS_TABLE} j
   SET state = 'claimed', claimed_by = %(worker)s, claimed_at = now(),
       heartbeat_at = now(), started_at = now(), updated_at = now()
  FROM claimed c
 WHERE j.job_key = c.job_key
RETURNING j.*"""
    rows = backend._execute_write(
        sql, params, tenant_id=GLOBAL_TENANT, relations=[JOBS_TABLE]
    )
    return rows[0] if rows else None


def start_attempt(backend: Any, job_key: str, source_version: Optional[str]) -> None:
    """Increment ``attempt`` and capture ``source_version`` as the apply's first act.

    **Incremented here, not at claim.** A job re-armed after a worker died would
    otherwise consume an attempt for work that never ran, so repeated crashes could
    ``abandon`` a perfectly healthy job without it ever failing on its own merits.
    ``attempt`` counts **executions**.

    ``source_version`` is captured now and stamped by the apply, so a producer landing
    newer facts mid-apply cannot have them attributed to this job.
    """
    backend._execute_write(
        f"""
UPDATE {JOBS_TABLE}
   SET attempt = attempt + 1, source_version = %(sv)s, updated_at = now()
 WHERE job_key = %(k)s
   -- Guarded on `claimed`: without it a job that already ran and was re-enqueued
   -- at the same key increments again, so `attempt` counts ENQUEUES rather than
   -- executions. Measured: 13 of 42 succeeded jobs showed attempt=2 with no
   -- error — a retry that never happened, which makes the column untrustworthy
   -- exactly where an operator needs to trust it.
   AND state = 'claimed'""",
        {"k": job_key, "sv": source_version},
        tenant_id=GLOBAL_TENANT,
        relations=[JOBS_TABLE],
    )


def heartbeat(backend: Any, job_key: str) -> None:
    """Refresh ``heartbeat_at``. Called by the RUNNING worker on an interval.

    This is what distinguishes *slow* from *dead* — the actual question. Keying the
    reaper on ``claimed_at`` instead would re-arm any apply exceeding the timeout
    **while it was still running**.
    """
    backend._execute_write(
        f"UPDATE {JOBS_TABLE} SET heartbeat_at = now(), updated_at = now() "
        f"WHERE job_key = %(k)s AND state = 'claimed'",
        {"k": job_key},
        tenant_id=GLOBAL_TENANT,
        relations=[JOBS_TABLE],
    )


# ── terminal transitions ─────────────────────────────────────────────────────

def mark_succeeded(backend: Any, job_key: str, rows_updated: int) -> None:
    """Terminal success. ``rows_updated`` must be the SINK's count.

    Not the driver's rowcount: the apply's outermost statement is
    ``UPDATE decoration_status``, which affects exactly one row. Recording that would
    show ``1`` for a 4,633-row refresh and — worse — break the event suppression rule
    (*emit only when an apply CHANGED rows*), making every routine tick emit.
    """
    backend._execute_write(
        f"""
UPDATE {JOBS_TABLE}
   SET state = 'succeeded', rows_updated = %(n)s, error = NULL,
       pending_fallback = NULL, finished_at = now(), updated_at = now()
 WHERE job_key = %(k)s""",
        {"k": job_key, "n": rows_updated},
        tenant_id=GLOBAL_TENANT,
        relations=[JOBS_TABLE],
    )


def mark_failed(backend: Any, job: dict[str, Any], error: str) -> str:
    """Record a failed attempt; re-arm with backoff or abandon.

    Returns the resulting state — ``'pending'`` or ``'abandoned'``. ``abandoned`` is
    terminal but **not permanent**: :func:`retry_job` resets it.
    """
    attempt = int(job.get("attempt") or 0)
    max_attempts = int(job.get("max_attempts") or DEFAULT_MAX_ATTEMPTS)

    if attempt >= max_attempts:
        backend._execute_write(
            f"""
UPDATE {JOBS_TABLE}
   SET state = 'abandoned', error = %(e)s, finished_at = now(), updated_at = now()
 WHERE job_key = %(k)s""",
            {"k": job["job_key"], "e": error},
            tenant_id=GLOBAL_TENANT,
            relations=[JOBS_TABLE],
        )
        return "abandoned"

    backend._execute_write(
        f"""
UPDATE {JOBS_TABLE}
   SET state = 'pending', error = %(e)s,
       next_attempt_at = now() + (%(backoff)s * INTERVAL '1 second'),
       claimed_by = NULL, claimed_at = NULL, updated_at = now()
 WHERE job_key = %(k)s""",
        {"k": job["job_key"], "e": error, "backoff": backoff_seconds(attempt)},
        tenant_id=GLOBAL_TENANT,
        relations=[JOBS_TABLE],
    )
    return "pending"


def retry_job(backend: Any, job_key: str) -> bool:
    """Operator action: reset a terminal job to ``pending`` with ``attempt = 0``.

    A state described as stuck-forever with a Retry button offering no transition
    would be a contradiction — this is that transition.
    """
    rows = backend._execute_write(
        f"""
UPDATE {JOBS_TABLE}
   SET state = 'pending', attempt = 0, error = NULL, next_attempt_at = now(),
       claimed_by = NULL, claimed_at = NULL, heartbeat_at = NULL,
       finished_at = NULL, updated_at = now()
 WHERE job_key = %(k)s AND state IN ('abandoned', 'failed')
RETURNING job_key""",
        {"k": job_key},
        tenant_id=GLOBAL_TENANT,
        relations=[JOBS_TABLE],
    )
    return bool(rows)


# ── § 3.6.4 — the reaper, and the two sweeps ─────────────────────────────────

def reap_stale_claims(
    backend: Any, claim_timeout_seconds: int = DEFAULT_CLAIM_TIMEOUT_SECONDS
) -> list[dict[str, Any]]:
    """Re-arm jobs whose worker stopped heartbeating. Runs at boot AND periodically.

    **On every worker, NOT leader-gated** — deliberately diverging from the ETL
    precedent, which gates its equivalent on ``if _scheduler.is_leader``. That gate is
    exactly the mechanism the recorded defect broke: a reaper only the leader runs does
    not run at all when leadership is wrong. This one is idempotent and its ``WHERE``
    is self-limiting, so N concurrent reapers are harmless — the worst case is two
    workers issuing the same no-op ``UPDATE``.

    Keyed on ``heartbeat_at``, never ``claimed_at``: the latter reaps slow-but-healthy
    jobs while they are still running.
    """
    return backend._execute_write(
        f"""
UPDATE {JOBS_TABLE}
   SET state = 'pending', claimed_by = NULL, claimed_at = NULL, updated_at = now()
 WHERE state = 'claimed'
   AND heartbeat_at < now() - (%(timeout)s * INTERVAL '1 second')
   AND is_deleted IS NOT TRUE
RETURNING job_key, decoration, tenant_id, namespace_id, attempt""",
        {"timeout": claim_timeout_seconds},
        tenant_id=GLOBAL_TENANT,
        relations=[JOBS_TABLE],
    )


def sweep_version_gaps(backend: Any) -> list[dict[str, Any]]:
    """Backstop: find tenants whose landed facts were never applied.

    Producer-commits-then-enqueue-fails is the one failure that reproduces the original
    defect exactly — facts landed, ``status='ok'``, no job, sink stale forever with no
    error surface. Enqueue cannot live in the fact transaction, so it **will**
    occasionally fail; this closes the window without distributed-transaction machinery.

    **Compares version to version, never version to generation.** ``source_version`` is
    a varchar producer stamp; ``generation`` is a bigint fence on fact rows. Comparing
    across the two is meaningless and the sweep would either fire constantly or never.

    Returns the ``(decoration, tenant, namespace)`` triples needing a job. The caller
    enqueues at a **fresh** generation.
    """
    return backend._execute_write(
        f"""
SELECT decoration, tenant_id, namespace_id, source_version, applied_version
  FROM {STATUS_TABLE}
 WHERE is_deleted IS NOT TRUE
   AND status = 'ok'
   AND source_version IS NOT NULL
   AND applied_version IS DISTINCT FROM source_version
   -- Only APPLY TARGETS (RowKind.APPLY_TARGET — see decorations.row_kind).
   -- A feed row or a tenant roll-up names NO sink rows, so a job for it could
   -- only ever report 0 rows updated. Measured: 10 of 42 jobs were these no-ops.
   --
   -- ⛔ The predicate below MUST stay equivalent to `is_apply_target()`. It is
   -- expressed in SQL because the filter runs in the database, but the Python
   -- classifier is the definition — `test_row_kind_sql_matches_python` asserts
   -- the two agree on every combination.
   AND tenant_id <> ''
   AND namespace_id <> ''""",
        {},
        tenant_id=GLOBAL_TENANT,
        relations=[STATUS_TABLE],
    )


def sweep_unapplied_rows(backend: Any) -> list[dict[str, Any]]:
    """Backstop #2: find tenants holding rows a decoration COULD fill but has not.

    ⛔ **WHY `sweep_version_gaps` CANNOT FIND THESE, AND IS NOT BROKEN.** That sweep asks
    *"was the last producer run applied?"* — a question about VERSIONS. This one asks
    *"is every eligible row actually decorated?"* — a question about ROWS. A target can
    answer the first perfectly and still fail the second, because ``applied_version`` is
    stamped by the apply statement **unconditionally**, including when its UPDATE matched
    zero rows (see ``build_apply``: the status UPDATE reads ``FROM counted``, never
    ``WHERE counted.n > 0``). So a row that was not eligible at apply time — or did not
    exist yet — leaves ``applied_version == source_version`` behind it, and the version
    check is satisfied forever while the row stays NULL.

    ⚠️ **MEASURED, on T1 (2026-09-21).** 18 ``vulnerabilities`` rows ingested 2025-12-23,
    seven months before the decoration layer shipped (``a006fa7``, 2026-07-31). All 12 of
    their distinct CVEs had facts in a 395,671-CVE store — ``CVE-2025-68664`` carried a
    real EPSS of 0.4293 (98.7th percentile) — and all 17 CVE-bearing rows read NULL.
    ``decorations status`` reported ``ok``, ``applied_version == source_version``, and
    ``sweep_version_gaps`` returned **0 gaps across every tenant**. The backstop ran every
    300s on every worker for seven weeks and correctly found nothing to do.

    ⛔ **A reader cannot tell this from an honest empty.** A dashboard renders "no
    exploitable vulnerabilities" identically whether EPSS is genuinely low or was never
    applied — the same opposite-conclusions failure ``expected_caller`` exists to remove
    in the write seam, reproduced one layer down.

    **Why a row probe and not "re-apply everything periodically".** A blind re-apply is a
    full-table UPDATE per decoration per tick — measured at 78,059 rows per job on the
    deadlock incident that ``_gap_generation`` was introduced to stop. This probe is a
    ``LIMIT 1`` existence check per (decoration, target): it enqueues only where a row
    genuinely lacks a fill that a fact could supply, so a healthy fleet does no work.

    ⚠️ **The probe MUST mirror the apply's own eligibility, not a simplification of it.**
    It reuses ``build_guard`` — the same fragment the apply and the ingest-time borrow
    both use — so a column the guard would refuse (an observed value, a higher-ranked
    decoration's stamp) is never counted as missing. A hand-written ``IS NULL`` here would
    re-enqueue forever on rows the apply then declines to touch: a hot loop that reports
    success and changes nothing.

    Returns the ``(decoration, tenant_id, namespace_id)`` triples needing a job, shaped
    exactly like :func:`sweep_version_gaps` so the caller enqueues them identically.
    """
    from pantheon_shared.datalake.decoration_sql import build_guard
    from pantheon_shared.datalake.decorations import DECORATIONS, Kind

    # Only APPLY TARGETS, same predicate as sweep_version_gaps — a feed row or a tenant
    # roll-up names no sink rows, so a job for it could only ever report 0 rows updated.
    targets = backend._execute_write(
        f"""
SELECT decoration, tenant_id, namespace_id, source_version
  FROM {STATUS_TABLE}
 WHERE is_deleted IS NOT TRUE
   AND status = 'ok'
   AND source_version IS NOT NULL
   AND source_version <> ''
   AND tenant_id <> ''
   AND namespace_id <> ''""",
        {},
        tenant_id=GLOBAL_TENANT,
        relations=[STATUS_TABLE],
    ) or []

    gaps: list[dict[str, Any]] = []
    for target in targets:
        decoration = target["decoration"]
        spec = DECORATIONS.get(decoration)
        if spec is None:
            # A status row for a decoration this build no longer ships. Not an error —
            # the retention sweep owns cleanup; re-enqueueing it would fail the apply.
            continue

        # ⛔ BOTH KINDS, and excluding DERIVE was a real bug in the first draft of this
        # function. `policy` — one of the two decorations shipping today — provides
        # NOTHING but DERIVE columns, so a SUBSTITUTE-only filter skipped it entirely
        # and missed the second confirmed instance of the very gap this sweep exists to
        # close (T1, `vulnerability_due_date` on 8 of 26 eligible rows).
        #
        # A DERIVE column still needs a FACT (`ci.<attr>`) to be written — it is
        # computed FROM the fact and the row, not from the row alone — so "fact exists
        # and column is empty" is the same question for both kinds. The kinds differ
        # only in their extra precondition, added per column below.
        # `''` for a global decoration — its facts are stored tenant-less and shared.
        fact_tenant = "" if spec.scope == "global" else target["tenant_id"]

        clauses: list[str] = []
        params: dict[str, Any] = {}
        for i, (column, out) in enumerate(spec.provides.items()):
            # The apply writes a column only where its guard passes AND the column is
            # currently empty. `build_guard` is reused verbatim so a column the apply
            # would decline (an observed value, a higher-ranked stamp) is never counted.
            parts = [build_guard(decoration, column), f"r.{column} IS NULL"]
            if out.kind is not Kind.SUBSTITUTE:
                # G6: a DERIVE expression yields NULL without its `requires` columns, so
                # a row missing them is NOT a gap — the apply would correctly skip it and
                # this sweep would re-enqueue forever. `requires`, never `reads`: the
                # latter is lineage and guarding on it inverts the breach column.
                parts.extend(f"r.{c} IS NOT NULL" for c in out.requires)

            # ⛔ PER-COLUMN, PER-ATTRIBUTE. "Any fact exists for this subject" is NOT
            # enough, and testing it that way is a self-inflicted hot loop: attributes
            # are not universal across subjects. `kev_due_date` exists for 1,656 of
            # ~353,522 CVEs, so `cisa_kev_data` is legitimately NULL on virtually every
            # row. MEASURED on T1 with the weaker predicate: 26 of 26 fully-decorated
            # rows reported as needing an apply, purely because no CVE was in KEV —
            # a sweep that would enqueue a no-op job every quantum, forever.
            akey = f"attr_{i}"
            params[akey] = out.attribute
            parts.append(
                f"EXISTS (SELECT 1 FROM {FACTS_TABLE} f"
                f" WHERE f.decoration = %(decoration)s"
                f"   AND f.tenant_id = %(fact_tenant)s"
                f"   AND f.subject_key = r.{spec.subject_column}"
                f"   AND f.attribute = %({akey})s"
                f"   AND f.is_deleted IS NOT TRUE)"
            )
            clauses.append("(" + " AND ".join(parts) + ")")

        if not clauses:
            continue

        # The guard is psycopg-escaped for parameterised execution (`LIKE 'decoration:%%'`).
        # This statement IS parameterised, so it stays escaped — `unescape_guard` is only
        # for evaluating a fragment standalone. Building the OR here rather than one query
        # per column keeps this to a single probe per target.
        missing = " OR ".join(clauses)

        try:
            # ⚠️ `to_regclass` GUARD, not a try/except around a failing SELECT. A tenant
            # that has never provisioned this sink table is the NORMAL case, not an
            # error: measured on this fleet, 26 status tenants × 4 decorations produced a
            # burst of `relation "assets" does not exist` at ERROR level every tick.
            # Logging a routine state as an error is how a real failure gets missed, and
            # a failed statement can also poison the surrounding transaction. Returning
            # no rows makes the probe skip the target silently, which is the truth.
            #
            # `to_regclass` resolves against the connection's search_path, so it asks
            # exactly the question the next statement would — "is this name resolvable
            # for THIS tenant's schema?" — rather than a catalog guess.
            exists = backend._execute_write(
                "SELECT to_regclass(%(rel)s) IS NOT NULL AS present",
                {"rel": spec.decorates},
                tenant_id=target["tenant_id"],
                relations=[spec.decorates],
            )
            if not exists or not exists[0].get("present"):
                continue

            hit = backend._execute_write(
                f"""
SELECT 1 AS needs_apply
  FROM {spec.decorates} r
 WHERE r.tenant_id = %(tenant)s
   AND r.namespace_id = %(namespace)s
   AND r.is_deleted IS NOT TRUE
   AND r.{spec.subject_column} IS NOT NULL
   AND ({missing})
 LIMIT 1""",
                {
                    "tenant": target["tenant_id"],
                    "namespace": target["namespace_id"],
                    "decoration": decoration,
                    "fact_tenant": fact_tenant,
                    **params,
                },
                tenant_id=target["tenant_id"],
                relations=[spec.decorates, FACTS_TABLE],
            )
        except Exception:
            # ⚠️ ISOLATED PER TARGET, and it must stay that way. One tenant whose sink
            # table does not exist yet (mid-provision) would otherwise abort the sweep
            # for every other tenant — turning a one-tenant gap into a fleet-wide one.
            # The caller logs; the next tick retries.
            continue

        if hit:
            gaps.append({
                "decoration": decoration,
                "tenant_id": target["tenant_id"],
                "namespace_id": target["namespace_id"],
                "source_version": target["source_version"],
                # Named so the enqueue description distinguishes this sweep's jobs from
                # the version-gap sweep's in `decorations jobs`.
                "reason": "unapplied_rows",
            })

    return gaps


def sweep_retention(
    backend: Any, retention_days: int = DEFAULT_RETENTION_DAYS
) -> int:
    """Soft-delete ``succeeded`` jobs older than the window.

    ``failed``/``abandoned`` rows are **never** auto-deleted — they are the audit trail
    the jobs endpoint exists to show, and an unapplied retraction must always have a
    visible owner.
    """
    rows = backend._execute_write(
        f"""
UPDATE {JOBS_TABLE}
   SET is_deleted = true, updated_at = now()
 WHERE state = 'succeeded'
   AND is_deleted IS NOT TRUE
   AND finished_at < now() - (%(days)s * INTERVAL '1 day')
RETURNING job_key""",
        {"days": retention_days},
        tenant_id=GLOBAL_TENANT,
        relations=[JOBS_TABLE],
    )
    return len(rows)
