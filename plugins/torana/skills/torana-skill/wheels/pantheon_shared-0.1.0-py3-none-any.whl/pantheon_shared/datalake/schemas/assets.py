from typing import Dict, Any
from .base import TableSchema


class AssetsSchema(TableSchema):
    """Schema definition for the assets table."""

    @property
    def table_name(self) -> str:
        return "assets"

    @property
    def primary_key(self) -> str:
        return "torana_entity_id"

    @property
    def description(self) -> str:
        return "Inventory of infrastructure assets, cloud resources, applications, and services with ownership and criticality information"

    @property
    def category(self) -> str:
        return "Asset Data"

    @property
    def timestamp_column(self) -> str:
        """Return the timestamp column for this table."""
        return "updated_at"

    @property
    def schema(self) -> Dict[str, Any]:
        return {
            "torana_entity_id": {"data_type": "VARCHAR(255)", "primary_key": True, "category": "Core Identity",
                "semantic_description": (
                    "Torana's stable id for one asset, prefixed by kind: `service:` for a "
                    "governed running service, `cloud:` for a discovered cloud resource, "
                    "`image:` for a container image, `container:` for one container of a "
                    "Kubernetes workload, `config:` for the NAME of a ConfigMap or Secret a "
                    "workload references (never its value). Vulnerabilities join here, and governance "
                    "is inherited along this key. The prefix tells you which supply path "
                    "produced the row."
                ),
            },
            "source_system_id": {"data_type": "VARCHAR(255)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "The asset's id in the system that reported it. Use it to open the asset in "
                    "that tool; not unique across sources."
                ),
            },
            "source_system": {"data_type": "VARCHAR(100)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "The integration or internal producer that reported this asset row. ⚠️ Determines which "
                    "other columns are populated at all, since sources differ in what they expose, and it "
                    "is the first thing to check when two rows describe the same asset differently."
                ),
            },
            "discovery_source": {"data_type": "VARCHAR(100)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "The FEED through which this asset was discovered — which pipeline told the platform it "
                    "exists. ⚠️ Kept distinct from `source_system` because a asset can be discovered by one "
                    "mechanism and maintained by another."
                ),
            },
            "discovery_method": {"data_type": "VARCHAR(50)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "By what MEANS this asset was discovered — an API collection, an inventory sweep, or a "
                    "manual registration. Complements `discovery_source` (which feed) and is how "
                    "automatically-inventoried rows are separated from hand-registered ones."
                ),
            },
            "asset_name": {"data_type": "VARCHAR(255)", "category": "Asset Details",
                "semantic_description": (
                    "The asset's name as its source system knows it. Human-readable, not stable "
                    "enough to join on."
                ),
            },
            "asset_description": {"data_type": "TEXT", "category": "Asset Details",
                "semantic_description": (
                    "Free-text description of what the asset is for, where a source supplies "
                    "one."
                ),
            },
            "asset_type": {"data_type": "VARCHAR(50)", "category": "Asset Details",
                "semantic_description": (
                    "What kind of thing this ASSET is — VM, Container, Service, ReplicaSet, Function, "
                    "Database. Determines which other fields are even meaningful (a Function has no MAC "
                    "address). Kubernetes rows: `kubernetes_workload` (the `service:` node), "
                    "`kubernetes_container` (one container of a workload; role main/sidecar/init and "
                    "its env variable NAMES in custom_attributes), `kubernetes_config` (a ConfigMap "
                    "or Secret NAME a workload references; no value is ever stored), "
                    "`kubernetes_service` (a Kubernetes Service OBJECT, keyed "
                    "`cloud:<provider>/container.service/<cluster>/<namespace>/<name>`; its type, "
                    "headless flag and port names/numbers in custom_attributes; its IPs and an "
                    "ExternalName host are never stored). "
                    "⚠️ Distinct from `findings.asset_type`, which is the producer's own label "
                    "copied onto a finding and is not guaranteed to match this canonical value."
                ),
            },
            # Asset-graph (AG0 § 3.3.4): logical-service identity for service:<env>/<name>
            # (a Kubernetes workload is service:<cluster>/<namespace>/<name> — OI-111)
            # assets (asset_type='service'). Additive, nullable. Other service governance
            # reuses real existing columns (criticality_name/level, asset_owner,
            # public_access, load_balancer_name).
            "service_name": {"data_type": "VARCHAR(255)", "category": "Asset Details",
                "semantic_description": (
                    "For a running service, its name. With container_cluster_id this is what "
                    "deployment governance matches on."
                ),
            },
            "service_application": {"data_type": "VARCHAR(255)", "category": "Asset Details",
                "semantic_description": (
                    "The application this service belongs to. Used together with the cluster to "
                    "bind a deployment's governance to the right rows."
                ),
            },
            # Asset-graph (AG3a, Torana_Asset_Graph_Design.md § 3.3.4 / § 4.9.3): the
            # container image a runtime/cloud asset is deployed from. Carries the SAME
            # digest the building artifact does, so the `image ──deployed_as──▶ service`
            # edge converges across passes on an immutable, indexed key (not a name).
            # Additive nullable — populated by cloud/runtime mappings (e.g. aws_config).
            "container_image_id": {"data_type": "VARCHAR(512)", "index": True, "category": "Asset Details",
                "semantic_description": (
                    "The image this asset runs. The bridge from a running thing to the artifact "
                    "it was built from, and to that artifact's vulnerabilities."
                ),
            },
            "container_image_digest": {"data_type": "VARCHAR(128)", "index": True, "category": "Asset Details",
                "semantic_description": (
                    "The container image's content hash, recorded on this asset row — the identifier that "
                    "cannot drift. ⚠️ A tag can be repointed at new content; a digest cannot, which is why "
                    "deployments and findings key on it rather than on the tag."
                ),
            },
            "asset_status": {"data_type": "VARCHAR(50)", "category": "Asset Details",
                "semantic_description": (
                    "The status the asset's own source reports, in lower case: 'active' or "
                    "'inactive', empty when the source states none. On a running service "
                    "(ECS service, Kubernetes workload) 'inactive' means its owner scaled it to "
                    "zero, so nothing of it runs and none is wanted; a service that is only "
                    "between runs or starting up is not 'inactive'. A failed read writes nothing "
                    "here."
                ),
            },
            "asset_environment": {"data_type": "VARCHAR(50)", "category": "Asset Details",
                "semantic_description": (
                    "Which environment this runs in: production, staging, development, test, "
                    "qa. Drives severity thresholds — the same flaw in prod and in dev are not "
                    "the same problem. OBSERVED-primary: a synced value wins over a declared "
                    "one."
                ),
            },
            "cloud_provider": {"data_type": "VARCHAR(50)", "category": "Cloud Provider-Specific Fields",
                "semantic_description": (
                    "Which cloud this runs in: AWS, Azure, GCP, OCI, or On-Premises. ⚠️ Distinct "
                    "from source_system, which says WHO reported the row — a Kubernetes connector "
                    "reporting a workload running in GCP writes source_system='kubernetes' and "
                    "cloud_provider='gcp'. Needed to disambiguate cloud_account_id, whose "
                    "namespace differs per provider."
                ),
            },
            "cloud_account_id": {"data_type": "VARCHAR(100)", "category": "Cloud Provider-Specific Fields",
                "semantic_description": (
                    "The cloud account or subscription this row belongs to — a GCP project id, an "
                    "AWS account number, an Azure subscription. Often the real boundary between "
                    "teams or environments, so it is the natural grouping for 'show me X by "
                    "account'. ⚠️ NOT a Jira project and NOT a logical/product grouping: those "
                    "are separate concepts (see issues.project_key and the governance properties). "
                    "On an asset it is the account the resource lives in, written by the cloud "
                    "inventory mappings (GCP, AWS). ⭐ It is also the key the project-level "
                    "governance decoration (`governance_project`) matches on, so an asset with no "
                    "account receives no project-level governance. NULL when no cloud inventory "
                    "has reported the asset: a Kubernetes connector alone does not write it."
                ),
            },
            "cloud_region": {"data_type": "VARCHAR(50)", "category": "Cloud Provider-Specific Fields",
                "semantic_description": (
                    "Cloud region. Matters for data residency and blast radius."
                ),
            },
            "cloud_resource_id": {"data_type": "VARCHAR(255)", "category": "Cloud Provider-Specific Fields",
                "semantic_description": (
                    "The provider's own identifier — ARN, resource id, self-link. What you "
                    "paste into the cloud console."
                ),
            },
            "compute_operating_system": {"data_type": "VARCHAR(100)", "category": "Compute Platform",
                "semantic_description": (
                    "Operating system. Determines which patches and OS-level findings apply."
                ),
            },
            "container_cluster_id": {"data_type": "VARCHAR(255)", "category": "Container Orchestration",
                "semantic_description": (
                    "The cluster this runs in. With service_application, the pair deployment "
                    "governance matches on."
                ),
            },
            "container_cluster_name": {"data_type": "VARCHAR(255)", "category": "Container Orchestration",
                "semantic_description": (
                    "Human-readable name of the cluster this asset runs in, as its orchestrator reports it. "
                    "Groups workloads by cluster for blast-radius questions; NULL for assets that are not "
                    "cluster-hosted."
                ),
            },
            # ⛔ NOT Torana's IAM `namespace_id`, AND THE NAMES ARE ONE CHARACTER APART.
            # `namespace_id` is the tenant-scoping field that sits alongside `tenant_id` on
            # every sink row. THIS is the Kubernetes object's `metadata.namespace` — a
            # different concept at a different layer. ⚠️ Writing the k8s namespace into
            # `namespace_id` would corrupt tenant scoping on every row it touched, which is
            # why this is a NEW column and not a reuse (F1).
            #
            # ⚠️ Until this column existed, the namespace was COLLECTED AND DISCARDED. The
            # k8s extractor has always put it on the record (`extractors/k8s.py` — the line
            # directly above `running_image_ref`) and `catalogs/kubernetes.yaml` has always
            # declared it, but the mapping had nowhere to land it, so the `service:` key was
            # built from the integration's STATIC `env_label` instead. Two workloads with
            # the same name in different namespaces therefore derived ONE key and merged.
            #
            # ⛔ MEASURED, and a merged node is worse than a missing one. CT: 14 Deployment
            # names exist in >1 namespace, 29 running workloads → 14 nodes, 15 with no
            # representation. T1 (SDG `torana-edge` fixture): 68 workloads → 64 nodes, and
            # all 64 `service:` keys carry the single segment `production`. An absent node is
            # missing; a merged node is WRONG WHILE LOOKING COMPLETE — every edge pointing at
            # it and every property resolved onto it is an unsignalled union of two services.
            #
            # ⛔ THE COLUMN MUST LAND WITH ITS WRITER (the #149 `host_id` rule). A
            # declared-but-unwritten column reports `reachable=false` and renders in the build
            # audit as a "can never work, should never have been authored" defect — which then
            # gets someone to DELETE working SQL. Its writer is the `namespace` derive in
            # kubernetes/workloads.yaml, sourced from the record the extractor already emits,
            # so this costs ZERO new HTTP calls. That derive is a normal mapping step, so
            # reachability parses it from the mapping tree — no write_seam registration is
            # needed or correct here (write_seam is for writes that go through NO mapping).
            #
            # ⚠️ OBSERVED, not governed. It is a fact the cluster reports, not tenant policy,
            # so it is an ETL-written column and NOT a domain property — it belongs on neither
            # `domain_properties/vm.py` nor `entity_properties_resolved`. (`asset_environment`
            # next door IS governed; do not copy its treatment.)
            "namespace": {"data_type": "VARCHAR(255)", "category": "Container Orchestration",
                "semantic_description": (
                    "The Kubernetes namespace this workload runs in, as the cluster reports it "
                    "(metadata.namespace) — e.g. 'kube-system', 'demo', 'edge'. Distinguishes two "
                    "workloads that share a name in different namespaces; they are different "
                    "services. NULL for assets that are not Kubernetes-hosted. ⛔ Unrelated to "
                    "namespace_id, which is Torana's internal tenant-scoping field."
                ),
            },
            "hostname": {"data_type": "VARCHAR(255)", "category": "Network & Location",
                "semantic_description": (
                    "The asset's host name. Human-recognisable but not reliably unique."
                ),
            },
            # ⛔ NOT a duplicate of `hostname`, and the difference is the whole point.
            # `hostname` is a human label with no uniqueness guarantee; this is the
            # canonical `host:<provider>/<id>` ENTITY KEY of the machine this row runs
            # on, built by host_key(). It is the TO-endpoint of the
            # service ──runs_on──▶ host edge, and `derive_runs_on` gates on exactly
            # (service_env, service_name, host_id).
            #
            # ⚠️ Until this column existed, `runs_on` was UNSATISFIABLE BY ANY PRODUCER
            # ON THE PLATFORM (#133): the edge rule shipped, the relationship contract
            # demanded it, and the column it gates on was on no datalake table at all —
            # so every mapping owing `runs_on` breached forever through no fault of its
            # author, and `host:`-ended relationships were entirely absent from the graph.
            # `EDGE_PRODUCER_STATUS["runs_on"]` was marked `dormant` for that reason.
            #
            # ⛔ THE COLUMN MUST LAND WITH ITS WRITER (#149). A declared-but-unwritten
            # column reports `reachable=false` and renders in the build audit as a
            # "can never work, should never have been authored" defect — which then gets
            # someone to DELETE working SQL. Its writer is the `host_id` derive in
            # kubernetes/workloads.yaml, sourced from the Pod's `spec.nodeName` (the
            # k8s extractor already fetches full Pod objects, so this costs zero new
            # HTTP calls). That derive is a normal mapping step, so reachability parses
            # it from the mapping tree — no write_seam registration is needed or correct
            # here; write_seam is for writes that go through NO mapping.
            "host_id": {"data_type": "VARCHAR(255)", "category": "Network & Location",
                "semantic_description": (
                    "Canonical host:<provider>/<id> entity key of the machine or node this "
                    "asset runs on. The join key for service-to-host relationships; not a "
                    "display name (that is `hostname`)."
                ),
            },
            # ── F5: what makes a NODE describable ────────────────────────────────────
            # ⛔ THESE LAND WITH THEIR WRITER — kubernetes/nodes.yaml, sourced from the
            # Node object's `status.nodeInfo` / `status.capacity` / labels / `spec`.
            # Until F5 there was no producer of `host:` rows at all: `_NODE_HOMES` declared
            # `"host": ("assets","torana_entity_id")` and node identity came only from a
            # Pod's `spec.nodeName` — a scheduling attribute, not a host record. Every one
            # of these values was PRESENT on the Node object and NONE was reachable, so
            # "which nodes run an EOL kernel" was unanswerable.
            #
            # ⚠️ `container_runtime` was ARCHIVED 2026-08-09 as a `shadow` column —
            # declared, written by nothing, read by nothing. It returns here under the one
            # sanctioned path: A COLUMN COMES BACK ONLY TOGETHER WITH THE WRITER THAT
            # FILLS IT. The other 14 are new. Re-adding any of these without the nodes
            # mapping would recreate exactly the shadow the archive exists to prevent.
            #
            # ⭐ Real columns, not `custom_attributes_value`. A blob costs no migration and
            # leaves every field unqueryable — which forfeits the entire reason to write
            # node rows. Decision closed as columns (F5 § The work).
            #
            # ⚠️ All NULLABLE and all NULL for non-node assets. A cloud VM row legitimately
            # has no kubelet version; NULL is the honest answer, never a default.
            "kernel_version": {"data_type": "VARCHAR(100)", "category": "Compute",
                "semantic_description": (
                    "Kernel the machine is running, as the node reports it (e.g. '6.12.94+'). "
                    "Answers EOL/patch-level questions about the host itself rather than what "
                    "runs on it. NULL for assets that are not machines."
                ),
            },
            "kubelet_version": {"data_type": "VARCHAR(50)", "category": "Container Orchestration",
                "semantic_description": (
                    "Kubelet version on this node (e.g. 'v1.35.7-gke.1222000'). Version skew "
                    "against the cluster control plane is a supportability signal. NULL for "
                    "anything that is not a Kubernetes node."
                ),
            },
            "container_runtime": {"data_type": "VARCHAR(100)", "category": "Container Orchestration",
                "semantic_description": (
                    "Container runtime executing workloads on this node, with its version "
                    "(e.g. 'containerd://2.1.9'). NULL for non-node assets."
                ),
            },
            "os_image": {"data_type": "VARCHAR(255)", "category": "Compute",
                "semantic_description": (
                    "OS image the machine booted, as reported (e.g. 'Container-Optimized OS "
                    "from Google'). Distinct from `compute_operating_system`, which is the "
                    "coarse OS family."
                ),
            },
            "architecture": {"data_type": "VARCHAR(20)", "category": "Compute",
                "semantic_description": (
                    "CPU architecture of the machine (amd64, arm64). Decides which build of "
                    "an image can run here."
                ),
            },
            "cpu_capacity": {"data_type": "VARCHAR(20)", "category": "Compute",
                "semantic_description": (
                    "Allocatable CPU the node reports, in Kubernetes units (e.g. '8'). Kept "
                    "as text because the source unit is a quantity string, not a number."
                ),
            },
            "memory_capacity": {"data_type": "VARCHAR(30)", "category": "Compute",
                "semantic_description": (
                    "Allocatable memory the node reports, in Kubernetes units (e.g. "
                    "'32873348Ki'). Text for the same reason as `cpu_capacity` — converting "
                    "at ingest would freeze a unit choice the reader may not want."
                ),
            },
            "pod_capacity": {"data_type": "VARCHAR(20)", "category": "Container Orchestration",
                "semantic_description": (
                    "Maximum pods schedulable on this node (e.g. '110'). With the pods "
                    "actually placed, it answers headroom questions."
                ),
            },
            "provider_id": {"data_type": "VARCHAR(255)", "category": "Container Orchestration",
                "semantic_description": (
                    "The cloud provider's own id for this machine, as the orchestrator "
                    "records it (e.g. 'gce://project/zone/instance'). ⭐ The join handle to "
                    "the SAME machine seen by a cloud-inventory connector."
                ),
            },
            "node_pool": {"data_type": "VARCHAR(255)", "category": "Container Orchestration",
                "semantic_description": (
                    "Managed node pool / node group this machine belongs to. Nodes in a pool "
                    "share a machine type and upgrade together, so it is the unit a fix is "
                    "usually applied to."
                ),
            },
            "machine_family": {"data_type": "VARCHAR(50)", "category": "Compute",
                "semantic_description": (
                    "Provider machine family (e.g. 'c2d'). Coarser than `instance_type`."
                ),
            },
            "instance_type": {"data_type": "VARCHAR(100)", "category": "Compute",
                "semantic_description": (
                    "Provider machine type of this node (e.g. 'c2d-standard-8')."
                ),
            },
            "cloud_zone": {"data_type": "VARCHAR(100)", "category": "Network & Location",
                "semantic_description": (
                    "Availability zone the machine sits in (e.g. 'us-west1-a'). Finer than "
                    "`cloud_region`; a zone outage is the blast radius."
                ),
            },
            "private_ipv4_addresses": {"data_type": "JSON", "category": "Network & Location",
                "semantic_description": (
                    "Internal IPv4 addresses. Reachable only from inside the network."
                ),
            },
            "fqdn": {"data_type": "VARCHAR(255)", "category": "Network & Location",
                "semantic_description": (
                    "Fully qualified domain name of this asset. The primary evidence for "
                    "network-reachability questions; NULL means no name was reported, which is not the same "
                    "as the asset being unreachable."
                ),
            },
            "mac_addresses": {"data_type": "JSON", "category": "Network & Location",
                "semantic_description": (
                    "Hardware addresses of the asset's interfaces."
                ),
            },
            "public_access": {"data_type": "BOOLEAN", "category": "Security Configuration",
                "semantic_description": (
                    "Whether this is reachable from the internet. THE canonical exposure column "
                    "— `publicly_accessible` is a deprecated alias kept only so the old name "
                    "cannot be reintroduced. Merged with OR across sources: a stale 'not "
                    "public' must never hide an observed load balancer. A front door that asks "
                    "for a sign-in is still public; whether it needs credentials is on the "
                    "exposed_via / routes_to edge."
                ),
            },
            "asset_owner": {"data_type": "VARCHAR(255)", "category": "Ownership & Organization",
                "semantic_description": (
                    "The person accountable for this asset. DECLARED — no scanner can know an "
                    "org chart, so it stays empty until a human sets it on a Deployment."
                ),
            },
            "asset_owner_email": {"data_type": "VARCHAR(255)", "category": "Ownership & Organization",
                "semantic_description": (
                    "Contact address for the owner, where supplied."
                ),
            },
            "asset_team": {"data_type": "VARCHAR(100)", "category": "Ownership & Organization",
                "semantic_description": (
                    "The team accountable for remediating findings here. DECLARED and "
                    "platform-canonical: cloud providers carry no team label, so it can only be "
                    "declared. When empty, remediation is assigned to nobody and ages unowned."
                ),
            },
            "image_ownership": {"data_type": "VARCHAR(20)", "category": "Ownership & Organization",
                "semantic_description": (
                    "WHO controls the container image this asset runs — and therefore who a "
                    "vulnerability in it is addressable to: the customer (they build it), the "
                    "cloud or platform supplier that ships it, somebody else's public image, or "
                    "a recorded verdict that the data cannot say. The values are the closed "
                    "vocabulary in value_domain.py (`('assets', 'image_ownership')`), declared "
                    "once in domain_properties/vm.py::image_ownership. ⛔ NOT the registry that "
                    "hosts the image — a first-party build and a mirrored third-party image sit "
                    "in the SAME registry under the same host, so "
                    "`container_image_registry_provider` cannot answer this. DECLARED: a tenant "
                    "declaration is authoritative; absent one, an `artifacts` row for the image "
                    "(the customer's own registry inventory) yields `first_party` and its ABSENCE "
                    "yields `undetermined`. Derivation never emits the other two values: telling "
                    "a supplier's image from a stranger's needs a human, so a filter on them "
                    "reads declarations only. ⚠️ `undetermined` is NOT a NULL substitute — NULL "
                    "means nothing has looked, `undetermined` means we looked."
                ),
            },
            "load_balancer_name": {"data_type": "VARCHAR(255)", "category": "Load Balancer & Networking",
                "semantic_description": (
                    "Load balancer fronting this asset. Its presence is often what makes a "
                    "private asset internet-reachable."
                ),
            },
            "criticality_name": {"data_type": "VARCHAR(20)", "category": "Risk & Security Posture",
                "semantic_description": (
                    "How much this asset matters to the business"
                    "A judgement, not an observation — the same machine is critical or not "
                    "depending on what it runs. When several deployments claim one image, the "
                    "most critical wins."
                ),
            },
            "criticality_level": {"data_type": "INTEGER", "category": "Risk & Security Posture",
                "semantic_description": (
                    "Numeric form of `criticality_name` for this asset, kept for ordering and comparison. "
                    "⚠️ Two columns holding ONE fact — set them together or set neither, since a query "
                    "reading only one of them silently disagrees with a query reading the other."
                ),
            },
            # Deployment-object governance (Deployment_Object_and_Runtime_Provenance.md § 3.3.4):
            # human-asserted governance stamped onto service:<env>/<name> assets by the K8s
            # integration (and re-stamped by the governance-repaint job on Deployment edit).
            # Additive, nullable, service-only. internet-facing reuses public_access;
            # criticality reuses criticality_name/level; owner reuses asset_owner — so ONLY
            # these two are net-new (data-sensitivity + which Deployment set the governance).
            "has_customer_data": {"data_type": "BOOLEAN", "category": "Risk & Security Posture",
                "semantic_description": (
                    "Whether customer data lives here. DECLARED by a human. Drives escalation "
                    "and compliance scope; no scanner can determine it reliably."
                ),
            },
            # ⛔ TWO COLUMNS ANSWER "WHO DECLARED THIS GOVERNANCE?", AND THEY PARTITION.
            # Checking only one and concluding provenance is absent is a real, made
            # mistake: on T2, `governance_source` is NULL on 1,726 of 1,789
            # governance-bearing rows — and every one of those carries
            # `decoration_provenance` instead. Measured 2026-09-14, clean partition,
            # no row uses both:
            #
            #   governance_source='deployment'                 63 rows
            #   decoration_provenance='decoration:governance_cluster'   1,036
            #   decoration_provenance='decoration:governance_project'     690
            #
            # ⭐ The split is a CONTRACT, not a coincidence. `decorations.py` maps
            # asset_owner / criticality_name / criticality_level / has_customer_data to
            # the governance decorations, its registry validator RAISES if a decorated
            # sink lacks the provenance columns, and it refuses to let anything decorate
            # the provenance columns themselves. So a decoration-written governance value
            # ALWAYS carries `decoration_provenance`, and this column stays NULL for it.
            #
            # ⚠️ Read BOTH when asking where a governance value came from.
            "governance_source": {"data_type": "VARCHAR(50)", "category": "Risk & Security Posture",
                "semantic_description": (
                    "Which DECLARATION wrote this asset row's governance: a Deployment object's "
                    "declared governance (repainted onto the service rows it owns), an "
                    "asset-inventory document, or the AWS integration (the resource's own tags, "
                    "the integration's declared defaults, or a record that AWS was read and "
                    "stated none of these values). Every writer assigns a literal from the closed "
                    "vocabulary in value_domain.py (`('assets', 'governance_source')`); read the "
                    "values there. A source may "
                    "clear a value it set; another source's empty value never erases it "
                    "(upsert_policies `governance_not_observed`). ⚠️ NULL does NOT mean unknown "
                    "provenance: a governance value written by the decoration layer records its "
                    "origin in `decoration_provenance` instead, and the two columns partition — "
                    "read both. The audit trail for a value nobody can otherwise explain."
                ),
            },
            "custom_attributes_value": {"data_type": "JSON", "category": "Tags & Metadata",
                "semantic_description": (
                    "Value of the custom attribute named alongside it on this row, carried from the "
                    "source's own tagging. ⛔ Free-form and source-defined, so treat it as investigative "
                    "context rather than a dimension to group by in shipped SQL."
                ),
            },
            "asset_created_at": {"data_type": "TIMESTAMP", "category": "Lifecycle & Management",
                "semantic_description": (
                    "When the asset was created in its source system."
                ),
            },
            "asset_launched_at": {"data_type": "TIMESTAMP", "category": "Lifecycle & Management",
                "semantic_description": (
                    "When it started running. Distinct from creation for anything that stops "
                    "and starts."
                ),
            },
            "asset_first_seen_at": {"data_type": "TIMESTAMP", "category": "Lifecycle & Management",
                "semantic_description": (
                    "When Torana first observed this asset — the platform's own view, "
                    "independent of the source's timestamps."
                ),
            },
            "asset_last_seen_at": {"data_type": "TIMESTAMP", "category": "Lifecycle & Management",
                "semantic_description": (
                    "When Torana last observed it. A stale value suggests the asset is gone or "
                    "the sync stopped."
                ),
            },
            "created_by": {
                "data_type": "VARCHAR(255)", "category": "Audit & Tracking",
                "semantic_description": (
                    "The Torana user or service principal that caused this asset row to be written — in "
                    "practice the integration that ingested it (`github_integration`, `jira_integration`). "
                    "⚠️ An INGEST-side actor, NOT the owner of the thing described: do not read it as "
                    "'who is responsible for this'."
                ),
            },
            "created_via": {"data_type": "VARCHAR(100)", "category": "Audit & Tracking",
                "semantic_description": (
                    "The Torana mechanism that wrote this asset row — an integration sync, a replay, a "
                    "manual push, or a synthetic dataset load. ⛔ Provenance, not asset data: it is what "
                    "separates genuinely ingested rows from generated ones, and a query measuring a real "
                    "estate should know which values are synthetic."
                ),
            },
            "dataset_tag": {"data_type": "VARCHAR(200)", "category": "Audit & Tracking",
                "semantic_description": (
                    "Marks this asset row as seeded by a NAMED synthetic dataset rather than a live "
                    "integration, so such rows can be purged as a set. NULL for genuinely ingested rows. ⛔ "
                    "Filter it out when measuring a real estate — counting demo rows as production asset "
                    "data is the error this column exists to prevent."
                ),
            },
            # ── Decoration layer provenance (DECORATION_LAYER_SPEC.md § 3.9) ──
            # Required on EVERY decorated sink: the apply statement stamps both
            # unconditionally, so a sink registered in DECORATIONS without them
            # fails loudly per job. `assets` became a decorated sink when the
            # `governance_cluster` / `governance_project` decorations landed —
            # deployment-asserted owning team, criticality and customer-data
            # classification. Mirrors the vulnerabilities pair exactly; keep the
            # two definitions identical.
            #
            # ⚠️ CREATE TABLE IF NOT EXISTS does NOT evolve an existing table, so
            # adding these here does NOT reach tenant schemas already created.
            # They need an explicit ALTER per tenant schema; the datalake's
            # `_verify_provenance_columns()` boot check reports exactly which are
            # still missing (it derives its sink list from DECORATIONS, so it
            # picked `assets` up automatically).
            # D21 (DS1a § 3.2.2): the read record. Merged per key by scope_reads_merge.
            "reads": {"data_type": "JSONB", "category": "Platform",
                "semantic_description": (
                    "On a scope row (an AWS account, a GCP project, a Kubernetes cluster, a repository): what "
                    "each connector data source last read of this scope, one entry per data source and "
                    "connection: '<read>|<integration id>' (AWS adds the region, 'ecs_services@eu-west-1|<id>'; "
                    "a sub-read such as service tags adds ':tags', 'ecs_services:tags@eu-west-1|<id>'). A read "
                    "is measured when ANY connection's entry for it is ok and its ok_at is within 48 hours. "
                    "Entry: at = start of the last run that read it; "
                    "ok = whether that read succeeded completely; ok_at = last complete success; first_at = "
                    "first read recorded; fail_since = start of the current failing streak; why / fix / "
                    "fix_owner / missing_permission / code = the connector's words when it did not succeed. "
                    "NULL on every other row.")},
            "decoration_provenance": {
                "data_type": "VARCHAR(64)", "category": "Audit & Tracking",
                "semantic_description": (
                    "Which DECORATION wrote this asset row's governance — `decoration:governance_cluster` "
                    "(declared on a Deployment and repainted cluster-wide) or "
                    "`decoration:governance_project` (declared at the GCP project level). NULL = the "
                    "decoration layer has not written here; anything not starting `decoration:` = an "
                    "observation the decoration layer must never overwrite. ⚠️ This column and "
                    "`governance_source` partition: a governance value written by a DECLARATION "
                    "records its origin there and leaves this NULL, and vice versa — read both."
                ),
            },
            "decoration_version": {
                "data_type": "VARCHAR(100)", "category": "Audit & Tracking",
                "semantic_description": (
                    "Version of the decoration pass that stamped this row."
                ),
            },
        }