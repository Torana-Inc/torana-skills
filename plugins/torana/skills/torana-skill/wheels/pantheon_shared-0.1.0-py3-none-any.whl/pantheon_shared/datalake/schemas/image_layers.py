from typing import Dict, Any
from .base import TableSchema


class ImageLayersSchema(TableSchema):
    """Schema for the image_layers table: an image's build history, one row per entry.

    One row per entry of the image config's `history[]`, in order. Each entry says what
    build step made it (`created_by`) and whether it produced a filesystem layer
    (`empty_layer`). The image config's `rootfs.diff_ids` lists the layers themselves.

    ⭐ HOW A LAYER IS MATCHED TO ITS BUILD STEP. The history entries with
    `empty_layer = false` correspond 1:1, in order, to `rootfs.diff_ids`. That zip is the
    only reliable link: `docker history` on a pulled image reports 0B for every entry, so
    sizes cannot be used. The writer does the zip and stores the result in `diff_id` /
    `layer_index`. When the two counts disagree (some builders omit history), every entry
    is still stored, `diff_id` stays NULL, and `history_layer_mismatch` is true. Nothing is
    guessed.

    ⛔ OBSERVED DATA ONLY. Which base image a layer came from is NOT stored: it is derived
    at read time by matching this image's ordered diff_ids against another image's (the
    longest common prefix), because the base image may be imported later or change.

    Keyed by the IMAGE (torana_artifact_id = the `image:` key, the same value as
    `artifacts.torana_artifact_id`), so it joins to artifacts without parsing.

    Writers: the image-evidence ingestor (CycloneDX / Trivy JSON / Torana build record,
    `/ingest/image-evidence`) and the registry image syncs (gcp/artifact_registry_images,
    which read the image config blob).
    """

    @property
    def table_name(self) -> str:
        return "image_layers"

    @property
    def primary_key(self) -> str:
        return "torana_image_layer_id"

    @property
    def description(self) -> str:
        return (
            "A container image's build history: one row per image-config history entry, in "
            "order, with the build step that made it and, for entries that produced a layer, "
            "that layer's diff_id"
        )

    @property
    def category(self) -> str:
        return "Entity Graph"

    @property
    def timestamp_column(self) -> str:
        return "updated_at"

    @property
    def schema(self) -> Dict[str, Any]:
        return {
            "torana_image_layer_id": {
                "data_type": "VARCHAR(700)", "primary_key": True, "category": "Core Identity",
                "semantic_description": (
                    "Torana's id for one history entry of one image as one source reported it: "
                    "`<image key>#<platform>#<source_system>#h<history_index>`. Primary key; re-ingesting "
                    "the same image from the same source converges on the same rows, and two sources or "
                    "two platforms of one index never overwrite each other."
                ),
            },
            "torana_artifact_id": {
                "data_type": "VARCHAR(600)", "not_null": True, "index": True, "category": "Core Identity",
                "semantic_description": (
                    "The image this entry belongs to, as its `image:<registry>/<repo>@sha256:<digest>` "
                    "key. Joins to `artifacts.torana_artifact_id` and to `entity_edges` endpoints."
                ),
            },
            "container_image_digest": {
                "data_type": "VARCHAR(100)", "index": True, "category": "Core Identity",
                "semantic_description": (
                    "The image's manifest digest, bare hex without `sha256:`, the same spelling as "
                    "`artifacts.container_image_digest`."
                ),
            },
            "platform": {
                "data_type": "VARCHAR(100)", "index": True, "category": "Core Identity",
                "semantic_description": (
                    "The platform whose config this history is (`linux/amd64`, `linux/arm64/v8`), from the "
                    "config's os/architecture/variant. ⚠️ A multi-platform image (an index) has one history "
                    "per platform; filter on this before reading a build top to bottom, or two platforms' "
                    "steps interleave. Empty when the config named none."
                ),
            },
            "history_index": {
                "data_type": "INTEGER", "not_null": True, "category": "Layer",
                "semantic_description": (
                    "Position of this entry in the image config's history[], starting at 0. "
                    "Order by it to read the build top to bottom."
                ),
            },
            "layer_index": {
                "data_type": "INTEGER", "category": "Layer",
                "semantic_description": (
                    "Position of this entry's layer in rootfs.diff_ids, starting at 0. NULL for an "
                    "entry that made no layer (`empty_layer`), and NULL for every entry when "
                    "`history_layer_mismatch` is true."
                ),
            },
            "diff_id": {
                "data_type": "VARCHAR(100)", "index": True, "category": "Layer",
                "semantic_description": (
                    "The uncompressed layer digest (`sha256:…`) this entry produced, from "
                    "rootfs.diff_ids. The key that `image_components.layer_diff_id` points at, and the "
                    "value two images share when one is built FROM the other. NULL when "
                    "`empty_layer` or `history_layer_mismatch`."
                ),
            },
            "created_by": {
                "data_type": "TEXT", "category": "Layer",
                "semantic_description": (
                    "The build instruction that made this entry, as the image records it (for "
                    "example `RUN /bin/sh -c uv pip install … -r /tmp/base-requirements.lock`). "
                    "Answers 'which build step put this package here?'."
                ),
            },
            "history_created": {
                "data_type": "TIMESTAMP", "category": "Layer",
                "semantic_description": (
                    "When this build step ran, as the image records it. Reproducible builds may set "
                    "it to a fixed epoch, so it is not proof of build time."
                ),
            },
            "empty_layer": {
                "data_type": "BOOLEAN", "category": "Layer",
                "semantic_description": (
                    "True when this step changed only metadata (ENV, LABEL, CMD…) and produced no "
                    "filesystem layer."
                ),
            },
            "comment": {
                "data_type": "TEXT", "category": "Layer",
                "semantic_description": "The history entry's own comment, when the builder wrote one (BuildKit writes `buildkit.dockerfile.v0`).",
            },
            "history_layer_mismatch": {
                "data_type": "BOOLEAN", "category": "Layer",
                "semantic_description": (
                    "True when the number of non-empty history entries differs from the number of "
                    "rootfs.diff_ids, so no entry could be matched to a layer. ⚠️ Then `diff_id` is "
                    "NULL on every row of this image; read the ordered diff_ids from "
                    "`artifacts.layer_diff_ids` instead."
                ),
            },
            "source_system": {
                "data_type": "VARCHAR(100)", "category": "Provenance",
                "semantic_description": (
                    "What reported this history: `trivy` (a native Trivy report), `trivy-cyclonedx`, `syft`, `cyclonedx`, `torana_build` or `gcp`."
                ),
            },
            "source_ref": {
                "data_type": "TEXT", "category": "Provenance",
                "semantic_description": (
                    "Where the evidence came from, precisely enough to fetch it again: the ingested "
                    "file's sha256 and name, or the registry config-blob digest it was read from."
                ),
            },
            "description": {
                "data_type": "TEXT", "not_null": True, "default": "", "category": "Layer",
                "semantic_description": "Human-readable note about this entry. Empty unless a writer has something to say.",
            },
            "created_via": {
                "data_type": "VARCHAR(100)", "category": "Audit & Tracking",
                "semantic_description": "The Torana mechanism that wrote this row (an integration sync or a push ingest).",
            },
            "dataset_tag": {
                "data_type": "VARCHAR(200)", "category": "Audit & Tracking",
                "semantic_description": (
                    "Marks this row as seeded by a NAMED synthetic dataset. NULL for observed data. "
                    "⛔ Filter it out when measuring a real estate."
                ),
            },
        }
