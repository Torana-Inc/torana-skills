"""
Integration generator metadata helpers.

Provides programmatic access to per-table conventions that the integration
generator needs but that are not derivable from the table schema alone:

  pack_target(table)         → the destination column for `pack` ops
  valid_set_columns(table)   → columns safe to write via a `set` (constant) op
  schema_columns(table)      → full set of column names for the destination table

These functions are the single source of truth for these conventions.
When adding a new datalake table or renaming a convention column, update
this file — the generator picks up changes automatically at generation time.
"""

from __future__ import annotations

from typing import Optional, Set

# ---------------------------------------------------------------------------
# Pack target per destination table
# ---------------------------------------------------------------------------

_PACK_TARGETS: dict[str, str] = {
    "identities": "attributes",
    "repositories": "custom_properties",
    "assets": "custom_attributes_value",
    "vulnerabilities": "scan_output",
    "findings": "custom_attributes",
    "datastores": "custom_attributes",
    "issues": "custom_fields",
    "artifacts": "custom_attributes",
    "controls": "custom_attributes",
    # entity_edges has no JSON pack column of its own; evidence is the structured
    # provenance bag and is written explicitly, not via `pack`.
    "entity_edges": "evidence",
    # ⛔ `packages` deliberately has NO pack target. It declared
    # `custom_attributes`, but that column was shadow — nothing wrote it and
    # nothing read it — and S11 removed it from PackagesSchema. Leaving the entry
    # would point the integration generator at a column that no longer exists, so
    # a generated `pack` step would fail schema validation at generation time.
    # `pack_target()` returns None here, which the generator already treats as a
    # TODO. ⚠️ Restoring a pack target for packages means DECLARING the column
    # again — and per the archive's rule, a column comes back only together with
    # the writer that fills it.
}


def pack_target(table: str) -> Optional[str]:
    """
    Return the destination column name for a `pack` op on the given table.

    Returns None for unknown tables (generator should treat as TODO).

    Examples
    --------
    >>> pack_target("assets")
    'custom_attributes_value'
    >>> pack_target("identities")
    'attributes'
    >>> pack_target("findings")
    'custom_attributes'
    """
    return _PACK_TARGETS.get(table)


# ---------------------------------------------------------------------------
# Valid set-op columns per destination table
# ---------------------------------------------------------------------------
# These are columns that integrations typically populate via a `set` (constant)
# operator step. The list is intentionally conservative — only include columns
# whose values are the same for every record from a given source (e.g.
# source_system="okta"). Columns that vary per record belong in `derive` steps.
#
# ⛔ EVERY NAME HERE MUST BE A DECLARED COLUMN ON ITS TABLE. This list is
# hand-written and nothing regenerates it, so it drifts silently — S11's removal
# of 753 shadow columns exposed 3 entries naming columns that no longer exist:
# `identities.identity_subtype`, `datastores.datastore_subtype`,
# `controls.control_type`. All three were shadow (declared, written by no mapping,
# read by nothing), so listing them as "safe to set" was already an invitation to
# write a column no consumer reads.
# ⚠️ Per-table, not per-name — and `created_via` is the worked example of why.
# It looked shadow on 7 tables, but it is WRITTEN from Python by the SDG replay
# path and READ by two shipped routes across all 11 sink tables, so it was kept
# and declared through the write seam instead. `test_meta_matches_schema` pins the
# invariant so the next removal pass compares against the schema, not a memory.

_VALID_SET_COLUMNS: dict[str, frozenset] = {
    "identities": frozenset({
        "source_system", "provider", "discovery_source", "discovery_method",
        "created_by", "created_via", "identity_type",
        "is_service_account", "is_machine_identity",
    }),
    "repositories": frozenset({
        "source_system", "provider", "discovery_source", "discovery_method",
        "created_via", "platform_type",
    }),
    "assets": frozenset({
        "source_system", "discovery_source", "discovery_method",
        # ⚠️ S14 (row 42) removed `asset_subtype` — it was shadow AND referenced
        # (by vm.tf.em_067 and corpus Q-067), i.e. read by SQL that could never
        # return a value. Listing it here as "safe to set" is exactly the drift
        # the block comment above predicts: nothing regenerates this list.
        "created_via", "asset_type",
        # Deployment-object governance (§ 3.3.4): governance_source is a `set`
        # constant (e.g. 'deployment'); has_customer_data is a per-Deployment
        # `derive` target (validated via schema_columns, not a constant here).
        "governance_source",
    }),
    "vulnerabilities": frozenset({
        "source_system", "scanner_name", "scan_type", "created_via",
        # ⛔ TRIAGE FLAGS — A MAPPING MUST NOT SEED THESE. Leave them unset and
        # let them arrive NULL.
        #
        # They are three-state: NULL means "nobody has triaged this", FALSE means
        # "a human looked and said no", TRUE is the verdict. A scanner cannot know
        # a triage verdict, so a mapping that writes `false` collapses the first
        # two into one value at ingest, permanently and unrecoverably.
        #
        # ⚠️ A query filtering these must use `IS NOT TRUE`, never `= false` — the
        # latter drops every untriaged row under SQL three-valued logic. That is a
        # property of the QUERY, not a reason to seed the column;
        # `sql-reachability`'s `nullable_boolean` check enforces it.
        #
        # They stay listed here because `set` must remain VALID on them — the PATCH
        # triage endpoint writes a human verdict — not because a mapping should.
        # ⚠️ 11 mappings still seed `false` (sarif/vulnerabilities.yaml is the
        # reference); retiring that is separate ETL work.
        "is_triaged", "is_false_positive", "is_risk_accepted",
        "is_suppressed", "is_verified",
    }),
    "findings": frozenset({
        "source_system", "provider", "finding_type", "severity",
        "created_by", "created_via",
    }),
    "datastores": frozenset({
        "source_system", "provider", "service_type", "discovery_source",
        "discovery_method", "environment", "created_by", "created_via",
        "datastore_type",
    }),
    "issues": frozenset({
        "source_system", "created_via",
    }),
    "artifacts": frozenset({
        "source_system", "discovery_source", "discovery_method",
        "created_via", "artifact_type",
    }),
    "controls": frozenset({
        "source_system", "provider", "control_class",
        "engine", "discovery_source", "discovery_method", "created_via",
        "status",
    }),
    "packages": frozenset({
        "source_system", "discovery_source", "package_manager",
    }),
    "entity_edges": frozenset({
        "source_system", "edge_type", "confidence",
    }),
}


def valid_set_columns(table: str) -> frozenset:
    """
    Return the set of column names that are safe to write via a `set` op.

    A `set` op writes the same constant value to every record. This function
    returns columns where that pattern is appropriate for the given table.
    Any column not in this set should be populated via a `derive` step instead.

    Returns an empty frozenset for unknown tables.

    Examples
    --------
    >>> "provider" in valid_set_columns("identities")
    True
    >>> "provider" in valid_set_columns("assets")
    False
    >>> "source_system" in valid_set_columns("findings")
    True
    """
    return _VALID_SET_COLUMNS.get(table, frozenset())


# ---------------------------------------------------------------------------
# Schema columns (live introspection)
# ---------------------------------------------------------------------------

def schema_columns(table: str) -> Set[str]:
    """
    Return the full set of column names for a datalake destination table.

    Loads the schema class dynamically so the result is always authoritative
    against the currently installed pantheon-shared. Also includes the IAM
    injected columns (tenant_id, namespace_id, is_deleted, etc.) that the ETL
    pipeline always injects regardless of the mapping YAML.

    Returns an empty set for unknown tables (generator should treat as TODO).

    Examples
    --------
    >>> "identity_id" in schema_columns("identities")
    True
    >>> "torana_entity_id" in schema_columns("assets")
    True
    """
    from pantheon_shared.datalake.schemas import (
        IdentitySchema, RepositoriesSchema, VulnerabilitySchema,
        AssetsSchema, DatastoresSchema, ArtifactsSchema, FindingsSchema, IssuesSchema,
        ControlsSchema, PackagesSchema, EntityEdgesSchema,
        EntityEdgeCandidatesSchema, EntityGraphDerivationMetricsSchema,
        PentestCasesSchema, PentestRunsSchema,
    )

    _TABLE_MAP = {
        "identities": IdentitySchema,
        "repositories": RepositoriesSchema,
        "vulnerabilities": VulnerabilitySchema,
        "assets": AssetsSchema,
        "datastores": DatastoresSchema,
        "artifacts": ArtifactsSchema,
        "findings": FindingsSchema,
        "issues": IssuesSchema,
        "controls": ControlsSchema,
        "packages": PackagesSchema,
        "entity_edges": EntityEdgesSchema,
        "entity_edge_candidates": EntityEdgeCandidatesSchema,
        "entity_graph_derivation_metrics": EntityGraphDerivationMetricsSchema,
        "pentest_cases": PentestCasesSchema,
        "pentest_runs": PentestRunsSchema,
    }

    # Columns always injected by the ETL pipeline regardless of schema
    # (must mirror system_fields.py IAM_FIELDS + LIFECYCLE_FIELDS + AUDIT_FIELDS
    #  + TRACE_FIELDS, i.e. everything get_full_schema() adds over .schema).
    _INJECTED = {
        "tenant_id", "namespace_id", "is_deleted",
        "created_at", "created_by", "updated_at", "updated_by",
        "trace_id",
    }

    cls = _TABLE_MAP.get(table)
    if cls is None:
        return set()

    return set(cls().schema.keys()) | _INJECTED


# ---------------------------------------------------------------------------
# Convenience: validate a mapping step against the schema
# ---------------------------------------------------------------------------

def validate_step_target(table: str, target: str, op: str) -> Optional[str]:
    """
    Check whether ``target`` is a valid destination column for ``table``.

    Returns None if valid, or an error string describing the problem.

    Staging fields (names starting with ``_``) are always allowed since they
    are transient and removed by a subsequent `drop` step.

    Parameters
    ----------
    table:
        Destination table name (e.g. "identities").
    target:
        The column name being written by the step.
    op:
        The operator type (e.g. "derive", "set", "rename"). Used to tailor
        the error message.
    """
    if target.startswith("_"):
        return None  # staging field — always OK

    cols = schema_columns(table)
    if not cols:
        return None  # unknown table — skip validation

    if target not in cols:
        return (
            f"op={op!r} writes target={target!r} which is not a column in "
            f"table={table!r}. Valid columns: {sorted(cols)}"
        )

    if op == "set" and target not in valid_set_columns(table):
        return (
            f"op='set' writes target={target!r} on table={table!r} but that column "
            f"is not in the valid_set_columns list. Use op='derive' if the value "
            f"varies per record, or add it to meta.valid_set_columns if it is truly "
            f"a constant for all records from this source."
        )

    return None
