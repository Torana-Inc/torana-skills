"""Read a tenant's LIVE column shape from `information_schema` (S19 / row 49).

⛔ WHY THIS EXISTS RATHER THAN REUSING THE REACHABILITY MACHINERY (§ 4 of the brief
says "reuse the existing machinery" — this is the one place that instruction cannot be
followed, and the reason is measured, not asserted):

  1. THE REACHABILITY MACHINERY IS UNAVAILABLE IN THE SERVICE THAT INSTALLS BUNDLES.
     `measure_shadow_set()` needs the write-seam registry, which is populated only by
     IMPORTING `torana_mesh` modules. Those live in `pantheon-integration`. Inside
     `pantheon-program-framework-dev` — the process that loads and installs bundles —
     the registry is EMPTY, `measure_shadow_set()` raises `SeamRegistryEmpty`, and B11
     converts that to a validation error on EVERY bundle load. Verified by running the
     S19 brief's own § 1.2 command. So an install-time check built on it would refuse
     every bundle in the only service that installs them.

  2. REACHABILITY CANNOT ANSWER THE TYPE QUESTION AT ALL. It knows which columns some
     pipeline can write; it carries no type information. The whole `numeric → text`
     axis is invisible to it. `information_schema` is the only source that has types.

⚠️ These are different questions and both are wanted — see the B15 docstring in the
bundle validator. Author-time asks *"is this bundle self-consistent against the
platform baseline?"*; install-time asks *"is it consistent with THIS TENANT's schema
right now?"*. This module answers the second.
"""

from __future__ import annotations

import logging
from typing import Dict, Iterable, Optional, Set, Tuple

from .schema_shape import SchemaShapeUnavailable

logger = logging.getLogger(__name__)

#: The 11 datalake sink tables — the only population carrying a reachability claim and
#: the only one this check scopes to.
#:
#: ⛔ A bundle's OWN transformer outputs (`prioritized_vulnerabilities`,
#: `threat_intel_ranked`, `remediation_base`, …) are deliberately EXCLUDED. Three
#: reasons, each sufficient: their shape derives from the bundle's own SQL and is
#: self-consistent by construction; they carry no reachability claim; and on a FRESH
#: install they do not exist yet, so checking them would refuse every first install.
#: Measured 2026-08-10: ~30 of 131 artifact-slots across the three shipped bundles read
#: a sink table; the other ~100 read bundle outputs.
SINK_TABLES: Tuple[str, ...] = (
    "assets", "vulnerabilities", "findings", "issues", "identities", "repositories",
    "entity_edges", "events", "controls", "datastores", "deployments",
)

#: ⚠️ `current_schema()` — NOT a hand-built `tenant_<uuid>` literal. The backend already
#: routes a query to the tenant's schema (that is what `DatalakeClient` resolves), so
#: asking the session which schema it is IN is both correct and immune to the naming
#: convention changing underneath this module. Building the name here would duplicate a
#: routing decision that already has an owner, and duplicating it is how the two drift.
_SHAPE_SQL = """
    SELECT table_name, column_name, data_type
    FROM information_schema.columns
    WHERE table_schema = current_schema()
      AND table_name IN ({placeholders})
"""


def read_live_shape(
    client,
    *,
    tenant_id: Optional[str] = None,
    iam_context=None,
    tables: Optional[Iterable[str]] = None,
) -> Tuple[Dict[Tuple[str, str], str], Set[str]]:
    """Return `({(table, column): data_type}, {tables_present})` for a tenant.

    `client` is a `DatalakeClient` — the blessed path, which resolves the tenant and
    owns schema routing. ⛔ This module never opens its own connection and never builds
    a schema name by hand.

    ⛔ FAILS CLOSED. Raises `SchemaShapeUnavailable` when the shape cannot be
    established — a query error, or a result in which NONE of the sink tables appear.
    It never returns an empty map as if it were an answer.

    ⚠️ THE EMPTY-MAP CASE IS THE WHOLE POINT, so it is worth being explicit about why
    it raises. An empty result is genuinely ambiguous: it means EITHER "this tenant has
    no sink tables" OR "the query ran somewhere unexpected and matched nothing". A
    caller that treated it as the former would find zero columns to compare, conclude
    every artifact is fine, and PASS a bundle whose columns it never looked at — while
    logging nothing. That is exactly B11's failure mode, and B11's answer is the one
    copied here: refuse rather than guess.
    """
    want = tuple(tables or SINK_TABLES)
    # Inlined as quoted literals: these are module constants, never caller input, and
    # the backends disagree on paramstyle for an IN-list.
    placeholders = ", ".join("'" + t.replace("'", "''") + "'" for t in want)
    sql = _SHAPE_SQL.format(placeholders=placeholders)

    try:
        result = client.query(sql, tenant_id=tenant_id, iam_context=iam_context)
        rows = _rows_of(result)
    except Exception as exc:  # noqa: BLE001 — any failure is "cannot verify"
        raise SchemaShapeUnavailable(
            f"could not read information_schema: {type(exc).__name__}: {exc}"
        ) from exc

    shape: Dict[Tuple[str, str], str] = {}
    present: Set[str] = set()
    for row in rows:
        table_name, column_name, data_type = _triple(row)
        t = str(table_name).lower()
        shape[(t, str(column_name).lower())] = str(data_type)
        present.add(t)

    if not present:
        raise SchemaShapeUnavailable(
            f"the schema reported NONE of the {len(want)} sink tables. This is refused "
            f"rather than read as 'nothing to check': an empty answer here is "
            f"indistinguishable from the query having run against the wrong schema, and "
            f"passing a bundle whose columns were never inspected is worse than "
            f"refusing it."
        )
    return shape, present


def _rows_of(result):
    """`QueryResult.rows`, or the result itself when a backend returns a plain list."""
    return getattr(result, "rows", None) or (result if isinstance(result, list) else [])


def _triple(row):
    """`(table_name, column_name, data_type)` from a dict row or a positional one."""
    if isinstance(row, dict):
        return row["table_name"], row["column_name"], row["data_type"]
    return row[0], row[1], row[2]


#: pg_stats null fractions for the sink tables — the POPULATED axis.
#:
#: ⛔ A CATALOG READ, NOT A TABLE SCAN. `pg_stats` is planner statistics, so this costs
#: what `information_schema` costs. The supply graph's exact value probe was measured at
#: 16.2s vs 0.65s per artifact (25x) and is deliberately skipped in list views; this
#: must never become that.
_NULL_FRAC_SQL = """
    SELECT tablename, attname, null_frac
    FROM pg_stats
    WHERE schemaname = current_schema()
      AND tablename IN ({placeholders})
"""

#: A column is EMPTY at or above this null fraction.
#:
#: ⚠️ ONE DEFINITION OF EMPTY, shared with the supply graph's `_classify_shape`. If that
#: boundary ever moves, this must move with it — two thresholds would mean a column the
#: install warns about and the widget-health chip calls fine, which is worse than either
#: answer alone.
EMPTY_NULL_FRAC = 0.999


def read_live_null_frac(client, *, tenant_id=None, iam_context=None, tables=None):
    """`{(table, column): null_frac}` for the sink tables — or `{}` if unknowable.

    ⛔ THE OPPOSITE POSTURE TO `read_live_shape`, DELIBERATELY. That one REFUSES what it
    cannot verify, because passing a bundle whose columns were never inspected ships a
    permanently-wrong widget. This one returns an EMPTY MAP and says nothing, because
    its only consumer emits a WARNING — and a warning raised on absent evidence is
    worse than no warning: it teaches operators that the channel cries wolf, and then
    the true ones are ignored too.

    ⚠️ `pg_stats` only has rows where ANALYZE has run. Measured on VM3 (2026-08-17):
    of that workspace's transformer tables only `prioritized_vulnerabilities` carried
    statistics. So absence is COMMON, not exceptional, and "no statistics" must read as
    "no opinion" — never as "empty".
    """
    want = tuple(tables or SINK_TABLES)
    placeholders = ", ".join("'" + t.replace("'", "''") + "'" for t in want)
    sql = _NULL_FRAC_SQL.format(placeholders=placeholders)
    out = {}
    try:
        rows = _rows_of(client.query(sql, tenant_id=tenant_id, iam_context=iam_context))
    except Exception as exc:  # noqa: BLE001 — a probe must never fail its caller
        logger.warning(
            "populated-probe: could not read pg_stats (%s: %s); no populated warnings "
            "will be emitted for this install", type(exc).__name__, exc)
        return {}
    for row in rows:
        try:
            if isinstance(row, dict):
                t, c, nf = row["tablename"], row["attname"], row["null_frac"]
            else:
                t, c, nf = row[0], row[1], row[2]
            if nf is None:
                continue
            out[(str(t).lower(), str(c).lower())] = float(nf)
        except (KeyError, IndexError, TypeError, ValueError):
            continue
    return out
