"""
DuckDB backend implementation for pantheon datalake.

This backend provides DuckDB database support with file-based multi-tenancy.
Each tenant gets their own .duckdb file for complete data isolation.

Key features:
- File-based multi-tenancy (separate .duckdb file per tenant)
- Connection pooling support
- SQL query execution
- Automatic IAM field injection
- Text-to-SQL via LLM integration

Environment variables:
    DATALAKE_DATABASE_PATH: Directory for tenant database files (default: current directory)
"""

import os
import re
import threading
from pathlib import Path
from typing import List, Dict, Any, Optional, Set

import duckdb

# LiteLLM for text-to-SQL capability
try:
    from litellm import completion
    LITELLM_AVAILABLE = True
except ImportError:
    LITELLM_AVAILABLE = False
    completion = None

from .. import get_logger

from .base import DatalakeBackend
from .types import (
    QueryResult,
    UpsertResult,
    TableInfo,
    ColumnInfo,
    ConnectionConfig
)
from .exceptions import (
    ConnectionError as DatalakeConnectionError,
    QueryError,
    TableNotFoundError
)
from ..iam import IAMContext
from .schemas import DatalakeTables

logger = get_logger(__name__)


class DuckDBBackend(DatalakeBackend):
    """
    DuckDB backend implementation.

    Each tenant gets a separate .duckdb file in the configured directory:
    {database_path}/torana.{tenant_id}.duckdb

    Example:
        config = ConnectionConfig(
            database='/data/datalake',
            user='pantheon',
            password='secret',  # Not used by DuckDB but required by interface
            port=0
        )
        backend = DuckDBBackend(config)

        # Connect to tenant database
        backend.connect(tenant_id='tenant-123')

        # Execute query
        result = backend.query("SELECT * FROM vulnerabilities", tenant_id='tenant-123')

        # Insert data
        backend.insert(
            'vulnerabilities',
            [{'id': 1, 'severity': 'HIGH'}],
            tenant_id='tenant-123'
        )
    """

    def __init__(self, config: ConnectionConfig):
        """
        Initialize DuckDB backend.

        Args:
            config: Connection configuration (database field is used as directory path).
        """
        self.config = config
        self._lock = threading.RLock()

    @classmethod
    def from_env(cls) -> 'DuckDBBackend':
        """
        Create DuckDB backend from environment variables.

        Environment variables:
            DATALAKE_DATABASE_PATH: Directory for database files (default: current directory)

        Returns:
            Configured DuckDB backend instance.
        """
        database_path = os.getenv('DATALAKE_DATABASE_PATH', os.getcwd())

        config = ConnectionConfig(
            host='localhost',  # Not used by DuckDB but required
            port=0,  # Not used by DuckDB
            database=database_path,
            user='pantheon',
            password='',  # DuckDB doesn't use passwords
            pool_size=0,  # Connection pooling disabled - using temp connections for multi-tenancy
            idle_timeout=int(os.getenv('DATALAKE_IDLE_TIMEOUT', '300'))
        )

        return cls(config)

    def connect(self, tenant_id: Optional[str] = None) -> bool:
        """
        Connect to DuckDB database.

        Note: With temporary connections, this is a no-op but kept for API compatibility.
        Each operation creates its own temporary connection.

        Args:
            tenant_id: Optional tenant ID (not used with temp connections).

        Returns:
            True (always succeeds).
        """
        return True

    def disconnect(self) -> None:
        """
        Disconnect from DuckDB database.

        Note: With temporary connections, this is a no-op but kept for API compatibility.
        Each operation manages its own temporary connection.
        """
        pass

    def _get_db_path(self, tenant_id: str, db_type: str = 'source') -> Path:
        """
        Get the database file path for a specific tenant and database type.

        Args:
            tenant_id: Tenant identifier.
            db_type: Database type - 'source' or 'transformers' (default: 'source').

        Returns:
            Path to the DuckDB database file.

        Raises:
            ValueError: If tenant_id is None or db_type is invalid.
        """
        if not tenant_id:
            raise ValueError("tenant_id is required for DuckDB file path resolution")

        if db_type not in ('source', 'transformers'):
            raise ValueError(f"Invalid db_type: {db_type}. Must be 'source' or 'transformers'")

        db_dir = Path(self.config.database)

        if db_type == 'source':
            return db_dir / f"torana_source_{tenant_id}.duckdb"
        else:  # transformers
            return db_dir / f"torana_transformers_{tenant_id}.duckdb"

    def _get_standard_table_names(self) -> Set[str]:
        """
        Get the set of standard datalake table names.

        Returns:
            Set of standard table names that should go to main/source database.
        """
        return {table.value for table in DatalakeTables}

    def _extract_table_names(self, sql: str) -> Set[str]:
        """
        Extract table names from SQL query.

        Looks for table names in FROM, JOIN, and DESCRIBE clauses, handling:
        - Simple table names: `FROM assets`, `DESCRIBE assets`
        - Schema-qualified names: `FROM main.assets`, `DESCRIBE main.assets`
        - Database.schema.table names: `FROM transformers.transformers.vm_metrics`

        Args:
            sql: SQL query string.

        Returns:
            Set of table names (without database/schema qualifiers).
        """
        sql_lower = sql.lower()
        table_names = set()

        # Pattern to match FROM/JOIN/DESCRIBE clauses with optional qualifiers
        # Matches: FROM table, FROM schema.table, FROM db.schema.table
        # Also matches JOIN and DESCRIBE with same patterns
        pattern = r'\b(from|join|describe)\s+([\w.]+)'

        for match in re.finditer(pattern, sql_lower, re.IGNORECASE):
            full_table_ref = match.group(2).strip()

            # Extract the base table name (last component after dots)
            # e.g., "main.assets" -> "assets", "transformers.transformers.vm_metrics" -> "vm_metrics"
            table_name = full_table_ref.split('.')[-1]
            table_names.add(table_name)

        return table_names

    def _needs_transformer_db(self, sql: str) -> bool:
        """
        Detect if a SQL query needs access to the transformer database.

        Decision logic:
        1. Any reference to `main.<Table>` -> use source database
        2. Any reference to `transformers.<table>` -> use transformer database
        3. If ALL tables are standard (issues, datastores, findings, identities, assets,
           repositories, vulnerabilities, artifacts) -> use source database
        4. If ANY table is NOT a standard table -> use transformer database
           (This handles queries joining source and transformer tables)

        Args:
            sql: SQL query string.

        Returns:
            True if query needs transformer DB, False if it needs source DB.
        """
        sql_lower = sql.lower()

        # Rule 1: explicit main.<table> reference -> use source database
        # Check for patterns like "FROM main.table", "JOIN main.table", "DESCRIBE main.table"
        if re.search(r'\b(from|join|describe)\s+main\.\w+', sql_lower, re.IGNORECASE):
            return False

        # Rule 2: explicit transformers.<table> reference -> use transformer database
        # Check for patterns like "FROM transformers.table", "JOIN transformers.table", "DESCRIBE transformers.table"
        if re.search(r'\b(from|join|describe)\s+transformers\.', sql_lower, re.IGNORECASE):
            return True

        # Rule 3 & 4: Extract table names and check if they are standard tables
        standard_tables = self._get_standard_table_names()
        table_names = self._extract_table_names(sql)

        # If ALL tables are standard tables, use source database
        # If ANY table is NOT a standard table, use transformer database
        # This handles queries that join source and transformer tables
        if not table_names:
            return False

        for table_name in table_names:
            if table_name not in standard_tables:
                # Found a non-standard table -> need transformer database
                return True

        # All tables are standard tables -> use source database
        return False

    def _qualify_table_references(self, sql: str, conn: duckdb.DuckDBPyConnection, transformers_attached: bool = False) -> str:
        """
        Qualify all table references with their full database.schema.table paths.

        Rules:
        - Standard tables (issues, datastores, findings, identities, assets, repositories, vulnerabilities, artifacts):
          - main.table or table -> qualified as main.table
        - Transformer tables (only if transformers_attached=True):
          - transformers.table or table -> qualified as transformers.transformers.table
        - Already fully qualified names are left as-is
        - If transformers_attached=False, non-standard tables are left unqualified

        Handles:
        - FROM/JOIN clauses
        - DESCRIBE statements

        Args:
            sql: Original SQL query
            conn: DuckDB connection (used to query transformer tables)
            transformers_attached: Whether the transformers database is attached

        Returns:
            Modified SQL with qualified table names
        """
        import re

        standard_tables = self._get_standard_table_names()

        # Get list of actual transformer tables (only if transformers DB is attached)
        transformer_tables = set()
        if transformers_attached:
            try:
                result = conn.execute("""
                    SELECT table_name FROM information_schema.tables
                    WHERE table_schema = 'transformers'
                """).fetchall()
                transformer_tables = {row[0].lower() for row in result}
            except Exception:
                # If query fails, we'll still qualify based on standard tables list
                pass

        modified_sql = sql

        # Handle DESCRIBE statements first (e.g., DESCRIBE table_name)
        describe_pattern = r'\bDESCRIBE\s+([\w.]+)'

        def replace_describe_ref(match):
            full_ref = match.group(1)
            parts = full_ref.split('.')
            base_name = parts[-1].lower()

            # Already fully qualified (db.schema.table) -> leave as-is
            if len(parts) == 3:
                return match.group(0)

            # Standard table -> main.table
            if base_name in standard_tables:
                if len(parts) == 2 and parts[0].lower() == 'main':
                    return match.group(0)  # Already main.table
                elif len(parts) == 1:
                    return f"DESCRIBE main.{full_ref}"
                return match.group(0)

            # Transformer table -> transformers.transformers.table (only if attached)
            if len(parts) == 2 and parts[0].lower() == 'transformers':
                if transformers_attached:
                    return f"DESCRIBE transformers.transformers.{parts[1]}"
                else:
                    return match.group(0)  # Don't qualify if not attached
            elif len(parts) == 1:
                # Unqualified non-standard table
                if transformers_attached and (base_name in transformer_tables or not transformer_tables):
                    return f"DESCRIBE transformers.transformers.{full_ref}"
                else:
                    # Leave unqualified (will be treated as main.table)
                    return f"DESCRIBE main.{full_ref}"

            # main.<non-standard-table> -> leave as-is
            if len(parts) == 2 and parts[0].lower() == 'main':
                return match.group(0)

            return match.group(0)

        modified_sql = re.sub(describe_pattern, replace_describe_ref, modified_sql, flags=re.IGNORECASE)

        # Handle FROM and JOIN clauses
        # Pattern matches: FROM table, FROM schema.table, FROM db.schema.table
        # Also matches JOIN with same patterns
        pattern = r'\b(from|join)\s+([\w.]+)'

        def replace_table_ref(match):
            keyword = match.group(1)  # FROM or JOIN
            full_ref = match.group(2)  # table reference

            parts = full_ref.split('.')
            base_name = parts[-1].lower()

            # Already fully qualified (db.schema.table) -> leave as-is
            if len(parts) == 3:
                return match.group(0)

            # Standard table
            if base_name in standard_tables:
                # main.table or table -> main.table
                if len(parts) == 2 and parts[0].lower() == 'main':
                    return match.group(0)  # Already main.table
                elif len(parts) == 1:
                    return f"{keyword} main.{full_ref}"  # table -> main.table
                return match.group(0)

            # Transformer table (or unknown table - treat as transformer, only if attached)
            # transformers.table or table -> transformers.transformers.table
            if len(parts) == 2 and parts[0].lower() == 'transformers':
                if transformers_attached:
                    return f"{keyword} transformers.transformers.{parts[1]}"
                else:
                    return match.group(0)  # Don't qualify if not attached
            elif len(parts) == 1:
                # Unqualified table name
                if transformers_attached and (base_name in transformer_tables or not transformer_tables):
                    return f"{keyword} transformers.transformers.{full_ref}"
                else:
                    # Treat as main.table if not a transformer table or not attached
                    return f"{keyword} main.{full_ref}"

            # main.<non-standard-table> -> leave as-is (user explicitly chose main)
            if len(parts) == 2 and parts[0].lower() == 'main':
                return match.group(0)

            return match.group(0)

        modified_sql = re.sub(pattern, replace_table_ref, modified_sql, flags=re.IGNORECASE)

        return modified_sql

    def _get_temp_connection(self, tenant_id: str, db_type: str = 'source') -> duckdb.DuckDBPyConnection:
        """
        Create a temporary DuckDB connection for a single operation.

        This is the preferred method for multi-service environments to avoid file locking.
        The connection should be closed immediately after use.

        Args:
            tenant_id: Tenant ID for database file path.
            db_type: Database type - 'source' or 'transformers'.

        Returns:
            DuckDB connection object (caller must close it).

        Raises:
            ConnectionError: If connection creation fails.
        """
        try:
            # Ensure database directory exists
            db_dir = Path(self.config.database)
            db_dir.mkdir(parents=True, exist_ok=True)

            # Get path for the specific database type
            db_path = self._get_db_path(tenant_id, db_type=db_type)

            # Create connection
            conn = duckdb.connect(str(db_path))

            # Configure connection settings
            conn.execute("PRAGMA enable_progress_bar = false")
            conn.execute("PRAGMA default_order = 'DESC'")

            return conn

        except Exception as e:
            raise DatalakeConnectionError(
                f"Failed to create DuckDB connection: {str(e)}",
                backend='duckdb',
                database=self.config.database
            ) from e

    def query(
        self,
        sql: str,
        tenant_id: str,
        params: Optional[Dict[str, Any]] = None
    ) -> QueryResult:
        """
        Execute a SQL query.

        Routing logic:
        1. main.<table> -> source database
        2. transformers.<table> -> transformer database
        3. Standard tables (issues, datastores, findings, identities, assets,
           repositories, vulnerabilities, artifacts) -> source database
        4. Any other table -> transformer database

        Table qualification:
        - Standard tables: main.table or table -> qualified as main.table
        - Transformer tables: transformers.table or table -> qualified as transformers.transformers.table

        Uses temporary connections to avoid file locking in multi-service environments.

        Args:
            sql: SQL query string.
            tenant_id: Tenant ID for multi-tenancy.
            params: Optional query parameters.

        Returns:
            QueryResult with rows and metadata.

        Raises:
            ConnectionError: If not connected.
            QueryError: If query execution fails.
        """
        # Use temporary connection to avoid file locking
        conn = None
        transformers_attached = False
        try:
            conn = self._get_temp_connection(tenant_id)

            # Check if query needs transformer database
            needs_transformers = self._needs_transformer_db(sql)

            # Attach transformer database if needed
            if needs_transformers:
                transformer_path = self._get_db_path(tenant_id, 'transformers')
                # Only attach if the transformer database file exists
                if os.path.exists(transformer_path):
                    # Attach as 'transformers' database with READ_ONLY mode
                    attach_sql = f"ATTACH '{transformer_path}' AS transformers (READ_ONLY)"
                    conn.execute(attach_sql)
                    transformers_attached = True
                # If transformers DB doesn't exist, transformers_attached stays False

            # Qualify all table references (both standard and transformer tables)
            # - Standard tables: main.table or table -> main.table
            # - Transformer tables: transformers.table or table -> transformers.transformers.table (only if attached)
            modified_sql = self._qualify_table_references(sql, conn, transformers_attached)

            # Execute query
            if params:
                # DuckDB uses %s style parameters
                result = conn.execute(modified_sql, params)
            else:
                result = conn.execute(modified_sql)

            # Fetch results
            rows = [list(row) for row in result.fetchall()]
            columns = [desc[0] for desc in result.description]

            return QueryResult(
                columns=columns,
                rows=rows
            )

        except duckdb.Error as e:
            raise QueryError(
                f"Query execution failed: {str(e)}",
                sql=sql,
                backend='duckdb'
            ) from e
        finally:
            # Detach transformer database if we attached it
            if conn and transformers_attached:
                try:
                    conn.execute("DETACH transformers")
                except Exception:
                    # Ignore detach errors (connection might be closed)
                    pass
            # Always close the temporary connection
            if conn:
                conn.close()

    def _inject_iam_fields(
        self,
        data: List[Dict[str, Any]],
        tenant_id: str
    ) -> List[Dict[str, Any]]:
        """
        Inject IAM fields into data records.

        Automatically adds tenant_id and namespace_id to each record if not already present.
        Uses the default namespace for the tenant (derived from IAMContext derivation logic).

        Args:
            data: List of records to enrich
            tenant_id: Tenant ID

        Returns:
            List of enriched records with IAM fields
        """
        # Derive namespace_id using the same logic as IAMContext
        # This uses the static method that queries the database or generates deterministic UUID
        namespace_id = IAMContext._derive_namespace_id(tenant_id)

        enriched_data = []
        for record in data:
            enriched_record = record.copy()

            # Add tenant_id if not present
            if 'tenant_id' not in enriched_record:
                enriched_record['tenant_id'] = tenant_id

            # Add namespace_id if not present
            if 'namespace_id' not in enriched_record and namespace_id:
                enriched_record['namespace_id'] = namespace_id

            enriched_data.append(enriched_record)

        return enriched_data

    def insert(
        self,
        table: str,
        data: List[Dict[str, Any]],
        tenant_id: str
    ) -> UpsertResult:
        """
        Insert records into a table.

        Uses temporary connections to avoid file locking in multi-service environments.

        Args:
            table: Table name.
            data: List of records to insert.
            tenant_id: Tenant ID for multi-tenancy.

        Returns:
            UpsertResult with operation statistics.

        Raises:
            QueryError: If insert fails.
        """
        if not data:
            return UpsertResult(success=True, inserted=0, updated=0)

        # Inject IAM fields (tenant_id, namespace_id) into data
        enriched_data = self._inject_iam_fields(data, tenant_id)

        # Use temporary connection to avoid file locking
        conn = None
        try:
            conn = self._get_temp_connection(tenant_id)

            # Build INSERT query
            columns = list(enriched_data[0].keys())
            placeholders = ', '.join(['?' for _ in columns])
            column_names = ', '.join(columns)

            sql = f"INSERT INTO {table} ({column_names}) VALUES ({placeholders})"

            # Flatten data for batch insert
            values = [
                [row[col] for col in columns]
                for row in enriched_data
            ]

            # Execute insert
            conn.executemany(sql, values)
            conn.commit()

            return UpsertResult(
                success=True,
                inserted=len(enriched_data),
                updated=0
            )

        except duckdb.Error as e:
            raise QueryError(
                f"Insert failed: {str(e)}",
                backend='duckdb'
            ) from e
        finally:
            # Always close the temporary connection
            if conn is not None:
                conn.close()

    def upsert(
        self,
        table: str,
        data: List[Dict[str, Any]],
        primary_key: str,
        tenant_id: str,
        preserve_columns: Optional[List[str]] = None,
    ) -> UpsertResult:
        """
        Upsert records (insert or update) into a table.

        DuckDB doesn't have native UPSERT, so we simulate it by checking
        if the record exists and inserting/updating accordingly.

        preserve_columns, when given, are skipped in the UPDATE branch so an
        existing row keeps its stored value (new rows still take it on INSERT).

        Uses temporary connections to avoid file locking in multi-service environments.

        Args:
            table: Table name.
            data: List of records to upsert.
            primary_key: Primary key column name.
            tenant_id: Tenant ID for multi-tenancy.

        Returns:
            UpsertResult with operation statistics.

        Raises:
            QueryError: If upsert fails.
        """
        # Inject IAM fields (tenant_id, namespace_id) into data
        enriched_data = self._inject_iam_fields(data, tenant_id)

        # Log database file path for debugging
        db_path = self._get_db_path(tenant_id)
        logger.info(f"[DuckDB] Upserting {len(enriched_data)} records into {table} for tenant {tenant_id}")
        logger.info(f"[DuckDB] Database file: {db_path}")

        # Use temporary connection to avoid file locking
        conn = None
        try:
            conn = self._get_temp_connection(tenant_id)

            inserted = 0
            updated = 0
            _preserve = set(preserve_columns or ())

            for record in enriched_data:
                # Check if record exists
                pk_value = record.get(primary_key)
                if pk_value is None:
                    raise QueryError(
                        f"Primary key '{primary_key}' not found in record",
                        backend='duckdb'
                    )

                # Check if exists
                check_sql = f"SELECT COUNT(*) as count FROM {table} WHERE {primary_key} = ?"
                result = conn.execute(check_sql, [pk_value]).fetchone()

                if result[0] > 0:
                    # Update existing record (skip preserve_columns so existing
                    # human-owned values survive an automated re-ingest).
                    _upd_cols = [
                        col for col in record.keys()
                        if col != primary_key and col not in _preserve
                    ]
                    set_clause = ', '.join([f"{col} = ?" for col in _upd_cols])
                    update_values = [record[col] for col in _upd_cols] + [pk_value]
                    update_sql = f"UPDATE {table} SET {set_clause} WHERE {primary_key} = ?"

                    conn.execute(update_sql, update_values)
                    updated += 1
                else:
                    # Insert new record
                    columns = list(record.keys())
                    placeholders = ', '.join(['?' for _ in columns])
                    column_names = ', '.join(columns)
                    values = [record[col] for col in columns]

                    insert_sql = f"INSERT INTO {table} ({column_names}) VALUES ({placeholders})"
                    conn.execute(insert_sql, values)
                    inserted += 1

            conn.commit()
            # Force checkpoint to ensure data is visible to other connections
            # This is critical in multi-process environments
            try:
                conn.execute("CHECKPOINT")
            except Exception as checkpoint_error:
                logger.warning(f"[DuckDB] Checkpoint after upsert failed (non-fatal): {checkpoint_error}")

            return UpsertResult(
                success=True,
                inserted=inserted,
                updated=updated
            )

        except duckdb.Error as e:
            raise QueryError(
                f"Upsert failed: {str(e)}",
                backend='duckdb'
            ) from e
        finally:
            # Always close the temporary connection
            if conn is not None:
                conn.close()

    # Type mapping from Snowflake/PostgreSQL to DuckDB
    _TYPE_MAPPING = {
        'TIMESTAMP_NTZ': 'TIMESTAMP',
        'TIMESTAMP_TZ': 'TIMESTAMPTZ',
        'VARIANT': 'JSON',
        'OBJECT': 'JSON',
        'ARRAY': 'JSON',
        'BINARY': 'BLOB',
    }

    def _convert_type(self, col_type: str) -> str:
        """
        Convert Snowflake/PostgreSQL types to DuckDB types.

        Args:
            col_type: Source column type (e.g., 'TIMESTAMP_NTZ', 'VARCHAR(255)')

        Returns:
            DuckDB-compatible type string
        """
        # Handle VARCHAR with length - keep as-is
        if col_type.startswith('VARCHAR'):
            return col_type

        # Handle DECIMAL with precision - keep as-is
        if col_type.startswith('DECIMAL'):
            return col_type

        # Map Snowflake-specific types
        return self._TYPE_MAPPING.get(col_type, col_type)

    def create_table(
        self,
        table: str,
        schema: Dict[str, Any],
        tenant_id: str
    ) -> bool:
        """
        Create a new table.

        Uses temporary connections to avoid file locking in multi-service environments.

        Args:
            table: Table name.
            schema: Column schema mapping (column_name -> column_definition).
                Can be simple type strings: {"id": "UUID", "name": "VARCHAR"}
                Or rich dicts: {"id": {"data_type": "UUID", "primary_key": True}}
            tenant_id: Tenant ID for multi-tenancy.

        Returns:
            True if table created successfully.

        Raises:
            QueryError: If table creation fails.
        """
        conn = None
        try:
            conn = self._get_temp_connection(tenant_id)

            # Build CREATE TABLE statement with support for rich schema metadata
            column_defs = []
            for name, col_def in schema.items():
                # Handle both simple type string and rich dict definitions
                if isinstance(col_def, dict):
                    # Rich schema definition with metadata
                    col_type = col_def.get('data_type', 'VARCHAR')
                    is_primary_key = col_def.get('primary_key', False)
                    is_not_null = col_def.get('not_null', False)
                else:
                    # Simple type string (backwards compatibility)
                    col_type = col_def
                    is_primary_key = False
                    is_not_null = False

                # Convert Snowflake/PostgreSQL types to DuckDB types
                col_type = self._convert_type(col_type)

                # Build column definition
                col_sql = f'"{name}" {col_type}'

                # Add PRIMARY KEY constraint if specified
                if is_primary_key:
                    col_sql += ' PRIMARY KEY'
                # Add NOT NULL constraint if specified (but not if already PRIMARY KEY)
                elif is_not_null:
                    col_sql += ' NOT NULL'

                column_defs.append(col_sql)

            columns = ', '.join(column_defs)
            sql = f'CREATE TABLE "{table}" ({columns})'

            conn.execute(sql)
            conn.commit()

            return True

        except duckdb.Error as e:
            raise QueryError(
                f"Table creation failed: {str(e)}",
                backend='duckdb'
            ) from e
        finally:
            if conn is not None:
                conn.close()

    def drop_table(self, table: str, tenant_id: str, db_type: Optional[str] = None) -> bool:
        """
        Drop a table.

        Uses temporary connections to avoid file locking in multi-service environments.

        Args:
            table: Table name.
            tenant_id: Tenant ID for multi-tenancy.
            db_type: Optional database type ('source' or 'transformers').
                    Defaults to 'source' for backward compatibility.

        Returns:
            True if table dropped successfully.

        Raises:
            QueryError: If drop fails.
        """
        conn = None
        try:
            # Default to 'source' for backward compatibility
            target_db_type = db_type or 'source'
            conn = self._get_temp_connection(tenant_id, db_type=target_db_type)

            # Tables in transformers database are in 'transformers' schema
            # Tables in source database are in 'main' schema
            if target_db_type == 'transformers':
                schema_qualified_table = f'transformers."{table}"'
            else:
                schema_qualified_table = f'"{table}"'

            conn.execute(f'DROP TABLE IF EXISTS {schema_qualified_table}')
            conn.commit()

            return True

        except duckdb.Error as e:
            raise QueryError(
                f"Table drop failed: {str(e)}",
                backend='duckdb'
            ) from e
        finally:
            if conn is not None:
                conn.close()

    def table_exists(self, table: str, tenant_id: str) -> bool:
        """
        Check if a table exists in either source or transformers database.

        Uses temporary connections to avoid file locking in multi-service environments.

        Args:
            table: Table name.
            tenant_id: Tenant ID for multi-tenancy.

        Returns:
            True if table exists in either database.
        """
        conn = None
        try:
            # First check source database
            conn = self._get_temp_connection(tenant_id, db_type='source')
            result = conn.execute(
                f"SELECT table_name FROM information_schema.tables WHERE table_name = '{table}'"
            ).fetchone()
            if result is not None:
                return True
            conn.close()

            # Then check transformers database
            conn = self._get_temp_connection(tenant_id, db_type='transformers')
            result = conn.execute(
                f"SELECT table_name FROM information_schema.tables WHERE table_name = '{table}'"
            ).fetchone()
            return result is not None

        except duckdb.Error:
            return False
        finally:
            if conn is not None:
                conn.close()

    def list_tables(
        self,
        tenant_id: str,
        db_type: Optional[str] = None
    ) -> List[TableInfo]:
        """
        List all tables for a tenant.

        Args:
            tenant_id: Tenant ID for multi-tenancy.
            db_type: Optional database type filter ('source', 'transformers', or 'all').
                    - 'source': Returns only source tables
                    - 'transformers': Returns only transformer output tables
                    - 'all': Returns both source and transformer tables
                    - None: Defaults to 'source' for backward compatibility

        Returns:
            List of TableInfo objects.
        """
        # Default to source database if not specified (backward compatibility)
        target_db_type = db_type or 'source'

        # Handle 'all' - return both source and transformer tables
        if target_db_type == 'all':
            source_tables = self.list_tables(tenant_id, db_type='source')
            transformer_tables = self.list_tables(tenant_id, db_type='transformers')
            return source_tables + transformer_tables

        # Validate db_type
        if target_db_type not in ('source', 'transformers'):
            raise ValueError(f"Invalid db_type: {db_type}. Must be 'source', 'transformers', or 'all'")

        # Get path for the target database
        db_path = self._get_db_path(tenant_id, target_db_type)

        # Return empty list if database file doesn't exist
        if not db_path.exists():
            return []

        # Create a temporary connection to the target database
        try:
            conn = duckdb.connect(str(db_path))

            # Tables are always in 'main' schema when connecting directly to the database file
            # The 'transformers' schema is only used when the transformer DB is attached to the source DB
            schema_filter = "'main'"
            schema_name = "main"

            result = conn.execute(
                f"SELECT table_name, table_type FROM information_schema.tables WHERE table_schema = {schema_filter}"
            ).fetchall()

            tables = []
            for row in result:
                tables.append(TableInfo(
                    name=row[0],
                    schema=schema_name,
                    table_type=row[1]
                ))

            conn.close()
            return tables

        except duckdb.Error as e:
            raise QueryError(
                f"Failed to list tables from {target_db_type} database: {str(e)}",
                backend='duckdb'
            ) from e

    def get_table_info(self, table: str, tenant_id: str) -> TableInfo:
        """
        Get detailed information about a table.

        Uses temporary connections to avoid file locking in multi-service environments.

        Args:
            table: Table name.
            tenant_id: Tenant ID for multi-tenancy.

        Returns:
            TableInfo with table metadata.

        Raises:
            TableNotFoundError: If table doesn't exist.
        """
        # Check if table exists
        if not self.table_exists(table, tenant_id):
            raise TableNotFoundError(
                table_name=table,
                schema=tenant_id,
                tenant_id=tenant_id
            )

        conn = None
        try:
            conn = self._get_temp_connection(tenant_id)

            # Get columns
            columns_result = conn.execute(
                f"PRAGMA table_info('{table}')"
            ).fetchall()

            columns = []
            for row in columns_result:
                # row: (cid, name, type, notnull, default_value, pk)
                columns.append(ColumnInfo(
                    name=row[1],
                    type=row[2],
                    nullable=row[3] == 0
                ))

            # Get row count
            count_result = conn.execute(
                f"SELECT COUNT(*) FROM {table}"
            ).fetchone()
            row_count = count_result[0] if count_result else 0

            return TableInfo(
                name=table,
                schema=tenant_id,
                row_count=row_count,
                columns=columns
            )
        finally:
            if conn is not None:
                conn.close()

    def text_to_sql(
        self,
        query: str,
        tenant_id: str,
        execute: bool = False
    ) -> Dict[str, Any]:
        """
        Convert natural language query to SQL using LLM.

        Args:
            query: Natural language query (e.g., "show me all critical vulnerabilities").
            tenant_id: Tenant identifier for scoping.
            execute: If True, execute the generated SQL and include results.

        Returns:
            Dictionary with keys:
                - 'sql': Generated SQL query string.
                - 'result': QueryResult if execute=True, None otherwise.
                - 'model': LLM model used for generation.

        Raises:
            QueryError: If text-to-SQL conversion fails.
        """
        if not LITELLM_AVAILABLE:
            raise QueryError("LiteLLM not available. Install litellm to use text-to-SQL: pip install litellm")

        # Import prompts
        from .text_to_sql import SYSTEM_PROMPT, USER_PROMPT_TEMPLATE

        user_prompt = USER_PROMPT_TEMPLATE.format(query=query)
        model = os.getenv("TEXT_TO_SQL_MODEL", "gpt-4")

        try:
            # Call LLM (use synchronous completion)
            response = completion(
                model=model,
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": user_prompt}
                ]
            )

            # Extract SQL from response
            sql = response.choices[0].message.content.strip()

            # Clean up markdown code blocks if present
            if sql.startswith("```"):
                # Extract content between ``` markers
                parts = sql.split("```")
                if len(parts) >= 2:
                    # Get the content after the first ```
                    sql = parts[1].strip()
                    # Remove language identifier if present (e.g., "sql")
                    if sql.startswith(("sql", "SQL")):
                        sql = sql.split("\n", 1)[1].strip()
            elif sql.startswith(("```sql", "```SQL")):
                # Handle ```sql...``` format
                sql = sql.split("\n", 1)[1].strip()
                if sql.endswith("```"):
                    sql = sql[:-3].strip()

            result = {
                'sql': sql,
                'model': model
            }

            if execute:
                query_result = self.query(sql, tenant_id)
                result['result'] = query_result.to_dict_list()

            return result

        except Exception as e:
            raise QueryError(f"Text-to-SQL conversion failed: {e}")

    def health_check(self) -> bool:
        """
        Check if the backend is healthy.

        Returns:
            True if backend is operational (always True for temp connections).
        """
        # With temporary connections, we're always healthy if we can create a connection
        # Try to create a temp connection to the default tenant
        try:
            conn = self._get_temp_connection('health-check')
            conn.execute("SELECT 1")
            conn.close()
            return True
        except Exception:
            return False

    def get_row_count(self, table: str, tenant_id: str) -> int:
        """
        Get the number of rows in a table.

        Args:
            table: Table name.
            tenant_id: Tenant ID for multi-tenancy.

        Returns:
            Number of rows in the table.

        Raises:
            QueryError: If query fails.
        """
        result = self.query(
            f"SELECT COUNT(*) as count FROM {table}",
            tenant_id
        )
        return result.first_row()['count']

    def cleanup_tenant(self, tenant_id: str) -> Dict[str, Any]:
        """Clean up all tenant data by dropping tables and removing database files.

        DuckDB uses file-per-tenant isolation, so cleanup means:
        1. Dropping all tables from the tenant's databases
        2. Closing connections for this tenant
        3. Removing the database files

        Args:
            tenant_id: Tenant UUID to clean up.

        Returns:
            Dict with cleanup results.
        """
        import os

        dropped_tables = []
        removed_files = []
        errors = []

        # Get all available schemas for dropping tables
        from pantheon_shared.datalake import (
            IdentitySchema, RepositoriesSchema, VulnerabilitySchema,
            AssetsSchema, DatastoresSchema, ArtifactsSchema, FindingsSchema, IssuesSchema
        )

        schemas = {
            'identities': IdentitySchema(),
            'repositories': RepositoriesSchema(),
            'vulnerabilities': VulnerabilitySchema(),
            'assets': AssetsSchema(),
            'datastores': DatastoresSchema(),
            'artifacts': ArtifactsSchema(),
            'findings': FindingsSchema(),
            'issues': IssuesSchema()
        }

        # First drop all tables from both databases
        for table_name in schemas.keys():
            try:
                # Try source database
                if self.drop_table(table_name, tenant_id):
                    dropped_tables.append(f"{table_name} (source)")
                    logger.info(f"Dropped table {table_name} from source DB for tenant {tenant_id}")
            except Exception as e:
                # Table might not exist, which is fine
                logger.debug(f"Table {table_name} did not exist in source DB for tenant {tenant_id}: {e}")

            try:
                # Try transformers database
                if self.drop_table(table_name, tenant_id):
                    dropped_tables.append(f"{table_name} (transformers)")
                    logger.info(f"Dropped table {table_name} from transformers DB for tenant {tenant_id}")
            except Exception as e:
                # Table might not exist, which is fine
                logger.debug(f"Table {table_name} did not exist in transformers DB for tenant {tenant_id}: {e}")

        # Close all connections for this tenant
        try:
            if hasattr(self, 'close_tenant_connections'):
                self.close_tenant_connections(tenant_id)
        except Exception as e:
            errors.append(f"Failed to close connections: {str(e)}")
            logger.error(f"Error closing connections for tenant {tenant_id}: {e}")

        # Remove the database files
        db_dir = Path(self.config.database)
        source_db_path = db_dir / f"torana_source_{tenant_id}.duckdb"
        transformers_db_path = db_dir / f"torana_transformers_{tenant_id}.duckdb"

        for db_path in [source_db_path, transformers_db_path]:
            try:
                if os.path.exists(db_path):
                    os.remove(db_path)
                    removed_files.append(str(db_path))
                    logger.info(f"Removed database file: {db_path}")
            except Exception as e:
                error_msg = f"Failed to remove {db_path}: {str(e)}"
                errors.append(error_msg)
                logger.error(error_msg)

        return {
            'success': len(errors) == 0,
            'dropped_tables': dropped_tables,
            'dropped_schemas': [],  # DuckDB doesn't use schemas
            'removed_files': removed_files,
            'errors': errors
        }

    def cleanup_orphaned(
        self,
        valid_tenant_ids: List[str],
        tenant_id: Optional[str] = None,
        dry_run: bool = False,
    ) -> Dict[str, Any]:
        """Clean up orphaned database files for deleted tenants.

        Finds all DuckDB files (torana_source_*.duckdb, torana_transformers_*.duckdb)
        and removes those whose tenant IDs are not in the valid_tenant_ids list.

        DuckDB detects orphans at FILE granularity only — a whole per-tenant
        database file. Row-level orphan scanning inside a surviving tenant's file
        is deliberately out of scope here and implemented for PostgreSQL only.

        Every reported object carries the canonical four keys consumed by
        pantheon-admin (`table`, `id`, `name`, `tenant_id`) plus an additive
        `type` key ('file') for callers that discriminate on it.

        Args:
            valid_tenant_ids: List of valid tenant UUIDs from pantheon-auth.
            tenant_id: Optional tenant id — NARROWS results to orphans belonging
                to this tenant.
            dry_run: When True, report orphans without removing any file.

        Returns:
            Dict with cleanup results.
        """
        import os
        import glob

        orphaned_files = []
        removed_files = []
        orphaned_objects: List[Dict[str, Any]] = []
        errors = []

        # Convert to set for faster lookup
        valid_tenant_set = set(valid_tenant_ids)

        # Find all DuckDB files in data directory
        db_dir = Path(self.config.database)

        if not os.path.exists(db_dir):
            return {
                'success': True,
                'orphaned_schemas': [],  # DuckDB doesn't use schemas
                'orphaned_files': [],
                'dropped_schemas': [],
                'removed_files': [],
                'orphaned_objects': [],
                'orphaned_rows': [],
                'deleted_rows': 0,
                'errors': []
            }

        # Find all torana_source_*.duckdb and torana_transformers_*.duckdb files
        source_files = glob.glob(os.path.join(db_dir, "torana_source_*.duckdb"))
        transformer_files = glob.glob(os.path.join(db_dir, "torana_transformers_*.duckdb"))

        all_db_files = source_files + transformer_files

        # Extract tenant_id from each file and check if it's valid
        for db_file in all_db_files:
            filename = os.path.basename(db_file)

            # Extract tenant_id from filename
            # torana_source_{tenant_id}.duckdb or torana_transformers_{tenant_id}.duckdb
            if "torana_source_" in filename:
                file_tenant_id = filename.replace("torana_source_", "").replace(".duckdb", "")
            elif "torana_transformers_" in filename:
                file_tenant_id = filename.replace("torana_transformers_", "").replace(".duckdb", "")
            else:
                # Skip files that don't match the expected pattern
                continue

            # Check if this tenant is valid
            if file_tenant_id in valid_tenant_set:
                continue

            # Scoped run: only report the requested tenant's files.
            if tenant_id and file_tenant_id != tenant_id:
                continue

            orphaned_files.append(db_file)
            orphaned_objects.append({
                # A file has no row id; the file path IS its identity.
                'type': 'file',
                'table': db_file,
                'id': db_file,
                'name': os.path.basename(db_file),
                'tenant_id': file_tenant_id,
            })
            logger.info(f"Found orphaned database file: {db_file} (tenant: {file_tenant_id})")

            if dry_run:
                continue

            # Remove the file
            try:
                # Close any open connections for this tenant first
                if hasattr(self, 'close_tenant_connections'):
                    self.close_tenant_connections(file_tenant_id)

                os.remove(db_file)
                removed_files.append(db_file)
                logger.info(f"Removed orphaned database file: {db_file}")
            except Exception as e:
                error_msg = f"Failed to remove orphaned file {db_file}: {str(e)}"
                errors.append(error_msg)
                logger.error(error_msg)

        return {
            'success': len(errors) == 0,
            'orphaned_schemas': [],  # DuckDB doesn't use schemas
            'orphaned_files': orphaned_files,
            'dropped_schemas': [],
            'removed_files': removed_files,
            'orphaned_objects': orphaned_objects,
            'orphaned_rows': [],  # DuckDB is file-granularity only
            'deleted_rows': 0,
            'errors': errors
        }

    def __repr__(self) -> str:
        """String representation."""
        return f"DuckDBBackend(database={self.config.database})"
