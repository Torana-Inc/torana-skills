"""
DatalakeClient - unified interface for all datalake backends.

This module provides a single client interface that abstracts away
backend-specific details (DuckDB, Snowflake, PostgreSQL).

Key features:
- Factory pattern: Backend selected via DATALAKE_BACKEND env var
- Singleton pattern: Reuses a single client instance per backend type
- Tenant ID resolution: Explicit or from IAMContext
- IAM field auto-injection: tenant_id, namespace_id, created_by, updated_by
- Connection pooling: Reuses connections across operations
"""

import os
import inspect
import threading
import time
from typing import List, Dict, Any, Optional

from .base import DatalakeBackend
from .types import QueryResult, UpsertResult, TableInfo
from .exceptions import (
    ValidationError,
    BackendNotSupportedError
)
from .metrics import (
    get_datalake_metrics_registry,
    DATALAKE_METRICS_ENABLED
)


# Singleton instances cache: {backend_type: DatalakeClient}
_client_instances: Dict[str, 'DatalakeClient'] = {}

#: ⛔ GUARDS `_client_instances`. This was `None`, with the comment "will be initialized with
#: a lock when needed" — and never was. So `__new__` did an UNLOCKED check-then-insert. Every
#: caller that lost that race built its OWN client, and `PostgresBackend.__init__` calls
#: `_initialize_pool()` unconditionally, so each one opened a SEPARATE connection pool of
#: `pool_size` connections.
#:
#: ⚠️ Measured 2026-08-18 (pantheon-agent-builder, one authoring run): **8 pools created in
#: the SAME SECOND on the SAME worker** — 8 x max=6 = 48 connections demanded — ending in
#: `connection pool exhausted`. ADK dispatches tool calls concurrently, and
#: `check_columns_populated_tool.py` alone constructs `DatalakeClient()` at four call sites.
#:
#: ⛔ The cost is NOT a slow query. The exhaustion made `get_table_schema` fail, which
#: silently disabled the schema-first guard in `check_columns_populated_tool` (it falls back
#: to "probe everything" when the schema read fails), which let the agent issue
#: `SELECT count(status)` for a column that does not exist — surfacing as apparent LLM
#: hallucination. ONE race, THREE symptoms.
#:
#: A module-level Lock is correct here, not a lazily-created one: creating the lock lazily is
#: the same check-then-act race, one level up.
_client_lock = threading.Lock()


def _create_backend(backend_type: str) -> DatalakeBackend:
    """
    Create a backend instance based on backend type.

    Args:
        backend_type: Type of backend ('duckdb', 'snowflake', 'postgres')

    Returns:
        Backend instance

    Raises:
        BackendNotSupportedError: If backend type is not supported
    """
    # Import backend implementations only when needed
    # This avoids circular imports and reduces startup time
    if backend_type == 'duckdb':
        from .duckdb_backend import DuckDBBackend
        return DuckDBBackend.from_env()
    elif backend_type == 'snowflake':
        from .snowflake_backend import SnowflakeBackend
        return SnowflakeBackend.from_env()
    elif backend_type == 'postgres':
        from .postgres_backend import PostgreSQLBackend
        return PostgreSQLBackend.from_env()
    else:
        raise BackendNotSupportedError(
            backend_type=backend_type,
            supported_types=['duckdb', 'snowflake', 'postgres']
        )


class DatalakeClient:
    """
    Unified client interface for all datalake backends.

    This client provides a consistent API regardless of which backend
    is configured (DuckDB, Snowflake, or PostgreSQL).

    Example:
        # From environment variable
        client = DatalakeClient()

        # Explicit backend
        client = DatalakeClient(backend_type='postgres')

        # With user context for IAM field injection
        client = DatalakeClient(user=authenticated_user)

        # Execute query
        result = client.query("SELECT * FROM vulnerabilities", tenant_id='tenant-123')
    """

    # IAM field names for auto-injection
    IAM_FIELDS = ['tenant_id', 'namespace_id', 'created_by', 'updated_by', 'is_deleted']

    def __new__(
        cls,
        backend_type: Optional[str] = None,
        backend: Optional[DatalakeBackend] = None,
        user: Optional[Any] = None,
        calling_service: Optional[str] = None,
        _force_new: bool = False
    ):
        """
        Create or return singleton DatalakeClient instance.

        Args:
            backend_type: Explicit backend type ('duckdb', 'snowflake', 'postgres').
            backend: Pre-configured backend instance (bypasses singleton, for testing).
            user: User context for IAM field injection (updated per call).
            calling_service: Service name for metrics tracking.
            _force_new: Internal flag to force new instance (for testing).

        Returns:
            DatalakeClient instance (singleton for given backend type)
        """
        # If a custom backend is provided, bypass singleton (for testing)
        if backend is not None or _force_new:
            return super(DatalakeClient, cls).__new__(cls)

        # Determine backend type
        if backend_type is None:
            backend_type = os.getenv('DATALAKE_BACKEND')
            if backend_type is None:
                raise ValidationError(
                    "DATALAKE_BACKEND environment variable must be set. "
                    "Supported values: 'duckdb', 'postgres', 'snowflake'."
                )

        # Validate backend type is not empty
        if not backend_type or not backend_type.strip():
            raise ValidationError(
                f"DATALAKE_BACKEND cannot be empty. "
                f"Supported values: 'duckdb', 'postgres', 'snowflake'. "
                f"Received: '{backend_type}'"
            )

        backend_key = backend_type.strip().lower()

        # ⛔ The check and the insert MUST be one atomic step. Unlocked, N concurrent callers
        # all miss the check and all insert — and each resulting client opens its own
        # connection pool. See the `_client_lock` comment for the measured failure.
        with _client_lock:
            # Re-check inside the lock: another thread may have created it while we waited.
            if backend_key in _client_instances:
                instance = _client_instances[backend_key]
                # Update user context if provided
                if user is not None:
                    instance._user_context = user
                return instance

            # Create new singleton instance
            instance = super(DatalakeClient, cls).__new__(cls)
            _client_instances[backend_key] = instance
            return instance

    def __init__(
        self,
        backend_type: Optional[str] = None,
        backend: Optional[DatalakeBackend] = None,
        user: Optional[Any] = None,
        calling_service: Optional[str] = None,
        _force_new: bool = False,
        _initialized: bool = False
    ):
        """
        Initialize the datalake client (only called once per singleton).

        Args:
            backend_type: Explicit backend type ('duckdb', 'snowflake', 'postgres').
            backend: Pre-configured backend instance (bypasses singleton, for testing).
            user: User context for IAM field injection.
            calling_service: Service name for metrics tracking.
            _force_new: Internal flag to force new instance.
            _initialized: Internal flag to track if __init__ was already called.
        """
        # Fast path, no lock: an already-built singleton is the overwhelmingly common case
        # and must not serialise on every construction.
        if hasattr(self, '_initialized') and self._initialized and hasattr(self, 'backend'):
            # Update user context if provided
            if user is not None:
                self._user_context = user
            return

        # ⛔ SECOND RACE, distinct from the one in __new__ and NOT fixed by it. Python calls
        # __init__ on EVERY construction, including when __new__ returned a cached instance.
        # So two threads can hold the SAME object, both see `_initialized` unset, and both
        # run the backend construction below — opening two pools on one client. Locking
        # __new__ alone leaves this open.
        with _client_lock:
            # Re-check under the lock: the thread we raced may have finished initialising.
            if getattr(self, '_initialized', False) and hasattr(self, 'backend'):
                if user is not None:
                    self._user_context = user
                return

            # Mark as initialized
            # (the flag is set at the END, once the backend really exists)

            if backend is not None:
                self.backend = backend
                backend_type = backend.__class__.__name__.replace('Backend', '').lower()
            else:
                # Determine backend type - FAIL LOUDLY if not specified
                if backend_type is None:
                    backend_type = os.getenv('DATALAKE_BACKEND')
                    if backend_type is None:
                        raise ValidationError(
                            "DATALAKE_BACKEND environment variable must be set. "
                            "Supported values: 'duckdb', 'postgres', 'snowflake'. "
                            "This ensures explicit backend configuration and prevents silent defaults."
                        )

                # Validate backend type is not empty
                if not backend_type or not backend_type.strip():
                    raise ValidationError(
                        f"DATALAKE_BACKEND cannot be empty. "
                        f"Supported values: 'duckdb', 'postgres', 'snowflake'. "
                        f"Received: '{backend_type}'"
                    )

                self.backend = _create_backend(backend_type.strip())

            # Store user context for IAM field injection
            self._user_context = user

            # Store backend type and calling service for metrics
            self._backend_type = backend_type.strip().lower()
            self._calling_service = calling_service or self._detect_calling_service()

            # Initialize metrics if enabled
            if DATALAKE_METRICS_ENABLED:
                self._metrics = get_datalake_metrics_registry().get_metrics(self._backend_type)
            else:
                self._metrics = None

            # ⭐ Set LAST, not first: a client marked initialised before its backend
            # exists would let a racing thread take the fast path above and use a
            # half-built object.
            self._initialized = True

    def _detect_calling_service(self) -> Optional[str]:
        """
        Attempt to detect the calling service name from environment or context.

        Returns:
            Service name if detected, None otherwise.
        """
        # Try to get from environment variable
        service_name = os.getenv('SERVICE_NAME') or os.getenv('PANTHEON_SERVICE')
        if service_name:
            return service_name

        # Try to infer from stack trace
        import traceback
        stack = traceback.extract_stack()
        for frame in stack:
            # Look for common service patterns in the filename
            if 'pantheon-' in frame.filename:
                parts = frame.filename.split('/')
                for part in parts:
                    if part.startswith('pantheon-'):
                        return part.replace('pantheon-', '').replace('/', '')
        return None

    def __enter__(self):
        """Enter context manager - backend connection pool is already initialized."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit context manager - for pooled backends, this is a no-op.

        For backends with connection pooling (PostgreSQL), the pool persists
        across requests and is only closed at service shutdown.

        For non-pooled backends (DuckDB), connections are managed per-client.

        Args:
            exc_type: Exception type if an exception occurred.
            exc_val: Exception value if an exception occurred.
            exc_tb: Exception traceback if an exception occurred.

        Returns:
            False to propagate exceptions.
        """
        # Don't call disconnect() - connection pools should persist
        # Pool cleanup happens at service shutdown via backend.disconnect()
        return False  # Don't suppress exceptions

    def connect(self, tenant_id: Optional[str] = None) -> bool:
        """
        Establish connection to the datalake backend.

        Args:
            tenant_id: Optional tenant ID for multi-tenant backends.

        Returns:
            True if connection successful.

        Raises:
            ConnectionError: If connection fails.
        """
        return self.backend.connect(tenant_id=tenant_id)

    def disconnect(self) -> None:
        """Disconnect from the datalake backend."""
        self.backend.disconnect()

    @classmethod
    def clear_singleton_cache(cls) -> None:
        """
        Clear all singleton instances.

        This method is primarily useful for testing to ensure clean state
        between tests. In production, singletons should persist for the
        lifetime of the service.
        """
        global _client_instances
        _client_instances = {}  # Reassign to clear

    @classmethod
    def get_singleton(cls, backend_type: Optional[str] = None) -> 'DatalakeClient':
        """
        Get the singleton instance for a given backend type.

        This is an explicit alternative to calling DatalakeClient() constructor,
        making the singleton pattern more visible in code.

        Args:
            backend_type: Backend type ('duckdb', 'postgres', 'snowflake').
                        If None, reads from DATALAKE_BACKEND env var.

        Returns:
            The singleton DatalakeClient instance.
        """
        return cls(backend_type=backend_type)

    def health_check(self) -> bool:
        """
        Check if the backend is healthy and connected.

        Returns:
            True if backend is healthy.
        """
        success = self.backend.health_check()
        if self._metrics:
            self._metrics.record_health_check(success)
        return success

    def _resolve_tenant_id(
        self,
        tenant_id: Optional[str],
        iam_context: Optional[Any] = None
    ) -> str:
        """
        Resolve tenant ID from multiple sources.

        Priority:
        1. Explicit tenant_id parameter
        2. iam_context parameter
        3. Self._user_context (from constructor)

        Args:
            tenant_id: Explicit tenant ID.
            iam_context: IAM context (IAMContext or AuthenticatedUser).

        Returns:
            Resolved tenant ID.

        Raises:
            ValidationError: If tenant ID cannot be resolved.
        """
        # Explicit tenant_id takes precedence
        if tenant_id:
            return tenant_id

        # Check iam_context parameter
        context = iam_context or self._user_context

        if context is None:
            raise ValidationError("tenant_id is required (not provided and no IAM context)")

        # Extract tenant_id from context
        if hasattr(context, 'tenant_id'):
            resolved = context.tenant_id
            if not resolved:
                raise ValidationError("tenant_id is required (IAM context has empty tenant_id)")
            return resolved
        else:
            raise ValidationError("tenant_id is required (IAM context missing tenant_id)")

    def _inject_iam_fields(
        self,
        data: List[Dict[str, Any]],
        iam_context: Optional[Any] = None,
        operation: str = 'insert',
        tenant_id: Optional[str] = None,
        namespace_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Auto-inject IAM fields into data records.

        Injected fields:
        - tenant_id: From IAM context or tenant_id parameter
        - namespace_id: From IAM context, or default namespace for tenant (fallback)
        - created_by: User ID for insert operations
        - updated_by: User ID for upsert operations

        Args:
            data: List of data records (dicts).
            iam_context: IAM context (IAMContext or AuthenticatedUser).
            operation: Operation type ('insert' or 'upsert').
            tenant_id: Tenant ID (used when IAM context is not available).

        Returns:
            Data with IAM fields injected.
        """
        from pantheon_shared.iam import get_or_create_default_namespace_id

        context = iam_context or self._user_context

        # Extract IAM field values
        resolved_tenant_id = tenant_id
        if context:
            # Prefer IAM context tenant_id if available
            context_tenant_id = getattr(context, 'tenant_id', None)
            if context_tenant_id:
                resolved_tenant_id = context_tenant_id

        # Get namespace_id: use parameter if provided, otherwise derive from context
        derived_namespace_id = namespace_id
        if not derived_namespace_id and context:
            derived_namespace_id = getattr(context, 'namespace_id', None)
            # If no namespace_id in context, get default namespace
            if not derived_namespace_id and hasattr(context, 'tenant_id') and context.tenant_id:
                derived_namespace_id = get_or_create_default_namespace_id(context, db_session=None)

        # Fallback: If we have tenant_id but no namespace_id, generate default namespace
        # by calling get_or_create_default_namespace_id with just tenant_id
        if not derived_namespace_id and resolved_tenant_id:
            derived_namespace_id = get_or_create_default_namespace_id(resolved_tenant_id, db_session=None)

        user_id = getattr(context, 'user_id', None) or getattr(context, 'id', None) if context else None

        from datetime import datetime, timezone
        now = datetime.now(timezone.utc).replace(tzinfo=None)

        enriched_data = []
        for record in data:
            enriched = record.copy()

            # Inject tenant_id if not present
            if resolved_tenant_id and 'tenant_id' not in enriched:
                enriched['tenant_id'] = resolved_tenant_id

            # Inject namespace_id if missing or None in record
            # Honor caller-provided namespace_id (via param or in data), but inject if missing/None
            if derived_namespace_id and ('namespace_id' not in enriched or enriched.get('namespace_id') is None):
                enriched['namespace_id'] = derived_namespace_id

            # Inject timestamps so watermark/CDC filters work correctly.
            # created_at is included on both insert and upsert so it appears in the
            # INSERT column list. The backend's ON CONFLICT DO UPDATE SET clause
            # excludes created_at, so existing rows keep their original value while
            # new rows (no conflict) get it set correctly on first insert.
            # updated_at is always refreshed on every write.
            if operation in ('insert', 'upsert') and 'created_at' not in enriched:
                enriched['created_at'] = now
            if operation in ('insert', 'upsert') and 'updated_at' not in enriched:
                enriched['updated_at'] = now

            # Inject user tracking fields
            if user_id:
                if operation in ('insert', 'upsert') and 'created_by' not in enriched:
                    enriched['created_by'] = user_id
                if operation in ('insert', 'upsert') and 'updated_by' not in enriched:
                    enriched['updated_by'] = user_id

            # Inject is_deleted for new records (soft-delete support)
            if operation == 'insert' and 'is_deleted' not in enriched:
                enriched['is_deleted'] = False

            enriched_data.append(enriched)

        return enriched_data

    def query(
        self,
        sql: str,
        tenant_id: Optional[str] = None,
        params: Optional[Dict[str, Any]] = None,
        iam_context: Optional[Any] = None
    ) -> QueryResult:
        """
        Execute a SQL query.

        Args:
            sql: SQL query string.
            tenant_id: Tenant ID for multi-tenancy.
            params: Query parameters for parameterized queries.
            iam_context: IAM context for tenant resolution.

        Returns:
            QueryResult with rows and metadata.

        Raises:
            ValidationError: If tenant_id cannot be resolved.
        """
        resolved_tenant_id = self._resolve_tenant_id(tenant_id, iam_context)

        # Track query execution time
        start_time = time.perf_counter()
        success = False
        try:
            result = self.backend.query(sql, resolved_tenant_id, params)
            success = True
            return result
        except Exception:
            success = False
            raise
        finally:
            if self._metrics:
                execution_time = time.perf_counter() - start_time
                self._metrics.record_query(
                    execution_time=execution_time,
                    success=success,
                    tenant_id=resolved_tenant_id,
                    sql=sql,
                    calling_service=self._calling_service
                )

    def explain_sql(
        self,
        sql: str,
        tenant_id: Optional[str] = None,
        iam_context: Optional[Any] = None,
    ) -> tuple[bool, str | None]:
        """Validate SQL by running EXPLAIN — no rows read, no side effects.

        Delegates to the backend's explain_sql if supported.  Falls back to
        a no-op (returns valid) for backends that don't implement EXPLAIN
        (e.g. DuckDB, Snowflake) so callers don't have to guard.

        Returns:
            (True, None) when the query is valid.
            (False, error_message) when the planner rejects it.
        """
        if not hasattr(self.backend, 'explain_sql'):
            return True, None
        resolved_tenant_id = self._resolve_tenant_id(tenant_id, iam_context)
        return self.backend.explain_sql(sql, resolved_tenant_id)

    def explain_sql_with_ephemeral_views(
        self,
        sql_to_check: str,
        upstream_views: list,
        tenant_id: Optional[str] = None,
        iam_context: Optional[Any] = None,
    ) -> tuple[bool, str | None]:
        """Cook-time correctness check for a DEPENDENT artifact: EXPLAIN its SQL against
        its upstream transformers built as temporary views (in dependency order), all in
        a rolled-back transaction. Validates table/column references WITHOUT materializing
        anything (deploy remains the only place data is written). See the backend method
        for the full contract. `upstream_views` = [(view_name, view_sql), …] in dep order.

        Falls back to a plain non-empty check (returns valid) for backends that don't
        implement it, so callers don't have to guard by backend type.
        """
        if not hasattr(self.backend, 'explain_sql_with_ephemeral_views'):
            return True, None
        resolved_tenant_id = self._resolve_tenant_id(tenant_id, iam_context)
        return self.backend.explain_sql_with_ephemeral_views(
            sql_to_check, upstream_views, resolved_tenant_id)

    def describe_sql_columns(
        self,
        sql_query: str,
        upstream_views: list,
        tenant_id: Optional[str] = None,
        iam_context: Optional[Any] = None,
    ):
        """Resolve a query's OUTPUT COLUMN NAMES with ZERO data materialization — build each
        upstream transformer + the query itself as temp views (metadata only), read the resolved
        columns from the catalog, roll back. Highest-fidelity (planner expands SELECT * / joins),
        zero rows read/written. Returns (column_names, None) or (None, error). See the backend
        method for the full contract. Returns (None, None) for backends without the capability."""
        if not hasattr(self.backend, 'describe_sql_columns'):
            return None, None
        resolved_tenant_id = self._resolve_tenant_id(tenant_id, iam_context)
        return self.backend.describe_sql_columns(
            sql_query, upstream_views, resolved_tenant_id)

    def query_data(
        self,
        sql: str,
        tenant_id: Optional[str] = None,
        iam_context: Optional[Any] = None
    ) -> List[Dict[str, Any]]:
        """
        Execute a SQL query and return rows as list of dicts.

        This is a compatibility method for the legacy API.
        It wraps the new query() method and converts the result to the legacy format.

        Args:
            sql: SQL query string.
            tenant_id: Tenant ID for multi-tenancy.
            iam_context: IAM context for tenant resolution.

        Returns:
            List of rows as dictionaries (column_name -> value).
        """
        result = self.query(sql, tenant_id, iam_context=iam_context)

        # Convert QueryResult (columns + rows) to legacy format (list of dicts)
        # QueryResult.rows is List[List[Any]], we need List[Dict[str, Any]]
        rows_as_dicts = []
        for row in result.rows:
            row_dict = {}
            for i, col_name in enumerate(result.columns):
                row_dict[col_name] = row[i]
            rows_as_dicts.append(row_dict)

        return rows_as_dicts

    def insert(
        self,
        table: str,
        data: List[Dict[str, Any]],
        tenant_id: Optional[str] = None,
        namespace_id: Optional[str] = None,
        iam_context: Optional[Any] = None
    ) -> UpsertResult:
        """
        Insert records into a table.

        Args:
            table: Table name.
            data: List of records to insert.
            tenant_id: Tenant ID for multi-tenancy.
            namespace_id: Namespace ID for multi-tenancy (optional, derived if not provided).
            iam_context: IAM context for tenant resolution and field injection.

        Returns:
            UpsertResult with operation statistics.

        Raises:
            ValidationError: If tenant_id cannot be resolved.
        """
        resolved_tenant_id = self._resolve_tenant_id(tenant_id, iam_context)
        enriched_data = self._inject_iam_fields(data, iam_context, operation='insert', tenant_id=resolved_tenant_id, namespace_id=namespace_id)

        # Track insert execution time
        start_time = time.perf_counter()
        success = False
        row_count = len(enriched_data)
        try:
            result = self.backend.insert(table, enriched_data, resolved_tenant_id)
            success = True
            return result
        except Exception:
            success = False
            raise
        finally:
            if self._metrics:
                execution_time = time.perf_counter() - start_time
                self._metrics.record_insert(
                    execution_time=execution_time,
                    success=success,
                    row_count=row_count if success else 0
                )

    def upsert(
        self,
        table: str,
        data: List[Dict[str, Any]],
        primary_key: str,
        tenant_id: Optional[str] = None,
        namespace_id: Optional[str] = None,
        iam_context: Optional[Any] = None,
        preserve: Optional[List[str]] = None,
        scope: Optional[str] = None,
    ) -> UpsertResult:
        """
        Upsert records (insert or update) into a table.

        Args:
            table: Table name.
            data: List of records to upsert.
            primary_key: Primary key column name.
            tenant_id: Tenant ID for multi-tenancy.
            namespace_id: Namespace ID for multi-tenancy (optional, derived if not provided).
            iam_context: IAM context for tenant resolution and field injection.
            preserve: Columns whose existing stored value must survive an UPDATE
                (conflict) instead of being overwritten by the incoming record.
                New rows still take the incoming value. Forwarded to the backend.

        Returns:
            UpsertResult with operation statistics.

        Raises:
            ValidationError: If tenant_id cannot be resolved.
        """
        # Global reference tables (scope="global") live in the shared `public`
        # schema and are tenant-independent — skip tenant resolution and IAM-field
        # injection entirely, writing a single shared copy. (PostgreSQL backend only.)
        if scope == "global":
            return self.backend.upsert(
                table, data, primary_key, tenant_id=None,
                preserve_columns=preserve, scope="global",
            )

        resolved_tenant_id = self._resolve_tenant_id(tenant_id, iam_context)
        enriched_data = self._inject_iam_fields(data, iam_context, operation='upsert', tenant_id=resolved_tenant_id, namespace_id=namespace_id)

        # Track upsert execution time
        start_time = time.perf_counter()
        success = False
        row_count = len(enriched_data)
        try:
            result = self.backend.upsert(table, enriched_data, primary_key, resolved_tenant_id, preserve_columns=preserve)
            success = True
            return result
        except Exception:
            success = False
            raise
        finally:
            if self._metrics:
                execution_time = time.perf_counter() - start_time
                self._metrics.record_upsert(
                    execution_time=execution_time,
                    success=success,
                    row_count=row_count if success else 0
                )

    def upsert_data(
        self,
        table: str,
        data: List[Dict[str, Any]],
        primary_key: str,
        tenant_id: Optional[str] = None,
        namespace_id: Optional[str] = None,
        iam_context: Optional[Any] = None
    ) -> UpsertResult:
        """
        Upsert records (insert or update) into a table.

        This is a backwards-compatibility alias for upsert().

        Args:
            table: Table name.
            data: List of records to upsert.
            primary_key: Primary key column name.
            tenant_id: Tenant ID for multi-tenancy.
            namespace_id: Namespace ID for multi-tenancy (optional, derived if not provided).
            iam_context: IAM context for tenant resolution and field injection.

        Returns:
            UpsertResult with operation statistics.

        Raises:
            ValidationError: If tenant_id cannot be resolved.
        """
        return self.upsert(table, data, primary_key, tenant_id, namespace_id, iam_context)

    def create_table(
        self,
        table: str,
        schema: Dict[str, str],
        tenant_id: Optional[str] = None,
        iam_context: Optional[Any] = None,
        scope: Optional[str] = None,
    ) -> bool:
        """
        Create a new table.

        Args:
            table: Table name.
            schema: Column schema mapping (column_name -> column_type).
            tenant_id: Tenant ID for multi-tenancy.
            iam_context: IAM context for tenant resolution.

        Returns:
            True if table created successfully.

        Raises:
            ValidationError: If tenant_id cannot be resolved.
        """
        # Global reference table in the shared `public` schema — no tenant resolution.
        if scope == "global":
            result = self.backend.create_table(table, schema, tenant_id=None, scope="global")
            if self._metrics and result:
                self._metrics.record_table_created()
            return result

        resolved_tenant_id = self._resolve_tenant_id(tenant_id, iam_context)
        result = self.backend.create_table(table, schema, resolved_tenant_id)
        if self._metrics and result:
            self._metrics.record_table_created()
        return result

    def drop_table(
        self,
        table: str,
        tenant_id: Optional[str] = None,
        db_type: Optional[str] = None,
        iam_context: Optional[Any] = None
    ) -> bool:
        """
        Drop a table.

        Args:
            table: Table name.
            tenant_id: Tenant ID for multi-tenancy.
            db_type: Optional database type ('source', 'transformers').
            iam_context: IAM context for tenant resolution.

        Returns:
            True if table dropped successfully.

        Raises:
            ValidationError: If tenant_id cannot be resolved.
        """
        resolved_tenant_id = self._resolve_tenant_id(tenant_id, iam_context)
        # Pass db_type if backend supports it (e.g., DuckDB backend)
        try:
            sig = inspect.signature(self.backend.drop_table)
            if 'db_type' in sig.parameters:
                result = self.backend.drop_table(table, resolved_tenant_id, db_type=db_type)
            else:
                result = self.backend.drop_table(table, resolved_tenant_id)
        except (ValueError, TypeError):
            result = self.backend.drop_table(table, resolved_tenant_id)

        if self._metrics and result:
            self._metrics.record_table_dropped()
        return result

    def table_exists(
        self,
        table: str,
        tenant_id: Optional[str] = None,
        db_type: Optional[str] = None,
        iam_context: Optional[Any] = None
    ) -> bool:
        """
        Check if a table exists.

        Args:
            table: Table name.
            tenant_id: Tenant ID for multi-tenancy.
            db_type: Optional database type ('source', 'transformers').
            iam_context: IAM context for tenant resolution.

        Returns:
            True if table exists.

        Raises:
            ValidationError: If tenant_id cannot be resolved.
        """
        resolved_tenant_id = self._resolve_tenant_id(tenant_id, iam_context)
        # Pass db_type if backend supports it (e.g., DuckDB backend)
        try:
            sig = inspect.signature(self.backend.table_exists)
            if 'db_type' in sig.parameters:
                result = self.backend.table_exists(table, resolved_tenant_id, db_type=db_type)
            else:
                result = self.backend.table_exists(table, resolved_tenant_id)
        except (ValueError, TypeError):
            result = self.backend.table_exists(table, resolved_tenant_id)

        if self._metrics:
            self._metrics.record_table_exists_check()
        return result

    def list_tables(
        self,
        tenant_id: Optional[str] = None,
        db_type: Optional[str] = None,
        iam_context: Optional[Any] = None
    ) -> List[TableInfo]:
        """
        List all tables for a tenant.

        Args:
            tenant_id: Tenant ID for multi-tenancy.
            db_type: Optional database type filter ('source', 'transformers', or 'all').
                    - 'source': Returns only source tables
                    - 'transformers': Returns only transformer output tables
                    - 'all': Returns both source and transformer tables
                    - None: Defaults to 'source' for backward compatibility
            iam_context: IAM context for tenant resolution.

        Returns:
            List of TableInfo objects.

        Raises:
            ValidationError: If tenant_id cannot be resolved.
        """
        resolved_tenant_id = self._resolve_tenant_id(tenant_id, iam_context)
        if self._metrics:
            self._metrics.record_list_tables()
        return self.backend.list_tables(resolved_tenant_id, db_type)

    def get_table_info(
        self,
        table: str,
        tenant_id: Optional[str] = None,
        iam_context: Optional[Any] = None
    ) -> TableInfo:
        """
        Get detailed information about a table.

        Args:
            table: Table name.
            tenant_id: Tenant ID for multi-tenancy.
            iam_context: IAM context for tenant resolution.

        Returns:
            TableInfo with table metadata.

        Raises:
            ValidationError: If tenant_id cannot be resolved.
        """
        resolved_tenant_id = self._resolve_tenant_id(tenant_id, iam_context)
        return self.backend.get_table_info(table, resolved_tenant_id)

    def text_to_sql(
        self,
        query: str,
        tenant_id: Optional[str] = None,
        execute: bool = False,
        iam_context: Optional[Any] = None
    ) -> Dict[str, Any]:
        """
        Convert natural language query to SQL.

        Args:
            query: Natural language query.
            tenant_id: Tenant ID for multi-tenancy.
            execute: If True, execute the query and return results.
            iam_context: IAM context for tenant resolution.

        Returns:
            Dict with 'sql' key and optional 'results' key if execute=True.

        Raises:
            ValidationError: If tenant_id cannot be resolved.
        """
        resolved_tenant_id = self._resolve_tenant_id(tenant_id, iam_context)

        # Track text-to-SQL execution time
        start_time = time.perf_counter()
        success = False
        try:
            result = self.backend.text_to_sql(query, resolved_tenant_id, execute)
            success = True
            return result
        except Exception:
            success = False
            raise
        finally:
            if self._metrics:
                execution_time = time.perf_counter() - start_time
                self._metrics.record_text_to_sql(
                    execution_time=execution_time,
                    success=success,
                    executed=execute and success
                )

    def get_row_count(
        self,
        table: str,
        tenant_id: Optional[str] = None,
        iam_context: Optional[Any] = None
    ) -> int:
        """
        Get the number of rows in a table.

        Args:
            table: Table name.
            tenant_id: Tenant ID for multi-tenancy.
            iam_context: IAM context for tenant resolution.

        Returns:
            Number of rows in the table.

        Raises:
            ValidationError: If tenant_id cannot be resolved.
        """
        resolved_tenant_id = self._resolve_tenant_id(tenant_id, iam_context)
        return self.backend.get_row_count(table, resolved_tenant_id)

    def update_rows(
        self,
        table: str,
        set_clause: str,
        where: str,
        params: Optional[Dict[str, Any]] = None,
        tenant_id: Optional[str] = None,
        iam_context: Optional[Any] = None,
    ) -> int:
        """
        Apply a SET to rows matching a WHERE clause; returns the number updated.

        The UPDATE sibling of delete_rows. Use it when a row must be AMENDED
        rather than removed — e.g. stripping one contributor from a shared row's
        provenance map, where deleting would destroy another writer's data.
        Commits; query() never commits and cannot run an UPDATE.

        Args:
            table: Table name.
            set_clause: SQL SET body WITHOUT the leading "SET".
            where: SQL WHERE clause WITHOUT the leading "WHERE".
            params: Optional bind parameters.
            tenant_id: Tenant ID for multi-tenancy.
            iam_context: IAM context for tenant resolution.

        Returns:
            Number of rows updated.

        Raises:
            ValidationError: If tenant_id cannot be resolved.
        """
        resolved_tenant_id = self._resolve_tenant_id(tenant_id, iam_context)
        return self.backend.update_rows(
            table, resolved_tenant_id, set_clause, where, params
        )

    def delete_rows(
        self,
        table: str,
        where: str,
        params: Optional[Dict[str, Any]] = None,
        tenant_id: Optional[str] = None,
        iam_context: Optional[Any] = None,
    ) -> int:
        """
        Delete rows matching a WHERE clause; returns the number deleted.

        This is a WRITE operation that commits the transaction. Use this for
        filtered deletes — query() never commits and cannot run a DELETE.

        Args:
            table: Table name.
            where: SQL WHERE clause WITHOUT the leading "WHERE".
            params: Optional bind parameters for the WHERE clause.
            tenant_id: Tenant ID for multi-tenancy.
            iam_context: IAM context for tenant resolution.

        Returns:
            Number of rows deleted.

        Raises:
            ValidationError: If tenant_id cannot be resolved.
        """
        resolved_tenant_id = self._resolve_tenant_id(tenant_id, iam_context)
        return self.backend.delete_rows(table, resolved_tenant_id, where, params)

    def cleanup_tenant(
        self,
        tenant_id: str,
        iam_context: Optional[Any] = None
    ) -> Dict[str, Any]:
        """
        Clean up all tenant data (tables, schemas, files).

        Args:
            tenant_id: Tenant UUID to clean up.
            iam_context: IAM context for tenant resolution.

        Returns:
            Dict with cleanup results.
        """
        resolved_tenant_id = self._resolve_tenant_id(tenant_id, iam_context)
        return self.backend.cleanup_tenant(resolved_tenant_id)

    def cleanup_orphaned(
        self,
        valid_tenant_ids: List[str],
        iam_context: Optional[Any] = None,
        tenant_id: Optional[str] = None,
        dry_run: bool = False,
    ) -> Dict[str, Any]:
        """
        Clean up orphaned data for deleted tenants.

        Args:
            valid_tenant_ids: List of valid tenant UUIDs from pantheon-auth.
            iam_context: IAM context for tenant resolution.
            tenant_id: Optional tenant id — NARROWS results to orphans belonging
                to this tenant.
            dry_run: When True, report orphans without deleting.

        Returns:
            Dict with cleanup results.
        """
        return self.backend.cleanup_orphaned(
            valid_tenant_ids,
            tenant_id=tenant_id,
            dry_run=dry_run,
        )

    def __repr__(self) -> str:
        """String representation."""
        backend_name = self.backend.__class__.__name__
        return f"DatalakeClient(backend={backend_name})"
