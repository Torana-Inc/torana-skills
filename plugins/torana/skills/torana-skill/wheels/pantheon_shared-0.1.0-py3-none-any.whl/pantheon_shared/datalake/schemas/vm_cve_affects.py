from typing import Dict, Any
from .base import TableSchema
from .system_fields import LIFECYCLE_FIELDS, AUDIT_FIELDS


class VmCveAffectsSchema(TableSchema):
    """Schema for the ``vm_cve_affects`` GLOBAL CVE-affiliation table (#356, ingest half).

    **What this table is.** One row per (CVE, CPE, version-range) that NVD publishes in a
    CVE's ``configurations[].nodes[].cpeMatch[]``. It answers exactly one question:
    *"what does NVD SAY this CVE affects?"* — verbatim, as published.

    ⛔ **WHAT THIS TABLE IS NOT, and this boundary is the point of the design.** It does
    NOT say *"therefore your package X is vulnerable."* That is CPE→purl matching, and it
    is **explicitly deferred** (decision 2026-09-07) pending a design spec with a stated
    precision bar. NVD names software as CPE
    (``cpe:2.3:a:apache:log4j:2.14.1:…``); this platform identifies packages as purl
    (``pkg:maven/org.apache.logging.log4j/log4j-core@2.14.1``). Same software, no reliable
    mechanical join — vendor ``apache`` ↔ namespace ``org.apache.logging.log4j``, product
    ``log4j`` ↔ name ``log4j-core``. Matching too loosely claims exposure that does not
    exist; too tightly reports false safety. **Do not add a join column, a resolved purl,
    or a match score to this table** — storing the claim and asserting the match are
    different products, and this one is only the first.

    **Why a child table rather than a column on ``vm_cve_metadata``.** One CVE affects many
    CPEs: 224,240 ``cpeMatch`` entries across the 29,869 classified CVEs of 2024 alone
    (~7.5 per CVE, and the widest carry hundreds). A column could hold only a truncation.

    ⚠️ **COVERAGE IS 76%, NOT 98.9%, AND ANY METRIC BUILT ON THIS MUST SAY SO.** Measured
    on the cached ``nvdcve-2.0-2024.json.gz`` 2026-09-07: 29,869 of 39,236 CVEs carry
    ``configurations`` — 76% of all, 77% of non-rejected. **Roughly one CVE in four has no
    CPE affiliation at all.** That beats today's zero, but a panel that renders the 76% as
    if it were the whole estate is another confidently-wrong number.

    PK ``torana_cve_affect_id`` = ``sha256(cve_id : criteria : the four version bounds :
    vulnerable)`` — deterministic, so a re-parse of the same feed collapses to the same
    rows rather than duplicating them. ⚠️ **A natural composite key would LOSE rows:**
    measured 841 cases in 2024 where one CVE lists the identical CPE+range twice across
    different nodes. A content hash makes that a no-op upsert instead of a collision.
    """

    @property
    def table_name(self) -> str:
        return "vm_cve_affects"

    @property
    def scope(self) -> str:
        """GLOBAL — one copy in the shared ``public`` schema, like its parent.

        NVD's affiliation claim is identical for every tenant, so it is stored once
        alongside ``vm_cve_metadata``. Declaring ``global`` also puts the table into the
        ``torana_global`` dbt source group, so ``{{ source('torana_global',
        'vm_cve_affects') }}`` resolves for transformers and catalog entries.
        """
        return "global"

    @property
    def primary_key(self) -> str:
        return "torana_cve_affect_id"

    @property
    def description(self) -> str:
        return (
            "What NVD says each CVE affects, as published: one row per CPE and version "
            "range from the advisory's configurations. Tenant-independent (shared public "
            "schema). States the vendor's claim only — it does NOT assert that any "
            "package you run is affected; CPE-to-purl matching is deliberately not done."
        )

    @property
    def category(self) -> str:
        return "Threat Intelligence"

    @property
    def timestamp_column(self) -> str:
        return "updated_at"

    @property
    def schema(self) -> Dict[str, Any]:
        return {
            "torana_cve_affect_id": {
                "data_type": "VARCHAR(64)", "primary_key": True, "category": "Identity",
                "semantic_description": (
                    "Torana's stable id for one affiliation claim. Derived from the claim's "
                    "own content, so re-reading the same advisory never duplicates a row."
                ),
            },
            "cve_id": {
                "data_type": "VARCHAR(50)", "not_null": True, "index": True,
                "category": "Identity",
                "semantic_description": (
                    "The CVE making the claim. Joins to vm_cve_metadata.cve_id."
                ),
            },
            # ── The claim, verbatim ──────────────────────────────────────────────
            # ⚠️ 149 chars is the longest criteria measured in the 2024 feed; 512 leaves
            # headroom for the longer vendor/product strings other years carry.
            "cpe_criteria": {
                "data_type": "VARCHAR(512)", "not_null": True, "index": True,
                "category": "Affiliation",
                "semantic_description": (
                    "The affected software as NVD names it, in full CPE 2.3 form. This is "
                    "NVD's vocabulary, not Torana's — it does not join to package names."
                ),
            },
            # The parsed components. Stored ALONGSIDE the verbatim criteria, never
            # instead of it: the string above stays authoritative, and these exist so a
            # reader can group by vendor without every query re-implementing the split.
            #
            # ⛔ THE SPLIT IS ESCAPE-AWARE, and it must stay that way. 33 criteria in the
            # 2024 feed embed an ESCAPED colon in the product name — Ruby/Perl `::`
            # packages such as `omniauth\:\:microsoftgraph` and `spreadsheet\:\:parsexlsx`.
            # A naive split(":") shifts every later field by one and silently writes the
            # wrong vendor and product. See threat_intel._split_cpe.
            "cpe_part": {
                "data_type": "VARCHAR(8)", "category": "Affiliation",
                "semantic_description": (
                    "Which kind of thing is affected: 'a' application, 'o' operating "
                    "system, 'h' hardware."
                ),
            },
            "cpe_vendor": {
                "data_type": "VARCHAR(128)", "index": True, "category": "Affiliation",
                "semantic_description": (
                    "Vendor as NVD names it (e.g. 'apache'). NVD's own vocabulary — it is "
                    "not a package namespace and does not join to one."
                ),
            },
            "cpe_product": {
                "data_type": "VARCHAR(128)", "index": True, "category": "Affiliation",
                "semantic_description": (
                    "Product as NVD names it (e.g. 'log4j'). Frequently differs from the "
                    "package name for the same software ('log4j-core')."
                ),
            },
            "cpe_version": {
                "data_type": "VARCHAR(128)", "category": "Affiliation",
                "semantic_description": (
                    "The version field of the CPE itself. '*' means the range columns "
                    "carry the real constraint."
                ),
            },
            # ── Version bounds: PREDICATES, not values ───────────────────────────
            # ⛔ Kept as four separate bounds ON PURPOSE. Flattening a range into one
            # version string loses the inclusive/exclusive distinction, and that
            # distinction is precisely what the deferred matching work will need to
            # decide whether an installed version falls inside the range. Storing
            # "2.15.0" cannot say whether 2.15.0 itself is affected.
            "version_start_including": {
                "data_type": "VARCHAR(64)", "category": "Affiliation",
                "semantic_description": "Lower bound, inclusive: versions >= this are affected.",
            },
            "version_start_excluding": {
                "data_type": "VARCHAR(64)", "category": "Affiliation",
                "semantic_description": "Lower bound, exclusive: versions > this are affected.",
            },
            "version_end_including": {
                "data_type": "VARCHAR(64)", "category": "Affiliation",
                "semantic_description": "Upper bound, inclusive: versions <= this are affected.",
            },
            "version_end_excluding": {
                "data_type": "VARCHAR(64)", "category": "Affiliation",
                "semantic_description": (
                    "Upper bound, exclusive: versions < this are affected. Typically the "
                    "version the fix shipped in."
                ),
            },
            # ⛔ NOT A FORMALITY — 52,492 of 224,240 cpeMatch entries in 2024 (23%) carry
            # vulnerable=false. Those describe a platform the CVE is scoped BY, not
            # software it affects (the running-on half of an AND node). Reading this
            # table without filtering `is_vulnerable` would treat nearly a quarter of
            # these rows as exposure claims NVD never made.
            "is_vulnerable": {
                "data_type": "BOOLEAN", "index": True, "category": "Affiliation",
                "semantic_description": (
                    "Whether NVD marks this CPE as actually vulnerable. False means the "
                    "entry only scopes the claim (a platform it runs on) — filter on this "
                    "before treating a row as an affected-software statement."
                ),
            },
            "match_criteria_id": {
                "data_type": "VARCHAR(64)", "category": "Provenance",
                "semantic_description": (
                    "NVD's own id for this match rule, carried so a row can be traced back "
                    "to the advisory it came from."
                ),
            },
            "source_version": {
                "data_type": "VARCHAR(64)", "category": "Provenance",
                "semantic_description": "Which feed run produced this row.",
            },
        }

    def get_full_schema(self) -> Dict[str, Any]:
        """Override: a GLOBAL table injects Lifecycle + Audit, but NOT IAM fields.

        Identical reasoning to ``VmCveMetadataSchema`` — the feed write path is
        tenant-less, so the NOT NULL tenant_id/namespace_id the base injects would
        reject every write.
        """
        return {**LIFECYCLE_FIELDS, **AUDIT_FIELDS, **self.schema}
