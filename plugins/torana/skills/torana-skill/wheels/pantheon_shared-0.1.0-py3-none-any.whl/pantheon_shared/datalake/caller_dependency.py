"""The SECOND axis — a column is reachable, but does it FILL BY ITSELF?

⭐ S18 (tracker row 50). `shadow_baseline.measure_shadow_set()` answers *"can
anything write this column?"*. This module answers the question that comes
immediately after and has no other home:

    answerable-and-self-filling   vs   answerable-but-depends-on-a-caller

Seven of the eight writer mechanisms fill themselves — a `mapping` fills when an
integration syncs, an `operator` when ETL runs, a `system` field on any insert.
Only `kind=declared` waits for an external actor to call an endpoint. So a
`declared`-only column is **reachable and may still be empty forever**.

## ⛔ Why this is a SECOND axis and never a correction to reachability

⚠️ Folding this into `reachable` would destroy the property that makes the write
seam work: *registering a writer makes a question answerable with no edit
anywhere else*. If a caller-dependency could flip `reachable` to false, then
registering a writer could make a passing query newly FAIL. The gate script
(`torana-text-to-sql/scripts/reachability_gate.py`) states this as its C3 rule
and this module obeys the same one — `caller_only` is **advisory**, never a
verdict input.

⛔ It is therefore NOT a second copy of B11. B11's shadow set and this module's
`caller_only` set are **disjoint by construction**: a shadow column has NO
writers, a caller-only column has writers that are ALL `declared`. A column
cannot be in both.

## ⚠️ The failure this exists to catch, measured

`PATCH /ingest/vulnerabilities` was extended with six human-triage columns.
Reachable columns went 389 → 395 and corpus questions Q-047/Q-092 flipped from
refused to CLEAN — with `count(is_confirmed)` = **0 of 6,179 rows** and no
caller in existence. The query parses, EXPLAINs, deploys, and returns nothing
forever. A dashboard renders an empty panel and a reader concludes *"there are
no lingering mitigations"* when the truth is *"nobody has recorded one."*
⛔ **Those are opposite conclusions.**

## ⭐ Why an app BUNDLE is the sharpest case

A bundle is authored once and installed into MANY tenants. An artifact built on
a caller-only column is not wrong in one workspace — it is wrong in every
workspace that never runs the caller, which is the default state. And unlike a
shadow column, nothing about the schema reveals it: the column is genuinely
writable.

## ⚠️ Three failure SHAPES, and only the first looks like "empty"

Mirrors the B11 note in `app_bundles/validator.py`, because a caller-only column
fails the same three ways a shadow column does:

  1. EMPTY    — `WHERE is_confirmed` never matches → "nothing confirmed".
  2. INFLATED — `WHERE col IS NULL` matches EVERY row → the whole estate lights up.
  3. INVERTED — an ANTI-join (`LEFT JOIN … WHERE torana_issue_id IS NULL`) on an
                unwritten correlation key reports 100% of findings "untracked".

⛔ A check that only asked *"does this render empty?"* would catch only the first.

## PLATFORM SCOPE, structurally — not by a flag

⭐ `build_reachability_map()` is inherently platform-scoped: `reachable_for(None)`
counts any shipped integration. This module never accepts a tenant scope and has
no flag that could select one, so a caller-only verdict CANNOT be accidentally
computed against one customer's connected integrations. That is the § 1.3a
guarantee made structural rather than argued: authoring is a platform question,
and the only way to get a tenant answer here is to not use this module at all.
"""

from __future__ import annotations

from typing import Dict, List, NamedTuple, Optional, Tuple

#: Writer kinds that fill THEMSELVES — no actor required.
#:
#: ⚠️ A POSITIVE membership set, deliberately, mirroring
#: `SELF_FILLING_WRITER_KINDS` in the gate script and `LOAD_BEARING_ANCESTORS`
#: beside it. "Everything except `declared`" would silently classify a NEW ninth
#: mechanism as self-filling on the day it appears — the optimistic direction,
#: and therefore the wrong one to guess in.
SELF_FILLING_WRITER_KINDS: frozenset = frozenset({
    "mapping", "operator", "ingestor", "extractor", "system", "decoration",
})

#: Caller statuses, from `write_seam.ExpectedCaller`. A closed vocabulary so a
#: machine can answer "which declared columns have no caller?".
#:
#: ⚠️ `None` (undeclared — "nobody said") is a THIRD state and is never a synonym
#: for `"none"` ("somebody said there is no caller"). Collapsing them would
#: report an unaudited column as a confirmed dead end.
CALLER_STATUS_WIRED = "wired"
CALLER_STATUS_MANUAL = "manual"
CALLER_STATUS_NONE = "none"


class CallerDependency(NamedTuple):
    """One column that fills ONLY when an external actor runs."""

    table: str
    column: str
    #: Worst caller status across the column's declared writers, or None when no
    #: writer declared one at all (UNDECLARED — distinct from `"none"`).
    status: Optional[str]
    #: True when a caller is named AND exists. False is the dead-on-arrival case.
    has_caller: bool
    #: Caller names, for the message a reader must act on.
    caller_names: Tuple[str, ...]
    #: Bridge-registry ids carrying the CALLABLE contract (method, path, payload).
    bridge_ids: Tuple[str, ...]

    @property
    def dead_on_arrival(self) -> bool:
        """⛔ No caller exists and none is even claimed to.

        ⚠️ UNDECLARED (`status is None`) counts here. `expected_caller` has been
        REQUIRED since 2026-08-06 (`register_writer` raises `MissingCallerError`
        without one), so an undeclared writer predates the rule and has never
        been audited — treating "nobody said" as safe is precisely how the six
        triage columns shipped.
        """
        return self.status in (CALLER_STATUS_NONE, None) or not self.has_caller


#: Rank worst-first. `manual` outranks `wired` because a human path is not run by
#: any schedule — the column is empty until somebody chooses to act.
_STATUS_RANK = {None: 0, CALLER_STATUS_NONE: 1, CALLER_STATUS_MANUAL: 2, CALLER_STATUS_WIRED: 3}


def _worst(statuses: List[Optional[str]]) -> Optional[str]:
    """The weakest guarantee among a column's callers.

    ⚠️ Worst-wins, not best-wins: a column with one wired and one manual caller
    is only as reliable as the path that actually runs for a given row, and the
    honest answer to "will this be filled?" is the weaker one.
    """
    if not statuses:
        return None
    return min(statuses, key=lambda s: _STATUS_RANK.get(s, 0))


def measure_caller_dependencies(
    *, require_seam: bool = True,
) -> Dict[Tuple[str, str], CallerDependency]:
    """`{(table, column): CallerDependency}` for every CALLER-ONLY column.

    A column is caller-only when it HAS writers and **all** of them are
    `kind=declared`.

    ⛔ The two halves are NOT symmetrical, and this is the rule the gate script
    calls § 3.3:

        self_filling = ANY writer kind fills itself
        caller_only  = ALL writers are `declared`      ← the strict case

    ⚠️ A column may carry BOTH a mapping and a declared writer (`cve_id` has 7
    writers). The seam deliberately allows it — that IS the triage design. Such a
    column is self-filling and must NOT be reported here: a sync also fills it,
    and telling an author "this only fills when <caller> runs" would send them to
    configure something that was never broken.

    ⛔ FAILS CLOSED exactly as `measure_shadow_set` does. `kind=declared` writers
    enter the map only by IMPORTING the modules that register them, and nothing
    scans. In a process that cannot import them the registry is EMPTY — and the
    caller-only set would come back **empty too**, which reads as "no
    dependencies" rather than "could not tell". That is the worse direction here
    than for shadow: an empty answer is indistinguishable from a clean bill.
    """
    from pantheon_shared.datalake.reachability import (
        SEAM_ORIGIN_ATTR,
        build_reachability_map,
    )
    from pantheon_shared.datalake.seam_source import SeamUnavailable
    from pantheon_shared.datalake.shadow_baseline import (
        SeamRegistryEmpty,
        declared_schema,
        load_write_seam_modules,
    )
    from pantheon_shared.datalake.write_seam import WRITERS

    load_write_seam_modules()

    declared = declared_schema()

    # ⭐ S22 (row 35) — mirrors `measure_shadow_set` exactly. Mechanism 8 arrives by
    # IMPORT where the modules are importable and by FETCH where they are not, so B13
    # runs in `pantheon-program-framework` for the first time.
    #
    # ⛔ The refusal survives, and it matters MORE here than for shadow: an empty
    # caller-only set is indistinguishable from a clean bill ("no caller dependencies"
    # vs "could not tell"), so a silent empty answer is the worse direction.
    try:
        rmap = build_reachability_map(tables=sorted(declared), declared=declared,
                                      require_seam=require_seam)
    except SeamUnavailable as exc:
        if not require_seam:
            raise
        raise SeamRegistryEmpty(
            f"the write-seam registry is EMPTY and could not be fetched: {exc}. "
            "Mechanism 8 (`kind=declared`) contributed no writers — and the "
            "caller-only set would come back EMPTY, which reads as 'no caller "
            "dependencies' when the truth is 'could not tell'. Run where "
            "`torana_mesh` is importable (i.e. inside pantheon-integration-dev), "
            "make the reachability API reachable, or pass require_seam=False if you "
            "genuinely want the mechanism-8-blind number."
        ) from exc

    snapshot = getattr(rmap, SEAM_ORIGIN_ATTR, None)
    seam_registrations = snapshot.registration_count if snapshot else len(WRITERS)

    if require_seam and not seam_registrations:
        raise SeamRegistryEmpty(
            "the write-seam registry is EMPTY, so mechanism 8 (`kind=declared`) "
            "contributed no writers — and the caller-only set would come back "
            "EMPTY, which reads as 'no caller dependencies' when the truth is "
            "'could not tell'. Run where `torana_mesh` is importable (i.e. "
            "inside pantheon-integration-dev), or pass require_seam=False if you "
            "genuinely want the mechanism-8-blind number."
        )

    out: Dict[Tuple[str, str], CallerDependency] = {}
    for (table, column), entry in rmap.columns.items():
        writers = list(entry.writers)
        if not writers:
            continue                      # shadow — B11's territory, not ours
        # ⚠️ THESE TWO GUARDS OVERLAP ON TODAY'S DATA, DELIBERATELY. With the eight
        # mechanisms that exist now, the second subsumes the first: a column with any
        # self-filling writer also fails `all(kind == "declared")`. Verified by mutation —
        # flipping the first guard's `any` to `all` does not move the set (29 either way).
        #
        # ⛔ Do NOT delete the first guard as dead code. They answer different questions,
        # and they diverge exactly when a NINTH writer kind appears:
        #   guard 1 asks "does something fill this by itself?"  → the semantic rule
        #   guard 2 asks "is every writer `declared`?"          → the conservative rule
        # A new kind that is self-filling but not yet in SELF_FILLING_WRITER_KINDS is
        # caught by guard 2 (not all declared → skip), which is the SAFE direction: report
        # nothing rather than call a self-filling column caller-only. Keeping both makes
        # that intent explicit instead of leaving it to a coincidence of the current set.
        if any(w.kind in SELF_FILLING_WRITER_KINDS for w in writers):
            continue                      # a sync fills it; not caller-only
        if not all(w.kind == "declared" for w in writers):
            continue                      # unknown ninth mechanism — do not guess

        statuses: List[Optional[str]] = []
        names: List[str] = []
        bridges: List[str] = []
        exists_flags: List[bool] = []
        for w in writers:
            ec = w.expected_caller if isinstance(w.expected_caller, dict) else None
            if ec:
                statuses.append(ec.get("status"))
                if ec.get("name"):
                    names.append(str(ec["name"]))
                exists_flags.append(bool(ec.get("exists")))
            else:
                statuses.append(None)     # UNDECLARED, never folded into "none"
                exists_flags.append(False)
            if w.bridge_id:
                bridges.append(str(w.bridge_id))

        status = _worst(statuses)
        out[(table.lower(), column.lower())] = CallerDependency(
            table=table.lower(),
            column=column.lower(),
            status=status,
            has_caller=bool(names) and any(exists_flags) and status != CALLER_STATUS_NONE,
            caller_names=tuple(sorted(set(names))),
            bridge_ids=tuple(sorted(set(bridges))),
        )
    return out
