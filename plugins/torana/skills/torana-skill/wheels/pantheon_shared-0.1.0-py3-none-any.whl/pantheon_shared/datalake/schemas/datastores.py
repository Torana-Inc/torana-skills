from typing import Dict, Any
from .base import TableSchema


class DatastoresSchema(TableSchema):
    """Schema definition for the datastores table."""

    @property
    def table_name(self) -> str:
        return "datastores"

    @property
    def primary_key(self) -> str:
        return "torana_datastore_id"

    @property
    def description(self) -> str:
        return "Databases and data storage systems with configuration, access controls, and security posture information"

    @property
    def category(self) -> str:
        return "Asset Data"

    @property
    def timestamp_column(self) -> str:
        """Return the timestamp column for this table."""
        return "updated_at"

    @property
    def schema(self) -> Dict[str, Any]:
        return {
            # ⛔ THE POINTER COLUMN THE ENTITY GRAPH KEYS FROM (#176). Every other
            # inventory table (`assets`, `artifacts`, `repositories`, `packages`) carries a
            # `torana_*` id and the graph resolves its rows through it; `datastores` was the
            # only one without, so no datastore could EVER be keyed into the graph and
            # `entity-graph health` reported 0/N as a permanent floor. That is a SCHEMA gap,
            # not a missing derivation — no mapping change could have moved it.
            #
            # ⚠️ `primary_key` (the property above) ALREADY returned "torana_datastore_id"
            # while this dict defined only `datastore_id`, so the declared PK named a column
            # that did not exist anywhere — in the schema or in the live table. Adding the
            # column is what makes the property true, rather than changing the property to
            # match a legacy column and re-pointing every reader.
            "torana_datastore_id": {"data_type": "VARCHAR(255)", "primary_key": True, "category": "Core Identity",
                "semantic_description": (
                    "Torana's stable id for one data store, source-neutral "
                    "(`datastore:<provider>/<engine>/<id>`). It is the endpoint a service's "
                    "`accesses` edge points at, so a store discovered by a cloud pass and one "
                    "named by a workload's configuration converge on the same row. A store is "
                    "the TO-end of that edge and never derives it itself."
                ),
            },
            "datastore_id": {
                "data_type": "VARCHAR(255)", "category": "Core Identity",
                "semantic_description": (
                "The store's identifier within its own source, kept as the provider produced it (for "
                "self-hosted stores a composed `datastore_key(...)` of provider/engine/name). ⚠️ Legacy "
                "key of this table and NOT the graph endpoint — `torana_datastore_id` is what the "
                "entity graph resolves, and joining on this one instead silently misses cross-source "
                "convergence."
                ),
            },
            "external_id": {
                "data_type": "VARCHAR(255)", "category": "Core Identity",
                "semantic_description": (
                "The data store's native identifier in the system that reported it, kept verbatim for "
                "traceability. Its shape is provider-specific (an ARN, a resource path, a channel id), "
                "so it is never comparable across sources."
                ),
            },
            "source_system": {
                "data_type": "VARCHAR(100)", "category": "Core Identity",
                "semantic_description": (
                    "The integration or internal producer that reported this data store row. ⚠️ Determines "
                    "which other columns are populated at all, since sources differ in what they expose, "
                    "and it is the first thing to check when two rows describe the same data store "
                    "differently."
                ),
            },
            "provider": {
                "data_type": "VARCHAR(50)", "category": "Core Identity",
                "semantic_description": (
                    "The vendor or platform family behind this data store, set as a mapping constant. ⚠️ "
                    "One level COARSER than `source_system`: several data sources of one vendor share a "
                    "provider value, so group by `provider` to ask about ecosystems and by `source_system` "
                    "to identify the feed."
                ),
            },
            "name": {
                "data_type": "VARCHAR(255)", "category": "Datastore Details",
                "semantic_description": (
                "Machine name of the data store as its source system knows it — a bucket name, a "
                "database name, a channel name. ⚠️ Distinct from `repositories.name` and "
                "`packages.name`: same column name, different entity, so a query that unions these "
                "tables must qualify it."
                ),
            },
            "display_name": {
                "data_type": "VARCHAR(255)", "category": "Datastore Details",
                "semantic_description": (
                "Human-readable label for this DATA STORE when rendering it in a UI, falling back to "
                "its machine name where the source offers nothing friendlier. Distinct from "
                "`identities.display_name`, which labels a principal rather than a store."
                ),
            },
            "description": {
                "data_type": "TEXT", "category": "Datastore Details",
                "semantic_description": (
                "Free-text account of what this DATA STORE is, either supplied by the source or "
                "composed at ingest (`'In-cluster <engine> engine: <name>'`). ⚠️ Not to be confused "
                "with `findings.description` or `issues.description`, which describe a security finding "
                "and a ticket respectively."
                ),
            },
            "datastore_type": {
                "data_type": "VARCHAR(50)", "category": "Datastore Details",
                "semantic_description": (
                "The store's canonical SHAPE, normalised at ingest from the engine so that stores of "
                "different vendors compare: `relational`, `document`, `keyvalue`, `vector`, `object`, "
                "`search`, `wide-column`, `analytical`, `graph`, `streaming`, `queue`, or `other`. "
                "Answers 'what kind of store', while `engine` names the specific product."
                ),
            },
            "service_type": {
                "data_type": "VARCHAR(50)", "category": "Datastore Details",
                "semantic_description": (
                "The hosting form the store runs as — a managed cloud service versus a self-hosted "
                "deployment. Separates 'the provider operates it' from 'we operate it', which is what "
                "decides who owns a patch."
                ),
            },
            "engine": {
                "data_type": "VARCHAR(50)", "category": "Datastore Details",
                "semantic_description": (
                "The concrete storage product behind this store (`postgres`, `minio`, `qdrant`, "
                "`redis`). The specific technology, from which `datastore_type` is derived; use "
                "`engine` for version- or product-specific questions and `datastore_type` to compare "
                "across vendors."
                ),
            },
            "status": {
                "data_type": "VARCHAR(50)", "category": "Datastore Details",
                "semantic_description": (
                "Operational state of the data store as reported by its source — whether it is running, "
                "stopped, or otherwise unavailable. ⚠️ Distinct from `findings.status` and "
                "`issues.status`, which track the lifecycle of a security finding and a ticket rather "
                "than a running resource."
                ),
            },
            "environment": {
                "data_type": "VARCHAR(50)", "category": "Datastore Details",
                "semantic_description": (
                    "The deployment tier this DATA STORE belongs to (`production` and similar). ⛔ "
                    "Provider-reported and frequently NULL — a Kubernetes pass leaves it unset — so "
                    "`environment != 'production'` silently excludes every store whose tier is simply "
                    "unknown; treat NULL as unclassified, not as non-production. ⚠️ Distinct from "
                    "`repositories.environment`, which is the tier a codebase SERVES rather than one a "
                    "running store sits in."
                ),
            },
            "publicly_accessible": {
                "data_type": "BOOLEAN", "category": "Network Configuration",
                "semantic_description": (
                "True when the data store is reachable from the public internet as reported by the "
                "source. ⛔ The highest-consequence boolean on this table: NULL means the source never "
                "reported exposure, NOT that the store is private, so counting `= false` as 'safe' "
                "quietly promotes unknowns into the safe bucket."
                ),
            },
            "cross_account_access": {
                "data_type": "BOOLEAN", "category": "Access & Authentication",
                "semantic_description": (
                "True when the store's policy permits access from outside its owning account or "
                "project. A lateral-movement signal that is independent of `publicly_accessible` — a "
                "store can be private to the internet and still broadly shared internally."
                ),
            },
            "custom_attributes": {
                "data_type": "VARIANT", "category": "Tags & Metadata",
                "semantic_description": (
                    "Raw source-specific fields for this data store, packed as JSON at ingest so nothing "
                    "the source returned is lost. ⛔ For investigation only — its keys vary by source, so "
                    "shipped SQL must read a declared column instead."
                ),
            },
            "data_classification": {
                "data_type": "VARCHAR(50)", "category": "Data Governance",
                "semantic_description": (
                "The category of data the store holds (for example `customer-data`, or `unknown` where "
                "nothing established it). Set by a governance source or inferred by an ingest rule; the "
                "basis for 'which stores hold regulated data' when it is populated."
                ),
            },
            "data_sensitivity": {
                "data_type": "VARCHAR(50)", "category": "Data Governance",
                "semantic_description": (
                "How sensitive the store's contents are, on the governance scale supplied by the "
                "source. Complements `data_classification` (what KIND of data) with a severity of "
                "exposure, and like it depends on a governance feed rather than a scanner."
                ),
            },
            "pii_data": {
                "data_type": "BOOLEAN", "category": "Data Governance",
                "semantic_description": (
                "True when the store is known to hold personally identifiable information. ⚠️ "
                "Governance-asserted rather than scanner-proven — NULL means unassessed, so this flag "
                "bounds what has been REVIEWED, not what actually contains PII."
                ),
            },
            "owner": {
                "data_type": "VARCHAR(255)", "category": "Ownership & Organization",
                "semantic_description": (
                "The team or person accountable for this data store, as recorded by a governance "
                "source. The routing target for an exposure finding on the store; NULL where no "
                "governance feed supplies ownership."
                ),
            },
            "data_steward": {
                "data_type": "VARCHAR(255)", "category": "Ownership & Organization",
                "semantic_description": (
                "The person or team accountable for the store's DATA — its classification, retention "
                "and access reviews — as distinct from `owner`, who is accountable for the resource "
                "itself. The two differ in most organisations and are deliberately separate columns."
                ),
            },
            "created_date": {
                "data_type": "TIMESTAMP_NTZ", "category": "Lifecycle & Management",
                "semantic_description": (
                "When the data store was created in its source system, as that system reports it. ⚠️ "
                "Not `created_at`, which is when Torana first ingested the row; a long-lived store "
                "ingested last week has an old `created_date` and a recent `created_at`."
                ),
            },
            "last_modified_date": {
                "data_type": "TIMESTAMP_NTZ", "category": "Lifecycle & Management",
                "semantic_description": (
                "When the store's definition last changed according to its source system. "
                "Provider-reported, so what counts as a modification varies by source; useful for drift "
                "detection rather than precise auditing."
                ),
            },
            "discovery_source": {
                "data_type": "VARCHAR(100)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "The FEED through which this data store was discovered — which pipeline told the "
                    "platform it exists. ⚠️ Kept distinct from `source_system` because a data store can be "
                    "discovered by one mechanism and maintained by another."
                ),
            },
            "discovery_method": {
                "data_type": "VARCHAR(50)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "By what MEANS this data store was discovered — an API collection, an inventory sweep, "
                    "or a manual registration. Complements `discovery_source` (which feed) and is how "
                    "automatically-inventoried rows are separated from hand-registered ones."
                ),
            },
            "created_by": {
                "data_type": "VARCHAR(255)", "category": "Audit & Tracking",
                "semantic_description": (
                "The Torana user or service principal that caused this row to be written. ⚠️ An "
                "ingest-side actor, not the store's business owner — read `owner` for accountability."
                ),
            },
            "created_via": {
                "data_type": "VARCHAR(100)", "category": "Audit & Tracking",
                "semantic_description": (
                    "The Torana mechanism that wrote this data store row — an integration sync, a replay, a "
                    "manual push, or a synthetic dataset load. ⛔ Provenance, not data store data: it is "
                    "what separates genuinely ingested rows from generated ones, and a query measuring a "
                    "real estate should know which values are synthetic."
                ),
            },
            "dataset_tag": {
                "data_type": "VARCHAR(200)", "category": "Audit & Tracking",
                "semantic_description": (
                    "Marks this data store row as seeded by a NAMED synthetic dataset rather than a live "
                    "integration, so such rows can be purged as a set. NULL for genuinely ingested rows. ⛔ "
                    "Filter it out when measuring a real estate — counting demo rows as production data "
                    "store data is the error this column exists to prevent."
                ),
            },
        }