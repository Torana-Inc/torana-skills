from typing import Dict, Any
from .base import TableSchema


class ImageComponentsSchema(TableSchema):
    """Schema for the image_components table: what an image contains, and where.

    One row per (image, package, file path). It is the per-image half of the SBOM:
    `packages` holds one row per package (a node shared by every image that has it) and
    the `contains` edge says the image has it, but neither can say WHERE in the image the
    package sits or WHICH LAYER put it there. A package can sit at two paths in one image
    (a wheel vendored inside setuptools as well as installed on its own), and each path is
    a separate row here.

    ⭐ `layer_diff_id` joins to `image_layers.diff_id`, which names the build step that
    added the package. NULL when the source did not report a layer (Container Analysis
    package occurrences carry a path but no layer).

    ⛔ OBSERVED DATA ONLY. Every row names its source (`source_system`, `source_ref`) so a
    verdict built on it can say where the evidence came from.

    Writers: the image-evidence ingestor (CycloneDX / Trivy JSON / Torana build record,
    `/ingest/image-evidence`) and gcp/container_analysis_packages.
    """

    @property
    def table_name(self) -> str:
        return "image_components"

    @property
    def primary_key(self) -> str:
        return "torana_image_component_id"

    @property
    def description(self) -> str:
        return (
            "The packages inside a container image: one row per image, package and file path, "
            "with the image layer that added it"
        )

    @property
    def category(self) -> str:
        return "Entity Graph"

    @property
    def timestamp_column(self) -> str:
        return "updated_at"

    @property
    def schema(self) -> Dict[str, Any]:
        return {
            "torana_image_component_id": {
                "data_type": "VARCHAR(100)", "primary_key": True, "category": "Core Identity",
                "semantic_description": (
                    "Torana's id for one package at one path in one image: `imgcomp:` + sha256 of "
                    "(image key, purl, file path, source, platform, and the layer when there is no "
                    "path). Primary key; re-ingesting the same image from the same source converges on "
                    "the same rows, and two sources or two platforms never overwrite each other."
                ),
            },
            "torana_artifact_id": {
                "data_type": "VARCHAR(600)", "not_null": True, "index": True, "category": "Core Identity",
                "semantic_description": (
                    "The image this image component sits in, as its "
                    "`image:<registry>/<repo>@sha256:<digest>` key. Joins to "
                    "`artifacts.torana_artifact_id` and to the `contains` edge's from_key."
                ),
            },
            "container_image_digest": {
                "data_type": "VARCHAR(100)", "index": True, "category": "Core Identity",
                "semantic_description": (
                    "The manifest digest of the image this image component was found in, bare hex "
                    "without `sha256:`, as in `artifacts.container_image_digest`."
                ),
            },
            "torana_package_id": {
                "data_type": "VARCHAR(512)", "index": True, "category": "Package",
                "semantic_description": (
                    "The package node (`pkg:<purl>`) this image component is an instance of, the same "
                    "value as `packages.torana_package_id` and the `contains` edge's to_key: many image "
                    "components (one per image and path) point at one package. NULL when the source "
                    "gave no purl."
                ),
            },
            "purl": {
                "data_type": "VARCHAR(512)", "category": "Package",
                "semantic_description": (
                    "Package URL of this image component, qualifiers removed (e.g. "
                    "`pkg:pypi/black@24.8.0`). The same value space as `packages.purl`, but repeated "
                    "once per package location in each image rather than once per package."
                ),
            },
            "name": {
                "data_type": "VARCHAR(255)", "category": "Package",
                "semantic_description": (
                    "Package name of this image component as the source reported it; the same name "
                    "repeats once per package location, unlike `packages.name`, one row per package."
                ),
            },
            "version": {
                "data_type": "VARCHAR(255)", "category": "Package",
                "semantic_description": (
                    "Installed version of this image component as the source reported it: the version "
                    "found at this package location, as opposed to `packages.version`, the version of "
                    "the one package row every image shares."
                ),
            },
            "pkg_type": {
                "data_type": "VARCHAR(50)", "category": "Package",
                "semantic_description": (
                    "What kind of package the scanner found, in its own words (Trivy `python-pkg`, "
                    "`debian`, `gobinary`; Container Analysis `OS`/`PYPI`). The ecosystem is the purl "
                    "type; this is the finer source label."
                ),
            },
            "file_path": {
                "data_type": "TEXT", "not_null": True, "default": "", "category": "Location",
                "semantic_description": (
                    "Where in the image filesystem the package was found (a dist-info METADATA file, a "
                    "binary, a lockfile). Empty for OS packages, which the package database records "
                    "rather than a file."
                ),
            },
            "platform": {
                "data_type": "VARCHAR(100)", "index": True, "category": "Location",
                "semantic_description": (
                    "The platform of the scan this image component came from (`linux/amd64`), when the "
                    "source said. "
                    "Part of the row's identity, so per-platform scans of one multi-platform image keep "
                    "their own rows. Empty when the source named no platform (Container Analysis)."
                ),
            },
            "layer_diff_id": {
                "data_type": "VARCHAR(100)", "index": True, "category": "Location",
                "semantic_description": (
                    "The image layer (uncompressed digest, `sha256:…`) that added this package. Join "
                    "to `image_layers.diff_id` for the build step. NULL when the source reported no "
                    "layer."
                ),
            },
            "source_system": {
                "data_type": "VARCHAR(100)", "category": "Provenance",
                "semantic_description": "What reported this image component: `trivy` (a native Trivy report), `trivy-cyclonedx` (Trivy's CycloneDX SBOM), `syft`, `cyclonedx`, `torana_build` or `gcp`.",
            },
            "source_ref": {
                "data_type": "TEXT", "category": "Provenance",
                "semantic_description": (
                    "Where this image component's evidence came from, precisely enough to fetch it "
                    "again: the ingested file's sha256 and name, or the Container Analysis occurrence "
                    "name."
                ),
            },
            "description": {
                "data_type": "TEXT", "not_null": True, "default": "", "category": "Package",
                "semantic_description": "Human-readable note about this image component. Empty unless a writer has something to say.",
            },
            "created_via": {
                "data_type": "VARCHAR(100)", "category": "Audit & Tracking",
                "semantic_description": "The Torana mechanism that wrote this image component row (an integration sync or a push ingest).",
            },
            "dataset_tag": {
                "data_type": "VARCHAR(200)", "category": "Audit & Tracking",
                "semantic_description": (
                    "Marks this image component row as seeded by a NAMED synthetic dataset. NULL for "
                    "observed data. "
                    "⛔ Filter it out when measuring a real estate."
                ),
            },
        }
