"""
Datalake utility functions.

This module provides utility functions for working with datalake backends,
including DuckDB file path resolution for multi-tenant environments.
"""

import os
from typing import Optional


def get_duckdb_file(
    tenant_id: Optional[str] = None,
    base_path: Optional[str] = None,
    db_type: str = 'source'
) -> str:
    """
    Get the DuckDB database file path for a given tenant.

    This function constructs the path to a tenant-specific DuckDB database file.
    It supports both source data (integrations write, transformers read) and
    transformer output (dbt writes, viz/detection read) databases.

    Args:
        tenant_id: Optional tenant UUID. If None, attempts to get tenant UUID from IAM context
        base_path: Optional base directory path. If None, uses DATALAKE_DATABASE_PATH or DUCKDB_PATH env var
        db_type: Database type - 'source' for source data or 'transformers' for transformer output (default: 'source')

    Returns:
        Full path to the DuckDB database file

    Raises:
        ValueError: If no tenant_id is provided and IAM context is not available

    Examples:
        >>> get_duckdb_file()
        './data/torana_source_123e4567-e89b-12d3-a456-426614174000.duckdb'  # Auto-gets tenant from IAM context

        >>> get_duckdb_file('123e4567-e89b-12d3-a456-426614174000')
        './data/torana_source_123e4567-e89b-12d3-a456-426614174000.duckdb'

        >>> get_duckdb_file('123e4567-e89b-12d3-a456-426614174000', db_type='transformers')
        './data/torana_transformers_123e4567-e89b-12d3-a456-426614174000.duckdb'

        >>> get_duckdb_file('123e4567-e89b-12d3-a456-426614174000', '/app/data', 'source')
        '/app/data/torana_source_123e4567-e89b-12d3-a456-426614174000.duckdb'

    Note:
        The tenant_id in IAMContext is already a UUID, so we use it directly for database naming.
        The file naming convention is: {base_name}_{db_type}_{tenant_id}.duckdb
    """
    # If no tenant_id provided, try to get from IAM context
    if tenant_id is None:
        try:
            from pantheon_shared.iam import IAMContext
            iam_context = IAMContext.get_iam_context()
            if iam_context and iam_context.tenant_id:
                # Use tenant_id (which is already a UUID) for database file naming
                tenant_id = iam_context.tenant_id
        except (ImportError, AttributeError):
            # IAM context not available, continue without tenant
            pass

    # Get base path from parameter, env var, or default
    if base_path is None:
        base_path = os.getenv("DATALAKE_DATABASE_PATH") or os.getenv("DUCKDB_PATH", "./data")

    # If base_path is already a full file path, extract directory
    if base_path.endswith('.duckdb'):
        base_dir = os.path.dirname(base_path) or '.'
        base_name = os.path.splitext(os.path.basename(base_path))[0]
        # Extract the base name without extension (e.g., 'torana' from 'torana.duckdb')
        base_name = base_name.replace('.duckdb', '')
    else:
        # If base_path is a directory, use it directly
        base_dir = base_path
        base_name = "torana"

    # Construct tenant-specific file path based on database type
    if tenant_id:
        if db_type == 'transformers':
            filename = f"{base_name}_transformers_{tenant_id}.duckdb"
        else:  # default to 'source'
            filename = f"{base_name}_source_{tenant_id}.duckdb"
    else:
        # If still no tenant (e.g., during service startup), raise an error
        # to prevent creating a non-tenant-specific database
        raise ValueError(
            "No tenant ID provided. DuckDB must be tenant-specific. "
            "Either pass tenant_id explicitly or ensure IAM context is available."
        )

    return os.path.join(base_dir, filename)


def get_duckdb_directory(tenant_id: Optional[str] = None, base_path: Optional[str] = None) -> str:
    """
    Get the directory containing the DuckDB database file.

    Args:
        tenant_id: Optional tenant ID
        base_path: Optional base directory path

    Returns:
        Directory path containing the DuckDB file
    """
    db_file = get_duckdb_file(tenant_id, base_path)
    return os.path.dirname(db_file)


def ensure_duckdb_directory(tenant_id: Optional[str] = None, base_path: Optional[str] = None) -> str:
    """
    Ensure the DuckDB directory exists and return the database file path.

    This function creates the directory structure for the DuckDB database file
    if it doesn't already exist.

    Args:
        tenant_id: Optional tenant ID
        base_path: Optional base directory path

    Returns:
        Full path to the DuckDB database file
    """
    db_file = get_duckdb_file(tenant_id, base_path)
    db_dir = os.path.dirname(db_file)

    # Create directory if it doesn't exist
    os.makedirs(db_dir, exist_ok=True)

    return db_file


__all__ = [
    "get_duckdb_file",
    "get_duckdb_directory",
    "ensure_duckdb_directory",
]
