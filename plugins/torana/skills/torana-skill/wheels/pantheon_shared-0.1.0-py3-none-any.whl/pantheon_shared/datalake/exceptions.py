"""
Custom exceptions for pantheon datalake backends.

This module defines the exception hierarchy used across all datalake
backend implementations (DuckDB, Snowflake, PostgreSQL).
"""

from typing import Optional, List, Any


class DatalakeError(Exception):
    """Base exception for all datalake-related errors.

    All custom exceptions in the datalake module inherit from this base class,
    allowing applications to catch all datalake errors with a single except clause.

    Attributes:
        message: Human-readable error message.
        backend: Name of the backend that raised the error (optional).
        details: Additional error details (optional).
    """

    def __init__(self, message: str, backend: Optional[str] = None, details: Optional[dict] = None):
        """Initialize datalake error.

        Args:
            message: Human-readable error message.
            backend: Backend name (e.g., 'duckdb', 'snowflake', 'postgres').
            details: Additional error context as key-value pairs.
        """
        self.message = message
        self.backend = backend
        self.details = details or {}

        # Build full error message with backend and details
        full_message = message
        if backend:
            full_message = f"[{backend.upper()}] {message}"
        if self.details:
            details_str = ", ".join(f"{k}={v}" for k, v in self.details.items())
            full_message = f"{full_message} ({details_str})"

        super().__init__(full_message)


class ConnectionError(DatalakeError):
    """Raised when database connection fails or is lost.

    This exception covers connection establishment failures, authentication errors,
    network issues, and connection pool exhaustion.

    Attributes:
        message: Error message describing the connection issue.
        host: Database host that connection failed to (optional).
        port: Database port (optional).
        database: Database name (optional).
        backend: Backend name (optional).
    """

    def __init__(
        self,
        message: str,
        host: Optional[str] = None,
        port: Optional[int] = None,
        database: Optional[str] = None,
        backend: Optional[str] = None
    ):
        """Initialize connection error.

        Args:
            message: Error message.
            host: Database hostname.
            port: Database port.
            database: Database name.
            backend: Backend name.
        """
        details = {}
        if host:
            details['host'] = host
        if port:
            details['port'] = port
        if database:
            details['database'] = database

        super().__init__(message, backend=backend, details=details)
        self.host = host
        self.port = port
        self.database = database


class QueryError(DatalakeError):
    """Raised when a query execution fails.

    This exception covers SQL syntax errors, constraint violations,
    missing tables/columns, and other query-related errors.

    Attributes:
        message: Error message describing the query failure.
        sql: The SQL query that failed (optional).
        params: Query parameters that were used (optional).
        backend: Backend name (optional).
    """

    def __init__(
        self,
        message: str,
        sql: Optional[str] = None,
        params: Optional[dict] = None,
        backend: Optional[str] = None
    ):
        """Initialize query error.

        Args:
            message: Error message.
            sql: SQL query that failed.
            params: Query parameters.
            backend: Backend name.
        """
        details = {}
        if sql:
            details['sql'] = sql[:100] + "..." if len(sql) > 100 else sql  # Truncate long queries
        if params:
            details['params'] = str(params)

        super().__init__(message, backend=backend, details=details)
        self.sql = sql
        self.params = params


class TenantNotFoundError(DatalakeError):
    """Raised when a tenant's data/schema cannot be found.

    This exception is raised when attempting to access a tenant that
    doesn't exist in the backend (e.g., missing database file, missing schema).

    Attributes:
        tenant_id: The tenant ID that was not found.
        backend: Backend name (optional).
    """

    def __init__(self, tenant_id: str, backend: Optional[str] = None):
        """Initialize tenant not found error.

        Args:
            tenant_id: Tenant ID that was not found.
            backend: Backend name.
        """
        message = f"Tenant data not found: {tenant_id}"
        super().__init__(message, backend=backend, details={'tenant_id': tenant_id})
        self.tenant_id = tenant_id


class BackendNotSupportedError(DatalakeError):
    """Raised when an unsupported backend type is requested.

    Attributes:
        backend_type: The unsupported backend type that was requested.
        supported_types: List of supported backend types.
    """

    def __init__(self, backend_type: str, supported_types: List[str]):
        """Initialize backend not supported error.

        Args:
            backend_type: The unsupported backend type.
            supported_types: List of valid backend types.
        """
        message = (
            f"Unsupported backend type: {backend_type}. "
            f"Supported types: {', '.join(supported_types)}"
        )
        super().__init__(message, details={'requested': backend_type})
        self.backend_type = backend_type
        self.supported_types = supported_types


class ConfigurationError(DatalakeError):
    """Raised when backend configuration is invalid or missing.

    This exception covers missing environment variables, invalid
    connection parameters, and misconfiguration issues.

    Attributes:
        message: Error message describing the configuration issue.
        missing_vars: List of missing required environment variables (optional).
        backend: Backend name (optional).
    """

    def __init__(self, message: str, missing_vars: Optional[List[str]] = None, backend: Optional[str] = None):
        """Initialize configuration error.

        Args:
            message: Error message.
            missing_vars: List of missing environment variable names.
            backend: Backend name.
        """
        details = {}
        if missing_vars:
            details['missing_vars'] = ", ".join(missing_vars)

        super().__init__(message, backend=backend, details=details)
        self.missing_vars = missing_vars or []


class ValidationError(DatalakeError):
    """Raised when data validation fails.

    This exception is raised when input data doesn't meet expected
    schemas, types, or constraints.

    Attributes:
        message: Error message describing validation failure.
        field: Field name that failed validation (optional).
        value: The invalid value (optional).
    """

    def __init__(self, message: str, field: Optional[str] = None, value: Optional[Any] = None):
        """Initialize validation error.

        Args:
            message: Error message.
            field: Field name that failed validation.
            value: The invalid value.
        """
        details = {}
        if field:
            details['field'] = field
        if value is not None:
            details['value'] = str(value)[:100]  # Truncate long values

        super().__init__(message, details=details)
        self.field = field
        self.value = value


class OperationTimeoutError(DatalakeError):
    """Raised when a backend operation times out.

    Attributes:
        message: Error message.
        operation: The operation that timed out (e.g., 'query', 'connect').
        timeout_seconds: Timeout duration in seconds.
    """

    def __init__(self, message: str, operation: str, timeout_seconds: float):
        """Initialize timeout error.

        Args:
            message: Error message.
            operation: Operation name.
            timeout_seconds: Timeout duration.
        """
        super().__init__(message, details={'operation': operation, 'timeout_seconds': timeout_seconds})
        self.operation = operation
        self.timeout_seconds = timeout_seconds


class TableNotFoundError(DatalakeError):
    """Raised when a requested table doesn't exist.

    Attributes:
        table_name: The table name that was not found.
        schema: Schema name where table was expected (optional).
        tenant_id: Tenant ID (optional).
    """

    def __init__(self, table_name: str, schema: Optional[str] = None, tenant_id: Optional[str] = None):
        """Initialize table not found error.

        Args:
            table_name: Table name that was not found.
            schema: Schema where table was expected.
            tenant_id: Tenant ID.
        """
        if schema:
            message = f"Table not found: {schema}.{table_name}"
        else:
            message = f"Table not found: {table_name}"

        details = {'table': table_name}
        if schema:
            details['schema'] = schema
        if tenant_id:
            details['tenant_id'] = tenant_id

        super().__init__(message, details=details)
        self.table_name = table_name
        self.schema = schema
        self.tenant_id = tenant_id


class LockConflictError(DatalakeError):
    """Raised when a database lock conflict occurs.

    This is common in DuckDB when multiple processes try to write
    to the same database file simultaneously.

    Attributes:
        message: Error message.
        database_path: Path to database file (for DuckDB).
        retry_attempts: Number of retry attempts made (optional).
    """

    def __init__(self, message: str, database_path: Optional[str] = None, retry_attempts: Optional[int] = None):
        """Initialize lock conflict error.

        Args:
            message: Error message.
            database_path: Path to database file.
            retry_attempts: Number of retries attempted.
        """
        details = {}
        if database_path:
            details['database'] = database_path
        if retry_attempts is not None:
            details['retry_attempts'] = retry_attempts

        super().__init__(message, backend='duckdb', details=details)
        self.database_path = database_path
        self.retry_attempts = retry_attempts
