"""The validated-provider filter — which providers we have proven against a real endpoint.

Design: ``pantheon-datalake/docs/SCHEMA_SERVICES_FILTER.md``.

════════════════════════════════════════════════════════════════════════════════
⛔ THIS FILTERS *PROVIDERS*, NOTHING ELSE
════════════════════════════════════════════════════════════════════════════════

Torana ships ETL mappings for 26 integration providers. Most were built from vendor API
documentation and have **never been run against a real endpoint** — yet the reachability
map parses their mapping YAML, finds a writer, and reports their columns as reachable.
``SCHEMA_SERVICES_FILTER`` is the platform-wide statement of which ones we have actually
validated.

Two categories are NEVER filterable, and conflating either with "an unvalidated provider"
is the bug this module exists to prevent:

1. **Unconditional writers** — ``integration is None``. System fields, global decorations,
   declared write-seam writers, operators, extractors. They belong to no integration and
   depend on nothing a customer connects.

2. **Push paths** — ``sarif``, ``asset``, ``trivy``, ``entity_edge``. Nobody *connects*
   SARIF; a scanner pushes to ``POST /api/v1/ingest/sarif``. These are DERIVED, never
   hardcoded: a mapping source with no ``IntegrationRegistry`` entry and no
   ``integrations/catalogs/*.yaml`` is not a connectable provider. A future push path is
   therefore exempt automatically instead of silently vanishing. See ``is_push_path``.

⚠️ **Survival is decided per WRITER by its ``integration``, never by its ``kind``.** The
``ingestor`` kind is why: 14 of its 24 writers carry an integration (``asset``, ``sarif``)
and survive only through the push-path branch, while 10 are unconditional. A model of
"five unconditional kinds + mapping" gets today's answer right by accident and would
silently filter a future ingestor built for a connectable provider.

⛔ **APPLIED AT SERIALIZATION, NEVER INSIDE ``build_reachability_map()``.** The map must
stay honest in memory, for two measured reasons:

  - ``/api/v1/datalake/schema/audit`` reconciles the write seam against the live DB and
    would report every hidden column as seam drift.
  - Every *roster* on this platform ("which integrations exist?") is derived by walking
    writers on reachable columns. Filter the map and the rosters silently lose the very
    providers the UI needs to grey out. Callers that need a roster read it from the
    unfiltered map — see ``SCHEMA_SERVICES_FILTER.md`` § 3.4.3.1, the TWO FACTS rule.

⚠️ **Changing the variable requires recreating every consuming container** — the parse is
``lru_cache``d per process, and four further caches downstream key without filter identity.
``dev-compose reload-env`` on integration, datalake, agent-builder AND viz. A plain
``restart`` does not pick up a changed env value at all.
"""
from __future__ import annotations

import logging
import os
from functools import lru_cache
from typing import Iterable, Optional, Set

logger = logging.getLogger(__name__)

ENV_VAR = "SCHEMA_SERVICES_FILTER"

#: Mapping sources that are push/ingest paths rather than connectable providers.
#: ⛔ NOT a hardcoded allowlist — this is only the fallback used when the caller cannot
#: supply the registry/catalog sets (``is_push_path`` derives the real answer). Kept so a
#: consumer with no access to pantheon-integration's tree still exempts the known four.
KNOWN_PUSH_PATHS: Set[str] = {"asset", "entity_edge", "sarif", "trivy"}


class InvalidProviderFilter(ValueError):
    """A configured name matches no mapping source.

    ⛔ Raised at STARTUP, never at request time. A typo must fail loudly: an unmatched
    name silently over-filters, and the columns it hides are indistinguishable from
    columns nothing writes.
    """


@lru_cache(maxsize=1)
def configured_providers() -> Optional[Set[str]]:
    """The validated-provider set, or ``None`` when filtering is OFF.

    ``None`` (empty or absent variable) means "no filtering" — every provider counts.
    An empty set is deliberately NOT representable: it would hide every provider-written
    column, which is never what an operator means by clearing the variable.
    """
    raw = (os.environ.get(ENV_VAR) or "").strip()
    if not raw:
        return None
    names = {p.strip().lower() for p in raw.split(",") if p.strip()}
    return names or None


def is_push_path(source: str, *, known_providers: Set[str]) -> bool:
    """True when ``source`` is a push/ingest path rather than a connectable provider.

    DERIVED, never hardcoded: ``known_providers`` is the union of the integration
    registry's names and the source-catalog stems. A mapping source absent from both is
    not something a customer connects.
    """
    return source.lower() not in {p.lower() for p in known_providers}


def writer_survives(
    integration: Optional[str],
    *,
    validated: Optional[Set[str]],
    push_paths: Optional[Set[str]] = None,
) -> bool:
    """Does one writer survive the filter?

    ⛔ ORDER MATTERS, and each branch answers a different question:
      1. ``validated is None``  → filtering is off entirely.
      2. ``integration is None`` → unconditional writer; belongs to no integration.
      3. push path              → not a connectable provider, so "unvalidated" is
                                  a category error for it.
      4. otherwise              → is this provider in the validated set?

    Pure function of its arguments — safe under arbitrary concurrent dispatch (R9).
    """
    if validated is None:
        return True
    if integration is None:
        return True
    name = integration.lower()
    if name in (push_paths if push_paths is not None else KNOWN_PUSH_PATHS):
        return True
    return name in validated


def validate_or_raise(*, known_sources: Iterable[str]) -> None:
    """Fail loudly at startup on a configured name that matches no mapping source.

    ⛔ Validate against the YAML ``metadata.source`` values — NOT directory names and NOT
    ``IntegrationRegistry`` names. The three vocabularies disagree:

        directory ``entity_edges/``  declares  source ``entity_edge``
        directory ``palo_alto/``     declares  source ``palo_alto``
                                     registry name ``palo_alto_networks``

    ``Writer.integration`` is populated from ``metadata.source``
    (``reachability.py``), so that is the only spelling a filter can match. A validator
    built on either other spelling accepts a name that matches nothing and over-filters in
    silence — the exact failure this function exists to catch.

    Also warns (never raises) when the configured set names only push paths, which is
    valid but pointless: push paths are exempt regardless.
    """
    validated = configured_providers()
    if validated is None:
        return

    known = {s.lower() for s in known_sources}
    unknown = sorted(validated - known)
    if unknown:
        raise InvalidProviderFilter(
            f"{ENV_VAR} names {unknown}, which match no mapping source. "
            f"Known sources: {sorted(known)}. "
            f"⚠️ Names must be the YAML `metadata.source` spelling — note "
            f"`entity_edge` (not `entity_edges`) and `palo_alto` (not "
            f"`palo_alto_networks`)."
        )

    only_push = validated & KNOWN_PUSH_PATHS
    if only_push and not (validated - KNOWN_PUSH_PATHS):
        logger.warning(
            "%s names only push paths %s — these are exempt from filtering regardless, "
            "so the filter will hide every provider-written column.",
            ENV_VAR, sorted(only_push),
        )
    elif only_push:
        logger.warning(
            "%s names push paths %s, which are exempt regardless — listing them has no "
            "effect and implies they are optional. Remove them.",
            ENV_VAR, sorted(only_push),
        )


def filter_status() -> dict:
    """Machine-readable filter state, for the `provider_filter` block on API payloads."""
    validated = configured_providers()
    return {
        "active": validated is not None,
        "validated": sorted(validated) if validated else [],
    }
