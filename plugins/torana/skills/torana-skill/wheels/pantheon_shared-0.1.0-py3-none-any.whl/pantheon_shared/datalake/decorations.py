"""The decoration registry — one source of truth for platform-asserted facts.

Design: ``pantheon-playground/usecases/vuln-prioritization-torana/DECORATION_LAYER_SPEC.md``
§ 3.4 (the registry) and § 3.4.1 (cross-decoration precedence).

A *decoration* is a platform-asserted fact applied to datalake rows with provenance.
Facts land in ``public.decoration_facts`` (subject-keyed, e.g. ``cve_id`` → EPSS score);
an apply job writes them into the sink table's real columns so every downstream
transformer, bundle, and widget sees them with **zero** query changes.

Why this module lives in ``pantheon-shared``: it is read by three independent
consumers — the apply job (pantheon-datalake), the ingest borrow path
(pantheon-integration's ``cve_enrich``), and the API/CLI surfaces. A copy in any
one of them would drift; the whole point of the layer is that it does not.

**Nothing here builds SQL.** The generator (``decoration_sql.py``) is the only
component that emits statements, and it derives every one of them from this dict.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Literal

__all__ = [
    "Kind",
    "Mode",
    "RowKind",
    "row_kind",
    "is_apply_target",
    "Output",
    "DecorationSpec",
    "DECORATIONS",
    "COLUMN_PRECEDENCE",
    "SEVERITY_RANK",
    "RAISE_RANKS",
    "DECORATION_TABLES",
    "PROVENANCE_COLUMN",
    "VERSION_COLUMN",
    "claimants",
    "lower_ranked",
    "higher_ranked",
    "decorated_columns",
    "sink_columns",
    "validate_registry",
    "RegistryError",
]


# ── The two axes a decorated column varies on ────────────────────────────────

class Kind(StrEnum):
    """How the fact becomes the column value."""

    SUBSTITUTE = "substitute"
    """The fact IS the column value (``epss_score := 0.94``)."""

    DERIVE = "derive"
    """The fact is an INPUT to a formula that also reads row columns
    (``vulnerability_due_date := row.scan_first_detected_date + fact days``).

    This distinction is what makes the layer general. An SLA *deadline* cannot
    be a stored fact: it differs for every row even when the policy is
    identical, so there is no single value to key on ``severity``. What IS
    subject-keyed and stable is the *policy* — ``{"Critical": 7, "High": 30}``.
    """


class Mode(StrEnum):
    """Who wins when the sink column already holds a value."""

    OVERRIDE = "override"
    """The asserted value wins — subject to the § 3.8 provenance guard, which
    still protects a scanner-supplied observation."""

    FILL = "fill"
    """The observed value wins; the decoration supplies only when absent."""

    RAISE = "raise"
    """The asserted value replaces the stored one ONLY when it ranks higher, and only on a
    row where none of ``Output.unless_present`` holds a value. It never lowers a value
    and is never retracted, so it needs no memory of what it replaced.

    ⭐ WHY A THIRD MODE. Severity from NVD (severity/CVSS change plan §1, 2026-09-15): NVD's
    CVSS band fills in the CVSS input a scanner did not send. It may raise a scanner's
    rating and must never lower one. FILL cannot say that — severity is never NULL, ingest
    writes 'Unknown' — and OVERRIDE would replace a stronger scanner rating.

    ⛔ WHY NEVER RETRACTED. The row keeps no record of the value before the raise: scanner
    syncs are incremental, so an unchanged finding is never re-read, and no column holds the
    scanner's own rating (no schema change, decided 2026-09-15). A lowered or withdrawn NVD
    score therefore leaves the raised value until the scanner re-reports the finding. The
    error runs toward overstating severity, never toward hiding it.
    """


@dataclass(frozen=True)
class Output:
    """One decorated SINK COLUMN and how it is produced."""

    kind: Kind
    mode: Mode
    attribute: str
    """Which ``decoration_facts.attribute`` feeds this column. NOT necessarily the
    column name — ``vulnerability_due_date`` is fed by the ``kev_due_date``
    attribute. G1 checks both names precisely because they differ."""

    expr: str | None = None
    """DERIVE only: SQL template. ``{fact}`` = the fact value (text, cast by the
    template); ``{row}.<col>`` = a column of the row being updated."""

    reads: tuple[str, ...] = ()
    """DERIVE only: every row column ``expr`` touches — LINEAGE. Verified to exist
    on the sink at startup; surfaced by the API so a reader can see what a
    derived value depends on."""

    requires: tuple[str, ...] = ()
    """DERIVE only: the subset of ``reads`` without which ``expr`` yields NULL —
    the non-NULL guard (G6).

    **NOT the same set as ``reads``, and conflating them inverts a column.** The
    breach expression READS ``vulnerability_due_date`` but does not REQUIRE it:
    its ``COALESCE`` exists precisely to handle that column being NULL. Guarding
    on ``reads`` would write the breach date *only where a due date already
    exists* — reviving the constant-FALSE ``is_sla_breached`` defect this whole
    layer exists to remove.
    """

    unless_present: tuple[str, ...] = ()
    """RAISE only: row columns holding the row's OWN evidence. When any is set the row is
    left alone. For severity these are the scanner's v3 and v4 scores — NVD fills in a
    missing CVSS score and never replaces one the scanner sent. ⚠️ v2 is deliberately
    absent: a v2 score never sets the band, so a v2-only row still takes NVD's."""


@dataclass(frozen=True)
class DecorationSpec:
    """One decoration: a coherent set of columns fed by one producer."""

    decorates: str
    """Sink table, e.g. ``vulnerabilities``."""

    subject_column: str
    """Sink column matched against ``decoration_facts.subject_key``."""

    scope: Literal["global", "tenant"]
    """``global`` → facts stored with ``tenant_id=''`` (feed-sourced, identical for
    every tenant); ``tenant`` → per-tenant facts."""

    provides: dict[str, Output]
    """Sink column -> how it is produced."""

    description: str = ""
    """Human-readable purpose, surfaced by the API and CLI."""


# ── The registry ─────────────────────────────────────────────────────────────

DECORATIONS: dict[str, DecorationSpec] = {
    # SUBSTITUTE — the fact is the value. Feed-sourced, tenant-independent.
    "cve_intel": DecorationSpec(
        decorates="vulnerabilities",
        subject_column="cve_id",
        scope="global",
        description=(
            "CVE threat intelligence (FIRST EPSS, CISA KEV, NVD advisory dates) "
            "asserted onto every vulnerability row carrying that CVE id, regardless "
            "of when the scan landed relative to the feed."
        ),
        provides={
            "epss_score": Output(Kind.SUBSTITUTE, Mode.OVERRIDE, attribute="epss_score"),
            "epss_percentile": Output(Kind.SUBSTITUTE, Mode.OVERRIDE, attribute="epss_percentile"),
            "cisa_kev_data": Output(Kind.SUBSTITUTE, Mode.OVERRIDE, attribute="cisa_kev_data"),
            # ── NVD advisory dates ──────────────────────────────────────────────
            #
            # ⭐ DECLARING THEM HERE IS WHAT MAKES THEM REACHABLE. `writers_from_
            # decorations()` (mechanism M3) imports DECORATIONS, so no hand-maintained
            # writer list needs editing — unlike the operator/ingestor/extractor lists.
            #
            # ⛔ OVERRIDE, NOT FILL, and the reason is the whole point of the column.
            # `cve_published_date` was previously DERIVED from the GCP Container
            # Analysis `createTime` — the same expression as `scan_first_detected_date`
            # — so the two were byte-identical on all 85,984 rows: a fabrication (when
            # OUR scanner first saw the occurrence, not when the advisory went public).
            # FILL would let exactly that kind of scanner-supplied value survive and
            # outrank the feed. NVD is THE authority for advisory dates; nothing a
            # scanner reports about them should win. Matches epss_score/cisa_kev_data.
            "cve_published_date": Output(
                Kind.SUBSTITUTE, Mode.OVERRIDE, attribute="published_date"
            ),
            "cve_last_modified_date": Output(
                Kind.SUBSTITUTE, Mode.OVERRIDE, attribute="last_modified_date"
            ),
            # FILL, not OVERRIDE: a scanner-supplied due date still wins, exactly
            # as cve_enrich.py:216-218 behaves today. Ranked ABOVE `policy` for
            # this column in COLUMN_PRECEDENCE — without which the winner is
            # whichever apply job happened to run last.
            "vulnerability_due_date": Output(
                Kind.SUBSTITUTE, Mode.FILL, attribute="kev_due_date"
            ),
            # ── NVD weakness class (#376) ───────────────────────────────────────
            #
            # ⭐ WHY THIS CLOSES #376. `vulnerabilities.cwe_id` is the ONLY column that
            # classifies a flaw, and it is 0-of-31,627 populated on this estate: the
            # scanners that emit CWE natively (sarif/trivy/blackduck) are not enabled,
            # and GCP Container Analysis carries no weakness field at all. So no mapping
            # change can produce it — but 99.4% of findings carry a `cve_id`, and NVD
            # publishes the CWE FOR THAT EXACT ID. Measured achievable coverage ~96%.
            #
            # ⛔ FILL, NOT OVERRIDE — and the contrast with the advisory dates above is
            # the whole reasoning. Those are OVERRIDE because a scanner reporting an
            # advisory date is reporting something it cannot know (it was fabricated
            # from scan time, which is what made them byte-identical). A scanner
            # reporting a CWE is different in kind: that is FIRST-HAND evidence about
            # code it actually analysed, and a code scanner routinely classifies a flaw
            # NVD never saw. NVD is the fallback here, not the authority — so it fills
            # the empty 100%, and never overwrites an observation.
            #
            # ⚠️ The FACT is already placeholder-free and primary-ranked: the producer
            # drops `NVD-CWE-noinfo` / `NVD-CWE-Other` rather than landing them, so a
            # value arriving here is always a real CWE. See threat_intel._nvd_cwes().
            "cwe_id": Output(Kind.SUBSTITUTE, Mode.FILL, attribute="cwe_id"),
            # ── Severity from NVD (severity/CVSS change plan §1, §2.5) ──────────────
            #
            # ⭐ NVD FILLS IN A CVSS SCORE THE SCANNER DID NOT SEND; IT NEVER REPLACES ONE.
            # The fact is NVD's v3 band (NVD's own score, else the CNA's), computed by the
            # producer. It raises severity only on a row with no scanner v3/v4 score, and
            # only when it outranks what is stored — so a scanner rating below NVD's band is
            # lifted, a stronger one stands, and a scanner score is never second-guessed.
            #
            # ⚠️ Measured before building (1,000 live GCP occurrences): 78 findings rise, 65 of
            # them with no scanner rating at all. On T1, every tier-7 finding in the
            # Prioritization app is Unknown with no score, and 463 of 587 have an NVD band.
            #
            # ⛔ Never retracted — see Mode.RAISE for why, and the error's direction.
            "severity": Output(
                Kind.SUBSTITUTE, Mode.RAISE, attribute="nvd_severity",
                unless_present=("cvss3_base_score", "cvss4_base_score"),
            ),
        },
    ),

    # DERIVE — the fact is the tenant's POLICY (a window in days); the DEADLINE is
    # computed per row from that row's own anchor.
    "policy": DecorationSpec(
        decorates="vulnerabilities",
        subject_column="severity",
        scope="tenant",
        description=(
            "The tenant's remediation SLA policy — a per-severity window in days — "
            "turned into a per-row deadline and breach date from each row's own "
            "first-detected anchor."
        ),
        provides={
            "vulnerability_due_date": Output(
                Kind.DERIVE, Mode.FILL, attribute="sla_window_days",
                expr="{row}.scan_first_detected_date + (({fact})::int * INTERVAL '1 day')",
                reads=("scan_first_detected_date",),
                requires=("scan_first_detected_date",),
            ),
            # `_apply_sla` writes TWO columns, not one. Omitting this one made
            # `is_sla_breached` constant-FALSE across three bundles, because that
            # column is the sole input to every bundle's breach predicate and each
            # guards it with IS NOT NULL — turning absence into a confident
            # "not breached".
            #
            # NOTE the expr differs from due_date's: breach follows the EFFECTIVE
            # due date (an existing due date wins over the severity window), which
            # is what makes a KEV row breach on CISA's deadline rather than the
            # generic window.
            "vulnerability_sla_breach_date": Output(
                Kind.DERIVE, Mode.FILL, attribute="sla_window_days",
                expr=(
                    "COALESCE({row}.vulnerability_due_date, "
                    "{row}.scan_first_detected_date + (({fact})::int * INTERVAL '1 day'))"
                ),
                reads=("vulnerability_due_date", "scan_first_detected_date"),
                requires=("scan_first_detected_date",),
            ),
        },
    ),

    # ── Deployment governance, in TWO tiers ──────────────────────────────────
    #
    # ⛔ WHY TWO DECORATIONS AND NOT ONE. `subject_column` is a SINGLE column by
    # design, so a "cluster, else project" fallback is not expressible in one
    # spec. Two decorations + a COLUMN_PRECEDENCE entry says the same thing
    # HONESTLY: cluster-scoped governance is more specific than project-wide,
    # so it wins, and the ordering is declared rather than left to whichever
    # apply job ran last.
    #
    # WHY THIS EXISTS AT ALL. Owning team / criticality / customer-data are
    # ASSERTED facts — the org decides them on a Deployment, and they change
    # when someone edits policy, not when a scanner runs. Per the mapping rule
    # ("Writers write only what they OBSERVED"), no mapping may write them.
    # Before this, exactly one code path did: a stamp inside the k8s extractor,
    # which reached only the 30 workloads THAT extractor produces. Measured on
    # T2 (2026-08-12): asset_team / asset_owner / criticality_name /
    # criticality_level / has_customer_data were each populated on 30 of 1,253
    # assets — identical counts, one shared cause — and 93% of vulnerabilities
    # resolved to `unassigned`.
    #
    # The join keys these decorations subject on did not exist until the CAI
    # mapping was fixed to populate them; both are now measured on T1 (live
    # GCP) and T2 (mock): container_cluster_id 733 rows, cloud_account_id
    # 1,117 — and the 733 read `us-west1-a/gke-twin-e8uiiw`, byte-identical to
    # deployments.cluster_ref.
    #
    # ⚠️ Mode.FILL, never OVERRIDE. A source that genuinely REPORTS an owner
    # (tenable/assets.yaml, aws_config/resources.yaml both pass through a real
    # asset_owner) is making an observation, and an observation outranks a
    # platform assertion. FILL also makes the apply's provenance guard do the
    # right thing: it may write its own value or an absent one, never a
    # scanner's.
    "governance_cluster": DecorationSpec(
        decorates="assets",
        subject_column="container_cluster_id",
        scope="tenant",
        description=(
            "Governance asserted on the Deployment that owns a cluster — owning "
            "team, owner, criticality and customer-data classification — applied "
            "to every asset in that cluster."
        ),
        provides={
            "asset_team": Output(Kind.SUBSTITUTE, Mode.FILL, attribute="team"),
            "asset_owner": Output(Kind.SUBSTITUTE, Mode.FILL, attribute="owner"),
            "criticality_name": Output(
                Kind.SUBSTITUTE, Mode.FILL, attribute="criticality_name"),
            "criticality_level": Output(
                Kind.SUBSTITUTE, Mode.FILL, attribute="criticality_level"),
            "has_customer_data": Output(
                Kind.SUBSTITUTE, Mode.FILL, attribute="has_customer_data"),
        },
    ),

    # Project-wide fallback. Covers the ~40% of cloud resources that are
    # genuinely NOT cluster-scoped (firewall rules, serviceusage.service,
    # project-level IAM) and would otherwise stay `unassigned` forever — the
    # exact blind spot that made ownership unmeasurable. Ranked BELOW
    # governance_cluster on every shared column.
    "governance_project": DecorationSpec(
        decorates="assets",
        subject_column="cloud_account_id",
        scope="tenant",
        description=(
            "Governance asserted at the cloud-account (GCP project) level, for "
            "assets that belong to no cluster. Outranked by cluster governance "
            "wherever both apply."
        ),
        provides={
            "asset_team": Output(Kind.SUBSTITUTE, Mode.FILL, attribute="team"),
            "asset_owner": Output(Kind.SUBSTITUTE, Mode.FILL, attribute="owner"),
            "criticality_name": Output(
                Kind.SUBSTITUTE, Mode.FILL, attribute="criticality_name"),
            "criticality_level": Output(
                Kind.SUBSTITUTE, Mode.FILL, attribute="criticality_level"),
            "has_customer_data": Output(
                Kind.SUBSTITUTE, Mode.FILL, attribute="has_customer_data"),
        },
    ),
}


# ── Cross-decoration precedence ──────────────────────────────────────────────
#
# The registry keys `provides` WITHIN a spec, so it cannot express "decoration A
# outranks decoration B on column X" — and this design already needs that.
# `vulnerability_due_date` has two claimants: CISA's own `kev_due_date` must
# outrank the tenant's policy window (today's documented behaviour — the KEV fill
# runs first so a CISA-mandated date is never overwritten by the generic window).
# The two jobs are enqueued independently, so without an ordering the outcome is
# nondeterministic.
#
# Only columns with >1 claimant appear here. Startup validation enforces that.

COLUMN_PRECEDENCE: dict[tuple[str, str], tuple[str, ...]] = {
    ("vulnerabilities", "vulnerability_due_date"): ("cve_intel", "policy"),

    # Governance: the MORE SPECIFIC scope wins. A cluster-scoped assertion is
    # about the deployment that actually runs the asset; the project-level one
    # is a fallback for assets that belong to no cluster. Without this ordering
    # a resource inside a governed cluster could take the project's team purely
    # because that apply job happened to run second.
    ("assets", "asset_team"): ("governance_cluster", "governance_project"),
    ("assets", "asset_owner"): ("governance_cluster", "governance_project"),
    ("assets", "criticality_name"): ("governance_cluster", "governance_project"),
    ("assets", "criticality_level"): ("governance_cluster", "governance_project"),
    ("assets", "has_customer_data"): ("governance_cluster", "governance_project"),
}


#: RAISE compares values by rank, so a RAISE output is valid only on a column with a
#: declared order. Severity's is the platform vocabulary (pantheon-integration
#: `normalize._SEVERITY_RANK`); anything outside it — 'Unknown', NULL, an unrecognised
#: spelling — ranks 0, so any real band outranks it.
SEVERITY_RANK: dict[str, int] = {
    "Critical": 5, "High": 4, "Medium": 3, "Low": 2, "Info": 1, "Unknown": 0,
}
RAISE_RANKS: dict[str, dict[str, int]] = {"severity": SEVERITY_RANK}


# ── Constants shared by the store, the generator, and the surfaces ───────────

DECORATION_TABLES = ("decoration_facts", "decoration_status", "decoration_apply_jobs")
"""The layer's own tables. The write path's relation allowlist is these three plus
every ``DECORATIONS[*].decorates`` sink."""

PROVENANCE_COLUMN = "decoration_provenance"
VERSION_COLUMN = "decoration_version"

_PROVENANCE_PAIR = frozenset({PROVENANCE_COLUMN, VERSION_COLUMN})

PROVENANCE_PREFIX = "decoration:"
"""Stamp format: ``decoration:<name>``. A row whose provenance does not start with
this prefix was written by an observer (a scanner) or by the legacy ingest path,
and the layer must not clear it."""


class RowKind(StrEnum):
    """What a ``decoration_status`` row IS — and therefore which fields mean anything.

    ⛔ **One table, three lifecycles.** This distinction was implicit for the first
    cut (inferred inline at four separate call sites), and two of those four got it
    wrong. Every symptom that followed traced to the same root: a row whose
    ``applied_version`` can never advance, compared against ``source_version`` as if
    it could, rendering "APPLYING…" forever.

    Deriving it here — once — is what makes that class of bug unrepresentable.
    """

    APPLY_TARGET = "apply_target"
    """tenant + namespace both set. Names real sink rows; an apply advances its
    ``applied_version``. The ONLY kind for which a version gap is meaningful."""

    TENANT_ROLLUP = "tenant_rollup"
    """tenant set, namespace ``''``. A per-tenant roll-up written when the producer
    visited the tenant but had no namespace to scope to (empty sink), or to clear a
    stale tenant-level error. Names NO sink rows."""

    FEED = "feed"
    """tenant ``''``. The producer's own fetch status for a ``global``-scope
    decoration — CISA KEV / FIRST EPSS are public facts, not tenant data."""


def row_kind(tenant_id: str | None, namespace_id: str | None) -> RowKind:
    """Classify a ``decoration_status`` row. THE one definition of this rule."""
    if not tenant_id:
        return RowKind.FEED
    if not namespace_id:
        return RowKind.TENANT_ROLLUP
    return RowKind.APPLY_TARGET


def is_apply_target(tenant_id: str | None, namespace_id: str | None) -> bool:
    """True when an apply job for this row could actually update sink rows.

    The backstop sweep, the ``pending_apply`` signal, and the producers' own
    ``applied_version`` handling all key off this — so they cannot disagree.
    """
    return row_kind(tenant_id, namespace_id) is RowKind.APPLY_TARGET


class RegistryError(RuntimeError):
    """Raised at startup when the registry is internally inconsistent.

    Deliberately fatal: a silent tie between two decorations on one column is the
    exact failure mode `COLUMN_PRECEDENCE` exists to prevent, so it fails loudly
    rather than defaulting to dict order.
    """


# ── Derived views over the registry ──────────────────────────────────────────

def claimants(table: str, column: str) -> tuple[str, ...]:
    """Every decoration that writes ``column`` on ``table``, highest precedence first.

    A single claimant needs no ``COLUMN_PRECEDENCE`` entry, so fall back to the
    one name. Order is only meaningful — and only required — when there are two.
    """
    ranked = COLUMN_PRECEDENCE.get((table, column))
    if ranked is not None:
        return ranked
    found = tuple(
        name for name, spec in DECORATIONS.items()
        if spec.decorates == table and column in spec.provides
    )
    return found


def lower_ranked(decoration: str, column: str) -> tuple[str, ...]:
    """Decorations this one outranks on ``column``.

    Used by the guard's third clause: a decoration may overwrite a value stamped
    by a decoration it outranks. **Often empty** — the guard elides the clause
    entirely in that case, because ``IN ()`` is a Postgres syntax error, not an
    empty set.
    """
    spec = DECORATIONS[decoration]
    ranked = claimants(spec.decorates, column)
    if decoration not in ranked:
        return ()
    return ranked[ranked.index(decoration) + 1:]


def higher_ranked(decoration: str, column: str) -> tuple[str, ...]:
    """Decorations that outrank this one on ``column``."""
    spec = DECORATIONS[decoration]
    ranked = claimants(spec.decorates, column)
    if decoration not in ranked:
        return ()
    return ranked[:ranked.index(decoration)]


def decorated_columns(table: str) -> tuple[str, ...]:
    """Every column on ``table`` that any decoration writes.

    The retraction's ``<no_value_remains>`` test spans all of these: the stamp may
    only be cleared once no decorated column on the row still holds a value.
    """
    cols: set[str] = set()
    for spec in DECORATIONS.values():
        if spec.decorates == table:
            cols.update(spec.provides)
    return tuple(sorted(cols))


def sink_columns(decoration: str) -> frozenset[str]:
    """The columns this decoration writes on its sink — ``frozenset(provides)``.

    This is G11's definition of ``sink_columns_written``, stated positively. An
    exclusion list ("everything in the SET minus the provenance pair") shipped the
    same off-by-one twice, because it named two of the three bookkeeping columns
    and ``updated_at`` slipped through both the original and its fix.
    """
    return frozenset(DECORATIONS[decoration].provides)


# ── Startup validation ───────────────────────────────────────────────────────

def validate_registry(sink_columns_by_table: dict[str, set[str]] | None = None) -> None:
    """Refuse to start on an inconsistent registry.

    Args:
        sink_columns_by_table: ``{table: {column, ...}}`` from the live schemas. When
            supplied, every ``provides`` key, every ``subject_column``, and every
            DERIVE's ``reads``/``requires`` column is checked to exist on the sink.
            Omit only in unit tests that are not exercising schema agreement.

    Raises:
        RegistryError: on any inconsistency. Fatal by design — see the class docstring.
    """
    problems: list[str] = []

    for name, spec in DECORATIONS.items():
        if not spec.provides:
            problems.append(f"{name}: declares no outputs")

        for column, out in spec.provides.items():
            where = f"{name}.provides[{column!r}]"

            if out.kind is Kind.DERIVE:
                if not out.expr:
                    problems.append(f"{where}: DERIVE requires `expr`")
                if not out.requires:
                    problems.append(
                        f"{where}: DERIVE requires a non-empty `requires` — an empty "
                        "guard writes NULL wherever an input is missing"
                    )
                unknown = set(out.requires) - set(out.reads)
                if unknown:
                    problems.append(
                        f"{where}: `requires` must be a subset of `reads`; "
                        f"{sorted(unknown)} is not read"
                    )
                if out.expr and "{fact}" not in out.expr:
                    problems.append(f"{where}: DERIVE `expr` never references {{fact}}")
            else:
                if out.expr or out.reads or out.requires:
                    problems.append(
                        f"{where}: SUBSTITUTE must not set expr/reads/requires — "
                        "the fact IS the value"
                    )

            if out.mode is Mode.RAISE:
                if out.kind is not Kind.SUBSTITUTE:
                    problems.append(
                        f"{where}: RAISE must be SUBSTITUTE — it compares the fact itself"
                    )
                if not out.unless_present:
                    problems.append(
                        f"{where}: RAISE requires `unless_present` — without it the fact "
                        "overrides the row's own evidence"
                    )
                if column not in RAISE_RANKS:
                    problems.append(
                        f"{where}: RAISE needs a declared rank order for {column!r} "
                        "(RAISE_RANKS)"
                    )
            elif out.unless_present:
                problems.append(f"{where}: `unless_present` is valid on RAISE only")

            if column in _PROVENANCE_PAIR:
                problems.append(
                    f"{where}: cannot decorate the provenance columns themselves"
                )

    # Every column claimed by >= 2 specs MUST declare its precedence. A silent tie
    # is the failure this exists to prevent, so it fails loudly rather than
    # defaulting to registry order.
    for table in {s.decorates for s in DECORATIONS.values()}:
        for column in decorated_columns(table):
            found = tuple(
                n for n, s in DECORATIONS.items()
                if s.decorates == table and column in s.provides
            )
            if len(found) < 2:
                if (table, column) in COLUMN_PRECEDENCE:
                    problems.append(
                        f"COLUMN_PRECEDENCE[{table!r},{column!r}]: only one claimant "
                        f"({found[0] if found else 'none'}) — an entry that can never fire "
                        "reads as covered when it is not"
                    )
                continue
            ranked = COLUMN_PRECEDENCE.get((table, column))
            if ranked is None:
                problems.append(
                    f"{table}.{column}: claimed by {sorted(found)} with no "
                    "COLUMN_PRECEDENCE entry — the winner would be whichever job ran last"
                )
            elif set(ranked) != set(found):
                problems.append(
                    f"COLUMN_PRECEDENCE[{table!r},{column!r}]={ranked} does not match "
                    f"the actual claimants {sorted(found)}"
                )
            elif len(set(ranked)) != len(ranked):
                problems.append(
                    f"COLUMN_PRECEDENCE[{table!r},{column!r}]={ranked} repeats a decoration"
                )

    # Stray precedence entries for tables/columns nothing decorates.
    for (table, column) in COLUMN_PRECEDENCE:
        if column not in decorated_columns(table):
            problems.append(
                f"COLUMN_PRECEDENCE[{table!r},{column!r}]: no decoration writes that column"
            )

    if sink_columns_by_table is not None:
        for name, spec in DECORATIONS.items():
            available = sink_columns_by_table.get(spec.decorates)
            if available is None:
                problems.append(
                    f"{name}: decorates unknown table {spec.decorates!r}"
                )
                continue
            if spec.subject_column not in available:
                problems.append(
                    f"{name}: subject_column {spec.subject_column!r} not on "
                    f"{spec.decorates}"
                )
            for column, out in spec.provides.items():
                if column not in available:
                    problems.append(
                        f"{name}.provides[{column!r}]: not a column of {spec.decorates}"
                    )
                for dep in out.unless_present:
                    if dep not in available:
                        problems.append(
                            f"{name}.provides[{column!r}]: unless_present column {dep!r} "
                            f"is not on {spec.decorates}"
                        )
                # `reads` is not decoration: it is checked here so a DERIVE naming a
                # column the sink does not have fails at startup rather than
                # producing NULLs at apply time.
                for dep in out.reads:
                    if dep not in available:
                        problems.append(
                            f"{name}.provides[{column!r}].reads: {dep!r} not on "
                            f"{spec.decorates}"
                        )
        # Per SINK, not per decoration — two decorations on one table would
        # otherwise report the same missing column twice.
        for table in sorted({s.decorates for s in DECORATIONS.values()}):
            available = sink_columns_by_table.get(table)
            if available is None:
                continue
            for col in (PROVENANCE_COLUMN, VERSION_COLUMN):
                if col not in available:
                    problems.append(
                        f"{table}: missing {col!r} — § 4.2 must land before "
                        "the first apply job runs"
                    )

    if problems:
        raise RegistryError(
            "decoration registry is inconsistent:\n  - " + "\n  - ".join(problems)
        )
