from typing import Dict, Any
from .base import TableSchema


class ArtifactsSchema(TableSchema):
    """Schema definition for the artifacts table."""

    @property
    def table_name(self) -> str:
        return "artifacts"

    @property
    def primary_key(self) -> str:
        return "torana_artifact_id"

    @property
    def description(self) -> str:
        return "Build artifacts, container images, and deployment packages with security scan results and metadata"

    @property
    def category(self) -> str:
        return "DevOps Data"

    @property
    def timestamp_column(self) -> str:
        """Return the timestamp column for this table."""
        return "updated_at"

    @property
    def schema(self) -> Dict[str, Any]:
        return {
            "torana_artifact_id": {"data_type": "TEXT", "primary_key": True, "category": "Core Identity",
                "semantic_description": (
                    "Torana's stable id for one build artifact — a container image, package or "
                    "binary. The middle of the chain: code is built INTO an artifact, and an "
                    "artifact is deployed AS a running asset."
                ),
            },
            "torana_entity_id": {"data_type": "VARCHAR(255)", "category": "Core Identity",
                "semantic_description": (
                    "The running entity this artifact was deployed as. One artifact can become "
                    "many entities, which is why a single vulnerable image can affect a whole "
                    "fleet."
                ),
            },
            "torana_repository_id": {"data_type": "VARCHAR(255)", "category": "Core Identity",
                "semantic_description": (
                    "Foreign key to the REPOSITORY this artifact was built from — the link that lets a "
                    "finding in an image be traced back to the code and the team that can fix it. ⚠️ A "
                    "foreign key, not this table's identity; `repositories.torana_repository_id` is the "
                    "primary key it points at."
                ),
            },
            "source_system_id": {"data_type": "VARCHAR(255)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "The artifact's id in the system that reported it."
                ),
            },
            "source_system": {"data_type": "VARCHAR(100)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "The integration or internal producer that reported this artifact row. ⚠️ Determines "
                    "which other columns are populated at all, since sources differ in what they expose, "
                    "and it is the first thing to check when two rows describe the same artifact "
                    "differently."
                ),
            },
            "cloud_account_id": {"data_type": "VARCHAR(100)", "category": "Cloud Provider-Specific Fields",
                "semantic_description": (
                    "The cloud account or subscription this row belongs to — a GCP project id, an "
                    "AWS account number, an Azure subscription. Often the real boundary between "
                    "teams or environments, so it is the natural grouping for 'show me X by "
                    "account'. ⚠️ NOT a Jira project and NOT a logical/product grouping: those "
                    "are separate concepts (see issues.project_key and the governance properties). "
                    "NULL for rows that are not cloud-sourced."
                ),
            },
            "cloud_provider": {"data_type": "VARCHAR(50)", "category": "Cloud Provider-Specific Fields",
                "semantic_description": (
                    "Which cloud this runs in: AWS, Azure, GCP, OCI, or On-Premises. ⚠️ Distinct "
                    "from source_system, which says WHO reported the row — a Kubernetes connector "
                    "reporting a workload running in GCP writes source_system='kubernetes' and "
                    "cloud_provider='gcp'. Needed to disambiguate cloud_account_id, whose namespace "
                    "differs per provider."
                ),
            },
            "discovery_source": {"data_type": "VARCHAR(100)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "The FEED through which this artifact was discovered — which pipeline told the platform "
                    "it exists. ⚠️ Kept distinct from `source_system` because a artifact can be discovered "
                    "by one mechanism and maintained by another."
                ),
            },
            "discovery_method": {"data_type": "VARCHAR(50)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "By what MEANS this artifact was discovered — an API collection, an inventory sweep, or "
                    "a manual registration. Complements `discovery_source` (which feed) and is how "
                    "automatically-inventoried rows are separated from hand-registered ones."
                ),
            },
            "name": {"data_type": "VARCHAR(255)", "category": "Artifact Details",
                "semantic_description": (
                    "Machine name of the ARTIFACT as its source registry knows it. ⚠️ Distinct from "
                    "`repositories.name` (a codebase), `packages.name` (a dependency) and `controls.name` "
                    "(a rule) — same column name across four tables, four different entities."
                ),
            },
            "display_name": {"data_type": "VARCHAR(255)", "category": "Artifact Details",
                "semantic_description": (
                    "Display name, where the source provides one distinct from `name`."
                ),
            },
            "description": {"data_type": "TEXT", "category": "Artifact Details",
                "semantic_description": (
                    "The artifact's own description. NOTE this is a DATA column; per-column "
                    "meaning lives in `semantic_description` metadata, not here."
                ),
            },
            "artifact_type": {"data_type": "VARCHAR(50)", "category": "Artifact Details",
                "semantic_description": (
                    "What kind of artifact this is: container_image, package, binary, library. "
                    "Determines which of the type-specific column blocks below are populated — "
                    "a package row leaves every container_image_* field empty."
                ),
            },
            "file_path": {"data_type": "VARCHAR(255)", "category": "Artifact Details",
                "semantic_description": (
                    "Path locating this artifact within its source — where the built object sits in the "
                    "registry or storage layout. ⚠️ Distinct from `findings.file_path`, which is the source "
                    "file a finding was detected in, not the location of a build output."
                ),
            },
            "languages": {"data_type": "JSON", "category": "Artifact Details",
                "semantic_description": (
                    "Programming languages detected inside this ARTIFACT, as reported by its source. ⚠️ "
                    "Distinct from `repositories.languages`, which describes the source tree; a built image "
                    "can carry runtimes absent from the repository that produced it."
                ),
            },
            "container_image_registry_provider": {"data_type": "VARCHAR(50)", "category": "Container Specifics",
                "semantic_description": (
                    "Which registry PRODUCT hosts this image, as a short product code derived from the "
                    "registry host in the image URI — e.g. `GAR` for Google Artifact Registry, `GCR` for "
                    "the deprecated Google Container Registry. Answers \"where is this image served from, "
                    "and who do I file a re-fetch against\". ⚠️ NOT the cloud vendor whose API reported "
                    "the image — a connector for one cloud can report images hosted anywhere. ⛔ NOT an "
                    "ownership signal: a first-party build and a mirrored third-party image can sit in "
                    "the same registry under the same host, so this never says whose image it is. "
                    "Ownership is a separate, declared tenant policy. ⚠️ Written by a derive that always "
                    "emits, so an image whose host matches no known registry carries the EMPTY STRING, "
                    "not NULL; NULL means no writer touched the column. See the column\'s value domain "
                    "for the emitting mapping."
                ),
            },
            "container_image_registry_name": {"data_type": "VARCHAR(255)", "category": "Container Specifics",
                "semantic_description": (
                    "Name of the registry hosting this container image, used to attribute an image to the "
                    "registry it was pulled from. NULL for artifacts that are not container images."
                ),
            },
            "container_image_registry_url": {"data_type": "VARCHAR(1000)", "category": "Container Specifics",
                "semantic_description": (
                    "Base URL of the registry hosting this container image, kept so an image can be "
                    "re-fetched or linked to. NULL for artifacts that are not container images."
                ),
            },
            "container_image_repository": {"data_type": "VARCHAR(255)", "category": "Container Specifics",
                "semantic_description": (
                    "Repository path within the registry that holds this image (the `org/name` portion of a "
                    "pull reference), excluding registry host, tag and digest."
                ),
            },
            "container_image_id": {"data_type": "VARCHAR(255)", "category": "Container Specifics",
                "semantic_description": (
                    "The image's own identifier as its registry reports it. ⚠️ Distinct from "
                    "`assets.container_image_id`, which records the image a RUNNING asset was launched from "
                    "— this row IS the image, that row merely references one."
                ),
            },
            "container_image_name": {"data_type": "VARCHAR(500)", "category": "Container Specifics",
                "semantic_description": (
                    "The image's name without tag or digest, naming the image family rather than one "
                    "specific build. ⛔ Not identity: many distinct builds share this name, so counting "
                    "images by name collapses every version into one."
                ),
            },
            "container_image_digest": {"data_type": "VARCHAR(100)", "category": "Container Specifics",
                "semantic_description": (
                    "The container image's content hash, recorded on this artifact row — the identifier "
                    "that cannot drift. ⚠️ A tag can be repointed at new content; a digest cannot, which is "
                    "why deployments and findings key on it rather than on the tag."
                ),
            },
            "container_image_tag": {"data_type": "VARCHAR(255)", "category": "Container Specifics",
                "semantic_description": (
                    "The tag this image was published under. Mutable: `latest` today is not "
                    "`latest` tomorrow, so a tag alone does not identify what actually ran."
                ),
            },
            "is_archived": {"data_type": "BOOLEAN", "category": "Artifact Status",
                "semantic_description": (
                    "True when the artifact has been archived in its source registry and is no longer "
                    "actively published. ⚠️ Distinct from `repositories.is_archived`, which archives a "
                    "codebase; an active repository can still hold archived artifacts."
                ),
            },
            "repository_url": {"data_type": "VARCHAR(1000)", "category": "Source Repository",
                "semantic_description": (
                    "URL of the source repository this artifact was built from, where the build system "
                    "records provenance. The link back from a built object to the code that produced it."
                ),
            },
            "repository_branch": {"data_type": "VARCHAR(100)", "category": "Source Repository",
                "semantic_description": (
                    "Branch of the source repository this artifact was built from, recorded at build time. "
                    "Distinguishes a release build from a feature-branch build of the same artifact name."
                ),
            },
            "repository_commit": {"data_type": "VARCHAR(40)", "category": "Source Repository",
                "semantic_description": (
                    "The exact commit built. What makes an artifact reproducible and lets a "
                    "finding be pinned to a point in history."
                ),
            },
            "repository_freshness": {"data_type": "VARCHAR(100)", "category": "Source Repository",
                "semantic_description": (
                    "How current the artifact is against its source repository. A stale "
                    "artifact may be missing fixes already merged in code."
                ),
            },
            "vm_last_scan_time": {"data_type": "TIMESTAMP", "category": "Vulnerability Management",
                "semantic_description": (
                    "Most recent scan. Old values mean the findings shown may not reflect the "
                    "current image."
                ),
            },
            # ── The COMPLETENESS CLAIM (CAP-15) ──────────────────────────────────────
            # ⛔ TWO OF THESE ARE RETURNING FROM THE REMOVED-COLUMN ARCHIVE, and the
            # archive rule is that a column comes back ONLY together with the writer that
            # fills it — never because it looks useful.
            #
            #   artifacts.vm_security_scan_status  removed 2026-08-09 (shadow)
            #   artifacts.vm_has_scan_results      removed 2026-08-09 (shadow)
            #       "Whether any scan has produced results. Configured-but-never-run is
            #        distinct from clean."
            #
            # ⭐ WHAT CHANGED: both were removed because NOTHING WROTE THEM. They now have
            # a writer — the `container_analysis_discovery` ETL source added in this same
            # change, reading Google's DISCOVERY occurrence. Same name reused deliberately
            # so the archive's record stays coherent.
            #
            # `vm_has_scan_results` is deliberately NOT restored: a boolean cannot say
            # WHICH ecosystems were examined, which is the whole question. `vm_scan_analyzers`
            # replaces it and strictly subsumes it — a non-empty list implies results exist.
            # ⛔ WHY THESE EXIST. Without them an artifact reporting zero findings is
            # indistinguishable from one nobody examined, and both render as good news.
            # Every clean result and every coverage percentage rests on an assumption the
            # platform could not check.
            #
            # MEASURED 2026-09-05 on tenant acme: `vm_last_scan_time` was populated on
            # 0 of 43 live images while Google's DISCOVERY occurrence carried a scan time
            # for 43 of 43 — the value existed upstream and nothing carried it across.
            "vm_scan_analyzers": {"data_type": "TEXT", "category": "Vulnerability Management",
                "semantic_description": (
                    "Which analyzers actually examined this artifact, comma-separated and "
                    "upper-case (GO,PYPI,OS,NPM,MAVEN,NUGET,COMPOSER,RUBYGEMS,RUST,SECRET). "
                    "⭐ THIS IS THE COMPLETENESS CLAIM: it is what separates 'this image "
                    "contains no Go packages' from 'nobody looked for Go packages here'. An "
                    "ecosystem ABSENT from this list was never examined, so a zero finding "
                    "count for it is not evidence of anything. NULL means the scanner did not "
                    "state its coverage — treat every ecosystem as unexamined."
                ),
            },
            "vm_security_scan_status": {"data_type": "VARCHAR(50)", "category": "Vulnerability Management",
                "semantic_description": (
                    "Whether the last scan COMPLETED (e.g. FINISHED_SUCCESS, FINISHED_FAILED, "
                    "SCANNING). ⚠️ A non-success value means the findings on this artifact are "
                    "partial — the scan did not finish, so absence of a finding proves nothing."
                ),
            },
            "vm_continuous_analysis": {"data_type": "VARCHAR(20)",
                "category": "Vulnerability Management",
                "semantic_description": (
                    "Whether the scanner is STILL re-examining this artifact as new advisories "
                    "are published (ACTIVE / INACTIVE). ⛔ INACTIVE is a silent-staleness "
                    "signal: the artifact's findings are frozen at the last scan while the "
                    "advisory world moves on, so a low count means 'nobody has looked lately', "
                    "not 'low risk'. MEASURED 2026-09-05: 172 of 310 images in one GCP project "
                    "were INACTIVE — Google drops continuous analysis roughly 30 days after push."
                ),
            },
            "criticality_name": {"data_type": "VARCHAR(20)", "category": "Risk & Security Posture",
                "semantic_description": (
                    "How much this artifact matters to the business. DECLARED — no scanner can "
                    "infer it."
                ),
            },
            "criticality_level": {"data_type": "INTEGER", "category": "Risk & Security Posture",
                "semantic_description": (
                    "Numeric form of `criticality_name` for this artifact, kept for ordering and "
                    "comparison. ⚠️ Two columns holding ONE fact — set them together or set neither, since "
                    "a query reading only one of them silently disagrees with a query reading the other."
                ),
            },
            "tags_metadata": {"data_type": "JSON", "category": "Tags & Metadata",
                "semantic_description": (
                    "Tag information carried from the registry for this artifact, including the tags "
                    "pointing at this build. ⛔ Registry tags are mutable and can be re-pointed to a "
                    "different digest, so treat this as a label rather than an identifier."
                ),
            },
            "custom_attributes": {"data_type": "JSON", "category": "Tags & Metadata",
                "semantic_description": (
                    "Raw source-specific fields for this artifact, packed as JSON at ingest so nothing the "
                    "source returned is lost. ⛔ For investigation only — its keys vary by source, so "
                    "shipped SQL must read a declared column instead."
                ),
            },
            "artifact_created_date": {"data_type": "TIMESTAMP", "category": "Lifecycle & Management",
                "semantic_description": (
                    "When the artifact was created in its source system, as that system reports it. ⚠️ Not "
                    "`created_at`, which records when Torana first ingested the row."
                ),
            },
            "artifact_updated_date": {"data_type": "TIMESTAMP", "category": "Lifecycle & Management",
                "semantic_description": (
                    "When the artifact was last updated in its source registry. Provider-reported; what "
                    "counts as an update varies by registry, so prefer it for drift detection rather than "
                    "precise auditing."
                ),
            },
            "artifact_last_pushed_date": {"data_type": "TIMESTAMP", "category": "Lifecycle & Management",
                "semantic_description": (
                    "When this artifact was most recently pushed to its registry. The best available "
                    "evidence of whether an image is still actively published, as distinct from merely "
                    "still present."
                ),
            },
            "created_by": {
                "data_type": "VARCHAR(255)", "category": "Audit & Tracking",
                "semantic_description": (
                    "The Torana user or service principal that caused this artifact row to be written — in "
                    "practice the integration that ingested it (`github_integration`, `jira_integration`). "
                    "⚠️ An INGEST-side actor, NOT the owner of the thing described: do not read it as "
                    "'who is responsible for this'."
                ),
            },
            "created_via": {"data_type": "VARCHAR(100)", "category": "Audit & Tracking",
                "semantic_description": (
                    "The Torana mechanism that wrote this artifact row — an integration sync, a replay, a "
                    "manual push, or a synthetic dataset load. ⛔ Provenance, not artifact data: it is what "
                    "separates genuinely ingested rows from generated ones, and a query measuring a real "
                    "estate should know which values are synthetic."
                ),
            },
            "dataset_tag": {"data_type": "VARCHAR(200)", "category": "Audit & Tracking",
                "semantic_description": (
                    "Marks this artifact row as seeded by a NAMED synthetic dataset rather than a live "
                    "integration, so such rows can be purged as a set. NULL for genuinely ingested rows. ⛔ "
                    "Filter it out when measuring a real estate — counting demo rows as production artifact "
                    "data is the error this column exists to prevent."
                ),
            },
        }