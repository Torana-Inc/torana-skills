from typing import Dict, Any
from .base import TableSchema


class RepositoriesSchema(TableSchema):
    """Schema definition for the repositories table."""

    @property
    def table_name(self) -> str:
        return "repositories"

    @property
    def primary_key(self) -> str:
        return "torana_repository_id"

    @property
    def description(self) -> str:
        return "Source code repositories with metadata about projects, branches, commits, and security scanning results"

    @property
    def category(self) -> str:
        return "DevOps Data"

    @property
    def timestamp_column(self) -> str:
        """Return the timestamp column for this table."""
        return "updated_at"

    @property
    def schema(self) -> Dict[str, Any]:
        return {
            "torana_repository_id": {"data_type": "VARCHAR(255)", "primary_key": True, "category": "Core Identity",
                "semantic_description": (
                    "Torana's stable id for one REPOSITORY, source-neutral (`repo:<host>/<org>/<repo>`), "
                    "and the primary key of this table. Scanner findings and VCS sync converge here, so "
                    "SARIF results and platform metadata land on the same row."
                ),
            },
            "source_system": {"data_type": "VARCHAR(100)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "The integration or internal producer that reported this repository row. ⚠️ Determines "
                    "which other columns are populated at all, since sources differ in what they expose, "
                    "and it is the first thing to check when two rows describe the same repository "
                    "differently."
                ),
            },
            "source_system_id": {"data_type": "VARCHAR(255)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "The repository's identifier in its hosting platform, kept verbatim so the row can be "
                    "traced back and re-fetched. Provider-specific in shape and never comparable across "
                    "platforms."
                ),
            },
            "discovery_source": {"data_type": "VARCHAR(100)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "The FEED through which this repository was discovered — which pipeline told the "
                    "platform it exists. ⚠️ Kept distinct from `source_system` because a repository can be "
                    "discovered by one mechanism and maintained by another."
                ),
            },
            "discovery_method": {"data_type": "VARCHAR(50)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "By what MEANS this repository was discovered — an API collection, an inventory sweep, "
                    "or a manual registration. Complements `discovery_source` (which feed) and is how "
                    "automatically-inventoried rows are separated from hand-registered ones."
                ),
            },
            "scan_enabled": {"data_type": "BOOLEAN", "category": "Discovery & Inventory",
                "semantic_description": (
                    "Whether scanning is configured. When false, no findings means nobody "
                    "looked."
                ),
            },
            "last_scan_date": {"data_type": "TIMESTAMP", "category": "Discovery & Inventory",
                "semantic_description": (
                    "When it was last scanned. Stale means the findings shown may be out of "
                    "date."
                ),
            },
            "provider": {"data_type": "VARCHAR(50)", "category": "Repository Details",
                "semantic_description": (
                    "The vendor or platform family behind this repository, set as a mapping constant. ⚠️ "
                    "One level COARSER than `source_system`: several data sources of one vendor share a "
                    "provider value, so group by `provider` to ask about ecosystems and by `source_system` "
                    "to identify the feed."
                ),
            },
            "platform_type": {"data_type": "VARCHAR(50)", "category": "Repository Details",
                "semantic_description": (
                    "Whether the host is cloud-hosted or self-managed."
                ),
            },
            "organization_id": {"data_type": "VARCHAR(255)", "category": "Repository Details",
                "semantic_description": (
                    "Identifier of the owning organisation on the hosting platform. Groups repositories by "
                    "org for ownership reporting, and is platform-specific rather than a Torana id."
                ),
            },
            "organization_name": {"data_type": "VARCHAR(255)", "category": "Repository Details",
                "semantic_description": (
                    "The owning org or group. Often the closest thing to a team boundary before "
                    "ownership is declared."
                ),
            },
            "name": {"data_type": "VARCHAR(255)", "category": "Repository Details",
                "semantic_description": (
                    "Repository name without its organisation prefix. ⚠️ NOT unique on its own — two orgs "
                    "can hold the same repository name, so identity requires the org or the full name; "
                    "distinct also from `artifacts.name` and `packages.name`."
                ),
            },
            "full_name": {"data_type": "VARCHAR(500)", "category": "Repository Details", "unique": True,
                "semantic_description": (
                    "Qualified `org/repo` name — what a developer recognises and searches for."
                ),
            },
            "display_name": {"data_type": "VARCHAR(255)", "category": "Repository Details",
                "semantic_description": (
                    "Display name, where the platform allows one distinct from `name`."
                ),
            },
            "description": {"data_type": "TEXT", "category": "Repository Details",
                "semantic_description": (
                    "The repository's own description. NOTE this is a DATA column; per-column "
                    "meaning is carried in `semantic_description` metadata, not here."
                ),
            },
            "language": {"data_type": "VARCHAR(50)", "category": "Repository Details",
                "semantic_description": (
                    "Primary language. Determines which package ecosystem and which SAST rules "
                    "apply."
                ),
            },
            "languages": {"data_type": "JSON", "category": "Repository Details",
                "semantic_description": (
                    "All languages detected, with their proportions. A repo that is 90% one "
                    "language and 10% another has two dependency trees to worry about."
                ),
            },
            "topics": {"data_type": "JSON", "category": "Repository Details",
                "semantic_description": (
                    "Platform topics or tags applied to the repository."
                ),
            },
            "size_kb": {"data_type": "BIGINT", "category": "Repository Details",
                "semantic_description": (
                    "Size of the repository in kilobytes as reported by its hosting platform. A rough proxy "
                    "for scale; platforms differ in whether history and large-file storage are counted."
                ),
            },
            "environment": {"data_type": "VARCHAR(50)", "category": "Repository Details",
                "semantic_description": (
                    "Which environment this REPOSITORY's code serves. ⚠️ Rarely populated — repos are "
                    "seldom tagged this way, so environment is usually inferred from what deploys them. "
                    "Distinct from `datastores.environment`, which is the tier a running store belongs to; "
                    "a repository is not itself deployed anywhere."
                ),
            },
            "default_branch": {"data_type": "VARCHAR(100)", "category": "Repository Status",
                "semantic_description": (
                    "The branch treated as canonical. Scans and policies normally target this "
                    "one."
                ),
            },
            "visibility": {"data_type": "VARCHAR(20)", "category": "Repository Status",
                "semantic_description": (
                    "public, private, or internal. A public repository leaks anything committed "
                    "to it, which makes exposed secrets categorically worse."
                ),
            },
            "is_archived": {"data_type": "BOOLEAN", "category": "Repository Status",
                "semantic_description": (
                    "Whether the repository is archived. Findings on archived code rarely "
                    "warrant action, but the code may still be deployed somewhere."
                ),
            },
            "is_disabled": {"data_type": "BOOLEAN", "category": "Repository Status",
                "semantic_description": (
                    "True when the hosting platform has disabled this repository, making it inaccessible. "
                    "⚠️ Distinct from `is_archived`, which is a deliberate read-only retirement — a "
                    "disabled repository is usually an administrative or billing action."
                ),
            },
            "is_fork": {"data_type": "BOOLEAN", "category": "Repository Status",
                "semantic_description": (
                    "Whether this is a fork. Findings in forks often duplicate the upstream and "
                    "inflate counts."
                ),
            },
            "is_template": {"data_type": "BOOLEAN", "category": "Repository Status",
                "semantic_description": (
                    "Whether it is a template others are generated from — a flaw here "
                    "propagates to every repository created from it."
                ),
            },
            "is_mirror": {"data_type": "BOOLEAN", "category": "Repository Status",
                "semantic_description": (
                    "True when this repository mirrors another upstream repository rather than being an "
                    "original codebase. ⛔ Mirrors duplicate findings from their upstream, so counting them "
                    "as owned code inflates both the estate and its vulnerability totals."
                ),
            },
            "is_private": {"data_type": "BOOLEAN", "category": "Repository Status",
                "semantic_description": (
                    "Whether access is restricted. Overlaps with `visibility`; prefer "
                    "`visibility`, which carries the three-way distinction."
                ),
            },
            "license_name": {"data_type": "VARCHAR(100)", "category": "License & Legal",
                "semantic_description": (
                    "The repository's declared licence in human-readable form, as the hosting platform "
                    "reports it. NULL means no licence was detected, which is not the same as being "
                    "unlicensed in the legal sense."
                ),
            },
            "license_key": {"data_type": "VARCHAR(50)", "category": "License & Legal",
                "semantic_description": (
                    "The platform's short key for that licence."
                ),
            },
            "license_url": {"data_type": "VARCHAR(1000)", "category": "License & Legal",
                "semantic_description": (
                    "Link to the full text of the repository's declared licence, where the hosting platform "
                    "supplies one."
                ),
            },
            "license_spdx_id": {"data_type": "VARCHAR(50)", "category": "License & Legal",
                "semantic_description": (
                    "SPDX identifier — the machine-comparable form of the licence."
                ),
            },
            "is_open_source": {"data_type": "BOOLEAN", "category": "License & Legal",
                "semantic_description": (
                    "Whether the licence is an open-source one."
                ),
            },
            "owner_id": {"data_type": "VARCHAR(255)", "category": "Ownership & Organization",
                "semantic_description": (
                    "Identifier of the repository's owner on the hosting platform, which may be a user or "
                    "an organisation. Platform-specific, and not a Torana identity id — join to "
                    "`identities` on the platform's own key, never on this column directly."
                ),
            },
            "owner_name": {"data_type": "VARCHAR(255)", "category": "Ownership & Organization",
                "semantic_description": (
                    "The owning user or org, as the hosting platform names it. This is the "
                    "PLATFORM's owner — not a declared accountable person. Use it as a hint "
                    "toward ownership, never as the answer to who must fix a finding."
                ),
            },
            "owner_type": {"data_type": "VARCHAR(50)", "category": "Ownership & Organization",
                "semantic_description": (
                    "Whether the platform owner is a user or an organization."
                ),
            },
            "owner_email": {"data_type": "VARCHAR(255)", "category": "Ownership & Organization",
                "semantic_description": (
                    "The owner's email. Empty on all 59 T1 repositories."
                ),
            },
            "teams": {"data_type": "JSON", "category": "Collaborators & Access",
                "semantic_description": (
                    "Teams with access on the hosting platform. Access is not accountability — "
                    "a team here can read the code without owning its findings."
                ),
            },
            "parent_repository_id": {"data_type": "VARCHAR(255)", "category": "Repository Relationships",
                "semantic_description": (
                    "The repository this was forked from, by id."
                ),
            },
            "parent_repository_name": {"data_type": "VARCHAR(500)", "category": "Repository Relationships",
                "semantic_description": (
                    "Name of the repository this one was forked from, where the platform reports a parent. "
                    "Present only for forks, and is what distinguishes a fork from an original codebase."
                ),
            },
            "secret_scanning_enabled": {"data_type": "BOOLEAN", "category": "Security Configuration",
                "semantic_description": (
                    "Whether the platform scans commits for credentials. When off, exposed "
                    "secrets go unnoticed rather than absent."
                ),
            },
            "dependency_security_updates_enabled": {"data_type": "BOOLEAN", "category": "Security Configuration",
                "semantic_description": (
                    "Whether automated dependency fix PRs are enabled."
                ),
            },
            "advanced_security_enabled": {"data_type": "BOOLEAN", "category": "Security Configuration",
                "semantic_description": (
                    "Whether the platform's advanced security features are on."
                ),
            },
            "vm_vulnerability_alerts_enabled": {"data_type": "BOOLEAN", "category": "Vulnerability Management",
                "semantic_description": (
                    "Whether the platform raises dependency alerts."
                ),
            },
            "vm_scan_enabled": {"data_type": "BOOLEAN", "category": "Vulnerability Management",
                "semantic_description": (
                    "Whether vulnerability scanning is configured for this repository."
                ),
            },
            "vm_has_scan_results": {"data_type": "BOOLEAN", "category": "Vulnerability Management",
                "semantic_description": (
                    "Whether any scan has produced results. Configured-but-never-run is a "
                    "distinct state from clean."
                ),
            },
            "criticality_name": {"data_type": "VARCHAR(20)", "category": "Risk & Security Posture",
                "semantic_description": (
                    "How much this repository matters to the business. DECLARED — no scanner can "
                    "infer it. Empty on all 59 T1 repositories."
                ),
            },
            "criticality_level": {"data_type": "INTEGER", "category": "Risk & Security Posture",
                "semantic_description": (
                    "Numeric form of `criticality_name` for this repository, kept for ordering and "
                    "comparison. ⚠️ Two columns holding ONE fact — set them together or set neither, since "
                    "a query reading only one of them silently disagrees with a query reading the other."
                ),
            },
            "stars_count": {"data_type": "INTEGER", "category": "Repository Metrics",
                "semantic_description": (
                    "Stars on the platform. For third-party code, a rough popularity signal; "
                    "for internal code, meaningless."
                ),
            },
            "watchers_count": {"data_type": "INTEGER", "category": "Repository Metrics",
                "semantic_description": (
                    "Number of accounts watching this repository on its hosting platform. A popularity "
                    "signal, not a security one; useful mainly to gauge whether a repository is actively "
                    "followed."
                ),
            },
            "forks_count": {"data_type": "INTEGER", "category": "Repository Metrics",
                "semantic_description": (
                    "Number of times this repository has been forked on its hosting platform. Indicates "
                    "reuse breadth — a widely-forked repository propagates its vulnerabilities to every "
                    "fork."
                ),
            },
            "issues_count": {"data_type": "INTEGER", "category": "Repository Metrics",
                "semantic_description": (
                    "Number of OPEN issues on this repository as its hosting platform reports it. ⚠️ Counts "
                    "the platform's own issue tracker, and is unrelated to rows in Torana's `issues` table, "
                    "which may come from a different tracking system entirely."
                ),
            },
            "last_commit_date": {"data_type": "TIMESTAMP", "category": "Activity Metrics",
                "semantic_description": (
                    "Most recent commit. Old code with open findings is often abandoned rather "
                    "than accepted."
                ),
            },
            "last_push_date": {"data_type": "TIMESTAMP", "category": "Activity Metrics",
                "semantic_description": (
                    "When code was most recently pushed to this repository. The primary evidence of whether "
                    "a codebase is still maintained, as distinct from merely still existing."
                ),
            },
            "last_activity_date": {"data_type": "TIMESTAMP", "category": "Activity Metrics",
                "semantic_description": (
                    "Most recent activity of any kind on this REPOSITORY — the signal for whether anyone "
                    "would notice a fix PR. ⚠️ Distinct from `identities.last_activity_date`, which records "
                    "what a principal did rather than what happened to a codebase."
                ),
            },
            "tags": {"data_type": "JSON", "category": "Tags & Metadata",
                "semantic_description": (
                    "Platform tags applied to the repository."
                ),
            },
            "custom_properties": {"data_type": "JSON", "category": "Tags & Metadata",
                "semantic_description": (
                    "Custom properties set on the platform. Often where an org encodes "
                    "ownership before declaring it properly."
                ),
            },
            "metadata": {"data_type": "JSON", "category": "Tags & Metadata",
                "semantic_description": (
                    "Additional metadata carried from the source."
                ),
            },
            "repo_created_date": {"data_type": "TIMESTAMP", "category": "Lifecycle & Management",
                "semantic_description": (
                    "When the repository was created on its hosting platform. ⚠️ Not `created_at`, which is "
                    "when Torana first ingested the row."
                ),
            },
            "repo_updated_date": {"data_type": "TIMESTAMP", "category": "Lifecycle & Management",
                "semantic_description": (
                    "When the repository's metadata last changed on its hosting platform. ⚠️ Changes on "
                    "metadata edits (description, topics, settings), so it is NOT evidence of code activity "
                    "— use `repo_pushed_date` or `last_push_date` for that."
                ),
            },
            "repo_pushed_date": {"data_type": "TIMESTAMP", "category": "Lifecycle & Management",
                "semantic_description": (
                    "When code was last pushed to this repository, as its hosting platform reports it. "
                    "Unlike `repo_updated_date`, this moves only on actual code activity."
                ),
            },
            "repo_maintenance_status": {"data_type": "VARCHAR(50)", "category": "Lifecycle & Management",
                "semantic_description": (
                    "Whether the repository is actively maintained."
                ),
            },
            "created_by": {
                "data_type": "VARCHAR(255)", "category": "Audit & Tracking",
                "semantic_description": (
                    "The Torana user or service principal that caused this repository row to be written — in "
                    "practice the integration that ingested it (`github_integration`, `jira_integration`). "
                    "⚠️ An INGEST-side actor, NOT the owner of the thing described: do not read it as "
                    "'who is responsible for this'."
                ),
            },
            "created_via": {"data_type": "VARCHAR(100)", "category": "Audit & Tracking",
                "semantic_description": (
                    "The Torana mechanism that wrote this repository row — an integration sync, a replay, a "
                    "manual push, or a synthetic dataset load. ⛔ Provenance, not repository data: it is "
                    "what separates genuinely ingested rows from generated ones, and a query measuring a "
                    "real estate should know which values are synthetic."
                ),
            },
            "dataset_tag": {"data_type": "VARCHAR(200)", "category": "Audit & Tracking",
                "semantic_description": (
                    "Marks this repository row as seeded by a NAMED synthetic dataset rather than a live "
                    "integration, so such rows can be purged as a set. NULL for genuinely ingested rows. ⛔ "
                    "Filter it out when measuring a real estate — counting demo rows as production "
                    "repository data is the error this column exists to prevent."
                ),
            },
        }