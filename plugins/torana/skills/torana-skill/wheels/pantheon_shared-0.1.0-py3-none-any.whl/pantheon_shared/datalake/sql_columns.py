"""SQL column extraction — WHICH COLUMNS DOES THIS QUERY READ, AND WHICH FILTER ROWS?

⛔ MOVED HERE FROM `pantheon-datalake` (2026-08-17), and the move is the point.

This parse answers two questions that several services independently need:

  refs          every (table, column) the SQL reads
  row_filtered  the subset used as a ROW FILTER (a WHERE predicate) rather than a
                projection — the distinction between "one cell shows blank" and
                "every row disappears"

⚠️ THERE WERE ALREADY TWO PARSERS BEFORE THIS MOVE, and that is the argument for it.
The authoritative one lived inside `torana_datalake/api/routes/supply.py` and was NOT
exposed over HTTP (the `supply/diagnosis` endpoint takes ALREADY-PARSED column names),
so `pantheon-cli` grew its own weaker copy — `_extract_column_refs` — which does not
compute `row_filtered` at all. A third caller would have meant a third parser, and
two definitions of "which columns does this SQL read" is exactly how a gate ends up
silently checking a different set than the one it reports on.

⛔ ONE DEFINITION. `supply.py` imports from here; so does the bundle install shape
check. Do not re-implement it in a caller — extend it here.

⚠️ It is INTENTIONALLY a regex/lexical parse, not a full SQL grammar. It runs on
untrusted authored SQL in a request path and must never hang or raise; every branch
degrades to "reported, not resolved" rather than failing. Read the inline notes before
tightening anything — several of them record a measured mis-parse that a "more
correct" rule reintroduced.
"""
from typing import Any, Dict, List, Set, Tuple

import re

# ─────────────────────────────────────────────────────────────────────────────
# ⛔ SQL → column refs. ONE copy, server-side.
#
# ⚠️ Moved here from pantheon-viz so the playground, the widget path and any
# future caller resolve columns the SAME way. § 3.4.0 puts the traversal in one
# place for exactly this reason; a second extractor in TypeScript (which the FE
# would otherwise need, having only raw SQL) is the fourth copy the spec exists
# to prevent — and it would drift from this one silently.
#
# ⛔ CONSERVATIVE BY DESIGN — resolves only what it can prove and SKIPS the
# rest. An unqualified column attributed to the wrong table produces a
# confident, wrong verdict about a column the query never reads, which is worse
# than showing nothing because nobody investigates a confident answer.
# ─────────────────────────────────────────────────────────────────────────────

_NOT_AN_ALIAS = {
    "on", "where", "group", "order", "having", "limit", "join", "inner", "left",
    "right", "full", "outer", "cross", "union", "select", "using", "and", "or",
    "qualify", "window", "offset", "fetch",
}

#: ⚠️ Words that appear in `<word>.<word>` position but are NOT a table
#: qualifier. Without this, `false)` style casts and schema prefixes leak in.
_SQL_FUNCS = {"coalesce", "cast", "nullif", "greatest", "least"}

#: ⚠️ SQL reserved words that must never be mistaken for a column in the
#: single-table unqualified pass. ⛔ Deliberately generous: a false NEGATIVE
#: (missing a column) under-reports, while a false POSITIVE invents a column the
#: table does not have and produces UNREACHABLE — "Torana does not collect
#: this" — about something that was never a column at all.
_SQL_RESERVED = {
    "select", "from", "where", "and", "or", "not", "null", "is", "in", "as",
    "on", "join", "left", "right", "inner", "outer", "full", "cross", "using",
    "group", "by", "order", "having", "limit", "offset", "fetch", "asc",
    "desc", "distinct", "case", "when", "then", "else", "end", "true",
    "false", "union", "all", "with", "over", "partition", "window", "between",
    "like", "ilike", "exists", "any", "some", "count", "sum", "avg", "min",
    "max", "cast", "interval", "current_date", "current_timestamp", "now",
    "date", "extract", "int", "integer", "text", "boolean", "numeric", "float",
    "timestamp", "varchar", "qualify", "row_number", "rank", "dense_rank",
    "lag", "lead", "first_value", "last_value", "nulls", "first", "last",
    "coalesce", "nullif", "greatest", "least", "abs", "round", "floor", "ceil",
    "concat", "substring", "trim", "lower", "upper", "length", "replace",
    "array", "unnest", "jsonb", "json", "day", "days", "month", "year", "hour",
    # ⛔ ADDED after measuring 202 fake column references on T1 (S7 row 17).
    # `FILTER` is the standard Postgres aggregate filter — `COUNT(*) FILTER
    # (WHERE ...)` appears in transformers across the estate, and its absence
    # here invented `assets.filter`, `issues.filter` and `identities.filter`,
    # each reported to the user as "Torana does not collect this yet".
    "filter",
    # ⚠️ Date/interval helpers seen invented as columns on T1:
    # `date_trunc('week', ...)` → `prioritized_vulnerabilities.date_trunc`,
    # and `EXTRACT(EPOCH FROM ...)` → `.epoch`.
    "date_trunc", "epoch", "week", "weeks", "quarter", "minute", "second",
    "age", "to_char", "to_date", "make_interval", "justify_interval",
    # ⚠️ Set/predicate keywords that are not columns.
    "intersect", "except", "ilike", "similar", "escape", "collate",
    "returning", "values", "recursive", "lateral", "ordinality",
    "percentile_cont", "percentile_disc", "within", "stddev", "variance",
    "bool_and", "bool_or", "string_agg", "array_agg", "jsonb_agg",
}


def _strip_calls(text: str, names: Tuple[str, ...]) -> str:
    """Remove `NAME( ... )` spans, matching parentheses so NESTED calls are covered.

    ⛔ WHY NOT A REGEX. `re.sub(r"filter\\s*\\([^()]*\\)", ...)` cannot cross a nested
    call: it strips `FILTER (WHERE x IS NOT NULL)` but leaves
    `FILTER (WHERE x IS NOT NULL AND x < NOW())` standing, because `NOW()` closes the
    character class early. The surviving fragment then looks like an ordinary WHERE
    and the column is misreported as row-filtering.

    ⚠️ These wrappers are stripped because the columns inside them SHAPE A VALUE and
    cannot DROP A ROW — `COUNT(*) FILTER (WHERE kev)` returns 0, not zero rows. The
    whole point of the distinction is that "the widget shows a 0" and "the widget
    shows nothing" are different answers with different owners.

    Conservative in the SAFE direction: an unbalanced or runaway span is left alone,
    so anything not confidently a wrapper is still treated as row-filtering.
    """
    out = text
    for name in names:
        pattern = re.compile(rf"\b{name}\s*\(", re.I)
        # Repeat until stable: one pass removes the outermost span, and an argument
        # may itself contain another call of the same name.
        for _ in range(8):
            m = pattern.search(out)
            if not m:
                break
            depth, i, n = 0, m.end() - 1, len(out)
            end = -1
            while i < n:
                ch = out[i]
                if ch == "(":
                    depth += 1
                elif ch == ")":
                    depth -= 1
                    if depth == 0:
                        end = i
                        break
                i += 1
            if end == -1:            # unbalanced -> leave it, fail safe
                break
            out = out[:m.start()] + " " + out[end + 1:]
    return out


#: ⛔ A DOUBLE-QUOTED IDENTIFIER IS **ONE** IDENTIFIER, SPACES AND ALL.
#: ⚠️ MEASURED 2026-09-07 on a shipped Classie widget: every scan in this file
#: uses `[a-zA-Z_][\w]*`, which cannot match an opening quote and cannot match a
#: space. So `... END AS "Kind of package"` was (1) never registered as an output
#: alias, and then (2) re-read by the bare-word pass as THREE columns of the FROM
#: table — `kind`, `of`, `package` — each reported to the customer as
#: "Torana does not collect this". Two quoted aliases invented FIVE phantom
#: columns on one widget, and the same blind spot hid quoted TABLE names
#: entirely (`FROM "My Table" t` resolved to no_tables_found).
#:
#: ⛔ MASK, DON'T PATCH EIGHT REGEXES. Rewriting each pattern to accept an
#: optional quoted form would leave eight places to keep in step, and any one
#: missed re-opens the same false positive. Instead every quoted identifier is
#: replaced ONCE, up front, by an opaque placeholder that DOES match
#: `[a-zA-Z_][\w]*` — so every existing scan treats it atomically and correctly
#: without knowing quoting exists — and the real text is restored on the way out.
_QUOTED_IDENT_RE = re.compile(r'"((?:[^"]|"")*)"')

#: The placeholder shape. ⚠️ Must match `[a-zA-Z_][\w]*` (so the existing scans
#: see one identifier) and must be lowercase-stable (the scans lowercase every
#: word before comparing it against `_SQL_RESERVED` and the alias maps).
_QUOTED_PLACEHOLDER = "__qtd{}__"
_QUOTED_PLACEHOLDER_RE = re.compile(r"^__qtd(\d+)__$")


def _mask_quoted_identifiers(text: str) -> Tuple[str, List[str]]:
    """Replace every ``"quoted identifier"`` with an opaque single-word token.

    Returns the masked text plus the ordered original identifiers, so a
    placeholder that survives to the output can be turned back into the name the
    author actually wrote.

    ⚠️ SINGLE-QUOTED STRING LITERALS ARE SKIPPED. `'it''s "quoted"'` is a VALUE,
    and the double quotes inside it are ordinary characters — masking them would
    invent an identifier out of string data. The scan therefore walks the text
    and steps over `'...'` spans (respecting the doubled-quote escape) rather
    than matching double-quoted runs globally.

    ⚠️ `""` is SQL's escape for a literal quote INSIDE a quoted identifier, so it
    does not close the identifier — hence `(?:[^"]|"")*`.

    Conservative in the SAFE direction: an UNTERMINATED quote masks nothing and
    the text is returned unchanged, leaving the old (imperfect) behaviour rather
    than swallowing the rest of the query.
    """
    # ⛔ CONTENT-ADDRESSED, not positional. ⚠️ MEASURED: numbering each
    # occurrence separately gave `WITH "My CTE" AS (…) … FROM "My CTE"` two
    # DIFFERENT tokens, so the CTE-name scan registered one and the FROM scan
    # saw the other as an unknown TABLE — reintroducing the fake-table leak the
    # cte_names block exists to prevent. Identical identifiers must mask
    # identically, exactly as identical bare words already do.
    originals: List[str] = []
    index: Dict[str, int] = {}
    out: List[str] = []
    i, n = 0, len(text)
    while i < n:
        ch = text[i]
        if ch == "'":
            # step over a string literal whole, doubled-quote escape included
            j = i + 1
            while j < n:
                if text[j] == "'":
                    if j + 1 < n and text[j + 1] == "'":
                        j += 2
                        continue
                    j += 1
                    break
                j += 1
            out.append(text[i:j])
            i = j
            continue
        if ch == '"':
            m = _QUOTED_IDENT_RE.match(text, i)
            if m:
                # `""` inside the identifier is one literal quote character.
                name = m.group(1).replace('""', '"')
                idx = index.get(name)
                if idx is None:
                    idx = len(originals)
                    index[name] = idx
                    originals.append(name)
                out.append(_QUOTED_PLACEHOLDER.format(idx))
                i = m.end()
                continue
            # unterminated — leave it alone, fail safe
        out.append(ch)
        i += 1
    return "".join(out), originals


def _unmask(word: str, originals: List[str]) -> str:
    """Placeholder → the identifier the author wrote; anything else unchanged."""
    m = _QUOTED_PLACEHOLDER_RE.match(word)
    if not m:
        return word
    idx = int(m.group(1))
    return originals[idx] if idx < len(originals) else word


def _is_placeholder(word: str) -> bool:
    return _QUOTED_PLACEHOLDER_RE.match(word) is not None


def _scoped_columns(sql: str):
    """The (table, column) reads resolved PER SELECT SCOPE, or None if the SQL does not
    parse as one statement (the regex pass then stands alone).

    ⛔ WHY (Classie 2026-09-30): the regex pass maps aliases once per query, so
    `FROM assigned a` in one CTE and `FROM assets a` in another made the CTE's
    `a.finding_key` an `assets` read (56 phantom NO_SUCH_COLUMN reads on
    posture_scanner_reports). And with two or more tables ANYWHERE in the query it
    skipped every unqualified column ("bare column names not checked" on 4 of Classie's 8
    rules), even when the column's own SELECT reads one table.
    Here each column is resolved against ITS OWN SELECT's FROM/JOINs (then the enclosing
    ones, for a correlated reference): a base-table source is a read; a CTE or derived
    table is not (its base reads are counted where it reads them); an unqualified column
    is attributed only when its scope has exactly one source, else counted as skipped.
    Returns (refs in first-seen order, skipped count, row-filtering reads, base tables).

    ⛔ The base tables come from the PARSE TREE too (T-18). The regex table scan takes
    the word after every `FROM`/`JOIN`, so `LEFT JOIN LATERAL (…)` named a table
    `lateral` and `FROM generate_series(…)` one called `generate_series`. `supply.py`
    calls a COUNT(*) widget healthy only when EVERY table has pg_stats, and a keyword
    never has any, so a widget it parsed perfectly well fell to `undetermined`. A table
    here is an `exp.Table` with a name that is not a CTE, the same test
    `supply._reads_no_relation` applies; a quoted name keeps its spelling.
    """
    try:
        import sqlglot
        from sqlglot import exp
        from pantheon_shared.sql.lineage import _ScopeResolver, _own_sources
        trees = [t for t in sqlglot.parse(sql, read="postgres") if t is not None]
    except Exception:  # noqa: BLE001 — unparseable: the regex pass stands alone
        return None
    if len(trees) != 1:
        return None
    tree = trees[0]
    # ⛔ ONLY A QUERY IS OURS TO ANSWER (T-22). The column walk below resolves a column
    # against its enclosing SELECT, so in `DELETE … WHERE severity = …` it finds no SELECT
    # and returns NO reads — an empty answer that looks exactly like a COUNT(*)'s
    # genuinely empty one. sqlglot also parses syntax it does not know (`VACUUM t`) into an
    # `exp.Command` without raising. Either way "parsed" is not "understood", so anything
    # that is not a query falls back to the regex pass instead of claiming it reads nothing.
    # A `CREATE … AS <query>` is read as the query it runs: the relation it creates is
    # written, never read, so it is not one of the query's tables either. (Without this,
    # `CREATE TEMP VIEW v AS SELECT id FROM t` fell to the regex, which read `create`,
    # `temp`, `view` and `v` as columns of `t`.)
    if isinstance(tree, exp.Create) and isinstance(tree.expression, exp.Query):
        tree = tree.expression
    if not isinstance(tree, exp.Query):
        return None
    cte_names = {(c.alias_or_name or "").lower() for c in tree.find_all(exp.CTE)
                 if c.alias_or_name}
    refs: List[Tuple[str, str]] = []
    seen: Set[Tuple[str, str]] = set()
    skipped: Set[str] = set()
    filtering: Set[Tuple[str, str]] = set()
    local_of: Dict[int, Dict[str, Tuple[str, object]]] = {}
    resolver = _ScopeResolver(tree)

    def _local(sel):
        if id(sel) not in local_of:
            local_of[id(sel)] = _own_sources(sel, cte_names)
        return local_of[id(sel)]

    def _spelled(ident, name: str) -> str:
        """The author's spelling for a QUOTED identifier, lowercase otherwise."""
        return name if isinstance(ident, exp.Identifier) and ident.quoted else name.lower()

    # ⛔ A QUOTED NAME KEEPS ITS SPELLING (T-25). Matching runs on lowercase keys, so
    # `_own_sources` hands back `"My Table"` as `my table` and every read of
    # `"Odd Column"` came out as `odd column` — a case-sensitive Postgres name naming a
    # different column than the query reads, so /supply diagnosed the wrong one. The
    # regex pass kept the spelling; the 37001ec scope pass (2026-09-30) silently
    # dropped it. Lowercase stays the KEY; only the emitted name is restored.
    # ⛔ …AND THAT INCLUDES A COLUMN REACHED THROUGH A CTE OR DERIVED TABLE (T-22). Those
    # come from `_ScopeResolver` in lineage.py, which keys on lowercase (it also drives
    # lineage, so it is left alone), and the same `p."Odd Column"` came out TWICE: once
    # spelled, read straight off `packages` inside the CTE, and once as `odd column`,
    # followed through the CTE from outside it. See `_respell` below.
    tables: List[str] = []
    table_spelling: Dict[str, str] = {}
    for t in tree.find_all(exp.Table, bfs=False):
        tname = t.name or ""
        if not tname or tname.lower() in cte_names:
            continue                        # a table function, or a CTE
        tname = _spelled(t.this, tname)
        table_spelling.setdefault(tname.lower(), tname)
        if tname not in tables:
            tables.append(tname)

    # Every read is collected first and emitted after, because `_respell` needs ALL the
    # direct reads before it can respell a followed one, whatever order the walk visits.
    found: List[Tuple[object, List[Tuple[str, str]], bool, bool]] = []
    direct: Dict[Tuple[str, str], List[str]] = {}

    for c in tree.find_all(exp.Column):
        if isinstance(c.this, exp.Star):
            continue
        name = (c.name or "").lower()
        sel = c.find_ancestor(exp.Select)
        if not name or sel is None:
            continue
        q = (c.table or "").lower()
        src = None
        if q:
            scope = sel
            while scope is not None and src is None:
                src = _local(scope).get(q)
                scope = scope.find_ancestor(exp.Select) if src is None else scope
        else:
            outputs = {(e.alias_or_name or "").lower() for e in sel.expressions
                       if isinstance(e, exp.Alias)}
            if name in outputs and c.find_ancestor(exp.Order, exp.Group, exp.Having):
                continue                    # a reference to this SELECT's own output
            sources = list(dict.fromkeys(_local(sel).values()))
            if len(sources) == 1:
                src = sources[0]
            elif len(sources) > 1:
                skipped.add(name)
                continue
        if src is None:
            continue
        followed = src[0] != "table"
        if not followed:
            pairs = [(table_spelling.get(str(src[1]), str(src[1])),
                      _spelled(c.this, c.name))]
            spellings = direct.setdefault((pairs[0][0].lower(), pairs[0][1].lower()), [])
            if pairs[0][1] not in spellings:
                spellings.append(pairs[0][1])
        else:
            # ⛔ A CTE/derived output is followed to the base columns behind it, so a
            # column carried by a star (`SELECT f.* FROM posture_findings f`) is still
            # counted as a read of `posture_findings`. Dropping it would lose a real
            # dependency and could report healthy what is blocked.
            pairs = [(t, col) for t, cs in resolver.column_of(src, name, frozenset()).items()
                     for col in sorted(cs)]
        in_pred = c.find_ancestor(exp.Where, exp.Having)
        filters_rows = (in_pred is not None and in_pred.find_ancestor(exp.Select) is sel
                        and c.find_ancestor(exp.Coalesce, exp.Filter) is None)
        found.append((c, pairs, followed, filters_rows))

    def _respell(c, table: str, col: str) -> str:
        """The spelling of a column FOLLOWED through a CTE/derived table (`col` arrives
        lowercase). ⛔ Never invents a spelling, it only picks one the query wrote:
        1. the outer name, when it is quoted and IS this column (carried by a star, where
           nothing inside the CTE names it at all);
        2. otherwise the spelling of the direct read of the same base column (an explicit
           projection always has one), so the pair matches the one already emitted.
        A table read as both `"Odd"` and `odd` has two direct spellings; both are already
        emitted, so either choice adds nothing new."""
        have = direct.get((table.lower(), col), [])
        if (isinstance(c.this, exp.Identifier) and c.this.quoted
                and c.name.lower() == col and (not have or c.name in have)):
            return c.name
        if col in have or not have:
            return col
        return have[0]

    for c, pairs, followed, filters_rows in found:
        if followed:
            pairs = [(table_spelling.get(t, t), _respell(c, t, col)) for t, col in pairs]
        for pair in pairs:
            if pair not in seen:
                seen.add(pair)
                refs.append(pair)
            if filters_rows:
                filtering.add(pair)
    return refs, len(skipped), filtering, tables


def extract_sql_columns(sql: str) -> Tuple[List[Tuple[str, str]], Dict[str, Any]]:
    """SQL text → the (table, column) pairs it reads, plus what we could NOT read.

    ⛔ RETURNS ITS OWN LIMITS. The second element is not decoration: a caller
    that cannot tell "this query reads nothing risky" from "we could not read
    this query" will report the second as the first, which is the
    confident-wrong-answer bug this whole surface exists to remove.

    Two resolution modes, and the second is what makes this usable on REAL
    artifacts:

    1. **Qualified** — ``alias.column`` where the alias maps to a FROM/JOIN
       table, or the qualifier IS a table name. Always safe.

    2. ⛔ **Unqualified, SINGLE-TABLE ONLY** — a bare ``column`` in a query with
       exactly ONE table in FROM/JOIN is unambiguously that table's.
       ⚠️ MEASURED, and this is why the mode exists: every one of the 26 rules
       on T1 is single-table with unqualified columns, so a qualified-only
       extractor returns ZERO columns for ALL of them and the artifact
       diagnosis silently passes every rule it is given. That is worse than not
       shipping it.

    ⛔ With TWO OR MORE tables, unqualified columns are SKIPPED, never guessed,
    and the skip is REPORTED. Attributing a column to the wrong table produces
    a confident verdict about a column the query never reads.
    """
    text = re.sub(r"--[^\n]*", " ", sql or "")
    text = re.sub(r"/\*.*?\*/", " ", text, flags=re.S)

    # ⛔ QUOTED IDENTIFIERS BECOME ONE OPAQUE WORD BEFORE ANY SCAN RUNS. Every
    # pattern below is `[a-zA-Z_][\w]*`, which cannot match a quote or a space;
    # masking is what makes all of them quoted-aware at once. Names are restored
    # at the two output points (the refs list and `predicated`). See
    # `_mask_quoted_identifiers`.
    text, _quoted = _mask_quoted_identifiers(text)

    # ⛔ STRING LITERALS ARE DATA, NEVER TABLES OR COLUMNS — remove them before any
    # scan runs. Every pattern below looks for bare words after `from`/`join`, and a
    # literal is just words; left in place, a sentence a human wrote as a column VALUE
    # is read as schema.
    #
    # ⚠️ MEASURED 2026-09-08 on the shipped `classie_em` v5 bundle, three widgets:
    #
    #     'You only pull from it'                    → invented a table `it`
    #     'Whether it is reachable from outside'     → invented a table `outside`
    #
    # ⛔ The damage is out of all proportion to the cause. A phantom table pushes a
    # genuinely SINGLE-TABLE query into the two-or-more-tables branch below, where
    # unqualified columns are correctly skipped rather than guessed — so `refs` comes
    # back EMPTY and the caller reports "we could not read which columns this query
    # depends on" about a query it parsed perfectly well. Three of forty widgets
    # carried a grey `Unknown` health badge beside a correct number.
    #
    # ⚠️ Order is deliberate: this runs AFTER `_mask_quoted_identifiers`, which is
    # already literal-aware and steps over `'...'` spans. Running it FIRST would
    # corrupt a legal quoted identifier containing an apostrophe (`"it\'s"`), whose
    # apostrophe would open a literal span that never closes where intended.
    #
    # `''` is SQL's escape for a quote inside a literal, so it does not close the
    # literal — hence `(?:[^\']|\'\')*`, mirroring the `""` rule above.
    text = re.sub(r"'(?:[^']|'')*'", " ", text)

    # ⛔ CTE NAMES ARE NOT SINK TABLES — strip them from consideration BEFORE
    # anything else. ⚠️ MEASURED on T1: `WITH backlog AS (...)` made `backlog`
    # look like a table, and every alias SELECTed out of it
    # (`backlog.open_critical`) resolved to a table that does not exist, so the
    # column came back UNREACHABLE — "Torana does not collect this" — about a
    # value the query itself computes. Two of the 202 fake references were
    # whole fake TABLES (`backlog`, `rate`) reached exactly this way.
    cte_names: Set[str] = {
        m.group(1).lower()
        for m in re.finditer(
            r"(?:\bwith\b|\bwith\s+recursive\b|,)\s*([a-zA-Z_][\w]*)\s+as\s*\(",
            text, flags=re.I)
    }
    # ⛔ …and the ALIASES a CTE is given at its use site. ⚠️ MEASURED: in
    # `FROM backlog b, rate r`, excluding only the CTE NAMES still let `b` and
    # `r` through as bare words, so a single-table query invented
    # `vulnerabilities.b` and `vulnerabilities.r`. Excluding the name without
    # its alias fixes the report and leaves the fault.
    for m in re.finditer(r"\b(?:from|join|,)\s+([a-zA-Z_][\w]*)\s+(?:as\s+)?([a-zA-Z_][\w]*)",
                         text, flags=re.I):
        if m.group(1).lower() in cte_names:
            alias = m.group(2).lower()
            if alias not in _NOT_AN_ALIAS:
                cte_names.add(alias)

    # ⛔ …and a DERIVED-TABLE alias: `FROM ( … ) t`. ⚠️ MEASURED on the widget
    # `Account Hygiene Summary`, whose SQL ends `) t ORDER BY ord` — `t` was
    # read as a bare column of the single FROM table and came back UNRESOLVED,
    # putting a "we could not trace this" line on a widget that is otherwise
    # fully traced. Same class as the CTE and SELECT-alias leaks: a name the
    # query DEFINES is never a column it READS.
    for m in re.finditer(r"\)\s*(?:as\s+)?([a-zA-Z_][\w]*)", text, flags=re.I):
        alias = m.group(1).lower()
        if alias not in _NOT_AN_ALIAS and alias not in _SQL_RESERVED:
            cte_names.add(alias)

    aliases: Dict[str, str] = {}
    tables: List[str] = []
    for m in re.finditer(
        r"\b(?:from|join)\s+([a-zA-Z_][\w]*)\s*(?:as\s+)?([a-zA-Z_][\w]*)?",
        text, flags=re.I,
    ):
        table = m.group(1).lower()
        alias = (m.group(2) or "").lower()
        # ⛔ A CTE is not a table we can make a supply claim about.
        if table in cte_names:
            continue
        # ⛔ A QUOTED TABLE NAME IS STILL A TABLE. ⚠️ MEASURED 2026-09-07:
        # `FROM "My Table" t` matched nothing at all, so the query resolved to
        # `no_tables_found` — the extractor reported it could read NOTHING about
        # a query it can read perfectly well. Masking makes the scan see one
        # word; this restores the author's spelling for the emitted name, since
        # a quoted table name is case-sensitive in Postgres.
        masked_table = table
        if _is_placeholder(table):
            table = _unmask(table, _quoted)
        if table not in tables:
            tables.append(table)
        aliases[table] = table
        # ⛔ Register the MASKED spelling too. Every scan below reads masked
        # text, so `"My Table".col` arrives as `__qtd0__.col` and would find no
        # qualifier without this — and the bare-word pass would emit the
        # placeholder itself as a column.
        aliases[masked_table] = table
        if alias and alias not in _NOT_AN_ALIAS:
            aliases[alias] = table

    # ⛔ OUTPUT ALIASES ARE NOT INPUT COLUMNS — collect them so mode 2 can skip
    # them. ⚠️ THIS IS THE DEFECT S7 § 2 MIS-DIAGNOSED. The brief reported
    # `prioritized_vulnerabilities.open_critical_prod` as a widget "querying a
    # phantom column"; the SQL is
    # `SELECT COUNT(*) AS open_critical_prod FROM prioritized_vulnerabilities`
    # — the name is what the query PRODUCES, never something it reads. The
    # widget was healthy and the extractor invented the fault.
    # ⛔ Reported as UNREACHABLE, i.e. "Torana does not collect this yet",
    # which is exactly the confident-wrong-answer this surface exists to
    # remove — so a false positive here is worse than a miss (see _SQL_RESERVED).
    select_aliases: Set[str] = {
        m.group(1).lower()
        for m in re.finditer(r"\bas\s+([a-zA-Z_][\w]*)\b", text, flags=re.I)
    } - set(aliases)

    seen: Set[Tuple[str, str]] = set()
    out: List[Tuple[str, str]] = []

    # -- mode 1: qualified ---------------------------------------------------
    qualified_positions: Set[str] = set()
    for m in re.finditer(r"\b([a-zA-Z_][\w]*)\.([a-zA-Z_][\w]*)\b", text):
        qual, col = m.group(1).lower(), m.group(2).lower()
        qualified_positions.add(col)
        table = aliases.get(qual)
        if not table or qual in _SQL_FUNCS:
            continue          # unresolvable qualifier — skip, NEVER guess
        # ⛔ A quoted column keeps the author's exact spelling — `"Odd Column"`
        # is a case-sensitive identifier in Postgres, and lowercasing it would
        # look up a different column than the query reads.
        col = _unmask(col, _quoted) if _is_placeholder(col) else col
        if (table, col) not in seen:
            seen.add((table, col))
            out.append((table, col))

    # -- mode 2: unqualified, single-table only ------------------------------
    unqualified_skipped = 0
    if len(tables) == 1:
        table = tables[0]
        # ⚠️ Strip the qualified pairs first so `a.col` does not also register
        # `col` as a bare name.
        bare = re.sub(r"\b[a-zA-Z_][\w]*\.[a-zA-Z_][\w]*\b", " ", text)
        # Drop string literals — 'high' is a value, not a column.
        bare = re.sub(r"'[^']*'", " ", bare)
        for m in re.finditer(r"\b([a-zA-Z_][\w]*)\b", bare):
            word = m.group(1).lower()
            if word in _SQL_RESERVED or word in _SQL_FUNCS:
                continue
            if word == table or word in aliases:
                continue
            # ⛔ Never report what the query PRODUCES as something it READS.
            if word in select_aliases or word in cte_names:
                continue
            word = _unmask(word, _quoted) if _is_placeholder(word) else word
            if (table, word) not in seen:
                seen.add((table, word))
                out.append((table, word))
    elif len(tables) > 1:
        # ⛔ Count what we are deliberately NOT resolving, and report it.
        bare = re.sub(r"\b[a-zA-Z_][\w]*\.[a-zA-Z_][\w]*\b", " ", text)
        bare = re.sub(r"'[^']*'", " ", bare)
        unqualified_skipped = len({
            m.group(1).lower() for m in re.finditer(r"\b([a-zA-Z_][\w]*)\b", bare)
            if m.group(1).lower() not in _SQL_RESERVED
            and m.group(1).lower() not in _SQL_FUNCS
            and m.group(1).lower() not in aliases
            # ⛔ An output alias was never an input, so counting it as
            # "skipped" overstates how much of the query we failed to read.
            and m.group(1).lower() not in select_aliases
            and m.group(1).lower() not in cte_names
        })

    # ⛔ WHICH COLUMNS ARE PREDICATED ON — needed by the § 3a "dead constant"
    # signal, which fires ONLY when a query FILTERS on a constant column.
    # ⚠️ S2 § 3a rule 1: a constant column merely SELECTed is harmless —
    # rendering `False` in a column is not a defect. Badging it would be the
    # 93%-false-alarm mistake in a new costume.
    #
    # Everything from the first WHERE/JOIN-ON/HAVING/GROUP BY onward is
    # predicate position. ⚠️ Deliberately COARSE and inclusive-of-the-tail: a
    # false negative here only means we stay quiet (the safe direction), while
    # a false positive puts a red mark on a healthy widget.
    predicated: Set[Tuple[str, str]] = set()
    pred_start = re.search(r"\b(where|having|on|group\s+by|filter)\b",
                           text, flags=re.I)
    if pred_start:
        ptext = text[pred_start.start():]
        for m in re.finditer(r"\b([a-zA-Z_][\w]*)\.([a-zA-Z_][\w]*)\b", ptext):
            t = aliases.get(m.group(1).lower())
            if t:
                predicated.add((t, m.group(2).lower()))
    # ⚠️ `predicated` still holds MASKED names here on purpose — the
    # row-filtering check below re-matches these names against the masked text,
    # and unmasking first would search for `Kind of package` in text that
    # contains only its placeholder. Unmasking happens once, at the very end.
        if len(tables) == 1:
            pbare = re.sub(r"\b[a-zA-Z_][\w]*\.[a-zA-Z_][\w]*\b", " ", ptext)
            pbare = re.sub(r"'[^']*'", " ", pbare)
            for m in re.finditer(r"\b([a-zA-Z_][\w]*)\b", pbare):
                w = m.group(1).lower()
                if (w not in _SQL_RESERVED and w not in _SQL_FUNCS
                        and w not in aliases and w not in select_aliases
                        and w not in cte_names and w != tables[0]):
                    predicated.add((tables[0], w))

    # ⛔ ROW-FILTERING vs merely PREDICATED — the distinction that separates
    # "returns nothing, ever" from "returns rows with an empty column".
    #
    # ⚠️ MEASURED, and the first cut of this got it wrong. `predicated` is TRUE
    # for a column anywhere after WHERE/JOIN-ON, which over-counts badly:
    #
    #   COUNT(*) FILTER (WHERE v.cisa_kev_data IS NOT NULL)  → shapes a COLUMN
    #   COALESCE(v.epss_score, 0)                            → NULL is DEFAULTED
    #
    # Neither can remove a row, so a missing value there leaves the query
    # returning exactly as many rows as before — just with a zero in one
    # column. Counting them as row filters made 30% of the estate report
    # "will not return anything" about queries that visibly return data
    # (`remediation_queue` renders a full table while claiming this).
    #
    # ⛔ So strip FILTER(...) aggregates and COALESCE(...) wrappers before
    # asking whether the column survives in the WHERE. Conservative in the SAFE
    # direction: anything still left is treated as row-filtering.
    # ⚠️ STRIP THE WRAPPERS FIRST, THEN find the WHERE. Doing it the other way
    # round misses a `COUNT(*) FILTER (WHERE x IS NOT NULL)` that sits in the
    # SELECT list — its inner WHERE then becomes the "first" WHERE and the real
    # predicate is never examined. Measured: kev_flag inside a FILTER
    # aggregate was still classed as row-filtering.
    # ⛔ BALANCED-PAREN STRIP, NOT `[^()]*`. A single `[^()]*` body cannot cross a
    # nested call, so `FILTER (WHERE x IS NOT NULL AND x < NOW())` was left standing
    # while the SIMPLE form `FILTER (WHERE x IS NOT NULL)` stripped cleanly. The
    # trailing AND-clause then leaked into the WHERE scan and the column was reported
    # as row-filtering.
    #
    # ⚠️ MEASURED 2026-08-17 on the shipped `ciso_posture` bundle: this produced a
    # FALSE "will be empty" warning for `identities.last_login_date`, whose widget
    # (`stale_disabled_accounts`) renders 2 rows — the exact confidently-wrong
    # answer this block already exists to prevent, reintroduced by the nesting case.
    _stripped = _strip_calls(text, ("filter", "coalesce"))
    row_filtered: Set[Tuple[str, str]] = set()
    # ⛔ AN OUTER JOIN'S `ON` CANNOT DROP A ROW FROM THE PRESERVED SIDE.
    # `LEFT JOIN r ON v.repo_id = r.repo_id` keeps every `v` row and NULLs the
    # right-hand columns when the key does not match — that is the entire point of
    # an outer join. An INNER join's ON genuinely does filter, so only the outer
    # forms are removed here.
    #
    # ⚠️ MEASURED 2026-08-17 on the shipped `ciso_posture` bundle: without this,
    # `vulnerabilities.torana_repository_id` (3 of 86,696 populated) was reported as
    # row-filtering because of a LEFT JOIN key, producing a "this will be empty"
    # warning about a relation that returns 86,693 rows.
    # ⚠️ The ON clause ends at the next clause KEYWORD, not at end-of-line. An
    # earlier cut used `[^\n]*` and swallowed the real `WHERE` on a single-line
    # query — turning a false POSITIVE into a false NEGATIVE, which is worse: the
    # warning silently stops firing for queries that genuinely return nothing.
    _stripped = re.sub(
        r"\b(?:left|right|full)(?:\s+outer)?\s+join\b.*?\bon\b"
        r"(?:(?!\b(?:where|having|group\s+by|order\s+by|limit|union|"
        r"left|right|full|inner|cross|join)\b).)*",
        " ", _stripped, flags=re.I | re.S)

    # ⛔ GROUP BY CHANGES THE GRAIN AND ORDER BY CHANGES THE ORDER — NEITHER CAN
    # REMOVE A ROW. Both were being scanned as row filters, because the body below
    # started at the first predicate keyword and then matched a column ANYWHERE in
    # the remaining text — which includes the whole GROUP BY / ORDER BY tail.
    #
    # ⚠️ MEASURED on Classie 2026-10-02, and it is the same confidently-wrong
    # direction the FILTER/COALESCE and outer-join strips above already guard.
    # `posture_mitigations.alert_priority` is used ONLY in `MIN(...)` and
    # `ORDER BY ... NULLS LAST`; `person_members` only in `COUNT(*) FILTER (...)`
    # and a `CASE WHEN`. Both were reported row-filtering, so `supply.py` set
    # `_blocks_rows`, kept `answerable = permanently_unanswerable`, and AI Home
    # told an operator that `Highest-Impact Remediation` and `Remediation Blast
    # Radius` "cannot return anything on this account" — while both widgets
    # RETURNED ROWS (1 and 2) on fresh data. A false "unanswerable" is as harmful
    # as a false "measured": the page can no longer say what is really blind.
    #
    #   GROUP BY  a NULL becomes its own GROUP; it is never dropped.
    #   ORDER BY  cannot remove anything, at all, ever.
    #
    # ⛔ EXCISE THE GROUP BY *LIST*, NOT EVERYTHING FROM `GROUP BY` ONWARD. A
    # HAVING always follows its GROUP BY and genuinely DOES drop groups, so
    # truncating at `group by` would silently stop the warning firing for a query
    # that really can return nothing — turning a false positive into a false
    # negative, which this module's own outer-join note calls the worse failure.
    # So the GROUP BY list ends at the next clause keyword, and a HAVING survives.
    _stripped = re.sub(
        r"\bgroup\s+by\b"
        r"(?:(?!\b(?:having|where|order\s+by|limit|offset|window|union|"
        r"intersect|except)\b).)*",
        " ", _stripped, flags=re.I | re.S)
    # ORDER BY runs to the end of its SELECT; LIMIT/OFFSET and the set operators
    # are the only things that can follow it, and none of them filters on a column.
    _stripped = re.sub(
        r"\border\s+by\b"
        r"(?:(?!\b(?:limit|offset|union|intersect|except)\b).)*",
        " ", _stripped, flags=re.I | re.S)

    # ⛔ A SELECT LIST CANNOT REMOVE A ROW EITHER — excise it, for the same reason as
    # GROUP BY / ORDER BY above. The body below runs from the FIRST predicate keyword
    # to the END of the text, so in a query with a CTE (or any earlier WHERE) every
    # later SELECT list sat inside it, and each column the outer query merely
    # DISPLAYED matched as a row filter.
    #
    # ⚠️ MEASURED on T2 2026-10-08: ROP's `rule_aging_tail` filters only on
    # `age_days`, but the outer `SELECT … is_patch_available, age_days FROM
    # aging_open_findings` followed the CTE's `WHERE age_days >= 90`. So
    # `is_patch_available` (NULL on all 14,052 rows) read as row-filtering, supply
    # called the rule `permanently_unanswerable`, and AI Home said "1 check cannot
    # fire" about a rule whose last run SUCCEEDED (it is quiet only because no finding
    # is yet 180 days old).
    #
    # ⚠️ Non-greedy to the FIRST `from`, so it errs SAFE: a scalar subquery or an
    # `EXTRACT(x FROM y)` in the list stops the strip early, and the remainder is
    # still scanned exactly as before — never fewer row filters than a real WHERE has.
    _stripped = re.sub(r"\bselect\b.*?\bfrom\b", " from ", _stripped, flags=re.I | re.S)

    # ⚠️ `group by` is no longer a body START — it is excised above, so a query
    # whose only predicate-shaped clause was a GROUP BY now correctly yields no
    # row filters at all.
    _pred_start = re.search(r"\b(where|having|on)\b", _stripped, flags=re.I)
    if _pred_start:
        _body = _stripped[_pred_start.start():]
        for t_, c_ in predicated:
            if re.search(rf"\b{re.escape(c_)}\b", _body, flags=re.I):
                row_filtered.add((t_, c_))

    # ⛔ NOW restore the author's spelling — after every masked-text match is done.
    predicated = {(t, _unmask(c, _quoted)) for t, c in predicated}
    row_filtered = {(t, _unmask(c, _quoted)) for t, c in row_filtered}

    limits: Dict[str, Any] = {
        "tables": tables,
        "predicated": sorted(f"{t}.{c}" for t, c in predicated),
        # ⛔ The subset that can actually zero the result set.
        "row_filtered": sorted(f"{t}.{c}" for t, c in row_filtered),
        "resolution": ("single_table_unqualified" if len(tables) == 1
                       else "qualified_only" if len(tables) > 1
                       else "no_tables_found"),
        # ⛔ Never silently drop. A consumer must be able to tell "clean" from
        # "we could not read most of this".
        "unqualified_columns_skipped": unqualified_skipped,
        # ⛔ ONLY WARN WHEN SOMETHING WAS ACTUALLY SKIPPED. ⚠️ MEASURED: a
        # multi-table query whose columns are ALL qualified skipped nothing, yet
        # still rendered "…were not checked. (0 column name(s) not checked)" —
        # a warning about the empty set. `prioritized_vulnerabilities` reads 4
        # tables, skipped 0, and showed it.
        # ⛔ A caveat that fires when there is nothing to caveat is noise, and
        # noise teaches the reader to ignore the line on the query where it IS
        # load-bearing — the same false-alarm failure § 3.17.3 measured for the
        # badge. The condition is what was SKIPPED, never how many tables there
        # are.
        "caveat": (
            "This query reads more than one table, so bare column names cannot "
            "be attributed to a table with certainty and were not checked."
            if unqualified_skipped > 0 else None
        ),
    }
    # ⭐ The scope pass, when the SQL parses, is the authority on WHICH columns are read
    # (see `_scoped_columns`). The regex pass keeps its hard-won predicate rules: a
    # row-filtering read it found survives when the scope pass confirms the read is real.
    #
    # ⛔ UNCONDITIONAL WHEN IT PARSED (T-22). The gate used to be `scoped[0] or not out`:
    # an EMPTY scope answer was overruled whenever the regex found anything. But the
    # queries whose honest answer is "no columns" are exactly COUNT(*) and `SELECT *`,
    # and on those the regex finds only what it invents:
    #
    #   WITH b AS (SELECT * FROM vulnerabilities) SELECT count(*) FROM b JOIN assets a ON true
    #     regex → tables ['vulnerabilities'] (assets DROPPED), and with one table its bare
    #             word pass read `assets` and `a` as COLUMNS of vulnerabilities
    #   SELECT count(*) FROM public.vulnerabilities
    #     regex → tables ['public'], refs ('public', 'vulnerabilities')
    #
    # Those refs reach every /supply column verdict, so /supply diagnosed reads the query
    # never makes, and the bogus `public` can never have pg_stats. The one thing the gate
    # guarded against, a parse that does not model the statement, is now refused inside
    # `_scoped_columns` (it returns None for anything that is not a query), so an empty
    # answer here means the parse tree read the query and found no columns.
    scoped = _scoped_columns(sql)
    if scoped is not None:
        s_refs, s_skipped, s_filter, s_tables = scoped
        real = set(s_refs)
        regex_rows = {tuple(x.split(".", 1)) for x in limits["row_filtered"]}
        # ⛔ UNION WITH THE SCOPE PASS, NEVER `r not in regex_refs`.
        #
        # `_scoped_columns` decides row-filtering from the PARSE TREE and counts a column
        # only when it sits under `exp.Where` / `exp.Having` in its own SELECT. That is
        # strictly better evidence than any regex, so when it says a column filters rows,
        # it does.
        #
        # ⚠️ The old condition was `r not in regex_refs`, where `regex_refs` is every
        # column the regex pass READ — not the ones it called row-filtering. So a scoped
        # filter survived only if the regex pass had never SEEN that column at all. For a
        # column the regex pass read but (correctly) no longer calls row-filtering, BOTH
        # branches dropped it and a genuine WHERE predicate vanished.
        #
        # ⚠️ MEASURED while narrowing the GROUP BY / ORDER BY rule above: on the shipped
        # `posture_findings` relation the parse tree names 17 row-filtering columns, and
        # the old merge returned only 1 of them — silently losing 16, including
        # `posture_runtime_context.image_is_running` and `posture_scanner_reports.status`,
        # every one of which really does sit in a WHERE. Losing a row filter is the
        # dangerous direction: `supply.py` then reports DEGRADED ("returns rows, some
        # fields empty") for a query that can genuinely return NOTHING — the same
        # confidently-wrong answer, pointing the other way.
        rows = {r for r in regex_rows if r in real} | set(s_filter)
        limits.update({
            # ⛔ The parse tree's tables, never the regex list (T-18; see `_scoped_columns`).
            "tables": s_tables,
            "predicated": sorted(x for x in limits["predicated"]
                                 if tuple(x.split(".", 1)) in real)
            + sorted(f"{t}.{c}" for t, c in s_filter
                     if f"{t}.{c}" not in limits["predicated"]),
            "row_filtered": sorted(f"{t}.{c}" for t, c in rows),
            "resolution": "scoped",
            "unqualified_columns_skipped": s_skipped,
            "caveat": ("Some bare column names read more than one table in their own "
                       "part of the query, so they cannot be attributed with certainty "
                       "and were not checked." if s_skipped > 0 else None),
        })
        return s_refs, limits
    return out, limits
