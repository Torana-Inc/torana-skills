"""SQL column extraction — WHICH COLUMNS DOES THIS QUERY READ, AND WHICH FILTER ROWS?

⛔ MOVED HERE FROM `pantheon-datalake` (2026-08-17), and the move is the point.

This parse answers two questions that several services independently need:

  refs          every (table, column) the SQL reads
  row_filtered  the subset used as a ROW FILTER (a WHERE predicate) rather than a
                projection — the distinction between "one cell shows blank" and
                "every row disappears"

⚠️ THERE WERE ALREADY TWO PARSERS BEFORE THIS MOVE, and that is the argument for it.
The authoritative one lived inside `torana_datalake/api/routes/supply.py` and was NOT
exposed over HTTP (the `supply/diagnosis` endpoint takes ALREADY-PARSED column names),
so `pantheon-cli` grew its own weaker copy — `_extract_column_refs` — which does not
compute `row_filtered` at all. A third caller would have meant a third parser, and
two definitions of "which columns does this SQL read" is exactly how a gate ends up
silently checking a different set than the one it reports on.

⛔ ONE DEFINITION. `supply.py` imports from here; so does the bundle install shape
check. Do not re-implement it in a caller — extend it here.

⚠️ It is INTENTIONALLY a regex/lexical parse, not a full SQL grammar. It runs on
untrusted authored SQL in a request path and must never hang or raise; every branch
degrades to "reported, not resolved" rather than failing. Read the inline notes before
tightening anything — several of them record a measured mis-parse that a "more
correct" rule reintroduced.
"""
from typing import Any, Dict, List, Set, Tuple

import re

# ─────────────────────────────────────────────────────────────────────────────
# ⛔ SQL → column refs. ONE copy, server-side.
#
# ⚠️ Moved here from pantheon-viz so the playground, the widget path and any
# future caller resolve columns the SAME way. § 3.4.0 puts the traversal in one
# place for exactly this reason; a second extractor in TypeScript (which the FE
# would otherwise need, having only raw SQL) is the fourth copy the spec exists
# to prevent — and it would drift from this one silently.
#
# ⛔ CONSERVATIVE BY DESIGN — resolves only what it can prove and SKIPS the
# rest. An unqualified column attributed to the wrong table produces a
# confident, wrong verdict about a column the query never reads, which is worse
# than showing nothing because nobody investigates a confident answer.
# ─────────────────────────────────────────────────────────────────────────────

_NOT_AN_ALIAS = {
    "on", "where", "group", "order", "having", "limit", "join", "inner", "left",
    "right", "full", "outer", "cross", "union", "select", "using", "and", "or",
    "qualify", "window", "offset", "fetch",
}

#: ⚠️ Words that appear in `<word>.<word>` position but are NOT a table
#: qualifier. Without this, `false)` style casts and schema prefixes leak in.
_SQL_FUNCS = {"coalesce", "cast", "nullif", "greatest", "least"}

#: ⚠️ SQL reserved words that must never be mistaken for a column in the
#: single-table unqualified pass. ⛔ Deliberately generous: a false NEGATIVE
#: (missing a column) under-reports, while a false POSITIVE invents a column the
#: table does not have and produces UNREACHABLE — "Torana does not collect
#: this" — about something that was never a column at all.
_SQL_RESERVED = {
    "select", "from", "where", "and", "or", "not", "null", "is", "in", "as",
    "on", "join", "left", "right", "inner", "outer", "full", "cross", "using",
    "group", "by", "order", "having", "limit", "offset", "fetch", "asc",
    "desc", "distinct", "case", "when", "then", "else", "end", "true",
    "false", "union", "all", "with", "over", "partition", "window", "between",
    "like", "ilike", "exists", "any", "some", "count", "sum", "avg", "min",
    "max", "cast", "interval", "current_date", "current_timestamp", "now",
    "date", "extract", "int", "integer", "text", "boolean", "numeric", "float",
    "timestamp", "varchar", "qualify", "row_number", "rank", "dense_rank",
    "lag", "lead", "first_value", "last_value", "nulls", "first", "last",
    "coalesce", "nullif", "greatest", "least", "abs", "round", "floor", "ceil",
    "concat", "substring", "trim", "lower", "upper", "length", "replace",
    "array", "unnest", "jsonb", "json", "day", "days", "month", "year", "hour",
    # ⛔ ADDED after measuring 202 fake column references on T1 (S7 row 17).
    # `FILTER` is the standard Postgres aggregate filter — `COUNT(*) FILTER
    # (WHERE ...)` appears in transformers across the estate, and its absence
    # here invented `assets.filter`, `issues.filter` and `identities.filter`,
    # each reported to the user as "Torana does not collect this yet".
    "filter",
    # ⚠️ Date/interval helpers seen invented as columns on T1:
    # `date_trunc('week', ...)` → `prioritized_vulnerabilities.date_trunc`,
    # and `EXTRACT(EPOCH FROM ...)` → `.epoch`.
    "date_trunc", "epoch", "week", "weeks", "quarter", "minute", "second",
    "age", "to_char", "to_date", "make_interval", "justify_interval",
    # ⚠️ Set/predicate keywords that are not columns.
    "intersect", "except", "ilike", "similar", "escape", "collate",
    "returning", "values", "recursive", "lateral", "ordinality",
    "percentile_cont", "percentile_disc", "within", "stddev", "variance",
    "bool_and", "bool_or", "string_agg", "array_agg", "jsonb_agg",
}


def _strip_calls(text: str, names: Tuple[str, ...]) -> str:
    """Remove `NAME( ... )` spans, matching parentheses so NESTED calls are covered.

    ⛔ WHY NOT A REGEX. `re.sub(r"filter\\s*\\([^()]*\\)", ...)` cannot cross a nested
    call: it strips `FILTER (WHERE x IS NOT NULL)` but leaves
    `FILTER (WHERE x IS NOT NULL AND x < NOW())` standing, because `NOW()` closes the
    character class early. The surviving fragment then looks like an ordinary WHERE
    and the column is misreported as row-filtering.

    ⚠️ These wrappers are stripped because the columns inside them SHAPE A VALUE and
    cannot DROP A ROW — `COUNT(*) FILTER (WHERE kev)` returns 0, not zero rows. The
    whole point of the distinction is that "the widget shows a 0" and "the widget
    shows nothing" are different answers with different owners.

    Conservative in the SAFE direction: an unbalanced or runaway span is left alone,
    so anything not confidently a wrapper is still treated as row-filtering.
    """
    out = text
    for name in names:
        pattern = re.compile(rf"\b{name}\s*\(", re.I)
        # Repeat until stable: one pass removes the outermost span, and an argument
        # may itself contain another call of the same name.
        for _ in range(8):
            m = pattern.search(out)
            if not m:
                break
            depth, i, n = 0, m.end() - 1, len(out)
            end = -1
            while i < n:
                ch = out[i]
                if ch == "(":
                    depth += 1
                elif ch == ")":
                    depth -= 1
                    if depth == 0:
                        end = i
                        break
                i += 1
            if end == -1:            # unbalanced -> leave it, fail safe
                break
            out = out[:m.start()] + " " + out[end + 1:]
    return out


#: ⛔ A DOUBLE-QUOTED IDENTIFIER IS **ONE** IDENTIFIER, SPACES AND ALL.
#: ⚠️ MEASURED 2026-09-07 on a shipped Classie widget: every scan in this file
#: uses `[a-zA-Z_][\w]*`, which cannot match an opening quote and cannot match a
#: space. So `... END AS "Kind of package"` was (1) never registered as an output
#: alias, and then (2) re-read by the bare-word pass as THREE columns of the FROM
#: table — `kind`, `of`, `package` — each reported to the customer as
#: "Torana does not collect this". Two quoted aliases invented FIVE phantom
#: columns on one widget, and the same blind spot hid quoted TABLE names
#: entirely (`FROM "My Table" t` resolved to no_tables_found).
#:
#: ⛔ MASK, DON'T PATCH EIGHT REGEXES. Rewriting each pattern to accept an
#: optional quoted form would leave eight places to keep in step, and any one
#: missed re-opens the same false positive. Instead every quoted identifier is
#: replaced ONCE, up front, by an opaque placeholder that DOES match
#: `[a-zA-Z_][\w]*` — so every existing scan treats it atomically and correctly
#: without knowing quoting exists — and the real text is restored on the way out.
_QUOTED_IDENT_RE = re.compile(r'"((?:[^"]|"")*)"')

#: The placeholder shape. ⚠️ Must match `[a-zA-Z_][\w]*` (so the existing scans
#: see one identifier) and must be lowercase-stable (the scans lowercase every
#: word before comparing it against `_SQL_RESERVED` and the alias maps).
_QUOTED_PLACEHOLDER = "__qtd{}__"
_QUOTED_PLACEHOLDER_RE = re.compile(r"^__qtd(\d+)__$")


def _mask_quoted_identifiers(text: str) -> Tuple[str, List[str]]:
    """Replace every ``"quoted identifier"`` with an opaque single-word token.

    Returns the masked text plus the ordered original identifiers, so a
    placeholder that survives to the output can be turned back into the name the
    author actually wrote.

    ⚠️ SINGLE-QUOTED STRING LITERALS ARE SKIPPED. `'it''s "quoted"'` is a VALUE,
    and the double quotes inside it are ordinary characters — masking them would
    invent an identifier out of string data. The scan therefore walks the text
    and steps over `'...'` spans (respecting the doubled-quote escape) rather
    than matching double-quoted runs globally.

    ⚠️ `""` is SQL's escape for a literal quote INSIDE a quoted identifier, so it
    does not close the identifier — hence `(?:[^"]|"")*`.

    Conservative in the SAFE direction: an UNTERMINATED quote masks nothing and
    the text is returned unchanged, leaving the old (imperfect) behaviour rather
    than swallowing the rest of the query.
    """
    # ⛔ CONTENT-ADDRESSED, not positional. ⚠️ MEASURED: numbering each
    # occurrence separately gave `WITH "My CTE" AS (…) … FROM "My CTE"` two
    # DIFFERENT tokens, so the CTE-name scan registered one and the FROM scan
    # saw the other as an unknown TABLE — reintroducing the fake-table leak the
    # cte_names block exists to prevent. Identical identifiers must mask
    # identically, exactly as identical bare words already do.
    originals: List[str] = []
    index: Dict[str, int] = {}
    out: List[str] = []
    i, n = 0, len(text)
    while i < n:
        ch = text[i]
        if ch == "'":
            # step over a string literal whole, doubled-quote escape included
            j = i + 1
            while j < n:
                if text[j] == "'":
                    if j + 1 < n and text[j + 1] == "'":
                        j += 2
                        continue
                    j += 1
                    break
                j += 1
            out.append(text[i:j])
            i = j
            continue
        if ch == '"':
            m = _QUOTED_IDENT_RE.match(text, i)
            if m:
                # `""` inside the identifier is one literal quote character.
                name = m.group(1).replace('""', '"')
                idx = index.get(name)
                if idx is None:
                    idx = len(originals)
                    index[name] = idx
                    originals.append(name)
                out.append(_QUOTED_PLACEHOLDER.format(idx))
                i = m.end()
                continue
            # unterminated — leave it alone, fail safe
        out.append(ch)
        i += 1
    return "".join(out), originals


def _unmask(word: str, originals: List[str]) -> str:
    """Placeholder → the identifier the author wrote; anything else unchanged."""
    m = _QUOTED_PLACEHOLDER_RE.match(word)
    if not m:
        return word
    idx = int(m.group(1))
    return originals[idx] if idx < len(originals) else word


def _is_placeholder(word: str) -> bool:
    return _QUOTED_PLACEHOLDER_RE.match(word) is not None


def extract_sql_columns(sql: str) -> Tuple[List[Tuple[str, str]], Dict[str, Any]]:
    """SQL text → the (table, column) pairs it reads, plus what we could NOT read.

    ⛔ RETURNS ITS OWN LIMITS. The second element is not decoration: a caller
    that cannot tell "this query reads nothing risky" from "we could not read
    this query" will report the second as the first, which is the
    confident-wrong-answer bug this whole surface exists to remove.

    Two resolution modes, and the second is what makes this usable on REAL
    artifacts:

    1. **Qualified** — ``alias.column`` where the alias maps to a FROM/JOIN
       table, or the qualifier IS a table name. Always safe.

    2. ⛔ **Unqualified, SINGLE-TABLE ONLY** — a bare ``column`` in a query with
       exactly ONE table in FROM/JOIN is unambiguously that table's.
       ⚠️ MEASURED, and this is why the mode exists: every one of the 26 rules
       on T1 is single-table with unqualified columns, so a qualified-only
       extractor returns ZERO columns for ALL of them and the artifact
       diagnosis silently passes every rule it is given. That is worse than not
       shipping it.

    ⛔ With TWO OR MORE tables, unqualified columns are SKIPPED, never guessed,
    and the skip is REPORTED. Attributing a column to the wrong table produces
    a confident verdict about a column the query never reads.
    """
    text = re.sub(r"--[^\n]*", " ", sql or "")
    text = re.sub(r"/\*.*?\*/", " ", text, flags=re.S)

    # ⛔ QUOTED IDENTIFIERS BECOME ONE OPAQUE WORD BEFORE ANY SCAN RUNS. Every
    # pattern below is `[a-zA-Z_][\w]*`, which cannot match a quote or a space;
    # masking is what makes all of them quoted-aware at once. Names are restored
    # at the two output points (the refs list and `predicated`). See
    # `_mask_quoted_identifiers`.
    text, _quoted = _mask_quoted_identifiers(text)

    # ⛔ STRING LITERALS ARE DATA, NEVER TABLES OR COLUMNS — remove them before any
    # scan runs. Every pattern below looks for bare words after `from`/`join`, and a
    # literal is just words; left in place, a sentence a human wrote as a column VALUE
    # is read as schema.
    #
    # ⚠️ MEASURED 2026-09-08 on the shipped `classie_em` v5 bundle, three widgets:
    #
    #     'You only pull from it'                    → invented a table `it`
    #     'Whether it is reachable from outside'     → invented a table `outside`
    #
    # ⛔ The damage is out of all proportion to the cause. A phantom table pushes a
    # genuinely SINGLE-TABLE query into the two-or-more-tables branch below, where
    # unqualified columns are correctly skipped rather than guessed — so `refs` comes
    # back EMPTY and the caller reports "we could not read which columns this query
    # depends on" about a query it parsed perfectly well. Three of forty widgets
    # carried a grey `Unknown` health badge beside a correct number.
    #
    # ⚠️ Order is deliberate: this runs AFTER `_mask_quoted_identifiers`, which is
    # already literal-aware and steps over `'...'` spans. Running it FIRST would
    # corrupt a legal quoted identifier containing an apostrophe (`"it\'s"`), whose
    # apostrophe would open a literal span that never closes where intended.
    #
    # `''` is SQL's escape for a quote inside a literal, so it does not close the
    # literal — hence `(?:[^\']|\'\')*`, mirroring the `""` rule above.
    text = re.sub(r"'(?:[^']|'')*'", " ", text)

    # ⛔ CTE NAMES ARE NOT SINK TABLES — strip them from consideration BEFORE
    # anything else. ⚠️ MEASURED on T1: `WITH backlog AS (...)` made `backlog`
    # look like a table, and every alias SELECTed out of it
    # (`backlog.open_critical`) resolved to a table that does not exist, so the
    # column came back UNREACHABLE — "Torana does not collect this" — about a
    # value the query itself computes. Two of the 202 fake references were
    # whole fake TABLES (`backlog`, `rate`) reached exactly this way.
    cte_names: Set[str] = {
        m.group(1).lower()
        for m in re.finditer(
            r"(?:\bwith\b|\bwith\s+recursive\b|,)\s*([a-zA-Z_][\w]*)\s+as\s*\(",
            text, flags=re.I)
    }
    # ⛔ …and the ALIASES a CTE is given at its use site. ⚠️ MEASURED: in
    # `FROM backlog b, rate r`, excluding only the CTE NAMES still let `b` and
    # `r` through as bare words, so a single-table query invented
    # `vulnerabilities.b` and `vulnerabilities.r`. Excluding the name without
    # its alias fixes the report and leaves the fault.
    for m in re.finditer(r"\b(?:from|join|,)\s+([a-zA-Z_][\w]*)\s+(?:as\s+)?([a-zA-Z_][\w]*)",
                         text, flags=re.I):
        if m.group(1).lower() in cte_names:
            alias = m.group(2).lower()
            if alias not in _NOT_AN_ALIAS:
                cte_names.add(alias)

    # ⛔ …and a DERIVED-TABLE alias: `FROM ( … ) t`. ⚠️ MEASURED on the widget
    # `Account Hygiene Summary`, whose SQL ends `) t ORDER BY ord` — `t` was
    # read as a bare column of the single FROM table and came back UNRESOLVED,
    # putting a "we could not trace this" line on a widget that is otherwise
    # fully traced. Same class as the CTE and SELECT-alias leaks: a name the
    # query DEFINES is never a column it READS.
    for m in re.finditer(r"\)\s*(?:as\s+)?([a-zA-Z_][\w]*)", text, flags=re.I):
        alias = m.group(1).lower()
        if alias not in _NOT_AN_ALIAS and alias not in _SQL_RESERVED:
            cte_names.add(alias)

    aliases: Dict[str, str] = {}
    tables: List[str] = []
    for m in re.finditer(
        r"\b(?:from|join)\s+([a-zA-Z_][\w]*)\s*(?:as\s+)?([a-zA-Z_][\w]*)?",
        text, flags=re.I,
    ):
        table = m.group(1).lower()
        alias = (m.group(2) or "").lower()
        # ⛔ A CTE is not a table we can make a supply claim about.
        if table in cte_names:
            continue
        # ⛔ A QUOTED TABLE NAME IS STILL A TABLE. ⚠️ MEASURED 2026-09-07:
        # `FROM "My Table" t` matched nothing at all, so the query resolved to
        # `no_tables_found` — the extractor reported it could read NOTHING about
        # a query it can read perfectly well. Masking makes the scan see one
        # word; this restores the author's spelling for the emitted name, since
        # a quoted table name is case-sensitive in Postgres.
        masked_table = table
        if _is_placeholder(table):
            table = _unmask(table, _quoted)
        if table not in tables:
            tables.append(table)
        aliases[table] = table
        # ⛔ Register the MASKED spelling too. Every scan below reads masked
        # text, so `"My Table".col` arrives as `__qtd0__.col` and would find no
        # qualifier without this — and the bare-word pass would emit the
        # placeholder itself as a column.
        aliases[masked_table] = table
        if alias and alias not in _NOT_AN_ALIAS:
            aliases[alias] = table

    # ⛔ OUTPUT ALIASES ARE NOT INPUT COLUMNS — collect them so mode 2 can skip
    # them. ⚠️ THIS IS THE DEFECT S7 § 2 MIS-DIAGNOSED. The brief reported
    # `prioritized_vulnerabilities.open_critical_prod` as a widget "querying a
    # phantom column"; the SQL is
    # `SELECT COUNT(*) AS open_critical_prod FROM prioritized_vulnerabilities`
    # — the name is what the query PRODUCES, never something it reads. The
    # widget was healthy and the extractor invented the fault.
    # ⛔ Reported as UNREACHABLE, i.e. "Torana does not collect this yet",
    # which is exactly the confident-wrong-answer this surface exists to
    # remove — so a false positive here is worse than a miss (see _SQL_RESERVED).
    select_aliases: Set[str] = {
        m.group(1).lower()
        for m in re.finditer(r"\bas\s+([a-zA-Z_][\w]*)\b", text, flags=re.I)
    } - set(aliases)

    seen: Set[Tuple[str, str]] = set()
    out: List[Tuple[str, str]] = []

    # -- mode 1: qualified ---------------------------------------------------
    qualified_positions: Set[str] = set()
    for m in re.finditer(r"\b([a-zA-Z_][\w]*)\.([a-zA-Z_][\w]*)\b", text):
        qual, col = m.group(1).lower(), m.group(2).lower()
        qualified_positions.add(col)
        table = aliases.get(qual)
        if not table or qual in _SQL_FUNCS:
            continue          # unresolvable qualifier — skip, NEVER guess
        # ⛔ A quoted column keeps the author's exact spelling — `"Odd Column"`
        # is a case-sensitive identifier in Postgres, and lowercasing it would
        # look up a different column than the query reads.
        col = _unmask(col, _quoted) if _is_placeholder(col) else col
        if (table, col) not in seen:
            seen.add((table, col))
            out.append((table, col))

    # -- mode 2: unqualified, single-table only ------------------------------
    unqualified_skipped = 0
    if len(tables) == 1:
        table = tables[0]
        # ⚠️ Strip the qualified pairs first so `a.col` does not also register
        # `col` as a bare name.
        bare = re.sub(r"\b[a-zA-Z_][\w]*\.[a-zA-Z_][\w]*\b", " ", text)
        # Drop string literals — 'high' is a value, not a column.
        bare = re.sub(r"'[^']*'", " ", bare)
        for m in re.finditer(r"\b([a-zA-Z_][\w]*)\b", bare):
            word = m.group(1).lower()
            if word in _SQL_RESERVED or word in _SQL_FUNCS:
                continue
            if word == table or word in aliases:
                continue
            # ⛔ Never report what the query PRODUCES as something it READS.
            if word in select_aliases or word in cte_names:
                continue
            word = _unmask(word, _quoted) if _is_placeholder(word) else word
            if (table, word) not in seen:
                seen.add((table, word))
                out.append((table, word))
    elif len(tables) > 1:
        # ⛔ Count what we are deliberately NOT resolving, and report it.
        bare = re.sub(r"\b[a-zA-Z_][\w]*\.[a-zA-Z_][\w]*\b", " ", text)
        bare = re.sub(r"'[^']*'", " ", bare)
        unqualified_skipped = len({
            m.group(1).lower() for m in re.finditer(r"\b([a-zA-Z_][\w]*)\b", bare)
            if m.group(1).lower() not in _SQL_RESERVED
            and m.group(1).lower() not in _SQL_FUNCS
            and m.group(1).lower() not in aliases
            # ⛔ An output alias was never an input, so counting it as
            # "skipped" overstates how much of the query we failed to read.
            and m.group(1).lower() not in select_aliases
            and m.group(1).lower() not in cte_names
        })

    # ⛔ WHICH COLUMNS ARE PREDICATED ON — needed by the § 3a "dead constant"
    # signal, which fires ONLY when a query FILTERS on a constant column.
    # ⚠️ S2 § 3a rule 1: a constant column merely SELECTed is harmless —
    # rendering `False` in a column is not a defect. Badging it would be the
    # 93%-false-alarm mistake in a new costume.
    #
    # Everything from the first WHERE/JOIN-ON/HAVING/GROUP BY onward is
    # predicate position. ⚠️ Deliberately COARSE and inclusive-of-the-tail: a
    # false negative here only means we stay quiet (the safe direction), while
    # a false positive puts a red mark on a healthy widget.
    predicated: Set[Tuple[str, str]] = set()
    pred_start = re.search(r"\b(where|having|on|group\s+by|filter)\b",
                           text, flags=re.I)
    if pred_start:
        ptext = text[pred_start.start():]
        for m in re.finditer(r"\b([a-zA-Z_][\w]*)\.([a-zA-Z_][\w]*)\b", ptext):
            t = aliases.get(m.group(1).lower())
            if t:
                predicated.add((t, m.group(2).lower()))
    # ⚠️ `predicated` still holds MASKED names here on purpose — the
    # row-filtering check below re-matches these names against the masked text,
    # and unmasking first would search for `Kind of package` in text that
    # contains only its placeholder. Unmasking happens once, at the very end.
        if len(tables) == 1:
            pbare = re.sub(r"\b[a-zA-Z_][\w]*\.[a-zA-Z_][\w]*\b", " ", ptext)
            pbare = re.sub(r"'[^']*'", " ", pbare)
            for m in re.finditer(r"\b([a-zA-Z_][\w]*)\b", pbare):
                w = m.group(1).lower()
                if (w not in _SQL_RESERVED and w not in _SQL_FUNCS
                        and w not in aliases and w not in select_aliases
                        and w not in cte_names and w != tables[0]):
                    predicated.add((tables[0], w))

    # ⛔ ROW-FILTERING vs merely PREDICATED — the distinction that separates
    # "returns nothing, ever" from "returns rows with an empty column".
    #
    # ⚠️ MEASURED, and the first cut of this got it wrong. `predicated` is TRUE
    # for a column anywhere after WHERE/JOIN-ON, which over-counts badly:
    #
    #   COUNT(*) FILTER (WHERE v.cisa_kev_data IS NOT NULL)  → shapes a COLUMN
    #   COALESCE(v.epss_score, 0)                            → NULL is DEFAULTED
    #
    # Neither can remove a row, so a missing value there leaves the query
    # returning exactly as many rows as before — just with a zero in one
    # column. Counting them as row filters made 30% of the estate report
    # "will not return anything" about queries that visibly return data
    # (`remediation_queue` renders a full table while claiming this).
    #
    # ⛔ So strip FILTER(...) aggregates and COALESCE(...) wrappers before
    # asking whether the column survives in the WHERE. Conservative in the SAFE
    # direction: anything still left is treated as row-filtering.
    # ⚠️ STRIP THE WRAPPERS FIRST, THEN find the WHERE. Doing it the other way
    # round misses a `COUNT(*) FILTER (WHERE x IS NOT NULL)` that sits in the
    # SELECT list — its inner WHERE then becomes the "first" WHERE and the real
    # predicate is never examined. Measured: kev_flag inside a FILTER
    # aggregate was still classed as row-filtering.
    # ⛔ BALANCED-PAREN STRIP, NOT `[^()]*`. A single `[^()]*` body cannot cross a
    # nested call, so `FILTER (WHERE x IS NOT NULL AND x < NOW())` was left standing
    # while the SIMPLE form `FILTER (WHERE x IS NOT NULL)` stripped cleanly. The
    # trailing AND-clause then leaked into the WHERE scan and the column was reported
    # as row-filtering.
    #
    # ⚠️ MEASURED 2026-08-17 on the shipped `ciso_posture` bundle: this produced a
    # FALSE "will be empty" warning for `identities.last_login_date`, whose widget
    # (`stale_disabled_accounts`) renders 2 rows — the exact confidently-wrong
    # answer this block already exists to prevent, reintroduced by the nesting case.
    _stripped = _strip_calls(text, ("filter", "coalesce"))
    row_filtered: Set[Tuple[str, str]] = set()
    # ⛔ AN OUTER JOIN'S `ON` CANNOT DROP A ROW FROM THE PRESERVED SIDE.
    # `LEFT JOIN r ON v.repo_id = r.repo_id` keeps every `v` row and NULLs the
    # right-hand columns when the key does not match — that is the entire point of
    # an outer join. An INNER join's ON genuinely does filter, so only the outer
    # forms are removed here.
    #
    # ⚠️ MEASURED 2026-08-17 on the shipped `ciso_posture` bundle: without this,
    # `vulnerabilities.torana_repository_id` (3 of 86,696 populated) was reported as
    # row-filtering because of a LEFT JOIN key, producing a "this will be empty"
    # warning about a relation that returns 86,693 rows.
    # ⚠️ The ON clause ends at the next clause KEYWORD, not at end-of-line. An
    # earlier cut used `[^\n]*` and swallowed the real `WHERE` on a single-line
    # query — turning a false POSITIVE into a false NEGATIVE, which is worse: the
    # warning silently stops firing for queries that genuinely return nothing.
    _stripped = re.sub(
        r"\b(?:left|right|full)(?:\s+outer)?\s+join\b.*?\bon\b"
        r"(?:(?!\b(?:where|having|group\s+by|order\s+by|limit|union|"
        r"left|right|full|inner|cross|join)\b).)*",
        " ", _stripped, flags=re.I | re.S)

    _pred_start = re.search(r"\b(where|having|on|group\s+by)\b", _stripped,
                            flags=re.I)
    if _pred_start:
        _body = _stripped[_pred_start.start():]
        for t_, c_ in predicated:
            if re.search(rf"\b{re.escape(c_)}\b", _body, flags=re.I):
                row_filtered.add((t_, c_))

    # ⛔ NOW restore the author's spelling — after every masked-text match is done.
    predicated = {(t, _unmask(c, _quoted)) for t, c in predicated}
    row_filtered = {(t, _unmask(c, _quoted)) for t, c in row_filtered}

    limits: Dict[str, Any] = {
        "tables": tables,
        "predicated": sorted(f"{t}.{c}" for t, c in predicated),
        # ⛔ The subset that can actually zero the result set.
        "row_filtered": sorted(f"{t}.{c}" for t, c in row_filtered),
        "resolution": ("single_table_unqualified" if len(tables) == 1
                       else "qualified_only" if len(tables) > 1
                       else "no_tables_found"),
        # ⛔ Never silently drop. A consumer must be able to tell "clean" from
        # "we could not read most of this".
        "unqualified_columns_skipped": unqualified_skipped,
        # ⛔ ONLY WARN WHEN SOMETHING WAS ACTUALLY SKIPPED. ⚠️ MEASURED: a
        # multi-table query whose columns are ALL qualified skipped nothing, yet
        # still rendered "…were not checked. (0 column name(s) not checked)" —
        # a warning about the empty set. `prioritized_vulnerabilities` reads 4
        # tables, skipped 0, and showed it.
        # ⛔ A caveat that fires when there is nothing to caveat is noise, and
        # noise teaches the reader to ignore the line on the query where it IS
        # load-bearing — the same false-alarm failure § 3.17.3 measured for the
        # badge. The condition is what was SKIPPED, never how many tables there
        # are.
        "caveat": (
            "This query reads more than one table, so bare column names cannot "
            "be attributed to a table with certainty and were not checked."
            if unqualified_skipped > 0 else None
        ),
    }
    return out, limits
