"""Progression check — does a query that CLAIMS a funnel actually produce one?

A "funnel", "reduction", "drop-off" or "narrowing" is a claim about SHAPE: each stage is a
subset of the one before it, so the counts must never increase. That claim is checkable, and
nothing was checking it.

⛔ WHY THIS EXISTS — the defect that passed every other gate
------------------------------------------------------------
Measured 2026-08-26 on a real blueprint step ("Calculate Workload Reduction Funnel", T2
proposal 3715ecb9). The authored SQL ran clean through reachability, shape routing, fan-out
and EXPLAIN, and produced:

    1  Open findings      95,976
    2  Distinct CVEs         537
    3  Distinct fixes        607   <-- GREW
    4  Fixable now           254

Stage 3 is LARGER than stage 2, so the "reduction" narrative is false — and the same defect
reproduced identically on a second tenant (T1: 492 -> 554), confirming it was the SQL and not
one tenant's data. The cause: stage 2 counted `cve_id` while stage 3 counted a composite
`(cve, package, version-pair)` key, and one CVE legitimately spans several packages.

⭐ **No column-level gate can catch this.** Every column is reachable, every literal is in
its domain, no join fans out. The error only exists in the RELATIONSHIP BETWEEN ROWS, which
is why it needs its own axis — and why it stayed invisible until someone read the numbers.

⛔ WHY THIS LIVES IN pantheon-shared, NOT IN EITHER GENERATOR
-------------------------------------------------------------
Same rule as `shape_routing`: there are TWO authoring surfaces — the platform agent
(pantheon-agent-builder) and the `torana-text-to-sql` Claude skill. A check implemented in one
is a check the other silently lacks, and the two would then disagree about the same SQL. One
rule, imported by both.

⚠️ ADVISORY, NEVER A REFUSAL
----------------------------
A progression can legitimately grow — "findings per stage of a pipeline that FANS OUT" is a
real shape, and a stage that counts a different unit than its predecessor may be intended.
This reports; the author decides. Consistent with `shape_routing` and the value axis:
reachability gates, everything else informs.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence

#: Words that CLAIM a narrowing shape. Matched against the intent/description text, never
#: against the SQL — the claim is made in prose, and prose is where the author asserts it.
#:
#: ⚠️ Deliberately narrow. A checker that fires on every query with the word "count" would be
#: ignored within a week, which is the failure mode this whole discipline argues against.
PROGRESSION_CLAIM_WORDS = (
    "funnel",
    "reduction",
    "reduces to",
    "narrows",
    "narrowing",
    "drop-off",
    "dropoff",
    "winnow",
    "distill",
    "progression from",
)

#: Column names a stage's magnitude is conventionally carried in.
_COUNT_KEYS = ("item_count", "count", "cnt", "n", "value", "stage_count", "finding_count")
#: Column names a stage's ORDER is conventionally carried in.
_ORDER_KEYS = ("stage_order", "order", "seq", "sequence", "step", "rank")
#: Column names a stage's LABEL is conventionally carried in.
_LABEL_KEYS = ("stage_name", "stage", "name", "label", "step_name")


def claims_progression(text: str) -> bool:
    """Does this intent/description CLAIM a narrowing shape?

    ⚠️ Reads the author's own words, not the SQL. A funnel is an assertion about meaning; the
    SQL cannot say whether one was intended, and guessing from structure would fire on every
    `UNION ALL` of aggregates.
    """
    if not text:
        return False
    low = text.lower()
    return any(w in low for w in PROGRESSION_CLAIM_WORDS)


@dataclass
class ProgressionFinding:
    """One place where a claimed progression grew instead of narrowing."""

    from_stage: str
    to_stage: str
    from_count: int
    to_count: int

    @property
    def growth(self) -> int:
        return self.to_count - self.from_count

    def describe(self) -> str:
        return (
            f"'{self.to_stage}' ({self.to_count:,}) is LARGER than '{self.from_stage}' "
            f"({self.from_count:,}) — +{self.growth:,}. A stage of a narrowing progression "
            f"cannot exceed the stage before it; the two stages are almost certainly "
            f"counting DIFFERENT UNITS."
        )


@dataclass
class ProgressionReport:
    checked: bool = False
    why_skipped: Optional[str] = None
    stages: List[Dict[str, Any]] = field(default_factory=list)
    findings: List[ProgressionFinding] = field(default_factory=list)

    @property
    def monotonic(self) -> bool:
        """True when every stage is <= its predecessor. Vacuously true if unchecked."""
        return not self.findings

    def warnings(self) -> List[str]:
        """Human-readable warnings — the shape both callers render."""
        if not self.findings:
            return []
        out = [
            "⛔ PROGRESSION NOT MONOTONIC — this result claims a funnel/reduction, but a "
            "stage GROWS:"
        ]
        out.extend(f"   {f.describe()}" for f in self.findings)
        out.append(
            "   ⚠️ Advisory: a progression CAN legitimately fan out. If the growth is "
            "intended, say so in the intent; if not, make every stage count the same unit."
        )
        return out


def _pick(row: Dict[str, Any], keys: Sequence[str]) -> Optional[str]:
    """First key present in the row, matched case-insensitively."""
    lowered = {str(k).lower(): k for k in row}
    for k in keys:
        if k in lowered:
            return lowered[k]
    return None


def check_progression(
    rows: Optional[Sequence[Dict[str, Any]]],
    intent_text: str = "",
    *,
    force: bool = False,
) -> ProgressionReport:
    """Verify a claimed progression actually narrows.

    `rows` is the query's OWN RESULT — this check cannot be done from SQL text, because
    whether stage 3 exceeds stage 2 is a fact about the data the query returned.

    Pass `force=True` to check regardless of what the intent says (useful when the caller
    already knows the artifact is a funnel).

    ⚠️ Returns `checked=False` with a reason rather than a false pass whenever the shape is
    not recognisable — an unchecked result reported as "monotonic ✅" is exactly the confident
    wrong answer this module exists to remove.
    """
    rep = ProgressionReport()

    if not force and not claims_progression(intent_text):
        rep.why_skipped = "the intent does not claim a funnel/reduction"
        return rep
    if not rows:
        rep.why_skipped = "no rows to check — run the query first"
        return rep

    first = rows[0]
    if not isinstance(first, dict):
        rep.why_skipped = "rows are not dicts"
        return rep

    count_key = _pick(first, _COUNT_KEYS)
    if not count_key:
        rep.why_skipped = (
            f"no stage-magnitude column found (looked for {list(_COUNT_KEYS)}) — "
            "cannot tell which column carries the count"
        )
        return rep

    order_key = _pick(first, _ORDER_KEYS)
    label_key = _pick(first, _LABEL_KEYS)

    ordered = list(rows)
    if order_key:
        # ⚠️ Sort by the DECLARED order, never by the count. Sorting by count would make every
        # progression monotonic by construction — the check would pass on the exact defect it
        # exists to catch.
        try:
            ordered.sort(key=lambda r: r.get(order_key))
        except TypeError:
            rep.why_skipped = f"stage order column '{order_key}' is not sortable"
            return rep

    stages: List[Dict[str, Any]] = []
    for i, r in enumerate(ordered):
        raw = r.get(count_key)
        if raw is None:
            continue
        try:
            n = int(raw)
        except (TypeError, ValueError):
            rep.why_skipped = f"stage magnitude '{raw}' is not an integer"
            return rep
        stages.append({
            "label": str(r.get(label_key) or f"stage {i + 1}") if label_key
            else f"stage {i + 1}",
            "count": n,
        })

    if len(stages) < 2:
        rep.why_skipped = "fewer than two stages — nothing to compare"
        return rep

    rep.checked = True
    rep.stages = stages
    for prev, cur in zip(stages, stages[1:]):
        if cur["count"] > prev["count"]:
            rep.findings.append(ProgressionFinding(
                from_stage=prev["label"], to_stage=cur["label"],
                from_count=prev["count"], to_count=cur["count"],
            ))
    return rep


def check_progression_sql_shape(sql: str) -> Optional[str]:
    """Cheap STATIC hint: does this SQL look like a stage progression at all?

    Returns a short reason when it does, else None. Used only to decide whether it is worth
    asking the caller to run the query — it makes no claim about monotonicity, which is
    unknowable from text.
    """
    if not sql:
        return None
    low = sql.lower()
    if low.count("union all") >= 2 and any(
        _pick({k: 1}, _ORDER_KEYS) or _pick({k: 1}, _LABEL_KEYS)
        for k in re.findall(r"as\s+([a-z_][a-z0-9_]*)", low)
    ):
        return "several UNION ALL branches with a stage label/order column"
    return None
