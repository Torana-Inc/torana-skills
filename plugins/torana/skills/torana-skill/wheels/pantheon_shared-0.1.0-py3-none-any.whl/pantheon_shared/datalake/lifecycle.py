"""Row-lifecycle rules applied inside the shared upsert — VULNERABILITY_LIFECYCLE_DESIGN.md § 3.4.1.

WHAT THIS IS
------------
For the `vulnerabilities` table, a handful of columns are not ordinary data: they record WHERE
a finding is in its life. Writing them with the generic `col = EXCLUDED.col` is how the platform
came to leave a resurrected row live while it still said "closed, disappeared", and to have no
record at all of when a finding's state changed.

Registered as a policy in `upsert_policies.py`: `PostgreSQLBackend.upsert` asks the registry, the
columns this module OWNS are removed from the generic SET list and replaced by the assignments below,
all evaluated in the SAME `ON CONFLICT … DO UPDATE` statement, under the row lock the conflict already
takes (R9). `prepare_vulnerability_records` is the insert-path half.

⛔ THE RULES KEY ON STATE, NEVER ON THE CODE PATH. T11 recorded a fix that cleared the closure
fields "where resurrection happens" in the ETL adapter — which runs on EVERY record of EVERY sync,
and would have wiped every human closure on a six-hour cron. Every rule here reads the stored row
(`T`) and the incoming row (`EXCLUDED`) and nothing else.

⚠️ Postgres evaluates every SET expression against the PRE-update row, so one assignment cannot
read another's result. Each rule therefore INLINES the expressions it depends on. The order of
definition is L1 → L2 → L3 → L4 → L5 → L6, and each may reference only earlier ones.

THE RULES (§ 3.4.1.4)
---------------------
  L1 is_deleted            re-observation reverses a tombstone only when its closure_reason is an
                           ABSENCE reason; any other tombstone survives (Q5 / T-O).
  L2 resurrect             (expression only) the single definition of "coming back".
  L3 closure_reason        a live, open-class row never carries a closure reason.
  L4 resolution_date       one closure clock for every path; never re-stamped while closed.
  L5 is_suppressed         = (status = 'Suppressed'); status is authoritative (Q4).
  L6 modified_date         moves only when a state column's value changes.
  CAS (WHERE)              a tombstone written from a stale read is refused (§ 3.8.3).

For every table other than `vulnerabilities` this module returns None and the upsert behaves
exactly as before.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, FrozenSet, Iterable, List, Optional, Set

from pantheon_shared.datalake.value_domain import (
    ABSENCE_CLOSURE_REASONS,
    OPEN_CLASS_STATUSES,
    TERMINAL_STATUSES,
)

__all__ = [
    "LIFECYCLE_TABLE",
    "OWNED_COLUMNS",
    "STAMPED_COLUMNS",
    "STATE_COLUMNS",
    "OPEN_CLASS_STATUSES",
    "TERMINAL_STATUSES",
    "vulnerability_rule_text",
    "LifecycleText",
    "prepare_vulnerability_records",
]

LIFECYCLE_TABLE = "vulnerabilities"

#: Columns whose value this module computes. Removed from the generic SET list.
OWNED_COLUMNS: FrozenSet[str] = frozenset({
    "is_deleted",
    "closure_reason",
    "vulnerability_resolution_date",
    "is_suppressed",
    "vulnerability_modified_date",
})

#: Columns `prepare_vulnerability_records` may ADD to a record the writer did not send. A value
#: stamped this way is for the INSERT only: on a conflict it must not read as the writer's claim
#: (L4 would fill a legacy closed row's missing date with the sync time, and every other record
#: in the statement would send NULL for the column). The backend runs such records in their own
#: statement and passes these columns as `stamped`, so the rules treat them as not sent.
STAMPED_COLUMNS: FrozenSet[str] = frozenset({
    "vulnerability_modified_date",
    "is_suppressed",
    "vulnerability_resolution_date",
})

#: A change in any of these moves the state clock (L6).
STATE_COLUMNS = (
    "is_deleted", "vulnerability_status", "closure_reason", "vulnerability_resolution_date",
    "is_triaged", "is_false_positive", "is_risk_accepted", "is_suppressed", "is_verified",
)

# OPEN_CLASS_STATUSES / TERMINAL_STATUSES are declared once, in value_domain.py.


def _q(col: str) -> str:
    """Quote a fixed, module-owned column name as an SQL identifier."""
    if not col.replace("_", "").isalnum():          # constants only — never caller input
        raise ValueError(f"unsafe column name {col!r}")
    return f'"{col}"'


def _in_list(values: Iterable[str]) -> str:
    return "(" + ", ".join("'" + v.replace("'", "''") + "'" for v in values) + ")"


@dataclass
class LifecycleText:
    """The clause as plain SQL text, `{T}` standing for the target table. Pure — no psycopg2
    connection is needed to build or inspect it, which is what makes it unit-testable."""

    owned: Set[str]
    #: column -> expression text
    assignments: Dict[str, str]
    where: Optional[str]


def vulnerability_rule_text(
    table: str,
    table_columns: Iterable[str],
    batch_columns: Iterable[str],
    preserve: Iterable[str],
    primary_key: str,
    stamped: Iterable[str] = (),
) -> Optional[LifecycleText]:
    """Build the L1–L6 + CAS rules as SQL text, `{T}` standing for the target table.

    Args:
        table: destination table name.
        table_columns: every column the live table has (information_schema).
        batch_columns: the columns this statement INSERTs (the batch's key union ∩ table).
        preserve: the mapping's `preserve` list — these keep their stored value.
        primary_key: the conflict column; never assigned.
        stamped: columns in the INSERT list only because the insert path stamped them
            (`STAMPED_COLUMNS` the writer did not send). Not authoritative on a conflict.
    """
    if table != LIFECYCLE_TABLE:
        return None
    tcols = set(table_columns)
    if not OWNED_COLUMNS & tcols:
        return None                               # a schema without these columns: nothing to own

    batch = set(batch_columns)
    keep = set(preserve) | set(stamped)

    def has(col: str) -> bool:
        return col in tcols

    def sent(col: str) -> bool:
        """The writer SENT this column (it is in the INSERT list), preserved or not. Distinct
        from `in_batch`, which also requires it to be authoritative for SET. Only the CAS needs
        this weaker test: a retirement preserves `scan_last_detected_date`, yet EXCLUDED still
        carries its stale-read value, which is exactly what the CAS compares (Round 4 item 2)."""
        return col in batch

    def in_batch(col: str) -> bool:
        """Incoming value is authoritative for this column in this statement."""
        return col in batch and col not in keep and col != primary_key

    T = "{T}"

    def stored(col: str) -> str:
        return f"{T}.{_q(col)}"

    def incoming(col: str) -> str:
        return f"EXCLUDED.{_q(col)}"

    def generic(col: str) -> str:
        """The value a NON-owned column will hold after this statement."""
        return incoming(col) if in_batch(col) else stored(col)

    absence = _in_list(ABSENCE_CLOSURE_REASONS)
    terminal = _in_list(TERMINAL_STATUSES)
    open_class = _in_list(OPEN_CLASS_STATUSES)

    status = generic("vulnerability_status") if has("vulnerability_status") else "NULL"

    # ── L1 is_deleted ───────────────────────────────────────────────────────────────────
    if has("is_deleted") and in_batch("is_deleted"):
        reason_now = f"COALESCE({stored('closure_reason')}, '')" if has("closure_reason") else "''"
        l1 = (f"(CASE WHEN {stored('is_deleted')} IS TRUE AND {incoming('is_deleted')} IS NOT TRUE "
              f"AND {reason_now} NOT IN {absence} THEN TRUE ELSE {incoming('is_deleted')} END)")
        # ── L2 resurrect ────────────────────────────────────────────────────────────────
        l2 = (f"({stored('is_deleted')} IS TRUE AND {incoming('is_deleted')} IS NOT TRUE "
              f"AND {reason_now} IN {absence})")
    elif has("is_deleted"):
        l1 = stored("is_deleted")
        l2 = "FALSE"
    else:
        l1 = "FALSE"
        l2 = "FALSE"

    live_open = f"(({l1}) IS NOT TRUE AND COALESCE({status}, 'Open') IN {open_class})"

    final: Dict[str, str] = {}
    assign: Dict[str, str] = {}

    if has("is_deleted"):
        final["is_deleted"] = l1
        if in_batch("is_deleted"):
            assign["is_deleted"] = l1

    # ── L3 closure_reason ───────────────────────────────────────────────────────────────
    if has("closure_reason"):
        # An incoming ABSENCE reason (a retirement) never overwrites a reason already stored:
        # the retiring job computed its value from a stale SELECT, and a human reason PATCHed
        # in the read→write window (e.g. `risk_accepted`) is the stronger claim. The client-side
        # `rec.get("closure_reason") or "disappeared"` cannot see that PATCH (Round 4 item 15a).
        keep_stored = ""
        if in_batch("closure_reason"):
            keep_stored = (f"WHEN {incoming('closure_reason')} IN {absence} "
                           f"AND {stored('closure_reason')} IS NOT NULL "
                           f"THEN {stored('closure_reason')} ")
        l3 = (f"(CASE WHEN {l2} THEN NULL WHEN {live_open} THEN NULL "
              f"{keep_stored}ELSE {generic('closure_reason')} END)")
        final["closure_reason"] = l3
        assign["closure_reason"] = l3

    # ── L4 vulnerability_resolution_date ────────────────────────────────────────────────
    if has("vulnerability_resolution_date"):
        res = "vulnerability_resolution_date"
        supplied = incoming(res) if in_batch(res) else "NULL"
        already_closed = f"({stored('vulnerability_status')} IN {terminal}" if has("vulnerability_status") else "(FALSE"
        already_closed += f" OR {stored('is_deleted')} IS TRUE)" if has("is_deleted") else ")"
        l4 = (f"(CASE WHEN {l2} OR {live_open} THEN NULL "
              f"WHEN {status} IN {terminal} OR ({l1}) IS TRUE THEN "
              # Already closed: never re-stamp. Keep the stored date; only fill a missing one
              # from a date the writer SUPPLIED. now() is reserved for a real transition into
              # closed — a legacy tombstone with no date must not gain one by being re-observed.
              f"(CASE WHEN {already_closed} THEN COALESCE({stored(res)}, {supplied}) "
              f"ELSE COALESCE({supplied}, {stored(res)}, now()) END) "
              f"ELSE {generic(res)} END)")
        final[res] = l4
        assign[res] = l4

    # ── L5 is_suppressed ────────────────────────────────────────────────────────────────
    if has("is_suppressed") and has("vulnerability_status"):
        # ⚠️ Only CORRECT a disagreement; never fold NULL to FALSE. NULL is the schema's
        # "untriaged" state, and turning it into FALSE would move L6's clock on every row the
        # first time it is re-observed — a state change that did not happen (caught by the
        # dry-run: 4 of 13 no-op cases moved the clock before this).
        flag = generic("is_suppressed")
        l5 = (f"(CASE WHEN COALESCE({status}, '') = 'Suppressed' THEN TRUE "
              f"WHEN ({flag}) IS TRUE THEN FALSE ELSE {flag} END)")
        final["is_suppressed"] = l5
        assign["is_suppressed"] = l5

    # ── L6 vulnerability_modified_date ──────────────────────────────────────────────────
    if has("vulnerability_modified_date"):
        diffs = []
        for col in STATE_COLUMNS:
            if not has(col):
                continue
            after = final.get(col, generic(col))
            diffs.append(f"{stored(col)} IS DISTINCT FROM {after}")
        mod = "vulnerability_modified_date"
        l6 = (f"(CASE WHEN {' OR '.join(diffs)} THEN now() ELSE {stored(mod)} END)"
              if diffs else stored(mod))
        assign[mod] = l6

    # ── CAS: refuse a tombstone written from a stale read (§ 3.8.3) ─────────────────────
    where = None
    # ⚠️ `sent`, not `has` or `in_batch`: if the writer did not send last-detected, EXCLUDED holds
    # the column default (NULL), the comparison is NULL and the guard would pass every row while
    # looking present. Emit it only when the comparison can mean something (Round 4 item 2).
    if has("is_deleted") and in_batch("is_deleted") and sent("scan_last_detected_date"):
        # ⚠️ COALESCE(..., FALSE) is load-bearing: with a NULL last-detected the bare predicate
        # is NULL, NOT NULL is NULL, and a NULL WHERE would skip EVERY update on the row.
        where = (f"NOT COALESCE({incoming('is_deleted')} IS TRUE "
                 f"AND {stored('is_deleted')} IS NOT TRUE "
                 f"AND {stored('scan_last_detected_date')} > {incoming('scan_last_detected_date')}, "
                 f"FALSE)")

    return LifecycleText(
        owned={c for c in OWNED_COLUMNS if has(c)},
        assignments=assign,
        where=where,
    )


def prepare_vulnerability_records(records: List[Dict[str, Any]], now: datetime) -> None:
    """Insert-path stamping, in place — the half of the rules a NEW row needs.

    A brand-new row has no stored row, so the conflict rules never run for it. The same facts
    are stamped onto the record before it is written: the state clock starts at arrival, a
    terminal status gets a closure date, and the suppression flag agrees with the status.

    ⛔ On an UPDATE a stamped value must be ignored, and owning the column is NOT enough: L4
    reads `EXCLUDED` as the writer's supplied date. The backend therefore calls this through
    `upsert_policies.prepare_record_groups`, which passes the `STAMPED_COLUMNS` a record did not
    carry to the rules as `stamped`.

    ⚠️ Runs in the backend AFTER `DatalakeClient` has injected `created_at`, so the clock starts
    from the same value as the row's creation (invariant I4′ compares them).
    """
    terminal = {s.lower() for s in TERMINAL_STATUSES}
    open_class = {s.lower() for s in OPEN_CLASS_STATUSES}
    for rec in records:
        if not rec.get("created_at"):
            rec["created_at"] = now
        if not rec.get("vulnerability_modified_date"):
            rec["vulnerability_modified_date"] = rec["created_at"]
        if "vulnerability_status" in rec:
            status = str(rec.get("vulnerability_status") or "").strip().lower()
            if status == "suppressed":
                rec["is_suppressed"] = True
            elif rec.get("is_suppressed") is True:
                rec["is_suppressed"] = False
            if status in terminal and not rec.get("vulnerability_resolution_date"):
                rec["vulnerability_resolution_date"] = now
        # Mirror L3/L4 for a NEW row (Round 4 item 16b): a live row whose status is open-class —
        # or absent, which L3 reads as Open — carries no closure fields. Tenable derives a
        # resolution date from `last_fixed` without writing a status, so a REOPENED finding
        # otherwise inserts open WITH a closure date (I1′ > 0 on a fresh sync).
        status_now = str(rec.get("vulnerability_status") or "open").strip().lower()
        if rec.get("is_deleted") is not True and status_now in open_class:
            if "closure_reason" in rec:
                rec["closure_reason"] = None
            if "vulnerability_resolution_date" in rec:
                rec["vulnerability_resolution_date"] = None
