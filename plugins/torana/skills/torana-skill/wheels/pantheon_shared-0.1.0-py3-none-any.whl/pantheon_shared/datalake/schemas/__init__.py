"""
Table schema definitions for Pantheon datalake.

These schemas define the structure of tables stored in the datalake across all backends
(DuckDB, Snowflake, PostgreSQL). All services writing to or reading from the datalake
should use these schema definitions to ensure consistency.

Example:
    from pantheon_shared.datalake.schemas import AssetsSchema, IdentitySchema

    assets_schema = AssetsSchema()
    print(assets_schema.table_name)  # "assets"
    print(assets_schema.primary_key)  # "torana_entity_id"
    print(assets_schema.schema)  # Dict of column definitions

Semantic Model:
    from pantheon_shared.datalake.schemas import get_semantic_model_path, load_semantic_model

    # Get path to YAML file
    path = get_semantic_model_path()

    # Load and parse semantic model
    model = load_semantic_model()
"""

from pathlib import Path
from typing import Dict, Any

from .base import TableSchema
from .identities import IdentitySchema
from .repositories import RepositoriesSchema
from .vulnerabilities import VulnerabilitySchema
from .assets import AssetsSchema
from .datastores import DatastoresSchema
from .artifacts import ArtifactsSchema
from .findings import FindingsSchema
from .issues import IssuesSchema
from .controls import ControlsSchema
from .packages import PackagesSchema
from .pentest_cases import PentestCasesSchema
from .pentest_runs import PentestRunsSchema
from .entity_edges import EntityEdgesSchema
from .entity_edge_candidates import EntityEdgeCandidatesSchema
from .entity_graph_derivation_metrics import EntityGraphDerivationMetricsSchema
from .entity_properties_resolved import EntityPropertiesResolvedSchema
from .join_trust import JoinTrustSchema
from .question_resolution import QuestionResolutionSchema
from .vm_cve_metadata import VmCveMetadataSchema
from .vm_cve_affects import VmCveAffectsSchema
from .tables import DatalakeTables

__all__ = [
    "TableSchema",
    "IdentitySchema",
    "RepositoriesSchema",
    "VulnerabilitySchema",
    "AssetsSchema",
    "DatastoresSchema",
    "ArtifactsSchema",
    "FindingsSchema",
    "IssuesSchema",
    "ControlsSchema",
    "PackagesSchema",
    "PentestCasesSchema",
    "PentestRunsSchema",
    "EntityEdgesSchema",
    "EntityEdgeCandidatesSchema",
    "EntityGraphDerivationMetricsSchema",
    "EntityPropertiesResolvedSchema",
    "JoinTrustSchema",
    "QuestionResolutionSchema",
    "VmCveMetadataSchema",
    "VmCveAffectsSchema",
    "DatalakeTables",
    "GLOBAL_TABLE_SCHEMAS",
    "TENANT_TABLE_SCHEMAS",
    "global_table_names",
    "get_semantic_model_path",
    "load_semantic_model",
    "validate_semantic_model",
    "validate_primary_keys",
    "undocumented_columns",
    "ValidationReport",
    "SchemaFinding",
]


#: Every schema class in this package, so scope can be DERIVED rather than listed.
#: Registered here alongside the imports above — one place, already the file every new
#: schema is added to.
_ALL_TABLE_SCHEMAS = (
    IdentitySchema, RepositoriesSchema, VulnerabilitySchema, AssetsSchema,
    DatastoresSchema, ArtifactsSchema, FindingsSchema, IssuesSchema,
    ControlsSchema, PackagesSchema, PentestCasesSchema, PentestRunsSchema,
    EntityEdgesSchema, EntityEdgeCandidatesSchema,
    EntityGraphDerivationMetricsSchema, EntityPropertiesResolvedSchema,
    JoinTrustSchema, QuestionResolutionSchema,
    VmCveMetadataSchema, VmCveAffectsSchema,
)

#: Schemas that live in the shared ``public`` schema rather than a tenant schema.
#: DERIVED from each schema's own ``scope`` property — never hand-maintained, because a
#: hand-maintained parallel list is exactly the drift ``core/source_sync.py`` exists to
#: prevent (see ``TableSchema.scope`` for the incident this comes from).
GLOBAL_TABLE_SCHEMAS = tuple(
    s for s in _ALL_TABLE_SCHEMAS if getattr(s(), "scope", "tenant") == "global"
)

#: Schemas that live in a per-tenant ``tenant_<uuid>`` schema — the complement of
#: ``GLOBAL_TABLE_SCHEMAS``, derived the same way and for the same reason.
#:
#: ⛔ MEASURED 2026-09-07, the drift this exists to end. `tenants.py` hand-listed the
#: tenant tables it provisions, and the list had fallen ONE behind the declarations:
#: 15 listed, 16 declared. The missing one was `entity_properties_resolved`, whose
#: writer had deliberately stopped creating it (S26: "provisioned by the datalake
#: reconciler alongside every other tenant table") — but the reconciler's list was
#: never updated to receive the handoff. The table survived only because it predated
#: that change, and NO column declared on it since has ever been added.
#:
#: ⚠️ The failure is silent: the upsert strips keys with no physical column, so a
#: write logs a successful row count and every consumer reads the default forever.
TENANT_TABLE_SCHEMAS = tuple(
    s for s in _ALL_TABLE_SCHEMAS if getattr(s(), "scope", "tenant") != "global"
)


def global_table_names() -> list:
    """Names of the tenant-independent (``public``-schema) tables, sorted.

    Consumed by ``pantheon_transformers.core.source_sync`` to emit the ``torana_global``
    dbt source group, so ``{{ source('torana_global', X) }}`` resolves for these tables
    the same way ``{{ source('torana', X) }}`` does for tenant sink tables.
    """
    return sorted(s().table_name for s in GLOBAL_TABLE_SCHEMAS)


def get_semantic_model_path() -> Path:
    """
    Get path to the semantic model YAML file.

    Returns:
        Path: Absolute path to torana_security_mesh_semantic_model.yaml

    Example:
        >>> from pantheon_shared.datalake.schemas import get_semantic_model_path
        >>> path = get_semantic_model_path()
        >>> print(path.exists())
        True
    """
    # ⚠️ Renamed from `..._updated.yaml` on 2026-09-14. The `_updated` suffix was a
    # timestamp that never updated: two stale copies also carried the name, and the
    # OLDEST file in the tree (pantheon-playground, 2025-11-28) was the one called
    # "updated". There is now exactly ONE semantic model and it has no suffix.
    return Path(__file__).parent / "torana_security_mesh_semantic_model.yaml"


def load_semantic_model() -> Dict[str, Any]:
    """
    Load and parse the semantic model YAML file.

    D4 — SCOPE OF AUTHORITY (DYNAMIC_SCHEMA_FOR_TEXT_TO_SQL.md):
    This YAML is NO LONGER the authority for table COLUMNS. The column truth comes
    from live DB introspection via datalake's get_all_table_columns / get_table_columns
    (always current; covers canonical + transformer tables). This YAML is retained
    ONLY as the MEANING overlay source — the synonyms, enum values, and join
    relationships that datalake's get_query_hints projects. Do NOT reintroduce a
    consumer that reads columns from here; partial/stale column data here is the
    exact bug that effort fixed (e.g. identities was absent → hallucinated columns).

    Returns:
        Dict[str, Any]: Parsed semantic model containing:
            - name: Model name
            - description: Model description
            - tables: List of table definitions with dimensions, metrics, and synonyms
              (consumed for MEANING — synonyms/enums — not as the column authority)
            - relationships: List of relationship definitions between tables
              (the curated join graph projected by get_query_hints)

    Raises:
        FileNotFoundError: If semantic model YAML file doesn't exist
        yaml.YAMLError: If YAML parsing fails

    Example:
        >>> from pantheon_shared.datalake.schemas import load_semantic_model
        >>> model = load_semantic_model()
        >>> print(model['name'])
        'torana_security_mesh_semantic_model'
        >>> print(len(model['tables']))
        7
    """
    import yaml

    model_path = get_semantic_model_path()

    if not model_path.exists():
        raise FileNotFoundError(f"Semantic model not found at: {model_path}")

    with open(model_path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)


# Imported last: validation reads _ALL_TABLE_SCHEMAS defined above.
from .validation import (  # noqa: E402
    SchemaFinding,
    ValidationReport,
    undocumented_columns,
    validate_primary_keys,
    validate_semantic_model,
)
