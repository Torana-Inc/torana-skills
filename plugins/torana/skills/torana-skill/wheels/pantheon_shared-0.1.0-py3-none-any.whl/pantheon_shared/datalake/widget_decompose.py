"""Widget row decomposition — the rows an aggregate cell was computed FROM.

A dashboard widget that groups collapses many records into one displayed row.
Clicking that row should reveal what it collapsed. This module answers, from the
widget's own SQL alone: *which records constitute this row, and which columns
make up each number in it?*

⛔ WHY THIS IS A REWRITE OF THE WIDGET'S SQL, NOT A QUERY AGAINST THE BASE TABLE
-------------------------------------------------------------------------------
`WIDGET_IMPROVEMENTS_SPEC.md` § 3.3 designed a drill as
`SELECT * FROM <source_table> WHERE <displayed column> = <clicked value>`, and
§ 0.2 records that it was REMOVED before shipping. It could not work: a widget's
displayed columns are frequently aliased or computed (`CASE … AS fixability`), so
filtering the base table by the displayed NAME errors with
`column "fixability" does not exist`.

This takes the other route. The widget's SQL already contains the exact relation
its aggregate was computed over, so we keep that relation verbatim — the same
FROM, the same JOINs, the same WHERE — and remove only the aggregation. No
displayed alias is ever referenced, so the failure that killed the original
approach cannot arise.

⭐ THE PROJECTION — three parts, and the third is not optional
--------------------------------------------------------------
    A. the GROUP BY keys                      (what identifies the clicked row)
    B. every column INSIDE an aggregate       (what the numbers are made of)
    C. the driving table's PRIMARY KEY        (what makes the rows distinct)

⚠️ C exists because of a measured bug. An earlier version projected A+B under
`SELECT DISTINCT`, reasoning that the distinct tuple IS the unit being counted.
That holds for `COUNT(DISTINCT col)` and is catastrophically wrong for `COUNT(*)`:

    widget:    SELECT severity, COUNT(*) FROM vulnerabilities GROUP BY severity
    cell:      Medium = 50,810
    A+B DISTINCT decomposition  ->       1 row      ⛔ off by 50,809
    A+B+C, no DISTINCT          ->  50,810 rows     ✅

`COUNT(*)` has no argument column, so without the primary key there is nothing in
the projection that differs between two constituent rows. Hence: **never
`DISTINCT`, always project the key.** The detail set is the pre-aggregation row
set, exactly.

⚠️ ROW COUNT AND METRIC VALUE ARE DIFFERENT NUMBERS, and the caller must show
both. Measured on a live tenant, a widget grouping (severity, package_manager)
with `COUNT(DISTINCT cve_id)`: the cell reads **218** while the constituent rows
number **45,993**. Both are correct — the metric counts distinct CVEs, the rows
are findings. A panel that shows only the row count next to a cell reading 218
looks broken. Use `reconciliation_sql()` to recompute each metric over the detail
set and display the derivation.

⛔ WHY RECONCILIATION IS SQL AND NOT PYTHON
-------------------------------------------
Recomputing `COUNT(DISTINCT …)` / `MAX(…)` in Python would be a second
implementation of SQL aggregate semantics — NULL handling, DISTINCT, collation —
and it would drift from the first one silently. The database that produced the
cell recomputes it.

This module issues no queries and holds no opinion about rows. It reads SQL and
returns SQL. Fetching, binding and paging are the caller's job.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple, Union

import sqlglot
from sqlglot import exp

# Decomposition kinds. `GROUPED` and `UNGROUPED` are both decomposable; the other
# two are not, for different reasons the UI must word differently.
KIND_GROUPED = "grouped"          # GROUP BY present — pin the clicked keys
KIND_UNGROUPED = "ungrouped"      # aggregate, no GROUP BY (a scalar) — whole population
KIND_NOT_AGGREGATE = "not_aggregate"   # each displayed row is already one record
KIND_UNSUPPORTED = "unsupported"       # could not be parsed/rewritten safely

_DIALECT = "postgres"

#: Identifier-safe fallback for a GROUP BY key that is an expression rather than a
#: bare column (e.g. ``DATE_TRUNC('month', ts)``), which has no natural name.
_SYNTHETIC_KEY = "group_key_{i}"


@dataclass(frozen=True)
class Metric:
    """One aggregate in the widget's SELECT — a number in the clicked row."""

    alias: str
    """Displayed column name (``image_count``)."""

    expression: str
    """The aggregate as written (``COUNT(DISTINCT v.torana_artifact_id)``)."""

    arg_columns: Tuple[str, ...]
    """Columns inside the aggregate. Empty for ``COUNT(*)`` — which is exactly
    why the projection also carries a primary key."""


@dataclass(frozen=True)
class Projection:
    """One output column of the detail query."""

    expression: str
    """As written in the widget's SQL (``v.torana_artifact_id``)."""

    alias: str
    """Output name, unqualified and de-duplicated. `reconciliation_sql` rewrites
    metric expressions onto these, so they must be stable and collision-free."""

    role: str
    """``key`` | ``metric_arg`` | ``row_identity`` — lets the UI group columns."""


@dataclass(frozen=True)
class Decomposition:
    """The result of analysing one widget's SQL."""

    kind: str
    sql: Optional[str] = None
    """Parameterised detail SQL, pyformat (``%(cve_id)s``) — bind, never format."""

    params: Tuple[str, ...] = ()
    """Parameter names, each taken from the clicked row by the same name."""

    placeholders: Tuple[str, ...] = ()
    """The placeholder each of `params` binds under in `sql`, in the same order.
    ⛔ A displayed name is not always a safe placeholder: psycopg reads
    `%(Sev (raw))s` up to the first `)`. An identifier-shaped name binds as
    itself; any other binds as `k<i>`. Build the bound dict as
    ``{placeholder: row[param]}``."""

    group_keys: Tuple[str, ...] = ()
    metrics: Tuple[Metric, ...] = ()
    projection: Tuple[Projection, ...] = ()
    reason: Optional[str] = None
    """Why this is not decomposable. Set only for the two non-decomposable kinds;
    it is written to be shown to a user verbatim."""

    warnings: Tuple[str, ...] = ()
    """Non-fatal caveats the UI should surface (e.g. no primary key available)."""

    cte_sql: Optional[str] = None
    body_sql: Optional[str] = None
    """`sql` split into its WITH clause and the SELECT after it, when it has one.
    `reconciliation_sql` puts the WITH OUTSIDE its wrapper, because a metric can
    name a CTE (`BOOL_OR(l.scan_type IN (SELECT … FROM required))`) and a CTE
    defined inside the wrapped subquery is out of scope there. Re-parsing `sql` to
    split it is not an option: a placeholder named after a displayed column
    (`%(Where the change is made)s`) does not parse back."""

    empty_state_sql: Optional[str] = None
    """A query (same placeholders as `sql`) that returns a row when the clicked
    row is a placeholder the widget adds when it has nothing to count, not a group
    of records. When it returns a row, show `empty_state_reason` instead of
    drilling: the drill would open nothing and its reconciliation would report a
    mismatch on a healthy widget."""

    empty_state_reason: Optional[str] = None

    row_identity: Tuple[str, ...] = ()
    """The projected aliases that together identify one detail row, in key
    order. More than one for a composite key (`image_key`, `package_key`); a
    caller pages and binds by ALL of them, never by the first."""

    row_identity_unique: bool = False
    """Is the `row_identity` column unique across the detail rows? Only then may a
    caller page by it (`WHERE key > cursor`). ⛔ A join anywhere between the
    driving table and the detail query, at the top or at any CTE hop, can repeat a
    row, and keyset paging then SKIPS every repeat of the row on the page
    boundary while the reconciliation still matches. Decided from the SQL's shape,
    never from today's data."""

    @property
    def decomposable(self) -> bool:
        return self.kind in (KIND_GROUPED, KIND_UNGROUPED)


def _aggregates(select: exp.Select) -> List[Tuple[str, exp.AggFunc]]:
    """Aggregates in the SELECT list, EXCLUDING window functions.

    ⚠️ `COUNT(*) OVER (PARTITION BY …)` is an `AggFunc` to sqlglot but is NOT a
    grouping aggregate — it produces one value per ROW, so there is nothing to
    decompose and treating it as a metric would invent a grouping that the query
    does not have.

    ⚠️ A ``FILTER (WHERE …)`` clause is part of the metric, not decoration.
    sqlglot models it as a `Filter` NODE WRAPPING the `AggFunc`, so returning the
    bare `AggFunc` silently drops the predicate: `COUNT(*) FILTER (WHERE is_kev)`
    becomes `COUNT(*)`. MEASURED 2026-09-08 on `vulnerabilities_by_team` — four
    differently-filtered metrics all reconciled to the same 1,396, which reads as
    "the numbers are wrong" when in fact the recomputation was. The wrapping
    `Filter` is returned whenever there is one.
    ⛔ ONE METRIC PER OUTPUT COLUMN, never one per aggregate. A column can wrap
    SEVERAL aggregates in a single expression:

        ROUND(100.0 * COUNT(*) FILTER (WHERE NOT is_sla_breached)
              / NULLIF(COUNT(*), 0), 1) AS sla_compliance_pct

    Emitting a Metric per AggFunc produced `sla_compliance_pct` TWICE, each
    carrying only a fragment, and reconciliation then recomputed a raw count
    (1058) and compared it against a percentage (72.9) — reporting a MISMATCH on
    a widget whose arithmetic was correct (MEASURED 2026-09-08:
    100.0*1058/1451 = 72.9). A panel whose job is to say which number to trust
    must never accuse a healthy widget. The whole column expression is the
    metric, recomputed exactly as written.
    """
    out: List[Tuple[str, exp.Expression]] = []
    for item in select.expressions:
        aggs = [a for a in item.find_all(exp.AggFunc)
                if a.find_ancestor(exp.Window) is None
                # ⛔ AN AGGREGATE INSIDE A SUBQUERY IS NOT THIS SELECT'S
                # AGGREGATE. `find_all` descends into scalar subqueries, so a
                # correlated
                #     (SELECT COUNT(*) FROM prioritized_vulnerabilities pv
                #      WHERE date_trunc('week', pv.scan_first_detected_date)
                #            = w.week_start) AS arrivals
                # looked like an aggregate of the OUTER select. Stripping it
                # hoisted `pv.scan_first_detected_date` into a scope where `pv`
                # does not exist, and Postgres refused the whole detail query
                # with `missing FROM-clause entry for table "pv"`.
                # MEASURED 2026-09-09 on `arrival_vs_closure_weekly` (both T2
                # and Classie): the drill-down was dead on every widget built
                # this way.
                # ⚠️ The subquery has its OWN FROM and its own aliases; the outer
                # query cannot reach them. Such a column is not decomposable
                # from here, so it must not be reported as a metric at all.
                and a.find_ancestor(exp.Subquery) is None]
        if not aggs:
            continue
        # Unwrap `expr AS name` so the metric is the EXPRESSION itself.
        expr = item.this if isinstance(item, exp.Alias) else item
        # A bare aggregate keeps its FILTER wrapper; anything compound is taken
        # whole, so the arithmetic between its aggregates survives.
        if len(aggs) == 1:
            filt = aggs[0].find_ancestor(exp.Filter)
            single = filt if filt is not None else aggs[0]
            if single.sql() == expr.sql():
                expr = single
        out.append((item.alias_or_name, expr))
    return out


def _key_name(key: exp.Expression, select: exp.Select, index: int,
              names: Optional[Mapping[str, str]] = None) -> str:
    """A parameter name for one GROUP BY key.

    A bare column names itself. An expression key (``DATE_TRUNC('month', ts)``)
    has no name of its own, so we take the alias of the matching SELECT item —
    which is what the clicked row is keyed by — and fall back to a positional
    synthetic name only when nothing matches.

    `names` overrides both, keyed by the key's SQL. `_cte_lift` uses it to bind
    every key under the name the widget DISPLAYS: after a lift a bare key is the
    CTE's column (`c.change`), a name the clicked row does not carry.
    """
    key_sql = key.sql(dialect=_DIALECT)
    if names and key_sql in names:
        return names[key_sql]
    if isinstance(key, exp.Column):
        return key.name
    for item in select.expressions:
        target = item.this if isinstance(item, exp.Alias) else item
        if target.sql(dialect=_DIALECT) == key_sql:
            name = item.alias_or_name
            if name:
                return name
    return _SYNTHETIC_KEY.format(i=index)


def _bind_names(keys: List[exp.Expression], select: exp.Select,
                names: Optional[Mapping[str, str]] = None
                ) -> Tuple[List[str], Optional[str]]:
    """(the name each key binds under, a refusal reason or None).

    ⛔ #685. A bare grouped column binds by its RAW column name, which is wrong
    in two shapes, and both drill into the wrong rows silently:
      1. `a.sev AS "A", b.sev AS "B" … GROUP BY a.sev, b.sev` → both keys are
         `sev`, so both bind the same value and `b.sev` is filtered by A's;
      2. `s.note AS decision, s.decision AS "Decision"` → the key `s.decision`
         binds as `decision`, which is the DISPLAYED name of `s.note`.
    So a bare key whose raw name is ambiguous (shared with another key, or
    equal to a different column's displayed name) binds under its OWN displayed
    alias instead, as the CTE lift already does. A raw name that is not
    ambiguous keeps binding as itself, so no working widget changes its SQL.
    If two keys still resolve to one name, nothing can tell their values apart,
    and the decomposition refuses, naming the columns.
    """
    base = [_key_name(k, select, i, names) for i, k in enumerate(keys)]
    shown: Dict[str, str] = {}          # displayed name -> SQL of what it shows
    alias_of: Dict[str, str] = {}       # SQL of a selected expression -> its alias
    for item in select.expressions:
        target = item.this if isinstance(item, exp.Alias) else item
        t_sql = target.sql(dialect=_DIALECT)
        shown.setdefault(item.alias_or_name, t_sql)
        if isinstance(item, exp.Alias):
            alias_of.setdefault(t_sql, item.alias)
    out: List[str] = []
    for i, (key, name) in enumerate(zip(keys, base)):
        k_sql = key.sql(dialect=_DIALECT)
        ambiguous = isinstance(key, exp.Column) and (
            base.count(name) > 1 or shown.get(name, k_sql) != k_sql)
        out.append(alias_of.get(k_sql, name) if ambiguous else name)
    for name in set(out):
        if out.count(name) > 1:
            cols = [k.sql(dialect=_DIALECT) for k, n in zip(keys, out) if n == name]
            return out, (f"This widget groups by {' and '.join(cols)}, which are both "
                         f"shown as \"{name}\", so a clicked row cannot say which value "
                         f"belongs to which. Give them different names in the widget "
                         f"to open its rows.")
    return out, None


def _unique_alias(base: str, taken: set) -> str:
    """A collision-free output name. Two source tables can both project
    `severity`; the second becomes `severity_2` so `reconciliation_sql` can still
    address each unambiguously.

    ⛔ COMPARED CASE-INSENSITIVELY. The aliases are emitted unquoted, so Postgres
    folds them: `Severity` and `severity` are one output name, and the second
    silently shadowed the first in the reconciliation, which then dropped that
    metric's verdict. `taken` holds lower-cased names."""
    base = re.sub(r"\W", "_", base) or "col"
    if base.lower() not in taken:
        taken.add(base.lower())
        return base
    i = 2
    while f"{base}_{i}".lower() in taken:
        i += 1
    alias = f"{base}_{i}"
    taken.add(alias.lower())
    return alias


#: How many CTE hops a resolution follows before it stops. Widgets nest two or
#: three deep; a longer chain is far more likely a mistake than a design.
_MAX_CTE_HOPS = 8


@dataclass(frozen=True)
class _Source:
    """Where the rows of one SELECT come from, followed through its CTE chain."""

    table: Optional[str]
    """The real relation at the end of the chain, or None when resolution stopped."""

    alias: Optional[str]
    """The name in scope in the detail query (the FROM alias, else its name)."""

    chain: Tuple[Tuple[str, exp.Select], ...] = ()
    """The CTEs walked, outermost first, as (name, body)."""

    stop: Optional[str] = None
    """Where and why resolution stopped, as "`<cte>`, which …", for a reader."""


def _ctes(select: exp.Select) -> Dict[str, exp.CTE]:
    with_ = select.args.get("with_")
    return {c.alias: c for c in with_.expressions} if with_ is not None else {}


def _renames_columns(cte: exp.CTE) -> bool:
    """`WITH a(x, y) AS (…)` renames its outputs positionally; the names its body
    selects are then not the names a reader of `a` sees."""
    alias = cte.args.get("alias")
    return bool(alias is not None and alias.columns)


def _union_branches(tree: exp.Expression) -> List[exp.Expression]:
    """The branches of a (possibly nested) UNION, in order."""
    if isinstance(tree, exp.Union):
        return _union_branches(tree.left) + _union_branches(tree.right)
    return [tree]


def _reads_relation(select: exp.Select, ctes: Mapping[str, exp.CTE],
                    seen: frozenset = frozenset()) -> bool:
    """Does this SELECT draw its rows from a real relation?

    Only its FROM and JOIN sources count, followed through CTEs: a filter such as
    `WHERE NOT EXISTS (SELECT 1 FROM labelled …)` reads a relation without drawing
    rows from it. `VALUES` and literal-only SELECTs draw from none. Anything this
    cannot classify counts as a relation, so an unknown never passes for empty.
    """
    sources: List[exp.Expression] = []
    if select.args.get("from_") is not None:
        sources.append(select.args["from_"].this)
    sources += [j.this for j in select.args.get("joins") or []]
    for src in sources:
        if isinstance(src, exp.Table):
            if src.name not in ctes:
                return True
            if src.name in seen:
                continue
            body = ctes[src.name].this
            for b in _union_branches(body):
                if isinstance(b, exp.Values):
                    continue
                if not isinstance(b, exp.Select) or _reads_relation(
                        b, ctes, seen | {src.name}):
                    return True
        elif isinstance(src, exp.Values):
            continue
        elif isinstance(src, exp.Subquery):
            for b in _union_branches(src.this):
                if isinstance(b, exp.Values):
                    continue
                if not isinstance(b, exp.Select) or _reads_relation(b, ctes, seen):
                    return True
        else:
            return True
    return False


def _driving_source(select: exp.Select) -> _Source:
    """The relation supplying the rows of `select`, followed through its CTE chain.

    ⭐ A WIDGET READS ITS ROWS THROUGH A CHAIN OF CTEs, not through one. Every
    widget in the EM bundles is CTE-driven, and a CTE commonly reads another
    (`labelled` reads `posture_scanner_reports`, `per_scanner` reads `labelled`).
    Following one hop and stopping left those widgets with no row identity, so a
    `COUNT(*)` drill-down returned rows nobody could tell apart. The chain is
    walked to the real relation, and the ALIAS returned is the outer one: the
    detail query still selects `FROM <cte>`, so the identity column must be
    qualified by the name in scope there.

    ⛔ EVERY HOP MUST READ A PLAIN TABLE OR CTE. A hop that reads a subquery,
    combines several queries (UNION) or renames its columns in a column list
    stops resolution rather than guessing which part carries identity: a wrong
    identity column is worse than a stated absence. A cycle and a chain longer
    than `_MAX_CTE_HOPS` stop too. `stop` names the CTE where it stopped, so the
    caller's "no primary key" warning says WHERE instead of leaving the reader to
    search the SQL.

    A hop that JOINs follows its FROM side, exactly as the outer query's own FROM
    does. ⚠️ A fan-out join can repeat a FROM-side row, so its key is then not
    unique in the detail set; that limit is the outer query's too, and stopping
    here instead cost Scanner Finding Outcomes the row identity it had (MEASURED
    2026-10-01, T1). `_key_through_chain` makes sure the key it carries really is
    the FROM side's.
    """
    frm = select.args.get("from_")
    if frm is None or not isinstance(frm.this, exp.Table):
        return _Source(None, None)
    name = frm.this.name
    alias = frm.this.alias or name
    ctes = _ctes(select)

    chain: List[Tuple[str, exp.Select]] = []
    seen: set = set()

    def _stop(why: str) -> _Source:
        return _Source(None, alias, tuple(chain), f"`{name}`, which {why}")

    while name in ctes:
        if name in seen:
            return _stop("is read again further down its own chain")
        if len(chain) >= _MAX_CTE_HOPS:
            return _stop(f"is more than {_MAX_CTE_HOPS} CTEs deep")
        seen.add(name)
        cte = ctes[name]
        if _renames_columns(cte):
            return _stop("renames its columns in a column list")
        body = cte.this
        if not isinstance(body, exp.Select):
            return _stop("combines several queries")
        chain.append((name, body))
        inner = body.args.get("from_")
        if inner is None:
            return _stop("reads no relation")
        if not isinstance(inner.this, exp.Table):
            return _stop("reads a subquery")
        name = inner.this.name
    return _Source(name, alias, tuple(chain))


def _key_through_chain(source: _Source, col: str) -> Tuple[Optional[str], Optional[str]]:
    """(name the key has at the top of the chain, None), or (None, where it stopped).

    ⛔ A RESOLVED PRIMARY KEY IS NOT AUTOMATICALLY REACHABLE. Every CTE on the
    chain stands between the table and the detail query. If ANY of them does not
    project the key, selecting it raises `column does not exist` and the whole
    drill-down fails, which is strictly worse than the "no primary key" warning it
    was meant to replace (measured 2026-09-15, Exposure Data Exploration:
    "column o.finding_id does not exist", HTTP 500 on every click). So the key is
    traced from the table UP through each CTE, following a rename (`id AS key`).

    ⛔ THE KEY MUST COME FROM THE FROM SIDE. In a hop that joins, `i.id` is the
    joined table's `id`, not the FROM table's; matching on the name alone made
    `items.id` pass for `orders.id`. So a column only counts when it is qualified
    by the FROM side's alias, or is unqualified in a hop with no join, and `*`
    across a join stops the trace. A computed column that merely carries the key's
    NAME is not the key either.
    """
    for name, body in reversed(source.chain):
        frm = body.args["from_"].this
        from_alias = frm.alias or frm.name
        joined = bool(body.args.get("joins"))
        out: Optional[str] = None
        for item in body.expressions:
            target = item.this if isinstance(item, exp.Alias) else item
            star = isinstance(item, exp.Star) or (
                isinstance(target, exp.Column) and isinstance(target.this, exp.Star))
            if star:
                qualifier = target.table if isinstance(target, exp.Column) else ""
                if qualifier == from_alias or (not qualifier and not joined):
                    out = col
                    break
                if not qualifier and joined:
                    return None, f"`{name}`, which selects * across a join"
                continue
            if (isinstance(target, exp.Column) and target.name == col
                    and (target.table == from_alias
                         or (not target.table and not joined))):
                out = item.alias_or_name
                break
        if out is None:
            return None, f"`{name}`, which does not carry `{col}`"
        col = out
    return col, None


def _resolve_output_alias(key: exp.Expression, select: exp.Select
                          ) -> Tuple[exp.Expression, bool]:
    """(the expression `key` groups by, whether that is AMBIGUOUS).

    `GROUP BY team` where `team` is an output alias (`v.owner AS team`) groups
    by `v.owner`. Left unresolved, the key matches no column and every check that
    asks "is this group pinned?" answers no without saying why.

    ⛔ POSTGRES PREFERS THE INPUT COLUMN. In `SELECT lower(v.severity) AS severity
    … GROUP BY severity` the name resolves to `v.severity` when the input has such
    a column, so pinning `lower(v.severity)` would pin a different grouping. This
    module cannot see the input's columns, so an unqualified key that names an
    output EXPRESSION is reported as ambiguous. An alias of a bare column with a
    different name (`v.owner AS team`) is resolved: the widget author renamed a
    column, and that is the reading the widget's own numbers were checked under.
    """
    if isinstance(key, exp.Column) and not key.table:
        for item in select.expressions:
            if not (isinstance(item, exp.Alias) and item.alias == key.name):
                continue
            if isinstance(item.this, exp.Column):
                if item.this.name == key.name:
                    return key, False
                return item.this.copy(), False
            return key, True
    return key, False


@dataclass(frozen=True)
class _Lift:
    """What `_cte_lift` found. `select` None with `stop` None: the shape does not
    apply (the outer SELECT does not read an aggregating CTE)."""

    select: Optional[exp.Select] = None
    names: Optional[Mapping[str, str]] = None
    """{key expression SQL: displayed name}."""
    warnings: Tuple[str, ...] = ()
    stop: Optional[str] = None
    empty_state: Optional[exp.Expression] = None
    """A query returning a row when the clicked keys come from the CTE's
    empty-state part rather than its counts (see `_cte_lift`). Its placeholders
    are named by displayed key; the caller renames them."""
    empty_state_cte: Optional[str] = None


def _cte_lift(tree: exp.Select, seen: Tuple[str, ...] = ()) -> _Lift:
    """Lift a widget that only PASSES THROUGH an aggregating CTE onto that CTE.

    ⭐ THE AGGREGATION LIVES ONE CTE DOWN. A widget commonly computes its numbers
    in a CTE and only formats them in the outer SELECT:

        WITH per_scanner AS (SELECT l.scanner, COUNT(*) AS reports
                               FROM labelled l GROUP BY l.scanner)
        SELECT p.scanner AS "Scanner", p.reports AS "Reports" FROM per_scanner p

    The outer SELECT has no aggregate, so it was refused as "a summary of several
    different things", and 306,437 Container Analysis reports could not be opened
    (MEASURED 2026-10-01, T1, Scanner Sources). This rewrites the widget onto the
    CTE: every displayed number the outer SELECT takes from the CTE is replaced by
    the CTE's own expression, under the DISPLAYED name, and the CTE's FROM, JOINs
    and WHERE stand as written. The result is an ordinary aggregating SELECT,
    which the rest of this module already decomposes.

    ⛔ EVERY GROUP OF THE CTE MUST BE PINNED EXACTLY, or the drill returns rows
    from OUTSIDE the clicked cell. A group is pinned exactly when the widget
    displays that GROUP BY column as it is (a bare reference, a rename is fine).
    Anything else refuses, naming the CTE and the column:
      * a group column the widget does not show. MEASURED on T1, Highest-Impact
        Remediation: `ranked` groups by `change_key`, and "Mitigate ecdsa" has
        two change keys, so pinning the displayed columns returned both groups;
      * a group column shown only through an expression that can merge groups
        (`COALESCE(x, 'unknown')`, a digest-truncating `regexp_replace`);
      * a displayed key taken from another relation the outer SELECT joins;
      * ROLLUP, CUBE or GROUPING SETS, whose subtotal rows no key value names.
    When every group is pinned, the clicked row IS one group, so the outer
    SELECT's own WHERE, JOINs, GROUP BY and DISTINCT, which only decide WHICH
    groups are displayed, need not be re-applied.

    ⚠️ AN EMPTY-STATE PART IS NOT A DATA ROW. `per_scanner` is its counts UNION
    ALL one placeholder row per required scan type no scanner sends
    ("none: IAC required, no scanner sends it"). Drilling a placeholder opens no
    rows, and its reconciliation then accused a healthy widget of a mismatch on
    2 of 8 rows (T1). A branch that draws rows from no relation is treated as the
    empty state: `empty_state` lets the caller recognise a click on one and say
    so instead of drilling. A second branch that reads real rows is a different
    population, so the lift refuses.

    Columns the lift drops from the projection: windows (`COUNT(*) OVER …`),
    columns of another relation the outer SELECT joins, subqueries, constants.
    A CTE that aggregates nothing but reads another CTE is lifted through, with
    the same cycle guard and depth cap as `_driving_source`.
    """
    frm = tree.args.get("from_")
    if frm is None or not isinstance(frm.this, exp.Table):
        return _Lift()
    ctes = _ctes(tree)
    name = frm.this.name
    if name not in ctes:
        return _Lift()

    def _stop(why: str) -> _Lift:
        return _Lift(stop=f"`{name}`, which {why}")

    if name in seen:
        return _stop("is read again further down its own chain")
    if len(seen) >= _MAX_CTE_HOPS:
        return _stop(f"is more than {_MAX_CTE_HOPS} CTEs deep")
    if _renames_columns(ctes[name]):
        return _stop("renames its columns in a column list")
    outer = frm.this.alias or name

    body = ctes[name].this
    empty_branches: List[exp.Select] = []
    if isinstance(body, exp.Union):
        branches = _union_branches(body)
        data = [b for b in branches if isinstance(b, exp.Select) and _aggregates(b)]
        if len(data) != 1:
            # Several aggregating parts, or none: no single population. The
            # caller's own wording for that case stands.
            return _Lift()
        for b in branches:
            if b is data[0]:
                continue
            if not isinstance(b, exp.Select) or _reads_relation(b, ctes):
                return _stop("adds rows that are not its counts to the rows it counts")
            empty_branches.append(b)
        body = data[0]
    if not isinstance(body, exp.Select):
        return _Lift()

    # {output name: the CTE's expression for it}
    cols: Dict[str, exp.Expression] = {}
    for item in body.expressions:
        if isinstance(item, exp.Star) or (
                isinstance(item, exp.Column) and isinstance(item.this, exp.Star)):
            return _stop("selects *, so its columns cannot be traced")
        cols[item.alias_or_name] = item.this if isinstance(item, exp.Alias) else item

    joined = bool(tree.args.get("joins"))

    def _from_cte(c: exp.Column) -> bool:
        return (c.table == outer or (not c.table and not joined)) and c.name in cols

    def _substitute(node: exp.Expression) -> exp.Expression:
        if isinstance(node, exp.Column) and _from_cte(node):
            repl = cols[node.name].copy()
            # Keep precedence: `x.a * 2` over `a AS b + c` must stay `(b + c) * 2`.
            if isinstance(repl, (exp.Binary, exp.Connector, exp.Not)):
                repl = exp.Paren(this=repl)
            return repl
        return node

    items: List[Tuple[str, exp.Expression, exp.Expression]] = []   # (shown, outer, lifted)
    for item in tree.expressions:
        expr = item.this if isinstance(item, exp.Alias) else item
        columns = list(expr.find_all(exp.Column))
        if (not columns or expr.find(exp.Window) is not None
                or expr.find(exp.Subquery) is not None
                or not all(_from_cte(c) for c in columns)):
            continue
        items.append((item.alias_or_name, expr, expr.copy().transform(_substitute)))
    if not items:
        return _stop("is where this widget's numbers come from, but no column it "
                     "shows can be traced to it")

    warnings: List[str] = []
    if tree.args.get("where") is not None or any(
            j.side != "LEFT" for j in tree.args.get("joins") or []):
        warnings.append(
            f"This widget's own filter decides which rows of `{name}` it shows and "
            f"is not re-applied here. A clicked row is unaffected; opening the "
            f"whole widget can include rows it does not show.")

    lifted = body.copy()
    for arg in ("order", "limit", "offset", "distinct"):
        lifted.set(arg, None)
    with_ = tree.args.get("with_")
    lifted.set("with_", with_.copy() if with_ is not None else None)

    if not _aggregates(body) and not body.args.get("group"):
        # A pass-through CTE: keep every column and look one hop further down.
        lifted.set("expressions",
                   [exp.alias_(e, n, quoted=True) for n, _, e in items])
        deeper = _cte_lift(lifted, seen + (name,))
        if deeper.select is None:
            return deeper
        return _Lift(deeper.select, deeper.names, tuple(warnings) + deeper.warnings,
                     None, deeper.empty_state, deeper.empty_state_cte)

    group = body.args.get("group")
    if group is not None and any(group.args.get(k)
                                 for k in ("rollup", "cube", "grouping_sets")):
        return _stop("groups with ROLLUP, CUBE or GROUPING SETS, so a subtotal row "
                     "is named by no key value")
    group_keys = _resolve_ordinal_keys(list(group.expressions) if group else [], body)
    resolved = [_resolve_output_alias(k, body) for k in group_keys]
    ambiguous = [k.name for k, amb in resolved if amb]
    if ambiguous:
        return _stop(f"groups by {ambiguous[0]}, a name Postgres may read as an input "
                     f"column rather than the expression it labels, so its groups "
                     f"cannot be pinned")
    group_keys = [k for k, _ in resolved]

    # A group is pinned EXACTLY by a displayed bare reference to its column.
    # ⚠️ Match on the CTE's OWN expression (`cols[...]`), not the substituted one:
    # `_substitute` parenthesises a binary expression for precedence, so
    # `(a || ':' || b)` never equalled the GROUP BY's `a || ':' || b` and a widget
    # that shows the key was refused for "not showing" it.
    exact: Dict[str, Tuple[str, exp.Expression]] = {}
    for shown, outer_expr, _ in items:
        if isinstance(outer_expr, exp.Column):
            own = cols[outer_expr.name]
            exact.setdefault(own.sql(dialect=_DIALECT), (shown, own.copy()))
    keys: List[Tuple[str, exp.Expression]] = []
    hidden: List[str] = []
    merged: List[Tuple[str, str]] = []
    for g in group_keys:
        g_sql = g.sql(dialect=_DIALECT)
        if g_sql in exact:
            if exact[g_sql] not in keys:
                keys.append(exact[g_sql])
            continue
        label = next((n for n, e in cols.items()
                      if e.sql(dialect=_DIALECT) == g_sql), g_sql)
        via = [shown for shown, outer_expr, _ in items
               if not isinstance(outer_expr, exp.Column)
               and any(c.name == label for c in outer_expr.find_all(exp.Column))]
        if via:
            merged.append((label, via[0]))
        else:
            hidden.append(label)
    if hidden or merged:
        clauses = []
        if hidden:
            clauses.append(f"groups by {', '.join(hidden)}, which this widget does "
                           f"not show")
        for label, shown in merged:
            clauses.append(f"{'groups ' if not clauses else ''}by {label}, which it "
                           f"shows only through \"{shown}\", an expression that can "
                           f"merge several groups")
        return _stop(", and ".join(clauses))

    metrics = [(shown, e) for shown, _, e in items if any(
        a.find_ancestor(exp.Window) is None and a.find_ancestor(exp.Subquery) is None
        for a in e.find_all(exp.AggFunc))]
    if not metrics:
        return _stop("is where this widget's numbers come from, but none of them "
                     "is shown")

    lifted.set("expressions",
               [exp.alias_(e, n, quoted=True) for n, e in keys + metrics])
    lifted.set("group", exp.Group(expressions=[e.copy() for _, e in keys])
               if keys else None)
    names = {e.sql(dialect=_DIALECT): n for n, e in keys}

    empty_state = None
    if empty_branches and keys:
        out_names = [i.alias_or_name for i in body.expressions]
        probes: List[exp.Select] = []
        for b in empty_branches:
            if len(b.expressions) != len(out_names):
                return _stop("adds rows whose columns do not line up with its counts")
            by_name = {n: (i.this if isinstance(i, exp.Alias) else i).copy()
                       for n, i in zip(out_names, b.expressions)}
            probe = b.copy()
            probe.set("expressions", [exp.Literal.number(1)])
            key_shown = {k for k, _ in keys}
            for shown, outer_expr, _ in items:
                if shown in key_shown and isinstance(outer_expr, exp.Column):
                    probe = probe.where(exp.Paren(this=exp.EQ(
                        this=_paren(by_name[outer_expr.name]),
                        expression=exp.Placeholder(this=shown))), copy=False)
            probes.append(probe)
        empty_state = probes[0]
        for extra in probes[1:]:
            empty_state = exp.union(empty_state, extra, distinct=False)
        if with_ is not None:
            empty_state.set("with_", with_.copy())
    return _Lift(lifted, names, tuple(warnings), None, empty_state,
                 name if empty_state is not None else None)


def _resolve_ordinal_keys(
    keys: List[exp.Expression],
    tree: exp.Select,
) -> List[exp.Expression]:
    """Replace ``GROUP BY 1`` with the SELECT expression it points at.

    ⚠️ MEASURED (2026-09-08, tenant T2): ``critical_age_buckets`` is written
    ``GROUP BY 1`` over a ``CASE … END AS age_bucket``. Left as a literal, the key
    is the integer ``1`` — which is not a column, cannot be bound from the clicked
    row, and would emit ``WHERE 1 = %(param)s``: valid SQL that filters nothing and
    silently returns the WHOLE population as the "rows behind" one bucket.

    Postgres ordinals are 1-based and index the SELECT list. An alias
    (``expr AS name``) is unwrapped to the underlying expression, because the alias
    does not exist yet at the point the rewritten WHERE is applied.

    Out-of-range or non-integer entries are returned unchanged; the caller then
    treats them exactly as any other expression key.
    """
    if not keys:
        return keys
    selects = list(tree.expressions or [])
    out: List[exp.Expression] = []
    for key in keys:
        resolved = key
        if isinstance(key, exp.Literal) and not key.args.get("is_string"):
            try:
                pos = int(key.name)
            except (TypeError, ValueError):
                pos = 0
            if 1 <= pos <= len(selects):
                target = selects[pos - 1]
                resolved = target.this if isinstance(target, exp.Alias) else target
                resolved = resolved.copy()
        out.append(resolved)
    return out


def _not_aggregate_reason(tree: exp.Select, dialect: str = _DIALECT) -> str:
    """Why this widget's rows cannot be opened — two different answers.

    ⛔ THE DEFAULT WORDING IS FALSE FOR ONE OF THEM. "Each row it shows is already
    a single record" is right for a row-level table (`SELECT ... FROM stalled_tickets`),
    and plainly wrong for a widget whose every row IS an aggregate — just of a
    different population:

        SELECT 'Repositories',     (SELECT COUNT(*) FROM allrepo)      UNION ALL
        SELECT 'Container images', (SELECT COUNT(*) FROM images)       UNION ALL
        SELECT 'Assets',           (SELECT COUNT(*) FROM assets)

    MEASURED on Classie ("What we found in your environment"). A reader looking at
    seven counts is told none of them is a count. Both cases are equally
    un-decomposable — there is no shared row set to open — but saying so wrongly
    costs trust in the one panel whose whole job is to be trustworthy.

    ⚠️ SAY WHAT THEY ARE LOOKING AT, not why the machinery cannot act. Two
    earlier drafts explained the mechanism — "not slices of one population", then
    "each row counts a different kind of thing" — and both read as riddles,
    because a reader does not arrive wondering about populations. They arrive
    wanting records. Name the widget for what it is (a summary of several
    different things), say plainly there is nothing to open, and point at the
    numbers that ARE there. ⛔ The last sentence is a promise the UI must keep:
    it is only true because the panel renders the widget's own rows underneath.

    The tell is an aggregate that exists but sits inside a SUBQUERY rather than in
    the SELECT list, so `_aggregates` (which reads the SELECT list only) finds
    none.
    """
    nested = [a for a in tree.find_all(exp.AggFunc)
              if a.find_ancestor(exp.Window) is None]
    if nested:
        # ⛔ NAME THE WIDGET'S OWN RELATIONS. This sentence used to hardcode
        # "repositories, images, assets", so a severity rollup was told it
        # summarised repositories and images — a confident, wrong explanation of
        # a refusal the reader cannot otherwise diagnose. Read the relations out
        # of the SQL, and say the generic thing when none can be named.
        names: List[str] = []
        for t in tree.find_all(exp.Table):
            n = t.name
            if n and n not in names:
                names.append(n)
        if names:
            shown = ", ".join(names[:3])
            return (f"This widget is a summary of several different things — "
                    f"{shown} — so there is nothing to open. "
                    f"The numbers it shows are below.")
        return ("This widget is a summary of several different things, so there "
                "is nothing to open. The numbers it shows are below.")
    return ("This widget does not aggregate — each row it shows is already "
            "a single record.")


def _union_data_branch(tree: exp.Union) -> Optional[exp.Select]:
    """The single aggregating branch of a UNION, or None.

    ⭐ WHY. A widget commonly reads `<real query> UNION ALL <empty-state row>` so
    the panel renders a message instead of a blank when there is no data. sqlglot
    parses that as `exp.Union`, not `exp.Select`, and the whole widget was refused
    with "Only a SELECT can be broken down" — the empty-state branch, whose only
    job is cosmetic, blocked the drill-down of the branch that has the rows.

    ⛔ ONLY WHEN EXACTLY ONE BRANCH AGGREGATES. A `UNION ALL` of several real
    aggregating branches (the "summary of several different things" shape) has no
    single population behind a clicked row, and silently drilling the first branch
    would answer a question the user did not ask. Ambiguity returns None so the
    caller refuses, which is the honest outcome.

    A branch of literals (the empty-state row) contributes no aggregate and is
    ignored. Nested UNIONs are flattened, so a three-way UNION with one real
    branch still resolves.
    """
    branches = _union_branches(tree)
    aggregating = [b for b in branches
                   if isinstance(b, exp.Select) and _aggregates(b)]
    return aggregating[0] if len(aggregating) == 1 else None


def decompose_widget_sql(
    sql: str,
    primary_keys: Optional[Mapping[str, Union[str, Sequence[str]]]] = None,
    dialect: str = _DIALECT,
    pin_keys: bool = True,
) -> Decomposition:
    """Analyse a widget's SQL and build the detail query behind one clicked row.

    Args:
        sql: the widget's own ``sql_command``.
        primary_keys: ``{table_name: pk_column}``, or a tuple of columns for a
            composite key. Supplied by the caller — this module issues no
            queries, so it cannot look one up. A table absent from the map simply
            yields no row-identity column plus a warning.
        dialect: sqlglot dialect; the placeholder style follows from it
            (postgres renders ``%(name)s``).

    Returns:
        A `Decomposition`. Check `.decomposable` before using `.sql`.
    """
    primary_keys = primary_keys or {}

    try:
        tree = sqlglot.parse_one(sql, dialect=dialect)
    except Exception as exc:  # noqa: BLE001 — any parse failure is one outcome
        return Decomposition(
            kind=KIND_UNSUPPORTED,
            reason=f"This widget's SQL could not be parsed, so its rows cannot be "
                   f"broken down ({exc.__class__.__name__}).",
        )

    if isinstance(tree, exp.Union):
        tree = _union_data_branch(tree) or tree

    if not isinstance(tree, exp.Select):
        return Decomposition(
            kind=KIND_UNSUPPORTED,
            reason="Only a SELECT can be broken down into the rows behind it.",
        )

    aggs = _aggregates(tree)
    key_names: Mapping[str, str] = {}
    lift_warnings: Tuple[str, ...] = ()
    lift = _Lift()
    if not aggs:
        lift = _cte_lift(tree)
        if lift.select is None:
            if lift.stop:
                # ⚠️ NOT "a summary of several different things": the widget has ONE
                # population, but one of its rows cannot be traced to exactly the
                # records behind it. Say where, so the reader is not sent to search
                # the SQL.
                return Decomposition(
                    kind=KIND_NOT_AGGREGATE,
                    reason=(f"This widget's rows cannot be opened one at a time: "
                            f"following its CTEs stopped at {lift.stop}. The "
                            f"numbers it shows are below."))
            return Decomposition(kind=KIND_NOT_AGGREGATE,
                                 reason=_not_aggregate_reason(tree, dialect))
        tree = lift.select
        key_names = lift.names or {}
        lift_warnings = lift.warnings
        aggs = _aggregates(tree)

    group = tree.args.get("group")
    keys: List[exp.Expression] = list(group.expressions) if group else []
    keys = _resolve_ordinal_keys(keys, tree)

    names, clash = _bind_names(keys, tree, key_names)
    if clash:
        return Decomposition(kind=KIND_UNSUPPORTED, reason=clash)

    metrics: List[Metric] = []
    arg_columns: List[exp.Column] = []
    seen_args: set = set()
    for alias, agg in aggs:
        cols: List[str] = []
        for col in agg.find_all(exp.Column):
            # A column inside a subquery belongs to THAT subquery's FROM
            # (`l.scan_type IN (SELECT rq.scan_type FROM required rq)`); projected
            # here it names a relation not in scope ("missing FROM-clause entry").
            if col.find_ancestor(exp.Subquery) is not None:
                continue
            csql = col.sql(dialect=dialect)
            cols.append(csql)
            if csql not in seen_args:
                seen_args.add(csql)
                arg_columns.append(col.copy())
        metrics.append(Metric(
            alias=alias,
            expression=agg.sql(dialect=dialect),
            arg_columns=tuple(cols),
        ))

    warnings: List[str] = list(lift_warnings)

    # C — row identity. Without it, constituent rows of a COUNT(*) are
    # indistinguishable from one another (see the module docstring).
    source = _driving_source(tree)
    joins_anywhere = bool(tree.args.get("joins")) or any(
        body.args.get("joins") for _, body in source.chain)
    # ⛔ THE WHOLE KEY, never its first column. `explore_packages` is unique on
    # (image_key, package_key); identity on `image_key` alone repeats for every
    # package on an image, and keyset paging on it SKIPPED rows. MEASURED
    # 2026-10-01, T1, "Is every kind of software you run being examined",
    # apk/alpine: 3,266 records, 2,926 reached by paging, 340 silently lost while
    # the reconciliation still matched. Every key column is traced through the
    # chain; if any one does not survive, there is no identity at all.
    pk_cols: List[exp.Column] = []
    stop = source.stop
    if source.table and source.table in primary_keys:
        for col in _key_columns(primary_keys[source.table]):
            top, stop = _key_through_chain(source, col)
            if top is None:
                pk_cols = []
                break
            pk_cols.append(exp.column(top, table=source.alias))
    if not pk_cols:
        missing = ("No primary key is available for this widget's source, so rows "
                   "that differ only in columns outside the projection will look "
                   "identical.")
        # ⭐ SAY WHERE. Without it the reader has a CTE chain to search by hand.
        if stop:
            missing += f" Following its CTEs stopped at {stop}."
        elif source.table and source.chain:
            missing += (f" Its CTEs lead to `{source.table}`, which declares no "
                        f"primary key.")
        warnings.append(missing)

    taken: set = set()
    projection: List[Projection] = []
    selected: List[exp.Expression] = []

    def _add(node: exp.Expression, role: str,
             prefer: Optional[str] = None) -> None:
        node_sql = node.sql(dialect=dialect)
        if any(p.expression == node_sql for p in projection):
            return
        # ⛔ NEVER NAME A COLUMN AFTER ITS SQL. `_unique_alias` replaces every
        # non-word character with `_`, so an EXPRESSION key became a column header
        # reading `COALESCE_NULLIF_asset_environment_________unlabelled___`
        # (MEASURED on Classie, "Publicly-accessible assets"). The widget already
        # gave that expression a name — `environment` — and `prefer` is how the
        # caller passes it in. Falls back to the old behaviour only when there is
        # no name to prefer, which is better than inventing one.
        base = prefer or (node.name if isinstance(node, exp.Column) else node_sql)
        alias = _unique_alias(base, taken)
        projection.append(Projection(expression=node_sql, alias=alias, role=role))
        selected.append(exp.alias_(node.copy(), alias))

    for col in pk_cols:
        _add(col, "row_identity")
    for i, key in enumerate(keys):
        # The clicked row is keyed by the DISPLAYED name, and so is the bound
        # parameter — so the projected column must use it too, or the detail
        # table shows a header nobody can match to the chart.
        _add(key, "key", prefer=names[i])
    for col in arg_columns:
        _add(col, "metric_arg")

    detail = tree.copy()
    # ⚠️ HAVING goes too: the clicked group already satisfied it, so re-applying it
    # to individual rows filters on a group predicate that no single row can meet.
    # ORDER BY / LIMIT chose WHICH aggregate rows to display — irrelevant once one
    # is pinned, and a LIMIT left in place would silently truncate the detail set.
    for arg in ("group", "order", "limit", "having", "distinct", "offset"):
        detail.set(arg, None)
    detail.set("expressions", selected)

    # ⭐ `pin_keys=False` answers a DIFFERENT question: not "the rows behind this
    # cell" but "the rows behind this WIDGET" — the whole population, no group key
    # pinned. The header Explore button asks that; a chart-slice click does not.
    # The projection and metrics are unchanged, so the caller still learns what the
    # widget aggregates and over which columns.
    # ⚠️ Two limits of `key = %(k)s`, both older than the CTE lift: a NULL key
    # never matches (the clicked NULL group drills to nothing), and a metric that
    # mixes in a key column recomputes over the pinned rows only.
    params: List[str] = []
    placeholders: List[str] = []
    if pin_keys:
        for i, key in enumerate(keys):
            name = names[i]
            params.append(name)
            placeholders.append(_placeholder(name, i, placeholders))
            detail = detail.where(
                exp.EQ(this=_paren(key.copy()),
                       expression=exp.Placeholder(this=placeholders[-1])),
                copy=False,
            )

    empty: Dict[str, Optional[str]] = {}
    if pin_keys and lift.empty_state is not None:
        by_name = dict(zip(params, placeholders))
        probe = lift.empty_state.transform(
            lambda n: exp.Placeholder(this=by_name.get(n.name, n.name))
            if isinstance(n, exp.Placeholder) else n)
        empty = {
            "empty_state_sql": probe.sql(dialect=dialect),
            "empty_state_reason": (
                f"This row is a placeholder `{lift.empty_state_cte}` adds when there "
                f"is nothing to count, so there are no records behind it. The "
                f"numbers it shows are below."),
        }

    return Decomposition(
        kind=KIND_GROUPED if keys else KIND_UNGROUPED,
        sql=detail.sql(dialect=dialect),
        params=tuple(params),
        placeholders=tuple(placeholders),
        # ⛔ THE BINDABLE NAME, never the raw SQL. `group_keys` used to emit the
        # expression verbatim, so a widget grouping on
        # `COALESCE(NULLIF(package_manager, ''), '(unknown)')` handed that whole
        # string to callers as the key. The FE then built
        # `?COALESCE(NULLIF(package_manager,%20''),%20'(unknown)')=npm`, the
        # server looked for a param named `package_manager`, and every drill on
        # such a widget failed with "the clicked row is missing the value(s) this
        # widget groups by" (MEASURED on Classie, where the bundles wrap most
        # group keys this way — it affected nearly every widget).
        # `params` already carried the right name (the SELECT alias); this makes
        # the two agree so a caller cannot pick the wrong one.
        group_keys=tuple(params) if pin_keys else tuple(
            names),
        metrics=tuple(metrics),
        projection=tuple(projection),
        warnings=tuple(warnings),
        row_identity=tuple(p.alias for p in projection if p.role == "row_identity"),
        row_identity_unique=bool(pk_cols) and not joins_anywhere,
        **_split_with(detail, dialect),
        **empty,
    )


def _paren(node: exp.Expression) -> exp.Expression:
    """Parenthesise a compound expression before it becomes an operand:
    `f.age > 30 = %(k)s` parses as `f.age > (30 = …)`."""
    if isinstance(node, (exp.Binary, exp.Connector, exp.Not)) and not isinstance(
            node, exp.Paren):
        return exp.Paren(this=node)
    return node


def _placeholder(name: str, index: int, taken: List[str]) -> str:
    """The placeholder a key binds under (see `Decomposition.placeholders`)."""
    if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name) and name not in taken:
        return name
    candidate = f"k{index}"
    while candidate in taken:
        candidate = f"_{candidate}"
    return candidate


def _split_with(detail: exp.Select, dialect: str) -> Dict[str, Optional[str]]:
    """`cte_sql` / `body_sql` for a detail query (see `Decomposition.cte_sql`)."""
    with_ = detail.args.get("with_")
    if with_ is None:
        return {}
    body = detail.copy()
    body.set("with_", None)
    return {"cte_sql": with_.sql(dialect=dialect), "body_sql": body.sql(dialect=dialect)}


def reconciliation_sql(
    decomposition: Decomposition,
    dialect: str = _DIALECT,
) -> Optional[str]:
    """SQL that recomputes every metric over the detail set.

    Wraps the detail query and re-applies each aggregate to its own projected
    columns, so the caller can assert the recomputed value equals the number the
    widget displayed. Returns ``_detail_rows`` alongside the metrics, because the
    two are different numbers and the UI must show both.

    ⛔ The comparison is the point: it verifies the REWRITE. If a recomputed
    metric disagrees with the displayed cell, the decomposition is wrong and the
    UI must say so rather than present the rows as an explanation.
    """
    if not decomposition.decomposable or not decomposition.sql:
        return None

    by_expression = {p.expression: p.alias for p in decomposition.projection}
    outer: List[str] = ["COUNT(*) AS _detail_rows"]

    for metric in decomposition.metrics:
        try:
            node = sqlglot.parse_one(metric.expression, dialect=dialect)
        except Exception:  # noqa: BLE001
            continue
        # Rewrite each column reference onto the detail query's output alias: the
        # subquery erases table qualifiers, so `v.torana_artifact_id` is only
        # addressable as the name it was projected under.
        def _rewrite(node: exp.Expression) -> exp.Expression:
            if isinstance(node, exp.Column):
                alias = by_expression.get(node.sql(dialect=dialect))
                if alias:
                    return exp.column(alias)
            return node

        rewritten = node.transform(_rewrite)
        outer.append(
            f"{rewritten.sql(dialect=dialect)} AS "
            f"{_quote_ident(metric.alias, dialect)}"
        )

    if decomposition.cte_sql and decomposition.body_sql:
        return (
            decomposition.cte_sql + "\nSELECT " + ", ".join(outer) + "\nFROM (\n"
            + decomposition.body_sql + "\n) AS _detail"
        )
    return (
        "SELECT " + ", ".join(outer) + "\nFROM (\n"
        + decomposition.sql + "\n) AS _detail"
    )


def sink_table_primary_keys() -> Dict[str, str]:
    """``{table_name: primary_key_column}`` for every sink table.

    ⭐ The `primary_keys` argument of `decompose_widget_sql` exists so this module
    issues no I/O — but every caller then needs the same map, and three callers
    hand-rolling it is three chances to disagree about what identifies a row. The
    schemas already declare it, so read it from there once.

    Best-effort per table: a schema whose `primary_key` cannot be read is omitted
    rather than raising, because a decomposition WITHOUT a row identity is still
    useful (it warns) while a failed import would take out the whole endpoint.
    """
    from . import schemas as _schemas

    out: Dict[str, str] = {}
    for name in getattr(_schemas, "__all__", []):
        cls = getattr(_schemas, name, None)
        if not isinstance(cls, type) or name == "TableSchema":
            continue
        try:
            inst = cls()
            table = getattr(inst, "table_name", None)
            pk = getattr(inst, "primary_key", None)
            if table and pk:
                out[str(table)] = str(pk)
        except Exception:      # noqa: BLE001 — one bad schema must not break the map
            continue
    return out


def primary_keys_with_transformers(
    transformers: Optional[Iterable[Mapping]] = None,
) -> Dict[str, Union[str, Tuple[str, ...]]]:
    """`sink_table_primary_keys()` plus a row identity for TRANSFORMER outputs.

    ⭐ WHY THIS EXISTS. The base map is built from ``schemas.__all__`` — 18 sink
    tables. A transformer output has no schema class, so it is structurally absent,
    and a decomposition over one therefore projects NO row identity. Measured on
    EM-BundleFix-3 (2026-09-08): every one of 22 widgets reads a transformer, so
    *every* ``COUNT(*)`` decomposition produced ``SELECT FROM <table> WHERE …`` — a
    correct total with zero columns behind it, which renders as a working panel
    showing nothing.

    ⛔ NEVER MUTATE THE BASE MAP. `sink_table_primary_keys()` derives from
    module-level schema classes shared by every request in this worker; mutating
    its result would leak one tenant's transformer keys into every later request in
    that process. This copies, and a real sink schema always wins over a
    transformer of the same name (`setdefault`).

    ⛔ ``unique_key`` is a JSON LIST (``transformer.py:52``) and may be
    multi-column, and the WHOLE list is the key. Taking only its first element
    made `explore_packages` (image_key, package_key) look keyed by `image_key`,
    and keyset paging on that skipped rows (MEASURED 2026-10-01, T1: 340 of 3,266
    records on one cell). A one-column key stays a plain string; a longer one is
    a tuple. ⚠️ The database declares these columns neither NOT NULL nor unique
    (only the dbt merge index exists), so a caller that pages by them must treat
    a NULL component safely.

    Args:
        transformers: transformer records as returned by
            ``GET /api/v1/transformers`` — each needs ``destination_table`` and
            ``unique_key``. Anything missing either is skipped silently.
    """
    out = dict(sink_table_primary_keys())
    for t in transformers or ():
        try:
            table = t.get("destination_table")
            uk = t.get("unique_key")
        except AttributeError:      # not a mapping — skip rather than raise
            continue
        if not table or not uk:
            continue
        cols = tuple(str(c) for c in (uk if isinstance(uk, (list, tuple)) else [uk]) if c)
        if cols:
            out.setdefault(str(table), cols[0] if len(cols) == 1 else cols)
    return out


def _key_columns(key: Union[str, Sequence[str]]) -> Tuple[str, ...]:
    """A primary-key map value as its ordered columns: a plain string is one
    column, a sequence is a composite key."""
    if isinstance(key, str):
        return (key,)
    return tuple(str(c) for c in key)


def _quote_ident(name: str, dialect: str) -> str:
    """Quote an output alias so a metric named e.g. `count` cannot collide with a
    keyword. Goes through sqlglot so the quoting matches the target dialect."""
    return exp.to_identifier(name, quoted=True).sql(dialect=dialect)
