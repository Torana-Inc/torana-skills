from typing import Dict, Any, List
from abc import ABC, abstractmethod
from .system_fields import (
    IAM_FIELDS, LIFECYCLE_FIELDS, AUDIT_FIELDS, TRACE_FIELDS,
    PROVENANCE_FIELDS, SYSTEM_FIELDS,
)


class TableSchema(ABC):
    """Base class for table schemas."""

    @property
    @abstractmethod
    def table_name(self) -> str:
        """Return the table name."""
        pass

    @property
    @abstractmethod
    def schema(self) -> Dict[str, Any]:
        """
        Return the business schema (customer-defined fields only).

        This should contain ONLY business fields from the playground CSV.
        System fields (IAM, Lifecycle, Audit) are injected via get_full_schema().

        This property is the source of truth for:
        - CSV generation (Option 1: Pydantic → CSV)
        - Schema documentation
        - Customer-facing schema display

        IMPORTANT: Do NOT add system fields here.
        """
        pass

    @property
    @abstractmethod
    def primary_key(self) -> str:
        """Return the primary key column name."""
        pass

    @property
    @abstractmethod
    def description(self) -> str:
        """Return a human-readable description of the table."""
        pass

    @property
    def category(self) -> str:
        """Return the category of this table (default: Security Data)."""
        return "Security Data"

    @property
    def scope(self) -> str:
        """Where this table physically lives: ``"tenant"`` (default) or ``"global"``.

        A ``global`` table is tenant-independent reference data written once into the
        shared ``public`` schema (``scope="global"`` on the write path) and readable by
        every tenant, because ``public`` is always on the search_path.

        WHY THIS EXISTS. Being global is what keeps a table OUT of ``DatalakeTables``
        (the tenant-sink enum), and ``core/source_sync.py`` derives the dbt ``torana``
        source declarations from that enum. So a global table was groundable and
        directly queryable, but *unreferenceable* via ``{{ source('torana', X) }}`` —
        the exact two-surfaces-disagreeing failure ``source_sync`` was written to end,
        reappearing for the global tier.

        Measured: ``vm.tf.p0_actions`` — a reviewed VM catalog entry — could not compile
        for ANY tenant because it does ``{{ source('torana','vm_cve_metadata') }}``, and
        that name is absent from every tenant's generated ``sources.yml`` (T2 declared 23
        tables; not one of them). The entry failed with ``compilation_error`` and rolled
        back the whole deploy.

        Declaring scope HERE, on the schema itself, is what lets ``source_sync`` emit a
        second, ``public``-pinned source group (``torana_global``) derived from the same
        single source of truth. A new global table then propagates automatically, exactly
        as a new sink table does — no hand-maintained list to drift.
        """
        return "tenant"

    @property
    def timestamp_column(self) -> str:
        """
        Return the column name to use for timestamp queries (e.g., latest_update).

        This provides deterministic timestamp column selection instead of guessing.
        Each schema should override this to specify its timestamp column.

        Returns:
            Column name to use for timestamp queries (e.g., 'record_updated', 'last_updated_at')
        """
        raise NotImplementedError(f"{self.__class__.__name__} must define timestamp_column property")

    def get_full_schema(self) -> Dict[str, Any]:
        """
        Return the complete schema with all system fields injected.

        Use this for:
        - Table creation (CREATE TABLE statements)
        - Schema validation
        - Database introspection

        Returns:
            Complete schema dict: business + IAM + lifecycle + audit + trace fields
        """
        schema = self.schema.copy()
        schema = {**IAM_FIELDS, **LIFECYCLE_FIELDS, **AUDIT_FIELDS, **TRACE_FIELDS,
                  **PROVENANCE_FIELDS, **schema}
        return schema

    def get_schema_for_queries(self) -> Dict[str, Any]:
        """
        Return schema for query building (excludes audit fields).

        Use this for:
        - Query builders
        - WHERE clause generation
        - Filter construction

        Why exclude audit? They're not used in WHERE clauses.
        Audit fields (created_at, created_by, updated_at, updated_by) are
        metadata only and don't affect query filtering.

        Returns:
            Schema dict: business + IAM + lifecycle fields (no audit)
        """
        schema = self.schema.copy()
        schema = {**IAM_FIELDS, **LIFECYCLE_FIELDS, **schema}
        return schema

    def get_schema_with_iam(self, include_optional: bool = True) -> Dict[str, Any]:
        """
        Legacy method for backward compatibility.

        DEPRECATED: Use get_full_schema() instead.
        This method exists for backward compatibility and will be removed in a future release.

        Args:
            include_optional: Ignored (kept for backward compatibility)

        Returns:
            Complete schema with all system fields
        """
        import warnings
        warnings.warn(
            "get_schema_with_iam() is deprecated. Use get_full_schema() instead.",
            DeprecationWarning,
            stacklevel=2
        )
        return self.get_full_schema()

    def get_create_table_sql(self, backend_type: str = "snowflake") -> str:
        """Generate CREATE TABLE SQL for the specified backend."""
        if backend_type.lower() == "snowflake":
            return self._get_snowflake_create_sql()
        else:
            raise ValueError(f"Unsupported backend type: {backend_type}")
    
    @staticmethod
    def _render_default(value) -> str:
        """Render a schema `default` value as a SQL literal."""
        if isinstance(value, bool):
            return "TRUE" if value else "FALSE"
        if value is None:
            return "NULL"
        if isinstance(value, (int, float)):
            return str(value)
        return "'" + str(value).replace("'", "''") + "'"

    def _get_snowflake_create_sql(self) -> str:
        """Generate Snowflake-specific CREATE TABLE SQL."""
        columns = []
        for field_name, field_info in self.get_full_schema().items():
            column_def = f"{field_name} {field_info['data_type']}"

            if field_info.get('primary_key', False):
                column_def += " PRIMARY KEY"
            else:
                # DEFAULT must precede NOT NULL in the column definition.
                # Previously the 'default' key was declared in several schemas
                # (e.g. system_fields.IAM/LIFECYCLE) but never emitted, so every
                # "defaulted" boolean landed NULLable with no default. That is
                # what let un-populated triage flags (is_false_positive etc.)
                # arrive as NULL and silently fail `= false` predicates.
                if 'default' in field_info:
                    column_def += f" DEFAULT {self._render_default(field_info['default'])}"
                if field_info.get('not_null', False):
                    column_def += " NOT NULL"

            columns.append(column_def)

        return f"CREATE TABLE IF NOT EXISTS {self.table_name} (\n  {',\n  '.join(columns)}\n)"