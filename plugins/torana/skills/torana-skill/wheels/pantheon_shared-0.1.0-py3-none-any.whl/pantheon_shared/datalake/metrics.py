"""
DataLake Client Metrics Module.

This module provides in-memory metrics tracking for DataLakeClient operations.
It tracks query performance, write operations, errors, and per-table/tenant/service
statistics to help with debugging and performance optimization.

Environment Variables:
    DATALAKE_METRICS_ENABLED: Enable/disable metrics collection (default: true)
    DATALAKE_METRICS_SLOW_QUERY_THRESHOLD: Threshold for slow queries in seconds (default: 2)
    DATALAKE_METRICS_VERY_SLOW_QUERY_THRESHOLD: Threshold for very slow queries in seconds (default: 5)
    DATALAKE_METRICS_MAX_TABLE_TRACKING: Maximum number of tables to track (default: 20)
    DATALAKE_METRICS_MAX_TENANT_TRACKING: Maximum number of tenants to track (default: 50)
    DATALAKE_METRICS_MAX_SERVICE_TRACKING: Maximum number of calling services to track (default: 20)
    DATALAKE_METRICS_QUERY_SAMPLING_RATE: Query sampling rate 0.0-1.0 (default: 1.0)
"""

import os
import re
import random
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List
from threading import Lock


# =============================================================================
# Configuration from Environment Variables
# =============================================================================

DATALAKE_METRICS_ENABLED = os.getenv('DATALAKE_METRICS_ENABLED', 'true').lower() == 'true'
DATALAKE_METRICS_SLOW_QUERY_THRESHOLD = float(os.getenv('DATALAKE_METRICS_SLOW_QUERY_THRESHOLD', '2'))
DATALAKE_METRICS_VERY_SLOW_QUERY_THRESHOLD = float(os.getenv('DATALAKE_METRICS_VERY_SLOW_QUERY_THRESHOLD', '5'))
DATALAKE_METRICS_MAX_TABLE_TRACKING = int(os.getenv('DATALAKE_METRICS_MAX_TABLE_TRACKING', '20'))
DATALAKE_METRICS_MAX_TENANT_TRACKING = int(os.getenv('DATALAKE_METRICS_MAX_TENANT_TRACKING', '50'))
DATALAKE_METRICS_MAX_SERVICE_TRACKING = int(os.getenv('DATALAKE_METRICS_MAX_SERVICE_TRACKING', '20'))
DATALAKE_METRICS_QUERY_SAMPLING_RATE = float(os.getenv('DATALAKE_METRICS_QUERY_SAMPLING_RATE', '1.0'))


# =============================================================================
# Metrics Data Classes
# =============================================================================

@dataclass
class DataLakeClientMetrics:
    """
    In-memory metrics tracking for DataLakeClient operations.

    This class tracks various metrics related to datalake operations including:
    - Query performance (execution time, slow queries)
    - Write operations (inserts, upserts, row counts)
    - DDL operations (table create/drop, exists checks)
    - Connection health (errors, health check failures)
    - Per-table, per-tenant, and per-service statistics

    Thread-safe: All methods use locks to ensure thread safety.
    """

    # Query Operation Metrics
    total_queries: int = 0
    successful_queries: int = 0
    failed_queries: int = 0
    total_query_time: float = 0.0  # Total time across all queries (seconds)

    # Query Performance Percentiles
    slow_query_count: int = 0  # Queries > DATALAKE_METRICS_SLOW_QUERY_THRESHOLD
    very_slow_query_count: int = 0  # Queries > DATALAKE_METRICS_VERY_SLOW_QUERY_THRESHOLD

    # Write Operation Metrics
    total_inserts: int = 0
    total_upserts: int = 0
    successful_writes: int = 0
    failed_writes: int = 0
    total_write_time: float = 0.0
    rows_inserted: int = 0
    rows_upserted: int = 0

    # DDL Operation Metrics
    total_tables_created: int = 0
    total_tables_dropped: int = 0
    table_exists_checks: int = 0
    list_tables_calls: int = 0

    # Connection Metrics
    connection_errors: int = 0
    health_check_calls: int = 0
    failed_health_checks: int = 0

    # Text-to-SQL Metrics
    text_to_sql_calls: int = 0
    text_to_sql_failures: int = 0
    text_to_sql_executions: int = 0
    total_text_to_sql_time: float = 0.0

    # Per-Table Query Count (Top N tables to identify hotspots)
    table_query_counts: Dict[str, int] = field(default_factory=dict)
    # Per-Tenant Query Count (identify noisy tenants)
    tenant_query_counts: Dict[str, int] = field(default_factory=dict)
    # Per-Calling Service Query Count (identify which services are heavy users)
    service_query_counts: Dict[str, int] = field(default_factory=dict)

    # Thread safety lock
    _lock: Lock = field(default_factory=Lock)

    # =============================================================================
    # Recording Methods
    # =============================================================================

    def _should_sample(self) -> bool:
        """Determine if this operation should be sampled based on sampling rate."""
        if DATALAKE_METRICS_QUERY_SAMPLING_RATE >= 1.0:
            return True
        return random.random() < DATALAKE_METRICS_QUERY_SAMPLING_RATE

    def record_query(
        self,
        execution_time: float,
        success: bool,
        tenant_id: str,
        sql: str,
        calling_service: Optional[str] = None
    ) -> None:
        """
        Record a query execution.

        Args:
            execution_time: Query execution time in seconds.
            success: Whether the query succeeded.
            tenant_id: Tenant ID for the query.
            sql: SQL query string (for table name extraction).
            calling_service: Optional name of the service making the call.
        """
        if not self._should_sample():
            return

        with self._lock:
            self.total_queries += 1
            self.total_query_time += execution_time

            if success:
                self.successful_queries += 1

                # Track slow queries
                if execution_time > DATALAKE_METRICS_VERY_SLOW_QUERY_THRESHOLD:
                    self.very_slow_query_count += 1
                elif execution_time > DATALAKE_METRICS_SLOW_QUERY_THRESHOLD:
                    self.slow_query_count += 1
            else:
                self.failed_queries += 1

            # Extract and track table name
            table_name = self._extract_table_name(sql)
            if table_name:
                self._track_item(self.table_query_counts, table_name, DATALAKE_METRICS_MAX_TABLE_TRACKING)

            # Track tenant
            self._track_item(self.tenant_query_counts, tenant_id, DATALAKE_METRICS_MAX_TENANT_TRACKING)

            # Track calling service
            if calling_service:
                self._track_item(self.service_query_counts, calling_service, DATALAKE_METRICS_MAX_SERVICE_TRACKING)

    def record_insert(
        self,
        execution_time: float,
        success: bool,
        row_count: int
    ) -> None:
        """
        Record an insert operation.

        Args:
            execution_time: Insert execution time in seconds.
            success: Whether the insert succeeded.
            row_count: Number of rows inserted.
        """
        with self._lock:
            self.total_inserts += 1
            self.total_write_time += execution_time

            if success:
                self.successful_writes += 1
                self.rows_inserted += row_count
            else:
                self.failed_writes += 1

    def record_upsert(
        self,
        execution_time: float,
        success: bool,
        row_count: int
    ) -> None:
        """
        Record an upsert operation.

        Args:
            execution_time: Upsert execution time in seconds.
            success: Whether the upsert succeeded.
            row_count: Number of rows upserted.
        """
        with self._lock:
            self.total_upserts += 1
            self.total_write_time += execution_time

            if success:
                self.successful_writes += 1
                self.rows_upserted += row_count
            else:
                self.failed_writes += 1

    def record_table_created(self) -> None:
        """Record a table creation operation."""
        with self._lock:
            self.total_tables_created += 1

    def record_table_dropped(self) -> None:
        """Record a table drop operation."""
        with self._lock:
            self.total_tables_dropped += 1

    def record_table_exists_check(self) -> None:
        """Record a table existence check."""
        with self._lock:
            self.table_exists_checks += 1

    def record_list_tables(self) -> None:
        """Record a list tables operation."""
        with self._lock:
            self.list_tables_calls += 1

    def record_connection_error(self) -> None:
        """Record a connection error."""
        with self._lock:
            self.connection_errors += 1

    def record_health_check(self, success: bool) -> None:
        """
        Record a health check operation.

        Args:
            success: Whether the health check succeeded.
        """
        with self._lock:
            self.health_check_calls += 1
            if not success:
                self.failed_health_checks += 1

    def record_text_to_sql(
        self,
        execution_time: float,
        success: bool,
        executed: bool
    ) -> None:
        """
        Record a text-to-SQL operation.

        Args:
            execution_time: Text-to-SQL execution time in seconds.
            success: Whether the SQL generation succeeded.
            executed: Whether the generated SQL was executed.
        """
        with self._lock:
            self.text_to_sql_calls += 1
            self.total_text_to_sql_time += execution_time

            if not success:
                self.text_to_sql_failures += 1
            if executed:
                self.text_to_sql_executions += 1

    # =============================================================================
    # Helper Methods
    # =============================================================================

    def _extract_table_name(self, sql: str) -> Optional[str]:
        """
        Extract the primary table name from a SQL query.

        Uses simple regex patterns to extract table names from common SQL queries:
        - SELECT/FROM: Extracts table after FROM or JOIN
        - INSERT/INTO: Extracts table after INTO
        - UPDATE: Extracts table after UPDATE

        Args:
            sql: SQL query string.

        Returns:
            Table name if found, None otherwise.
        """
        if not sql:
            return None

        sql_upper = sql.upper().strip()

        # Handle SELECT queries
        if sql_upper.startswith('SELECT'):
            # Find FROM clause
            from_match = re.search(r'\bFROM\s+(\w+)', sql_upper)
            if from_match:
                return from_match.group(1).lower()

        # Handle INSERT queries
        elif sql_upper.startswith('INSERT'):
            into_match = re.search(r'\bINTO\s+(\w+)', sql_upper)
            if into_match:
                return into_match.group(1).lower()

        # Handle UPDATE queries
        elif sql_upper.startswith('UPDATE'):
            update_match = re.search(r'\bUPDATE\s+(\w+)', sql_upper)
            if update_match:
                return update_match.group(1).lower()

        return None

    def _track_item(self, tracking_dict: Dict[str, int], key: str, max_items: int) -> None:
        """
        Track an item in a dictionary with a maximum size limit.

        If the dictionary is full and the key is not already present,
        the item with the lowest count is removed to make room.

        Args:
            tracking_dict: Dictionary tracking item counts.
            key: Key to track.
            max_items: Maximum number of items to track.
        """
        if key in tracking_dict:
            tracking_dict[key] += 1
        elif len(tracking_dict) < max_items:
            tracking_dict[key] = 1
        else:
            # Find and replace the item with the lowest count
            min_key = min(tracking_dict, key=tracking_dict.get)
            if tracking_dict[min_key] == 1:
                # Replace items with count of 1
                del tracking_dict[min_key]
                tracking_dict[key] = 1

    def _get_top_items(self, tracking_dict: Dict[str, int], limit: int = 10) -> List[Dict[str, Any]]:
        """
        Get the top N items from a tracking dictionary sorted by count.

        Args:
            tracking_dict: Dictionary tracking item counts.
            limit: Maximum number of items to return.

        Returns:
            List of dictionaries with 'key' and 'count' keys.
        """
        sorted_items = sorted(tracking_dict.items(), key=lambda x: x[1], reverse=True)
        return [{'key': k, 'count': v} for k, v in sorted_items[:limit]]

    # =============================================================================
    # Serialization
    # =============================================================================

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert metrics to a dictionary for JSON serialization.

        Returns:
            Dictionary containing all metrics with computed averages and percentages.
        """
        avg_query_time = self.total_query_time / self.total_queries if self.total_queries > 0 else 0
        avg_write_time = self.total_write_time / (self.total_inserts + self.total_upserts) if (self.total_inserts + self.total_upserts) > 0 else 0
        avg_text_to_sql_time = self.total_text_to_sql_time / self.text_to_sql_calls if self.text_to_sql_calls > 0 else 0
        query_success_rate = (self.successful_queries / self.total_queries * 100) if self.total_queries > 0 else 0
        write_success_rate = (self.successful_writes / (self.total_inserts + self.total_upserts) * 100) if (self.total_inserts + self.total_upserts) > 0 else 0

        return {
            'query_metrics': {
                'total_queries': self.total_queries,
                'successful_queries': self.successful_queries,
                'failed_queries': self.failed_queries,
                'success_rate_percent': round(query_success_rate, 2),
                'total_query_time_s': round(self.total_query_time, 3),
                'avg_query_time_ms': round(avg_query_time * 1000, 2),
                'slow_query_count': self.slow_query_count,
                'very_slow_query_count': self.very_slow_query_count,
            },
            'write_metrics': {
                'total_inserts': self.total_inserts,
                'total_upserts': self.total_upserts,
                'successful_writes': self.successful_writes,
                'failed_writes': self.failed_writes,
                'success_rate_percent': round(write_success_rate, 2),
                'total_write_time_s': round(self.total_write_time, 3),
                'avg_write_time_ms': round(avg_write_time * 1000, 2),
                'rows_inserted': self.rows_inserted,
                'rows_upserted': self.rows_upserted,
            },
            'ddl_metrics': {
                'total_tables_created': self.total_tables_created,
                'total_tables_dropped': self.total_tables_dropped,
                'table_exists_checks': self.table_exists_checks,
                'list_tables_calls': self.list_tables_calls,
            },
            'connection_metrics': {
                'connection_errors': self.connection_errors,
                'health_check_calls': self.health_check_calls,
                'failed_health_checks': self.failed_health_checks,
            },
            'text_to_sql_metrics': {
                'total_calls': self.text_to_sql_calls,
                'failures': self.text_to_sql_failures,
                'executions': self.text_to_sql_executions,
                'total_time_s': round(self.total_text_to_sql_time, 3),
                'avg_time_ms': round(avg_text_to_sql_time * 1000, 2),
            },
            'top_tables': self._get_top_items(self.table_query_counts),
            'top_tenants': self._get_top_items(self.tenant_query_counts),
            'top_services': self._get_top_items(self.service_query_counts),
        }


# =============================================================================
# Metrics Registry
# =============================================================================

class DataLakeMetricsRegistry:
    """
    Global registry for DataLakeClient metrics.

    This class manages metrics for different backend types (duckdb, postgres, snowflake)
    and provides thread-safe access to the metrics instances.

    The registry is a singleton that can be accessed from anywhere in the application.
    """

    _instance: Optional['DataLakeMetricsRegistry'] = None
    _lock: Lock = Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._metrics: Dict[str, DataLakeClientMetrics] = {}
        return cls._instance

    def get_metrics(self, backend_type: str) -> DataLakeClientMetrics:
        """
        Get metrics for a specific backend type.

        Args:
            backend_type: Backend type ('duckdb', 'postgres', 'snowflake').

        Returns:
            DataLakeClientMetrics instance for the backend.
        """
        with self._lock:
            if backend_type not in self._metrics:
                self._metrics[backend_type] = DataLakeClientMetrics()
            return self._metrics[backend_type]

    def get_all_metrics(self) -> Dict[str, DataLakeClientMetrics]:
        """
        Get metrics for all backend types.

        Returns:
            Dictionary mapping backend types to their metrics.
        """
        with self._lock:
            return self._metrics.copy()

    def reset_metrics(self, backend_type: str) -> bool:
        """
        Reset metrics for a specific backend type.

        Args:
            backend_type: Backend type to reset.

        Returns:
            True if metrics were reset, False if backend not found.
        """
        with self._lock:
            if backend_type in self._metrics:
                self._metrics[backend_type] = DataLakeClientMetrics()
                return True
            return False

    def reset_all_metrics(self) -> None:
        """Reset all metrics for all backend types."""
        with self._lock:
            self._metrics.clear()


# Global metrics registry instance
_metrics_registry = DataLakeMetricsRegistry()


def get_datalake_metrics_registry() -> DataLakeMetricsRegistry:
    """
    Get the global DataLake metrics registry.

    Returns:
        Global DataLakeMetricsRegistry instance.
    """
    return _metrics_registry
