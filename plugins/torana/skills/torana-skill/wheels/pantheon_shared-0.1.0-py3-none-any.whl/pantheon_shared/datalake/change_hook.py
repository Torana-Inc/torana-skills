"""Data changed → queue a rebuild, decided ONCE at the datalake write layer
(DT_MATERIALIZATION_POLICY_SPEC § 3.2.15, Phase 7 "B", 2026-09-29).

⛔ WHY HERE. Until Phase 7 every writer decided for itself whether to mark the tenant's derived
state dirty: the ETL runner marked at run completion, each push route marked its tables, and
decoration apply, the threat-intel feeds, SDG replay, entity-graph prune and compensating controls
marked nothing, so their changes never reached a rebuild. `PostgreSQLBackend`'s committing write
methods are the one point every datalake writer passes, so the backend reports every committed
write here, and ONE policy decides.

    backend commit ──► changed(tenant | None, table)      (never blocks, never raises)
                          │ filter: a transformer INPUT relation, outside derived_scope()
                          ▼
                       coalescer (per process, per (tenant, table), WINDOW_SECONDS)
                          │ leading edge: first write → mark now
                          │ trailing edge: more writes in the window → ONE mark at window end
                          ▼
                       sender thread ──► the process's registered sink(tenant, table, reason)

⛔ NOTHING RUNS ON THE WRITE PATH. `changed()` only records into an in-memory dict under a lock
and sets an Event; the mark is delivered by one daemon sender thread per process, after the write
committed and its connection returned to the pool (root CLAUDE.md Defect B: no session held
across a network call). A raising or slow sink never fails or slows a write.

⛔ THE TRAILING EDGE IS NOT OPTIONAL. Leading-only coalescing loses a rebuild: mark at t=0, a
drain claims at t=2 (max-deferral), a write at t=5 is suppressed, the drain completes with
`last_marked_at (0) <= claimed_at (2)` and clears the flag — the t=5 write is never rebuilt. The
trailing mark lands after `claimed_at`, so integration's lost-update guard keeps the flag.

⚠️ CRASH BOUND. A trailing mark held in memory is lost if the process dies inside the window.
The leading mark of the same burst already set the tenant dirty, so the loss is only a drain that
claimed inside that window; staleness then lasts until the next write or clock trigger. The
durable fix is the change ledger (pantheon-datalake/docs/DATA_CHANGE_LEDGER_SPEC.md).

WHAT COUNTS: tables a transformer can read — `DatalakeTables` (tenant sinks), the global
reference tables (`vm_cve_metadata`, `vm_cve_affects`) and the two derived relations integration
writes. Transformer outputs (dbt writes through its own connection; DT's `drop_table` passes
`db_type="transformers"`), bookkeeping tables and schema DDL are not inputs and are never recorded.
Global tables report `tenant=None`; the sink decides who reads them.

R9: all state is per process. Two workers writing one tenant each deliver at most 2 marks per
window; the drain's claim (an advisory lock + a conditional UPDATE) still admits one drainer.
"""
from __future__ import annotations

import contextvars
import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from typing import Callable, Dict, FrozenSet, Iterator, List, Optional, Tuple

logger = logging.getLogger(__name__)

#: Coalescing window per (tenant, table), per process (§ 3.2.15). `last_marked_at` trails the
#: last write by at most this much, so the drain's 60 s quiet period starts 0–10 s late, never early.
WINDOW_SECONDS = 10.0
#: How often the sender wakes without a new leading mark (trailing edges, pruning).
_TICK_SECONDS = 1.0

#: sink(tenant_id or None, table, reason). Called on the sender thread; may block and may raise.
Sink = Callable[[Optional[str], str, str], None]

_derived: contextvars.ContextVar[bool] = contextvars.ContextVar("datalake_derived_write",
                                                                 default=False)


@contextmanager
def derived_scope() -> Iterator[None]:
    """Writes inside this block are the DERIVED layer rebuilding itself (the drain's purge,
    reconcile, graph-health, property resolution, priority recompute). They are consumed by the
    drain that makes them, so they must not re-dirty the tenant.

    ⚠️ `loop.run_in_executor` does NOT copy context variables by default. A service whose
    derived writes go through an executor calls `install_context_executor(loop)` at startup,
    or the thread sees the default and marks."""
    token = _derived.set(True)
    try:
        yield
    finally:
        _derived.reset(token)


def in_derived_scope() -> bool:
    return _derived.get()


class _ContextThreadPoolExecutor(ThreadPoolExecutor):
    """A ThreadPoolExecutor whose tasks run in a COPY of the submitter's context, the way
    `asyncio.to_thread` does. `loop.run_in_executor(None, ...)` does not copy it."""

    def submit(self, fn, /, *args, **kwargs):
        return super().submit(contextvars.copy_context().run, fn, *args, **kwargs)


def install_context_executor(loop) -> None:
    """Make `loop.run_in_executor(None, ...)` carry context variables into the worker thread.

    ⛔ Why here and not at each call site: `derived_scope()` is a contextvar, and the derived
    layer's writes reach the backend through `run_in_executor` in many places (reconcile's
    collapse, the entity-graph writers, property resolution, priority recompute, the ETL
    adapter). One missed call site re-dirties the tenant after every drain, forever. Installing
    the default executor once per event loop covers them all. Idempotent per loop; call it at
    startup, before the loop's default executor is first used."""
    if getattr(loop, "_default_executor", None).__class__ is _ContextThreadPoolExecutor:
        return
    loop.set_default_executor(_ContextThreadPoolExecutor(thread_name_prefix="asyncio-ctx"))


_relations: Optional[FrozenSet[str]] = None
_globals: Optional[FrozenSet[str]] = None


def transformer_input_relations() -> FrozenSet[str]:
    """Every relation a transformer may read (the same set DT's PLATFORM_RELATIONS pins)."""
    global _relations
    if _relations is None:
        from .schemas import DatalakeTables, global_table_names
        _relations = frozenset({t.value for t in DatalakeTables} | set(global_table_names())
                               | {"entity_properties_resolved", "entity_edge_candidates"})
    return _relations


def global_relations() -> FrozenSet[str]:
    global _globals
    if _globals is None:
        from .schemas import global_table_names
        _globals = frozenset(global_table_names())
    return _globals


def reason_for(table: str) -> str:
    """The drain's selection input for a data change (integration `select_input_changed`)."""
    return f"etl:{table}"


class _Coalescer:
    """Per-process leading + trailing edge coalescing and the sender thread. Thread-safe."""

    def __init__(self, clock: Callable[[], float] = time.monotonic,
                 window: float = WINDOW_SECONDS) -> None:
        self._clock = clock
        self._window = window
        self._lock = threading.Lock()
        self._state: Dict[Tuple[Optional[str], str], Dict[str, float]] = {}
        self._due: List[Tuple[Optional[str], str]] = []
        self._wake = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self.sink: Optional[Sink] = None
        self.stats = {"offered": 0, "sent": 0, "coalesced": 0, "errors": 0, "no_sink": 0}
        self._last_error_log = 0.0

    # ── the write path: record only ──
    def offer(self, tenant_id: Optional[str], table: str) -> None:
        key = (tenant_id, table)
        now = self._clock()
        with self._lock:
            self.stats["offered"] += 1
            st = self._state.get(key)
            if st is None or now - st["sent"] >= self._window:
                self._state[key] = {"sent": now, "pending": 0.0}
                self._due.append(key)                           # leading edge
            else:
                st["pending"] = 1.0                            # trailing edge owed
                self.stats["coalesced"] += 1
        self._wake.set()

    # ── the sender: everything below runs off the write path ──
    def take_due(self) -> List[Tuple[Optional[str], str]]:
        """Keys to mark now: leading edges, plus pending keys whose window has closed."""
        now = self._clock()
        with self._lock:
            out, self._due = self._due, []
            for key, st in list(self._state.items()):
                if st["pending"] and now - st["sent"] >= self._window:
                    st["sent"], st["pending"] = now, 0.0
                    out.append(key)                            # trailing edge
                elif not st["pending"] and now - st["sent"] >= 10 * self._window:
                    del self._state[key]                       # idle: forget it
        return out

    def deliver(self, keys: List[Tuple[Optional[str], str]]) -> None:
        sink = self.sink
        for tenant_id, table in keys:
            if sink is None:
                self.stats["no_sink"] += 1
                continue
            try:
                sink(tenant_id, table, reason_for(table))
                self.stats["sent"] += 1
            except Exception as exc:  # noqa: BLE001 — marking never fails anything
                self.stats["errors"] += 1
                now = self._clock()
                if now - self._last_error_log >= self._window:   # once per window
                    self._last_error_log = now
                    logger.warning("change_hook: mark %s/%s failed (%d errors so far): %s",
                                   str(tenant_id)[:8], table, self.stats["errors"], exc)

    def _run(self) -> None:
        while True:
            self._wake.wait(_TICK_SECONDS)
            self._wake.clear()
            try:
                self.deliver(self.take_due())
            except Exception as exc:  # noqa: BLE001 — the sender must never die
                logger.warning("change_hook: sender pass failed: %s", exc)

    def start(self) -> None:
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                return
            self._thread = threading.Thread(target=self._run, name="datalake-change-hook",
                                            daemon=True)
            self._thread.start()


_coalescer = _Coalescer()
_warned_no_sink = False


def register_sink(sink: Sink) -> None:
    """Each datalake-writing service registers ONE sink at startup:
    integration → in-process `mark_derived_state_dirty` (on its event loop);
    datalake / SDG / admin → integration's internal door `/internal/derived-state/refresh`."""
    _coalescer.sink = sink
    _coalescer.start()


#: Integration's door for a change reported by ANOTHER service (datalake, SDG, admin).
CHANGED_PATH = "/api/v1/internal/derived-state/changed"


def http_sink(service_name: str, tenant_name: str, namespace_name: str,
              timeout: float = 10.0) -> Sink:
    """The sink for a service that is not integration: POST each mark to integration's
    `/internal/derived-state/changed` with the service's own system-tenant service JWT.
    Integration resolves the target tenant's namespace (the caller does not know it) and, for a
    global table (`tenant=None`), the tenants whose transformers read it. Runs on the sender
    thread, so it uses the SYNC client; one client, reused."""
    state: Dict[str, object] = {}

    def sink(tenant_id: Optional[str], table: str, reason: str) -> None:
        client = state.get("client")
        if client is None:
            from ..http import PantheonSyncClient
            from ..pantheon_services import PantheonService
            client = PantheonSyncClient.for_service(
                service_name=service_name, target_service=PantheonService.INTEGRATION,
                tenant_name=tenant_name, namespace_name=namespace_name)
            state["client"] = client
        resp = client.post(CHANGED_PATH, json={"tenant_id": tenant_id, "table": table},
                           timeout=timeout)
        if resp.status_code >= 300:
            raise RuntimeError(f"integration answered {resp.status_code}: {resp.text[:200]}")
    return sink


def changed(tenant_id: Optional[str], table: str, op: str = "write",
            db_type: Optional[str] = None) -> None:
    """Called by the backend AFTER a write committed. Never raises, never blocks."""
    global _warned_no_sink
    try:
        if db_type == "transformers" or _derived.get():
            return
        if table not in transformer_input_relations():
            return
        tenant = None if table in global_relations() else (str(tenant_id) if tenant_id else None)
        if tenant is None and table not in global_relations():
            return
        if _coalescer.sink is None:
            if not _warned_no_sink:
                _warned_no_sink = True
                logger.warning(
                    "change_hook: a datalake write to %s committed in a process with NO sink "
                    "registered — no rebuild will be queued for it. Register one at startup "
                    "(DT_MATERIALIZATION_POLICY_SPEC § 3.2.15).", table)
            _coalescer.stats["no_sink"] += 1
            return
        _coalescer.offer(tenant, table)
    except Exception as exc:  # noqa: BLE001 — a write must never fail because of marking
        _coalescer.stats["errors"] += 1
        logger.debug("change_hook.changed failed: %s", exc)


def stats() -> Dict[str, int]:
    return dict(_coalescer.stats)
