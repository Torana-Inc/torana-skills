"""The convergence gate — a declared column has a writer, or it does not exist.

⭐ S9 (tracker row 19). This is the GATE half. Per § 4 of the brief the ordering is
**gate first, then the report, then any removal** — removing columns before the
growth path works leaves the platform unable to add them back cleanly.

## What this enforces

⛔ **A NEW declared column with no writer FAILS.** Not warns.

The columns that are shadow today cannot fail — they already shipped, and a
gate that fails on merge #1 gets deleted rather than obeyed. So the shape is a
**ratchet**, not a cliff:

    the baseline below is a CEILING that may only ever go DOWN

Add a column with a writer  → baseline unchanged, gate passes.
Add a column with NO writer → the shadow set grows past the ceiling → ⛔ FAIL.
Give a shadow column a writer → the set shrinks; the test tells you to lower the
                                ceiling, so the win is locked in and cannot regress.

## ⭐ S11 (tracker row 34) lowered this ratchet 920 → 150

The removal half of the plan, which row 19 stopped short of. 770 of the 920 shadow
columns were referenced by NOTHING — no corpus question, no `vm.tf.*` entry, no app
bundle, no template. ⛔ 753 were deleted; **17 were KEPT** — the
`created_via`/`dataset_tag` SDG-provenance pair, which two shipped API routes query
across all 11 sink tables and which pantheon-sdg writes from Python. They were
reachability-invisible, not unwritten; they are now DECLARED via the write seam
(`torana_mesh/etl/sdg_provenance.py`), which is why `reachable` rose 397 → 414. Removal is
just that deletion: `_ensure_schema_columns()` builds its per-tenant `ALTER TABLE …
ADD COLUMN IF NOT EXISTS` list from these classes, so a fresh tenant simply never
gets the column. No migration, no DROP COLUMN, no data path.

## ⭐ S14 (tracker row 42) took the ratchet to ZERO — the gate is now closed

Row 34 left 150 columns standing: all `shadow_and_referenced`, i.e. read by a
corpus question or a `vm.tf.*` catalog entry while nothing wrote them. Row 42
removed them on ONE principle rather than 150 judgements — **a declared column
has a writer, or it does not exist**. None appeared in any category model, so we
do not believe a connected tool should write them, nor a future one; *"a tool we
do not support yet might"* is unfalsifiable, which is exactly the aspiration
`SCHEMA_CONVERGENCE.md` § 4 says must stop being indistinguishable from the
contract. The references were ALREADY broken — every one returned nothing and
always had — so removal stops CLAIMING a capability rather than losing one.

Measured in pantheon-integration-dev: **564 → 415 declared, 415 reachable, 0
shadow (100%)**. 141 `shadow_and_referenced` + 8 residual row-34 leftovers
(7 `identities`, 1 `repositories`) that nothing referenced. ⛔ `reachable` LOST
NOTHING — verified by comparing `(table, column)` SETS, not totals; it rose by
exactly 1 because `datastores.dataset_tag` gained the write-seam registration it
had always been owed (see below).

⚠️ **`datastores.dataset_tag` was the row-34 mistake repeating one column over.**
The SDG-provenance registration excluded `datastores` wholesale on the grounds
that it "reaches these columns through its own mappings" — true of
`created_via` (slack/channels.yaml writes it) and FALSE of `dataset_tag`, which
had no writer of any kind while pantheon-sdg's replay engine stamps it
unconditionally and `clear-sdg-data` filters on it. The exclusion is now
per-column. ⛔ An exclusion justified for a table must hold for EVERY column it
excludes.

⭐ **So the ceiling has reached its floor.** `declared` and `writable` are the
same set, and any future increase is unambiguously a NEW shadow column — a build
failure, not a discovery. There is no backlog left for a regression to hide in.

⭐ **Before re-declaring anything removed here, read the archive**:
`pantheon-datalake/docs/corpus/removed_columns_archive.csv` — 770 rows with the
`data_type` and (where anyone ever wrote one) the `semantic_description`. It is a
design record, ⛔ **not a to-do list**: a column comes back only together with the
writer that fills it, which is what this gate enforces.

## Why a count and not a list

⚠️ A frozen list of column names would need editing on every legitimate schema
change, and a list that is edited constantly is a list nobody reads — the failure
mode `write_seam.py` records for hand-written registries. A single integer cannot
drift silently: any movement in either direction is a one-line, reviewable diff
with this docstring attached.

⛔ **There is deliberately NO grandfather list here.** The precedent is
`GRANDFATHERED_WITHOUT_CALLER` in `write_seam.py`: empty by measurement, kept empty
by a test, because *"the rule depended on someone remembering"* and columns shipped
without it. Same shape, same reason — the baseline IS the whole exemption surface,
and it is one number.

## ⚠️ Where this can be evaluated

`kind=declared` writers reach the reachability map by IMPORTING the modules that
call ``register_writer()`` — nothing scans for them. Those live in ``torana_mesh``.
So a process that cannot import them sees an EMPTY seam registry and reports ~12
columns WITH writers as shadow, **silently** (``parse_errors`` stays empty, because
importing ``write_seam`` itself succeeds).

Measured 2026-08-09, BEFORE the S11 removal (the gap is the point, not the totals):

    host venv (no torana_mesh) : WRITERS=0   → 385 reachable / 932 shadow
    pantheon-integration-dev   : WRITERS=11  → 397 reachable / 920 shadow  ← true

After S11, in pantheon-integration-dev: 564 declared / 414 reachable / 150 shadow.
After S14: **415 declared / 415 reachable / 0 shadow**.
⚠️ `reachable` did not FALL across EITHER removal (397 → 414 → 415) — the check
that proves no writable column was deleted. It rose by 17 at S11 (the
SDG-provenance pair declared via the write seam) and by 1 more at S14
(`datastores.dataset_tag`, the column that registration had wrongly excluded).
⛔ Compare `(table, column)` SETS, never totals: a count can hold steady while a
delete-one/gain-one swap hides inside it.

⛔ Therefore ``measure_shadow_set`` REFUSES to answer when the seam registry is
empty rather than returning a confident wrong number — § 6.2 rule 1.
"""

from __future__ import annotations

from typing import Dict, Iterable, List, NamedTuple, Optional, Set, Tuple

# ── The ceiling ──────────────────────────────────────────────────────────────
# ⛔ MEASURED 2026-08-13 on the platform scope, inside pantheon-integration-dev
# with all write-seam modules imported. (History: 1317 declared / 397 reachable /
# 920 shadow → S11 removed 753 → S14 removed 149, reaching 415/415/0 → S27
# removed 1 and identified the 2 below.)
#
# ⚠️ THIS NUMBER MAY ONLY EVER DECREASE, WITH EXACTLY ONE EXCEPTION, ALREADY
# SPENT — the two columns named in the docstring below. If a change of yours
# raises it for ANY OTHER column, that change added a column nothing can write:
# build the writer, or do not declare the column. Do not "fix the test".
#
# Lower it (and only lower it) when a writer lands for a column that had none.
SHADOW_BASELINE: int = 2
"""Max declared-but-unwritable columns at PLATFORM scope. Ratchet: down only.

⛔ **The 2 are NAMED, and the allowance is exhausted by them.** This is not two
columns of slack — it is these two specific columns and no others:

    ("vulnerabilities", "cve_published_date")
    ("vulnerabilities", "cve_last_modified_date")

**Why they are deliberately unwritten.** Both HAD a writer and it was REMOVED on
purpose (`mappings/gcp/container_analysis_occurrences.yaml`). It derived them from
`createTime`/`updateTime` — the same expression as `scan_first_detected_date` — so
the columns were byte-identical to the microsecond on all 85,984 rows. That is a
fabrication: those fields are when OUR scanner saw the occurrence, not when the
ADVISORY became public. The columns answer *"how long has this been public?"*,
which every SLA and exposure-window calculation depends on. Populated with scan
time they silently return the wrong answer while LOOKING fully populated — worse
than an obvious gap. The honest value is NULL until an advisory feed (NVD/OSV,
joined on `cve_id`) backs them.

⭐ **So `0 → 2` is NOT the failure this ratchet exists to catch.** That failure is
*"someone declared a column nothing writes and raised the ceiling to hide it"*.
This is the opposite: a writer was deliberately DELETED to stop it fabricating
data, and the column is kept declared as the honest target for a real source.
⛔ **Any increase beyond these two is still a build failure.** There is no slack
here for a regression to hide inside — a third shadow column means a NEW
unwritable declaration, and the answer is to build the writer or drop the column.

⚠️ **Why these are not simply subtracted from the measurement** (the design
question that was asked and answered, 2026-08-13): a `DELIBERATELY_UNWRITTEN` set
that `measure_shadow_set()` subtracts would keep this constant at 0 and express
the intent more precisely — but `shadow_columns` is ALSO what B11 uses
(`app_bundles/validator.py`) to reject a bundle whose SQL reads an unwritable
column. Subtracting these two would disarm B11 for exactly the columns that most
need it: a bundle could read `cve_published_date`, pass validation, ship, and
render an empty panel that a customer reads as *"nothing was published recently"*
when the truth is *"nobody records it"*. The count moves; the hazard does not.
⭐ If that set is ever built, it must be a SEPARATE axis (an annotation on the
shadow entry) that B11 continues to reject on — never a subtraction."""

# ⛔ Population, stated in the constant's own neighbourhood — § 6.2 rule 2. A
# count whose population is implied is the defect that rule exists to remove.
SHADOW_BASELINE_POPULATION = (
    "platform scope (every integration Torana ships, connected or not); "
    "11 sink tables; 435 declared columns; measured 2026-09-05"
)

SHADOW_BASELINE_DECLARED: int = 435
"""Declared-column total the baseline was measured against. If this moves, the
schema grew or shrank — which is the event the gate exists to notice.

⚠️ **Edit this together with `SHADOW_BASELINE_POPULATION` above** — it embeds the
same number in prose, and `test_shadow_baseline.py` asserts the two agree. Change
one alone and the gate fails on the population assertion instead.

History: 415 (S14, 2026-08-10) → 417 (the `assets` decoration provenance pair,
added by the decoration work and never reconciled) → **416** (S27 removed
`vulnerabilities.severity_score`, a duplicate of `cvss_base_score`) → **435**
(2026-09-05).

⛔ THE 416 → 435 JUMP IS 19 COLUMNS, AND ONLY 3 OF THEM BELONG TO THE CHANGE THAT
WROTE THIS LINE. Recording the split rather than one number, because a single
figure here would absorb sixteen unreviewed columns into a change that did not add
them — which is precisely the "growth reviewed rather than absorbed" property this
constant exists to hold:

  +3  THIS change — the `artifacts` scan-completeness trio (`vm_scan_analyzers`,
      `vm_security_scan_status`, `vm_continuous_analysis`, CAP-15). ⭐ Each ships
      WITH its writer, the `container_analysis_discovery` mapping, so the shadow
      count does not move; two of the three are returning from the removed-column
      archive, and the thing that changed is that they now have a writer they
      previously lacked. Verified: all three report reachable=True.

  +16 PRE-EXISTING DRIFT, from 20 commits that touched
      `datalake/schemas/` between 31002eb (2026-08-13, the last time this constant
      was measured) and now WITHOUT re-running this gate — a806592
      (`cloud_account_id`/`cloud_provider` on 4 sink tables), 1839975 (controls
      review-by + vuln linkage), 484252f (`assets.host_id`), 97487bf
      (`torana_datastore_id`), cb6336d (`risk_acceptance_expires_at`) and others.
      ⚠️ This constant asserted 419 while the real total was 432, so the
      denominator has been stating a falsehood for three weeks. Reconciled here
      because a knowingly-wrong constant is worse than a moved one — NOT because
      those 16 columns were reviewed by this change. They were not.

⛔ AND THE SHADOW COUNT IS NOW GENUINELY BREACHED — SEPARATELY, AND NOT BY THIS
CHANGE. `SHADOW_BASELINE` is 2 and the measured shadow set is **4**:

    ("artifacts", "display_name")
    ("controls", "expires_at")                  ← NEW, commit 1839975
    ("controls", "torana_vulnerability_id")     ← NEW, commit 1839975
    ("vulnerabilities", "cvss_risk_rating")

⚠️ Note that NEITHER of the two columns `SHADOW_BASELINE`'s own docstring names
(`cve_published_date`, `cve_last_modified_date`) is in that set any more — 6f90f73
gave them writers, which should have taken the count to 0. So all four entries
above are drift the gate never got to report.

⛔ `SHADOW_BASELINE` is deliberately LEFT AT 2. Raising it is the one move its
docstring forbids by name ("Do NOT raise SHADOW_BASELINE to make this pass"), and
doing so here would legalise two columns another change declared with no writer —
laundering someone else's shadow columns through an unrelated commit. The gate is
SUPPOSED to be red until each of the four gets a writer or is dropped."""


class SeamRegistryEmpty(RuntimeError):
    """The write-seam registry held no registrations, so the answer would be wrong.

    Its own type (not a bare RuntimeError) so *"this process cannot see mechanism
    8"* is distinguishable from a genuine measurement failure. Raised rather than
    returned as a number, because a confident wrong count is the exact failure
    this whole subsystem exists to remove.
    """


class ShadowMeasurement(NamedTuple):
    declared: int
    reachable: int
    shadow: int
    shadow_columns: Tuple[Tuple[str, str], ...]
    seam_registrations: int

    @property
    def population(self) -> str:
        return SHADOW_BASELINE_POPULATION


# Modules whose import registers write-seam writers. Import is the ONLY way the
# registry is populated; there is no scan. Kept here so both the gate and the
# report load the same set rather than each maintaining its own.
#
# ⚠️ THIS LIST DRIFTS, AND IT HAD. It held 5 entries while 6 modules called
# `register_writer()` — `torana_mesh.etl.sdg_provenance` was missing. ⭐ Measured, the
# omission cost nothing: 78 columns either way, because 3 of the 5 listed modules
# import `sdg_provenance` TRANSITIVELY. ⛔ **That is luck, not design** — remove that
# transitive import and 78 silently becomes 76, with no error anywhere.
#
# So the list is no longer the authority: `discover_write_seam_modules()` below finds
# the modules by SOURCE SCAN, and `test_write_seam_module_list_matches_discovery`
# fails when the two disagree. Every hand-written list in this area has drifted (nine
# tuples in `reachability.py`, a stale symbol name, a missing ingestor); this one is
# kept only as the fast import path and is now CHECKED against discovery.
WRITE_SEAM_MODULES: Tuple[str, ...] = (
    "torana_mesh.api.routes.ingest",
    "torana_mesh.etl.sdg_provenance",
    "torana_mesh.services.reconciliation",
    "torana_mesh.services.deployment_repaint",
    "torana_mesh.services.deployment_intelligence",
    "torana_mesh.services.graph_health_verdict",
    # Priority recompute — stamps vulnerabilities.priority/_score/_source from the
    # tenant's policy weights (SEVERITY_AND_PRIORITY_MODEL.md § 4.5). Added 2026-08-13.
    # ⚠️ This entry was FORGOTTEN on first write and `discover_write_seam_modules()`
    # caught it — which is the exact scenario its docstring predicts ("someone adds a
    # seventh writer module and forgets the list"). The seam registered fine on a
    # direct import but was invisible to `load_write_seam_modules()`, so the shadow
    # measurement would have counted the three new columns as unwritten.
    "torana_mesh.services.priority_recompute",
)


# The package the writer modules live in. Discovery walks its source tree rather
# than importing it, so it works in a process where `torana_mesh` is absent.
WRITE_SEAM_PACKAGE: str = "torana_mesh"


def discover_write_seam_modules(package_root: Optional[str] = None) -> Tuple[str, ...]:
    """⭐ Find every module that calls ``register_writer()``, by SOURCE SCAN.

    ⛔ **The point is that this does NOT read ``WRITE_SEAM_MODULES``** — it is the
    independent second opinion that makes the hand-written list falsifiable. A test
    asserts the two agree; when someone adds a seventh writer module and forgets the
    list, that test fails instead of the registry silently shrinking.

    Deliberately an AST-free textual scan of ``.py`` sources rather than an import
    walk: it must work in a process where ``torana_mesh`` is not importable at all
    (which is the whole failure mode this row exists to fix), and importing every
    module in a package to find out which ones register would run arbitrary
    top-level code.

    Returns dotted module paths, sorted. Empty tuple when the package source cannot
    be located — callers distinguish *"scanned and found none"* from *"could not
    scan"* via ``package_root``/``locate_write_seam_package()``.
    """
    root = package_root or locate_write_seam_package()
    if not root:
        return ()

    import os

    found: List[str] = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in {"__pycache__", ".git"}]
        for fn in filenames:
            if not fn.endswith(".py"):
                continue
            path = os.path.join(dirpath, fn)
            try:
                with open(path, "r", encoding="utf-8") as fh:
                    src = fh.read()
            except OSError:
                continue
            # A CALL, not the import — `write_seam.py` itself defines the function and
            # several modules import the name without registering anything.
            if "register_writer(" not in src:
                continue
            if not _has_register_writer_call(src):
                continue
            rel = os.path.relpath(path, os.path.dirname(root))
            mod = rel[:-3].replace(os.sep, ".")
            if mod.endswith(".__init__"):
                mod = mod[: -len(".__init__")]
            found.append(mod)
    return tuple(sorted(found))


def _has_register_writer_call(src: str) -> bool:
    """True when ``src`` really CALLS ``register_writer(...)``.

    ⚠️ A substring match alone would count `write_seam.py`'s own `def
    register_writer(` and any docstring that merely mentions the call — which would
    make discovery over-report and the drift test fail for the wrong reason. So parse
    it, and fall back to the substring only when the source will not parse.
    """
    import ast

    try:
        tree = ast.parse(src)
    except SyntaxError:
        return True

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        fn = node.func
        name = getattr(fn, "id", None) or getattr(fn, "attr", None)
        if name == "register_writer":
            return True
    return False


def locate_write_seam_package() -> Optional[str]:
    """Filesystem path to the ``torana_mesh`` package source, or ``None``.

    Tries the installed package first (the container case, where it is importable),
    then walks up looking for a sibling repo checkout (the host case, where it is
    not). Returning ``None`` rather than guessing keeps *"scanned and found none"*
    distinguishable from *"never scanned"* — the exact conflation this row removes.
    """
    import os

    try:
        import importlib.util
        spec = importlib.util.find_spec(WRITE_SEAM_PACKAGE)
        if spec and spec.submodule_search_locations:
            return list(spec.submodule_search_locations)[0]
    except Exception:
        pass

    here = os.path.abspath(__file__)
    for _ in range(12):
        here = os.path.dirname(here)
        if not here or here == os.sep:
            break
        cand = os.path.join(here, "pantheon-integration", WRITE_SEAM_PACKAGE)
        if os.path.isdir(cand):
            return cand
    return None


def load_write_seam_modules() -> List[str]:
    """Import every module that registers a writer. Returns the ones that failed.

    Failure-tolerant by design: a caller in a process where ``torana_mesh`` is
    absent must be able to find that out and refuse, rather than crash.
    """
    import importlib

    from pantheon_shared.datalake.write_seam import _set_autoloading

    # ⭐ S24. Mark registrations arriving here as LOADER-SUPPLIED rather than
    # explicit, so `_load_and_require_registry` can tell "a module in this process
    # declared itself" from "the auto-loader scraped up what it could". Only the
    # second is evidence of an incomplete registry.
    import sys

    _set_autoloading(True)
    try:
        failed: List[str] = []
        for mod in WRITE_SEAM_MODULES:
            try:
                importlib.import_module(mod)
            except Exception:
                failed.append(mod)
                continue

            # ⛔ S24. `import` is a NO-OP once the module is in `sys.modules`, so if the
            # registry was cleared (a test, an explicit reset) after the first import,
            # re-importing does NOT re-run the top-level `register_writer()` calls and
            # the registry stays empty — while the loader truthfully reports ZERO
            # failures. That combination produced the most misleading refusal possible:
            # "no import failures, so the module list must be stale", when the list was
            # correct and the modules were simply already loaded.
            #
            # So: if the module is cached but contributed nothing, RELOAD it to re-run
            # its registrations. Guarded on "contributed nothing" so the normal path
            # (first import, registry populated) never pays for a reload.
            if not _module_registered_anything(mod):
                try:
                    importlib.reload(sys.modules[mod])
                except Exception:
                    failed.append(mod)
        return failed
    finally:
        _set_autoloading(False)


def _module_registered_anything(mod: str) -> bool:
    """True when at least one registration's ``source`` points at ``mod``.

    ⚠️ Matched on the registration's declared ``source`` (``path/to/mod.py::func``)
    rather than on an id prefix: ``writer_id`` is free-form (``ingest.patch_vulnerability``
    does not contain its module path), so an id-prefix test would report "contributed
    nothing" for every writer and reload all six on every call.
    """
    from pantheon_shared.datalake.write_seam import WRITERS

    tail = mod.split(".")[-1]
    return any(f"{tail}.py" in (reg.source or "") for reg in WRITERS.values())


def declared_schema() -> Dict[str, List[str]]:
    """`{table: [columns]}` for the 11 sink tables.

    Prefers the reachability route's own registry so the gate and the API cannot
    disagree about the denominator; falls back to importing the schema classes
    directly when ``torana_mesh`` is absent.
    """
    try:
        from torana_mesh.api.routes.reachability import _declared_schema  # type: ignore
        return {t: list(c) for t, c in _declared_schema().items()}
    except Exception:
        pass

    import importlib

    registry = [
        ("artifacts", "ArtifactsSchema"),
        ("assets", "AssetsSchema"),
        ("controls", "ControlsSchema"),
        ("datastores", "DatastoresSchema"),
        ("entity_edges", "EntityEdgesSchema"),
        ("findings", "FindingsSchema"),
        ("identities", "IdentitySchema"),
        ("issues", "IssuesSchema"),
        ("packages", "PackagesSchema"),
        ("repositories", "RepositoriesSchema"),
        ("vulnerabilities", "VulnerabilitySchema"),
    ]
    out: Dict[str, List[str]] = {}
    for mod, cls in registry:
        m = importlib.import_module(f"pantheon_shared.datalake.schemas.{mod}")
        obj = getattr(m, cls)()
        out[obj.table_name] = list(obj.schema.keys())
    return out


def measure_shadow_set(*, require_seam: bool = True) -> ShadowMeasurement:
    """Measure declared-but-unwritable columns at PLATFORM scope.

    ⛔ Raises `SeamRegistryEmpty` when mechanism 8 contributed nothing and
    `require_seam` is set. See the module docstring: answering anyway would
    report ~12 written columns as shadow with no signal that it had happened.
    """
    from pantheon_shared.datalake.reachability import (
        SEAM_ORIGIN_ATTR,
        build_reachability_map,
    )
    from pantheon_shared.datalake.seam_source import SeamUnavailable
    from pantheon_shared.datalake.write_seam import WRITERS

    load_write_seam_modules()

    declared = declared_schema()

    # ⭐ S22 (row 35). The seam no longer has to be IMPORTABLE here — when the import
    # produced nothing, `writers_from_declared_seam` fetches the same registrations over
    # the reachability API, so this runs in `pantheon-program-framework` (the only
    # process holding the app bundles) for the first time.
    #
    # ⛔ THE REFUSAL IS PRESERVED, and that is the load-bearing property. If the fetch
    # cannot establish the registry it raises `SeamUnavailable`, which is translated
    # here into the SAME `SeamRegistryEmpty` callers already handle. "Could not verify"
    # still never becomes "verified and fine" — § 3.2 of the brief.
    try:
        rmap = build_reachability_map(tables=sorted(declared), declared=declared,
                                      require_seam=require_seam)
    except SeamUnavailable as exc:
        if not require_seam:
            raise
        raise SeamRegistryEmpty(
            f"the write-seam registry is EMPTY and could not be fetched: {exc}. "
            "Mechanism 8 (`kind=declared`) contributed no writers, so ~12 columns "
            "that ARE written would be counted as shadow. The registry is populated "
            f"by IMPORTING the modules that call register_writer() "
            f"({', '.join(WRITE_SEAM_MODULES)}), which live in torana_mesh, or by "
            "fetching them from the reachability API. Run where torana_mesh is "
            "importable (pantheon-integration-dev), make the API reachable, or pass "
            "require_seam=False if you genuinely want the mechanism-8-blind number."
        ) from exc

    # ⚠️ Count what was actually SEEN, by whichever route supplied it — an in-process
    # registry (`WRITERS`) or a fetched snapshot. A hard-coded `len(WRITERS)` would
    # report 0 on the fetch path and make a working measurement look degraded.
    snapshot = getattr(rmap, SEAM_ORIGIN_ATTR, None)
    seam_registrations = snapshot.registration_count if snapshot else len(WRITERS)

    if require_seam and not seam_registrations:
        raise SeamRegistryEmpty(
            "the write-seam registry is EMPTY, so mechanism 8 (`kind=declared`) "
            "contributed no writers and ~12 columns that ARE written would be "
            "counted as shadow. The registry is populated by IMPORTING the "
            f"modules that call register_writer() ({', '.join(WRITE_SEAM_MODULES)}), "
            "which live in torana_mesh. Run where torana_mesh is importable "
            "(pantheon-integration-dev), or pass require_seam=False if you "
            "genuinely want the mechanism-8-blind number."
        )

    reachable = {k for k, e in rmap.columns.items() if e.writers}

    shadow = tuple(sorted(
        (t.lower(), c.lower())
        for t, cols in declared.items()
        for c in cols
        if (t.lower(), c.lower()) not in reachable
    ))
    return ShadowMeasurement(
        declared=sum(len(v) for v in declared.values()),
        reachable=len(reachable),
        shadow=len(shadow),
        shadow_columns=shadow,
        seam_registrations=seam_registrations,
    )
