from typing import Dict, Any
from .base import TableSchema


class JoinTrustSchema(TableSchema):
    """Schema for the per-tenant ``join_trust`` table.

    One row per measurement of one declared relationship: how many rows on the
    left side actually find a partner on the right, measured on THIS tenant's
    data rather than promised by the schema. It is what turns a declared
    ``JOIN KEY`` into `RELY` / `DEGRADED` / `NORELY` / `UNMEASURED`, and what
    lets a SQL author quote an orphan rate instead of presenting a silently
    truncated count as complete.

    ⛔ DECLARED HERE BECAUSE A MIGRATION CANNOT PROVISION A TENANT.
    Until this class existed, ``join_trust`` was created ONLY by the hand-written
    ``op.create_table`` in datalake revision ``s18_0006_join_trust`` — and a new
    tenant never reached it. Two independent reasons, both of which had to hold:

      1. Tenant provisioning builds tables from the DECLARED SCHEMA CLASSES
         (``tables_for_tenant()`` = SINK ∪ DERIVED). A table with no class is not
         skipped — it was never a candidate.
      2. The live creation path runs ``reconcile_tenant(data=False)`` (deliberately:
         a data migration must never execute inside a multi-worker gunicorn boot),
         so its target is ``last_ddl_revision()``. That resolved to
         ``s18_0002_drop_unwritten``, because ``s18_0003`` is a ``data`` revision —
         which strands EVERY later DDL revision, ``s18_0006`` among them.

    So the table needed a migration to exist, and the migration never ran on the
    path that creates tenants. ⚠️ It failed SILENTLY: ``reconcile_tenant`` returned
    ok (it did all it was asked), and ``join_trust`` is in ``_BOOKKEEPING_TABLES``
    so it is excluded from table listings — a drift report comparing declared
    against live could not see it either. The first symptom was an HTTP 500 from
    ``POST /datalake/join-health/measure`` naming a relation that does not exist.
    Measured 2026-09-21: present on 2 container-reconciled tenants, absent on the
    2 created through the live path.

    ⭐ THIS IS THE ``entity_properties_resolved`` FIX, APPLIED AGAIN. That table
    had the identical failure — created lazily elsewhere, "existed on some tenants
    and not others", and **unmigratable**, since Alembic cannot carry a revision
    for a table the reconciler never provisions. Declaring it fixed both. See
    ``_derived_schemas()`` in ``alembic_support/declared_schema.py``, and the rule
    stated in ``_create_schema_and_tables``: *built from the declared schema
    classes, NEVER hand-written DDL in a migration — duplicating it as CREATE
    TABLE in a revision is how the two mechanisms drift.*

    ⚠️ NOT A SINK, and it carries NO reachability or write-seam claim. Nothing
    ingests it and no mapping writes it; the join-health measurer is its only
    writer. Adding it to the sink set would give it a contract it cannot honour.
    It is platform BOOKKEEPING that happens to live per-tenant, because the
    measurement it stores is a property of one tenant's data.

    ⚠️ ``description`` is declared as a BUSINESS column deliberately, matching the
    ``entity_properties_resolved`` precedent and the platform convention that every
    row carries a semantic description. It is not one of the injected system
    fields; do not remove it expecting ``get_full_schema()`` to supply one.

    ⚠️ TWO COLUMNS ARRIVE THAT ``s18_0006`` DID NOT CREATE: ``trace_id`` (TRACE)
    and ``contributing_sources`` (PROVENANCE) are injected by ``get_full_schema()``
    into every declared table. A tenant provisioned from this class therefore has
    two columns a tenant migrated by ``s18_0006`` lacks. That is additive and
    harmless — nothing reads them here — but it is a real difference between the
    two populations, so it is stated rather than discovered later.

    System fields (IAM, lifecycle, audit, trace, provenance) are injected by
    ``get_full_schema()`` — do NOT declare them here. The migration's eight
    hand-written IAM/lifecycle/audit columns are exactly those, which is the
    duplication this class removes.
    """

    @property
    def table_name(self) -> str:
        return "join_trust"

    @property
    def primary_key(self) -> str:
        return "id"

    @property
    def description(self) -> str:
        return (
            "Measured trust of each declared join, per tenant: how many left-side "
            "rows actually find a partner. One row per measurement, newest wins. "
            "Platform bookkeeping, not tenant data and not transformer output — it "
            "carries no reachability claim and nothing ingests it."
        )

    @property
    def category(self) -> str:
        return "Platform Bookkeeping"

    @property
    def timestamp_column(self) -> str:
        return "measured_at"

    @property
    def schema(self) -> Dict[str, Any]:
        return {
            "id": {
                "data_type": "UUID", "primary_key": True, "not_null": True,
                "category": "Core Identity",
                "semantic_description": (
                    "Surrogate key for one measurement. Rows accumulate — the read "
                    "is newest-per-relationship, never a single current row."
                ),
            },
            # ⭐ THE KEY. Already authored as `name:` on every relationship in the
            # semantic model YAML, which is what lets the declaration and the
            # measurement live in separate files and still render together.
            "relationship_name": {
                "data_type": "TEXT", "not_null": True,
                "category": "Core Identity",
                "semantic_description": (
                    "The declared relationship measured, matching `name:` in the "
                    "semantic model. The join between what was promised and what "
                    "was observed."
                ),
            },
            "left_rows": {
                "data_type": "BIGINT", "not_null": True, "category": "Measurement",
                "semantic_description": (
                    "Rows on the left side of the join, before any key filter — the "
                    "denominator a reader assumes when told 'this join works'."
                ),
            },
            "joinable_rows": {
                "data_type": "BIGINT", "not_null": True, "category": "Measurement",
                "semantic_description": (
                    "Left rows carrying a non-NULL join key, i.e. those that COULD "
                    "match. ⚠️ Distinct from left_rows: a NULL key means the join is "
                    "unused on that row, not broken."
                ),
            },
            "matched_rows": {
                "data_type": "BIGINT", "not_null": True, "category": "Measurement",
                "semantic_description": (
                    "Joinable rows that actually found a partner. matched vs "
                    "joinable is the orphan rate; matched vs left is not."
                ),
            },
            "orphan_rate": {
                "data_type": "NUMERIC(6,4)", "category": "Measurement",
                "semantic_description": (
                    "Share of joinable rows with no partner. ⛔ NULL when "
                    "joinable_rows = 0 — no denominator, therefore no rate. NOT "
                    "zero: zero reads as 'perfectly joined', the opposite of "
                    "'unmeasurable'."
                ),
            },
            "trust": {
                "data_type": "VARCHAR(16)", "not_null": True, "category": "Verdict",
                "semantic_description": (
                    "RELY (orphan rate <= 1%) | DEGRADED (works for most rows, "
                    "silently drops the rest) | NORELY (rows name partners that do "
                    "not exist, so an empty result is NOT evidence of absence) | "
                    "UNMEASURED (nobody has checked — never read as 'fine')."
                ),
            },
            "unmeasured_reason": {
                "data_type": "VARCHAR(32)", "not_null": True, "default": "",
                "category": "Verdict",
                "semantic_description": (
                    "Why trust is UNMEASURED: no_rows | never_run | below_floor | "
                    "no_joinable_keys | column_missing. ⭐ Separates 'expected, "
                    "wait' from 'a broken pipeline', which read identically on the "
                    "orphan rate alone. column_missing is a declaration defect — the "
                    "semantic model names a join the live schema does not have."
                ),
            },
            "diagnosis": {
                "data_type": "TEXT", "not_null": True, "default": "",
                "category": "Verdict",
                "semantic_description": (
                    "One sentence a human reads — what turns '0 of 568' into "
                    "'vulnerabilities mint image: keys, assets mint cloud:/service: "
                    "— disjoint keyspaces'."
                ),
            },
            "measured_at": {
                "data_type": "TIMESTAMP", "not_null": True,
                "category": "Measurement",
                "semantic_description": (
                    "When this measurement ran. ⚠️ Rows accumulate, so every read is "
                    "newest-per-relationship; an old row is history, not the answer."
                ),
            },
            "duration_ms": {
                "data_type": "INTEGER", "category": "Measurement",
                "semantic_description": (
                    "How long the measurement itself took, so a duration tripwire "
                    "has a series to compare against rather than a guessed constant."
                ),
            },
            "left_synced_at": {
                "data_type": "TIMESTAMP", "category": "Measurement",
                "semantic_description": (
                    "Last sync of the left table. ⭐ With right_synced_at this "
                    "separates 'mid-onboarding' from 'permanently broken', which "
                    "read IDENTICALLY on the orphan rate alone."
                ),
            },
            "right_synced_at": {
                "data_type": "TIMESTAMP", "category": "Measurement",
                "semantic_description": (
                    "Last sync of the right table. See left_synced_at."
                ),
            },
            "description": {
                "data_type": "TEXT", "not_null": True, "default": "",
                "category": "Core Identity",
                "semantic_description": (
                    "Semantic description of what this measurement row records. "
                    "Declared as a business column deliberately — it is not an "
                    "injected system field."
                ),
            },
        }
