"""System fields that are auto-injected into all datalake schemas.

System fields are categorized into three types:
1. IAM: Identity and Access Management (access control)
2. Lifecycle: Data state management (soft-delete)
3. Audit: Compliance and accountability (who/when)
"""

# ============================================================================
# IAM FIELDS: Identity and Access Management
# ============================================================================
# Purpose: Control WHO can access WHAT data
# Characteristics: Used in security checks, multi-tenancy isolation
# ============================================================================

IAM_FIELDS = {
    "tenant_id": {
        "data_type": "VARCHAR(255)",
        "not_null": True,
        "category": "IAM",
        "description": "Tenant identifier (multi-tenancy isolation)",
    },
    "namespace_id": {
        "data_type": "VARCHAR(255)",
        "not_null": True,
        "category": "IAM",
        "description": "Namespace identifier (scoping within tenant)",
    },
}

# ============================================================================
# LIFECYCLE FIELDS: Data state and soft-delete
# ============================================================================
# Purpose: Track data lifecycle (active, deleted, archived)
# Characteristics: Used in filtering, not in access control
# ============================================================================

LIFECYCLE_FIELDS = {
    "is_deleted": {
        "data_type": "BOOLEAN",
        "not_null": False,
        "default": False,
        "category": "Lifecycle",
        "description": "Soft-delete flag (record is hidden but preserved)",
    },
}

# ============================================================================
# AUDIT FIELDS: Compliance and accountability
# ============================================================================
# Purpose: Track who changed what and when
# Characteristics: Not used in access control or filtering
# ============================================================================

AUDIT_FIELDS = {
    "created_at": {
        "data_type": "TIMESTAMP",
        "not_null": False,
        "category": "Audit",
        "description": "Record creation timestamp",
    },
    "created_by": {
        "data_type": "VARCHAR(255)",
        "not_null": False,
        "category": "Audit",
        "description": "User or system that created the record",
    },
    "updated_at": {
        "data_type": "TIMESTAMP",
        "not_null": False,
        "category": "Audit",
        "description": "Last update timestamp",
    },
    "updated_by": {
        "data_type": "VARCHAR(255)",
        "not_null": False,
        "category": "Audit",
        "description": "User or system that last updated the record",
    },
}

# ============================================================================
# TRACE FIELDS: Observability correlation
# ============================================================================
# Purpose: Correlate a persisted row to its Jaeger trace and Loki/ES logs via
#          the single platform trace_id (the ONE trace_id contract). Populated
#          server-side from the request's TraceContext at write time; nullable
#          (best-effort — a missing id never blocks a write).
# ============================================================================

TRACE_FIELDS = {
    "trace_id": {
        "data_type": "VARCHAR(255)",
        "not_null": False,
        "category": "Audit",
        "description": "Platform trace_id correlating this row to its Jaeger trace and Loki/ES logs",
    },
}

# ============================================================================
# PROVENANCE_FIELDS — row-level source attribution (viz provenance spec § 3.3.2).
#
# A standard-table row can have MULTIPLE writers over time — convergence on
# source-neutral keys is designed in (github/repositories and jira/projects both
# upsert `repositories` on torana_repository_id). But `source_system` is set by a
# plain `set` op on every upsert, so it records only the LAST writer; the earlier
# contributions are erased.
#
# `contributing_sources` is a KEYED MAP that accumulates instead:
#   {"<source>:<integration_id>": {integration_id, data_source,
#                                  first_seen, last_seen, runs}}
# A map, NOT an append log: `entity_edges` has 131k+ rows re-walked every sync, so
# a per-landing append would grow unbounded and churn TOAST. The key is stable per
# (source, integration), so a re-sync updates its own entry in place.
#
# The merge happens in the shared ON CONFLICT clause (postgres_backend.py), NOT
# per-mapping — a field only some pipelines populate would under-report
# contributors with no way to tell absence from "never contributed".
# ============================================================================

PROVENANCE_FIELDS = {
    "contributing_sources": {
        "data_type": "JSONB",
        "not_null": False,
        "category": "Audit",
        "description": (
            "Keyed map of integrations that have written this row: "
            "{'<source>:<integration_id>': {integration_id, data_source, "
            "first_seen, last_seen, runs}}. Accumulated in the shared upsert "
            "ON CONFLICT clause; never overwritten wholesale."
        ),
    },
}

# All system fields (IAM + Lifecycle + Audit + Trace + Provenance)
SYSTEM_FIELDS = {**IAM_FIELDS, **LIFECYCLE_FIELDS, **AUDIT_FIELDS,
                 **TRACE_FIELDS, **PROVENANCE_FIELDS}

# Standard system fields (always included in table creation)
STANDARD_SYSTEM_FIELDS = SYSTEM_FIELDS
