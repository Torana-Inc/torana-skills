from typing import Dict, Any
from .base import TableSchema


class IdentitySchema(TableSchema):
    """Schema definition for the identities table."""

    @property
    def table_name(self) -> str:
        return "identities"

    @property
    def primary_key(self) -> str:
        # ⛔ Returns "identity_id", NOT "torana_identity_id". This property used to name a
        # column that existed nowhere - not in the schema dict below, and not in
        # the live table - so the declared primary key of `identities` pointed at
        # nothing. Same defect class as #176 (`datastores`), found by the
        # semantic-model validator in datalake/schemas/validation.py.
        #
        # #176 fixed `datastores` by ADDING the column, because the entity graph
        # genuinely needed a `torana_*` pointer to key rows from. That reasoning
        # does NOT apply here: nothing reads "torana_identity_id" (grepped across
        # shared, integration and datalake - only prose mentions), and every
        # mapping that writes this table declares `primary_key: identity_id`.
        # Adding a column nothing writes would create exactly the shadow column
        # the reachability rules exist to prevent, so the property is corrected
        # to the column that is actually written instead.
        return "identity_id"

    @property
    def description(self) -> str:
        return "User and service identities across cloud and on-prem systems with authentication and access control data"

    @property
    def category(self) -> str:
        return "Identity Data"

    @property
    def timestamp_column(self) -> str:
        """Return the timestamp column for this table."""
        return "updated_at"

    @property
    def schema(self) -> Dict[str, Any]:
        return {
            "identity_id": {
                "data_type": "VARCHAR(255)", "primary_key": True, "category": "Core Identity",
                "semantic_description": (
                "Source-scoped identifier for one identity, prefixed with the provider that produced it "
                "(`gcp_sa_<uniqueId>`, `aws_iam_<UserId>`). Primary key of this table; one row per "
                "identity per source system, so the SAME human with an Okta account and a GitHub "
                "account is TWO rows here, not one."
                ),
            },
            "external_id": {
                "data_type": "VARCHAR(255)", "category": "Core Identity",
                "semantic_description": (
                "The identity's own identifier in the source system, kept verbatim so a row can be "
                "traced back and re-fetched. Its SHAPE is provider-specific and not comparable across "
                "sources: an ARN on AWS, the fully-qualified resource name on GCP, a numeric id on "
                "GitLab. Never join two providers on this column."
                ),
            },
            "source_system": {
                "data_type": "VARCHAR(100)", "category": "Core Identity",
                "semantic_description": (
                    "The integration or internal producer that reported this identity row. ⚠️ Determines "
                    "which other columns are populated at all, since sources differ in what they expose, "
                    "and it is the first thing to check when two rows describe the same identity "
                    "differently."
                ),
            },
            "cloud_account_id": {"data_type": "VARCHAR(100)", "category": "Cloud Provider-Specific Fields",
                "semantic_description": (
                    "The cloud account or subscription this row belongs to — a GCP project id, an "
                    "AWS account number, an Azure subscription. Often the real boundary between "
                    "teams or environments, so it is the natural grouping for 'show me X by "
                    "account'. ⚠️ NOT a Jira project and NOT a logical/product grouping: those "
                    "are separate concepts (see issues.project_key and the governance properties). "
                    "NULL for rows that are not cloud-sourced."
                ),
            },
            "cloud_provider": {"data_type": "VARCHAR(50)", "category": "Cloud Provider-Specific Fields",
                "semantic_description": (
                    "Which cloud this runs in: AWS, Azure, GCP, OCI, or On-Premises. ⚠️ Distinct "
                    "from source_system, which says WHO reported the row — a Kubernetes connector "
                    "reporting a workload running in GCP writes source_system='kubernetes' and "
                    "cloud_provider='gcp'. Needed to disambiguate cloud_account_id, whose namespace "
                    "differs per provider."
                ),
            },
            "provider": {
                "data_type": "VARCHAR(50)", "category": "Core Identity",
                "semantic_description": (
                    "The vendor or platform family behind this identity, set as a mapping constant. ⚠️ One "
                    "level COARSER than `source_system`: several data sources of one vendor share a "
                    "provider value, so group by `provider` to ask about ecosystems and by `source_system` "
                    "to identify the feed."
                ),
            },
            "account_id": {
                "data_type": "VARCHAR(100)", "category": "Core Identity",
                "semantic_description": (
                "The identity's login or account handle within its source system — an email address for "
                "GCP service accounts, an IAM user name on AWS. This is the human-recognisable account "
                "key, whereas `identity_id` is Torana's row key and `external_id` is the provider's "
                "opaque one."
                ),
            },
            "identity_type": {
                "data_type": "VARCHAR(50)", "category": "Identity Classification",
                "semantic_description": (
                "Canonical class of this identity, normalised across providers by "
                "`normalize_identity_type()` so every source spells it the same way. Observed values on "
                "real data include `user`, `service_account`, `service_account_key` and `team`; an "
                "unrecognised provider value is preserved in snake_case rather than collapsed to "
                "`unknown`, so new types appear here rather than disappearing."
                ),
            },
            "is_service_account": {
                "data_type": "BOOLEAN", "category": "Identity Classification",
                "semantic_description": (
                "True when the identity is non-human (a bot, an app user, a machine principal). ⚠️ "
                "Populated only by sources that expose a bot flag — jira, slack and github set it, "
                "while GCP leaves it NULL even for rows whose `identity_type` IS `service_account`. "
                "Filter on `identity_type` when you need every non-human identity; this flag alone "
                "undercounts them."
                ),
            },
            "is_machine_identity": {
                "data_type": "BOOLEAN", "category": "Identity Classification",
                "semantic_description": (
                "True when the identity represents a workload or machine credential rather than a "
                "person or a bot user. Broader in intent than `is_service_account`, which tracks the "
                "source's own bot flag; both are provider-reported and neither is derived by Torana."
                ),
            },
            "username": {
                "data_type": "VARCHAR(255)", "category": "Basic Information",
                "semantic_description": (
                "The login name the identity authenticates with in its source system. Frequently equal "
                "to `account_id`, and on providers that expose no separate handle the mapping copies "
                "one to the other, so do not treat a match between the two as evidence of anything."
                ),
            },
            "display_name": {
                "data_type": "VARCHAR(255)", "category": "Basic Information",
                "semantic_description": (
                "Human-readable label for this IDENTITY as the source system presents it, used when "
                "rendering a principal in a UI. Falls back to the account handle where a provider "
                "supplies no friendly name. ⚠️ Distinct from `full_name`, which is the person's real "
                "name and is populated only by directory sources."
                ),
            },
            "full_name": {
                "data_type": "VARCHAR(255)", "category": "Basic Information",
                "semantic_description": (
                "The person's real-world name as recorded in the source directory. Populated only by "
                "identity providers that carry HR-style attributes, and NULL for service accounts and "
                "machine identities by nature."
                ),
            },
            "first_name": {
                "data_type": "VARCHAR(100)", "category": "Basic Information",
                "semantic_description": (
                "Given name of the person behind this identity, where the source directory exposes name "
                "parts separately. NULL for non-human identities."
                ),
            },
            "last_name": {
                "data_type": "VARCHAR(100)", "category": "Basic Information",
                "semantic_description": (
                "Family name of the person behind this identity, where the source directory exposes "
                "name parts separately. NULL for non-human identities."
                ),
            },
            "email": {
                "data_type": "VARCHAR(255)", "category": "Basic Information",
                "semantic_description": (
                "Email address of the identity as reported by the source. ⚠️ Sparsely populated in "
                "practice and NOT a reliable join key: GCP service-account rows carry the address in "
                "`account_id` and `username` while leaving this column NULL, deliberately, because a "
                "fabricated placeholder here would read as a real mailbox."
                ),
            },
            "status": {
                "data_type": "VARCHAR(50)", "category": "Account Status",
                "semantic_description": (
                "Lifecycle state of the account in its source system, normalised by the mappings to "
                "`active` or `inactive` (from enabled/disabled/deleted flags upstream). Answers whether "
                "the account may still be used; it does NOT say whether the account is privileged or in "
                "use — see `last_login_date` for activity."
                ),
            },
            "enabled": {
                "data_type": "BOOLEAN", "category": "Account Status",
                "semantic_description": (
                "True when the source system reports the account as enabled. The raw provider flag from "
                "which `status` is derived; prefer `status` for cross-provider queries, since not every "
                "source populates this boolean."
                ),
            },
            "disabled": {
                "data_type": "BOOLEAN", "category": "Account Status",
                "semantic_description": (
                "True when the source system reports the account as explicitly disabled. ⚠️ Not simply "
                "the negation of `enabled` — a provider may set neither, so `disabled IS NOT true` and "
                "`enabled = true` select different row sets."
                ),
            },
            "is_admin": {
                "data_type": "BOOLEAN", "category": "Account Details",
                "semantic_description": (
                "True when the identity holds an administrative role in its source system, such as an "
                "org owner or workspace admin. Provider-reported and scoped to THAT system: an admin in "
                "Slack implies nothing about cloud privilege."
                ),
            },
            "is_privileged": {
                "data_type": "BOOLEAN", "category": "Account Details",
                "semantic_description": (
                "True when the identity holds elevated permissions beyond an ordinary user, as judged "
                "by the source. Broader than `is_admin`, which is specifically an administrator role, "
                "and equally scoped to the identity's own source system."
                ),
            },
            "mfa_enabled": {
                "data_type": "BOOLEAN", "category": "Authentication",
                "semantic_description": (
                "True when multi-factor authentication is enabled for this identity in its source "
                "system. ⚠️ NULL means the provider did not report MFA state, NOT that MFA is off — "
                "counting `mfa_enabled = false` as 'unprotected accounts' silently reclassifies every "
                "unreported identity."
                ),
            },
            "created_date": {
                "data_type": "TIMESTAMP_NTZ", "category": "Lifecycle",
                "semantic_description": (
                "When the IDENTITY was created in its source system, as reported by that system (AWS "
                "`CreateDate`, and the equivalent elsewhere). ⚠️ Not to be confused with `created_at`, "
                "which is when Torana first ingested the row — the two can differ by years."
                ),
            },
            "last_modified_date": {
                "data_type": "TIMESTAMP_NTZ", "category": "Lifecycle",
                "semantic_description": (
                "When the identity record last changed in its source system. Provider-reported, so its "
                "precision and its definition of 'changed' vary by source; use it to spot drift, not as "
                "a precise audit timestamp."
                ),
            },
            "last_login_date": {
                "data_type": "TIMESTAMP_NTZ", "category": "Lifecycle",
                "semantic_description": (
                "When this identity last authenticated successfully, as reported by the source. The "
                "primary evidence for a dormant-account query; NULL where the provider does not expose "
                "login history, which is not the same as never having logged in."
                ),
            },
            "last_activity_date": {
                "data_type": "TIMESTAMP_NTZ", "category": "Lifecycle",
                "semantic_description": (
                "When the identity last did anything the source system recorded, which is broader than "
                "a login (AWS maps `PasswordLastUsed` here). ⚠️ Distinct from "
                "`repositories.last_activity_date`, which measures commit activity on a codebase, not "
                "the actions of a principal."
                ),
            },
            "department": {
                "data_type": "VARCHAR(100)", "category": "Organization",
                "semantic_description": (
                "Organisational unit the person belongs to, sourced from directory attributes. "
                "Populated only by identity providers carrying HR data; the basis for owner-by-team "
                "reporting where it exists."
                ),
            },
            "title": {
                "data_type": "VARCHAR(100)", "category": "Organization",
                "semantic_description": (
                "The person's job title as recorded in the source directory. ⚠️ Distinct from "
                "`findings.title`, which is the summary line of a security finding — same column name, "
                "entirely different concept."
                ),
            },
            "attributes": {
                "data_type": "VARIANT", "category": "Metadata",
                "semantic_description": (
                "Raw provider-specific fields for this identity, packed as JSON at ingest so nothing "
                "the source returned is lost. A staging area for values without a typed column yet; ⛔ "
                "read it for investigation, never as a substitute for a declared column in shipped SQL, "
                "since its keys are unstable across providers."
                ),
            },
            "discovery_source": {
                "data_type": "VARCHAR(100)", "category": "Discovery",
                "semantic_description": (
                    "The FEED through which this identity was discovered — which pipeline told the platform "
                    "it exists. ⚠️ Kept distinct from `source_system` because a identity can be discovered "
                    "by one mechanism and maintained by another."
                ),
            },
            "discovery_method": {
                "data_type": "VARCHAR(50)", "category": "Discovery",
                "semantic_description": (
                    "By what MEANS this identity was discovered — an API collection, an inventory sweep, or "
                    "a manual registration. Complements `discovery_source` (which feed) and is how "
                    "automatically-inventoried rows are separated from hand-registered ones."
                ),
            },
            "api_collected": {
                "data_type": "BOOLEAN", "category": "Discovery",
                "semantic_description": (
                "True when this identity row came from a programmatic API collection rather than a "
                "manual or file-based load. Provenance evidence for trusting the row's freshness."
                ),
            },
            "auto_discovered": {
                "data_type": "BOOLEAN", "category": "Discovery",
                "semantic_description": (
                "True when Torana discovered this identity automatically rather than a user registering "
                "it. Together with `api_collected`, distinguishes an inventoried estate from a "
                "hand-curated one."
                ),
            },
            "created_by": {
                "data_type": "VARCHAR(255)", "category": "Audit",
                "semantic_description": (
                "The Torana user or service principal that caused this row to be created. ⚠️ An "
                "INGEST-side actor, not the identity's owner in the source system — do not read it as "
                "'who owns this account'."
                ),
            },
            "created_via": {
                "data_type": "VARCHAR(100)", "category": "Audit",
                "semantic_description": (
                    "The Torana mechanism that wrote this identity row — an integration sync, a replay, a "
                    "manual push, or a synthetic dataset load. ⛔ Provenance, not identity data: it is what "
                    "separates genuinely ingested rows from generated ones, and a query measuring a real "
                    "estate should know which values are synthetic."
                ),
            },
            "dataset_tag": {
                "data_type": "VARCHAR(200)", "category": "Audit",
                "semantic_description": (
                    "Marks this identity row as seeded by a NAMED synthetic dataset rather than a live "
                    "integration, so such rows can be purged as a set. NULL for genuinely ingested rows. ⛔ "
                    "Filter it out when measuring a real estate — counting demo rows as production identity "
                    "data is the error this column exists to prevent."
                ),
            },
        }