"""Per-column conflict policies for the shared upsert — ONE hook, many rules.

WHY THIS EXISTS
---------------
`PostgreSQLBackend.upsert` writes every sink row as `INSERT … ON CONFLICT … DO UPDATE SET
col = EXCLUDED.col`. Some columns cannot be written that way, because their new value depends on
the STORED value as well as the incoming one:

  * `contributing_sources` — a per-key merge that keeps `first_seen` and increments `runs`
    (viz provenance § 3.3.5);
  * the vulnerability LIFECYCLE columns — computed from both rows so a reopen clears the closure,
    a closure is stamped once, and the state clock moves only on a real change
    (VULNERABILITY_LIFECYCLE_DESIGN.md § 3.4.1).

Both used to be special cases hard-coded into the backend. This module is the single registry:
each policy says which columns it OWNS (removed from the generic SET list), what to assign
instead, an optional `WHERE` for `DO UPDATE`, and an optional hook that prepares records before
the INSERT. The backend asks the registry and splices; it no longer knows any individual rule.

⛔ A policy's assignment MUST own its column. If the generic `col = EXCLUDED.col` were also
emitted, the last assignment would win in Postgres and silently undo the policy — that is the
invisible blocker the `contributing_sources` merge originally hit (spec R4).

ADDING A POLICY: write a builder `(ctx) -> Optional[ConflictClause]`, optionally a
`prepare(records, now)` hook, and append a `Policy` to `POLICIES`. Order in `POLICIES` is the
order of the emitted assignments.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Dict, FrozenSet, Iterable, List, Optional, Set, Tuple

from psycopg2 import sql

from pantheon_shared.datalake import lifecycle

__all__ = ["ConflictContext", "ConflictClause", "Policy", "POLICIES",
           "prepare_records", "prepare_record_groups", "conflict_clauses"]


@dataclass
class ConflictContext:
    """Everything a policy may look at when building its clause for one statement."""

    table: str
    table_columns: Set[str]
    batch_columns: Set[str]
    preserve: Set[str]
    primary_key: str
    table_ref: sql.Composable
    #: Columns present only because a `prepare` hook stamped them; not the writer's claim.
    stamped: Set[str] = field(default_factory=set)


@dataclass
class ConflictClause:
    #: Columns this policy assigns; removed from the generic `col = EXCLUDED.col` list.
    owned: Set[str] = field(default_factory=set)
    assignments: List[sql.Composable] = field(default_factory=list)
    #: Optional predicate ANDed into `DO UPDATE … WHERE`.
    where: Optional[sql.Composable] = None


@dataclass
class Policy:
    name: str
    #: Tables the policy applies to; None = any table (it checks its own columns).
    tables: Optional[Set[str]]
    build: Callable[[ConflictContext], Optional[ConflictClause]]
    prepare: Optional[Callable[[List[Dict[str, Any]], datetime], None]] = None
    #: Columns `prepare` may add that the writer did not send (insert-only values).
    stamps: FrozenSet[str] = frozenset()


# ── Policy 1: contributing_sources per-key merge (moved verbatim from the backend) ─────────

_PROV = "contributing_sources"


def _provenance_clause(ctx: ConflictContext) -> Optional[ConflictClause]:
    """Per-KEY merge, not `target || EXCLUDED`. A shallow `||` would replace a key present on both
    sides wholesale — resetting first_seen and pinning runs at 1. jsonb_object_agg over the union of
    keys keeps the stored first_seen and increments the stored runs (viz spec § 3.3.5). Pure SQL, so
    it is atomic under the row lock (§ 3.8.4 R9.2).

    Owns the column whenever it is in the batch — even the no-op case — which is what excluded it
    from the generic list before this registry existed.

    ⛔ AN UPSERT ADDS AT MOST ONE RUN, AND NONE WHEN `last_seen` DID NOT MOVE. The incoming `runs`
    is a DELTA only when the adapter stamped it (always 1). A writer that re-upserts a stored row
    (`SELECT *` then flip `is_deleted` — the reconciler's tombstone, node supersede, edge re-point;
    9 sites) carries the stored entry through, so its `runs` is the stored TOTAL. Adding it doubled
    the count on every sweep. MEASURED on Classie 2026-10-08: 22 `builds_image` contributors pinned
    at 2,147,483,647 and the `::int` overflow failed every reconcile. An entry whose `last_seen`
    equals the stored one is that same observation re-sent, so it adds 0. `bigint` is the
    backstop.
    """
    if _PROV not in ctx.batch_columns:
        return None
    return ConflictClause(
        owned={_PROV},
        assignments=[sql.SQL(
            "{col} = ("
            "  SELECT jsonb_object_agg(k, CASE"
            "    WHEN old.v IS NULL THEN new.v"
            "    WHEN new.v IS NULL THEN old.v"
            "    ELSE new.v"
            "         || jsonb_build_object('first_seen', old.v->>'first_seen')"
            "         || jsonb_build_object('runs',"
            "              COALESCE((old.v->>'runs')::bigint, 0)"
            "              + CASE WHEN new.v->>'last_seen' IS NOT DISTINCT FROM old.v->>'last_seen'"
            "                     THEN 0"
            "                     ELSE LEAST(GREATEST(COALESCE((new.v->>'runs')::bigint, 1), 0), 1)"
            "                END)"
            "  END)"
            "  FROM (SELECT jsonb_object_keys("
            "          COALESCE({tbl}.{col}, '{{}}'::jsonb)"
            "          || COALESCE(EXCLUDED.{col}, '{{}}'::jsonb)) AS k) keys"
            "  LEFT JOIN LATERAL (SELECT COALESCE({tbl}.{col}, '{{}}'::jsonb) -> keys.k AS v) old ON TRUE"
            "  LEFT JOIN LATERAL (SELECT COALESCE(EXCLUDED.{col}, '{{}}'::jsonb) -> keys.k AS v) new ON TRUE"
            ")"
        ).format(col=sql.Identifier(_PROV), tbl=ctx.table_ref)],
    )


# ── Policy 2: vulnerability lifecycle (rules in lifecycle.py) ───────────────────────────────

def _lifecycle_clause(ctx: ConflictContext) -> Optional[ConflictClause]:
    text = lifecycle.vulnerability_rule_text(
        ctx.table, ctx.table_columns, ctx.batch_columns, ctx.preserve, ctx.primary_key,
        stamped=ctx.stamped)
    if text is None:
        return None

    def compose(fragment: str) -> sql.Composable:
        return sql.SQL(fragment).format(T=ctx.table_ref)

    return ConflictClause(
        owned=set(text.owned),
        assignments=[compose(f'"{col}" = {expr}') for col, expr in text.assignments.items()],
        where=compose(text.where) if text.where else None,
    )


# ── Policy 3: first-detected never moves forward (A8) ──────────────────────────────────────

#: The column that records WHEN WE FIRST SAW the finding. One entry today; a dict so a second
#: "earliest wins" column is a one-line addition rather than a second policy.
#: ⚠️ `scanned_at` is deliberately NOT here — it means "when this scan ran", which SHOULD move
#: forward on every sync. ⚠️ `first_seen_at` is not here either: it is not a `vulnerabilities`
#: column at all (verified against the live schema 2026-10-06), only a record-level key
#: `cve_enrich` reads as an anchor fallback, so there is nothing to protect in the table.
_EARLIEST_WINS: Dict[str, Set[str]] = {"vulnerabilities": {"scan_first_detected_date"}}


def _earliest_wins_clause(ctx: ConflictContext) -> Optional[ConflictClause]:
    """`col = LEAST(stored, incoming)` — a first-detection date may only move EARLIER (A8).

    ⛔ WHY. The generic `col = EXCLUDED.col` lets a re-ingest overwrite first-detected with
    whatever the source reports now. Container Analysis re-creating an occurrence is enough:
    MEASURED on T2 2026-10-06, 6,055 of 12,844 open `gcp_container_analysis` rows carried
    `scan_first_detected_date = 2026-10-01` (a re-ingest date), and 12 rows had it LATER than
    their own `created_at` — the row claiming to have been first seen after it was created,
    which is only possible if the value was rewritten after insert. 51 open rows ended up with
    a due date EARLIER than their own first-detected, so every SLA computation anchored on
    first-detection under-counted breaches.

    ⭐ LEAST, not `preserve_columns`. Preserve keeps the stored value unconditionally, which is
    wrong when a genuinely earlier date arrives (a backfill, or a source that starts reporting
    an older occurrence). "Earliest wins" is the actual rule, and this registry is where the
    codebase already says a stored-value-dependent rule belongs.

    ⚠️ `LEAST` ignores NULLs in Postgres, so an incoming NULL cannot erase a stored date and a
    stored NULL is filled by the first real value — both correct here. On INSERT the column is
    unaffected: this clause only applies to `DO UPDATE`.
    """
    cols = _EARLIEST_WINS.get(ctx.table)
    if not cols:
        return None
    owned = {c for c in cols if c in ctx.batch_columns and c in ctx.table_columns}
    if not owned:
        return None
    return ConflictClause(
        owned=set(owned),
        assignments=[
            sql.SQL("{col} = LEAST({tbl}.{col}, EXCLUDED.{col})").format(
                col=sql.Identifier(c), tbl=ctx.table_ref)
            for c in sorted(owned)
        ],
    )


#: Order = order of the emitted assignments. Lifecycle first reproduces the statement the
#: backend emitted before this registry existed (verified by diffing the rendered SQL).
POLICIES: List[Policy] = [
    Policy(name="vulnerability_lifecycle", tables={lifecycle.LIFECYCLE_TABLE},
           build=_lifecycle_clause, prepare=lifecycle.prepare_vulnerability_records,
           stamps=lifecycle.STAMPED_COLUMNS),
    Policy(name="first_detected_earliest_wins", tables=set(_EARLIEST_WINS),
           build=_earliest_wins_clause),
    Policy(name="contributing_sources_merge", tables=None, build=_provenance_clause),
]


def _applies(policy: Policy, table: str) -> bool:
    return policy.tables is None or table in policy.tables


def prepare_records(table: str, records: List[Dict[str, Any]], now: datetime) -> None:
    """Run every applicable policy's insert-path hook, in place, before the column list is built."""
    for policy in POLICIES:
        if policy.prepare and _applies(policy, table):
            policy.prepare(records, now)


def prepare_record_groups(
    table: str, records: List[Dict[str, Any]], now: datetime,
) -> List[Tuple[List[Dict[str, Any]], Set[str]]]:
    """`prepare_records`, split so a stamped value can never pose as the writer's.

    Records are cut into CONTIGUOUS runs (order is kept, so a key written twice in one batch
    still ends on its last value) by which stampable columns the writer sent. Each run is
    stamped and returned with the columns it did NOT send: the backend builds one statement per
    run and passes those as `ConflictContext.stamped`. A table with no stamping policy, or a
    homogeneous batch, is one run — the statement is the same as before.
    """
    stampable: Set[str] = set()
    for policy in POLICIES:
        if policy.prepare and _applies(policy, table):
            stampable |= policy.stamps
    if not stampable:
        prepare_records(table, records, now)
        return [(records, set())]

    runs: List[Tuple[List[Dict[str, Any]], Set[str]]] = []
    last_sent: Optional[FrozenSet[str]] = None
    for rec in records:
        sent = frozenset(k for k in stampable if k in rec)
        if sent != last_sent:
            runs.append(([], stampable - sent))
            last_sent = sent
        runs[-1][0].append(rec)
    for run, _ in runs:
        prepare_records(table, run, now)
    return runs


def conflict_clauses(ctx: ConflictContext) -> List[ConflictClause]:
    """Every applicable policy's clause for this statement, in registry order."""
    out = []
    for policy in POLICIES:
        if not _applies(policy, ctx.table):
            continue
        clause = policy.build(ctx)
        if clause is not None:
            out.append(clause)
    return out


def combine_where(clauses: Iterable[ConflictClause]) -> Optional[sql.Composable]:
    """AND the policies' predicates, or None when no policy has one."""
    parts = [c.where for c in clauses if c.where is not None]
    if not parts:
        return None
    return sql.SQL(" AND ").join(sql.SQL("(") + p + sql.SQL(")") for p in parts)
