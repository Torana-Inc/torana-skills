"""Per-column conflict policies for the shared upsert — ONE hook, many rules.

WHY THIS EXISTS
---------------
`PostgreSQLBackend.upsert` writes every sink row as `INSERT … ON CONFLICT … DO UPDATE SET
col = EXCLUDED.col`. Some columns cannot be written that way, because their new value depends on
the STORED value as well as the incoming one:

  * `contributing_sources` — a per-key merge that keeps `first_seen` and increments `runs`
    (viz provenance § 3.3.5);
  * the vulnerability LIFECYCLE columns — computed from both rows so a reopen clears the closure,
    a closure is stamped once, and the state clock moves only on a real change
    (VULNERABILITY_LIFECYCLE_DESIGN.md § 3.4.1).

Both used to be special cases hard-coded into the backend. This module is the single registry:
each policy says which columns it OWNS (removed from the generic SET list), what to assign
instead, an optional `WHERE` for `DO UPDATE`, and an optional hook that prepares records before
the INSERT. The backend asks the registry and splices; it no longer knows any individual rule.

⛔ A policy's assignment MUST own its column. If the generic `col = EXCLUDED.col` were also
emitted, the last assignment would win in Postgres and silently undo the policy — that is the
invisible blocker the `contributing_sources` merge originally hit (spec R4).

ADDING A POLICY: write a builder `(ctx) -> Optional[ConflictClause]`, optionally a
`prepare(records, now)` hook, and append a `Policy` to `POLICIES`. Order in `POLICIES` is the
order of the emitted assignments.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Dict, FrozenSet, Iterable, List, Optional, Set, Tuple

from psycopg2 import sql

from pantheon_shared.datalake import lifecycle

__all__ = ["ConflictContext", "ConflictClause", "Policy", "POLICIES",
           "prepare_records", "prepare_record_groups", "conflict_clauses"]


@dataclass
class ConflictContext:
    """Everything a policy may look at when building its clause for one statement."""

    table: str
    table_columns: Set[str]
    batch_columns: Set[str]
    preserve: Set[str]
    primary_key: str
    table_ref: sql.Composable
    #: Columns present only because a `prepare` hook stamped them; not the writer's claim.
    stamped: Set[str] = field(default_factory=set)


@dataclass
class ConflictClause:
    #: Columns this policy assigns; removed from the generic `col = EXCLUDED.col` list.
    owned: Set[str] = field(default_factory=set)
    assignments: List[sql.Composable] = field(default_factory=list)
    #: Optional predicate ANDed into `DO UPDATE … WHERE`.
    where: Optional[sql.Composable] = None


@dataclass
class Policy:
    name: str
    #: Tables the policy applies to; None = any table (it checks its own columns).
    tables: Optional[Set[str]]
    build: Callable[[ConflictContext], Optional[ConflictClause]]
    prepare: Optional[Callable[[List[Dict[str, Any]], datetime], None]] = None
    #: Columns `prepare` may add that the writer did not send (insert-only values).
    stamps: FrozenSet[str] = frozenset()


# ── Policy 1: contributing_sources per-key merge (moved verbatim from the backend) ─────────

_PROV = "contributing_sources"


def _provenance_clause(ctx: ConflictContext) -> Optional[ConflictClause]:
    """Per-KEY merge, not `target || EXCLUDED`. A shallow `||` would replace a key present on both
    sides wholesale — resetting first_seen and pinning runs at 1. jsonb_object_agg over the union of
    keys keeps the stored first_seen and increments the stored runs (viz spec § 3.3.5). Pure SQL, so
    it is atomic under the row lock (§ 3.8.4 R9.2).

    Owns the column whenever it is in the batch — even the no-op case — which is what excluded it
    from the generic list before this registry existed.

    ⛔ AN UPSERT ADDS AT MOST ONE RUN, AND NONE WHEN `last_seen` DID NOT MOVE. The incoming `runs`
    is a DELTA only when the adapter stamped it (always 1). A writer that re-upserts a stored row
    (`SELECT *` then flip `is_deleted` — the reconciler's tombstone, node supersede, edge re-point;
    9 sites) carries the stored entry through, so its `runs` is the stored TOTAL. Adding it doubled
    the count on every sweep. MEASURED on Classie 2026-10-08: 22 `builds_image` contributors pinned
    at 2,147,483,647 and the `::int` overflow failed every reconcile. An entry whose `last_seen`
    equals the stored one is that same observation re-sent, so it adds 0. `bigint` is the
    backstop.
    """
    if _PROV not in ctx.batch_columns:
        return None
    return ConflictClause(
        owned={_PROV},
        assignments=[sql.SQL(
            "{col} = ("
            "  SELECT jsonb_object_agg(k, CASE"
            "    WHEN old.v IS NULL THEN new.v"
            "    WHEN new.v IS NULL THEN old.v"
            "    ELSE new.v"
            "         || jsonb_build_object('first_seen', old.v->>'first_seen')"
            "         || jsonb_build_object('runs',"
            "              COALESCE((old.v->>'runs')::bigint, 0)"
            "              + CASE WHEN new.v->>'last_seen' IS NOT DISTINCT FROM old.v->>'last_seen'"
            "                     THEN 0"
            "                     ELSE LEAST(GREATEST(COALESCE((new.v->>'runs')::bigint, 1), 0), 1)"
            "                END)"
            "  END)"
            "  FROM (SELECT jsonb_object_keys("
            "          COALESCE({tbl}.{col}, '{{}}'::jsonb)"
            "          || COALESCE(EXCLUDED.{col}, '{{}}'::jsonb)) AS k) keys"
            "  LEFT JOIN LATERAL (SELECT COALESCE({tbl}.{col}, '{{}}'::jsonb) -> keys.k AS v) old ON TRUE"
            "  LEFT JOIN LATERAL (SELECT COALESCE(EXCLUDED.{col}, '{{}}'::jsonb) -> keys.k AS v) new ON TRUE"
            ")"
        ).format(col=sql.Identifier(_PROV), tbl=ctx.table_ref)],
    )


# ── Policy 2: vulnerability lifecycle (rules in lifecycle.py) ───────────────────────────────

def _lifecycle_clause(ctx: ConflictContext) -> Optional[ConflictClause]:
    text = lifecycle.vulnerability_rule_text(
        ctx.table, ctx.table_columns, ctx.batch_columns, ctx.preserve, ctx.primary_key,
        stamped=ctx.stamped)
    if text is None:
        return None

    def compose(fragment: str) -> sql.Composable:
        return sql.SQL(fragment).format(T=ctx.table_ref)

    return ConflictClause(
        owned=set(text.owned),
        assignments=[compose(f'"{col}" = {expr}') for col, expr in text.assignments.items()],
        where=compose(text.where) if text.where else None,
    )


# ── Policy 3: first-detected never moves forward (A8) ──────────────────────────────────────

#: The column that records WHEN WE FIRST SAW the finding. One entry today; a dict so a second
#: "earliest wins" column is a one-line addition rather than a second policy.
#: ⚠️ `scanned_at` is deliberately NOT here — it means "when this scan ran", which SHOULD move
#: forward on every sync. ⚠️ `first_seen_at` is not here either: it is not a `vulnerabilities`
#: column at all (verified against the live schema 2026-10-06), only a record-level key
#: `cve_enrich` reads as an anchor fallback, so there is nothing to protect in the table.
_EARLIEST_WINS: Dict[str, Set[str]] = {"vulnerabilities": {"scan_first_detected_date"}}


def _earliest_wins_clause(ctx: ConflictContext) -> Optional[ConflictClause]:
    """`col = LEAST(stored, incoming)` — a first-detection date may only move EARLIER (A8).

    ⛔ WHY. The generic `col = EXCLUDED.col` lets a re-ingest overwrite first-detected with
    whatever the source reports now. Container Analysis re-creating an occurrence is enough:
    MEASURED on T2 2026-10-06, 6,055 of 12,844 open `gcp_container_analysis` rows carried
    `scan_first_detected_date = 2026-10-01` (a re-ingest date), and 12 rows had it LATER than
    their own `created_at` — the row claiming to have been first seen after it was created,
    which is only possible if the value was rewritten after insert. 51 open rows ended up with
    a due date EARLIER than their own first-detected, so every SLA computation anchored on
    first-detection under-counted breaches.

    ⭐ LEAST, not `preserve_columns`. Preserve keeps the stored value unconditionally, which is
    wrong when a genuinely earlier date arrives (a backfill, or a source that starts reporting
    an older occurrence). "Earliest wins" is the actual rule, and this registry is where the
    codebase already says a stored-value-dependent rule belongs.

    ⚠️ `LEAST` ignores NULLs in Postgres, so an incoming NULL cannot erase a stored date and a
    stored NULL is filled by the first real value — both correct here. On INSERT the column is
    unaffected: this clause only applies to `DO UPDATE`.
    """
    cols = _EARLIEST_WINS.get(ctx.table)
    if not cols:
        return None
    owned = {c for c in cols if c in ctx.batch_columns and c in ctx.table_columns}
    if not owned:
        return None
    return ConflictClause(
        owned=set(owned),
        assignments=[
            sql.SQL("{col} = LEAST({tbl}.{col}, EXCLUDED.{col})").format(
                col=sql.Identifier(c), tbl=ctx.table_ref)
            for c in sorted(owned)
        ],
    )


# ── Policy 4: a shared row keeps the label of the source that created it ────────────────────

#: A row's `source_system` that is NOT a real source: platform-asserted placeholders (the
#: reconciler mints identities, graph-health writes findings) which must yield the label the
#: moment a real source writes the same row.
_PLATFORM_PREFIX = "torana-"
_LABEL = "source_system"


def _owner_label_sql(ctx: ConflictContext) -> sql.Composable:
    """SQL for the label this write leaves on the row (the OWNER's label).

    1. A writer that CLAIMS the row — its incoming `contributing_sources` entry carries
       `owner: true`, which the adapter stamps from the mapping's `metadata.ownership: primary` —
       sets the label, whatever was stored. The source that defines an entity owns it.
    2. Otherwise the stored label stays, unless it is empty or a platform placeholder, in which
       case the incoming writer takes it.

    ⛔ No `%` in this fragment (see `_stable_label_clause`)."""
    lab, tbl = sql.Identifier(_LABEL), ctx.table_ref
    if _PROV in ctx.batch_columns:
        claim = sql.SQL(
            "EXISTS (SELECT 1 FROM jsonb_each(COALESCE(EXCLUDED.{prov}, '{{}}'::jsonb)) AS c(k, v) "
            "WHERE jsonb_typeof(c.v) = 'object' AND c.v->>'owner' = 'true')"
        ).format(prov=sql.Identifier(_PROV))
    else:
        claim = sql.SQL("FALSE")
    return sql.SQL(
        "(CASE WHEN {claim} THEN EXCLUDED.{lab} "
        "WHEN COALESCE({tbl}.{lab}, '') = '' OR LEFT({tbl}.{lab}, {n}) = {prefix} "
        "THEN EXCLUDED.{lab} ELSE {tbl}.{lab} END)"
    ).format(claim=claim, lab=lab, tbl=tbl, n=sql.Literal(len(_PLATFORM_PREFIX)),
             prefix=sql.Literal(_PLATFORM_PREFIX))


def _stable_label_clause(ctx: ConflictContext) -> Optional[ConflictClause]:
    """`source_system = <stored>` unless the stored label is empty or a platform placeholder.

    ⛔ WHY. A sink row can be written by several integrations (a Kubernetes workload is also a
    Cloud Asset Inventory resource; a registry image is also a running image) and the generic
    `col = EXCLUDED.col` made the label whichever sync ran LAST. MEASURED on T2 2026-10-16:
      * 62 workload assets read `gcp` / `Deployment` because the GCP sync followed the cluster
        sync, so the `join_overlap` health check (which filtered `source_system = 'kubernetes'`)
        returned 0 and a healthy tenant read `broken` — while a fresh tenant, synced in the other
        order, read `kubernetes` and passed;
      * the GCP sync relabelled running images `gcp`, so the registry sweep retired 58 images the
        cluster had seen running minutes earlier;
      * `datalake summary --source` for the same project differed between two tenants.
    The label flipped on every sync order, so no query that filtered on it was stable.

    THE RULE. The source that DEFINES the entity owns the label: a mapping that declares
    `metadata.ownership: primary` claims its rows (the adapter marks its `contributing_sources`
    entry `owner: true`), and a claim sets the label whatever was stored. Without a claim the
    first real writer's label sticks. WHO ELSE WROTE THE ROW is read from `contributing_sources`,
    which is a per-source merge and already complete. A placeholder (`torana-*`,
    platform-asserted) never holds a label against a real source.

    ⭐ A CLAIM IS WHAT MAKES THE OWNER DETERMINISTIC. "First writer wins" alone is stable but
    order-dependent: a fresh tenant whose cloud-inventory sync runs before the cluster sync keeps
    `gcp` for every workload, and a tenant whose cloud sync merely ran last when the policy
    shipped is pinned there. The claimant's next sync reclaims the row in every environment, so
    no data repair is needed.

    ⚠️ Applies only where the table carries `contributing_sources` (a shared sink); a table
    without it has one writer per row and the generic assignment is already stable. A caller that
    lists `source_system` in `preserve_columns` keeps its own behaviour.

    ⛔ NO `%` ANYWHERE IN THIS STATEMENT. It is executed with bound parameters, so a literal
    `LIKE 'torana-%'` is read as a placeholder and every upsert to the table fails with "tuple
    index out of range". The first version of this policy did exactly that (T4, 2026-10-16);
    `LEFT(col, n) = 'prefix'` says the same thing without the character.
    """
    if (_LABEL not in ctx.batch_columns or _LABEL not in ctx.table_columns
            or _PROV not in ctx.table_columns or _LABEL in ctx.preserve):
        return None
    return ConflictClause(
        owned={_LABEL},
        assignments=[sql.SQL("{col} = {owner}").format(
            col=sql.Identifier(_LABEL), owner=_owner_label_sql(ctx))],
    )


# ── Policy 5: the label's owner decides the row's TYPE ──────────────────────────────────────

#: Per table: columns whose value is a vocabulary the PRODUCERS disagree on for one entity
#: (a workload is `kubernetes_workload` to the cluster sync and `Deployment` to the cloud-asset
#: sync). One entry today; a dict so a second such column is one line, not a second policy.
_OWNER_TYPED: Dict[str, Tuple[str, ...]] = {"assets": ("asset_type",)}


def _owner_typed_clause(ctx: ConflictContext) -> Optional[ConflictClause]:
    """`asset_type` is written only by the source that OWNS the row's label.

    ⛔ WHY. Policy 4 stopped `source_system` flipping with sync order, but the type still did:
    after a GCP sync a cluster-owned workload read `kubernetes` / `Deployment`, after a cluster
    sync `kubernetes` / `kubernetes_workload`. A label and a type from different producers is
    worse than either alone — nothing could tell which vocabulary a row used.

    THE RULE. The owner is whoever the label policy keeps: a claimant if the writer claims, else
    the stored label, unless that is empty or a platform placeholder (then the incoming writer).
    If the incoming writer IS the owner its type is taken; otherwise the stored type stays. A stored NULL type is filled by
    whoever writes first. Every other column is untouched — this is about the type vocabulary
    only, not a claim that non-owners' data is wrong.

    Needs the label policy's preconditions (the table carries `source_system` and
    `contributing_sources`, both in the batch) so owner and type can never disagree about who
    the owner is. ⛔ No `%` in the SQL (see Policy 4).
    """
    cols = _OWNER_TYPED.get(ctx.table)
    if not cols or _stable_label_clause(ctx) is None:
        return None
    owned = {c for c in cols if c in ctx.batch_columns and c in ctx.table_columns
             and c not in ctx.preserve}
    if not owned:
        return None
    lab, tbl = sql.Identifier(_LABEL), ctx.table_ref
    owner = _owner_label_sql(ctx)
    return ConflictClause(
        owned=set(owned),
        assignments=[
            sql.SQL(
                "{col} = CASE WHEN {tbl}.{col} IS NULL OR EXCLUDED.{lab} IS NOT DISTINCT FROM {owner} "
                "THEN EXCLUDED.{col} ELSE {tbl}.{col} END"
            ).format(col=sql.Identifier(c), tbl=tbl, lab=lab, owner=owner)
            for c in sorted(owned)
        ],
    )


# ── Policy 6: governance columns — an empty value is "not observed" ─────────────────────────

_GOV_SOURCE = "governance_source"
#: The business-context columns a source states about an asset. `governance_source` names the
#: layer that supplied them.
GOVERNANCE_COLUMNS: Tuple[str, ...] = (
    "asset_environment", "asset_owner", "asset_team",
    "criticality_name", "criticality_level", "has_customer_data",
)
#: `governance_source` value → the SOURCE FAMILY that wrote it. A family may clear what it
#: set; one source's layers are one family (AWS reports "aws_tags" or "aws_integration"
#: depending on which layer supplied the value, and "aws_unset" when it found none). A value
#: not listed here is its own family.
GOVERNANCE_FAMILIES: Dict[str, str] = {
    "aws_tags": "aws",
    "aws_integration": "aws",
    "aws_unset": "aws",
    "deployment": "deployment",
    "manifest": "manifest",
}


def _family_sql(expr: sql.Composable) -> sql.Composable:
    """`CASE <expr> WHEN 'aws_tags' THEN 'aws' … ELSE <expr> END` — the family of a source."""
    whens = sql.SQL(" ").join(
        sql.SQL("WHEN {} THEN {}").format(sql.Literal(k), sql.Literal(v))
        for k, v in sorted(GOVERNANCE_FAMILIES.items()))
    return sql.SQL("(CASE {e} {whens} ELSE {e} END)").format(e=expr, whens=whens)


def _governance_clause(ctx: ConflictContext) -> Optional[ConflictClause]:
    """A source's empty governance value never erases another source's; a source may clear its own.

    ⛔ WHY. The generic `col = EXCLUDED.col` writes NULL whenever a writer has no value — and the
    backend builds every row from the UNION of the batch's keys, so a record that merely LACKS
    the key in a mixed batch is written as NULL too. Any mapping that resolves environment,
    owner, team, criticality or customer data and finds nothing would erase what a Deployment,
    a manifest push or another source declared.

    THE RULE (per column, judged against the STORED row — Postgres evaluates every SET
    expression on the old row, so all six agree on who stored them):
      * the incoming row's family equals the stored row's family → the incoming value wins,
        NULL included: a source may clear a value it set (an AWS tag removed);
      * otherwise → `COALESCE(incoming, stored)`: an empty value means "not observed".
    A row with no incoming `governance_source` (the mixed-batch case, or a writer that
    resolves none of these) has no family, so it can never clear.

    ⛔ WHO OWNS THE ROW MOVES ONLY WITH A VALUE. `governance_source` takes the incoming one
    when the family is the same, or when the write carries at least one non-NULL owned
    column (`has_customer_data = false` is a value). A write that observed NOTHING never
    takes the row over: otherwise an AWS `aws_unset` over a Deployment row would keep the
    values but flip the family, and the NEXT AWS sync — now "the same family" — would erase
    them. For the same reason a stored NULL source (a decoration's value, or a legacy row)
    is never claimed by an all-NULL write.

    ⚠️ Owns a column only when the batch carries it. A column absent from the whole batch gets
    no assignment and keeps its stored value — identical to the generic path, which is what
    keeps a Deployment with no owner from clearing anything.

    Deliberately NOT handled (both recorded for later):
      * cross-family precedence: a non-empty value from another family still replaces the
        stored one (last writer), as before this policy. No asset row is written by two
        governance families today.
      * per-column provenance: the family is per ROW. Two families writing different columns
        of one row would let the last one clear all six; exact ownership needs a per-column
        map, deferred until such a row exists.
    """
    if ctx.table != "assets" or _GOV_SOURCE not in ctx.table_columns:
        return None
    owned = {c for c in GOVERNANCE_COLUMNS
             if c in ctx.batch_columns and c in ctx.table_columns and c not in ctx.preserve}
    gov_sent = _GOV_SOURCE in ctx.batch_columns and _GOV_SOURCE not in ctx.preserve
    if not owned and not gov_sent:
        return None
    tbl, gs = ctx.table_ref, sql.Identifier(_GOV_SOURCE)
    if gov_sent:
        incoming = _family_sql(sql.SQL("EXCLUDED.{}").format(gs))
        same = sql.SQL("{inc} IS NOT NULL AND {inc} = {sto}").format(
            inc=incoming, sto=_family_sql(sql.SQL("{}.{}").format(tbl, gs)))
    else:
        same = sql.SQL("FALSE")
    assignments = [
        sql.SQL("{c} = CASE WHEN {same} THEN EXCLUDED.{c} "
                "ELSE COALESCE(EXCLUDED.{c}, {tbl}.{c}) END").format(
            c=sql.Identifier(c), same=same, tbl=tbl)
        for c in sorted(owned)
    ]
    if gov_sent:
        observed = (sql.SQL(" OR ").join(
            sql.SQL("EXCLUDED.{} IS NOT NULL").format(sql.Identifier(c)) for c in sorted(owned))
            if owned else sql.SQL("FALSE"))
        owned.add(_GOV_SOURCE)
        assignments.append(sql.SQL(
            "{c} = CASE WHEN EXCLUDED.{c} IS NOT NULL AND (({same}) OR ({observed})) "
            "THEN EXCLUDED.{c} ELSE {tbl}.{c} END").format(
            c=gs, same=same, observed=observed, tbl=tbl))
    return ConflictClause(owned=owned, assignments=assignments)


#: Order = order of the emitted assignments. Lifecycle first reproduces the statement the
#: backend emitted before this registry existed (verified by diffing the rendered SQL).
POLICIES: List[Policy] = [
    Policy(name="vulnerability_lifecycle", tables={lifecycle.LIFECYCLE_TABLE},
           build=_lifecycle_clause, prepare=lifecycle.prepare_vulnerability_records,
           stamps=lifecycle.STAMPED_COLUMNS),
    Policy(name="first_detected_earliest_wins", tables=set(_EARLIEST_WINS),
           build=_earliest_wins_clause),
    Policy(name="contributing_sources_merge", tables=None, build=_provenance_clause),
    Policy(name="stable_source_label", tables=None, build=_stable_label_clause),
    Policy(name="owner_decides_type", tables=set(_OWNER_TYPED), build=_owner_typed_clause),
    Policy(name="governance_not_observed", tables={"assets"}, build=_governance_clause),
]


def _applies(policy: Policy, table: str) -> bool:
    return policy.tables is None or table in policy.tables


def prepare_records(table: str, records: List[Dict[str, Any]], now: datetime) -> None:
    """Run every applicable policy's insert-path hook, in place, before the column list is built."""
    for policy in POLICIES:
        if policy.prepare and _applies(policy, table):
            policy.prepare(records, now)


def prepare_record_groups(
    table: str, records: List[Dict[str, Any]], now: datetime,
) -> List[Tuple[List[Dict[str, Any]], Set[str]]]:
    """`prepare_records`, split so a stamped value can never pose as the writer's.

    Records are cut into CONTIGUOUS runs (order is kept, so a key written twice in one batch
    still ends on its last value) by which stampable columns the writer sent. Each run is
    stamped and returned with the columns it did NOT send: the backend builds one statement per
    run and passes those as `ConflictContext.stamped`. A table with no stamping policy, or a
    homogeneous batch, is one run — the statement is the same as before.
    """
    stampable: Set[str] = set()
    for policy in POLICIES:
        if policy.prepare and _applies(policy, table):
            stampable |= policy.stamps
    if not stampable:
        prepare_records(table, records, now)
        return [(records, set())]

    runs: List[Tuple[List[Dict[str, Any]], Set[str]]] = []
    last_sent: Optional[FrozenSet[str]] = None
    for rec in records:
        sent = frozenset(k for k in stampable if k in rec)
        if sent != last_sent:
            runs.append(([], stampable - sent))
            last_sent = sent
        runs[-1][0].append(rec)
    for run, _ in runs:
        prepare_records(table, run, now)
    return runs


def conflict_clauses(ctx: ConflictContext) -> List[ConflictClause]:
    """Every applicable policy's clause for this statement, in registry order."""
    out = []
    for policy in POLICIES:
        if not _applies(policy, ctx.table):
            continue
        clause = policy.build(ctx)
        if clause is not None:
            out.append(clause)
    return out


def combine_where(clauses: Iterable[ConflictClause]) -> Optional[sql.Composable]:
    """AND the policies' predicates, or None when no policy has one."""
    parts = [c.where for c in clauses if c.where is not None]
    if not parts:
        return None
    return sql.SQL(" AND ").join(sql.SQL("(") + p + sql.SQL(")") for p in parts)
