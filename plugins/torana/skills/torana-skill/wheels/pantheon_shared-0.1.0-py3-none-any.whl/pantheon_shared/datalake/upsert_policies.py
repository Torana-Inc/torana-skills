"""Per-column conflict policies for the shared upsert — ONE hook, many rules.

WHY THIS EXISTS
---------------
`PostgreSQLBackend.upsert` writes every sink row as `INSERT … ON CONFLICT … DO UPDATE SET
col = EXCLUDED.col`. Some columns cannot be written that way, because their new value depends on
the STORED value as well as the incoming one:

  * `contributing_sources` — a per-key merge that keeps `first_seen` and increments `runs`
    (viz provenance § 3.3.5);
  * the vulnerability LIFECYCLE columns — computed from both rows so a reopen clears the closure,
    a closure is stamped once, and the state clock moves only on a real change
    (VULNERABILITY_LIFECYCLE_DESIGN.md § 3.4.1).

Both used to be special cases hard-coded into the backend. This module is the single registry:
each policy says which columns it OWNS (removed from the generic SET list), what to assign
instead, an optional `WHERE` for `DO UPDATE`, and an optional hook that prepares records before
the INSERT. The backend asks the registry and splices; it no longer knows any individual rule.

⛔ A policy's assignment MUST own its column. If the generic `col = EXCLUDED.col` were also
emitted, the last assignment would win in Postgres and silently undo the policy — that is the
invisible blocker the `contributing_sources` merge originally hit (spec R4).

ADDING A POLICY: write a builder `(ctx) -> Optional[ConflictClause]`, optionally a
`prepare(records, now)` hook, and append a `Policy` to `POLICIES`. Order in `POLICIES` is the
order of the emitted assignments.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Callable, Dict, FrozenSet, Iterable, List, Optional, Set, Tuple

from psycopg2 import sql

from pantheon_shared.datalake import lifecycle
from pantheon_shared.identity.scope_key import ENTRY_INTEGRATION_SEP, entry_base_sql

__all__ = ["ConflictContext", "ConflictClause", "Policy", "POLICIES",
           "prepare_records", "prepare_record_groups", "conflict_clauses"]


@dataclass
class ConflictContext:
    """Everything a policy may look at when building its clause for one statement."""

    table: str
    table_columns: Set[str]
    batch_columns: Set[str]
    preserve: Set[str]
    primary_key: str
    table_ref: sql.Composable
    #: Columns present only because a `prepare` hook stamped them; not the writer's claim.
    stamped: Set[str] = field(default_factory=set)


@dataclass
class ConflictClause:
    #: Columns this policy assigns; removed from the generic `col = EXCLUDED.col` list.
    owned: Set[str] = field(default_factory=set)
    assignments: List[sql.Composable] = field(default_factory=list)
    #: Optional predicate ANDed into `DO UPDATE … WHERE`.
    where: Optional[sql.Composable] = None


@dataclass
class Policy:
    name: str
    #: Tables the policy applies to; None = any table (it checks its own columns).
    tables: Optional[Set[str]]
    build: Callable[[ConflictContext], Optional[ConflictClause]]
    prepare: Optional[Callable[[List[Dict[str, Any]], datetime], None]] = None
    #: Columns `prepare` may add that the writer did not send (insert-only values).
    stamps: FrozenSet[str] = frozenset()


# ── Policy 1: contributing_sources per-key merge (moved verbatim from the backend) ─────────

_PROV = "contributing_sources"


def _provenance_clause(ctx: ConflictContext) -> Optional[ConflictClause]:
    """Per-KEY merge, not `target || EXCLUDED`. A shallow `||` would replace a key present on both
    sides wholesale — resetting first_seen and pinning runs at 1. jsonb_object_agg over the union of
    keys keeps the stored first_seen and increments the stored runs (viz spec § 3.3.5). Pure SQL, so
    it is atomic under the row lock (§ 3.8.4 R9.2).

    Owns the column whenever it is in the batch — even the no-op case — which is what excluded it
    from the generic list before this registry existed.

    ⛔ AN UPSERT ADDS AT MOST ONE RUN, AND NONE WHEN `last_seen` DID NOT MOVE. The incoming `runs`
    is a DELTA only when the adapter stamped it (always 1). A writer that re-upserts a stored row
    (`SELECT *` then flip `is_deleted` — the reconciler's tombstone, node supersede, edge re-point;
    9 sites) carries the stored entry through, so its `runs` is the stored TOTAL. Adding it doubled
    the count on every sweep. MEASURED on Classie 2026-10-08: 22 `builds_image` contributors pinned
    at 2,147,483,647 and the `::int` overflow failed every reconcile. An entry whose `last_seen`
    equals the stored one is that same observation re-sent, so it adds 0. `bigint` is the
    backstop.
    """
    if _PROV not in ctx.batch_columns:
        return None
    return ConflictClause(
        owned={_PROV},
        assignments=[sql.SQL(
            "{col} = ("
            "  SELECT jsonb_object_agg(k, CASE"
            "    WHEN old.v IS NULL THEN new.v"
            "    WHEN new.v IS NULL THEN old.v"
            "    ELSE new.v"
            "         || jsonb_build_object('first_seen', old.v->>'first_seen')"
            "         || jsonb_build_object('runs',"
            "              COALESCE((old.v->>'runs')::bigint, 0)"
            "              + CASE WHEN new.v->>'last_seen' IS NOT DISTINCT FROM old.v->>'last_seen'"
            "                     THEN 0"
            "                     ELSE LEAST(GREATEST(COALESCE((new.v->>'runs')::bigint, 1), 0), 1)"
            "                END)"
            "  END)"
            "  FROM (SELECT jsonb_object_keys("
            "          COALESCE({tbl}.{col}, '{{}}'::jsonb)"
            "          || COALESCE(EXCLUDED.{col}, '{{}}'::jsonb)) AS k) keys"
            "  LEFT JOIN LATERAL (SELECT COALESCE({tbl}.{col}, '{{}}'::jsonb) -> keys.k AS v) old ON TRUE"
            "  LEFT JOIN LATERAL (SELECT COALESCE(EXCLUDED.{col}, '{{}}'::jsonb) -> keys.k AS v) new ON TRUE"
            ")"
        ).format(col=sql.Identifier(_PROV), tbl=ctx.table_ref)],
    )


# ── Policy 2: vulnerability lifecycle (rules in lifecycle.py) ───────────────────────────────

def _lifecycle_clause(ctx: ConflictContext) -> Optional[ConflictClause]:
    text = lifecycle.vulnerability_rule_text(
        ctx.table, ctx.table_columns, ctx.batch_columns, ctx.preserve, ctx.primary_key,
        stamped=ctx.stamped)
    if text is None:
        return None

    def compose(fragment: str) -> sql.Composable:
        return sql.SQL(fragment).format(T=ctx.table_ref)

    return ConflictClause(
        owned=set(text.owned),
        assignments=[compose(f'"{col}" = {expr}') for col, expr in text.assignments.items()],
        where=compose(text.where) if text.where else None,
    )


# ── Policy 3: first-detected never moves forward (A8) ──────────────────────────────────────

#: The column that records WHEN WE FIRST SAW the finding. One entry today; a dict so a second
#: "earliest wins" column is a one-line addition rather than a second policy.
#: ⚠️ `scanned_at` is deliberately NOT here — it means "when this scan ran", which SHOULD move
#: forward on every sync. ⚠️ `first_seen_at` is not here either: it is not a `vulnerabilities`
#: column at all (verified against the live schema 2026-10-06), only a record-level key
#: `cve_enrich` reads as an anchor fallback, so there is nothing to protect in the table.
_EARLIEST_WINS: Dict[str, Set[str]] = {"vulnerabilities": {"scan_first_detected_date"}}


def _earliest_wins_clause(ctx: ConflictContext) -> Optional[ConflictClause]:
    """`col = LEAST(stored, incoming)` — a first-detection date may only move EARLIER (A8).

    ⛔ WHY. The generic `col = EXCLUDED.col` lets a re-ingest overwrite first-detected with
    whatever the source reports now. Container Analysis re-creating an occurrence is enough:
    MEASURED on T2 2026-10-06, 6,055 of 12,844 open `gcp_container_analysis` rows carried
    `scan_first_detected_date = 2026-10-01` (a re-ingest date), and 12 rows had it LATER than
    their own `created_at` — the row claiming to have been first seen after it was created,
    which is only possible if the value was rewritten after insert. 51 open rows ended up with
    a due date EARLIER than their own first-detected, so every SLA computation anchored on
    first-detection under-counted breaches.

    ⭐ LEAST, not `preserve_columns`. Preserve keeps the stored value unconditionally, which is
    wrong when a genuinely earlier date arrives (a backfill, or a source that starts reporting
    an older occurrence). "Earliest wins" is the actual rule, and this registry is where the
    codebase already says a stored-value-dependent rule belongs.

    ⚠️ `LEAST` ignores NULLs in Postgres, so an incoming NULL cannot erase a stored date and a
    stored NULL is filled by the first real value — both correct here. On INSERT the column is
    unaffected: this clause only applies to `DO UPDATE`.
    """
    cols = _EARLIEST_WINS.get(ctx.table)
    if not cols:
        return None
    owned = {c for c in cols if c in ctx.batch_columns and c in ctx.table_columns}
    if not owned:
        return None
    return ConflictClause(
        owned=set(owned),
        assignments=[
            sql.SQL("{col} = LEAST({tbl}.{col}, EXCLUDED.{col})").format(
                col=sql.Identifier(c), tbl=ctx.table_ref)
            for c in sorted(owned)
        ],
    )


# ── Policy 4: a shared row keeps the label of the source that created it ────────────────────

#: A row's `source_system` that is NOT a real source: platform-asserted placeholders (the
#: reconciler mints identities, graph-health writes findings) which must yield the label the
#: moment a real source writes the same row.
_PLATFORM_PREFIX = "torana-"
_LABEL = "source_system"


def _owner_label_sql(ctx: ConflictContext) -> sql.Composable:
    """SQL for the label this write leaves on the row (the OWNER's label).

    1. A writer that CLAIMS the row — its incoming `contributing_sources` entry carries
       `owner: true`, which the adapter stamps from the mapping's `metadata.ownership: primary` —
       sets the label, whatever was stored. The source that defines an entity owns it.
    2. Otherwise the stored label stays, unless it is empty or a platform placeholder, in which
       case the incoming writer takes it.

    ⛔ No `%` in this fragment (see `_stable_label_clause`)."""
    lab, tbl = sql.Identifier(_LABEL), ctx.table_ref
    if _PROV in ctx.batch_columns:
        claim = sql.SQL(
            "EXISTS (SELECT 1 FROM jsonb_each(COALESCE(EXCLUDED.{prov}, '{{}}'::jsonb)) AS c(k, v) "
            "WHERE jsonb_typeof(c.v) = 'object' AND c.v->>'owner' = 'true')"
        ).format(prov=sql.Identifier(_PROV))
    else:
        claim = sql.SQL("FALSE")
    return sql.SQL(
        "(CASE WHEN {claim} THEN EXCLUDED.{lab} "
        "WHEN COALESCE({tbl}.{lab}, '') = '' OR LEFT({tbl}.{lab}, {n}) = {prefix} "
        "THEN EXCLUDED.{lab} ELSE {tbl}.{lab} END)"
    ).format(claim=claim, lab=lab, tbl=tbl, n=sql.Literal(len(_PLATFORM_PREFIX)),
             prefix=sql.Literal(_PLATFORM_PREFIX))


def _stable_label_clause(ctx: ConflictContext) -> Optional[ConflictClause]:
    """`source_system = <stored>` unless the stored label is empty or a platform placeholder.

    ⛔ WHY. A sink row can be written by several integrations (a Kubernetes workload is also a
    Cloud Asset Inventory resource; a registry image is also a running image) and the generic
    `col = EXCLUDED.col` made the label whichever sync ran LAST. MEASURED on T2 2026-10-16:
      * 62 workload assets read `gcp` / `Deployment` because the GCP sync followed the cluster
        sync, so the `join_overlap` health check (which filtered `source_system = 'kubernetes'`)
        returned 0 and a healthy tenant read `broken` — while a fresh tenant, synced in the other
        order, read `kubernetes` and passed;
      * the GCP sync relabelled running images `gcp`, so the registry sweep retired 58 images the
        cluster had seen running minutes earlier;
      * `datalake summary --source` for the same project differed between two tenants.
    The label flipped on every sync order, so no query that filtered on it was stable.

    THE RULE. The source that DEFINES the entity owns the label: a mapping that declares
    `metadata.ownership: primary` claims its rows (the adapter marks its `contributing_sources`
    entry `owner: true`), and a claim sets the label whatever was stored. Without a claim the
    first real writer's label sticks. WHO ELSE WROTE THE ROW is read from `contributing_sources`,
    which is a per-source merge and already complete. A placeholder (`torana-*`,
    platform-asserted) never holds a label against a real source.

    ⭐ A CLAIM IS WHAT MAKES THE OWNER DETERMINISTIC. "First writer wins" alone is stable but
    order-dependent: a fresh tenant whose cloud-inventory sync runs before the cluster sync keeps
    `gcp` for every workload, and a tenant whose cloud sync merely ran last when the policy
    shipped is pinned there. The claimant's next sync reclaims the row in every environment, so
    no data repair is needed.

    ⚠️ Applies only where the table carries `contributing_sources` (a shared sink); a table
    without it has one writer per row and the generic assignment is already stable. A caller that
    lists `source_system` in `preserve_columns` keeps its own behaviour.

    ⛔ NO `%` ANYWHERE IN THIS STATEMENT. It is executed with bound parameters, so a literal
    `LIKE 'torana-%'` is read as a placeholder and every upsert to the table fails with "tuple
    index out of range". The first version of this policy did exactly that (T4, 2026-10-16);
    `LEFT(col, n) = 'prefix'` says the same thing without the character.
    """
    if (_LABEL not in ctx.batch_columns or _LABEL not in ctx.table_columns
            or _PROV not in ctx.table_columns or _LABEL in ctx.preserve):
        return None
    return ConflictClause(
        owned={_LABEL},
        assignments=[sql.SQL("{col} = {owner}").format(
            col=sql.Identifier(_LABEL), owner=_owner_label_sql(ctx))],
    )


# ── Policy 5: the label's owner decides the row's TYPE ──────────────────────────────────────

#: Per table: columns whose value is a vocabulary the PRODUCERS disagree on for one entity
#: (a workload is `kubernetes_workload` to the cluster sync and `Deployment` to the cloud-asset
#: sync). One entry today; a dict so a second such column is one line, not a second policy.
_OWNER_TYPED: Dict[str, Tuple[str, ...]] = {"assets": ("asset_type",)}


def _owner_typed_clause(ctx: ConflictContext) -> Optional[ConflictClause]:
    """`asset_type` is written only by the source that OWNS the row's label.

    ⛔ WHY. Policy 4 stopped `source_system` flipping with sync order, but the type still did:
    after a GCP sync a cluster-owned workload read `kubernetes` / `Deployment`, after a cluster
    sync `kubernetes` / `kubernetes_workload`. A label and a type from different producers is
    worse than either alone — nothing could tell which vocabulary a row used.

    THE RULE. The owner is whoever the label policy keeps: a claimant if the writer claims, else
    the stored label, unless that is empty or a platform placeholder (then the incoming writer).
    If the incoming writer IS the owner its type is taken; otherwise the stored type stays. A stored NULL type is filled by
    whoever writes first. Every other column is untouched — this is about the type vocabulary
    only, not a claim that non-owners' data is wrong.

    Needs the label policy's preconditions (the table carries `source_system` and
    `contributing_sources`, both in the batch) so owner and type can never disagree about who
    the owner is. ⛔ No `%` in the SQL (see Policy 4).
    """
    cols = _OWNER_TYPED.get(ctx.table)
    if not cols or _stable_label_clause(ctx) is None:
        return None
    owned = {c for c in cols if c in ctx.batch_columns and c in ctx.table_columns
             and c not in ctx.preserve}
    if not owned:
        return None
    lab, tbl = sql.Identifier(_LABEL), ctx.table_ref
    owner = _owner_label_sql(ctx)
    return ConflictClause(
        owned=set(owned),
        assignments=[
            sql.SQL(
                "{col} = CASE WHEN {tbl}.{col} IS NULL OR EXCLUDED.{lab} IS NOT DISTINCT FROM {owner} "
                "THEN EXCLUDED.{col} ELSE {tbl}.{col} END"
            ).format(col=sql.Identifier(c), tbl=tbl, lab=lab, owner=owner)
            for c in sorted(owned)
        ],
    )


# ── Policy 6: governance columns — an empty value is "not observed" ─────────────────────────

_GOV_SOURCE = "governance_source"
#: The business-context columns a source states about an asset. `governance_source` names the
#: layer that supplied them.
GOVERNANCE_COLUMNS: Tuple[str, ...] = (
    "asset_environment", "asset_owner", "asset_team",
    "criticality_name", "criticality_level", "has_customer_data",
)
#: `governance_source` value → the SOURCE FAMILY that wrote it. A family may clear what it
#: set; one source's layers are one family (AWS reports "aws_tags" or "aws_integration"
#: depending on which layer supplied the value, and "aws_unset" when it found none). A value
#: not listed here is its own family.
GOVERNANCE_FAMILIES: Dict[str, str] = {
    "aws_tags": "aws",
    "aws_unset": "aws",
    "manifest": "manifest",
    "k8s_labels": "k8s",
    "k8s_unset": "k8s",
    "gcp_labels": "gcp",
    "gcp_unset": "gcp",
    "manifest_labels": "manifest",
}
#: (stored family, incoming family) pairs where the stored value always stands: a live
#: cluster's own labels are never replaced by a pushed manifest's (DS2 § 3.3.6). The live
#: sync still decides in the other direction, its NULL included.
GOVERNANCE_STANDS: Tuple[Tuple[str, str], ...] = (("k8s", "manifest"),)
#: PI-13: (stored family, incoming family) pairs where the incoming write decides as if it were
#: the same family, its NULL included: a live cluster's labels replace what a pushed manifest
#: stated for the same workload, and a label removed in the cluster clears the manifest's value.
GOVERNANCE_DECIDES: Tuple[Tuple[str, str], ...] = (("manifest", "k8s"),)


def _family_sql(expr: sql.Composable) -> sql.Composable:
    """`CASE <expr> WHEN 'aws_tags' THEN 'aws' … ELSE <expr> END` — the family of a source."""
    whens = sql.SQL(" ").join(
        sql.SQL("WHEN {} THEN {}").format(sql.Literal(k), sql.Literal(v))
        for k, v in sorted(GOVERNANCE_FAMILIES.items()))
    return sql.SQL("(CASE {e} {whens} ELSE {e} END)").format(e=expr, whens=whens)


def _governance_clause(ctx: ConflictContext) -> Optional[ConflictClause]:
    """A source's empty governance value never erases another source's; a source may clear its own.

    ⛔ WHY. The generic `col = EXCLUDED.col` writes NULL whenever a writer has no value — and the
    backend builds every row from the UNION of the batch's keys, so a record that merely LACKS
    the key in a mixed batch is written as NULL too. Any mapping that resolves environment,
    owner, team, criticality or customer data and finds nothing would erase what a Deployment,
    a manifest push or another source declared.

    THE RULE (per column, judged against the STORED row — Postgres evaluates every SET
    expression on the old row, so all six agree on who stored them):
      * the incoming row's family equals the stored row's family → the incoming value wins,
        NULL included: a source may clear a value it set (an AWS tag removed);
      * otherwise → `COALESCE(incoming, stored)`: an empty value means "not observed".
    A row with no incoming `governance_source` (the mixed-batch case, or a writer that
    resolves none of these) has no family, so it can never clear.

    ⛔ WHO OWNS THE ROW MOVES ONLY WITH A VALUE. `governance_source` takes the incoming one
    when the family is the same, or when the write carries at least one non-NULL owned
    column (`has_customer_data = false` is a value). A write that observed NOTHING never
    takes the row over: otherwise an AWS `aws_unset` over a Deployment row would keep the
    values but flip the family, and the NEXT AWS sync — now "the same family" — would erase
    them. For the same reason a stored NULL source (a decoration's value, or a legacy row)
    is never claimed by an all-NULL write.

    ⚠️ Owns a column only when the batch carries it. A column absent from the whole batch gets
    no assignment and keeps its stored value — identical to the generic path, which is what
    keeps a Deployment with no owner from clearing anything.

    Deliberately NOT handled (both recorded for later):
      * cross-family precedence: a non-empty value from another family still replaces the
        stored one (last writer), with two exceptions for the one row a live cluster and a pushed
        manifest share: `GOVERNANCE_STANDS` — the cluster's own labels (`k8s`) are never
        replaced by the manifest's (`manifest`); `GOVERNANCE_DECIDES` — a `k8s` write over a
        `manifest` row decides like the same family, so its NULL clears the manifest's value.
      * per-column provenance: the family is per ROW. Two families writing different columns
        of one row would let the last one clear all six; exact ownership needs a per-column
        map, deferred until such a row exists.
    """
    if ctx.table != "assets" or _GOV_SOURCE not in ctx.table_columns:
        return None
    owned = {c for c in GOVERNANCE_COLUMNS
             if c in ctx.batch_columns and c in ctx.table_columns and c not in ctx.preserve}
    gov_sent = _GOV_SOURCE in ctx.batch_columns and _GOV_SOURCE not in ctx.preserve
    if not owned and not gov_sent:
        return None
    tbl, gs = ctx.table_ref, sql.Identifier(_GOV_SOURCE)
    if gov_sent:
        incoming = _family_sql(sql.SQL("EXCLUDED.{}").format(gs))
        stored = _family_sql(sql.SQL("{}.{}").format(tbl, gs))
        def pairs(table):
            if not table:
                return sql.SQL("FALSE")
            return sql.SQL(" OR ").join(
                sql.SQL("({sto} = {s} AND {inc} = {i})").format(
                    sto=stored, inc=incoming, s=sql.Literal(s_fam), i=sql.Literal(i_fam))
                for s_fam, i_fam in table)
        # same family, or a pair in GOVERNANCE_DECIDES: the incoming write decides, NULL included
        same = sql.SQL("({inc} IS NOT NULL AND {inc} = {sto}) OR {decides}").format(
            inc=incoming, sto=stored, decides=pairs(GOVERNANCE_DECIDES))
        stands = pairs(GOVERNANCE_STANDS)
    else:
        same = sql.SQL("FALSE")
        stands = sql.SQL("FALSE")
    assignments = [
        sql.SQL("{c} = CASE WHEN {stands} THEN {tbl}.{c} WHEN {same} THEN EXCLUDED.{c} "
                "ELSE COALESCE(EXCLUDED.{c}, {tbl}.{c}) END").format(
            c=sql.Identifier(c), stands=stands, same=same, tbl=tbl)
        for c in sorted(owned)
    ]
    if gov_sent:
        observed = (sql.SQL(" OR ").join(
            sql.SQL("EXCLUDED.{} IS NOT NULL").format(sql.Identifier(c)) for c in sorted(owned))
            if owned else sql.SQL("FALSE"))
        owned.add(_GOV_SOURCE)
        assignments.append(sql.SQL(
            "{c} = CASE WHEN {stands} THEN {tbl}.{c} "
            "WHEN EXCLUDED.{c} IS NOT NULL AND (({same}) OR ({observed})) "
            "THEN EXCLUDED.{c} ELSE {tbl}.{c} END").format(
            c=gs, stands=stands, same=same, observed=observed, tbl=tbl))
    return ConflictClause(owned=owned, assignments=assignments)


# ── Policy 7: a CI attestation does not re-attribute another repository's artifact ──────────

#: S-29. The `source_system` the build-provenance route stamps (torana_mesh ingest.py
#: `build_provenance_records`). Keyed by table: the columns an attestation writes about WHO
#: built the row. They are held together, so a held write cannot leave A's commit on B's repo.
ATTESTATION_SOURCE = "ci_build"
_ATTESTED_KEY = "torana_repository_id"
_ATTESTED_COLUMNS: Dict[str, Tuple[str, ...]] = {"artifacts": (
    "torana_repository_id", "repository_url", "repository_commit", "repository_branch",
    "name", "display_name", "description",
)}


def _attested_builder_clause(ctx: ConflictContext) -> Optional[ConflictClause]:
    """`col = stored` when a CI attestation names a DIFFERENT repository than the stored one.

    ⛔ WHY (S-29). The generic `col = EXCLUDED.col` let a CI job in repo A attest repo B's zip
    and become its builder: MEASURED on a throwaway PG through the real route, the second
    attestation rewrote torana_repository_id / repository_url / repository_commit. The route
    refuses that before writing and reads the row back after writing; this is the atomic floor
    both rely on, because two first attestations in flight at once both pass a read.

    THE RULE. Only a write whose incoming `source_system` is the attestation source is held,
    and only when the stored row already names a repository and the incoming one differs. The
    same repository re-attesting updates normally. Any other writer (the contest resolution,
    a backfill) keeps today's behaviour.

    ⚠️ Every CASE reads the STORED `torana_repository_id`: Postgres evaluates all SET
    expressions against the old row, so holding the key column does not change what the other
    columns compare against. No `%` in the statement (it runs with bound parameters).
    """
    cols = _ATTESTED_COLUMNS.get(ctx.table)
    if (not cols or _ATTESTED_KEY not in ctx.batch_columns
            or _LABEL not in ctx.batch_columns):
        return None
    owned = {c for c in cols
             if c in ctx.batch_columns and c in ctx.table_columns and c not in ctx.preserve}
    if not owned:
        return None
    tbl, key = ctx.table_ref, sql.Identifier(_ATTESTED_KEY)
    foreign = sql.SQL(
        "(EXCLUDED.{lab} = {src} AND {tbl}.{k} IS NOT NULL AND {tbl}.{k} <> EXCLUDED.{k})"
    ).format(lab=sql.Identifier(_LABEL), src=sql.Literal(ATTESTATION_SOURCE), tbl=tbl, k=key)
    return ConflictClause(
        owned=owned,
        assignments=[
            sql.SQL("{c} = CASE WHEN {f} THEN {tbl}.{c} ELSE EXCLUDED.{c} END").format(
                c=sql.Identifier(c), f=foreign, tbl=tbl)
            for c in sorted(owned)
        ],
    )


# ── Policy: an entity-edge tombstone written from a stale read is refused (BF2, F4) ───────────

_EDGES = "entity_edges"


def stale_edge_tombstone(stored: Dict[str, Any], incoming: Dict[str, Any]) -> bool:
    """True when `incoming` is a tombstone of a LIVE edge that carries an OLDER observation than the
    stored row — i.e. it was built from a read that a sync has since overtaken. The Python statement
    of the rule `_stale_edge_tombstone_clause` writes in SQL (the race test reads this one).

    ⛔ THE RACE. The reconciler re-upserts the full `SELECT *` row with `is_deleted = TRUE`
    (`_tombstone_edges`). Between its read and its write a sync can re-observe the edge (stamping a
    newer `last_seen`); an unconditional write then tombstones an edge that is live again, and the
    service's findings read "not running" until the next sync. A tombstone stating no `last_seen`
    is not judged."""
    if incoming.get("is_deleted") is not True or stored.get("is_deleted") is True:
        return False
    old, new = incoming.get("last_seen"), stored.get("last_seen")
    return old is not None and new is not None and new > old


def _stale_edge_tombstone_clause(ctx: ConflictContext) -> Optional[ConflictClause]:
    """`DO UPDATE … WHERE NOT (stale tombstone)` on entity_edges, when the writer sent both columns.
    Assigns nothing; every other writer's statement is unchanged (it only ever refuses a tombstone
    whose observation is older than the stored one)."""
    if not {"is_deleted", "last_seen"} <= ctx.batch_columns:
        return None
    return ConflictClause(where=sql.SQL(
        "NOT (EXCLUDED.{d} IS TRUE AND {tbl}.{d} IS NOT TRUE "
        "AND EXCLUDED.{ls} IS NOT NULL AND {tbl}.{ls} IS NOT NULL AND {tbl}.{ls} > EXCLUDED.{ls})"
    ).format(d=sql.Identifier("is_deleted"), ls=sql.Identifier("last_seen"), tbl=ctx.table_ref))


# ── Policy: the read record merges per key (D21, DS1a § 3.2.4, R9) ────────────────────────────

_READS = "reads"
_SEP = ENTRY_INTEGRATION_SEP
_BASE_K, _BASE_MK = entry_base_sql("keys.k"), entry_base_sql("mk.key")


def _reads_clause(ctx: ConflictContext) -> Optional[ConflictClause]:
    """Per-KEY merge of the read record (D21). A batch sync of one cluster runs workloads,
    services_ingresses and routes concurrently, each upserting the same scope row: a plain
    `reads = EXCLUDED.reads` would let the last writer erase the others' keys. For each entry key:
    - the entry of the run that STARTED later wins (`at`, compared as timestamptz); equal `at` = the
      incoming one;
    - ok_at = the latest success of either side (a late, older success still advances it);
    - first_at = the earliest of either side;
    - fail_since = when the winner failed: the earliest failure of either side that is after ok_at,
      else the winner's at; NULL when the winner succeeded;
    - an incoming '!complete:<data source>|<integration>' marker (written only to rows that already
      exist) drops a STORED entry of that data source AND integration (any ':<sub-read>' and
      '@<region>' form) whose `at` is older than the marker's (the walk's start), so one connection's
      walk never drops another's entries on the same scope (Q1). A legacy key with no '|<integration>'
      is dropped by any marker of its data source. The marker itself is never stored. The walk's own entries
      carry an `at` at or after the marker's and a newer run's a later one, so both survive.
    - PS-7: an entry with no `at` (a legacy or hand-written one) counts as the OLDEST for the
      winner (any timed entry replaces it) and is never dropped by a '!complete' marker (its age is
      unknown, so it is not "older than the walk"). A plain cast would compare NULL, keep it
      forever on replace and drop it on any marker.
    One statement under the row lock, so concurrent writers for different keys never lose each
    other's entries. Timestamps are compared as timestamptz, never as text. A writer that lists
    `reads` in preserve_columns keeps the stored record untouched (PS-7)."""
    if _READS not in ctx.batch_columns or _READS in ctx.preserve:
        return None
    return ConflictClause(owned={_READS}, assignments=[sql.SQL(
        "{col} = COALESCE(("
        " SELECT jsonb_object_agg(keys.k, CASE"
        "   WHEN o.v IS NULL THEN n.v"
        "   WHEN n.v IS NULL THEN o.v"
        "   ELSE m.latest || jsonb_build_object("
        "        'ok_at', m.ok_at, 'first_at', m.first_at,"
        "        'fail_since', CASE WHEN COALESCE((m.latest->>'ok')::boolean, FALSE) THEN NULL"
        "                           WHEN m.fail_c IS NOT NULL AND (m.ok_at IS NULL OR m.fail_c > m.ok_at) THEN m.fail_c"
        "                           ELSE (m.latest->>'at')::timestamptz END)"
        "   END)"
        " FROM (SELECT jsonb_object_keys(COALESCE({tbl}.{col}, '{{}}'::jsonb) || COALESCE(EXCLUDED.{col}, '{{}}'::jsonb)) AS k) keys"
        " LEFT JOIN LATERAL (SELECT COALESCE({tbl}.{col}, '{{}}'::jsonb) -> keys.k AS v) o ON TRUE"
        " LEFT JOIN LATERAL (SELECT COALESCE(EXCLUDED.{col}, '{{}}'::jsonb) -> keys.k AS v) n ON TRUE"
        " LEFT JOIN LATERAL (SELECT"
        "     CASE WHEN COALESCE((n.v->>'at')::timestamptz, '-infinity'::timestamptz)"
        "            >= COALESCE((o.v->>'at')::timestamptz, '-infinity'::timestamptz) THEN n.v ELSE o.v END AS latest,"
        "     GREATEST((o.v->>'ok_at')::timestamptz, (n.v->>'ok_at')::timestamptz) AS ok_at,"
        "     LEAST((o.v->>'first_at')::timestamptz, (n.v->>'first_at')::timestamptz) AS first_at,"
        "     LEAST(CASE WHEN NOT COALESCE((o.v->>'ok')::boolean, FALSE)"
        "                THEN COALESCE((o.v->>'fail_since')::timestamptz, (o.v->>'at')::timestamptz) END,"
        "           CASE WHEN NOT COALESCE((n.v->>'ok')::boolean, FALSE) THEN (n.v->>'at')::timestamptz END) AS fail_c"
        "   ) m ON TRUE"
        " LEFT JOIN LATERAL (SELECT MAX((mk.value ->> 'at')::timestamptz) AS done_at"
        "     FROM jsonb_each(COALESCE(EXCLUDED.{col}, '{{}}'::jsonb)) mk"
        "    WHERE CASE WHEN position('" + _SEP + "' IN keys.k) > 0"
        "               THEN mk.key = '!complete:' || split_part(split_part(" + _BASE_K + ", '@', 1), ':', 1)"
        "                             || '" + _SEP + "' || split_part(keys.k, '" + _SEP + "', 2)"
        "               ELSE " + _BASE_MK + " = '!complete:' || split_part(split_part(keys.k, '@', 1), ':', 1) END"
        "   ) c ON TRUE"
        " WHERE left(keys.k, 1) <> '!'"
        "   AND NOT (n.v IS NULL AND c.done_at IS NOT NULL"
        "            AND COALESCE((o.v->>'at')::timestamptz, 'infinity'::timestamptz) < c.done_at)"
        " ), '{{}}'::jsonb)"
    ).format(col=sql.Identifier(_READS), tbl=ctx.table_ref)])

#: torana-scan's reachability answer (DS3 § 3.4.5). Written only by the SARIF ingest, which sends
#: all four keys on every record, NULL when the scan did not measure.
_REACH_COLUMNS = ("code_reachability", "code_reachability_commit", "code_reachability_evidence",
                  "code_reachability_measured_at")
_REACH_TIME = "code_reachability_measured_at"

_REACH_KEEP = sql.SQL(
    "{c} = CASE WHEN EXCLUDED.code_reachability IS NOT NULL THEN EXCLUDED.{c} ELSE {tbl}.{c} END")
# The first time this answer was measured at this commit: kept while the answer and the commit
# are unchanged.
_REACH_FIRST = sql.SQL(
    "{c} = CASE WHEN EXCLUDED.code_reachability IS NULL THEN {tbl}.{c} "
    "WHEN EXCLUDED.code_reachability IS NOT DISTINCT FROM {tbl}.code_reachability "
    "AND EXCLUDED.code_reachability_commit IS NOT DISTINCT FROM {tbl}.code_reachability_commit "
    "THEN COALESCE({tbl}.{c}, EXCLUDED.{c}) ELSE EXCLUDED.{c} END")


def _scan_reachability_clause(ctx: ConflictContext) -> Optional[ConflictClause]:
    """Keep the stored reachability answer unless this write re-measured it (D7).

    A SARIF batch carries the four keys on every record, NULL when the scan did not measure; the
    generic `col = EXCLUDED.col` would erase a measured answer. They move together, except that
    `code_reachability_measured_at` keeps the first time the same answer was measured at the same
    commit (DS3 § 3.2.5, the pentest time test). Every assignment reads the stored row, so the
    order does not matter.
    """
    if ctx.table != "vulnerabilities" or "code_reachability" not in ctx.batch_columns:
        return None
    owned = {c for c in _REACH_COLUMNS
             if c in ctx.batch_columns and c in ctx.table_columns and c not in ctx.preserve}
    if not owned:
        return None
    tbl = ctx.table_ref
    return ConflictClause(
        owned=owned,
        assignments=[
            (_REACH_FIRST if c == _REACH_TIME else _REACH_KEEP).format(
                c=sql.Identifier(c), tbl=tbl)
            for c in sorted(owned)
        ],
    )


#: Order = order of the emitted assignments. Lifecycle first reproduces the statement the
#: backend emitted before this registry existed (verified by diffing the rendered SQL).
POLICIES: List[Policy] = [
    Policy(name="vulnerability_lifecycle", tables={lifecycle.LIFECYCLE_TABLE},
           build=_lifecycle_clause, prepare=lifecycle.prepare_vulnerability_records,
           stamps=lifecycle.STAMPED_COLUMNS),
    Policy(name="first_detected_earliest_wins", tables=set(_EARLIEST_WINS),
           build=_earliest_wins_clause),
    Policy(name="contributing_sources_merge", tables=None, build=_provenance_clause),
    Policy(name="stable_source_label", tables=None, build=_stable_label_clause),
    Policy(name="owner_decides_type", tables=set(_OWNER_TYPED), build=_owner_typed_clause),
    Policy(name="governance_not_observed", tables={"assets"}, build=_governance_clause),
    Policy(name="attested_builder_kept", tables=set(_ATTESTED_COLUMNS),
           build=_attested_builder_clause),
    Policy(name="stale_edge_tombstone_refused", tables={_EDGES},
           build=_stale_edge_tombstone_clause),
    Policy(name="scope_reads_merge", tables={"assets", "repositories"}, build=_reads_clause),
    Policy(name="scan_reachability_kept", tables={"vulnerabilities"},
           build=_scan_reachability_clause),
]


def _applies(policy: Policy, table: str) -> bool:
    return policy.tables is None or table in policy.tables


def prepare_records(table: str, records: List[Dict[str, Any]], now: datetime) -> None:
    """Run every applicable policy's insert-path hook, in place, before the column list is built."""
    for policy in POLICIES:
        if policy.prepare and _applies(policy, table):
            policy.prepare(records, now)


def prepare_record_groups(
    table: str, records: List[Dict[str, Any]], now: datetime,
) -> List[Tuple[List[Dict[str, Any]], Set[str]]]:
    """`prepare_records`, split so a stamped value can never pose as the writer's.

    Records are cut into CONTIGUOUS runs (order is kept, so a key written twice in one batch
    still ends on its last value) by which stampable columns the writer sent. Each run is
    stamped and returned with the columns it did NOT send: the backend builds one statement per
    run and passes those as `ConflictContext.stamped`. A table with no stamping policy, or a
    homogeneous batch, is one run — the statement is the same as before.
    """
    stampable: Set[str] = set()
    for policy in POLICIES:
        if policy.prepare and _applies(policy, table):
            stampable |= policy.stamps
    if not stampable:
        prepare_records(table, records, now)
        return [(records, set())]

    runs: List[Tuple[List[Dict[str, Any]], Set[str]]] = []
    last_sent: Optional[FrozenSet[str]] = None
    for rec in records:
        sent = frozenset(k for k in stampable if k in rec)
        if sent != last_sent:
            runs.append(([], stampable - sent))
            last_sent = sent
        runs[-1][0].append(rec)
    for run, _ in runs:
        prepare_records(table, run, now)
    return runs


def conflict_clauses(ctx: ConflictContext) -> List[ConflictClause]:
    """Every applicable policy's clause for this statement, in registry order."""
    out = []
    for policy in POLICIES:
        if not _applies(policy, ctx.table):
            continue
        clause = policy.build(ctx)
        if clause is not None:
            out.append(clause)
    return out


def combine_where(clauses: Iterable[ConflictClause]) -> Optional[sql.Composable]:
    """AND the policies' predicates, or None when no policy has one."""
    parts = [c.where for c in clauses if c.where is not None]
    if not parts:
        return None
    return sql.SQL(" AND ").join(sql.SQL("(") + p + sql.SQL(")") for p in parts)
