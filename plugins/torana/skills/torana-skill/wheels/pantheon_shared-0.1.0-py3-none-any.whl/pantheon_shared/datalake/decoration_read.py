"""The decoration layer's READ API — used by the ingest borrow path.

Design: ``DECORATION_LAYER_SPEC.md`` § 3.7.1.

Two write paths share one source of truth: the batch **apply** (which decorates rows
already in the sink) and the **ingest borrow** (which decorates rows as they land, so a
new row is correct immediately rather than waiting for a job). This module is what the
borrow path reads, so both paths resolve from the same facts and cannot disagree.

The two shapes an implementer cannot infer, and which the wrong guess breaks:

* **A subject with no facts is ABSENT from the outer dict** — ``facts.get(cve_id)``
  returns ``None``, so the caller's ``if f:`` naturally skips it.
* **An attribute this subject has no fact for is ABSENT from its :class:`FactRow`.**
  ``.get()`` returns ``None`` and does **not** raise. ⛔ Attributes are **not universal
  across subjects**: measured, ``kev_due_date`` exists for **1,656 of 353,522** CVEs, so
  absence is the common case and a subscript would ``KeyError`` on ~99.5% of rows —
  breaking the never-fail-a-sync rule.
"""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any, Iterable, Optional

from pantheon_shared.datalake.decorations import DECORATIONS
from pantheon_shared.datalake.decoration_store import GLOBAL_TENANT

__all__ = ["FactRow", "facts_for"]


class FactRow(Mapping):
    """One subject's facts: ``attribute -> value``, plus the version that produced them.

    A ``Mapping``, so ``in`` / iteration / ``len`` all work — but callers should use
    ``.get()``, never ``[...]``, for the reason in the module docstring.
    """

    __slots__ = ("_values", "source_version")

    def __init__(self, values: dict[str, Any], source_version: str = ""):
        self._values = values
        self.source_version = source_version

    def __getitem__(self, attribute: str) -> Any:
        return self._values[attribute]

    def __iter__(self) -> Iterator[str]:
        return iter(self._values)

    def __len__(self) -> int:
        return len(self._values)

    def __repr__(self) -> str:
        return f"FactRow({self._values!r}, source_version={self.source_version!r})"


def facts_for(
    backend: Any,
    decoration: str,
    subjects: Optional[Iterable[str]] = None,
    *,
    tenant_id: str = GLOBAL_TENANT,
    namespace_id: str = "",
) -> dict[str, FactRow]:
    """``{subject_key: FactRow}`` for one decoration.

    **Batch-scoped: one query per batch, never per record** — the same shape as the
    ``by_cve`` cache the borrow path already builds today.

    Args:
        backend: the datalake backend (the ``_execute_write`` seam).
        decoration: registry name.
        subjects: restrict to these subject keys. ``None`` returns every subject for the
            decoration — correct for a tenant-scoped decoration like ``policy``, whose
            whole fact set is a handful of severities. **For a subject-keyed decoration
            always pass the batch's subjects**: ``cve_intel`` holds 353k of them.
        tenant_id: ``''`` for a ``global``-scope decoration; the tenant for a
            ``tenant``-scope one. Defaulted from the registry when not given explicitly.

    Returns:
        Subjects with no facts are **absent**, not present-and-empty.
    """
    spec = DECORATIONS.get(decoration)
    if spec is None:
        raise KeyError(f"unknown decoration {decoration!r}")

    # A global decoration's facts live under tenant_id='' regardless of who is asking.
    scope_tenant = GLOBAL_TENANT if spec.scope == "global" else tenant_id

    params: dict[str, Any] = {"decoration": decoration, "tenant": scope_tenant}
    subject_filter = ""
    if subjects is not None:
        wanted = [s for s in subjects if s]
        if not wanted:
            # An empty subject set means "nothing to look up" — NOT "everything".
            # The degenerate reading would pull 353k rows to decorate zero records.
            return {}
        subject_filter = " AND subject_key = ANY(%(subjects)s)"
        params["subjects"] = wanted

    rows = backend._execute_write(
        f"""
SELECT subject_key, attribute, value #>> '{{}}' AS value, source_version
  FROM decoration_facts
 WHERE decoration = %(decoration)s
   AND tenant_id = %(tenant)s
   AND is_deleted IS NOT TRUE{subject_filter}""",
        params,
        tenant_id=scope_tenant,
        relations=["decoration_facts"],
    )

    out: dict[str, dict[str, Any]] = {}
    versions: dict[str, str] = {}
    for r in rows:
        subject = r["subject_key"]
        out.setdefault(subject, {})[r["attribute"]] = r["value"]
        # Last writer wins per subject; all attributes of one subject are landed by the
        # same producer run, so they share a version in practice.
        versions[subject] = r.get("source_version") or ""

    return {s: FactRow(v, versions.get(s, "")) for s, v in out.items()}
