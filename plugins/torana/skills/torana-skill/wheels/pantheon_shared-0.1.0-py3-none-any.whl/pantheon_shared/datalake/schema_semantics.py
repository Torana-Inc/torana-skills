"""Schema SEMANTICS — descriptions, collisions and value domains, as ONE implementation.

`Torana_Schema_Semantics.md` § 3.3 / § 3.8. The sibling module `schema_audit.py`
reconciles column **presence**; this one asks whether a machine author can understand
what a column MEANS.

## ⛔ Why this lives in pantheon-shared

§ 3.8 requires the audit to be reachable from all three surfaces (API, `torana` CLI,
FE). The measurement logic therefore cannot live in `pantheon-datalake/scripts/`,
which the service cannot import — that is how a "second overlapping audit surface"
gets built by accident, which § 3.3 names as itself a defect. The script is now a
thin CLI over this module; the API route imports the same `audit_static()`.

## ⚠️ Q1–Q6 catch bad descriptions; they cannot certify good ones

A fluent, wrong, 60-character sentence passes every rule. § 3.4.3 routes a 10% sample
to human review and reports the error rate rather than assuming it is zero — measured
at 5.6% (1 of 18) on the descriptions this spec authored.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from typing import Any, Dict, List, NamedTuple, Optional, Sequence, Set, Tuple

Key = Tuple[str, str]

#: § 3.4.1 Q1. Below this a description is a restatement of the column name.
#: Measured: the `findings` median was 34 chars at baseline.
THIN_CHARS = 40

#: § 3.6.1 — the mechanical candidate rule. Hand-picking produced the 45 declared
#: domains and missed `entity_edges.edge_type`, the highest-consequence enum in
#: the datalake; these thresholds replace the judgement call.
CAND_MIN_ROWS = 20        # enough evidence to generalise
CAND_MAX_DISTINCT = 25    # plausibly an enum
CAND_REPEAT_RATIO = 0.2   # repeats, not free text
DISTINCT_LIMIT = 100      # § 3.10 — never an unbounded SELECT DISTINCT

#: § 3.4.1 Q6. A vendor name in a description is correct only where the column is
#: itself vendor-specific; `severity` naming Tenable teaches an author a falsehood.
VENDORS = (
    "tenable", "qualys", "snyk", "wiz", "crowdstrike", "semgrep", "aikido",
    "cloudflare", "splunk", "okta", "servicenow", "jira", "github", "gitlab",
    "bitbucket", "circleci", "salesforce", "slack", "elasticsearch",
    "palo alto", "kubernetes",
)

#: Tokens that carry no meaning, so Q3 ("says something the name does not") is not
#: satisfied by padding a restatement with articles.
STOPWORDS = frozenset("""
a an the of for to in on at by with from this that these those is are was were
be been being it its as or and not no if then than which who whom whose what
when where how any all each per via s
""".split())

#: § 3.4.1 Q4 escape hatches — an explicit contrast satisfies the grain rule even
#: when the entity noun itself does not appear.
CONTRAST_MARKERS = (
    "not to be confused", "unlike", "as opposed to", "in contrast",
    "distinct from", "differs from", "rather than", "not the same as",
)

#: The entity noun(s) a table's own descriptions may use to state their grain.
#: Keyed by table; a collision column passes Q4 by naming its OWN entity.
TABLE_ENTITY_NOUNS: Dict[str, Tuple[str, ...]] = {
    "assets": ("asset", "host", "instance", "resource", "workload", "machine"),
    "findings": ("finding", "detection", "scan result", "scan finding"),
    "vulnerabilities": ("vulnerability", "vuln", "cve", "advisory"),
    "issues": ("issue", "ticket", "work item"),
    "repositories": ("repository", "repo", "codebase", "source tree"),
    "artifacts": ("artifact", "image", "build", "package artifact", "container"),
    "identities": ("identity", "identities", "principal", "user", "account", "service account"),
    "controls": ("control", "policy", "check", "benchmark", "rule"),
    "datastores": ("datastore", "data store", "database", "bucket", "storage"),
    "packages": ("package", "dependency", "library", "component"),
    "entity_edges": ("edge", "relationship", "link", "graph"),
}


class ColumnFinding(NamedTuple):
    """One column that fails the § 3.4.1 quality bar."""

    table: str
    column: str
    rule: str      # Q1..Q6
    detail: str

    @property
    def key(self) -> Key:
        return (self.table, self.column)


class Collision(NamedTuple):
    """One column NAME appearing on more than one table with differing descriptions."""

    column: str
    tables: Tuple[str, ...]
    distinct_descriptions: int


def _tokens(text: str) -> Set[str]:
    return {t for t in re.split(r"[^a-z0-9]+", text.lower()) if t and t not in STOPWORDS}


#: Columns whose PURPOSE is to carry provider identity or provenance. Naming vendors
#: in their descriptions is the correct behaviour, not a Q6 violation.
_PROVENANCE_COLUMN = re.compile(
    r"(source_system|provider|discovery_source|discovery_method|created_via|"
    r"dataset_tag|tool_name|_id$|^identity_id$|external_id|project_key|"
    r"finding_type|identity_type|is_admin|is_service_account|environment|status)"
)

#: Phrases that mark values as ILLUSTRATIVE. A description saying "for example `gcp`"
#: is teaching the column's shape, not asserting the column is GCP-specific.
_ILLUSTRATIVE = (
    "for example", "e.g", "such as", "and similar", "including", "observed values",
    "and the equivalent", "or similar",
)


def _is_illustrative(low: str) -> bool:
    return any(m in low for m in _ILLUSTRATIVE)


def _norm(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", text.lower()).strip()


def _quiet_imports() -> None:
    """Silence import-time logging BEFORE the schema modules load.

    ⛔ Not cosmetic. Importing `pantheon_shared.datalake` registers ~25 integrations
    and each logs to **stdout**, which corrupts `--format json` into unparseable
    output — measured: `json.load` failed with "Extra data: line 1 column 5". Every
    downstream consumer (§ 3.8's API and CLI surfaces) parses this stream, so the
    audit must own its stdout.
    """
    import logging
    logging.disable(logging.CRITICAL)
    try:
        import structlog
        structlog.configure(
            logger_factory=structlog.ReturnLoggerFactory(),
            processors=[],
            cache_logger_on_first_use=False,
        )
    except Exception:  # noqa: BLE001 — silencing is best-effort, never fatal
        pass


def load_declared() -> Dict[str, Dict[str, Dict[str, Any]]]:
    """`{table: {column: entry}}` for the 11 base sink tables.

    ⛔ § 3.9: a schema class that fails to import is reported as `error`, NEVER as
    an empty table — a dropped table reading as "perfect" is how a regression
    hides. The exception is re-raised into the caller's error map, not swallowed.
    """
    _quiet_imports()
    from pantheon_shared.datalake.shadow_baseline import declared_schema
    from pantheon_shared.datalake.schemas import _ALL_TABLE_SCHEMAS

    scoped = declared_schema()  # the 11 gated sink tables
    out: Dict[str, Dict[str, Dict[str, Any]]] = {}
    for cls in _ALL_TABLE_SCHEMAS:
        obj = cls()
        name = obj.table_name
        if name not in scoped:
            continue
        entries = obj.schema
        out[name] = {c: (entries.get(c) or {}) for c in scoped[name]}
    return out


def check_quality(
    table: str,
    column: str,
    entry: Dict[str, Any],
    *,
    collision_columns: Set[str],
    has_domain: bool,
    domain_values: Sequence[str] = (),
) -> List[ColumnFinding]:
    """The § 3.4.1 bar, Q1-Q6. Each rule is independently script-checkable.

    ⚠️ § 3.4.3: these catch BAD descriptions; they cannot certify good ones. A
    fluent, wrong, 60-character sentence passes all six. The gate is a floor.
    """
    desc = (entry.get("semantic_description") or "").strip()
    out: List[ColumnFinding] = []

    if not desc:
        return [ColumnFinding(table, column, "Q1", "no description")]

    # Q1 — length floor.
    if len(desc) < THIN_CHARS:
        out.append(ColumnFinding(table, column, "Q1", f"{len(desc)} chars < {THIN_CHARS}"))

    # Q2 — not a restatement of the column name.
    #
    # ⚠️ Compared on MEANINGFUL tokens, not raw normalised strings. A raw compare
    # misses `"The asset name."` for `asset_name` — the stray article alone makes
    # the strings differ — which is the single most likely restatement anyone
    # actually writes, and § 3.4.1 names that exact phrasing as the thing Q2 exists
    # to catch. Stopwords are dropped before comparing so articles cannot launder a
    # restatement past the rule.
    if _tokens(desc) == _tokens(column.replace("_", " ")):
        out.append(ColumnFinding(table, column, "Q2", "restates the column name"))

    # Q3 — carries at least one token the column name does not.
    if not (_tokens(desc) - _tokens(column.replace("_", " "))):
        out.append(ColumnFinding(table, column, "Q3", "adds no token beyond the column name"))

    # Q4 — a collision column must state its grain or draw an explicit contrast.
    if column in collision_columns:
        low = desc.lower()
        nouns = TABLE_ENTITY_NOUNS.get(table, ())
        if not (any(n in low for n in nouns) or any(m in low for m in CONTRAST_MARKERS)):
            out.append(ColumnFinding(
                table, column, "Q4",
                f"collision column names neither its own entity {nouns!r} nor a contrast",
            ))

    # Q5 — where a domain is declared, the description must not re-enumerate it.
    #      Two authorities for one fact drift; the domain is the authority.
    #
    # ⚠️ Fires only on an EXHAUSTIVE restatement, not on illustration. Naming two or
    # three values to show an author the SHAPE of the column is the single most
    # useful thing a description can do; reproducing the whole closed list is what
    # drifts when the domain changes. The rule therefore triggers on a near-complete
    # copy (most of the domain, and at least 4 values), and never on a description
    # that explicitly marks its values as examples.
    if has_domain and domain_values:
        low = desc.lower()
        # ⚠️ A description that lists the values IN ORDER TO CONTRAST them with
        # another column is doing real work, not duplicating the domain. Measured:
        # `vulnerabilities.severity` and `.priority` list their values precisely to
        # teach that severity is a property of the FLAW while priority is the
        # TENANT's policy answer — the single most consequential distinction in the
        # vulnerability schema. Stripping the lists to satisfy a mechanical rule
        # would make the schema worse, which is § 3.4.1's own warning that the bar
        # is a floor and not a proof. A cross-reference to a sibling column is
        # therefore accepted as the description carrying its own justification.
        contrasts = "`" in desc and any(
            m in low for m in ("distinct from", "rather than", "not to be confused",
                               "unlike", "whereas", "use `", "against this"))
        if not _is_illustrative(low) and not contrasts:
            hits = [v for v in domain_values
                    if v and len(str(v)) > 2 and str(v).lower() in low]
            if len(hits) >= 4 and len(hits) >= 0.8 * len(domain_values):
                out.append(ColumnFinding(
                    table, column, "Q5",
                    f"enumerates {len(hits)} of {len(domain_values)} declared domain values "
                    f"({hits[:4]}) — the domain is the authority",
                ))

    # Q6 — no vendor name unless the column is itself vendor-specific.
    #
    # ⛔ NARROWED after measurement. The first cut flagged 16 columns, and inspection
    # showed every one was a FALSE POSITIVE: a `source_system` description that says
    # "(`gcp`, `okta`, `jira`)" is naming the values the column HOLDS, which is
    # precisely the information an author needs, and `identity_id` illustrating
    # "`gcp_sa_<uniqueId>`, `aws_iam_<UserId>`" is showing the key's shape.
    #
    # § 3.4.1's actual target is a vendor claim leaking into a vendor-NEUTRAL concept
    # ("`severity` may not say Tenable"). So the rule now fires only when a vendor is
    # named WITHOUT example framing — no backticks, no "e.g.", no "such as" — and
    # never on a column that legitimately carries provider identity or provenance.
    low = desc.lower()
    col_low = column.lower()
    if not _PROVENANCE_COLUMN.search(col_low) and not _is_illustrative(low):
        for v in VENDORS:
            if v not in low:
                continue
            if v.replace(" ", "_") in col_low or v.replace(" ", "") in col_low:
                continue
            # Backticked or parenthesised => an example, not a claim of specificity.
            if re.search(r"[`(][^`)]*" + re.escape(v), low):
                continue
            out.append(ColumnFinding(
                table, column, "Q6",
                f"names vendor '{v}' outside example framing on a vendor-neutral column",
            ))
            break

    return out


def find_collisions(declared: Dict[str, Dict[str, Dict[str, Any]]]) -> List[Collision]:
    """Column names on >1 table whose descriptions DIFFER (§ 2.3).

    ⚠️ System fields are excluded: they are injected identically on every table by
    `system_fields.py`, so they are shared by construction and can never be the
    ambiguity this metric hunts.
    """
    from pantheon_shared.datalake.schemas.system_fields import STANDARD_SYSTEM_FIELDS

    system = {f.lower() for f in STANDARD_SYSTEM_FIELDS}
    by_col: Dict[str, Dict[str, str]] = {}
    for table, cols in declared.items():
        for col, entry in cols.items():
            if col.lower() in system:
                continue
            by_col.setdefault(col, {})[table] = (
                entry.get("semantic_description") or "").strip()

    out: List[Collision] = []
    for col, per_table in sorted(by_col.items()):
        if len(per_table) < 2:
            continue
        distinct = {_norm(d) for d in per_table.values()}
        if len(distinct) > 1:
            out.append(Collision(col, tuple(sorted(per_table)), len(distinct)))
    return out


def load_domains() -> Dict[Key, Dict[str, Any]]:
    from pantheon_shared.datalake.value_domain import DOMAINS
    return dict(DOMAINS)


def audit_static(*, declared=None) -> Dict[str, Any]:
    """Every metric that needs no live stack. Never raises on a bad table."""
    errors: Dict[str, str] = {}
    if declared is None:
        try:
            declared = load_declared()
        except Exception as exc:  # noqa: BLE001
            return {
                "error": f"{type(exc).__name__}: {exc}",
                "tables": {}, "counts": {}, "table_errors": {"*": str(exc)},
            }

    domains = load_domains()
    collisions = find_collisions(declared)
    collision_columns = {c.column for c in collisions}

    per_table: Dict[str, Any] = {}
    failures: List[ColumnFinding] = []
    described = missing = thin = 0

    for table in sorted(declared):
        cols = declared[table]
        t_desc = t_miss = t_thin = 0
        for col, entry in sorted(cols.items()):
            desc = (entry.get("semantic_description") or "").strip()
            if desc:
                t_desc += 1
                if len(desc) < THIN_CHARS:
                    t_thin += 1
            else:
                t_miss += 1
            dom = domains.get((table, col))
            failures.extend(check_quality(
                table, col, entry,
                collision_columns=collision_columns,
                has_domain=dom is not None,
                domain_values=tuple((dom or {}).get("values") or ()),
            ))
        per_table[table] = {
            "columns": len(cols), "described": t_desc,
            "missing": t_miss, "thin": t_thin,
        }
        described += t_desc
        missing += t_miss
        thin += t_thin

    quality_fail_keys = {f.key for f in failures}
    return {
        "tables": per_table,
        "table_errors": errors,
        "counts": {
            "columns": sum(t["columns"] for t in per_table.values()),
            "described": described,
            "missing": missing,
            "thin": thin,
            "quality_fail": len(quality_fail_keys),
            "collisions": len(collisions),
            "domains_declared": len(domains),
        },
        "quality_failures": [f._asdict() for f in failures],
        "collision_list": [c._asdict() for c in collisions],
    }


