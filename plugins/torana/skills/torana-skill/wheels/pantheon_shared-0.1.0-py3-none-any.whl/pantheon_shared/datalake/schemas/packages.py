from typing import Dict, Any
from .base import TableSchema


class PackagesSchema(TableSchema):
    """Schema for the packages table (Torana_Asset_Graph_Design.md § 3.3.2).

    Third-party SBOM components, ``purl``-keyed. Separated from ``artifacts``
    because it is a different granularity (components *inside* artifacts),
    high-cardinality, many-to-many with images (via ``contains`` edges), and the
    natural home for SCA vulnerabilities (which reference it via
    ``vulnerabilities.torana_package_id``).

    PK uses the ``torana_<entity>_id`` prefixed convention (§ 3.3). ``description``,
    ``first_seen`` and ``last_seen`` are explicit business columns — they are NOT
    system-injected (only IAM + audit fields are; § 3.3).
    """

    @property
    def table_name(self) -> str:
        return "packages"

    @property
    def primary_key(self) -> str:
        return "torana_package_id"

    @property
    def description(self) -> str:
        return (
            "Third-party software packages (SBOM components, purl-keyed) discovered "
            "inside container images and build artifacts; the attach point for SCA "
            "vulnerabilities in the asset graph (CAASM)."
        )

    @property
    def category(self) -> str:
        return "Entity Graph"

    @property
    def timestamp_column(self) -> str:
        return "updated_at"

    @property
    def schema(self) -> Dict[str, Any]:
        return {
            "torana_package_id": {
                "data_type": "VARCHAR(512)", "primary_key": True, "category": "Core Identity",
                "semantic_description": (
                    "Torana's stable id for one third-party package, in the form "
                    "`pkg:<purl>`. Vulnerabilities from SCA scanners attach here."
                ),
            },
            "purl": {
                "data_type": "VARCHAR(512)", "not_null": True, "index": True, "category": "Core Identity",
                "semantic_description": (
                    "Package URL (purl) — the ecosystem-neutral identifier, e.g. "
                    "`pkg:npm/lodash@4.17.21`. The join key SCA findings arrive on."
                ),
            },
            "package_manager": {
                "data_type": "VARCHAR(50)", "index": True, "category": "Package Details",
                "semantic_description": (
                    "Ecosystem the package comes from (npm, pypi, maven, go, and similar). ⚠️ Determines "
                    "how two version strings compare, so a version comparison that ignores it is wrong "
                    "across ecosystems. Identical in meaning on `packages` and `vulnerabilities`."
                ),
            },
            "name": {
                "data_type": "VARCHAR(255)", "category": "Package Details",
                "semantic_description": "Package name without ecosystem or version qualifiers.",
            },
            "version": {
                "data_type": "VARCHAR(100)", "category": "Package Details",
                "semantic_description": (
                    "Version string as published. Format follows the ecosystem's own "
                    "convention, so it is not comparable across package managers."
                ),
            },
            "source_system": {
                "data_type": "VARCHAR(100)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "The integration or internal producer that reported this package row. ⚠️ Determines "
                    "which other columns are populated at all, since sources differ in what they expose, "
                    "and it is the first thing to check when two rows describe the same package differently."
                ),
            },
            "cloud_account_id": {"data_type": "VARCHAR(100)", "category": "Cloud Provider-Specific Fields",
                "semantic_description": (
                    "The cloud account or subscription this row belongs to — a GCP project id, an "
                    "AWS account number, an Azure subscription. Often the real boundary between "
                    "teams or environments, so it is the natural grouping for 'show me X by "
                    "account'. ⚠️ NOT a Jira project and NOT a logical/product grouping: those "
                    "are separate concepts (see issues.project_key and the governance properties). "
                    "NULL for rows that are not cloud-sourced."
                ),
            },
            "cloud_provider": {"data_type": "VARCHAR(50)", "category": "Cloud Provider-Specific Fields",
                "semantic_description": (
                    "Which cloud this runs in: AWS, Azure, GCP, OCI, or On-Premises. ⚠️ Distinct "
                    "from source_system, which says WHO reported the row — a Kubernetes connector "
                    "reporting a workload running in GCP writes source_system='kubernetes' and "
                    "cloud_provider='gcp'. Needed to disambiguate cloud_account_id, whose namespace "
                    "differs per provider."
                ),
            },
            "discovery_source": {
                "data_type": "VARCHAR(100)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "The FEED through which this package was discovered — which pipeline told the platform "
                    "it exists. ⚠️ Kept distinct from `source_system` because a package can be discovered "
                    "by one mechanism and maintained by another."
                ),
            },
            "created_by": {
                "data_type": "VARCHAR(255)", "category": "Discovery & Inventory",
                "semantic_description": (
                    "The Torana user or service principal that caused this package row to be written — in "
                    "practice the integration that ingested it (`github_integration`, `jira_integration`). "
                    "⚠️ An INGEST-side actor, NOT the owner of the thing described: do not read it as "
                    "'who is responsible for this'."
                ),
            },
            # SDG-replay marker (mirrors the other sink tables) so `clear-sdg-data` can
            # purge replay-seeded packages by created_via='sdg_replay' [+ dataset_tag].
            "created_via": {"data_type": "VARCHAR(50)", "index": True, "category": "Discovery & Inventory",
                "semantic_description": (
                    "The Torana mechanism that wrote this package row — an integration sync, a replay, a "
                    "manual push, or a synthetic dataset load. ⛔ Provenance, not package data: it is what "
                    "separates genuinely ingested rows from generated ones, and a query measuring a real "
                    "estate should know which values are synthetic."
                ),
            },
            "dataset_tag": {"data_type": "VARCHAR(255)", "index": True, "category": "Discovery & Inventory",
                "semantic_description": (
                    "Marks this package row as seeded by a NAMED synthetic dataset rather than a live "
                    "integration, so such rows can be purged as a set. NULL for genuinely ingested rows. ⛔ "
                    "Filter it out when measuring a real estate — counting demo rows as production package "
                    "data is the error this column exists to prevent."
                ),
            },
        }
