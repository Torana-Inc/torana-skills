"""THE exposure rule for a service (EPR Platform Design § B; DS1b § 3.2.1).

A service is exposed when a live `exposed_via` starts at it, or a live `routes_to` ending at it
has evidence reach 'internet'. The sign-in is a detail, never a condition.

⛔ posture_runtime_context's internet_route / exposed_service CTEs state the same rule; a contract
test in pantheon-data-transformers holds the two texts together. The reconciler's assert and its
retract both use `exposed_service_sql`, so they are exact opposites wherever the scope was read.
"""
from pantheon_shared.identity.scope_key import entry_base_sql, entry_fresh_ok_sql

#: The reach of a route edge: the top level first (the edge merge writes each source's latest
#: fields there), else the writing source's own block, else 'unknown'.
REACH_SQL = ("COALESCE(NULLIF({e}.evidence::jsonb ->> 'reach', ''), "
             "NULLIF({e}.evidence::jsonb -> {e}.source_system ->> 'reach', ''), 'unknown')")


def exposed_service_sql(key: str) -> str:
    """A SQL predicate: the service whose key is the SQL expression `key` is exposed."""
    return ("(EXISTS (SELECT 1 FROM entity_edges x_ev WHERE x_ev.from_key = " + key +
            " AND x_ev.edge_type = 'exposed_via' AND coalesce(x_ev.is_deleted, false) = false)"
            " OR EXISTS (SELECT 1 FROM entity_edges x_rt WHERE x_rt.to_key = " + key +
            " AND x_rt.edge_type = 'routes_to' AND coalesce(x_rt.is_deleted, false) = false"
            " AND " + REACH_SQL.format(e="x_rt") + " = 'internet'))")


def retract_gate_sql(key: str, prc_present: bool) -> str:
    """The gate on a RETRACT of `public_access` (never on an assert). Three cases, in this order:

    1. No posture_runtime_context relation on the tenant (the EPR bundle is not installed), or no
       JUDGED PRC row for the service: no row (a service with no image place), or every row has
       `exposure_read_basis` NULL (its own scope has no read record yet: "unjudged stays as
       today"). TODAY'S edge-only retract, unchanged — the gate is TRUE, so the existing
       `NOT <exposed_service_sql>` alone decides (a flag must not stay internet-facing forever).
    2. Judged: asset_context must have judged the service's exposure READS measured on every row
       (`exposure_read_basis`) — the one judgement, never restated here …
    3. … AND none of the read-record entries that judgement read may be failed on the LIVE scope
       row. PRC is rebuilt only on the next drain, while the runtime edge sweep can retire a
       degraded read's edges in the sweep before; the live entry closes that window. ⛔ It checks
       only the entries PRC lists in `exposure_read_entries` (`{scope, key, prefix}`), so a failed
       tag read, another region, or another GCP data source on the same scope row never blocks
       it. No data-source list, no rule here. Entries are judged per BASE (Q1, scope_key.entry_base):
       a failed entry blocks only when no integration's entry of the same base is ok and fresh."""
    if not prc_present:
        return "TRUE"
    unjudged = ("NOT EXISTS (SELECT 1 FROM posture_runtime_context rc0 WHERE rc0.service_key = " + key +
                " AND rc0.is_deleted IS NOT TRUE AND rc0.exposure_read_basis IS NOT NULL)")
    measured = ("NOT EXISTS (SELECT 1 FROM posture_runtime_context rc_n WHERE rc_n.service_key = " + key +
                " AND rc_n.is_deleted IS NOT TRUE AND rc_n.exposure_read_basis IS DISTINCT FROM 'measured')")
    base, base2 = entry_base_sql("e.key"), entry_base_sql("e2.key")
    live_ok = ("NOT EXISTS (SELECT 1 FROM posture_runtime_context rc_s"
               " CROSS JOIN LATERAL jsonb_array_elements(COALESCE(rc_s.exposure_read_entries::jsonb, '[]'::jsonb)) r"
               " JOIN assets s ON s.torana_entity_id = r.value ->> 'scope'"
               " CROSS JOIN LATERAL jsonb_each(COALESCE(s.reads::jsonb, '{}'::jsonb)) e"
               " WHERE rc_s.service_key = " + key + " AND rc_s.is_deleted IS NOT TRUE"
               " AND CASE WHEN COALESCE((r.value ->> 'prefix')::boolean, FALSE)"
               "          THEN left(" + base + ", length(r.value ->> 'key')) = r.value ->> 'key'"
               "          ELSE " + base + " = r.value ->> 'key' END"
               " AND NOT COALESCE((e.value ->> 'ok')::boolean, FALSE)"
               # Q1: a failed entry blocks only when NO integration's entry of the same base is ok and fresh
               " AND NOT EXISTS (SELECT 1 FROM jsonb_each(COALESCE(s.reads::jsonb, '{}'::jsonb)) e2"
               "                  WHERE " + base2 + " = " + base + " AND " + entry_fresh_ok_sql("e2.value") + "))")
    return "(" + unjudged + " OR (" + measured + " AND " + live_ok + "))"


__all__ = ["REACH_SQL", "exposed_service_sql", "retract_gate_sql"]
