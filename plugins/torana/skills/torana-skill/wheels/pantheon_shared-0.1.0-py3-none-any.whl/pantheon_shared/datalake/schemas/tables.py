"""
Table name constants for Pantheon datalake.

Provides centralized table name definitions to avoid hardcoding strings across services.
Use these constants instead of raw strings like "identities", "assets", etc.

Example:
    from pantheon_shared.datalake.schemas import DatalakeTables

    # Instead of:
    backend.upsert_data("identities", records, ...)

    # Use:
    backend.upsert_data(DatalakeTables.IDENTITIES, records, ...)
"""

from enum import Enum


class DatalakeTables(str, Enum):
    """Table names for core datalake tables."""

    IDENTITIES = "identities"
    REPOSITORIES = "repositories"
    VULNERABILITIES = "vulnerabilities"
    ASSETS = "assets"
    DATASTORES = "datastores"
    ARTIFACTS = "artifacts"
    FINDINGS = "findings"
    ISSUES = "issues"
    CONTROLS = "controls"
    PACKAGES = "packages"
    ASSET_EDGES = "entity_edges"
    PENTEST_CASES = "pentest_cases"
    PENTEST_RUNS = "pentest_runs"

    def __str__(self) -> str:
        """Return the string value for compatibility with SQL queries."""
        return self.value
