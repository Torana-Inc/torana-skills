"""The standing schema audit — every surface that DESCRIBES the schema, reconciled.

NORTH_STAR_BUILD_SYSTEM.md § 4.6. Three large changes landed on the datalake
schema without a reconciling pass: the § 1.3 collapse removed **903 columns**,
platform and corpus schemas merged into one reachable set, and tenant schemas
are provisioned separately. Nothing since has asserted that every surface
describing the schema still agrees with the schema.

## Why this is a MODULE and not a script

⛔ The last cleanup left residue precisely because nothing re-ran afterwards.
A one-off pass that produces a CSV is the failure mode, not the fix:
`docs/corpus/shadow_column_report.csv` is a frozen 2026-08-10 snapshot that no
service reads, and it disagrees with the live schema by 9 columns purely
because time passed. This module is imported by the API, the CLI and the
harness so there is ONE implementation and no surface can drift from it.

## The two directions — one alone hides half the drift

    describes-but-absent    a surface names a column the live DB does not have
    present-but-undescribed the live DB has a column no surface declares

Today's evidence for why BOTH are required: the reachability ratchet reads the
CODE schema and reports 3 shadow columns; the datalake API joins against the
LIVE DB and reports 4. Neither is wrong — they answer different directions.
`vulnerabilities.severity_score` is invisible to the ratchet (undeclared in
code) while sitting physically in all three tenant tables, three days after
§ 1.3 recorded it as removed. Only the second direction can see it.

## Platform vs tenant is a REAL distinction, not noise

⚠️ The two scopes legitimately differ, and conflating them makes the audit
useless: at tenant scope 126 platform-reachable columns are filtered out
because this tenant has not connected the integration that writes them. Those
are `connectable` — a config gap with a customer-side owner — NOT drift.
Reporting them would produce ~126 false positives on every run and the check
would be ignored inside a week. This module reuses the existing
`connectable`/`shadow` split rather than inventing a second vocabulary for it.

## System fields are classified out PROGRAMMATICALLY

The 9 `STANDARD_SYSTEM_FIELDS` (tenant_id, namespace_id, is_deleted, the audit
quartet, trace_id, contributing_sources) are injected per-table by
`system_fields.py` and are therefore absent from every entity schema by design.
They are read from that module, never hardcoded here — a hardcoded copy is a
tenth surface to drift.

## The archive is a GUARD, never a to-do list

`removed_columns_archive.csv` holds 903 deliberately-deleted columns. A column
in it must NOT be re-added; when the audit finds one still described or still
physically present, the resolution is always REMOVAL. Cross-checking against
the archive is what stops a well-meaning fix from resurrecting a column the
collapse removed on purpose.
"""

from __future__ import annotations

import csv
from pathlib import Path
from typing import Any, Dict, List, NamedTuple, Optional, Sequence, Set, Tuple

Key = Tuple[str, str]


# ⛔ NAMED, bounded exceptions — debt with an identified writer, not aspiration.
#
# § S14 of `shadow_baseline.py` ruled that *"a tool we do not support yet might
# write it"* is unfalsifiable and must stop being indistinguishable from the
# contract. These entries are the opposite: each names the SPECIFIC writer that
# is owed, so the claim is falsifiable and closes when that writer lands.
#
# ⚠️ These do NOT suppress the finding — the audit still reports them and still
# EXITS NON-ZERO (the operator's explicit decision, 2026-08-18). They are
# separated from new drift only so that a NEWLY introduced writerless column is
# instantly distinguishable from this known debt, and "red" never decays into
# ambient noise.
KNOWN_OWED: Dict[Key, str] = {
    ("vulnerabilities", "cve_published_date"): (
        "NVD/OSV advisory fetcher populating decoration_facts.published_date; "
        "the cve_intel decoration pipeline already joins on cve_id and needs "
        "only a `provides` entry once the fetcher lands. A writer was REMOVED "
        "on purpose (gcp/container_analysis_occurrences.yaml) because it "
        "derived the value from scan time, making it byte-identical to "
        "scan_first_detected_date on all 85,984 rows."
    ),
    ("vulnerabilities", "cve_last_modified_date"): (
        "NVD/OSV advisory fetcher populating decoration_facts.last_modified_date "
        "— same pipeline and same removed-fabrication history as "
        "cve_published_date."
    ),
    ("assets", "image_ownership"): (
        "the DECLARATION door — a `governance_push` target on the "
        "asset_inventory.v1 contract (mappings/asset/assets.yaml), which does not "
        "carry an ownership field yet. ⭐ THE COLUMN IS NOT UNUSED: the DERIVED "
        "half shipped with Spec F Phase 3 and writes to "
        "`entity_properties_resolved.image_ownership` "
        "(torana_mesh/services/image_ownership.py, stamped by ResolutionBuilder "
        "step 4d), which is the surface MET-003 and the `vm.tf.em_101` catalog "
        "entry actually read — MEASURED on T2 2026-09-07: 13 first_party + 33 "
        "undetermined over 46 running images. "
        "⛔ WHY THE DERIVATION MUST NOT WRITE HERE, rather than this being an "
        "oversight: `assets.image_ownership` is where a TENANT DECLARATION lands, "
        "and a declaration outranks derivation outright (Spec F § 3.1 "
        "conflict_rule). If the derived default were written to the same column, "
        "the resolver would read its own output back as a declaration on the next "
        "pass, and a derived `undetermined` would then outrank the very inventory "
        "backing that should correct it once the customer's registry is onboarded. "
        "The two halves are deliberately on two surfaces. "
        "Owed when the ownership field is added to the asset_inventory.v1 push "
        "contract and the torana-asset-inventory skill — a CONTRACT change, not a "
        "mapping edit (same shape as the `team` gap, Spec G § 3.9.8)."
    ),
}


class Finding(NamedTuple):
    """One reconciliation result. `surface` is what claimed it; `direction` which way."""

    table: str
    column: str
    surface: str
    direction: str          # describes_but_absent | present_but_undescribed
    verdict: str            # drift | by_design | known_owed | archived_residue
    detail: str

    @property
    def key(self) -> Key:
        return (self.table, self.column)

    @property
    def is_drift(self) -> bool:
        """`by_design` never fails the audit; everything else does."""
        return self.verdict != "by_design"


class AuditResult(NamedTuple):
    findings: Tuple[Finding, ...]
    surfaces: Tuple[str, ...]
    scope: str
    counts: Dict[str, int]

    @property
    def drift(self) -> Tuple[Finding, ...]:
        return tuple(f for f in self.findings if f.is_drift)

    @property
    def new_drift(self) -> Tuple[Finding, ...]:
        """Drift that is NOT the known-owed debt — the part that must never appear."""
        return tuple(f for f in self.drift if f.verdict != "known_owed")

    @property
    def ok(self) -> bool:
        return not self.drift

    @property
    def exit_code(self) -> int:
        return 0 if self.ok else 1


def system_fields() -> Set[str]:
    """The injected per-table system columns, read from their declaring module."""
    try:
        from pantheon_shared.datalake.schemas.system_fields import (
            STANDARD_SYSTEM_FIELDS,
        )
        return {c.lower() for c in STANDARD_SYSTEM_FIELDS}
    except Exception:
        # ⛔ Never guess a smaller set: a missed system field is reported as
        # drift on EVERY table, which is the false-positive flood that gets the
        # audit ignored. An empty set here would do exactly that, so re-raise.
        raise


def archived_columns(path: Optional[Path] = None) -> Dict[Key, str]:
    """`{(table, column): archived_on}` from the 903-row removal archive.

    The archive is the guard that stops a fix from re-adding a column the § 1.3
    collapse deleted on purpose. A missing file degrades to an empty guard with
    the caller informed via `surfaces`, never a raise — the audit is still
    useful without it, just less specific about WHY a column must go.
    """
    if path is None:
        path = _default_archive_path()
    out: Dict[Key, str] = {}
    if not path or not path.exists():
        return out
    with path.open(newline="") as fh:
        for row in csv.DictReader(fh):
            t = (row.get("table") or "").strip().lower()
            c = (row.get("column") or "").strip().lower()
            if t and c:
                out[(t, c)] = (row.get("archived_on") or "").strip()
    return out


def _default_archive_path() -> Optional[Path]:
    """Locate `removed_columns_archive.csv` across the sibling-checkout layout."""
    here = Path(__file__).resolve()
    rel = Path("pantheon-datalake/docs/corpus/removed_columns_archive.csv")
    for parent in here.parents:
        cand = parent / rel
        if cand.exists():
            return cand
    return None


def overlay_enum_columns(model: Optional[Dict[str, Any]] = None) -> Dict[Key, List[str]]:
    """`{(table, column): enum}` for every column the MEANING overlay describes.

    The overlay is a published contract: the skill and `vm_data_builder_v2` both
    read it to decide what to filter on. An enum naming a column that no longer
    exists is an invitation to author SQL against it, and the resulting failure
    is a query that parses, deploys green and returns nothing forever.
    """
    if model is None:
        from pantheon_shared.datalake.schemas import load_semantic_model
        model = load_semantic_model()
    out: Dict[Key, List[str]] = {}
    for table in model.get("tables", []) or []:
        tname = (table.get("name") or "").strip().lower()
        if not tname:
            continue
        for dim in (table.get("dimensions") or []) + (table.get("metrics") or []):
            cname = (dim.get("name") or "").strip().lower()
            if not cname:
                continue
            enum = dim.get("enum")
            if enum:
                out[(tname, cname)] = list(enum)
    return out


def overlay_described_columns(model: Optional[Dict[str, Any]] = None) -> Set[Key]:
    """Every `(table, column)` the overlay describes at all (synonyms or enum)."""
    if model is None:
        from pantheon_shared.datalake.schemas import load_semantic_model
        model = load_semantic_model()
    out: Set[Key] = set()
    for table in model.get("tables", []) or []:
        tname = (table.get("name") or "").strip().lower()
        if not tname:
            continue
        for dim in (table.get("dimensions") or []) + (table.get("metrics") or []):
            cname = (dim.get("name") or "").strip().lower()
            if cname and (dim.get("synonyms") or dim.get("enum")):
                out.add((tname, cname))
    return out


# ── The reconcilers ────────────────────────────────────────────────────────────
#
# Each returns Findings for ONE surface. They are separate functions rather than
# one pass so a surface can be added without touching the others — § 4.6 asks for
# the surfaces to be ENUMERATED, and "a surface nobody lists is a surface nobody
# reconciles".


def reconcile_overlay(
    *,
    declared: Dict[str, Sequence[str]],
    reachable_platform: Set[Key],
    archive: Dict[Key, str],
    model: Optional[Dict[str, Any]] = None,
) -> List[Finding]:
    """The MEANING overlay (`query-hints`) vs the schema — describes-but-absent.

    ⛔ An overlay entry for a dead column is dangerous, not untidy: it is a
    PUBLISHED CONTRACT that the skill and `vm_data_builder_v2` read to decide
    what to filter on. Describing a column that no longer exists is an
    invitation to author SQL against it, and the failure is a query that
    parses, deploys green and returns nothing forever.
    """
    declared_keys = {
        (t.lower(), c.lower()) for t, cols in declared.items() for c in cols
    }
    out: List[Finding] = []

    for (table, column), enum in sorted(overlay_enum_columns(model).items()):
        key = (table, column)
        if key in declared_keys:
            continue
        archived_on = archive.get(key)
        if archived_on:
            out.append(Finding(
                table, column, "semantic_overlay", "describes_but_absent",
                "archived_residue",
                f"enum({len(enum)} values) declared for a column ARCHIVED on "
                f"{archived_on}. § 1.3 residue — remove the overlay entry; the "
                f"column must NOT be re-added.",
            ))
        else:
            out.append(Finding(
                table, column, "semantic_overlay", "describes_but_absent", "drift",
                f"enum({len(enum)} values) declared for a column absent from the "
                f"declared schema, and NOT in the removal archive.",
            ))

    # A described column that exists but nothing can write is a softer signal —
    # the description is not wrong, the WRITER is missing. Reported against the
    # writer surface (below), not here, so one root cause yields one finding.
    return out


def reconcile_writers(
    *,
    declared: Dict[str, Sequence[str]],
    reachable_platform: Set[Key],
    archive: Dict[Key, str],
) -> List[Finding]:
    """Declared columns with no writer at PLATFORM scope.

    ⭐ This is the operator's rule, made mechanical: *a column is declared only
    if a writer lands with it*. There is no staging scope — that is where the
    903 archived columns came from.

    ⚠️ Platform scope ONLY. At tenant scope ~126 columns are legitimately
    unreachable because this tenant has not connected the integration that
    writes them (`connectable`). Those are a config gap with a customer-side
    owner, not drift; reporting them would flood the audit with false positives
    and it would be ignored inside a week.
    """
    out: List[Finding] = []
    for table, cols in sorted(declared.items()):
        for column in sorted(c.lower() for c in cols):
            key = (table.lower(), column)
            if key in reachable_platform:
                continue
            owed = KNOWN_OWED.get(key)
            if owed:
                out.append(Finding(
                    table.lower(), column, "write_seam", "describes_but_absent",
                    "known_owed",
                    f"declared, no platform writer. Owed writer: {owed}",
                ))
            else:
                out.append(Finding(
                    table.lower(), column, "write_seam", "describes_but_absent",
                    "drift",
                    "declared but NO writer at platform scope. Either build the "
                    "writer (register_writer / a mapping target) or drop the "
                    "column — a declared column has a writer, or it does not exist.",
                ))
    return out


def reconcile_live_schema(
    *,
    declared: Dict[str, Sequence[str]],
    live: Dict[str, Sequence[str]],
    archive: Dict[Key, str],
) -> List[Finding]:
    """The live DB vs the code-declared schema — BOTH directions.

    ⛔ This is the direction no existing check covers, and it is the one that
    found the § 1.3 residue. The reachability ratchet reads the CODE schema, so
    a column dropped from code but still physically present in the tenant table
    is INVISIBLE to it. `vulnerabilities.severity_score` is exactly that: the
    archive records it removed 2026-08-13, and it is still in all three tenant
    schemas today.
    """
    sysf = system_fields()
    out: List[Finding] = []

    for table in sorted(set(declared) & set(live)):
        dec = {c.lower() for c in declared[table]}
        liv = {c.lower() for c in live[table]}

        for column in sorted(liv - dec):
            key = (table.lower(), column)
            if column in sysf:
                # Injected per-table by system_fields.py and therefore absent
                # from every entity schema BY DESIGN. Never drift.
                out.append(Finding(
                    table.lower(), column, "live_db", "present_but_undescribed",
                    "by_design",
                    "system field injected by system_fields.py — absent from "
                    "entity schemas by design.",
                ))
                continue
            archived_on = archive.get(key)
            if archived_on:
                out.append(Finding(
                    table.lower(), column, "live_db", "present_but_undescribed",
                    "archived_residue",
                    f"ARCHIVED on {archived_on} and removed from the code schema, "
                    f"but still physically present in the live table. § 1.3 "
                    f"residue — drop the column; do NOT re-declare it.",
                ))
            else:
                out.append(Finding(
                    table.lower(), column, "live_db", "present_but_undescribed",
                    "drift",
                    "present in the live table but declared by no schema class. "
                    "Either declare it (with a writer) or drop it.",
                ))

        for column in sorted(dec - liv):
            out.append(Finding(
                table.lower(), column, "live_db", "describes_but_absent", "drift",
                "declared in the code schema but ABSENT from the live table — "
                "the tenant provisioning path (_ensure_schema_columns) has not "
                "applied it, or a migration is pending.",
            ))

    return out


def reconcile_scope_convergence(
    *,
    declared: Dict[str, Sequence[str]],
    reachable_platform: Set[Key],
) -> List[Finding]:
    """⭐ The operator's rule, asserted directly (2026-08-18).

    *Every declared column has a writer* implies the DEFAULT schema answer and
    the `--reachable --scope platform` answer must be IDENTICAL on the 11 sink
    tables. Measured 2026-08-18: default=422, platform-reachable=418, and the
    entire 4-column gap is the writerless set. Fix those and the gap is 0
    (proven), so consumers get the same columns whether or not they pass
    `--reachable` — there is no "asking the wrong way".

    This is a DERIVED assertion (it re-reports what `reconcile_writers` found),
    so it emits no per-column findings. It exists as a named invariant the
    summary can state, so a regression is legible as *"the scopes diverged"*
    rather than only as *"one more shadow column"*.
    """
    return []


def scope_gap(
    *, declared: Dict[str, Sequence[str]], reachable_platform: Set[Key]
) -> Tuple[int, Tuple[Key, ...]]:
    """`(gap, columns)` — declared sink columns with no platform writer."""
    missing = tuple(sorted(
        (t.lower(), c.lower())
        for t, cols in declared.items()
        for c in (x.lower() for x in cols)
        if (t.lower(), c.lower()) not in reachable_platform
    ))
    return len(missing), missing


def _covers_overlay_tables(declared: Dict[str, Sequence[str]]) -> bool:
    """Does `declared` look like the REAL schema rather than an injected subset?

    True when every table the overlay describes is present in `declared`. The
    overlay only describes sink tables, so the real schema always covers it and a
    synthetic fixture essentially never does.
    """
    try:
        from pantheon_shared.datalake.schemas import load_semantic_model
        model = load_semantic_model()
    except Exception:
        return False
    overlay_tables = {
        (t.get("name") or "").strip().lower()
        for t in (model.get("tables") or [])
        if (t.get("name") or "").strip()
    }
    if not overlay_tables:
        return False
    return overlay_tables <= {t.lower() for t in declared}


def run_audit(
    *,
    declared: Dict[str, Sequence[str]],
    reachable_platform: Set[Key],
    live: Optional[Dict[str, Sequence[str]]] = None,
    archive: Optional[Dict[Key, str]] = None,
    model: Optional[Dict[str, Any]] = None,
    scope: str = "platform",
) -> AuditResult:
    """Reconcile every enumerated surface. Pure — all inputs are injected.

    Kept free of I/O so the same function serves the API, the CLI and the tests,
    and so a test can construct a drifting schema without a database. The
    callers do the fetching; this does the reasoning.
    """
    if archive is None:
        archive = archived_columns()

    # ⛔ The overlay is only reconcilable against the REAL schema. When a caller
    # injects a synthetic `declared` (tests, what-if analysis), loading the shipped
    # overlay would compare 200-odd real described columns against a handful of
    # injected ones and report every one as "describes-but-absent" — 21 phantom
    # findings, and a synthetic CLEAN schema exiting non-zero. That would make the
    # module untestable and, worse, teach a reader that a clean result is impossible.
    #
    # ⚠️ Detected by SHAPE, not by a flag the caller must remember to pass: a
    # `declared` that does not cover the overlay's own tables is not the real schema.
    if model is None and not _covers_overlay_tables(declared):
        model = {"tables": []}

    surfaces: List[str] = [
        "declared_schema (code)",
        "write_seam (platform reachability)",
        "semantic_overlay (query-hints)",
        "removed_columns_archive (guard)",
    ]

    findings: List[Finding] = []
    findings += reconcile_writers(
        declared=declared, reachable_platform=reachable_platform, archive=archive
    )
    findings += reconcile_overlay(
        declared=declared, reachable_platform=reachable_platform,
        archive=archive, model=model,
    )
    if live is not None:
        surfaces.append("live_db (information_schema)")
        findings += reconcile_live_schema(
            declared=declared, live=live, archive=archive
        )

    findings.sort(key=lambda f: (f.verdict != "drift", f.table, f.column, f.surface))

    counts: Dict[str, int] = {}
    for f in findings:
        counts[f.verdict] = counts.get(f.verdict, 0) + 1
        counts[f"direction:{f.direction}"] = counts.get(f"direction:{f.direction}", 0) + 1
    gap, _ = scope_gap(declared=declared, reachable_platform=reachable_platform)
    counts["scope_gap"] = gap
    counts["declared_columns"] = sum(len(c) for c in declared.values())
    counts["reachable_platform"] = len(reachable_platform)

    return AuditResult(
        findings=tuple(findings),
        surfaces=tuple(surfaces),
        scope=scope,
        counts=counts,
    )


def platform_reachable_keys(*, require_seam: bool = True) -> Set[Key]:
    """`{(table, column)}` writable at PLATFORM scope, via the write seam.

    ⛔ Delegates to the SAME path `measure_shadow_set()` uses, so the audit and
    the ratchet can never disagree about who can write what. In particular the
    `SeamRegistryEmpty` refusal is preserved: when the seam registry is empty
    the answer would report ~12 written columns as unwritable, so it RAISES
    rather than returning a confidently wrong set. "Could not verify" must
    never silently become "verified and clean" — that is the whole failure mode
    this subsystem exists to remove.
    """
    from pantheon_shared.datalake.reachability import build_reachability_map
    from pantheon_shared.datalake.shadow_baseline import (
        declared_schema,
        load_write_seam_modules,
    )

    load_write_seam_modules()
    declared = declared_schema()
    rmap = build_reachability_map(
        tables=sorted(declared), declared=declared, require_seam=require_seam
    )
    return {k for k, e in rmap.columns.items() if e.writers}
