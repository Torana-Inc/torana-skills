from typing import Dict, Any
from .base import TableSchema


class QuestionResolutionSchema(TableSchema):
    """Schema for the per-tenant ``question_resolution`` table.

    One row per question asked of the platform and the corpus id it resolved to —
    or did not. It is the DEMAND record: which questions people actually ask, and
    which the corpus cannot answer, so curation is driven by observed demand
    rather than by what someone imagined would be useful.

    ⛔ DECLARED HERE FOR THE SAME REASON AS ``join_trust`` — see
    ``JoinTrustSchema`` for the full account. In short: its only creator was the
    hand-written ``op.create_table`` in datalake revision
    ``s18_0001_question_resolution``, and the live tenant-creation path runs
    ``reconcile_tenant(data=False)``, whose target ``last_ddl_revision()``
    resolves to ``s18_0002_drop_unwritten``.

    ⭐ ``s18_0001`` is BEFORE that stop point, so — unlike ``join_trust`` — this
    table IS created on a fresh tenant today. It is declared anyway, for two
    reasons that are worth stating rather than leaving to chance:

      1. The protection is incidental. It survives only because no ``data``
         revision happens to sit before ``s18_0001``. Insert one and this table
         joins ``join_trust`` in being silently absent, with no code change
         anywhere and no signal until a write 500s.
      2. The rule in ``_create_schema_and_tables`` is not conditional: tenant
         tables are built from declared schema classes, never from hand-written
         DDL in a migration, because duplicating the definition is how the two
         mechanisms drift.

    ⚠️ NOT A SINK, and it carries NO reachability or write-seam claim. Nothing
    ingests it and no mapping writes it. It is platform BOOKKEEPING that lives
    per-tenant because the demand it records belongs to one tenant.

    ⛔ It is deliberately excluded from ``_NON_SDG_MANAGED_TABLES`` — that set is
    also the ``clear-all`` target list, and clearing this log would erase recorded
    demand, which is the one thing in it that cannot be regenerated.

    ⚠️ TWO COLUMNS ARRIVE THAT ``s18_0001`` DID NOT CREATE: ``trace_id`` and
    ``contributing_sources``, injected into every declared table by
    ``get_full_schema()``. Additive and unread here, but a real difference between
    a tenant provisioned from this class and one migrated by ``s18_0001``.

    System fields (IAM, lifecycle, audit, trace, provenance) are injected — do NOT
    declare them here.
    """

    @property
    def table_name(self) -> str:
        return "question_resolution"

    @property
    def primary_key(self) -> str:
        return "id"

    @property
    def description(self) -> str:
        return (
            "Log of questions asked of the platform and the corpus id each "
            "resolved to. The demand record that drives curation: an unresolved "
            "row is a question the corpus cannot answer yet. Platform "
            "bookkeeping — nothing ingests it and it carries no reachability claim."
        )

    @property
    def category(self) -> str:
        return "Platform Bookkeeping"

    @property
    def timestamp_column(self) -> str:
        return "resolved_at"

    @property
    def schema(self) -> Dict[str, Any]:
        return {
            "id": {
                "data_type": "UUID", "primary_key": True, "not_null": True,
                "category": "Core Identity",
                "semantic_description": (
                    "Surrogate key for one resolution attempt. Rows accumulate — "
                    "the same question asked twice is two rows, which is what makes "
                    "the log a measure of demand."
                ),
            },
            "asked_text": {
                "data_type": "TEXT", "not_null": True, "category": "Core Identity",
                "semantic_description": (
                    "What was asked, VERBATIM. ⛔ Deliberately not normalised — the "
                    "exact phrasing is the evidence, and normalising it would "
                    "destroy the signal about how people actually ask."
                ),
            },
            "question_id": {
                "data_type": "VARCHAR(32)", "category": "Verdict",
                "semantic_description": (
                    "The canonical corpus id this resolved to. ⭐ NULL is a RESULT, "
                    "not a failure: it records a question the corpus cannot answer, "
                    "which is precisely the demand signal curation reads."
                ),
            },
            "confidence": {
                "data_type": "NUMERIC(4,3)", "category": "Verdict",
                "semantic_description": (
                    "How certain the resolution was. NULL when unresolved, or when "
                    "the method carries no score of its own."
                ),
            },
            "method": {
                "data_type": "VARCHAR(32)", "not_null": True,
                "default": "unresolved", "category": "Verdict",
                "semantic_description": (
                    "exact | embedding | llm | unresolved — how the answer was "
                    "reached, so a curator can tell a lexical hit from a semantic "
                    "guess. ⚠️ 'unresolved' is an explicit named state, not a "
                    "stand-in for a missing value."
                ),
            },
            "alternatives": {
                "data_type": "JSONB", "not_null": True, "default": "[]",
                "category": "Verdict",
                "semantic_description": (
                    "The other candidates considered, with their scores. An empty "
                    "list means none were, never that none existed."
                ),
            },
            "resolved_at": {
                "data_type": "TIMESTAMP", "not_null": True, "category": "Verdict",
                "semantic_description": (
                    "When the resolution ran — the time axis the demand query reads."
                ),
            },
            "description": {
                "data_type": "TEXT", "not_null": True, "default": "",
                "category": "Core Identity",
                "semantic_description": (
                    "Semantic description of what this row records. Declared as a "
                    "business column deliberately — it is not an injected system "
                    "field."
                ),
            },
        }
