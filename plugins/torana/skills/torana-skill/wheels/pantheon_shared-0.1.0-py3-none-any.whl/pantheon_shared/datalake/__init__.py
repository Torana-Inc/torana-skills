"""
Unified Datalake Client for Pantheon Services.

This module provides a unified interface for interacting with various datalake backends
(DuckDB, Snowflake, PostgreSQL) through a single DatalakeClient interface.

All Pantheon services should use this unified client instead of backend-specific code.

Example:
    from pantheon_shared.datalake import DatalakeClient

    # Auto-selects backend from DATALAKE_BACKEND env var
    client = DatalakeClient()

    # Query data
    result = client.query("SELECT * FROM vulnerabilities", tenant_id="tenant-123")

    # Insert data
    client.insert("assets", [{"name": "asset1", "type": "host"}], tenant_id="tenant-123")
"""

from .client import DatalakeClient
from .types import QueryResult, UpsertResult, TableInfo, TenantContext
from .exceptions import (
    DatalakeError,
    ConnectionError,
    ValidationError,
    QueryError,
    TableNotFoundError,
    BackendNotSupportedError,
    ConfigurationError,
    TenantNotFoundError,
    OperationTimeoutError,
    LockConflictError
)
from .schemas import (
    TableSchema,
    IdentitySchema,
    RepositoriesSchema,
    VulnerabilitySchema,
    AssetsSchema,
    DatastoresSchema,
    ArtifactsSchema,
    FindingsSchema,
    IssuesSchema,
    ControlsSchema,
    PackagesSchema,
    EntityEdgesSchema,
    EntityEdgeCandidatesSchema,
    EntityGraphDerivationMetricsSchema,
    EntityPropertiesResolvedSchema,
    JoinTrustSchema,
    QuestionResolutionSchema,
    VmCveMetadataSchema,
    PentestCasesSchema,
    PentestRunsSchema,
    DatalakeTables
)
from .utils import get_duckdb_file, get_duckdb_directory, ensure_duckdb_directory
# The validated-provider filter (SCHEMA_SERVICES_FILTER). ⛔ ONE implementation shared by
# datalake, integration and agent-builder — three copies of a predicate this load-bearing
# would drift, and a drifted filter hides different columns on different surfaces.
from .provider_filter import (
    ENV_VAR as PROVIDER_FILTER_ENV_VAR,
    InvalidProviderFilter,
    KNOWN_PUSH_PATHS,
    configured_providers,
    filter_status,
    is_push_path,
    validate_or_raise,
    writer_survives,
)
from .progression_check import (
    check_progression,
    claims_progression,
    ProgressionReport,
    ProgressionFinding,
)
from .shape_routing import (
    route_sql,
    constant_warnings,
    shape_signature,
    shapes_from_diagnosis,
    ShapeRoute,
    ColumnUsage,
    ConstantWarning,
    DEPTH_FILL,
    DEPTH_SHAPE,
    DEPTH_VALUES,
)
# Widget row decomposition — the rows an aggregate cell was computed FROM.
# Lives here because BOTH the viz render path and the CLI must produce the same
# detail query for the same widget; a local copy in either would drift.
from .widget_decompose import (
    decompose_widget_sql,
    reconciliation_sql,
    sink_table_primary_keys,
    primary_keys_with_transformers,
    Decomposition,
    Metric,
    Projection,
    KIND_GROUPED,
    KIND_UNGROUPED,
    KIND_NOT_AGGREGATE,
    KIND_UNSUPPORTED,
)
# S12 / row 20z — ⛔ ONE validator every producer passes through (§ 7.7), so a
# new artifact type cannot bypass it. Exported here because five services create
# artifacts and none of them may hold their own copy of the rule.
from .artifact_intent import (
    Intent,
    IntentVerdict,
    MissingIntentError,
    parse_intent,
    validate_intent,
    require_intent,
    render_intent,
    grain_changed,
    INTENT_PARTS,
)

__all__ = [
    "decompose_widget_sql",
    "reconciliation_sql",
    "sink_table_primary_keys",
    "primary_keys_with_transformers",
    "Decomposition",
    "Metric",
    "Projection",
    "KIND_GROUPED",
    "KIND_UNGROUPED",
    "KIND_NOT_AGGREGATE",
    "KIND_UNSUPPORTED",
    # Artifact intent (S12 / row 20z)
    "Intent",
    "IntentVerdict",
    "MissingIntentError",
    "parse_intent",
    "validate_intent",
    "require_intent",
    "render_intent",
    "grain_changed",
    "INTENT_PARTS",
    # Client
    "DatalakeClient",

    # Types
    "QueryResult",
    "UpsertResult",
    "TableInfo",
    "TenantContext",

    # Exceptions
    "DatalakeError",
    "ConnectionError",
    "ValidationError",
    "QueryError",
    "TableNotFoundError",
    "BackendNotSupportedError",
    "ConfigurationError",
    "TenantNotFoundError",
    "OperationTimeoutError",
    "LockConflictError",

    # Schemas
    "TableSchema",
    "IdentitySchema",
    "RepositoriesSchema",
    "VulnerabilitySchema",
    "AssetsSchema",
    "DatastoresSchema",
    "ArtifactsSchema",
    "FindingsSchema",
    "IssuesSchema",
    "ControlsSchema",
    "PackagesSchema",
    "EntityEdgesSchema",
    "EntityEdgeCandidatesSchema",
    "EntityGraphDerivationMetricsSchema",
    "EntityPropertiesResolvedSchema",
    "JoinTrustSchema",
    "QuestionResolutionSchema",
    "VmCveMetadataSchema",
    "PentestCasesSchema",
    "PentestRunsSchema",
    "DatalakeTables",

    # Validated-provider filter (SCHEMA_SERVICES_FILTER) — ONE implementation, three
    # consumers (datalake, integration, agent-builder). See provider_filter.py.
    "PROVIDER_FILTER_ENV_VAR",
    "InvalidProviderFilter",
    "KNOWN_PUSH_PATHS",
    "configured_providers",
    "filter_status",
    "is_push_path",
    "validate_or_raise",
    "writer_survives",

    # Utilities
    "get_duckdb_file",
    "get_duckdb_directory",
    "ensure_duckdb_directory",

    # Shape routing (S6) — the value-axis depth a column needs, from how the
    # SQL uses it. ONE classifier shared by both text-to-SQL harnesses.
    "check_progression",
    "claims_progression",
    "ProgressionReport",
    "ProgressionFinding",
    "route_sql",
    "constant_warnings",
    "shape_signature",
    "shapes_from_diagnosis",
    "ShapeRoute",
    "ColumnUsage",
    "ConstantWarning",
    "DEPTH_FILL",
    "DEPTH_SHAPE",
    "DEPTH_VALUES",
]

# Metrics are imported lazily to avoid circular imports
# Access via: from pantheon_shared.datalake.metrics import get_datalake_metrics_registry
