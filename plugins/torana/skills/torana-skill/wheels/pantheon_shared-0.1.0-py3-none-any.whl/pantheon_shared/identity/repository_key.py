"""Canonical, source-neutral repository identity.

This is the single place that turns any flavour of repository reference — a git
remote (`git@github.com:org/repo.git`, `https://github.com/org/repo`), a SARIF
`versionControlProvenance.repositoryUri`, or an already-normalized host/org/repo
string — into one stable key.

Design decision D3 (see pantheon-docs/Torana_SARIF_Asset_Ingestion_Design.md):
the repository primary key is **source-neutral** so that the GitHub integration
sync, scanner-produced SARIF, and the asset-inventory skill all converge on the
SAME `repositories` row instead of creating per-source islands. `source_system`
becomes a plain column, never part of the primary key.

    asset_key            = normalize(host/org/repo)   # lowercased, scheme/.git stripped
    torana_repository_id = "repo:" + asset_key

Both ingestion streams (assets, SARIF) derive the key from their own payload, so
linkage is declarative — no DB lookup at ingest time, order-independent.
"""

from __future__ import annotations

import hashlib
import re
from urllib.parse import unquote as _unquote

__all__ = [
    "normalize_asset_key",
    "repository_id",
    "asset_key_from_git_remote",
    "asset_key_from_sarif_repo_uri",
    # Asset-graph (AG0) — polymorphic source-neutral keys (§ 3.3.1)
    "LEGAL_KEY_PREFIXES",
    "has_legal_prefix",
    "normalize_polymorphic_key",
    "cloud_key",
    "service_key",
    "host_key",
    "image_key",
    "gav_key",
    "pkg_key",
    "team_key",
    "datastore_key",
    "route_key",
    "route_path_slug",
    "edge_id",
]

REPOSITORY_ID_PREFIX = "repo:"

# ---------------------------------------------------------------------------
# Asset-graph polymorphic key schemes (Torana_Asset_Graph_Design.md § 3.3.1)
# ---------------------------------------------------------------------------
# The SINGLE SOURCE OF TRUTH for legal key-scheme prefixes (§ 3.6.2a). Three
# surfaces consume this exact set — the recognized-prefix validator (§ 3.6.1),
# the edge-endpoint type map (§ 3.6.3a), and the `via=[...]` traversal contract
# (§ 3.4.2). Adding a ninth scheme is a one-place edit here.
LEGAL_KEY_PREFIXES: frozenset[str] = frozenset({
    "repo:",      # code repo            -> repositories
    "cloud:",     # cloud resource       -> assets
    "service:",   # running service      -> assets (asset_type='service')
    "host:",      # host / node          -> assets
    "image:",     # container image      -> artifacts (by digest)
    "gav:",       # first-party artifact -> artifacts
    "pkg:",       # 3rd-party package    -> packages
    "team:",      # team / owner         -> identities (identity_type='team')
    "datastore:",  # data store           -> datastores (Bucket A / A3 — the `accesses` to-endpoint)
    # ⭐ HTTP ROUTE (F2, 2026-09-14). route:<namespace>/<ingress>/<path-slug> -> assets
    # (asset_type='http_route'). An Ingress host+path pair, so "which workload serves
    # demo.classie.dev/search?" is answerable.
    #
    # ⛔ NOT a property of the service, because a route is MANY-TO-MANY: one Ingress fans
    # out to many services and one service is reachable by several paths. Measured on CT:
    # 27 exposed_via edges collapse onto 5 endpoints, with EIGHT services sharing
    # demo.demo.classie.dev — so all 8 read equally internet-facing and a responder
    # triaging the finance agent gets the same answer as for an internal-only service.
    # The key encodes host AND path for that reason: keying on the ingress alone would
    # reproduce the collapse one level up. Spec: pantheon-integration/docs/F2_HTTP_ROUTE_NODES.md
    "route:",     # HTTP route           -> assets (asset_type='http_route')
})

# scp-like git remote, e.g. `git@github.com:org/repo.git`
_SCP_LIKE = re.compile(r"^(?P<user>[^/@]+)@(?P<host>[^:/]+):(?P<path>.+)$")
# URL scheme, e.g. `https://`, `ssh://`, `git://`
_SCHEME = re.compile(r"^[a-z][a-z0-9+.\-]*://")
# leading userinfo, e.g. `git@` or `user:pass@`
_LEADING_USERINFO = re.compile(r"^[^/@]+@")


def normalize_asset_key(reference: str) -> str:
    """Normalize any repository reference to a canonical `host/org/repo` key.

    Accepts git remotes (scp-like or URL), SARIF repository URIs, or an
    already-normalized key. Idempotent: ``normalize_asset_key(normalize_asset_key(x))``
    equals ``normalize_asset_key(x)``.

    Raises ``ValueError`` for empty / underivable input.
    """
    if reference is None:
        raise ValueError("repository reference must not be None")
    key = reference.strip().lower()
    if not key:
        raise ValueError("repository reference must not be empty")

    scp = _SCP_LIKE.match(key)
    if scp:
        # git@github.com:org/repo(.git) -> github.com/org/repo(.git)
        key = f"{scp.group('host')}/{scp.group('path')}"
    else:
        key = _SCHEME.sub("", key)

    key = _LEADING_USERINFO.sub("", key)  # strip embedded credentials at host position
    key = key.strip("/")
    if key.endswith(".git"):
        key = key[:-4]
    key = re.sub(r"/{2,}", "/", key)  # collapse duplicate slashes
    key = _strip_web_path(key)

    # A real repository key is always `host/path` — reject host-only or junk input.
    if "/" not in key:
        raise ValueError(f"could not derive an asset key from {reference!r}")
    return key


#: Path segments that begin a FORGE WEB PATH rather than part of the repository's
#: identity. `-` is GitLab's separator (`/group/repo/-/blob/...`); the rest are
#: GitHub/Gitea verbs. Bitbucket's `src` is included for the same reason.
_WEB_PATH_VERBS = frozenset({
    "-", "tree", "blob", "raw", "blame", "commit", "commits", "compare", "releases",
    "tags", "branches", "pull", "pulls", "merge_requests", "issues", "wiki", "actions",
    "src",
})

#: How many segments of `host/org/repo` must survive before a verb may truncate.
#: ⛔ A repository may legitimately BE called `tree` (`github.com/org/tree`), so a verb
#: is only a verb once the host and at least one owner + name are already accounted
#: for. GitLab subgroups nest deeper and are preserved because `-` marks their web
#: path explicitly.
_MIN_IDENTITY_SEGMENTS = 3


def _strip_web_path(key: str) -> str:
    """Drop a forge WEB PATH from a repository key, keeping the repository itself.

    ⛔ THE KEY IS A JOIN KEY, AND A PATH IN IT MATCHES NOTHING — FOREVER.
    An image built from a subfolder of a monorepo carries an OCI
    `org.opencontainers.image.source` label pointing at the FOLDER, not the repo:

        https://github.com/chainguard-images/images/tree/main/images/python

    Passed through unchanged that became
    `repo:github.com/chainguard-images/images/tree/main/images/python` — a key for a
    repository that does not exist. MEASURED on Classie 2026-09-28: 22 artifacts
    carried it, 22 `builds_image` edges were minted from it at HIGH confidence (the
    label's presence is the authoritative-provenance signal), and because the entity
    graph derives nodes from edge ENDPOINTS, that string is itself a phantom
    repository node in the estate.

    ⚠️ Worse than an absent key, not better: an artifact with a populated
    `torana_repository_id` READS as having known provenance, so a false attribution
    replaces a visible gap.

    ⭐ Truncating at the verb — rather than taking the first two path segments —
    preserves GitLab subgroups (`gitlab.com/group/sub/repo`), which legitimately nest
    deeper than `org/repo`.
    """
    parts = [p for p in key.split("/") if p]
    for i, seg in enumerate(parts):
        if i >= _MIN_IDENTITY_SEGMENTS and seg in _WEB_PATH_VERBS:
            return "/".join(parts[:i])
    return key


def repository_id(reference: str) -> str:
    """Return the canonical `torana_repository_id` for a repository reference.

    Accepts a raw remote/URI or an already-normalized key (normalization is
    idempotent), so callers never double-prefix.
    """
    if isinstance(reference, str) and reference.startswith(REPOSITORY_ID_PREFIX):
        reference = reference[len(REPOSITORY_ID_PREFIX):]
    return REPOSITORY_ID_PREFIX + normalize_asset_key(reference)


def asset_key_from_git_remote(remote: str) -> str:
    """Convenience alias: derive the asset key from a `git remote` URL."""
    return normalize_asset_key(remote)


def asset_key_from_sarif_repo_uri(uri: str) -> str:
    """Convenience alias: derive the asset key from a SARIF `repositoryUri`."""
    return normalize_asset_key(uri)


# ---------------------------------------------------------------------------
# Polymorphic, source-neutral asset keys (§ 3.3.1) + edge id (§ 3.3.3)
# ---------------------------------------------------------------------------

def has_legal_prefix(key: str) -> bool:
    """True iff ``key`` begins with one of the eight legal § 3.6.2a prefixes.

    This is the recognized-prefix gate behind § 3.6.1. It does not validate the
    body — only that the scheme is in the closed vocabulary.
    """
    if not isinstance(key, str):
        return False
    return any(key.startswith(p) for p in LEGAL_KEY_PREFIXES)


def _normalize_body(body: str) -> str:
    """Lowercase + strip + collapse duplicate slashes for a key body.

    Deliberately lighter than ``normalize_asset_key`` — image digests, purls and
    cloud self-links carry meaningful characters (``@``, ``:``) that the repo
    normalizer would mangle. We only lowercase, trim, and collapse `//`.
    """
    if body is None:
        raise ValueError("key body must not be None")
    out = body.strip().lower().strip("/")
    out = re.sub(r"/{2,}", "/", out)
    if not out:
        raise ValueError("key body must not be empty")
    return out


def _typed_key(prefix: str, body: str) -> str:
    """Build/normalize a `<prefix><body>` key, idempotent on the prefix."""
    if isinstance(body, str) and body.startswith(prefix):
        body = body[len(prefix):]
    return prefix + _normalize_body(body)


def normalize_polymorphic_key(key: str) -> str:
    """Normalize any of the eight key schemes idempotently.

    `repo:` routes through the canonical repository normalizer (host/org/repo,
    `.git`-stripped); every other scheme uses the lighter body normalizer so
    digests/purls/self-links survive intact.

    Raises ``ValueError`` if the key carries no legal § 3.6.2a prefix.
    """
    if not has_legal_prefix(key):
        raise ValueError(f"key {key!r} has no recognized scheme prefix")
    if key.startswith(REPOSITORY_ID_PREFIX):
        return repository_id(key)
    prefix = next(p for p in LEGAL_KEY_PREFIXES if key.startswith(p))
    return _typed_key(prefix, key[len(prefix):])


def cloud_key(provider: str, rtype: str, ident: str) -> str:
    """`cloud:<provider>/<type>/<id>` e.g. cloud:gcp/compute.instance/<self-link>."""
    return _typed_key("cloud:", f"{provider}/{rtype}/{ident}")


def service_key(env: str, name: str) -> str:
    """`service:<env>/<name>` — a logical running service."""
    return _typed_key("service:", f"{env}/{name}")


def host_key(provider: str, ident: str) -> str:
    """`host:<provider>/<id>` — a VM / GKE node."""
    return _typed_key("host:", f"{provider}/{ident}")


#: Docker Hub's canonical registry host, and the implicit namespace it gives a
#: single-segment ("official") image. `nginx` IS `docker.io/library/nginx`; the short
#: form is a CLI convenience, not a second image.
_DOCKER_HUB = "docker.io"
_DOCKER_HUB_LIBRARY = "library"
_DOCKER_HUB_ALIASES = ("index.docker.io", "registry-1.docker.io", "docker.io")


def _expand_docker_hub(ref: str) -> str:
    """Expand a Docker-Hub short reference to its fully-qualified form.

    ⛔ WHY THIS EXISTS. Producers disagree about how to spell the SAME image, and an
    unexpanded short name forms a perfectly VALID key that nothing else agrees with — no
    error, no DLQ entry, just a node that joins to nothing. Trivy's `RepoDigests` reports
    `alpine@sha256:…` and `pgvector/pgvector@sha256:…`, while the Kubernetes sync and the
    registry sync both write the qualified form, so a Trivy finding could never meet the
    image it was found in.

    The rule is Docker's own reference grammar: the first path segment is a REGISTRY only
    if it looks like a host — it contains a dot or a port, or is exactly `localhost`.
    Anything else is a Docker Hub namespace, and a bare name additionally takes the
    implicit `library/`.

    ⚠️ Applied to DIGEST-PINNED and tag refs alike; this only rewrites the name portion
    and never touches the `@sha256:` / `:tag` suffix.
    """
    body = ref.strip()
    if not body:
        return ref
    # Split the name from its digest/tag so a port (`host:5000`) is never mistaken for a
    # tag and a tag is never mistaken for a registry port.
    name, sep, suffix = body.partition("@")
    if not sep:
        head, colon, tail = body.rpartition(":")
        # A ':' introduces a REGISTRY PORT only when a '/' follows it (`localhost:5000/app`);
        # otherwise it is a TAG. Testing for '/' in the HEAD instead gets `alpine:3.19`
        # wrong — no slash anywhere, so the tag was read as a port, the name looked like a
        # host, and the ref was left unexpanded.
        if colon and "/" not in tail:
            name, sep, suffix = head, ":", tail
        else:
            name, sep, suffix = body, "", ""

    segments = name.split("/")
    first = segments[0]
    is_registry = ("." in first) or (":" in first) or first == "localhost"

    if is_registry:
        # Fold Docker Hub's aliases onto one spelling so the same image cannot arrive
        # under two registry names.
        if first in _DOCKER_HUB_ALIASES:
            segments[0] = _DOCKER_HUB
            if len(segments) == 2:
                segments.insert(1, _DOCKER_HUB_LIBRARY)
        name = "/".join(segments)
    elif len(segments) == 1:
        name = f"{_DOCKER_HUB}/{_DOCKER_HUB_LIBRARY}/{segments[0]}"
    else:
        name = f"{_DOCKER_HUB}/{name}"

    return f"{name}{sep}{suffix}" if sep else name


def drop_tag_when_pinned(ref: str) -> str:
    """`repo:tag@sha256:X` -> `repo@sha256:X`. The digest IS the image; the tag is a label that can move.

    ⛔ ONE KEY PER DIGEST. Kubernetes manifests pin both (`pause:3.10@sha256:X`) while the registry and the scanners write the
    digest alone, so one image was minted as two nodes: it was closed "no longer deployed" under one key while open and
    running under the other (Classie, 28 GKE system images). A ':' starts a TAG only when no '/' follows it (otherwise it is a
    registry port, `host:5000/app@sha256:X`). A reference without a digest keeps its tag: there the tag is all there is."""
    name, sep, digest = str(ref).partition("@")
    if not sep:
        return ref
    head, colon, tail = name.rpartition(":")
    if colon and tail and "/" not in tail and head and not head.endswith("/"):
        name = head
    return f"{name}@{digest}"


def image_key(ref: str) -> str:
    """`image:<registry/repo@sha256:digest>` — digest-pinned container image.

    ⭐ Short Docker Hub references are EXPANDED first (`nginx@sha256:…` ->
    `docker.io/library/nginx@sha256:…`), so every producer lands on one node for one
    image. See `_expand_docker_hub` for why an unexpanded name is worse than an error.
    """
    body = str(ref).strip()
    if body.startswith("image:"):
        body = body[len("image:"):]
    return _typed_key("image:", _expand_docker_hub(drop_tag_when_pinned(body)))


def gav_key(coords: str) -> str:
    """`gav:<group:artifact:version>` — first-party build artifact."""
    return _typed_key("gav:", coords)


def zip_artifact_key(code_sha256: str) -> str:
    """`gav:zip:sha256:<hex>` — a deployment ZIP, identified ONLY by its content.

    ⭐ WHY THIS EXISTS AT ALL. A container image carries a digest that the registry and
    the runtime BOTH report independently, which is what lets `builds_image` and
    `deployed_as` meet without the two observers ever coordinating. A ZIP has the same
    property — AWS computes `CodeSha256` from the bytes it received, and CI can compute
    the same hash from the bytes it shipped — but no shared node kind to converge ON.
    This is that node.

    ⛔ CONTENT-ADDRESSED, AND NOTHING ELSE IS IN THE KEY. Specifically NOT the function
    name and NOT the cloud:
      * the CI job that built the zip does not know where it will be deployed, so a
        target-specific key means the two observers compute different strings and the
        edge never forms — the exact non-convergence this module exists to prevent;
      * one zip deployed to three functions must be ONE artifact node with three
        `deployed_as` edges. Putting the function name in the coords makes it three
        nodes and silently breaks "what else is running this code?".

    ⚠️ HEX, NOT BASE64, AND THIS IS LOAD-BEARING. AWS returns `CodeSha256` as base64 of
    the raw digest; `sha256sum` emits hex. They must not both be accepted as-is or the
    two producers mint different keys for one artifact. Hex is chosen because
    `_typed_key` LOWERCASES, and base64 is case-sensitive — lowercasing it destroys the
    digest and makes it unrecoverable from the key, while hex passes through untouched.
    Base64 input is therefore CONVERTED here rather than rejected, so a caller holding
    either spelling lands on the same node.

    Accepts: 64-char hex, `sha256:<hex>`, base64 (with or without padding), or an
    already-built `gav:` key (idempotent, like `repository_id` and `image_key`).
    Raises ValueError on anything that is not a SHA-256, because a key built from a
    non-digest would form perfectly and match nothing for ever.
    """
    import base64 as _b64
    import binascii as _ba

    raw = str(code_sha256 or "").strip()
    if not raw:
        raise ValueError("zip_artifact_key: empty code_sha256")
    low = raw.lower()
    # Idempotent: tolerate a value that has already been keyed.
    for prefix in ("gav:zip:sha256:", "zip:sha256:", "sha256:"):
        if low.startswith(prefix):
            raw, low = raw[len(prefix):], low[len(prefix):]
            break
    if len(low) == 64 and all(c in "0123456789abcdef" for c in low):
        return _typed_key("gav:", f"zip:sha256:{low}")
    # base64 of the 32 raw bytes — AWS's spelling. Pad before decoding; `==` is often
    # stripped by shells and config files.
    b64 = raw + "=" * (-len(raw) % 4)
    try:
        decoded = _b64.b64decode(b64, validate=True)
    except (_ba.Error, ValueError) as exc:
        raise ValueError(
            f"zip_artifact_key: {code_sha256!r} is neither hex nor base64 SHA-256") from exc
    if len(decoded) != 32:
        raise ValueError(
            f"zip_artifact_key: decoded {len(decoded)} bytes, expected 32 (SHA-256)")
    return _typed_key("gav:", f"zip:sha256:{decoded.hex()}")


#: Percent-escape that must SURVIVE decoding. `%2F` is an encoded `/`, and a purl's
#: structure IS its slashes — decoding one would split a name into a namespace and
#: invent a path segment that no other producer writes.
_PURL_KEEP_ESCAPED = ("%2F", "%2f")
_PURL_SLASH_SENTINEL = "\x00purlslash\x00"


def _normalize_purl_body(body: str) -> str:
    """Canonicalise a purl so every producer of one package writes ONE key.

    ⛔ WHY THIS IS NOT `_normalize_body`. That helper lowercases, which is wrong for a
    purl, and does not decode, which is the defect. Two producers describing the SAME
    Debian package disagreed on BOTH counts (measured 2026-10-06 on
    pantheon-detection-framework@sha256:1a39920a, CVE-2026-33845):

        Container Analysis   pkg:deb/debian/libgnutls30@3.7.9-2+deb12u4      48 edges
        Trivy                pkg:deb/debian/libgnutls30@3.7.9-2%2bdeb12u4     0 edges

    CA builds its purl by concatenation and emits a literal `+`; Trivy emits the
    spec-correct `%2B`, which `_normalize_body` then lowercased to `%2b`. Neither is
    wrong on its own — but identity has to be ONE rule, and two rules mint two nodes.
    On demo, 75 of the 140 keys one Trivy image scan produces would have FORKED an
    existing package; 165 of 306 `pkg:deb/` rows carry a `+`, because `+deb12u4` is
    Debian's revision convention. Same for `%2B` in golang `+incompatible` and cargo.

    ⭐ DECODE, DO NOT ENCODE — chosen on measurement, not taste. Decoding is a NO-OP for
    every key Container Analysis has ever written (0 of 1,210 on demo, 0 of 547 on
    Classie carry an escape), so the whole migration is 865 Dependabot npm rows on one
    tenant. Standardising on the encoded form instead would have re-keyed every literal
    `+` GAR ever wrote, on every estate.

    ⚠️ CASE IS PRESERVED, and that is a change. Go module paths, Maven groupIds and
    GitHub orgs are case-sensitive, so lowercasing them loses identity rather than
    canonicalising it — `github.com/Masterminds/semver` is not `masterminds`. Verified
    safe before changing: across 816 live Container Analysis occurrences and two full
    Trivy reports, ZERO package names carry an uppercase character, so nothing in flight
    re-keys. The purl TYPE is still lowercased, which the purl spec does mandate.

    ⚠️ THIS FEEDS A PRIMARY KEY. A changed key INSERTs rather than updates and the old
    one is NOT retired (measured: a PyPI resync took the split from 110 to 155, not to
    0), so the one source that stores escaped keys — github/dependency_sbom, 865 rows
    on Classie — needs a deliberate re-key, not just a re-run.
    """
    if body is None:
        raise ValueError("key body must not be None")
    out = body.strip().strip("/")
    for esc in _PURL_KEEP_ESCAPED:
        out = out.replace(esc, _PURL_SLASH_SENTINEL)
    out = _unquote(out)
    out = out.replace(_PURL_SLASH_SENTINEL, "%2F")
    out = re.sub(r"/{2,}", "/", out)
    # The purl TYPE is lowercase by spec; everything after it keeps its case.
    head, sep, rest = out.partition("/")
    out = head.lower() + sep + rest
    if not out:
        raise ValueError("key body must not be empty")
    return out


def pkg_key(purl: str) -> str:
    """`pkg:<purl>` — third-party SBOM component (purl already carries `pkg:`).

    ⛔ Uses `_normalize_purl_body`, NOT `_normalize_body`: a purl is percent-encoded and
    case-significant, and treating it like a generic key body split one package into two
    graph nodes. See that function for the measurement.
    """
    body = purl[len("pkg:"):] if isinstance(purl, str) and purl.startswith("pkg:") else purl
    return "pkg:" + _normalize_purl_body(body)


def team_key(org_name: str) -> str:
    """`team:<org/name>` — owning team (the `owns`-edge `to` endpoint)."""
    return _typed_key("team:", org_name)


def datastore_key(provider: str, engine: str, ident: str) -> str:
    """`datastore:<provider>/<engine>/<id>` — a data store (the `accesses`-edge `to`
    endpoint). Bucket A / A3.

    Source-neutral by design (like ``cloud_key``): a compose-declared `torana-db`
    (``datastore:self-hosted/postgres/torana-db``) and a future cloud-observed Cloud SQL
    instance (``datastore:gcp/postgres/...``) are *different* nodes — different runtime
    realities — which the reconciliation layer relates, never force-merges (§ 3.9.1).

    Empty ``provider``/``engine`` segments collapse out, so a bare identifier still yields
    a legal key (``datastore:<ident>``); callers SHOULD pass ``self-hosted``/``unknown``
    rather than empty for clarity, but the builder is forgiving. Accepts an already-built
    ``datastore:`` value idempotently.
    """
    if isinstance(ident, str) and ident.startswith("datastore:"):
        return _typed_key("datastore:", ident[len("datastore:"):])
    body = "/".join(seg for seg in (str(provider or "").strip(),
                                    str(engine or "").strip(),
                                    str(ident or "").strip()) if seg)
    return _typed_key("datastore:", body)


#: Characters kept verbatim in a path slug. Everything else collapses to "-".
#: ⚠️ `/` is DELIBERATELY EXCLUDED — a slug must not reintroduce path separators, or
#: `_normalize_body` would treat the segments as key structure and two different routes
#: (`/api/v1` on ingress A, `/v1` on an ingress literally named `api`) could converge.
_ROUTE_SLUG_KEEP = re.compile(r"[^a-z0-9._-]+")


def route_path_slug(path: str) -> str:
    """Collapse a URL path into ONE key-safe segment.

    ⛔ THE ROOT PATH IS WHY THIS EXISTS. `_normalize_body` strips leading/trailing
    slashes, so the commonest ingress path of all — ``"/"`` — normalizes to the empty
    string and RAISES ``ValueError("key body must not be empty")``. Measured on the
    gke-twin fixture: 2 of 9 routes are ``"/"``. A builder that passed the raw path
    through would crash the pipeline on the most ordinary input in the dataset.

    ⭐ So the root becomes the literal ``root``, and every other path becomes a single
    slug with separators folded to ``-``:

        "/"         -> "root"
        "/admin"    -> "admin"
        "/api/v1"   -> "api-v1"
        "/a//b/"    -> "a-b"

    ⛔ KNOWN COLLAPSE, measured and accepted: a wildcard suffix folds away, so ``/api``
    and ``/api/*`` both slug to ``api``. An earlier draft of this docstring claimed they
    stayed distinct — that was WRONG, and checking it against the capture is what caught
    it. It is acceptable because standard Kubernetes expresses match mode in
    ``pathType`` (``Prefix``/``Exact``), NOT in the path string: all 9 routes in the
    gke-twin capture carry a clean path plus ``pathType: Prefix``. The ``/api/*`` form is
    a GCE-ingress annotation style.

    ⚠️ So if a cluster is ever seen mixing ``/api`` and ``/api/*`` in ONE ingress, those
    two routes WILL merge onto one node. The fix then is to fold ``pathType`` into the
    slug — deliberately not done now, because it would put a discriminator in every key
    to serve a shape no observed cluster uses, and an unused discriminator is how keys
    become unreadable.
    """
    if path is None:
        raise ValueError("route path must not be None")
    slug = _ROUTE_SLUG_KEEP.sub("-", str(path).strip().lower()).strip("-")
    # Everything collapsed away (the root "/", or a path of pure separators).
    return slug or "root"


def route_key(namespace: str, ingress: str, path: str) -> str:
    """`route:<namespace>/<ingress>/<path-slug>` — one HTTP route (F2).

    An Ingress host+path pair that reaches a workload, homed in ``assets`` as
    ``asset_type='http_route'``.

    ⛔ THE KEY ENCODES ALL THREE PARTS DELIBERATELY, and dropping any one of them
    reproduces a measured collapse:

    * **namespace** — F1's lesson. ``demo`` and ``edge`` front the SAME 19 service
      names on CT; keying without the namespace merged them onto one node, so one
      service appeared to have two hostnames. The gke-twin fixture reproduces this:
      ``/api`` exists in BOTH ``torana`` and ``torana-edge``, backed by a service of
      the same name in each.
    * **ingress** — two Ingress objects in one namespace legitimately serve the same
      path on different hosts.
    * **path** — the whole point of F2. Eight services share
      ``demo.demo.classie.dev`` on CT and all read equally internet-facing; the path
      is what separates them. Keying on the ingress alone would reproduce that
      collapse one level up.

    ⚠️ The HOST is deliberately NOT in the key. A route's host already has its own
    node (``cloud:<provider>/lb-endpoint/<host>``, reached by ``exposed_via``), and one
    Ingress rule can list several hosts for one path set — putting the host here would
    multiply otherwise-identical routes and split the very thing the ``routes_to`` edge
    is meant to join. The host is carried as a COLUMN on the route row, not in its
    identity.

    Idempotent on an already-built ``route:`` value, like every builder here.
    """
    if isinstance(namespace, str) and namespace.startswith("route:"):
        return _typed_key("route:", namespace)
    ns = (namespace or "").strip().lower() or "default"
    ing = (ingress or "").strip().lower() or "unknown"
    return _typed_key("route:", f"{ns}/{ing}/{route_path_slug(path)}")


def edge_id(record) -> str:
    """Deterministic `torana_edge_id` for an entity-graph edge (§ 3.3.3).

    ``sha256(tenant_id : from_key : to_key : edge_type)`` — confidence/evidence
    are intentionally excluded so re-derivation is idempotent. ``record`` is the
    ETL record (dict or _RecordProxy) carrying ``tenant_id`` (injected onto the
    record pre-pipeline on the push path), ``from_key``, ``to_key``, ``edge_type``.

    Accepts attribute or item access so it works for both a plain dict and the
    sandbox ``_RecordProxy``.
    """
    def _get(name: str):
        if hasattr(record, "get"):
            return record.get(name)
        return getattr(record, name, None)

    tenant_id = _get("tenant_id")
    from_key = _get("from_key")
    to_key = _get("to_key")
    edge_type = _get("edge_type")
    if not all([tenant_id, from_key, to_key, edge_type]):
        raise ValueError(
            "edge_id requires tenant_id, from_key, to_key, edge_type on the record"
        )
    raw = f"{tenant_id}:{from_key}:{to_key}:{edge_type}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()
