"""The scope row a connector read is recorded on (D21), and the entry key inside it.

A connector run reads one or more SCOPES (a Kubernetes cluster, an AWS account and region, a GCP
project). The read record (`assets.reads`, DS1a § 3.2.2) keeps one entry per data source on each
scope row, so asset_context can say "not checked" when a read failed or went stale instead of
concluding "no". The SAME key expressions live in asset_context's SQL
(`service_resolved.own_scope_key`, DS1a § 3.2.5); a contract test holds them together.
"""
import logging
from typing import Optional, Tuple

from pantheon_shared.identity.repository_key import cloud_key

_LOG = logging.getLogger(__name__)

#: ledger source -> (key provider, key type)
SCOPE_KINDS = {"kubernetes": ("k8s", "cluster"), "aws": ("aws", "account"), "gcp": ("gcp", "project")}

#: The asset_type of a scope row CREATED by the read record. No reader keys on these values; an
#: existing row keeps its own type (the writer preserves it).
SCOPE_ASSET_TYPE = {"kubernetes": "scope_cluster", "aws": "scope_account", "gcp": "scope_project"}
#: Every reader that lists assets as inventory filters these out (DS1a § 3.2.2 readers).
SCOPE_ASSET_TYPES = tuple(sorted(SCOPE_ASSET_TYPE.values()))

#: AWS error codes that mean "these credentials may not read this". In a region the operator did
#: NOT configure (the connection reads the default region list), they mean "this region is not
#: ours" (an SCP, an opt-in region) and the unit is EXCLUDED: no read entry, so services left over
#: there read not_measured, never "no". In a region the operator DID configure, they are a missing
#: permission the customer can grant: the unit FAILS with code permission_denied
#: (region_not_readable for an opt-in region), so Home names the IAM action.
AWS_DENIED_CODES = frozenset({"AccessDenied", "AccessDeniedException", "UnauthorizedOperation", "OptInRequired",
                              "UnrecognizedClientException", "AuthFailure"})

#: The codes a customer can fix in their own estate (a permission, an API switched off, a region
#: not enabled). A failed entry with one of these codes, or with a non-empty missing_permission, is
#: a Home line; any other failure (a timeout, throttling, a provider 5xx, a Torana error) is an ops
#: signal (DS1a § 3.2.8 g). The same literal is in posture_runtime_context
#: (`need_state.customer_fix`); a contract test holds them together.
CUSTOMER_FIX_CODES = frozenset({"permission_denied", "api_disabled", "region_not_readable"})


#: A bare word a Kubernetes unit key must never be: the name of a KIND of read (workloads, pods, configmaps, and any
#: other resource a reader lists) or no cluster at all. A kind goes in the sub-read part, '<cluster_ref>#<kind>', on the
#: real cluster row; a bare kind made `cloud:k8s/cluster/workloads`, one fake row shared by every cluster (G4 #5).
#: ⚠️ A cluster_ref is free text, so shape cannot tell a cluster from a kind word. A cluster must be configured with
#: its location (`<location>/<name>`, how GKE/EKS refs are written); a bare kind-word ref is dropped and logged.
NOT_A_CLUSTER = frozenset({
    "workloads", "pods", "configmaps", "manifest", "<unknown cluster>",
    "deployments", "statefulsets", "daemonsets", "replicasets", "jobs", "cronjobs", "services", "ingresses",
    "endpoints", "nodes", "namespaces", "secrets", "serviceaccounts", "persistentvolumes", "persistentvolumeclaims",
    "networkpolicies", "roles", "rolebindings", "clusterroles", "clusterrolebindings", "events", "images", "kinds",
})


def _split_unit(unit_key: str) -> Tuple[str, str]:
    """A unit key is '<scope>[/<region>][#<sub-read>]'. A sub-read ('#tags', '#stores') is a read
    of its own inside the scope (service tags, the scope's store list): it has its own entry and
    never stands in for the main read."""
    base, _, part = str(unit_key or "").partition("#")
    return base.strip(), part.strip().lower()


def is_sub_read(unit_key: str) -> bool:
    """True for a sub-read unit ('acct/r#tags'): its failure alone leaves the walk complete
    (DS1a § 3.2.10 c)."""
    return bool(_split_unit(unit_key)[1])


def scope_row_key(source: str, unit_key: str) -> Optional[str]:
    """The scope row for one ledger unit, or None for a source whose units are not scope rows
    (github, sarif …). AWS units are 'account/region'; the row is the ACCOUNT."""
    kind = SCOPE_KINDS.get(str(source or ""))
    k, _ = _split_unit(unit_key)
    if not kind or not k:
        return None
    if source == "kubernetes" and k.lower() in NOT_A_CLUSTER:
        _LOG.warning("scope_row_key refused a Kubernetes unit key that names a kind, not a cluster: %r "
                     "(key it '<cluster_ref>#<kind>'); its read record is dropped", unit_key)
        return None
    if source == "aws":
        k = k.split("/", 1)[0].strip()
        if not k:
            return None
    return cloud_key(kind[0], kind[1], k)


#: Separates an entry's BASE (what was read) from the integration that read it (Q1): two
#: connections reading the same scope keep one entry each, '<base>|<integration_id>'.
ENTRY_INTEGRATION_SEP = "|"

#: The platform's fixed read-freshness rule (D21): an ok entry whose ok_at is older than this is
#: stale. The same literal is in posture_runtime_context (`need_state`); a contract test holds them.
READ_FRESH_HOURS = 48


def scope_entry_key(source: str, data_source: str, unit_key: str, integration_id: str = "") -> str:
    """The key inside `reads`: the BASE — the data source, then ':<sub-read>' for a sub-read unit,
    then '@<region>' for an AWS regional unit — then '|<integration_id>' when an integration read it.
    'acct/eu-west-1' -> 'ecs_services@eu-west-1|<iid>'; 'acct/eu-west-1#tags' ->
    'ecs_services:tags@eu-west-1|<iid>'; 'acct/eu-west-1#stores' -> 'lambda_functions:stores@eu-west-1|<iid>';
    a region-less AWS unit 'acct#tags' -> 's3_buckets:tags|<iid>'; a GCP unit 'proj#stores' ->
    'cloud_run_services:stores|<iid>'."""
    base, part = _split_unit(unit_key)
    ds = f"{data_source}:{part}" if part else str(data_source)
    if source == "aws" and "/" in base:
        ds = f"{ds}@{base.split('/', 1)[1].strip().lower()}"
    iid = str(integration_id or "").strip()
    return f"{ds}{ENTRY_INTEGRATION_SEP}{iid}" if iid else ds


def entry_base(entry_key: str) -> str:
    """What an entry read, without the integration: 'ecs_services@eu-west-1|<iid>' -> 'ecs_services@eu-west-1'.
    Readers judge per BASE: measured when ANY entry with that base is ok and fresh (Q1)."""
    return str(entry_key or "").split(ENTRY_INTEGRATION_SEP, 1)[0]


def entry_integration(entry_key: str) -> str:
    """The integration that wrote an entry, '' for a legacy key (no '|')."""
    parts = str(entry_key or "").split(ENTRY_INTEGRATION_SEP, 1)
    return parts[1] if len(parts) == 2 else ""


def complete_marker(data_source: str, integration_id: str = "") -> str:
    """The '!complete' marker a complete walk sends: it drops THIS integration's stored entries of the
    data source older than the walk start (a legacy key, with no integration, is dropped by any
    marker of its data source). Never stored."""
    iid = str(integration_id or "").strip()
    return f"!complete:{data_source}" + (f"{ENTRY_INTEGRATION_SEP}{iid}" if iid else "")


def entry_base_sql(key_expr: str) -> str:
    """SQL for entry_base(): the one spelling every SQL reader uses (PDT posture_runtime_context, PPF Home,
    the retract gate). A contract test holds the literal copies in definitions.json to this text."""
    return f"split_part({key_expr}, '{ENTRY_INTEGRATION_SEP}', 1)"


def entry_fresh_ok_sql(value_expr: str) -> str:
    """SQL: the entry `value_expr` (a jsonb entry) is ok AND fresh (ok_at within READ_FRESH_HOURS). A base
    is measured when ANY of its entries satisfies this (Q1)."""
    return (f"(COALESCE(({value_expr} ->> 'ok')::boolean, FALSE) "
            f"AND COALESCE(({value_expr} ->> 'ok_at')::timestamptz >= NOW() - interval '{READ_FRESH_HOURS} hours', FALSE))")


def gcp_project_key(project_id: str) -> Optional[str]:
    p = str(project_id or "").strip()
    return cloud_key("gcp", "project", p) if p else None


__all__ = ["NOT_A_CLUSTER", "SCOPE_KINDS", "SCOPE_ASSET_TYPE", "SCOPE_ASSET_TYPES", "AWS_DENIED_CODES", "CUSTOMER_FIX_CODES",
           "ENTRY_INTEGRATION_SEP", "READ_FRESH_HOURS", "is_sub_read", "scope_row_key", "scope_entry_key",
           "entry_base", "entry_integration", "complete_marker", "entry_base_sql", "entry_fresh_ok_sql",
           "gcp_project_key"]
