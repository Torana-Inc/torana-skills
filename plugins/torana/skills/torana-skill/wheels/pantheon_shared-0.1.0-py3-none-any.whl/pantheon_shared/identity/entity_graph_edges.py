"""Asset-graph edge vocabulary (Torana_Asset_Graph_Design.md § 3.2.2, § 3.6.3a).

The closed set of edge types and the per-edge-type legal endpoint-prefix map.
Both derive from the single-source-of-truth prefix set in ``repository_key``
(``LEGAL_KEY_PREFIXES`` — § 3.6.2a), so there is exactly one place that defines
which key schemes are legal.

The endpoint map (§ 3.6.3a) cannot live in JSON Schema, which validates a field
in isolation rather than the relationship between two fields; it is enforced in
the edge ingestor. A mismatch is routed to the DLQ (reason
``invalid_edge_endpoints``), never raised — a raised exception aborts the whole
batch in the ETL pipeline.
"""

from __future__ import annotations

from .repository_key import LEGAL_KEY_PREFIXES

__all__ = [
    "EDGE_TYPES",
    "CONFIDENCE_LEVELS",
    "CONFIDENCE_RANK",
    "EDGE_ENDPOINT_MAP",
    "check_edge_endpoints",
]

# Closed edge-type vocabulary (§ 3.2.2).
EDGE_TYPES: frozenset[str] = frozenset({
    "builds",
    "builds_image",   # repo: ──builds_image──▶ image: — container build provenance (the gav-less analogue of `builds`, keyed from the image's OCI `image.source` label)
    "packaged_in",
    "contains",
    "depends_on",   # repo: ──depends_on──▶ pkg: — DECLARED dependency (scan/SCA side); the code-side analogue of `contains` (image→pkg, runtime). A package is a shared node, so repo→pkg must be an edge, not a column.
    "deployed_as",
    "declares",
    "exposed_via",
    "runs_on",
    "owns",
    "accesses",   # Bucket A / A3 — service: ──accesses──▶ datastore: ("which workloads touch a data store")
    # ⭐ RBAC (2026-08-26). cloud: ──grants──▶ cloud: — "this principal HOLDS that role".
    # ⛔ ONLY the cluster API can produce it. Cloud Asset Inventory publishes that a
    # binding EXISTS and nothing else: MEASURED on T1 across all 1,286 binding rows CAI
    # wrote, `roleRef` occurs 0 times and `subjects` 0 times — and those two fields ARE
    # the edge's endpoints. So the binding rows stay `not-a-graph-entity`, correctly: a
    # binding is the RELATIONSHIP, not a node that owns relationships.
    "grants",
    # ⭐ ROUTING (F2, 2026-09-14). route: ──routes_to──▶ service: — "this host+path pair
    # reaches that workload". The edge that makes "which workload serves
    # demo.classie.dev/search?" answerable; today the path is never stored.
    #
    # ⛔ DELIBERATELY NOT `exposed_via`, and the distinction is load-bearing. That edge's
    # consumer flips `assets.public_access`, which the reachable-CVE path reads as
    # internet-exposed. Overloading it would put ClusterIP services on it — the exact
    # false positive refused in #163, which would have marked ~44 internal services
    # internet-facing. `routes_to` asserts REACHABILITY BY A PATH and says nothing about
    # whether that path is public; `exposed_via` keeps its meaning unchanged.
    "routes_to",
    # ⭐ CONTAINMENT (#163, ratified 2026-08-15). cloud: ──part_of──▶ service: — "this
    # cloud-plane object is PART OF that running service". The k8s Service/Endpoints
    # objects that FRONT a workload, and (later) the controller-owned ReplicaSet/Pod rows.
    #
    # ⛔ IT EXISTS PRECISELY SO CONTAINMENT DOES NOT NEED A `service:` KEY. The tempting
    # alternative — key a Service/ReplicaSet/Pod as `service:<env>/<name>` so it merges
    # into the workload — is forbidden: #135 § 2.2 says a k8s Service must NOT be folded
    # into its workload (it is the thing that EXPOSES it), and ~10 ReplicaSets per service
    # would shatter ONE service into ten unjoinable nodes (#134). A duplicate node is
    # WORSE than a missing one: a missing node is absent, a duplicate splits the estate so
    # every join silently sees half of it.
    #
    # ⛔ AND IT IS DELIBERATELY NOT `exposed_via`. That was #163's originally-prescribed
    # remedy and it is UNSAFE: `reconcile.public_access` flips `assets.public_access` on
    # ANY inbound `exposed_via`, and the `reachable` CVE path reads that as internet-
    # exposed. CAI is metadata-only (#150), so these rows cannot reveal ClusterIP vs
    # LoadBalancer — emitting `exposed_via` would mark ~44 INTERNAL ClusterIP services
    # internet-facing, converting a false "not exposed" into a false "exposed" on the exact
    # question customers buy the product for. `part_of` asserts containment and NOTHING
    # about reachability, so no exposure verdict is derived from it.
    "part_of",
})

# Closed confidence vocabulary + ordered rank for monotonic-max (§ 3.2.7, § 3.3.3).
CONFIDENCE_LEVELS: frozenset[str] = frozenset({"low", "medium", "high", "authoritative"})
CONFIDENCE_RANK: dict[str, int] = {
    "low": 0,
    "medium": 1,
    "high": 2,
    "authoritative": 3,
}

# Per-edge-type legal endpoint prefixes (§ 3.6.3a). ``None`` for ``from`` means
# "any of the eight legal prefixes" (only ``owns`` uses this — a team can own a
# repo, a service, a cloud resource, …) but it is still drawn from the closed set.
EDGE_ENDPOINT_MAP: dict[str, tuple[frozenset[str] | None, frozenset[str]]] = {
    "builds":       (frozenset({"repo:"}),    frozenset({"gav:"})),
    "builds_image": (frozenset({"repo:"}),    frozenset({"image:"})),   # container build provenance (repo → image; no gav)
    "packaged_in":  (frozenset({"gav:"}),     frozenset({"image:"})),
    "contains":     (frozenset({"image:"}),   frozenset({"pkg:"})),
    "depends_on":   (frozenset({"repo:"}),    frozenset({"pkg:"})),   # declared dependency (scan/SCA); code-side analogue of contains
    "deployed_as":  (frozenset({"image:"}),   frozenset({"service:"})),
    "declares":     (frozenset({"repo:"}),    frozenset({"cloud:"})),
    "exposed_via":  (frozenset({"service:"}), frozenset({"cloud:"})),
    "runs_on":      (frozenset({"service:"}), frozenset({"host:"})),
    "owns":         (None,                    frozenset({"team:"})),  # from: any of the eight
    "accesses":     (frozenset({"service:"}), frozenset({"datastore:"})),  # A3
    # Containment (#163): a cloud-plane object is PART OF a running service. from: is
    # `cloud:` only — deliberately NOT `None`. A wide-open from-endpoint would let any
    # key claim membership of a service, and the whole point of this edge is that the
    # CONTAINED thing keeps its own identity rather than being folded into the container.
    "part_of":      (frozenset({"cloud:"}),   frozenset({"service:"})),
    # RBAC (2026-08-26): principal ──grants──▶ role. BOTH sides `cloud:`, deliberately.
    # A ServiceAccount and a ClusterRole are ALREADY `cloud:` nodes with a home in
    # `assets` — CAI keys them `cloud:<provider>/container.serviceaccount/<name>` and
    # `cloud:<provider>/container.clusterrole/<name>`. Minting a new `principal:`/`role:`
    # prefix would re-key 86 live rows and split every one from the inventory row
    # describing the same object — the identity-split failure three separate defects were
    # traced to on 2026-08-26. from: is `cloud:` only, not None, for the same reason
    # `part_of` narrows it: a wide-open from-endpoint would let any key claim a role.
    "grants":       (frozenset({"cloud:"}),   frozenset({"cloud:"})),
    # Routing (F2, 2026-09-14): an HTTP route reaches a workload. Both endpoints are
    # narrowed to ONE prefix — `route:` can only originate a route, and only a running
    # service can terminate one — for the same reason `part_of` and `grants` narrow
    # theirs: a wide-open endpoint lets any key claim the relationship, and a typed map
    # is what makes a malformed edge DLQ rather than land silently wrong.
    "routes_to":    (frozenset({"route:"}),   frozenset({"service:"})),
}


def _prefix_of(key: str) -> str | None:
    for p in LEGAL_KEY_PREFIXES:
        if isinstance(key, str) and key.startswith(p):
            return p
    return None


def check_edge_endpoints(edge_type: str, from_key: str, to_key: str) -> str | None:
    """Validate that an edge's endpoints are type-correct for its ``edge_type``.

    Returns ``None`` when the edge is valid, otherwise a short human-readable
    reason string (used as the DLQ ``invalid_edge_endpoints`` detail). The caller
    must route a non-None result to the DLQ and ``continue`` — it must NOT raise.
    """
    if edge_type not in EDGE_ENDPOINT_MAP:
        return f"unknown edge_type {edge_type!r}"

    from_allowed, to_allowed = EDGE_ENDPOINT_MAP[edge_type]
    from_prefix = _prefix_of(from_key)
    to_prefix = _prefix_of(to_key)

    if from_prefix is None:
        return f"from_key {from_key!r} has no legal scheme prefix"
    if to_prefix is None:
        return f"to_key {to_key!r} has no legal scheme prefix"

    # from_allowed is None -> any of the eight legal prefixes (already checked above)
    if from_allowed is not None and from_prefix not in from_allowed:
        return (
            f"edge_type {edge_type!r} requires from-prefix in "
            f"{sorted(from_allowed)}, got {from_prefix!r}"
        )
    if to_prefix not in to_allowed:
        return (
            f"edge_type {edge_type!r} requires to-prefix in "
            f"{sorted(to_allowed)}, got {to_prefix!r}"
        )
    return None
