"""
Database Query Builder with IAM Support

Provides a unified way to build queries with automatic tenant and namespace filtering
for all services that access SQL databases (PostgreSQL, DuckDB, etc.).
"""

from typing import Dict, Any, Optional, List, Union
from ..iam import IAMContext, get_or_create_default_namespace_id
from .. import get_logger

logger = get_logger(__name__)


class TenantAwareQueryBuilder:
    """
    Query builder that automatically adds tenant and namespace filtering to SQL queries.

    This class provides a fluent interface for building SQL queries with automatic
    IAM enforcement, ensuring proper data isolation across tenants.
    """

    def __init__(self, iam_context: IAMContext):
        """
        Initialize the query builder with IAM context.

        Args:
            iam_context: The IAM context containing tenant information
        """
        self.iam_context = iam_context
        self._reset()

    def _reset(self):
        """Reset the query builder for a new query."""
        self._select_fields = []
        self._table_name = None
        self._where_conditions = []
        self._order_by = []
        self._limit = None
        self._offset = None
        self._params = []
        self._distinct = False
        self._group_by = []
        self._having_conditions = []
        return self

    def select(self, *fields: str) -> 'TenantAwareQueryBuilder':
        """
        Add SELECT fields to the query.

        Args:
            *fields: Field names to select. Use '*' for all fields.

        Returns:
            Self for method chaining
        """
        self._select_fields.extend(fields)
        return self

    def from_table(self, table_name: str, qualified_name: Optional[str] = None) -> 'TenantAwareQueryBuilder':
        """
        Set the table to query from.

        Args:
            table_name: The table name
            qualified_name: Optional qualified name (e.g., database.schema.table)

        Returns:
            Self for method chaining
        """
        self._table_name = qualified_name or table_name
        return self

    def where(self, condition: str, *params: Any) -> 'TenantAwareQueryBuilder':
        """
        Add a WHERE condition.

        Args:
            condition: SQL condition string
            *params: Parameters for the condition

        Returns:
            Self for method chaining
        """
        self._where_conditions.append((condition, params))
        return self

    def where_in(self, field: str, values: List[Any]) -> 'TenantAwareQueryBuilder':
        """
        Add a WHERE IN condition.

        Args:
            field: The field name
            values: List of values

        Returns:
            Self for method chaining
        """
        placeholders = ','.join(['?' for _ in values])
        condition = f"{field} IN ({placeholders})"
        self._where_conditions.append((condition, values))
        return self

    def where_between(self, field: str, start: Any, end: Any) -> 'TenantAwareQueryBuilder':
        """
        Add a WHERE BETWEEN condition.

        Args:
            field: The field name
            start: Start value
            end: End value

        Returns:
            Self for method chaining
        """
        condition = f"{field} BETWEEN ? AND ?"
        self._where_conditions.append((condition, [start, end]))
        return self

    def order_by(self, field: str, desc: bool = False) -> 'TenantAwareQueryBuilder':
        """
        Add an ORDER BY clause.

        Args:
            field: Field name to order by
            desc: Whether to sort in descending order

        Returns:
            Self for method chaining
        """
        direction = "DESC" if desc else "ASC"
        self._order_by.append(f"{field} {direction}")
        return self

    def limit(self, limit: int) -> 'TenantAwareQueryBuilder':
        """
        Set the query limit.

        Args:
            limit: Maximum number of rows to return

        Returns:
            Self for method chaining
        """
        self._limit = limit
        return self

    def offset(self, offset: int) -> 'TenantAwareQueryBuilder':
        """
        Set the query offset.

        Args:
            offset: Number of rows to skip

        Returns:
            Self for method chaining
        """
        self._offset = offset
        return self

    def distinct(self) -> 'TenantAwareQueryBuilder':
        """
        Add DISTINCT to the query.

        Returns:
            Self for method chaining
        """
        self._distinct = True
        return self

    def group_by(self, *fields: str) -> 'TenantAwareQueryBuilder':
        """
        Add GROUP BY clause.

        Args:
            *fields: Fields to group by

        Returns:
            Self for method chaining
        """
        self._group_by.extend(fields)
        return self

    def having(self, condition: str, *params: Any) -> 'TenantAwareQueryBuilder':
        """
        Add a HAVING condition.

        Args:
            condition: SQL condition string
            *params: Parameters for the condition

        Returns:
            Self for method chaining
        """
        self._having_conditions.append((condition, params))
        return self

    def build(self, apply_iam_filter: bool = True) -> Dict[str, Any]:
        """
        Build the final query with IAM filtering.

        Args:
            apply_iam_filter: Whether to apply tenant/namespace filtering

        Returns:
            Dictionary with 'query' and 'params' keys
        """
        if not self._table_name:
            raise ValueError("Table name is required")

        # Get tenant info for IAM filtering
        tenant_id = self.iam_context.tenant_id
        namespace_id = get_or_create_default_namespace_id(self.iam_context)

        # Build SELECT clause
        if self._distinct:
            select_clause = "SELECT DISTINCT"
        else:
            select_clause = "SELECT"

        if self._select_fields:
            select_clause += " " + ", ".join(self._select_fields)
        else:
            select_clause += " *"

        # Build FROM clause
        query_parts = [select_clause, f"FROM {self._table_name}"]

        # Build WHERE clause
        all_where_conditions = []
        all_params = []

        # Add IAM filtering if requested
        if apply_iam_filter:
            iam_condition = "tenant_id = ? AND namespace_id = ?"
            all_where_conditions.append(iam_condition)
            all_params.extend([tenant_id, namespace_id])

        # Add user-defined WHERE conditions
        for condition, params in self._where_conditions:
            all_where_conditions.append(condition)
            all_params.extend(params)

        if all_where_conditions:
            query_parts.append("WHERE " + " AND ".join(all_where_conditions))

        # Add GROUP BY
        if self._group_by:
            query_parts.append("GROUP BY " + ", ".join(self._group_by))

        # Add HAVING conditions
        if self._having_conditions:
            having_parts = []
            for condition, params in self._having_conditions:
                having_parts.append(condition)
                all_params.extend(params)
            query_parts.append("HAVING " + " AND ".join(having_parts))

        # Add ORDER BY
        if self._order_by:
            query_parts.append("ORDER BY " + ", ".join(self._order_by))

        # Add LIMIT and OFFSET
        if self._limit is not None:
            query_parts.append(f"LIMIT {self._limit}")

        if self._offset is not None:
            query_parts.append(f"OFFSET {self._offset}")

        query = " ".join(query_parts)

        logger.info(
            "Built tenant-aware query",
            tenant_id=tenant_id,
            namespace_id=namespace_id,
            table=self._table_name
        )

        return {
            'query': query,
            'params': all_params
        }

    def count(self) -> Dict[str, Any]:
        """
        Build a COUNT query.

        Returns:
            Dictionary with 'query' and 'params' keys for COUNT query
        """
        # Save current state
        saved_select = self._select_fields[:]
        saved_order = self._order_by[:]
        saved_limit = self._limit
        saved_offset = self._offset
        saved_group = self._group_by[:]
        saved_having = []
        for condition, params in self._having_conditions:
            saved_having.append((condition, params[:]))

        # Build COUNT query
        self._select_fields = ["COUNT(*)"]
        self._order_by = []
        self._limit = None
        self._offset = None
        self._group_by = []
        self._having_conditions = []

        result = self.build()

        # Restore state
        self._select_fields = saved_select
        self._order_by = saved_order
        self._limit = saved_limit
        self._offset = saved_offset
        self._group_by = saved_group
        self._having_conditions = saved_having

        return result


class QueryExecutor:
    """
    Utility class for executing queries with IAM filtering.

    This class provides a simple interface for executing tenant-aware queries
    without worrying about the IAM details.
    """

    def __init__(self, backend, iam_context: IAMContext):
        """
        Initialize the query executor.

        Args:
            backend: The database backend instance
            iam_context: The IAM context
        """
        self.backend = backend
        self.iam_context = iam_context

    def query_table(
        self,
        table_name: str,
        filters: Optional[Dict[str, Any]] = None,
        limit: int = 100,
        offset: int = 0,
        order_by: Optional[str] = None,
        order_desc: bool = False
    ) -> List[Dict[str, Any]]:
        """
        Query a table with automatic tenant filtering.

        Args:
            table_name: Name of the table
            filters: Optional dictionary of filters
            limit: Maximum number of rows
            offset: Number of rows to skip
            order_by: Field to order by
            order_desc: Whether to sort descending

        Returns:
            List of query results
        """
        builder = TenantAwareQueryBuilder(self.iam_context)

        # Get qualified table name if backend supports it
        qualified_name = None
        if hasattr(self.backend, 'get_qualified_table_name'):
            qualified_name = self.backend.get_qualified_table_name(table_name)

        builder.select("*").from_table(table_name, qualified_name)

        # Add filters
        if filters:
            for field, value in filters.items():
                if isinstance(value, list):
                    builder.where_in(field, value)
                elif isinstance(value, dict) and 'between' in value:
                    builder.where_between(field, value['between'][0], value['between'][1])
                else:
                    builder.where(f"{field} = ?", value)

        # Add ordering
        if order_by:
            builder.order_by(order_by, order_desc)

        # Add pagination
        builder.limit(limit).offset(offset)

        # Build and execute query
        # Disable IAM filtering for transformer tables (they're already tenant-isolated)
        apply_iam_filter = not table_name.startswith('transformers.')
        query_dict = builder.build(apply_iam_filter=apply_iam_filter)

        if hasattr(self.backend, 'query_data_with_params'):
            # Backend supports parameterized queries
            return self.backend.query_data_with_params(
                query_dict['query'],
                query_dict['params'],
                tenant_id=self.iam_context.tenant_id
            )
        else:
            # Backend expects formatted query
            query = query_dict['query']
            for param in query_dict['params']:
                query = query.replace('?', f"'{param}'", 1)
            return self.backend.query_data(query, tenant_id=self.iam_context.tenant_id)

    def count_table(self, table_name: str, filters: Optional[Dict[str, Any]] = None) -> int:
        """
        Count rows in a table with automatic tenant filtering.

        Args:
            table_name: Name of the table
            filters: Optional dictionary of filters

        Returns:
            Count of rows
        """
        builder = TenantAwareQueryBuilder(self.iam_context)

        # Get qualified table name if backend supports it
        qualified_name = None
        if hasattr(self.backend, 'get_qualified_table_name'):
            qualified_name = self.backend.get_qualified_table_name(table_name)

        builder.from_table(table_name, qualified_name)

        # Add filters
        if filters:
            for field, value in filters.items():
                if isinstance(value, list):
                    builder.where_in(field, value)
                else:
                    builder.where(f"{field} = ?", value)

        # Build count query
        query_dict = builder.count()

        if hasattr(self.backend, 'query_data_with_params'):
            # Backend supports parameterized queries
            result = self.backend.query_data_with_params(query_dict['query'], query_dict['params'])
        else:
            # Backend expects formatted query
            query = query_dict['query']
            for param in query_dict['params']:
                query = query.replace('?', f"'{param}'", 1)
            result = self.backend.query_data(query)

        # Extract count from result
        if result and len(result) > 0:
            return result[0].get('count', 0)
        return 0


def add_tenant_filter_to_sql(
    query: str,
    iam_context: IAMContext,
    table_name: str = None,
    include_namespace: bool = True
) -> str:
    """
    Simple utility to add tenant filtering to an existing SQL query string.

    This is a convenience function for cases where you have an existing
    SQL query and need to add tenant filtering quickly.

    Args:
        query: The SQL query string
        iam_context: The IAM context
        table_name: Optional table name for logging
        include_namespace: Whether to include namespace filtering

    Returns:
        Query with tenant filtering applied
    """
    # Get tenant info
    tenant_id = iam_context.tenant_id
    namespace_id = get_or_create_default_namespace_id(iam_context)

    # Build tenant filter condition
    conditions = [f"tenant_id = '{tenant_id}'"]
    if include_namespace:
        conditions.append(f"namespace_id = '{namespace_id}'")

    iam_condition = " AND ".join(conditions)

    # Add WHERE clause
    if "WHERE" in query.upper():
        query += f" AND {iam_condition}"
    else:
        query += f" WHERE {iam_condition}"

    if table_name:
        logger.info(
            f"Added tenant filter to query",
            table=table_name,
            tenant_id=tenant_id,
            namespace_id=namespace_id if include_namespace else None
        )

    return query