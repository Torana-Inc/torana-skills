"""
Database Query Builder with IAM Support

Provides a unified way to build queries with automatic tenant and namespace filtering
for all services that access SQL databases (PostgreSQL, DuckDB, etc.).
"""

import re
from typing import Dict, Any, Iterable, Optional, List, Union
from ..iam import IAMContext, get_or_create_default_namespace_id
from .. import get_logger

logger = get_logger(__name__)


class FilterError(ValueError):
    """A filter the executor refuses to apply. ⛔ Never ignored: an ignored filter WIDENS the
    answer (more rows than asked, shown as if filtered), which no caller can tell from a real one.

    `code` is a stable machine word; a route maps this to a 422 that starts with it.
    """
    code = "invalid_filter"

    def __init__(self, message: str, *, field: Optional[str] = None,
                 operation: Optional[Any] = None):
        super().__init__(message)
        self.field = field
        self.operation = operation


class UnsupportedFilterOperation(FilterError):
    """An `operation` the executor cannot apply (unknown name, or a value of the wrong shape)."""
    code = "unsupported_operation"


class UnknownFilterColumn(FilterError):
    """A filter key or `order_by` that is not a column of the table (F28-sec).

    ⛔ Filter keys and `order_by` are written into the SQL as IDENTIFIERS, which no bind
    parameter can carry. Before F28-sec they went in raw, so a key such as
    `id = id OR 1=1 --` was SQL the caller wrote, past the tenant predicate.
    """
    code = "unknown_column"


#: A plain SQL identifier. Checked even when the caller passes no column allowlist.
_IDENTIFIER = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def quote_identifier(name: str) -> str:
    """`name` as a double-quoted SQL identifier (embedded quotes doubled)."""
    return '"' + str(name).replace('"', '""') + '"'


def _sql_literal(value: Any) -> str:
    """One value as a SQL literal, for a backend that cannot bind parameters.

    ⛔ Standard-conforming strings (Postgres's default since 9.1, and DuckDB's): a quote is
    escaped by doubling it and a backslash is literal. Before F28-sec values were pasted as
    `'{value}'` with no escaping, so a value holding `'` ended the literal.

    ⚠️ Every non-null value stays a QUOTED literal of `str(value)`, as before: an untyped
    literal the database coerces to the column's type (`'7'` against a numeric column compares
    numerically). Rendering 7 bare would turn `text_col = 7` into an operator error.
    """
    if value is None:
        return "NULL"
    text = str(value)
    if "\x00" in text:
        raise FilterError("a filter value may not contain a NUL byte")
    return "'" + text.replace("'", "''") + "'"


def inline_params(query: str, params: List[Any]) -> str:
    """`?` placeholders replaced by escaped literals in ONE pass.

    ⛔ One pass, not `str.replace('?', ..., 1)` per param: the old loop re-scanned text it had
    just inserted, so a value containing `?` received the NEXT value inside its literal.
    """
    parts = query.split("?")
    if len(parts) - 1 != len(params):
        raise ValueError(f"query has {len(parts) - 1} placeholders for {len(params)} params")
    out = [parts[0]]
    for value, tail in zip(params, parts[1:]):
        out.append(_sql_literal(value))
        out.append(tail)
    return "".join(out)


class TenantAwareQueryBuilder:
    """
    Query builder that automatically adds tenant and namespace filtering to SQL queries.

    This class provides a fluent interface for building SQL queries with automatic
    IAM enforcement, ensuring proper data isolation across tenants.
    """

    def __init__(self, iam_context: IAMContext):
        """
        Initialize the query builder with IAM context.

        Args:
            iam_context: The IAM context containing tenant information
        """
        self.iam_context = iam_context
        self._reset()

    def _reset(self):
        """Reset the query builder for a new query."""
        self._select_fields = []
        self._table_name = None
        self._where_conditions = []
        self._order_by = []
        self._limit = None
        self._offset = None
        self._params = []
        self._distinct = False
        self._group_by = []
        self._having_conditions = []
        return self

    def select(self, *fields: str) -> 'TenantAwareQueryBuilder':
        """
        Add SELECT fields to the query.

        Args:
            *fields: Field names to select. Use '*' for all fields.

        Returns:
            Self for method chaining
        """
        self._select_fields.extend(fields)
        return self

    def from_table(self, table_name: str, qualified_name: Optional[str] = None) -> 'TenantAwareQueryBuilder':
        """
        Set the table to query from.

        Args:
            table_name: The table name
            qualified_name: Optional qualified name (e.g., database.schema.table)

        Returns:
            Self for method chaining
        """
        self._table_name = qualified_name or table_name
        return self

    def where(self, condition: str, *params: Any) -> 'TenantAwareQueryBuilder':
        """
        Add a WHERE condition.

        Args:
            condition: SQL condition string
            *params: Parameters for the condition

        Returns:
            Self for method chaining
        """
        self._where_conditions.append((condition, params))
        return self

    def where_in(self, field: str, values: List[Any]) -> 'TenantAwareQueryBuilder':
        """
        Add a WHERE IN condition.

        Args:
            field: The field name
            values: List of values

        Returns:
            Self for method chaining
        """
        placeholders = ','.join(['?' for _ in values])
        condition = f"{field} IN ({placeholders})"
        self._where_conditions.append((condition, values))
        return self

    def where_between(self, field: str, start: Any, end: Any) -> 'TenantAwareQueryBuilder':
        """
        Add a WHERE BETWEEN condition.

        Args:
            field: The field name
            start: Start value
            end: End value

        Returns:
            Self for method chaining
        """
        condition = f"{field} BETWEEN ? AND ?"
        self._where_conditions.append((condition, [start, end]))
        return self

    def order_by(self, field: str, desc: bool = False) -> 'TenantAwareQueryBuilder':
        """
        Add an ORDER BY clause.

        Args:
            field: Field name to order by
            desc: Whether to sort in descending order

        Returns:
            Self for method chaining
        """
        direction = "DESC" if desc else "ASC"
        self._order_by.append(f"{field} {direction}")
        return self

    def limit(self, limit: int) -> 'TenantAwareQueryBuilder':
        """
        Set the query limit.

        Args:
            limit: Maximum number of rows to return

        Returns:
            Self for method chaining
        """
        self._limit = limit
        return self

    def offset(self, offset: int) -> 'TenantAwareQueryBuilder':
        """
        Set the query offset.

        Args:
            offset: Number of rows to skip

        Returns:
            Self for method chaining
        """
        self._offset = offset
        return self

    def distinct(self) -> 'TenantAwareQueryBuilder':
        """
        Add DISTINCT to the query.

        Returns:
            Self for method chaining
        """
        self._distinct = True
        return self

    def group_by(self, *fields: str) -> 'TenantAwareQueryBuilder':
        """
        Add GROUP BY clause.

        Args:
            *fields: Fields to group by

        Returns:
            Self for method chaining
        """
        self._group_by.extend(fields)
        return self

    def having(self, condition: str, *params: Any) -> 'TenantAwareQueryBuilder':
        """
        Add a HAVING condition.

        Args:
            condition: SQL condition string
            *params: Parameters for the condition

        Returns:
            Self for method chaining
        """
        self._having_conditions.append((condition, params))
        return self

    def build(self, apply_iam_filter: bool = True) -> Dict[str, Any]:
        """
        Build the final query with IAM filtering.

        Args:
            apply_iam_filter: Whether to apply tenant/namespace filtering

        Returns:
            Dictionary with 'query' and 'params' keys
        """
        if not self._table_name:
            raise ValueError("Table name is required")

        # Get tenant info for IAM filtering
        tenant_id = self.iam_context.tenant_id
        namespace_id = get_or_create_default_namespace_id(self.iam_context)

        # Build SELECT clause
        if self._distinct:
            select_clause = "SELECT DISTINCT"
        else:
            select_clause = "SELECT"

        if self._select_fields:
            select_clause += " " + ", ".join(self._select_fields)
        else:
            select_clause += " *"

        # Build FROM clause
        query_parts = [select_clause, f"FROM {self._table_name}"]

        # Build WHERE clause
        all_where_conditions = []
        all_params = []

        # Add IAM filtering if requested
        if apply_iam_filter:
            iam_condition = "tenant_id = ? AND namespace_id = ?"
            all_where_conditions.append(iam_condition)
            all_params.extend([tenant_id, namespace_id])

        # Add user-defined WHERE conditions
        for condition, params in self._where_conditions:
            all_where_conditions.append(condition)
            all_params.extend(params)

        if all_where_conditions:
            query_parts.append("WHERE " + " AND ".join(all_where_conditions))

        # Add GROUP BY
        if self._group_by:
            query_parts.append("GROUP BY " + ", ".join(self._group_by))

        # Add HAVING conditions
        if self._having_conditions:
            having_parts = []
            for condition, params in self._having_conditions:
                having_parts.append(condition)
                all_params.extend(params)
            query_parts.append("HAVING " + " AND ".join(having_parts))

        # Add ORDER BY
        if self._order_by:
            query_parts.append("ORDER BY " + ", ".join(self._order_by))

        # Add LIMIT and OFFSET
        if self._limit is not None:
            query_parts.append(f"LIMIT {self._limit}")

        if self._offset is not None:
            query_parts.append(f"OFFSET {self._offset}")

        query = " ".join(query_parts)

        logger.info(
            "Built tenant-aware query",
            tenant_id=tenant_id,
            namespace_id=namespace_id,
            table=self._table_name
        )

        return {
            'query': query,
            'params': all_params
        }

    def count(self, apply_iam_filter: bool = True) -> Dict[str, Any]:
        """
        Build a COUNT query.

        Args:
            apply_iam_filter: Whether to add the tenant/namespace predicate. Mirrors
                ``build()``'s parameter of the same name, and exists for the same
                reason: a transformer table is already tenant-isolated by its schema,
                so re-adding the predicate names columns it does not have. Defaults to
                True, so every existing caller keeps its current behaviour.

        Returns:
            Dictionary with 'query' and 'params' keys for COUNT query
        """
        # Save current state
        saved_select = self._select_fields[:]
        saved_order = self._order_by[:]
        saved_limit = self._limit
        saved_offset = self._offset
        saved_group = self._group_by[:]
        saved_having = []
        for condition, params in self._having_conditions:
            saved_having.append((condition, params[:]))

        # Build COUNT query
        self._select_fields = ["COUNT(*)"]
        self._order_by = []
        self._limit = None
        self._offset = None
        self._group_by = []
        self._having_conditions = []

        result = self.build(apply_iam_filter=apply_iam_filter)

        # Restore state
        self._select_fields = saved_select
        self._order_by = saved_order
        self._limit = saved_limit
        self._offset = saved_offset
        self._group_by = saved_group
        self._having_conditions = saved_having

        return result


class QueryExecutor:
    """
    Utility class for executing queries with IAM filtering.

    This class provides a simple interface for executing tenant-aware queries
    without worrying about the IAM details.
    """

    def __init__(self, backend, iam_context: IAMContext):
        """
        Initialize the query executor.

        Args:
            backend: The database backend instance
            iam_context: The IAM context
        """
        self.backend = backend
        self.iam_context = iam_context

    #: `{operation: sql}` for the `{"operation": ..., "value": ...}` filter shape the
    #: query routes already parse (`_extract_filters_from_args` emits exactly this).
    #:
    #: ⛔ WITHOUT THIS MAP THE DICT FELL THROUGH TO `field = ?` AND WAS BOUND AS A
    #: PYTHON DICT, producing `severity = '{'operation'...` — a 400 with a SQL syntax
    #: error, not a wrong result. So every operator except equals/in/between was
    #: BROKEN on this path, and a caller could not tell "unsupported" from "malformed".
    #: Verified against the live API before the fix.
    _OPERATION_SQL = {
        'equals': '{f} = ?',
        'not_equals': '{f} <> ?',
        'greater_than': '{f} > ?',
        'greater_than_equals': '{f} >= ?',
        'less_than': '{f} < ?',
        'less_than_equals': '{f} <= ?',
        'contains': '{f}::text LIKE ?',
        'contains_ignore_case': '{f}::text ILIKE ?',
        'starts_with': '{f}::text LIKE ?',
        'ends_with': '{f}::text LIKE ?',
    }

    #: Operators taking no value at all. Kept separate because a `?` placeholder with
    #: no parameter is a bind-count mismatch, not a no-op.
    _NULLARY_SQL = {
        'is_null': '{f} IS NULL',
        'is_not_null': '{f} IS NOT NULL',
    }

    #: Every operation name this executor applies: the canonical FilterOperation list of
    #: `pantheon_shared.query.models` (the FE's table-models.ts mirrors it).
    _KNOWN_OPERATIONS = frozenset(_OPERATION_SQL) | frozenset(_NULLARY_SQL) | {
        'in_list', 'not_in_list', 'between'}

    #: An empty IN list matches NO row. `IN ()` is a syntax error, and skipping the
    #: predicate would match EVERY row (the filter widens).
    _MATCH_NONE = '1 = 0'

    @classmethod
    def _canonical_operation(cls, op: Any) -> Optional[str]:
        """The canonical name for `op`, through the same alias map `FilterClause` uses
        (`gt`, `>`, `in`, `nin`, ...: one vocabulary); None when it is not an operation."""
        if not isinstance(op, str):
            return None
        if op in cls._KNOWN_OPERATIONS:
            return op
        from pantheon_shared.query.models import _OPERATION_ALIASES
        key = op.strip().lower()
        return _OPERATION_ALIASES.get(key) or (key if key in cls._KNOWN_OPERATIONS else None)

    @staticmethod
    def _range(field: str, value: Any, op: Any) -> tuple:
        if not isinstance(value, (list, tuple)) or len(value) != 2:
            raise UnsupportedFilterOperation(
                f"filter on {field!r}: 'between' needs a list of exactly 2 values [low, high], got {value!r}",
                field=field, operation=op)
        return value[0], value[1]

    @staticmethod
    def _column_index(columns: Optional[Iterable[str]]) -> Optional[Dict[str, str]]:
        """{exact name: name, lower name: name} for the allowlist; None when there is none.
        A lower-case alias that two real columns share is dropped (ambiguous)."""
        if columns is None:
            return None
        index: Dict[str, str] = {}
        lowered: Dict[str, Optional[str]] = {}
        for c in columns:
            c = str(c)
            index[c] = c
            low = c.lower()
            lowered[low] = None if (low in lowered and lowered[low] != c) else c
        for low, c in lowered.items():
            if c is not None:
                index.setdefault(low, c)
        return index

    @staticmethod
    def _column(field: Any, index: Optional[Dict[str, str]]) -> str:
        """The QUOTED column `field` names, or UnknownFilterColumn (F28-sec).

        With an allowlist (`columns=`), the key must be one of the table's columns (exact, or
        its unique case-insensitive match, so `Severity` keeps working against `severity`).
        Without one, it must at least be a plain identifier. Either way it is quoted.
        """
        name = str(field)
        if index is not None:
            real = index.get(name) or index.get(name.lower())
            if real is None:
                raise UnknownFilterColumn(f"{name!r} is not a column of this table", field=name)
            return quote_identifier(real)
        if not _IDENTIFIER.match(name):
            raise UnknownFilterColumn(f"{name!r} is not a plain column name", field=name)
        return quote_identifier(name)

    @classmethod
    def _apply_filters(cls, builder, filters: Optional[Dict[str, Any]],
                       columns: Optional[Iterable[str]] = None) -> None:
        """Every filter onto the builder, or a FilterError. ⛔ ONE function for `query_table`
        AND `count_table`: they are the row half and the count half of one question, so a
        predicate honoured by one and dropped by the other yields a total that disagrees with
        the page it paginates."""
        index = cls._column_index(columns)
        for field, value in (filters or {}).items():
            col = cls._column(field, index)
            if isinstance(value, list):
                if value:
                    builder.where_in(col, value)
                else:
                    builder.where(cls._MATCH_NONE)
            elif isinstance(value, dict) and 'between' in value:
                low, high = cls._range(field, value['between'], 'between')
                builder.where_between(col, low, high)
            elif isinstance(value, dict) and 'operation' in value:
                cls._apply_operation(builder, col, value, name=field)
            elif isinstance(value, dict):
                raise UnsupportedFilterOperation(
                    f"filter on {field!r} is an object with neither 'operation' nor 'between': "
                    f"use {{\"operation\": ..., \"value\": ...}}", field=field)
            else:
                builder.where(f"{col} = ?", value)

    @classmethod
    def _order_column(cls, order_by: Optional[str], columns: Optional[Iterable[str]]) -> Optional[str]:
        """`order_by` as a quoted, allowlisted column (F28-sec: it was interpolated raw)."""
        if not order_by:
            return None
        return cls._column(order_by, cls._column_index(columns))

    @classmethod
    def _apply_operation(cls, builder, field: str, spec: Dict[str, Any],
                         name: Optional[str] = None) -> None:
        """Translate one `{operation, value}` filter onto the builder. `field` is the SQL
        column expression; `name` is the caller's key, for error messages.

        ⛔ An UNKNOWN operation RAISES UnsupportedFilterOperation (F28). It used to be
        ignored, which widened the filter: the caller got unfiltered rows that looked
        filtered, a confident wrong answer. A refused request is visible; that one is not.
        """
        name = field if name is None else name
        raw_op = spec.get('operation')
        op = cls._canonical_operation(raw_op)
        value = spec.get('value')
        if op is None:
            raise UnsupportedFilterOperation(
                f"filter on {name!r}: unknown operation {raw_op!r}; supported: "
                f"{', '.join(sorted(cls._KNOWN_OPERATIONS))}", field=name, operation=raw_op)

        nullary = cls._NULLARY_SQL.get(op)
        if nullary:
            builder.where(nullary.format(f=field))
            return

        if op == 'between':
            low, high = cls._range(name, value, raw_op)
            builder.where_between(field, low, high)     # inclusive at both ends
            return

        if op in ('in_list', 'not_in_list'):
            # `where_in` owns the placeholder expansion; an empty list would otherwise
            # render `IN ()`, which is a Postgres syntax error.
            values = value if isinstance(value, (list, tuple)) else [value]
            if not values:
                if op == 'in_list':
                    builder.where(cls._MATCH_NONE)      # IN nothing matches nothing
                return                                  # NOT IN nothing excludes nothing
            if op == 'in_list':
                builder.where_in(field, list(values))
            else:
                placeholders = ', '.join('?' for _ in values)
                builder.where(f"{field} NOT IN ({placeholders})", *values)
            return

        template = cls._OPERATION_SQL[op]

        if op == 'contains' or op == 'contains_ignore_case':
            value = f"%{value}%"
        elif op == 'starts_with':
            value = f"{value}%"
        elif op == 'ends_with':
            value = f"%{value}"
        builder.where(template.format(f=field), value)

    @staticmethod
    def _is_schema_isolated(table_name: str, explicit: Optional[bool]) -> bool:
        """Does this relation rely on its SCHEMA for tenant isolation (no tenant_id)?

        ⭐ One helper so `query_table` and `count_table` can never answer differently —
        they are the row half and the count half of one question, and a disagreement
        shows up as a total that does not match the page it paginates.

        An explicit flag always wins. The `transformers.` prefix fallback is LEGACY: it
        is how this was inferred before callers could say so, and it is kept only so an
        untouched caller keeps its current behaviour. It is not a good signal — no
        `transformers` schema exists in the database, so any caller actually using that
        prefix to address a table was already broken.
        """
        if explicit is not None:
            return explicit
        return table_name.startswith('transformers.')

    def query_table(
        self,
        table_name: str,
        filters: Optional[Dict[str, Any]] = None,
        limit: int = 100,
        offset: int = 0,
        order_by: Optional[str] = None,
        order_desc: bool = False,
        tenant_isolated_by_schema: Optional[bool] = None,
        columns: Optional[Iterable[str]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Query a table with automatic tenant filtering.

        Args:
            table_name: Name of the table
            filters: Optional dictionary of filters
            limit: Maximum number of rows
            offset: Number of rows to skip
            order_by: Field to order by
            order_desc: Whether to sort descending
            columns: The table's real column names. ⛔ Pass them whenever filters or
                `order_by` come from a caller: every filter key and `order_by` must then be
                one of them (UnknownFilterColumn otherwise). Without it a key must still be
                a plain identifier. Keys are quoted either way (F28-sec).
            tenant_isolated_by_schema: True when the relation carries NO `tenant_id`
                column because it is already isolated by living in the tenant schema
                (transformer output tables). Such a table must NOT get a
                `WHERE tenant_id = ?` clause — it would fail with
                'column "tenant_id" does not exist'.

                ⚠️ Default None preserves the legacy inference below (name starts with
                `transformers.`). Pass it EXPLICITLY rather than relying on that: the
                prefix was doing two unrelated jobs at once — naming a schema AND
                signalling "skip IAM filtering" — and the schema half was wrong (no
                `transformers` schema exists; the tables live in `tenant_{id}`). A
                caller that correctly drops the bad prefix would silently lose the
                filter suppression too, and get a 500 instead.

        Returns:
            List of query results
        """
        builder = TenantAwareQueryBuilder(self.iam_context)

        # Get qualified table name if backend supports it
        qualified_name = None
        if hasattr(self.backend, 'get_qualified_table_name'):
            qualified_name = self.backend.get_qualified_table_name(table_name)

        builder.select("*").from_table(table_name, qualified_name)

        # Add filters (raises FilterError rather than drop one)
        self._apply_filters(builder, filters, columns)

        # Add ordering
        order_col = self._order_column(order_by, columns)
        if order_col:
            builder.order_by(order_col, order_desc)

        # Add pagination
        builder.limit(limit).offset(offset)

        # Build and execute query.
        # Transformer output tables are already tenant-isolated by their schema and
        # carry no tenant_id column, so IAM filtering must be skipped for them.
        query_dict = builder.build(
            apply_iam_filter=not self._is_schema_isolated(table_name, tenant_isolated_by_schema))

        if hasattr(self.backend, 'query_data_with_params'):
            # Backend supports parameterized queries
            return self.backend.query_data_with_params(
                query_dict['query'],
                query_dict['params'],
                tenant_id=self.iam_context.tenant_id
            )
        else:
            # Backend expects formatted query: escaped literals, one pass (F28-sec)
            query = inline_params(query_dict['query'], query_dict['params'])
            return self.backend.query_data(query, tenant_id=self.iam_context.tenant_id)

    def count_table(
        self,
        table_name: str,
        filters: Optional[Dict[str, Any]] = None,
        tenant_isolated_by_schema: Optional[bool] = None,
        columns: Optional[Iterable[str]] = None,
    ) -> int:
        """
        Count rows in a table with automatic tenant filtering.

        Args:
            table_name: Name of the table
            filters: Optional dictionary of filters
            tenant_isolated_by_schema: See `query_table` — MUST be passed the same
                value the paired `query_table` call gets, or the count and the rows
                scope differently.
            columns: See `query_table`; pass the same allowlist.

        Returns:
            Count of rows
        """
        builder = TenantAwareQueryBuilder(self.iam_context)

        # Get qualified table name if backend supports it
        qualified_name = None
        if hasattr(self.backend, 'get_qualified_table_name'):
            qualified_name = self.backend.get_qualified_table_name(table_name)

        builder.from_table(table_name, qualified_name)

        # ⛔ THE SAME `_apply_filters` AS `query_table`. The two are the row half and the
        # count half of ONE question ("which rows match these filters?"), so a predicate
        # honoured by one and dropped by the other yields a total that disagrees with the
        # page it is paginating (a `between` once counted as unfiltered here did exactly
        # that: the last pages came back empty with no error anywhere).
        self._apply_filters(builder, filters, columns)

        # Build count query.
        # ⛔ `apply_iam_filter` mirrors `query_table`: a transformer table is already
        # tenant-isolated by its schema, and adding the predicate again refers to
        # columns it does not have. Omitting this made the count either error or
        # disagree with the rows for every `transformers.*` table.
        query_dict = builder.count(
            apply_iam_filter=not self._is_schema_isolated(table_name, tenant_isolated_by_schema))

        # ⛔ `tenant_id=` IS REQUIRED, and its absence was a real defect: the backend
        # uses it to pick the tenant SCHEMA to run against (`tenant_<uuid>`), so
        # without it the count runs somewhere other than where `query_table` ran —
        # returning 0, or another tenant's number, for rows that plainly exist. The
        # SQL-level IAM predicate built above does not substitute for it; they scope
        # different things (rows vs. which schema is searched).
        if hasattr(self.backend, 'query_data_with_params'):
            # Backend supports parameterized queries
            result = self.backend.query_data_with_params(
                query_dict['query'],
                query_dict['params'],
                tenant_id=self.iam_context.tenant_id,
            )
        else:
            # Backend expects formatted query: escaped literals, one pass (F28-sec)
            query = inline_params(query_dict['query'], query_dict['params'])
            result = self.backend.query_data(
                query, tenant_id=self.iam_context.tenant_id)

        # Extract count from result
        if result and len(result) > 0:
            return result[0].get('count', 0)
        return 0


def add_tenant_filter_to_sql(
    query: str,
    iam_context: IAMContext,
    table_name: str = None,
    include_namespace: bool = True
) -> str:
    """
    Simple utility to add tenant filtering to an existing SQL query string.

    This is a convenience function for cases where you have an existing
    SQL query and need to add tenant filtering quickly.

    Args:
        query: The SQL query string
        iam_context: The IAM context
        table_name: Optional table name for logging
        include_namespace: Whether to include namespace filtering

    Returns:
        Query with tenant filtering applied
    """
    # Get tenant info
    tenant_id = iam_context.tenant_id
    namespace_id = get_or_create_default_namespace_id(iam_context)

    # Build tenant filter condition
    conditions = [f"tenant_id = '{tenant_id}'"]
    if include_namespace:
        conditions.append(f"namespace_id = '{namespace_id}'")

    iam_condition = " AND ".join(conditions)

    # Add WHERE clause
    if "WHERE" in query.upper():
        query += f" AND {iam_condition}"
    else:
        query += f" WHERE {iam_condition}"

    if table_name:
        logger.info(
            f"Added tenant filter to query",
            table=table_name,
            tenant_id=tenant_id,
            namespace_id=namespace_id if include_namespace else None
        )

    return query