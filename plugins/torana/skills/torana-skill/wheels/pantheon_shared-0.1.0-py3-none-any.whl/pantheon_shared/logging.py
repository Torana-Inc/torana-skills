"""
Pantheon Shared Logging Module

Unified structured logging configuration for all Pantheon microservices.
Provides JSON and console output with worker ID tracking and service-specific configurations.
"""

import logging
import sys
import os
import json
from datetime import datetime, timezone
from typing import Dict, Any, Optional, List, Tuple
import structlog

_logging_configured = False


def add_worker_info(logger, method_name: str, event_dict: dict) -> dict:
    """Add worker ID and process information to log entries"""
    event_dict["worker_id"] = os.getpid()
    event_dict["hostname"] = os.environ.get("HOSTNAME", "unknown")
    return event_dict


def add_trace_context(logger, method_name: str, event_dict: dict) -> dict:
    """
    Add trace context to log entries.

    Automatically includes:
    - Custom trace_id, span_id from TraceContext (business-level correlation)
    - OpenTelemetry trace_id, span_id from current OTel span (Jaeger correlation)

    This enables log correlation across services for distributed tracing.
    """
    # Add custom TraceContext (business-level correlation)
    try:
        from .tracing import get_current_trace_context
        trace_ctx = get_current_trace_context()
        if trace_ctx:
            event_dict["trace_id"] = trace_ctx.trace_id
            event_dict["span_id"] = trace_ctx.span_id
            if trace_ctx.parent_span_id:
                event_dict["parent_span_id"] = trace_ctx.parent_span_id
            # Business-level filter keys (S5/R2(B)): emitted as structured log
            # fields so Grafana/Loki can filter a whole conversation (session_id)
            # or a single turn (turn_id). Vector extracts these into Loki labels.
            if getattr(trace_ctx, "session_id", None):
                event_dict["session_id"] = trace_ctx.session_id
            if getattr(trace_ctx, "turn_id", None):
                event_dict["turn_id"] = trace_ctx.turn_id
    except ImportError:
        # Tracing module not available - skip
        pass
    except Exception:
        # Don't let trace context errors break logging
        pass

    # Add OpenTelemetry trace/span IDs (Jaeger correlation)
    try:
        from opentelemetry import trace
        current_span = trace.get_current_span()
        if current_span and current_span.is_recording():
            # Get the span context which contains trace_id and span_id
            span_context = current_span.get_span_context()
            if span_context and span_context.is_valid:
                # Convert OTel trace_id (16 bytes) and span_id (8 bytes) to hex strings
                otel_trace_id = span_context.trace_id.hex()
                otel_span_id = span_context.span_id.hex()
                event_dict["otel.trace_id"] = otel_trace_id
                event_dict["otel.span_id"] = otel_span_id
    except ImportError:
        # OpenTelemetry not available - skip
        pass
    except Exception:
        # Don't let OTel errors break logging
        pass

    return event_dict


def rename_event_to_message(logger, method_name: str, event_dict: dict) -> dict:
    """Rename 'event' field to 'message' for consistency"""
    if "event" in event_dict:
        event_dict["message"] = event_dict.pop("event")
    return event_dict


def json_serializer(event_dict: Dict[str, Any]) -> str:
    """Custom JSON serializer for optimal ELK integration"""
    # Move common fields to root level for better ELK parsing
    log_entry = {
        "timestamp": event_dict.pop("timestamp", ""),
        "level": event_dict.pop("level", "info"),
        "logger": event_dict.pop("logger", ""),
        "worker_id": event_dict.get("worker_id"),
        "hostname": event_dict.get("hostname"),
        "message": event_dict.pop("event", ""),
        "structured_data": event_dict  # Include all structured fields
    }
    return json.dumps(log_entry, default=str)


def custom_console_renderer(logger, method_name: str, event_dict: Dict[str, Any]) -> str:
    """Custom console renderer with simple key=value structured text format for Vector compatibility"""
    # Extract core values
    timestamp = event_dict.get("timestamp", "")
    level = event_dict.get("level", "info").lower()

    # Get the main message - check for both 'event' and 'message' keys
    message = event_dict.get("event") or event_dict.get("message", "")

    # Extract clean timestamp format (remove microseconds and timezone)
    if timestamp:
        try:
            from datetime import datetime
            # Parse ISO format and format cleanly
            dt = datetime.fromisoformat(timestamp.replace('Z', '+00:00'))
            clean_timestamp = dt.strftime("%Y-%m-%d %H:%M:%S UTC")
        except:
            clean_timestamp = timestamp[:19]  # Fallback: first 19 chars
    else:
        clean_timestamp = ""

    # Create simple key=value pairs - in preferred order
    log_parts = [
        f"level={level}"
    ]

    # Add message as quoted value to handle spaces and special chars
    if message:
        # Escape any quotes in the message
        safe_message = message.replace('"', '\\"')
        log_parts.append(f'message="{safe_message}"')

    # Add timestamp
    log_parts.append(f"timestamp={clean_timestamp}")

    # Add logger
    log_parts.append(f"logger={event_dict.get('logger', 'unknown')}")

    # Add worker_id
    log_parts.append(f"worker_id={event_dict.get('worker_id', os.getpid())}")

    # Add hostname if available and not unknown
    hostname = event_dict.get("hostname", os.environ.get("HOSTNAME", "unknown"))
    if hostname != "unknown":
        log_parts.append(f"hostname={hostname}")

    # Add additional structured fields as key=value pairs (excluding core fields)
    excluded_keys = {"timestamp", "level", "worker_id", "hostname", "logger", "event", "message"}

    for key, value in event_dict.items():
        if key not in excluded_keys and value is not None:
            # Convert value to string and escape special characters
            str_value = str(value).replace('"', '\\"')
            # Quote values with spaces
            if ' ' in str_value:
                log_parts.append(f'{key}="{str_value}"')
            else:
                log_parts.append(f'{key}={str_value}')

    # Join all parts with spaces
    formatted_message = " ".join(log_parts)

    # Add color coding for ERROR and WARNING levels in text mode (for development)
    if level == "error":
        # ANSI escape codes for red text (not background, to be less disruptive)
        red_text = "\033[91m"  # Bright red text
        reset = "\033[0m"  # Reset to default
        formatted_message = f"{red_text}{formatted_message}{reset}"
        # formatted_message = f"{formatted_message}"
    elif level == "warning":
        # ANSI escape codes for yellow/amber text
        yellow_text = "\033[93m"  # Bright yellow text
        reset = "\033[0m"  # Reset to default
        formatted_message = f"{yellow_text}{formatted_message}{reset}"
        # formatted_message = f"{formatted_message}"

    return formatted_message


def setup_logging(
    log_level: int = logging.INFO,
    service_name: Optional[str] = None,
    additional_loggers: Optional[Dict[str, int]] = None,
    show_config: bool = True,
    library_logging_mode: str = "quiet",
    custom_library_levels: Optional[List[str]] = None,
) -> None:
    """
    Configure structured logging for the application

    Args:
        log_level: Default logging level (default: INFO)
        service_name: Name of the service for logging output
        additional_loggers: Dictionary of logger names and their levels
        show_config: Whether to print configuration on startup
        library_logging_mode: "quiet" for minimal logging, "normal" for standard logging
        custom_library_levels: List of custom library level overrides in format "logger_name=LEVEL"
    """
    global _logging_configured

    # Prevent multiple configuration calls
    if _logging_configured:
        return

    # First, configure library logging levels
    setup_library_logging(library_logging_mode, custom_library_levels)

    # Configure structlog for structured logging
    log_format_type = "json" if os.getenv("LOG_FORMAT", "text") == "json" else "text"

    processors = [
        structlog.contextvars.merge_contextvars,  # Merge bind_contextvars() fields (run_id, etc.)
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        add_worker_info,  # Add worker_id, hostname
        add_trace_context,  # Add trace_id, span_id for distributed tracing
        rename_event_to_message,  # Rename 'event' to 'message' for consistency
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        structlog.processors.JSONRenderer() if log_format_type == "json" else custom_console_renderer,
    ]

    structlog.configure(
        processors=processors,
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
        wrapper_class=structlog.stdlib.BoundLogger,
    )

    # Configure standard logging to use structlog
    logging.basicConfig(
        format="%(message)s",  # Let structlog handle formatting
        stream=sys.stdout,
        level=log_level,
    )

    # Custom JSON formatter for optimal ELK integration
    if log_format_type == "json":
        # Use custom JSON formatter for standard logging to avoid recursion
        class CustomJSONFormatter(logging.Formatter):
            def format(self, record):
                message = record.getMessage()

                # Check if message is already JSON to avoid double encoding
                try:
                    parsed = json.loads(message)
                    # If this is already structured JSON, use it directly
                    if isinstance(parsed, dict) and ("event" in parsed or "message" in parsed):
                        log_entry = {
                            "timestamp": datetime.now(timezone.utc).isoformat() + "Z",
                            "level": record.levelname.lower(),
                            "logger": record.name,
                            "worker_id": os.getpid(),
                            "hostname": os.environ.get("HOSTNAME", "unknown"),
                            "message": parsed.get("message") or parsed.get("event", ""),
                            "logger_name": parsed.get("logger", record.name),
                            "module": record.module,
                            "function": record.funcName,
                            "line": record.lineno
                        }
                        # Add other fields if present
                        if "level" in parsed:
                            log_entry["level"] = parsed["level"]
                        if "worker_id" in parsed:
                            log_entry["worker_id"] = parsed["worker_id"]
                        if "timestamp" in parsed:
                            log_entry["timestamp"] = parsed["timestamp"]
                    else:
                        # Not structured JSON, treat as regular message
                        log_entry = {
                            "timestamp": datetime.now(timezone.utc).isoformat() + "Z",
                            "level": record.levelname.lower(),
                            "logger": record.name,
                            "worker_id": os.getpid(),
                            "hostname": os.environ.get("HOSTNAME", "unknown"),
                            "message": message,
                            "module": record.module,
                            "function": record.funcName,
                            "line": record.lineno
                        }
                except (json.JSONDecodeError, TypeError):
                    # Not valid JSON, treat as regular message
                    log_entry = {
                        "timestamp": datetime.now(timezone.utc).isoformat() + "Z",
                        "level": record.levelname.lower(),
                        "logger": record.name,
                        "worker_id": os.getpid(),
                        "hostname": os.environ.get("HOSTNAME", "unknown"),
                        "message": message,
                        "module": record.module,
                        "function": record.funcName,
                        "line": record.lineno
                    }

                if record.exc_info:
                    log_entry["exception"] = self.formatException(record.exc_info)
                return json.dumps(log_entry, default=str)

        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(CustomJSONFormatter())

        # Override JSON processor
        structlog.processors.JSONRenderer.serializer = json_serializer

        # Remove default handler and add ours
        root_logger = logging.getLogger()
        for h in root_logger.handlers[:]:
            root_logger.removeHandler(h)
        root_logger.addHandler(handler)
    else:
        # Fallback to text format for development - let structlog handle all formatting
        logging.basicConfig(
            format="%(message)s",  # Let structlog handle formatting
            stream=sys.stdout,
            level=log_level,
        )

    # Set service-specific loggers if provided (these override library settings)
    if additional_loggers:
        for logger_name, logger_level in additional_loggers.items():
            logging.getLogger(logger_name).setLevel(logger_level)

    # Log current configuration
    if show_config:
        service_prefix = f"{service_name} " if service_name else ""
        print(f"📋 {service_prefix}Logging Configuration:", flush=True)
        print(f"   LOG_LEVEL: {logging.getLevelName(log_level)}", flush=True)
        print(f"   LOG_FORMAT: {log_format_type}", flush=True)
        print(f"   LIBRARY_LOGGING_MODE: {library_logging_mode}", flush=True)
        print(f"   WORKER_ID: {os.getpid()} (enabled in all log entries)", flush=True)
        print(f"   COLOR FORMATTING: ANSI codes enabled (harmless if unsupported)", flush=True)

        if additional_loggers:
            print(f"   SERVICE LOGGERS: {len(additional_loggers)} configured", flush=True)
        if custom_library_levels:
            print(f"   CUSTOM LIBRARY LEVELS: {len(custom_library_levels)} overrides", flush=True)

    # Mark logging as configured
    _logging_configured = True


def get_structured_formatter():
    """Get a structured logging formatter for gunicorn"""
    if os.getenv("LOG_FORMAT", "text") == "json":
        return CustomJSONFormatter()
    else:
        return ColoredFormatter("[%(asctime)s] [PID:%(process)d] [%(name)s] [%(levelname)s] %(message)s",
                              datefmt="%Y-%m-%d %H:%M:%S")


def setup_library_logging(library_logging_mode: str = "quiet", custom_levels: List[str] | None = None) -> None:
    """
    Configure logging levels for third-party libraries.

    Args:
        library_logging_mode: "quiet" for minimal logging, "normal" for standard logging
        custom_levels: List of custom level overrides in format "logger_name=LEVEL"
    """

    # Define base logging levels based on mode
    if library_logging_mode == "quiet":
        base_levels = {
            # SQLAlchemy - reduce from INFO to WARNING to minimize SQL statement spam
            "sqlalchemy.engine": logging.WARNING,
            "sqlalchemy.pool": logging.WARNING,
            "sqlalchemy.orm": logging.WARNING,
            "sqlalchemy.dialects": logging.WARNING,

            # HTTP clients - reduce connection spam
            "urllib3.connectionpool": logging.WARNING,
            "requests.packages.urllib3": logging.WARNING,
            "aiohttp.access": logging.WARNING,

            # ASGI servers - reduce access log spam (use our own middleware)
            "uvicorn.access": logging.WARNING,
            "uvicorn.error": logging.INFO,

            # Asyncpg (PostgreSQL async driver)
            "asyncpg": logging.WARNING,

            # Keycloak client
            "python_keycloak": logging.WARNING,

            # HTTP libraries
            "httpx": logging.WARNING,
            "httpcore": logging.WARNING,
            "httpcore.connection": logging.WARNING,
            "httpcore.http11": logging.WARNING,

            # Other verbose libraries
            "kombu": logging.WARNING,  # Message queue library
            "celery": logging.WARNING,
            "redis": logging.WARNING,
        }
    elif library_logging_mode == "normal":
        base_levels = {
            # Standard logging levels for normal operation
            "sqlalchemy.engine": logging.INFO,
            "sqlalchemy.pool": logging.INFO,
            "sqlalchemy.orm": logging.INFO,
            "sqlalchemy.dialects": logging.INFO,
            "urllib3.connectionpool": logging.INFO,
            "requests.packages.urllib3": logging.INFO,
            "aiohttp.access": logging.INFO,
            "uvicorn.access": logging.INFO,
            "uvicorn.error": logging.INFO,
            "asyncpg": logging.INFO,
            "python_keycloak": logging.INFO,
            "httpx": logging.INFO,
            "httpcore": logging.INFO,
            "httpcore.connection": logging.INFO,
            "httpcore.http11": logging.INFO,
            "kombu": logging.INFO,
            "celery": logging.INFO,
            "redis": logging.INFO,
        }
    else:
        # Default to quiet for unknown modes
        base_levels = {
            "sqlalchemy.engine": logging.WARNING,
            "sqlalchemy.pool": logging.WARNING,
            "sqlalchemy.orm": logging.WARNING,
            "sqlalchemy.dialects": logging.WARNING,
            "urllib3.connectionpool": logging.WARNING,
            "requests.packages.urllib3": logging.WARNING,
            "aiohttp.access": logging.WARNING,
            "uvicorn.access": logging.WARNING,
            "uvicorn.error": logging.INFO,
            "asyncpg": logging.WARNING,
            "python_keycloak": logging.WARNING,
            "httpx": logging.WARNING,
            "httpcore": logging.WARNING,
            "httpcore.connection": logging.WARNING,
            "httpcore.http11": logging.WARNING,
            "kombu": logging.WARNING,
            "celery": logging.WARNING,
            "redis": logging.WARNING,
        }

    # Apply custom level overrides if provided
    if custom_levels:
        for level_override in custom_levels:
            try:
                if "=" in level_override:
                    logger_name, level_str = level_override.split("=", 1)
                    logger_name = logger_name.strip()
                    level_str = level_str.strip().upper()

                    # Convert string level to logging constant
                    if hasattr(logging, level_str):
                        level = getattr(logging, level_str)
                        base_levels[logger_name] = level
            except (ValueError, AttributeError):
                # Skip invalid level specifications
                continue

    # Apply the logging levels
    for logger_name, level in base_levels.items():
        logging.getLogger(logger_name).setLevel(level)

    # Configure standard logging format - let structlog handle all formatting
    logging.basicConfig(
        level=logging.INFO,
        format="%(message)s",  # Let structlog handle formatting
        stream=sys.stdout,
    )


def configure_structlog() -> None:
    """
    Configure structlog for structured logging across the application.

    This should be called after setup_library_logging() to ensure
    proper log level hierarchy.
    """
    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,  # Merge bind_contextvars() fields
            structlog.stdlib.filter_by_level,
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.stdlib.PositionalArgumentsFormatter(),
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.UnicodeDecoder(),
            structlog.processors.JSONRenderer(),
        ],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )


def get_library_log_levels() -> Dict[str, int]:
    """
    Get the current library log level configuration.

    Returns:
        Dictionary mapping logger names to their configured log levels.
    """
    return {
        "sqlalchemy.engine": logging.WARNING,
        "sqlalchemy.pool": logging.WARNING,
        "sqlalchemy.orm": logging.WARNING,
        "sqlalchemy.dialects": logging.WARNING,
        "urllib3.connectionpool": logging.WARNING,
        "requests.packages.urllib3": logging.WARNING,
        "aiohttp.access": logging.WARNING,
        "uvicorn.access": logging.WARNING,
        "uvicorn.error": logging.INFO,
        "asyncpg": logging.WARNING,
        "python_keycloak": logging.WARNING,
        "httpx": logging.WARNING,
        "httpcore": logging.WARNING,
        "httpcore.connection": logging.WARNING,
        "httpcore.http11": logging.WARNING,
        "kombu": logging.WARNING,
        "celery": logging.WARNING,
        "redis": logging.WARNING,
    }


def add_library_log_level(logger_name: str, level: int = logging.WARNING) -> None:
    """
    Add or update a library log level configuration.

    Args:
        logger_name: The logger name (e.g., 'sqlalchemy.engine')
        level: The logging level (default: logging.WARNING)
    """
    logging.getLogger(logger_name).setLevel(level)


def quiet_sqlalchemy() -> None:
    """
    Convenience function to specifically quiet SQLAlchemy logging.

    This sets all SQLAlchemy-related loggers to WARNING level.
    """
    sqlalchemy_loggers = [
        "sqlalchemy.engine",
        "sqlalchemy.pool",
        "sqlalchemy.orm",
        "sqlalchemy.dialects",
        "sqlalchemy.engine.base"
    ]

    for logger_name in sqlalchemy_loggers:
        logging.getLogger(logger_name).setLevel(logging.WARNING)


def get_logger(name: str = None) -> structlog.stdlib.BoundLogger:
    """Get a structured logger instance"""
    return structlog.get_logger(name)