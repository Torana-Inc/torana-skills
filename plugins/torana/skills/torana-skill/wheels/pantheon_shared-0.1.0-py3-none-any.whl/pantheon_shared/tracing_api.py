"""
Tracing control API endpoints for Pantheon services.

This module provides FastAPI endpoints to dynamically control
distributed tracing across all Pantheon services.
"""

from typing import Dict, Any
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from pantheon_shared.iam import IAMContext, has_permission
from pantheon_shared.iam.api import IAMEndpoint
from pantheon_shared.logging import get_logger

router = APIRouter()
logger = get_logger(__name__)


class TracingStateRequest(BaseModel):
    """Request model for setting tracing state"""
    enabled: bool


@router.get(
    "/tracing/status",
    response_model=Dict[str, Any],
    summary="Get tracing status",
    description="Retrieve current tracing status (enabled/disabled)",
    operation_id="get_tracing_status",
    tags=["tracing"],
    responses={
        200: {"description": "Tracing status retrieved successfully"},
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden - insufficient permissions"},
    },
    **has_permission("system:read").openapi_kwargs
)
async def get_tracing_status(iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)):
    """Get current tracing status"""
    from .tracing.state import is_tracing_enabled
    return {
        "status": "success",
        "data": {
            "tracing_enabled": is_tracing_enabled(),
            "description": "Distributed tracing is currently enabled" if is_tracing_enabled() else "Distributed tracing is currently disabled"
        }
    }


@router.put(
    "/tracing/status",
    response_model=Dict[str, Any],
    summary="Set tracing status",
    description="Enable or disable distributed tracing dynamically",
    operation_id="set_tracing_status",
    tags=["tracing"],
    responses={
        200: {"description": "Tracing status updated successfully"},
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden - insufficient permissions"},
    },
    **has_permission("system:admin").openapi_kwargs
)
async def set_tracing_status(
    request: TracingStateRequest,
    iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)
):
    """Set tracing status (enable/disable)"""
    from .tracing.state import set_tracing_enabled, is_tracing_enabled
    previous_state = is_tracing_enabled()
    set_tracing_enabled(request.enabled)

    logger.info(
        f"Tracing state changed via API",
        previous_state=previous_state,
        new_state=request.enabled,
        changed_by=iam_context.email if iam_context else "unknown",
        tenant_id=iam_context.tenant_id if iam_context else None,
    )

    return {
        "status": "success",
        "message": f"Tracing {'enabled' if request.enabled else 'disabled'}",
        "data": {
            "previous_state": previous_state,
            "current_state": request.enabled,
            "changed_by": iam_context.email if iam_context else "unknown",
            "tenant_id": iam_context.tenant_id if iam_context else None,
        }
    }


@router.post(
    "/tracing/enable",
    response_model=Dict[str, Any],
    summary="Enable tracing",
    description="Enable distributed tracing across all services",
    operation_id="enable_tracing",
    tags=["tracing"],
    responses={
        200: {"description": "Tracing enabled successfully"},
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden - insufficient permissions"},
    },
    **has_permission("system:admin").openapi_kwargs
)
async def enable_tracing(iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)):
    """Enable distributed tracing"""
    return await set_tracing_status(
        TracingStateRequest(enabled=True),
        iam_context
    )


@router.post(
    "/tracing/disable",
    response_model=Dict[str, Any],
    summary="Disable tracing",
    description="Disable distributed tracing across all services",
    operation_id="disable_tracing",
    tags=["tracing"],
    responses={
        200: {"description": "Tracing disabled successfully"},
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden - insufficient permissions"},
    },
    **has_permission("system:admin").openapi_kwargs
)
async def disable_tracing(iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)):
    """Disable distributed tracing"""
    return await set_tracing_status(
        TracingStateRequest(enabled=False),
        iam_context
    )


@router.get(
    "/tracing/info",
    response_model=Dict[str, Any],
    summary="Get tracing information",
    description="Retrieve detailed tracing configuration and status",
    operation_id="get_tracing_info",
    tags=["tracing"],
    responses={
        200: {"description": "Tracing information retrieved successfully"},
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden - insufficient permissions"},
    },
    **has_permission("system:read").openapi_kwargs
)
async def get_tracing_info(iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)):
    """Get detailed tracing information"""
    from .tracing.state import is_tracing_enabled
    import os

    return {
        "status": "success",
        "data": {
            "tracing_enabled": is_tracing_enabled(),
            "configuration": {
                "enable_otlp_trace": os.getenv("ENABLE_OTLP_TRACE", "false"),
                "otlp_endpoint": os.getenv("OTLP_ENDPOINT", "jaeger:4317"),
                "enable_console_trace": os.getenv("ENABLE_CONSOLE_TRACE", "false"),
                "use_simple_tracer": os.getenv("USE_SIMPLE_TRACER", "false"),
                "trace_sample_rate": os.getenv("TRACE_SAMPLE_RATE", "1.0"),
            },
            "description": "Current tracing configuration and status"
        }
    }


# Export the router for use in services
tracing_router = router
