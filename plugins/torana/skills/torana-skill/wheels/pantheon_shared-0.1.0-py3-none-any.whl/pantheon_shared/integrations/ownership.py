"""Does an integration belong to the caller's tenant? — ONE check for every service.

⛔ WHY THIS EXISTS. A request that NAMES an integration (an ingest stamping provenance with
`integration_id`, a route scoping a read to one integration) is a claim about another
tenant's object unless something checks it. Before this module each service either re-did
the lookup by hand or skipped it: pantheon-integration's `POST /ingest/entity-edges`
accepted ANY well-formed `integration_id` and wrote it into `contributing_sources`, so a
tenant could stamp its edges with another tenant's integration — and per-integration consent
then attributes (or purges) them under that integration.

⭐ USAGE (any service, from an async handler or job):

    from pantheon_shared.integrations.ownership import require_integration_in_tenant

    await require_integration_in_tenant(integration_id, tenant_id=str(iam.tenant_id))

East-west by default: a tenant-scoped service call to pantheon-integration's
`GET /api/v1/integrations/{id}`, which is tenant-scoped itself (404 for another tenant's id).
⛔ pantheon-integration must NOT call itself over HTTP — it passes `local_owner_lookup`, an
in-process `async (integration_id) -> owner tenant id | None`.

Raises `IntegrationNotInTenant` (a FastAPI HTTPException):
  * 404 — no such integration, OR it belongs to another tenant. Deliberately the SAME
    answer for both: a 403 would confirm to the caller that the id exists elsewhere.
  * 403 — the caller has no tenant to check against.
  * 503 — the owner could not be determined (lookup failed / integration service down).
    ⛔ FAILS CLOSED: an unverifiable claim is refused, never waved through.

⚠️ DB-session rule (root CLAUDE.md, defect B): `local_owner_lookup` must open, read and
CLOSE its own session; this module holds no session across the HTTP call.
"""

from __future__ import annotations

from typing import Any, Awaitable, Callable, Optional
from uuid import UUID

from fastapi import HTTPException

from pantheon_shared import get_logger

logger = get_logger(__name__)

#: In-process owner lookup: integration id -> owning tenant id, or None when unknown.
OwnerLookup = Callable[[str], Awaitable[Optional[Any]]]

_INTEGRATION_PATH = "/api/v1/integrations/{integration_id}"


class IntegrationNotInTenant(HTTPException):
    """The named integration is not the caller's (see module docstring for the codes)."""


def _norm(value: Any) -> str:
    """Canonical text of a tenant/integration id (UUIDs compare case-insensitively)."""
    s = str(value).strip()
    try:
        return str(UUID(s))
    except (ValueError, TypeError, AttributeError):
        return s


async def _owned_via_integration_service(integration_id: str, tenant_id: str,
                                         namespace_id: Optional[str],
                                         service_name: str) -> bool:
    """True when pantheon-integration returns the integration to a call scoped to
    `tenant_id`. Its GET route is tenant-scoped, so another tenant's id is a 404."""
    from pantheon_shared.http import PantheonClient
    from pantheon_shared.pantheon_services import PantheonService

    async with PantheonClient.for_service(
        service_name=service_name,
        target_service=PantheonService.INTEGRATION,
        tenant_id=tenant_id,
        namespace_id=namespace_id,
    ) as client:
        resp = await client.get(_INTEGRATION_PATH.format(integration_id=integration_id),
                                timeout=10.0)
    if resp.status_code == 200:
        return True
    if resp.status_code in (403, 404):
        return False
    raise RuntimeError(f"pantheon-integration answered {resp.status_code}")


async def require_integration_in_tenant(
    integration_id: Any,
    *,
    tenant_id: Any,
    namespace_id: Optional[Any] = None,
    local_owner_lookup: Optional[OwnerLookup] = None,
    service_name: str = "pantheon-shared",
) -> str:
    """Return the canonical `integration_id` when it belongs to `tenant_id`, else raise
    `IntegrationNotInTenant` (404 / 403 / 503 — see the module docstring)."""
    if not tenant_id:
        raise IntegrationNotInTenant(status_code=403,
                                     detail="No tenant to check the integration against")
    iid = _norm(integration_id)
    tid = _norm(tenant_id)
    not_yours = IntegrationNotInTenant(
        status_code=404, detail=f"Integration {iid} not found in this tenant")
    try:
        if local_owner_lookup is not None:
            owner = await local_owner_lookup(iid)
            owned = owner is not None and _norm(owner) == tid
        else:
            owned = await _owned_via_integration_service(
                iid, tid, str(namespace_id) if namespace_id else None, service_name)
    except IntegrationNotInTenant:
        raise
    except Exception as exc:      # noqa: BLE001 — fail CLOSED, with the cause logged
        logger.warning("integration ownership check failed integration=%s tenant=%s: %s",
                       iid, tid, exc)
        raise IntegrationNotInTenant(
            status_code=503,
            detail="Could not verify that the integration belongs to this tenant",
        ) from exc
    if not owned:
        raise not_yours
    return iid
