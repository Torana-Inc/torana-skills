"""Integration helpers shared by ETL, auth, and the api-gw proxy.

Exists so the three consumers of a templated `base_url` cannot drift apart — see
`base_url.py` for why that drift is a live onboarding trap (#168).
"""

from pantheon_shared.integrations.base_url import (
    TEMPLATED_HOST_SUFFIXES,
    normalize_host_value,
    render_base_url_template,
)

__all__ = [
    "TEMPLATED_HOST_SUFFIXES",
    "normalize_host_value",
    "render_base_url_template",
]
