"""#168 — ONE normaliser for templated integration `base_url`s.

⛔ THE DEFECT THIS EXISTS TO KILL. Two builders construct the same host from the same stored
credential and **disagree**:

  * `torana_mesh/etl/extractors/jira.py::_base_url` documents that it accepts
    `toranasecurity`, `x.atlassian.net`, `https://x.atlassian.net`, and even a stray TLD
    (`toranasecurity.ai`) **interchangeably**, and normalises all four.
  * `pantheon-api-gw/.../proxy_service.py` does a bare `.replace("{domain}", value)` into
    `https://{domain}.atlassian.net`, which accepts **only the bare form**.

Measured: **3 of the 4 documented-as-valid spellings produce a malformed host** through the
proxy — a doubled suffix (`x.atlassian.net.atlassian.net`) or a nested scheme
(`https://https://…`). Every real proxied call then fails.

⛔ AND HEALTH CANNOT SEE IT. `test_connection` runs the **normalising** ETL path, so the
integration reports `active` while every proxied call 502s. That is the false-green: the
signal operators trust is produced by the code path that is not broken.

⭐ SO THIS IS A LATENT ONBOARDING TRAP, NOT A LIVE OUTAGE. All four probes passed on the
current estate because its stored value happens to be the bare form. It fires on the next
tenant who types the natural full host — which is what the FE's own placeholder invites.

⚠️ OKTA HAS THE IDENTICAL SPLIT. `okta_api_spec.json` templates `https://{okta_domain}/api/v1`;
its ETL builder adds a scheme when missing, the proxy does not. Same class, same fix — which
is why this module is keyed by suffix rather than hardcoding Jira.

⭐ DIRECTION (ratified by the operator): **constrain the input instead of normalising after the
fact.** Declare the fixed suffix once, render it as an FE adornment so the user types only the
variable part, and have ETL + auth + proxy consume ONE shared normaliser. This module is that
normaliser. Normalising here is defence-in-depth for values already stored, not a licence to
keep accepting four spellings forever.
"""

from __future__ import annotations

import re
from typing import Mapping, Optional

#: Placeholder name -> the fixed suffix that belongs to it.
#:
#: A templated `base_url` such as `https://{domain}.atlassian.net` carries its suffix in the
#: TEMPLATE, so the stored credential must hold only the variable part. Anything a user typed
#: beyond that is what this table lets us strip back off.
#:
#: `okta_domain` maps to None: `https://{okta_domain}/api/v1` has NO fixed host suffix — the
#: full host is the variable. Scheme/slash normalisation still applies; suffix-stripping does
#: not, and silently stripping something here would corrupt a valid Okta host.
TEMPLATED_HOST_SUFFIXES: Mapping[str, Optional[str]] = {
    "domain": ".atlassian.net",
    "subdomain": ".atlassian.net",
    "okta_domain": None,
}

_SCHEME_RE = re.compile(r"^[a-zA-Z][a-zA-Z0-9+.\-]*://")


def normalize_host_value(value: str, suffix: Optional[str]) -> str:
    """Reduce a user-typed host value to the bare part a template expects.

    Accepts every spelling the ETL builder documents and returns the ONE form that is safe to
    substitute into a template:

        toranasecurity                       -> toranasecurity
        toranasecurity.atlassian.net         -> toranasecurity
        https://toranasecurity.atlassian.net -> toranasecurity
        toranasecurity.ai                    -> toranasecurity   (stray TLD, suffix known)

    ⚠️ The stray-TLD case is why `suffix` is required rather than inferred. Taking the first
    label unconditionally would turn a legitimate Okta host (`acme.okta.com`, no fixed suffix)
    into `acme` and break it. First-label extraction is only sound when we KNOW the suffix that
    should have been there, so it is gated on `suffix` being set.
    """
    v = (value or "").strip()
    if not v:
        return ""
    v = _SCHEME_RE.sub("", v)          # drop scheme -> prevents `https://https://…`
    v = v.strip("/")                   # drop stray slashes -> prevents `//` in the host
    if not v:
        return ""
    if suffix:
        if v.lower().endswith(suffix.lower()):
            v = v[: -len(suffix)]      # drop the suffix the TEMPLATE already supplies
        elif "." in v:
            v = v.split(".")[0]        # stray TLD (`x.ai`) — keep the label only
    return v.strip(".")


def render_base_url_template(template: str, credentials: Mapping[str, object]) -> str:
    """Substitute `{placeholder}`s in a base_url template, normalising host values first.

    This is the function the proxy must call instead of a bare `.replace()`. Placeholders not
    in `TEMPLATED_HOST_SUFFIXES` are substituted verbatim — they are not host values, so
    normalising them could corrupt real data.

    Empty/None credential values are left as an unsubstituted placeholder ON PURPOSE: emitting
    `https://.atlassian.net` would be a syntactically valid URL that fails at request time with
    a DNS error, which reads as a network problem. A surviving `{domain}` is unmistakably a
    configuration problem.
    """
    out = template or ""
    for key, raw in (credentials or {}).items():
        placeholder = "{%s}" % key
        if placeholder not in out:
            continue
        if raw in (None, ""):
            continue
        value = str(raw)
        if key in TEMPLATED_HOST_SUFFIXES:
            value = normalize_host_value(value, TEMPLATED_HOST_SUFFIXES[key])
            if not value:
                continue
        out = out.replace(placeholder, value)
    return out
