"""
Pantheon Unified ORM - Base Model

This module provides the PantheonDB base class that all Pantheon models should inherit from.
It provides automatic IAM field management, CRUD operations, and query builder factory.
"""

from sqlalchemy import Column, String, Boolean, DateTime, select, update, delete
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.dialects.postgresql import ENUM as PG_ENUM
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime, timezone
from typing import Optional, List, Dict, Any, Union
from uuid import UUID as PyUUID
from enum import Enum as PyEnum

from pantheon_shared.iam.context import IAMContext
from pantheon_shared import get_logger

logger = get_logger(__name__)


def _utc_now() -> datetime:
    """Get current UTC datetime using the new timezone-aware API."""
    return datetime.now(timezone.utc)


def _to_uuid(value: Union[str, PyUUID, None]) -> Optional[PyUUID]:
    """Convert string UUID to UUID object if needed."""
    if value is None:
        return None
    if isinstance(value, str):
        return PyUUID(value)
    return value


def _get_enum_value(cls, field: str, value: Any) -> Any:
    """
    Extract the appropriate value for enum columns.

    If the column is a native PostgreSQL enum and the value is a Python enum,
    extract the enum's value (string) for comparison.
    This fixes the issue where PantheonDB.filter() doesn't handle native PostgreSQL enums.

    Args:
        cls: The model class
        field: Field name to check
        value: Value to potentially convert

    Returns:
        The value to use for filtering (extracted enum value if needed)
    """
    if value is None:
        return None

    # Check if this is an enum column
    column = getattr(cls, field, None)
    if column and isinstance(column.type, PG_ENUM):
        # If value is a Python enum, extract its value
        if isinstance(value, PyEnum):
            return value.value
        # Otherwise return as-is (already a string)
        return value

    return value


def _get_tenant_filter_value(cls, column_name: str, value: Union[str, PyUUID, None]) -> Union[str, PyUUID, None]:
    """
    Get the appropriate filter value for tenant_id/namespace_id columns.
    Returns string if the column is String type, UUID if UUID type.
    This handles models that override tenant_id/namespace_id with String(255).
    """
    if value is None:
        return None
    # Check if the column is a String type (overridden in model)
    column = getattr(cls, column_name)
    if isinstance(column.type, String):
        return str(value)  # Keep as string
    return _to_uuid(value)  # Convert to UUID for UUID columns


class PantheonAuthDB:
    """
    Base model for identity primitives (Tenant, Namespace, User, Role, AuditLog).

    This class provides:
    - Nullable tenant_id and namespace_id (identity primitives may not have both)
    - Audit fields (created_at, updated_at, created_by, updated_by, is_deleted)
    - Soft delete support
    - Same CRUD methods as PantheonDB but handles nullable IAM fields

    Use this for models that are part of the identity system where:
    - Tenant is the root entity (has no tenant_id/namespace_id)
    - Namespace has tenant_id but no namespace_id
    - User has tenant_id but no namespace_id
    - AuditLog may have NULL tenant_id/namespace_id for system events

    For regular business entities, use PantheonDB instead.
    """

    # ===== IAM FIELDS (nullable for identity primitives) =====
    tenant_id = Column(
        PG_UUID(as_uuid=True),
        nullable=True,
        index=True,
        comment="Tenant ID for multi-tenancy (NULL for root Tenant entity)"
    )

    namespace_id = Column(
        PG_UUID(as_uuid=True),
        nullable=True,
        index=True,
        comment="Namespace ID for multi-tenancy (NULL for tenant-scoped entities)"
    )

    is_deleted = Column(
        Boolean,
        default=False,
        nullable=False,
        index=True,
        comment="Soft delete flag"
    )

    # ===== AUDIT FIELDS (automatic) =====
    created_at = Column(
        DateTime(timezone=True),
        default=_utc_now,
        nullable=False,
        comment="Creation timestamp (auto-set)"
    )

    updated_at = Column(
        DateTime(timezone=True),
        default=_utc_now,
        onupdate=_utc_now,
        nullable=False,
        comment="Last update timestamp (auto-set)"
    )

    created_by = Column(
        String(255),
        nullable=False,
        default="system",
        comment="User ID who created the record"
    )

    updated_by = Column(
        String(255),
        nullable=False,
        default="system",
        comment="User ID who last updated the record"
    )

    # ===== TIER 1: SIMPLE CRUD METHODS =====

    @classmethod
    async def create(
        cls,
        db: AsyncSession,
        iam: IAMContext,
        data: Dict[str, Any]
    ):
        """
        Create a new record with AUTOMATIC IAM field assignment.

        IAM fields set automatically:
        - tenant_id: From IAMContext (if model has this field)
        - namespace_id: From IAMContext (if model has this field)
        - created_by: From IAMContext.user_id
        - updated_by: From IAMContext.user_id

        Args:
            db: Async database session
            iam: IAM context (required - enforces IAM safety)
            data: Dictionary with model data (IAM fields will be set automatically)

        Returns:
            Created model instance
        """
        # Only set IAM fields if they exist in the model (check if column is defined)
        # This allows models to override/remove IAM fields they don't need
        if hasattr(cls, 'tenant_id'):
            data["tenant_id"] = iam.tenant_id
        if hasattr(cls, 'namespace_id') and iam.namespace_id:
            data["namespace_id"] = iam.namespace_id

        user_id_str = str(iam.user_id) if iam.user_id else "system"
        data["created_by"] = user_id_str
        data["updated_by"] = user_id_str

        # Create instance
        obj = cls(**data)
        db.add(obj)
        await db.commit()
        await db.refresh(obj)

        return obj

    @classmethod
    async def get_by_id(
        cls,
        db: AsyncSession,
        iam: IAMContext,
        obj_id: PyUUID,
        cross_tenant: bool = False
    ) -> Optional:
        """
        Get a record by ID with AUTOMATIC tenant filtering (if applicable).

        Args:
            db: Async database session
            iam: IAM context
            obj_id: UUID of the record
            cross_tenant: Allow cross-tenant access (requires permission)

        Returns:
            Model instance or None if not found
        """
        stmt = select(cls).where(cls.id == obj_id)
        stmt = stmt.where(cls.is_deleted == False)

        # Only apply tenant filtering if the model has these fields
        if not cross_tenant:
            if hasattr(cls, 'tenant_id'):
                stmt = stmt.where(cls.tenant_id == iam.tenant_id)
            if hasattr(cls, 'namespace_id') and iam.namespace_id:
                stmt = stmt.where(cls.namespace_id == iam.namespace_id)

        result = await db.execute(stmt)
        return result.scalar_one_or_none()

    @classmethod
    async def filter(
        cls,
        db: AsyncSession,
        iam: IAMContext,
        filters: Dict[str, Any],
        limit: Optional[int] = None,
        offset: int = 0
    ) -> List:
        """
        Filter records with AUTOMATIC tenant filtering (if applicable).

        Args:
            db: Async database session
            iam: IAM context
            filters: Dictionary of field/value pairs to filter by
            limit: Optional limit for pagination
            offset: Optional offset for pagination

        Returns:
            List of model instances
        """
        stmt = select(cls).where(cls.is_deleted == False)

        # Only apply tenant filtering if the model has these fields
        if hasattr(cls, 'tenant_id'):
            stmt = stmt.where(cls.tenant_id == iam.tenant_id)
        if hasattr(cls, 'namespace_id') and iam.namespace_id:
            stmt = stmt.where(cls.namespace_id == iam.namespace_id)

        # Apply filters
        for field, value in filters.items():
            if hasattr(cls, field):
                # Handle enum columns - extract enum value if needed
                filter_value = _get_enum_value(cls, field, value)
                stmt = stmt.where(getattr(cls, field) == filter_value)

        # Apply pagination
        if offset:
            stmt = stmt.offset(offset)
        if limit:
            stmt = stmt.limit(limit)

        result = await db.execute(stmt)
        return list(result.scalars().all())

    @classmethod
    async def update(
        cls,
        db: AsyncSession,
        iam: IAMContext,
        obj_id: PyUUID,
        data: Dict[str, Any],
        cross_tenant: bool = False
    ) -> Optional:
        """
        Update a record with AUTOMATIC IAM field management.

        Protected fields (cannot be updated):
        - tenant_id (prevents tenant migration)
        - namespace_id (prevents namespace migration)
        - created_by (preserves creator)
        - created_at (preserves creation time)

        Automatically updated:
        - updated_at (by database trigger)
        - updated_by (from IAMContext.user_id)

        Args:
            db: Async database session
            iam: IAM context
            obj_id: UUID of the record to update
            data: Dictionary with fields to update
            cross_tenant: Allow cross-tenant access

        Returns:
            Updated model instance or None if not found
        """
        # Remove protected fields
        protected = {"tenant_id", "namespace_id", "created_by", "created_at"}
        for field in protected:
            data.pop(field, None)

        # Set updated_by
        data["updated_by"] = str(iam.user_id) if iam.user_id else "system"

        # Build update statement
        stmt = (
            update(cls)
            .where(cls.id == obj_id)
            .values(**data)
            .returning(cls)
        )

        # Add tenant filtering if not cross-tenant (only if model has these fields)
        if not cross_tenant:
            if hasattr(cls, 'tenant_id'):
                stmt = stmt.where(cls.tenant_id == iam.tenant_id)
            if hasattr(cls, 'namespace_id') and iam.namespace_id:
                stmt = stmt.where(cls.namespace_id == iam.namespace_id)

        result = await db.execute(stmt)
        await db.commit()

        return result.scalar_one_or_none()

    @classmethod
    async def delete(
        cls,
        db: AsyncSession,
        iam: IAMContext,
        obj_id: PyUUID,
        hard_delete: bool = False,
        cross_tenant: bool = False
    ) -> bool:
        """
        Delete a record (SOFT DELETE by default).

        Args:
            db: Async database session
            iam: IAM context
            obj_id: UUID of the record to delete
            hard_delete: If True, permanently delete from database
            cross_tenant: Allow cross-tenant access

        Returns:
            True if deleted, False if not found
        """
        if hard_delete:
            stmt = delete(cls).where(cls.id == obj_id)
        else:
            stmt = (
                update(cls)
                .where(cls.id == obj_id)
                .values(
                    is_deleted=True,
                    updated_by=str(iam.user_id) if iam.user_id else "system"
                )
            )

        # Add tenant filtering if not cross-tenant (only if model has these fields)
        if not cross_tenant:
            if hasattr(cls, 'tenant_id'):
                stmt = stmt.where(cls.tenant_id == iam.tenant_id)
            if hasattr(cls, 'namespace_id') and iam.namespace_id:
                stmt = stmt.where(cls.namespace_id == iam.namespace_id)

        result = await db.execute(stmt)
        await db.commit()

        return result.rowcount > 0

    @classmethod
    async def count(
        cls,
        db: AsyncSession,
        iam: IAMContext,
        filters: Optional[Dict[str, Any]] = None
    ) -> int:
        """
        Count records matching filters with AUTOMATIC tenant filtering (if applicable).

        Args:
            db: Async database session
            iam: IAM context
            filters: Optional dictionary of field/value pairs to filter by

        Returns:
            Number of matching records
        """
        from sqlalchemy import func

        stmt = select(func.count()).select_from(cls)
        stmt = stmt.where(cls.is_deleted == False)

        # Only apply tenant filtering if the model has these fields
        if hasattr(cls, 'tenant_id'):
            stmt = stmt.where(cls.tenant_id == iam.tenant_id)
        if hasattr(cls, 'namespace_id') and iam.namespace_id:
            stmt = stmt.where(cls.namespace_id == iam.namespace_id)

        if filters:
            for field, value in filters.items():
                if hasattr(cls, field):
                    # Handle enum columns - extract enum value if needed
                    filter_value = _get_enum_value(cls, field, value)
                    stmt = stmt.where(getattr(cls, field) == filter_value)

        result = await db.execute(stmt)
        return result.scalar_one() or 0

    # ===== TIER 2: QUERY BUILDER FACTORY =====

    @classmethod
    def query_builder(cls) -> 'QueryBuilder':
        """
        Get a QueryBuilder for complex queries (joins, aggregations).

        Returns:
            QueryBuilder instance configured for this model

        Usage:
            builder = Tenant.query_builder()
            builder.filter("name", "test")
            result = await builder.execute(db, iam)
        """
        from pantheon_shared.orm.query_builder import QueryBuilder
        return QueryBuilder(cls)

    # ===== HELPER METHODS =====

    def to_dict(self) -> Dict[str, Any]:
        """Convert model instance to dictionary."""
        return {
            c.name: getattr(self, c.name)
            for c in self.__table__.columns
        }

    @property
    def iam_fields(self) -> Dict[str, Any]:
        """Get IAM fields as a dictionary."""
        fields = {
            "is_deleted": self.is_deleted,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "created_by": self.created_by,
            "updated_by": self.updated_by,
        }
        if hasattr(self, 'tenant_id'):
            fields["tenant_id"] = self.tenant_id
        if hasattr(self, 'namespace_id'):
            fields["namespace_id"] = self.namespace_id
        return fields


class PantheonDB:
    """
    Unified base model for ALL Pantheon database entities.

    This single class provides:
    - All IAM fields (tenant_id, namespace_id, created_by, updated_by, is_deleted)
    - Audit fields (created_at, updated_at)
    - CRUD methods (create, get_by_id, filter, update, delete)
    - Query builder factory for complex queries
    - Automatic IAM field management - IMPOSSIBLE to forget

    Usage:
        from sqlalchemy.ext.declarative import declarative_base
        from pantheon_shared.orm import PantheonDB

        Base = declarative_base()

        class Agent(Base, PantheonDB):
            __tablename__ = "agents"
            id = Column(PG_UUID(as_uuid=True), primary_key=True)
            name = Column(String(255))

        # Simple CRUD (Tier 1)
        agent = await Agent.create(db, iam, {"name": "Test"})
        agent = await Agent.get_by_id(db, iam, agent_id)
        agents = await Agent.filter(db, iam, {"status": "active"})

        # Complex queries (Tier 2)
        builder = Agent.query_builder()
        builder.join(Program, Agent.program_id == Program.id)
        result = await builder.execute(db, iam)
    """

    # ===== IAM FIELDS (all required, indexed) =====
    tenant_id = Column(
        PG_UUID(as_uuid=True),
        nullable=False,
        index=True,
        comment="Tenant ID for multi-tenancy"
    )

    namespace_id = Column(
        PG_UUID(as_uuid=True),
        nullable=False,
        index=True,
        comment="Namespace ID for multi-tenancy"
    )

    is_deleted = Column(
        Boolean,
        default=False,
        nullable=False,
        index=True,
        comment="Soft delete flag"
    )

    # ===== WORKSPACE FIELD =====
    # Tables that don't need workspace_id (config tables, IAM tables, execution logs)
    # should override this with: workspace_id = None
    workspace_id = Column(
        String(255),
        nullable=True,
        index=True,
        comment="Workspace ID for workspace-scoped artifacts"
    )

    # ===== AUDIT FIELDS (automatic) =====
    created_at = Column(
        DateTime(timezone=True),
        default=_utc_now,
        nullable=False,
        comment="Creation timestamp (auto-set)"
    )

    updated_at = Column(
        DateTime(timezone=True),
        default=_utc_now,
        onupdate=_utc_now,
        nullable=False,
        comment="Last update timestamp (auto-set)"
    )

    created_by = Column(
        String(255),
        nullable=False,
        default="system",
        comment="User ID who created the record"
    )

    updated_by = Column(
        String(255),
        nullable=False,
        default="system",
        comment="User ID who last updated the record"
    )

    # ===== TIER 1: SIMPLE CRUD METHODS =====

    @classmethod
    async def create(
        cls,
        db: AsyncSession,
        iam: IAMContext,
        data: Dict[str, Any]
    ):
        """
        Create a new record with AUTOMATIC IAM field assignment.

        IAM fields set automatically:
        - tenant_id: From IAMContext
        - namespace_id: From IAMContext
        - workspace_id: From caller (required if model has the field)
        - created_by: From IAMContext.user_id
        - updated_by: From IAMContext.user_id

        Args:
            db: Async database session
            iam: IAM context (required - enforces IAM safety)
            data: Dictionary with model data (IAM fields will be set automatically)

        Returns:
            Created model instance
        """
        # Set IAM fields automatically (handles both String and UUID column types)
        data["tenant_id"] = _get_tenant_filter_value(cls, 'tenant_id', iam.tenant_id)

        # Handle namespace_id - derive default for tenant if None
        namespace_id_to_use = iam.namespace_id
        if not namespace_id_to_use:
            # Try to derive default namespace for the tenant
            namespace_id_to_use = iam._derive_namespace_id(iam.tenant_id)

        if namespace_id_to_use:
            data["namespace_id"] = _get_tenant_filter_value(cls, 'namespace_id', namespace_id_to_use)

        ws_attr = getattr(cls, 'workspace_id', None)
        if ws_attr is not None:
            ws_cols = getattr(ws_attr, 'property', None)
            ws_nullable = True
            if ws_cols is not None:
                try:
                    ws_nullable = ws_cols.columns[0].nullable
                except (AttributeError, IndexError):
                    ws_nullable = True
            if not ws_nullable and not data.get('workspace_id'):
                raise ValueError(
                    f"workspace_id is required when creating {cls.__name__}"
                )

        user_id_str = str(iam.user_id) if iam.user_id else "system"
        data["created_by"] = user_id_str
        data["updated_by"] = user_id_str

        # Create instance
        obj = cls(**data)
        db.add(obj)
        await db.commit()
        await db.refresh(obj)

        return obj

    @classmethod
    async def get_by_id(
        cls,
        db: AsyncSession,
        iam: IAMContext,
        obj_id: PyUUID,
        cross_tenant: bool = False
    ) -> Optional:
        """
        Get a record by ID with AUTOMATIC tenant filtering.

        Args:
            db: Async database session
            iam: IAM context
            obj_id: UUID of the record
            cross_tenant: Allow cross-tenant access (requires permission)

        Returns:
            Model instance or None if not found
        """
        stmt = select(cls).where(cls.id == obj_id)
        stmt = stmt.where(cls.is_deleted == False)

        # Automatic tenant filtering (handles both String and UUID column types)
        if not cross_tenant:
            stmt = stmt.where(cls.tenant_id == _get_tenant_filter_value(cls, 'tenant_id', iam.tenant_id))
            if iam.namespace_id:
                stmt = stmt.where(cls.namespace_id == _get_tenant_filter_value(cls, 'namespace_id', iam.namespace_id))

        result = await db.execute(stmt)
        return result.scalar_one_or_none()

    @classmethod
    async def filter(
        cls,
        db: AsyncSession,
        iam: IAMContext,
        filters: Dict[str, Any],
        limit: Optional[int] = None,
        offset: int = 0
    ) -> List:
        """
        Filter records with AUTOMATIC tenant filtering.

        Args:
            db: Async database session
            iam: IAM context
            filters: Dictionary of field/value pairs to filter by
            limit: Optional limit for pagination
            offset: Optional offset for pagination

        Returns:
            List of model instances
        """
        stmt = select(cls).where(cls.is_deleted == False)
        stmt = stmt.where(cls.tenant_id == _get_tenant_filter_value(cls, 'tenant_id', iam.tenant_id))

        if iam.namespace_id:
            stmt = stmt.where(cls.namespace_id == _get_tenant_filter_value(cls, 'namespace_id', iam.namespace_id))

        # Apply filters
        for field, value in filters.items():
            if hasattr(cls, field):
                # Handle enum columns - extract enum value if needed
                filter_value = _get_enum_value(cls, field, value)
                stmt = stmt.where(getattr(cls, field) == filter_value)

        # Apply pagination
        if offset:
            stmt = stmt.offset(offset)
        if limit:
            stmt = stmt.limit(limit)

        result = await db.execute(stmt)
        return list(result.scalars().all())

    @classmethod
    async def update(
        cls,
        db: AsyncSession,
        iam: IAMContext,
        obj_id: PyUUID,
        data: Dict[str, Any],
        cross_tenant: bool = False
    ) -> Optional:
        """
        Update a record with AUTOMATIC IAM field management.

        Protected fields (cannot be updated):
        - tenant_id (prevents tenant migration)
        - namespace_id (prevents namespace migration)
        - created_by (preserves creator)
        - created_at (preserves creation time)

        Automatically updated:
        - updated_at (by database trigger)
        - updated_by (from IAMContext.user_id)

        Args:
            db: Async database session
            iam: IAM context
            obj_id: UUID of the record to update
            data: Dictionary with fields to update
            cross_tenant: Allow cross-tenant access

        Returns:
            Updated model instance or None if not found
        """
        # Remove protected fields (workspace_id requires dedicated move endpoint)
        protected = {"tenant_id", "namespace_id", "workspace_id", "created_by", "created_at"}
        for field in protected:
            data.pop(field, None)

        # Set updated_by
        data["updated_by"] = str(iam.user_id) if iam.user_id else "system"

        # Build update statement
        stmt = (
            update(cls)
            .where(cls.id == obj_id)
            .values(**data)
            .returning(cls)
        )

        # Add tenant filtering if not cross-tenant (handles both String and UUID types)
        if not cross_tenant:
            stmt = stmt.where(cls.tenant_id == _get_tenant_filter_value(cls, 'tenant_id', iam.tenant_id))
            if iam.namespace_id:
                stmt = stmt.where(cls.namespace_id == _get_tenant_filter_value(cls, 'namespace_id', iam.namespace_id))

        result = await db.execute(stmt)
        await db.commit()

        return result.scalar_one_or_none()

    @classmethod
    async def delete(
        cls,
        db: AsyncSession,
        iam: IAMContext,
        obj_id: PyUUID,
        hard_delete: bool = False,
        cross_tenant: bool = False
    ) -> bool:
        """
        Delete a record (SOFT DELETE by default).

        Args:
            db: Async database session
            iam: IAM context
            obj_id: UUID of the record to delete
            hard_delete: If True, permanently delete from database
            cross_tenant: Allow cross-tenant access

        Returns:
            True if deleted, False if not found
        """
        if hard_delete:
            stmt = delete(cls).where(cls.id == obj_id)
        else:
            stmt = (
                update(cls)
                .where(cls.id == obj_id)
                .values(
                    is_deleted=True,
                    updated_by=str(iam.user_id) if iam.user_id else "system"
                )
            )

        # Add tenant filtering if not cross-tenant (handles both String and UUID types)
        if not cross_tenant:
            stmt = stmt.where(cls.tenant_id == _get_tenant_filter_value(cls, 'tenant_id', iam.tenant_id))
            if iam.namespace_id:
                stmt = stmt.where(cls.namespace_id == _get_tenant_filter_value(cls, 'namespace_id', iam.namespace_id))

        result = await db.execute(stmt)
        await db.commit()

        return result.rowcount > 0

    @classmethod
    async def count(
        cls,
        db: AsyncSession,
        iam: IAMContext,
        filters: Optional[Dict[str, Any]] = None
    ) -> int:
        """
        Count records matching filters with AUTOMATIC tenant filtering.

        Args:
            db: Async database session
            iam: IAM context
            filters: Optional dictionary of field/value pairs to filter by

        Returns:
            Number of matching records
        """
        from sqlalchemy import func

        stmt = select(func.count()).select_from(cls)
        stmt = stmt.where(cls.is_deleted == False)
        stmt = stmt.where(cls.tenant_id == _get_tenant_filter_value(cls, 'tenant_id', iam.tenant_id))

        if iam.namespace_id:
            stmt = stmt.where(cls.namespace_id == _get_tenant_filter_value(cls, 'namespace_id', iam.namespace_id))

        if filters:
            for field, value in filters.items():
                if hasattr(cls, field):
                    # Handle enum columns - extract enum value if needed
                    filter_value = _get_enum_value(cls, field, value)
                    stmt = stmt.where(getattr(cls, field) == filter_value)

        result = await db.execute(stmt)
        return result.scalar_one() or 0

    # ===== TIER 2: QUERY BUILDER FACTORY =====

    @classmethod
    def query_builder(cls) -> 'QueryBuilder':
        """
        Get a QueryBuilder for complex queries (joins, aggregations).

        Returns:
            QueryBuilder instance configured for this model

        Usage:
            builder = Agent.query_builder()
            builder.join(Program, Agent.program_id == Program.id)
            builder.filter("status", "active")
            result = await builder.execute(db, iam)
        """
        from pantheon_shared.orm.query_builder import QueryBuilder
        return QueryBuilder(cls)

    # ===== IAMRepository COMPATIBILITY METHODS =====

    @classmethod
    def get_tenant_filtered_query(
        cls,
        db_session,
        tenant_id: Optional[Union[str, PyUUID]],
        namespace_id: Optional[Union[str, PyUUID]] = None,
        include_deleted: bool = False
    ):
        """
        Get a select statement filtered by tenant and optionally namespace.

        This method provides compatibility with IAMRepository which expects
        model classes to have this method.

        Args:
            db_session: Database session (sync or async) - not used, kept for API compatibility
            tenant_id: Tenant ID to filter by
            namespace_id: Optional namespace ID to filter by
            include_deleted: Whether to include soft-deleted records

        Returns:
            SQLAlchemy select statement with tenant/namespace filters applied
        """
        stmt = select(cls)

        # Apply tenant filter (handle both String and UUID column types)
        if tenant_id is not None:
            stmt = stmt.where(cls.tenant_id == _get_tenant_filter_value(cls, 'tenant_id', tenant_id))

        # Apply namespace filter if provided
        if namespace_id:
            stmt = stmt.where(cls.namespace_id == _get_tenant_filter_value(cls, 'namespace_id', namespace_id))

        # Apply soft-delete filter
        if not include_deleted:
            stmt = stmt.where(cls.is_deleted == False)

        return stmt

    @classmethod
    def get_cross_tenant_query(
        cls,
        db_session,
        include_deleted: bool = False
    ):
        """
        Get a select statement for cross-tenant access (admin only).

        This method provides compatibility with IAMRepository which expects
        model classes to have this method.

        Args:
            db_session: Database session (sync or async) - not used, kept for API compatibility
            include_deleted: Whether to include soft-deleted records

        Returns:
            SQLAlchemy select statement without tenant filter
        """
        stmt = select(cls)

        if not include_deleted:
            stmt = stmt.where(cls.is_deleted == False)

        return stmt

    # ===== HELPER METHODS =====

    def to_dict(self) -> Dict[str, Any]:
        """Convert model instance to dictionary."""
        return {
            c.name: getattr(self, c.name)
            for c in self.__table__.columns
        }

    @property
    def iam_fields(self) -> Dict[str, Any]:
        """Get IAM fields as a dictionary."""
        return {
            "tenant_id": self.tenant_id,
            "namespace_id": self.namespace_id,
            "created_by": self.created_by,
            "updated_by": self.updated_by,
            "is_deleted": self.is_deleted,
        }

    # ===== TIER 3: API LAYER HELPERS =====

    @classmethod
    def parse_query_filters(
        cls,
        query_params: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Parse HTTP query parameters into structured filters for QueryBuilder.

        Supports operators via double-underscore suffix:
        - status=active → simple filter
        - name__like=test → LIKE filter
        - name__ilike=test → case-insensitive LIKE filter
        - age__gte=18 → greater than or equal
        - age__gt=18 → greater than
        - age__lte=18 → less than or equal
        - age__lt=18 → less than
        - tags__in=a,b,c → IN filter (comma-separated values)

        Special parameters (excluded from filters):
        - cursor: Pagination cursor
        - limit: Items per page
        - sort: Sort column (prefix with - for descending)

        Args:
            query_params: Raw query parameters from HTTP request

        Returns:
            {
                "filters": {field: value, ...},  # Simple equality filters
                "operators": [(field, op, value), ...],  # Operator filters
                "pagination": {"cursor": ..., "limit": ..., "sort": ...}
            }

        Example:
            >>> params = {"status": "active", "name__like": "test", "limit": "20"}
            >>> parsed = Agent.parse_query_filters(params)
            >>> # Returns:
            >>> # {
            >>> #     "filters": {"status": "active"},
            >>> #     "operators": [("name", "like", "test")],
            >>> #     "pagination": {"limit": 20}
            >>> # }
        """
        simple_filters = {}
        operator_filters = []
        pagination = {}

        # Special parameter names that should not be treated as filters
        special_params = {"cursor", "limit", "sort", "page", "page_size"}

        for key, value in query_params.items():
            if key in special_params:
                pagination[key] = value
            elif "__" in key:
                # Split on last occurrence to handle field names with underscores
                parts = key.rsplit("__", 1)
                if len(parts) == 2:
                    field, op = parts
                    operator_filters.append((field, op, value))
            else:
                simple_filters[key] = value

        return {
            "filters": simple_filters,
            "operators": operator_filters,
            "pagination": pagination
        }

    @classmethod
    async def list_with_pagination(
        cls,
        db: AsyncSession,
        iam: IAMContext,
        query_params: Dict[str, Any],
        max_limit: int = 100
    ) -> Dict[str, Any]:
        """
        Execute a LIST query with automatic filter parsing and pagination.

        This is the ONE METHOD to handle all standard LIST endpoints.
        It parses query parameters, builds the query, executes it, and
        returns a consistent response format with pagination metadata.

        Supported query parameters:
        - cursor: Pagination cursor for next page
        - limit: Items per page (default 50, max specified by max_limit)
        - sort: Sort column (prefix with - for descending, e.g., -created_at)
        - field=value: Simple equality filter
        - field__op=value: Operator filter (like, ilike, gt, gte, lt, lte, in)

        Args:
            db: Async database session
            iam: IAM context
            query_params: Raw query parameters from HTTP request
            max_limit: Maximum items per page (default 100)

        Returns:
            Standard LIST response format:
            {
                "items": [...],  # List of model dicts
                "pagination": {
                    "next_cursor": "...",  # Cursor for next page
                    "has_more": true,      # Whether more items exist
                    "limit": 50           # Items per page
                },
                "_headers": {  # Optional: Standard response headers
                    "X-Total-Count": 123,
                    "X-Pagination-Limit": 50
                }
            }

        Example:
            >>> # In FastAPI route handler:
            >>> result = await Agent.list_with_pagination(
            >>>     db, iam, dict(request.query_params)
            >>> )
            >>> return result

        Example URLs:
            - GET /agents?status=active&limit=20
            - GET /agents?name__like=test&sort=-created_at
            - GET /agents?cursor=abc123&limit=50
            - GET /agents?status__in=active,pending&sort=name
        """
        # Parse query parameters
        parsed = cls.parse_query_filters(query_params)

        # Build query using QueryBuilder
        builder = cls.query_builder()

        # Apply simple equality filters
        for field, value in parsed["filters"].items():
            if hasattr(cls, field):
                builder.filter(field, value)

        # Apply operator filters
        for field, op, value in parsed["operators"]:
            if not hasattr(cls, field):
                continue  # Skip invalid fields

            if op == "like":
                builder.filter_like(field, value)
            elif op == "ilike":
                builder.filter_ilike(field, value)
            elif op == "gt":
                builder.filter_gt(field, value)
            elif op == "gte":
                builder.filter_gte(field, value)
            elif op == "lt":
                builder.filter_lt(field, value)
            elif op == "lte":
                builder.filter_lte(field, value)
            elif op == "in":
                # Handle comma-separated values
                if isinstance(value, str):
                    values = [v.strip() for v in value.split(",")]
                else:
                    values = value
                builder.filter_in(field, values)

        # Apply sorting
        sort = parsed["pagination"].get("sort", "created_at")
        if sort:
            if sort.startswith("-"):
                builder.sort(sort[1:], "desc")
            else:
                builder.sort(sort, "asc")

        # Apply pagination
        cursor = parsed["pagination"].get("cursor")
        limit = int(parsed["pagination"].get("limit", 50))
        limit = min(limit, max_limit)  # Enforce max limit

        if cursor:
            builder.paginate(cursor=cursor, limit=limit)
        else:
            builder.paginate(limit=limit)

        # Execute query
        result = await builder.execute(db, iam)

        # Build response with consistent format
        response = {
            "items": [item.to_dict() for item in result.items],
            "pagination": {
                "next_cursor": result.next_cursor,
                "has_more": result.has_more,
                "limit": result.limit
            }
        }

        return response
