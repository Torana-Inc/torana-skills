"""
Pantheon Unified ORM - Query Builder

This module provides the QueryBuilder for complex queries with joins, aggregations,
and automatic IAM filtering on all tables.
"""

from datetime import datetime
from typing import Any, Dict, List, Optional, Union
from uuid import UUID as PyUUID
from sqlalchemy import select, and_, or_, String
from sqlalchemy.dialects.postgresql import ENUM as PG_ENUM
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.sql import Select
from dataclasses import dataclass
from enum import Enum as PyEnum

from pantheon_shared.iam.context import IAMContext


def _to_uuid(value: Union[str, PyUUID, None]) -> Optional[PyUUID]:
    """Convert string UUID to UUID object if needed."""
    if value is None:
        return None
    if isinstance(value, str):
        return PyUUID(value)
    return value


def _get_enum_value(model, field: str, value: Any) -> Any:
    """
    Extract the appropriate value for enum columns.

    If the column is a native PostgreSQL enum and the value is a Python enum,
    extract the enum's value (string) for comparison.

    Args:
        model: The model class
        field: Field name to check
        value: Value to potentially convert

    Returns:
        The value to use for filtering (extracted enum value if needed)
    """
    if value is None:
        return None

    # Check if this is an enum column
    column = getattr(model, field, None)
    if column and isinstance(column.type, PG_ENUM):
        # If value is a Python enum, extract its value
        if isinstance(value, PyEnum):
            return value.value
        # Otherwise return as-is (already a string)
        return value

    return value


def _get_tenant_filter_value(model, column_name: str, value: Union[str, PyUUID, None]) -> Union[str, PyUUID, None]:
    """
    Get the appropriate filter value for tenant_id/namespace_id columns.
    Returns string if the column is String type, UUID if UUID type.
    This handles models that override tenant_id/namespace_id with String(255).
    """
    if value is None:
        return None
    # Check if the column is a String type (overridden in model)
    column = getattr(model, column_name)
    if isinstance(column.type, String):
        return str(value)  # Keep as string
    return _to_uuid(value)  # Convert to UUID for UUID columns


class QueryBuilder:
    """
    Fluent query builder for complex queries with join support.

    Features:
    - Single and multi-table queries
    - Join support with automatic IAM filtering on ALL tables
    - Rich filtering (equality, comparison, LIKE, IN, OR across fields, etc.)
    - Cursor-based pagination
    - Sorting
    - Aggregations

    Usage:
        # Single table
        builder = Agent.query_builder()
        builder.filter("status", "active")
        result = await builder.execute(db, iam)

        # With joins
        builder = Agent.query_builder()
        builder.join(Program, Agent.program_id == Program.id)
        builder.join(Workspace, Program.workspace_id == Workspace.id)
        builder.filter("status", "active")
        result = await builder.execute(db, iam)

        # Search across multiple fields
        builder = Prompt.query_builder()
        builder.filter_or_across_fields(
            fields=['name', 'description', 'content'],
            pattern='%search_term%'
        )
        result = await builder.execute(db, iam)
    """

    def __init__(self, primary_model):
        """
        Initialize query builder.

        Args:
            primary_model: SQLAlchemy model class (must inherit PantheonDB)
        """
        self.primary_model = primary_model
        self.joins = []  # List of (model, on_clause)
        self.filters = []
        self._sort_column = None
        self._sort_direction = "asc"
        self._limit = None
        self._offset = None
        self._cursor = None
        self._include_deleted = False

    def join(self, model, on_clause):
        """
        Join another PantheonDB model.

        Args:
            model: Another PantheonDB model class
            on_clause: SQLAlchemy join condition

        Returns:
            Self for chaining

        Example:
            builder.join(Program, Agent.program_id == Program.id)
        """
        self.joins.append((model, on_clause))
        return self

    def filter(self, field: str, value: Any):
        """Add equality filter."""
        if not hasattr(self.primary_model, field):
            raise ValueError(f"Invalid field: {field}")
        # Handle enum columns - extract enum value if needed
        filter_value = _get_enum_value(self.primary_model, field, value)
        self.filters.append(
            (getattr(self.primary_model, field) == filter_value, "and")
        )
        return self

    def filter_gt(self, field: str, value: Any):
        """Greater than filter."""
        self.filters.append(
            (getattr(self.primary_model, field) > value, "and")
        )
        return self

    def filter_gte(self, field: str, value: Any):
        """Greater than or equal filter."""
        self.filters.append(
            (getattr(self.primary_model, field) >= value, "and")
        )
        return self

    def filter_lt(self, field: str, value: Any):
        """Less than filter."""
        self.filters.append(
            (getattr(self.primary_model, field) < value, "and")
        )
        return self

    def filter_lte(self, field: str, value: Any):
        """Less than or equal filter."""
        self.filters.append(
            (getattr(self.primary_model, field) <= value, "and")
        )
        return self

    def filter_in(self, field: str, values: List[Any]):
        """IN filter."""
        self.filters.append(
            (getattr(self.primary_model, field).in_(values), "and")
        )
        return self

    def filter_like(self, field: str, pattern: str):
        """LIKE filter (case-sensitive)."""
        self.filters.append(
            (getattr(self.primary_model, field).like(pattern), "and")
        )
        return self

    def filter_ilike(self, field: str, pattern: str):
        """ILIKE filter (case-insensitive)."""
        self.filters.append(
            (getattr(self.primary_model, field).ilike(pattern), "and")
        )
        return self

    def filter_or(self, field: str, value: Any):
        """Add OR filter (alternative to AND)."""
        if not hasattr(self.primary_model, field):
            raise ValueError(f"Invalid field: {field}")
        self.filters.append(
            (getattr(self.primary_model, field) == value, "or")
        )
        return self

    def filter_or_across_fields(self, fields: List[str], pattern: str, case_sensitive: bool = False):
        """
        Add OR filter across multiple different fields.

        This creates: WHERE field1 ILIKE pattern OR field2 ILIKE pattern OR field3 ILIKE pattern

        Args:
            fields: List of field names to search across
            pattern: Search pattern (use % for wildcards, e.g., "%search_term%")
            case_sensitive: If True, use LIKE (case-sensitive). If False, use ILIKE (case-insensitive)

        Returns:
            Self for chaining

        Example:
            # Search across name, description, and content fields
            builder.filter_or_across_fields(
                fields=['name', 'description', 'content'],
                pattern='%search_term%'
            )

            # Case-sensitive search
            builder.filter_or_across_fields(
                fields=['title'],
                pattern='Test%',
                case_sensitive=True
            )
        """
        # Validate all fields exist
        for field in fields:
            if not hasattr(self.primary_model, field):
                raise ValueError(f"Invalid field: {field}")

        # Build OR conditions across all fields
        if case_sensitive:
            conditions = [getattr(self.primary_model, field).like(pattern) for field in fields]
        else:
            conditions = [getattr(self.primary_model, field).ilike(pattern) for field in fields]

        # Add as a single OR condition
        self.filters.append((or_(*conditions), "and"))
        return self

    def updated_since(self, timestamp: datetime):
        """
        Filter records updated at or after the given timestamp, including soft-deleted records.

        This is used by the artifact cache service to fetch all changed records (including
        deletions) since the last refresh. When called, the is_deleted == False filter is
        skipped in execute() so that soft-deleted artifacts are returned for cache removal.

        Args:
            timestamp: Datetime threshold; records with updated_at >= timestamp are returned

        Returns:
            Self for chaining
        """
        self._include_deleted = True
        self.filter_gte("updated_at", timestamp)
        return self

    def sort(self, column: str, direction: str = "asc"):
        """
        Add sort order.

        Args:
            column: Column name to sort by
            direction: "asc" or "desc"
        """
        if not hasattr(self.primary_model, column):
            raise ValueError(f"Invalid sort column: {column}")

        self._sort_column = column
        self._sort_direction = direction.lower()
        return self

    def paginate(self, cursor: Optional[str] = None, limit: int = 50):
        """
        Configure cursor-based pagination.

        Args:
            cursor: Optional cursor from previous page
            limit: Number of items per page
        """
        self._cursor = cursor
        self._limit = limit
        return self

    def offset_paginate(self, offset: int = 0, limit: int = 50):
        """
        Configure offset-based pagination.

        Args:
            offset: Number of items to skip
            limit: Number of items per page
        """
        self._offset = offset
        self._limit = limit
        return self

    def build(self) -> Select:
        """
        Build SQLAlchemy select statement.

        Returns:
            Select statement ready for execution
        """
        stmt = select(self.primary_model)

        # Add joins
        for model, on_clause in self.joins:
            stmt = stmt.join(model, on_clause)

        # Apply filters
        if self.filters:
            conditions = []
            current_and = []

            for condition, logical_op in self.filters:
                if logical_op == "and":
                    current_and.append(condition)
                else:  # or
                    if current_and:
                        conditions.append(and_(*current_and))
                        current_and = []
                    conditions.append(condition)

            # Add remaining AND conditions
            if current_and:
                conditions.append(and_(*current_and))

            # Apply conditions
            if len(conditions) == 1:
                stmt = stmt.where(conditions[0])
            elif len(conditions) > 1:
                stmt = stmt.where(or_(*conditions))

        # Apply cursor filtering
        if self._cursor and self._sort_column:
            order_attr = getattr(self.primary_model, self._sort_column)
            if self._sort_direction == "desc":
                stmt = stmt.where(order_attr < self._cursor)
            else:
                stmt = stmt.where(order_attr > self._cursor)

        # Apply sorting
        if self._sort_column:
            order_attr = getattr(self.primary_model, self._sort_column)
            if self._sort_direction == "desc":
                stmt = stmt.order_by(order_attr.desc())
            else:
                stmt = stmt.order_by(order_attr.asc())

        # Apply limit
        if self._limit:
            if self._cursor:
                # Fetch one extra to determine if there are more results
                stmt = stmt.limit(self._limit + 1)
            else:
                stmt = stmt.limit(self._limit)

        # Apply offset (only for offset-based pagination)
        if self._offset is not None:
            stmt = stmt.offset(self._offset)

        return stmt

    async def execute(self, db: AsyncSession, iam: IAMContext):
        """
        Execute the query with AUTOMATIC IAM filtering on ALL tables.

        This is the KEY method - it applies IAM filtering to:
        1. The primary model
        2. ALL joined models

        Args:
            db: Async database session
            iam: IAM context

        Returns:
            QueryResult with items and cursor metadata
        """
        stmt = self.build()

        # Add IAM filtering for PRIMARY model (handles both String and UUID types)
        if not self._include_deleted:
            stmt = stmt.where(self.primary_model.is_deleted == False)
        stmt = stmt.where(self.primary_model.tenant_id == _get_tenant_filter_value(self.primary_model, 'tenant_id', iam.tenant_id))
        if iam.namespace_id:
            stmt = stmt.where(self.primary_model.namespace_id == _get_tenant_filter_value(self.primary_model, 'namespace_id', iam.namespace_id))

        # Add IAM filtering for ALL joined models (KEY!)
        for model, _ in self.joins:
            if not self._include_deleted:
                stmt = stmt.where(model.is_deleted == False)
            stmt = stmt.where(model.tenant_id == _get_tenant_filter_value(model, 'tenant_id', iam.tenant_id))
            if iam.namespace_id:
                stmt = stmt.where(model.namespace_id == _get_tenant_filter_value(model, 'namespace_id', iam.namespace_id))

        # Execute
        result = await db.execute(stmt)
        items = result.scalars().all()

        # Handle cursor pagination
        if self._limit:
            # Determine if there are more results
            # When cursor is set, we fetched limit+1 items to check for more
            # When no cursor, we need to query again to check for more
            if self._cursor:
                has_more = len(items) > self._limit
                if has_more:
                    items = items[:self._limit]

                next_cursor = None
                if items and has_more and self._sort_column:
                    last_item = items[-1]
                    next_cursor = str(getattr(last_item, self._sort_column))

                return QueryResult(
                    items=list(items),
                    next_cursor=next_cursor,
                    has_more=has_more,
                    limit=self._limit
                )
            else:
                # First page - need to check if there are more results
                # Count total items to determine if there are more
                count_stmt = select(self.primary_model)
                # Apply same IAM filtering
                if not self._include_deleted:
                    count_stmt = count_stmt.where(self.primary_model.is_deleted == False)
                count_stmt = count_stmt.where(self.primary_model.tenant_id == _get_tenant_filter_value(self.primary_model, 'tenant_id', iam.tenant_id))
                if iam.namespace_id:
                    count_stmt = count_stmt.where(self.primary_model.namespace_id == _get_tenant_filter_value(self.primary_model, 'namespace_id', iam.namespace_id))
                # Apply same joins
                for model, on_clause in self.joins:
                    count_stmt = count_stmt.join(model, on_clause)
                # Apply same filters (from build())
                if self.filters:
                    conditions = []
                    current_and = []

                    for condition, logical_op in self.filters:
                        if logical_op == "and":
                            current_and.append(condition)
                        else:  # or
                            if current_and:
                                conditions.append(and_(*current_and))
                                current_and = []
                            conditions.append(condition)

                    if current_and:
                        conditions.append(and_(*current_and))

                    if len(conditions) == 1:
                        count_stmt = count_stmt.where(conditions[0])
                    elif len(conditions) > 1:
                        count_stmt = count_stmt.where(or_(*conditions))

                from sqlalchemy import func
                count_result = await db.execute(select(func.count()).select_from(count_stmt.alias('subquery')))
                total_count = count_result.scalar_one() or 0

                has_more = total_count > self._limit

                next_cursor = None
                if items and has_more and self._sort_column:
                    last_item = items[-1]
                    next_cursor = str(getattr(last_item, self._sort_column))

                return QueryResult(
                    items=list(items),
                    next_cursor=next_cursor,
                    has_more=has_more,
                    limit=self._limit
                )

        return QueryResult(
            items=list(items),
            next_cursor=None,
            has_more=False,
            limit=self._limit or len(items)
        )


@dataclass
class QueryResult:
    """
    Result of a query.

    Attributes:
        items: List of model instances
        next_cursor: Cursor for next page (if cursor-based)
        has_more: Whether more items exist
        limit: Number of items per page
    """
    items: List[Any]
    next_cursor: Optional[str]
    has_more: bool
    limit: int

    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary for API responses."""
        return {
            "items": [item.to_dict() if hasattr(item, 'to_dict') else item for item in self.items],
            "pagination": {
                "next_cursor": self.next_cursor,
                "has_more": self.has_more,
                "limit": self.limit
            }
        }
