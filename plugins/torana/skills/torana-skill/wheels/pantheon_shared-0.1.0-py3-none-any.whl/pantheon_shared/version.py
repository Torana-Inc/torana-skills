"""
Version information for pantheon-shared.

This module provides version information including the package version
and the git commit SHA from which the package was built.
"""

from typing import NamedTuple
from pathlib import Path
import os
import subprocess
import inspect


class VersionInfo(NamedTuple):
    """Build provenance for the running code."""
    version: str
    commit_sha: str
    branch: str
    dirty: bool
    commit_time: str = "unknown"


def get_version() -> VersionInfo:
    """
    Get the current version information of pantheon-shared.

    Returns:
        VersionInfo: Named tuple containing version and commit_sha

    Example:
        >>> from pantheon_shared.version import get_version
        >>> version_info = get_version()
        >>> print(f"Version: {version_info.version}")
        >>> print(f"Commit: {version_info.commit_sha}")
    """
    # _version.py is written by build_version.py at build time. It is not
    # tracked in git, so it is absent in a source checkout that has not been
    # built -- hence the fallback below.
    try:
        from pantheon_shared import _version
    except ImportError:
        return VersionInfo(
            version=_get_version_from_file(),
            commit_sha="unknown",
            branch="unknown",
            dirty=False,
            commit_time="unknown",
        )

    # Read each field defensively: a wheel built before BRANCH/DIRTY existed
    # still imports cleanly, it just reports "unknown" for the new fields.
    return VersionInfo(
        version=getattr(_version, "VERSION", None) or _get_version_from_file(),
        commit_sha=getattr(_version, "COMMIT_SHA", None) or "unknown",
        branch=getattr(_version, "BRANCH", None) or "unknown",
        dirty=bool(getattr(_version, "DIRTY", False)),
        commit_time=getattr(_version, "COMMIT_TIME", None) or "unknown",
    )


def get_service_commit_sha() -> str:
    """
    Get the git commit SHA for the calling service.

    This function attempts to read the commit SHA from the service's
    _version.py file by inspecting the call stack to find the caller's
    module and importing _version from the same package.

    Returns:
        str: The git commit SHA, or "unknown" if not available

    Example:
        >>> from pantheon_shared.version import get_service_commit_sha
        >>> commit_sha = get_service_commit_sha()
        >>> print(f"Service commit: {commit_sha}")
    """
    # Strategy 0: the image's build provenance, stamped by the Dockerfile from
    # --build-arg. This is checked FIRST and deliberately outranks _version.py:
    # in a container that file is baked in by `COPY` from whatever the host had
    # generated, which goes stale silently (measured: ~7 months out of date).
    # The env var is set at image build, so it always describes THIS image.
    env_sha = os.environ.get("PANTHEON_COMMIT_SHA", "").strip()
    if env_sha and env_sha != "unknown":
        return env_sha

    # Strategy 1: Inspect the call stack to find the calling service's module
    # and try to import _version from the same package
    try:
        frame = inspect.currentframe()
        # Walk up the stack to find a frame outside of pantheon_shared
        while frame:
            module_name = frame.f_globals.get('__name__', '')
            # Skip pantheon_shared internal modules and __main__
            if module_name and not module_name.startswith('pantheon_shared') and module_name != '__main__':
                # Found a potential service module, try to import _version from it
                # Extract the package name
                parts = module_name.split('.')
                if len(parts) >= 1:
                    # Try to import _version from the same package at different levels
                    for i in range(len(parts), 0, -1):
                        base_package = '.'.join(parts[:i])
                        if base_package:  # Make sure we have a package name
                            try:
                                import importlib
                                version_module_name = f'{base_package}._version'
                                version_module = importlib.import_module(version_module_name)
                                if hasattr(version_module, 'COMMIT_SHA'):
                                    return version_module.COMMIT_SHA
                            except (ImportError, ModuleNotFoundError):
                                continue
                            except Exception:
                                continue
            frame = frame.f_back
    except Exception:
        pass

    # Strategy 2: Try common package names for Pantheon services
    # This is a fallback for specific known package structures
    known_packages = [
        'src._version',  # For services where src is the package (e.g., pantheon-admin in dev mode)
        'src.pantheon_workflow._version',  # Workflow framework (dev mode)
        'src.pantheon_viz._version',  # Viz service (dev mode)
        'src.pantheon_detection._version',  # Detection framework (dev mode)
        'src.pantheon_program_framework._version',  # Program framework (dev mode)
        'src.pantheon_agent_builder._version',  # Agent Builder (dev mode)
        'src.pantheon_rag._version',  # RAG service (dev mode)
        'src.pantheon_api_gw._version',  # API Gateway (dev mode)
        '_version',  # Direct import (e.g., pantheon_admin._version)
        'torana_mesh._version',  # Integration service
        'torana_datalake._version',  # Datalake service
        'torana_transformers._version',  # Transformers service
        'pantheon_detection._version',  # Detection framework
        'pantheon_program_framework._version',  # Program framework
        'pantheon_viz._version',  # Viz service
        'pantheon_workflow._version',  # Workflow framework
        'pantheon_admin._version',  # Admin service (when src is package)
        'pantheon_api_gw._version',  # API Gateway
        'pantheon_agent_builder._version',  # Agent Builder
        'pantheon_rag._version',  # RAG service
    ]

    for module_name in known_packages:
        try:
            import importlib
            version_module = importlib.import_module(module_name)
            if hasattr(version_module, 'COMMIT_SHA'):
                return version_module.COMMIT_SHA
        except (ImportError, ModuleNotFoundError):
            continue
        except Exception:
            continue

    # Strategy 3: Fallback to git subprocess (for development environments where git is available)
    try:
        result = subprocess.run(
            ['git', 'rev-parse', 'HEAD'],
            capture_output=True,
            text=True,
            check=True,
            timeout=5
        )
        return result.stdout.strip()
    except Exception:
        return "unknown"


def get_service_build_info() -> dict:
    """Branch, commit time and dirty flag for the running service image.

    Sourced only from the build-arg env vars, which is the only mechanism that
    describes the image itself. Returns "unknown"/False for a bare `docker
    build` or a local (non-container) run, where no build host stamped them.

    ⚠️ `commit_time` is "unknown" on any image built before the build arg was
    added. That is deliberate: an image whose age we cannot establish must say
    so, never fall back to a value (image mtime, "now") that would read as the
    commit date while being unrelated to it.
    """
    branch = os.environ.get("PANTHEON_BRANCH", "").strip() or "unknown"
    dirty = os.environ.get("PANTHEON_DIRTY", "").strip().lower() in ("true", "1", "yes")
    commit_time = os.environ.get("PANTHEON_COMMIT_TIME", "").strip() or "unknown"
    return {"branch": branch, "dirty": dirty, "commit_time": commit_time}


def _get_version_from_file() -> str:
    """Read version from VERSION file in the package root."""
    # Try to get VERSION file from installed package location
    try:
        import pantheon_shared
        version_file = Path(pantheon_shared.__file__).parent.parent / "VERSION"
        if version_file.exists():
            return version_file.read_text().strip()
    except Exception:
        pass

    # Fallback to development version
    return "0.1.0"


__all__ = ["VersionInfo", "get_version", "get_service_commit_sha",
           "get_service_build_info"]
