"""
Cache Context Module

Provides ContextVar-based context for identifying Gemini cache entries.
This allows tests and services to add identifying information to cache
display_name for easier debugging and traceability.

The Gemini CachedContent API display_name has a 64-character maximum.
Our format: adk-<tenant:6>-<agent:6>-<session:6>-<ts>-<cnt>c

Usage (Test):
    from pantheon_shared.cache_context import set_cache_context

    # In test - can use longer identifiers
    set_cache_context(
        test_name="cache02",      # Short test identifier
        agent_abbrev="wta",       # Agent initials
        session_suffix="abc123"   # Session suffix
    )

Usage (Production):
    from pantheon_shared.cache_context import set_cache_context

    # In chat endpoint
    set_cache_context(
        tenant_short="t1abc",     # First 5 chars of tenant_id
        agent_short="a2def",      # First 5 chars of agent_id
        session_short="s3xyz"     # Last 5 chars of session_id
    )

Resulting display_name format:
    adk-<context>-<timestamp>-<count>contents
    Example: adk-t1abc-a2def-s3xyz-1770890928-1contents (38 chars)
"""

from contextvars import ContextVar
from dataclasses import dataclass
from typing import Optional


@dataclass
class CacheContext:
    """Context for identifying Gemini cache entries."""
    # Production fields (tenant, agent, session)
    tenant_short: Optional[str] = None
    agent_short: Optional[str] = None
    session_short: Optional[str] = None
    # Test fields (for backward compatibility with tests)
    test_name: Optional[str] = None
    agent_abbrev: Optional[str] = None


# ContextVar to store cache context for the current request
_cache_context_var: ContextVar[Optional[CacheContext]] = ContextVar(
    "cache_context", default=None
)


def set_cache_context(
    # Production fields
    tenant_short: Optional[str] = None,
    agent_short: Optional[str] = None,
    session_short: Optional[str] = None,
    # Test fields (backward compatibility)
    test_name: Optional[str] = None,
    agent_name: Optional[str] = None,
    session_suffix: Optional[str] = None
) -> None:
    """
    Set the cache context for the current request.

    This information will be included in the Gemini cache display_name
    for easier identification and debugging.

    The display_name has a 64-character max, so identifiers are truncated.

    Args:
        Production fields:
            tenant_short: Short tenant identifier (e.g., first 5 chars of tenant_id)
            agent_short: Short agent identifier (e.g., first 5 chars of agent_id)
            session_short: Short session identifier (e.g., last 5 chars of session_id)

        Test fields (backward compatibility):
            test_name: Name of the test (e.g., "test_cache_02")
            agent_name: Name of the agent (e.g., "Weather Test Agent")
            session_suffix: Session identifier suffix (e.g., "abc12345")
    """
    # If test fields provided, convert them to short format
    if test_name or agent_name:
        # Extract short identifiers from test context
        final_test = _extract_short_id(test_name, "tc")
        final_agent = _extract_agent_abbrev(agent_name) if agent_name else None
        final_session = _extract_short_id(session_suffix, "ss")

        context = CacheContext(
            test_name=final_test,
            agent_abbrev=final_agent,
            session_short=final_session,
        )
    else:
        # Use production fields directly
        context = CacheContext(
            tenant_short=_sanitize_id(tenant_short, 5) if tenant_short else None,
            agent_short=_sanitize_id(agent_short, 5) if agent_short else None,
            session_short=_sanitize_id(session_short, 5) if session_short else None,
        )

    _cache_context_var.set(context)


def _sanitize_id(value: Optional[str], max_len: int = 5) -> Optional[str]:
    """Sanitize identifier: keep alphanumeric, truncate to max_len."""
    if not value:
        return None
    # Keep only alphanumeric chars
    clean = "".join(c for c in value if c.isalnum())
    return clean[:max_len].lower() if clean else None


def _extract_short_id(value: Optional[str], prefix: str = "") -> Optional[str]:
    """
    Extract a short identifier from a value.
    Tries to find a number, otherwise truncates.

    Examples:
        "test_cache_02" -> "02"
        "abc123def" -> "123"
        "no_numbers" -> "nonum" (truncated)
    """
    if not value:
        return None

    import re
    # Try to find a number in the value
    match = re.search(r'(\d+)', value)
    if match:
        return match.group(1)[:3]  # Keep up to 3 digits

    # No number found, truncate
    clean = "".join(c for c in value if c.isalnum())
    return clean[:4].lower() if clean else None


def _extract_agent_abbrev(agent_name: Optional[str]) -> Optional[str]:
    """
    Extract abbreviation from agent name.
    Uses initials of words.

    Examples:
        "Weather Test Agent" -> "wta"
        "My Cool Bot" -> "mcb"
    """
    if not agent_name:
        return None

    words = agent_name.lower().split()
    if not words:
        return None

    # Take first letter of each word, max 3 letters
    initials = "".join(w[0] for w in words if w)[:3]
    return initials if initials else None


def get_cache_context() -> Optional[CacheContext]:
    """
    Get the current cache context.

    Returns:
        The current CacheContext or None if not set
    """
    return _cache_context_var.get()


def get_cache_context_suffix() -> str:
    """
    Build a suffix for the cache display_name based on current context.

    The Gemini CachedContent API display_name has a 64-character maximum.
    Target format: -<tenant:5>-<agent:5>-<session:5> (17 chars max)

    Returns:
        A string like "-t1abc-a2def-s3xyz" or empty string if no context is set.
    """
    context = get_cache_context()
    if not context:
        return ""

    parts = []

    # Handle production context (tenant, agent, session)
    if context.tenant_short:
        parts.append(context.tenant_short)
    elif context.test_name:
        parts.append(context.test_name)

    if context.agent_short:
        parts.append(context.agent_short)
    elif context.agent_abbrev:
        parts.append(context.agent_abbrev)

    if context.session_short:
        parts.append(context.session_short)

    if not parts:
        return ""

    return "-" + "-".join(parts)


def clear_cache_context() -> None:
    """Clear the cache context after request completes."""
    _cache_context_var.set(None)
