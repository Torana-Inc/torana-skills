"""Pydantic models for the App-graph wire format.

Stable contract between backend builders and any consumer (FE, CLI, MCP
tools). Keep this minimal — layout (x/y, lane ordering, edge curve type)
stays consumer-side because it depends on the surface doing the rendering.
"""

from __future__ import annotations

import enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class NodeKind(str, enum.Enum):
    """The kinds of nodes the App-graph supports.

    The FE renders each kind with its own styling; the CLI groups by kind
    in its text/table output; agents reason about the kind to apply
    kind-specific tools.
    """

    SOURCE   = "source"     # an integration (Slack, GitHub, Wiz, etc.)
    DATALAKE = "datalake"   # a base datalake table (vulnerabilities, repositories, ...)
    PIPELINE = "pipeline"   # a transformer
    RULE     = "rule"       # a detection rule
    ALERT    = "alert"      # synthetic node — the alerts a rule emits, lifecycle continues through routes/agent/playbook
    ROUTE    = "route"      # an alert-routing rule
    AGENT    = "agent"      # a workspace agent attachment
    PLAYBOOK = "playbook"   # a playbook


class EdgeStyle(str, enum.Enum):
    """Hint at how an edge should be drawn.

    The backend never picks pixel colours; it tells the consumer which
    *kind* of edge this is, and the consumer maps that to its own
    palette + line style.

      - ``primary`` — the load-bearing data-flow edge for a node (e.g.
        rule → its triggering datalake table). Renders prominently.
      - ``default`` — a normal data-flow edge.
      - ``dashed`` — a derived/inferred edge where the provenance isn't
        firmly stored anywhere (today: source → datalake, since the
        integration→table mapping lives in the ingest pipeline and is
        not surfaced by an API).
    """

    PRIMARY = "primary"
    DEFAULT = "default"
    DASHED  = "dashed"


class GraphNode(BaseModel):
    """One renderable node in the graph.

    ``id`` is ``{kind}:{artifact_id}``. For synthetic nodes the segment
    after the colon is a stable string identifier we mint (e.g.
    ``datalake:vulnerabilities``, ``outcome:alerts``). The ``raw``
    payload carries the source artifact so consumers can render
    kind-specific inspector content without making a second call.
    """

    id: str = Field(description="Stable id, shape `{kind}:{artifact_id}`.")
    kind: NodeKind
    title: str
    description: Optional[str] = None
    stats: List[str] = Field(
        default_factory=list,
        description="Short metric chips — e.g. `[\"critical\", \"HITL\"]`."
    )
    raw: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Source artifact payload. Null for synthetic nodes."
    )

    model_config = {"use_enum_values": True}


class GraphEdge(BaseModel):
    """One directed connection between two nodes.

    ``style`` is rendering guidance only; it never carries semantic
    meaning (consumers must not infer "this edge is real because it's
    primary" — the existence of the edge IS the assertion). The hint
    just helps the consumer pick a colour/dash pattern.
    """

    from_id: str = Field(alias="from", description="Source node id.")
    to_id: str = Field(alias="to", description="Target node id.")
    style: EdgeStyle = EdgeStyle.DEFAULT
    label: Optional[str] = Field(
        default=None,
        description="Optional short label rendered on the edge (e.g. trigger condition)."
    )

    model_config = {"populate_by_name": True, "use_enum_values": True}


class AppGraph(BaseModel):
    """The full graph response for one workspace."""

    workspace_id: str
    nodes: List[GraphNode] = Field(default_factory=list)
    edges: List[GraphEdge] = Field(default_factory=list)
    # Echo the artifact totals so a caller can see at a glance whether
    # the graph reflects everything in the workspace or only a slice.
    counts: Dict[str, int] = Field(
        default_factory=dict,
        description="Per-kind counts of real (non-overflow / non-empty) nodes."
    )
