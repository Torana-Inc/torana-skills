"""App-graph node + edge schemas and the deterministic stitching helper.

The graph of an "App" (workspace) is the visualization of its data flow:
Sources → Datalake → Pipeline → Agents → Rules → Routes → Playbooks →
Outcomes. The backend exposes this as a single endpoint so the FE, CLI,
agents, MCP tools, and CI can all consume one canonical answer instead
of each re-stitching it from six list calls.

This package owns the *contract* (Pydantic models) and the *builder*
(``build_app_graph``). Any service that publishes a graph endpoint
imports from here; that way the schema and the join logic live in one
place.
"""

from pantheon_shared.graph.schemas import (
    AppGraph,
    GraphEdge,
    GraphNode,
    NodeKind,
    EdgeStyle,
)
from pantheon_shared.graph.build import build_app_graph

__all__ = [
    "AppGraph",
    "GraphEdge",
    "GraphNode",
    "NodeKind",
    "EdgeStyle",
    "build_app_graph",
]
