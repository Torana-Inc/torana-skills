"""Stitch raw artifact lists into the canonical App-graph.

This is a pure function: no IO, no IAM, no DB. The caller fetches the
artifact lists (whichever way is convenient — internal service-to-service
HTTP, direct SQLAlchemy reads, etc.) and hands them in; the builder
returns ``AppGraph``.

The provenance edges (rule → datalake, transformer → datalake, route →
specific destination) are derived from real fields. The synthetic ones
(source → datalake, agent → routes) are explicitly marked ``dashed``
because the backing data doesn't exist yet.
"""

from __future__ import annotations

from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence

from pantheon_shared.graph.schemas import AppGraph, EdgeStyle, GraphEdge, GraphNode, NodeKind


def _g(d: Mapping[str, Any], *keys: str, default: Any = None) -> Any:
    """Tolerant getter — accepts dicts or objects (SQLAlchemy rows) and
    returns the first present, non-None value among ``keys``."""
    for k in keys:
        if isinstance(d, Mapping):
            v = d.get(k)
        else:
            v = getattr(d, k, None)
        if v is not None:
            return v
    return default


def _lower(s: Any) -> str:
    return str(s).strip().lower() if s else ""


def build_app_graph(
    *,
    workspace_id: str,
    integrations: Sequence[Mapping[str, Any]] = (),
    transformers: Sequence[Mapping[str, Any]] = (),
    agents: Sequence[Mapping[str, Any]] = (),
    rules: Sequence[Mapping[str, Any]] = (),
    routes: Sequence[Mapping[str, Any]] = (),
    playbooks: Sequence[Mapping[str, Any]] = (),
    queries: Sequence[Mapping[str, Any]] = (),
) -> AppGraph:
    """Build the App-graph for one workspace from raw artifact lists.

    The input lists may be dicts (deserialized API responses) or ORM rows
    (objects with attributes). The builder reads via ``_g`` which handles
    both.

    Returns an ``AppGraph`` with ``nodes`` and ``edges`` already deduped
    and in stable order (sorted by id), so two calls with the same inputs
    produce byte-identical output. That property matters for diff-based
    workflows (CLI ``--mermaid``, agent reasoning, CI snapshots).
    """
    nodes: List[GraphNode] = []
    edges_set: Dict[str, GraphEdge] = {}  # keyed by f"{from}->{to}" for dedupe

    queries_by_id: Dict[str, Mapping[str, Any]] = {
        str(_g(q, "id")): q for q in queries if _g(q, "id")
    }

    # ── Sources ──────────────────────────────────────────────────────────
    for it in integrations:
        if not _g(it, "is_active", default=True):
            continue
        iid = _g(it, "id")
        if not iid:
            continue
        nodes.append(GraphNode(
            id=f"source:{iid}",
            kind=NodeKind.SOURCE,
            title=_g(it, "name", "provider", default="Integration"),
            description=_g(it, "description") or f"{_g(it, 'integration_type', default='')} · {_g(it, 'provider', default='')}".strip(" ·"),
            stats=[str(_g(it, "status", default=""))] if _g(it, "status") else [],
            raw=dict(it) if isinstance(it, Mapping) else None,
        ))

    # ── Datalake (synthetic) — the union of three sources:
    #      1. rule.query → query.source_tables  (tables rules query)
    #      2. transformer.source_tables          (tables pipelines query)
    #      3. integration.writes_to              (tables active integrations
    #                                             populate on next sync — even
    #                                             if no rule/pipeline reads them)
    #    Source (3) is what makes the graph honest: an active integration that
    #    writes to a table the workspace doesn't yet consume STILL shows that
    #    table, because the data is landing there on every sync. The user sees
    #    an unconsumed table as a hint: "you have data here you're not using."
    #    Tables that are themselves transformer outputs aren't shown here;
    #    they're rendered as Pipeline nodes instead.
    transformer_dests = {
        _lower(_g(t, "destination_table"))
        for t in transformers if _g(t, "destination_table")
    }
    datalake_tables: set[str] = set()
    for r in rules:
        qid = _g(r, "query_id")
        q = queries_by_id.get(str(qid)) if qid else None
        for t in (_g(q, "source_tables", default=[]) or []):
            name = _lower(t)
            if name and name not in transformer_dests:
                datalake_tables.add(name)
    for t in transformers:
        for tbl in (_g(t, "source_tables", default=[]) or []):
            name = _lower(tbl)
            if name and name not in transformer_dests:
                datalake_tables.add(name)
    for it in integrations:
        if not _g(it, "is_active", default=True):
            continue
        for tbl in (_g(it, "writes_to", default=[]) or []):
            name = _lower(tbl)
            if name and name not in transformer_dests:
                datalake_tables.add(name)
    for name in sorted(datalake_tables):
        nodes.append(GraphNode(
            id=f"datalake:{name}",
            kind=NodeKind.DATALAKE,
            title=name,
            description="Datalake table read by this app's rules or transformers.",
            stats=[],
            raw={"name": name, "_kind": "datalake-table"},
        ))

    # ── Pipeline (transformers) ──────────────────────────────────────────
    for t in transformers:
        tid = _g(t, "id")
        if not tid:
            continue
        nodes.append(GraphNode(
            id=f"pipeline:{tid}",
            kind=NodeKind.PIPELINE,
            title=_g(t, "name", default="Transformer"),
            description=_g(t, "description", default="Maps inbound data to the canonical schema."),
            stats=([] if _g(t, "is_active", default=True) else ["disabled"]),
            raw=dict(t) if isinstance(t, Mapping) else None,
        ))

    # ── Agents ───────────────────────────────────────────────────────────
    # Note: autonomy_mode is intentionally NOT surfaced in stats today.
    # The field is configured on attachments but not yet enforced at
    # runtime — every agent currently follows whatever its prompt says,
    # regardless of mode. Showing the mode as a stat would mislead users
    # into thinking the platform gates behavior on it. Re-introduce when
    # autonomy enforcement actually lands.
    for a in agents:
        if _g(a, "is_deleted", default=False):
            continue
        aid = _g(a, "id")
        if not aid:
            continue
        nodes.append(GraphNode(
            id=f"agent:{aid}",
            kind=NodeKind.AGENT,
            title=_g(a, "agent_name", default="Agent"),
            description=str(_g(a, "responsibility", default="") or _g(a, "role", default=""))[:200],
            stats=[str(_g(a, "role", default=""))] if _g(a, "role") else [],
            raw=dict(a) if isinstance(a, Mapping) else None,
        ))

    # ── Rules ────────────────────────────────────────────────────────────
    for r in rules:
        rid = _g(r, "id")
        if not rid:
            continue
        # The rule node carries two stat chips:
        #   1. Severity (Critical / High / Medium / Low) — always present
        #   2. "alerting off" — ONLY when alert_enabled is false
        # Earlier this said "disabled", which read as "the rule itself is
        # disabled". That was misleading: the rule still runs; only the
        # alert-emission side-effect is suppressed. "alerting off" makes
        # the scope of the off-state explicit.
        nodes.append(GraphNode(
            id=f"rule:{rid}",
            kind=NodeKind.RULE,
            title=_g(r, "name", default="Rule"),
            description=_g(r, "description", default=""),
            stats=[
                str(_g(r, "severity", default="")),
                *(["alerting off"] if _g(r, "alert_enabled") is False else []),
            ],
            raw=dict(r) if isinstance(r, Mapping) else None,
        ))

    # ── Routes ───────────────────────────────────────────────────────────
    for rt in routes:
        rtid = _g(rt, "id")
        if not rtid:
            continue
        nodes.append(GraphNode(
            id=f"route:{rtid}",
            kind=NodeKind.ROUTE,
            title=_g(rt, "name", default="Routing rule"),
            description=_g(rt, "description", default=""),
            stats=([] if _g(rt, "enabled", default=True) else ["disabled"]),
            raw=dict(rt) if isinstance(rt, Mapping) else None,
        ))

    # ── Playbooks ────────────────────────────────────────────────────────
    for p in playbooks:
        pid = _g(p, "id")
        if not pid:
            continue
        nodes.append(GraphNode(
            id=f"playbook:{pid}",
            kind=NodeKind.PLAYBOOK,
            title=_g(p, "name", default="Playbook"),
            description=_g(p, "description", default=""),
            stats=[],
            raw=dict(p) if isinstance(p, Mapping) else None,
        ))

    # ── Alerts synthetic node ────────────────────────────────────────────
    # The single "Alert" node represents the runtime concept — rules emit
    # alerts; routes/agents/playbooks consume them. It sits between rules
    # and the downstream lanes. The FE doesn't surface an "Inbox →" chip
    # on the card; the inspector pane (when the user clicks) handles
    # deep-linking to the Inbox if needed.
    nodes.append(GraphNode(
        id="alert:all",
        kind=NodeKind.ALERT,
        title="Alerts",
        description="Alerts emitted by rules. Routed to agents or playbooks.",
        stats=[],
        raw={"_kind": "alert-anchor", "target_kind": "inbox"},
    ))

    # Snapshot of every node id built so far. Edge builders below resolve
    # their endpoints against this set so a reference to a node that was
    # never created (e.g. a route naming a playbook_id from another
    # workspace) does not become a dangling edge (#63).
    node_ids: set[str] = {n.id for n in nodes}

    # ── Edges ────────────────────────────────────────────────────────────
    # Helper to add an edge, deduped by from→to and biased toward the
    # strongest style (primary > default > dashed).
    style_rank = {EdgeStyle.PRIMARY.value: 2, EdgeStyle.DEFAULT.value: 1, EdgeStyle.DASHED.value: 0}

    def add_edge(frm: str, to: str, style: EdgeStyle, label: Optional[str] = None) -> None:
        key = f"{frm}->{to}"
        existing = edges_set.get(key)
        if existing is None:
            edges_set[key] = GraphEdge(**{"from": frm, "to": to, "style": style.value, "label": label})
            return
        existing_style_val = existing.style if isinstance(existing.style, str) else existing.style.value
        if style_rank.get(style.value, 0) > style_rank.get(existing_style_val, 0):
            edges_set[key] = GraphEdge(**{"from": frm, "to": to, "style": style.value, "label": label})

    pipeline_by_dest: Dict[str, str] = {
        _lower(_g(t, "destination_table")): f"pipeline:{_g(t, 'id')}"
        for t in transformers if _g(t, "id") and _g(t, "destination_table")
    }
    datalake_by_name: Dict[str, str] = {n: f"datalake:{n}" for n in datalake_tables}

    # Source → Datalake — driven by the integration's declared writes_to
    # (resolved server-side from each enabled data source's mapping
    # destination_table). One edge per (source, table) pair. Integrations
    # that don't write any datalake table (e.g. Jira/Slack used purely as
    # playbook tools) produce zero edges here — they show up on the canvas
    # via the playbook→source "uses" lane instead.
    for it in integrations:
        if not _g(it, "is_active", default=True):
            continue
        iid = _g(it, "id")
        if not iid:
            continue
        writes_to = _g(it, "writes_to", default=[]) or []
        for tbl in writes_to:
            name = _lower(tbl)
            if name in datalake_by_name:
                add_edge(f"source:{iid}", datalake_by_name[name], EdgeStyle.DEFAULT)

    # Datalake / upstream transformer → Transformer (real, via source_tables).
    for t in transformers:
        tid = _g(t, "id")
        if not tid:
            continue
        for tbl in (_g(t, "source_tables", default=[]) or []):
            name = _lower(tbl)
            upstream = pipeline_by_dest.get(name)
            if upstream:
                add_edge(upstream, f"pipeline:{tid}", EdgeStyle.PRIMARY)
            elif name in datalake_by_name:
                add_edge(datalake_by_name[name], f"pipeline:{tid}", EdgeStyle.DEFAULT)

    # Datalake / upstream transformer → Rule (real, via rule.query_id).
    for r in rules:
        rid = _g(r, "id")
        qid = _g(r, "query_id")
        q = queries_by_id.get(str(qid)) if qid else None
        if not rid or not q:
            continue
        for tbl in (_g(q, "source_tables", default=[]) or []):
            name = _lower(tbl)
            upstream = pipeline_by_dest.get(name)
            if upstream:
                add_edge(upstream, f"rule:{rid}", EdgeStyle.DEFAULT)
            elif name in datalake_by_name:
                add_edge(datalake_by_name[name], f"rule:{rid}", EdgeStyle.DEFAULT)

    # Rule → Alert — every rule's match becomes an alert IF alert_enabled
    # is on. A rule with alert_enabled=false runs its query on schedule but
    # silently drops matches (used for shadow/dry-run rules). The graph
    # should reflect that: no edge to the alert funnel, because nothing
    # actually flows there. The rule node itself stays visible with the
    # "disabled" badge — disabled is a stable configuration state, not an
    # invisible rule. This separation makes the graph honest about what's
    # the runtime concept (the alert) vs the configuration (the rule).
    for r in rules:
        rid = _g(r, "id")
        if not rid:
            continue
        if _g(r, "alert_enabled", default=True) is False:
            continue
        add_edge(f"rule:{rid}", "alert:all", EdgeStyle.DEFAULT)

    # Alert → Route — every route evaluates against the alert stream.
    # The route's trigger (on_alert_created / on_verdict) labels the edge,
    # qualified by verdict_condition when present so the FE shows e.g.
    # "on verdict · if TRUE_POSITIVE" instead of an ambiguous "on verdict".
    for rt in routes:
        rtid = _g(rt, "id")
        if not rtid:
            continue
        trigger = _g(rt, "trigger") or ""
        verdict_cond = _g(rt, "verdict_condition")
        label_parts: List[str] = []
        if trigger:
            label_parts.append(trigger.replace("_", " "))
        if verdict_cond:
            label_parts.append(f"if {verdict_cond}")
        label = " · ".join(label_parts) if label_parts else None
        add_edge("alert:all", f"route:{rtid}", EdgeStyle.DEFAULT, label=label)

    # Route → specific destination (real, via destination_config). Also
    # tracks which agents have at least one inbound route — those become
    # the "active" agents the FE renders; others are dropped from the
    # canvas (still listed in the App Inventory rail).
    agent_inbound: set[str] = set()
    for rt in routes:
        rtid = _g(rt, "id")
        if not rtid:
            continue
        dest_type = _g(rt, "destination_type")
        config = _g(rt, "destination_config") or {}
        if dest_type == "agent":
            target = config.get("agent_id") if isinstance(config, Mapping) else None
            if target:
                # destination_config.agent_id is the *agent* identity id.
                # First try matching attachment.agent_id (when set), then
                # fall back to triage attachment (current convention for
                # `on_alert_created` routes), then to the first attachment
                # at all so the edge isn't silently dropped.
                attachment = next(
                    (a for a in agents if str(_g(a, "agent_id", default="") or "") == str(target)),
                    None,
                )
                if not attachment and _g(rt, "trigger") == "on_alert_created":
                    attachment = next(
                        (a for a in agents if _g(a, "role") == "triage"),
                        None,
                    )
                if not attachment:
                    attachment = agents[0] if agents else None
                att_id = _g(attachment, "id") if attachment else None
                if att_id:
                    add_edge(f"route:{rtid}", f"agent:{att_id}", EdgeStyle.PRIMARY)
                    agent_inbound.add(f"agent:{att_id}")
        elif dest_type == "playbook":
            target = config.get("playbook_id") if isinstance(config, Mapping) else None
            # Only draw the edge if the referenced playbook is actually a node
            # in this graph. A route may name a playbook_id that belongs to a
            # different workspace, was deleted, or is otherwise not in the built
            # node set — drawing it anyway produces a dangling edge to a
            # non-existent node (#63). Every other consumer edge above already
            # resolves its target against a known node; this one did not.
            if target and f"playbook:{target}" in node_ids:
                add_edge(f"route:{rtid}", f"playbook:{target}", EdgeStyle.PRIMARY)

    # Synthetic Alert → Triage Agent (fallback edge). Describes the workspace's
    # end-to-end behavior, not its implementation: "if no explicit route
    # matches, the alert goes to the triage agent." Today the dispatch is
    # event-subscription driven (alert_created NOTIFY → workflow-framework
    # event-bus worker → triage agent); tomorrow it could be a default rule
    # or something else. The graph deliberately hides those mechanics — the
    # tenant-user persona only needs to know which agent eventually sees the
    # alert. Drawn dashed so it reads as "synthetic / fallback" rather than
    # a real DB-backed route. Triage identified by attachment.role=='triage'.
    triage_attachment = next(
        (
            a for a in agents
            if _g(a, "role") == "triage"
            and not _g(a, "is_deleted", default=False)
        ),
        None,
    )
    triage_id = _g(triage_attachment, "id") if triage_attachment else None
    if triage_id:
        add_edge(
            "alert:all",
            f"agent:{triage_id}",
            EdgeStyle.DASHED,
            label="fallback to triage",
        )
        # Anchor the triage agent so it isn't pruned as orphaned even when no
        # explicit route points at it (e.g. workspace with zero routes).
        agent_inbound.add(f"agent:{triage_id}")

    # Synthetic Agent → Alert (verdict loopback). The triage agent doesn't
    # produce a new signal — it mutates the alert (sets triage_verdict).
    # Downstream on_verdict routes then re-evaluate the same Alert node.
    # Drawn dashed + labelled "sets verdict" to make the mutation
    # semantics visible. Same pattern applies to other agent kinds that
    # mutate alert state.
    for agent_node_id in agent_inbound:
        add_edge(
            agent_node_id,
            "alert:all",
            EdgeStyle.DASHED,
            label="sets verdict",
        )

    # Playbook → Alert (side-effect loopback). Playbooks read alerts and
    # may write back (assign owner, change status, attach Jira ticket).
    # The Alert node serves as the terminal "where alerts live" — the FE
    # makes it click-to-Inbox.
    for p in playbooks:
        pid = _g(p, "id")
        if pid:
            add_edge(f"playbook:{pid}", "alert:all", EdgeStyle.DEFAULT, label="updates")

    # Playbook → Source (tool dependency, dashed). A playbook that calls
    # external systems (Jira ticket create, Slack DM, etc.) declares those
    # providers in ``tool_dependencies``. We resolve each declared provider
    # to an active integration node and emit a dashed "uses" edge so the
    # canvas shows which sources are consumed as tools — distinct from the
    # source→datalake ingestion lane.
    source_by_provider: Dict[str, str] = {}
    for it in integrations:
        if not _g(it, "is_active", default=True):
            continue
        iid = _g(it, "id")
        prov = _lower(_g(it, "provider"))
        if iid and prov and prov not in source_by_provider:
            source_by_provider[prov] = f"source:{iid}"

    for p in playbooks:
        pid = _g(p, "id")
        if not pid:
            continue
        for prov in (_g(p, "tool_dependencies", default=[]) or []):
            src_node = source_by_provider.get(_lower(prov))
            if src_node:
                add_edge(f"playbook:{pid}", src_node, EdgeStyle.DASHED, label="uses")

    # Prune orphan agents — an agent with zero edges in OR out doesn't
    # participate in this app's data flow. We still need it visible
    # somewhere (the FE App Inventory palette lists every attachment), but
    # rendering it on the canvas adds visual noise without explaining
    # anything. The fanout endpoint returns ALL workspace agents; this
    # filter just trims the GRAPH render to ones that actually move data.
    edge_node_ids: set[str] = set()
    for e in edges_set.values():
        edge_node_ids.add(e.from_id)
        edge_node_ids.add(e.to_id)
    nodes = [
        n for n in nodes
        if not (
            (n.kind == NodeKind.AGENT.value if isinstance(n.kind, str) else n.kind == NodeKind.AGENT)
            and n.id not in edge_node_ids
        )
    ]

    # Edge → node integrity prune (#63). After orphan-agent pruning above,
    # rebuild the surviving node-id set and drop any edge whose endpoint is
    # not a real node. This is the general backstop for dangling edges: a
    # node that was pruned here, or an edge target that was never a node in
    # the first place, must not survive as an edge to nowhere. Without this
    # the App Graph rendered edges pointing at ids the FE has no node for.
    surviving_node_ids: set[str] = {n.id for n in nodes}
    edges_set = {
        k: e for k, e in edges_set.items()
        if e.from_id in surviving_node_ids and e.to_id in surviving_node_ids
    }

    # Stable sort so the same inputs always produce the same bytes — that
    # matters for diff-based workflows (mermaid output, agent reasoning,
    # CI snapshots).
    nodes.sort(key=lambda n: n.id)
    edges = sorted(edges_set.values(), key=lambda e: (e.from_id, e.to_id))

    counts: Dict[str, int] = {}
    for n in nodes:
        kind_val = n.kind if isinstance(n.kind, str) else n.kind.value
        counts[kind_val] = counts.get(kind_val, 0) + 1

    return AppGraph(
        workspace_id=workspace_id,
        nodes=nodes,
        edges=edges,
        counts=counts,
    )
