"""
Per-worker metrics snapshot emitter (G-X-2, D4).

Every service runs several gunicorn workers, each with its own in-memory counters for LLM
calls, east-west HTTP calls and datalake queries, plus its own SQLAlchemy connection
pool(s). None of that is logged, scraped or stored anywhere today (see
`pantheon-deploy/docs/GRAFANA_DASHBOARDS_ROADMAP.md` § "Information that exists but isn't
emitted" — G-X-2). This module closes that gap with ONE primitive: call
`start_metrics_snapshot_emitter(service_name)` once per worker, after gunicorn forks, and
every `interval_seconds` (default 60) it logs ONE FLAT logfmt line PER THING MEASURED (via
`log_event`, so Loki/Grafana gets it), never a nested dict crammed into one value:

- `metrics.snapshot.http` — one line per (caller, target) pair with a delta, carrying
  `caller`, `target`, `requests`, `s2xx`/`s3xx`/`s4xx`/`s5xx` and the duration buckets
  (`lt_100ms`, `lt_500ms`, `lt_2s`, `lt_10s`, `ge_10s`) as top-level int fields. `s409` is
  a SUBSET of `s4xx`, not instead of it: `PantheonClient` treats 409 as non-error (startup
  idempotent re-registration), so a caller→callee pair that is 100% 409 looks like 100%
  4xx failures on a naive dashboard unless `s409` is subtracted out first.
- `metrics.snapshot.pool` — one line per engine this process holds, carrying `engine`,
  `pool_size`, `checked_out`, `overflow`. NOT a counter, so logged as-is (current value),
  never as a delta.
- `metrics.snapshot.llm` — one line per (llm-service, model) pair with a delta, carrying
  `llm_service`, `model`, `calls`, `errors`, `rate_limited`, `latency_ms_sum`. No
  `latency_ms_max`: `LLMCallMetrics` tracks only a service-wide cumulative max, never a
  per-model one, so reporting it per-model would look like real per-model data it isn't.
  `rate_limit_hit_count` is service-wide too, so it gets its own line per llm-service
  (`model="__all__"`) rather than being duplicated onto every model's line.
- `metrics.snapshot.datalake` — one line per backend with a delta, carrying `caller`,
  `queries`, `latency_ms_sum`. No `latency_ms_max`: `DataLakeClientMetrics` tracks no
  max-latency field at all (only slow/very-slow query COUNTS past fixed thresholds), so
  there is nothing honest to report there.

Every line's top-level `service` field is the Loki stream's own service name
(`pantheon-<x>`, matching `{service="pantheon-<x>-dev"}` minus the `-dev` suffix) so a
panel can `sum by (service)` or join `caller`/`target` against it. **Nothing is emitted
for an empty category** — no line at all, rather than a line with zero fields, so a LogQL
query never has to filter out noise.

Every field name is a plain logfmt/LogQL label: `s2xx` not `2xx` (LogQL label names can't
start with a digit), so `| logfmt | unwrap requests` (or any other field) works directly
without a regex over a nested blob. This was tried once as nested dicts rendered into a
single `http="{...}"` value and found unqueryable in Loki (not valid JSON — Python dict
repr, single-quoted) — see the fix note in `GRAFANA_DASHBOARDS_ROADMAP.md` W2's entry.

Rules for C (`GRAFANA_DASHBOARDS_ROADMAP.md` § "Where the data comes from"), restated here
because this module is where they are enforced:

1. Every worker logs its OWN snapshot (`service`, `worker_pid`, `hostname`). No leader
   election, no cross-worker coordination — each service's workers fork independently and
   a dashboard panel does `sum by (service)` with `last_over_time` per worker.
2. In-memory counters reset on restart, so they are logged as DELTAS since the last
   snapshot, never as running totals.
3. This code path NEVER opens a DB session and NEVER makes a network call. Reading
   in-memory counters and calling `AsyncEngineManager.pool_stats()` (which only
   introspects the SQLAlchemy pool object already held in-process) is fine — that is not a
   network call. If you are tempted to add anything that awaits an HTTP client or a DB
   session here, it belongs in option A (the Postgres datasource) instead.
4. It must start AFTER gunicorn forks, not at import time — call it from each worker's own
   post-fork startup (a FastAPI lifespan/startup hook), not from module-level code that
   runs once in the master before forking and would make every worker think it already
   started.

Each service calls `start_metrics_snapshot_emitter()` from its own FastAPI lifespan, right
after its logging setup (W2 in `GRAFANA_DASHBOARDS_ROADMAP.md`). This module never wires
itself in. Tests: `tests/test_metrics_snapshot.py`.
"""

import os
import socket
import threading
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

from .logging import get_logger
from .logging_events import log_event

logger = get_logger(__name__)

#: Event name every snapshot line is logged under (G-X-2).
METRICS_SNAPSHOT_EVENT = "metrics.snapshot"

#: Default interval between snapshots, in seconds (the roadmap's "every 60s").
DEFAULT_INTERVAL_SECONDS = 60


def _hostname() -> str:
    """Best-effort hostname, matching the convention already used by `logging.py`."""
    host = os.environ.get("HOSTNAME")
    if host:
        return host
    try:
        return socket.gethostname()
    except Exception:
        return "unknown"


@dataclass
class _LLMModelSnapshot:
    """Last-seen CUMULATIVE values for one (service, model) pair, to diff against."""
    calls: int = 0
    errors: int = 0
    rate_limit_hits: int = 0
    latency_total: float = 0.0


@dataclass
class _EmitterState:
    """Everything one running emitter needs to compute deltas between ticks.

    All "last_*" fields hold the CUMULATIVE value observed at the previous tick, never a
    delta — the delta is `current - last`, computed fresh each tick and then the "last"
    value is advanced to `current`.
    """
    # llm/metrics.py: per (llm-service-key, model) cumulative snapshot.
    last_llm: Dict[str, Dict[str, _LLMModelSnapshot]] = field(default_factory=dict)
    # http/client.py ClientMetrics: per (client-service-key, target_service) cumulative dict.
    last_http: Dict[str, Dict[str, Dict[str, Any]]] = field(default_factory=dict)
    # datalake/metrics.py: per backend_type cumulative dict.
    last_datalake: Dict[str, Dict[str, Any]] = field(default_factory=dict)


def _delta(current: float, last: float) -> float:
    """`current - last`, clamped at 0.

    A negative delta means the counter was RESET underneath us (process restart reusing a
    registry key, or a `reset_*_metrics()` admin call) rather than genuinely going
    backwards, since every source here is monotonically increasing between resets. Treating
    it as 0 for that tick is more honest than emitting a negative count on a dashboard.
    """
    return max(current - last, 0)


def _emit_snapshot_line(event: str, service_name: str, **fields: Any) -> None:
    """One flat `log_event` call shared by every collector below.

    Always carries `service`, `worker_pid`, `hostname` so a panel can `sum by (service)`
    or filter to one worker, exactly like the old single-line shape did — the difference
    is that every OTHER field is a top-level scalar too, never a nested dict rendered into
    one value (that was tried and found unqueryable in Loki — see the module docstring).
    """
    log_event(
        event,
        tenant_id="platform",
        status="ok",
        service=service_name,
        worker_pid=os.getpid(),
        hostname=_hostname(),
        **fields,
    )


def _emit_llm_deltas(service_name: str, state: _EmitterState) -> None:
    """One `metrics.snapshot.llm` line per (llm-service, model) with a nonzero delta."""
    try:
        from .llm.metrics import get_all_llm_metrics
    except Exception:
        return

    try:
        all_metrics = get_all_llm_metrics()
        for llm_service, metrics in all_metrics.items():
            last_models = state.last_llm.setdefault(llm_service, {})
            for model, call_count in metrics.model_call_counts.items():
                last = last_models.setdefault(model, _LLMModelSnapshot())
                error_count = metrics.model_error_counts.get(model, 0)
                latency_total = metrics.model_latency_totals.get(model, 0.0)

                calls_delta = _delta(call_count, last.calls)
                errors_delta = _delta(error_count, last.errors)
                latency_delta = _delta(latency_total, last.latency_total)

                last.calls = call_count
                last.errors = error_count
                last.latency_total = latency_total

                if not (calls_delta or errors_delta or latency_delta):
                    continue  # nothing changed for this model this tick — emit nothing

                # `LLMCallMetrics` tracks only a service-wide cumulative `max_latency`, never
                # a per-model one — reporting it on every model's line would look like
                # per-model data it isn't. `latency_ms_max` is omitted here; only the true
                # per-model `latency_ms_sum` (divide by `calls` for the per-tick average).
                _emit_snapshot_line(
                    "metrics.snapshot.llm",
                    service_name,
                    llm_service=llm_service,
                    model=model,
                    calls=calls_delta,
                    errors=errors_delta,
                    rate_limited=0,  # per-service only (see below) — this line is per-model
                    latency_ms_sum=round(latency_delta * 1000, 2),
                )

            # rate_limit_hit_count is tracked per-service, not per-model, in LLMCallMetrics —
            # its own line, not folded into a per-model one.
            rl_key = "__rate_limit__"
            last_rl = last_models.setdefault(rl_key, _LLMModelSnapshot())
            rl_delta = _delta(metrics.rate_limit_hit_count, last_rl.rate_limit_hits)
            last_rl.rate_limit_hits = metrics.rate_limit_hit_count
            if rl_delta:
                _emit_snapshot_line(
                    "metrics.snapshot.llm",
                    service_name,
                    llm_service=llm_service,
                    model="__all__",
                    calls=0,
                    errors=0,
                    rate_limited=rl_delta,
                    latency_ms_sum=0,
                )
    except Exception:
        logger.warning("metrics-snapshot-llm-collection-failed", exc_info=True)


def _emit_http_deltas(service_name: str, state: _EmitterState) -> None:
    """One `metrics.snapshot.http` line per (caller, target) pair with a nonzero delta."""
    try:
        from .http.client import PantheonClient
    except Exception:
        return

    try:
        registry = PantheonClient._metrics_registry
        for client_service, client_metrics in registry.items():
            last_targets = state.last_http.setdefault(client_service, {})

            for target_service, target_metrics in client_metrics.by_target.items():
                last = last_targets.setdefault(target_service, {
                    "num_2xx": 0, "num_3xx": 0, "num_4xx": 0, "num_5xx": 0, "num_409": 0,
                    "total_requests": 0, "duration_buckets": {},
                })

                requests_delta = _delta(target_metrics.total_requests, last["total_requests"])
                s2xx_delta = _delta(target_metrics.num_2xx, last["num_2xx"])
                s3xx_delta = _delta(target_metrics.num_3xx, last["num_3xx"])
                s4xx_delta = _delta(target_metrics.num_4xx, last["num_4xx"])
                s5xx_delta = _delta(target_metrics.num_5xx, last["num_5xx"])
                # Subset of s4xx, not instead of it — see `PerTargetMetrics.num_409`'s
                # docstring in http/client.py for why 409 needs to be split out.
                s409_delta = _delta(target_metrics.num_409, last["num_409"])
                bucket_deltas = {
                    name: _delta(count, last["duration_buckets"].get(name, 0))
                    for name, count in target_metrics.duration_buckets.items()
                }

                last["num_2xx"] = target_metrics.num_2xx
                last["num_3xx"] = target_metrics.num_3xx
                last["num_4xx"] = target_metrics.num_4xx
                last["num_5xx"] = target_metrics.num_5xx
                last["num_409"] = target_metrics.num_409
                last["total_requests"] = target_metrics.total_requests
                last["duration_buckets"] = dict(target_metrics.duration_buckets)

                if not requests_delta:
                    continue  # nothing happened on this (caller, target) pair this tick

                _emit_snapshot_line(
                    "metrics.snapshot.http",
                    service_name,
                    caller=client_service,
                    target=target_service,
                    requests=requests_delta,
                    s2xx=s2xx_delta,
                    s3xx=s3xx_delta,
                    s4xx=s4xx_delta,
                    s409=s409_delta,
                    s5xx=s5xx_delta,
                    lt_100ms=bucket_deltas.get("lt_100ms", 0),
                    lt_500ms=bucket_deltas.get("lt_500ms", 0),
                    lt_2s=bucket_deltas.get("lt_2s", 0),
                    lt_10s=bucket_deltas.get("lt_10s", 0),
                    ge_10s=bucket_deltas.get("ge_10s", 0),
                )
    except Exception:
        logger.warning("metrics-snapshot-http-collection-failed", exc_info=True)


def _emit_datalake_deltas(service_name: str, state: _EmitterState) -> None:
    """One `metrics.snapshot.datalake` line per backend with a nonzero delta."""
    try:
        from .datalake.metrics import get_datalake_metrics_registry
    except Exception:
        return

    try:
        registry = get_datalake_metrics_registry()
        all_metrics = registry.get_all_metrics()
        for backend_type, metrics in all_metrics.items():
            last = state.last_datalake.setdefault(backend_type, {
                "total_queries": 0, "failed_queries": 0, "total_query_time": 0.0,
                "total_inserts": 0, "total_upserts": 0, "failed_writes": 0,
            })

            queries_delta = _delta(metrics.total_queries, last["total_queries"])
            query_time_delta = _delta(metrics.total_query_time, last["total_query_time"])

            last["total_queries"] = metrics.total_queries
            last["failed_queries"] = metrics.failed_queries
            last["total_query_time"] = metrics.total_query_time
            last["total_inserts"] = metrics.total_inserts
            last["total_upserts"] = metrics.total_upserts
            last["failed_writes"] = metrics.failed_writes

            if not queries_delta:
                continue  # no queries against this backend this tick

            # `DataLakeClientMetrics` tracks no max-latency field at all (confirmed by
            # reading datalake/metrics.py — only slow/very-slow query COUNTS past fixed
            # thresholds). `latency_ms_max` would have to be a hardcoded 0, indistinguishable
            # from a real zero on a dashboard, so it is omitted rather than faked.
            _emit_snapshot_line(
                "metrics.snapshot.datalake",
                service_name,
                caller=backend_type,
                queries=queries_delta,
                latency_ms_sum=round(query_time_delta * 1000, 2),
            )
    except Exception:
        logger.warning("metrics-snapshot-datalake-collection-failed", exc_info=True)


def _pool_stats_from_raw_engine(engine: Any) -> Dict[str, Any]:
    """Same shape as `AsyncEngineManager.pool_stats()`, for an engine not wrapped in one.

    A plain `create_async_engine()`/`create_engine()` result still has a SQLAlchemy `Pool`
    at `.pool` with the same `size()`/`checkedout()`/`overflow()` methods `pool_stats()`
    reads — this is the same introspection, just without the `AsyncEngineManager` wrapper.
    """
    try:
        pool = engine.pool
        return {
            "pool_size": pool.size(),
            "checked_out": pool.checkedout(),
            "overflow": pool.overflow(),
        }
    except Exception:  # pragma: no cover - pool introspection is advisory
        return {}


def _emit_pool_stats(service_name: str) -> None:
    """One `metrics.snapshot.pool` line per engine this process holds (current, not a delta).

    Covers two registries: `AsyncEngineManager` instances (self-registering) and raw
    engines a service created directly and registered via
    `register_engine_for_pool_stats()` — some services (program-framework,
    workflow-framework) build their engine with `create_async_engine()` themselves,
    bypassing `AsyncEngineManager`, usually because they need pool-sizing logic
    `AsyncEngineManager`'s settings binding doesn't support; either way the pool object
    itself is always a plain SQLAlchemy `Pool`.

    Rule B (root CLAUDE.md § DB sessions): `pool_stats()` only introspects the SQLAlchemy
    pool object already held in-process — it does not open a session or make a network
    call, so it is safe to call from this background loop.
    """
    try:
        from .database import all_engine_managers, all_raw_engines
    except Exception:
        return

    try:
        seen_labels: Dict[str, int] = {}

        def _emit_one(label: str, stats: Dict[str, Any]) -> None:
            if not stats:
                return
            index = seen_labels.get(label, 0)
            seen_labels[label] = index + 1
            # Two engines sharing a label (e.g. both defaulted) would otherwise emit two
            # lines with the same `engine` value; disambiguate by index in that case.
            engine_name = label if index == 0 else f"{label}_{index}"
            _emit_snapshot_line(
                "metrics.snapshot.pool",
                service_name,
                engine=engine_name,
                pool_size=stats.get("pool_size", 0),
                checked_out=stats.get("checked_out", 0),
                overflow=stats.get("overflow", 0),
            )

        for manager in all_engine_managers():
            _emit_one(manager.default_app_name or "engine", manager.pool_stats())

        for name, engine in all_raw_engines().items():
            _emit_one(name, _pool_stats_from_raw_engine(engine))
    except Exception:
        logger.warning("metrics-snapshot-pool-stats-failed", exc_info=True)


def _run_snapshot_tick(service_name: str, state: _EmitterState) -> None:
    """Emit every flat snapshot line for this tick (zero or more, one call each).

    Never raises: each emitter function already guards itself, and `log_event` itself
    never raises, but the whole tick is additionally wrapped so a bug here can never kill
    the background thread's loop.
    """
    try:
        _emit_llm_deltas(service_name, state)
        _emit_http_deltas(service_name, state)
        _emit_datalake_deltas(service_name, state)
        _emit_pool_stats(service_name)
    except Exception:
        logger.warning("metrics-snapshot-tick-failed", exc_info=True)


class _SnapshotEmitter:
    """Owns the background daemon thread for one worker process.

    Not part of the public API — use `start_metrics_snapshot_emitter()`.
    """

    def __init__(self, service_name: str, interval_seconds: int):
        self.service_name = service_name
        self.interval_seconds = interval_seconds
        self.state = _EmitterState()
        self.pid = os.getpid()
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        self._thread = threading.Thread(
            target=self._loop,
            name=f"metrics-snapshot-{self.service_name}",
            daemon=True,  # never blocks process shutdown
        )
        self._thread.start()

    def _loop(self) -> None:
        while not self._stop.wait(self.interval_seconds):
            # The spec calls for restarting if os.getpid() changes (a fork after the
            # thread started). A thread does not survive fork() in the child in the way
            # this check could observe from inside itself, so in practice this guards
            # the pathological case of this object being resumed/reused post-fork rather
            # than started fresh per worker (see start_metrics_snapshot_emitter's own
            # pid check, which is the primary guard).
            if os.getpid() != self.pid:
                logger.warning(
                    "metrics-snapshot-pid-changed",
                    expected_pid=self.pid,
                    actual_pid=os.getpid(),
                )
                self.pid = os.getpid()
                self.state = _EmitterState()  # counters restart cleanly under the new pid
            _run_snapshot_tick(self.service_name, self.state)


#: One emitter per process. Guards `start_metrics_snapshot_emitter()` being called more
#: than once in the same worker (a no-op) and detects a fork the module didn't expect
#: (restarts the thread under the new pid).
_emitter: Optional[_SnapshotEmitter] = None
_emitter_lock = threading.Lock()


def start_metrics_snapshot_emitter(
    service_name: str,
    interval_seconds: int = DEFAULT_INTERVAL_SECONDS,
) -> None:
    """Start this worker's per-process metrics snapshot emitter (G-X-2, D4).

    Call this from each service's own post-fork startup (a FastAPI lifespan/startup hook
    run inside the gunicorn worker), NOT at import time and NOT from code that runs once
    in the gunicorn master before it forks — a call before forking would be inherited by
    every worker as "already started" and no worker would actually run the loop.

    Idempotent: calling it again in the same process is a no-op. If it detects the
    process's pid has changed since it started (an unexpected fork), it logs a warning and
    restarts its internal thread under the new pid with fresh counters, rather than going
    on logging under a stale identity.

    Args:
        service_name: This service's name, logged on every snapshot line as `service` (the
            `GRAFANA_DASHBOARDS_ROADMAP.md` panels do `sum by (service)`).
        interval_seconds: Seconds between snapshots. Defaults to 60, matching every other
            option-C snapshot on this platform. Tests may pass a much shorter value.

    This function itself never raises: a failure to start the background thread is logged
    and swallowed, because a missing metrics snapshot must never be the reason a service
    fails to boot.
    """
    global _emitter
    try:
        with _emitter_lock:
            current_pid = os.getpid()
            if _emitter is not None:
                if _emitter.pid == current_pid:
                    # Already running in this process under this pid: no-op.
                    return
                logger.warning(
                    "metrics-snapshot-restart-after-fork",
                    service=service_name,
                    previous_pid=_emitter.pid,
                    current_pid=current_pid,
                )
            _emitter = _SnapshotEmitter(service_name, interval_seconds)
            _emitter.start()
    except Exception:
        logger.warning("metrics-snapshot-emitter-start-failed", exc_info=True)
