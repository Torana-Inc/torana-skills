"""
JWT utilities for Pantheon microservices.

Provides functions to decode and create JWT tokens using the shared secret.
"""

import os
import jwt
from datetime import datetime, timedelta, timezone
from typing import Dict, Any, Optional


def decode_jwt_token(
    token: str,
    jwt_secret_key: Optional[str] = None,
    jwt_algorithm: str = "HS256",
    allow_testing_tokens: bool = False,
    audience: Optional[str] = None
) -> Dict[str, Any]:
    """
    Decode and validate a JWT token.

    Args:
        token: JWT token string
        jwt_secret_key: Secret key for JWT validation (auto-read from JWT_SECRET_KEY env var if not provided)
        jwt_algorithm: JWT algorithm (default: HS256)
        allow_testing_tokens: Allow fake tokens for testing
        audience: Expected audience (optional - if not provided, audience validation is skipped)

    Returns:
        Dict containing token payload

    Raises:
        ValueError: If token is invalid or expired
    """
    if jwt_secret_key is None:
        jwt_secret_key = os.getenv("JWT_SECRET_KEY")
        if jwt_secret_key is None:
            raise ValueError("jwt_secret_key must be provided or JWT_SECRET_KEY environment variable must be set")

    # Allow testing tokens if enabled
    if allow_testing_tokens and token == "testing-token":
        return {
            "sub": "test-user",
            "email": "test@example.com",
            "name": "Test User",
            "tenant_id": "test-tenant",
            "roles": ["user"],
            "permissions": ["read"],
            "is_active": True,
            "is_verified": True
        }

    try:
        # Set decode options
        options = {"verify_aud": audience is not None}

        # Only add audience if specified
        if audience:
            payload = jwt.decode(
                token,
                jwt_secret_key,
                algorithms=[jwt_algorithm],
                audience=audience,
                options=options
            )
        else:
            payload = jwt.decode(
                token,
                jwt_secret_key,
                algorithms=[jwt_algorithm],
                options=options
            )
        return payload
    except jwt.ExpiredSignatureError:
        raise ValueError("Token has expired")
    except jwt.InvalidTokenError as e:
        raise ValueError(f"Invalid token: {str(e)}")


def create_jwt_token(
    payload: Dict[str, Any],
    jwt_secret_key: Optional[str] = None,
    jwt_algorithm: str = "HS256",
    expires_in: int = 3600
) -> str:
    """
    Create a JWT token with specified expiration.

    Args:
        payload: Token payload data
        jwt_secret_key: Secret key for JWT signing (auto-read from JWT_SECRET_KEY env var if not provided)
        jwt_algorithm: JWT algorithm (default: HS256)
        expires_in: Token validity in seconds (default: 3600)

    Returns:
        JWT token string
    """
    if jwt_secret_key is None:
        jwt_secret_key = os.getenv("JWT_SECRET_KEY")
        if jwt_secret_key is None:
            raise ValueError("jwt_secret_key must be provided or JWT_SECRET_KEY environment variable must be set")

    # Add expiration and issued at claims
    now = datetime.now(timezone.utc)
    payload.update({
        "iat": now,
        "exp": now + timedelta(seconds=expires_in)
    })

    # Create and sign token
    token = jwt.encode(
        payload,
        jwt_secret_key,
        algorithm=jwt_algorithm
    )

    return token


def validate_jwt_claims(payload: Dict[str, Any]) -> bool:
    """
    Validate required JWT claims.

    Args:
        payload: Decoded JWT payload

    Returns:
        True if valid, False otherwise
    """
    required_claims = ["sub", "iss", "aud"]
    return all(claim in payload for claim in required_claims)


def refresh_jwt_token(
    token: str,
    jwt_secret_key: Optional[str] = None,
    jwt_algorithm: str = "HS256",
    expires_in: int = 3600
) -> str:
    """
    Refresh a JWT token by creating a new token with updated expiration.

    Args:
        token: Existing JWT token
        jwt_secret_key: Secret key for JWT validation/signing
        jwt_algorithm: JWT algorithm (default: HS256)
        expires_in: New token validity in seconds (default: 3600)

    Returns:
        New JWT token string
    """
    # Decode existing token (without expiration validation)
    if jwt_secret_key is None:
        jwt_secret_key = os.getenv("JWT_SECRET_KEY")
        if jwt_secret_key is None:
            raise ValueError("jwt_secret_key must be provided or JWT_SECRET_KEY environment variable must be set")

    try:
        # Decode token without verifying expiration
        payload = jwt.decode(
            token,
            jwt_secret_key,
            algorithms=[jwt_algorithm],
            options={"verify_exp": False}
        )
    except jwt.InvalidTokenError as e:
        raise ValueError(f"Invalid token for refresh: {str(e)}")

    # Remove old timestamps
    payload.pop("iat", None)
    payload.pop("exp", None)

    # Create new token
    return create_jwt_token(payload, jwt_secret_key, jwt_algorithm, expires_in)