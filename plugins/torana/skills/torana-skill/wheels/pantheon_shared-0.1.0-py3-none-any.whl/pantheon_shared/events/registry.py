"""Producer registry for the platform event timeline.

`homepage_timeline_event.producer` is an unconstrained ``varchar(50)`` and its
vocabulary historically lived in a code comment. With one producer that is
invisible; with eight it is tag sprawl. This module is the single place that
declares every valid producer, its ``event_key`` grammar, its default
relevance/line-type, and — importantly — the **user-facing label** the FE filter
chips render, so those labels can never be free-form strings.

Design: PLATFORM_EVENT_TIMELINE_SPEC.md § 3.4.2.

Validation is deliberately CLIENT-side only for now (§ 3.9.4): the ingest
endpoint lives in program-framework and would validate against whatever wheel
version that service happens to have, so during a rolling deploy a producer on a
newer wheel could be rejected by an older-wheel server — silently, because
``emit()`` is best-effort. Server-side enforcement lands once all services share
a wheel version.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class ProducerSpec:
    """One declared event producer.

    name              wire value written to ``homepage_timeline_event.producer``
    label             user-facing chip label (§ 3.5.3) — never free-form
    key_prefixes      allowed ``event_key`` prefixes; empty tuple = any
    default_relevance used when the caller passes ``relevance=None``
    default_line_type used when the caller passes ``line_type=None``
    suppression       DECLARED, human-readable rule for when this producer stays
                      silent. See the module note on why this is a registry field
                      and not per-producer prose.
    """

    name: str
    label: str
    key_prefixes: tuple
    default_relevance: int
    default_line_type: str
    suppression: str = "not declared"


#: THE one definition of the line-type vocabulary, platform-wide.
#:
#: ``pantheon-program-framework``'s ``timeline_emitter`` imports THIS rather than
#: keeping its own copy. Two copies on two deploy cadences means adding a fourth
#: type here would have producers emitting a value the server rejects — and since
#: ``emit()`` swallows failures, the feature would go silently inert.
VALID_LINE_TYPES = frozenset({"delta", "work", "nudge"})


#: THE one definition of the severity vocabulary, platform-wide.
#:
#: Validated for the SAME reason as ``VALID_LINE_TYPES``, and the reason is sharper
#: here: ``emit()`` is best-effort and NEVER raises, so an unvalidated severity typo
#: ("critcal", "HIGH", "warn") reaches the DB as-is and is invisible forever — the line
#: renders with no severity styling and no error is logged anywhere. Until now this was
#: a free-form ``Optional[str]`` whose only vocabulary was a code comment on
#: ``homepage_timeline_event.severity`` (``# critical | high | info``).
#:
#: Validate NOW, while the registry has ~9 producers. After 30, an audit means visiting
#: 30 call sites.
#:
#: ``None`` remains legal and is the common case — most lines carry no severity at all.
VALID_SEVERITIES = frozenset({"critical", "high", "info"})


#: SUPPRESSION IS A REGISTRY CONTRACT, NOT A PER-PRODUCER JUDGEMENT CALL.
#:
#: A single VM app already carries ~7 rules + 20 transformers + 8 schedulers on a
#: daily cadence, and the platform survey (spec § 5) counts ~40 candidate event
#: sources. If every run emits, the feed becomes the thing users learn to ignore —
#: the same failure mode as an unread alert queue, and fatal to a feed whose whole
#: value is that a line means something happened worth knowing.
#:
#: So every producer MUST declare, here, when it stays silent. The string is
#: human-readable rather than executable on purpose: the rule lives at the emit
#: site (it needs the run's own data), but declaring it centrally makes the
#: contract reviewable in one place and makes an undeclared producer obvious.
PRODUCERS: dict[str, ProducerSpec] = {
    # The prefix is verified against the shipped producer: funnel_diff_producer.py
    # already emits f"funnel_diff:{stage}", so migrating it to the shared emit()
    # passes validate_event unchanged. No key rewrite needed.
    "funnel_diff": ProducerSpec(
        "funnel_diff", "Posture", ("funnel_diff:",), 60, "delta",
        suppression="only when a stage moved by >=3 AND >=10% of its prior value",
    ),
    "etl_sync": ProducerSpec(
        "etl_sync", "Sync", ("sync:",), 45, "work",
        suppression=("only when records_out > 0, or status != success, or dlq_count > 0, or the "
                     "source just went quiet (stop_reason zero_record_regression: 0 records from a source "
                     "that delivered before; once per quiet episode, not on every quiet run)"),
    ),
    "retirement": ProducerSpec(
        "retirement", "Retirement", ("retire:",), 40, "work",
        suppression="only when retired counts > 0",
    ),
    "graph_health": ProducerSpec(
        "graph_health", "Asset graph", ("graph:",), 60, "delta",
        suppression="only on a verdict change; steady-state re-derivation is silent",
    ),
    # NORTH_STAR_BUILD_SYSTEM § 3.9. A widget that starts (or stops) returning data is
    # user-meaningful background state — "your dashboard just lit up" is exactly what a
    # tenant wants to hear after connecting an integration. Deliberately narrow: only a
    # TRANSITION into or out of `live` qualifies, so a polling UI cannot generate a stream.
    "widget_verdict": ProducerSpec(
        "widget_verdict", "Widget", ("verdict:",), 50, "delta",
        suppression=(
            "only on a transition INTO or OUT OF `live`; an unchanged verdict and every SA "
            "fleet read stay silent"
        ),
    ),
    "deploy": ProducerSpec(
        "deploy", "Deploy", ("deploy:",), 55, "work",
        suppression="none — a deploy is always worth a line",
    ),
    # Security findings that arrived and were NOT routed anywhere. There is no table
    # recording this today — the absence IS the defect, which is why this emits at the
    # source rather than deriving.
    "alert_routing": ProducerSpec(
        "alert_routing", "Alert routing", ("routing:",), 70, "nudge",
        suppression="only when an alert reaches NO destination at all; a routed alert is silent",
    ),
    # A finding the platform closed on its OWN — triage auto-closing it as benign or
    # false-positive per policy, not a user action. The owning developer otherwise
    # never learns their finding was dismissed; the auto-close mutates triage state
    # with no surface the dev sees (#70). Emitted at the auto-close site in
    # detection-framework's AlertService.update_triage_verdict.
    "finding_lifecycle": ProducerSpec(
        "finding_lifecycle", "Findings", ("finding:",), 65, "delta",
        suppression=(
            "only on an AUTOMATIC benign/false_positive triage close; a true_positive "
            "(assigned onward), an inconclusive (escalated), and a user-driven close all "
            "stay silent"
        ),
    ),
    # An Inbox item ending, reopening, or a whole rule's items being held back,
    # decided by the platform rather than by a person. An operator who finds work gone
    # from their queue has no other record of what removed it, and a rule whose data
    # cannot be trusted stops ending items silently — both are things the person whose
    # queue it is would want to know. Emitted after the commit by the lifecycle worker.
    "inbox_lifecycle": ProducerSpec(
        "inbox_lifecycle", "Inbox", ("inbox:",), 65, "delta",
        suppression=(
            "applied: one line per run, only when the run closed or reopened at least "
            "one item; refused or held: one line when a rule's last run BECOMES refused "
            "or held, none while it stays so; refresh and re-rate never emit"
        ),
    ),
    # A user's scheduled work stopping on its own. Auto-disable/pause mutates
    # scheduled_tasks.status in place with no history row, so a user whose nightly job
    # stopped gets no record of when or why.
    "scheduler": ProducerSpec(
        "scheduler", "Scheduler", ("schedule:",), 75, "delta",
        suppression="only on auto-disable/pause/expire; ordinary runs and failures are silent",
    ),
    # An agent whose health the platform changed on its own. Reconciliation adds and
    # removes tools from live agents; the resulting health lived only in a cache entry
    # and a log line, so a healthy->degraded change vanished on the next restart.
    "agent_health": ProducerSpec(
        "agent_health", "Agent health", ("agent_health:",), 65, "delta",
        suppression="only on a health TRANSITION (prior != current); steady-state rebuilds are silent",
    ),
    # An agent the platform ran on its own — alert triage, AI Home narration and its
    # critic, the program advisor, playbook steps. The caller is another service, so
    # no person watched the run; until this line existed a narration that timed out
    # every hour (Classie 2026-10-01) left no trace a customer could see.
    # ⚠️ Every run emits, and the reader's roll-up is what keeps the feed readable:
    # one line per agent per outcome per window ("ran 37 times"). Success and failure
    # use DIFFERENT event keys, so a newer success never buries a failure as a member.
    "agent_run": ProducerSpec(
        "agent_run", "Agent runs", ("agent_run:",), 30, "work",
        suppression=(
            "only background runs — the caller is a service, not a person; an agent "
            "a user invokes directly is watched and stays silent. Runs roll up per "
            "agent and outcome; a failure carries severity=high"
        ),
    ),
    # Platform-asserted facts written onto datalake rows (threat intel, SLA policy).
    # DECORATION_LAYER_SPEC.md § 3.13. The user sees these values on every dashboard,
    # so a refresh that MOVED them is worth a line — and a decoration that stopped
    # working is worth a loud one, because the numbers go stale silently otherwise.
    "decoration": ProducerSpec(
        "decoration", "Decoration", ("decoration:",), 70, "delta",
        suppression="only when an apply CHANGED rows, or a decoration source/apply "
                    "transitions ok<->error, or a job is abandoned. Routine no-op runs are silent",
    ),
    # A materialized POLICY value changing under the user (an SLA window tightening
    # re-dates every deadline built from it).
    "policy": ProducerSpec(
        "policy", "Policy", ("policy:",), 75, "delta",
        suppression="only when a materialized policy VALUE changed; a no-op refresh is silent",
    ),
    # Knowledge (Atlas) reconcile: background work done on the tenant's behalf that they would not
    # otherwise see. SELECTION_ON_SYNC.md § 3.9. One event per (reconcile pass, integration), never per item.
    # The consent purge (OI-169, design § 3.18.7): one event per (purge pass, source) that deleted, one when a pass
    # could not verify a zero count.
    # The Atlas section sweep (DF, slice A-DF § 8): one event per (sweep pass, tenant) that changed ≥1 finding's section,
    # key `atlas:alert_section:sweep:<tenant>`. A pass that only refreshed `as_of` (nothing changed) or could not reach
    # the Atlas is silent (f1's freshness rule, Q6).
    "atlas": ProducerSpec(
        "atlas", "Knowledge", ("atlas:",), 45, "work",
        suppression="only when a reconcile pass offered, auto-selected, retired or carried over ≥1 item for an integration, "
                    "or a consent purge pass deleted ≥1 version of a source or failed its zero-count verification, "
                    "or an alert-section sweep pass changed ≥1 finding's Atlas section (a refresh-only or unreachable "
                    "pass is silent)",
    ),
    # A fix PR whose fate Torana had to go and ASK GitHub for (B29 / F32,
    # FIX_PR_B29_RECONCILER_SPEC.md § 3.9). Torana learned a PR's outcome from ONE webhook
    # delivery and GitHub Apps never retry a failed one, so a lost delivery did not degrade a
    # remediation row — it FROZE it, with every surface reporting the frozen value as current.
    # Four times in four days, three unrelated causes. The reconciler now asks, which makes the
    # catch-up itself background work the user never watched: the row it moves is the one their
    # queue renders, and "this fix closed three days ago and we only just noticed" is precisely
    # the sentence they would want and could not otherwise get.
    # ⚠️ The SWEEP emits; the `refresh` button and `reconcile` verb do NOT. A person who clicked
    # is already watching the answer come back (PLATFORM_EVENTS.md § 1).
    "remediation_reconcile": ProducerSpec(
        "remediation_reconcile", "Fix PRs", ("remediation:",), 55, "work",
        suppression=(
            "only when a SWEEP pass moved a remediation row to merged or abandoned. An "
            "unchanged PR is silent, a read that FAILED is silent (it is recorded on the row "
            "as last_reconcile_error and shown as the freshness line, so the feed would add "
            "nothing), and a user-forced refresh is silent because they are watching it"
        ),
    ),
    # A full (non-PR) SARIF scan pushed by CI or the CLI (pantheon-integration
    # `ingest_sarif`). The push lands findings and retires the ones the scanner no
    # longer sees, all without a person watching the platform side; a push whose
    # records failed to load (DLQ) retires nothing, and that must be said, not left
    # silent. PR-scoped scans already report on the pull request, so they never emit.
    "ci_scan": ProducerSpec(
        "ci_scan", "Scans", ("scan:",), 55, "delta",
        suppression=(
            "only a FULL scan that landed >=1 finding, retired >=1, or dead-lettered >=1 "
            "record; a PR-scoped scan and a full scan where nothing moved stay silent"
        ),
    ),
    # Account lifecycle a user did not perform themselves.
    "account": ProducerSpec(
        "account", "Account", ("account:",), 65, "delta",
        suppression="only on lock/unlock by an administrator; self-service changes are silent",
    ),
    # APP_LANDING_PAGE_DESIGN_NOTE R9.5: the app's Intent or Goals were re-derived and CHANGED. A no-op refresh is silent.
    "app_engagement": ProducerSpec(
        "app_engagement", "App", ("engagement:",), 60, "delta",
        suppression="shown only when a refresh changed the Intent or Goals; a no-op is silent",
    ),
}


def resolve_producer(producer: str) -> ProducerSpec:
    """Look the producer up.

    Separate from :func:`validate_event` on purpose: a caller must be able to read
    ``spec.default_line_type`` BEFORE the line type is validated, which a
    single-phase validate cannot do (the spec is not known until the producer is
    resolved). See § 3.4.1.
    """
    spec = PRODUCERS.get(producer)
    if spec is None:
        raise ValueError(
            f"unknown producer '{producer}' — declare it in "
            f"pantheon_shared/events/registry.py"
        )
    return spec


def validate_event(
    spec: ProducerSpec,
    event_key: str,
    line_type: str,
    severity: str | None = None,
) -> None:
    """Raise ValueError unless (event_key, line_type, severity) are legal for ``spec``.

    ``severity`` is optional and defaults to None — the common case, and always legal.
    A non-None value must be in :data:`VALID_SEVERITIES`; see that constant for why an
    unvalidated severity is invisible rather than merely wrong.
    """
    if line_type not in VALID_LINE_TYPES:
        raise ValueError(
            f"invalid line_type '{line_type}' — must be one of "
            f"{sorted(VALID_LINE_TYPES)}"
        )
    if spec.key_prefixes and not event_key.startswith(spec.key_prefixes):
        raise ValueError(
            f"event_key '{event_key}' must start with one of {spec.key_prefixes}"
        )
    if severity is not None and severity not in VALID_SEVERITIES:
        raise ValueError(
            f"invalid severity '{severity}' — must be None or one of "
            f"{sorted(VALID_SEVERITIES)}"
        )


def producer_labels() -> dict[str, str]:
    """{producer_name: user-facing label} — the FE filter-chip vocabulary (§ 3.5.3)."""
    return {name: spec.label for name, spec in PRODUCERS.items()}
