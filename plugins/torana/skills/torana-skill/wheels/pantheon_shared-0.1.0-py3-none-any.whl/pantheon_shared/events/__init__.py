"""Platform event timeline — the cross-producer event layer.

Any service can append an event with one import and one call:

    from pantheon_shared.events import emit
    await emit(service_name=settings.service_name, tenant_id=..., producer="etl_sync", ...)

Design: PLATFORM_EVENT_TIMELINE_SPEC.md § 3.4.1 (emit) and § 3.4.2 (registry).
"""

from .emitter import emit
from .registry import (
    PRODUCERS,
    VALID_LINE_TYPES,
    VALID_SEVERITIES,
    ProducerSpec,
    producer_labels,
    resolve_producer,
    validate_event,
)

__all__ = [
    "emit",
    "PRODUCERS",
    "VALID_LINE_TYPES",
    "VALID_SEVERITIES",
    "ProducerSpec",
    "producer_labels",
    "resolve_producer",
    "validate_event",
]
