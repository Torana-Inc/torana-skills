"""Platform event emission — one import, one call, from any service.

    from pantheon_shared.events import emit

    await emit(service_name=settings.service_name, tenant_id=..., producer="etl_sync",
               event_key="sync:<integration>:<source>", title="Synced GitHub — 12 new records")

Design: PLATFORM_EVENT_TIMELINE_SPEC.md § 3.4.1.

**Transport is an implementation detail.** This posts to program-framework's
service-to-service ingest endpoint rather than writing to its database directly.
A shared library holding its own connection to another service's DB was
considered and rejected: it would add a second engine+pool per producing service
against an already-tight connection budget, hand N services write credentials to
a table they do not own, turn a schema change into an N-service lockstep deploy,
and lose the server-side IAM derivation that makes a producer *unable* to
mis-assign tenancy. Because the interface is the reusable part, this body can
become a direct write later without touching a single producer.

**emit() never raises.** A failed timeline write must never abort the work that
produced it. Callers may check the bool; most should not care.
"""

import logging
from typing import Any, Optional

from pantheon_shared.events.registry import resolve_producer, validate_event
from pantheon_shared.http.client import PantheonClient
from pantheon_shared.pantheon_services import (
    PantheonService,
    get_pantheon_service_url,
)

logger = logging.getLogger(__name__)

_INGEST_PATH = "/api/v1/workspaces/internal/timeline-events"

#: Short on purpose. Emitting an event is never worth stalling a sync run.
_TIMEOUT_SECONDS = 5.0


async def emit(
    *,
    service_name: str,
    tenant_id,
    producer: str,
    event_key: str,
    title: str,
    line_type: Optional[str] = None,
    workspace_id=None,
    namespace_id=None,
    user_id=None,
    actor_kind: Optional[str] = None,
    actor_id: Optional[str] = None,
    detail: Optional[dict[str, Any]] = None,
    relevance: Optional[int] = None,
    severity: Optional[str] = None,
    rollup_key: Optional[str] = None,
    description: str = "",
) -> bool:
    """Append one platform event. Best-effort: returns False, never raises.

    service_name  the CALLING service, e.g. ``settings.service_name``. REQUIRED —
                  ``$SERVICE_NAME`` is not set in any Pantheon container, so the
                  factory's auto-detect would mint an S2S JWT as "unknown-service".
    tenant_id     the tenant whose WORK produced the event — not necessarily the
                  emitting service's own env tenant.
    workspace_id  None => a tenant-wide event, shown on every workspace timeline
                  in that tenant. ETL is tenant-scoped, so its producer passes None.
    namespace_id  None => derived server-side (from the workspace row, else the
                  tenant default).
    line_type     None => the registry's default for this producer.
    relevance     None => the registry's default for this producer.
    """
    try:
        # Two-phase: resolve the producer FIRST so its defaults are reachable,
        # then validate the resolved values. A one-phase call cannot do this.
        spec = resolve_producer(producer)
        line_type = line_type or spec.default_line_type
        validate_event(spec, event_key, line_type, severity)
    except Exception:
        # Broad on purpose: emit() must never raise. A narrow `except ValueError`
        # would let a NameError/TypeError escape into a caller (e.g. the ETL
        # runner) whose own handler would then skip later work.
        logger.warning(
            "events.emit rejected: producer=%s event_key=%s line_type=%s",
            producer, event_key, line_type,
        )
        return False

    body: dict[str, Any] = {
        "tenant_id": str(tenant_id),
        "producer": producer,
        "event_key": event_key,
        "title": title,
        "line_type": line_type,
        "detail": detail or {},
        "relevance": relevance if relevance is not None else spec.default_relevance,
        "severity": severity,
        "actor_kind": actor_kind,
        "actor_id": actor_id,
        "rollup_key": rollup_key,
        "description": description or title[:255],
    }
    if workspace_id is not None:
        body["workspace_id"] = str(workspace_id)
    if namespace_id is not None:
        body["namespace_id"] = str(namespace_id)
    if user_id is not None:
        body["user_id"] = str(user_id)

    try:
        base = get_pantheon_service_url(
            PantheonService.PROGRAM_FRAMEWORK, url_env_var="PROGRAM_SERVICE_URL"
        ).rstrip("/")
        # `async with` closes the httpx client. The in-repo reference caller
        # (torana_mesh/etl/viz_cache_notifier.py) does NOT close its client;
        # copying that verbatim would leak a connection per event.
        async with PantheonClient(
            service_name=service_name,
            tenant_id=str(tenant_id),
            namespace_id=str(namespace_id) if namespace_id else None,
        ) as client:
            resp = await client.post(
                f"{base}{_INGEST_PATH}", json=body, timeout=_TIMEOUT_SECONDS
            )
        if resp.status_code // 100 == 2:
            return True
        logger.warning(
            "events.emit rejected by ingest (%s): %s",
            resp.status_code, resp.text[:200],
        )
        return False
    except Exception:
        logger.exception(
            "events.emit failed (producer=%s key=%s)", producer, event_key
        )
        return False
