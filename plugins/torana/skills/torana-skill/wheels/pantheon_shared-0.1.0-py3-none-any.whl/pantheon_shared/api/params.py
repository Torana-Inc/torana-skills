"""
Reusable FastAPI query parameter dependencies for Pantheon services.
"""

from datetime import datetime
from typing import Optional

from fastapi import Query


def updated_since_param(
    updated_since: Optional[datetime] = Query(
        None,
        description=(
            "Return only records whose updated_at >= this timestamp. "
            "Includes soft-deleted records so that callers can detect deletions. "
            "ISO-8601 format, e.g. 2024-01-15T10:30:00Z"
        )
    )
) -> Optional[datetime]:
    """
    FastAPI dependency for the ?updated_since=<datetime> query parameter.

    When provided, the caller receives all records (including soft-deleted ones)
    that were modified at or after the given timestamp. This is used by the
    artifact cache service to perform incremental refreshes.

    Usage in an endpoint:
        from pantheon_shared.api.params import updated_since_param

        @router.get("")
        def list_items(
            updated_since: Optional[datetime] = Depends(updated_since_param),
            ...
        ):
            builder = Item.query_builder()
            if updated_since:
                builder.updated_since(updated_since)
            ...
    """
    return updated_since
