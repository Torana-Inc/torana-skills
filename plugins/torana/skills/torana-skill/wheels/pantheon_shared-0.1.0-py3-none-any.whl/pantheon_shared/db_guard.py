"""Database session-lifetime guard.

Catches two defects that repeatedly took Pantheon services down. Both are
invisible in code review — each individual line looks correct — and both fail
in the same ugly way: a pooled connection is pinned, the pool (1-3 connections
on most services) empties, and the service stops answering entirely.

────────────────────────────────────────────────────────────────────────────
DEFECT A — `async def` handler holding a SYNCHRONOUS Session
────────────────────────────────────────────────────────────────────────────
FastAPI runs `async def` handlers ON THE EVENT LOOP; it runs plain `def`
handlers in the anyio threadpool. So an `async def` handler that takes a sync
`Session` does blocking psycopg2 I/O on the loop — and, far worse, a contended
`QueuePool.get()` is a blocking `threading.Condition.wait(timeout)` on the loop.

The failure is not slowness, it is a SELF-DEADLOCK: the requests holding the
connections are on the same frozen thread as the waiters, so they can never
reach their `finally: db.close()`. Connections are never returned. The service
does not recover when load stops, because it was never waiting on load.

    Measured 2026-08-12, pantheon-data-transformers (pool 1+2 = 3):
    22 widget renders at concurrency 6 -> HTTP 000, container still reporting
    "(healthy)", no recovery after 45s idle. Only a restart cleared it.
    Converting ONE handler to `def` + adding pool_timeout:
    wall clock 13.5s -> 1.4s, p95 5751ms -> 794ms, renders >4.5s 54% -> 6%.

Detection is STATIC (`check_handlers`) — call it at startup with your router.

────────────────────────────────────────────────────────────────────────────
DEFECT B — a DB session held open ACROSS a network call
────────────────────────────────────────────────────────────────────────────
A session opened, then an east-west HTTP call (or LLM call, or subprocess)
awaited while it is still open, pins a pooled connection for the duration of a
network round trip. Under concurrency the pool empties and the service wedges —
and if the callee is itself waiting on the caller's service, the two deadlock.

    Found 2026-08-12 in 8 places across detection-framework (330s and 50s
    holds, per alert), workflow-framework (600s hold, per scheduler tick),
    and program-framework (300s hold + an advisory lock).

Detection is RUNTIME: `session_scope()` marks a session open in a ContextVar,
and `assert_no_session_held()` — called from PantheonClient.request() — trips
if a network call starts while one is marked.

────────────────────────────────────────────────────────────────────────────
THE CORRECT SHAPE (already proven in-tree)
────────────────────────────────────────────────────────────────────────────
Do NOT hold a session across the call. Read what you need, close, do the
network work, then reopen to persist:

    with db_manager.get_session() as s:      # phase 1: read
        snapshot = _snapshot(s.query(Thing).get(x))
        s.commit()
    result = await client.post(...)           # phase 2: network, NO session
    with db_manager.get_session() as s:      # phase 3: persist
        s.execute(update(...)); s.commit()

`pantheon-workflow-framework`'s playbook_executor already does this by passing
a session FACTORY down (`db_factory=AsyncSessionLocal`) so each short write
opens and closes its own session around a 300s agent call.

────────────────────────────────────────────────────────────────────────────
ENFORCEMENT
────────────────────────────────────────────────────────────────────────────
Defect B is STRICT BY DEFAULT — it raises. Set `DB_GUARD_STRICT_DISABLE=true`
to downgrade to a warning (left commented out in pantheon-deploy/.env; it is a
kill-switch, not a normal setting).

Defect A currently WARNS ONLY — `check_handlers` logs a CRITICAL naming every
offending handler but never raises, because 26 known handlers in
data-transformers are still unconverted and hard-failing would refuse to boot.
Flip `_HANDLER_CHECK_RAISES` to True once that list reaches zero.
"""
import inspect
import os
import time
from contextlib import contextmanager
from contextvars import ContextVar
from typing import Any, Iterator, List, Optional, Tuple

from . import get_logger

logger = get_logger(__name__)

__all__ = [
    "DbSessionHeldError",
    "session_scope",
    "get_open_session_scope",
    "assert_no_session_held",
    "check_handlers",
    "strict_enabled",
]


class DbSessionHeldError(RuntimeError):
    """A network call was attempted while a DB session was held open."""


# ── Defect B: runtime detection ────────────────────────────────────────────
# ContextVar, matching the platform idiom (tracing/context.py:121,
# iam/context.py:588, cache_context.py:54). ContextVar — not a plain global —
# because it must be correct across concurrent async tasks: each task gets its
# own view, so one request's open session never masks or trips another's.
#
# Holds (label, opened_monotonic) so the error can name WHERE the session was
# opened, not just that one was. Without the label the report says "a session
# is held" and the reader still has to hunt for which one.
_open_session: ContextVar[Optional[Tuple[str, float]]] = ContextVar(
    "db_guard_open_session", default=None
)

_STRICT_DISABLE_ENV = "DB_GUARD_STRICT_DISABLE"

# Flip to True only when check_handlers() reports zero offenders fleet-wide.
_HANDLER_CHECK_RAISES = False


def strict_enabled() -> bool:
    """True when a violation should RAISE rather than warn.

    Strict is the DEFAULT. `DB_GUARD_STRICT_DISABLE=true` is a kill-switch for
    an environment that would otherwise be unable to boot or serve — not a
    normal setting. Read per-call, never cached, so it can be flipped without
    a rebuild (and so tests can toggle it).
    """
    return os.getenv(_STRICT_DISABLE_ENV, "false").strip().lower() not in (
        "true", "1", "yes",
    )


@contextmanager
def session_scope(label: str) -> Iterator[None]:
    """Mark a DB session as OPEN for the duration of this block.

    Wrap wherever a session is acquired, so `assert_no_session_held()` can tell
    that a network call is happening underneath one::

        with db_manager.get_session() as s, session_scope("action_worker:345"):
            ...

    `label` should be `file.py:line` or `module:function` — it is the only
    thing that tells the reader WHICH session tripped the guard.

    Nesting is deliberately NOT tracked as a stack: the outermost scope wins,
    because that is the one that has been open longest and is the real
    offender. An inner short-lived session inside a long outer one is not a
    separate bug, it is the same bug.
    """
    if _open_session.get() is not None:
        # Already inside a scope — do not overwrite the outer (older) one.
        yield
        return
    token = _open_session.set((label, time.monotonic()))
    try:
        yield
    finally:
        _open_session.reset(token)


def get_open_session_scope() -> Optional[Tuple[str, float]]:
    """The currently-open session scope as (label, opened_monotonic), or None."""
    return _open_session.get()


def assert_no_session_held(operation: str) -> None:
    """Trip if a network call is starting while a DB session is held.

    Called from `PantheonClient.request()` — the single funnel every east-west
    call passes through. Safe to call from anywhere else that blocks for a
    meaningful time (LLM calls, subprocesses, poll loops).

    Raises `DbSessionHeldError` when strict (the default); logs a WARNING when
    `DB_GUARD_STRICT_DISABLE=true`.
    """
    held = _open_session.get()
    if held is None:
        return
    label, opened_at = held
    held_for = time.monotonic() - opened_at
    msg = (
        f"DB session held across a network call — this pins a pooled "
        f"connection for the whole round trip and is how services deadlock. "
        f"session opened at: {label} (held {held_for:.2f}s); "
        f"attempted operation: {operation}. "
        f"Fix: close the session BEFORE the call and reopen after "
        f"(read -> commit/close -> network -> reopen to persist)."
    )
    if strict_enabled():
        raise DbSessionHeldError(msg)
    logger.warning("db_guard: %s", msg)


# ── Defect A: static detection ─────────────────────────────────────────────
def _is_sync_session_dependency(param: inspect.Parameter) -> bool:
    """True when this parameter is a SYNC sqlalchemy Session.

    Resolves the ANNOTATION, never the dependency's NAME. Name-matching cannot
    work here: across the fleet `get_db_session` means a sync Session in
    detection-framework but an async one in data-transformers, and `get_db` is
    sync in workflow-framework but async in program-framework. Four meanings,
    two names. The annotation is the only honest signal.
    """
    ann = param.annotation
    if ann is inspect.Parameter.empty:
        return False
    try:
        from sqlalchemy.orm import Session as SyncSession
        from sqlalchemy.ext.asyncio import AsyncSession
    except Exception:  # pragma: no cover - sqlalchemy always present in services
        return False
    if isinstance(ann, str):
        # from __future__ import annotations, or a quoted hint.
        return ann.split("[")[0].strip().endswith("Session") and "Async" not in ann
    try:
        if inspect.isclass(ann) and issubclass(ann, AsyncSession):
            return False
        return inspect.isclass(ann) and issubclass(ann, SyncSession)
    except TypeError:
        return False


def check_handlers(routes: Any, *, service_name: str = "") -> List[str]:
    """Report `async def` route handlers that take a synchronous Session.

    Pass a FastAPI app's `.routes` at startup::

        from pantheon_shared.db_guard import check_handlers
        check_handlers(app.routes, service_name="pantheon-data-transformers")

    Returns the list of offender descriptions (empty when clean). Logs a
    CRITICAL naming each one. Raises only when `_HANDLER_CHECK_RAISES` is True
    — see the module docstring for why that is still False.
    """
    offenders: List[str] = []
    for route in routes or []:
        endpoint = getattr(route, "endpoint", None)
        if endpoint is None or not inspect.iscoroutinefunction(endpoint):
            continue
        try:
            sig = inspect.signature(endpoint)
        except (ValueError, TypeError):
            continue
        for param in sig.parameters.values():
            if not _is_sync_session_dependency(param):
                continue
            src = getattr(endpoint, "__code__", None)
            where = (
                f"{src.co_filename}:{src.co_firstlineno}" if src else endpoint.__module__
            )
            offenders.append(f"{where}  {endpoint.__name__}(  {param.name}: Session  )")
            break

    if offenders:
        logger.critical(
            "db_guard: %d async def handler(s) hold a SYNC Session%s. Each can "
            "freeze the event loop on a contended pool checkout, making "
            "`finally: db.close()` unreachable — a self-deadlock the service "
            "does not recover from. Fix: change `async def` to `def` (FastAPI "
            "then runs it in the threadpool) after confirming the body has no "
            "`await`.\n  %s",
            len(offenders),
            f" in {service_name}" if service_name else "",
            "\n  ".join(offenders),
        )
        if _HANDLER_CHECK_RAISES:
            raise RuntimeError(
                f"db_guard: {len(offenders)} async def handler(s) hold a sync Session"
            )
    else:
        logger.info(
            "db_guard: no async-def-with-sync-Session handlers%s",
            f" in {service_name}" if service_name else "",
        )
    return offenders
