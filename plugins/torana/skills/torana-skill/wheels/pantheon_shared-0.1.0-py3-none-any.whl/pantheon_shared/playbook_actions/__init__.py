"""Declarative playbook actions that run without a model (OI-188 b).

Spec: pantheon-knowledge docs/design/PLAYBOOK_DECLARATIVE_ACTIONS.md § 3.2-3.3. PF and WF import this one module, so
the schema, the renderer, the legacy flattening and the converter have one definition.
"""
from pantheon_shared.playbook_actions.describe import describe_actions
from pantheon_shared.playbook_actions.legacy import legacy_flatten, normalize_legacy_action, slugify_group
from pantheon_shared.playbook_actions.render import (
    ALERT_FIELDS,
    ALLOWED_ROOTS,
    EXECUTION_FIELDS,
    MAX_JIRA_DESCRIPTION,
    MAX_JIRA_SUMMARY,
    MAX_SLACK_TEXT,
    MAX_SLACK_TITLE,
    NOT_AVAILABLE,
    PLAYBOOK_FIELDS,
    RenderResult,
    TemplateIssue,
    render_text,
    template_variables,
    validate_templates,
)
from pantheon_shared.playbook_actions.schema import (
    ACTIONS_SCHEMA_VERSION,
    ActionKey,
    GroupKey,
    NotifyAction,
    PlaybookAction,
    PlaybookActions,
    TicketAction,
    parse_actions,
)

__all__ = [
    "ACTIONS_SCHEMA_VERSION", "ALERT_FIELDS", "ALLOWED_ROOTS", "ActionKey", "EXECUTION_FIELDS", "GroupKey",
    "MAX_JIRA_DESCRIPTION", "MAX_JIRA_SUMMARY", "MAX_SLACK_TEXT", "MAX_SLACK_TITLE", "NOT_AVAILABLE", "NotifyAction",
    "PLAYBOOK_FIELDS", "PlaybookAction", "PlaybookActions", "RenderResult", "TemplateIssue", "TicketAction",
    "describe_actions", "legacy_flatten", "normalize_legacy_action", "parse_actions", "render_text", "slugify_group",
    "template_variables", "validate_templates",
]
