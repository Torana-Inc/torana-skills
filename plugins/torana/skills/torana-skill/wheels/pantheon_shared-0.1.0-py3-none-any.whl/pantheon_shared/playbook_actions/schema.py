"""Typed declarative playbook actions (OI-188 b, spec § 3.2).

A `notify` or `ticket` action whose channel, recipients and text are declared needs no model: WF renders it in code
and pantheon-integration delivers it. Adding a field is a schema-version bump, never an untyped dict.
"""
from __future__ import annotations

from typing import List, Literal, Optional, Union

from pydantic import BaseModel, ConfigDict, Field, RootModel, StringConstraints, field_validator, model_validator
from typing_extensions import Annotated

ACTIONS_SCHEMA_VERSION = 1

GroupKey = Annotated[str, StringConstraints(pattern=r"^[a-z0-9][a-z0-9_-]{0,62}$")]
ActionKey = Annotated[str, StringConstraints(pattern=r"^[a-z0-9][a-z0-9_]{0,62}$")]
Label = Annotated[str, StringConstraints(pattern=r"^[A-Za-z0-9_.-]{1,50}$")]


class NotifyAction(BaseModel):
    model_config = ConfigDict(extra="forbid")

    type: Literal["notify"]
    key: ActionKey                                       # unique within the playbook; stable across edits
    channel: Literal["slack"]                            # the only notify channel with a sender today
    recipient_groups: Annotated[List[GroupKey], Field(min_length=1, max_length=10)]
    title_template: Optional[Annotated[str, StringConstraints(max_length=200)]] = None
    message_template: Annotated[str, StringConstraints(min_length=1, max_length=3000)]

    @field_validator("recipient_groups")
    @classmethod
    def _dedupe(cls, v: List[str]) -> List[str]:
        return list(dict.fromkeys(v))


class TicketAction(BaseModel):
    model_config = ConfigDict(extra="forbid")

    type: Literal["ticket"]
    key: ActionKey
    system: Literal["jira"]
    recipient_group: GroupKey                            # resolves to ONE Jira project + issue type
    summary_template: Annotated[str, StringConstraints(min_length=1, max_length=255)]
    description_template: Annotated[str, StringConstraints(max_length=10000)] = ""
    labels: Annotated[List[Label], Field(max_length=10)] = []


PlaybookAction = Annotated[Union[NotifyAction, TicketAction], Field(discriminator="type")]


class PlaybookActions(RootModel[Annotated[List[PlaybookAction], Field(max_length=20)]]):
    """The `actions` list of one playbook. Action keys must be unique."""

    @model_validator(mode="after")
    def _unique_keys(self) -> "PlaybookActions":
        seen = set()
        for a in self.root:
            if a.key in seen:
                raise ValueError(f"duplicate action key: {a.key}")
            seen.add(a.key)
        return self


def parse_actions(actions) -> List[Union[NotifyAction, TicketAction]]:
    """Typed actions from typed models or their stored JSON form (validated)."""
    if not actions:
        return []
    if all(isinstance(a, (NotifyAction, TicketAction)) for a in actions):
        return list(actions)
    return PlaybookActions.model_validate([a.model_dump() if isinstance(a, BaseModel) else a for a in actions]).root
