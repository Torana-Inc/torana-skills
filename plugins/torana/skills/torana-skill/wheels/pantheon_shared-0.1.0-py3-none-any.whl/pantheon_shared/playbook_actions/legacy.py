"""Legacy build_v2 playbook actions (OI-188 b, spec § 3.2).

`legacy_flatten` is pantheon-program-framework's `_create_playbook` flattening (`build_v2_deploy_executor.py:
2717-2734`), moved here VERBATIM so PF and WF run the same code: deploy output stays byte-identical (test T5).
`normalize_legacy_action` maps one untyped `definition["actions"]` entry to a typed action, or None. It never guesses.
"""
from __future__ import annotations

import re
from typing import Optional, Union

from pydantic import ValidationError

from pantheon_shared.playbook_actions.schema import NotifyAction, TicketAction


def legacy_flatten(d: dict) -> str:
    """The playbook instructions PF has always synthesized from a build_v2 definition."""
    name = d.get("name") or d.get("title") or "SLA Playbook"
    instructions = (d.get("instructions") or "").strip()
    if len(instructions) < 10:
        parts = [d.get("description") or d.get("title") or name]
        for a in (d.get("actions") or []):
            if not isinstance(a, dict):
                continue
            act = a.get("action_type") or "action"
            chan = a.get("notification_channel")
            recips = ", ".join(a.get("recipient_groups") or [])
            tmpl = a.get("message_template") or ""
            line = f"- {act}" + (f" via {chan}" if chan else "") + (f" to {recips}" if recips else "")
            if tmpl:
                line += f": {tmpl}"
            parts.append(line)
        instructions = "\n".join(p for p in parts if p).strip()
    if len(instructions) < 10:
        instructions = f"Playbook for {name}. Notify the responsible teams on trigger."
    return instructions


NOTIFY_TYPES = frozenset({"notify", "notification", "send_notification", "slack", "slack_message", "alert_team"})
TICKET_TYPES = frozenset({"ticket", "create_ticket", "jira", "open_ticket"})
LEGACY_TICKET_SUMMARY = "[<<alert_data.severity>>] <<alert_data.alert_name>>"


def slugify_group(name: str) -> str:
    """'Platform Oncall' -> 'platform-oncall': lower case, spaces -> '-', other characters dropped."""
    s = str(name).strip().lower().replace(" ", "-")
    return re.sub(r"[^a-z0-9_-]", "", s)


def normalize_legacy_action(d: dict, index: int) -> Optional[Union[NotifyAction, TicketAction]]:
    if not isinstance(d, dict):
        return None
    action_type = str(d.get("action_type") or "").strip().lower()
    channel = str(d.get("notification_channel") or "").strip().lower() or None
    raw_groups = d.get("recipient_groups") or []
    if not isinstance(raw_groups, list):
        return None
    groups = list(dict.fromkeys(slugify_group(g) for g in raw_groups if isinstance(g, str)))
    template = d.get("message_template")
    try:
        if action_type in NOTIFY_TYPES and channel in (None, "slack"):
            if not groups or not isinstance(template, str) or not template.strip():
                return None
            return NotifyAction(type="notify", key=f"notify_{index}", channel="slack", recipient_groups=groups,
                                message_template=template)
        if action_type in TICKET_TYPES and channel in (None, "jira"):
            if not groups:
                return None
            return TicketAction(type="ticket", key=f"ticket_{index}", system="jira", recipient_group=groups[0],
                                summary_template=LEGACY_TICKET_SUMMARY,
                                description_template=template if isinstance(template, str) else "")
    except ValidationError:
        return None
    return None
