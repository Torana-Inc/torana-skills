"""Deterministic template rendering for declarative playbook actions (OI-188 b, spec § 3.3). No model, no I/O, no
clock: the caller passes `execution.timestamp`. Same input, byte-identical output.

Syntax is WF's existing `<<root.path>>` (`TemplateRenderer.extract_variables`), so one template language exists.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, Iterable, List, Literal, Optional, Set, Tuple

from pydantic import BaseModel

from pantheon_shared.playbook_actions.schema import NotifyAction, TicketAction, parse_actions

ALLOWED_ROOTS = {"alert_data", "input", "execution", "playbook"}
ALERT_FIELDS = {"alert_id", "alert_name", "alert_description", "severity", "tags", "rule_id", "rule_name",
                "created_at", "status", "workspace_id", "routing_rule_id", "alert_url"}
EXECUTION_FIELDS = {"id", "timestamp", "date"}
PLAYBOOK_FIELDS = {"name", "id"}
#: Bulk or identity data: never renderable, whatever the alert context carries.
BLOCKED_ALERT_FIELDS = {"rule_results", "tenant_id", "namespace_id"}

NOT_AVAILABLE = "(not available)"
ELLIPSIS = "…"

#: Per-target limits (§ 3.3.1): Slack text / title, Jira summary / description.
MAX_SLACK_TEXT, MAX_SLACK_TITLE, MAX_JIRA_SUMMARY, MAX_JIRA_DESCRIPTION = 3000, 200, 255, 10000

_VAR = re.compile(r"<<([^>]+)>>")                     # == TemplateRenderer.extract_variables
_WS_RUN = re.compile(r"[\r\n\t]+")

Mode = Literal["slack", "plain", "single_line"]


@dataclass(frozen=True)
class RenderResult:
    text: str
    missing: List[str] = field(default_factory=list)
    truncated: bool = False


class TemplateIssue(BaseModel):
    level: Literal["error", "warning"]
    action_key: str
    field: str
    variable: str
    message: str


def template_variables(template: str) -> List[str]:
    return [m.strip() for m in _VAR.findall(template or "")]


def _renderable(path: str) -> bool:
    parts = path.split(".")
    root = parts[0]
    if root not in ALLOWED_ROOTS or len(parts) < 2:
        return False
    if root == "alert_data":
        return parts[1] not in BLOCKED_ALERT_FIELDS
    if root == "execution":
        return parts[1] in EXECUTION_FIELDS
    if root == "playbook":
        return parts[1] in PLAYBOOK_FIELDS
    return True


def _lookup(ctx: dict, path: str) -> Tuple[bool, Any]:
    if not _renderable(path):
        return False, None
    cur: Any = ctx
    for part in path.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return False, None
        cur = cur[part]
    return (cur is not None), cur


def _value_text(v: Any) -> str:
    if isinstance(v, str):
        return v
    if isinstance(v, (list, tuple)):
        return ", ".join(map(str, v))
    if isinstance(v, dict):
        return json.dumps(v, separators=(",", ":"), sort_keys=True, default=str)
    return str(v)


def _slack_escape(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def render_text(template: str, ctx: dict, *, mode: Mode, max_len: int) -> RenderResult:
    missing: List[str] = []

    def sub(m: "re.Match[str]") -> str:
        path = m.group(1).strip()
        found, value = _lookup(ctx or {}, path)
        if not found:
            if path not in missing:
                missing.append(path)
            return NOT_AVAILABLE
        text = _value_text(value)
        return _slack_escape(text) if mode == "slack" else text

    text = _VAR.sub(sub, template or "")
    if mode == "single_line":
        text = _WS_RUN.sub(" ", text).strip()
    truncated = len(text) > max_len
    if truncated:
        text = text[:max(0, max_len - 1)] + ELLIPSIS
    return RenderResult(text=text, missing=missing, truncated=truncated)


def _templates(action) -> Iterable[Tuple[str, Optional[str]]]:
    if isinstance(action, NotifyAction):
        return (("title_template", action.title_template), ("message_template", action.message_template))
    if isinstance(action, TicketAction):
        return (("summary_template", action.summary_template), ("description_template", action.description_template))
    return ()


def _issue(path: str, declared_inputs: Set[str]) -> Optional[Tuple[str, str]]:
    parts = path.split(".")
    root = parts[0]
    if root not in ALLOWED_ROOTS:
        return "error", f"unknown variable root '{root}' (allowed: {', '.join(sorted(ALLOWED_ROOTS))})"
    if len(parts) < 2:
        return "error", f"'{path}' names a whole context, not a field"
    name = parts[1]
    if root == "alert_data":
        if name in BLOCKED_ALERT_FIELDS:
            return "error", f"'{path}' is not renderable (bulk or identity data)"
        if name not in ALERT_FIELDS:
            return "warning", f"'{path}' is not a known alert field ({', '.join(sorted(ALERT_FIELDS))})"
        return None
    if root == "execution" and name not in EXECUTION_FIELDS:
        return "error", f"unknown execution field '{name}' (allowed: {', '.join(sorted(EXECUTION_FIELDS))})"
    if root == "playbook" and name not in PLAYBOOK_FIELDS:
        return "error", f"unknown playbook field '{name}' (allowed: {', '.join(sorted(PLAYBOOK_FIELDS))})"
    if root == "input" and name not in declared_inputs:
        return "error", f"input '{name}' is not a declared input parameter"
    return None


def validate_templates(actions, declared_inputs: Set[str]) -> List[TemplateIssue]:
    """Errors: unknown root, unknown execution./playbook. field, undeclared input, blocked alert field.
    Warnings: an alert_data field outside ALERT_FIELDS (DF may add keys later)."""
    out: List[TemplateIssue] = []
    for action in parse_actions(actions):
        for fname, tmpl in _templates(action):
            for path in template_variables(tmpl or ""):
                hit = _issue(path, set(declared_inputs or ()))
                if hit:
                    out.append(TemplateIssue(level=hit[0], action_key=action.key, field=fname, variable=path,
                                             message=hit[1]))
    return out
