"""One human line per typed action (OI-188 b, spec § 3.2): the stored summary of a declarative playbook and the
hybrid agent preamble. Not expected to equal `legacy_flatten`."""
from __future__ import annotations

from pantheon_shared.playbook_actions.schema import NotifyAction, TicketAction, parse_actions


def describe_actions(actions) -> str:
    lines = []
    for a in parse_actions(actions):
        if isinstance(a, NotifyAction):
            lines.append(f"- notify via {a.channel} to {', '.join(a.recipient_groups)}: {a.message_template}")
        elif isinstance(a, TicketAction):
            lines.append(f"- ticket in {a.system} for {a.recipient_group}: {a.summary_template}")
    return "\n".join(lines)
