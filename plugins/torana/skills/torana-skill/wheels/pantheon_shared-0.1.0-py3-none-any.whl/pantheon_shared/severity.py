"""The words every surface uses for a severity: ONE place, Title case in and out, never a stored enum value.

An alert carries two severities that are not the same fact:
  * the RULE's (`alerts.severity`, Postgres enum low|medium|high|critical): a constant of the rule, the same on every item it raises;
  * the FINDING's (`alerts.finding_severity`, the datalake's vocabulary Critical|High|Medium|Low|Info): what the matched finding said.
A surface shows the finding's, as "Not recorded" when the finding stated none, and never lets the rule's stand in for it. Where both
appear they are labelled `RULE_SEVERITY_LABEL` and `FINDING_SEVERITY_LABEL`.
"""
from __future__ import annotations

from typing import Any, Optional

NOT_RECORDED = "Not recorded"
#: A rule that declares no severity (rules.severity is NULL): nothing stands in for it.
NOT_DECLARED = "Not declared"
RULE_SEVERITY_LABEL = "Rule severity"
FINDING_SEVERITY_LABEL = "Finding severity"

#: Worst first. The datalake adds Info, which the rule enum has no word for.
SEVERITY_WORDS = ("Critical", "High", "Medium", "Low", "Info")
_BY_LOWER = {w.lower(): w for w in SEVERITY_WORDS}


def _text(value: Any) -> str:
    value = getattr(value, "value", value)      # an Enum member
    return "" if value is None else str(value).strip()


def severity_word(value: Any) -> Optional[str]:
    """`critical`, ` HIGH `, `Medium` -> Critical, High, Medium. None for nothing stated; a value outside the vocabulary keeps its
    own text with the first letter capital (it is shown, not hidden or mapped to a neighbour)."""
    text = _text(value)
    if not text or text == "—":
        return None
    return _BY_LOWER.get(text.lower()) or text[:1].upper() + text[1:]


def rule_severity_word(severity: Any) -> Optional[str]:
    """The declaring rule's severity in words, e.g. "Medium"."""
    return severity_word(severity)


def rule_severity_label_text(severity: Any) -> str:
    """The rule's declared severity in words, or "Not declared" when the rule declares none."""
    return severity_word(severity) or NOT_DECLARED


def finding_severity_word(finding_severity: Any) -> str:
    """The finding's own severity in words, or "Not recorded" (the finding stated none; the rule's is never a stand-in)."""
    return severity_word(finding_severity) or NOT_RECORDED
