"""
Auto-generated build provenance.

Written by build_version.py at build time and NOT tracked in git.
Do not edit manually -- your changes will be overwritten by the next build.
"""

VERSION = "0.1.0"
COMMIT_SHA = "326f331af0080645032c82cb68ba92edd88e80a1"
COMMIT_TIME = "2026-10-18T09:17:30+05:30"
BRANCH = "main"
DIRTY = False
