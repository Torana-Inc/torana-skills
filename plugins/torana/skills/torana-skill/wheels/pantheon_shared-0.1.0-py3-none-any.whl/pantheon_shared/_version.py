"""
Auto-generated build provenance.

Written by build_version.py at build time and NOT tracked in git.
Do not edit manually -- your changes will be overwritten by the next build.
"""

VERSION = "0.1.0"
COMMIT_SHA = "10fd5d1f925f4bed5a0b522fe49566d6607011b9"
COMMIT_TIME = "2026-10-28T14:30:15-07:00"
BRANCH = "main"
DIRTY = True
