"""
Auto-generated build provenance.

Written by build_version.py at build time and NOT tracked in git.
Do not edit manually -- your changes will be overwritten by the next build.
"""

VERSION = "0.1.0"
COMMIT_SHA = "0f252a0a2cd656b0756fbd79fbf75a9370405c1c"
COMMIT_TIME = "2026-11-24T07:44:36-08:00"
BRANCH = "remotes/origin/HEAD"
DIRTY = False
