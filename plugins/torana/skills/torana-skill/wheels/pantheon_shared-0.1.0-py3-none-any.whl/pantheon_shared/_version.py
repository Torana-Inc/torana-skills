"""
Auto-generated build provenance.

Written by build_version.py at build time and NOT tracked in git.
Do not edit manually -- your changes will be overwritten by the next build.
"""

VERSION = "0.1.0"
COMMIT_SHA = "486b6349231c41f899552d04e71d7d873be13d79"
COMMIT_TIME = "2026-10-27T17:59:53+05:30"
BRANCH = "feature/fix-knowledge"
DIRTY = False
