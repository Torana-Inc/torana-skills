"""
Auto-generated build provenance.

Written by build_version.py at build time and NOT tracked in git.
Do not edit manually -- your changes will be overwritten by the next build.
"""

VERSION = "0.1.0"
COMMIT_SHA = "ec7e7674b268d6f667bec7815ffafcae2e0d727e"
COMMIT_TIME = "2026-09-19T22:29:16+05:30"
BRANCH = "main"
DIRTY = False
