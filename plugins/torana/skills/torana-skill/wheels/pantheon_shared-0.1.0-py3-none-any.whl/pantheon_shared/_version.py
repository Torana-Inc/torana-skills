"""
Auto-generated build provenance.

Written by build_version.py at build time and NOT tracked in git.
Do not edit manually -- your changes will be overwritten by the next build.
"""

VERSION = "0.1.0"
COMMIT_SHA = "b93c27a55e0ecd74d7addc64f1a542bfdd15e61d"
COMMIT_TIME = "2026-10-22T06:04:27-07:00"
BRANCH = "heads/batch2/mc-2026-10-21"
DIRTY = False
