"""
Auto-generated build provenance.

Written by build_version.py at build time and NOT tracked in git.
Do not edit manually -- your changes will be overwritten by the next build.
"""

VERSION = "0.1.0"
COMMIT_SHA = "91c5784e4e12d59e7447ba67547c197243e2540f"
COMMIT_TIME = "2026-09-22T21:03:52+05:30"
BRANCH = "main"
DIRTY = False
