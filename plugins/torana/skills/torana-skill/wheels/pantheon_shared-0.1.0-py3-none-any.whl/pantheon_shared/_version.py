"""
Auto-generated build provenance.

Written by build_version.py at build time and NOT tracked in git.
Do not edit manually -- your changes will be overwritten by the next build.
"""

VERSION = "0.1.0"
COMMIT_SHA = "8cbce42907ebad25f6efd6011aad096494b23b7b"
COMMIT_TIME = "2026-10-29T10:36:54+05:30"
BRANCH = "feature/fix-pr-localhost-1029"
DIRTY = False
