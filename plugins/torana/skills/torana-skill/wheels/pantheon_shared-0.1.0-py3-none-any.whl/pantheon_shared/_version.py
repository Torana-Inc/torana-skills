"""
Auto-generated build provenance.

Written by build_version.py at build time and NOT tracked in git.
Do not edit manually -- your changes will be overwritten by the next build.
"""

VERSION = "0.1.0"
COMMIT_SHA = "5ff876f75c5f46dd1f14697dbca35bb8464b1b4b"
COMMIT_TIME = "2026-10-30T12:28:09-07:00"
BRANCH = "main"
DIRTY = False
