"""
Auto-generated build provenance.

Written by build_version.py at build time and NOT tracked in git.
Do not edit manually -- your changes will be overwritten by the next build.
"""

VERSION = "0.1.0"
COMMIT_SHA = "2740f4137f73eb2796ae1690e031af28d6030e08"
COMMIT_TIME = "2026-11-06T20:36:43+05:30"
BRANCH = "main"
DIRTY = False
