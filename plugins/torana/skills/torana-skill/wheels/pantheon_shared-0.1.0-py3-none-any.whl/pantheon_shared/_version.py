"""
Auto-generated build provenance.

Written by build_version.py at build time and NOT tracked in git.
Do not edit manually -- your changes will be overwritten by the next build.
"""

VERSION = "0.1.0"
COMMIT_SHA = "35a6fb6b6173d847ff47023ad330ad7d584a2476"
COMMIT_TIME = "2026-10-15T00:44:39-07:00"
BRANCH = "heads/home-why"
DIRTY = False
