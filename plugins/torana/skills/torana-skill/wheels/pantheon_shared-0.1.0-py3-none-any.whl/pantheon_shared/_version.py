"""
Auto-generated build provenance.

Written by build_version.py at build time and NOT tracked in git.
Do not edit manually -- your changes will be overwritten by the next build.
"""

VERSION = "0.1.0"
COMMIT_SHA = "e34c17053fd8bf50658cfcbaf7c88b6e19b596c5"
COMMIT_TIME = "2026-09-15T17:56:40-07:00"
BRANCH = "main"
DIRTY = False
