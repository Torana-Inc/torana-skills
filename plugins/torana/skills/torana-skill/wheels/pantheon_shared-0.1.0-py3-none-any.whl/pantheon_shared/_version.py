"""
Auto-generated build provenance.

Written by build_version.py at build time and NOT tracked in git.
Do not edit manually -- your changes will be overwritten by the next build.
"""

VERSION = "0.1.0"
COMMIT_SHA = "836af2c53b2baba3dbd35c59982c9ce221e6bf8f"
COMMIT_TIME = "2026-10-24T07:57:40-07:00"
BRANCH = "main"
DIRTY = False
