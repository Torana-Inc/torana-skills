"""
Auto-generated build provenance.

Written by build_version.py at build time and NOT tracked in git.
Do not edit manually -- your changes will be overwritten by the next build.
"""

VERSION = "0.1.0"
COMMIT_SHA = "1b812888a04d32e71dbd855d152a5b68c7f6d559"
COMMIT_TIME = "2026-11-05T18:47:18+05:30"
BRANCH = "main"
DIRTY = False
