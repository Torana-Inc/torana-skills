"""
Auto-generated build provenance.

Written by build_version.py at build time and NOT tracked in git.
Do not edit manually -- your changes will be overwritten by the next build.
"""

VERSION = "0.1.0"
COMMIT_SHA = "c81c025e4bc7ce8aa8f16a0993a69928fd571509"
COMMIT_TIME = "2026-10-27T11:51:02-07:00"
BRANCH = "main"
DIRTY = False
