"""
Auto-generated build provenance.

Written by build_version.py at build time and NOT tracked in git.
Do not edit manually -- your changes will be overwritten by the next build.
"""

VERSION = "0.1.0"
COMMIT_SHA = "d2b1dc7710b5c77566f67f2054b24a9f0cc59e02"
COMMIT_TIME = "2026-10-04T16:50:52+05:30"
BRANCH = "main"
DIRTY = False
