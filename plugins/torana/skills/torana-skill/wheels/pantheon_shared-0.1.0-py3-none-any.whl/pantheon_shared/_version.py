"""
Auto-generated build provenance.

Written by build_version.py at build time and NOT tracked in git.
Do not edit manually -- your changes will be overwritten by the next build.
"""

VERSION = "0.1.0"
COMMIT_SHA = "7039c4891fe99c05f6e2c663323cff7bbe15451a"
COMMIT_TIME = "2026-10-13T13:10:03-07:00"
BRANCH = "main"
DIRTY = False
