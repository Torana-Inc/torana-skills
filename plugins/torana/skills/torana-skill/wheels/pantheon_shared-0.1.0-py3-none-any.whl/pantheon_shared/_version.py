"""
Auto-generated build provenance.

Written by build_version.py at build time and NOT tracked in git.
Do not edit manually -- your changes will be overwritten by the next build.
"""

VERSION = "0.1.0"
COMMIT_SHA = "04a220c087880b4e214a3c2898817dff333c116f"
COMMIT_TIME = "2026-10-14T15:36:52-07:00"
BRANCH = "main"
DIRTY = False
