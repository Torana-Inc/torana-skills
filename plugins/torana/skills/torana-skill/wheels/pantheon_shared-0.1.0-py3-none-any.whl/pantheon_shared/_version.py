"""
Auto-generated build provenance.

Written by build_version.py at build time and NOT tracked in git.
Do not edit manually -- your changes will be overwritten by the next build.
"""

VERSION = "0.1.0"
COMMIT_SHA = "346c4729f01415772f00bcc9be2fc40334914b84"
COMMIT_TIME = "2026-10-14T19:41:06+05:30"
BRANCH = "main"
DIRTY = False
