"""
Auto-generated build provenance.

Written by build_version.py at build time and NOT tracked in git.
Do not edit manually -- your changes will be overwritten by the next build.
"""

VERSION = "0.1.0"
COMMIT_SHA = "c28d08639cb9a195d7954ae0fa3c4d1977336a02"
COMMIT_TIME = "2026-09-30T13:01:09-07:00"
BRANCH = "main"
DIRTY = False
