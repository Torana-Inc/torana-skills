"""
Auto-generated build provenance.

Written by build_version.py at build time and NOT tracked in git.
Do not edit manually -- your changes will be overwritten by the next build.
"""

VERSION = "0.1.0"
COMMIT_SHA = "66a681b937808d5b306b756ee9f50fb258cab221"
COMMIT_TIME = "2026-10-19T20:33:57+05:30"
BRANCH = "main"
DIRTY = False
