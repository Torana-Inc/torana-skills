"""
Auto-generated build provenance.

Written by build_version.py at build time and NOT tracked in git.
Do not edit manually -- your changes will be overwritten by the next build.
"""

VERSION = "0.1.0"
COMMIT_SHA = "3d580b4b20510ec1abe66e9e8e22b9e119349b7d"
COMMIT_TIME = "2026-09-30T21:11:19+05:30"
BRANCH = "main"
DIRTY = False
