"""
Auto-generated build provenance.

Written by build_version.py at build time and NOT tracked in git.
Do not edit manually -- your changes will be overwritten by the next build.
"""

VERSION = "0.1.0"
COMMIT_SHA = "4fa533658c07bd006fc6bbc53ce3c6d7124eda35"
COMMIT_TIME = "2026-10-27T11:31:33-07:00"
BRANCH = "fix/api-diff-check-precision"
DIRTY = False
