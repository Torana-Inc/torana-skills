"""Assessments: the answer to a named question about an item, built from passes (PROOF_ASSESSMENTS_SPEC § 3.2.8).
Importing this package registers every domain's questions."""
from . import domains  # noqa: F401
from .registry import PassDef, QuestionDef, for_item_type, questions

__all__ = ["PassDef", "QuestionDef", "for_item_type", "questions"]
