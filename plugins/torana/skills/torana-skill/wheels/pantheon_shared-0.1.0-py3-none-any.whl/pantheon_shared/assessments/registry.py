"""The question registry: what can be asked about an item, and which passes answer it. Platform code: a domain adds
an entry (domains/<name>.py); nothing here names a domain. PROOF_ASSESSMENTS_SPEC § 3.2.8."""
from __future__ import annotations

import dataclasses
from dataclasses import dataclass

ANSWER_TYPES = ("range", "verdict", "choice")
ASK_KINDS = ("connect", "define", "decide", "run")
RUNS = ("platform", "customer")


@dataclass(frozen=True)
class PassDef:
    kind: str
    title: str                       # the name on the evidence-strength chip
    reads: str                       # one sentence, shown to people and agents
    runs: str                        # RUNS
    available: bool = False          # False: declared so that it shows as a gap; nothing produces it yet
    claim: str | None = None         # the claim id whose presence (and not `missing`) means this pass is in
    required: bool = False           # counted separately: "N of M required"
    gap: str = ""                    # what the platform says when this pass is missing
    ask_kind: str = ""               # ASK_KINDS
    ask: str = ""                    # what unlocks it
    ask_ready: bool = False          # the platform capability EXISTS and the customer has not enabled it: only then
    #                                  is `ask` shown as an instruction. False: the pass is simply not checked yet,
    #                                  and every surface shows `gap`, a statement, never an instruction.


# Passes every domain can include by name (`shared("policy")`): the platform defines them once.
SHARED_PASSES = {
    "policy": PassDef(kind="policy", title="Policy", runs="platform",
                      reads="Your own rules: response times, change windows, approvals.",
                      gap="Your response times and change windows are not applied to this estimate.",
                      ask_kind="define", ask="Set response times and change windows."),
    "owner_answer": PassDef(kind="owner_answer", title="Owner's answer", runs="customer",
                            reads="What the item's owner states or corrects.",
                            gap="Some things only the owner can answer.", ask_kind="decide",
                            ask="Answer the open questions."),
    "outcome": PassDef(kind="outcome", title="Outcome", runs="platform",
                       reads="What it actually took, once the item closes.",
                       gap="Nothing has closed with an estimate yet.", ask_kind="connect",
                       ask="Link pull requests or tickets."),
}


def shared(kind: str, **override) -> PassDef:
    """A platform-defined pass, included in a domain's entry. `override` may set `required`, `ask_ready` or a domain's
    own wording."""
    return dataclasses.replace(SHARED_PASSES[kind], **override)


@dataclass(frozen=True)
class QuestionDef:
    domain: str
    item_type: str                   # the proof item type this question is asked of (alerts.classify)
    question: str                    # also the claim section its claims are in
    title: str
    answer: dict                     # {"type": ANSWER_TYPES, ...}
    rule: str                        # the proof rule that computes the answer; it takes one argument, the subject key
    passes: tuple

    def coverage(self, claims: list) -> dict:
        """How strong the evidence is: which declared passes are in, out of all that are possible. `claims` is the
        item's proof claims ({id, kind}); a pass is in when the claim it names is there and is not `missing`."""
        have = {c["id"] for c in claims if c.get("kind") != "missing"}
        rows = [{"kind": p.kind, "title": p.title, "reads": p.reads, "runs": p.runs, "required": p.required,
                 "available": p.available, "claim": p.claim, "done": p.claim in have,
                 "gap": p.gap, "ask_kind": p.ask_kind, "ask": p.ask, "ask_ready": p.ask_ready} for p in self.passes]
        req = [r for r in rows if r["required"]]
        return {"done": sum(r["done"] for r in rows), "total": len(rows),
                "required_done": sum(r["done"] for r in req), "required_total": len(req),
                # missing passes nobody can act on yet: counted here, so no surface counts
                "not_available": sum(not r["done"] and not r["ask_ready"] for r in rows),
                "passes": rows, "missing": [r for r in rows if not r["done"]]}


_QUESTIONS: dict[tuple[str, str], QuestionDef] = {}


def register_question(q: QuestionDef) -> QuestionDef:
    key = (q.item_type, q.question)
    if key in _QUESTIONS:
        raise ValueError(f"{key}: question already registered by domain {_QUESTIONS[key].domain}")
    if q.answer.get("type") not in ANSWER_TYPES:
        raise ValueError(f"{key}: unknown answer type {q.answer.get('type')!r}")
    for p in q.passes:
        if p.runs not in RUNS or (p.ask_kind and p.ask_kind not in ASK_KINDS):
            raise ValueError(f"{key}/{p.kind}: bad runs or ask_kind")
        if p.available != (p.claim is not None):
            raise ValueError(f"{key}/{p.kind}: an available pass names its claim, and only an available pass does")
        if not p.available and not p.gap:
            raise ValueError(f"{key}/{p.kind}: a pass that is not available says what is not known (gap)")
    _QUESTIONS[key] = q
    return q


def for_item_type(item_type: str) -> list[QuestionDef]:
    return [q for q in _QUESTIONS.values() if q.item_type == item_type]


def questions() -> list[QuestionDef]:
    return list(_QUESTIONS.values())
