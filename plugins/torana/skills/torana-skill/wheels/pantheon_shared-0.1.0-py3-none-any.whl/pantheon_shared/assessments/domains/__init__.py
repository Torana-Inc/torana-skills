"""Domain entries of the question registry: one module per domain, imported here so its questions register."""
from . import vm  # noqa: F401
