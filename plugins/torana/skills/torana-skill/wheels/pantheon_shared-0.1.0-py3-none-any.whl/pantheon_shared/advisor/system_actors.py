SYSTEM_ACTOR_REFRESH_SWEEP = "system:advisor_refresh_sweep"
