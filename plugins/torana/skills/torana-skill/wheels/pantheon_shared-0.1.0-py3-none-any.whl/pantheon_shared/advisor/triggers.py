TRIGGERED_BY_VALUES = (
    "workspace_creation",
    "manual_refresh",
    "scheduled_sweep",
    "admin_sweep",
)
