ARTIFACT_TYPES = (
    "rule",
    "suite",
    "dashboard",
    "transformer",
    "playbook",
    "alert_route",
    "schedule",
    "policy_document",
)
