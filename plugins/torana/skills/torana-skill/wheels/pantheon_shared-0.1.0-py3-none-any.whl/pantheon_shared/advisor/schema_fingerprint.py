"""Schema fingerprint helper for Slice 2c Snapshot v2.

Produces a deterministic SHA-256 hex digest of a sorted column list.
Used by F-tools (Slice 2f) to detect schema drift between sweeps by
comparing `environment_summary.data_sources[].schema_fingerprint` values
across `previous_environment_summary` and the current summary.
"""
from __future__ import annotations

import hashlib
import json
from typing import Sequence


def compute_schema_fingerprint(columns: Sequence[str]) -> str:
    """Return sha256:<hex> for the sorted, deduplicated column list.

    Sorting and deduplication ensure the fingerprint is stable regardless
    of the order columns are returned from the DB schema query.

    Args:
        columns: Column names for a single data-source table.

    Returns:
        String of the form "sha256:<64-char hex digest>".
    """
    canonical = json.dumps(sorted(set(columns)), separators=(",", ":"))
    digest = hashlib.sha256(canonical.encode()).hexdigest()
    return f"sha256:{digest}"
