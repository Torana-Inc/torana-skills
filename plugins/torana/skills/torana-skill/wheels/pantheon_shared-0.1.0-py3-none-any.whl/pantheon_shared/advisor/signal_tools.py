import importlib

SIGNAL_TOOL_NAMES_BY_SLICE: dict[str, tuple[str, ...]] = {
    "2b": (
        "get_workspace_artifacts",
        "get_rule_run_stats",
        "get_alert_dispositions",
        "get_data_source_stats",
        "get_framework_coverage",
    ),
    "2d": (
        "summarize_usage_signals",
    ),
    "2f": (
        "detect_schema_drift",
        "compute_rule_coverage",
        "list_silent_rules",
    ),
}

# Maps each tool name to the module that must export it.
# Keep in sync with the agent-builder tool registry.
_TOOL_MODULES: dict[str, str] = {
    "get_workspace_artifacts": "pantheon_program_framework.services.refresh_signal_tools",
    "get_rule_run_stats": "pantheon_program_framework.services.refresh_signal_tools",
    "get_alert_dispositions": "pantheon_program_framework.services.refresh_signal_tools",
    "get_data_source_stats": "pantheon_program_framework.services.refresh_signal_tools",
    "get_framework_coverage": "pantheon_program_framework.services.refresh_signal_tools",
    "summarize_usage_signals": "pantheon_program_framework.services.refresh_signal_tools",
    "detect_schema_drift": "pantheon_program_framework.services.refresh_signal_tools",
    "compute_rule_coverage": "pantheon_program_framework.services.refresh_signal_tools",
    "list_silent_rules": "pantheon_program_framework.services.refresh_signal_tools",
}


def active_signal_tool_names() -> tuple[str, ...]:
    """Return the bypass list for the currently-deployed slices.

    A slice is active iff every tool function it declares is importable.
    This is a code-version check, not a feature-flag check — slices that
    haven't shipped yet fail closed rather than referencing nonexistent
    functions.
    """
    enabled = _enabled_slices_by_import()
    return tuple(
        name
        for slice_id, names in SIGNAL_TOOL_NAMES_BY_SLICE.items()
        if slice_id in enabled
        for name in names
    )


def _enabled_slices_by_import() -> set[str]:
    """A slice is 'active' iff every tool it declares can be imported.

    A half-deployed slice (implementation added but agent-builder tool
    registry not yet updated) fails closed — the bypass list does not
    reference a function that doesn't exist yet.
    """
    enabled: set[str] = set()
    for slice_id, names in SIGNAL_TOOL_NAMES_BY_SLICE.items():
        try:
            for name in names:
                mod_path = _TOOL_MODULES[name]
                mod = importlib.import_module(mod_path)
                if not hasattr(mod, name):
                    raise ImportError(f"{name} not in {mod_path}")
            enabled.add(slice_id)
        except (ImportError, KeyError):
            pass
    return enabled
