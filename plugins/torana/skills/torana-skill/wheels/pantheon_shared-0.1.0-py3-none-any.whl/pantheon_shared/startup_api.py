"""Shared ``/health/startup`` endpoint.

Exposes :mod:`pantheon_shared.locking.startup_state` over HTTP so every service
gets the same startup-diagnostics surface from one line of wiring instead of a
copy-pasted route per repo::

    from pantheon_shared import startup_router
    app.include_router(startup_router, prefix="/api/v1")

Why this is a shared router rather than per-service code
--------------------------------------------------------
The payload is entirely service-agnostic — it is just the contents of the
process-local startup record. Duplicating the route per service would mean
seven copies drifting apart, and the whole point of the startup-state work is
that this failure class is identical across services.

Pairs with the ``startup_ok`` / ``startup_error`` fields each service adds to
its own ``/health`` response. ``/health`` answers "should a load balancer send
me traffic?"; this endpoint answers "what exactly went wrong, and on which
worker?".
"""

from typing import Any, Dict

from fastapi import APIRouter

from pantheon_shared.iam.openapi_extensions import public_endpoint
from pantheon_shared.locking import startup_state

router = APIRouter()


@router.get(
    "/health/startup",
    response_model=Dict[str, Any],
    operation_id="startup_health_check",
    summary="Startup Health Detail",
    description=(
        "Per-worker detail of how this process's startup went: every recorded "
        "step, its status, and the error for any that failed.\n\n"
        "Because gunicorn runs several workers and victor-only steps run in "
        "exactly one of them, repeat calls may land on different workers and "
        "return different views — `worker_pid` identifies which one answered. "
        "Failures published by other workers are surfaced through `/health` "
        "(`startup_ok` / `startup_error`), which reads the shared flags table."
    ),
    tags=["health"],
    **public_endpoint().openapi_kwargs
)
async def startup_health_check() -> Dict[str, Any]:
    """Return the raw per-worker startup record."""
    return startup_state.snapshot()
