"""
FastAPI Depends() helpers for the unified table query contract.
"""

import json
from typing import Optional

from fastapi import HTTPException, Query
from pydantic import ValidationError

from pantheon_shared.query.models import CursorRequest, FilterClause, PageRequest, SortClause


def _parse_filters(filters: Optional[str]) -> dict:
    """Parse the JSON `filters` query string → {field: FilterClause}. Any client error —
    a malformed value (empty-after-strip, "undefined"/"null", non-JSON), a non-object, or
    a valid-JSON clause with a bad shape/operator (e.g. operation '==' instead of
    'equals') — raises a clean 400. None of these are server faults, so none should
    surface as a 500."""
    if not filters or not filters.strip():
        return {}
    try:
        raw = json.loads(filters)
    except json.JSONDecodeError:
        raise HTTPException(
            status_code=400,
            detail="`filters` must be a JSON object string, e.g. "
                   '{"name":{"operation":"contains_ignore_case","value":"acme"}}',
        )
    if not isinstance(raw, dict):
        raise HTTPException(status_code=400, detail="`filters` must be a JSON object")
    try:
        return {k: FilterClause.model_validate(v) for k, v in raw.items()}
    except ValidationError as exc:
        raise HTTPException(
            status_code=400,
            detail=(
                "`filters` has an invalid clause (check `operation` is one of the "
                "allowed values, e.g. 'equals'/'contains_ignore_case', and `value` is "
                f"present where required): {exc.errors(include_url=False)}"
            ),
        )


def _parse_sort(sort: Optional[str]) -> list:
    """Parse the JSON `sort` query string → [SortClause]. Any client error (non-JSON,
    non-array, or a bad clause shape/direction) → clean 400, never a 500."""
    if not sort or not sort.strip():
        return []
    try:
        raw = json.loads(sort)
    except json.JSONDecodeError:
        raise HTTPException(
            status_code=400,
            detail='`sort` must be a JSON array string, e.g. '
                   '[{"field":"created_at","direction":"desc"}]',
        )
    if not isinstance(raw, list):
        raise HTTPException(status_code=400, detail="`sort` must be a JSON array")
    try:
        return [SortClause.model_validate(s) for s in raw]
    except ValidationError as exc:
        raise HTTPException(
            status_code=400,
            detail=(
                "`sort` has an invalid clause (check `field` is present and `direction` "
                f"is 'asc' or 'desc'): {exc.errors(include_url=False)}"
            ),
        )


def page_query_params(
    page: int = Query(1, ge=1, description="1-indexed page number"),
    page_size: int = Query(25, ge=1, le=100, description="Items per page (max 100)"),
    filters: Optional[str] = Query(
        None,
        description=(
            'JSON filter map — e.g. {"name":{"operation":"contains_ignore_case","value":"acme"}}'
        ),
    ),
    sort: Optional[str] = Query(
        None,
        description='JSON sort array — e.g. [{"field":"created_at","direction":"desc"}]',
    ),
) -> PageRequest:
    """
    FastAPI dependency that parses page-based query params into a PageRequest.

    Usage:
        @router.get("/items")
        async def list_items(request: PageRequest = Depends(page_query_params)):
            ...
    """
    # filters/sort arrive as JSON-encoded query strings. A malformed value must become a
    # clean 400, not an unhandled JSONDecodeError (500). See _parse_filters/_parse_sort.
    return PageRequest(
        page=page, page_size=page_size,
        filters=_parse_filters(filters), sort=_parse_sort(sort),
    )


def cursor_query_params(
    cursor: Optional[str] = Query(None, description="Opaque cursor from previous response"),
    limit: int = Query(25, ge=1, le=100, description="Items per page (max 100)"),
    filters: Optional[str] = Query(
        None,
        description='JSON filter map — e.g. {"status":{"operation":"equals","value":"active"}}',
    ),
    sort: Optional[str] = Query(
        None,
        description='JSON sort array — e.g. [{"field":"created_at","direction":"desc"}]',
    ),
) -> CursorRequest:
    """
    FastAPI dependency that parses cursor-based query params into a CursorRequest.

    Usage:
        @router.get("/items")
        async def list_items(request: CursorRequest = Depends(cursor_query_params)):
            ...
    """
    return CursorRequest(
        cursor=cursor, limit=limit,
        filters=_parse_filters(filters), sort=_parse_sort(sort),
    )
