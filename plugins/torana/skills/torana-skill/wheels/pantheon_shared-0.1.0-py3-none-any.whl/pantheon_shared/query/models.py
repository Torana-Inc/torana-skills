"""
Pydantic models for the unified table query contract.
"""

from typing import Any, Dict, Generic, List, Literal, Optional, TypeVar

from pydantic import BaseModel, Field, model_validator


# Common symbolic / shorthand operators mapped to the canonical operation name.
# LLM-driven tool calls (and humans) routinely write `==`, `!=`, `>`, `in`, etc.;
# accept those rather than 400-ing a request that's unambiguous in intent.
_OPERATION_ALIASES = {
    "==": "equals", "=": "equals", "eq": "equals",
    "!=": "not_equals", "<>": "not_equals", "ne": "not_equals",
    ">": "greater_than", "gt": "greater_than",
    ">=": "greater_than_equals", "gte": "greater_than_equals", "ge": "greater_than_equals",
    "<": "less_than", "lt": "less_than",
    "<=": "less_than_equals", "lte": "less_than_equals", "le": "less_than_equals",
    "like": "contains", "ilike": "contains_ignore_case", "icontains": "contains_ignore_case",
    "startswith": "starts_with", "endswith": "ends_with",
    "in": "in_list", "not_in": "not_in_list", "nin": "not_in_list",
    "isnull": "is_null", "isnotnull": "is_not_null", "is_not_null ": "is_not_null",
}

T = TypeVar("T")

FilterOperation = Literal[
    "equals",
    "not_equals",
    "greater_than",
    "greater_than_equals",
    "less_than",
    "less_than_equals",
    "between",
    "contains",
    "contains_ignore_case",
    "starts_with",
    "ends_with",
    "in_list",
    "not_in_list",
    "is_null",
    "is_not_null",
]

_NULLARY_OPS = {"is_null", "is_not_null"}
_LIST_OPS = {"in_list", "not_in_list"}
_BETWEEN_OPS = {"between"}
_VALUE_REQUIRED_OPS = set(FilterOperation.__args__) - _NULLARY_OPS  # type: ignore[attr-defined]


class FilterClause(BaseModel):
    operation: FilterOperation
    value: Optional[Any] = None

    @model_validator(mode="before")
    @classmethod
    def _coerce_operation_alias(cls, data: Any) -> Any:
        """Map symbolic/shorthand operators (==, !=, >, in, …) to canonical names before
        the Literal check, so a clause that's unambiguous in intent is accepted rather
        than rejected. Unknown operators still fall through to a normal validation error
        (surfaced as a 400 by the query dependency)."""
        if isinstance(data, dict):
            op = data.get("operation")
            if isinstance(op, str):
                canonical = _OPERATION_ALIASES.get(op.strip().lower())
                if canonical:
                    data = {**data, "operation": canonical}
        return data

    @model_validator(mode="after")
    def validate_value(self) -> "FilterClause":
        op = self.operation
        val = self.value

        if op in _NULLARY_OPS:
            if val is not None:
                raise ValueError(f"operation '{op}' must not have a value")
            return self

        if val is None:
            raise ValueError(f"operation '{op}' requires a value")

        if op in _BETWEEN_OPS:
            if not isinstance(val, (list, tuple)) or len(val) != 2:
                raise ValueError("operation 'between' requires a list of exactly 2 values")

        if op in _LIST_OPS:
            if not isinstance(val, (list, tuple)):
                raise ValueError(f"operation '{op}' requires a list value")

        return self


class SortClause(BaseModel):
    field: str
    direction: Literal["asc", "desc"] = "asc"


class PageRequest(BaseModel):
    page: int = Field(1, ge=1, description="1-indexed page number")
    page_size: int = Field(25, ge=1, le=100, description="Items per page (max 100)")
    filters: Dict[str, FilterClause] = Field(default_factory=dict)
    sort: List[SortClause] = Field(default_factory=list)


class CursorRequest(BaseModel):
    cursor: Optional[str] = Field(None, description="Opaque cursor from previous response")
    limit: int = Field(25, ge=1, le=100, description="Items per page (max 100)")
    filters: Dict[str, FilterClause] = Field(default_factory=dict)
    sort: List[SortClause] = Field(default_factory=list)


class PagedResponse(BaseModel, Generic[T]):
    items: List[T]
    page: int
    page_size: int
    total: int
    total_pages: int


class CursorResponse(BaseModel, Generic[T]):
    items: List[T]
    next_cursor: Optional[str]
    has_more: bool
    limit: int
