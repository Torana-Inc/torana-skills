"""
Single source of truth: map a FilterOperation string to a SQLAlchemy column expression.
"""

from typing import Any

from sqlalchemy.sql.elements import ColumnElement

# Operators that must have no value
NULLARY_OPS = {"is_null", "is_not_null"}

# Operators that require a list value
LIST_OPS = {"in_list", "not_in_list"}

# Reusable op sets for SelectFields declarations
TEXT_OPS = {"equals", "not_equals", "contains", "contains_ignore_case", "starts_with", "ends_with", "is_null", "is_not_null"}
ENUM_OPS = {"equals", "not_equals", "in_list", "not_in_list", "is_null", "is_not_null"}
NUMERIC_OPS = {"equals", "not_equals", "greater_than", "greater_than_equals", "less_than", "less_than_equals", "between", "is_null", "is_not_null"}
DATE_OPS = {"equals", "greater_than", "greater_than_equals", "less_than", "less_than_equals", "between", "is_null", "is_not_null"}
ID_OPS = {"equals", "is_null", "is_not_null"}


def apply_operator(col: ColumnElement, op: str, value: Any) -> ColumnElement:
    """
    Return a SQLAlchemy boolean expression for ``col <op> value``.

    Raises ValueError for unknown operators (should not happen if models.py
    validates the op before this is called).
    """
    if op == "is_null":
        return col.is_(None)
    if op == "is_not_null":
        return col.isnot(None)
    if op == "equals":
        return col == value
    if op == "not_equals":
        return col != value
    if op == "greater_than":
        return col > value
    if op == "greater_than_equals":
        return col >= value
    if op == "less_than":
        return col < value
    if op == "less_than_equals":
        return col <= value
    if op == "between":
        return col.between(value[0], value[1])
    if op == "contains":
        return col.like(f"%{value}%")
    if op == "contains_ignore_case":
        return col.ilike(f"%{value}%")
    if op == "starts_with":
        return col.ilike(f"{value}%")
    if op == "ends_with":
        return col.ilike(f"%{value}")
    if op == "in_list":
        return col.in_(value)
    if op == "not_in_list":
        return col.notin_(value)
    raise ValueError(f"Unknown filter operator: {op!r}")
