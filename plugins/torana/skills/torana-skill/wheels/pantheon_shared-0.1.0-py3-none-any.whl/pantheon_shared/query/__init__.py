"""
Unified table query contract for Pantheon services.

Public API:
  Models:    PageRequest, CursorRequest, PagedResponse, CursorResponse,
             FilterClause, SortClause, FilterOperation
  Depends:   page_query_params, cursor_query_params
  Executors (QueryBuilder path):  execute_page, execute_cursor
  Executors (raw-Select path):    execute_page_select, execute_page_select_async,
                                  execute_cursor_select, execute_cursor_select_async,
                                  SelectFields
"""

from pantheon_shared.query.dependency import cursor_query_params, page_query_params
from pantheon_shared.query.executor import execute_cursor, execute_page
from pantheon_shared.query.executor_select import (
    SelectFields,
    execute_cursor_select,
    execute_cursor_select_async,
    execute_page_select,
    execute_page_select_async,
)
from pantheon_shared.query.models import (
    CursorRequest,
    CursorResponse,
    FilterClause,
    FilterOperation,
    PagedResponse,
    PageRequest,
    SortClause,
)

__all__ = [
    # Models
    "FilterOperation",
    "FilterClause",
    "SortClause",
    "PageRequest",
    "CursorRequest",
    "PagedResponse",
    "CursorResponse",
    # FastAPI dependencies
    "page_query_params",
    "cursor_query_params",
    # QueryBuilder executors
    "execute_page",
    "execute_cursor",
    # Raw-Select executors
    "SelectFields",
    "execute_page_select",
    "execute_page_select_async",
    "execute_cursor_select",
    "execute_cursor_select_async",
]
