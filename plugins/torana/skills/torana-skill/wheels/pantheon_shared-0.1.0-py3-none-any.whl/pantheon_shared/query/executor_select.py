"""
Raw-Select path for the unified table query contract.

Use this when QueryBuilder is not suitable:
  - Synchronous SQLAlchemy Session (e.g. pantheon-detection-framework)
  - Aggregations / custom column projections
  - UNION / subquery constructions
  - Eager loading with selectinload / joinedload

The caller builds a base Select statement that already encodes the business
logic (joins, eager loads, static WHERE clauses).  This executor applies the
user-supplied filters/sort, handles pagination, and returns the standard
PagedResponse / CursorResponse envelope.

IAM is the caller's responsibility — pass an ``iam_attach_fn`` that adds
tenant/is_deleted clauses to the statement.  This keeps the executor agnostic
about model shapes and column types.

Example — sync session (detection-framework style):

    from sqlalchemy.orm import Session
    from sqlalchemy import select
    from pantheon_shared.query import page_query_params, PagedResponse, SortClause
    from pantheon_shared.query.executor_select import (
        SelectFields, execute_page_select,
    )
    from pantheon_shared.query.models import FilterOperation

    FIELDS: SelectFields = {
        "severity":  {"col": Alert.severity,   "ops": {"equals", "in_list", "not_in_list"}},
        "status":    {"col": Alert.status,      "ops": {"equals", "in_list"}},
        "assigned_to": {"col": Alert.assigned_to, "ops": {"equals", "is_null", "is_not_null"}},
        "created_at": {"col": Alert.created_at, "ops": {"greater_than", "less_than", "between"}, "sortable": True},
        "name":      {"col": Alert.name,        "ops": {"contains_ignore_case"}},
    }
    DEFAULT_SORT = [SortClause(field="created_at", direction="desc")]

    def _attach_iam(stmt, iam):
        return (stmt
            .where(Alert.tenant_id == iam.tenant_id)
            .where(Alert.is_deleted.is_(False)))

    @router.get("", response_model=PagedResponse[AlertResponse])
    def list_alerts(
        request: PageRequest = Depends(page_query_params),
        iam: IAMContext = Depends(IAMEndpoint.get_iam_context),
        db: Session = Depends(get_db_session),
    ):
        base_stmt = select(Alert)
        return execute_page_select(
            request, base_stmt, db,
            fields=FIELDS,
            iam_attach_fn=lambda s: _attach_iam(s, iam),
            serializer=AlertResponse.from_orm,
            default_sort=DEFAULT_SORT,
        )
"""

import math
from typing import Any, Callable, Dict, List, Literal, Optional, Set, Union

from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Session
from sqlalchemy.sql import Select

from pantheon_shared.query.models import (
    CursorRequest,
    CursorResponse,
    PageRequest,
    PagedResponse,
    SortClause,
)
from pantheon_shared.query.operators import apply_operator

# Type alias for the per-field spec dict.
# Each key is a filterable/sortable field name.
# Each value is a dict with:
#   col      — SQLAlchemy column/attribute (required)
#   ops      — set of allowed FilterOperation strings (required)
#   sortable — True if this field may be used in ORDER BY (default False)
FieldSpec = Dict[str, Any]      # {"col": ..., "ops": set, "sortable": bool}
SelectFields = Dict[str, FieldSpec]

# A sync or async DB session.
DBSession = Union[Session, AsyncSession]

# Signature: (stmt: Select) -> Select — adds IAM filters in place.
IAMAttachFn = Callable[[Select], Select]

CountMode = Literal["exact", "none"]


def _apply_select_filters(
    stmt: Select,
    request_filters: dict,
    fields: SelectFields,
) -> Select:
    unknown = set(request_filters.keys()) - set(fields.keys())
    if unknown:
        raise HTTPException(
            status_code=400,
            detail=f"Filter field(s) not allowed: {sorted(unknown)}",
        )

    for field, clause in request_filters.items():
        spec = fields[field]
        if clause.operation not in spec["ops"]:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"Operation '{clause.operation}' is not allowed on field '{field}'. "
                    f"Allowed: {sorted(spec['ops'])}"
                ),
            )
        expr = apply_operator(spec["col"], clause.operation, clause.value)
        stmt = stmt.where(expr)

    return stmt


def _apply_select_sort(
    stmt: Select,
    request_sort: List[SortClause],
    fields: SelectFields,
) -> Select:
    for clause in request_sort:
        spec = fields.get(clause.field)
        if spec is None or not spec.get("sortable", False):
            raise HTTPException(
                status_code=400,
                detail=f"Sort field not allowed: {clause.field}",
            )
        col = spec["col"]
        stmt = stmt.order_by(col.desc() if clause.direction == "desc" else col.asc())
    return stmt


def _apply_default_select_sort(
    stmt: Select,
    request_sort: List[SortClause],
    default_sort: List[SortClause],
    fields: SelectFields,
) -> Select:
    if not request_sort:
        for clause in default_sort:
            spec = fields.get(clause.field)
            if spec is None:
                continue
            col = spec["col"]
            stmt = stmt.order_by(col.desc() if clause.direction == "desc" else col.asc())
    return stmt


# ---------------------------------------------------------------------------
# Sync helpers
# ---------------------------------------------------------------------------

def _count_sync(db: Session, data_stmt: Select) -> int:
    count_stmt = select(func.count()).select_from(data_stmt.subquery())
    return db.execute(count_stmt).scalar_one() or 0


def _fetch_sync(db: Session, stmt: Select) -> list:
    return list(db.execute(stmt).scalars().all())


# ---------------------------------------------------------------------------
# Async helpers
# ---------------------------------------------------------------------------

async def _count_async(db: AsyncSession, data_stmt: Select) -> int:
    count_stmt = select(func.count()).select_from(data_stmt.subquery())
    result = await db.execute(count_stmt)
    return result.scalar_one() or 0


async def _fetch_async(db: AsyncSession, stmt: Select) -> list:
    result = await db.execute(stmt)
    return list(result.scalars().all())


# ---------------------------------------------------------------------------
# Public API — page-based
# ---------------------------------------------------------------------------

def execute_page_select(
    request: PageRequest,
    stmt: Select,
    db: Session,
    *,
    fields: SelectFields,
    iam_attach_fn: IAMAttachFn,
    serializer: Callable,
    default_sort: Optional[List[SortClause]] = None,
    count_mode: CountMode = "exact",
) -> PagedResponse:
    """
    Synchronous page executor for raw Select statements.

    Args:
        request:        Parsed PageRequest (from page_query_params).
        stmt:           Base Select with joins / eager loads already applied.
                        Do NOT add WHERE, ORDER BY, LIMIT, or OFFSET — this
                        function applies them.
        db:             Synchronous SQLAlchemy Session.
        fields:         Per-field spec dict describing allowed filter ops and
                        sortable columns.  See module docstring for format.
        iam_attach_fn:  Callable(stmt) → stmt.  Adds tenant_id / is_deleted
                        filters.  Called once for the data query and once (if
                        count_mode="exact") for the COUNT query.
        serializer:     Applied to each ORM row, e.g. MyResponse.from_orm.
        default_sort:   Sort applied when the caller sends no sort clauses.
        count_mode:     "exact" runs COUNT(*); "none" returns total=-1.

    Returns:
        PagedResponse[T]
    """
    stmt = _apply_select_filters(stmt, request.filters, fields)
    stmt = _apply_select_sort(stmt, request.sort, fields)
    stmt = _apply_default_select_sort(stmt, request.sort, default_sort or [], fields)
    stmt = iam_attach_fn(stmt)

    if count_mode == "exact":
        total = _count_sync(db, stmt)
        total_pages = math.ceil(total / request.page_size) if total > 0 else 0
    else:
        total = -1
        total_pages = -1

    offset = (request.page - 1) * request.page_size
    data_stmt = stmt.offset(offset).limit(request.page_size)
    items = _fetch_sync(db, data_stmt)

    return PagedResponse(
        items=[serializer(item) for item in items],
        page=request.page,
        page_size=request.page_size,
        total=total,
        total_pages=total_pages,
    )


async def execute_page_select_async(
    request: PageRequest,
    stmt: Select,
    db: AsyncSession,
    *,
    fields: SelectFields,
    iam_attach_fn: IAMAttachFn,
    serializer: Callable,
    default_sort: Optional[List[SortClause]] = None,
    count_mode: CountMode = "exact",
) -> PagedResponse:
    """
    Async page executor for raw Select statements.

    Same contract as execute_page_select but accepts AsyncSession.
    Use this for services that have an async session but still need
    custom projections, UNION queries, or aggregations.
    """
    stmt = _apply_select_filters(stmt, request.filters, fields)
    stmt = _apply_select_sort(stmt, request.sort, fields)
    stmt = _apply_default_select_sort(stmt, request.sort, default_sort or [], fields)
    stmt = iam_attach_fn(stmt)

    if count_mode == "exact":
        total = await _count_async(db, stmt)
        total_pages = math.ceil(total / request.page_size) if total > 0 else 0
    else:
        total = -1
        total_pages = -1

    offset = (request.page - 1) * request.page_size
    data_stmt = stmt.offset(offset).limit(request.page_size)
    items = await _fetch_async(db, data_stmt)

    return PagedResponse(
        items=[serializer(item) for item in items],
        page=request.page,
        page_size=request.page_size,
        total=total,
        total_pages=total_pages,
    )


# ---------------------------------------------------------------------------
# Public API — cursor-based
# ---------------------------------------------------------------------------

def execute_cursor_select(
    request: CursorRequest,
    stmt: Select,
    db: Session,
    *,
    fields: SelectFields,
    iam_attach_fn: IAMAttachFn,
    serializer: Callable,
    cursor_field: str,
    default_sort: Optional[List[SortClause]] = None,
) -> CursorResponse:
    """
    Synchronous cursor executor for raw Select statements.

    Args:
        cursor_field:   The field name used for cursor comparison.  Must be
                        present in *fields* and sortable.  The cursor value
                        is a plain string representation of the column value
                        (e.g. a datetime ISO string or a UUID).
    """
    if cursor_field not in fields:
        raise ValueError(f"cursor_field '{cursor_field}' must be present in fields")

    stmt = _apply_select_filters(stmt, request.filters, fields)
    stmt = _apply_select_sort(stmt, request.sort, fields)
    stmt = _apply_default_select_sort(stmt, request.sort, default_sort or [], fields)

    if request.cursor:
        cursor_col = fields[cursor_field]["col"]
        # Determine direction from the first explicit or default sort on the cursor field
        effective_sort = request.sort or (default_sort or [])
        direction = "asc"
        for sc in effective_sort:
            if sc.field == cursor_field:
                direction = sc.direction
                break
        if direction == "desc":
            stmt = stmt.where(cursor_col < request.cursor)
        else:
            stmt = stmt.where(cursor_col > request.cursor)

    stmt = iam_attach_fn(stmt)

    # Fetch limit+1 to detect has_more
    data_stmt = stmt.limit(request.limit + 1)
    items = _fetch_sync(db, data_stmt)

    has_more = len(items) > request.limit
    if has_more:
        items = items[: request.limit]

    next_cursor = None
    if items and has_more:
        last = items[-1]
        col_attr = fields[cursor_field]["col"]
        # col_attr is a mapped attribute; get the value from the ORM object
        next_cursor = str(getattr(last, col_attr.key))

    return CursorResponse(
        items=[serializer(item) for item in items],
        next_cursor=next_cursor,
        has_more=has_more,
        limit=request.limit,
    )


async def execute_cursor_select_async(
    request: CursorRequest,
    stmt: Select,
    db: AsyncSession,
    *,
    fields: SelectFields,
    iam_attach_fn: IAMAttachFn,
    serializer: Callable,
    cursor_field: str,
    default_sort: Optional[List[SortClause]] = None,
) -> CursorResponse:
    """
    Async cursor executor for raw Select statements.

    Same contract as execute_cursor_select but accepts AsyncSession.
    """
    if cursor_field not in fields:
        raise ValueError(f"cursor_field '{cursor_field}' must be present in fields")

    stmt = _apply_select_filters(stmt, request.filters, fields)
    stmt = _apply_select_sort(stmt, request.sort, fields)
    stmt = _apply_default_select_sort(stmt, request.sort, default_sort or [], fields)

    if request.cursor:
        cursor_col = fields[cursor_field]["col"]
        effective_sort = request.sort or (default_sort or [])
        direction = "asc"
        for sc in effective_sort:
            if sc.field == cursor_field:
                direction = sc.direction
                break
        if direction == "desc":
            stmt = stmt.where(cursor_col < request.cursor)
        else:
            stmt = stmt.where(cursor_col > request.cursor)

    stmt = iam_attach_fn(stmt)

    data_stmt = stmt.limit(request.limit + 1)
    items = await _fetch_async(db, data_stmt)

    has_more = len(items) > request.limit
    if has_more:
        items = items[: request.limit]

    next_cursor = None
    if items and has_more:
        last = items[-1]
        col_attr = fields[cursor_field]["col"]
        next_cursor = str(getattr(last, col_attr.key))

    return CursorResponse(
        items=[serializer(item) for item in items],
        next_cursor=next_cursor,
        has_more=has_more,
        limit=request.limit,
    )
