"""
Bridges PageRequest/CursorRequest → QueryBuilder → PagedResponse/CursorResponse.
"""

import math
from typing import Callable, List, Optional, Set

from fastapi import HTTPException
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from pantheon_shared.iam.context import IAMContext
from pantheon_shared.orm.query_builder import QueryBuilder, _get_tenant_filter_value
from pantheon_shared.query.models import (
    CursorRequest,
    CursorResponse,
    PageRequest,
    PagedResponse,
    SortClause,
)
from pantheon_shared.query.operators import apply_operator


def _apply_filters(
    builder: QueryBuilder,
    request_filters: dict,
    allowed_filters: Set[str],
) -> None:
    unknown = set(request_filters.keys()) - allowed_filters
    if unknown:
        raise HTTPException(
            status_code=400,
            detail=f"Filter field(s) not allowed: {sorted(unknown)}",
        )

    for field, clause in request_filters.items():
        col = getattr(builder.primary_model, field, None)
        if col is None:
            raise HTTPException(
                status_code=400,
                detail=f"Unknown filter field: {field}",
            )
        expr = apply_operator(col, clause.operation, clause.value)
        builder.filters.append((expr, "and"))


def _apply_sort(
    builder: QueryBuilder,
    request_sort: List[SortClause],
    allowed_sort: Set[str],
) -> None:
    for clause in request_sort:
        if clause.field not in allowed_sort:
            raise HTTPException(
                status_code=400,
                detail=f"Sort field not allowed: {clause.field}",
            )
        builder.sort(clause.field, clause.direction)


def _apply_default_sort(
    builder: QueryBuilder,
    request_sort: List[SortClause],
    default_sort: List[SortClause],
) -> None:
    """Apply default_sort when the caller sent no sort clauses."""
    if not request_sort:
        for clause in default_sort:
            builder.sort(clause.field, clause.direction)


async def _count_query(
    builder: QueryBuilder,
    db: AsyncSession,
    iam: IAMContext,
    include_tenant_filter: bool,
) -> int:
    """
    Run COUNT(*) with the same model/joins/filters as *builder* but without
    LIMIT/OFFSET (which must not yet have been set on builder).
    """
    model = builder.primary_model
    data_stmt = builder.build()

    data_stmt = data_stmt.where(model.is_deleted.is_(False))

    if include_tenant_filter:
        data_stmt = data_stmt.where(
            model.tenant_id == _get_tenant_filter_value(model, "tenant_id", iam.tenant_id)
        )
        if iam.namespace_id:
            data_stmt = data_stmt.where(
                model.namespace_id == _get_tenant_filter_value(model, "namespace_id", iam.namespace_id)
            )

    for joined_model, _ in builder.joins:
        data_stmt = data_stmt.where(joined_model.is_deleted.is_(False))
        if include_tenant_filter:
            data_stmt = data_stmt.where(
                joined_model.tenant_id == _get_tenant_filter_value(joined_model, "tenant_id", iam.tenant_id)
            )
            if iam.namespace_id:
                data_stmt = data_stmt.where(
                    joined_model.namespace_id == _get_tenant_filter_value(
                        joined_model, "namespace_id", iam.namespace_id
                    )
                )

    count_stmt = select(func.count()).select_from(data_stmt.alias("count_subq"))
    result = await db.execute(count_stmt)
    return result.scalar_one() or 0


async def execute_page(
    request: PageRequest,
    builder: QueryBuilder,
    db: AsyncSession,
    iam: IAMContext,
    allowed_filters: Set[str],
    allowed_sort: Set[str],
    serializer: Callable,
    *,
    default_sort: Optional[List[SortClause]] = None,
    count_total: bool = True,
    include_tenant_filter: bool = True,
) -> PagedResponse:
    """
    Apply filters + sort from *request* to *builder*, run the query, return PagedResponse.

    Args:
        request:               Parsed PageRequest from page_query_params dependency.
        builder:               QueryBuilder with primary model (and joins) already set.
        db:                    Async DB session.
        iam:                   IAM context.
        allowed_filters:       Whitelist of filterable field names (400 on unknown).
        allowed_sort:          Whitelist of sortable field names (400 on unknown).
        serializer:            Applied to each ORM item, e.g. MyResponse.model_validate.
        default_sort:          Sort applied when the caller sends no sort clauses.
                               Prevents non-deterministic ordering. Recommended: at
                               minimum [SortClause(field="id", direction="asc")].
        count_total:           If False, skip COUNT query; returns total=-1/total_pages=-1.
        include_tenant_filter: Set to False for SA-only cross-tenant endpoints.

    Usage:
        ALLOWED_FILTERS = {"name", "state"}
        ALLOWED_SORT    = {"name", "created_at"}
        DEFAULT_SORT    = [SortClause(field="created_at", direction="desc")]

        @router.get("/workspaces", response_model=PagedResponse[WorkspaceResponse])
        async def list_workspaces(
            request: PageRequest = Depends(page_query_params),
            db: AsyncSession = Depends(get_db),
            iam: IAMContext = Depends(IAMEndpoint.get_iam_context),
        ):
            builder = Workspace.query_builder()
            return await execute_page(
                request, builder, db, iam,
                ALLOWED_FILTERS, ALLOWED_SORT,
                WorkspaceResponse.model_validate,
                default_sort=DEFAULT_SORT,
            )
    """
    _apply_filters(builder, request.filters, allowed_filters)
    _apply_sort(builder, request.sort, allowed_sort)
    _apply_default_sort(builder, request.sort, default_sort or [])

    if count_total:
        total = await _count_query(builder, db, iam, include_tenant_filter)
        total_pages = math.ceil(total / request.page_size) if total > 0 else 0
    else:
        total = -1
        total_pages = -1

    offset = (request.page - 1) * request.page_size
    builder.offset_paginate(offset=offset, limit=request.page_size)

    # Pass include_tenant_filter down to builder.execute via a monkey-patch-free
    # approach: if cross-tenant, we call build() + execute manually so IAM is skipped.
    if include_tenant_filter:
        result = await builder.execute(db, iam)
        items = result.items
    else:
        stmt = builder.build()
        stmt = stmt.where(builder.primary_model.is_deleted.is_(False))
        db_result = await db.execute(stmt)
        items = list(db_result.scalars().all())

    return PagedResponse(
        items=[serializer(item) for item in items],
        page=request.page,
        page_size=request.page_size,
        total=total,
        total_pages=total_pages,
    )


async def execute_cursor(
    request: CursorRequest,
    builder: QueryBuilder,
    db: AsyncSession,
    iam: IAMContext,
    allowed_filters: Set[str],
    allowed_sort: Set[str],
    serializer: Callable,
    *,
    default_sort: Optional[List[SortClause]] = None,
    include_tenant_filter: bool = True,
) -> CursorResponse:
    """
    Apply filters + sort from *request* to *builder*, run the query, return CursorResponse.

    Args:
        request:               Parsed CursorRequest from cursor_query_params dependency.
        builder:               QueryBuilder with primary model (and joins) already set.
        db:                    Async DB session.
        iam:                   IAM context.
        allowed_filters:       Whitelist of filterable field names (400 on unknown).
        allowed_sort:          Whitelist of sortable field names (400 on unknown).
        serializer:            Applied to each ORM item, e.g. MyResponse.model_validate.
        default_sort:          Sort applied when the caller sends no sort clauses.
                               Must be stable (e.g. created_at desc + id asc) to ensure
                               correct cursor behaviour.
        include_tenant_filter: Set to False for SA-only cross-tenant endpoints.

    Usage:
        ALLOWED_FILTERS = {"tenant_id", "action_kind"}
        ALLOWED_SORT    = {"created_at"}
        DEFAULT_SORT    = [
            SortClause(field="created_at", direction="desc"),
            SortClause(field="id", direction="asc"),
        ]

        @router.get("/audit/records", response_model=CursorResponse[AuditRecordResponse])
        async def list_audit_records(
            request: CursorRequest = Depends(cursor_query_params),
            db: AsyncSession = Depends(get_db),
            iam: IAMContext = Depends(IAMEndpoint.get_iam_context),
        ):
            builder = AuditRecord.query_builder()
            return await execute_cursor(
                request, builder, db, iam,
                ALLOWED_FILTERS, ALLOWED_SORT,
                AuditRecordResponse.model_validate,
                default_sort=DEFAULT_SORT,
            )
    """
    _apply_filters(builder, request.filters, allowed_filters)
    _apply_sort(builder, request.sort, allowed_sort)
    _apply_default_sort(builder, request.sort, default_sort or [])

    builder.paginate(cursor=request.cursor, limit=request.limit)

    if include_tenant_filter:
        result = await builder.execute(db, iam)
    else:
        stmt = builder.build()
        stmt = stmt.where(builder.primary_model.is_deleted.is_(False))
        db_result = await db.execute(stmt)
        raw_items = list(db_result.scalars().all())
        # Replicate has_more / next_cursor logic from QueryBuilder
        has_more = len(raw_items) > request.limit
        if has_more:
            raw_items = raw_items[: request.limit]
        next_cursor = None
        if raw_items and has_more and builder._sort_column:
            next_cursor = str(getattr(raw_items[-1], builder._sort_column))
        from pantheon_shared.orm.query_builder import QueryResult
        result = QueryResult(
            items=raw_items,
            next_cursor=next_cursor,
            has_more=has_more,
            limit=request.limit,
        )

    return CursorResponse(
        items=[serializer(item) for item in result.items],
        next_cursor=result.next_cursor,
        has_more=result.has_more,
        limit=result.limit,
    )
