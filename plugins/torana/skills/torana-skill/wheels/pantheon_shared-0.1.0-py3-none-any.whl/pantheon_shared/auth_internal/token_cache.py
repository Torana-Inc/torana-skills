"""
In-memory token caching for performance optimization.

This module provides a simple in-memory cache for JWT tokens to reduce
the overhead of frequent token creation for service-to-service communication.
"""

import time
from typing import Optional, Dict, Any
from datetime import datetime, timedelta
from threading import RLock

import structlog

logger = structlog.get_logger(__name__)

# Global token cache instance for singleton pattern
_global_token_cache: Optional['TokenCache'] = None
_cache_lock = RLock()


def get_global_token_cache(default_ttl_seconds: int = 3300) -> 'TokenCache':
    """
    Get the global singleton TokenCache instance.

    Args:
        default_ttl_seconds: Default TTL for tokens in seconds (default: 3300 = 55 minutes)

    Returns:
        The global TokenCache instance
    """
    global _global_token_cache

    with _cache_lock:
        if _global_token_cache is None:
            _global_token_cache = TokenCache(default_ttl_seconds=default_ttl_seconds)
            # logger.info("Created global token cache instance", default_ttl_seconds=default_ttl_seconds)

    return _global_token_cache


class TokenCache:
    """In-memory cache for JWT tokens with TTL support"""

    def __init__(self, default_ttl_seconds: int = 2700):
        self.default_ttl = timedelta(seconds=default_ttl_seconds)
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._lock = RLock()

        # Clean up any expired tokens on initialization
        self.cleanup_expired()

    def set(self, key: str, token: str, expires_in_seconds: Optional[int] = None) -> None:
        """
        Cache a token with TTL.

        Args:
            key: Cache key (e.g., "service:service-name:tenant-id")
            token: JWT token string
            expires_in_seconds: Custom TTL in seconds (uses default if None)
        """
        # Fix: Use "is not None" instead of truthy check, so 0 seconds is valid (no caching)
        ttl = timedelta(seconds=expires_in_seconds) if expires_in_seconds is not None else self.default_ttl
        expires_at = datetime.now() + ttl
        created_at = datetime.now()
        ttl_seconds = ttl.total_seconds()

        with self._lock:
            self._cache[key] = {
                "token": token,
                "expires_at": expires_at,
                "created_at": created_at
            }

  
    def get(self, key: str) -> Optional[str]:
        """
        Get cached token if it's still valid.

        Args:
            key: Cache key

        Returns:
            Token string if valid, None otherwise
        """
        with self._lock:
            entry = self._cache.get(key)
            now = datetime.now()

            #  DEBUG: Cache lookup details
            #logger.debug(
            #    "  - Cache lookup",
            #    key=key,
            #    cache_entry_found=entry is not None,
            #    current_time=now.isoformat(),
            #    total_cache_entries=len(self._cache)
            #)

            if not entry:
                #logger.debug(
                #    "  - No cache entry found",
                #    key=key,
                #    available_keys=list(self._cache.keys())
                #)
                return None

            # Check if token has expired or is close to expiring (within buffer seconds)
            expires_at = entry["expires_at"]
            time_to_expiry = (expires_at - now).total_seconds()
            is_expired = now > expires_at
            # Consider token stale if less than 10% of TTL remaining OR less than 30 seconds
            ttl_seconds = (expires_at - entry["created_at"]).total_seconds()
            stale_buffer_seconds = min(ttl_seconds * 0.1, 30)
            is_close_to_expiry = time_to_expiry < stale_buffer_seconds

            #  DEBUG: Token expiry check details
            #logger.debug(
            #    "  - Token expiry check",
            #    key=key,
            #    created_at=entry["created_at"].isoformat(),
            #    expires_at=expires_at.isoformat(),
            #    current_time=now.isoformat(),
            #    is_expired=is_expired,
            #    is_close_to_expiry=is_close_to_expiry,
            #    time_to_expiry_seconds=time_to_expiry,
            #    token_preview=f"{entry['token'][:20]}..." if len(entry['token']) > 20 else entry['token']
            #)

            if is_expired or is_close_to_expiry:
                # Remove expired or close-to-expiry entry
                del self._cache[key]
                # if is_expired:
                #     logger.info(
                #         "  - EXPIRED token removed from cache",
                #         key=key,
                #         expired_at=expires_at.isoformat(),
                #         current_time=now.isoformat(),
                #         seconds_expired=(now - expires_at).total_seconds()
                #     )
                # else:
                #     logger.info(
                #         "  - CLOSE TO EXPIRY token removed from cache",
                #         key=key,
                #         expires_at=expires_at.isoformat(),
                #         current_time=now.isoformat(),
                #         time_to_expiry_seconds=time_to_expiry
                #     )
                return None

            # logger.info(
            #     "  - VALID token retrieved from cache",
            #     key=key,
            #     time_to_expiry_seconds=time_to_expiry,
            #     token_preview=f"{entry['token'][:20]}..." if len(entry['token']) > 20 else entry['token']
            # )
            return entry["token"]

    def invalidate(self, key: str) -> None:
        """
        Remove a specific token from cache.

        Args:
            key: Cache key to invalidate
        """
        with self._lock:
            if key in self._cache:
                del self._cache[key]
                logger.debug("Token invalidated", key=key)

    def clear(self) -> None:
        """Clear all cached tokens"""
        with self._lock:
            count = len(self._cache)
            self._cache.clear()
            logger.debug("All tokens cleared from cache", count=count)

    def cleanup_expired(self) -> int:
        """
        Remove all expired tokens from cache.

        Returns:
            Number of expired tokens removed
        """
        now = datetime.now()
        expired_keys = []

        with self._lock:
            for key, entry in self._cache.items():
                if now > entry["expires_at"]:
                    expired_keys.append(key)

            for key in expired_keys:
                del self._cache[key]

        if expired_keys:
            logger.debug("Expired tokens cleaned up", count=len(expired_keys))

        return len(expired_keys)

    def get_stats(self) -> Dict[str, Any]:
        """
        Get cache statistics.

        Returns:
            Dictionary with cache stats
        """
        with self._lock:
            total_entries = len(self._cache)
            now = datetime.now()
            expired_count = sum(1 for entry in self._cache.values() if now > entry["expires_at"])
            valid_count = total_entries - expired_count

            return {
                "total_entries": total_entries,
                "valid_entries": valid_count,
                "expired_entries": expired_count,
                "cache_keys": list(self._cache.keys())
            }

    def is_valid(self, key: str) -> bool:
        """
        Check if a cached token is valid (exists and not expired).

        Args:
            key: Cache key

        Returns:
            True if token is valid, False otherwise
        """
        token = self.get(key)
        return token is not None

    def get_token_info(self, key: str) -> Optional[Dict[str, Any]]:
        """
        Get information about a cached token without retrieving the token itself.

        Args:
            key: Cache key

        Returns:
            Dictionary with token info or None if not found
        """
        with self._lock:
            entry = self._cache.get(key)
            if not entry:
                return None

            now = datetime.now()
            is_expired = now > entry["expires_at"]
            ttl_seconds = (entry["expires_at"] - now).total_seconds() if not is_expired else 0

            return {
                "created_at": entry["created_at"].isoformat(),
                "expires_at": entry["expires_at"].isoformat(),
                "is_expired": is_expired,
                "ttl_seconds": ttl_seconds
            }
