"""
Internal JWT token management for inter-service authentication.

This module provides centralized JWT token creation, validation, and refresh
functionality specifically for Pantheon service-to-service communication.
"""

import time
import secrets
from typing import Optional, Dict, Any
from datetime import datetime, timedelta

import structlog

logger = structlog.get_logger(__name__)


class InternalJWTManager:
    """Centralized JWT token management for inter-service authentication"""

    def __init__(self, secret_key: str, issuer: str = "pantheon"):
        self.secret_key = secret_key
        self.issuer = issuer

    @classmethod
    def from_settings(cls) -> "InternalJWTManager":
        """Create JWT manager from environment settings"""
        import os

        secret_key = os.getenv("JWT_SECRET_KEY")
        if not secret_key:
            # Generate a default secret key for development
            secret_key = secrets.token_urlsafe(64)
            logger.warning(
                "JWT_SECRET_KEY not found in environment, using generated key",
                secret_key_prefix=secret_key[:8] + "..."
            )

        issuer = os.getenv("JWT_ISSUER", "pantheon")
        return cls(secret_key=secret_key, issuer=issuer)

    def create_service_token(
        self,
        service_name: str,
        tenant_id: str,
        namespace_id: Optional[str] = None,
        expires_in_minutes: int = 60
    ) -> str:
        """Create JWT token for service-to-service communication"""

        now = datetime.now()
        payload = {
            "sub": f"service:{service_name}",
            "service_name": service_name,
            "tenant_id": tenant_id,
            "namespace_id": namespace_id,
            "token_type": "service",
            "exp": int((now + timedelta(minutes=expires_in_minutes)).timestamp()),
            "iat": int(now.timestamp()),
            "jti": secrets.token_urlsafe(32),
            "iss": self.issuer
        }

        try:
            import jwt
            return jwt.encode(payload, self.secret_key, algorithm="HS256")
        except ImportError as e:
            logger.error("PyJWT library not available", error=str(e))
            raise ImportError("PyJWT library is required for JWT functionality")

    
    def validate_token(self, token: str) -> Dict[str, Any]:
        """Validate JWT token and extract claims"""

        try:
            import jwt
            payload = jwt.decode(
                token,
                self.secret_key,
                algorithms=["HS256"],
                issuer=self.issuer if self.issuer != "pantheon" else None
            )
            return payload
        except jwt.ExpiredSignatureError:
            logger.debug("JWT token has expired")
            raise ValueError("Token has expired")
        except jwt.InvalidTokenError as e:
            logger.debug("Invalid JWT token", error=str(e))
            raise ValueError(f"Invalid token: {str(e)}")
        except Exception as e:
            logger.error("Unexpected error during JWT validation", error=str(e))
            raise

    def is_expiring_soon(self, token: str, minutes_threshold: int = 5) -> bool:
        """Check if token is expiring within the threshold"""
        try:
            payload = self.validate_token(token)
            exp_timestamp = payload.get("exp")
            if not exp_timestamp:
                return True

            exp_datetime = datetime.fromtimestamp(exp_timestamp)
            now = datetime.now()

            return exp_datetime <= (now + timedelta(minutes=minutes_threshold))
        except:
            # If we can't validate the token, consider it expiring
            return True

    
    def extract_service_context(self, token: str) -> Dict[str, Any]:
        """Extract service context from validated token"""
        try:
            payload = self.validate_token(token)
            return {
                "service_name": payload.get("service_name"),
                "tenant_id": payload.get("tenant_id"),
                "namespace_id": payload.get("namespace_id"),
                "token_type": payload.get("token_type"),
                "permissions": payload.get("permissions", [])
            }
        except Exception as e:
            logger.error("Failed to extract service context", error=str(e))
            return {}