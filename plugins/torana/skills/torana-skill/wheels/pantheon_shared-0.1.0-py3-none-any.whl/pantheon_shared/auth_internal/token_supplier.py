"""
Reusable token supplier for service-to-service JWTs.

Refreshes tokens when they cross a lifetime threshold and caches decoded claims
to avoid per-request JWT decoding.
"""

from __future__ import annotations

import base64
import json
import os
import time
from threading import RLock
from typing import Any, Dict, Optional

import structlog

logger = structlog.get_logger(__name__)


class ServiceTokenSupplier:
    """Supply service tokens, refreshing when near expiry."""

    def __init__(self, refresh_threshold: Optional[float] = None) -> None:
        self.refresh_threshold = self._normalize_threshold(
            refresh_threshold,
            os.getenv("PANTHEON_SERVICE_TOKEN_REFRESH_THRESHOLD", "0.8"),
        )
        self._lock = RLock()
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._replacements: Dict[str, Dict[str, Any]] = {}
        self._replacement_ttl_seconds = int(
            os.getenv("PANTHEON_SERVICE_TOKEN_REPLACEMENT_TTL", "300")
        )

    @staticmethod
    def _normalize_threshold(
        explicit_value: Optional[float],
        env_value: str,
    ) -> float:
        value = explicit_value
        if value is None:
            try:
                value = float(env_value)
            except ValueError:
                value = 0.8
        if value <= 0 or value >= 1:
            return 0.8
        return value

    @staticmethod
    def _decode_payload(token: str) -> Optional[Dict[str, Any]]:
        try:
            parts = token.split(".")
            if len(parts) != 3:
                return None
            payload_b64 = parts[1]
            payload_b64 += "=" * (-len(payload_b64) % 4)
            decoded = base64.urlsafe_b64decode(payload_b64.encode("utf-8"))
            return json.loads(decoded)
        except Exception:
            return None

    def _cleanup_replacements(self, now: float) -> None:
        expired = [
            key for key, entry in self._replacements.items()
            if entry["expires_at"] <= now
        ]
        for key in expired:
            del self._replacements[key]

    def _store_replacement(self, old_token: str, new_token: str) -> None:
        now = time.time()
        payload = self._decode_payload(new_token) or {}
        exp = payload.get("exp")
        expires_at = now + self._replacement_ttl_seconds
        if isinstance(exp, (int, float)):
            expires_at = min(expires_at, exp)
        self._replacements[old_token] = {
            "token": new_token,
            "expires_at": expires_at,
        }

    def _get_refresh_at(self, payload: Dict[str, Any]) -> float:
        exp = payload.get("exp")
        iat = payload.get("iat")
        if isinstance(exp, (int, float)) and isinstance(iat, (int, float)):
            if exp > iat:
                lifetime = exp - iat
                return iat + lifetime * self.refresh_threshold
            return time.time()
        if isinstance(exp, (int, float)):
            return exp - 30
        return time.time()

    @staticmethod
    def _extract_service_name(payload: Dict[str, Any]) -> Optional[str]:
        service_name = payload.get("service_name")
        if service_name:
            return service_name
        subject = payload.get("sub")
        if isinstance(subject, str) and subject.startswith("service:"):
            return subject.split("service:", 1)[1]
        return None

    @staticmethod
    def _extract_impersonation_context(
        payload: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        token_type = payload.get("token_type")
        original_tenant_id = payload.get("original_tenant_id")
        impersonated_by = payload.get("impersonated_by")
        if token_type == "impersonation" or original_tenant_id or impersonated_by:
            return {
                "token_type": token_type,
                "original_tenant_id": original_tenant_id,
                "impersonated_by": impersonated_by,
            }
        return None

    async def _refresh_token(self, payload: Dict[str, Any]) -> Optional[str]:
        service_name = self._extract_service_name(payload)
        tenant_id = payload.get("tenant_id")
        tenant_name = payload.get("tenant_name")
        namespace_id = payload.get("namespace_id")
        namespace_name = payload.get("namespace_name")
        if not service_name:
            logger.warning("token_refresh_missing_service_name")
            return None
        if not tenant_id and not tenant_name:
            logger.warning("token_refresh_missing_tenant", service=service_name)
            return None

        impersonation_context = self._extract_impersonation_context(payload)

        try:
            from pantheon_shared.http import PantheonClient

            client = PantheonClient(
                service_name=service_name,
                tenant_id=tenant_id,
                tenant_name=tenant_name,
                namespace_id=namespace_id,
                namespace_name=namespace_name,
                impersonation_context=impersonation_context,
            )
            return await client._get_token()
        except Exception as exc:
            logger.warning(
                "token_refresh_failed",
                service=service_name,
                error=str(exc),
            )
            return None

    async def get_token(self, current_token: Optional[str]) -> Optional[str]:
        if not current_token:
            return None

        now = time.time()
        with self._lock:
            self._cleanup_replacements(now)
            replacement = self._replacements.get(current_token)
            if replacement and replacement["expires_at"] > now:
                return replacement["token"]
            entry = self._cache.get(current_token)
            if entry and now < entry["refresh_at"]:
                return current_token

        payload = None
        with self._lock:
            entry = self._cache.get(current_token)
            if entry:
                payload = entry["payload"]

        if payload is None:
            payload = self._decode_payload(current_token)
            if payload is None:
                return current_token

        refresh_at = self._get_refresh_at(payload)
        with self._lock:
            self._cache[current_token] = {
                "payload": payload,
                "refresh_at": refresh_at,
            }

        if now < refresh_at:
            return current_token

        new_token = await self._refresh_token(payload)
        if not new_token:
            return current_token

        new_payload = self._decode_payload(new_token) or {}
        new_refresh_at = self._get_refresh_at(new_payload)
        with self._lock:
            self._cache[new_token] = {
                "payload": new_payload,
                "refresh_at": new_refresh_at,
            }
            self._store_replacement(current_token, new_token)

        return new_token
