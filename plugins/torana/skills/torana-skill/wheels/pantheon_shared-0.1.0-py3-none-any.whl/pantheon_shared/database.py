"""
Database utilities for Pantheon microservices.

Provides common database validation and connection functionality.

SQLAlchemy's asyncio extension needs greenlet, which SQLAlchemy 2.1 no longer installs. It is imported where an engine is built (a service),
never at module level, so this module and the package root import on a customer install (the CLI) that has no greenlet.
"""
from __future__ import annotations

import os
import asyncio
import functools
import threading
import time
import weakref
from dataclasses import dataclass
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.pool import NullPool
from typing import TYPE_CHECKING, Any, AsyncGenerator, Dict, List, Optional

if TYPE_CHECKING:                       # annotations only (this module has `from __future__ import annotations`)
    from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession


def validate_database_url(database_url: str) -> str:
    """
    Validate that DATABASE_URL is present and accessible.

    Args:
        database_url: The database URL to validate

    Returns:
        The validated database URL

    Raises:
        ValueError: If DATABASE_URL is missing, invalid format, or connection fails
    """
    if not database_url:
        raise ValueError("DATABASE_URL environment variable is required")

    if not database_url.startswith(('postgresql://', 'postgresql+asyncpg://')):
        raise ValueError(
            "DATABASE_URL must be a PostgreSQL connection string. "
            "Expected format: postgresql://user:password@host:port/database "
            "or postgresql+asyncpg://user:password@host:port/database"
        )

    # Try to connect to validate the database is accessible
    try:
        # Use sync connection for validation
        sync_url = database_url.replace('postgresql+asyncpg://', 'postgresql://')
        # Set application_name for connection tracking
        app_name = os.getenv("APPLICATION_NAME", "pantheon-service")
        engine = create_engine(
            sync_url,
            connect_args={
                "application_name": f"{app_name}-validation"
            }
        )
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        engine.dispose()
    except SQLAlchemyError as e:
        raise ValueError(f"Cannot connect to database: {e}")
    except Exception as e:
        raise ValueError(f"Database connection failed: {e}")

    return database_url


class DatabaseValidatorMixin:
    """
    Mixin class that provides database validation functionality.

    Use this class with Pydantic BaseSettings to add DATABASE_URL validation.
    """

    @classmethod
    def __pydantic_init_subclass__(cls, **kwargs: Any) -> None:
        """Register database validator when class is created."""
        super().__pydantic_init_subclass__(**kwargs)

        # Add the validator if it doesn't exist
        if hasattr(cls, 'database_url') and not hasattr(cls, 'validate_database_url'):
            from pydantic import validator
            setattr(cls, 'validate_database_url', validator('database_url')(validate_database_url))


def validate_database_url_field(cls, v: str) -> str:
    """
    Pydantic validator function for DATABASE_URL field.

    Usage:
        class Settings(BaseSettings):
            database_url: str = Field(alias="DATABASE_URL")

            @validator('database_url')
            def validate_database_url(cls, v):
                from pantheon_shared.database import validate_database_url_field
                return validate_database_url_field(cls, v)

    Args:
        cls: The settings class
        v: The database URL value to validate

    Returns:
        The validated database URL
    """
    return validate_database_url(v)


@dataclass
class DatabaseHealth:
    """Result of a pool-independent database health probe (issue #10).

    ``status`` is deliberately three-valued:

    * ``healthy``   - a connection was obtained and ``SELECT 1`` succeeded.
    * ``degraded``  - the pool is saturated. The service is BUSY. A liveness
                      probe must NOT fail on this, or load causes restarts.
    * ``unhealthy`` - the database could not be reached at all.
    """

    status: str
    detail: Optional[str] = None
    pool_size: Optional[int] = None
    checked_out: Optional[int] = None
    overflow: Optional[int] = None
    max_overflow: Optional[int] = None

    @property
    def is_alive(self) -> bool:
        """True unless the database is genuinely unreachable.

        This is the value a LIVENESS probe should use: a saturated pool means
        busy, and restarting a busy service makes the outage worse.
        """
        return self.status != "unhealthy"

    @property
    def is_ready(self) -> bool:
        """True only when the service can serve a request right now.

        This is the value a READINESS probe should use - shedding traffic from
        a saturated instance is correct; killing it is not.
        """
        return self.status == "healthy"

    def to_dict(self) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"status": self.status}
        if self.detail:
            payload["detail"] = self.detail
        for key in ("pool_size", "checked_out", "overflow", "max_overflow"):
            value = getattr(self, key)
            if value is not None:
                payload[key] = value
        return payload


def pool_counters(pool: Any) -> Dict[str, Any]:
    """The counters of one SQLAlchemy pool: `pool_size`, `checked_out`, `overflow`, `max_overflow`.

    ⚠️ `overflow` is SQLAlchemy's running counter (connections created minus `pool_size`, so
    it starts negative), NOT the configured ceiling. The ceiling is `max_overflow`, and the
    hard limit on concurrent checkouts is `pool_size + max_overflow`. A saturation ratio over
    `pool_size` alone reads 1.0 while a pool still has overflow headroom: measured on Classie
    2026-10-08, integration (2 + 1) paged `DB pool ≥ 0.9` four times a day at 2 of 3.

    `max_overflow` is read from `QueuePool._max_overflow` (SQLAlchemy exposes no public
    accessor) and is omitted when it is absent or negative (unlimited), so a reader falls
    back to `pool_size` rather than dividing by a meaningless number.

    ⛔ Every key returned here must be a `DatabaseHealth` field: `health_check()` passes this
    dict in as `DatabaseHealth(**stats)`, so an extra key breaks every health probe.
    """
    stats: Dict[str, Any] = {
        "pool_size": pool.size(),
        "checked_out": pool.checkedout(),
        "overflow": pool.overflow(),
    }
    max_overflow = getattr(pool, "_max_overflow", None)
    if isinstance(max_overflow, int) and max_overflow >= 0:
        stats["max_overflow"] = max_overflow
    return stats


#: Process-wide, weakly-referenced registry of every `AsyncEngineManager` this worker has
#: created (G-PG-2 / W2). No service held a global registry before this; each service holds
#: its own singleton manager and nothing enumerated them. A `WeakSet` so the registry itself
#: never keeps a manager (and its engine/connections) alive past the service's own reference
#: dropping it. `pool_stats()` only introspects the in-process SQLAlchemy pool object, so
#: iterating this registry opens no DB session and makes no network call (root CLAUDE.md
#: rule B).
_ENGINE_MANAGER_REGISTRY: "weakref.WeakSet[AsyncEngineManager]" = weakref.WeakSet()


def all_engine_managers() -> List["AsyncEngineManager"]:
    """Every `AsyncEngineManager` created in THIS process, still alive.

    Used by the metrics snapshot emitter (`pantheon_shared.metrics_snapshot`) to poll
    `pool_stats()` for every engine the process holds, without the service needing to pass
    its manager(s) in explicitly.
    """
    return list(_ENGINE_MANAGER_REGISTRY)


#: Process-wide, weakly-referenced registry of raw SQLAlchemy engines a service created
#: directly (`create_async_engine()`/`create_engine()`), bypassing `AsyncEngineManager`
#: entirely — e.g. a service with its own pool-sizing logic that needs full control over
#: engine construction. Keyed by the name the service wants on its `metrics.snapshot.pool`
#: line. A `WeakSet` of (name, engine) pairs would defeat weak-referencing on the tuple
#: itself, so this is a plain dict keyed by name with a weakref VALUE instead — the entry
#: silently drops out once the service's own reference to the engine is gone.
_RAW_ENGINE_REGISTRY: "weakref.WeakValueDictionary[str, Any]" = weakref.WeakValueDictionary()


def register_engine_for_pool_stats(name: str, engine: Any) -> None:
    """Register a raw SQLAlchemy engine (sync or async) for the metrics snapshot emitter.

    Use this ONLY when a service builds its engine directly with
    `create_async_engine()`/`create_engine()` instead of going through
    `AsyncEngineManager` (which registers itself automatically). Call it once, right after
    the engine is created — e.g. at the end of a lazy `_init()` function. Safe to call more
    than once with the same name; the latest engine wins.

    This does not open a session or make a network call — it only stores a weak reference
    so `all_raw_engines()` can later call `.pool.size()` etc on it (root CLAUDE.md rule B).
    """
    try:
        _RAW_ENGINE_REGISTRY[name] = engine
    except Exception:  # pragma: no cover - registration is advisory, never fatal
        pass


def all_raw_engines() -> Dict[str, Any]:
    """Every raw engine registered via `register_engine_for_pool_stats()`, still alive."""
    return dict(_RAW_ENGINE_REGISTRY)


class AsyncEngineManager:
    """
    Manages a singleton async database engine with proper connection pooling.

    This class ensures that only ONE engine is created per service, preventing
    connection leaks that occur when creating new engines repeatedly.

    Usage:
        manager = AsyncEngineManager(
            database_url="postgresql+asyncpg://...",
            pool_size=5,
            max_overflow=10,
            default_app_name="my-service"
        )

        # In FastAPI dependency
        async def get_db() -> AsyncGenerator[AsyncSession, None]:
            async with manager.get_session() as session:
                yield session
    """

    def __init__(
        self,
        database_url: str,
        pool_size: int = 5,
        max_overflow: int = 10,
        default_app_name: Optional[str] = None,
        pool_timeout: Optional[float] = None
    ):
        """
        Initialize the engine manager.

        Args:
            database_url: PostgreSQL connection URL (with asyncpg driver)
            pool_size: Connection pool size
            max_overflow: Maximum overflow connections
            default_app_name: Default application name for PostgreSQL tracking
                             (uses APPLICATION_NAME env var if not provided)
            pool_timeout: Seconds to wait for a free connection before failing.
                          PLATFORM_PERF RC-2: a short timeout turns a 30s checkout
                          stall (SQLAlchemy's default) into a fast failure so a
                          contended caller retries/circuit-breaks instead of pinning
                          a request thread. Defaults to the DATABASE_POOL_TIMEOUT env
                          (fleet-wide), falling back to 10s.
        """
        self.database_url = database_url
        self.pool_size = pool_size
        self.max_overflow = max_overflow
        self.default_app_name = default_app_name
        if pool_timeout is None:
            pool_timeout = float(os.getenv("DATABASE_POOL_TIMEOUT", "10"))
        self.pool_timeout = pool_timeout
        self._engine: Optional[AsyncEngine] = None
        self._session_factory = None
        _ENGINE_MANAGER_REGISTRY.add(self)

    def get_engine(self) -> AsyncEngine:
        """
        Get or create the singleton database engine.

        Returns:
            AsyncEngine: The database engine (created once per process)
        """
        if self._engine is None:
            from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
            # Get application name from environment or use default
            application_name = os.getenv("APPLICATION_NAME", self.default_app_name or "pantheon-service")

            self._engine = create_async_engine(
                self.database_url,
                pool_size=self.pool_size,
                max_overflow=self.max_overflow,
                pool_timeout=self.pool_timeout,
                pool_pre_ping=True,
                # Kept below Postgres's idle_session_timeout (600 s). The pool recycles a connection only when it is
                # checked out, so this does NOT stop the server reaping IDLE pooled connections; that reaping is by
                # design (see the comment above idle_session_timeout in pantheon-deploy/docker-compose.dev.yml). What
                # 540 s does is retire a busy connection before the server would, which cut app-side stale-connection
                # errors (~1.7 -> ~0.5 per 10 min; GRAFANA_ALERTS.md DB-8, measured 2026-10-03).
                pool_recycle=540,
                echo=False,
                future=True,
                connect_args={
                    "server_settings": {
                        "application_name": application_name
                    }
                }
            )

            self._session_factory = async_sessionmaker(
                bind=self._engine,
                class_=AsyncSession,
                expire_on_commit=False,
                autoflush=False
            )

        return self._engine

    async def get_session(self) -> AsyncGenerator[AsyncSession, None]:
        """
        Get a database session from the engine's connection pool.

        Yields:
            AsyncSession: Database session

        Note:
            The session is automatically committed on success and rolled back on error.
            The connection is always returned to the pool via context manager cleanup.
        """
        engine = self.get_engine()

        if self._session_factory is None:
            from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker
            self._session_factory = async_sessionmaker(
                bind=engine,
                class_=AsyncSession,
                expire_on_commit=False,
                autoflush=False
            )

        async with self._session_factory() as session:
            try:
                yield session
                # Commit on successful completion
                await session.commit()
            except Exception:
                # Rollback on error
                await session.rollback()
                raise
            finally:
                # Ensure session is closed (context manager does this, but be explicit)
                # This ensures the connection is returned to the pool
                pass  # The async with statement handles cleanup

    async def health_check(
        self,
        timeout: Optional[float] = None,
    ) -> "DatabaseHealth":
        """Check database reachability WITHOUT waiting on the request pool.

        Issue #10: ``/health`` used the same pooled dependency as request
        handling, so a service that was merely BUSY - every connection checked
        out, but perfectly healthy - could not obtain a connection for its own
        liveness probe within the probe's deadline. The orchestrator then killed
        the container mid-request, which freed the pool, which made the restart
        look unexplained. Load caused restarts, and the restarts looked random.

        A health probe answers "is this process able to serve?", and waiting on
        a saturated pool answers a different question ("is the pool free?").
        This method therefore:

        * uses its own short timeout (``DATABASE_HEALTH_POOL_TIMEOUT``, default
          0.1s) instead of the request pool timeout (default 10s), and
        * reports pool SATURATION as ``degraded``, not ``unhealthy`` - a full
          pool means busy, and killing a busy service is the wrong response.

        Only an actual connection error is ``unhealthy``.

        Args:
            timeout: Seconds to wait for a connection. Defaults to
                ``DATABASE_HEALTH_POOL_TIMEOUT`` (0.1s).

        Returns:
            DatabaseHealth: status plus the pool counters, so a probe endpoint
            can surface WHY it is degraded rather than just failing.
        """
        if timeout is None:
            timeout = float(os.getenv("DATABASE_HEALTH_POOL_TIMEOUT", "0.1"))

        engine = self.get_engine()
        stats = self.pool_stats()

        try:
            async def _ping() -> None:
                async with engine.connect() as conn:
                    await conn.execute(text("SELECT 1"))

            await asyncio.wait_for(_ping(), timeout=timeout)
            return DatabaseHealth(status="healthy", **stats)
        except (asyncio.TimeoutError, TimeoutError):
            # Busy, not broken. Do NOT report unhealthy - that gets the
            # container killed precisely when it is under load (issue #10).
            return DatabaseHealth(
                status="degraded",
                detail=(
                    f"no pooled connection available within {timeout}s "
                    "(pool saturated; the service is busy, not unreachable)"
                ),
                **stats,
            )
        except Exception as exc:
            return DatabaseHealth(
                status="unhealthy",
                detail=f"{type(exc).__name__}: {exc}",
                **stats,
            )

    def pool_stats(self) -> Dict[str, Any]:
        """Best-effort snapshot of the connection pool counters."""
        if self._engine is None:
            return {}
        try:
            return pool_counters(self._engine.pool)
        except Exception:  # pragma: no cover - pool introspection is advisory
            return {}

    async def close(self) -> None:
        """Close the database engine and all connections."""
        if self._engine is not None:
            await self._engine.dispose()
            self._engine = None
            self._session_factory = None


def create_async_engine_manager(
    database_url: str,
    pool_size: int = 5,
    max_overflow: int = 10,
    default_app_name: Optional[str] = None
) -> AsyncEngineManager:
    """
    Create an AsyncEngineManager for managing database connections.

    Convenience function for creating an engine manager.

    Args:
        database_url: PostgreSQL connection URL (with asyncpg driver)
        pool_size: Connection pool size (default: 5)
        max_overflow: Maximum overflow connections (default: 10)
        default_app_name: Default application name (uses APPLICATION_NAME env var if None)

    Returns:
        AsyncEngineManager: Configured engine manager

    Example:
        from pantheon_shared.database import create_async_engine_manager

        engine_manager = create_async_engine_manager(
            database_url=settings.database_url,
            pool_size=settings.database_pool_size,
            max_overflow=settings.database_max_overflow,
            default_app_name="my-service"
        )

        # Use in FastAPI
        @app.get("/items")
        async def get_items(db: AsyncSession = Depends(get_db)):
            ...
    """
    return AsyncEngineManager(
        database_url=database_url,
        pool_size=pool_size,
        max_overflow=max_overflow,
        default_app_name=default_app_name
    )


#: Minimum gap between two pool-timeout lines for the same pool; the timeouts in between are
#: counted and reported as `suppressed=N` on the next line.
POOL_TIMEOUT_LOG_MIN_INTERVAL = 5.0

_pool_timeout_lock = threading.Lock()
_pool_timeout_service = ["pantheon-service"]
#: Per pool: [monotonic time of the last line, timeouts suppressed since]. Weak keys, so a
#: disposed pool drops out.
_pool_timeout_state: "weakref.WeakKeyDictionary[Any, List[float]]" = weakref.WeakKeyDictionary()


def _log_pool_timeout(pool: Any, err: BaseException) -> None:
    """Log one `db pool timeout (` line for a checkout timeout (DB-6). Never raises.

    The wording is load-bearing: alert rule `db-pool-timeout` matches `db pool timeout (`.
    """
    try:
        if getattr(err, "_pantheon_pool_timeout_logged", False):
            return  # QueuePool._do_get recurses into itself; log the timeout once
        try:
            err._pantheon_pool_timeout_logged = True
        except Exception:
            pass
        now = time.monotonic()
        try:
            state = _pool_timeout_state.setdefault(pool, [float("-inf"), 0])
        except TypeError:  # pragma: no cover - a pool that cannot be weak-referenced
            state = [float("-inf"), 0]
        if now - state[0] < POOL_TIMEOUT_LOG_MIN_INTERVAL:
            state[1] += 1
            return
        suppressed = int(state[1])
        state[0], state[1] = now, 0
        try:
            checked_out = pool.checkedout()
        except Exception:
            checked_out = -1
        message = (f"db pool timeout ({_pool_timeout_service[0]}): {err}; "
                   f"checked_out={checked_out} suppressed={suppressed}")
        from .logging import get_logger
        get_logger(__name__).error(message)
    except Exception:
        pass


def install_pool_timeout_logging(service_name: Optional[str] = None) -> bool:
    """Log every pool checkout timeout in this process as `db pool timeout (<service>): …` (DB-6).

    SQLAlchemy has no checkout-timeout event, so this wraps `QueuePool._do_get` ONCE,
    class-wide. That covers every pool in the process: `AsyncEngineManager`,
    `create_sync_engine`, a service's raw `create_engine()`/`create_async_engine()`
    (`AsyncAdaptedQueuePool` inherits `_do_get`) and subclasses that call `super()._do_get()`
    (detection's `DiagnosticQueuePool`). A catch at the session dependency would miss raw
    engines and background jobs (pantheon-deploy docs/em/C10_C12_ALERT_PROOF_PLAN.md § 9).

    Behaviour is unchanged: the success path only adds a `try` (zero cost on CPython 3.11+),
    and the SAME exception object is re-raised. Idempotent. Called from
    `start_metrics_snapshot_emitter()`, i.e. per worker after the fork.

    Returns False, with a warning, when `QueuePool._do_get` no longer exists (a SQLAlchemy
    upgrade); `tests/test_pool_timeout_logging.py` fails on that too, so it cannot pass CI
    silently.
    """
    try:
        from sqlalchemy import exc as sa_exc
        from sqlalchemy.pool import QueuePool
        with _pool_timeout_lock:
            if service_name:
                _pool_timeout_service[0] = service_name
            original = QueuePool.__dict__.get("_do_get")
            if original is None:
                from .logging import get_logger
                get_logger(__name__).warning(
                    "pool-timeout-logging-not-installed: sqlalchemy QueuePool._do_get is missing")
                return False
            if getattr(original, "_pantheon_pool_timeout_wrapped", False):
                return True

            @functools.wraps(original)
            def _do_get(self):  # type: ignore[no-untyped-def]
                try:
                    return original(self)
                except sa_exc.TimeoutError as err:
                    _log_pool_timeout(self, err)
                    raise

            _do_get._pantheon_pool_timeout_wrapped = True  # type: ignore[attr-defined]
            _do_get._pantheon_original = original  # type: ignore[attr-defined]
            QueuePool._do_get = _do_get
            return True
    except Exception:
        return False


def create_sync_engine(
    database_url: str,
    pool_size: int = 5,
    max_overflow: int = 10,
    pool_timeout: Optional[float] = None,
    pool_recycle: int = 540,
    application_name: Optional[str] = None,
    connect_options: Optional[dict] = None,
    echo: bool = False,
) -> Engine:
    """
    Create a synchronous SQLAlchemy Engine with connection-drop resilience.

    This is the sync counterpart to ``AsyncEngineManager`` — it bakes in the same
    pool hardening so a hand-rolled sync engine in a service doesn't silently
    re-introduce the "server closed the connection unexpectedly" failure mode:

    - ``pool_pre_ping=True`` — validates a pooled connection (cheap ``SELECT 1``)
      before handing it to a caller, transparently discarding and reconnecting if
      Postgres dropped the backend (restart, idle reap, OOM, connection-tuning).
    - ``pool_recycle`` (default 540s / 9 min): recycles a connection older than this the next
      time it is checked out. Kept below the server's ``idle_session_timeout`` (600 s). It cannot
      retire an IDLE connection (nothing checks it out), so Postgres reaping idle pooled connections
      is expected and by design; ``pool_pre_ping`` reopens them transparently. Lowering this from
      1800 s on 2026-10-03 cut app-side stale-connection errors but not server-side reaps (DB-8).
    - ``pool_timeout`` — fast-fail on a contended checkout (PLATFORM_PERF RC-2)
      instead of stalling for SQLAlchemy's 30s default. Defaults to the
      DATABASE_POOL_TIMEOUT env (fleet-wide), falling back to 10s.

    SQLite URLs use ``NullPool`` (no pooling args) since the resilience knobs are
    meaningless for a file/in-memory database.

    Args:
        database_url: Sync SQLAlchemy URL (postgresql:// or postgresql+psycopg2://).
        pool_size: Connection pool size.
        max_overflow: Maximum overflow connections.
        pool_timeout: Seconds to wait for a free connection before failing.
                      Defaults to DATABASE_POOL_TIMEOUT env, then 10s.
        pool_recycle: Seconds after which a pooled connection is recycled.
        application_name: PostgreSQL application_name for connection tracking
                          (uses APPLICATION_NAME env var if not provided).
        connect_options: Extra libpq options merged into the connection's ``-c``
                         options string (e.g. ``{"timezone": "utc"}``). Each
                         key/value becomes ``-c key=value`` alongside
                         application_name. Postgres-only; ignored for SQLite.
        echo: SQLAlchemy echo flag (keep False outside debugging).

    Returns:
        Engine: A configured synchronous engine.
    """
    app_name = application_name or os.getenv("APPLICATION_NAME", "pantheon-service")

    is_sqlite = "sqlite" in database_url

    if is_sqlite:
        return create_engine(
            database_url,
            poolclass=NullPool,
            echo=echo,
            future=True,
        )

    if pool_timeout is None:
        pool_timeout = float(os.getenv("DATABASE_POOL_TIMEOUT", "10"))

    connect_args = {}
    if "postgresql" in database_url:
        opts = dict(connect_options or {})
        opts["application_name"] = app_name
        connect_args = {"options": " ".join(f"-c {k}={v}" for k, v in opts.items())}

    return create_engine(
        database_url,
        pool_size=pool_size,
        max_overflow=max_overflow,
        pool_timeout=pool_timeout,
        pool_pre_ping=True,
        pool_recycle=pool_recycle,
        echo=echo,
        future=True,
        connect_args=connect_args,
    )
