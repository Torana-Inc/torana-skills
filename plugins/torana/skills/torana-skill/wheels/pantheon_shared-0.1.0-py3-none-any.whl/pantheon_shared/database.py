"""
Database utilities for Pantheon microservices.

Provides common database validation and connection functionality.
"""

import os
import asyncio
from dataclasses import dataclass
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.ext.asyncio import create_async_engine, AsyncEngine, async_sessionmaker, AsyncSession
from sqlalchemy.pool import NullPool
from typing import Any, AsyncGenerator, Dict, Optional


def validate_database_url(database_url: str) -> str:
    """
    Validate that DATABASE_URL is present and accessible.

    Args:
        database_url: The database URL to validate

    Returns:
        The validated database URL

    Raises:
        ValueError: If DATABASE_URL is missing, invalid format, or connection fails
    """
    if not database_url:
        raise ValueError("DATABASE_URL environment variable is required")

    if not database_url.startswith(('postgresql://', 'postgresql+asyncpg://')):
        raise ValueError(
            "DATABASE_URL must be a PostgreSQL connection string. "
            "Expected format: postgresql://user:password@host:port/database "
            "or postgresql+asyncpg://user:password@host:port/database"
        )

    # Try to connect to validate the database is accessible
    try:
        # Use sync connection for validation
        sync_url = database_url.replace('postgresql+asyncpg://', 'postgresql://')
        # Set application_name for connection tracking
        app_name = os.getenv("APPLICATION_NAME", "pantheon-service")
        engine = create_engine(
            sync_url,
            connect_args={
                "application_name": f"{app_name}-validation"
            }
        )
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        engine.dispose()
    except SQLAlchemyError as e:
        raise ValueError(f"Cannot connect to database: {e}")
    except Exception as e:
        raise ValueError(f"Database connection failed: {e}")

    return database_url


class DatabaseValidatorMixin:
    """
    Mixin class that provides database validation functionality.

    Use this class with Pydantic BaseSettings to add DATABASE_URL validation.
    """

    @classmethod
    def __pydantic_init_subclass__(cls, **kwargs: Any) -> None:
        """Register database validator when class is created."""
        super().__pydantic_init_subclass__(**kwargs)

        # Add the validator if it doesn't exist
        if hasattr(cls, 'database_url') and not hasattr(cls, 'validate_database_url'):
            from pydantic import validator
            setattr(cls, 'validate_database_url', validator('database_url')(validate_database_url))


def validate_database_url_field(cls, v: str) -> str:
    """
    Pydantic validator function for DATABASE_URL field.

    Usage:
        class Settings(BaseSettings):
            database_url: str = Field(alias="DATABASE_URL")

            @validator('database_url')
            def validate_database_url(cls, v):
                from pantheon_shared.database import validate_database_url_field
                return validate_database_url_field(cls, v)

    Args:
        cls: The settings class
        v: The database URL value to validate

    Returns:
        The validated database URL
    """
    return validate_database_url(v)


@dataclass
class DatabaseHealth:
    """Result of a pool-independent database health probe (issue #10).

    ``status`` is deliberately three-valued:

    * ``healthy``   - a connection was obtained and ``SELECT 1`` succeeded.
    * ``degraded``  - the pool is saturated. The service is BUSY. A liveness
                      probe must NOT fail on this, or load causes restarts.
    * ``unhealthy`` - the database could not be reached at all.
    """

    status: str
    detail: Optional[str] = None
    pool_size: Optional[int] = None
    checked_out: Optional[int] = None
    overflow: Optional[int] = None

    @property
    def is_alive(self) -> bool:
        """True unless the database is genuinely unreachable.

        This is the value a LIVENESS probe should use: a saturated pool means
        busy, and restarting a busy service makes the outage worse.
        """
        return self.status != "unhealthy"

    @property
    def is_ready(self) -> bool:
        """True only when the service can serve a request right now.

        This is the value a READINESS probe should use - shedding traffic from
        a saturated instance is correct; killing it is not.
        """
        return self.status == "healthy"

    def to_dict(self) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"status": self.status}
        if self.detail:
            payload["detail"] = self.detail
        for key in ("pool_size", "checked_out", "overflow"):
            value = getattr(self, key)
            if value is not None:
                payload[key] = value
        return payload


class AsyncEngineManager:
    """
    Manages a singleton async database engine with proper connection pooling.

    This class ensures that only ONE engine is created per service, preventing
    connection leaks that occur when creating new engines repeatedly.

    Usage:
        manager = AsyncEngineManager(
            database_url="postgresql+asyncpg://...",
            pool_size=5,
            max_overflow=10,
            default_app_name="my-service"
        )

        # In FastAPI dependency
        async def get_db() -> AsyncGenerator[AsyncSession, None]:
            async with manager.get_session() as session:
                yield session
    """

    def __init__(
        self,
        database_url: str,
        pool_size: int = 5,
        max_overflow: int = 10,
        default_app_name: Optional[str] = None,
        pool_timeout: Optional[float] = None
    ):
        """
        Initialize the engine manager.

        Args:
            database_url: PostgreSQL connection URL (with asyncpg driver)
            pool_size: Connection pool size
            max_overflow: Maximum overflow connections
            default_app_name: Default application name for PostgreSQL tracking
                             (uses APPLICATION_NAME env var if not provided)
            pool_timeout: Seconds to wait for a free connection before failing.
                          PLATFORM_PERF RC-2: a short timeout turns a 30s checkout
                          stall (SQLAlchemy's default) into a fast failure so a
                          contended caller retries/circuit-breaks instead of pinning
                          a request thread. Defaults to the DATABASE_POOL_TIMEOUT env
                          (fleet-wide), falling back to 10s.
        """
        self.database_url = database_url
        self.pool_size = pool_size
        self.max_overflow = max_overflow
        self.default_app_name = default_app_name
        if pool_timeout is None:
            pool_timeout = float(os.getenv("DATABASE_POOL_TIMEOUT", "10"))
        self.pool_timeout = pool_timeout
        self._engine: Optional[AsyncEngine] = None
        self._session_factory = None

    def get_engine(self) -> AsyncEngine:
        """
        Get or create the singleton database engine.

        Returns:
            AsyncEngine: The database engine (created once per process)
        """
        if self._engine is None:
            # Get application name from environment or use default
            application_name = os.getenv("APPLICATION_NAME", self.default_app_name or "pantheon-service")

            self._engine = create_async_engine(
                self.database_url,
                pool_size=self.pool_size,
                max_overflow=self.max_overflow,
                pool_timeout=self.pool_timeout,
                pool_pre_ping=True,
                pool_recycle=1800,
                echo=False,
                future=True,
                connect_args={
                    "server_settings": {
                        "application_name": application_name
                    }
                }
            )

            self._session_factory = async_sessionmaker(
                bind=self._engine,
                class_=AsyncSession,
                expire_on_commit=False,
                autoflush=False
            )

        return self._engine

    async def get_session(self) -> AsyncGenerator[AsyncSession, None]:
        """
        Get a database session from the engine's connection pool.

        Yields:
            AsyncSession: Database session

        Note:
            The session is automatically committed on success and rolled back on error.
            The connection is always returned to the pool via context manager cleanup.
        """
        engine = self.get_engine()

        if self._session_factory is None:
            self._session_factory = async_sessionmaker(
                bind=engine,
                class_=AsyncSession,
                expire_on_commit=False,
                autoflush=False
            )

        async with self._session_factory() as session:
            try:
                yield session
                # Commit on successful completion
                await session.commit()
            except Exception:
                # Rollback on error
                await session.rollback()
                raise
            finally:
                # Ensure session is closed (context manager does this, but be explicit)
                # This ensures the connection is returned to the pool
                pass  # The async with statement handles cleanup

    async def health_check(
        self,
        timeout: Optional[float] = None,
    ) -> "DatabaseHealth":
        """Check database reachability WITHOUT waiting on the request pool.

        Issue #10: ``/health`` used the same pooled dependency as request
        handling, so a service that was merely BUSY - every connection checked
        out, but perfectly healthy - could not obtain a connection for its own
        liveness probe within the probe's deadline. The orchestrator then killed
        the container mid-request, which freed the pool, which made the restart
        look unexplained. Load caused restarts, and the restarts looked random.

        A health probe answers "is this process able to serve?", and waiting on
        a saturated pool answers a different question ("is the pool free?").
        This method therefore:

        * uses its own short timeout (``DATABASE_HEALTH_POOL_TIMEOUT``, default
          0.1s) instead of the request pool timeout (default 10s), and
        * reports pool SATURATION as ``degraded``, not ``unhealthy`` - a full
          pool means busy, and killing a busy service is the wrong response.

        Only an actual connection error is ``unhealthy``.

        Args:
            timeout: Seconds to wait for a connection. Defaults to
                ``DATABASE_HEALTH_POOL_TIMEOUT`` (0.1s).

        Returns:
            DatabaseHealth: status plus the pool counters, so a probe endpoint
            can surface WHY it is degraded rather than just failing.
        """
        if timeout is None:
            timeout = float(os.getenv("DATABASE_HEALTH_POOL_TIMEOUT", "0.1"))

        engine = self.get_engine()
        stats = self.pool_stats()

        try:
            async def _ping() -> None:
                async with engine.connect() as conn:
                    await conn.execute(text("SELECT 1"))

            await asyncio.wait_for(_ping(), timeout=timeout)
            return DatabaseHealth(status="healthy", **stats)
        except (asyncio.TimeoutError, TimeoutError):
            # Busy, not broken. Do NOT report unhealthy - that gets the
            # container killed precisely when it is under load (issue #10).
            return DatabaseHealth(
                status="degraded",
                detail=(
                    f"no pooled connection available within {timeout}s "
                    "(pool saturated; the service is busy, not unreachable)"
                ),
                **stats,
            )
        except Exception as exc:
            return DatabaseHealth(
                status="unhealthy",
                detail=f"{type(exc).__name__}: {exc}",
                **stats,
            )

    def pool_stats(self) -> Dict[str, Any]:
        """Best-effort snapshot of the connection pool counters."""
        if self._engine is None:
            return {}
        try:
            pool = self._engine.pool
            return {
                "pool_size": pool.size(),
                "checked_out": pool.checkedout(),
                "overflow": pool.overflow(),
            }
        except Exception:  # pragma: no cover - pool introspection is advisory
            return {}

    async def close(self) -> None:
        """Close the database engine and all connections."""
        if self._engine is not None:
            await self._engine.dispose()
            self._engine = None
            self._session_factory = None


def create_async_engine_manager(
    database_url: str,
    pool_size: int = 5,
    max_overflow: int = 10,
    default_app_name: Optional[str] = None
) -> AsyncEngineManager:
    """
    Create an AsyncEngineManager for managing database connections.

    Convenience function for creating an engine manager.

    Args:
        database_url: PostgreSQL connection URL (with asyncpg driver)
        pool_size: Connection pool size (default: 5)
        max_overflow: Maximum overflow connections (default: 10)
        default_app_name: Default application name (uses APPLICATION_NAME env var if None)

    Returns:
        AsyncEngineManager: Configured engine manager

    Example:
        from pantheon_shared.database import create_async_engine_manager

        engine_manager = create_async_engine_manager(
            database_url=settings.database_url,
            pool_size=settings.database_pool_size,
            max_overflow=settings.database_max_overflow,
            default_app_name="my-service"
        )

        # Use in FastAPI
        @app.get("/items")
        async def get_items(db: AsyncSession = Depends(get_db)):
            ...
    """
    return AsyncEngineManager(
        database_url=database_url,
        pool_size=pool_size,
        max_overflow=max_overflow,
        default_app_name=default_app_name
    )


def create_sync_engine(
    database_url: str,
    pool_size: int = 5,
    max_overflow: int = 10,
    pool_timeout: Optional[float] = None,
    pool_recycle: int = 1800,
    application_name: Optional[str] = None,
    connect_options: Optional[dict] = None,
    echo: bool = False,
) -> Engine:
    """
    Create a synchronous SQLAlchemy Engine with connection-drop resilience.

    This is the sync counterpart to ``AsyncEngineManager`` — it bakes in the same
    pool hardening so a hand-rolled sync engine in a service doesn't silently
    re-introduce the "server closed the connection unexpectedly" failure mode:

    - ``pool_pre_ping=True`` — validates a pooled connection (cheap ``SELECT 1``)
      before handing it to a caller, transparently discarding and reconnecting if
      Postgres dropped the backend (restart, idle reap, OOM, connection-tuning).
    - ``pool_recycle`` (default 1800s / 30 min) — proactively recycles connections
      older than the recycle window so they never outlive Postgres' idle timeout.
    - ``pool_timeout`` — fast-fail on a contended checkout (PLATFORM_PERF RC-2)
      instead of stalling for SQLAlchemy's 30s default. Defaults to the
      DATABASE_POOL_TIMEOUT env (fleet-wide), falling back to 10s.

    SQLite URLs use ``NullPool`` (no pooling args) since the resilience knobs are
    meaningless for a file/in-memory database.

    Args:
        database_url: Sync SQLAlchemy URL (postgresql:// or postgresql+psycopg2://).
        pool_size: Connection pool size.
        max_overflow: Maximum overflow connections.
        pool_timeout: Seconds to wait for a free connection before failing.
                      Defaults to DATABASE_POOL_TIMEOUT env, then 10s.
        pool_recycle: Seconds after which a pooled connection is recycled.
        application_name: PostgreSQL application_name for connection tracking
                          (uses APPLICATION_NAME env var if not provided).
        connect_options: Extra libpq options merged into the connection's ``-c``
                         options string (e.g. ``{"timezone": "utc"}``). Each
                         key/value becomes ``-c key=value`` alongside
                         application_name. Postgres-only; ignored for SQLite.
        echo: SQLAlchemy echo flag (keep False outside debugging).

    Returns:
        Engine: A configured synchronous engine.
    """
    app_name = application_name or os.getenv("APPLICATION_NAME", "pantheon-service")

    is_sqlite = "sqlite" in database_url

    if is_sqlite:
        return create_engine(
            database_url,
            poolclass=NullPool,
            echo=echo,
            future=True,
        )

    if pool_timeout is None:
        pool_timeout = float(os.getenv("DATABASE_POOL_TIMEOUT", "10"))

    connect_args = {}
    if "postgresql" in database_url:
        opts = dict(connect_options or {})
        opts["application_name"] = app_name
        connect_args = {"options": " ".join(f"-c {k}={v}" for k, v in opts.items())}

    return create_engine(
        database_url,
        pool_size=pool_size,
        max_overflow=max_overflow,
        pool_timeout=pool_timeout,
        pool_pre_ping=True,
        pool_recycle=pool_recycle,
        echo=echo,
        future=True,
        connect_args=connect_args,
    )
