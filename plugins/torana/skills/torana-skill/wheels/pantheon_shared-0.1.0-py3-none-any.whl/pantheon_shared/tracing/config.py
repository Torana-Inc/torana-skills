"""
Tracing configuration and setup utilities.

Provides TracingConfig dataclass and setup_tracing() function for
initializing distributed tracing in Pantheon services.
"""

import os
from dataclasses import dataclass, field
from typing import Optional, List

from .spans import SpanManager
from .state import set_tracing_enabled

import structlog

logger = structlog.get_logger(__name__)


@dataclass
class TracingConfig:
    """
    Configuration for distributed tracing.

    Typically loaded from environment variables using from_env().

    Attributes:
        service_name: Name of the service for trace identification
        otlp_endpoint: Jaeger OTLP gRPC endpoint (e.g., "jaeger:4317")
        enable_otlp: Whether to enable OTLP exporter (sends traces to Jaeger)
        enable_console: Whether to print traces to console (for debugging)
        use_simple_processor: Use SimpleSpanProcessor for immediate export (dev/debug)
        sample_rate: Sampling rate 0.0-1.0 (1.0 = 100% sampling)
        exclude_paths: URL paths to exclude from tracing (e.g., health checks)
    """
    service_name: str
    otlp_endpoint: Optional[str] = None
    enable_otlp: bool = False
    enable_console: bool = False
    use_simple_processor: bool = False  # For immediate export (useful for dev/debug)
    sample_rate: float = 1.0
    exclude_paths: List[str] = field(default_factory=list)

    @classmethod
    def from_env(cls, service_name: str) -> "TracingConfig":
        """
        Create TracingConfig from environment variables.

        Environment variables:
        - ENABLE_OTLP_TRACE: Enable OTLP exporter (default: false)
        - OTLP_ENDPOINT: Jaeger OTLP endpoint (default: jaeger:4317)
        - ENABLE_CONSOLE_TRACE: Enable console output (default: false)
        - TRACE_SAMPLE_RATE: Sampling rate 0.0-1.0 (default: 1.0)
        - OTEL_SERVICE_NAME: Override service name
        - <SERVICE>_DISABLE_TRACING: Service-specific disable flag (e.g., PANTEON_AUTH_DISABLE_TRACING=true)

        Args:
            service_name: Default service name if OTEL_SERVICE_NAME not set

        Returns:
            TracingConfig instance with values from environment
        """
        # Check for service-specific tracing disable flag
        # Converts service name like "pantheon-auth" to "PANTHEON_AUTH_DISABLE_TRACING"
        service_upper = service_name.upper().replace("-", "_")
        disable_var = f"{service_upper}_DISABLE_TRACING"
        tracing_disabled = os.getenv(disable_var, "false").lower() == "true"

        # If tracing is disabled for this service, both OTLP and console will be false
        if tracing_disabled:
            logger.info(
                "Tracing disabled for service via environment variable",
                service=service_name,
                env_var=disable_var,
            )
            return cls(
                service_name=service_name,
                otlp_endpoint=os.getenv("OTLP_ENDPOINT", "jaeger:4317"),
                enable_otlp=False,
                enable_console=False,
                use_simple_processor=False,
                sample_rate=float(os.getenv("TRACE_SAMPLE_RATE", "1.0")),
            )

        # Normal configuration flow
        return cls(
            service_name=service_name,
            otlp_endpoint=os.getenv("OTLP_ENDPOINT", "jaeger:4317"),
            enable_otlp=os.getenv("ENABLE_OTLP_TRACE", "false").lower() == "true",
            enable_console=os.getenv("ENABLE_CONSOLE_TRACE", "false").lower() == "true",
            use_simple_processor=os.getenv("USE_SIMPLE_TRACER", "false").lower() == "true",
            sample_rate=float(os.getenv("TRACE_SAMPLE_RATE", "1.0")),
        )


def setup_tracing(config: TracingConfig) -> Optional[SpanManager]:
    """
    Initialize distributed tracing for a service.

    Creates a SpanManager configured with the provided settings.
    If both OTLP and console are disabled, returns None (tracing disabled).

    Args:
        config: TracingConfig with service settings

    Returns:
        SpanManager instance for creating spans, or None if disabled

    Example:
        ```python
        from pantheon_shared.tracing import TracingConfig, setup_tracing

        config = TracingConfig.from_env("pantheon-auth")
        span_manager = setup_tracing(config)

        # span_manager can be passed to TracingMiddleware
        app.add_middleware(
            TracingMiddleware,
            service_name="pantheon-auth",
            span_manager=span_manager,
        )
        ```
    """
    # Determine if tracing should be enabled based on config
    tracing_enabled = config.enable_otlp or config.enable_console

    # Set the global tracing state (controls middleware behavior)
    set_tracing_enabled(tracing_enabled)

    if not tracing_enabled:
        logger.debug(
            "Distributed tracing disabled",
            service=config.service_name,
            hint="Set ENABLE_OTLP_TRACE=true to enable",
        )
        return None

    logger.debug(
        "Initializing distributed tracing",
        service=config.service_name,
        otlp_enabled=config.enable_otlp,
        otlp_endpoint=config.otlp_endpoint if config.enable_otlp else None,
        console_enabled=config.enable_console,
        simple_processor=config.use_simple_processor,
        sample_rate=config.sample_rate,
    )

    span_manager = SpanManager(
        service_name=config.service_name,
        otlp_endpoint=config.otlp_endpoint if config.enable_otlp else None,
        enable_console=config.enable_console,
        use_simple_processor=config.use_simple_processor,
    )

    return span_manager
