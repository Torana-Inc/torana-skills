"""
Trace context management using contextvars for request-scoped trace information.

This module provides the core TraceContext class and contextvar-based storage
for maintaining trace context throughout an async request lifecycle.
"""

import uuid
from contextvars import ContextVar
from dataclasses import dataclass, field
from typing import Optional
from datetime import datetime, timezone


@dataclass
class TraceContext:
    """
    Holds trace information for the current request context.

    Attributes:
        trace_id: Global identifier for the entire request chain (same across all services)
        span_id: Identifier for the current operation/span
        parent_span_id: Identifier of the parent span (for linking)
        service_name: Name of the current service
        operation_name: Name of the current operation (e.g., endpoint path)
        start_time: When this span started
        sampled: Whether this trace should be recorded
        session_id: Business-level chat/agent session id (optional; for log filtering)
        turn_id: Business-level per-turn id (optional; for log filtering)
    """
    trace_id: str
    span_id: str
    parent_span_id: Optional[str] = None
    service_name: Optional[str] = None
    operation_name: Optional[str] = None
    start_time: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    sampled: bool = True
    # Business-level correlation fields — independent of the trace/span ids.
    # When populated they are emitted as structured log fields (session_id=…,
    # turn_id=…) so Grafana/Loki can filter a whole conversation or a single
    # turn without an OR-of-trace_ids query. See agent-builder
    # docs/VM_OPERATION_PROGRAM_ANALYSIS.md § S5 (R2(B)).
    session_id: Optional[str] = None
    turn_id: Optional[str] = None

    @classmethod
    def new(cls, service_name: str, operation_name: Optional[str] = None) -> "TraceContext":
        """Create a new root trace context (no parent)."""
        return cls(
            trace_id=cls._generate_trace_id(),
            span_id=cls._generate_span_id(),
            parent_span_id=None,
            service_name=service_name,
            operation_name=operation_name,
        )

    @classmethod
    def from_parent(
        cls,
        parent_trace_id: str,
        parent_span_id: str,
        service_name: str,
        operation_name: Optional[str] = None,
        sampled: bool = True,
    ) -> "TraceContext":
        """Create a child trace context linked to a parent."""
        return cls(
            trace_id=parent_trace_id,  # Same trace_id as parent
            span_id=cls._generate_span_id(),  # New span_id
            parent_span_id=parent_span_id,  # Link to parent
            service_name=service_name,
            operation_name=operation_name,
            sampled=sampled,
        )

    @staticmethod
    def _generate_trace_id() -> str:
        """Generate a 32-character trace ID (W3C format)."""
        return uuid.uuid4().hex

    @staticmethod
    def _generate_span_id() -> str:
        """Generate a 16-character span ID (W3C format)."""
        return uuid.uuid4().hex[:16]

    def to_headers(self) -> dict:
        """Convert trace context to HTTP headers for propagation."""
        headers = {
            "X-Trace-ID": self.trace_id,
            "X-Span-ID": self.span_id,
            "X-Request-ID": self.trace_id,  # Backward compatibility
        }
        if self.parent_span_id:
            headers["X-Parent-Span-ID"] = self.parent_span_id

        # W3C Trace Context format
        # Format: {version}-{trace_id}-{span_id}-{flags}
        flags = "01" if self.sampled else "00"
        headers["traceparent"] = f"00-{self.trace_id}-{self.span_id}-{flags}"

        return headers

    def to_log_context(self) -> dict:
        """Return fields to be included in all log statements."""
        ctx = {
            "trace_id": self.trace_id,
            "span_id": self.span_id,
        }
        if self.parent_span_id:
            ctx["parent_span_id"] = self.parent_span_id
        if self.service_name:
            ctx["service"] = self.service_name
        if self.session_id:
            ctx["session_id"] = self.session_id
        if self.turn_id:
            ctx["turn_id"] = self.turn_id
        return ctx


# ContextVar for storing trace context in async-safe manner
_trace_context_var: ContextVar[Optional[TraceContext]] = ContextVar(
    "trace_context", default=None
)


def get_current_trace_context() -> Optional[TraceContext]:
    """Get the current trace context for this request."""
    return _trace_context_var.get()


def set_trace_context(ctx: TraceContext) -> None:
    """Set the trace context for this request."""
    _trace_context_var.set(ctx)


def clear_trace_context() -> None:
    """Clear the trace context after request completes."""
    _trace_context_var.set(None)
