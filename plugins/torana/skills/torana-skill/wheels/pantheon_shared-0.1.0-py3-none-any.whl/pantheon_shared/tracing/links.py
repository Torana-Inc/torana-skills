"""
OTel Span Link Utilities.

Creates span links from saved trace/span ID hex strings, enabling
cross-trace correlation in Jaeger (e.g., HITL pause → resume).
"""
from typing import Optional, Dict, Any

from opentelemetry.trace import Link, SpanContext, TraceFlags, INVALID_SPAN_CONTEXT


def create_span_link(
    trace_id_hex: str,
    span_id_hex: str,
    attributes: Optional[Dict[str, Any]] = None,
) -> Optional[Link]:
    """
    Create an OTel span link from saved trace/span ID hex strings.

    Args:
        trace_id_hex: 32-char lowercase hex trace ID
        span_id_hex: 16-char lowercase hex span ID
        attributes: Optional link attributes for Jaeger search

    Returns:
        Link object, or None if input is invalid.
    """
    if not trace_id_hex or not span_id_hex:
        return None
    try:
        span_context = SpanContext(
            trace_id=int(trace_id_hex, 16),
            span_id=int(span_id_hex, 16),
            is_remote=True,
            trace_flags=TraceFlags(TraceFlags.SAMPLED),
        )
        if span_context == INVALID_SPAN_CONTEXT:
            return None
        return Link(context=span_context, attributes=attributes or {})
    except (ValueError, TypeError):
        return None
