"""
CLIENT span for every east-west call (F4b, F50).

Background work (queue workers, schedulers, executor threads) calls other services with no OTel
span in context. Without a span, the receiver would be parented on ids that were never exported.
With it, the call has a real root span in the caller's service, and the receiver is its child.
See pantheon-shared/docs/F4_TRACE_PARENTING_SPEC.md § 3.4.5.

F50: the span used to open ONLY when no span was current, so a call made inside a request or a
unit span propagated that span itself, and the receiver's SERVER span hung directly off the
unit root with no hop between them: Jaeger could not show which call, its method, URL, status
or client-side latency. Now every call opens a CLIENT span as a child of whatever is current
(or as a root when nothing is), and traceparent carries THAT span.
"""

from contextlib import contextmanager
from typing import Any, Iterator, Optional

from .spans import OPENTELEMETRY_AVAILABLE


@contextmanager
def east_west_client_span(method: str, url: str, service_name: str) -> Iterator[Optional[Any]]:
    """Yield a CLIENT span that is current for the call, or None when tracing is off.

    The span is a child of the current span (a request, a unit or an ADK tool span), or a root
    when none is current. None when: OTel is unavailable, tracing is disabled, or no tracer is
    configured. It ends on exit, including when the call raises; `use_span` then records the
    exception and sets the status to ERROR.
    """
    if not OPENTELEMETRY_AVAILABLE:
        yield None
        return

    from opentelemetry import trace
    from opentelemetry.trace import SpanKind

    from .middleware import get_global_span_manager
    from .state import is_tracing_enabled

    span_manager = get_global_span_manager()
    if not is_tracing_enabled() or span_manager is None or span_manager.tracer is None:
        yield None
        return

    span = span_manager.tracer.start_span(
        f"{method.upper()} {url}",
        kind=SpanKind.CLIENT,
        attributes={
            "http.method": method.upper(),
            "http.url": str(url),
            "service.name": service_name,
        },
    )
    with trace.use_span(span, end_on_exit=True):
        yield span


def set_client_status(span: Optional[Any], status_code: int) -> None:
    """Record the response on a client span: `http.status_code`, and ERROR status on a 5xx.

    A 4xx is the caller's request being refused, not a failed hop, so it stays UNSET (the
    OTel HTTP convention for CLIENT spans marks 4xx as error; we do not, because an LLM's bad
    guess would then paint every agent turn red in Jaeger).
    """
    if span is None:
        return
    span.set_attribute("http.status_code", status_code)
    if status_code >= 500 and OPENTELEMETRY_AVAILABLE:
        from opentelemetry.trace import Status, StatusCode
        span.set_status(Status(StatusCode.ERROR, f"HTTP {status_code}"))
