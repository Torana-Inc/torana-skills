"""
Pantheon Distributed Tracing Module

Provides OpenTelemetry-based distributed tracing for all Pantheon services.
Enables end-to-end request correlation across microservices with Jaeger integration.

Quick Start:
    ```python
    from pantheon_shared.tracing import TracingConfig, TracingMiddleware, setup_tracing

    # In your FastAPI app
    config = TracingConfig.from_env("my-service")
    span_manager = setup_tracing(config)

    app.add_middleware(
        TracingMiddleware,
        service_name="my-service",
        span_manager=span_manager,
    )
    ```

Environment Variables:
    ENABLE_OTLP_TRACE: Enable OTLP exporter (default: false)
    OTLP_ENDPOINT: Jaeger OTLP endpoint (default: jaeger:4317)
    ENABLE_CONSOLE_TRACE: Enable console output (default: false)
    OTEL_SERVICE_NAME: Override service name
    TRACE_SAMPLE_RATE: Sampling rate 0.0-1.0 (default: 1.0)
"""

from .context import (
    TraceContext,
    get_current_trace_context,
    set_trace_context,
    clear_trace_context,
)
from .propagation import (
    extract_trace_context,
    inject_trace_headers,
)
from .middleware import TracingMiddleware, set_global_span_manager, get_global_span_manager
from .spans import SpanManager
from .config import TracingConfig, setup_tracing
from .state import is_tracing_enabled, set_tracing_enabled
from .links import create_span_link

__all__ = [
    # Context management
    "TraceContext",
    "get_current_trace_context",
    "set_trace_context",
    "clear_trace_context",
    # Header propagation
    "extract_trace_context",
    "inject_trace_headers",
    # Middleware
    "TracingMiddleware",
    "set_global_span_manager",
    "get_global_span_manager",
    # Span management
    "SpanManager",
    # Configuration
    "TracingConfig",
    "setup_tracing",
    # Tracing control state
    "is_tracing_enabled",
    "set_tracing_enabled",
    # Span links (cross-trace correlation)
    "create_span_link",
]
