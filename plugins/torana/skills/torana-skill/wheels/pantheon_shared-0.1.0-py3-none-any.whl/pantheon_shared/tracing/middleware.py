"""
FastAPI middleware for distributed tracing.

Automatically extracts trace context from incoming requests and creates spans.
"""

import os
import re
import time
from typing import Callable, Optional, List, TYPE_CHECKING, Set

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp
from starlette.requests import Request
from starlette.responses import Response

from .context import (
    set_trace_context,
    clear_trace_context,
)
from .propagation import extract_trace_context
from .spans import OPENTELEMETRY_AVAILABLE
from .error_scrub import code_for_status as _code_for_status, scrub_5xx

import structlog

if TYPE_CHECKING:
    from .spans import SpanManager

logger = structlog.get_logger(__name__)

# Global span manager storage - shared across all middleware instances
_global_span_manager: Optional["SpanManager"] = None


def _request_tenant(request: Request) -> str:
    """The tenant of a request for its C-01 failure line, or ``unknown`` when none was resolved.

    `auth.py` puts the authenticated user on ``request.state.current_user``; the request state is
    shared with this middleware, unlike a ContextVar set inside the route. An unauthenticated
    request (or one that failed before auth ran) logs ``unknown``, never ``platform``. Never raises.
    """
    try:
        user = getattr(request.state, "current_user", None)
        tenant = getattr(user, "tenant_id", None) if user is not None else None
        return str(tenant) if tenant else "unknown"
    except Exception:
        return "unknown"


def _log_request_failure(request: Request, *, error_code: str, http_status: Optional[int],
                         detail=None) -> None:
    """The ONE C-01 ``api.request.failed`` line for a request (5xx, or an exception that escaped)."""
    from ..logging_events import log_failure
    log_failure(
        "api.request",
        tenant_id=_request_tenant(request),
        error_code=error_code,
        unit_id=request.headers.get("x-request-id"),
        detail=detail,
        http_method=request.method,
        http_path=request.url.path,
        http_status=http_status,
    )


_REFERENCE_RE = re.compile(r"^[0-9a-f]{32}$")


def _edge_reference(request: Request) -> Optional[str]:
    """C-04: nginx's $request_id when the request came THROUGH nginx, else None.

    nginx sets X-Real-IP and overwrites any caller-sent X-Request-ID with its own id on every proxied location
    (config/*/nginx/conf/includes/proxy_headers.conf; pantheon-auth trusts X-Real-IP the same way,
    services/login_audit.py). An east-west call has no X-Real-IP. All zero or malformed -> None. Never raises.
    """
    try:
        if not request.headers.get("x-real-ip"):
            return None
        ref = (request.headers.get("x-request-id") or "").strip().lower()
        return ref if _REFERENCE_RE.match(ref) and int(ref, 16) else None
    except Exception:
        return None


def get_global_span_manager() -> Optional["SpanManager"]:
    """Get the global span manager."""
    return _global_span_manager


def set_global_span_manager(span_manager: "SpanManager") -> None:
    """Set the global span manager."""
    global _global_span_manager
    _global_span_manager = span_manager


def _parse_status_codes(env_value: Optional[str]) -> Set[int]:
    """Parse comma-separated HTTP status codes into a set of ints."""
    if not env_value:
        return set()
    codes: Set[int] = set()
    for token in env_value.split(","):
        token = token.strip()
        if not token:
            continue
        try:
            codes.add(int(token))
        except ValueError:
            logger.warning(
                "invalid_http_status_code_config",
                value=token,
            )
    return codes


_DEFAULT_SLOW_MS = 1000.0


def _parse_slow_ms(env_value: Optional[str]) -> float:
    """REQUEST_LOG_SLOW_MS: a 2xx/3xx at least this slow gets a completion line. <= 0 turns that off."""
    if env_value is None or not env_value.strip():
        return _DEFAULT_SLOW_MS
    try:
        return float(env_value)
    except ValueError:
        logger.warning("invalid_request_log_slow_ms", value=env_value, default=_DEFAULT_SLOW_MS)
        return _DEFAULT_SLOW_MS


def _route_template(request: Request) -> Optional[str]:
    """The matched route's path template (e.g. ``/api/v1/atlas/nodes/{path}``), or None.

    The router writes ``scope["route"]`` while routing, i.e. only AFTER ``call_next``; the
    scope dict is shared with the downstream app, so it is visible here afterwards. No match
    (404) leaves it unset.

    ⛔ FROM FastAPI 0.141 (the locked version) ``scope["route"]`` is the router's own route, without the
    ``include_router`` prefix (``/nodes/{path}``). The full template is on FastAPI's effective-route context
    in the scope, so that is read first; ``scope["route"]`` stays the fallback for FastAPI <= 0.136 and for a
    route declared on the app itself. Same cause as ``iam.cross_tenant.route_template``.
    """
    effective = (request.scope.get("fastapi") or {}).get("effective_route_context")
    route = request.scope.get("route")
    # path_format drops convertors: "/nodes/{path:path}" -> "/nodes/{path}".
    for candidate in (effective, route):
        template = getattr(candidate, "path_format", None) or getattr(candidate, "path", None)
        if template:
            return template
    return None


def _name_span_by_route(span, request: Request) -> None:
    """OI-97: name the SERVER span by the route template, not the raw path, so path-parameter
    values do not each become their own Jaeger operation. Unmatched (404) keeps method + raw path."""
    template = _route_template(request)
    if not template:
        return
    try:
        span.update_name(f"{request.method} {template}")
        span.set_attribute("http.route_template", template)
    except Exception:  # noqa: BLE001 — naming must never fail the request
        pass


class TracingMiddleware(BaseHTTPMiddleware):
    """
    Middleware that handles distributed tracing for all incoming requests.

    Features:
    - Extracts trace context from incoming headers (or generates new)
    - Creates spans for each request
    - Injects trace context into response headers
    - Records timing and status information

    Usage:
        ```python
        from pantheon_shared.tracing import TracingMiddleware, setup_tracing

        app = FastAPI()

        # In lifespan - store span_manager in app.state
        app.state.span_manager = setup_tracing(TracingConfig.from_env("my-service"))

        # Add middleware - pass app reference to get span_manager dynamically
        app.add_middleware(
            TracingMiddleware,
            service_name="my-service",
        )
        ```
    """

    def __init__(
        self,
        app: ASGIApp,
        service_name: str,
        exclude_paths: Optional[List[str]] = None,
    ):
        super().__init__(app)
        self.app = app  # Store app reference to get span_manager dynamically
        self.service_name = service_name
        self.exclude_paths = exclude_paths or [
            "/health",
            "/healthz",
            "/ready",
            "/metrics",
            "/api/v1/health",
        ]
        self.warn_status_codes = _parse_status_codes(
            os.getenv("PANTHEON_HTTP_LOG_WARN_CODES")
        )
        self.error_status_codes = _parse_status_codes(
            os.getenv("PANTHEON_HTTP_LOG_ERROR_CODES")
        )
        # S2-16 (tracing option C): which completed requests get a log line. Every 4xx/5xx and any
        # request at least this slow do; other 2xx/3xx stay silent. The line carries nginx's
        # request_id, so `|= "<request_id>"` finds it from the access log.
        self.slow_ms = _parse_slow_ms(os.getenv("REQUEST_LOG_SLOW_MS"))

    def _log_completion(self, request: Request, status: int, duration_ms: float, trace_ctx,
                        detail: Optional[str] = None) -> None:
        """One line per completed request that is an error or slow (S2-16); nothing otherwise.

        - 5xx, or a code in PANTHEON_HTTP_LOG_ERROR_CODES  -> error   `http_response_error`
        - a code in PANTHEON_HTTP_LOG_WARN_CODES           -> warning `http_response_warning`
        - any other 4xx, or a 2xx/3xx >= REQUEST_LOG_SLOW_MS -> info  `http_request_completed`
        Each carries trace_id AND request_id (nginx's id; they differ when the caller sent its own
        X-Trace-ID).

        F7: a WARN-listed 4xx whose caller is an LLM (origin ``llm-tool`` / ``cli-llm``) is logged at
        INFO instead. An agent's request refused with a sentence telling it what to send is the loop
        working, not a defect (the datalake already treats an LLM's bad SQL this way, F6). 5xx and
        ERROR-listed codes stay ERROR whoever asked. The line carries ``origin``/``agent``/``tool``
        through `add_call_origin`.
        """
        slow = self.slow_ms > 0 and duration_ms >= self.slow_ms
        fields = dict(
            **trace_ctx.to_log_context(),
            # nginx's $request_id, as sent upstream in X-Request-ID (S2-10). Logged separately because
            # trace_id is NOT always it: a caller's own X-Trace-ID wins (the torana CLI always sends
            # one, F4), so only this field makes `|= "<request_id>"` work for every caller.
            request_id=request.headers.get("x-request-id"),
            http_method=request.method,
            http_path=request.url.path,
            http_status=status,
            duration_ms=round(duration_ms, 2),
            slow=slow,
        )
        from ..http.origin import current_origin, is_llm_origin
        if status in self.error_status_codes or status >= 500:
            logger.error("http_response_error", **fields)
            if status >= 500:
                # C-01: a 5xx is a failed api.request. An ERROR-listed 4xx is not.
                # C-04b: `detail` is the body the scrub took off the response (None when it sent it as is).
                _log_request_failure(request, error_code=_code_for_status(status), http_status=status,
                                     detail=detail)
        elif status in self.warn_status_codes and not is_llm_origin(current_origin()):
            logger.warning("http_response_warning", **fields)
        elif status >= 400 or slow:
            logger.info("http_request_completed", slow_threshold_ms=self.slow_ms, **fields)

    async def _scrubbed(self, request: Request, response: Response) -> Response:
        """The untraced paths: scrub, and keep the body in the one C-01 line when something was taken off."""
        response, detail = await scrub_5xx(request, response)
        if detail is not None:
            _log_request_failure(request, error_code=_code_for_status(response.status_code),
                                 http_status=response.status_code, detail=detail)
        return response

    def _get_span_manager(self) -> Optional["SpanManager"]:
        """Get span_manager from global storage if available."""
        return get_global_span_manager()

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        # F2: bind the inbound x-pantheon-origin first, so PantheonClient forwards it even when
        # tracing is off or the path is excluded. Reads one header, never raises.
        from ..http.origin import bind_inbound_origin
        bind_inbound_origin(request)

        # Check if tracing is dynamically disabled (skip all tracing logic)
        from .state import is_tracing_enabled
        if not is_tracing_enabled() or any(request.url.path.startswith(path) for path in self.exclude_paths):
            # Tracing off, or a health/metrics path: no span, but C-04b still scrubs a 5xx sent through nginx.
            return await self._scrubbed(request, await call_next(request))

        # Extract or create trace context
        trace_ctx = extract_trace_context(
            headers=dict(request.headers),
            service_name=self.service_name,
            operation_name=f"{request.method} {request.url.path}",
        )

        # Store in contextvar for access throughout request lifecycle
        set_trace_context(trace_ctx)

        # Start span if span manager is available
        span_manager = self._get_span_manager()
        span = None
        if span_manager:
            from opentelemetry.trace import SpanKind
            from .spans import _ROOT_TRACE_ID
            # C-04: the error reference (nginx's id) rides the span, and becomes the trace id when the request
            # brings no OTel parent (the torana CLI's c11a id is not one), so Jaeger finds it by id on v1 and v2.
            reference = _edge_reference(request)
            attributes = {
                "http.method": request.method,
                "http.url": str(request.url),
                "http.route": request.url.path,
                # The raw path stays on the span; the NAME becomes the route template (OI-97).
                "http.target": request.url.path,
                "http.host": request.headers.get("host", ""),
                "service.name": self.service_name,
            }
            if reference:
                attributes["torana.reference"] = reference
            token = _ROOT_TRACE_ID.set(reference) if reference and not trace_ctx.otel_trace_id else None
            try:
                span = span_manager.start_span(
                    name=f"{request.method} {request.url.path}",
                    trace_ctx=trace_ctx,
                    attributes=attributes,
                    kind=SpanKind.SERVER,
                )
            finally:
                if token is not None:
                    _ROOT_TRACE_ID.reset(token)

        # F4c — the ONE-trace_id rule, by construction: unless the caller chose its own business id
        # (e.g. the test suite's test_*), the logged trace_id IS the Jaeger trace id, and span_id IS
        # this server span. trace_ctx is the object already stored by set_trace_context above, so
        # every later get_current_trace_context() in this request sees the rebound ids.
        if span is not None and OPENTELEMETRY_AVAILABLE:
            _sc = span.get_span_context()
            if _sc.is_valid:
                _otel_tid = format(_sc.trace_id, "032x")
                if not trace_ctx.inbound_trace_id or trace_ctx.trace_id == _otel_tid:
                    trace_ctx.trace_id = _otel_tid
                trace_ctx.span_id = format(_sc.span_id, "016x")
                span.set_attribute("custom.trace_id", trace_ctx.trace_id)
                span.set_attribute("custom.span_id", trace_ctx.span_id)

        start_time = time.time()

        try:
            # Process request with span as current (for proper parent-child relationships)
            if span and OPENTELEMETRY_AVAILABLE:
                from opentelemetry import trace
                with trace.use_span(span, end_on_exit=False):
                    response = await call_next(request)
            else:
                response = await call_next(request)

            duration_ms = (time.time() - start_time) * 1000
            # C-04b: a 5xx sent through nginx leaves with a code and fixed words; its body goes to the C-01 line.
            response, scrubbed_detail = await scrub_5xx(request, response)

            # Add trace headers to response
            response.headers["X-Trace-ID"] = trace_ctx.trace_id
            response.headers["X-Span-ID"] = trace_ctx.span_id
            response.headers["X-Request-ID"] = trace_ctx.trace_id

            # # Log request completion with trace context
            # logger.info(
            #     "request_completed",
            #     **trace_ctx.to_log_context(),
            #     http_method=request.method,
            #     http_path=request.url.path,
            #     http_status=response.status_code,
            #     duration_ms=round(duration_ms, 2),
            # )

            # End span with success
            if span and span_manager:
                _name_span_by_route(span, request)
                span_manager.end_span(
                    span,
                    status_code=response.status_code,
                    attributes={"http.status_code": response.status_code,
                                "torana.tenant": _request_tenant(request)},
                )

            self._log_completion(request, response.status_code, duration_ms, trace_ctx, detail=scrubbed_detail)

            return response

        except Exception as e:
            duration_ms = (time.time() - start_time) * 1000

            # Log error with trace context
            logger.error(
                "request_failed",
                **trace_ctx.to_log_context(),
                request_id=request.headers.get("x-request-id"),
                http_method=request.method,
                http_path=request.url.path,
                error=str(e),
                error_type=type(e).__name__,
                duration_ms=round(duration_ms, 2),
            )
            # C-01: the exception escapes and is answered 500 OUTSIDE this middleware, so
            # `_log_completion` never sees it; this is the request's one failure line.
            _log_request_failure(request, error_code="api.unhandled_exception", http_status=500,
                                 detail=f"{type(e).__name__}: {e}")

            # End span with error
            if span and span_manager:
                _name_span_by_route(span, request)
                span_manager.end_span(
                    span,
                    error=e,
                    attributes={"error": True, "error.message": str(e),
                                "torana.tenant": _request_tenant(request)},
                )

            raise

        finally:
            # Always clear trace context after request
            clear_trace_context()
