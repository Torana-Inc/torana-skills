"""
FastAPI middleware for distributed tracing.

Automatically extracts trace context from incoming requests and creates spans.
"""

import os
import time
from typing import Callable, Optional, List, TYPE_CHECKING, Set

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp
from starlette.requests import Request
from starlette.responses import Response

from .context import (
    set_trace_context,
    clear_trace_context,
)
from .propagation import extract_trace_context
from .spans import OPENTELEMETRY_AVAILABLE

import structlog

if TYPE_CHECKING:
    from .spans import SpanManager

logger = structlog.get_logger(__name__)

# Global span manager storage - shared across all middleware instances
_global_span_manager: Optional["SpanManager"] = None


def get_global_span_manager() -> Optional["SpanManager"]:
    """Get the global span manager."""
    return _global_span_manager


def set_global_span_manager(span_manager: "SpanManager") -> None:
    """Set the global span manager."""
    global _global_span_manager
    _global_span_manager = span_manager


def _parse_status_codes(env_value: Optional[str]) -> Set[int]:
    """Parse comma-separated HTTP status codes into a set of ints."""
    if not env_value:
        return set()
    codes: Set[int] = set()
    for token in env_value.split(","):
        token = token.strip()
        if not token:
            continue
        try:
            codes.add(int(token))
        except ValueError:
            logger.warning(
                "invalid_http_status_code_config",
                value=token,
            )
    return codes


class TracingMiddleware(BaseHTTPMiddleware):
    """
    Middleware that handles distributed tracing for all incoming requests.

    Features:
    - Extracts trace context from incoming headers (or generates new)
    - Creates spans for each request
    - Injects trace context into response headers
    - Records timing and status information

    Usage:
        ```python
        from pantheon_shared.tracing import TracingMiddleware, setup_tracing

        app = FastAPI()

        # In lifespan - store span_manager in app.state
        app.state.span_manager = setup_tracing(TracingConfig.from_env("my-service"))

        # Add middleware - pass app reference to get span_manager dynamically
        app.add_middleware(
            TracingMiddleware,
            service_name="my-service",
        )
        ```
    """

    def __init__(
        self,
        app: ASGIApp,
        service_name: str,
        exclude_paths: Optional[List[str]] = None,
    ):
        super().__init__(app)
        self.app = app  # Store app reference to get span_manager dynamically
        self.service_name = service_name
        self.exclude_paths = exclude_paths or [
            "/health",
            "/healthz",
            "/ready",
            "/metrics",
            "/api/v1/health",
        ]
        self.warn_status_codes = _parse_status_codes(
            os.getenv("PANTHEON_HTTP_LOG_WARN_CODES")
        )
        self.error_status_codes = _parse_status_codes(
            os.getenv("PANTHEON_HTTP_LOG_ERROR_CODES")
        )

    def _get_span_manager(self) -> Optional["SpanManager"]:
        """Get span_manager from global storage if available."""
        return get_global_span_manager()

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        # Check if tracing is dynamically disabled (skip all tracing logic)
        from .state import is_tracing_enabled
        if not is_tracing_enabled():
            # Tracing is disabled, just pass through
            return await call_next(request)

        # Skip tracing for health checks and metrics
        if any(request.url.path.startswith(path) for path in self.exclude_paths):
            return await call_next(request)

        # Extract or create trace context
        trace_ctx = extract_trace_context(
            headers=dict(request.headers),
            service_name=self.service_name,
            operation_name=f"{request.method} {request.url.path}",
        )

        # Store in contextvar for access throughout request lifecycle
        set_trace_context(trace_ctx)

        # Start span if span manager is available
        span_manager = self._get_span_manager()
        span = None
        if span_manager:
            from opentelemetry import trace
            span = span_manager.start_span(
                name=f"{request.method} {request.url.path}",
                trace_ctx=trace_ctx,
                attributes={
                    "http.method": request.method,
                    "http.url": str(request.url),
                    "http.route": request.url.path,
                    "http.host": request.headers.get("host", ""),
                    "service.name": self.service_name,
                },
            )

        start_time = time.time()

        try:
            # Process request with span as current (for proper parent-child relationships)
            if span and OPENTELEMETRY_AVAILABLE:
                from opentelemetry import trace
                with trace.use_span(span, end_on_exit=False):
                    response = await call_next(request)
            else:
                response = await call_next(request)

            duration_ms = (time.time() - start_time) * 1000

            # Add trace headers to response
            response.headers["X-Trace-ID"] = trace_ctx.trace_id
            response.headers["X-Span-ID"] = trace_ctx.span_id
            response.headers["X-Request-ID"] = trace_ctx.trace_id

            # # Log request completion with trace context
            # logger.info(
            #     "request_completed",
            #     **trace_ctx.to_log_context(),
            #     http_method=request.method,
            #     http_path=request.url.path,
            #     http_status=response.status_code,
            #     duration_ms=round(duration_ms, 2),
            # )

            # End span with success
            if span and span_manager:
                span_manager.end_span(
                    span,
                    status_code=response.status_code,
                    attributes={"http.status_code": response.status_code},
                )

            if response.status_code in self.error_status_codes:
                logger.error(
                    "http_response_error",
                    **trace_ctx.to_log_context(),
                    http_method=request.method,
                    http_path=request.url.path,
                    http_status=response.status_code,
                    duration_ms=round(duration_ms, 2),
                )
            elif response.status_code in self.warn_status_codes:
                logger.warning(
                    "http_response_warning",
                    **trace_ctx.to_log_context(),
                    http_method=request.method,
                    http_path=request.url.path,
                    http_status=response.status_code,
                    duration_ms=round(duration_ms, 2),
                )

            return response

        except Exception as e:
            duration_ms = (time.time() - start_time) * 1000

            # Log error with trace context
            logger.error(
                "request_failed",
                **trace_ctx.to_log_context(),
                http_method=request.method,
                http_path=request.url.path,
                error=str(e),
                error_type=type(e).__name__,
                duration_ms=round(duration_ms, 2),
            )

            # End span with error
            if span and span_manager:
                span_manager.end_span(
                    span,
                    error=e,
                    attributes={"error": True, "error.message": str(e)},
                )

            raise

        finally:
            # Always clear trace context after request
            clear_trace_context()
