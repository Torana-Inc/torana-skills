"""
Global tracing state management for process-scoped tracing control.

Provides a simple boolean flag for enabling/disabling tracing dynamically
without service restart. This is process-scoped (per service instance).
"""

_tracing_enabled: bool = True


def is_tracing_enabled() -> bool:
    """Check if tracing is currently enabled."""
    return _tracing_enabled


def set_tracing_enabled(enabled: bool) -> None:
    """
    Enable or disable tracing dynamically.

    This function can be called via API endpoint to control tracing without
    restarting the service. Changes take effect immediately on the next request.

    Args:
        enabled: True to enable tracing, False to disable
    """
    global _tracing_enabled
    _tracing_enabled = enabled
