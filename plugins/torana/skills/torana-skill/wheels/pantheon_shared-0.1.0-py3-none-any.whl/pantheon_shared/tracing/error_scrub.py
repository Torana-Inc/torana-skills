"""C-04b: a 5xx answered through nginx carries an error code and fixed words, never exception text.

The scrub runs in `TracingMiddleware`, which every API service mounts. It touches a response only when BOTH hold:
- its status is 5xx, and
- the request came through nginx (`X-Real-IP` set; the same test as C-04's `_edge_reference`).
East-west bodies stay as they are: agent repair loops read a 5xx `detail` (Bhakta's ruling A, 2026-11-05).

What happens to a scrubbed response:
- a JSON body `{"error": <code in USER_FACING_5XX>, "message": str}` (or the same under `detail`) passes unchanged;
- any other body (JSON, plain text, HTML from a proxy) becomes `{"detail": <words>, "error": <code>}`, and its
  original text goes to the request's C-01 `api.request.failed` line as `error_detail` (redacted, <= 300 chars);
- a body that is a stream (`text/event-stream`, `application/x-ndjson`), unsized or larger than MAX_READ_BYTES is
  NEVER read: it is closed unread and replaced; the log line says it was not read.
Status code and every other header stay as they were.
"""
from __future__ import annotations

import json
from typing import Optional, Tuple

from starlette.requests import Request
from starlette.responses import Response

#: 5xx codes whose `message` a service writes FOR USERS: such a body passes unchanged. Each message is fixed words
#: (or a status number); none embeds exception text. The same literal is pinned in pantheon-cli
#: `torana_cli/client/error_words.py` and pantheon-fe `shared/error-words.ts` (filled there in C-04b S2).
USER_FACING_5XX: frozenset = frozenset({
    "extractor_unavailable",         # integration upgrade_cards.py, knowledge atlas_api_diffs.py (503)
    "eligibility_unavailable",       # same two files (502)
    "namespace_lookup_unavailable",  # agent-builder context_lake.py (503)
    "app_not_configured",            # integration github_app.py (503)
})

#: The words a scrubbed body carries. Same sentences as the CLI's and FE's HAPPENED_5XX (C-04 S1).
SCRUBBED_WORDS = {
    "api.internal_error": "Something failed on Torana's side.",
    "api.upstream_error": "A Torana service did not answer.",
}

#: The largest 5xx body read for the log line. FastAPI's error bodies are a few hundred bytes.
MAX_READ_BYTES = 65536
_STREAM_TYPES = ("text/event-stream", "application/x-ndjson")


def code_for_status(status: int) -> str:
    """502/503/504 are a dependency failing; any other 5xx is ours."""
    return "api.upstream_error" if status in (502, 503, 504) else "api.internal_error"


def came_through_nginx(request: Request) -> bool:
    """nginx sets X-Real-IP on every proxied location (includes/proxy_headers.conf); east-west calls do not."""
    try:
        return bool(request.headers.get("x-real-ip"))
    except Exception:  # noqa: BLE001
        return False


def is_user_facing(body: bytes) -> bool:
    """True for `{"error": <listed code>, "message": str}`, top level or under `detail`."""
    try:
        doc = json.loads(body)
    except (ValueError, UnicodeDecodeError):
        return False
    if not isinstance(doc, dict):
        return False
    inner = doc.get("detail") if isinstance(doc.get("detail"), dict) else doc
    return inner.get("error") in USER_FACING_5XX and isinstance(inner.get("message"), str)


def _rebuilt(response: Response, body: bytes, content_type: str) -> Response:
    """Same status and headers (incl. repeated ones such as set-cookie), new body and its length and type."""
    out = Response(content=body, status_code=response.status_code)
    keep = [(k, v) for k, v in response.raw_headers if k.lower() not in (b"content-length", b"content-type")]
    out.raw_headers = keep + [(b"content-length", str(len(body)).encode("latin-1")),
                              (b"content-type", content_type.encode("latin-1"))]
    return out


async def _close_unread(response: Response) -> None:
    iterator = getattr(response, "body_iterator", None)
    aclose = getattr(iterator, "aclose", None)
    if aclose is not None:
        try:
            await aclose()
        except Exception:  # noqa: BLE001 — closing must never fail the request
            pass


async def scrub_5xx(request: Request, response: Response) -> Tuple[Response, Optional[str]]:
    """(the response to send, the original body for the log line or None). Never raises."""
    try:
        status = response.status_code
        if status < 500 or not came_through_nginx(request):
            return response, None
        code = code_for_status(status)
        words = json.dumps({"detail": SCRUBBED_WORDS[code], "error": code}).encode()
        ctype = response.headers.get("content-type", "")
        size = response.headers.get("content-length", "")
        if ctype.startswith(_STREAM_TYPES) or not size.isdigit() or int(size) > MAX_READ_BYTES:
            await _close_unread(response)
            return (_rebuilt(response, words, "application/json"),
                    f"<5xx body not read: content-type={ctype or '-'} content-length={size or 'unsized'}>")
        body = b"".join([chunk async for chunk in response.body_iterator])
        if ctype.startswith("application/json") and is_user_facing(body):
            return _rebuilt(response, body, ctype), None
        return _rebuilt(response, words, "application/json"), body.decode("utf-8", "replace")
    except Exception as exc:  # noqa: BLE001 — a scrub failure must not leak either: send the words
        code = code_for_status(getattr(response, "status_code", 500))
        return (_rebuilt(response, json.dumps({"detail": SCRUBBED_WORDS[code], "error": code}).encode(),
                         "application/json"),
                f"<5xx scrub failed: {type(exc).__name__}>")
