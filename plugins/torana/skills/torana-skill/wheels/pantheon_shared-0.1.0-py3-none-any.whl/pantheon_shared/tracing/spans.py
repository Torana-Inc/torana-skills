"""
OpenTelemetry span management for Jaeger integration.

Provides SpanManager class for creating and managing spans that are
exported to Jaeger via OTLP protocol.
"""

from typing import Any, Dict, Optional

import structlog

from .context import TraceContext

logger = structlog.get_logger(__name__)

# OpenTelemetry imports - these are optional dependencies
# If not installed, SpanManager will work but won't create actual spans
try:
    from opentelemetry import trace, context
    from opentelemetry.sdk.trace import TracerProvider, Span
    from opentelemetry.sdk.trace.export import BatchSpanProcessor, SimpleSpanProcessor, ConsoleSpanExporter
    from opentelemetry.sdk.resources import Resource, SERVICE_NAME
    from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
    from opentelemetry.trace import Status, StatusCode, Link, SpanContext, TraceFlags, NonRecordingSpan
    from opentelemetry.trace.span import INVALID_SPAN_CONTEXT
    from opentelemetry.propagators.textmap import TextMapPropagator
    from opentelemetry.sdk.trace.id_generator import IdGenerator
    OPENTELEMETRY_AVAILABLE = True
except ImportError:
    OPENTELEMETRY_AVAILABLE = False
    Span = None  # type: ignore
    SpanContext = None  # type: ignore
    TraceFlags = None  # type: ignore
    Link = None  # type: ignore
    NonRecordingSpan = None  # type: ignore
    INVALID_SPAN_CONTEXT = None  # type: ignore


class SpanManager:
    """
    Manages OpenTelemetry spans and exports them to Jaeger.

    Provides a simple interface for creating and managing spans
    that automatically link to the trace context.

    If OpenTelemetry is not installed, the manager will still work
    but won't create actual spans (graceful degradation).

    Usage:
        ```python
        span_manager = SpanManager(
            service_name="my-service",
            otlp_endpoint="jaeger:4317",
        )

        span = span_manager.start_span("my_operation", trace_ctx)
        try:
            # do work
            span_manager.end_span(span, status_code=200)
        except Exception as e:
            span_manager.end_span(span, error=e)
        ```
    """

    def __init__(
        self,
        service_name: str,
        otlp_endpoint: Optional[str] = None,
        enable_console: bool = False,
        use_simple_processor: bool = False,  # For immediate export (dev/testing)
    ):
        self.service_name = service_name
        self.tracer = None
        self._setup_tracer(otlp_endpoint, enable_console, use_simple_processor)

    def _setup_tracer(
        self,
        otlp_endpoint: Optional[str],
        enable_console: bool,
        use_simple_processor: bool,
    ) -> None:
        """Configure OpenTelemetry tracer with exporters."""

        if not OPENTELEMETRY_AVAILABLE:
            logger.warning(
                "OpenTelemetry not installed - spans will not be created",
                service=self.service_name,
                hint="pip install opentelemetry-api opentelemetry-sdk opentelemetry-exporter-otlp-proto-grpc"
            )
            return

        if not otlp_endpoint and not enable_console:
            logger.debug(
                "Tracing disabled - no exporters configured",
                service=self.service_name,
            )
            return

        # Create resource with service name
        resource = Resource(attributes={
            SERVICE_NAME: self.service_name
        })

        # Create tracer provider
        provider = TracerProvider(resource=resource)

        # Add OTLP exporter for Jaeger
        if otlp_endpoint:
            try:
                otlp_exporter = OTLPSpanExporter(
                    endpoint=otlp_endpoint,
                    insecure=True,  # For local development
                )
                # Use SimpleSpanProcessor for immediate export (useful for dev/testing)
                # BatchSpanProcessor batches spans for better performance but delays export
                if use_simple_processor:
                    provider.add_span_processor(SimpleSpanProcessor(otlp_exporter))
                    logger.debug(
                        "OTLP exporter configured (SimpleProcessor - immediate export)",
                        endpoint=otlp_endpoint,
                        service=self.service_name,
                    )
                else:
                    provider.add_span_processor(BatchSpanProcessor(otlp_exporter))
                    logger.debug(
                        "OTLP exporter configured (BatchProcessor - batches spans)",
                        endpoint=otlp_endpoint,
                        service=self.service_name,
                    )
            except Exception as e:
                logger.error(
                    "Failed to configure OTLP exporter",
                    error=str(e),
                    service=self.service_name,
                )

        # Add console exporter for debugging
        if enable_console:
            if use_simple_processor:
                provider.add_span_processor(SimpleSpanProcessor(ConsoleSpanExporter()))
            else:
                provider.add_span_processor(BatchSpanProcessor(ConsoleSpanExporter()))
            logger.debug(
                "Console span exporter enabled",
                service=self.service_name,
            )

        # Set as global tracer provider
        trace.set_tracer_provider(provider)

        # Get tracer for this service
        self.tracer = trace.get_tracer(self.service_name)

    def _create_span_context(
        self, trace_id: str, span_id: str
    ) -> Optional[SpanContext]:
        """Create an OpenTelemetry SpanContext from trace_id and span_id."""
        if not OPENTELEMETRY_AVAILABLE:
            return None

        try:
            # Convert hex string trace_id (32 chars) and span_id (16 chars) to bytes, then to int
            # OpenTelemetry SpanContext expects integers, not bytes
            trace_id_int = int.from_bytes(bytes.fromhex(trace_id), byteorder='big')
            span_id_int = int.from_bytes(bytes.fromhex(span_id), byteorder='big')
        except (ValueError, TypeError):
            # Generate valid hex trace/span IDs if provided ones are invalid
            # This allows tests to use human-readable trace IDs like "test_tt_05"
            # while still enabling OpenTelemetry tracing
            import uuid

            trace_id_int = int.from_bytes(bytes.fromhex(uuid.uuid4().hex), byteorder='big')
            span_id_int = int.from_bytes(bytes.fromhex(uuid.uuid4().hex[:16]), byteorder='big')

        return SpanContext(
            trace_id=trace_id_int,
            span_id=span_id_int,
            is_remote=True,  # Mark as remote since we're reconstructing from headers
            trace_flags=TraceFlags(0x01),  # Sampled flag
        )

    def start_span(
        self,
        name: str,
        trace_ctx: TraceContext,
        attributes: Optional[Dict[str, Any]] = None,
    ) -> Optional[Span]:
        """
        Start a new span linked to the trace context.

        This method properly creates child spans by:
        1. Using current OpenTelemetry span as parent if available (automatic trace_id propagation)
        2. Otherwise creating a parent link from custom trace_ctx

        Args:
            name: Name of the span (e.g., "GET /api/v1/users")
            trace_ctx: Current trace context
            attributes: Additional span attributes

        Returns:
            OpenTelemetry Span object or None if tracing disabled
        """
        if not self.tracer:
            return None

        span_attrs = {
            "service.name": trace_ctx.service_name or self.service_name,
            "custom.trace_id": trace_ctx.trace_id,
            "custom.span_id": trace_ctx.span_id,
            "custom.parent_span_id": trace_ctx.parent_span_id or "",
            **(attributes or {}),
        }

        # First, try to use current OpenTelemetry span as parent (proper child span)
        current_span = trace.get_current_span()
        if current_span and current_span.is_recording():
            # This will automatically create a child span with same trace_id
            span = self.tracer.start_span(
                name=name,
                attributes=span_attrs,
            )
            return span

        # Fallback: If no current span but we have parent info, create a link
        # (Note: Links don't create parent-child relationship, but show correlation)
        links = []
        if trace_ctx.parent_span_id:
            parent_context = self._create_span_context(
                trace_ctx.trace_id, trace_ctx.parent_span_id
            )
            if parent_context and parent_context != INVALID_SPAN_CONTEXT:
                links.append(Link(parent_context))

        span = self.tracer.start_span(
            name=name,
            attributes=span_attrs,
            links=links if links else None,
        )

        return span

    def end_span(
        self,
        span: Optional[Span],
        status_code: Optional[int] = None,
        error: Optional[Exception] = None,
        attributes: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        End a span with status information.

        Args:
            span: The span to end
            status_code: HTTP status code (if applicable)
            error: Exception if the operation failed
            attributes: Additional attributes to add before ending
        """
        if not span or not OPENTELEMETRY_AVAILABLE:
            return

        # Add any additional attributes
        if attributes:
            for key, value in attributes.items():
                span.set_attribute(key, value)

        # Set status based on error or status code
        if error:
            span.set_status(Status(StatusCode.ERROR, str(error)))
            span.record_exception(error)
        elif status_code and status_code >= 400:
            span.set_status(Status(StatusCode.ERROR, f"HTTP {status_code}"))
        else:
            span.set_status(Status(StatusCode.OK))

        span.end()
