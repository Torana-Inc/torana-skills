"""
OpenTelemetry span management for Jaeger integration.

Provides SpanManager class for creating and managing spans that are
exported to Jaeger via OTLP protocol.
"""

from typing import Any, Dict, Optional

import structlog

from .context import TraceContext

logger = structlog.get_logger(__name__)

# OpenTelemetry imports - these are optional dependencies
# If not installed, SpanManager will work but won't create actual spans
try:
    from opentelemetry import trace, context
    from opentelemetry.sdk.trace import TracerProvider, Span
    from opentelemetry.sdk.trace.export import BatchSpanProcessor, SimpleSpanProcessor, ConsoleSpanExporter
    from opentelemetry.sdk.resources import Resource, SERVICE_NAME
    from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
    from opentelemetry.trace import Status, StatusCode, SpanContext, SpanKind, TraceFlags, NonRecordingSpan
    from opentelemetry.propagators.textmap import TextMapPropagator
    from opentelemetry.sdk.trace.id_generator import IdGenerator
    from opentelemetry.sdk.trace.sampling import ParentBased, TraceIdRatioBased
    OPENTELEMETRY_AVAILABLE = True
except ImportError:
    OPENTELEMETRY_AVAILABLE = False
    Span = None  # type: ignore
    SpanContext = None  # type: ignore
    TraceFlags = None  # type: ignore
    SpanKind = None  # type: ignore
    NonRecordingSpan = None  # type: ignore


class SpanManager:
    """
    Manages OpenTelemetry spans and exports them to Jaeger.

    Provides a simple interface for creating and managing spans
    that automatically link to the trace context.

    If OpenTelemetry is not installed, the manager will still work
    but won't create actual spans (graceful degradation).

    Usage:
        ```python
        span_manager = SpanManager(
            service_name="my-service",
            otlp_endpoint="jaeger:4317",
        )

        span = span_manager.start_span("my_operation", trace_ctx)
        try:
            # do work
            span_manager.end_span(span, status_code=200)
        except Exception as e:
            span_manager.end_span(span, error=e)
        ```
    """

    def __init__(
        self,
        service_name: str,
        otlp_endpoint: Optional[str] = None,
        enable_console: bool = False,
        use_simple_processor: bool = False,  # For immediate export (dev/testing)
        sample_rate: float = 1.0,
    ):
        self.service_name = service_name
        self.tracer = None
        self._setup_tracer(otlp_endpoint, enable_console, use_simple_processor, sample_rate)

    def _setup_tracer(
        self,
        otlp_endpoint: Optional[str],
        enable_console: bool,
        use_simple_processor: bool,
        sample_rate: float = 1.0,
    ) -> None:
        """Configure OpenTelemetry tracer with exporters."""

        if not OPENTELEMETRY_AVAILABLE:
            logger.warning(
                "OpenTelemetry not installed - spans will not be created",
                service=self.service_name,
                hint="pip install opentelemetry-api opentelemetry-sdk opentelemetry-exporter-otlp-proto-grpc"
            )
            return

        if not otlp_endpoint and not enable_console:
            logger.debug(
                "Tracing disabled - no exporters configured",
                service=self.service_name,
            )
            return

        # Create resource with service name
        resource = Resource(attributes={
            SERVICE_NAME: self.service_name
        })

        # Parent-based (F32): a root is kept with probability sample_rate; a span with a parent follows
        # the parent's decision, so a hop never breaks a trace the caller kept. At 1.0 this equals the
        # SDK default, ParentBased(ALWAYS_ON).
        provider = TracerProvider(
            resource=resource,
            sampler=ParentBased(root=TraceIdRatioBased(sample_rate)),
        )

        # Add OTLP exporter for Jaeger
        if otlp_endpoint:
            try:
                otlp_exporter = OTLPSpanExporter(
                    endpoint=otlp_endpoint,
                    insecure=True,  # For local development
                )
                # Use SimpleSpanProcessor for immediate export (useful for dev/testing)
                # BatchSpanProcessor batches spans for better performance but delays export
                if use_simple_processor:
                    provider.add_span_processor(SimpleSpanProcessor(otlp_exporter))
                    logger.debug(
                        "OTLP exporter configured (SimpleProcessor - immediate export)",
                        endpoint=otlp_endpoint,
                        service=self.service_name,
                    )
                else:
                    provider.add_span_processor(BatchSpanProcessor(otlp_exporter))
                    logger.debug(
                        "OTLP exporter configured (BatchProcessor - batches spans)",
                        endpoint=otlp_endpoint,
                        service=self.service_name,
                    )
            except Exception as e:
                logger.error(
                    "Failed to configure OTLP exporter",
                    error=str(e),
                    service=self.service_name,
                )

        # Add console exporter for debugging
        if enable_console:
            if use_simple_processor:
                provider.add_span_processor(SimpleSpanProcessor(ConsoleSpanExporter()))
            else:
                provider.add_span_processor(BatchSpanProcessor(ConsoleSpanExporter()))
            logger.debug(
                "Console span exporter enabled",
                service=self.service_name,
            )

        # Set as global tracer provider
        trace.set_tracer_provider(provider)

        # Tracer from THIS provider: the global one can be set only once per process, so a second
        # SpanManager would otherwise get the first provider's sampler and exporters.
        self.tracer = provider.get_tracer(self.service_name)

    def start_span(
        self,
        name: str,
        trace_ctx: TraceContext,
        attributes: Optional[Dict[str, Any]] = None,
        kind: Optional["SpanKind"] = None,
    ) -> Optional[Span]:
        """
        Start a new span for the trace context.

        Parentage, in order:
        1. The current in-process OTel span (a child within this service).
        2. The REMOTE caller from the inbound ``traceparent`` (``trace_ctx.otel_trace_id`` /
           ``otel_parent_span_id``, set by ``extract_trace_context``), so the hop joins the caller's
           Jaeger trace (F4a).
        3. Otherwise a root span.

        Args:
            name: Name of the span (e.g., "GET /api/v1/users")
            trace_ctx: Current trace context
            attributes: Additional span attributes
            kind: OTel SpanKind (default INTERNAL; the middleware passes SERVER)

        Returns:
            OpenTelemetry Span object or None if tracing disabled
        """
        if not self.tracer:
            return None

        span_kind = kind or SpanKind.INTERNAL
        span_attrs = {
            "service.name": trace_ctx.service_name or self.service_name,
            "custom.trace_id": trace_ctx.trace_id,
            "custom.span_id": trace_ctx.span_id,
            "custom.parent_span_id": trace_ctx.parent_span_id or "",
            **(attributes or {}),
        }

        current_span = trace.get_current_span()
        if current_span and current_span.is_recording():
            # Child of the in-process span (same trace_id).
            return self.tracer.start_span(name=name, attributes=span_attrs, kind=span_kind)

        if trace_ctx.otel_trace_id and trace_ctx.otel_parent_span_id:
            remote = SpanContext(
                trace_id=int(trace_ctx.otel_trace_id, 16),
                span_id=int(trace_ctx.otel_parent_span_id, 16),
                is_remote=True,
                trace_flags=TraceFlags(TraceFlags.SAMPLED if trace_ctx.sampled else TraceFlags.DEFAULT),
            )
            return self.tracer.start_span(
                name=name,
                attributes=span_attrs,
                kind=span_kind,
                context=trace.set_span_in_context(NonRecordingSpan(remote)),
            )

        # No usable remote parent (sess_*/test_* business ids, header-less requests): a root.
        return self.tracer.start_span(name=name, attributes=span_attrs, kind=span_kind)

    def end_span(
        self,
        span: Optional[Span],
        status_code: Optional[int] = None,
        error: Optional[Exception] = None,
        attributes: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        End a span with status information.

        Args:
            span: The span to end
            status_code: HTTP status code (if applicable)
            error: Exception if the operation failed
            attributes: Additional attributes to add before ending
        """
        if not span or not OPENTELEMETRY_AVAILABLE:
            return

        # Add any additional attributes
        if attributes:
            for key, value in attributes.items():
                span.set_attribute(key, value)

        # Set status based on error or status code
        if error:
            span.set_status(Status(StatusCode.ERROR, str(error)))
            span.record_exception(error)
        elif status_code and status_code >= 400:
            span.set_status(Status(StatusCode.ERROR, f"HTTP {status_code}"))
        else:
            span.set_status(Status(StatusCode.OK))

        span.end()
