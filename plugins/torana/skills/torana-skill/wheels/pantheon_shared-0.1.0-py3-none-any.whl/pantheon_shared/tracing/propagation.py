"""
Trace context propagation utilities.

Handles extraction from incoming headers and injection into outgoing headers.
Supports W3C Trace Context standard and fallback headers.
"""

import re
from typing import Dict, Optional

from .context import TraceContext


# W3C Trace Context regex
# Format: {version}-{trace_id}-{span_id}-{flags}
# Example: 00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01
TRACEPARENT_REGEX = re.compile(
    r"^(?P<version>[0-9a-f]{2})-"
    r"(?P<trace_id>[0-9a-f]{32})-"
    r"(?P<span_id>[0-9a-f]{16})-"
    r"(?P<flags>[0-9a-f]{2})$"
)


def extract_trace_context(
    headers: Dict[str, str],
    service_name: str,
    operation_name: Optional[str] = None,
) -> TraceContext:
    """
    Extract trace context from incoming HTTP headers.

    Supports:
    - W3C Trace Context (traceparent header)
    - Simple X-Trace-ID / X-Span-ID headers
    - Legacy X-Request-ID header

    If no trace context is found, creates a new root trace.

    Args:
        headers: HTTP headers dictionary (case-insensitive keys recommended)
        service_name: Name of the current service
        operation_name: Name of the operation (e.g., endpoint path)

    Returns:
        TraceContext object for this request
    """
    # Normalize header keys to lowercase for consistent lookup
    normalized = {k.lower(): v for k, v in headers.items()}

    trace_id = None
    parent_span_id = None
    sampled = True

    # Try W3C Trace Context first (most standard)
    traceparent = normalized.get("traceparent")
    if traceparent:
        match = TRACEPARENT_REGEX.match(traceparent)
        if match:
            trace_id = match.group("trace_id")
            parent_span_id = match.group("span_id")
            sampled = match.group("flags") == "01"

    # Fallback to simple headers
    if not trace_id:
        trace_id = (
            normalized.get("x-trace-id") or
            normalized.get("x-request-id")
        )
        parent_span_id = normalized.get("x-span-id")

    # Create appropriate context
    if trace_id and parent_span_id:
        # Child span - we have a parent
        return TraceContext.from_parent(
            parent_trace_id=trace_id,
            parent_span_id=parent_span_id,
            service_name=service_name,
            operation_name=operation_name,
            sampled=sampled,
        )
    elif trace_id:
        # We have a trace_id but no parent span - treat as continuation
        # Use first 16 chars of trace_id as pseudo-parent for linking
        return TraceContext.from_parent(
            parent_trace_id=trace_id,
            parent_span_id=trace_id[:16],
            service_name=service_name,
            operation_name=operation_name,
            sampled=sampled,
        )
    else:
        # No trace context - create new root trace
        return TraceContext.new(
            service_name=service_name,
            operation_name=operation_name,
        )


def inject_trace_headers(
    headers: Dict[str, str],
    trace_ctx: Optional[TraceContext] = None,
) -> Dict[str, str]:
    """
    Inject trace context headers for outgoing requests.

    If no trace_ctx is provided, attempts to get current context from contextvar.

    Args:
        headers: Existing headers dictionary to update
        trace_ctx: Optional TraceContext (uses current context if not provided)

    Returns:
        Updated headers dictionary with trace headers
    """
    from .context import get_current_trace_context

    if trace_ctx is None:
        trace_ctx = get_current_trace_context()

    if trace_ctx:
        headers.update(trace_ctx.to_headers())

    return headers
