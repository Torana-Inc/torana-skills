"""
Trace context propagation utilities.

Handles extraction from incoming headers and injection into outgoing headers.

Two ids travel on the wire, and they are kept apart (F4, see
pantheon-shared/docs/F4_TRACE_PARENTING_SPEC.md § 3.2.2):
- ``traceparent`` (W3C) carries OTel ids ONLY. It alone decides Jaeger parentage.
- ``X-Trace-ID`` carries the business trace id, the one every log line shows. It is usually equal to
  the OTel trace id. It differs only for a caller-chosen id such as the test suite's ``test_*``.
"""

import re
import uuid
from typing import Dict, Optional, Tuple

from .context import TraceContext


# W3C Trace Context regex
# Format: {version}-{trace_id}-{span_id}-{flags}
# Example: 00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01
TRACEPARENT_REGEX = re.compile(
    r"^(?P<version>[0-9a-f]{2})-"
    r"(?P<trace_id>[0-9a-f]{32})-"
    r"(?P<span_id>[0-9a-f]{16})-"
    r"(?P<flags>[0-9a-f]{2})$"
)

_HEX32 = re.compile(r"^[0-9a-f]{32}$")
_HEX16 = re.compile(r"^[0-9a-f]{16}$")
_DASHED_UUID = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")
# Business ids and session/turn labels end up in log lines, Loki labels and Grafana links: accept
# only this charset so a header cannot inject a newline or a LogQL fragment.
_SAFE_ID = re.compile(r"^[A-Za-z0-9_.:\-]{1,128}$")


def is_otel_trace_id(value: Optional[str]) -> bool:
    """True for a valid (non-zero) 32-hex OTel trace id."""
    return bool(value) and bool(_HEX32.match(value)) and value != "0" * 32


def is_otel_span_id(value: Optional[str]) -> bool:
    """True for a valid (non-zero) 16-hex OTel span id."""
    return bool(value) and bool(_HEX16.match(value)) and value != "0" * 16


def normalize_trace_id(raw: Optional[str]) -> Optional[str]:
    """Business trace id from a header.

    A dashed UUID (what pre-F4 PantheonClient sent with no context) becomes 32-hex, so it fits the
    String(32) columns and opens in Jaeger (F29). A 32-hex id is lower-cased. Any other well-formed
    id (``test_*``, ``sess_*``) is kept verbatim. A malformed one is dropped.
    """
    if not raw:
        return None
    s = raw.strip()
    low = s.lower()
    if _DASHED_UUID.match(low):
        return low.replace("-", "")
    if _HEX32.match(low):
        return low
    return s if _SAFE_ID.match(s) else None


def _safe_label(raw: Optional[str]) -> Optional[str]:
    s = (raw or "").strip()
    return s if s and _SAFE_ID.match(s) else None


def _current_otel_ids() -> Optional[Tuple[str, str, bool]]:
    """(trace_hex, span_hex, sampled) of the current OTel span, or None."""
    try:
        from opentelemetry import trace
        sc = trace.get_current_span().get_span_context()
        if sc.is_valid:
            return format(sc.trace_id, "032x"), format(sc.span_id, "016x"), bool(sc.trace_flags & 0x01)
    except Exception:
        pass
    return None


def extract_trace_context(
    headers: Dict[str, str],
    service_name: str,
    operation_name: Optional[str] = None,
) -> TraceContext:
    """
    Extract trace context from incoming HTTP headers.

    - OTel parent: from a valid ``traceparent``. For a legacy sender with no usable traceparent,
      from a hex (or de-hyphenated) ``X-Trace-ID`` plus ``X-Span-ID`` (or the id's first 16 chars).
    - Business trace id: ``X-Trace-ID`` / ``X-Request-ID`` when present and well-formed, else the
      traceparent's trace id, else a new one (the middleware then rebinds it to the OTel id).
    - ``X-Session-ID`` / ``X-Turn-ID`` become the context's session_id / turn_id.

    Never raises on malformed input: a bad header is ignored.
    """
    normalized = {k.lower(): v for k, v in headers.items()}

    otel_trace_id: Optional[str] = None
    otel_parent: Optional[str] = None
    sampled = True

    tp = (normalized.get("traceparent") or "").strip().lower()
    match = TRACEPARENT_REGEX.match(tp) if tp else None
    if match and is_otel_trace_id(match.group("trace_id")) and is_otel_span_id(match.group("span_id")):
        otel_trace_id = match.group("trace_id")
        otel_parent = match.group("span_id")
        sampled = (int(match.group("flags"), 16) & 0x01) == 0x01

    business = normalize_trace_id(normalized.get("x-trace-id") or normalized.get("x-request-id"))
    header_span = (normalized.get("x-span-id") or "").strip().lower()

    if otel_trace_id is None and is_otel_trace_id(business):
        # Legacy (pre-F4) sender: no usable traceparent, but a hex / de-hyphenated X-Trace-ID.
        # Parent every receiver of that call under one (phantom) parent so they share a trace.
        candidate = header_span if is_otel_span_id(header_span) else business[:16]
        if is_otel_span_id(candidate):
            otel_trace_id, otel_parent = business, candidate

    trace_id = business or otel_trace_id
    if trace_id:
        ctx = TraceContext.from_parent(
            parent_trace_id=trace_id,
            parent_span_id=otel_parent or header_span or trace_id[:16],
            service_name=service_name,
            operation_name=operation_name,
            sampled=sampled,
        )
        ctx.inbound_trace_id = True
    else:
        ctx = TraceContext.new(service_name=service_name, operation_name=operation_name)

    ctx.otel_trace_id = otel_trace_id
    ctx.otel_parent_span_id = otel_parent
    ctx.session_id = _safe_label(normalized.get("x-session-id"))
    ctx.turn_id = _safe_label(normalized.get("x-turn-id"))
    return ctx


def outgoing_trace_headers(trace_ctx: Optional[TraceContext] = None) -> Dict[str, str]:
    """Trace headers for ANY outgoing east-west call.

    The W3C parent comes from, in order: the current OTel span; a TraceContext whose ids are valid
    hex; a freshly minted 32-hex id (never a dashed uuid4()). X-Trace-ID carries the business id.
    """
    from .context import get_current_trace_context

    if trace_ctx is None:
        trace_ctx = get_current_trace_context()

    otel = _current_otel_ids()
    if otel:
        t, s, sampled = otel
    elif trace_ctx and is_otel_trace_id(trace_ctx.trace_id) and is_otel_span_id(trace_ctx.span_id):
        t, s, sampled = trace_ctx.trace_id, trace_ctx.span_id, trace_ctx.sampled
    else:
        t, s, sampled = uuid.uuid4().hex, uuid.uuid4().hex[:16], True

    business = (trace_ctx.trace_id if trace_ctx and trace_ctx.trace_id else None) or t
    headers = {
        "traceparent": f"00-{t}-{s}-{'01' if sampled else '00'}",
        "X-Trace-ID": business,
        "X-Request-ID": business,  # Backward compatibility
        "X-Span-ID": s,
    }
    if trace_ctx and trace_ctx.session_id:
        headers["X-Session-ID"] = trace_ctx.session_id
    if trace_ctx and trace_ctx.turn_id:
        headers["X-Turn-ID"] = trace_ctx.turn_id
    return headers


def inject_trace_headers(
    headers: Dict[str, str],
    trace_ctx: Optional[TraceContext] = None,
) -> Dict[str, str]:
    """Inject trace headers for an outgoing request (see `outgoing_trace_headers`)."""
    headers.update(outgoing_trace_headers(trace_ctx))
    return headers
