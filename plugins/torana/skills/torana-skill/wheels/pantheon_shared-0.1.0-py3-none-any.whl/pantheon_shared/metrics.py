"""
Metrics API endpoints for PantheonClient and DataLakeClient.

This module provides FastAPI endpoints to expose HTTP client metrics
and DataLake client metrics for monitoring and observability.
"""

from typing import Dict, Any
from fastapi import APIRouter, Depends, Body
from pydantic import BaseModel
from pantheon_shared.http.client import PantheonClient, EastWestLogLevel
from pantheon_shared.iam import IAMContext, has_permission
from pantheon_shared.iam.api import IAMEndpoint
from pantheon_shared.datalake.metrics import get_datalake_metrics_registry, DATALAKE_METRICS_ENABLED

router = APIRouter()


class LogLevelRequest(BaseModel):
    """Request model for setting logging level"""
    level: int


@router.get(
    "/metrics/service-clients",
    response_model=Dict[str, Any],
    summary="Get metrics for all services",
    description="Retrieve HTTP client metrics for all registered services",
    operation_id="get_all_service_metrics",
    tags=["metrics"],
    responses={
        200: {"description": "Service metrics retrieved successfully"},
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden - insufficient permissions"},
    },
    **has_permission("metrics:read").openapi_kwargs
)
async def get_all_service_metrics(iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)):
    """Get metrics for all services"""
    metrics = {}
    for service_name, client_metrics in PantheonClient._metrics_registry.items():
        metrics[service_name] = client_metrics.to_dict()

    return {
        "status": "success",
        "data": {
            "services": metrics,
            "total_services": len(metrics)
        }
    }


@router.get(
    "/metrics/service-clients/{service_name}",
    response_model=Dict[str, Any],
    summary="Get metrics for a specific service",
    description="Retrieve HTTP client metrics for a specific service",
    operation_id="get_service_metrics",
    tags=["metrics"],
    responses={
        200: {"description": "Service metrics retrieved successfully"},
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden - insufficient permissions"},
        404: {"description": "Service not found"},
    },
    **has_permission("metrics:read").openapi_kwargs
)
async def get_service_metrics(service_name: str, iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)):
    """Get metrics for a specific service"""
    if service_name not in PantheonClient._metrics_registry:
        return {
            "status": "error",
            "message": f"No metrics found for service: {service_name}"
        }

    client_metrics = PantheonClient._metrics_registry[service_name]

    return {
        "status": "success",
        "data": {
            "service_name": service_name,
            "metrics": client_metrics.to_dict()
        }
    }


@router.delete(
    "/metrics/service-clients/{service_name}",
    response_model=Dict[str, Any],
    summary="Reset metrics for a specific service",
    description="Reset HTTP client metrics for a specific service",
    operation_id="reset_service_metrics",
    tags=["metrics"],
    responses={
        200: {"description": "Service metrics reset successfully"},
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden - insufficient permissions"},
        404: {"description": "Service not found"},
    },
    **has_permission("metrics:write").openapi_kwargs
)
async def reset_service_metrics(service_name: str, iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)):
    """Reset metrics for a specific service"""
    if service_name not in PantheonClient._metrics_registry:
        return {
            "status": "error",
            "message": f"No metrics found for service: {service_name}"
        }

    # Reset metrics by creating a new ClientMetrics instance
    from pantheon_shared.http.client import ClientMetrics
    PantheonClient._metrics_registry[service_name] = ClientMetrics()

    return {
        "status": "success",
        "message": f"Metrics reset for service: {service_name}"
    }


@router.delete(
    "/metrics/service-clients",
    response_model=Dict[str, Any],
    summary="Reset metrics for all services",
    description="Reset HTTP client metrics for all services",
    operation_id="reset_all_metrics",
    tags=["metrics"],
    responses={
        200: {"description": "All metrics reset successfully"},
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden - insufficient permissions"},
    },
    **has_permission("metrics:write").openapi_kwargs
)
async def reset_all_metrics(iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)):
    """Reset metrics for all services"""
    # Clear the entire metrics registry
    PantheonClient._metrics_registry.clear()

    return {
        "status": "success",
        "message": "All metrics have been reset"
    }


@router.get(
    "/metrics/summary",
    response_model=Dict[str, Any],
    summary="Get metrics summary across all services",
    description="Retrieve a summary of HTTP client metrics across all services",
    operation_id="get_metrics_summary",
    tags=["metrics"],
    responses={
        200: {"description": "Metrics summary retrieved successfully"},
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden - insufficient permissions"},
    },
    **has_permission("metrics:read").openapi_kwargs
)
async def get_metrics_summary(iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)):
    """Get a summary of all metrics across all services"""
    total_2xx = 0
    total_3xx = 0
    total_4xx = 0
    total_5xx = 0
    total_requests = 0
    total_response_time = 0.0

    for client_metrics in PantheonClient._metrics_registry.values():
        total_2xx += client_metrics.num_2xx
        total_3xx += client_metrics.num_3xx
        total_4xx += client_metrics.num_4xx
        total_5xx += client_metrics.num_5xx
        total_requests += client_metrics.total_requests
        total_response_time += client_metrics.total_response_time

    avg_response_time = total_response_time / total_requests if total_requests > 0 else 0

    # Calculate success rate (2xx responses)
    success_rate = (total_2xx / total_requests * 100) if total_requests > 0 else 0

    # Calculate error rate (4xx + 5xx responses)
    error_rate = ((total_4xx + total_5xx) / total_requests * 100) if total_requests > 0 else 0

    return {
        "status": "success",
        "data": {
            "total_requests": total_requests,
            "total_2xx": total_2xx,
            "total_3xx": total_3xx,
            "total_4xx": total_4xx,
            "total_5xx": total_5xx,
            "success_rate_percent": round(success_rate, 2),
            "error_rate_percent": round(error_rate, 2),
            "avg_response_time_ms": round(avg_response_time * 1000, 2),
            "total_response_time_s": round(total_response_time, 3),
            "active_services": len(PantheonClient._metrics_registry)
        }
    }


# =============================================================================
# DataLake Client Metrics Endpoints
# =============================================================================

@router.get(
    "/metrics/data-lake",
    response_model=Dict[str, Any],
    summary="Get metrics for all datalake backends",
    description="Retrieve DataLake client metrics for all backend types (duckdb, postgres, snowflake)",
    operation_id="get_all_datalake_metrics",
    tags=["metrics"],
    responses={
        200: {"description": "DataLake metrics retrieved successfully"},
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden - insufficient permissions"},
        503: {"description": "Metrics not enabled"},
    },
    **has_permission("metrics:read").openapi_kwargs
)
async def get_all_datalake_metrics(iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)):
    """Get metrics for all datalake backends"""
    if not DATALAKE_METRICS_ENABLED:
        return {
            "status": "error",
            "message": "DataLake metrics are not enabled. Set DATALAKE_METRICS_ENABLED=true to enable."
        }

    registry = get_datalake_metrics_registry()
    all_metrics = registry.get_all_metrics()

    # Convert to dict format
    backends = {}
    for backend_type, metrics in all_metrics.items():
        backends[backend_type] = metrics.to_dict()

    # Calculate summary across all backends
    summary = _calculate_datalake_summary(all_metrics)

    return {
        "status": "success",
        "data": {
            "backends": backends,
            "summary": summary,
            "enabled_backends": len(backends)
        }
    }


@router.get(
    "/metrics/data-lake/{backend_type}",
    response_model=Dict[str, Any],
    summary="Get metrics for a specific datalake backend",
    description="Retrieve DataLake client metrics for a specific backend type (duckdb, postgres, snowflake)",
    operation_id="get_datalake_backend_metrics",
    tags=["metrics"],
    responses={
        200: {"description": "Backend metrics retrieved successfully"},
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden - insufficient permissions"},
        404: {"description": "Backend not found or no metrics available"},
        503: {"description": "Metrics not enabled"},
    },
    **has_permission("metrics:read").openapi_kwargs
)
async def get_datalake_backend_metrics(
    backend_type: str,
    iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)
):
    """Get metrics for a specific datalake backend"""
    if not DATALAKE_METRICS_ENABLED:
        return {
            "status": "error",
            "message": "DataLake metrics are not enabled. Set DATALAKE_METRICS_ENABLED=true to enable."
        }

    registry = get_datalake_metrics_registry()
    all_metrics = registry.get_all_metrics()

    if backend_type not in all_metrics:
        return {
            "status": "error",
            "message": f"No metrics found for backend: {backend_type}. "
                      f"Valid backends: duckdb, postgres, snowflake"
        }

    metrics = all_metrics[backend_type]

    return {
        "status": "success",
        "data": {
            "backend_type": backend_type,
            "metrics": metrics.to_dict()
        }
    }


@router.delete(
    "/metrics/data-lake/{backend_type}",
    response_model=Dict[str, Any],
    summary="Reset metrics for a specific datalake backend",
    description="Reset DataLake client metrics for a specific backend type",
    operation_id="reset_datalake_backend_metrics",
    tags=["metrics"],
    responses={
        200: {"description": "Backend metrics reset successfully"},
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden - insufficient permissions"},
        404: {"description": "Backend not found"},
        503: {"description": "Metrics not enabled"},
    },
    **has_permission("metrics:write").openapi_kwargs
)
async def reset_datalake_backend_metrics(
    backend_type: str,
    iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)
):
    """Reset metrics for a specific datalake backend"""
    if not DATALAKE_METRICS_ENABLED:
        return {
            "status": "error",
            "message": "DataLake metrics are not enabled. Set DATALAKE_METRICS_ENABLED=true to enable."
        }

    registry = get_datalake_metrics_registry()
    success = registry.reset_metrics(backend_type)

    if not success:
        return {
            "status": "error",
            "message": f"No metrics found for backend: {backend_type}. "
                      f"Valid backends: duckdb, postgres, snowflake"
        }

    return {
        "status": "success",
        "message": f"Metrics reset for backend: {backend_type}"
    }


@router.delete(
    "/metrics/data-lake",
    response_model=Dict[str, Any],
    summary="Reset metrics for all datalake backends",
    description="Reset DataLake client metrics for all backend types",
    operation_id="reset_all_datalake_metrics",
    tags=["metrics"],
    responses={
        200: {"description": "All backend metrics reset successfully"},
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden - insufficient permissions"},
        503: {"description": "Metrics not enabled"},
    },
    **has_permission("metrics:write").openapi_kwargs
)
async def reset_all_datalake_metrics(iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)):
    """Reset metrics for all datalake backends"""
    if not DATALAKE_METRICS_ENABLED:
        return {
            "status": "error",
            "message": "DataLake metrics are not enabled. Set DATALAKE_METRICS_ENABLED=true to enable."
        }

    registry = get_datalake_metrics_registry()
    registry.reset_all_metrics()

    return {
        "status": "success",
        "message": "All DataLake metrics have been reset"
    }


def _calculate_datalake_summary(all_metrics: Dict[str, Any]) -> Dict[str, Any]:
    """
    Calculate summary metrics across all datalake backends.

    Args:
        all_metrics: Dictionary of backend_type -> DataLakeClientMetrics

    Returns:
        Summary dictionary with aggregated metrics.
    """
    total_queries = sum(m.total_queries for m in all_metrics.values())
    successful_queries = sum(m.successful_queries for m in all_metrics.values())
    failed_queries = sum(m.failed_queries for m in all_metrics.values())
    total_query_time = sum(m.total_query_time for m in all_metrics.values())

    total_inserts = sum(m.total_inserts for m in all_metrics.values())
    total_upserts = sum(m.total_upserts for m in all_metrics.values())
    successful_writes = sum(m.successful_writes for m in all_metrics.values())
    failed_writes = sum(m.failed_writes for m in all_metrics.values())
    rows_inserted = sum(m.rows_inserted for m in all_metrics.values())
    rows_upserted = sum(m.rows_upserted for m in all_metrics.values())

    slow_queries = sum(m.slow_query_count for m in all_metrics.values())
    very_slow_queries = sum(m.very_slow_query_count for m in all_metrics.values())

    connection_errors = sum(m.connection_errors for m in all_metrics.values())
    failed_health_checks = sum(m.failed_health_checks for m in all_metrics.values())

    avg_query_time = total_query_time / total_queries if total_queries > 0 else 0

    query_success_rate = (successful_queries / total_queries * 100) if total_queries > 0 else 0
    write_success_rate = (successful_writes / (total_inserts + total_upserts) * 100) if (total_inserts + total_upserts) > 0 else 0

    return {
        "query_metrics": {
            "total_queries": total_queries,
            "successful_queries": successful_queries,
            "failed_queries": failed_queries,
            "success_rate_percent": round(query_success_rate, 2),
            "avg_query_time_ms": round(avg_query_time * 1000, 2),
            "slow_query_count": slow_queries,
            "very_slow_query_count": very_slow_queries,
        },
        "write_metrics": {
            "total_inserts": total_inserts,
            "total_upserts": total_upserts,
            "successful_writes": successful_writes,
            "failed_writes": failed_writes,
            "success_rate_percent": round(write_success_rate, 2),
            "rows_inserted": rows_inserted,
            "rows_upserted": rows_upserted,
        },
        "connection_metrics": {
            "connection_errors": connection_errors,
            "failed_health_checks": failed_health_checks,
        }
    }


# =============================================================================
# East-West Logging Configuration Endpoints
# =============================================================================

@router.get(
    "/metrics/logging-config",
    response_model=Dict[str, Any],
    summary="Get east-west logging configuration",
    description="Get the current logging level and enabled flags for this service",
    operation_id="get_logging_config",
    tags=["metrics"],
    responses={
        200: {"description": "Logging config retrieved successfully"},
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden"},
    },
    **has_permission("metrics:read").openapi_kwargs
)
async def get_logging_config(iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)):
    """Get east-west logging configuration for this service"""
    # Get the service name from the first registered service (this service)
    if not PantheonClient._logging_config:
        return {
            "status": "success",
            "data": {
                "service_name": "unknown",
                "level": EastWestLogLevel.NONE,
                "flags": [],
                "is_all": False
            }
        }

    service_name = next(iter(PantheonClient._logging_config.keys()), "unknown")

    return {
        "status": "success",
        "data": PantheonClient.get_logging_config_dict(service_name)
    }


@router.put(
    "/metrics/logging-config",
    response_model=Dict[str, Any],
    summary="Set east-west logging configuration",
    description="Set the logging level for this service. Level is a bitmask: 1=errors, 2=access, 4=req-detail, 8=resp-detail. Combine values: e.g., 3 = errors + access",
    operation_id="set_logging_config",
    tags=["metrics"],
    responses={
        200: {"description": "Logging config updated successfully"},
        400: {"description": "Invalid level value"},
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden"},
    },
    **has_permission("metrics:write").openapi_kwargs
)
async def set_logging_config(
    request: LogLevelRequest,
    iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)
):
    """Set east-west logging configuration for this service"""
    level = request.level

    # Validate level is a valid bitmask (0-15)
    if not isinstance(level, int) or level < 0 or level > 15:
        return {
            "status": "error",
            "message": "Invalid level value. Must be 0-15 (bitmask of: 1=errors, 2=access, 4=req-detail, 8=resp-detail)"
        }

    # Get the service name from the first registered service
    if not PantheonClient._logging_config:
        return {
            "status": "error",
            "message": "No services have initialized PantheonClient yet"
        }

    service_name = next(iter(PantheonClient._logging_config.keys()), "unknown")

    # Set the logging level
    PantheonClient.set_logging_level(service_name, level)

    return {
        "status": "success",
        "message": f"Logging level updated to {level}",
        "data": PantheonClient.get_logging_config_dict(service_name)
    }


@router.get(
    "/metrics/logging-config/summary",
    response_model=Dict[str, Any],
    summary="Get east-west logging summary",
    description="Get a human-readable summary of what logging is enabled",
    operation_id="get_logging_summary",
    tags=["metrics"],
    responses={
        200: {"description": "Logging summary retrieved successfully"},
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden"},
    },
    **has_permission("metrics:read").openapi_kwargs
)
async def get_logging_summary(iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)):
    """Get a human-readable summary of logging configuration"""
    if not PantheonClient._logging_config:
        return {
            "status": "success",
            "data": {
                "level": EastWestLogLevel.NONE,
                "description": "No east-west logging enabled",
                "enabled_features": []
            }
        }

    service_name = next(iter(PantheonClient._logging_config.keys()), "unknown")
    level = PantheonClient.get_logging_level(service_name)

    enabled = EastWestLogLevel.get_human_readable(level)

    if not enabled:
        description = "No east-west logging enabled"
    elif level == EastWestLogLevel.ALL:
        description = "All east-west logging enabled"
    else:
        description = f"Enabled: {', '.join(enabled)}"

    return {
        "status": "success",
        "data": {
            "level": level,
            "description": description,
            "enabled_features": enabled
        }
    }


# =============================================================================
# LLM Metrics Endpoints
# =============================================================================

@router.get(
    "/metrics/llm",
    response_model=Dict[str, Any],
    summary="Get LLM metrics for all services",
    description="Retrieve LLM metrics for all Pantheon services",
    operation_id="get_all_llm_metrics",
    tags=["metrics"],
    responses={
        200: {"description": "LLM metrics retrieved successfully"},
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden"},
    },
    **has_permission("metrics:read").openapi_kwargs
)
async def get_all_llm_metrics(iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)):
    """Get LLM metrics for all services"""
    try:
        from pantheon_shared.llm import get_all_llm_metrics, LLM_METRICS_ENABLED
    except ImportError:
        return {
            "status": "error",
            "message": "LLM metrics module not available"
        }

    if not LLM_METRICS_ENABLED:
        return {
            "status": "error",
            "message": "LLM metrics are not enabled. Set LLM_METRICS_ENABLED=true to enable."
        }

    all_metrics = get_all_llm_metrics()

    # Convert to dict format
    services = {}
    for service_name, metrics in all_metrics.items():
        services[service_name] = metrics.to_dict()

    # Calculate summary
    from pantheon_shared.llm import calculate_llm_summary
    summary = calculate_llm_summary()

    return {
        "status": "success",
        "data": {
            "services": services,
            "summary": summary,
            "enabled_services": len(services)
        }
    }


@router.get(
    "/metrics/llm/{service_name}",
    response_model=Dict[str, Any],
    summary="Get LLM metrics for a specific service",
    description="Retrieve LLM metrics for a specific service",
    operation_id="get_llm_service_metrics",
    tags=["metrics"],
    responses={
        200: {"description": "Service LLM metrics retrieved successfully"},
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden"},
        404: {"description": "Service not found or no metrics available"},
    },
    **has_permission("metrics:read").openapi_kwargs
)
async def get_llm_service_metrics(
    service_name: str,
    iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)
):
    """Get LLM metrics for a specific service"""
    try:
        from pantheon_shared.llm import get_all_llm_metrics, LLM_METRICS_ENABLED
    except ImportError:
        return {
            "status": "error",
            "message": "LLM metrics module not available"
        }

    if not LLM_METRICS_ENABLED:
        return {
            "status": "error",
            "message": "LLM metrics are not enabled. Set LLM_METRICS_ENABLED=true to enable."
        }

    all_metrics = get_all_llm_metrics()

    if service_name not in all_metrics:
        return {
            "status": "error",
            "message": f"No metrics found for service: {service_name}"
        }

    metrics = all_metrics[service_name]

    return {
        "status": "success",
        "data": {
            "service_name": service_name,
            "metrics": metrics.to_dict()
        }
    }


@router.delete(
    "/metrics/llm/{service_name}",
    response_model=Dict[str, Any],
    summary="Reset LLM metrics for a specific service",
    description="Reset LLM metrics for a specific service",
    operation_id="reset_llm_service_metrics",
    tags=["metrics"],
    responses={
        200: {"description": "Service LLM metrics reset successfully"},
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden"},
        404: {"description": "Service not found"},
    },
    **has_permission("metrics:write").openapi_kwargs
)
async def reset_llm_service_metrics(
    service_name: str,
    iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)
):
    """Reset LLM metrics for a specific service"""
    try:
        from pantheon_shared.llm import reset_llm_metrics, LLM_METRICS_ENABLED
    except ImportError:
        return {
            "status": "error",
            "message": "LLM metrics module not available"
        }

    if not LLM_METRICS_ENABLED:
        return {
            "status": "error",
            "message": "LLM metrics are not enabled. Set LLM_METRICS_ENABLED=true to enable."
        }

    success = reset_llm_metrics(service_name)

    if not success:
        return {
            "status": "error",
            "message": f"No metrics found for service: {service_name}"
        }

    return {
        "status": "success",
        "message": f"Metrics reset for service: {service_name}"
    }


@router.delete(
    "/metrics/llm",
    response_model=Dict[str, Any],
    summary="Reset LLM metrics for all services",
    description="Reset LLM metrics for all services",
    operation_id="reset_all_llm_metrics",
    tags=["metrics"],
    responses={
        200: {"description": "All LLM metrics reset successfully"},
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden"},
    },
    **has_permission("metrics:write").openapi_kwargs
)
async def reset_all_llm_metrics(iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)):
    """Reset LLM metrics for all services"""
    try:
        from pantheon_shared.llm import reset_llm_metrics, LLM_METRICS_ENABLED
    except ImportError:
        return {
            "status": "error",
            "message": "LLM metrics module not available"
        }

    if not LLM_METRICS_ENABLED:
        return {
            "status": "error",
            "message": "LLM metrics are not enabled. Set LLM_METRICS_ENABLED=true to enable."
        }

    reset_llm_metrics()

    return {
        "status": "success",
        "message": "All LLM metrics have been reset"
    }


@router.get(
    "/metrics/llm/summary",
    response_model=Dict[str, Any],
    summary="Get LLM metrics summary across all services",
    description="Retrieve a summary of LLM metrics across all services",
    operation_id="get_llm_metrics_summary",
    tags=["metrics"],
    responses={
        200: {"description": "LLM metrics summary retrieved successfully"},
        401: {"description": "Unauthorized"},
        403: {"description": "Forbidden"},
    },
    **has_permission("metrics:read").openapi_kwargs
)
async def get_llm_metrics_summary(iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)):
    """Get a summary of all LLM metrics across all services"""
    try:
        from pantheon_shared.llm import calculate_llm_summary, LLM_METRICS_ENABLED
    except ImportError:
        return {
            "status": "error",
            "message": "LLM metrics module not available"
        }

    if not LLM_METRICS_ENABLED:
        return {
            "status": "error",
            "message": "LLM metrics are not enabled. Set LLM_METRICS_ENABLED=true to enable."
        }

    summary = calculate_llm_summary()

    return {
        "status": "success",
        "data": summary
    }
