"""
Structured "one line per unit of work" event logger (G-X-1).

This is a LOGGING helper, not the platform event timeline
(`pantheon_shared.events.emit` — see ``docs/PLATFORM_EVENTS.md``). The timeline is a
user-facing feed of a handful of curated, registry-declared producers. `log_event` is the
opposite: a cheap, unregistered, call-it-anywhere line meant for Loki/Grafana so every
service's background work gets at least one greppable, stable-named line per run, even
when nothing durable gets written to a table (or the row is later hard-deleted).

Use it for internal/operational "unit of work finished" lines: an agent turn, a sync, a
rule run, a scheduled job tick, a metrics snapshot. Do NOT use it for anything a user
should see on the Platform Events timeline — that still goes through
`pantheon_shared.events.emit`, which is reviewed, registered and suppression-gated.

Usage:

    from pantheon_shared import log_event

    log_event(
        "agent.turn.completed",
        tenant_id=tenant_id,       # or "platform" for non-tenant-scoped work
        status="success",
        duration_ms=1234,
        agent_id=agent_id,
    )
"""

from typing import Any, Optional

from .logging import get_logger

logger = get_logger(__name__)

#: Sentinel `tenant_id` for work that is not scoped to any tenant.
PLATFORM_TENANT = "platform"


def log_event(
    event: str,
    *,
    tenant_id: Optional[str] = None,
    status: Optional[str] = None,
    duration_ms: Optional[float] = None,
    **fields: Any,
) -> None:
    """Write one structured log line for a unit of background work.

    Args:
        event: A stable, dotted event name (e.g. ``"agent.turn.completed"``,
            ``"metrics.snapshot"``). Keep it greppable and consistent across call sites —
            it is the thing a dashboard or a saved Loki query keys on.
        tenant_id: The tenant this event belongs to, or ``None``/omitted for
            non-tenant-scoped (platform) work, in which case `PLATFORM_TENANT`
            (``"platform"``) is logged instead. Required by convention — always present
            in the emitted line, one way or another.
        status: Outcome of the unit of work (e.g. ``"success"``, ``"error"``, ``"ok"``).
            Required by convention — always present in the emitted line; defaults to
            ``"unknown"`` if not supplied, rather than raising, to honour the "never
            raises" contract below.
        duration_ms: How long the unit of work took, in milliseconds. Optional — only
            pass it for events that model something with a duration. Omit it entirely
            (don't pass 0 or None as a stand-in) for events that don't have one, so a
            duration panel doesn't average in a meaningless zero.
        **fields: Any additional `k=v` fields the event wants to carry (ids, counts,
            model names, etc.). Passed straight through to the configured structlog
            logger, which renders them as logfmt-style key=value pairs for Loki.

    This is a pure logging call and mirrors `pantheon_shared.events.emit`'s "never
    raises" discipline: internals are wrapped in try/except so a logging helper can
    never be the thing that crashes the caller's actual work. On any internal failure it
    falls back to a best-effort bare log call and gives up silently.
    """
    try:
        resolved_tenant = tenant_id if tenant_id else PLATFORM_TENANT
        resolved_status = status if status else "unknown"

        payload = dict(fields)
        payload["tenant_id"] = resolved_tenant
        payload["status"] = resolved_status
        if duration_ms is not None:
            payload["duration_ms"] = duration_ms

        logger.info(event, **payload)
    except Exception:
        # ⛔ NEVER RAISES — a dropped/malformed event line must never abort the work
        # that produced it (same discipline as pantheon_shared.events.emit).
        try:
            logger.info(event)
        except Exception:
            pass
