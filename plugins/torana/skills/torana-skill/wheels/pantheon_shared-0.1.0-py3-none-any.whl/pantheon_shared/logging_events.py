"""
Structured "one line per unit of work" event logger (G-X-1).

This is a LOGGING helper, not the platform event timeline
(`pantheon_shared.events.emit` — see ``docs/PLATFORM_EVENTS.md``). The timeline is a
user-facing feed of a handful of curated, registry-declared producers. `log_event` is the
opposite: a cheap, unregistered, call-it-anywhere line meant for Loki/Grafana so every
service's background work gets at least one greppable, stable-named line per run, even
when nothing durable gets written to a table (or the row is later hard-deleted).

Use it for internal/operational "unit of work finished" lines: an agent turn, a sync, a
rule run, a scheduled job tick, a metrics snapshot. Do NOT use it for anything a user
should see on the Platform Events timeline — that still goes through
`pantheon_shared.events.emit`, which is reviewed, registered and suppression-gated.

Usage:

    from pantheon_shared import log_event

    log_event(
        "agent.turn.completed",
        tenant_id=tenant_id,       # or "platform" for non-tenant-scoped work
        status="success",
        duration_ms=1234,
        agent_id=agent_id,
    )
"""

import re
from typing import Any, Optional, Tuple

from .logging import get_logger

logger = get_logger(__name__)

#: Sentinel `tenant_id` for work that is not scoped to any tenant.
PLATFORM_TENANT = "platform"


def log_event(
    event: str,
    *,
    tenant_id: Optional[str] = None,
    status: Optional[str] = None,
    duration_ms: Optional[float] = None,
    **fields: Any,
) -> None:
    """Write one structured log line for a unit of background work.

    Args:
        event: A stable, dotted event name (e.g. ``"agent.turn.completed"``,
            ``"metrics.snapshot"``). Keep it greppable and consistent across call sites —
            it is the thing a dashboard or a saved Loki query keys on.
        tenant_id: The tenant this event belongs to, or ``None``/omitted for
            non-tenant-scoped (platform) work, in which case `PLATFORM_TENANT`
            (``"platform"``) is logged instead. Required by convention — always present
            in the emitted line, one way or another.
        status: Outcome of the unit of work (e.g. ``"success"``, ``"error"``, ``"ok"``).
            Required by convention — always present in the emitted line; defaults to
            ``"unknown"`` if not supplied, rather than raising, to honour the "never
            raises" contract below.
        duration_ms: How long the unit of work took, in milliseconds. Optional — only
            pass it for events that model something with a duration. Omit it entirely
            (don't pass 0 or None as a stand-in) for events that don't have one, so a
            duration panel doesn't average in a meaningless zero.
        **fields: Any additional `k=v` fields the event wants to carry (ids, counts,
            model names, etc.). Passed straight through to the configured structlog
            logger, which renders them as logfmt-style key=value pairs for Loki.

    This is a pure logging call and mirrors `pantheon_shared.events.emit`'s "never
    raises" discipline: internals are wrapped in try/except so a logging helper can
    never be the thing that crashes the caller's actual work. On any internal failure it
    falls back to a best-effort bare log call and gives up silently.
    """
    try:
        resolved_tenant = tenant_id if tenant_id else PLATFORM_TENANT
        resolved_status = status if status else "unknown"

        payload = dict(fields)
        payload["tenant_id"] = resolved_tenant
        payload["status"] = resolved_status
        if duration_ms is not None:
            payload["duration_ms"] = duration_ms

        logger.info(event, **payload)
    except Exception:
        # ⛔ NEVER RAISES — a dropped/malformed event line must never abort the work
        # that produced it (same discipline as pantheon_shared.events.emit).
        try:
            logger.info(event)
        except Exception:
            pass


# ─── C-01: the failure convention ────────────────────────────────────────────────────────────
#
# One line per failed unit of work, so stream C can alert on it and route it. The convention and
# the registry: docs/FAILURE_CONVENTION.md and `pantheon_shared.failure_codes`.

#: `tenant_id` for a failure whose tenant could not be resolved (an unauthenticated request that
#: answered 5xx). NOT `PLATFORM_TENANT`: that one means deliberately non-tenant work.
UNKNOWN_TENANT = "unknown"

#: The longest `error_detail` a failure line carries, after redaction.
ERROR_DETAIL_MAX = 300

_REDACTED = "[REDACTED]"

# Order matters: the specific shapes run before the generic ones.
_SECRET_PATTERNS = (
    # scheme://user:password@host -> scheme://[REDACTED]@host
    (re.compile(r"(?i)\b([a-z][a-z0-9+.\-]*://)[^\s/@]+@"), r"\1" + _REDACTED + "@"),
    # Authorization: Bearer / Basic / Token <value>
    (re.compile(r"(?i)\b(bearer|basic|token)\s+[A-Za-z0-9\-._~+/=]{8,}"), r"\1 " + _REDACTED),
    # JWTs
    (re.compile(r"\beyJ[A-Za-z0-9_\-]{5,}\.[A-Za-z0-9_\-]{5,}(?:\.[A-Za-z0-9_\-]*)?"), _REDACTED),
    # Well-known token shapes: GitHub, Slack, sk-… model keys, Google API keys, AWS key ids
    (re.compile(r"\b(?:gh[pousr]_[A-Za-z0-9]{16,}|github_pat_[A-Za-z0-9_]{16,}|xox[abposr]-[A-Za-z0-9\-]{8,}"
                r"|sk-[A-Za-z0-9_\-]{16,}|AIza[0-9A-Za-z_\-]{30,}|(?:AKIA|ASIA)[0-9A-Z]{16})"), _REDACTED),
    # password=…, api_key: …, "token": "…", client_secret=…, authorization=…
    (re.compile(r"(?i)([\"']?\b[\w\-]*(?:password|passwd|pwd|secret|token|api[_\-]?key|apikey|authorization"
                r"|credential|private[_\-]?key)[\w\-]*[\"']?\s*[:=]\s*)(\"[^\"]*\"|'[^']*'|[^\s,;&}]+)"),
     r"\1" + _REDACTED),
    # Any other long opaque blob (40+ chars of hex/base64) is more likely a key than prose.
    (re.compile(r"\b[A-Za-z0-9+/_\-]{40,}={0,2}"), _REDACTED),
)


def sanitize_error_detail(detail: Any, max_len: int = ERROR_DETAIL_MAX) -> Optional[str]:
    """Redact credentials from a failure's text, fold it to one line and cut it to `max_len` chars.

    Strips URL credentials, bearer/basic tokens, JWTs, well-known token shapes, secret-named
    key=value pairs and long opaque blobs. Redaction runs BEFORE the cut, so a secret straddling
    the limit is never half-kept. Never raises: on any error it returns a fixed marker, never the
    raw text.
    """
    if detail is None:
        return None
    try:
        text = " ".join(str(detail).split())
        for pattern, repl in _SECRET_PATTERNS:
            text = pattern.sub(repl, text)
        if len(text) > max_len:
            text = text[: max_len - 1] + "…"
        return text
    except Exception:
        return "[unprintable]"


def resolve_error_code(error_code: Optional[str], unit: str) -> Tuple[str, Optional[str]]:
    """Map a caller's code onto the registry: `(code, raw)`; `raw` is set only when it changed.

    A registered code passes through. An unregistered code in a known domain becomes
    `<domain>.unknown`; an unknown domain (or no code) becomes `<unit's domain>.unknown`.
    """
    from .failure_codes import ERROR_DOMAINS, FAILURE_CODES

    if error_code and error_code in FAILURE_CODES:
        return error_code, None
    domain = (error_code or "").split(".", 1)[0]
    if domain not in ERROR_DOMAINS:
        unit_domain = (unit or "").split(".", 1)[0]
        domain = unit_domain if unit_domain in ERROR_DOMAINS else "api"
    if error_code == f"{domain}.unknown":
        return error_code, None
    return f"{domain}.unknown", (error_code or None)


def _current_trace_id() -> Optional[str]:
    try:
        from .tracing import get_current_trace_context
        ctx = get_current_trace_context()
        return ctx.trace_id if ctx else None
    except Exception:
        return None


def log_failure(
    unit: str,
    *,
    tenant_id: Optional[str],
    error_code: Optional[str],
    error_class: Optional[str] = None,
    unit_id: Optional[Any] = None,
    workspace_id: Optional[Any] = None,
    detail: Any = None,
    **fields: Any,
) -> None:
    """Write the ONE C-01 failure line for a failed unit of work. Call it once per failure.

    Line: ``<unit>.failed status=failed tenant_id=… trace_id=… error_code=<domain>.<reason>
    error_class=… unit_id=… [workspace_id] [error_detail]``, level ERROR, logger
    ``pantheon_shared.logging_events``. The Loki label ``service`` names the emitting service.

    Args:
        unit: one of `failure_codes.FAILURE_UNITS` (``api.request``, ``agent.turn``, ``sync.run``,
            ``rule.run``, ``pr.action``). An unlisted unit is still logged, with ``unit_known=False``.
        tenant_id: required. The tenant, ``PLATFORM_TENANT`` for deliberately non-tenant work, or
            ``UNKNOWN_TENANT`` when it could not be resolved; ``None``/empty logs as ``unknown``.
        error_code: ``<domain>.<reason>`` from `failure_codes.FAILURE_CODES`. Anything else logs as
            ``<domain>.unknown`` with the original in ``error_code_raw``; never dropped.
        error_class: overrides the registry's class for this one occurrence. Defaults to the
            registry's class (``bug`` for an unknown code). An invalid value logs as ``bug``, with
            the original in ``error_class_raw``.
        unit_id: the run / turn / job / request / remediation id.
        workspace_id: the workspace, when the unit has one.
        detail: the error text or exception, logged as ``error_detail`` after
            `sanitize_error_detail` (secrets redacted, at most 300 characters).
        **fields: extra kwargs (counts, http_status, …). Never ``extra={}``: that renders as one
            repr blob LogQL cannot filter.

    ⛔ NEVER RAISES. A failure line must never become a second failure.
    """
    try:
        from .failure_codes import ERROR_CLASSES, FAILURE_CODES, FAILURE_UNITS, UNKNOWN_CLASS

        payload = dict(fields)
        code, raw = resolve_error_code(error_code, unit)
        if error_class in ERROR_CLASSES:
            cls = error_class
        elif error_class is None:
            cls = FAILURE_CODES.get(code, UNKNOWN_CLASS)
        else:
            cls = UNKNOWN_CLASS
            payload["error_class_raw"] = str(error_class)

        # `unit` is a field so a rule filters `| unit="sync.run"`; the event name lives only in
        # `message`, which the text renderer prefixes to the fields.
        payload["unit"] = unit
        payload["status"] = "failed"
        payload["tenant_id"] = str(tenant_id) if tenant_id else UNKNOWN_TENANT
        payload["error_code"] = code
        payload["error_class"] = cls
        if raw is not None:
            payload["error_code_raw"] = str(raw)
        if unit not in FAILURE_UNITS:
            payload["unit_known"] = False
        if unit_id is not None:
            payload["unit_id"] = str(unit_id)
        if workspace_id is not None:
            payload["workspace_id"] = str(workspace_id)
        clean = sanitize_error_detail(detail)
        if clean:
            payload["error_detail"] = clean
        # The trace processor stamps this too; set here so the line carries it even where a
        # structlog chain lacks that processor (scripts, tests).
        trace_id = _current_trace_id()
        if trace_id:
            payload.setdefault("trace_id", trace_id)

        logger.error(f"{unit}.failed", **payload)
    except Exception:
        # ⛔ NEVER RAISES, same discipline as log_event.
        try:
            logger.error(f"{unit}.failed", status="failed")
        except Exception:
            pass
