"""``AgentInvocationEnvelope`` — the single contract every caller uses to invoke an agent.

The envelope replaces today's ad-hoc context-passing (each caller — chat, alert
triage, scheduler — rolls its own context shape). Producers:

- pantheon-program-framework — Build-in-Chat, on-demand task runs
- pantheon-workflow-framework — scheduler ``_execute_agent_task``,
  event-bus worker, work-item router
- pantheon-detection-framework — alert routing path (during the transition)

Consumer: pantheon-agent-builder ``/api/v1/invocations`` and ``/api/v1/agents/{id}/invoke``.
The endpoint mirrors the envelope into ``EventContext.workspace_id`` and the
ADK Session ``initial_state`` under key ``envelope`` so prompts can reference it.

Dependency-free on purpose. Uses ``dataclasses`` over Pydantic so the envelope
is cheap to construct in hot paths.

See §6.2 and §9.5 of ``docs/Agents_In_Workspaces_Implementation_Guide.md``.
"""

from __future__ import annotations

import uuid
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Mapping, Optional
from uuid import UUID

from pantheon_shared.agents.guardrails import validate_guardrails
from pantheon_shared.workspace.agent_roles import (
    WorkspaceAgentAutonomyMode,
    WorkspaceAgentRole,
)


# ---------------------------------------------------------------------------
# Sub-shapes
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class AnchorRef:
    """What this invocation is *about*.

    Examples:
    - ``AnchorRef(kind="alert", id="<alert_uuid>")`` for triage
    - ``AnchorRef(kind="message", id="<msg_id>")`` for msg-workspace
    - ``AnchorRef(kind="proposal", id="<proposal_uuid>")`` for build-in-chat
    - ``None`` for headless cadence runs
    """

    kind: str
    id: str


@dataclass(frozen=True)
class TriggerInfo:
    """Why this invocation is happening.

    ``kind`` is one of ``schedule | routing | event | manual | chat`` (free-form
    string — adding new trigger kinds doesn't require touching this dataclass).
    The remaining fields are optional context hooks.
    """

    kind: str
    scheduled_task_id: Optional[str] = None
    routing_rule_id: Optional[str] = None
    channel: Optional[str] = None
    payload: Optional[Mapping[str, Any]] = None
    actor: Optional[str] = None  # who / what initiated (user id, agent name, "system")


@dataclass(frozen=True)
class InvocationBudget:
    """Per-invocation ceilings derived from the attachment's guardrails."""

    tokens: Optional[int] = None
    usd: Optional[float] = None
    wallclock_seconds: Optional[int] = None
    tool_calls: Optional[int] = None


# ---------------------------------------------------------------------------
# Envelope
# ---------------------------------------------------------------------------


@dataclass
class AgentInvocationEnvelope:
    """Stable contract carried on every ``/invocations`` call.

    The envelope is *immutable per invocation* — the consumer (agent-builder)
    may copy it into ``EventContext`` but must not modify it.
    """

    # ----- Identity ---------------------------------------------------------
    workspace_id: UUID
    workspace_type: str  # WorkspaceType.value (free string to avoid hard coupling)
    tenant_id: UUID
    namespace_id: UUID

    # ----- Attachment (optional only for legacy direct invokes) -------------
    attachment_id: Optional[UUID] = None
    role: Optional[WorkspaceAgentRole] = None
    responsibility: Mapping[str, Any] = field(default_factory=dict)
    autonomy_mode: WorkspaceAgentAutonomyMode = WorkspaceAgentAutonomyMode.HUMAN_IN_THE_LOOP
    guardrails: Mapping[str, Any] = field(default_factory=dict)

    # ----- Trigger / Anchor -------------------------------------------------
    trigger: Optional[TriggerInfo] = None
    anchor: Optional[AnchorRef] = None

    # ----- Context references (NOT inline blobs; fetched if needed) ---------
    environment_summary_ref: Optional[str] = None
    policy_context: List[Dict[str, Any]] = field(default_factory=list)

    # ----- Budget -----------------------------------------------------------
    invocation_budget: InvocationBudget = field(default_factory=InvocationBudget)

    # ----- Audit ------------------------------------------------------------
    correlation_id: UUID = field(default_factory=uuid.uuid4)
    request_id: UUID = field(default_factory=uuid.uuid4)

    # ----- Schema version ---------------------------------------------------
    schema_version: str = "1.0"

    # ----- Serialization ----------------------------------------------------

    def to_dict(self) -> dict:
        """JSON-ready dict. Enums become their ``.value`` strings; UUIDs strings."""
        raw = asdict(self)
        raw["workspace_id"] = str(self.workspace_id)
        raw["tenant_id"] = str(self.tenant_id)
        raw["namespace_id"] = str(self.namespace_id)
        if self.attachment_id is not None:
            raw["attachment_id"] = str(self.attachment_id)
        raw["correlation_id"] = str(self.correlation_id)
        raw["request_id"] = str(self.request_id)
        if self.role is not None:
            raw["role"] = self.role.value
        raw["autonomy_mode"] = self.autonomy_mode.value
        return raw

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "AgentInvocationEnvelope":
        """Inverse of ``to_dict``. Permissive on unknown keys for forward compat."""
        trigger = data.get("trigger")
        anchor = data.get("anchor")
        budget = data.get("invocation_budget") or {}
        return cls(
            workspace_id=UUID(str(data["workspace_id"])),
            workspace_type=data.get("workspace_type", ""),
            tenant_id=UUID(str(data["tenant_id"])),
            namespace_id=UUID(str(data["namespace_id"])),
            attachment_id=(
                UUID(str(data["attachment_id"]))
                if data.get("attachment_id")
                else None
            ),
            role=WorkspaceAgentRole.from_raw(data.get("role")) if data.get("role") else None,
            responsibility=data.get("responsibility") or {},
            autonomy_mode=(
                WorkspaceAgentAutonomyMode.from_raw(data["autonomy_mode"])
                or WorkspaceAgentAutonomyMode.HUMAN_IN_THE_LOOP
                if "autonomy_mode" in data
                else WorkspaceAgentAutonomyMode.HUMAN_IN_THE_LOOP
            ),
            guardrails=data.get("guardrails") or {},
            trigger=TriggerInfo(**trigger) if isinstance(trigger, dict) else None,
            anchor=AnchorRef(**anchor) if isinstance(anchor, dict) else None,
            environment_summary_ref=data.get("environment_summary_ref"),
            policy_context=list(data.get("policy_context") or []),
            invocation_budget=InvocationBudget(**budget) if isinstance(budget, dict) else InvocationBudget(),
            correlation_id=UUID(str(data["correlation_id"])) if data.get("correlation_id") else uuid.uuid4(),
            request_id=UUID(str(data["request_id"])) if data.get("request_id") else uuid.uuid4(),
            schema_version=str(data.get("schema_version", "1.0")),
        )


# ---------------------------------------------------------------------------
# Factory — the single function every caller should use
# ---------------------------------------------------------------------------


def build_invocation_envelope(
    *,
    workspace_id: UUID,
    workspace_type: str,
    tenant_id: UUID,
    namespace_id: UUID,
    attachment_id: Optional[UUID] = None,
    role: Optional[WorkspaceAgentRole] = None,
    responsibility: Optional[Mapping[str, Any]] = None,
    autonomy_mode: WorkspaceAgentAutonomyMode = WorkspaceAgentAutonomyMode.HUMAN_IN_THE_LOOP,
    guardrails: Optional[Mapping[str, Any]] = None,
    trigger: Optional[TriggerInfo] = None,
    anchor: Optional[AnchorRef] = None,
    environment_summary_ref: Optional[str] = None,
    policy_context: Optional[List[Dict[str, Any]]] = None,
    invocation_budget: Optional[InvocationBudget] = None,
    correlation_id: Optional[UUID] = None,
) -> AgentInvocationEnvelope:
    """Construct a validated ``AgentInvocationEnvelope``.

    Validates guardrails up front so callers fail fast — agent-builder's
    runtime guardrail middleware should never see a malformed shape.

    ``correlation_id`` defaults to a fresh UUID4. Pass a value to thread an
    existing trace across services.
    """
    validate_guardrails(guardrails)

    return AgentInvocationEnvelope(
        workspace_id=workspace_id,
        workspace_type=workspace_type,
        tenant_id=tenant_id,
        namespace_id=namespace_id,
        attachment_id=attachment_id,
        role=role,
        responsibility=responsibility or {},
        autonomy_mode=autonomy_mode,
        guardrails=guardrails or {},
        trigger=trigger,
        anchor=anchor,
        environment_summary_ref=environment_summary_ref,
        policy_context=list(policy_context or []),
        invocation_budget=invocation_budget or InvocationBudget(),
        correlation_id=correlation_id or uuid.uuid4(),
        request_id=uuid.uuid4(),
    )


__all__ = [
    "AnchorRef",
    "TriggerInfo",
    "InvocationBudget",
    "AgentInvocationEnvelope",
    "build_invocation_envelope",
]
