"""Guardrails schema and merge helpers for workspace agent attachments.

A guardrails dict caps what a single agent invocation may do on a workspace.
The same schema is used in four places:

- ``workspace_agents.guardrails`` (JSONB column in pantheon-program-framework)
- ``AdvisorAttachment.guardrails`` (Pydantic field in agent-builder schemas)
- ``InvocationEnvelope.guardrails`` (this package's ``envelope.py``)
- Agent-builder execution-pipeline middleware (enforces ceilings at runtime)

This module is deliberately dependency-free — no Pydantic, no jsonschema — so
it can be imported from anywhere. Validation is hand-rolled and intentionally
minimal: enforce types and ranges, ignore unknown keys (forward-compat).

See §1.1 and §8.3 of the implementation guide.
"""

from __future__ import annotations

from typing import Any, Iterable, List, Mapping, Optional


# JSON Schema (dialect 2020-12-compatible subset) suitable for embedding in the
# OpenAPI 3.1 spec at docs/openapi/workspace-agents.openapi.yaml.
GUARDRAILS_JSON_SCHEMA: dict = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "title": "Guardrails",
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "actions_per_invocation": {"type": "integer", "minimum": 0},
        "actions_per_day": {"type": "integer", "minimum": 0},
        "max_usd_per_invocation": {"type": "number", "minimum": 0},
        "max_usd_per_day": {"type": "number", "minimum": 0},
        "max_wallclock_seconds": {"type": "integer", "minimum": 0},
        "max_tool_calls": {"type": "integer", "minimum": 0},
        "blast_radius_classes": {
            "type": "array",
            "items": {
                "type": "string",
                "enum": ["read_only", "internal_writes", "external_calls"],
            },
            "uniqueItems": True,
        },
        "blocked_tools": {
            "type": "array",
            "items": {"type": "string"},
            "uniqueItems": True,
        },
        "required_approvals_for": {
            "type": "array",
            "items": {"type": "string"},
            "uniqueItems": True,
        },
    },
}


_NUMERIC_FIELDS = (
    "actions_per_invocation",
    "actions_per_day",
    "max_usd_per_invocation",
    "max_usd_per_day",
    "max_wallclock_seconds",
    "max_tool_calls",
)

_LIST_FIELDS = (
    "blast_radius_classes",
    "blocked_tools",
    "required_approvals_for",
)

_BLAST_RADIUS_VALUES = {"read_only", "internal_writes", "external_calls"}


class GuardrailValidationError(ValueError):
    """Raised when a guardrails dict fails validation.

    The ``errors`` attribute is a list of ``(field, reason)`` tuples so callers
    can surface specific problems in HTTP 400 responses.
    """

    def __init__(self, errors: List[tuple]):
        self.errors = errors
        joined = "; ".join(f"{f}: {r}" for f, r in errors)
        super().__init__(f"invalid guardrails: {joined}")


def validate_guardrails(data: Optional[Mapping[str, Any]]) -> None:
    """Validate a guardrails dict. Raises ``GuardrailValidationError`` on failure.

    Accepts ``None`` and ``{}`` as valid (no ceilings = unrestricted, subject
    to tenant-level policy enforced elsewhere).
    """
    if data is None or len(data) == 0:
        return
    errors: List[tuple] = []

    for field in _NUMERIC_FIELDS:
        if field not in data:
            continue
        value = data[field]
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            errors.append((field, "must be a non-negative number"))
            continue
        if value < 0:
            errors.append((field, "must be >= 0"))

    for field in _LIST_FIELDS:
        if field not in data:
            continue
        value = data[field]
        if not isinstance(value, list):
            errors.append((field, "must be an array"))
            continue
        if not all(isinstance(v, str) for v in value):
            errors.append((field, "all entries must be strings"))
            continue
        if len(value) != len(set(value)):
            errors.append((field, "entries must be unique"))
        if field == "blast_radius_classes":
            bad = [v for v in value if v not in _BLAST_RADIUS_VALUES]
            if bad:
                errors.append((field, f"invalid values: {bad}"))

    if errors:
        raise GuardrailValidationError(errors)


def merge_guardrails(
    existing: Optional[Mapping[str, Any]],
    incoming: Optional[Mapping[str, Any]],
) -> dict:
    """Return guardrails representing the **stricter** of two inputs.

    Merge rules (§1.8.3 of the implementation guide):
    - Numeric ceilings: take the **minimum** of present values; if only one
      side is present, take it (the other side is "no ceiling on this field").
    - List restrictions (``blocked_tools``, ``required_approvals_for``,
      ``blast_radius_classes``): take the **union** — adding restrictions
      is always allowed.

    This function never relaxes guardrails. Inputs are not mutated; a new
    dict is returned. Either side may be ``None`` or empty.
    """
    a = dict(existing or {})
    b = dict(incoming or {})
    out: dict = {}

    for field in _NUMERIC_FIELDS:
        av, bv = a.get(field), b.get(field)
        if av is None and bv is None:
            continue
        if av is None:
            out[field] = bv
        elif bv is None:
            out[field] = av
        else:
            out[field] = min(av, bv)

    for field in _LIST_FIELDS:
        merged = _union_preserve_order(a.get(field) or [], b.get(field) or [])
        if merged:
            out[field] = merged

    return out


def _union_preserve_order(a: Iterable[str], b: Iterable[str]) -> List[str]:
    seen: set = set()
    out: List[str] = []
    for v in list(a) + list(b):
        if v not in seen:
            seen.add(v)
            out.append(v)
    return out


__all__ = [
    "GUARDRAILS_JSON_SCHEMA",
    "GuardrailValidationError",
    "validate_guardrails",
    "merge_guardrails",
]
