"""Thin helper that ties an agent invocation to a WorkspaceArtifactLedger entry.

The full ledger client already exists at ``pantheon_shared.ledger.client``.
This module is a *narrower* convenience for the common case: an autonomous
agent invocation just mutated something, and we want to record both the
audit row and the ledger row, tagged with the envelope's correlation_id and
attachment_id.

See §6.1 and §8.1 of ``docs/Agents_In_Workspaces_Implementation_Guide.md``.

Why a helper:
- Callers from sub-agent tool wrappers shouldn't have to remember to thread
  ``correlation_id`` and ``attachment_id`` into the underlying ledger client.
- Centralises the "agent did X" pattern so we can later swap the ledger
  schema (e.g. add ``attachment_id`` column on the ledger row) without
  touching every call site.
"""

from __future__ import annotations

from typing import Any, List, Literal, Optional
from uuid import UUID

from pantheon_shared.iam.context import IAMContext
from pantheon_shared.ledger.client import write_ledger_entry


async def record_agent_mutation(
    *,
    iam_context: IAMContext,
    envelope_dict: dict,                           # Output of AgentInvocationEnvelope.to_dict()
    audit_record_id: UUID,
    target_kind: str,
    target_id: str,
    mutation_kind: Literal["create", "update", "delete", "state_change"],
    pre_state: Optional[dict],
    post_state: Optional[dict],
    mutated_fields: Optional[List[str]] = None,
    db: Any = None,
) -> UUID:
    """Write a ledger entry for an agent-driven mutation.

    The envelope dict supplies ``correlation_id`` (mandatory) and
    ``attachment_id`` (mirrored into ``mutated_fields`` for filterability
    until the ledger row gets its own attachment_id column).

    Returns the new ledger entry's UUID.
    """
    correlation_id = UUID(str(envelope_dict["correlation_id"]))
    attachment_id = envelope_dict.get("attachment_id")

    # Until WorkspaceArtifactLedger gains a first-class attachment_id column,
    # surface the linkage in mutated_fields so admin queries can grep for it.
    extended_fields = list(mutated_fields or [])
    if attachment_id:
        extended_fields.append(f"_attachment_id={attachment_id}")

    return await write_ledger_entry(
        iam_context=iam_context,
        audit_record_id=audit_record_id,
        correlation_id=correlation_id,
        target_kind=target_kind,
        target_id=target_id,
        mutation_kind=mutation_kind,
        pre_state=pre_state,
        post_state=post_state,
        mutated_fields=extended_fields,
        db=db,
    )


__all__ = ["record_agent_mutation"]
