"""
Version API endpoint for pantheon-shared.

This module provides FastAPI endpoints to expose version information
including the package version and git commit SHA.
"""

from typing import Dict, Any
from fastapi import APIRouter
from pantheon_shared.version import (get_version, get_service_commit_sha,
                                     get_service_build_info)
from pydantic import BaseModel

router = APIRouter()


class VersionInfo(BaseModel):
    """Version information model."""
    version: str
    commit_sha: str


@router.get(
    "/version",
    response_model=Dict[str, Any],
    summary="Get version information",
    description="Retrieve version information including package version, service commit SHA, and pantheon-shared commit SHA",
    operation_id="get_version",
    tags=["version"],
    responses={
        200: {"description": "Version information retrieved successfully"},
    },
)
async def get_version_info():
    """
    Get version information for the service.

    Returns:
        Dictionary containing version, service/shared commit SHAs, their commit
        times, and the branch/dirty provenance for each.

    Note:
        - service_commit_sha: The git commit SHA of the service's own repository
        - shared_commit_sha: The git commit SHA of the pantheon-shared library
        - *_commit_time: committer date of the corresponding SHA (ISO-8601), or
          "unknown" for a build made before the stamp existed
    """
    version_info = get_version()
    service_commit = get_service_commit_sha()
    service_build = get_service_build_info()

    return {
        "status": "success",
        "data": {
            "version": version_info.version,
            "service_commit_sha": service_commit,
            "shared_commit_sha": version_info.commit_sha,
            # Build provenance. A `*_dirty` of True means the corresponding
            # commit SHA does NOT fully describe the running code, so treat it
            # as approximate. The service_* values come from the image build
            # args; the shared_* values from the wheel's own build stamp.
            "service_branch": service_build["branch"],
            "service_dirty": service_build["dirty"],
            "shared_branch": version_info.branch,
            "shared_dirty": version_info.dirty,
            # Committer date of each commit above, ISO-8601 with offset. A SHA
            # says WHICH build; the time says HOW OLD — the question an operator
            # actually asks. "unknown" on images/wheels built before these were
            # stamped; never substituted with a proxy (image mtime, "now"), which
            # would read as a commit date while being unrelated to one.
            "service_commit_time": service_build["commit_time"],
            "shared_commit_time": version_info.commit_time,
        }
    }


__all__ = ["router"]
