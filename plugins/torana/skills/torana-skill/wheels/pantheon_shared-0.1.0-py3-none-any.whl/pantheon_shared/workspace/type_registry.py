"""Workspace-type registry — replaces ad-hoc branching in program-framework.

Today, type-specific behavior (advisor allowlist, MSA stub, VM bootstrap) is
scattered across ``api/routes/workspace_advisor.py`` and friends. This module
is the single source of truth for "what does workspace type X bring with it"
so that adding a new domain (Security Review, msg-workspace, GRC) is a
registry entry rather than scattered conditionals.

See §1.7 and §10 of ``docs/Agents_In_Workspaces_Implementation_Guide.md``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Mapping, Optional

from pantheon_shared.workspace.agent_roles import (
    WorkspaceAgentAutonomyMode,
    WorkspaceAgentRole,
)
from pantheon_shared.workspace.types import WorkspaceType


@dataclass(frozen=True)
class DefaultAttachment:
    """One default workspace_agent attachment to seed at workspace creation."""

    agent_name: str
    role: WorkspaceAgentRole
    responsibility: Mapping[str, object] = field(default_factory=dict)
    autonomy_mode: WorkspaceAgentAutonomyMode = WorkspaceAgentAutonomyMode.HUMAN_IN_THE_LOOP
    guardrails: Mapping[str, object] = field(default_factory=dict)


@dataclass(frozen=True)
class WorkspaceTypeSpec:
    """Everything the platform needs to know about a workspace type.

    Used by:
    - program-framework's workspace-create flow (seeds ``default_attachments``)
    - the Advisor route (replaces ``_ADVISOR_SUPPORTED_WORKSPACE_TYPES``
      with ``WORKSPACE_TYPE_SPECS.get(type)`` and a ``None`` check)
    - the work-item router (consults ``work_item_kinds`` to know what source
      kinds this type produces)
    """

    type: WorkspaceType
    advisor_agent: str
    expert_agent: str
    default_attachments: List[DefaultAttachment] = field(default_factory=list)
    work_item_kinds: List[str] = field(default_factory=list)
    build_tools_extras: List[str] = field(default_factory=list)
    home_layout_template: str = ""


def _vm() -> WorkspaceTypeSpec:
    """VM workspace defaults — 5 attachments, one per role.

    advisor:  Program Advisor Agent runs sweeps + emits proposals.
    builder:  VM Expert drives Build-tab chat and Build-in-Chat. Home Page
              Agent is **not** seeded here; it's a sub-agent of VM Expert
              that the expert delegates to internally for landing-page work.
    build_v2: VM Builder V2 drives the Build-V2 tab chat and cook flow (it is
              blueprint/artifact-state aware, unlike the v1 builder).
    operator: VM Operator Agent backs the "Ask the App" chat rail across
              user-facing surfaces (Home, Dashboards, Inbox) and on-demand
              operational actions.
    triage:   VM Triage Agent processes incoming alerts (severity high+).
    """
    return WorkspaceTypeSpec(
        type=WorkspaceType.VULNERABILITY_MANAGEMENT,
        advisor_agent="Program Advisor Agent",
        expert_agent="Vulnerability Management Expert",
        default_attachments=[
            DefaultAttachment(
                agent_name="Program Advisor Agent",
                role=WorkspaceAgentRole.ADVISOR,
            ),
            DefaultAttachment(
                agent_name="Vulnerability Management Expert",
                role=WorkspaceAgentRole.BUILDER,
            ),
            # NO BUILD_V2 here. The plain vulnerability_management type must NOT seed the build_v2
            # vertical — that lives only on VULNERABILITY_MANAGEMENT_V2 (see _vm_v2). This is the
            # isolation boundary: an old-template VM app never gets build_v2 (Agent Team §8.5c).
            DefaultAttachment(
                agent_name="Vulnerability Management Operator Agent",
                role=WorkspaceAgentRole.OPERATOR,
                responsibility={"surfaces": ["landing_page", "dashboards", "inbox"]},
            ),
            DefaultAttachment(
                agent_name="Vulnerability Management Triage Agent",
                role=WorkspaceAgentRole.TRIAGE,
                responsibility={
                    "work_item_kinds": ["alert"],
                    "severity_floor": "high",
                },
                autonomy_mode=WorkspaceAgentAutonomyMode.HUMAN_IN_THE_LOOP,
            ),
        ],
        work_item_kinds=["alert", "finding"],
        build_tools_extras=["kev_match", "get_rule_run_results"],
        home_layout_template="vm_default_v1",
    )


def _vm_v2() -> WorkspaceTypeSpec:
    """Vulnerability Management V2 defaults — the isolated build_v2 (L0-L3) vertical.

    Used by the "Vulnerability Management V2" workspace template (its `category` normalizes to
    ``vulnerability_management_v2``). Mirrors ``_vm()`` but seeds the V2 agents AND the build_v2
    role. Apps of this type get the Build-V2 experience; plain-VM apps never do. See Agent Team
    re-architecture §8 (isolation) + §8.5c (why a distinct type is the only durable discriminator).
    """
    return WorkspaceTypeSpec(
        type=WorkspaceType.VULNERABILITY_MANAGEMENT_V2,
        advisor_agent="Program Advisor Agent",
        expert_agent="VM-Expert V2",
        default_attachments=[
            # The shipping V2 role agents (the _min A/B experiment agents were retired + DELETED
            # after the experiment concluded — see project_minimalist_role_agents. The lean design
            # they proved was adopted INTO these V2 agents). advisor→Program Advisor Agent (no V2
            # advisor exists), operator→Operator Agent V2, triage→Triage Agent V2, builder→VM-Expert V2.
            DefaultAttachment(
                agent_name="Program Advisor Agent",
                role=WorkspaceAgentRole.ADVISOR,
            ),
            DefaultAttachment(
                agent_name="VM-Expert V2",
                role=WorkspaceAgentRole.BUILDER,
            ),
            # NOTE: no build_v2 team slot. The `build_v2` ROLE was retired (Arm B) — Build-V2 is now
            # gated purely by the workspace TYPE (VULNERABILITY_MANAGEMENT_V2), not a fifth agent
            # attachment. The cook engine ("Vulnerability Management Builder V2") is still reached by
            # NAME via BUILD_V2_COOK_AGENT_NAME — it is headless infrastructure behind the Build
            # button, not a visible team member. See project_build_v2_role_retirement.
            DefaultAttachment(
                agent_name="Vulnerability Management Operator Agent V2",
                role=WorkspaceAgentRole.OPERATOR,
                responsibility={"surfaces": ["landing_page", "dashboards", "inbox"]},
            ),
            DefaultAttachment(
                agent_name="Vulnerability Management Triage Agent V2",
                role=WorkspaceAgentRole.TRIAGE,
                responsibility={
                    "work_item_kinds": ["alert"],
                    "severity_floor": "high",
                },
                autonomy_mode=WorkspaceAgentAutonomyMode.HUMAN_IN_THE_LOOP,
            ),
        ],
        work_item_kinds=["alert", "finding"],
        build_tools_extras=["kev_match", "get_rule_run_results"],
        home_layout_template="vm_default_v1",
    )


def _msa() -> WorkspaceTypeSpec:
    """MSA Review workspace defaults — no triage stream today.

    Three attachments. MSA still uses the curated stub Advisor (see §1.7
    of the implementation guide) until a tailored MSA Advisor ships.
    """
    return WorkspaceTypeSpec(
        type=WorkspaceType.MSA_REVIEW,
        advisor_agent="Program Advisor Agent",   # MSA still uses stub today; see §1.7
        expert_agent="MSA Review Expert",
        default_attachments=[
            DefaultAttachment(
                agent_name="Program Advisor Agent",
                role=WorkspaceAgentRole.ADVISOR,
            ),
            DefaultAttachment(
                agent_name="MSA Review Expert",
                role=WorkspaceAgentRole.BUILDER,
            ),
            DefaultAttachment(
                agent_name="MSA Review Expert",
                role=WorkspaceAgentRole.OPERATOR,
                responsibility={"surfaces": ["landing_page"]},
            ),
        ],
        work_item_kinds=["review_task", "obligation_breach"],
        home_layout_template="msa_default_v1",
    )


def _security_review() -> WorkspaceTypeSpec:
    """Security Review workspace — review tasks, threat modeling, attestation.

    Single domain expert in all four operational roles. Same agent, different
    invocation contexts (proposing, building, conversing, triaging review
    tasks against frameworks). The Security Review Expert seed lives at
    ``pantheon-agent-builder/agents/security_review_expert.json``.
    """
    return WorkspaceTypeSpec(
        type=WorkspaceType.SECURITY_REVIEW,
        advisor_agent="Security Review Expert",
        expert_agent="Security Review Expert",
        default_attachments=[
            DefaultAttachment(
                agent_name="Security Review Expert",
                role=WorkspaceAgentRole.ADVISOR,
            ),
            DefaultAttachment(
                agent_name="Security Review Expert",
                role=WorkspaceAgentRole.BUILDER,
            ),
            DefaultAttachment(
                agent_name="Security Review Expert",
                role=WorkspaceAgentRole.OPERATOR,
                responsibility={"surfaces": ["landing_page"]},
            ),
            DefaultAttachment(
                agent_name="Security Review Expert",
                role=WorkspaceAgentRole.TRIAGE,
                responsibility={
                    "work_item_kinds": ["review_task"],
                    "frameworks": ["soc2", "iso27001"],
                },
            ),
        ],
        work_item_kinds=["review_task", "finding", "exception_request"],
        home_layout_template="security_review_default_v1",
    )


def _msg_workspace() -> WorkspaceTypeSpec:
    """Message workspace — inbound chat / email / Slack triage.

    No proposal/build flow today — operator + triage only. Auto-Responder
    is a second triage attachment with narrower scope (work_item_kinds=
    ['message']) running at suggest_only so it never sends without review.
    """
    return WorkspaceTypeSpec(
        type=WorkspaceType.MSG_WORKSPACE,
        advisor_agent="Message Triage Agent",   # placeholder; no real advisor today
        expert_agent="Message Triage Agent",
        default_attachments=[
            DefaultAttachment(
                agent_name="Message Triage Agent",
                role=WorkspaceAgentRole.OPERATOR,
                responsibility={"surfaces": ["landing_page"]},
            ),
            DefaultAttachment(
                agent_name="Message Triage Agent",
                role=WorkspaceAgentRole.TRIAGE,
                responsibility={"work_item_kinds": ["message"]},
                autonomy_mode=WorkspaceAgentAutonomyMode.HUMAN_IN_THE_LOOP,
            ),
            DefaultAttachment(
                agent_name="Auto-Responder Agent",
                role=WorkspaceAgentRole.TRIAGE,
                responsibility={
                    "work_item_kinds": ["message"],
                    "auto_reply": True,
                },
                # Auto-replies are sensitive — start at suggest_only and let
                # the builder opt up.
                autonomy_mode=WorkspaceAgentAutonomyMode.SUGGEST_ONLY,
            ),
        ],
        work_item_kinds=["message"],
        home_layout_template="msg_workspace_default_v1",
    )


WORKSPACE_TYPE_SPECS: Dict[WorkspaceType, WorkspaceTypeSpec] = {
    WorkspaceType.VULNERABILITY_MANAGEMENT: _vm(),
    WorkspaceType.VULNERABILITY_MANAGEMENT_V2: _vm_v2(),
    WorkspaceType.MSA_REVIEW: _msa(),
    WorkspaceType.SECURITY_REVIEW: _security_review(),
    WorkspaceType.MSG_WORKSPACE: _msg_workspace(),
}


def get_spec(workspace_type: WorkspaceType) -> Optional[WorkspaceTypeSpec]:
    """Lookup spec; returns ``None`` for types without a registry entry."""
    return WORKSPACE_TYPE_SPECS.get(workspace_type)


def is_advisor_supported(workspace_type: WorkspaceType) -> bool:
    """Replacement for ``_ADVISOR_SUPPORTED_WORKSPACE_TYPES`` allowlist."""
    return workspace_type in WORKSPACE_TYPE_SPECS


__all__ = [
    "DefaultAttachment",
    "WorkspaceTypeSpec",
    "WORKSPACE_TYPE_SPECS",
    "get_spec",
    "is_advisor_supported",
]
