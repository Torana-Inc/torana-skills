"""WorkspaceType enumeration — single source of truth for workspace type values.

The canonical storage value is the enum's `.value` (snake_case string).
Display names (title-case) come from template categories and must be
normalised to a WorkspaceType before being stored in the DB.

Usage:
    from pantheon_shared.workspace.types import WorkspaceType

    wt = WorkspaceType.from_display("Vulnerability Management")
    # → WorkspaceType.VULNERABILITY_MANAGEMENT

    wt.value  # → "vulnerability_management"
"""

from __future__ import annotations

import enum
from typing import Optional


class WorkspaceType(str, enum.Enum):
    """Canonical workspace type values stored in workspaces.type."""

    VULNERABILITY_MANAGEMENT = "vulnerability_management"
    # build_v2 vertical — the "Vulnerability Management V2" template maps here. Distinct type so the
    # V2 (L0-L3) agents + the build_v2 experience are seeded ONLY for V2 apps; the plain
    # `vulnerability_management` type never seeds build_v2. This is the durable isolation boundary
    # (Agent Team re-architecture §8.5c). Template `category` "Vulnerability Management V2" normalizes
    # here via from_raw.
    VULNERABILITY_MANAGEMENT_V2 = "vulnerability_management_v2"
    ALERT_TRIAGE = "alert_triage"
    COMPLIANCE = "compliance"
    CUSTOM = "custom"
    GRC = "grc"
    INCIDENT_RESPONSE = "incident_response"
    MSA_REVIEW = "msa_review"
    MSG_WORKSPACE = "msg_workspace"  # Block 9 — inbound message triage workspace
    RISK_MANAGEMENT = "risk_management"
    SECURITY_ARCHITECTURE = "security_architecture"
    SECURITY_REVIEW = "security_review"  # Block 9 — security review program
    SOC = "soc"
    THIRD_PARTY_RISK = "third_party_risk"

    @classmethod
    def from_raw(cls, value: Optional[str]) -> Optional["WorkspaceType"]:
        """Coerce a raw string (snake_case or display name) to WorkspaceType.

        Returns None if value is None or unrecognised rather than raising,
        so callers can decide how to handle unknown types gracefully.
        """
        if value is None:
            return None
        normalized = value.strip().lower().replace(" ", "_").replace("-", "_")
        try:
            return cls(normalized)
        except ValueError:
            return None
