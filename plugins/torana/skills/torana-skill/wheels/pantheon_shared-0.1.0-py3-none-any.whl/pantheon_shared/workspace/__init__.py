"""
Pantheon Workspace Module

Provides workspace resolution and utilities mirroring the namespace pattern.
"""

from pantheon_shared.workspace.resolver import (
    get_default_workspace_id,
    aget_default_workspace_id,
    set_cached_workspace_id,
    clear_workspace_cache,
)
from pantheon_shared.workspace.types import WorkspaceType
from pantheon_shared.workspace.utils import get_workspace_id
from pantheon_shared.workspace.agent_roles import (
    WorkspaceAgentAutonomyMode,
    WorkspaceAgentRole,
)
from pantheon_shared.workspace.type_registry import (
    DefaultAttachment,
    WORKSPACE_TYPE_SPECS,
    WorkspaceTypeSpec,
    get_spec,
    is_advisor_supported,
)

__all__ = [
    "get_default_workspace_id",
    "aget_default_workspace_id",
    "set_cached_workspace_id",
    "clear_workspace_cache",
    "get_workspace_id",
    "WorkspaceType",
    "WorkspaceAgentRole",
    "WorkspaceAgentAutonomyMode",
    "DefaultAttachment",
    "WorkspaceTypeSpec",
    "WORKSPACE_TYPE_SPECS",
    "get_spec",
    "is_advisor_supported",
]
