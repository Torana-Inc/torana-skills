"""
Workspace Resolver — mirrors namespace resolution pattern.

Resolves the default workspace_id for a (tenant_id, namespace_id) pair.
Resolution order:
  1. In-memory cache
  2. HTTP call to pantheon-program-framework internal endpoint
  3. None (caller should reject the operation)

Cache key: (tenant_id, namespace_id) → workspace_id string
Cache is indefinite (default workspace never changes) unless DISABLE_TENANT_WS_CACHE=true.
"""

import os
import logging
from typing import Optional, Dict, Tuple

logger = logging.getLogger(__name__)


_DEFAULT_WORKSPACE_PATH = "/api/v1/internal/workspaces/default"
_MAX_RETRIES = 3
_INITIAL_RETRY_DELAY = 0.5
_TIMEOUT_SECONDS = 5.0


def _is_terminal_status(status_code: int) -> bool:
    """True for a status that a retry cannot fix.

    401/403 mean the service token was rejected and 404 means no default
    workspace exists — all configuration faults. Retrying only adds latency
    (1.5s of backoff) before failing identically. 429 is excluded: it is a
    4xx that explicitly asks the caller to try again later.
    """
    return 400 <= status_code < 500 and status_code != 429


def _default_ppf_url() -> str:
    """Resolve the PPF base URL.

    Mirrors ``events/emitter.py`` — the other pantheon-shared caller of this
    same service. ``PROGRAM_SERVICE_URL`` is the platform-wide convention; the
    helper falls back to the per-service host/port vars and finally to the
    built-in default, so this resolves correctly on every deployment target.

    The previous hardcoded ``pantheon-program-framework-dev:8009`` was the
    localhost-only container name and does not resolve on classie or GKE.
    """
    from pantheon_shared.pantheon_services import (
        PantheonService,
        get_pantheon_service_url,
    )

    return get_pantheon_service_url(
        PantheonService.PROGRAM_FRAMEWORK, url_env_var="PROGRAM_SERVICE_URL"
    ).rstrip("/")


# Cache: (tenant_id, namespace_id) → default_workspace_id
_tenant_workspace_cache: Dict[Tuple[str, str], str] = {}

_disable_cache = os.getenv('DISABLE_TENANT_WS_CACHE', 'false').lower() in ('true', '1', 'yes')


def get_default_workspace_id(
    tenant_id: str,
    namespace_id: str,
    ppf_base_url: Optional[str] = None
) -> Optional[str]:
    """
    Get the default workspace ID for a tenant/namespace pair (synchronous).

    Mirrors: pantheon_shared.iam.utils.get_or_create_default_namespace_id()

    Returns None if PPF is unreachable and cache is cold — caller must reject.
    """
    cache_key = (str(tenant_id), str(namespace_id))

    if not _disable_cache and cache_key in _tenant_workspace_cache:
        return _tenant_workspace_cache[cache_key]

    ppf_url = ppf_base_url or _default_ppf_url()
    workspace_id = _fetch_default_workspace_from_ppf(str(tenant_id), str(namespace_id), ppf_url)

    if workspace_id and not _disable_cache:
        _tenant_workspace_cache[cache_key] = workspace_id

    return workspace_id


async def aget_default_workspace_id(
    tenant_id: str,
    namespace_id: str,
    ppf_base_url: Optional[str] = None
) -> Optional[str]:
    """
    Get the default workspace ID for a tenant/namespace pair (async).

    Use this in async service code (FastAPI endpoints, service methods).
    """
    cache_key = (str(tenant_id), str(namespace_id))

    if not _disable_cache and cache_key in _tenant_workspace_cache:
        return _tenant_workspace_cache[cache_key]

    ppf_url = ppf_base_url or _default_ppf_url()
    workspace_id = await _afetch_default_workspace_from_ppf(str(tenant_id), str(namespace_id), ppf_url)

    if workspace_id and not _disable_cache:
        _tenant_workspace_cache[cache_key] = workspace_id

    return workspace_id


def set_cached_workspace_id(tenant_id: str, namespace_id: str, workspace_id: str):
    """Explicitly set cache entry — used during tenant bootstrap and testing."""
    if not _disable_cache:
        _tenant_workspace_cache[(str(tenant_id), str(namespace_id))] = workspace_id


def clear_workspace_cache():
    """Clear the workspace cache — for testing."""
    global _tenant_workspace_cache
    _tenant_workspace_cache = {}


def _fetch_default_workspace_from_ppf(
    tenant_id: str,
    namespace_id: str,
    ppf_url: str
) -> Optional[str]:
    """Synchronous HTTP call to PPF to get default workspace ID.

    Uses PantheonSyncClient for the service JWT: the target router is mounted
    behind ``require_internal_caller``, which rejects an unauthenticated
    request with 401. A bare ``requests.get`` here returned None on every call.
    """
    from pantheon_shared.http.factory import create_pantheon_sync_client
    import time

    url = f"{ppf_url}{_DEFAULT_WORKSPACE_PATH}"
    params = {"tenant_id": tenant_id, "namespace_id": namespace_id}

    retry_delay = _INITIAL_RETRY_DELAY

    for attempt in range(_MAX_RETRIES):
        try:
            with create_pantheon_sync_client(
                tenant_id=tenant_id,
                namespace_id=namespace_id,
                timeout=_TIMEOUT_SECONDS,
            ) as client:
                resp = client.get(url, params=params)
            if resp.status_code == 200:
                return str(resp.json()["id"])
            logger.warning(
                f"PPF returned {resp.status_code} for default workspace "
                f"(tenant={tenant_id}, attempt {attempt + 1}/{_MAX_RETRIES})"
            )
            # 4xx is a configuration/authorization fault, not a transient one —
            # retrying just burns the backoff before failing identically.
            if _is_terminal_status(resp.status_code):
                return None
        except Exception as e:
            logger.warning(
                f"Failed to reach PPF for default workspace "
                f"(tenant={tenant_id}, attempt {attempt + 1}/{_MAX_RETRIES}): {e}"
            )

        if attempt < _MAX_RETRIES - 1:
            time.sleep(retry_delay)
            retry_delay *= 2

    return None


async def _afetch_default_workspace_from_ppf(
    tenant_id: str,
    namespace_id: str,
    ppf_url: str
) -> Optional[str]:
    """Async HTTP call to PPF to get default workspace ID.

    Uses PantheonClient for the service JWT — see the sync twin above.
    """
    from pantheon_shared.http.factory import create_pantheon_client
    import asyncio

    url = f"{ppf_url}{_DEFAULT_WORKSPACE_PATH}"
    params = {"tenant_id": tenant_id, "namespace_id": namespace_id}

    retry_delay = _INITIAL_RETRY_DELAY

    for attempt in range(_MAX_RETRIES):
        try:
            async with create_pantheon_client(
                tenant_id=tenant_id,
                namespace_id=namespace_id,
                timeout=_TIMEOUT_SECONDS,
            ) as client:
                resp = await client.get(url, params=params)
            if resp.status_code == 200:
                return str(resp.json()["id"])
            logger.warning(
                f"PPF returned {resp.status_code} for default workspace "
                f"(tenant={tenant_id}, attempt {attempt + 1}/{_MAX_RETRIES})"
            )
            # See the sync twin: 4xx will not fix itself on a retry.
            if _is_terminal_status(resp.status_code):
                return None
        except Exception as e:
            logger.warning(
                f"Failed to reach PPF for default workspace "
                f"(tenant={tenant_id}, attempt {attempt + 1}/{_MAX_RETRIES}): {e}"
            )

        if attempt < _MAX_RETRIES - 1:
            await asyncio.sleep(retry_delay)
            retry_delay *= 2

    return None
