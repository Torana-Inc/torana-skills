"""
Workspace Resolver — mirrors namespace resolution pattern.

Resolves the default workspace_id for a (tenant_id, namespace_id) pair.
Resolution order:
  1. In-memory cache
  2. HTTP call to pantheon-program-framework internal endpoint
  3. None (caller should reject the operation)

Cache key: (tenant_id, namespace_id) → workspace_id string
Cache is indefinite (default workspace never changes) unless DISABLE_TENANT_WS_CACHE=true.
"""

import os
import logging
from typing import Optional, Dict, Tuple

logger = logging.getLogger(__name__)

# Cache: (tenant_id, namespace_id) → default_workspace_id
_tenant_workspace_cache: Dict[Tuple[str, str], str] = {}

_disable_cache = os.getenv('DISABLE_TENANT_WS_CACHE', 'false').lower() in ('true', '1', 'yes')


def get_default_workspace_id(
    tenant_id: str,
    namespace_id: str,
    ppf_base_url: Optional[str] = None
) -> Optional[str]:
    """
    Get the default workspace ID for a tenant/namespace pair (synchronous).

    Mirrors: pantheon_shared.iam.utils.get_or_create_default_namespace_id()

    Returns None if PPF is unreachable and cache is cold — caller must reject.
    """
    cache_key = (str(tenant_id), str(namespace_id))

    if not _disable_cache and cache_key in _tenant_workspace_cache:
        return _tenant_workspace_cache[cache_key]

    ppf_url = ppf_base_url or os.getenv("PPF_BASE_URL", "http://pantheon-program-framework-dev:8009")
    workspace_id = _fetch_default_workspace_from_ppf(str(tenant_id), str(namespace_id), ppf_url)

    if workspace_id and not _disable_cache:
        _tenant_workspace_cache[cache_key] = workspace_id

    return workspace_id


async def aget_default_workspace_id(
    tenant_id: str,
    namespace_id: str,
    ppf_base_url: Optional[str] = None
) -> Optional[str]:
    """
    Get the default workspace ID for a tenant/namespace pair (async).

    Use this in async service code (FastAPI endpoints, service methods).
    """
    cache_key = (str(tenant_id), str(namespace_id))

    if not _disable_cache and cache_key in _tenant_workspace_cache:
        return _tenant_workspace_cache[cache_key]

    ppf_url = ppf_base_url or os.getenv("PPF_BASE_URL", "http://pantheon-program-framework-dev:8009")
    workspace_id = await _afetch_default_workspace_from_ppf(str(tenant_id), str(namespace_id), ppf_url)

    if workspace_id and not _disable_cache:
        _tenant_workspace_cache[cache_key] = workspace_id

    return workspace_id


def set_cached_workspace_id(tenant_id: str, namespace_id: str, workspace_id: str):
    """Explicitly set cache entry — used during tenant bootstrap and testing."""
    if not _disable_cache:
        _tenant_workspace_cache[(str(tenant_id), str(namespace_id))] = workspace_id


def clear_workspace_cache():
    """Clear the workspace cache — for testing."""
    global _tenant_workspace_cache
    _tenant_workspace_cache = {}


def _fetch_default_workspace_from_ppf(
    tenant_id: str,
    namespace_id: str,
    ppf_url: str
) -> Optional[str]:
    """Synchronous HTTP call to PPF to get default workspace ID."""
    import requests
    import time

    url = f"{ppf_url}/api/v1/internal/workspaces/default"
    params = {"tenant_id": tenant_id, "namespace_id": namespace_id}

    max_retries = 3
    retry_delay = 0.5

    for attempt in range(max_retries):
        try:
            resp = requests.get(url, params=params, timeout=5)
            if resp.status_code == 200:
                data = resp.json()
                return str(data["id"])
            logger.warning(
                f"PPF returned {resp.status_code} for default workspace "
                f"(tenant={tenant_id}, attempt {attempt + 1}/{max_retries})"
            )
        except Exception as e:
            logger.warning(
                f"Failed to reach PPF for default workspace "
                f"(tenant={tenant_id}, attempt {attempt + 1}/{max_retries}): {e}"
            )

        if attempt < max_retries - 1:
            time.sleep(retry_delay)
            retry_delay *= 2

    return None


async def _afetch_default_workspace_from_ppf(
    tenant_id: str,
    namespace_id: str,
    ppf_url: str
) -> Optional[str]:
    """Async HTTP call to PPF to get default workspace ID."""
    import httpx
    import asyncio

    url = f"{ppf_url}/api/v1/internal/workspaces/default"
    params = {"tenant_id": tenant_id, "namespace_id": namespace_id}

    max_retries = 3
    retry_delay = 0.5

    async with httpx.AsyncClient(timeout=5.0) as client:
        for attempt in range(max_retries):
            try:
                resp = await client.get(url, params=params)
                if resp.status_code == 200:
                    data = resp.json()
                    return str(data["id"])
                logger.warning(
                    f"PPF returned {resp.status_code} for default workspace "
                    f"(tenant={tenant_id}, attempt {attempt + 1}/{max_retries})"
                )
            except Exception as e:
                logger.warning(
                    f"Failed to reach PPF for default workspace "
                    f"(tenant={tenant_id}, attempt {attempt + 1}/{max_retries}): {e}"
                )

            if attempt < max_retries - 1:
                await asyncio.sleep(retry_delay)
                retry_delay *= 2

    return None
