"""Roles and autonomy modes for workspace_agent attachments.

Single source of truth for the role/autonomy enums introduced by
``docs/Agents_In_Workspaces_Implementation_Guide.md`` in pantheon-program-framework.

These values are the canonical storage form (``.value``) used in:
- ``workspace_agents.role`` (program-framework)
- ``AdvisorAttachment.role`` (agent-builder Program Advisor schema)
- ``WorkspaceAgentAttachmentCreate.role`` (FE + OpenAPI)

Keep this module dependency-free so it can be imported from any service.
"""

from __future__ import annotations

import enum
from typing import Optional


class WorkspaceAgentRole(str, enum.Enum):
    """Role an agent plays in a workspace.

    Four roles, one per product surface:

    * ``advisor``  — runs sweeps, emits proposals on the Build tab. Platform-
      level agent (e.g. Program Advisor Agent) but attached per workspace so
      audit and Recent Runs can bind by ``attachment_id``.
    * ``builder``  — backs Build-tab chat (Ask the Builder) and the
      "Build in Chat" flow on an approved proposal. The workspace's domain
      expert in build mode.
    * ``operator`` — backs the workspace's Home Chat panel and on-demand
      operational actions. The workspace's domain expert in operate mode.
      Frequently the same agent as ``builder`` (e.g. VM Expert) but the
      attachment is distinct so behaviour can diverge per context.
    * ``triage``   — handles incoming work items (alerts, messages, review
      tasks). Fires via the event bus, routing rules, or scheduled tasks.

    Specialty roles (``remediation``, ``reviewer``, ``auditor``, ``scheduler``,
    ``chat``) collapsed into these four during the agents-in-workspace
    consolidation. Scoped specialists (e.g. a Remediation Drafter for cloud
    assets) are now expressed as additional ``triage`` or ``operator``
    attachments with a narrow ``responsibility`` rather than fresh roles.
    """

    ADVISOR = "advisor"          # Proposes + runs sweeps (Build tab attention list)
    BUILDER = "builder"          # Build-tab chat + Build-in-Chat (domain expert, build mode)
    OPERATOR = "operator"        # Home Chat + ad-hoc actions (domain expert, operate mode)
    TRIAGE = "triage"            # Incoming work item handler (alerts / messages / review tasks)
    # NOTE: a `build_v2` role was briefly added here (Arm B) then RETIRED — Build-V2 is gated by the
    # workspace TYPE (VULNERABILITY_MANAGEMENT_V2), not a fifth role; the cook engine is reached by
    # name. from_raw("build_v2") now returns None (graceful) so any stale DB row won't crash.
    # See project_build_v2_role_retirement.

    @classmethod
    def from_raw(cls, value: Optional[str]) -> Optional["WorkspaceAgentRole"]:
        """Coerce a raw string (any case, dashes/spaces tolerated) to a role.

        Returns ``None`` for unrecognised values rather than raising so callers
        can decide how to handle drift gracefully. Mirrors ``WorkspaceType.from_raw``.
        """
        if value is None:
            return None
        normalized = value.strip().lower().replace(" ", "_").replace("-", "_")
        try:
            return cls(normalized)
        except ValueError:
            return None


class WorkspaceAgentAutonomyMode(str, enum.Enum):
    """How much an attachment is allowed to mutate without a human in the loop.

    Order is *increasing autonomy*: comparing the indices in ``_ORDER`` lets
    callers pick the stricter of two modes when merging guardrails on idempotent
    upserts (see §1.8.3 of the implementation guide).
    """

    SUGGEST_ONLY = "suggest_only"
    HUMAN_IN_THE_LOOP = "human_in_the_loop"
    AUTONOMOUS_WITH_GUARDRAILS = "autonomous_with_guardrails"

    @classmethod
    def from_raw(cls, value: Optional[str]) -> Optional["WorkspaceAgentAutonomyMode"]:
        if value is None:
            return None
        normalized = value.strip().lower().replace(" ", "_").replace("-", "_")
        try:
            return cls(normalized)
        except ValueError:
            return None

    @classmethod
    def stricter(
        cls,
        a: "WorkspaceAgentAutonomyMode",
        b: "WorkspaceAgentAutonomyMode",
    ) -> "WorkspaceAgentAutonomyMode":
        """Return the more conservative of two autonomy modes.

        Used by the idempotent ``POST /workspaces/{id}/agents`` endpoint to
        ensure merging an existing attachment with new requested modes never
        silently relaxes autonomy.
        """
        return a if _ORDER.index(a) <= _ORDER.index(b) else b


_ORDER = [
    WorkspaceAgentAutonomyMode.SUGGEST_ONLY,
    WorkspaceAgentAutonomyMode.HUMAN_IN_THE_LOOP,
    WorkspaceAgentAutonomyMode.AUTONOMOUS_WITH_GUARDRAILS,
]


__all__ = [
    "WorkspaceAgentRole",
    "WorkspaceAgentAutonomyMode",
]
