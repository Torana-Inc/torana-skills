"""
Workspace utility functions.

Mirrors: pantheon_shared.iam.utils (ensure_iam_fields pattern)
"""

from typing import Optional, TYPE_CHECKING

try:
    from fastapi import Query as _Query

    def get_workspace_id(
        workspace_id: Optional[str] = _Query(None, description="Filter results by workspace ID")
    ) -> Optional[str]:
        """FastAPI dependency — extracts workspace_id from ?workspace_id= query param.

        Usage:
            from pantheon_shared.workspace import get_workspace_id

            @router.get("/rules")
            async def list_rules(workspace_id: Optional[str] = Depends(get_workspace_id)):
                ...
        """
        return workspace_id

except ImportError:
    # fastapi not available (e.g. scripts, tests without FastAPI)
    def get_workspace_id(workspace_id=None):  # type: ignore[misc]
        return workspace_id

if TYPE_CHECKING:
    from pantheon_shared.iam.context import IAMContext


def ensure_workspace_field(
    obj_data: dict,
    iam_context: 'IAMContext',
    workspace_id: Optional[str] = None
) -> dict:
    """
    Ensure workspace_id is present in object data (synchronous).

    Mirrors: pantheon_shared.iam.utils.ensure_iam_fields()

    Args:
        obj_data: Data dict for the artifact
        iam_context: IAMContext with tenant_id and namespace_id
        workspace_id: Explicit workspace_id (from request body) — takes priority

    Returns:
        Updated dict with workspace_id set

    Raises:
        ValueError: If workspace cannot be resolved and no explicit ID given
    """
    if workspace_id:
        obj_data['workspace_id'] = workspace_id
        return obj_data

    if 'workspace_id' in obj_data and obj_data['workspace_id']:
        return obj_data

    from pantheon_shared.workspace.resolver import get_default_workspace_id
    resolved = get_default_workspace_id(
        str(iam_context.tenant_id),
        str(iam_context.namespace_id)
    )
    if resolved is None:
        raise ValueError(
            "Cannot resolve default workspace. "
            "Ensure pantheon-program-framework is running."
        )
    obj_data['workspace_id'] = resolved
    return obj_data


async def aensure_workspace_field(
    obj_data: dict,
    iam_context: 'IAMContext',
    workspace_id: Optional[str] = None
) -> dict:
    """
    Ensure workspace_id is present in object data (async).

    Use this in async service code.
    """
    if workspace_id:
        obj_data['workspace_id'] = workspace_id
        return obj_data

    if 'workspace_id' in obj_data and obj_data['workspace_id']:
        return obj_data

    from pantheon_shared.workspace.resolver import aget_default_workspace_id
    resolved = await aget_default_workspace_id(
        str(iam_context.tenant_id),
        str(iam_context.namespace_id)
    )
    if resolved is None:
        raise ValueError(
            "Cannot resolve default workspace. "
            "Ensure pantheon-program-framework is running."
        )
    obj_data['workspace_id'] = resolved
    return obj_data
