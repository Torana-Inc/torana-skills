"""Where a platform row came from, in the words a person uses, and as of when.

Every sink row carries `source_system` and `contributing_sources`:
    { "<provider>:<integration id | push>": { data_source, last_seen, first_seen, runs } }
`push` marks a source that sent its data to us (a scanner upload, the entity-graph reconciler) rather than being polled.
The datalake and the graph are OUR COPY of each source as of its last sync, so the time is "as of", never "now".
"""
from __future__ import annotations

from .times import latest, pt

_SCANNERS = {
    "gcp_container_analysis": "GCP Container Analysis",
    "gcp_security_command_center": "GCP Security Command Center",
    "dependabot": "GitHub Dependabot",
    "semgrep": "Semgrep",
    "gitleaks": "Gitleaks",
    "trivy-image": "Trivy", "trivy-fs": "Trivy", "trivy-config": "Trivy",
}
_SYSTEMS = {
    "kubernetes": "GKE cluster",
    "github": "GitHub",
    "cloudflare": "Cloudflare",
    "gcp": "GCP",
    "sarif": "SARIF upload",
    "semgrep": "Semgrep", "gitleaks": "Gitleaks", "trivy-image": "Trivy", "trivy-fs": "Trivy", "trivy-config": "Trivy",
    "torana-entity-graph-reconciler": "Torana entity graph",
    "servicenow": "ServiceNow", "crowdstrike": "CrowdStrike", "qualys": "Qualys", "splunk": "Splunk", "elasticsearch": "Elasticsearch",
}
_TABLE_SYSTEMS = {("artifacts", "gcp"): "GCP Artifact Registry", ("assets", "servicenow"): "ServiceNow CMDB"}
CVE_FEEDS = "NVD · FIRST EPSS · CISA KEV"
ASSET_INVENTORY = "Asset inventory"


def source_name(table: str, system: str | None, scanner: str | None = None, pushed: bool = False) -> str | None:
    """The user-facing name of a row's source. A scanner row names its scanner ("via push" when it was uploaded)."""
    name = _SCANNERS.get(scanner or "") if table == "vulnerabilities" else None
    name = name or _TABLE_SYSTEMS.get((table, system or "")) or _SYSTEMS.get(system or "")
    if not name:
        return system or None
    return f"{name} via push" if pushed and table == "vulnerabilities" else name


def _seen(cs) -> list:
    return [v.get("last_seen") for v in (cs or {}).values() if isinstance(v, dict)]


def as_of(cs, *fallbacks) -> str | None:
    """The newest time a source confirmed the row: `contributing_sources.*.last_seen`, else the first fallback present."""
    return latest(_seen(cs)) or latest(fallbacks)


def provenance(table: str, row: dict) -> dict:
    """{source, as_of} for a row read with `source_system` and `contributing_sources` (and any `last_seen` columns)."""
    cs = row.get("contributing_sources") or {}
    pushed = any(str(k).endswith(":push") for k in cs)
    when = as_of(cs, row.get("last_seen"), row.get("asset_last_seen_at"), row.get("scan_last_detected_date"),
                 row.get("updated_at"))
    return {"source": source_name(table, row.get("source_system"), row.get("scanner_name"), pushed), "as_of": pt(when), "when": when}
