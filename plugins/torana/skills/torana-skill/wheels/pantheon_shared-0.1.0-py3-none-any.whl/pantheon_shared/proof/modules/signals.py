"""signals — threat signals on the running product, recounted from posture_findings.

The detection rule rule_threat_status_changed groups open findings on running images by their STRONGEST signal:
known_exploited (cisa) > zero_day > exploit_available (exploit) > likelihood_pct/100 >= 0.5 (likely).
This module recomputes one group's membership with the same predicate, so its counts are proved here,
not copied from the alert.
"""
from ..core.engine import rule

_FIRST = {"cisa": ["known_exploited", "=", True], "zero_day": ["zero_day", "=", True],
          "exploit": ["exploit_available", "=", True], "likely": ["likelihood_pct", ">=", 50]}
# A finding counts only under its strongest signal: drop rows that carry a stronger one.
_STRONGER = {"cisa": [], "zero_day": ["known_exploited"], "exploit": ["known_exploited", "zero_day"],
             "likely": ["known_exploited", "zero_day", "exploit_available"]}


def member_rows(ctx, signal: str) -> tuple[list, dict | None]:
    """THE membership of one signal group, and the pointer of the selection it came from. Shared by the rule
    below (the counts) and claims.signals (the graph), so both read the SAME selection leaf. Unknown signal → []."""
    if signal not in _FIRST:
        return [], None
    rows, ptr = ctx.select_p("posture_findings", [["running_state", "=", "running"], ["status", "=", "open"], _FIRST[signal]])
    return [r for r in rows if not any(r.get(c) is True for c in _STRONGER[signal])], ptr


@rule("signals.threat_members", 2)
def threat_members(ctx, signal: str) -> dict:
    """The open findings on running images whose strongest threat signal is `signal` (member_rows), and their
    counts: findings, distinct CVEs, distinct images, internet-facing (internet_facing_services > 0),
    with a fix (fix_available TRUE), without one, and Critical (severity 'Critical')."""
    if signal not in _FIRST:
        return {"known": False, "findings": None, "cves": None, "images": None, "internet_facing": None,
                "with_a_fix": None, "without_a_fix": None, "critical": None}
    rows = member_rows(ctx, signal)[0]
    n = len(rows)
    with_fix = sum(1 for r in rows if r.get("fix_available") is True)
    return {"known": True, "findings": n,
            "cves": len({r.get("cve_id") for r in rows} - {None}),
            "images": len({r.get("place_key") for r in rows} - {None}),
            "internet_facing": sum(1 for r in rows if (r.get("internet_facing_services") or 0) > 0),
            "with_a_fix": with_fix, "without_a_fix": n - with_fix,
            "critical": sum(1 for r in rows if r.get("severity") == "Critical")}
