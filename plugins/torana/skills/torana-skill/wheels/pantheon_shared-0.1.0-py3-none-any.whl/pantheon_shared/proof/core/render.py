"""Templates -> spans. A span is {text, p?}: p is the pointer behind the text; no p = template wording.

Formatters are part of the template, not of the data: the pointer always carries the raw value.
"""
from __future__ import annotations

import re
from datetime import datetime, timezone

from ..times import PT, pt


def _dt(v):
    """A datalake time as an aware datetime; a naive one is UTC."""
    d = datetime.fromisoformat(str(v).replace("Z", "+00:00")) if v else None
    return d if d is None or d.tzinfo else d.replace(tzinfo=timezone.utc)


def qualified(s) -> str:
    """A key without its scheme and digest, its last two path segments: service:demo/x → demo/x;
    repo:github.com/org/x → org/x; image:…/org/x@sha256:<64> → org/x@<8>. Generic: no tenant's names are special."""
    s = str(s or "—")
    name, _, digest = s.partition("@sha256:")
    name = "/".join(name.split(":")[-1].split("/")[-2:])
    return f"{name}@{digest[:8]}" if digest else name


CHANGE_WORDS = {"major": "A major version change", "minor": "A minor version change",
                "patch": "A patch version change", "revision": "A revision of the same version (packaging or pre-release)",
                "unknown": "A change whose size is not known"}

FMT = {
    "time": lambda v: pt(v) or "—",                                                  # Pacific time, never raw UTC
    "day": lambda v: _dt(v).astimezone(PT).strftime("%-d %b %Y") if v else "—",
    "digest": lambda v: (v.split("sha256:")[1][:8] if v and "sha256:" in v else (v or "—")),
    "pct": lambda v: "—" if v is None else f"{float(v) * 100:.2f}%",
    "svc": lambda v: qualified(v) if v else "—",
    "yesno": lambda v: "—" if v is None else ("yes" if str(v).lower() == "true" else "no"),
    "repo": lambda v: qualified(v) if v else "—",
    "team": lambda v: (v or "—").replace("team:", ""),
    "lb": lambda v: (v or "—").split("/")[-1][:12] + "…",
    # Wording formatters: the sentence depends on the value, the pointer still carries the raw value.
    "kev": lambda v: "Listed on CISA KEV as known-exploited." if v is True else "No known exploitation: not on CISA KEV.",
    "word": lambda v: {1: "One", 2: "Two", 3: "Three"}.get(v, str(v)),
    "cap": lambda v: (str(v)[:1].upper() + str(v)[1:]) if v else "—",
    "days": lambda v: "—" if v is None else f"{float(v):g}",
    "change": lambda v: CHANGE_WORDS.get(v, CHANGE_WORDS["unknown"]),
}


def text_of(value, fmt: str | None) -> str:
    if fmt:
        return FMT[fmt](value)
    return "—" if value is None or value == "" else str(value)


# {name} is a slot (a value with a pointer). {name?one|many} is a word chosen by that slot's value: "image{n?|s}",
# "{n?has|have}". The chosen word is plain template text (no pointer); the count itself stays a slot.
_TOKEN = re.compile(r"\{(\w+)\}|\{(\w+)\?([^|{}]*)\|([^{}]*)\}")


def _is_one(v) -> bool:
    return v == 1 or str(v) == "1"


def render(template: str, slots: dict) -> list[dict]:
    """slots: name -> (value, pointer) or (value, pointer, formatter)."""
    spans, i = [], 0
    for m in _TOKEN.finditer(template):
        if m.start() > i:
            spans.append({"text": template[i:m.start()]})
        i = m.end()
        if m.group(2):                                      # {name?one|many}
            word = m.group(3) if _is_one(slots[m.group(2)][0]) else m.group(4)
            if word:
                spans.append({"text": word})
            continue
        name = m.group(1)
        val, ptr = slots[name][0], slots[name][1]
        fmt = slots[name][2] if len(slots[name]) > 2 else None
        span = {"text": text_of(val, fmt), "slot": name}
        if ptr is not None:
            span["p"] = ptr
        if val is None and span["text"] == "—":
            span["null"] = True
        spans.append(span)
    if i < len(template):
        spans.append({"text": template[i:]})
    return spans


def plain(spans: list[dict]) -> str:
    return "".join(s["text"] for s in spans or [])
