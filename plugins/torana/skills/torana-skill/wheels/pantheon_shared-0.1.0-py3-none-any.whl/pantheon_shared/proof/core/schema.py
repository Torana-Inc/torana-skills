"""Schema binding. The framework owns no table shape or meaning: both are injected by the runtime
(pantheon-datalake supplies them from its own schema registry and semantic model)."""
from __future__ import annotations

import re
from typing import Callable, Optional

IDENT = re.compile(r"^[a-z_][a-z0-9_]*$")

# API resources the framework reads like tables. Only the alert is modelled in this change.
API_RESOURCES = {"api.alert": {"key": ["id"], "path": "alerts/{id}"}}

# Relations the platform lists without a usable primary key for this purpose. Grain = definitions.json `unique_key`
# (posture_*, explore_images) or the global reference table key. MEASURED (R1): explore_images 185/185 and 235/235
# unique image keys on T1/T2; posture_findings 28,698/28,698 unique finding keys on T2.
DECLARED_KEYS: dict[str, list[str]] = {
    "explore_images": ["image_key"],
    "posture_findings": ["finding_key"],
    "posture_scanner_reports": ["report_row_key"],
    "posture_mitigations": ["mitigation_key"],
    "posture_fixes": ["fix_key"],               # MEASURED 2026-10-07: 73 rows, 73 distinct fix_key on T2
    "posture_runtime_context": ["place_kind", "place_key", "via_image_key", "service_key"],
}


class SchemaError(Exception):
    """A table the runtime cannot key. A framework bug, never a user error."""


class SchemaBinding:
    def __init__(self, keys: Callable[[str], Optional[str]], meanings: Callable[[str, str], dict],
                 version: Optional[str]):
        self._keys, self._meanings, self.version = keys, meanings, version
        self.declared = dict(DECLARED_KEYS)

    def key_of(self, table: str) -> list[str]:
        if table in API_RESOURCES:
            return API_RESOURCES[table]["key"]
        if table in self.declared:
            return self.declared[table]
        pk = self._keys(table)
        if not pk:
            raise SchemaError(f"{table}: no primary key from the runtime and none declared")
        return [pk]

    def check_ident(self, *names: str) -> None:
        for n in names:
            if not IDENT.match(n):
                raise SchemaError(f"not an identifier: {n!r}")

    def meaning(self, table: str, column: str) -> dict:
        """{'text': str|None, 'writers': None, 'q': None} — shape Ctx.meaning reads (engine: m.get('text'))."""
        return self._meanings(table, column)
