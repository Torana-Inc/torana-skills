"""The LLM boundary for briefs: validate model-written sentences against the claims they cite, and
INVALIDATE them when those claims change. The model is never asked to recompute anything.

validate(brief, claims)        every sentence cites ≥1 existing claim; every checkable token (number, CVE/CWE id,
                               hex id with a digit, identifier with / _ : ., lowercase name with ≥2 hyphens, quoted
                               title) appears in the text of a cited claim; a number must stand alone there
feedback(validated)            one line per problem, phrased for the model's next round
invalidate(brief, item_diff)   a sentence is STALE when any claim it cites did not come back "unchanged";
                               it is then re-validated against the NEW claims to show what no longer holds
stale_sentences(brief, then, now)  staleness of a stored brief against a current record (clock-only = as_of)
Spec: pantheon-fe/docs/AI_HOME_V2_BRIEF_SPEC.md § 3.4.2.
"""
from __future__ import annotations

import re

from ..core.render import plain
from ..recompute import diff

SECTION_IDS = ("tldr", "wrong", "deep", "tech", "fix", "plan")
REQUIRED_SECTIONS = ("tldr", "fix")
MAX_SENTENCE_CHARS = 400
MAX_SENTENCES = 40
VALIDATOR_ID = "pantheon_shared.proof.llm.brief v2"

TOKEN = re.compile(
    r"“[^”]+”|CVE-\d{4}-\d+|CWE-\d+"
    r"|[A-Za-z0-9_.\-]*[/_:.][A-Za-z0-9_.\-/:]+"
    r"|\b(?=[0-9a-f]*\d)[0-9a-f]{7,}\b"          # hex ids / digests containing a digit (8de08eba)
    r"|\b[a-z0-9]+(?:-[a-z0-9]+){2,}\b"           # lowercase names with >= 2 hyphens (pantheon-data-transformers)
    r"|\d[\d.,:%]*")
STOP = {"end-to-end", "up-to-date", "out-of-date", "day-to-day", "one-to-one", "state-of-the-art"}
NUMBER = re.compile(r"^\d[\d.,:%]*$")


def _norm(s: str) -> str:
    return s.replace("“", "").replace("”", "").replace('"', "").rstrip(".,;:)").lstrip("(")


def _claim_text(c: dict) -> str:
    return plain(c.get("spans")) + " " + plain(c.get("missing"))


def _grounded(token: str, corpus: str) -> bool:
    """A number must stand alone in the cited text: not inside a longer number, a date, a time or an identifier.
    Ids, identifiers, hyphenated names and quoted titles may appear as substrings (a title is quoted in prose but not
    in the claim; 3.1 sits inside CVSS:3.1/…)."""
    if NUMBER.match(token):
        pat = r"(?<![\w.])(?<!\d[,:\-])" + re.escape(token) + r"(?![\w]|[.,:]\d)"
        return re.search(pat, corpus) is not None
    return token in corpus


def check_sentence(s: dict, claims: dict) -> dict:
    text = (s.get("title", "") + " " + s["text"]).strip()
    unknown = [c for c in s["cites"] if c not in claims]
    corpus = " ".join(_claim_text(claims[c]) for c in s["cites"] if c in claims)
    tokens = [t for t in (_norm(t) for t in TOKEN.findall(text)) if t and t not in STOP]
    ungrounded = [t for t in tokens if not _grounded(t, corpus)]
    too_long = len(s["text"]) > MAX_SENTENCE_CHARS
    return {"pass": bool(s["cites"]) and not unknown and not ungrounded and not too_long,
            "unknown_cites": unknown, "tokens": tokens, "ungrounded": ungrounded, "too_long": too_long}


def _section_problems(brief: dict, total: int) -> list[str]:
    out = []
    ids = [sec.get("id") for sec in brief["sections"]]
    for sid in ids:
        if sid not in SECTION_IDS:
            out.append(f"section {sid}: not a section id (use one of {', '.join(SECTION_IDS)})")
    for sid in REQUIRED_SECTIONS:
        sec = next((x for x in brief["sections"] if x.get("id") == sid), None)
        if sec is None or not sec["sentences"]:
            out.append(f"section {sid}: no sentences")
    if total > MAX_SENTENCES:
        out.append(f"the brief has {total} sentences; the limit is {MAX_SENTENCES}")
    return out


def validate(brief: dict, claims: dict) -> dict:
    total = passed = 0
    for sec in brief["sections"]:
        for s in sec["sentences"]:
            s["check"] = check_sentence(s, claims)
            total += 1
            passed += s["check"]["pass"]
    brief["validation"] = {"sentences": total, "passed": passed, "validator": VALIDATOR_ID,
                           "problems": _section_problems(brief, total),
                           "rule": "every sentence cites ≥1 claim and is ≤ 400 chars; every number / id / hex id / identifier / "
                                   "hyphenated name / quoted title appears in a cited claim, and a number stands alone there "
                                   "(not inside a longer number, date, time or identifier); tldr and fix have sentences; ≤ 40 sentences"}
    return brief


def feedback(brief: dict) -> list[str]:
    """One line per problem of a VALIDATED brief, phrased so the model can fix exactly that."""
    out = list(brief["validation"]["problems"])
    for sec in brief["sections"]:
        for i, s in enumerate(sec["sentences"], 1):
            ck = s["check"]
            where = f"section {sec.get('id')}, sentence {i}"
            if not s["cites"]:
                out.append(f"{where}: cites no claim; cite the claims it rests on")
            for c in ck["unknown_cites"]:
                out.append(f"{where}: cites '{c}', which is not a claim of this item")
            for t in ck["ungrounded"]:
                out.append(f"{where}: '{t}' is not in the cited claims [{', '.join(s['cites'])}]; "
                           f"cite the claim whose text carries it, or remove it")
            if ck["too_long"]:
                out.append(f"{where}: longer than {MAX_SENTENCE_CHARS} characters; split it")
    return out


def invalidate(brief: dict, item_diff: dict, new_claims: dict) -> dict:
    stale = []
    for sec in brief["sections"]:
        for s in sec["sentences"]:
            moved = [c for c in s["cites"] if item_diff.get(c, {}).get("outcome") not in (None, "unchanged")]
            if moved:
                recheck = check_sentence(s, new_claims)
                stale.append({"section": sec["id"], "text": s["text"], "claims": moved,
                              "still_grounded": recheck["pass"], "no_longer_grounded": recheck["ungrounded"]})
    return {"stale_sentences": len(stale), "sentences": stale}


def stale_sentences(brief: dict, then_record: dict, now_record: dict) -> dict:
    """Which sentences of a stored brief rest on claims that changed since `then_record` (the record it was written
    from). A claim that changed only because the build clock moved ("aged") does not make a sentence stale: such
    sentences are listed in `as_of` so a time-relative number is shown dated, never as current."""
    d =diff(then_record, now_record, "verify")["claims"]
    new_claims = {c["id"]: c for c in now_record["item"]["claims"]}
    moved = {cid: c for cid, c in d.items() if c["outcome"] not in ("unchanged", "aged")}
    aged = {cid: {"outcome": "changed"} for cid, c in d.items() if c["outcome"] == "aged"}
    index = {(sec["id"], st["text"]): i for sec in brief["sections"] for i, st in enumerate(sec["sentences"])}

    def tag(r):
        return [{**x, "index": index[(x["section"], x["text"])]} for x in r["sentences"]]

    st = invalidate(brief, moved, new_claims)
    asof = invalidate(brief, aged, new_claims)
    stale_keys = {(x["section"], x["text"]) for x in st["sentences"]}
    return {"count": st["stale_sentences"], "stale": tag(st),
            "as_of": [x for x in tag(asof) if (x["section"], x["text"]) not in stale_keys]}
