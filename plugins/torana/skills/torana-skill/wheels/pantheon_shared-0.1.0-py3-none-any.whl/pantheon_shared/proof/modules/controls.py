"""controls — compensating controls the platform has inventoried."""
from ..core.engine import rule


@rule("controls.inventory", 1)
def inventory(ctx) -> dict:
    """How many live (not deleted) controls the platform holds. Zero is evidence of absence, with its query."""
    rows = ctx.select("controls", [["is_deleted", "=", False]])
    return {"count": len(rows)}
