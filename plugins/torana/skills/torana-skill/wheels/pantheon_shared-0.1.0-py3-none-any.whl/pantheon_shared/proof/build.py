"""Build one proof record for one alert, or replay a record from its capture. No I/O of its own:
all reads go through the injected Source (live) or the record (replay)."""
from __future__ import annotations

from . import modules  # noqa: F401  (registers rules)
from .claims import alert_facts, code_finding, entries, group_member, signals, vuln_in_image
from .core.engine import REGISTRY, Build, CapturedReader, LiveReader, NotCaptured
from .core.schema import SchemaBinding
from .core.source import RecordingSource

FRAMEWORK_VERSION = "0.7.0"
# 0.7.0: section "effort" (claim kind assessed, judgement rules, question registry); path-guarded, no format change.
# 0.6.1: a fix entry's target claim names its MEMBERS' version (entries._target reads entry_version), plus the
#        wider-version claim; 0.6.0: graph nodes carry what they ARE (members.node_facts); 0.5.0: group_member
#        (classify v4). None of these change the format.
# MAJOR = the record FORMAT that replay reads: `leaves` and their kinds, key encoding (core/pointers.py), WHERE
# canonicalisation (core/where.py `norm`), CapturedReader. Bump the major, and only the major, when one of those
# changes; replay refuses across majors (`replay_refusal`). A minor/patch bump (rules, claim builders, rendering)
# never stops a replay: it runs and reports `framework_changed` and `rules_changed`. 0.1.0 → 0.4.0 changed none of
# the four (git log of core/pointers.py, where.norm and CapturedReader is empty or additive).

# Item type (alerts.classify) → claim builder. Anything not listed is built as unmodelled.
CLAIM_BUILDERS = {
    "vuln_in_image": vuln_in_image.build_claims,
    "fix_entry": entries.build_fix_claims,
    "mitigation_entry": entries.build_mitigation_claims,
    "threat_signal": signals.build_threat_claims,
    "posture_summary": signals.build_summary_claims,
    "code_finding": code_finding.build_code_claims,
    "group_check": alert_facts.build_group_check,      # APP_PROFILES_SPEC § 3.3.4
    "group_member": group_member.build_group_member,   # one row of a group check: its own path (classify v4)
}


def _build_claims(build: Build, alert_id: str) -> dict:
    """Classify the alert, build its item, and prepend the alert-facts claims every item can cite."""
    ctx = build.ctx()
    kind = ctx.call("alerts.classify", alert_id=alert_id)
    item = CLAIM_BUILDERS.get(kind["item_type"], alert_facts.build_unmodelled)(build, alert_id)
    item["claims"] = alert_facts.claims(build, alert_id) + item["claims"]
    item["decision_key"] = kind["decision_key"]
    item["priority"] = kind["priority"]
    if "unjudged" not in item:
        item["unjudged"] = ctx.call("alerts.triage_state", alert_id=alert_id)["unjudged"]
    return item


def _record(build: Build, queries: list, meta: dict, item: dict) -> dict:
    used = {r["rule"] for r in build.runs.values()}
    rec = {
        "meta": meta, "queries": queries, "leaves": build.leaves, "runs": build.runs,
        "missing_inputs": build.missing_inputs,
        "rules": {rid: {"id": rid, "version": REGISTRY[rid].version, "doc": REGISTRY[rid].doc, "source": REGISTRY[rid].source,
                        "code_hash": REGISTRY[rid].code_hash, "module": REGISTRY[rid].module} for rid in sorted(used)},
        "item": item,
    }
    return rec


def build_item(source, schema: SchemaBinding, *, alert_id: str, tenant_id: str, now: str) -> dict:
    """Live build. `source` implements Source (sql/api); `now` is the build clock (an input, never read inside rules)."""
    rec = RecordingSource(source)
    build = Build(reader=LiveReader(rec, schema), now=now)
    item = _build_claims(build, alert_id)
    meta = {"alert_id": alert_id, "tenant_id": tenant_id, "now": now, "schema_version": schema.version,
            "declared_keys": schema.declared, "framework": FRAMEWORK_VERSION}
    return _record(build, rec.log, meta, item)


def _major(version) -> str:
    return str(version or "").split(".")[0]


def replay_refusal(record: dict) -> str | None:
    """Why this code cannot replay `record`, or None. Only a different MAJOR framework (the record format changed,
    so captured values could be misread rather than fail loudly) refuses. Rule changes since the record are not a
    refusal: replay reports them (`rules_changed`), or `NotCaptured` when a rule reads a cell the record lacks."""
    built_by = (record.get("meta") or {}).get("framework")
    if not built_by:
        return "record has no meta.framework; rebuild it"
    if _major(built_by) != _major(FRAMEWORK_VERSION):
        return (f"record built by proof framework {built_by} (record format {_major(built_by)}.x); this is "
                f"{FRAMEWORK_VERSION} (format {_major(FRAMEWORK_VERSION)}.x); rebuild it")
    return None


def framework_changed(record: dict) -> dict | None:
    """{then, now} when the record was built by another framework version (same major), else None."""
    built_by = (record.get("meta") or {}).get("framework")
    return None if built_by == FRAMEWORK_VERSION else {"then": built_by, "now": FRAMEWORK_VERSION}


def replay_item(record: dict) -> dict:
    """Rebuild from the values the record captured, at the record's clock. Raises ValueError on a malformed
    record and NotCaptured when the rules ask for a value the record never read (rule code changed)."""
    meta, item = record.get("meta") or {}, record.get("item") or {}
    if not meta.get("alert_id") or item.get("alert_id") != meta["alert_id"]:
        raise ValueError("record must hold exactly one item whose alert_id equals meta.alert_id")
    build = Build(reader=CapturedReader(record), now=meta["now"], captured=True)
    new_item = _build_claims(build, meta["alert_id"])
    return _record(build, [], meta, new_item)


__all__ = ["FRAMEWORK_VERSION", "build_item", "replay_item", "replay_refusal", "framework_changed", "NotCaptured"]
