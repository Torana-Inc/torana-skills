"""Build one proof record for one alert, or replay a record from its capture. No I/O of its own:
all reads go through the injected Source (live) or the record (replay)."""
from __future__ import annotations

from . import modules  # noqa: F401  (registers rules)
from .claims import alert_facts, code_finding, entries, group_member, signals, vuln_in_image
from .core.engine import REGISTRY, Build, CapturedReader, LiveReader, NotCaptured
from .core.schema import SchemaBinding
from .core.source import RecordingSource

FRAMEWORK_VERSION = "0.7.20"
# 0.7.20: the EPR integration onto main. Main and EPR each numbered their own 0.7.13 and 0.7.14; main's are kept below as
#        0.7.13-main / 0.7.14-main (the exposure path D1-D5), EPR's as 0.7.13-0.7.19. Rules that both sides bumped to the same
#        version get the next one with no new behaviour: `alerts.classify` v9 (AC's v8 + DS3's v8), `path.exposure` v5 (D1-D3's v3,
#        D5's v4 + DS1b's v3), `path.service_facts` v6 (D1-D3's v4 + DS2's v4, DS5's v5). No format change.
# 0.7.19 (Q1): `runtime.scope_reads` v2 adds `read_labels` (the scope's reads by base, `entry_base`; the integration named only
#        when two connections read one base), and the "Where does it run?" claim lists them as a ref instead of the raw
#        '<base>|<integration_id>' keys. Its text and `reads` (the whole captured record) are unchanged, so an older record
#        replays from its own capture with rule_changed 1 -> 2 only. No format change.
# 0.7.18 (DS5): `path.service_facts` v5 returns `customer_data_derived_from`; the path claim reads "Yes (derived: uses <store>)"
#        and the image claim states a derived source. Path-guarded: a record without the read replays with it None.
# 0.7.17 (DS3 E-08.1): `alerts.classify` v8 adds `priority_reason_by` ('agent' | 'ranking'): who wrote the sentence in `priority_reason`, now that a
#        rule-held item carries the ranking's own reason. Home's card line reads "Ranking: ..." or "Triage agent: ...". Path-guarded: a record
#        saved before it has no such cell and replays with its own output, which Home prints as "Triage agent:". No format change.
#        E-08.16: the code_finding and vuln_in_image claims read the `finding_ranking` row (`posture.ranking_row`; a record saved before holds the
#        `posture_findings` cells and replays from them), the action claim names the priority and the ranking's sentence, a new "priority" claim
#        cites rule `ranking.priority` v1, and `code.reports` v2 adds the scan's answer, commit, time and basis (path-guarded). `alerts.classify`
#        v8 reads the covering entry's row from finding_ranking with the same guard.
# 0.7.16 (DS2): the service-facts claims read business context from sources and policy entries only (labels, tags, CMDB,
#        policy), never from Deployment or integration-declared values; the retired governance families no longer appear.
# 0.7.15 (DS1b): new rule `runtime.exposure_answer` v1 reads the claim's own posture_runtime_context row (exposure_link_found,
#        exposure_basis, exposure_sign_in), so the card gives asset_context's one answer: True, False, or None ("not
#        measured" when the scope's network reads failed or went stale). `runtime.exposure` stays v1 (the edge, its
#        endpoint and load balancer). Path guard: a record without that read, or a service with no row, renders the v1
#        sentence and chip from the edge, so an older record replays its own text. (0.7.14 is DS1a's read-record claim.)
# 0.7.15 (DS1b, E-02.5): `path.exposure` v3 adds `answers` (the exposure answer per service, from posture_runtime_context) and
#        `routes` (the sign-in of each live route into a service); the exposure-path card gains a "Sign-in by route" row.
#        Path-guarded: a record built before v3 replays with both empty and no row.
# 0.7.14 (DS1a, E-17.1): new rule `runtime.scope_reads` v1 (what the app last read for a service's scope: PRC's bases and
#        read sources plus the scope row's `reads`); the "Where does it run?" claim appends one sentence from it; Home's
#        blind-spot lines carry kind, fix, owner and first seen (`home_sections._blind`). Path-guarded: a record captured
#        before 0.7.14 replays with every scope-read field None and no extra sentence.
# 0.7.13 (BF2): new rule `images.logical_image` v1 (a multi-arch member manifest stands for its index, the one row
#        explore_images keeps); `images.builder_repo` v3 reads the build-record fallback under it; `images.service_of` v4
#        counts the index's own edges and lists every running image (`running_images`, `several_running`: a rollout runs
#        two); `alerts.is_stale` v2 reads the logical image and is never stale while the image is any running one.
#        Path-guarded: a record without the `artifacts` read replays with the key itself, i.e. as before.
# 0.7.14-main (D4): the exposure path draws a DEPLOYMENT column (Internet → deployment → service → image → package → CVE) when
#        every service names its cluster: new rule `path.deployments` v1 (one deployment per cluster from the service key;
#        environment, cluster name, GKE/Kubernetes, integration from the service asset rows); TOP applies per deployment, so
#        every deployment is drawn, exposed ones first; a deployment is `collapsed` with its `children`, and its edges straight
#        to the images carry `folded`. No other rule changed. Path-guarded: a record built before it holds no
#        `path.deployments` read and replays the flat path it was built with (`claims/path.py` `_deployment_layer`). No format change.
# 0.7.13-main (D1-D3): the exposure path (claims/path.py, no rule changed): a service links only to the images it RUNS, never also to
#        the repository that builds them (it drew a second "runs → +K more" edge from every service); one package node per
#        version set the drawn places ship, not the entry's every version on one node; a Kubernetes source names its
#        cluster ("Kubernetes · demo-vm-k3s", "GKE · gke-twin-x2yk48"), never "GKE cluster" for a k3s box. No format change.
# 0.7.12 (I-133): `images.builder_repo` v2 reads every live builds_image edge and names no builder when several repositories
#        (build-record edges, else name matches) built the image; `images.service_of` v3 picks none of several builders and
#        names only the image's own services; new rule `images.detections_on_image` v1 counts over the alert's image when
#        no builder is picked. Path-guarded as 0.7.9: a record without the new reads replays without them.
# 0.7.11 (B7 row B): `images.first_detection` v4 never returns a sentinel. An undated vulnerability row is counted but cannot
#        be the first detection; with no dated row `first_detected` is None (v3 returned the string "9999", which crashed the
#        "introduced" claim's date rendering) and the claim says no first-detection date is recorded. Same reads as v3.
# 0.7.10 (B7 row B review M1): `images.package_layer` v2 is keyed on `torana_package_id` (the column a vulnerability row
#        carries); v1 took a purl, which `vulnerabilities` lacks, so the origin claim never reached the rule. Among history
#        entries sharing a diff_id the earliest is taken. Path-guarded as 0.7.9: a record without the reads replays without them.
# 0.7.9 (B7 row B): new rule `images.package_layer` v1 reads the image's own evidence (image_components, image_layers). The
#        vuln_in_image "origin" claim uses it when the scanner's occurrence names no layer (a Trivy- or SBOM-sourced finding):
#        file, layer, and the build step that made the layer. Path-guarded: a record built before it replays without those
#        reads. No format change; a finding whose occurrence names a layer reads exactly as before.
# 0.7.8 (I-106): path guards for the 0.7.6 reads: `ownership.owner` v4, `path.owners` v3 and `path.service_facts` v3 replay a record built before
#        0.7.6 with their prior version's outputs (no asset governance read, the asset's own criticality / customer data) instead of raising
#        NotCaptured. No format change; live outputs identical.
# 0.7.7 (I-106 C2/C3): path guards only (alerts.classify v7, alerts.severity_sources v3, the alert.state claim), so records built
#        before 0.7.2-0.7.5 replay instead of raising NotCaptured on the cells those versions started reading; a non-agent v5 record
#        keeps its v5 keys. No format change; live outputs identical.
# 0.7.6: a service's criticality and customer data are the RESOLVED values the app ranks on (posture_runtime_context: the source's value, else the policy default,
#        with `*_source`), not the raw asset columns, which can hold a value set in Torana: `path.service_facts` is v2, and the vuln_in_image "env" claim
#        and the Path service card state the source. No format change.
#        A service's team the Deployment stamped is not an owner either: `ownership.owner` is v3 and `path.owners` v2 read the service's asset record and drop it.
# 0.7.5: `alert.state` and Home's rows state the item's ONE severity (`entry_severity_label` / `entry_severity`), and `alerts.severity_sources` is v2 (a rule that
#        declares none reports none); Home's change detection compares `entry_severity`. No format change.
# 0.7.3: the item also carries triage, reachability and known_exploited_cves (alerts.classify v6) for Home's per-card `why`; no format change.
# 0.7.2: the item carries band, priority_source and priority_reason (alerts.classify v5) for Home's per-card `why`; no format change.
# 0.7.1: an entry's "clears" claim and chip copy the Inbox's own count, floor split and CVE count (rule
#        entries.inbox_counts reads the alert row) when the entry has linked open members (HB-2); no format change.
# 0.7.0: section "effort" (claim kind assessed, judgement rules, question registry); path-guarded, no format change.
# 0.6.1: a fix entry's target claim names its MEMBERS' version (entries._target reads entry_version), plus the
#        wider-version claim; 0.6.0: graph nodes carry what they ARE (members.node_facts); 0.5.0: group_member
#        (classify v4). None of these change the format.
# MAJOR = the record FORMAT that replay reads: `leaves` and their kinds, key encoding (core/pointers.py), WHERE
# canonicalisation (core/where.py `norm`), CapturedReader. Bump the major, and only the major, when one of those
# changes; replay refuses across majors (`replay_refusal`). A minor/patch bump (rules, claim builders, rendering)
# never stops a replay: it runs and reports `framework_changed` and `rules_changed`. 0.1.0 → 0.4.0 changed none of
# the four (git log of core/pointers.py, where.norm and CapturedReader is empty or additive).

# Item type (alerts.classify) → claim builder. Anything not listed is built as unmodelled.
CLAIM_BUILDERS = {
    "vuln_in_image": vuln_in_image.build_claims,
    "fix_entry": entries.build_fix_claims,
    "mitigation_entry": entries.build_mitigation_claims,
    "threat_signal": signals.build_threat_claims,
    "posture_summary": signals.build_summary_claims,
    "code_finding": code_finding.build_code_claims,
    "group_check": alert_facts.build_group_check,      # APP_PROFILES_SPEC § 3.3.4
    "group_member": group_member.build_group_member,   # one row of a group check: its own path (classify v4)
}


def _build_claims(build: Build, alert_id: str) -> dict:
    """Classify the alert, build its item, and prepend the alert-facts claims every item can cite."""
    ctx = build.ctx()
    kind = ctx.call("alerts.classify", alert_id=alert_id)
    item = CLAIM_BUILDERS.get(kind["item_type"], alert_facts.build_unmodelled)(build, alert_id)
    item["claims"] = alert_facts.claims(build, alert_id) + item["claims"]
    item["decision_key"] = kind["decision_key"]
    item["priority"] = kind["priority"]
    # Home's `why` reads these three (alerts.classify v5); absent in a record built before, and then no line is written for them.
    for k in ("band", "priority_source", "priority_reason", "priority_reason_by", "triage", "reachability", "known_exploited_cves"):
        item[k] = kind.get(k)
    if "unjudged" not in item:
        item["unjudged"] = ctx.call("alerts.triage_state", alert_id=alert_id)["unjudged"]
    return item


def _record(build: Build, queries: list, meta: dict, item: dict) -> dict:
    used = {r["rule"] for r in build.runs.values()}
    rec = {
        "meta": meta, "queries": queries, "leaves": build.leaves, "runs": build.runs,
        "missing_inputs": build.missing_inputs,
        "rules": {rid: {"id": rid, "version": REGISTRY[rid].version, "doc": REGISTRY[rid].doc, "source": REGISTRY[rid].source,
                        "code_hash": REGISTRY[rid].code_hash, "module": REGISTRY[rid].module} for rid in sorted(used)},
        "item": item,
    }
    return rec


def build_item(source, schema: SchemaBinding, *, alert_id: str, tenant_id: str, now: str) -> dict:
    """Live build. `source` implements Source (sql/api); `now` is the build clock (an input, never read inside rules)."""
    rec = RecordingSource(source)
    build = Build(reader=LiveReader(rec, schema), now=now)
    item = _build_claims(build, alert_id)
    meta = {"alert_id": alert_id, "tenant_id": tenant_id, "now": now, "schema_version": schema.version,
            "declared_keys": schema.declared, "framework": FRAMEWORK_VERSION}
    return _record(build, rec.log, meta, item)


def _major(version) -> str:
    return str(version or "").split(".")[0]


def replay_refusal(record: dict) -> str | None:
    """Why this code cannot replay `record`, or None. Only a different MAJOR framework (the record format changed,
    so captured values could be misread rather than fail loudly) refuses. Rule changes since the record are not a
    refusal: replay reports them (`rules_changed`), or `NotCaptured` when a rule reads a cell the record lacks."""
    built_by = (record.get("meta") or {}).get("framework")
    if not built_by:
        return "record has no meta.framework; rebuild it"
    if _major(built_by) != _major(FRAMEWORK_VERSION):
        return (f"record built by proof framework {built_by} (record format {_major(built_by)}.x); this is "
                f"{FRAMEWORK_VERSION} (format {_major(FRAMEWORK_VERSION)}.x); rebuild it")
    return None


def framework_changed(record: dict) -> dict | None:
    """{then, now} when the record was built by another framework version (same major), else None."""
    built_by = (record.get("meta") or {}).get("framework")
    return None if built_by == FRAMEWORK_VERSION else {"then": built_by, "now": FRAMEWORK_VERSION}


def replay_item(record: dict) -> dict:
    """Rebuild from the values the record captured, at the record's clock. Raises ValueError on a malformed
    record and NotCaptured when the rules ask for a value the record never read (rule code changed)."""
    meta, item = record.get("meta") or {}, record.get("item") or {}
    if not meta.get("alert_id") or item.get("alert_id") != meta["alert_id"]:
        raise ValueError("record must hold exactly one item whose alert_id equals meta.alert_id")
    build = Build(reader=CapturedReader(record), now=meta["now"], captured=True)
    new_item = _build_claims(build, meta["alert_id"])
    return _record(build, [], meta, new_item)


__all__ = ["FRAMEWORK_VERSION", "build_item", "replay_item", "replay_refusal", "framework_changed", "NotCaptured"]
