"""Every card of the proven Home as finished lines. Spec: pantheon-cli/docs/specs/HOME_SURFACE_SPEC.md § 3.2, § 3.3.

⭐ ONE COMPUTATION OF THE WORDS. The page (pantheon-fe ai-home-v2) and the CLI (`ai-home get --section`) print these
lines; neither builds a card's words itself. `sections()` is computed when the page is served (as `health` is), from
the stored run only, so every stored run has it and nothing is re-narrated.
PURE: reads page = {facts, narration, proof, health} only. No I/O, no settings, no module state, no system clock
(`now` is a parameter; without it the run's own `now_at` is used).

A line is {kind, text, marker, indent, cites, commands, source, parts}:
- `parts` are the named values a screen lays out; `text` is the one-line rendering of those SAME parts, built in the
  same function. The CLI prints `text`, the screen lays out `parts`.
- `marker` is the meaning, never the glyph: ai (✦ model-written), proven (◆), warn (▲), watch (◐), ok (✓), off (○),
  or None. Shape carries the kind, never colour alone. A text may mark words to catch with `**…**` (home.py).
- `cites` is [{id, kind: "claim"|"group", text}] from the STORED proof: what the page cited, not a live re-proof.
- `source` is the row's artifact ref as the facts carry it ({kind, id, …}); a surface builds its own link from it.
- `commands` are runnable as written: the real app id is substituted.
Each section function is a port of the screen code it replaces (pantheon-fe src/app/ai-home/home-view.ts and
src/app/ai-home-v2/zones/); the screen's wording wins where the CLI's differed.
"""
from __future__ import annotations

import re
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from .health import DEFAULT_TZ, _dt

SECTIONS_VERSION = 1
SECTION_KEYS = ("act_first", "summary", "what_matters", "trust", "health", "needs_you",
                "handled", "rules", "dashboards", "blind")          # the API vocabulary, spec § 3.2

#: ⭐ THE ONE PLACE the app-scoped command prefix is spelled (`torana app <id> …`).
APP_CMD = "torana app"

#: Item types that never get an AI brief: no proof model, or a grouped check with no fix claim to ground one on
#: (APP_PROFILES_SPEC § 3.6.8; the server refuses both). THE definition; torana_cli/ai_home_v2.py and pantheon-fe
#: v2-brief-types.ts keep copies until they read a line's `commands` / `parts.has_brief`.
NO_BRIEF_TYPES = frozenset({"unmodelled", "group_check", "group_member"})

#: The template zone each section is drawn in (ai-home-v2.component.html); a zone the template omits has no section.
ZONE_SECTIONS = {"Z0": ("act_first",), "Z1": ("summary", "what_matters"), "Z2": ("trust",), "Zhealth": ("health",),
                 "Z3": ("needs_you",), "Z4": ("handled",), "Zrules": ("rules",), "Zdash": ("dashboards",),
                 "Z6": ("blind",)}
#: A run stored before templates shipped (home-view.ts FALLBACK_ZONES, the zones V2 draws).
FALLBACK_ZONES = ({"id": "Z1", "title": None}, {"id": "Z2", "title": None}, {"id": "Z3", "title": "Needs you now"},
                  {"id": "Z4", "title": "Since you were last here"}, {"id": "Z6", "title": "What this page cannot see"})

#: key → (fallback title when the template gives none, what the card shows in one sentence).
_CARD = {
    "act_first": ("Act on these first", "The few things to do before anything else on this page."),
    "summary": (None, "The page in one sentence, its headline counts, and how the run came down to them."),
    "what_matters": ("What matters to you", "The questions this app answers for you, each with its current answer."),
    "trust": (None, "What could make this page wrong, said only when something could."),
    "health": ("How this app is running", "Whether the app itself is working: its data syncs, checks, agents and "
                                          "alert routing."),
    "needs_you": ("Needs you", "The decisions waiting on a person, one card per decision."),
    "handled": ("Handled for you", "What the app closed or acted on without you in this window."),
    "rules": ("Rules and alerts", "Whether the app's checks ran, what they matched, and how the alert list is moving."),
    "dashboards": ("How things are going", "The app's own figures, grouped by dashboard, with what each one says."),
    "blind": ("What this page cannot see", "The figures this page cannot compute, and what would supply them."),
}
NO_NARRATION = "This run has no narration; the figures are unaffected."
#: What `--section <key>` prints for a card the screen does not draw because it has nothing to say (`drawn: false`).
NOTHING = {"act_first": "Nothing is flagged to act on first.", "trust": "No coverage caveats on this page.",
           "blind": "This page reports nothing it cannot see."}
#: The Inbox's open (non-terminal) statuses: what "See them in the Inbox" filters to.
OPEN_STATUSES = "open,queued,triaging,awaiting_input,pending_remediation,escalated"
#: Why an entry closed without being done (the collector's `_MOVED_REASONS`).
MOVED_REASONS = ("rerouted", "merged")
#: How many blocked checks are named in full; beyond this three are named and the rest counted (blocked-rule-names.ts).
NAME_ALL_UP_TO, NAMED_WHEN_TRUNCATED = 5, 3
RULE_ROWS_MAX = 5
_TONE_MARKER = {"bad": "warn", "watch": "watch", "ok": "ok"}
_CHIP_MARKER = {"group": "proven", "stale": "warn"}
_CHIP_GLYPH = {"group": "◆", "stale": "▲", "unjudged": "○", "drift": "◇", "unmodelled": "⊘", "effort": "◈"}
_COV_GLYPH = {"measured": "●", "partial": "◐", "blind": "⊘", "not_yet": "○"}
_COV_LABEL = {"measured": "live", "partial": "stale", "blind": "blind", "not_yet": "not yet"}
_CHANGE = {"still_here": "still here", "new": "new", "resolved": "resolved"}
_TRUST_SEE = {"rule_supply": "{home} gaps", "rule_runs": "{app} rules list"}
_BACKTICKED = re.compile(r"`(torana [^`]+)`")


# ── small helpers ────────────────────────────────────────────────────────────────────────────────────────────────
def _line(kind: str, text, *, marker: str | None = None, indent: int = 0, cites: list | None = None,
          commands: list | None = None, source: dict | None = None, parts: dict | None = None) -> dict:
    return {"kind": kind, "text": str(text or ""), "marker": marker, "indent": indent, "cites": cites or [],
            "commands": commands or [], "source": source, "parts": parts}


def _text(v) -> str:
    """A proven narration's sentence is {text, cites}; a classic one is a string."""
    return str(v.get("text") or "") if isinstance(v, dict) else str(v or "")


def _ids(v) -> list:
    return list(v.get("cites") or []) if isinstance(v, dict) else []


def _num(v) -> str:
    return f"{v:,}" if isinstance(v, int) and not isinstance(v, bool) else str(v)


def _is_int(v) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _dot(*xs) -> str:
    return " · ".join(str(x) for x in xs if x)


def _hours(stamp, now: datetime) -> int | None:
    t = _dt(stamp)
    return None if t is None else max(0, int((now - t).total_seconds() // 3600))


def _age(stamp, now: datetime) -> dict | None:
    """The page's age tile: hours under 48, then days (home-view.ts ageLabel)."""
    hrs = _hours(stamp, now)
    if hrs is None:
        return None
    if hrs < 48:
        return {"n": hrs, "unit": "hr" if hrs == 1 else "hrs"}
    d = hrs // 24
    return {"n": d, "unit": "day" if d == 1 else "days"}


def _age_text(age: dict | None) -> str | None:
    return f"{age['n']} {age['unit']}" if age else None


def _days(stamp, now: datetime) -> int:
    hrs = _hours(stamp, now)
    return 0 if hrs is None else hrs // 24


def _ago(stamp, now: datetime) -> str:
    """measure-clocks.pipe.ts `ago`."""
    t = _dt(stamp)
    if t is None:
        return str(stamp)
    secs = max(0, (now - t).total_seconds())
    if secs < 90:
        return "just now"
    if secs < 5400:
        return f"{int(secs // 60)}m ago"
    if secs < 172800:
        return f"{int(secs // 3600)}h ago"
    return f"{int(secs // 86400)}d ago"


def _when(stamp, tz: str | None) -> str | None:
    """"3 Oct 11:01 AM PT": a time in the zone the health lines are written in (health.py)."""
    t = _dt(stamp)
    if t is None:
        return None
    zone = ZoneInfo(tz or DEFAULT_TZ)
    local = t.astimezone(zone)
    return f"{local.strftime('%-d %b %-I:%M %p')} {'PT' if zone.key == DEFAULT_TZ else local.strftime('%Z')}"


def _artifact_command(ref) -> str | None:
    """The command that opens the record a line came from (the CLI's half of the route table, ai_home/artifacts.py)."""
    if not isinstance(ref, dict) or not ref.get("id"):
        return None
    cmd = {"alert": "torana alert {id} get", "widget": "torana widget {id} decompose",
           "vulnerability": "torana vulnerabilities list --id {id}"}.get(str(ref.get("kind") or ""))
    return cmd.format(id=ref["id"]) if cmd else None


def blocked_rules_text(blocked: int, names) -> str:
    """"4 cannot fire: a, b, c, d". The count is never larger than the names shown plus "and N more"."""
    all_ = [n for n in names or [] if n]
    shown = all_ if len(all_) <= NAME_ALL_UP_TO else all_[:NAMED_WHEN_TRUNCATED]
    more = max(0, blocked - len(shown))
    if not shown:
        return f"{blocked} cannot fire"
    return f"{blocked} cannot fire: {', '.join(shown)}" + (f" and {more} more" if more else "")


def cite_index(proof: dict | None) -> dict:
    """id → {id, kind, text} over the STORED proof: a claim by its `cid`, a decision group by its `gid`."""
    idx: dict = {}
    for g in (proof or {}).get("groups") or []:
        if g.get("gid"):
            idx[g["gid"]] = {"id": g["gid"], "kind": "group", "text": g.get("text")}
    for it in (proof or {}).get("items") or []:
        for c in it.get("claims") or []:
            if c.get("cid"):
                idx[c["cid"]] = {"id": c["cid"], "kind": "claim", "text": c.get("text")}
    return idx


class _Page:
    """The page's parts, read once. Not state: built and dropped inside one `sections()` call."""

    def __init__(self, page: dict, ws: str, now: datetime | None, tz: str | None):
        self.facts = page.get("facts") or {}
        self.narr = page.get("narration") or None
        self.proof = page.get("proof") or {}
        self.home = self.proof.get("home") or {}
        self.strip = page.get("health") or None
        self.collector_errors = page.get("collector_errors") or self.facts.get("collector_errors") or []
        self.ws, self.tz = ws, tz
        window = self.facts.get("window") or {}
        self.now = now or _dt(page.get("now_at")) or _dt(window.get("now_at")) or datetime.now(timezone.utc)
        self.since = _dt(page.get("since_at")) or _dt(window.get("since_at"))
        self.app = f"{APP_CMD} {ws}"
        self.home_cmd = f"{self.app} ai-home"
        self.idx = cite_index(self.proof)
        self.items = {it["alert_id"]: it for it in self.proof.get("items") or [] if it.get("alert_id")}
        self.alerts = {str(a.get("id")): a for a in (self.facts.get("alerts") or {}).get("items") or []
                       if isinstance(a, dict)}

    def cites(self, ids) -> list:
        return [self.idx.get(i) or {"id": i, "kind": "group" if str(i).startswith("G") and ":" not in str(i)
                                    else "claim", "text": None} for i in dict.fromkeys(ids or [])]

    def in_window(self, stamp) -> bool:
        t = _dt(stamp)
        return bool(t and self.since and t >= self.since)

    def item_commands(self, alert_id: str) -> list:
        it = self.items.get(alert_id) or {}
        out = [f"{self.home_cmd} item {alert_id} get --section ledger"]
        if it.get("has_graph"):
            out.append(f"{self.home_cmd} item {alert_id} get --section graph")
        if it.get("type") not in NO_BRIEF_TYPES:
            out.append(f"{self.home_cmd} item {alert_id} brief get")
        return out


# ── Z0 act first, Z6 blind ───────────────────────────────────────────────────────────────────────────────────────
def _act_first(p: _Page) -> dict:
    if p.narr is None:
        return {"unavailable": NO_NARRATION, "drawn": False}
    lines = []
    for it in p.narr.get("act_first") or []:
        lines.append(_line("ai", _text(it.get("claim")), marker="ai", cites=p.cites(_ids(it.get("claim"))),
                           parts={"source_key": it.get("source_key")}))
        if it.get("why_first"):
            lines.append(_line("ai", _text(it.get("why_first")), marker="ai", indent=1,
                               cites=p.cites(_ids(it.get("why_first")))))
    return {"lines": lines} if lines else {"empty": NOTHING["act_first"], "drawn": False}


def _blind(p: _Page) -> dict:
    """⚠️ On a proven run the blind block is written by CODE from coverage (PF proven_narrator.blind_block), so its
    lines carry no `ai` marker. Nothing blind → `drawn: false`: on the screen the card's absence is the signal."""
    if p.narr is None:
        return {"unavailable": NO_NARRATION, "drawn": False}
    bb = p.narr.get("blind_block")
    if not bb:
        return {"empty": NOTHING["blind"], "drawn": False}
    lines = [_line("summary", bb.get("lead"))] if bb.get("lead") else []
    for s in bb.get("items") or []:
        fill = f" {s['filling_source']} would supply it." if s.get("filling_source") else ""
        lines.append(_line("blind_spot", f"{s.get('measure_name')}: {s.get('missing_input')}. {s.get('why') or ''}"
                           .rstrip() + fill, indent=1,
                           parts={k: s.get(k) for k in ("measure_name", "missing_input", "why", "filling_source")}))
    return {"lines": lines}


# ── Z1 summary ───────────────────────────────────────────────────────────────────────────────────────────────────
def _row_keys(p: _Page) -> list:
    """The page's rows (home-view.ts provenRows): the narrator's, in its order; without narration, the chosen rows."""
    return ([a.get("item_key") for a in (p.narr or {}).get("attention_items") or [] if a.get("item_key")]
            or list(p.home.get("chips") or {}))


def _health_view(p: _Page) -> dict | None:
    """The stored code-written home.health (home v6+); a run stored before it reads the page's own strip."""
    h = p.home.get("health")
    if h:
        return {"tone": h.get("tone"), "title": h.get("title"), "lines": h.get("lines") or []}
    s = p.strip
    return {"tone": s.get("tone"), "title": s.get("verdict"), "lines": s.get("lines") or []} if s else None


def _summary(p: _Page) -> dict:
    narr = p.narr or {}
    n = len(_row_keys(p))
    title = _text(narr.get("title_sentence"))
    hero = p.home.get("hero")
    if hero:         # the code-computed headline; the narrator's sentence is the headline only when there is none
        lines = [_line("summary", hero)]
    elif title:
        lines = [_line("ai", title, marker="ai", cites=p.cites(_ids(narr.get("title_sentence"))))]
    else:
        lines = [_line("summary", f"{n} item{'' if n == 1 else 's'} need{'s' if n == 1 else ''} you.")]
    if _text(narr.get("scope_sentence")):
        lines.append(_line("ai", _text(narr.get("scope_sentence")), marker="ai",
                           cites=p.cites(_ids(narr.get("scope_sentence")))))
    # Events in the window (activity timeline: syncs, runs, platform work), never "handled for you"; "N+" when the
    # collector's read hit its limit; "—" when unknown, never 0.
    since = p.facts.get("since") or {}
    ev = since.get("handled_count")
    events = "—" if not _is_int(ev) else f"{ev}+" if since.get("handled_truncated") is True else str(ev)
    h = _health_view(p)
    verdict = (h or {}).get("title") or "nothing to report about the app itself"
    tile = re.split(r" · |: ", verdict)[0]           # the tile is a glance; the reason is the health card's
    lines.append(_line("counts", _dot(f"{n} need you", f"{events} events in the window", tile),
                       marker=_TONE_MARKER.get((h or {}).get("tone"), "ok"),
                       parts={"need_you": n, "events": events,
                              "health": {"tone": (h or {}).get("tone"), "verdict": verdict, "headline": tile}}))
    steps = p.home.get("funnel") or []
    if steps and p.home.get("funnel_summary"):
        lines.append(_line("summary", p.home["funnel_summary"]))
        for st in steps:
            count = "—" if st.get("count") is None else _num(st["count"])
            lines.append(_line("funnel_step", _dot(f"{count} {st.get('unit')}", st.get("note")), indent=1,
                               parts={k: st.get(k) for k in ("stage", "count", "unit", "note")}))
    return {"lines": lines}


# ── Z2 trust ─────────────────────────────────────────────────────────────────────────────────────────────────────
def _trust(p: _Page) -> dict:
    """`proof.home.trust` as stored (home.trust), then a source the collector could not read, then the data-only note.
    Nothing to say → `drawn: false`: the screen draws this card only when something could make the page wrong."""
    lines, notes = [], []
    for t in p.home.get("trust") or []:
        cmd = _TRUST_SEE.get(t.get("see"))
        lines.append(_line("trust", t.get("text"), marker="warn" if t.get("glyph") == "▲" else "watch",
                           commands=[cmd.format(home=p.home_cmd, app=p.app)] if cmd else [],
                           parts={"kind": t.get("kind"), "see": t.get("see"), "glyph": t.get("glyph")}))
    errs = p.collector_errors
    if errs:
        lines.append(_line("summary", f"**{len(errs)} source(s) could not be read.** The figures below are computed "
                                      "without them, so they may under-count.", marker="warn"))
        lines += [_line("collector_error", f"{e.get('source')}: {e.get('error')}", indent=1,
                        parts={"source": e.get("source"), "error": e.get("error")}) for e in errs]
    if p.narr is None:
        notes.append("Showing measured data only. This run produced no narration; the figures are unaffected.")
    if not lines and not notes:
        return {"empty": NOTHING["trust"], "drawn": False}
    return {"lines": lines, "notes": notes}


# ── Zhealth ──────────────────────────────────────────────────────────────────────────────────────────────────────
def _health(p: _Page) -> dict:
    h = _health_view(p)
    if not h:
        return {"unavailable": "This run stored no facts about the app itself, so its state cannot be said.",
                "drawn": False}
    rule_ids = {r.get("name"): r.get("id") for r in (p.facts.get("rules") or {}).get("items") or []}
    lines = [_line("summary", h["title"], marker=_TONE_MARKER.get(h["tone"]))]
    for ln in h["lines"]:
        text = str(ln.get("text") or "")
        off = ln.get("glyph") == "○"                  # switched off: not running, and not a fault
        cmds = list(dict.fromkeys(_BACKTICKED.findall(text)))
        lines.append(_line("health_line", text, marker="off" if off else _TONE_MARKER.get(ln.get("tone")), indent=1,
                           commands=cmds, parts={"kind": ln.get("kind"), "tone": ln.get("tone"),
                                                 "glyph": ln.get("glyph"), "detail": ln.get("detail"),
                                                 "short": ln.get("short")}))
        if ln.get("detail"):
            lines.append(_line("note", f"Technical detail: {ln['detail']}", indent=2))
        if ln.get("kind") == "rule_blocked":
            for f in ln.get("items") or []:
                filled = (f"Filled only by {f['filled_by']}" if f.get("filled_by")
                          else f.get("meaning") or "Nothing fills it on this account")
                rid = rule_ids.get(f.get("rule"))
                lines.append(_line("blocked_field", _dot(f"{f.get('field')} ({f.get('column')}): {filled}",
                                                         f"To fix: {f['what_to_do']}" if f.get("what_to_do") else None),
                                   indent=2, commands=[f"torana rule {rid} get"] if rid else [], parts=dict(f)))
            continue
        groups: dict = {}                             # one group per integration, in stored order (the drawer's)
        for s in ln.get("items") or []:
            groups.setdefault(s.get("integration_id") or s.get("integration_name") or "?", []).append(s)
        for gid, rows in groups.items():
            iid = rows[0].get("integration_id")
            k = len(rows)
            lines.append(_line("sync_group", _dot(rows[0].get("integration_name") or "?",
                                                  f"{k} data source{'' if k == 1 else 's'}"), indent=2,
                               commands=[f"torana integration {iid} get"] if iid else [],
                               source={"kind": "integration", "id": iid} if iid else None,
                               parts={"integration_id": iid, "integration_name": rows[0].get("integration_name"),
                                      "count": k}))
            for s in rows:
                partial = s.get("status") == "partial"
                since, good = _when(s.get("failing_since"), p.tz), _when(s.get("last_success_at"), p.tz)
                lines.append(_line("sync_row", _dot(s.get("data_source"), "Incomplete" if partial else "Failed",
                                                    s.get("reason"), f"Failing since {since}" if since else None,
                                                    f"Last good sync {good}" if good else "No good sync on record"),
                                   marker="watch" if partial else "warn", indent=3, parts=dict(s)))
    # The screen's strip is silent when all is well (the hero's tile already says it); the lines are still the answer.
    return {"lines": lines, "drawn": h["tone"] != "ok"}


# ── Z3 needs you ─────────────────────────────────────────────────────────────────────────────────────────────────
def seen_before_line(shown: int, seen: int) -> str | None:
    """One sentence for the Needs-you list, in place of "still here" on every card: how many of the cards shown were
    on the previous Home page. None when none was (or there is no previous page). The FE states the same rule
    (pantheon-fe home-view.ts `seenBeforeLine`)."""
    if seen <= 0 or shown <= 0:
        return None
    if shown == 1:
        return "This was here on your last visit."
    return (f"All {shown} were here on your last visit." if seen >= shown
            else f"{seen} of {shown} were here on your last visit.")


def _row(p: _Page, key: str, indent: int) -> list:
    """One Needs-you row (v2-needs-you-row): the narrator's headline, the alert's own columns, the proof chips, then
    the AI-written recommendation on its own `ai` line. THE PROSE IS NARRATED, THE ATTRIBUTES ARE MEASURED."""
    a = next((x for x in (p.narr or {}).get("attention_items") or [] if x.get("item_key") == key), {})
    al, it = p.alerts.get(key) or {}, p.items.get(key) or {}
    chips = [{"kind": c.get("kind"), "glyph": _CHIP_GLYPH.get(c.get("kind"), "·"), "text": c.get("text"),
              "marker": _CHIP_MARKER.get(c.get("kind"))} for c in (p.home.get("chips") or {}).get(key) or []]
    age = _age(al.get("created_at"), p.now)
    parts = {"alert_id": key,
             "headline": _text(a.get("headline")) or it.get("title") or al.get("name") or key,
             "severity": str(al.get("severity") or "").lower() or None,
             "status": str(al.get("status") or "").replace("_", " ") or None,
             "owner": "owned by a person" if al.get("assigned_to") else None,
             "chips": chips, "age": age, "change": _CHANGE.get(al.get("change") or "") or None,
             # Only an explicit false hides the Graph; absent (a run stored before the flag) is unknown and keeps it.
             "has_graph": it.get("has_graph") is not False, "has_brief": it.get("type") not in NO_BRIEF_TYPES}
    waiting = f"waiting {_age_text(age)}" if age else None
    # "still here" is not printed per row (it is true of every row that was on the last page): the section says it
    # once, above its rows (seen_before_line). The value stays in `parts`.
    out = [_line("row", _dot(parts["headline"], parts["severity"], parts["status"], parts["owner"],
                             *[c["text"] for c in chips], waiting,
                             parts["change"] if parts["change"] != _CHANGE["still_here"] else None),
                 indent=indent, cites=p.cites(_ids(a.get("headline"))), commands=p.item_commands(key),
                 source=a.get("source") or al.get("source") or {"kind": "alert", "id": key}, parts=parts)]
    if _text(a.get("recommendation")):
        out.append(_line("ai", _text(a.get("recommendation")), marker="ai", indent=indent + 1,
                         cites=p.cites(_ids(a.get("recommendation")))))
    return out


def _members(p: _Page, card: dict, indent: int) -> list:
    out = []
    sections = card.get("sections") or [{"label": None, "members": card.get("members") or []}]
    for s in sections:
        if s.get("label"):
            out.append(_line("note", s["label"], indent=indent))
        for aid in s.get("members") or []:
            it = p.items.get(aid) or {}
            stale = bool(it.get("stale"))
            title = it.get("title") or aid
            out.append(_line("member", ("retired image · " if stale else "") + title,
                             marker="warn" if stale else None, indent=indent + 1,
                             commands=[f"{p.home_cmd} item {aid} get --section ledger"],
                             source={"kind": "alert", "id": aid},
                             parts={"alert_id": aid, "title": title, "stale": stale,
                                    "has_brief": it.get("type") not in NO_BRIEF_TYPES}))
    return out


def _card(p: _Page, c: dict) -> list:
    """One stored card (home.cards) as lines: `insight` = the highlight, `group` = another decision of several
    alerts, `retired` = every alert on an image that no longer runs, `row` = a decision of one alert."""
    kind, n, lead = c.get("kind"), len(c.get("members") or []), c.get("lead")
    if kind == "row":
        return _row(p, lead, 0) if lead else []
    rows = f"{n} row{'' if n == 1 else 's'}"
    brief = c.get("brief")
    parts = {"card_kind": kind, "key": c.get("key"), "title": c.get("title") or "",
             "headline": c.get("title") or "", "count": n,
             "note": c.get("text") or None, "lead": lead, "brief": brief,
             "has_brief": bool(brief) and (p.items.get(brief) or {}).get("type") not in NO_BRIEF_TYPES}
    if kind == "insight":
        a = next((x for x in (p.narr or {}).get("attention_items") or [] if x.get("item_key") == lead), {})
        parts["why"] = (p.home.get("highlight") or {}).get("reason")
        first = brief or (c.get("members") or [None])[0]
        out = [_line("card", c.get("title"), marker="proven", cites=p.cites(_ids(a.get("headline"))),
                     commands=p.item_commands(first) if first else [], parts=parts)]
        if parts["why"]:
            out.append(_line("note", f"Why this one: {parts['why']}", indent=1))
        if _text(a.get("recommendation")):
            out.append(_line("ai", _text(a.get("recommendation")), marker="ai", indent=1,
                             cites=p.cites(_ids(a.get("recommendation")))))
        return out + ([_line("note", f"The {rows}:", indent=1)] + _members(p, c, 1) if n > 1 else [])
    retired = kind == "retired"
    out = [_line("card", c.get("title") if retired else _dot(c.get("title"), rows),
                 marker="warn" if retired else "proven", parts=parts)]
    if retired and c.get("text"):
        out.append(_line("note", c["text"], indent=1))
    if lead:
        out += _row(p, lead, 1)
    return out + [_line("note", f"The {rows}:", indent=1)] + _members(p, c, 1)


def _needs_you(p: _Page) -> dict:
    keys = _row_keys(p)
    stored = p.home.get("cards")
    cards = stored if stored is not None else [{"kind": "row", "lead": k} for k in keys]
    lines = [ln for c in cards for ln in _card(p, c)]
    notes = []
    if not p.proof.get("items"):
        notes.append("Proof unavailable for this run: no row could be proven, so the rows come from the facts.")
    elif p.narr is None:
        notes.append("No narration passed the code critic, so the rows are shown without prose.")
    if not lines:
        rc = (p.facts.get("attention") or {}).get("rule_coverage") or {}
        if not rc.get("available"):
            return {"notes": notes,
                    "unavailable": "Rule coverage could not be read, so an empty list is not an all-clear."}
        blocked = int(rc.get("blocked") or 0)
        if not blocked:
            return {"notes": notes, "empty": "Nothing needs a decision from you right now."}
        named = blocked_rules_text(blocked, rc.get("blocked_rules")).partition(": ")[2]
        return {"notes": notes, "empty": (f"Nothing is in your inbox, but {blocked} of {rc.get('total')} watches "
                                          "cannot fire, so this is not an all-clear."
                                          + (f" Not watching: {named}." if named else ""))}
    al = p.facts.get("alerts") or {}
    open_label = (_num(al["open_total"]) if _is_int(al.get("open_total"))
                  else _num(al["open_count"]) + ("+" if al.get("truncated") else "")
                  if _is_int(al.get("open_count")) else None)
    if keys and open_label:
        notes.insert(0, f"showing {len(keys)} of {open_label} open")
    notes.insert(1 if keys and open_label else 0, "One card per decision; the highlighted one first."
                 if stored is not None else "This run predates stored cards: rows in the narrator's order.")
    leads = [c.get("lead") for c in cards if c.get("lead")]
    seen = seen_before_line(len(leads), sum((p.alerts.get(k) or {}).get("change") == "still_here" for k in leads))
    if seen:
        notes.insert(2 if keys and open_label else 1, "◷ " + seen)
    stale = p.home.get("stale")
    if stored is None and stale:          # a run stored before the cards (home v5) has no retired card: its one line
        lines.append(_line("stale", stale.get("text"), marker="warn",
                           parts={"alert_ids": list(stale.get("alert_ids") or [])}))
    rest = p.home.get("rest")
    if rest and rest.get("count"):
        lines.append(_line("rest", rest.get("text"),
                           commands=[f"torana alerts list --workspace-id {p.ws} --status {OPEN_STATUSES}"],
                           parts={"count": rest.get("count"), "by_type": rest.get("by_type")}))
    return {"lines": lines, "notes": notes}


# ── Z4 handled ───────────────────────────────────────────────────────────────────────────────────────────────────
def _handled(p: _Page) -> dict:
    """What the app dealt with WITHOUT the operator (home-view.ts handledRows), newest first, under the narrator's
    account of the window. ⚠️ Read from the handled buckets, not "every alert that is not open": an alert a PERSON
    closed is not the app working on your behalf.
    ⛔ "Closed" is said only of an alert that IS closed. A handled bucket also holds alerts the app acted on that are
    still open (`handled_by_app_playbook_executed`: MEASURED 10 of 10 rows still `pending_remediation`, run c6d38139),
    and the screen's port called every one "Closed". Those read "Acted on by the app"."""
    summary = _text((p.narr or {}).get("since_summary"))
    rows = []
    for name, b in ((p.facts.get("attention") or {}).get("buckets") or {}).items():
        if not str(name).startswith("handled_by_app") or not isinstance(b, dict):
            continue
        for a in b.get("alerts") or []:
            stamp = a.get("updated_at") or a.get("created_at")
            age = _age(stamp, p.now)
            # The bucket's own row, else the page's alert row; an alert with no status on either is not called closed.
            status = str(a.get("status") or (p.alerts.get(str(a.get("id"))) or {}).get("status") or "")
            closed = status in ("closed", "resolved")
            parts = {"alert_id": a.get("id"), "headline": a.get("name") or a.get("title"),
                     "state": "Closed" if closed else "Acted on by the app", "closed": closed,
                     "verdict": str(a.get("triage_verdict") or str(name).replace("handled_by_app_", ""))
                     .replace("_", " "),
                     "by": "by the app", "age": age,
                     "change": _CHANGE.get((p.alerts.get(str(a.get("id"))) or {}).get("change") or "") or None}
            src = a.get("source") or {"kind": "alert", "id": a.get("id")}
            cmd = _artifact_command(src)
            rows.append((_hours(stamp, p.now) if age else 0, _line(
                "handled_row", _dot(parts["headline"], f"{parts['state']} · {parts['verdict']}",
                                    parts["by"] if closed else None, _age_text(age), parts["change"]),
                marker="ok" if closed else None, commands=[cmd] if cmd else [], source=src, parts=parts)))
    rows.sort(key=lambda r: r[0] // 24)                     # by whole days, stable: the screen's order
    lines = ([_line("ai", summary, marker="ai")] if summary else []) + [ln for _, ln in rows]
    n_closed = sum(1 for _, ln in rows if ln["parts"]["closed"])
    notes = ([f"{n_closed} closed by the app"] if n_closed else []) + (
        [f"{len(rows) - n_closed} acted on by the app, still open"] if len(rows) > n_closed else [])
    return {"lines": lines, "notes": notes,
            "empty": None if lines else "The app closed nothing on your behalf in this window."}


# ── Zrules ───────────────────────────────────────────────────────────────────────────────────────────────────────
def _count_or_floor(total, floor: int, alerts: dict):
    """The endpoint's count when the collector read it; else the count over the fetched rows, `+` when truncated."""
    if _is_int(total):
        return total
    return f"{floor:,}+" if alerts.get("truncated") else floor


def _counters(p: _Page) -> list:
    """The five counts that say whether the alert list is moving (home-view.ts alertCounters). COMPUTED, not narrated;
    each prefers the collector's endpoint count, else a floor over the ≤200 fetched rows."""
    a = p.facts.get("alerts") or {}
    items = [x for x in a.get("items") or [] if isinstance(x, dict)]

    def terminal(x):
        return str(x.get("status") or "") in ("closed", "resolved")

    def moved(x):
        return str(x.get("resolution_reason") or "").lower() in MOVED_REASONS
    open_ = [x for x in items if not terminal(x)]
    open_floor = a["open_count"] if _is_int(a.get("open_count")) else len(open_)
    stale = _count_or_floor(a.get("stale_open_total"),
                            sum(1 for x in open_ if _days(x.get("created_at"), p.now) >= 1), a)
    closed_floor = int(a.get("closed_count") or 0)
    rows = [
        ("open_now", "open now", None, _count_or_floor(a.get("open_total"), open_floor, a), False),
        ("open_older_than_a_day", "open, older than a day", "open_now", stale, stale != 0),
        ("newly_opened", "newly opened", None, _count_or_floor(
            a.get("new_open_total"), sum(1 for x in open_ if p.in_window(x.get("created_at"))), a), False),
        ("newly_closed", "newly closed", None, _count_or_floor(a.get("new_closed_total"), sum(
            1 for x in items if terminal(x) and not moved(x) and p.in_window(x.get("updated_at"))), a), False),
        ("closed_total", "closed in total", None, _count_or_floor(a.get("closed_total"), closed_floor, a), False),
    ]
    return [counter_line(key, label, v, hot, of) for key, label, of, v, hot in rows]


#: What a nested counter's text says about the counter it is part of.
_COUNTER_OF = {"open_now": "of those open now"}


def counter_line(key: str, label: str, value, hot: bool, of: str | None = None) -> dict:
    """One counter, ADDRESSABLE BY ITS LABEL (HB-1, 2026-10-14). The label stands alone ("open, older than a day",
    never "of those, older than a day", which names nothing without the line above it), and it is on the line itself
    as well as in `parts`: `key` (stable, snake_case), `label` and `value`. `of` names the counter this one is PART
    of, so a reader never has to infer the nesting from the wording; the text says it too. The text leads with the
    label ("open, older than a day: 84 (of those open now)") so a terminal reader finds it by its label."""
    text = f"{label}: {_num(value)}" + (f" ({_COUNTER_OF.get(of, 'of ' + of)})" if of else "")
    ln = _line("counter", text, marker="warn" if hot else None, indent=1,
               parts={"key": key, "label": label, "value": value, "hot": hot, "of": of})
    ln.update({"key": key, "label": label, "value": value})
    return ln


def _rule_run(p: _Page, r: dict) -> dict:
    """Did the rule RUN, and did it raise anything. THREE outcomes, not two: "matched nothing" is the only good news."""
    never = bool(r.get("never_ran"))
    ok = not never and str(r.get("last_status") or "").upper() == "SUCCESS"
    matched = r.get("last_result_count")
    outcome = ("" if never else "matched nothing" if not matched
               else f"matched {matched}, raised alerts" if r.get("last_raised_alert")
               else f"matched {matched}, raised nothing")
    age = _age(r.get("last_run_at"), p.now)
    parts = {"rule_id": r.get("id"), "name": r.get("name"), "description": r.get("description") or "",
             "status": "never ran" if never else str(r.get("last_status") or "").lower(), "ok": ok,
             "never_ran": never, "age": age, "manual": str(r.get("last_trigger") or "").upper() == "MANUAL",
             "outcome": outcome}
    meta = [] if never else [f"last ran {_age_text(age)} ago" if age else None,
                             "manual run" if parts["manual"] else None, outcome]
    return _line("rule_run", _dot(parts["name"], parts["status"], *meta),
                 marker="watch" if never else "ok" if ok else "warn", indent=1,
                 commands=[f"torana rule {r['id']} get"] if r.get("id") else [],
                 source={"kind": "rule", "id": r["id"]} if r.get("id") else None, parts=parts)


def _rules_summary(p: _Page) -> str:
    """What the five rows cannot say about the rest (home-view.ts rulesSummary)."""
    r = p.facts.get("rules") or {}
    total = int(r["total"] if r.get("total") is not None else len(r.get("items") or []))
    if not total:
        return ""
    parts = [f"{total}{'+' if r.get('total_capped') else ''} detection{'' if total == 1 else 's'}"]
    # "no scheduled run recorded", never "not scheduled": a schedule may exist and not have fired in the logs read.
    seen = int(r.get("scheduled_runs_seen") or 0)
    parts.append(f"{seen} scheduled run(s) recorded" if seen else "no scheduled run recorded")
    if int(r.get("never_ran_count") or 0):
        parts.append(f"{r['never_ran_count']} never ran")
    blocked = int(((p.facts.get("attention") or {}).get("rule_coverage") or {}).get("blocked") or 0)
    if blocked:
        parts.append(f"{blocked} cannot fire")
    return " · ".join(parts)


def _watch_line(p: _Page) -> dict:
    """What the app is WATCHING (home-view.ts watchLine, watchUnsound): whether a rule RAN (`rules`) and whether it
    COULD EVER FIRE (`rule_coverage`) are different facts, and both are needed."""
    rules = [r for r in (p.facts.get("rules") or {}).get("items") or [] if isinstance(r, dict)]
    rc = (p.facts.get("attention") or {}).get("rule_coverage") or {}
    total = len(rules) or int(rc.get("total") or 0)
    if not total:       # the loudest state, never a blank: an app nothing watches can only be unobserved
        return _line("watch", "No watches configured — nothing is raising alerts for this app.", marker="warn")
    never = sum(1 for r in rules if r.get("never_ran"))
    failed = sum(1 for r in rules if not r.get("never_ran") and str(r.get("last_status") or "").upper() != "SUCCESS")
    blocked = int(rc.get("blocked") or 0)
    parts = ([f"{never} never ran"] if never else []) + ([f"{failed} failed on its last run"] if failed else []) + (
        [blocked_rules_text(blocked, rc.get("blocked_rules"))] if blocked else [])
    noun = "watch" if total == 1 else "watches"
    return _line("watch", f"{total} {noun} — {', '.join(parts) if parts else 'all ran, none blocked'}.",
                 marker="warn" if parts else None,
                 parts={"total": total, "never_ran": never, "failed": failed, "blocked": blocked})


def _rules(p: _Page) -> dict:
    rf = p.facts.get("rules") or {}
    items = [r for r in rf.get("items") or [] if isinstance(r, dict)]
    summary = _rules_summary(p)
    lines = [_line("summary", summary, commands=[f"{p.app} rules list"])] if summary else []
    lines.append(_watch_line(p))
    lines += _counters(p)
    # At most five; never-run rules lead, then most recently run. NOT windowed: a rule that last ran 25 hours ago is
    # what a reader most needs to see, so its age is stated instead.
    ordered = sorted(items, key=lambda r: str(r.get("last_run_at") or ""), reverse=True)
    ordered.sort(key=lambda r: not r.get("never_ran"))
    lines += [_rule_run(p, r) for r in ordered[:RULE_ROWS_MAX]]
    notes = []
    if not items:
        lines.append(_line("note", "This app has no detection rules, so nothing is watching for it.", marker="warn",
                           indent=1))
    elif len(items) > RULE_ROWS_MAX:
        notes.append(f"{len(items) - RULE_ROWS_MAX} more: {p.app} rules list")
    return {"lines": lines, "notes": notes,
            "unavailable": "The app's rules could not be read for this run." if rf.get("available") is False
            and not items else None}


# ── Zdash ────────────────────────────────────────────────────────────────────────────────────────────────────────
def _clocks(m: dict | None, now: datetime) -> str:
    """One measure's clocks, read together (measure-clocks.pipe.ts): "computed recently" and "data is recent" are
    different claims. A pushed source has no schedule, so its age sits beside the data clock, never in it."""
    m = m or {}
    as_of, ran, pushed = m.get("as_of"), m.get("query_ran_at"), m.get("pushed_as_of")
    if not (as_of or ran or pushed):
        return ""
    push_only = m.get("freshness") == "pushed"
    data = "pushed data" if push_only else f"data as of {_ago(as_of, now)}" if as_of else "data age unknown"
    push = ""
    if pushed:
        oldest = m.get("pushed_oldest_as_of")
        push = (f" · {'last push' if push_only else 'pushed data last push'} {_ago(pushed, now)}"
                + (f", oldest sender {_ago(oldest, now)}" if oldest else ""))
    return f"viewed now · {data}{push}" + (f" · computed {_ago(ran, now)}" if ran else "")


def _dashboards(p: _Page) -> dict:
    """The measures in the app's own grouping (home-view.ts dashboardBlocks, v2-dashboards). The NAME and the COUNT
    come from the facts, the lead and each card's words are the narrator's. A block whose dashboard is not in the
    capture is dropped. A blind card carries no number: it states the absence."""
    if p.narr is None:
        return {"unavailable": NO_NARRATION, "drawn": False}
    captured = {str(d.get("id")): d for d in (p.facts.get("dashboards") or {}).get("items") or []
                if isinstance(d, dict)}
    measures = {str(m.get("widget_id")): m for m in p.facts.get("measures") or [] if m.get("widget_id")}
    lines = []
    for b in p.narr.get("dashboard_blocks") or []:
        d = captured.get(str(b.get("dashboard_id")))
        if not d:
            continue
        name, cards = d.get("name") or "Dashboard", b.get("cards") or []
        total = d.get("widget_count") if _is_int(d.get("widget_count")) else None
        lines.append(_line("dashboard_block",
                           _dot(name, f"{len(cards)} of {total} views" if total is not None else None),
                           commands=[f"torana dashboard {d['id']} render"],
                           source={"kind": "dashboard", "id": d.get("id")},
                           parts={"dashboard_id": d.get("id"), "name": name, "shown": len(cards), "total": total}))
        if _text(b.get("lead")):
            lines.append(_line("ai", _text(b.get("lead")), marker="ai", indent=1, cites=p.cites(_ids(b.get("lead")))))
        for c in cards:
            state = c.get("coverage_state")
            number = c.get("number") or None
            figure = (" ".join(str(x) for x in (number, c.get("number_label")) if x) if number
                      else "not answerable" if state == "blind" else "a breakdown, not one number")
            label = _COV_LABEL.get(state, str(state))
            # The coverage travels with the number as glyph + label, said only when it is not plain 'measured'.
            cov = _dot(f"{_COV_GLYPH.get(state, '·')} {label}", c.get("coverage_note")) if state != "measured" else None
            clocks = _clocks(measures.get(str(c.get("widget_id"))), p.now)
            drillable = state not in ("blind", "not_yet")
            src = c.get("source") or ({"kind": "widget", "id": c["widget_id"]} if c.get("widget_id") else None)
            cmd = _artifact_command(src) if drillable else None
            lines.append(_line(
                "dashboard_card", _dot(c.get("headline"), figure, c.get("so_what"), cov, clocks),
                marker="ai", indent=1, commands=[cmd] if cmd else [], source=src,
                parts={"widget_id": c.get("widget_id"), "number": number, "number_label": c.get("number_label"),
                       "headline": c.get("headline"), "so_what": c.get("so_what"), "coverage_state": state,
                       "coverage_label": label, "coverage_note": c.get("coverage_note"), "clocks": clocks or None,
                       "drillable": drillable}))
    return {"lines": lines, "drawn": bool(lines)}


# ── assembly ─────────────────────────────────────────────────────────────────────────────────────────────────────
_BUILD = {"act_first": _act_first, "summary": _summary, "trust": _trust, "health": _health, "needs_you": _needs_you,
          "handled": _handled, "rules": _rules, "dashboards": _dashboards, "blind": _blind}


def section_cli(key: str, workspace_id: str) -> str:
    """The command that prints one card. `what_matters` is not part of a stored run: its own list answers it."""
    home = f"{APP_CMD} {workspace_id} ai-home"
    return f"{home} questions list" if key == "what_matters" else f"{home} get --section {key.replace('_', '-')}"


def sections(page: dict, *, workspace_id: str, now: datetime | None = None, tz: str | None = None) -> list[dict]:
    """Every card of the proven Home as finished lines. PURE: reads page = {facts, narration, proof, health}
    only; no I/O, no settings, no module state. Returns only the zones the run's template lists, in its order.

    One block: {key, title, description, cli, lines, notes, empty, unavailable, drawn}. `empty` is the sentence to show
    when the card has nothing, `unavailable` why the server could not fill it: a card is never silently empty.
    `drawn` is false when the screen draws no card for it today (act_first, trust and blind with nothing to say,
    dashboards with no block, health when all is well): a screen keeps hiding it, `--section <key>` still prints it.
    `what_matters` carries `live: true` and no lines: it is read from its own route.
    `now` dates the ages (handled, rules, the figures' clocks); without it the run's own `now_at` is used.
    `tz` is the zone absolute times are written in (default: health.py's)."""
    page = page or {}
    p = _Page(page, str(workspace_id), now, tz)
    zones = (p.facts.get("template") or {}).get("zones") or FALLBACK_ZONES
    out, seen = [], set()
    for z in zones:
        for key in ZONE_SECTIONS.get(str((z or {}).get("id")), ()):
            if key in seen:
                continue
            seen.add(key)
            fallback, description = _CARD[key]
            # Z1's title belongs to its hero; "What matters to you" and the untitled trust lines keep their own.
            title = fallback if key in ("what_matters", "trust") else (z.get("title") or fallback)
            block = {"key": key, "title": title, "description": description, "cli": section_cli(key, p.ws),
                     "lines": [], "notes": [], "empty": None, "unavailable": None, "drawn": True}
            if key == "what_matters":
                block["live"] = True
            else:
                block.update({k: v for k, v in _BUILD[key](p).items() if v is not None})
            out.append(block)
    return out
