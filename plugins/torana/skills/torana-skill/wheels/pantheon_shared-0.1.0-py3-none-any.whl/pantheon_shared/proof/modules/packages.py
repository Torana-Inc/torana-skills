"""packages — software packages inside images (entity graph `contains` edges, SBOM-derived)."""
from ..core.engine import NotCaptured, rule


@rule("packages.binaries_of", 3)
def binaries_of(ctx, image: str, source_package: str, version: str, ecosystem: str | None = None) -> dict:
    """HEURISTIC. A scanner names a SOURCE package; the image SBOM names BINARY packages.
    match = a `contains` edge from the image to pkg:<ecosystem>/<name starting with the source name>@<identical version>.
    v2: the ecosystem is the one the image's own packages use, never assumed (v1 defaulted to deb/debian, so a Wolfi or
    Alpine image matched nothing). Pass `ecosystem` (e.g. "apk/alpine") to pin it; otherwise every ecosystem the image
    carries is searched and `ecosystems` names the ones that matched. No match is "not matched", never a guess.
    v3: the same outputs live; a record captured under v1 (which never ran v2's select) replays with v1's own select
    instead of raising NotCaptured (`_contains`).
    Not authoritative: no platform edge maps a source package to its binaries."""
    edges = [e for e in _contains(ctx, image, source_package, version, ecosystem) if _named(e.get("to_key"), source_package)]
    names = [e.get("to_key").split("/")[-1].split("@")[0] for e in edges]
    ecos = sorted({"/".join(e.get("to_key").split("/")[:2]).removeprefix("pkg:") for e in edges})
    return {"binaries": ", ".join(names) or None, "edges": [e.key for e in edges], "ecosystems": ecos,
            "confidence": "heuristic"}


def _contains(ctx, image: str, source_package: str, version: str, ecosystem: str | None) -> list:
    """The image's `contains` edges at this version, under the ecosystem prefix (any ecosystem when none is pinned).
    Path guard: a record captured under v1 holds only v1's select (prefix pkg:deb/debian/<source>), so replaying it
    re-runs THAT select and reproduces v1's answer; the version bump reports `rule_changed`."""
    def sel(prefix):
        return ctx.select("entity_edges", [["edge_type", "=", "contains"], ["from_key", "=", image], ["is_deleted", "=", False],
                                           ["to_key", "prefix", prefix], ["to_key", "suffix", f"@{version}"]])
    try:
        return sel(f"pkg:{ecosystem}/" if ecosystem else "pkg:")
    except NotCaptured:
        if ecosystem:
            raise
        return sel(f"pkg:deb/debian/{source_package}")


def _named(purl: str | None, source_package: str) -> bool:
    """The package name (last path segment, before @) starts with the source package name."""
    return str(purl or "").split("/")[-1].split("@")[0].startswith(source_package)
