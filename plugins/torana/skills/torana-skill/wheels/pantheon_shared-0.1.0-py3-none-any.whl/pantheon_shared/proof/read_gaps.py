"""A customer-fixable READ failure as ONE Home "broken" line (G4 #11c; DS1a § 3.2.8, the home_gaps row contract).

A connector read that fails for a reason the customer can fix (a role not granted, an API switched off) is recorded on
the scope row's read record (`assets.reads`, DS1a § 3.2.2). An org-level GCP read is recorded as the sub-read
`<project>#org` on EVERY project row the integration reads, so the same refusal appears once per project. Home says it
ONCE: one line per (integration, organization, reason_code, role). The sync list then keeps only failures no read
record covers, so nothing is said twice (health._sync_rows reads `covered_syncs`).

Pure. Input = `facts.read_failures`, one dict per FAILED read entry:
  {integration_id, integration_name?, scope_row?, entry_key ('<data_source>[:<sub>][@region]|<integration_id>'),
   org_id?, reason_code, missing_permission?, fix?, fix_owner?, reason?, first_seen?}
Only a customer-fixable one (shared `CUSTOMER_FIX_CODES`, or a missing_permission) becomes a line; any other failure
(`read_failed`: a timeout, a provider 5xx) is Torana's, goes to ops and is never Home text (G4 #9).
Output rows = the home_gaps columns (kind, measure_name, missing_input, why, fix, owner, first_seen) plus `covers`.
"""
from __future__ import annotations

import re
from datetime import datetime, timezone

from ..identity.scope_key import CUSTOMER_FIX_CODES, ENTRY_INTEGRATION_SEP, entry_base


_TERMINAL = re.compile(r"[.!?][)\]\"'\u201d\u2019]*$")


def one_sentence(text) -> str | None:
    """A fix as ONE sentence-ending text (G4 B1): trailing whitespace and ';' go, a text that already ends in a terminal
    mark (a full stop, '!' or '?', optionally followed by a closing bracket or quote) stays, a run of trailing '..' becomes '.', anything
    else gets '.'. Only the END is touched: 'v1.2' and abbreviations inside the text stay whole."""
    t = re.sub(r"[\s;]+$", "", str(text or ""))
    t = t.strip()
    if not t:
        return None
    t = re.sub(r"\.{2,}$", ".", t)
    if not t.strip(". "):          # only dots ("." or "...") is no sentence
        return None
    return t if _TERMINAL.search(t) else t + "."


def iso_or_none(v) -> str | None:
    """A first_seen as an ISO-8601 string (UTC when it has no zone), or None when it is not a date (G4 B1)."""
    if isinstance(v, datetime):
        d = v
    else:
        raw = str(v or "").strip()
        if not raw:
            return None
        try:
            d = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        except ValueError:
            return None
    return (d if d.tzinfo else d.replace(tzinfo=timezone.utc)).isoformat()


def earliest(a, b) -> str | None:
    """The earlier of two first_seen values, compared as datetimes (never as strings); a non-date is ignored."""
    da, db = iso_or_none(a), iso_or_none(b)
    if da and db:
        return da if datetime.fromisoformat(da) <= datetime.fromisoformat(db) else db
    return da or db

#: A data source in the words a customer reads it in.
_SOURCE_WORDS = {"cloud_assets": "Cloud Asset Inventory", "scc_findings": "Security Command Center findings"}


#: The `why`, in Torana's own words per code. ⛔ Never the provider's text and never the record's free `reason`: a
#: refusal body can carry names and ids the page must not repeat.
_CODE_WORDS = {
    "permission_denied": "Torana was refused access to this data",
    "api_disabled": "The API this data comes from is switched off",
    "region_not_readable": "This region is not enabled for the account Torana reads with",
    "credentials_rejected": "The credentials Torana reads with were rejected",
}


def _data_source(entry_key: str) -> str:
    """'cloud_assets:org@r|iid' -> 'cloud_assets'."""
    return entry_base(entry_key).split(":", 1)[0].split("@", 1)[0]


def is_customer_read_failure(f: dict) -> bool:
    return str(f.get("reason_code") or f.get("code") or "") in CUSTOMER_FIX_CODES or bool(str(f.get("missing_permission") or "").strip())


def read_failure_gaps(read_failures: list | None) -> list[dict]:
    """One 'broken' line per (integration, org, reason_code, role), in first-seen order."""
    groups: dict[tuple, dict] = {}
    for f in read_failures or []:
        if not isinstance(f, dict) or not is_customer_read_failure(f):
            continue
        iid = str(f.get("integration_id") or "") or (str(f.get("entry_key") or "").split(ENTRY_INTEGRATION_SEP, 1) + [""])[1]
        ds = _data_source(str(f.get("entry_key") or ""))
        code = str(f.get("reason_code") or f.get("code") or "")
        role = str(f.get("missing_permission") or "").strip()
        k = (iid, str(f.get("org_id") or ""), code, role)
        g = groups.get(k)
        if g is None:
            org = str(f.get("org_id") or "").strip()
            why = _CODE_WORDS.get(code, "Torana could not read this data") + (f" (organization {org})" if org else "") \
                + ", so what it covers is not known."
            groups[k] = g = {"kind": "broken", "measure_name": _SOURCE_WORDS.get(ds, ds.replace("_", " ")),
                             "missing_input": role or code.replace("_", " "), "why": why, "reason_code": code,
                             "fix": one_sentence(f.get("fix")), "owner": str(f.get("fix_owner") or "").strip() or None,
                             "first_seen": iso_or_none(f.get("first_seen")), "integration_id": iid or None,
                             "integration_name": f.get("integration_name"), "org_id": f.get("org_id") or None,
                             "covers": [], "scopes": 0}
        g["scopes"] += 1
        if (iid, ds) not in g["covers"]:
            g["covers"].append((iid, ds))
        g["first_seen"] = earliest(g["first_seen"], f.get("first_seen"))
    return list(groups.values())


def covered_syncs(read_failures: list | None) -> dict:
    """{(integration_id, data_source): {reason_code, …}} a customer-fixable read record already explains."""
    out: dict[tuple, set] = {}
    for g in read_failure_gaps(read_failures):
        for c in g["covers"]:
            out.setdefault(c, set()).add(g["reason_code"])
    return out


#: What a sync row's own failure text says for each covered code. A row is the SAME failure as the read record only
#: when its reason says so; any other failure of that source stays in the sync list.
_ROW_WORDS = {
    "permission_denied": ("403", "forbidden", "permission", "denied", "not authorized", "unauthorized"),
    "api_disabled": ("disabled", "not been used", "service_disabled"),
    "region_not_readable": ("region", "opt-in"),
    "credentials_rejected": ("401", "credentials", "authentication", "unauthenticated"),
}


def row_is_covered(row: dict, codes: set) -> bool:
    text = f"{row.get('detail') or ''} {row.get('reason') or ''}".lower()
    return any(w in text for c in codes for w in _ROW_WORDS.get(c, ()))
