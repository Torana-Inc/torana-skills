"""The engine: rules, contexts, readers and the build record.

A RULE is a pure function  fn(ctx, **args) -> dict  registered with an id and a version.
It reads ONLY through ctx:
    ctx.row(table, key)          one row by primary key        -> Row  (None if absent; absence is recorded)
    ctx.select(table, where)     rows matching a closed WHERE  -> [Row] ordered by primary key
    ctx.meaning(table, column)   the platform's column meaning -> str | None
    ctx.now                      the build clock (an INPUT, never read from the system inside a rule)
    ctx.call(rule_id, **args)    another rule                  -> RuleResult (memoised per build)
Row.get(path) / RuleResult.get(out) record a pointer each time a value is used, so the proof of
any output is exactly the set of values that produced it.

Two readers implement the same interface:
    LiveReader       the platform now (through a RecordingSource)
    CapturedReader   the values a previous build captured — REPLAY must reproduce it exactly
"""
from __future__ import annotations

import inspect
import json
import re
from dataclasses import dataclass, field
from typing import Any, Callable

from . import pointers as P
from .schema import API_RESOURCES
from .where import matches, norm, to_sql

# ── rule registry ───────────────────────────────────────────────────────────
FORBIDDEN = re.compile(r"datetime\.now|datetime\.utcnow|time\.time\(|\.today\(|random\.|uuid\.uuid4")


@dataclass
class RuleDef:
    id: str
    version: int
    fn: Callable
    doc: str
    source: str
    code_hash: str
    module: str
    judgement: bool = False      # its output is an estimate, not a fact: a claim that rests on it is `assessed`


REGISTRY: dict[str, RuleDef] = {}


def rule(rule_id: str, version: int, judgement: bool = False):
    """Register a rule. Refuses rules that read the clock or randomness: they could not be replayed.
    `judgement=True` declares that the rule turns facts into an estimate (PROOF_ASSESSMENTS_SPEC § 3.2.2)."""
    def deco(fn):
        src = inspect.getsource(fn)
        if FORBIDDEN.search(src):
            raise ValueError(f"{rule_id}: non-deterministic call in rule body; take ctx.now as input instead")
        if rule_id in REGISTRY and REGISTRY[rule_id].fn.__qualname__ != fn.__qualname__:
            raise ValueError(f"{rule_id}: duplicate rule id (already {REGISTRY[rule_id].module}.{REGISTRY[rule_id].fn.__qualname__})")
        REGISTRY[rule_id] = RuleDef(rule_id, version, fn, inspect.getdoc(fn) or "", src, P.vhash(src), fn.__module__,
                                    judgement)
        return fn
    return deco


class NotCaptured(Exception):
    """Replay asked for a value the original build never read: the rule changed or is non-deterministic."""


def get_path(obj: Any, path: str) -> Any:
    cur = obj
    for part in path.split(".") if path else []:
        if cur is None:
            return None
        if isinstance(cur, str) and cur[:1] in "[{":
            try:
                cur = json.loads(cur)
            except ValueError:
                return None
        if isinstance(cur, list):
            cur = cur[int(part)] if part.isdigit() and int(part) < len(cur) else None
        elif isinstance(cur, dict):
            cur = cur.get(part)
        else:
            return None
    return cur


# ── rows ────────────────────────────────────────────────────────────────────
class Row:
    def __init__(self, ctx: "Ctx", table: str, key: Any, data: Any, q: str | None, captured: bool = False):
        self._ctx, self.table, self.key, self._data, self.q, self._captured = ctx, table, key, data, q, captured

    def _value(self, path: str) -> Any:
        if self._captured:
            if path not in self._data:
                raise NotCaptured(f"{self.table} {self.key} {path}")
            return self._data[path]
        return get_path(self._data, path)

    def p(self, path: str) -> tuple[Any, dict]:
        v = self._value(path)
        ptr = P.cell(self.table, self.key, path, v, self.q)
        self._ctx._record(ptr)
        return v, ptr

    def get(self, path: str) -> Any:
        return self.p(path)[0]


@dataclass
class RuleResult:
    ctx: "Ctx"
    run_id: str
    outputs: dict

    def p(self, out: str) -> tuple[Any, dict]:
        rd = REGISTRY[self.ctx.build.runs[self.run_id]["rule"]]
        ptr = P.rule_out(self.run_id, out, rd.judgement)
        self.ctx._record(ptr)
        return self.outputs.get(out), ptr

    def get(self, out: str) -> Any:
        return self.p(out)[0]

    def __getitem__(self, out: str) -> Any:
        return self.get(out)


# ── readers ─────────────────────────────────────────────────────────────────
class LiveReader:
    def __init__(self, source, schema):
        self.source, self.schema = source, schema
        self._rows: dict[tuple[str, str], tuple[str, Any]] = {}

    def _key(self, table: str, data: dict) -> Any:
        cols = self.schema.key_of(table)
        return data.get(cols[0]) if len(cols) == 1 else {c: data.get(c) for c in cols}

    def row(self, table: str, key: Any) -> tuple[str, Any]:
        ck = (table, P.key_str(key))
        if ck in self._rows:
            return self._rows[ck]
        if table in API_RESOURCES:
            res = API_RESOURCES[table]
            kc = res["key"][0]
            q, data = self.source.api(res["path"].format(**{kc: key}))
            out = (q, data or None)
        else:
            cols = self.schema.key_of(table)
            kv = {cols[0]: key} if len(cols) == 1 else key
            q, rows = self.source.sql(to_sql(table, [[c, "=", kv.get(c)] for c in cols], cols, self._check))
            out = (q, rows[0] if rows else None)
        self._rows[ck] = out
        return out

    def select(self, table: str, where: list, columns: list | None = None) -> tuple[str, list[dict]]:
        if table in API_RESOURCES:
            res = API_RESOURCES[table]
            by = next((v for c, op, v in where if c == res["by"] and op == "="), None)
            if by is None:
                raise ValueError(f"{table}: select needs {res['by']} = …")
            q, data = self.source.api(res["list"].format(**{res["by"]: by}))
            items = data if isinstance(data, list) else (data or {}).get("items", [])
            rows = sorted([{**r, res["by"]: r.get(res["by"], by)} for r in items if matches({**r, res["by"]: r.get(res["by"], by)}, where)],
                          key=lambda r: P.key_str(self._key(table, r)))
        else:
            q, rows = self.source.sql(to_sql(table, where, self.schema.key_of(table), self._check, columns))
        if not columns:                       # a projected row is partial: never serve it later as the whole row
            for r in rows:
                self._rows[(table, P.key_str(self._key(table, r)))] = (q, r)
        return q, rows

    def meaning(self, table: str, column: str) -> dict:
        return self.schema.meaning(table, column)

    def _check(self, *names):
        self.schema.check_ident(*names)


class CapturedReader:
    """Serves exactly what a build captured. Anything else raises NotCaptured."""

    def __init__(self, build: dict):
        self.cells: dict[tuple[str, str], dict] = {}
        self.absent: set[tuple[str, str]] = set()
        self.sels: dict[str, list] = {}
        self.meanings: dict[tuple[str, str], dict] = {}
        self.key_cols = build.get("keys", {})
        for p in build["leaves"].values():
            if p["k"] == "cell":
                self.cells.setdefault((p["table"], P.key_str(p["key"])), {})[p["path"]] = p["value"]
            elif p["k"] == "absent":
                self.absent.add((p["table"], P.key_str(p["key"])))
            elif p["k"] == "sel":
                self.sels[f"{p['table']}|{P.canon(p['where'])}"] = p["keys"]
            elif p["k"] == "meaning":
                self.meanings[(p["table"], p["column"])] = {"text": p["text"], "writers": None, "q": None}

    def row(self, table: str, key: Any) -> tuple[str, Any]:
        ck = (table, P.key_str(key))
        if ck in self.absent:
            return None, None
        if ck in self.cells:
            return None, self.cells[ck]
        raise NotCaptured(f"row {table} {key}")

    def select(self, table: str, where: list, columns: list | None = None) -> tuple[str, list]:
        sk = f"{table}|{P.canon(where)}"
        if sk not in self.sels:
            raise NotCaptured(f"select {sk}")
        return None, [(k, self.cells.get((table, P.key_str(k)), {})) for k in self.sels[sk]]

    def meaning(self, table: str, column: str) -> dict:
        if (table, column) not in self.meanings:
            raise NotCaptured(f"meaning {table}.{column}")
        return self.meanings[(table, column)]


# ── context ─────────────────────────────────────────────────────────────────
class Ctx:
    def __init__(self, build: "Build", run_id: str | None = None):
        self.build, self.run_id, self.inputs = build, run_id, []

    @property
    def now(self) -> str:
        ptr = P.now(self.build.now)
        self._record(ptr)
        return self.build.now

    def _record(self, ptr: dict) -> None:
        self.inputs.append(ptr)
        if P.leaf_id(ptr):
            self.build.leaves[P.leaf_id(ptr)] = ptr

    def row(self, table: str, key: Any) -> Row | None:
        if key is None or (isinstance(key, dict) and any(v is None for v in key.values())):
            self.build.missing_inputs.append({"run": self.run_id, "table": table, "key": key})
            return None                       # not evidence of anything; dependent claims render "—"
        q, data = self.build.reader.row(table, key)
        if data is None:
            self._record(P.absent(table, key, q))
            return None
        return Row(self, table, key, data, q, captured=self.build.captured)

    def select(self, table: str, where: list, columns: list | None = None) -> list[Row]:
        return self.select_p(table, where, columns)[0]

    def select_p(self, table: str, where: list, columns: list | None = None) -> tuple[list[Row], dict | None]:
        """select, plus the selection's own pointer (what a graph's "K more" node cites); None when not read.
        `columns` projects the read to the named columns (and the closed set of derived ones, see where.DERIVED): a rule
        that needs three cells never fetches the other 130, and never the scanner's raw output."""
        w = norm(where)
        if any(op == "=" and val is None for _, op, val in w):
            self.build.missing_inputs.append({"run": self.run_id, "table": table, "where": w})
            return [], None                   # an explicit NULL test must use op "is_null"
        q, rows = self.build.reader.select(table, w, columns) if columns else self.build.reader.select(table, w)
        if self.build.captured:
            keys = [k for k, _ in rows]
            out = [Row(self, table, k, d, None, captured=True) for k, d in rows]
        else:
            keys = [self.build.reader._key(table, r) for r in rows]
            out = [Row(self, table, k, r, q) for k, r in zip(keys, rows)]
        ptr = P.sel(table, w, keys, q)
        self._record(ptr)
        return out, ptr

    def one(self, table: str, where: list, columns: list | None = None) -> Row | None:
        rows = self.select(table, where, columns)
        return rows[0] if rows else None

    def meaning(self, table: str, column: str) -> tuple[str | None, dict]:
        m = self.build.reader.meaning(table, column)
        ptr = P.meaning(table, column, m.get("text"))
        self._record(ptr)
        return m.get("text"), ptr

    def call(self, rule_id: str, **args) -> RuleResult:
        run_id, outputs = self.build.run_rule(rule_id, args, parent=self.run_id)
        return RuleResult(self, run_id, outputs)


# ── build ───────────────────────────────────────────────────────────────────
@dataclass
class Build:
    reader: Any
    now: str
    captured: bool = False
    leaves: dict = field(default_factory=dict)        # leaf_id -> pointer (the build's captured inputs)
    runs: dict = field(default_factory=dict)          # run_id -> {rule, version, code_hash, args, inputs, outputs, parent}
    missing_inputs: list = field(default_factory=list)  # reads skipped because a key was None (spec § 3.2.2 (c))
    _memo: dict = field(default_factory=dict)

    def run_rule(self, rule_id: str, args: dict, parent: str | None = None) -> tuple[str, dict]:
        rd = REGISTRY[rule_id]
        # Before the memo: a judgement rule a claim builder already ran is memoised, and would otherwise be handed to
        # any later caller unchecked, which would launder an estimate into a `derived` claim.
        if parent and rd.judgement and not REGISTRY[self.runs[parent]["rule"]].judgement:
            raise ValueError(f"{rule_id}: a judgement rule may only be called by a judgement rule or a claim builder")
        mk = f"{rule_id}|{P.canon(args)}"
        if mk in self._memo:
            return self._memo[mk]
        run_id = f"R{len(self.runs) + 1:04d}"
        # Reserve the id BEFORE the rule runs: a nested ctx.call computes its id from len(self.runs), so an
        # unreserved id was reused by the callee and then overwritten by the caller, losing the callee's run.
        self.runs[run_id] = {"run": run_id, "rule": rule_id, "version": rd.version, "code_hash": rd.code_hash,
                             "args": args, "inputs": [], "outputs": None, "parent": parent}
        ctx = Ctx(self, run_id)
        outputs = rd.fn(ctx, **args)
        self.runs[run_id].update(inputs=ctx.inputs, outputs=outputs)
        self._memo[mk] = (run_id, outputs)
        return run_id, outputs

    def ctx(self) -> Ctx:
        """A top-level context (claims, page assembly). Not memoised; its inputs belong to the caller."""
        return Ctx(self, None)


def closure(build: dict, ptrs: list[dict]) -> list[dict]:
    """All leaf inputs behind a set of pointers, following rule outputs through their runs."""
    seen, out, stack = set(), [], list(ptrs)
    while stack:
        p = stack.pop()
        if p["k"] == "rule":
            if p["run"] in seen:
                continue
            seen.add(p["run"])
            stack.extend(build["runs"][p["run"]]["inputs"])
        elif P.leaf_id(p):
            lid = P.leaf_id(p)
            if lid not in seen:
                seen.add(lid)
                out.append(p)
    return out


def rules_in_closure(build: dict, ptrs: list[dict]) -> set[str]:
    seen, stack = set(), [p["run"] for p in ptrs if p["k"] == "rule"]
    while stack:
        r = stack.pop()
        if r in seen:
            continue
        seen.add(r)
        stack.extend(p["run"] for p in build["runs"][r]["inputs"] if p["k"] == "rule")
    return seen
