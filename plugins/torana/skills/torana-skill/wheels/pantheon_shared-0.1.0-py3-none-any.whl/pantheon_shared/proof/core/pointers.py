"""Evidence pointers: where a value came from, precisely enough to read it again.

Every pointer is a plain dict (JSON-serialisable, stable across processes) built by these helpers.

  cell     one value at one path of one row        {k, table, key, path, hash, value, q}
  absent   a row looked up by key that is not there {k, table, key, q}
  sel      the key set a WHERE returned            {k, table, where, keys, hash, q}
  meaning  the platform's own column description  {k, table, column, hash, text}
  now      the clock, passed INTO a rule as input  {k, value}
  rule     one output of one rule run              {k, run, out}
  llm      model-written text; a label, never evidence {k, by, ...}

`hash` is over the canonical JSON of the value, so "updated_at moved but the value did not" is
not a change. `q` names the query (in the build's query log) that produced the read.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any


def canon(value: Any) -> str:
    return json.dumps(value, sort_keys=True, default=str, separators=(",", ":"))


def vhash(value: Any) -> str:
    return hashlib.sha256(canon(value).encode()).hexdigest()[:16]


def key_str(key: Any) -> str:
    """A row key as a stable string (composite keys are dicts)."""
    return canon(key) if isinstance(key, (dict, list)) else str(key)


def cell(table: str, key: Any, path: str, value: Any, q: str | None) -> dict:
    return {"k": "cell", "table": table, "key": key, "path": path, "hash": vhash(value), "value": value, "q": q}


def absent(table: str, key: Any, q: str | None) -> dict:
    return {"k": "absent", "table": table, "key": key, "q": q}


def sel(table: str, where: list, keys: list, q: str | None) -> dict:
    return {"k": "sel", "table": table, "where": where, "keys": keys, "hash": vhash(keys), "q": q}


def meaning(table: str, column: str, text: str | None) -> dict:
    return {"k": "meaning", "table": table, "column": column, "hash": vhash(text), "text": text}


def now(value: str) -> dict:
    return {"k": "now", "value": value}


def rule_out(run: str, out: str, judgement: bool = False) -> dict:
    return {"k": "rule", "run": run, "out": out, **({"judgement": True} if judgement else {})}


def llm(by: str, **ref: Any) -> dict:
    return {"k": "llm", "by": by, **ref}


def leaf_id(p: dict) -> str | None:
    """Identity of a leaf input, independent of its value — used to match old vs new reads."""
    k = p.get("k")
    if k == "cell":
        return f"cell|{p['table']}|{key_str(p['key'])}|{p['path']}"
    if k == "absent":
        return f"cell|{p['table']}|{key_str(p['key'])}|*"
    if k == "sel":
        return f"sel|{p['table']}|{canon(p['where'])}"
    if k == "meaning":
        return f"meaning|{p['table']}|{p['column']}"
    if k == "now":
        return "now"
    return None


def leaf_hash(p: dict) -> str | None:
    if p["k"] == "absent":
        return "absent"
    return p.get("hash") or (vhash(p["value"]) if p["k"] == "now" else None)
