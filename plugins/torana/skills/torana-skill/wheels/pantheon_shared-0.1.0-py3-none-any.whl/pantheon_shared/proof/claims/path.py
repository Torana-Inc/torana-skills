"""The exposure path an Inbox item shows, drawn from PLATFORM rows (modules/path.py): internet → services → places → the item.

Members are an ANCHOR (an entry's open linked members, a finding's own key, a code finding's repository and file); every
node and edge is a fact read about them from the entity graph, assets, artifacts, repositories, vulnerabilities and the CVE
table. A node carries `meta` (its own metadata and links, never its relationships) and the source and as-of time of what it
says; an edge carries its source and time. The page shows exactly this; nothing is added from the ranking.
"""
from __future__ import annotations

from .. import links as L
from ..core.engine import NotCaptured
from ..core.where import norm
from ..modules.path import deployments_where, is_function_package, is_gke_cluster, is_image, place_kind, service_cluster
from ..source_names import CVE_FEEDS, K8S_SOURCE
from ..times import pt
from .fanout import TOP, _follow_services, labels

EMPTY = {"nodes": [], "edges": [], "blast": []}
NO_MEMBERS = "No member findings are listed for this entry."
UNKNOWN = "unknown"
HIDDEN_MAX = 100                       # names listed behind a "+K more" node
COLS_ENTRY = {"inet": 0, "svc": 1, "place": 2, "item": 3, "cve": 4}
COLS_DEPLOY = {"inet": 0, "dep": 1, "svc": 2, "place": 3, "item": 4, "cve": 5}
COLS_CODE = {"inet": 0, "svc": 1, "img": 2, "repo": 3, "file": 4, "item": 5}


def _val(v) -> str:
    return UNKNOWN if v in (None, "", [], {}) else str(v)


def _yn(v):
    return None if v is None else ("yes" if v in (True, "true", "True") else "no")


def _meta(rows, links=None, source=None, as_of=None, items=None):
    """A node's panel: [label, value] rows (unknown shown as "unknown"), link-outs, its source and time. None when it would
    say nothing: no known value, no link, no list. Such a node is not clickable."""
    rows = [[k, _val(v)] for k, v in rows]
    links = [{"label": a, "url": u} for a, u in (links or []) if u]
    known = any(v != UNKNOWN for _, v in rows)
    if not (known or links or items):
        return None
    m = {"rows": rows, "links": links, "source": source, "as_of": as_of}
    if items:
        m["items"] = items
    return m


def _node(nid, col, row, t1, t2, p, meta=None, **flags) -> dict:
    n = {"id": nid, "col": col, "row": row, "t1": t1, "t2": t2, "p": p, **flags}
    if meta:
        n["meta"] = meta
    return n


def _edge(a, b, label, p, prov=None, style="reported") -> dict:
    prov = prov or {}
    return {"from": a, "to": b, "label": label, "style": style, "p": p, "source": prov.get("source"), "as_of": prov.get("as_of")}


def _short(key: str) -> str:
    """The name a node of that key carries: an image as `name@digest8`, a function package as `zip@digest8`, a
    repository without its host, a service as given. ⚠️ Kept in step with `fanout._short`, which titles the drawn
    nodes — the two must agree or a place is named one thing in the graph and another in a "+K more" list."""
    k = str(key)
    if k.startswith("gav:zip:sha256:"):
        return f"zip@{k.rsplit(':', 1)[-1][:8]}"
    if k.startswith(("image:", "image@")):
        return _image_name(k)[2] if "@sha256:" in k and not k.startswith("image@") else "image@" + k.split("sha256:")[-1][:8]
    return k[len("repo:github.com/"):] if k.startswith("repo:github.com/") else k.split(":", 1)[-1]


def _more(nid, col, row, hidden: list, noun: str, p, link_of=None, source=None, as_of=None):
    """"+K more": the hidden names (the short names the drawn nodes use, never a digest), each linked where a provider page
    exists, with where and when they were read."""
    if not hidden:
        return None
    items = [{"label": _short(h), "url": (link_of(h) if link_of else None)} for h in hidden[:HIDDEN_MAX]]
    return _node(nid, col, row, f"+{len(hidden)} more", noun, p, _meta([], None, source, as_of, items))


def _image_name(key: str) -> tuple[str, str, str]:
    """(registry path, short digest, short label) of `image:<path>@sha256:<digest>`."""
    body = key[len("image:"):] if key.startswith("image:") else key
    path, _, digest = body.partition("@sha256:")            # a digest-only key (`image@sha256:<digest>`) has path "image"
    path = "" if path == "image" else path
    return path, digest[:12], f"{path.split('/')[-1]}@{digest[:8]}" if digest else path.split("/")[-1]


def _cluster(name) -> str | None:
    parts = str(name or "").split("/")
    return f"{parts[2]} · {parts[1]} · {parts[0]}" if len(parts) == 3 and all(parts) else name


def _sev(score) -> str | None:
    try:
        x = float(score)
    except (TypeError, ValueError):
        return None
    word = "Critical" if x >= 9 else "High" if x >= 7 else "Medium" if x >= 4 else "Low"
    return f"{x:.1f} ({word})"


_CONTEXT_SOURCE = {"source": "set at the source", "source_inherited": "inherited at the source", "default": "the policy default"}


def _with_source(value, source):
    """A business-context value with where it came from ("medium (the policy default)"); None when there is no value."""
    if value in (None, "", "—"):
        return None
    word = _CONTEXT_SOURCE.get(source)
    return f"{value} ({word})" if word else value


def _service_meta(key, facts, owners, link_name):
    f = (facts or {}).get(key) or {}
    own = ", ".join((owners or {}).get(key, {}).get("owners") or []) or f.get("owner")
    url = L.gke_workload_url(f.get("cluster"), f.get("namespace"), link_name, f.get("workload_kind")) or L.gke_cluster_url(f.get("cluster"))
    return _meta([["Cluster", _cluster(f.get("cluster"))], ["Namespace", f.get("namespace")], ["Environment", f.get("environment")],
                  ["Criticality", _with_source(f.get("criticality"), f.get("criticality_source"))],
                  ["Customer data", (f"{_yn(f.get('customer_data'))} (derived: uses {f.get('customer_data_derived_from')})"
                                     if f.get("customer_data_derived_from") and _yn(f.get("customer_data")) not in (None, "", "—")
                                     else _with_source(_yn(f.get("customer_data")), f.get("customer_data_source")))], ["Owner", own],
                  ["Running since", f.get("running_since")]],
                 # The GKE console link is built only for a GKE cluster's 3-part name; a k3s cluster gets none.
                 [("Open in GKE", url if is_gke_cluster(f.get("cluster")) else None)],
                 cluster_source(f.get("source"), key, facts), f.get("as_of"))


def _image_meta(key, facts):
    f = (facts or {}).get(key) or {}
    path, digest, _ = _image_name(key)
    return _meta([["Registry path", path], ["Digest", digest], ["Pushed", f.get("pushed")]], [("Open in Artifact Registry", L.gar_image_url(key))],
                 f.get("source"), f.get("as_of"))


#: What a place of each kind is CALLED on the page. ⛔ Three kinds, not a boolean — see
#: `place_kind`. "function package" is the word the product uses for a deployment zip.
PLACE_LABEL = {"image": "image", "function": "function package", "repository": "repository"}


def _zip_meta(key, prov=None):
    """A function package's own panel: its content digest, and where the deployment that named it was read.

    ⚠️ DELIBERATELY THIN, and it says only what is true. A zip has NO inventory row today — nothing
    in `artifacts`, `packages` or `assets` holds a `gav:zip:` key — because the only observer so far
    is the Lambda record that stages its `CodeSha256`. So there is no push date to show and no
    registry to link to, and inventing either would be a value no row holds. The digest IS the
    identity (the key is content-addressed), so the panel is never empty, which is what makes the
    node clickable: before this it had no meta at all, because `_repo_meta` was asked about a key
    that is not a repository and found nothing.
    """
    prov = prov or {}
    return _meta([["Digest", str(key).split("sha256:")[-1][:12]], ["Packaging", "zip (deployment package)"]],
                 None, prov.get("source"), prov.get("as_of"))


def _repo_meta(key, facts):
    f = (facts or {}).get(key) or {}
    owner = f.get("owner") and (f"{f['owner']} ({f['owner_type']})" if f.get("owner_type") else f["owner"])
    return _meta([["Owner", owner], ["Criticality", None], ["Last push", f.get("last_push")]], [("Open in GitHub", L.github_repo_url(key))],
                 f.get("source"), f.get("as_of"))


def _cve_meta(cve, facts):
    f = (facts or {}).get(cve) or {}
    desc = str(f.get("description") or "").strip().split("\n")[0]
    desc = desc if len(desc) <= 160 else desc[:157].rstrip() + "…"
    epss = f"{float(f['epss']) * 100:.2f}% · {int(float(f.get('epss_percentile') or 0) * 100)}th percentile" if f.get("epss") is not None else None
    kev = None if f.get("kev") is None else (f"listed{' since ' + f['kev_added'] if f.get('kev_added') else ''}" if f.get("kev") else "not listed")
    return _meta([["Summary", desc], ["CVSS", _sev(f.get("cvss"))], ["EPSS", epss], ["CISA KEV", kev], ["CWE", f.get("cwe")],
                  ["Published", f.get("published")]], [("NVD", L.nvd_url(cve)), ("CISA KEV", L.kev_url(cve) if f.get("kev") else None)],
                 f.get("source") or CVE_FEEDS, f.get("as_of"))


def _package_meta(package, versions, pf, partial=False):
    pf = pf or {}
    fixed = None if not pf.get("found") else (", ".join(pf.get("fixed_versions") or []) or "no fix recorded")
    return _meta([["Package", package], ["Installed", ", ".join(versions or [])], [("Fixed in (CVEs shown)" if partial else "Fixed in"), fixed],
                  ["Dependency", ", ".join(pf.get("dependency") or []) or None], ["Manifest", ", ".join(pf.get("manifests") or []) or None],
                  ["First seen", pf.get("first_seen")], ["Reported by", ", ".join(pf.get("sources") or []) or None]],
                 None, ", ".join(pf.get("sources") or []) or None, pf.get("as_of"))


def _internet(exposure: dict, services_facts: dict, shown_services: list):
    ex = (exposure or {}).get("exposed") or {}
    hosts = sorted({e.get("endpoint") for s, e in ex.items() if e.get("endpoint")})
    fk = next((s for s in shown_services if ex.get(s)), None) or next(iter(ex), None)
    first = _svc_prov(ex.get(fk) or {}, fk, services_facts) if fk else {}
    ingress = next((((services_facts or {}).get(s) or {}).get("ingress") for s in shown_services if ((services_facts or {}).get(s) or {}).get("ingress")), None)
    # The gateway the shown services are reached THROUGH (MC-6): load balancer → reverse proxy → service. The row
    # appears only when one is recorded; a load balancer that reaches the service directly has none.
    gws = sorted({_service_name(v["gateway"]) for s in (shown_services or list(ex)) for e in [ex.get(s)] if e
                  for v in [e.get("via")] if v})
    through = [["Through", ", ".join(gws[:3]) + (f" and {len(gws) - 3} more" if len(gws) > 3 else "") + " (reverse proxy)"]] if gws else []
    return _meta([["Public address", ", ".join(hosts[:3]) + (f" and {len(hosts) - 3} more" if len(hosts) > 3 else "") if hosts else None],
                  *through, ["Ingress", ingress], ["Sign-in by route", _route_sign_ins(exposure, shown_services)]],
                 None, first.get("source"), first.get("as_of"))


#: How a route's recorded sign-in reads on the card: only an explicit "none" is "no sign-in", silence is "unknown".
_SIGN_IN = {"none": "no sign-in", "unknown": "unknown"}


def _route_sign_ins(exposure: dict, shown_services: list) -> str | None:
    """Up to 5 `matcher: sign-in` pairs for the shown services' routes, plus "and N more" (DS1b § 3.2.7). None when the
    record holds no route (a record built before path.exposure v3, or a service reached by no route)."""
    routes = (exposure or {}).get("routes") or {}
    pairs = [f"{r['matcher']}: {_SIGN_IN.get(r['auth'], 'sign-in required')}" if r.get("matcher")
             else _SIGN_IN.get(r["auth"], "sign-in required")
             for s in (shown_services or sorted(routes)) for r in routes.get(s) or []]
    return ", ".join(pairs[:5]) + (f" and {len(pairs) - 5} more" if len(pairs) > 5 else "") if pairs else None


def _service_name(key: str) -> str:
    """The workload name a `service:<cluster>/<namespace>/<name>` key ends in."""
    return str(key).rsplit("/", 1)[-1]


def _first_prov(services: dict) -> dict:
    """The source and time of the first deployment edge read — what a function-package panel cites."""
    for s in (services or {}).values():
        if s.get("source") or s.get("as_of"):
            return {"source": s.get("source"), "as_of": s.get("as_of")}
    return {}


def _key_cluster(service_key) -> str | None:
    """The cluster segment of `service:<cluster>/<namespace>/<name>`; None for a key without one."""
    return service_cluster(service_key)


def cluster_source(source, service_key, facts=None):
    """`Kubernetes cluster` → `Kubernetes · demo-vm-k3s` / `GKE · gke-twin-x2yk48`: the cluster the row was read from.

    ⛔ It said "GKE cluster" for EVERY Kubernetes row (source_names mapped the provider `kubernetes` to it), so the
    two k3s boxes on T2 read as GKE. The provider cannot tell them apart; the cluster's own name form can."""
    if not source or K8S_SOURCE not in str(source):
        return source
    cl = ((facts or {}).get(service_key) or {}).get("cluster") or _key_cluster(service_key)
    if not cl:
        return source
    word = "GKE" if is_gke_cluster(cl) else "Kubernetes"
    return str(source).replace(K8S_SOURCE, f"{word} · {str(cl).split('/')[-1]}", 1)


def _svc_prov(prov, service_key, facts=None) -> dict:
    prov = prov or {}
    return {**prov, "source": cluster_source(prov.get("source"), service_key, facts)}


def _cover(svc_rank: list, shown: list, linked: dict) -> tuple[list, list]:
    """The services drawn: first, for each drawn place in turn, the best-ranked service that runs it (unless a chosen one
    already does), then the rest by rank, TOP in all. ⛔ Rank alone drew an image no drawn service runs (T2 litellm:
    pantheon-agent-builder@ddfa runs only on the two k3s boxes, whose services ranked 7th and later), an image with no
    incoming edge."""
    chosen: list = []
    for pl in shown:
        if len(chosen) >= TOP or any(pl in linked[s] for s in chosen):
            continue
        best = next((s for s in svc_rank if pl in linked[s]), None)
        if best:
            chosen.append(best)
    for s in svc_rank:
        if len(chosen) >= TOP:
            break
        if s not in chosen:
            chosen.append(s)
    chosen = sorted(chosen, key=svc_rank.index)
    return chosen, [s for s in svc_rank if s not in chosen]


def _svc_t2(service_key, facts, exposed: bool) -> str:
    """`gke-twin-x2yk48 · internet-facing` / `demo-vm-k3s · running`: the cluster on every service node, so two services
    of one name in two environments are told apart (the title is the workload name alone)."""
    cl = ((facts or {}).get(service_key) or {}).get("cluster") or _key_cluster(service_key)
    word = "internet-facing" if exposed else "running"
    return f"{str(cl).split('/')[-1]} · {word}" if cl else word


def _runtime_places(svc: dict, places: dict) -> set:
    """The places a service is drawn linked to: the images (or function packages) it runs that are places themselves;
    only when there are none, the repositories that build what it runs ("built from")."""
    run = set(svc.get("images") or []) & set(places)
    return run or set(svc.get("places") or [])


def _version_groups(nodes: list, shown: list, places: dict) -> list:
    """[(versions, [(place index, place row)])]: the drawn places grouped by the version set each ships, the group of the
    top-most place first."""
    rows = {n["id"]: n["row"] for n in nodes}
    groups: dict = {}
    for i, pl in sorted(enumerate(shown), key=lambda x: (rows.get(f"p{x[0]}", x[0]), x[0])):
        groups.setdefault(tuple(places[pl].get("versions") or []), []).append((i, rows.get(f"p{i}", i)))
    return list(groups.items())


def _spread_rows(nodes: list) -> None:
    """Rows strictly increasing in order, so two package nodes never share a grid cell."""
    last = -1
    for n in nodes:
        n["row"] = max(n["row"], last + 1)
        last = n["row"]


def _deployment_layer(ctx, services: dict):
    """`path.deployments` for the services, or None when the path draws no deployment column: a service whose key names
    no cluster (an AWS estate, a two-part key), or a REPLAY of a record built before the rule existed (0.7.13 and older).
    ⛔ The replay case is probed on the reader BEFORE the call: a rule that raised NotCaptured would still have reserved a
    run id, and the replayed runs would no longer line up with the record's (`recompute.reproduced` compares them by
    position), so an older record would stop reproducing."""
    keys = sorted(services)
    if not keys or not all(service_cluster(s) for s in keys):
        return None
    if ctx.build.captured:
        try:
            ctx.build.reader.select("assets", norm(deployments_where(keys)))      # as Ctx.select_p keys it
        except NotCaptured:
            return None
    return ctx.call("path.deployments", services=keys)


def _layer_plan(groups: dict, svc_rank: list, linked: dict, ranked: list, exposed: dict) -> tuple[list, list, list]:
    """(plan, shown places, hidden places). ⭐ TOP APPLIES PER DEPLOYMENT, so every deployment is drawn: each takes the TOP
    places its services run (by rank) and the services that cover them (`_cover`). Rank alone gave the six service rows
    to one environment (T2 "Upgrade litellm": demo-vm's services crowded out the other two). Exposed deployments first,
    then the one with more services, then the cluster name. A place no deployment draws (not running, or past TOP in every
    deployment) is hidden behind "+K more"."""
    order = sorted(groups, key=lambda c: (not any(s in exposed for s in groups[c]["services"]), -len(groups[c]["services"]), c))
    plan, drawn = [], set()
    for c in order:
        mine = set(groups[c]["services"])
        svcs = [s for s in svc_rank if s in mine]
        here = {pl for s in svcs for pl in linked[s]}
        pls = [pl for pl in ranked if pl in here][:TOP]
        chosen, rest = _cover(svcs, pls, linked)
        plan.append({"cluster": c, "chosen": chosen, "hidden": rest, "places": pls,
                     "exposed": any(s in exposed for s in mine)})
        drawn.update(pls)
    shown = [pl for pl in ranked if pl in drawn]
    return plan, shown, [pl for pl in ranked if pl not in drawn]


def _deployment_meta(g: dict, svcs: list, exposed: dict, prov: dict):
    """A deployment's panel: environment, cluster, kind, the integration that reported it, how it is reached."""
    ex = [exposed[s] for s in svcs if s in exposed]
    hosts = sorted({e.get("endpoint") for e in ex if e.get("endpoint")})
    gws = sorted({_service_name(e["via"]["gateway"]) for e in ex if e.get("via")})
    reach = ("internet-facing" if ex else "no public address recorded for its services")
    url = L.gke_cluster_url(g.get("cluster_name")) if g.get("kind") == "GKE" else None
    return _meta([["Environment", g.get("environment")], ["Cluster", g.get("cluster_name")], ["Kind", g.get("kind")],
                  ["Integration", g.get("integration")], ["Exposure", reach],
                  ["Public address", ", ".join(hosts) or None], ["Through", (", ".join(gws) + " (reverse proxy)") if gws else None],
                  ["Services", f"{len(svcs)} run this package's places" + (f" ({g['with_asset']} with an asset record)"
                                                                            if g.get("with_asset", len(svcs)) != len(svcs) else "")]],
                 [("Open in GKE", url)], prov.get("source"), prov.get("as_of"))


def deployment_t2(cluster: str, exposed: bool, n: int) -> str:
    """`gke-twin-x2yk48 · internet-facing · 13 services`. ⚠️ The words, not a colour, carry the state."""
    return f"{str(cluster).split('/')[-1]} · {'internet-facing' if exposed else 'not internet-facing'} · {n} service{'' if n == 1 else 's'}"


def entry_path(ctx, anchor, kind_key: str) -> dict:
    """The path for an entry (one package) or a finding (one member). `anchor` is the RuleResult of path.entry_members /
    path.finding_member.

    ⭐ DEPLOYMENT LAYER (0.7.14): when every service names its cluster, a deployment column sits between the internet and the
    services: Internet —reaches→ deployment —hosts→ service —runs→ image. A deployment node is `kind: "deployment"`,
    `collapsed: true`, `children` = its service node ids (each child carries `parent`); its edges straight to the images its
    drawn services run (`runs`) carry `folded: <deployment id>` and are drawn ONLY while that deployment is collapsed. Rows
    are the expanded layout, so a consumer that cannot fold still draws a well-formed graph and every deployment."""
    places = anchor.get("places") or {}
    if not anchor.get("available") or not places:
        return {**EMPTY, "note": NO_MEMBERS}
    package, versions = anchor.get("package"), anchor.get("versions") or []
    ranked = sorted(places, key=lambda pl: (-len(places[pl]["cves"]), pl))
    shown, hidden = ranked[:TOP], ranked[TOP:]
    dep = ctx.call("path.deployment", places=sorted(places))
    services = dep.get("services") or {}
    # ⛔ A service RUNS one image. `path.deployment` also lists the repository that builds it (repo → builds_image → the
    # same image), so when the image is itself a place the repository is the same fact twice: it drew a second "runs"
    # edge from every service to "+K more" (MEASURED on T2 "Upgrade litellm": 9 drawn services, 9 such edges, all to a
    # hidden repository). The repository is linked only when no image the service runs is a place (repository-only SCA).
    linked = {s: _runtime_places(services[s], places) for s in services}
    exp = ctx.call("path.exposure", services=sorted(services))
    exposed = exp.get("exposed") or {}
    layer = _deployment_layer(ctx, services)
    groups = (layer.get("deployments") or {}) if layer is not None else {}
    plan: list = []
    if groups:
        svc_rank = sorted(services, key=lambda s: (s not in exposed, -len(linked[s]), s))
        plan, shown, hidden = _layer_plan(groups, svc_rank, linked, ranked, exposed)
        shown_svc, hidden_svc = [s for d in plan for s in d["chosen"]], []
        cols = COLS_DEPLOY
    else:
        # Services that run a DRAWN place come first, so a drawn service always has an edge; one that runs only hidden places
        # links to the "+K more" places node. Among those, an internet-facing one first: the repository count used to break
        # this tie by accident, and without it the order fell back to the name, which dropped every internet-facing service
        # (and the Internet node) from the T2 litellm path.
        svc_rank = sorted(services, key=lambda s: (-len(linked[s] & set(shown)), s not in exposed, -len(linked[s]), s))
        shown_svc, hidden_svc = _cover(svc_rank, shown, linked)
        cols = COLS_ENTRY
    shown_repos = [pl for pl in shown if pl.startswith("repo:")]
    own = ctx.call("path.owners", entities=sorted({*shown_svc, *shown_repos}))
    sfacts = ctx.call("path.service_facts", services=sorted(shown_svc))
    images = [pl for pl in shown if is_image(pl)]
    ifacts = ctx.call("path.image_facts", images=sorted(images)) if images else None
    rfacts = ctx.call("path.repo_facts", repos=sorted(shown_repos)) if shown_repos else None
    top = ranked[0]
    cve_rank = sorted(anchor.get("cves") or [], key=lambda c: (-sum(c in v["cves"] for v in places.values()), c))
    shown_cve, hidden_cve = cve_rank[:TOP], cve_rank[TOP:]
    # The package read covers the CVEs drawn, at the largest place: one row each, so the record stays small however many
    # members the entry has (840 members once cost 0.5 MB here).
    pf = ctx.call("path.package_facts", package=package, versions=versions, images=[top] if is_image(top) else [],
                  repos=[top] if top.startswith("repo:") else [], cves=sorted(shown_cve), ecosystem=anchor.get("ecosystem")) if package else None
    cfacts = ctx.call("path.cve_facts", cves=sorted(shown_cve)) if shown_cve else None

    lab = labels(shown)
    N, E = [], []
    svc_links: dict = {}
    for i, pl in enumerate(shown):
        kind = place_kind(pl)
        t1 = lab[pl]
        n_find = len(places[pl]["cves"])
        notrun = pl in (dep.get("not_deployed") or [])
        t2 = f"{PLACE_LABEL[kind]} · {n_find} finding{'' if n_find == 1 else 's'}" + (" · not running" if notrun else "")
        meta = (_image_meta(pl, (ifacts or {}).get("images")) if kind == "image"
                else _zip_meta(pl, _first_prov(services)) if kind == "function"
                else _repo_meta(pl, (rfacts or {}).get("repos")))
        N.append(_node(f"p{i}", cols["place"], i, t1, t2, dep.p("services")[1], meta))
    svf = (sfacts or {}).get("services")
    hid_pl = _more("p-more", cols["place"], len(shown), hidden, f"more places · {sum(len(places[h]['cves']) for h in hidden)} findings",
                   dep.p("services")[1],
                   lambda h: None if is_function_package(h) else (
                       L.gar_image_url(h) if is_image(h) else L.github_repo_url(h)),
                   ", ".join((pf or {}).get("sources") or []) or next((cluster_source(s.get("source"), k, svf) for k, s in services.items()
                                                                     if s.get("source")), None),
                   (pf or {}).get("as_of") or next((s.get("as_of") for s in services.values() if s.get("as_of")), None))
    # The row of each drawn service: its index without deployments; with them, each deployment's block of service rows
    # (its "+K more services" node last) one after another.
    svc_row, row_of_rows, dep_rows = {}, [], []
    if plan:
        for d in plan:
            dep_rows.append(len(row_of_rows))
            row_of_rows += d["chosen"] + ([None] if d["hidden"] else [])
            if not d["chosen"] and not d["hidden"]:
                row_of_rows.append(None)
        svc_row = {s: r for r, s in enumerate(row_of_rows) if s}
    for j, sk in enumerate(shown_svc):
        e = exposed.get(sk)
        t2 = ("internet-facing" if e else "running") if plan else _svc_t2(sk, svf, bool(e))
        N.append(_node(f"s{j}", cols["svc"], svc_row.get(sk, j), _service_name(sk), t2, dep.p("services")[1],
                       _service_meta(sk, svf, (own or {}).get("owners"), sk.split("/")[-1]),
                       **({"cls": "inet"} if e else {})))
        sprov = _svc_prov(services[sk], sk, svf)
        svc_links.setdefault(sk, [])
        for i, pl in enumerate(shown):
            if pl in linked[sk]:
                svc_links[sk].append((f"p{i}", None))
                # ⚠️ A repository is "built from"; an image and a function package are both RUN, and both
                # edges are REPORTED (a live `deployed_as`), never derived.
                _runs = place_kind(pl) in ("image", "function")
                E.append(_edge(f"s{j}", f"p{i}", "runs" if _runs else "built from", dep.p("services")[1], sprov,
                               "reported" if _runs else "derived"))
        if hid_pl and any(h in linked[sk] for h in hidden):
            E.append(_edge(f"s{j}", "p-more", "runs", dep.p("services")[1], sprov))
        if e and not plan:
            E.append(_edge("inet", f"s{j}", "reaches", exp.p("exposed")[1], _svc_prov(e, sk, svf)))
    if hidden_svc:
        N.append(_more("s-more", cols["svc"], len(shown_svc), hidden_svc, "more services", dep.p("services")[1], None,
                       cluster_source(services[hidden_svc[0]].get("source"), hidden_svc[0], svf), services[hidden_svc[0]].get("as_of")))
        N[-1]["meta"]["items"] = [{"label": h.split(":", 1)[-1], "url": None} for h in hidden_svc[:HIDDEN_MAX]]
    if plan:
        _deployment_nodes(N, E, plan, groups, shown, shown_svc, dep_rows, linked, hidden, hid_pl, services, exposed, dep, exp,
                          layer, svf)
    elif any(s in exposed for s in shown_svc):
        rows = max(min(len(svc_rank), TOP), 1)
        N.append(_node("inet", cols["inet"], (rows - 1) // 2, "Internet", "internet-facing", exp.p("exposed")[1],
                       _internet(exp, (sfacts or {}).get("services"), shown_svc), cls="inet"))
    if hid_pl:
        N.append(hid_pl)
    _follow_services(N, row_of_rows if plan else shown_svc, svc_links)
    mid = max(((max((n["row"] for n in N), default=0)) // 2), 0)
    item_p = pf.p("rows")[1] if pf else dep.p("services")[1]
    # ⛔ ONE PACKAGE NODE PER VERSION SET THE DRAWN PLACES SHIP. One node carrying the entry's every version said each image
    # "contains litellm (1.40.2, 1.50, … 1.97)" when all 18 images ship 1.82.6 and the other seven versions are pinned only
    # in repository manifests (MEASURED on T2). The panel keeps the entry's full list ("Installed").
    pmeta = _package_meta(package, versions, pf, bool(hidden_cve))
    groups_v = _version_groups(N, shown, places)
    pkg_ids = []
    for g, (vs, members) in enumerate(groups_v):
        nid = "item" if g == 0 else f"item{g}"
        pkg_ids.append((nid, members))
        row = mid if len(groups_v) == 1 else members[0][1]
        N.append(_node(nid, cols["item"], row, package or kind_key, ", ".join(vs or versions), item_p, pmeta, me=True))
        for i, _ in members:
            E.append(_edge(f"p{i}", nid, "contains", item_p, {"source": ", ".join(pf.get("sources") or []) if pf else None, "as_of": pf.get("as_of") if pf else None}))
    _spread_rows([n for n in N if n["id"] in {x for x, _ in pkg_ids}])
    for k, cve in enumerate(shown_cve):
        f = ((cfacts or {}).get("cves") or {}).get(cve)
        N.append(_node(f"c{k}", cols["cve"], k, cve, f"on {sum(cve in v['cves'] for v in places.values())} place{'' if sum(cve in v['cves'] for v in places.values()) == 1 else 's'}",
                       cfacts.p("cves")[1] if cfacts else item_p, _cve_meta(cve, (cfacts or {}).get("cves")), cls="cve"))
        # A CVE hangs off each package node whose drawn places carry it; one no drawn place carries hangs off the first.
        owners_of = [nid for nid, members in pkg_ids if any(cve in places[shown[i]]["cves"] for i, _ in members)] or [pkg_ids[0][0]]
        for nid in owners_of:
            E.append(_edge(nid, f"c{k}", "has", item_p, {"source": CVE_FEEDS, "as_of": (f or {}).get("as_of")}))
    if hidden_cve:
        cve_seen = next((c.get("as_of") for c in ((cfacts or {}).get("cves") or {}).values() if c.get("as_of")), None)
        N.append(_more("c-more", cols["cve"], len(shown_cve), hidden_cve, "more CVEs", item_p, L.nvd_url, CVE_FEEDS, cve_seen))
    out = {"nodes": N, "edges": E, "blast": []}
    nd = dep.get("not_deployed") or []
    # ⛔ NO PLATFORM WORD. This said "not running on GKE" on every estate, including one with no
    # Kubernetes at all (SKPI-2: an AWS-only estate of Lambdas and one Fargate task). The sentence
    # needs none — and the count itself was wrong for a second reason, now fixed in
    # `path.deployment` v2: every running zip Lambda was in `nd`.
    notes = [f"{len(nd)} of {len(places)} places are not running as of the last sync."] if nd else []
    diff = _ranking_differs(ctx, package, [pl for pl in shown if is_image(pl)], set(nd), services, shown_cve)
    out["note"] = " ".join(notes + ([diff] if diff else [])) or None
    if out["note"] is None:
        del out["note"]
    return out


def _deployment_nodes(N, E, plan, groups, shown, shown_svc, dep_rows, linked, hidden, hid_pl, services, exposed, dep, exp,
                      layer, svf) -> None:
    """The deployment column: one node per deployment (collapsed by default), its "+K more services" node, the Internet
    node when any deployment is exposed, and the edges: Internet —reaches→ deployment (the children's `exposed_via` edges),
    deployment —hosts→ service (the service asset rows the rule read), and the FOLDED deployment —runs→ place edges."""
    sid = {s: f"s{j}" for j, s in enumerate(shown_svc)}
    pid = {pl: f"p{i}" for i, pl in enumerate(shown)}
    dp = layer.p("deployments")[1]
    for k, d in enumerate(plan):
        g = groups[d["cluster"]]
        mine = g["services"]
        did = f"d{k}"
        children = [sid[s] for s in d["chosen"]]
        hprov = {"source": cluster_source(g.get("integration"), mine[0], svf), "as_of": g.get("as_of")}
        if d["hidden"]:
            more = _more(f"{did}-more", COLS_DEPLOY["svc"], dep_rows[k] + len(d["chosen"]), d["hidden"], "more services",
                         dep.p("services")[1], None, cluster_source(services[d["hidden"][0]].get("source"), d["hidden"][0], svf),
                         services[d["hidden"][0]].get("as_of"))
            more["meta"]["items"] = [{"label": _service_name(h), "url": None} for h in d["hidden"][:HIDDEN_MAX]]
            more["parent"] = did
            N.append(more)
            children.append(more["id"])
        for s in d["chosen"]:
            N[next(i for i, n in enumerate(N) if n["id"] == sid[s])]["parent"] = did
            E.append(_edge(did, sid[s], "hosts", dp, hprov))
        if d["hidden"]:
            E.append(_edge(did, f"{did}-more", "hosts", dp, hprov))
        first_prov = _svc_prov(services[d["chosen"][0]], d["chosen"][0], svf) if d["chosen"] else {}
        runs = [pl for pl in shown if any(pl in linked[s] for s in d["chosen"])]
        for pl in runs:
            _r = place_kind(pl) in ("image", "function")
            E.append({**_edge(did, pid[pl], "runs" if _r else "built from", dep.p("services")[1], first_prov,
                              "reported" if _r else "derived"), "folded": did})
        if hid_pl and any(h in linked[s] for s in d["chosen"] for h in hidden):
            E.append({**_edge(did, "p-more", "runs", dep.p("services")[1], first_prov), "folded": did})
        cls = {"cls": "inet"} if d["exposed"] else {}
        N.append(_node(did, COLS_DEPLOY["dep"], dep_rows[k], g.get("environment") or "unknown environment",
                       deployment_t2(d["cluster"], d["exposed"], len(mine)), dp,
                       _deployment_meta(g, mine, exposed, hprov), kind="deployment", collapsed=True, children=children,
                       cluster=d["cluster"], **cls))
        if d["exposed"]:
            e = next(exposed[s] for s in mine if s in exposed)
            ek = next(s for s in mine if s in exposed)
            E.append(_edge("inet", did, "reaches", exp.p("exposed")[1], _svc_prov(e, ek, svf)))
    if any(d["exposed"] for d in plan):
        ex_rows = [dep_rows[k] for k, d in enumerate(plan) if d["exposed"]]
        exp_svcs = [s for d in plan if d["exposed"] for s in groups[d["cluster"]]["services"]]
        N.append(_node("inet", COLS_DEPLOY["inet"], (min(ex_rows) + max(ex_rows)) // 2, "Internet", "internet-facing",
                       exp.p("exposed")[1], _internet(exp, svf, [s for s in shown_svc if s in exposed] or exp_svcs), cls="inet"))


def _ranking_differs(ctx, package, images: list, not_running: set, services: dict, cves: list) -> str | None:
    """One neutral line when the live edges and the ranking disagree about whether a drawn image runs, with both times."""
    if not package or not images:
        return None
    states = ctx.call("path.ranking_running", package=package, places=sorted(images), cves=sorted(cves))["states"]
    stale_run = [i for i in images if i in states and states[i]["running"] and i in not_running]
    stale_not = [i for i in images if i in states and not states[i]["running"] and i not in not_running]
    seen = [s.get("as_of") for s in services.values() if s.get("as_of")]
    cluster_t = seen[0] if seen else pt(ctx.now)
    parts = []
    for group, was, now in ((stale_run, "running", "no longer runs"), (stale_not, "not running", "now runs")):
        if group:
            n = len(group)
            t = max(states[i]["as_of"] or "" for i in group) or None
            parts.append(f"The ranking last scored {n} of these places as {was}{' (as of ' + t + ')' if t else ''}; "
                         f"the cluster {now} {'it' if n == 1 else 'them'} (as of {cluster_t}).")
    return " ".join(parts) or None


NO_PLATFORM_PATH = "No platform path for this kind of item yet."


def no_path(note: str = NO_PLATFORM_PATH) -> dict:
    return {**EMPTY, "note": note}


def code_path(ctx, repo: str | None, file: str | None, rule_id: str | None, vuln_ids: list | None = None) -> dict:
    """Code finding: internet → services → deployed images → the repository → the finding's file. The repository, file and rule
    are the anchor; images and services come from the entity graph, the file's facts from the scanner's own rows."""
    if not repo:
        return no_path("The finding names no repository.")
    dep = ctx.call("path.deployment", places=[repo])
    ri = (dep.get("repo_images") or {}).get(repo) or {"images": [], "deployed": []}
    services = dep.get("services") or {}
    imgs = sorted(ri["images"], key=lambda i: (i not in ri["deployed"], i))
    shown_img, hidden_img = imgs[:TOP], imgs[TOP:]
    img_svc0 = dep.get("image_services") or {}
    svc_rank = sorted(services, key=lambda s: (-sum(any(x["service"] == s for x in img_svc0.get(i, [])) for i in shown_img), s))
    shown_svc, hidden_svc = svc_rank[:TOP], svc_rank[TOP:]
    exp = ctx.call("path.exposure", services=sorted(services))
    exposed = exp.get("exposed") or {}
    sfacts = ctx.call("path.service_facts", services=sorted(shown_svc))
    own = ctx.call("path.owners", entities=sorted({*shown_svc, repo}))
    ifacts = ctx.call("path.image_facts", images=sorted(shown_img)) if shown_img else None
    rfacts = ctx.call("path.repo_facts", repos=[repo])
    cf = ctx.call("path.code_facts", repo=repo, path=file or "", scanner_rule=rule_id, vuln_ids=vuln_ids or []) if file else None
    lab = labels([*shown_img, *shown_svc, repo])
    N, E = [], []
    svc_links: dict = {}
    img_svc = dep.get("image_services") or {}
    for i, img in enumerate(shown_img):
        live = img in ri["deployed"]
        N.append(_node(f"i{i}", COLS_CODE["img"], i, lab[img], "image · deployed" if live else "image · not deployed", dep.p("repo_images")[1],
                       _image_meta(img, (ifacts or {}).get("images"))))
        E.append(_edge(f"i{i}", "repo", "built by", dep.p("repo_images")[1], (dep.get("build_edges") or {}).get(repo)))
    hid_i = _more("i-more", COLS_CODE["img"], len(shown_img), hidden_img,
                  (f"more images · {sum(1 for h in hidden_img if h in ri['deployed'])} deployed" if any(h in ri["deployed"] for h in hidden_img)
                   else "more images · none deployed"), dep.p("repo_images")[1], L.gar_image_url,
                  ((dep.get("build_edges") or {}).get(repo) or {}).get("source"), ((dep.get("build_edges") or {}).get(repo) or {}).get("as_of"))
    for j, sk in enumerate(shown_svc):
        e = exposed.get(sk)
        N.append(_node(f"s{j}", COLS_CODE["svc"], j, lab[sk], "internet-facing" if e else "running", dep.p("services")[1],
                       _service_meta(sk, (sfacts or {}).get("services"), (own or {}).get("owners"), sk.split("/")[-1]),
                       **({"cls": "inet"} if e else {})))
        linked = [i for i, img in enumerate(shown_img) if any(s["service"] == sk for s in img_svc.get(img, []))]
        svc_links.setdefault(sk, [])
        for i in linked:
            svc_links.setdefault(sk, []).append((f"i{i}", None))
            E.append(_edge(f"s{j}", f"i{i}", "runs", dep.p("image_services")[1], _svc_prov(services[sk], sk, (sfacts or {}).get("services"))))
        if not linked and hid_i and any(any(x["service"] == sk for x in img_svc.get(h, [])) for h in hidden_img):
            E.append(_edge(f"s{j}", "i-more", "runs", dep.p("image_services")[1], _svc_prov(services[sk], sk, (sfacts or {}).get("services"))))
        elif not linked:
            E.append(_edge(f"s{j}", "repo", "runs", dep.p("services")[1], _svc_prov(services[sk], sk, (sfacts or {}).get("services")), "derived"))
        if e:
            E.append(_edge("inet", f"s{j}", "reaches", exp.p("exposed")[1], _svc_prov(e, sk, (sfacts or {}).get("services"))))
    if hidden_svc:
        N.append(_more("s-more", COLS_CODE["svc"], len(shown_svc), hidden_svc, "more services", dep.p("services")[1], None,
                       cluster_source(services[hidden_svc[0]].get("source"), hidden_svc[0]), services[hidden_svc[0]].get("as_of")))
    if any(s in exposed for s in shown_svc):
        rows = max(min(len(svc_rank), TOP), 1)
        N.append(_node("inet", COLS_CODE["inet"], (rows - 1) // 2, "Internet", "internet-facing", exp.p("exposed")[1],
                       _internet(exp, (sfacts or {}).get("services"), shown_svc), cls="inet"))
    if hid_i:
        N.append(hid_i)
    N.append(_node("repo", COLS_CODE["repo"], 0, lab[repo], "repository", rfacts.p("repos")[1], _repo_meta(repo, (rfacts or {}).get("repos"))))
    if cf is not None:
        found = cf.get("found")
        first = (cf.get("lines") or [None])[0]
        status = "still reported" if str(cf.get("status") or "").lower() == "open" else (cf.get("status") or None)
        rows = [["File", file], ["Line", ", ".join(str(x) for x in cf.get("lines") or [])], ["Rule", cf.get("rule")],
                ["Confidence", cf.get("confidence")], ["Impact", cf.get("impact")], ["Likelihood", cf.get("likelihood")],
                ["CWE", cf.get("cwe")], ["Commit", (cf.get("commit") or "")[:10] or None], ["First seen", cf.get("first_seen")],
                ["Last reported", cf.get("last_reported")], ["Status", status]]
        meta = _meta(rows, [("Open file in GitHub", L.github_file_url(repo, cf.get("commit"), file, first, cf.get("end_line"),
                                                                       ((rfacts or {}).get("repos") or {}).get(repo, {}).get("default_branch"))),
                            ("Scanner rule", L.rule_url(cf.get("rule_uri")))], cf.get("source"), cf.get("as_of")) if found else None
        # The file is a node of its own (panel: line, rule, confidence, CWE, commit, first seen, still reported, and the link to
        # the file at that commit and line). The finding is the item at the end: this item, so not clickable.
        N.append(_node("file", COLS_CODE["file"], 0, str(file or "—").split("/")[-1], "file", cf.p("rows")[1], meta))
        N.append(_node("item", COLS_CODE["item"], 0, str(cf.get("rule") or "finding").split(".")[-1], f"line {first}" if first else "finding",
                       cf.p("rows")[1], None, me=True))
        E.append(_edge("repo", "file", "contains", cf.p("rows")[1], {"source": cf.get("source"), "as_of": cf.get("as_of")}))
        E.append(_edge("file", "item", "flagged at", cf.p("rows")[1], {"source": cf.get("source"), "as_of": cf.get("as_of")}))
    elif file:
        N.append(_node("file", COLS_CODE["file"], 0, str(file).split("/")[-1], "file", rfacts.p("repos")[1], None))
        N.append(_node("item", COLS_CODE["item"], 0, "finding", "not in the datalake", rfacts.p("repos")[1], None, me=True))
        E.append(_edge("repo", "file", "contains", rfacts.p("repos")[1]))
        E.append(_edge("file", "item", "flagged at", rfacts.p("repos")[1]))
    _follow_services(N, shown_svc, svc_links)
    return {"nodes": N, "edges": E, "blast": []}
