"""The exposure path an Inbox item shows, drawn from PLATFORM rows (modules/path.py): internet → services → places → the item.

Members are an ANCHOR (an entry's open linked members, a finding's own key, a code finding's repository and file); every
node and edge is a fact read about them from the entity graph, assets, artifacts, repositories, vulnerabilities and the CVE
table. A node carries `meta` (its own metadata and links, never its relationships) and the source and as-of time of what it
says; an edge carries its source and time. The page shows exactly this; nothing is added from the ranking.
"""
from __future__ import annotations

from .. import links as L
from ..modules.path import is_image
from ..source_names import CVE_FEEDS
from ..times import pt
from .fanout import TOP, _follow_services, labels

EMPTY = {"nodes": [], "edges": [], "blast": []}
NO_MEMBERS = "No member findings are listed for this entry."
UNKNOWN = "unknown"
HIDDEN_MAX = 100                       # names listed behind a "+K more" node
COLS_ENTRY = {"inet": 0, "svc": 1, "place": 2, "item": 3, "cve": 4}
COLS_CODE = {"inet": 0, "svc": 1, "img": 2, "repo": 3, "file": 4, "item": 5}


def _val(v) -> str:
    return UNKNOWN if v in (None, "", [], {}) else str(v)


def _yn(v):
    return None if v is None else ("yes" if v in (True, "true", "True") else "no")


def _meta(rows, links=None, source=None, as_of=None, items=None):
    """A node's panel: [label, value] rows (unknown shown as "unknown"), link-outs, its source and time. None when it would
    say nothing: no known value, no link, no list. Such a node is not clickable."""
    rows = [[k, _val(v)] for k, v in rows]
    links = [{"label": a, "url": u} for a, u in (links or []) if u]
    known = any(v != UNKNOWN for _, v in rows)
    if not (known or links or items):
        return None
    m = {"rows": rows, "links": links, "source": source, "as_of": as_of}
    if items:
        m["items"] = items
    return m


def _node(nid, col, row, t1, t2, p, meta=None, **flags) -> dict:
    n = {"id": nid, "col": col, "row": row, "t1": t1, "t2": t2, "p": p, **flags}
    if meta:
        n["meta"] = meta
    return n


def _edge(a, b, label, p, prov=None, style="reported") -> dict:
    prov = prov or {}
    return {"from": a, "to": b, "label": label, "style": style, "p": p, "source": prov.get("source"), "as_of": prov.get("as_of")}


def _short(key: str) -> str:
    """The name a node of that key carries: an image as `name@digest8`, a repository without its host, a service as given."""
    k = str(key)
    if k.startswith(("image:", "image@")):
        return _image_name(k)[2] if "@sha256:" in k and not k.startswith("image@") else "image@" + k.split("sha256:")[-1][:8]
    return k[len("repo:github.com/"):] if k.startswith("repo:github.com/") else k.split(":", 1)[-1]


def _more(nid, col, row, hidden: list, noun: str, p, link_of=None, source=None, as_of=None):
    """"+K more": the hidden names (the short names the drawn nodes use, never a digest), each linked where a provider page
    exists, with where and when they were read."""
    if not hidden:
        return None
    items = [{"label": _short(h), "url": (link_of(h) if link_of else None)} for h in hidden[:HIDDEN_MAX]]
    return _node(nid, col, row, f"+{len(hidden)} more", noun, p, _meta([], None, source, as_of, items))


def _image_name(key: str) -> tuple[str, str, str]:
    """(registry path, short digest, short label) of `image:<path>@sha256:<digest>`."""
    body = key[len("image:"):] if key.startswith("image:") else key
    path, _, digest = body.partition("@sha256:")            # a digest-only key (`image@sha256:<digest>`) has path "image"
    path = "" if path == "image" else path
    return path, digest[:12], f"{path.split('/')[-1]}@{digest[:8]}" if digest else path.split("/")[-1]


def _cluster(name) -> str | None:
    parts = str(name or "").split("/")
    return f"{parts[2]} · {parts[1]} · {parts[0]}" if len(parts) == 3 and all(parts) else name


def _sev(score) -> str | None:
    try:
        x = float(score)
    except (TypeError, ValueError):
        return None
    word = "Critical" if x >= 9 else "High" if x >= 7 else "Medium" if x >= 4 else "Low"
    return f"{x:.1f} ({word})"


def _service_meta(key, facts, owners, link_name):
    f = (facts or {}).get(key) or {}
    own = ", ".join((owners or {}).get(key, {}).get("owners") or []) or f.get("owner")
    url = L.gke_workload_url(f.get("cluster"), f.get("namespace"), link_name, f.get("workload_kind")) or L.gke_cluster_url(f.get("cluster"))
    return _meta([["Cluster", _cluster(f.get("cluster"))], ["Namespace", f.get("namespace")], ["Environment", f.get("environment")],
                  ["Criticality", f.get("criticality")], ["Customer data", _yn(f.get("customer_data"))], ["Owner", own],
                  ["Running since", f.get("running_since")]],
                 [("Open in GKE", url)], f.get("source"), f.get("as_of"))


def _image_meta(key, facts):
    f = (facts or {}).get(key) or {}
    path, digest, _ = _image_name(key)
    return _meta([["Registry path", path], ["Digest", digest], ["Pushed", f.get("pushed")]], [("Open in Artifact Registry", L.gar_image_url(key))],
                 f.get("source"), f.get("as_of"))


def _repo_meta(key, facts):
    f = (facts or {}).get(key) or {}
    owner = f.get("owner") and (f"{f['owner']} ({f['owner_type']})" if f.get("owner_type") else f["owner"])
    return _meta([["Owner", owner], ["Criticality", None], ["Last push", f.get("last_push")]], [("Open in GitHub", L.github_repo_url(key))],
                 f.get("source"), f.get("as_of"))


def _cve_meta(cve, facts):
    f = (facts or {}).get(cve) or {}
    desc = str(f.get("description") or "").strip().split("\n")[0]
    desc = desc if len(desc) <= 160 else desc[:157].rstrip() + "…"
    epss = f"{float(f['epss']) * 100:.2f}% · {int(float(f.get('epss_percentile') or 0) * 100)}th percentile" if f.get("epss") is not None else None
    kev = None if f.get("kev") is None else (f"listed{' since ' + f['kev_added'] if f.get('kev_added') else ''}" if f.get("kev") else "not listed")
    return _meta([["Summary", desc], ["CVSS", _sev(f.get("cvss"))], ["EPSS", epss], ["CISA KEV", kev], ["CWE", f.get("cwe")],
                  ["Published", f.get("published")]], [("NVD", L.nvd_url(cve)), ("CISA KEV", L.kev_url(cve) if f.get("kev") else None)],
                 f.get("source") or CVE_FEEDS, f.get("as_of"))


def _package_meta(package, versions, pf, partial=False):
    pf = pf or {}
    fixed = None if not pf.get("found") else (", ".join(pf.get("fixed_versions") or []) or "no fix recorded")
    return _meta([["Package", package], ["Installed", ", ".join(versions or [])], [("Fixed in (CVEs shown)" if partial else "Fixed in"), fixed],
                  ["Dependency", ", ".join(pf.get("dependency") or []) or None], ["Manifest", ", ".join(pf.get("manifests") or []) or None],
                  ["First seen", pf.get("first_seen")], ["Reported by", ", ".join(pf.get("sources") or []) or None]],
                 None, ", ".join(pf.get("sources") or []) or None, pf.get("as_of"))


def _internet(exposure: dict, services_facts: dict, shown_services: list):
    ex = (exposure or {}).get("exposed") or {}
    hosts = sorted({e.get("endpoint") for s, e in ex.items() if e.get("endpoint")})
    first = next((e for s in shown_services for e in [ex.get(s)] if e), None) or next(iter(ex.values()), {})
    ingress = next((((services_facts or {}).get(s) or {}).get("ingress") for s in shown_services if ((services_facts or {}).get(s) or {}).get("ingress")), None)
    return _meta([["Public address", ", ".join(hosts[:3]) + (f" and {len(hosts) - 3} more" if len(hosts) > 3 else "") if hosts else None],
                  ["Ingress", ingress]], None, first.get("source"), first.get("as_of"))


def entry_path(ctx, anchor, kind_key: str) -> dict:
    """The path for an entry (one package) or a finding (one member). `anchor` is the RuleResult of path.entry_members /
    path.finding_member."""
    places = anchor.get("places") or {}
    if not anchor.get("available") or not places:
        return {**EMPTY, "note": NO_MEMBERS}
    package, versions = anchor.get("package"), anchor.get("versions") or []
    ranked = sorted(places, key=lambda pl: (-len(places[pl]["cves"]), pl))
    shown, hidden = ranked[:TOP], ranked[TOP:]
    dep = ctx.call("path.deployment", places=sorted(places))
    services = dep.get("services") or {}
    # Services that run a DRAWN place come first, so a drawn service always has an edge; one that runs only hidden places
    # links to the "+K more" places node.
    svc_rank = sorted(services, key=lambda s: (-len(set(services[s]["places"]) & set(shown)), -len(services[s]["places"]), s))
    shown_svc, hidden_svc = svc_rank[:TOP], svc_rank[TOP:]
    exp = ctx.call("path.exposure", services=sorted(services))
    exposed = exp.get("exposed") or {}
    shown_repos = [pl for pl in shown if pl.startswith("repo:")]
    own = ctx.call("path.owners", entities=sorted({*shown_svc, *shown_repos}))
    sfacts = ctx.call("path.service_facts", services=sorted(shown_svc))
    images = [pl for pl in shown if is_image(pl)]
    ifacts = ctx.call("path.image_facts", images=sorted(images)) if images else None
    rfacts = ctx.call("path.repo_facts", repos=sorted(shown_repos)) if shown_repos else None
    top = ranked[0]
    cve_rank = sorted(anchor.get("cves") or [], key=lambda c: (-sum(c in v["cves"] for v in places.values()), c))
    shown_cve, hidden_cve = cve_rank[:TOP], cve_rank[TOP:]
    # The package read covers the CVEs drawn, at the largest place: one row each, so the record stays small however many
    # members the entry has (840 members once cost 0.5 MB here).
    pf = ctx.call("path.package_facts", package=package, versions=versions, images=[top] if is_image(top) else [],
                  repos=[top] if top.startswith("repo:") else [], cves=sorted(shown_cve), ecosystem=anchor.get("ecosystem")) if package else None
    cfacts = ctx.call("path.cve_facts", cves=sorted(shown_cve)) if shown_cve else None

    lab = labels([*shown, *shown_svc])
    N, E = [], []
    svc_links: dict = {}
    for i, pl in enumerate(shown):
        isimg = is_image(pl)
        t1 = lab[pl]
        n_find = len(places[pl]["cves"])
        notrun = pl in (dep.get("not_deployed") or [])
        t2 = f"{'image' if isimg else 'repository'} · {n_find} finding{'' if n_find == 1 else 's'}" + (" · not running" if notrun else "")
        meta = _image_meta(pl, (ifacts or {}).get("images")) if isimg else _repo_meta(pl, (rfacts or {}).get("repos"))
        N.append(_node(f"p{i}", COLS_ENTRY["place"], i, t1, t2, dep.p("services")[1], meta))
    hid_pl = _more("p-more", COLS_ENTRY["place"], len(shown), hidden, f"more places · {sum(len(places[h]['cves']) for h in hidden)} findings",
                   dep.p("services")[1], lambda h: L.gar_image_url(h) if is_image(h) else L.github_repo_url(h),
                   ", ".join((pf or {}).get("sources") or []) or next((s.get("source") for s in services.values() if s.get("source")), None),
                   (pf or {}).get("as_of") or next((s.get("as_of") for s in services.values() if s.get("as_of")), None))
    for j, sk in enumerate(shown_svc):
        e = exposed.get(sk)
        N.append(_node(f"s{j}", COLS_ENTRY["svc"], j, lab[sk], "internet-facing" if e else "running", dep.p("services")[1],
                       _service_meta(sk, (sfacts or {}).get("services"), (own or {}).get("owners"), sk.split("/")[-1]),
                       **({"cls": "inet"} if e else {})))
        svc_links.setdefault(sk, [])
        for i, pl in enumerate(shown):
            if pl in services[sk]["places"]:
                svc_links[sk].append((f"p{i}", None))
                E.append(_edge(f"s{j}", f"p{i}", "runs" if is_image(pl) else "built from", dep.p("services")[1], services[sk],
                               "reported" if is_image(pl) else "derived"))
        if hid_pl and any(h in services[sk]["places"] for h in hidden):
            E.append(_edge(f"s{j}", "p-more", "runs", dep.p("services")[1], services[sk]))
        if e:
            E.append(_edge("inet", f"s{j}", "reaches", exp.p("exposed")[1], e))
    if hidden_svc:
        N.append(_more("s-more", COLS_ENTRY["svc"], len(shown_svc), hidden_svc, "more services", dep.p("services")[1], None,
                       services[hidden_svc[0]].get("source"), services[hidden_svc[0]].get("as_of")))
        N[-1]["meta"]["items"] = [{"label": h.split(":", 1)[-1], "url": None} for h in hidden_svc[:HIDDEN_MAX]]
    if any(s in exposed for s in shown_svc):
        rows = max(min(len(svc_rank), TOP), 1)
        N.append(_node("inet", COLS_ENTRY["inet"], (rows - 1) // 2, "Internet", "internet-facing", exp.p("exposed")[1],
                       _internet(exp, (sfacts or {}).get("services"), shown_svc), cls="inet"))
    if hid_pl:
        N.append(hid_pl)
    _follow_services(N, shown_svc, svc_links)
    mid = max(((max((n["row"] for n in N), default=0)) // 2), 0)
    item_p = pf.p("rows")[1] if pf else dep.p("services")[1]
    N.append(_node("item", COLS_ENTRY["item"], mid, package or kind_key, ", ".join(versions), item_p, _package_meta(package, versions, pf, bool(hidden_cve)), me=True))
    for i, pl in enumerate(shown):
        E.append(_edge(f"p{i}", "item", "contains", item_p, {"source": ", ".join(pf.get("sources") or []) if pf else None, "as_of": pf.get("as_of") if pf else None}))
    for k, cve in enumerate(shown_cve):
        f = ((cfacts or {}).get("cves") or {}).get(cve)
        N.append(_node(f"c{k}", COLS_ENTRY["cve"], k, cve, f"on {sum(cve in v['cves'] for v in places.values())} place{'' if sum(cve in v['cves'] for v in places.values()) == 1 else 's'}",
                       cfacts.p("cves")[1] if cfacts else item_p, _cve_meta(cve, (cfacts or {}).get("cves")), cls="cve"))
        E.append(_edge("item", f"c{k}", "has", item_p, {"source": CVE_FEEDS, "as_of": (f or {}).get("as_of")}))
    if hidden_cve:
        cve_seen = next((c.get("as_of") for c in ((cfacts or {}).get("cves") or {}).values() if c.get("as_of")), None)
        N.append(_more("c-more", COLS_ENTRY["cve"], len(shown_cve), hidden_cve, "more CVEs", item_p, L.nvd_url, CVE_FEEDS, cve_seen))
    out = {"nodes": N, "edges": E, "blast": []}
    nd = dep.get("not_deployed") or []
    notes = [f"{len(nd)} of {len(places)} places are not running on GKE as of the last sync."] if nd else []
    diff = _ranking_differs(ctx, package, [pl for pl in shown if is_image(pl)], set(nd), services, shown_cve)
    out["note"] = " ".join(notes + ([diff] if diff else [])) or None
    if out["note"] is None:
        del out["note"]
    return out


def _ranking_differs(ctx, package, images: list, not_running: set, services: dict, cves: list) -> str | None:
    """One neutral line when the live edges and the ranking disagree about whether a drawn image runs, with both times."""
    if not package or not images:
        return None
    states = ctx.call("path.ranking_running", package=package, places=sorted(images), cves=sorted(cves))["states"]
    stale_run = [i for i in images if i in states and states[i]["running"] and i in not_running]
    stale_not = [i for i in images if i in states and not states[i]["running"] and i not in not_running]
    seen = [s.get("as_of") for s in services.values() if s.get("as_of")]
    cluster_t = seen[0] if seen else pt(ctx.now)
    parts = []
    for group, was, now in ((stale_run, "running", "no longer runs"), (stale_not, "not running", "now runs")):
        if group:
            n = len(group)
            t = max(states[i]["as_of"] or "" for i in group) or None
            parts.append(f"The ranking last scored {n} of these places as {was}{' (as of ' + t + ')' if t else ''}; "
                         f"the cluster {now} {'it' if n == 1 else 'them'} (as of {cluster_t}).")
    return " ".join(parts) or None


NO_PLATFORM_PATH = "No platform path for this kind of item yet."


def no_path(note: str = NO_PLATFORM_PATH) -> dict:
    return {**EMPTY, "note": note}


def code_path(ctx, repo: str | None, file: str | None, rule_id: str | None, vuln_ids: list | None = None) -> dict:
    """Code finding: internet → services → deployed images → the repository → the finding's file. The repository, file and rule
    are the anchor; images and services come from the entity graph, the file's facts from the scanner's own rows."""
    if not repo:
        return no_path("The finding names no repository.")
    dep = ctx.call("path.deployment", places=[repo])
    ri = (dep.get("repo_images") or {}).get(repo) or {"images": [], "deployed": []}
    services = dep.get("services") or {}
    imgs = sorted(ri["images"], key=lambda i: (i not in ri["deployed"], i))
    shown_img, hidden_img = imgs[:TOP], imgs[TOP:]
    img_svc0 = dep.get("image_services") or {}
    svc_rank = sorted(services, key=lambda s: (-sum(any(x["service"] == s for x in img_svc0.get(i, [])) for i in shown_img), s))
    shown_svc, hidden_svc = svc_rank[:TOP], svc_rank[TOP:]
    exp = ctx.call("path.exposure", services=sorted(services))
    exposed = exp.get("exposed") or {}
    sfacts = ctx.call("path.service_facts", services=sorted(shown_svc))
    own = ctx.call("path.owners", entities=sorted({*shown_svc, repo}))
    ifacts = ctx.call("path.image_facts", images=sorted(shown_img)) if shown_img else None
    rfacts = ctx.call("path.repo_facts", repos=[repo])
    cf = ctx.call("path.code_facts", repo=repo, path=file or "", scanner_rule=rule_id, vuln_ids=vuln_ids or []) if file else None
    lab = labels([*shown_img, *shown_svc, repo])
    N, E = [], []
    svc_links: dict = {}
    img_svc = dep.get("image_services") or {}
    for i, img in enumerate(shown_img):
        live = img in ri["deployed"]
        N.append(_node(f"i{i}", COLS_CODE["img"], i, lab[img], "image · deployed" if live else "image · not deployed", dep.p("repo_images")[1],
                       _image_meta(img, (ifacts or {}).get("images"))))
        E.append(_edge(f"i{i}", "repo", "built by", dep.p("repo_images")[1], (dep.get("build_edges") or {}).get(repo)))
    hid_i = _more("i-more", COLS_CODE["img"], len(shown_img), hidden_img,
                  (f"more images · {sum(1 for h in hidden_img if h in ri['deployed'])} deployed" if any(h in ri["deployed"] for h in hidden_img)
                   else "more images · none deployed"), dep.p("repo_images")[1], L.gar_image_url,
                  ((dep.get("build_edges") or {}).get(repo) or {}).get("source"), ((dep.get("build_edges") or {}).get(repo) or {}).get("as_of"))
    for j, sk in enumerate(shown_svc):
        e = exposed.get(sk)
        N.append(_node(f"s{j}", COLS_CODE["svc"], j, lab[sk], "internet-facing" if e else "running", dep.p("services")[1],
                       _service_meta(sk, (sfacts or {}).get("services"), (own or {}).get("owners"), sk.split("/")[-1]),
                       **({"cls": "inet"} if e else {})))
        linked = [i for i, img in enumerate(shown_img) if any(s["service"] == sk for s in img_svc.get(img, []))]
        svc_links.setdefault(sk, [])
        for i in linked:
            svc_links.setdefault(sk, []).append((f"i{i}", None))
            E.append(_edge(f"s{j}", f"i{i}", "runs", dep.p("image_services")[1], services[sk]))
        if not linked and hid_i and any(any(x["service"] == sk for x in img_svc.get(h, [])) for h in hidden_img):
            E.append(_edge(f"s{j}", "i-more", "runs", dep.p("image_services")[1], services[sk]))
        elif not linked:
            E.append(_edge(f"s{j}", "repo", "runs", dep.p("services")[1], services[sk], "derived"))
        if e:
            E.append(_edge("inet", f"s{j}", "reaches", exp.p("exposed")[1], e))
    if hidden_svc:
        N.append(_more("s-more", COLS_CODE["svc"], len(shown_svc), hidden_svc, "more services", dep.p("services")[1], None,
                       services[hidden_svc[0]].get("source"), services[hidden_svc[0]].get("as_of")))
    if any(s in exposed for s in shown_svc):
        rows = max(min(len(svc_rank), TOP), 1)
        N.append(_node("inet", COLS_CODE["inet"], (rows - 1) // 2, "Internet", "internet-facing", exp.p("exposed")[1],
                       _internet(exp, (sfacts or {}).get("services"), shown_svc), cls="inet"))
    if hid_i:
        N.append(hid_i)
    N.append(_node("repo", COLS_CODE["repo"], 0, lab[repo], "repository", rfacts.p("repos")[1], _repo_meta(repo, (rfacts or {}).get("repos"))))
    if cf is not None:
        found = cf.get("found")
        first = (cf.get("lines") or [None])[0]
        status = "still reported" if str(cf.get("status") or "").lower() == "open" else (cf.get("status") or None)
        rows = [["File", file], ["Line", ", ".join(str(x) for x in cf.get("lines") or [])], ["Rule", cf.get("rule")],
                ["Confidence", cf.get("confidence")], ["Impact", cf.get("impact")], ["Likelihood", cf.get("likelihood")],
                ["CWE", cf.get("cwe")], ["Commit", (cf.get("commit") or "")[:10] or None], ["First seen", cf.get("first_seen")],
                ["Last reported", cf.get("last_reported")], ["Status", status]]
        meta = _meta(rows, [("Open file in GitHub", L.github_file_url(repo, cf.get("commit"), file, first, cf.get("end_line"),
                                                                       ((rfacts or {}).get("repos") or {}).get(repo, {}).get("default_branch"))),
                            ("Scanner rule", L.rule_url(cf.get("rule_uri")))], cf.get("source"), cf.get("as_of")) if found else None
        # The file is a node of its own (panel: line, rule, confidence, CWE, commit, first seen, still reported, and the link to
        # the file at that commit and line). The finding is the item at the end: this item, so not clickable.
        N.append(_node("file", COLS_CODE["file"], 0, str(file or "—").split("/")[-1], "file", cf.p("rows")[1], meta))
        N.append(_node("item", COLS_CODE["item"], 0, str(cf.get("rule") or "finding").split(".")[-1], f"line {first}" if first else "finding",
                       cf.p("rows")[1], None, me=True))
        E.append(_edge("repo", "file", "contains", cf.p("rows")[1], {"source": cf.get("source"), "as_of": cf.get("as_of")}))
        E.append(_edge("file", "item", "flagged at", cf.p("rows")[1], {"source": cf.get("source"), "as_of": cf.get("as_of")}))
    elif file:
        N.append(_node("file", COLS_CODE["file"], 0, str(file).split("/")[-1], "file", rfacts.p("repos")[1], None))
        N.append(_node("item", COLS_CODE["item"], 0, "finding", "not in the datalake", rfacts.p("repos")[1], None, me=True))
        E.append(_edge("repo", "file", "contains", rfacts.p("repos")[1]))
        E.append(_edge("file", "item", "flagged at", rfacts.p("repos")[1]))
    _follow_services(N, shown_svc, svc_links)
    return {"nodes": N, "edges": E, "blast": []}
