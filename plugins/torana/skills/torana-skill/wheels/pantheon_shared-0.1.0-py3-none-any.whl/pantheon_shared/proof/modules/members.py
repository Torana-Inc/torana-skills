"""members — what the entity graph says around ONE row of a group check (APP_PROFILES_SPEC § 3.3.4): the teams that own its
node, the services that run on it, and which CMDB hosts carry the host names the row lists (a privileged account's
servers). Read from `entity_edges` and `assets` only; the row's own evidence is read by the claim builder from the alert.

⚠️ A host NAME the row lists is matched to an inventory host by `asset_name` (case-insensitive, CMDB first). That is a
name match, not an identity the source stated, so the graph draws what follows from it as heuristic.
"""
from __future__ import annotations

import json

from ..core.engine import NotCaptured, rule
from ..source_names import provenance
from ..times import pt

PROV = ["source_system", "contributing_sources"]
EDGE = ["from_key", "to_key", "edge_type", "last_seen", *PROV]
LIVE = ["is_deleted", "=", False]


def _prov(rows) -> dict:
    """Source and as-of of the first row read (sorted), or nothing."""
    if not rows:
        return {"source": None, "as_of": None}
    r = rows[0]
    return provenance("entity_edges", {c: r.get(c) for c in (*PROV, "last_seen")})


def _teams(rows) -> list:
    return sorted({(r.get("to_key") or "").replace("team:", "") for r in rows} - {""})


@rule("members.neighbours", 1)
def neighbours(ctx, node: str | None, names: list) -> dict:
    """`owners` / `services` of `node` (live `owns` edges from it, live `runs_on` edges into it), with where and when
    they were read; `by_name`: each listed host name (lower-case) → the inventory host key whose `asset_name` it is
    (`host:servicenow/…` first, else the first key in order); `name_owners`: that host key → its owning teams."""
    out: dict = {"owners": [], "owners_prov": _prov([]), "services": [], "services_prov": _prov([]),
                 "by_name": {}, "name_owners": {}}
    if node:
        own = sorted(ctx.select("entity_edges", [["edge_type", "=", "owns"], ["from_key", "=", node], LIVE], EDGE),
                     key=lambda r: str(r.get("to_key")))
        run = sorted(ctx.select("entity_edges", [["edge_type", "=", "runs_on"], ["to_key", "=", node], LIVE], EDGE),
                     key=lambda r: str(r.get("from_key")))
        out.update(owners=_teams(own), owners_prov=_prov(own),
                   services=sorted({r.get("from_key") for r in run} - {None}), services_prov=_prov(run))
    wanted = sorted({str(n).strip() for n in names or [] if str(n or "").strip()})
    if wanted:
        variants = sorted({v for n in wanted for v in (n, n.lower(), n.upper())})
        rows = ctx.select("assets", [["asset_name", "in", variants]], ["torana_entity_id", "asset_name", "is_deleted"])
        hosts: dict = {}
        for r in rows:
            k = str(r.get("torana_entity_id") or "")
            if k.startswith("host:") and not r.get("is_deleted"):
                hosts.setdefault(str(r.get("asset_name") or "").lower(), []).append(k)
        for n in wanted:
            ks = sorted(hosts.get(n.lower()) or [], key=lambda k: (not k.startswith("host:servicenow/"), k))
            if ks:
                out["by_name"][n.lower()] = ks[0]
        keys = sorted(set(out["by_name"].values()))
        if keys:
            own = ctx.select("entity_edges", [["edge_type", "=", "owns"], ["from_key", "in", keys], LIVE], EDGE)
            for k in keys:
                out["name_owners"][k] = _teams([r for r in own if r.get("from_key") == k])
    return out


HOST_COLS = ["torana_entity_id", "asset_name", "asset_description", "asset_type", "asset_environment", "compute_operating_system",
             "private_ipv4_addresses", "fqdn", "hostname", "asset_owner", "criticality_name", "custom_attributes_value",
             "is_deleted", *PROV]
TEAM_COLS = ["identity_id", "display_name", "identity_type", "status", "discovery_source", "discovery_method", "provider",
             *PROV]


def _host_record(r) -> dict:
    """One inventory record of a host, as the node's panel shows it. CMDB fields come from the CI row's
    `custom_attributes_value` (ServiceNow `u_*` / `sys_class_name`); an EDR or scanner record adds when it last saw it."""
    ca = r.get("custom_attributes_value") or {}
    if isinstance(ca, str):
        try:
            ca = json.loads(ca)
        except ValueError:
            ca = {}
    ca = ca if isinstance(ca, dict) else {}
    pv = provenance("assets", {c: r.get(c) for c in PROV})
    ips = r.get("private_ipv4_addresses")
    ip = ", ".join(ips) if isinstance(ips, list) else ips
    return {"key": r.key, "system": r.get("source_system"), "source": pv["source"], "as_of": pv["as_of"],
            "description": r.get("asset_description"), "type": r.get("asset_type"), "environment": r.get("asset_environment"),
            "os": r.get("compute_operating_system") or ca.get("os") or ca.get("os_version"),
            "ip": ip or ca.get("u_server_ip_address") or ca.get("address") or ca.get("local_ip"),
            "fqdn": r.get("fqdn"), "owner": r.get("asset_owner"), "tier": r.get("criticality_name"),
            "role": ca.get("u_role"), "application": ca.get("u_application"), "impact": ca.get("u_business_impact"),
            "location": ca.get("u_location"), "ci_class": ca.get("sys_class_name"), "status": ca.get("operational_status"),
            "agent": ca.get("agent_version"), "last_seen": pt(ca.get("last_seen")), "last_scan": pt(ca.get("lastVulnScan"))}


@rule("members.node_facts", 1)
def node_facts(ctx, hosts: list, teams: list) -> dict:
    """What a graph node IS, for its panel. `hosts`: host NAME (lower-case) → every live inventory record whose
    `asset_name` it is (CMDB first, then EDR, scanner, ...: a host is known by each source on its own row). `teams`:
    team key → its identity row and how many live `owns` edges point at it, by the owned node's kind.

    Path guard: a record built before this rule existed never made these reads, so on replay they raise NotCaptured;
    the rule then returns nothing and the claim keeps the panel the row's own columns gave (as that record did)."""
    try:
        return _node_facts(ctx, hosts, teams)
    except NotCaptured:
        return {"hosts": {}, "teams": {}}


def _node_facts(ctx, hosts: list, teams: list) -> dict:
    out: dict = {"hosts": {}, "teams": {}}
    wanted = sorted({str(n).strip().lower() for n in hosts or [] if str(n or "").strip()})
    if wanted:
        variants = sorted({v for n in wanted for v in (n, n.upper())})
        for r in ctx.select("assets", [["asset_name", "in", variants], LIVE], HOST_COLS):
            if str(r.get("torana_entity_id") or "").startswith("host:"):
                out["hosts"].setdefault(str(r.get("asset_name") or "").lower(), []).append(_host_record(r))
        for recs in out["hosts"].values():
            recs.sort(key=lambda x: (x["system"] != "servicenow", str(x["key"])))
    keys = sorted({str(t) for t in teams or [] if t})
    if keys:
        rows = {r.key: r for r in ctx.select("identities", [["identity_id", "in", keys], LIVE], TEAM_COLS)}
        owned = ctx.select("entity_edges", [["edge_type", "=", "owns"], ["to_key", "in", keys], LIVE], ["from_key", "to_key"])
        for k in keys:
            kinds: dict = {}
            for e in owned:
                if e.get("to_key") == k:
                    kind = str(e.get("from_key") or "").split(":", 1)[0] or "other"
                    kinds[kind] = kinds.get(kind, 0) + 1
            r = rows.get(k)
            pv = provenance("identities", {c: r.get(c) for c in PROV}) if r else {"source": None, "as_of": None}
            out["teams"][k] = {"found": r is not None, "name": r.get("display_name") if r else None,
                               "type": r.get("identity_type") if r else None, "status": r.get("status") if r else None,
                               "how": " · ".join(x for x in ((r.get("discovery_source") if r else None),
                                                            (r.get("discovery_method") if r else None)) if x) or None,
                               "owns": dict(sorted(kinds.items())), "source": pv["source"], "as_of": pv["as_of"]}
    return out
