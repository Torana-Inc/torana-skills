"""App Health: one colour per part of the app, rolled up into the 10 rows Home ends with (design note
APP_HEALTH_DESIGN_NOTE.md, S1). Pure: reads only the facts payload, like health.py and home.py.

ONE vocabulary for every surface (D9): the API, the CLI, the Home page and the plugin read what this module builds.

  row  = {key, name, order, status, since, who_fixes, sentence, next_step, support_code, parts[]}
  part = {kind, name, status, since, sentence, link}

D4  the 10 rows, in this order (`ROWS`). App Gaps is not a row: it is the Landing Page's own section.
D5  Detections, Playbooks and Agents are PARTS of the row they serve. A failing detection is red on row 6 (it selects
    nothing), orange on row 7 (its new items do not arrive) and orange on row 8 (its closing check cannot run).
D8  red = failing; orange = degraded, out of date, partial or paused; grey = never run or unreadable; green = confirmed
    working. A row takes its worst part (red > orange > grey > green), so an unknown part can never make a row green. A
    row the app does not use is `not_used`, with no colour.
I1  green only if every part was read and confirmed working (a row with no part is grey, "Not checked yet").
I2  every sentence comes from `CONDITIONS` (or a template over an app artifact's own name). No raw error text, relation
    name, internal status code or service name reaches a row: `find_leaks` is the test's check.
I3  `since` is the start of the current non-green state, from the source's own times; it clears when the row is green.
I4  every warning Home showed before (a health line, a trust line) maps to a row: `LINE_ROW` and `TRUST_ROW`, held to
    today's line kinds by a parity test. A gap line (`GAP_LINE_KINDS`) maps to no row: the App Gaps section says it.

A Torana-side cause (who_fixes == "torana") states the problem and its effect; it makes no promise about a fix (Jay). `log_red_transitions` logs exactly one
`log_failure` for each such row on its transition into red (never on every refresh).
"""
from __future__ import annotations

import hashlib
import re
from typing import Iterable

from . import health as _h
from .home import trust
from .read_gaps import earliest, iso_or_none

GREEN, ORANGE, RED, GREY, NOT_USED = "green", "orange", "red", "grey", "not_used"
STATUSES = (GREEN, ORANGE, RED, GREY, NOT_USED)
#: worst first. not_used has no colour and never wins.
_SEVERITY = {RED: 3, ORANGE: 2, GREY: 1, GREEN: 0}

YOU, TORANA = "you", "torana"

#: D4: the rows, in the customer's own UI words and this fixed order.
ROWS = (
    ("integrations", "Integrations"),
    ("datalake", "DataLake"),
    ("data_pipelines", "DataPipelines"),
    ("entity_graph", "Entity Graph"),
    ("dashboard_widgets", "Dashboard Widgets"),
    ("inbox_filtered", "Inbox Filtered Items"),
    ("inbox_needs_attention", "Inbox Active Items"),
    ("inbox_closed", "Inbox Closed Items"),
    ("home_top_priorities", "Home Top Priorities"),
    ("home_daily_briefing", "Home Daily Briefing"),
)
ROW_KEYS = tuple(k for k, _ in ROWS)
ROW_NAME = dict(ROWS)
ROW_ORDER = {k: i for i, (k, _) in enumerate(ROWS, 1)}

PART_KINDS = ("integration", "sync", "table", "entity_graph", "widget", "detection", "closing_check", "agent", "route",
              "retriage", "playbook", "question", "home_input")

#: Jay: customer-facing status text states the problem and its effect; it never promises a fix. This is THE guard: it matches
#: a sentence or next step whose subject is Torana (or "we") promising action. Tests in every repo that owns customer status
#: text import it (PS app_health, PDF inbox_serve_health, integration sync_state) instead of keeping a copy.
PROMISE_RE = re.compile(
    r"\b(torana|we)\b\s+(is|are|has|have|will|'s|'re|fixes|fix|investigat\w*)|\bbeing (fixed|looked|investigated)\b|"
    r"\buntil torana\b|looking into it|working on it|fixing it", re.I)

NOT_USED_SENTENCE = "Not used by this app."

#: Status labels, in cloud status-page words. not_used has no colour and is never summarised.
STATUS_LABEL = {GREEN: "Operational", ORANGE: "Degraded", RED: "Outage", GREY: "Unknown", NOT_USED: "Not in use"}
SUMMARY_SENTENCE = {GREEN: "All systems operational", ORANGE: "Some systems are degraded", RED: "Some systems have an outage",
                    GREY: "Some systems could not be checked"}
NOT_CHECKED_SENTENCE = "Not checked yet."
NOT_CHECKED_NEXT = "Refresh App Health."

#: condition → (status, who_fixes, sentence, next_step). `{name}` is an app artifact's own UI name (a check, an
#: integration, an agent); nothing else is ever substituted. The customer's words, one place (I2).
CONDITIONS: dict[str, tuple[str, str, str, str]] = {
    "ok": (GREEN, YOU, "Operational.", ""),
    "not_checked": (GREY, TORANA, NOT_CHECKED_SENTENCE, NOT_CHECKED_NEXT),
    "unreadable": (GREY, TORANA, "Could not be read this time, so its status is unknown.",
                   "Nothing to do; this checks again on the next refresh."),
    # row 1 / 2: integrations and the DataLake
    "integration_blocked": (RED, YOU, "{name} cannot be read because of a setting on your side, so what is built from it may "
                                      "be missing or incomplete.",
                            "Update the credentials or permissions on the integration's page."),
    "sync_failing": (RED, YOU, "{name} has not synced successfully, so data built from it is as of its last good sync.",
                     "Fix it on the integration's page."),
    "sync_quiet": (ORANGE, YOU, "{name} has stopped sending data, so data built from it is as of the last data it sent.",
                   "Check the integration's page and the system it reads."),
    "sync_partial": (ORANGE, YOU, "{name} synced, but part of it did not: the data from that part is as of its last good sync.",
                     "Check the integration's page."),
    "sync_partial_torana": (ORANGE, TORANA, "{name} synced, but part of it did not: the data from that part is as of its last good sync.",
                            "Nothing to do; the next sync retries."),
    "sync_unread": (GREY, TORANA, "The status of the data syncs could not be read this time.",
                    "Nothing to do; this checks again on the next refresh."),
    # row 5: dashboard widgets
    "figures_unavailable": (ORANGE, TORANA, "Some figures are not available right now.",
                            "Nothing to do; each affected figure says so where it is shown."),
    "figures_stale": (ORANGE, YOU, "Some figures are out of date because the data behind them has stopped arriving.",
                      "Check the integrations that feed them."),
    "figures_undated": (ORANGE, TORANA, "Some figures have no reliable date, so how fresh they are is not known.",
                        "Nothing to do."),
    "figures_blind": (ORANGE, YOU, "Some figures cannot be answered from the data connected to this app.",
                      "Connect the data they need (see App Gaps)."),
    "figures_wait_on_gaps": (NOT_USED, YOU, "{wait} on App Gaps.", "See App Gaps."),
    "figures_not_yet": (GREY, YOU, "Some figures are set up but have never been recorded.",
                        "Wait for the next run, or run it once from the app."),
    # row 6/7/8: detections and what they feed
    "detection_broken": (RED, YOU, "The {name} check has stopped running: it no longer matches the data it reads.",
                         "Apply the latest update to this app, or have its owner fix the check."),
    "detection_broken_torana": (RED, TORANA, "The {name} check has stopped running.",
                                "Nothing to do."),
    "detection_failed": (RED, YOU, "The {name} check failed on its last run, so it raised nothing then.",
                         "Have the owner of the check look at it."),
    "detection_failed_torana": (RED, TORANA, "The {name} check failed on its last run.",
                                "Nothing to do."),
    "detection_never_ran": (GREY, YOU, "The {name} check has never run, so its silence means nothing.",
                            "Check that it has a schedule, or run it once."),
    "detection_blocked": (ORANGE, YOU, "The {name} check will never raise anything: the data it reads is not supplied.",
                          "Supply the data it needs (see App Gaps)."),
    "detections_unread": (GREY, TORANA, "This app's checks could not be read, so a quiet Inbox does not yet mean nothing was found.",
                          "Nothing to do; this checks again on the next refresh."),
    "no_detections": (GREY, YOU, "Nothing is watching this app: no checks are set up, so no alerts can be raised.",
                      "Set up checks for this app."),
    "feeds_stopped": (ORANGE, YOU, "New items from the {name} check are not arriving.",
                      "Fix the {name} check (see Inbox Filtered Items)."),
    "closing_cannot_run": (ORANGE, YOU, "The {name} check cannot tell when its items have been fixed, so those items stay "
                                        "open; you can close them yourself meanwhile.",
                           "Fix the {name} check (see Inbox Filtered Items)."),
    "closing_cannot_run_torana": (ORANGE, TORANA, "The {name} check cannot tell when its items have been fixed, so those "
                                                  "items stay open.",
                                  "Nothing to do; you can close those items yourself meanwhile."),
    # row 7: agents and routes
    "agent_failing": (RED, TORANA, "{name} is failing, so its work for this app is not getting done.",
                      "Nothing to do."),
    "agent_failing_you": (RED, YOU, "{name} is failing, so its work for this app is not getting done.",
                          "Whoever manages agents on this account needs to check it."),
    "agent_flaky": (ORANGE, TORANA, "{name} fails now and then, so some of its work for this app is skipped.",
                    "Nothing to do."),
    "agent_paused": (ORANGE, TORANA, "{name} is switched off, so its work for this app is not happening. Torana can switch it back on.",
                     "If that is intended there is nothing to do."),
    "agent_other_scope": (GREEN, TORANA, "A background agent that may serve another app had trouble; it is not known to "
                                         "affect this app.", ""),
    "agent_recovered": (GREEN, TORANA, "{name} recovered from an earlier problem.", ""),
    "routing_unread": (GREY, TORANA, "Whether this app's alerts reach anyone could not be read this time.",
                       "Nothing to do; this checks again on the next refresh."),
    "no_triage_agent": (ORANGE, YOU, "No triage agent is attached, so alerts no route claims are not judged: they wait for a "
                                     "person.", "Attach a triage agent to this app."),
    # collectors outside PS (PPF S2): integrations, schedules, derived tables, Entity Graph, closing checks, re-triage, playbooks
    "integration_disconnected": (RED, YOU, "{name} is disconnected, so nothing new is coming in from it.",
                                 "Reconnect it on the integration's page."),
    "integration_failing": (RED, YOU, "{name} is failing: its latest sync did not succeed, so data built from it is as of the "
                                      "last good sync.", "Fix it on the integration's page."),
    "integration_partial": (ORANGE, TORANA, "{name} synced, but part of it did not; the rest is current.",
                            "Nothing to do; the next sync retries."),
    "integration_partial_you": (ORANGE, YOU, "{name} synced, but part of it did not; the rest is current.",
                                "Fix it on the integration's page."),
    "integration_failing_torana": (RED, TORANA, "{name} is failing: its latest sync did not succeed, so data built from it is as "
                                                "of the last good sync.", "Nothing to do."),
    "integration_unknown": (GREY, TORANA, "The status of {name} is not known yet.",
                            "Nothing to do; this checks again on the next refresh."),
    "sync_missed_schedule": (ORANGE, YOU, "{name} did not sync when its schedule says it should, so data built from it is "
                                          "older than expected.", "Check its schedule and the integration's page."),
    "table_failed": (RED, TORANA, "{name} could not be built, so what is shown from it is out of date.",
                     "Nothing to do."),
    "table_quarantined": (RED, TORANA, "{name} is paused after repeated build failures, so what is shown from it is out of "
                                       "date.", "Nothing to do."),
    "table_owed_rebuild": (ORANGE, TORANA, "{name} is out of date and is being rebuilt.",
                           "Nothing to do; it is current again once the rebuild finishes."),
    "table_unbuilt": (GREY, TORANA, "{name}: not built yet, so nothing is shown from it.",
                      "Nothing to do; it appears after its first build."),
    "table_source_missing": (RED, YOU, "{name} depends on a tool or data source that was removed, so it can no longer be built.",
                             "Reconnect the removed integration, or remove what depends on it."),
    "graph_failed": (RED, TORANA, "The Entity Graph could not be updated, so relationships shown may be out of date.", "Nothing to do."),
    "graph_stale": (ORANGE, TORANA, "The Entity Graph is out of date.",
                    "Nothing to do; this checks again on the next refresh."),
    "graph_degraded": (ORANGE, TORANA, "{name} is only partly up to date: some links could not be settled yet.", "Nothing to do; this checks again on the next refresh."),
    "graph_never_ran": (GREY, TORANA, "The Entity Graph has not been built yet.",
                        "Nothing to do; it appears after its first build."),
    "lifecycle_refused": (ORANGE, TORANA, "The closing check for {name} was refused, so its items stay open.", "Nothing to do; you can close those items yourself meanwhile."),
    "lifecycle_stale": (ORANGE, TORANA, "The closing check for {name} has not run recently, so items already fixed may still "
                                        "show as open.",
                        "Nothing to do; you can close those items yourself meanwhile."),
    "retriage_capped": (ORANGE, TORANA, "Re-checking items is paused for now because the hourly limit was reached, so some "
                                        "verdicts may be out of date.",
                        "Nothing to do; re-checking resumes by itself."),
    "playbook_failed": (ORANGE, YOU, "The latest run of the {name} playbook failed, so what it does for this app did not "
                                     "happen.", "Open the playbook and look at its last run."),
    "escalation_failed": (ORANGE, TORANA, "Some escalations for this app did not go out.",
                          "Nothing to do."),
    "question_failing": (ORANGE, TORANA, "The Daily Briefing question {name} keeps failing, so its answer is missing or old.", "Nothing to do."),
    "inbox_serve_failing": (RED, TORANA, "The Inbox list could not be loaded.",
                            "You can close or open items again once it loads."),
    "inbox_serve_quiet": (ORANGE, TORANA, "The Inbox list could not be loaded earlier and has not been checked since.", "Nothing to do; this checks again on the next refresh."),
    "inbox_serve_recovered": (GREEN, TORANA, "The Inbox list could not be loaded earlier and loads again.", ""),
    # a routing rule's delivery (PDF delivery-health, kind routing): who fixes it depends on the cause
    "routing_failed": (RED, TORANA, "Alerts sent by the {name} route could not be delivered.",
                       "Nothing to do on your side."),
    "routing_refused": (ORANGE, YOU, "The destination of the {name} route refused the alerts.",
                        "Check the route's destination: the channel or project still exists and the integration still has "
                        "permission."),
    "routing_failed_unknown": (ORANGE, YOU, "Alerts sent by the {name} route did not all reach their destination.",
                               "Check that the route's destination still exists and accepts them."),
    "routing_recovered": (GREEN, TORANA, "Messages to {name} were not delivered earlier and are being delivered again.", ""),
    # row 9: the Inbox could not be read (A2)
    "inbox_unread": (GREY, TORANA, "The Inbox could not be read this run, so the decisions cannot be counted.",
                     "Nothing to do; this checks again on the next refresh."),
    # row 10: the Daily Briefing (the old red box)
    "briefing_held": (ORANGE, TORANA, "The Daily Briefing could not be refreshed, so what is shown is from an earlier run.",
                      "Nothing to do; this checks again on the next refresh."),
    "briefing_failed": (RED, TORANA, "The Daily Briefing could not be written.",
                        "Nothing to do."),
}

#: I4. Every line kind health.py produces → (condition, row key(s)). A parity test holds this to health._all_lines.
LINE_ROW: dict[str, tuple[str, ...]] = {
    "sync_blocked": ("integrations",),                    # connected, and its sign-in or permission stopped working: Health
    "source_blocked": (), "read_broken": (),   # never given access: the App Gaps section, no health row (D15)
    "sync_failing": ("datalake",),
    "source_unread": ("dashboard_widgets",),
    "rule_broken": ("inbox_filtered", "inbox_needs_attention", "inbox_closed"),
    "rule_failed": ("inbox_filtered", "inbox_needs_attention", "inbox_closed"),
    "rule_cannot_close": ("inbox_closed",),
    "rule_never_ran": ("inbox_filtered",), "rule_blocked": ("inbox_filtered",), "rules_unknown": ("inbox_filtered",),
    "agent_failing": ("inbox_needs_attention",), "agent_flaky": ("inbox_needs_attention",),
    "agent_recovered": ("inbox_needs_attention",), "agent_off": ("inbox_needs_attention",),
    "no_alert_route": (), "no_triage_agent": ("inbox_needs_attention",),   # alerts reach nobody: the App Gaps section
    "routing_unknown": ("inbox_needs_attention",),
    "all_clear": (),
}
#: home.trust() line kinds ("rules" and "dates"/"unavailable" lines).
#: D15: a condition is a Gap (the Landing Page's App Gaps section, via health.NEEDS_KINDS; no health row) or a Health
#: condition (a row), never both.
GAP_LINE_KINDS = frozenset({"source_blocked", "read_broken", "no_alert_route"})
HEALTH_LINE_KINDS = frozenset(k for k, rows in LINE_ROW.items() if rows)
TRUST_ROW = {"rules": ("inbox_filtered",), "dates": ("dashboard_widgets",), "unavailable": ("dashboard_widgets",)}

#: What may never reach a part NAME (a name is an app artifact's UI name; a raw id or identifier is not one).
_NAME_LEAK = re.compile(
    r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"            # an id
    r"|\b[a-z0-9]+_[a-z0-9_]+\b"                                                 # a snake_case identifier
    r"|(?<!\w)'[\w.]+'|\"[^\"]+\""                                               # a quoted identifier
    r"|(?-i:\b[a-z][a-z0-9_]+\.[a-z][a-z0-9_]+\b)"                              # a dot-joined identifier (main.assets)
    r"|\bverdict:|#", re.I)
#: What may never reach a customer SENTENCE (template text, with {name} not yet filled in): the name rules plus raw errors,
#: status codes, relation names, service names, database words.
_LEAK = re.compile(
    _NAME_LEAK.pattern
    + r"|\bowed_\w+|\b(?:HTTP|http)\b|\b[45]\d\d\b"                           # a status code
    + r"|\bpantheon[-_]\w+|\b\w*(?:Error|Exception|Timeout)\b|Traceback"          # a service name, a raw error
    + r"|(?-i:\b(?:main|transformers|alerts|assets|vulnerabilities)\.[a-z_]+\b)|\bSELECT\b|\bsplit_part\b"
    + r"|does not exist|not success|\bis keyed\b|\blast sweep\b|psycopg|sqlalchemy|duckdb|asyncpg|UndefinedColumn", re.I)


def find_leaks(text: str) -> list[str]:
    """What in a SENTENCE TEMPLATE breaks I2 (raw error text, a relation name, an internal status code, a service name, a
    raw identifier). Run it on `CONDITIONS` text and on the sentence of a row built WITHOUT a free-text name; a part name
    is checked by `find_name_leaks`, since a figure's own title may carry a number ('CVEs older than 400 days')."""
    return [m.group(0) for m in _LEAK.finditer(text or "")]


def find_name_leaks(name: str) -> list[str]:
    """What in a part NAME is not an app artifact's UI name: an id, a snake_case identifier, a quoted identifier."""
    return [m.group(0) for m in _NAME_LEAK.finditer(name or "")]


#: the name a part takes when the artifact has none, or only a raw one (an agent without a name has its id as "name").
_SHARED_SUFFIX = " (shared with other apps)"
_KIND_FALLBACK = {"integration": "An integration", "sync": "A data source", "table": "A data table",
                  "entity_graph": "The Entity Graph", "widget": "A figure", "detection": "A check",
                  "closing_check": "A closing check", "agent": "A background agent", "route": "An alert route",
                  "retriage": "Re-checking", "playbook": "A playbook", "question": "A question", "home_input": "A source"}


def _part(kind: str, name: str, cond: str, since=None, link: str | None = None, **fmt) -> dict:
    status, who, sentence, nxt = CONDITIONS[cond]
    name = str(name or "").strip()
    if not name or find_name_leaks(name):
        shared = _SHARED_SUFFIX if name.endswith(_SHARED_SUFFIX) else ""
        base = name[:-len(_SHARED_SUFFIX)].strip() if shared else name
        if not base or find_name_leaks(base):                          # I2: never a raw id or identifier
            name = _KIND_FALLBACK.get(kind, "A part of this app") + shared
    shown = fmt.get("fmt_name") or name
    n = fmt.get("n", "")
    count = int(n) if str(n).strip().isdigit() else 0
    wait = ("1 figure waits" if count == 1 else f"{count} figures wait") if count > 0 else "Some figures wait"  # never "0 figures"
    if find_name_leaks(shown):
        shown = name
    out = {"kind": kind, "name": name, "status": status, "since": iso_or_none(since), "link": link,
           "sentence": sentence.format(name=shown, n=n, wait=wait), "next_step": nxt.format(name=shown, n=n, wait=wait),
           "who_fixes": who, "condition": cond}
    if fmt.get("caveat"):
        out["caveat"] = True                   # a note on the row with no colour of its own (never rolled up)
    return out


def rollup(statuses: Iterable[str]) -> str:
    """The row colour: the worst of its parts (red > orange > grey > green). No part reads grey, never green (I1)."""
    worst = None
    for s in statuses:
        if s == NOT_USED:
            continue
        if s not in _SEVERITY:
            s = GREY                          # an unrecognised status is unknown, never green
        if worst is None or _SEVERITY[s] > _SEVERITY[worst]:
            worst = s
    return worst or GREY


def health_summary(rows: list[dict]) -> dict:
    """One {colour, sentence} for the whole section, from its rows (not_used rows ignored). All green → "All systems
    operational"; else the worst colour speaks: red outage, then orange degraded, then grey unknown. Grey is never
    summarised as operational, and no judged row at all is unknown (I1)."""
    colour = rollup(r["status"] for r in rows if r.get("status") != NOT_USED)
    return {"colour": colour, "sentence": SUMMARY_SENTENCE[colour]}


def support_code(row_key: str, parts: list[dict]) -> str | None:
    """An opaque reference for support (the raw cause stays in log_failure and is never served)."""
    bad = sorted(f"{p['kind']}:{p.get('condition')}" for p in parts if p["status"] not in (GREEN, NOT_USED))
    if not bad:
        return None
    return "AH-" + hashlib.sha1(f"{row_key}|{'|'.join(bad)}".encode()).hexdigest()[:8].upper()


def make_row(key: str, parts: list[dict], *, not_used: bool = False) -> dict:
    """`_make_row` plus the status `label` in status-page words (Operational, Degraded, Outage, Unknown, Not in use)."""
    row = _make_row(key, parts, not_used=not_used)
    row["label"] = STATUS_LABEL[row["status"]]
    return row


def _make_row(key: str, parts: list[dict], *, not_used: bool = False) -> dict:
    """One row from its parts. Its sentence, next step and who-fixes are the worst part's; since is the earliest start of a
    non-green part (I3), and None when green."""
    base = {"key": key, "name": ROW_NAME[key], "order": ROW_ORDER[key]}
    if not_used:
        return {**base, "status": NOT_USED, "since": None, "who_fixes": YOU, "sentence": NOT_USED_SENTENCE, "next_step": "",
                "support_code": None, "parts": []}
    judged = [p for p in parts if not p.get("caveat")]       # a caveat is a note with no colour: never rolled up
    if parts and judged and all(p["status"] == NOT_USED for p in judged):
        return {**base, "status": NOT_USED, "since": None, "who_fixes": YOU, "sentence": NOT_USED_SENTENCE, "next_step": "",
                "support_code": None, "parts": parts}
    if not judged:
        status, who, sentence, nxt = CONDITIONS["not_checked"]
        return {**base, "status": GREY, "since": None, "who_fixes": who, "sentence": sentence, "next_step": nxt,
                "support_code": None, "parts": parts}
    status = rollup(p["status"] for p in judged)
    worst = [p for p in judged if p["status"] == status] or judged
    lead = worst[0]
    non_green = [p for p in judged if p["status"] not in (GREEN, NOT_USED)]
    since = None
    for p in non_green:
        since = earliest(since, p.get("since"))
    extra = len(worst) - 1
    sentence = lead["sentence"] + (f" ({extra} more)" if extra > 0 else "")
    return {**base, "status": status, "since": since if status != GREEN else None,
            "who_fixes": lead["who_fixes"] if status != GREEN else YOU, "sentence": sentence,
            "next_step": lead["next_step"], "support_code": support_code(key, judged), "parts": parts}


# ---------------------------------------------------------------------------------------------------------------- build

def _agent_label(a: dict | None) -> str:
    """An agent's own name, never its id (health.py falls back to the id for a nameless agent)."""
    return str((a or {}).get("agent_name") or "").strip() or "A background agent"


def _link(kind: str, ident) -> str | None:
    """'<kind>:<id>' for the drill-down to open the artifact; the id is only ever in the link (never a name or a sentence)."""
    i = str(ident or "").strip()
    return f"{kind}:{i}" if i else None


def _rules_by_name(facts: dict) -> dict:
    return {r.get("name"): r for r in (facts.get("rules") or {}).get("items") or [] if isinstance(r, dict)}


def _line_parts(facts: dict, lines: list[dict]) -> dict[str, list[dict]]:
    """Parts per row from health.py's lines (I4: the same conditions the health card said)."""
    out: dict[str, list[dict]] = {k: [] for k in ROW_KEYS}
    rules = _rules_by_name(facts)
    agents = {str(a.get("agent_name") or a.get("agent_id")): a for a in (facts.get("since") or {}).get("agent_runs") or []
              if isinstance(a, dict)}
    for ln in lines:
        kind, name = ln.get("kind"), str(ln.get("name") or "")
        shown = _h._check(name) if name else ""
        rule = rules.get(name) or {}
        shipped = bool(rule.get("from_app"))
        since = rule.get("failing_since") or None
        rlink = _link("detection", rule.get("id"))
        if kind == "sync_blocked":
            need = ln.get("need") or {}
            out["integrations"].append(_part("integration", str(need.get("measure_name") or "An integration"),
                                             "integration_blocked", need.get("first_seen"),
                                             _link("integration", need.get("integration_id"))))
        elif kind == "sync_failing":
            items = ln.get("items") or []
            first = None
            for r in items:
                first = earliest(first, r.get("failing_since"))
            quiet = bool(items) and all(r.get("status") == "went_quiet" for r in items)
            names = sorted({str(r.get("integration_name")) for r in items if r.get("integration_name")})
            out["datalake"].append(_part("sync", ", ".join(names[:3]) or "A data source",
                                         "sync_quiet" if quiet else "sync_failing", first,
                                         _link("integration", next((r.get("integration_id") for r in items if r.get("integration_id")), None))))
        elif kind == "source_unread":
            titles = [t for t in (str(f.get("title") or "").strip() for f in ln.get("figures") or [] if isinstance(f, dict)) if t]
            label = ", ".join(titles[:3]) + (f" and {len(titles) - 3} more" if len(titles) > 3 else "")
            out["dashboard_widgets"].append(_part("widget", label or "Figures", "figures_unavailable", n=len(titles) or None))
        elif kind in ("rule_broken", "rule_failed"):
            cond = ("detection_broken" if kind == "rule_broken" else "detection_failed") + ("_torana" if shipped and kind == "rule_failed" else "")
            out["inbox_filtered"].append(_part("detection", shown, cond, since or rule.get("last_run_at"), rlink))
            out["inbox_needs_attention"].append(_part("detection", shown, "feeds_stopped", since or rule.get("last_run_at"),
                                                      rlink, fmt_name=shown))
            out["inbox_closed"].append(_part("closing_check", shown, "closing_cannot_run", since or rule.get("last_run_at"),
                                             rlink, fmt_name=shown))
        elif kind == "rule_cannot_close":
            out["inbox_closed"].append(_part("closing_check", shown, "closing_cannot_run_torana" if shipped else
                                             "closing_cannot_run", rule.get("last_run_at"), rlink))
        elif kind == "rule_never_ran":
            out["inbox_filtered"].append(_part("detection", shown, "detection_never_ran", link=rlink))
        elif kind == "rule_blocked":
            out["inbox_filtered"].append(_part("detection", shown or "Some checks", "detection_blocked", link=rlink))
        elif kind == "rules_unknown":
            out["inbox_filtered"].append(_part("detection", "Checks", "detections_unread"))
        elif kind == "agent_off":
            out["inbox_needs_attention"].append(_part("agent", _agent_label(agents.get(name)), "agent_paused"))
        elif kind in ("agent_failing", "agent_flaky", "agent_recovered"):
            a = agents.get(name) or {}
            label = _agent_label(a)
            if a.get("scope") not in (None, "this_app"):
                out["inbox_needs_attention"].append(_part("agent", label, "agent_other_scope"))
            else:
                cond = {"agent_failing": "agent_failing", "agent_flaky": "agent_flaky", "agent_recovered": "agent_recovered"}[kind]
                out["inbox_needs_attention"].append(_part("agent", label, cond, a.get("first_failed_at")))
        elif kind == "no_triage_agent":
            out["inbox_needs_attention"].append(_part("agent", "Triage agent", "no_triage_agent"))
        elif kind == "routing_unknown":
            out["inbox_needs_attention"].append(_part("route", "Alert routes", "routing_unread"))
    return out


def _judged(ps: list[dict]) -> list[dict]:
    return [p for p in ps if not p.get("caveat")]


def _confirmed_parts(facts: dict, parts: dict[str, list[dict]]) -> None:
    """A green part only where the facts show the source WAS read and nothing is wrong (I1: never green by absence)."""
    syncs = facts.get("syncs")
    if isinstance(syncs, dict):
        if syncs.get("available") is False:
            parts["datalake"].append(_part("sync", "Data syncs", "sync_unread"))
        elif not _judged(parts["datalake"]):
            parts["datalake"].append(_part("sync", "Data syncs", "ok"))
    rules = facts.get("rules")
    if isinstance(rules, dict) and rules.get("available") is not False and rules.get("items") is not None:
        if not _judged(parts["inbox_filtered"]):
            parts["inbox_filtered"].append(_part("detection", "Checks", "ok"))
        if not _judged(parts["inbox_closed"]):
            parts["inbox_closed"].append(_part("closing_check", "Closing checks", "ok"))
    rt = facts.get("routing")
    configured = isinstance(rt, dict) and any(isinstance(rt.get(k), int) and rt[k] > 0 for k in ("alert_routes", "triage_agents"))
    if configured and rt.get("available") is not False \
            and not any(p["status"] != GREEN for p in parts["inbox_needs_attention"]):
        # I1: green only from something actually set up; an app with no route and no triage agent has nothing to confirm here
        parts["inbox_needs_attention"].append(_part("route", "Alert routes and triage", "ok"))
    if isinstance(facts.get("measures"), list) and facts["measures"] and not _judged(parts["dashboard_widgets"]):
        parts["dashboard_widgets"].append(_part("widget", "Figures", "ok"))


#: Defaults a need line carries when it has no real name for what is missing (health.py, read_gaps.py): they name nothing, so a
#: figure whose reason merely contains one is not thereby covered by ANY gap.
_PLACEHOLDER_TEXT = frozenset({"access to this data", "part of this page's data", "a source", "a data source"})


def _placeholders() -> frozenset:
    return _PLACEHOLDER_TEXT | frozenset(str(v).strip().lower() for v in _h._NEED_MISSING.values())


def _gap_tokens(lines: list[dict]) -> set[str]:
    """What the App Gaps lines name (the measure, the missing input, the integration), lower-cased: what a blind figure's own
    reason must mention for that gap to be the cause of its blindness."""
    out: set[str] = set()
    for ln in lines:
        if ln.get("kind") not in GAP_LINE_KINDS:
            continue
        need = ln.get("need") or {}
        for v in (need.get("measure_name"), need.get("missing_input"), ln.get("name")):
            t = str(v or "").strip().lower()
            if len(t) >= 4 and t not in _placeholders():
                out.add(t)
    return out


def _figure_text(me: dict) -> str:
    """What a blind figure says it is missing: the coverage reason, the blocked columns and the integrations it waits on."""
    cov = me.get("coverage") if isinstance(me.get("coverage"), dict) else {}
    bits = [cov.get("reason"), me.get("missing_input"), *(cov.get("blocked_columns") or []),
            *(cov.get("missing_integrations") or []), *(me.get("missing_integrations") or [])]
    return " ".join(str(b) for b in bits if b).lower()


def _blind_split(facts: dict, lines: list[dict]) -> tuple[int, int]:
    """(blind figures an App Gaps line accounts for, the rest). A figure counts as covered by a gap ONLY when its own reason
    names what the gap names. Facts that cannot match per figure leave it uncovered: unless coverage is proven it is orange."""
    mix = facts.get("coverage_mix") or {}
    measures = [m for m in facts.get("measures") or [] if isinstance(m, dict)]
    n_blind = int(mix.get("blind") or 0)
    for me in measures:
        if me.get("available") is False and ((me.get("coverage") or {}).get("state") in (None, "blind")):
            n_blind = max(0, n_blind - 1)          # said once, as "not available" (home.trust)
    tokens = _gap_tokens(lines)
    covered = 0
    for me in measures:
        if me.get("available") is False or (me.get("coverage") or {}).get("state") != "blind":
            continue
        text = _figure_text(me)
        if text and any(t in text or text in t for t in tokens):
            covered += 1
    covered = min(covered, n_blind)
    return covered, n_blind - covered


def _trust_parts(facts: dict, parts: dict[str, list[dict]], lines: list[dict] | None = None) -> None:
    """The trust lines (home.trust) that health lines do not already say."""
    for t in trust(facts):
        k = t.get("kind")
        if k == "rules" and "Nothing is watching" in (t.get("text") or ""):
            parts["inbox_filtered"].append(_part("detection", "Checks", "no_detections"))
        elif k == "dates":
            txt = t.get("text") or ""
            if "out of date" in txt:
                parts["dashboard_widgets"].append(_part("widget", "Figures", "figures_stale"))
            if "no reliable date" in txt:
                parts["dashboard_widgets"].append(_part("widget", "Figures", "figures_undated"))
            if "can't be answered" in txt:
                covered, rest = _blind_split(facts, lines or [])
                if covered:
                    # D15: blind because of a gap that App Gaps already names: no colour here, the figure keeps its marker (D6).
                    parts["dashboard_widgets"].append(_part("widget", "Figures", "figures_wait_on_gaps",
                                                            link="section:app_gaps", n=covered, caveat=True))
                if rest or not covered:
                    parts["dashboard_widgets"].append(_part("widget", "Figures", "figures_blind"))     # I1: orange unless proven
            if "never recorded" in txt:
                parts["dashboard_widgets"].append(_part("widget", "Figures", "figures_not_yet"))
        elif k == "unavailable" and not any(p["condition"] == "figures_unavailable" for p in parts["dashboard_widgets"]):
            parts["dashboard_widgets"].append(_part("widget", "Figures", "figures_unavailable"))


def _inbox_and_briefing(facts: dict, parts: dict[str, list[dict]]) -> None:
    from .home import alerts_unread

    if isinstance(facts.get("alerts"), dict):
        if alerts_unread(facts):
            parts["home_top_priorities"].append(_part("home_input", "The Inbox", "inbox_unread"))
            parts["inbox_needs_attention"].append(_part("home_input", "The Inbox", "inbox_unread"))
        else:
            parts["home_top_priorities"].append(_part("home_input", "The Inbox", "ok"))
    b = facts.get("briefing")
    if isinstance(b, dict):                       # S2 supplies it: {state: ok|held|failed, since}
        cond = {"held": "briefing_held", "failed": "briefing_failed", "ok": "ok"}.get(str(b.get("state")), "unreadable")
        parts["home_daily_briefing"].append(_part("question", "Daily Briefing", cond, b.get("since")))


def build_rows(facts: dict | None, tz: str | None = None, extra_parts: dict | None = None,
               not_used: Iterable[str] = ()) -> list[dict]:
    """The 10 rows, D4 order, from the facts payload. `extra_parts` {row key: [part]} is what PPF's collectors read from the
    other services (integrations, DataPipelines, Entity Graph, widgets, closing checks, playbooks, ...), each built with
    `part()`; `not_used` names the rows the app does not use. A row with no part reads "Not checked yet" (grey): never green."""
    facts = facts if isinstance(facts, dict) else {}
    parts: dict[str, list[dict]] = {k: [] for k in ROW_KEYS}
    if facts:
        lines = _h._wrapped(facts, tz, _h._all_lines) or []
        for k, v in _line_parts(facts, lines).items():
            parts[k].extend(v)
        _trust_parts(facts, parts, lines)
        _inbox_and_briefing(facts, parts)
    for k, v in (extra_parts or {}).items():
        if k in parts:
            parts[k].extend(v)
    if facts:
        _confirmed_parts(facts, parts)       # LAST: it counts every part, so "Working" never sits beside a red or orange one
    skip = set(not_used)
    return [make_row(k, parts[k], not_used=k in skip and not parts[k]) for k in ROW_KEYS]


def part(kind: str, name: str, condition: str, since=None, link: str | None = None, n=None) -> dict:
    """A part for a collector outside this module (PPF): the status, sentence and next step come from `CONDITIONS`."""
    if kind not in PART_KINDS:
        raise ValueError(f"unknown part kind {kind!r}")
    if condition not in CONDITIONS:
        raise ValueError(f"unknown condition {condition!r}")
    return _part(kind, name, condition, since, link, n="" if n is None else n)


def public_row(row: dict) -> dict:
    """The row exactly as every surface serves it: the contract fields only (parts drop who_fixes/condition)."""
    keep = ("kind", "name", "status", "since", "sentence", "link")
    return {**{k: row[k] for k in ("key", "name", "order", "status", "since", "who_fixes", "sentence", "next_step",
                                   "support_code")},
            "parts": [{k: p.get(k) for k in keep} for p in row["parts"]]}


def _part_key(row_key: str, p: dict) -> tuple:
    return (row_key, p.get("kind"), p.get("name"), p.get("condition"), p.get("link"))


def log_red_transitions(previous: list[dict] | None, rows: list[dict], *, tenant_id: str | None,
                        workspace_id: str | None = None) -> int:
    """Exactly one `log_failure` per Torana-side red PART that is new since `previous`, keyed by (row, kind, name,
    condition, link) (two failing tables are two failures even when they share a name): a Torana red part that joins a row already red from a customer part is logged, and part order never decides
    it. A part that stays red logs nothing. `previous` should be the STORED full rows (parts keep `condition` and `who_fixes`;
    public_row strips them only when serving). A rows-without-who_fixes snapshot (an older store, or public rows) still
    matches on (row, kind, name) and on the link.

    ⛔ CONTRACT (design note § 7): the caller logs ONLY AFTER its snapshot write won the compare-and-set on the previous
    snapshot's computed_at (the start time of the reads). Two overlapping computations that both log would send ops the
    same transition twice."""
    from ..logging_events import log_failure

    seen: set[tuple] = set()
    by_link: set[tuple] = set()          # a link is stable across a rename of the part: no re-log burst at a deploy
    for r in previous or []:
        for p in r.get("parts") or []:
            if p.get("status") == RED:
                seen.add(_part_key(r["key"], p))
                # a link match covers a rename of a TORANA-side part only. A customer-side red part (who_fixes "you") that turns
                # Torana-side is a new failure for ops. Stored rows that carry no who_fixes (served rows from before) keep
                # the link-only match: that is the deploy case.
                if p.get("link") and p.get("who_fixes", TORANA) == TORANA:
                    by_link.add((r["key"], p.get("kind"), p.get("link")))
    n = 0
    for r in rows:
        for p in r["parts"]:
            if p["status"] != RED or p.get("who_fixes") != TORANA:
                continue
            key = _part_key(r["key"], p)
            if key in seen or (key[0], key[1], key[2], None, key[4]) in seen:
                continue
            if p.get("link") and (r["key"], p.get("kind"), p.get("link")) in by_link:
                continue                 # the same part renamed (or its condition changed while red)
            seen.add(key)
            log_failure("home.source", tenant_id=tenant_id, error_code="home.app_health_red", unit_id=f"{r['key']}:{p['kind']}",
                        workspace_id=workspace_id, support_code=r.get("support_code"), condition=p.get("condition"))
            n += 1
    return n


def delivery_condition(kind: str, state: str, error_class: str | None) -> str:
    """The condition for one PDF delivery-health route ({kind: routing|escalation, state: failing|recovered, error_class:
    destination_refused|delivery_error|unknown}): who fixes it follows the error class, never a guess. An unknown class
    promises nothing (routing_failed_unknown)."""
    if state != "failing":
        return "routing_recovered" if kind == "routing" else "ok"
    if kind == "escalation":
        return "escalation_failed"
    return {"destination_refused": "routing_refused", "delivery_error": "routing_failed"}.get(str(error_class or ""),
                                                                                            "routing_failed_unknown")
