"""The fan-out graph: one item that covers MANY findings (a threat signal, a fix or mitigation entry, a posture
finding with no image model). Spec: pantheon-fe/docs/AI_HOME_V2_HOME_PROOF_SPEC.md § 3.4.1.

Columns, left to right: the internet → services → places (image or repository) → [the item] → CVEs, on the same
col/row grid vuln_in_image.graph uses, so the page draws it unchanged. A member is one posture finding: its key,
its CVE, its place and the pointer that proves "this place has this CVE".

⛔ Every node and edge points at the cell (or selection) it was drawn from. Services, exposure and load balancers are
read from ONE representative member row per shown place (posture_findings.service_keys,
internet_facing_service_keys, load_balancer_keys), never from every member: a mitigation lists up to 840 members,
and the record must stay under the 1 MiB /verify cap (§ 3.6.12).
⚠️ Aggregation: each column shows its TOP biggest members; the rest become ONE "+K more" node citing the
selection (or the cell) that lists them all. "Biggest" = most member findings (places), most places (CVEs, services).
"""
from __future__ import annotations

from typing import Callable, NamedTuple

from ..core.render import qualified

TOP = 6
EMPTY = {"nodes": [], "edges": [], "blast": []}
# Column of each kind when the item sits between places and CVEs (entries); a threat or a single finding puts the
# CVEs right after the places and the item after them.
COLS_ENTRY = {"inet": 0, "svc": 1, "place": 2, "item": 3, "cve": 4}
COLS_SIGNAL = {"inet": 0, "svc": 1, "place": 2, "cve": 3, "item": 4}


class Member(NamedTuple):
    key: str
    cve: str | None
    place: str | None
    p: dict | None


def place_of_key(finding_key: str) -> str:
    """The place segment of a posture finding key CVE|ecosystem|package|version|place."""
    return finding_key.split("|", 4)[-1]


def _short(s) -> str:
    """image:…/pantheon-viz@sha256:26ed4ca3… → pantheon-viz@26ed4ca3; repo:github.com/x/y → y; service:torana/z → z."""
    s = str(s or "—")
    name, _, digest = s.partition("@sha256:")
    name = name.split("/")[-1].split(":")[-1]
    return f"{name}@{digest[:8]}" if digest else name


def labels(keys) -> dict:
    """A label for every key in ONE graph: the short name, and the namespace-qualified name for any keys whose short
    names collide (service:demo/x and service:edge/x, or a repository and a service both called x). Without this the
    page printed two nodes with one name and their edges read as duplicates or as a loop."""
    keys = [k for k in dict.fromkeys(keys) if k]
    out = {k: _short(k) for k in keys}
    by_short: dict = {}
    for k, v in out.items():
        by_short.setdefault(v, []).append(k)
    for v, ks in by_short.items():
        if len(ks) > 1:
            q = {k: qualified(k) for k in ks}
            for k in ks:
                # Still equal after qualifying (same name in the same namespace, different scheme): keep the scheme.
                out[k] = q[k] if list(q.values()).count(q[k]) == 1 else str(k)
    return out


def _ranked(groups: dict, weight: Callable) -> list:
    return sorted(groups, key=lambda k: (-weight(groups[k]), str(k)))


def _more(N: list, nid: str, col: int, row: int, hidden: int, noun: str, p) -> None:
    if hidden > 0 and p:
        N.append({"id": nid, "col": col, "row": row, "t1": f"+{hidden} more", "t2": noun, "p": p})


def fanout(members: list[Member], rows_for: Callable[[list[str]], dict], more_p: dict | None,
           cols: dict, link_place_cve: bool) -> tuple[list, list, dict, dict]:
    """Nodes and edges for the internet/service/place/CVE columns. Returns (nodes, edges, place ids, CVE ids):
    the caller adds the item node and wires it to the places or CVEs it returns.
    rows_for(keys) → {finding_key: Row}: one representative posture_findings row per shown place."""
    N, E = [], []
    by_place: dict = {}
    by_cve: dict = {}
    for m in members:
        if m.place and m.cve:
            by_place.setdefault(m.place, []).append(m)
            by_cve.setdefault(m.cve, {}).setdefault(m.place, m)
    places = _ranked(by_place, len)
    cves = _ranked(by_cve, len)
    shown_p, shown_c = places[:TOP], cves[:TOP]
    reps = rows_for([by_place[pl][0].key for pl in shown_p]) if shown_p else {}

    def edge(a, b, label, p, style="reported"):
        E.append({"from": a, "to": b, "label": label, "style": style, "p": p})

    place_ids, svc_links, inet, lbs = {}, {}, {}, {}
    named: list = []                    # (node, key): relabelled together at the end, so colliding names are told apart
    for i, pl in enumerate(shown_p):
        r = reps.get(by_place[pl][0].key)
        name, pp = r.p("place_key") if r is not None else (pl, by_place[pl][0].p)
        n = len(by_place[pl])
        kind = "repository" if str(name).startswith("repo:") else "image"
        pid = place_ids[pl] = f"p{i}"
        N.append({"id": pid, "col": cols["place"], "row": i, "t1": _short(name),
                  "t2": f"{kind} · {n} finding{'' if n == 1 else 's'}", "p": pp})
        named.append((N[-1], name))
        if r is None:
            continue
        svcs, sp = r.p("service_keys")
        for s in svcs or []:
            svc_links.setdefault(s, []).append((pid, sp))
        ifs, ip = r.p("internet_facing_service_keys")
        for s in ifs or []:
            inet.setdefault(s, ip)
        lb, lp = r.p("load_balancer_keys")
        for x in lb or []:
            lbs.setdefault(x, lp)
    hidden_findings = sum(len(by_place[pl]) for pl in places[TOP:])
    _more(N, "p-more", cols["place"], len(shown_p), len(places) - len(shown_p),
          f"more places · {hidden_findings} finding{'' if hidden_findings == 1 else 's'}", more_p)

    svcs = _ranked(svc_links, len)
    for j, s in enumerate(svcs[:TOP]):
        sid = f"s{j}"
        exposed = s in inet
        N.append({"id": sid, "col": cols["svc"], "row": j, "t1": _short(s),
                  "t2": "internet-facing" if exposed else "running", **({"cls": "inet"} if exposed else {}),
                  "p": inet[s] if exposed else svc_links[s][0][1]})
        named.append((N[-1], s))
        for pid, sp in svc_links[s]:
            edge(sid, pid, "runs", sp)
        if exposed:
            edge("inet", sid, "reaches", inet[s])
    hidden_s = svcs[TOP:]
    _more(N, "s-more", cols["svc"], min(len(svcs), TOP), len(hidden_s), "more services",
          svc_links[hidden_s[0]][0][1] if hidden_s else None)
    _follow_services(N, svcs[:TOP], svc_links)
    if any(s in inet for s in svcs[:TOP]):
        rows = max(min(len(svcs), TOP), 1)
        N.append({"id": "inet", "col": cols["inet"], "row": (rows - 1) // 2, "t1": "Internet",
                  "t2": f"via {len(lbs)} load balancer{'' if len(lbs) == 1 else 's'}" if lbs else "internet-facing",
                  "cls": "inet", "p": next(iter(lbs.values()), None) or next(iter(inet.values()))})

    names = labels([k for _, k in named])
    for node, key in named:
        node["t1"] = names[key]
    cve_ids = {}
    for i, c in enumerate(shown_c):
        cid = cve_ids[c] = f"c{i}"
        on = len(by_cve[c])
        first = next(iter(by_cve[c].values()))
        N.append({"id": cid, "col": cols["cve"], "row": i, "t1": c, "t2": f"on {on} place{'' if on == 1 else 's'}",
                  "cls": "cve", "p": first.p})
        if link_place_cve:
            for pl, m in by_cve[c].items():
                if pl in place_ids:
                    edge(place_ids[pl], cid, "has", m.p)
    _more(N, "c-more", cols["cve"], len(shown_c), len(cves) - len(shown_c), "more CVEs", more_p)
    return N, E, place_ids, cve_ids


def slim(p: dict | None) -> dict | None:
    """A graph pointer WITHOUT its payload: the record's `leaves` already hold the value (cell) or key list (sel)
    once, and the page/CLI resolve a slim pointer there (proof-resolve.ts). ⚠️ MEASURED 2026-10-07 on T2: with full
    pointers, mitigate|vim's graph repeated its 840-key member_finding_keys cell on ~20 nodes and edges, and the
    record reached 2.49 MB, over the 1 MiB /verify cap (§ 3.6.12)."""
    if not p or p.get("k") not in ("cell", "sel"):
        return p
    return {k: v for k, v in p.items() if k not in ("value", "keys", "q")} | {"slim": True}


def finish(nodes: list, edges: list) -> dict:
    """The graph as stored: every node and edge pointer slimmed (see slim)."""
    for x in nodes + edges:
        x["p"] = slim(x.get("p"))
    return {"nodes": nodes, "edges": edges, "blast": []} if nodes else EMPTY


def _follow_services(N: list, shown_svcs: list, svc_links: dict) -> None:
    """Fewer crossings: each place moves to the row of the FIRST shown service that runs it (a place several services
    run sits at the first one's row); places no shown service runs keep their rank order below them. Rows only: ids,
    pointers and edges are unchanged, and the page stays a dumb grid. "+K more" stays last."""
    first = {}
    for j, s in enumerate(shown_svcs):
        for pid, _ in svc_links.get(s, []):
            first.setdefault(pid, j)
    places = [n for n in N if n["id"].startswith("p") and n["id"][1:].isdigit()]
    order = sorted(places, key=lambda n: (first.get(n["id"], len(shown_svcs)), n["row"]))
    row = -1
    for n in order:
        row = max(first.get(n["id"], 0), row + 1)
        n["row"] = row
    for n in N:
        if n["id"] == "p-more":
            n["row"] = row + 1


def mid_row(nodes: list) -> int:
    """The row that centres a single node against the tallest column."""
    rows = [n["row"] for n in nodes if n["row"] >= 0]
    return (max(rows) // 2) if rows else 0
