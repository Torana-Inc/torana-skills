"""A tiny, closed WHERE language. Rules state WHAT they select; the framework writes the SQL.

A where is a list of (column, op, value) triples. Ops:
  =  !=  >=  in  prefix  suffix  suffix_any  is_null  not_null
(>= compares numbers; a NULL cell never matches it, in SQL and in memory alike.)
Because it is data, a selection can be logged, hashed, replayed from a capture, and re-run live
with identical meaning. Free-form SQL inside a rule would make all three impossible.
"""
from __future__ import annotations

from typing import Any

OPS = {"=", "!=", ">=", "in", "prefix", "suffix", "suffix_any", "is_null", "not_null"}


def norm(where: list) -> list:
    out = []
    for col, op, val in where:
        if op not in OPS:
            raise ValueError(f"unknown op {op}")
        if op in ("in", "suffix_any"):
            val = sorted(set(val), key=str)
        out.append([col, op, val])
    return sorted(out, key=lambda t: (t[0], t[1], str(t[2])))


def lit(v: Any) -> str:
    if v is None:
        return "NULL"
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    if isinstance(v, (int, float)):
        return str(v)
    return "'" + str(v).replace("'", "''") + "'"


def like_lit(s: str) -> str:
    """Quote s for a LIKE pattern with ESCAPE '!'. '!' (not '\\') keeps backslashes out of the literal,
    so the datalake's read-only guard can mask literals and never scans values as SQL (spec B1)."""
    return lit(s.replace("!", "!!").replace("%", "!%").replace("_", "!_"))


# Derived columns: named extracts of a JSON text column, so a rule can read the one field it needs (a line number, a rule
# link) WITHOUT selecting the whole column. `vulnerabilities.scan_output` holds the scanner's raw output, including the
# flagged source line; a projected read of these names never brings it into the proof. The set is closed: a name not
# listed here is refused.
_JSON_TEXT = "CAST(scan_output AS text)"


def _extract(key: str, pattern: str = "[^\"]+") -> str:
    return f"substring({_JSON_TEXT} from '\"{key}\": \"?({pattern})')"


DERIVED: dict[str, dict[str, str]] = {
    "vulnerabilities": {
        "scan_line": _extract("line", "[0-9]+"),
        "scan_end_line": _extract("end_line", "[0-9]+"),
        "scan_rule_id": _extract("rule_id"),
        "scan_rule_help_uri": _extract("rule_help_uri"),
        "scan_confidence": _extract("confidence", "[A-Za-z]+"),
        "scan_impact": _extract("impact", "[A-Za-z]+"),
        "scan_likelihood": _extract("likelihood", "[A-Za-z]+"),
        "scan_resource_name": _extract("resourceName"),
        "scan_alert_number": _extract("alert_number", "[0-9]+"),
    },
}


def select_list(table: str, columns: list[str] | None, order_by: list[str]) -> str:
    """`*`, or the named columns (plus the key columns, so rows can be keyed) with derived names written as extracts."""
    if not columns:
        return "*"
    derived = DERIVED.get(table, {})
    out = []
    for c in dict.fromkeys([*order_by, *columns]):
        out.append(f"{derived[c]} AS {c}" if c in derived else c)
    return ", ".join(out)


def plain_columns(table: str, columns: list[str] | None) -> list[str]:
    """The columns of `columns` that are real column names (identifier-checked by the caller); derived ones are known names."""
    return [c for c in columns or [] if c not in DERIVED.get(table, {})]


def to_sql(table: str, where: list, order_by: list[str], check, columns: list[str] | None = None) -> str:
    check(table, *order_by, *(c for c, _, _ in where), *plain_columns(table, columns))
    parts = []
    for col, op, val in where:
        if op == "=":
            parts.append(f"{col} IS NULL" if val is None else f"{col} = {lit(val)}")
        elif op == "!=":
            parts.append(f"{col} IS NOT NULL" if val is None else f"{col} <> {lit(val)}")
        elif op == ">=":
            parts.append(f"{col} >= {lit(val)}")
        elif op == "in":
            parts.append(f"{col} IN ({', '.join(lit(v) for v in val)})" if val else "FALSE")
        elif op == "prefix":
            parts.append(f"{col} LIKE {like_lit(val)[:-1]}%' ESCAPE '!'")
        elif op == "suffix":
            parts.append(f"{col} LIKE '%{like_lit(val)[1:]} ESCAPE '!'")
        elif op == "suffix_any":
            parts.append("(" + " OR ".join(f"{col} LIKE '%{like_lit(v)[1:]} ESCAPE '!'" for v in val) + ")" if val else "FALSE")
        elif op == "is_null":
            parts.append(f"{col} IS NULL")
        elif op == "not_null":
            parts.append(f"{col} IS NOT NULL")
    sql = f"SELECT {select_list(table, columns, order_by)} FROM {table}"
    if parts:
        sql += " WHERE " + " AND ".join(parts)
    return sql + " ORDER BY " + ", ".join(order_by)


def matches(row: dict, where: list) -> bool:
    """Evaluate a where in memory (used by the in-memory test source and by captured replay)."""
    for col, op, val in where:
        v = row.get(col)
        if op == "=" and not (v is None if val is None else v == val):
            return False
        if op == "!=" and (v is None if val is None else v == val):
            return False
        if op == ">=" and not (isinstance(v, (int, float)) and not isinstance(v, bool) and v >= val):
            return False
        if op == "in" and v not in val:
            return False
        if op == "prefix" and not (isinstance(v, str) and v.startswith(val)):
            return False
        if op == "suffix" and not (isinstance(v, str) and v.endswith(val)):
            return False
        if op == "suffix_any" and not (isinstance(v, str) and any(v.endswith(x) for x in val)):
            return False
        if op == "is_null" and v is not None:
            return False
        if op == "not_null" and v is None:
            return False
    return True
