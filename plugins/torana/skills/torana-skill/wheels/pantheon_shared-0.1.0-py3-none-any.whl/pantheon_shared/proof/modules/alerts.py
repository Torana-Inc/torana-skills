"""alerts — what an Inbox item is about, and whether that is still true.

Source: detection-framework alerts (read through the platform API, addressed by alert id).
"""
from urllib.parse import unquote

from ..core.engine import NotCaptured, rule

#: Inbox entry roots (pantheon-detection-framework services/entries.py) are keyed `<policy>|<identity>`
#: (services/remediation_registry.py `entry_key`); a package policy's identity is the purl without its version.
ROOT_POLICIES = {"upgrade.package.v1": "fix_entry", "mitigate.package.v1": "mitigation_entry"}
_DISTROS = ("apk", "deb", "rpm")

def parse_vuln_id(vid: str | None, cve: str | None) -> dict | None:
    """gcp_ca_<image:…>_<CVE id>_<pkg:…@version> split into its parts; None when it does not parse."""
    vid = vid or ""
    if not vid.startswith("gcp_ca_") or not cve or f"_{cve}_" not in vid:
        return None
    image, purl = vid[len("gcp_ca_"):].split(f"_{cve}_", 1)
    if not image.startswith("image:") or not purl.startswith("pkg:") or "@" not in purl:
        return None
    return {"image": image, "cve": cve, "purl": purl,
            "package": purl.split("/")[-1].split("@")[0], "version": purl.split("@", 1)[1]}


def _covering_entry(ctx, finding_key: str | None) -> tuple[str | None, object]:
    """The ranking entry a finding is worked under, as a decision key, plus the finding's own priority.
    route 'upgrade' with a fix_key → fix|<fix_key>; route 'mitigate' → mit|mitigate|<package_name>."""
    from .posture import ranking_row
    f = ranking_row(ctx, finding_key)[0] if finding_key else None
    if f is None:
        return None, None
    route, prio = f.get("route"), f.get("alert_priority")
    if route == "upgrade" and f.get("fix_key"):
        return f"fix|{f.get('fix_key')}", prio
    if route == "mitigate":
        return f"mit|mitigate|{f.get('package_name')}", prio
    return None, prio


def purl_parts(purl: str | None) -> tuple[str | None, str | None]:
    """pkg:<type>[/<namespace>]/<name> → (ecosystem, package name) as the ranking keys them (posture_fixes.fix_key
    = <ecosystem>|<package_name>): a distro type keeps its namespace (pkg:deb/debian/zlib → deb/debian, zlib); any
    other type is the ecosystem alone and the rest is the name (pkg:npm/%40angular/core → npm, @angular/core).
    (None, None) when it does not parse. ⚠️ The registry normalises pypi names (lower case, [-_.] → -), so a purl can
    miss a row the stored facts would find: the facts are read first (see _entry_root)."""
    s = unquote(str(purl or "")).split("?")[0].split("#")[0]
    if not s.startswith("pkg:"):
        return None, None
    parts = [x for x in s[4:].split("/") if x]
    if parts and parts[0] in _DISTROS:
        return (f"{parts[0]}/{parts[1]}", "/".join(parts[2:])) if len(parts) >= 3 else (None, None)
    return (parts[0], "/".join(parts[1:])) if len(parts) >= 2 else (None, None)


def _entry_root(ctx, a, alert_id: str, prio) -> dict | None:
    """An Inbox entry root for one package (`upgrade.package.v1|<purl>` or `mitigate.package.v1|<purl>`, its
    rule_run_results empty) → the ranking's fix or mitigation entry for that package, or None when it is no such root.
    The package is read from the root's stored identity facts (remediation_facts: ecosystem, package_name), else
    parsed from the purl. The ranking row must exist: none → unmodelled, with the key that was looked for."""
    gk = a.get("group_key") or ""
    policy, _, ident = gk.partition("|")
    item_type = ROOT_POLICIES.get(policy)
    if not item_type:
        return None
    facts = a.get("remediation_facts") or {}
    eco, name = facts.get("ecosystem"), facts.get("package_name")
    via = "remediation_facts"
    if not (eco and name):
        eco, name = purl_parts(facts.get("purl") or ident)
        via = "purl"
    base = {"vuln_id": None, "via": via, "entry_key": gk}
    if not (eco and name):
        return {**base, "item_type": "unmodelled", "decision_key": f"alert|{alert_id}", "priority": prio,
                "reason": "an Inbox entry whose package cannot be read from its facts"}
    if item_type == "fix_entry":
        key = f"{eco}|{name}"
        row = ctx.row("posture_fixes", key)
        if row is None:
            return {**base, "item_type": "unmodelled", "decision_key": f"alert|{alert_id}", "priority": prio,
                    "reason": f"an Inbox entry for the package {name} ({eco}); the ranking holds no upgrade for it"}
        return {**base, "item_type": "fix_entry", "fix_key": key, "decision_key": f"fix|{key}",
                "priority": prio if prio is not None else row.get("alert_priority")}
    rows = sorted(ctx.select("posture_mitigations", [["ecosystem", "=", eco], ["package_name", "=", name]]),
                  key=lambda r: str(r.key))
    if not rows:
        return {**base, "item_type": "unmodelled", "decision_key": f"alert|{alert_id}", "priority": prio,
                "reason": f"an Inbox entry for the package {name} ({eco}); the ranking holds no mitigation for it"}
    return {**base, "item_type": "mitigation_entry", "mitigation_key": rows[0].key,
            "decision_key": f"mit|{rows[0].key}",
            "priority": prio if prio is not None else rows[0].get("alert_priority")}


def _code_finding(ctx, fk: str, prio, via: str, vuln_id: str | None = None) -> dict:
    """A code finding (SAST, IaC, secrets): decided on its own; its decision is its finding key."""
    _, fprio = _covering_entry(ctx, fk)
    return {"item_type": "code_finding", "via": via, "vuln_id": vuln_id, "finding_key": fk, "decision_key": fk,
            "priority": prio if prio is not None else fprio}


def _classify(ctx, alert_id: str) -> dict:
    """Which proof model an alert gets, and which decision it belongs to (first match wins):
    a parsable Container Analysis id, or a posture finding with a Container Analysis report → vuln_in_image;
    a posture finding `code|…` → code_finding; fix_key → fix_entry; mitigation_key → mitigation_entry;
    group_key posture|threat|… → threat_signal; group_key posture|… → posture_summary; an Inbox entry root
    upgrade.package.v1|<purl> / mitigate.package.v1|<purl> → fix_entry / mitigation_entry (see _entry_root);
    a scanner id whose report belongs to a `code|…` posture finding → code_finding; anything else → unmodelled.
    decision_key: the covering upgrade/mitigation entry of a finding, else cve|<cve>|<package>; a code finding's
    own key; fix|<fix_key>; mit|<mitigation_key>; the group_key; alert|<alert_id>.
    priority: the alert's alert_priority, else the finding's (or the entry row's).
    v2 (2026-10-07): code_finding and Inbox entry roots. Only branches that returned unmodelled in v1 changed.
    v3 (APP_PROFILES_SPEC): a group root (`group_role` root, with a group_key no earlier branch claimed)
    → group_check. Only the final unmodelled return changed.
    v4: a ROW of such a group (`group_role` member, owned by a root via `parent_alert_id`, carrying no finding id) →
    group_member, whose proof draws that row's own path (claims/group_member.py). Only the final unmodelled return
    changed, and the decision_key stays `alert|<id>`. MEASURED 2026-10-10 on localhost: cmdb_visibility rows only (T3 233;
    T1 and T2 VM members carry a finding id or a posture group_key, so earlier branches claim them first)."""
    a = ctx.row("api.alert", alert_id)
    if a is None:
        return {"item_type": "unmodelled", "decision_key": f"alert|{alert_id}", "vuln_id": None, "priority": None}
    # The number the Inbox sorts by (`alerts.triage_priority`: the ranking's, or the one the triage agent / a person / a
    # code measurement set) wins, so Home and the Inbox read the same urgency; the finding's own alert_priority is the fallback.
    prio = _triage_priority(a)
    if prio is None:
        prio = a.get("rule_run_results.0.alert_priority")
    vid = a.get("rule_run_results.0.torana_vulnerability_id")
    cve = a.get("rule_run_results.0.cve_id")
    parsed = parse_vuln_id(vid, cve)
    if parsed:
        rep = ctx.one("posture_scanner_reports", [["report_id", "=", vid]])
        cover, fprio = _covering_entry(ctx, rep.get("finding_key") if rep else None)
        return {"item_type": "vuln_in_image", "via": "scanner_id", "vuln_id": vid,
                "decision_key": cover or f"cve|{parsed['cve']}|{parsed['package']}",
                "priority": prio if prio is not None else fprio}
    fk = a.get("rule_run_results.0.finding_key")
    if fk and fk.startswith("code|"):
        return _code_finding(ctx, fk, prio, "posture_finding")
    if fk:
        reports = ctx.select("posture_scanner_reports", [["finding_key", "=", fk], ["scanner", "=", "gcp_container_analysis"]])
        cve = cve or fk.split("|")[0]
        rep = next((r for r in reports if parse_vuln_id(r.get("report_id"), cve)), None)
        cover, fprio = _covering_entry(ctx, fk)
        if rep is None and is_image_item_key(fk):
            # v8 (AC, image rebuild carry): a `path` survivor's key is the ITEM (problem, image path), which names no
            # build, so no report and no ranking row carry it. It is proved through its group's representative row.
            item = _image_item(ctx, alert_id, fk, cve, prio)
            if item is not None:
                return item
        if rep is not None:
            parsed = parse_vuln_id(rep.get("report_id"), cve)
            return {"item_type": "vuln_in_image", "via": "posture_finding", "vuln_id": rep.get("report_id"),
                    "finding_key": fk, "report_key": rep.key,
                    "decision_key": cover or f"cve|{parsed['cve']}|{parsed['package']}",
                    "priority": prio if prio is not None else fprio}
        return {"item_type": "unmodelled", "vuln_id": None, "finding_key": fk,
                "decision_key": cover or f"alert|{alert_id}", "priority": prio if prio is not None else fprio}
    fix_key = a.get("rule_run_results.0.fix_key")
    if fix_key:
        return {"item_type": "fix_entry", "fix_key": fix_key, "decision_key": f"fix|{fix_key}", "priority": prio}
    mit_key = a.get("rule_run_results.0.mitigation_key")
    if mit_key:
        return {"item_type": "mitigation_entry", "mitigation_key": mit_key, "decision_key": f"mit|{mit_key}", "priority": prio}
    gk = a.get("rule_run_results.0.group_key") or ""
    if gk.startswith("posture|threat|"):
        return {"item_type": "threat_signal", "group_key": gk, "decision_key": gk, "priority": prio}
    if gk.startswith("posture|"):
        return {"item_type": "posture_summary", "group_key": gk, "decision_key": gk, "priority": prio}
    root = _entry_root(ctx, a, alert_id, prio)
    if root is not None:
        return root
    if vid:
        rep = next((r for r in sorted(ctx.select("posture_scanner_reports", [["report_id", "=", vid]]),
                                      key=lambda r: str(r.key))
                    if str(r.get("finding_key") or "").startswith("code|")), None)
        if rep is not None:
            return _code_finding(ctx, rep.get("finding_key"), prio, "scanner_id", vuln_id=vid)
    if gk:
        # v3: an alert that stands for a group its rule declared (DF rule.group_role='root'). Reached only by a
        # group_key no earlier branch claimed. MEASURED 2026-10-09: cmdb_visibility alone (APP_PROFILES_SPEC § 2.6), so
        # no stored VM record reads `group_role` on replay. A MEMBER keeps today's result exactly.
        if a.get("group_role") == "root":
            return {"item_type": "group_check", "group_key": gk, "decision_key": gk, "vuln_id": None, "priority": prio}
        if a.get("group_role") == "member" and not vid and _parent(a):
            return {"item_type": "group_member", "group_key": gk, "decision_key": f"alert|{alert_id}", "vuln_id": None,
                    "priority": prio}
    return {"item_type": "unmodelled", "vuln_id": vid or None, "decision_key": f"alert|{alert_id}", "priority": prio}


def is_image_item_key(fk: str | None) -> bool:
    """An image ITEM key (PDT posture_findings.item_key = `<problem>|image:<path>`): it names the image path and no
    build. A `digest` key ends `|image@sha256:…`. ⛔ The shape is the guard: only such a key reads `item_key` /
    `is_item_row`, so no read touches those columns where the datalake does not have them yet."""
    s = str(fk or "")
    tail = s.rsplit("|", 1)[-1] if "|" in s else ""
    return tail.startswith("image:") and "@" not in tail


def _image_item(ctx, alert_id: str, item_key: str, cve: str | None, prio) -> dict | None:
    """v8 (AC, PK IMAGE_REBUILD_CARRY_NOTE rev 2, risk 12): an alert whose finding key is an image ITEM key
    (`posture_findings.item_key`, one item per problem and image path) → its group's representative row
    (`is_item_row`), classified like the finding that row is: its Container Analysis report, its covering entry and
    its priority. `finding_key` is the representative's (the row every later claim reads); `item_key` is the alert's.
    None when no representative row exists (the caller returns v7's unmodelled answer).
    Path guard: a record captured before v8 never read this select, so it replays as v7 answered (None)."""
    try:
        rows = ctx.select("posture_findings", [["item_key", "=", item_key], ["is_item_row", "=", True]])
    except NotCaptured:
        return None
    rows = sorted(rows, key=lambda r: str(r.key))
    if not rows:
        return None
    fk = str(rows[0].key)
    cve = cve or fk.split("|")[0]
    reports = ctx.select("posture_scanner_reports", [["finding_key", "=", fk], ["scanner", "=", "gcp_container_analysis"]])
    rep = next((r for r in reports if parse_vuln_id(r.get("report_id"), cve)), None)
    cover, fprio = _covering_entry(ctx, fk)
    priority = prio if prio is not None else fprio
    if rep is None:
        return {"item_type": "unmodelled", "vuln_id": None, "finding_key": fk, "item_key": item_key,
                "decision_key": cover or f"alert|{alert_id}", "priority": priority}
    parsed = parse_vuln_id(rep.get("report_id"), cve)
    return {"item_type": "vuln_in_image", "via": "image_item", "vuln_id": rep.get("report_id"),
            "finding_key": fk, "item_key": item_key, "report_key": rep.key,
            "decision_key": cover or f"cve|{parsed['cve']}|{parsed['package']}", "priority": priority}


def _parent(a) -> str | None:
    """The root a member belongs to. Path guard: a record captured under v3 never read `parent_alert_id`, so it replays as
    v3 did (unmodelled, `rule_changed alerts.classify 3→4`) instead of raising NotCaptured."""
    try:
        return a.get("parent_alert_id")
    except NotCaptured:
        return None


def _triage_priority(a):
    """`alerts.triage_priority` (read since 2026-10-14). Path guard: a record captured before then never read it, so it
    replays with the matched row's alert_priority, as it was built, instead of raising NotCaptured."""
    try:
        return a.get("triage_priority")
    except NotCaptured:
        return None


#: v10: the stored spellings → the vocabulary ranking|agent|person|reachability (PDF migration 128).
_SOURCE_VOCAB = {"rule": "ranking", "user": "person"}


def _priority_source(stored, priority):
    src = str(stored).strip() if stored else ""
    if src:
        return _SOURCE_VOCAB.get(src, src)
    return "ranking" if priority is not None else None


def _v5_keys(a) -> dict:
    band = a.get("rule_run_results.0.tier_line") or a.get("rule_run_results.0.reason_label")
    return {"band": str(band).strip() if band else None,
            "priority_source": _priority_source(a.get("triage_priority_source"), a.get("triage_priority")),
            "priority_reason": _priority_reason(a),
            "priority_reason_by": _priority_reason_by(a)}


def _priority_reason(a):
    """v5 (f57a4e0) read `priority_reason` ONLY while triage_priority_source == "agent"; v6 reads it always. Path guard:
    a non-agent record captured under v5 never read it, and v5 answered None for it, so None is that record's own output
    (and the rest of the v5 group still replays instead of being dropped with it)."""
    try:
        return a.get("priority_reason") or None
    except NotCaptured:
        return None


def _priority_reason_by(a):
    """v8: who wrote `priority_reason` ('agent' | 'ranking'). A record captured before v8 has no such cell: None is its own output, and Home
    prints None as "Triage agent:", which is what that record always said."""
    try:
        return a.get("priority_reason_by") or None
    except NotCaptured:
        return None


def _v6_keys(a) -> dict:
    reach = {k: a.get(f"reachability.{k}") for k in ("verdict", "commit", "entry_points_considered", "entry_point_kind", "reason",
                                                     "starts_at_module_load")}
    return {"triage": {"verdict": a.get("triage_verdict"), "source": a.get("verdict_source"), "person": a.get("verdict_actor_name"),
                       "root": a.get("group_role") == "root", "confirmed_by_triage": a.get("members_confirmed_by_triage"),
                       "open": a.get("members_open")},
            "reachability": reach if reach["verdict"] else None,
            "known_exploited_cves": a.get("known_exploited_cves")}


def _captured_or_none(build, a) -> dict | None:
    """Path guard for a version's added keys, as a group: a record captured before that version never read them, so it
    replays WITHOUT them (its own output, exactly) instead of raising NotCaptured or showing None as if measured."""
    try:
        return build(a)
    except NotCaptured:
        return None


@rule("alerts.classify", 10)
def classify(ctx, alert_id: str) -> dict:
    """Which proof model an alert gets, and which decision it belongs to: `_classify` (its docstring above is the contract for item_type,
    decision_key and priority; v1 to v4 are its history).
    v5 (Home's `why`): the same outputs plus `band` (the ranking's own wording for the band the item sits in: the row's tier_line, else its
    reason_label; None when the row carries neither), `priority_source` ('ranking' · 'agent' · 'person' · 'reachability'; v10 maps the stored 'rule'/'user' to ranking/person; None when the alert carries no
    priority) and `priority_reason` (the triage agent's sentence for the number the item has now, as the alert response states it).
    v6: `triage` (who decided the verdict: `verdict`, `source` (triage_agent · person · ranking_rules), `person`, and for an entry the open members
    the triage agent confirmed: `confirmed_by_triage` of `open`), `reachability` (a code finding's newest measured fact, as the alert response
    carries it) and `known_exploited_cves` (an entry's distinct known-exploited CVEs). Only keys were added; each is None where the alert carries none.
    v7: path guards only (`_triage_priority`, `_captured_or_none`, `_priority_reason`), so a record captured before v5 / v6 / the triage_priority read
    replays with its own outputs instead of raising NotCaptured. A live read never raises, so live outputs are v6's exactly.
    v8 (AC): an image ITEM key (a `path` survivor, `_image_item`) is proved through its group's representative row. Only a
    branch that returned unmodelled in v7 changed (a finding key naming no build, with no report of its own).
    v8 (DS3, made beside AC's v8): `priority_reason_by` ('agent' · 'ranking'): who wrote `priority_reason`, because a rule-held item now carries the ranking's reason (DS3).
    Path-guarded (`_priority_reason_by`): a record captured before it replays without it.
    v9: both v8 changes together (the EPR integration onto main); no new behaviour."""
    out = _classify(ctx, alert_id)
    a = ctx.row("api.alert", alert_id)
    if a is not None:
        v5 = _captured_or_none(_v5_keys, a)
        if v5 is not None:
            out = {**out, **v5}
            out = {**out, **(_captured_or_none(_v6_keys, a) or {})}
    return out


@rule("alerts.target", 2)
def target(ctx, alert_id: str) -> dict:
    """What the alert is about: the finding id it carries, split into image, CVE and package.
    The id comes from alerts.classify, so a posture finding reaches the image model through its Container
    Analysis report. Modelled only when the id is gcp_ca_<image:…>_<CVE id>_<pkg:…@version>."""
    k = ctx.call("alerts.classify", alert_id=alert_id)
    vid = k["vuln_id"] or ""
    a = ctx.row("api.alert", alert_id)
    cve = a.get("rule_run_results.0.cve_id") if a else None
    if not cve and k.get("finding_key"):
        cve = k["finding_key"].split("|")[0]
    parsed = parse_vuln_id(vid, cve) if k["item_type"] == "vuln_in_image" else None
    if not parsed:
        return {"item_type": "unmodelled", "vuln_id": vid or None}
    return {"item_type": "vuln_in_image", "vuln_id": vid, **parsed}


@rule("alerts.is_stale", 2)
def is_stale(ctx, alert_id: str) -> dict:
    """Is the alert about the image that runs now?
    stale = the alert's image differs from the service's running image, the alert's image is not deployed,
    and no live (not deleted) finding row for this CVE remains on it.
    v2 (BF2): the alert's image is read as its LOGICAL image (`images.logical_image`: a member manifest stands for its
    index, the one row explore_images keeps for a multi-arch image), and live finding rows count under either key.
    An image is not stale while it is ANY of the running images (`images.service_of` v4 `running_images`: a rollout
    runs two). A key with no index reads exactly as v1."""
    t = ctx.call("alerts.target", alert_id=alert_id)
    img, cve = t["image"], t["cve"]
    svc = ctx.call("images.service_of", image=img)
    run_img = svc["running_image"]
    running = set(svc.get("running_images") or ([run_img] if run_img else []))
    li = ctx.call("images.logical_image", image=img)["image"] if img else img
    x = ctx.one("explore_images", [["image_key", "=", li]])
    deployed = x.get("is_deployed") if x else None
    findings = x.get("finding_count") if x else None
    keys = ["=", img] if li == img else ["in", [img, li]]
    live = ctx.select("vulnerabilities", [["torana_artifact_id", *keys], ["cve_id", "=", cve], ["is_deleted", "=", False]])
    run_live = ctx.select("vulnerabilities", [["torana_artifact_id", "=", run_img], ["cve_id", "=", cve], ["is_deleted", "=", False]]) if run_img else []
    stale = bool(run_img) and not ({img, li} & running) and str(deployed).lower() == "false" and not live
    return {"stale": stale, "alert_image_deployed": deployed, "alert_image_findings": findings,
            "alert_image_live_rows": len(live), "running_image_live_rows": len(run_live),
            "running_vuln_id": run_live[0].key if run_live else None}


def _rule_severity_declared(a):
    """Path guard: None (unknown, so the stored severity stands) for a record captured before severity_sources v2 read it."""
    try:
        return a.get("rule_severity_declared")
    except NotCaptured:
        return None


@rule("alerts.severity_sources", 3)
def severity_sources(ctx, alert_id: str, vuln_id: str | None) -> dict:
    """Where each severity on the item comes from. mismatch = the rule's severity and the finding's are both stated and differ.

    v2: a rule that declares NO severity has none to report (`rule` is None). `alerts.severity` is stored NOT NULL, so the item
    carries a placeholder 'low' for it, and v1 reported that as the rule's own and called it a mismatch with the finding.
    v3: path guard only (`_rule_severity_declared`): a record captured under v1 never read the flag, so it replays as v1 did."""
    a = ctx.row("api.alert", alert_id)
    if not a:
        return {"rule": None, "finding": None, "scanner": None, "mismatch": False}
    v = ctx.row("vulnerabilities", vuln_id) if vuln_id else None
    rule_sev, finding_sev = a.get("severity"), a.get("finding_severity")
    if _rule_severity_declared(a) is False:
        rule_sev = None
    return {"rule": rule_sev, "finding": finding_sev, "scanner": v.get("severity") if v else None,
            "mismatch": bool(rule_sev and finding_sev and str(rule_sev).lower() != str(finding_sev).lower())}


@rule("alerts.triage_state", 1)
def triage_state(ctx, alert_id: str) -> dict:
    """Has anyone judged the item? unjudged = triage failed and no verdict was recorded."""
    a = ctx.row("api.alert", alert_id)
    if not a:
        return {"failure_state": None, "verdict": None, "unjudged": False}
    state, verdict = a.get("triage_failure.state"), a.get("triage_verdict")
    return {"failure_state": state, "verdict": verdict, "unjudged": state == "failed" and verdict is None}


@rule("alerts.parent_link", 1)
def parent_link(ctx, alert_id: str, finding_key: str | None) -> dict:
    """Is the alert attached to the ranking entry that covers its finding?
    missing_link = an entry lists the finding while the alert's parent_alert_id is null."""
    a = ctx.row("api.alert", alert_id)
    if not a:
        return {"parent": None, "linked": False, "missing_link": False}
    parent = a.get("parent_alert_id")
    entry = ctx.call("posture.entry_for_finding", finding_key=finding_key) if finding_key else None
    has_entry = bool(entry and entry["entry_key"])
    return {"parent": parent, "linked": parent is not None, "missing_link": has_entry and parent is None}


@rule("alerts.age", 1)
def age(ctx, alert_id: str) -> dict:
    """Hours the alert has been open at build time (build clock minus created_at)."""
    from datetime import datetime
    a = ctx.row("api.alert", alert_id)
    if not a:
        return {"hours": None}
    created = a.get("created_at")
    if not created:
        return {"hours": None}
    now = datetime.fromisoformat(ctx.now.replace("Z", "+00:00"))
    return {"hours": int((now - datetime.fromisoformat(created.replace("Z", "+00:00"))).total_seconds() // 3600)}
