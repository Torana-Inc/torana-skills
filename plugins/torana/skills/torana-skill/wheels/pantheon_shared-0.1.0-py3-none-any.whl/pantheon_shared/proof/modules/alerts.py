"""alerts — what an Inbox item is about, and whether that is still true.

Source: detection-framework alerts (read through the platform API, addressed by alert id).
"""
from urllib.parse import unquote

from ..core.engine import NotCaptured, rule

#: Inbox entry roots (pantheon-detection-framework services/entries.py) are keyed `<policy>|<identity>`
#: (services/remediation_registry.py `entry_key`); a package policy's identity is the purl without its version.
ROOT_POLICIES = {"upgrade.package.v1": "fix_entry", "mitigate.package.v1": "mitigation_entry"}
_DISTROS = ("apk", "deb", "rpm")

def parse_vuln_id(vid: str | None, cve: str | None) -> dict | None:
    """gcp_ca_<image:…>_<CVE id>_<pkg:…@version> split into its parts; None when it does not parse."""
    vid = vid or ""
    if not vid.startswith("gcp_ca_") or not cve or f"_{cve}_" not in vid:
        return None
    image, purl = vid[len("gcp_ca_"):].split(f"_{cve}_", 1)
    if not image.startswith("image:") or not purl.startswith("pkg:") or "@" not in purl:
        return None
    return {"image": image, "cve": cve, "purl": purl,
            "package": purl.split("/")[-1].split("@")[0], "version": purl.split("@", 1)[1]}


def _covering_entry(ctx, finding_key: str | None) -> tuple[str | None, object]:
    """The ranking entry a finding is worked under, as a decision key, plus the finding's own priority.
    route 'upgrade' with a fix_key → fix|<fix_key>; route 'mitigate' → mit|mitigate|<package_name>."""
    f = ctx.row("posture_findings", finding_key) if finding_key else None
    if f is None:
        return None, None
    route, prio = f.get("route"), f.get("alert_priority")
    if route == "upgrade" and f.get("fix_key"):
        return f"fix|{f.get('fix_key')}", prio
    if route == "mitigate":
        return f"mit|mitigate|{f.get('package_name')}", prio
    return None, prio


def purl_parts(purl: str | None) -> tuple[str | None, str | None]:
    """pkg:<type>[/<namespace>]/<name> → (ecosystem, package name) as the ranking keys them (posture_fixes.fix_key
    = <ecosystem>|<package_name>): a distro type keeps its namespace (pkg:deb/debian/zlib → deb/debian, zlib); any
    other type is the ecosystem alone and the rest is the name (pkg:npm/%40angular/core → npm, @angular/core).
    (None, None) when it does not parse. ⚠️ The registry normalises pypi names (lower case, [-_.] → -), so a purl can
    miss a row the stored facts would find: the facts are read first (see _entry_root)."""
    s = unquote(str(purl or "")).split("?")[0].split("#")[0]
    if not s.startswith("pkg:"):
        return None, None
    parts = [x for x in s[4:].split("/") if x]
    if parts and parts[0] in _DISTROS:
        return (f"{parts[0]}/{parts[1]}", "/".join(parts[2:])) if len(parts) >= 3 else (None, None)
    return (parts[0], "/".join(parts[1:])) if len(parts) >= 2 else (None, None)


def _entry_root(ctx, a, alert_id: str, prio) -> dict | None:
    """An Inbox entry root for one package (`upgrade.package.v1|<purl>` or `mitigate.package.v1|<purl>`, its
    rule_run_results empty) → the ranking's fix or mitigation entry for that package, or None when it is no such root.
    The package is read from the root's stored identity facts (remediation_facts: ecosystem, package_name), else
    parsed from the purl. The ranking row must exist: none → unmodelled, with the key that was looked for."""
    gk = a.get("group_key") or ""
    policy, _, ident = gk.partition("|")
    item_type = ROOT_POLICIES.get(policy)
    if not item_type:
        return None
    facts = a.get("remediation_facts") or {}
    eco, name = facts.get("ecosystem"), facts.get("package_name")
    via = "remediation_facts"
    if not (eco and name):
        eco, name = purl_parts(facts.get("purl") or ident)
        via = "purl"
    base = {"vuln_id": None, "via": via, "entry_key": gk}
    if not (eco and name):
        return {**base, "item_type": "unmodelled", "decision_key": f"alert|{alert_id}", "priority": prio,
                "reason": "an Inbox entry whose package cannot be read from its facts"}
    if item_type == "fix_entry":
        key = f"{eco}|{name}"
        row = ctx.row("posture_fixes", key)
        if row is None:
            return {**base, "item_type": "unmodelled", "decision_key": f"alert|{alert_id}", "priority": prio,
                    "reason": f"an Inbox entry for the package {name} ({eco}); the ranking holds no upgrade for it"}
        return {**base, "item_type": "fix_entry", "fix_key": key, "decision_key": f"fix|{key}",
                "priority": prio if prio is not None else row.get("alert_priority")}
    rows = sorted(ctx.select("posture_mitigations", [["ecosystem", "=", eco], ["package_name", "=", name]]),
                  key=lambda r: str(r.key))
    if not rows:
        return {**base, "item_type": "unmodelled", "decision_key": f"alert|{alert_id}", "priority": prio,
                "reason": f"an Inbox entry for the package {name} ({eco}); the ranking holds no mitigation for it"}
    return {**base, "item_type": "mitigation_entry", "mitigation_key": rows[0].key,
            "decision_key": f"mit|{rows[0].key}",
            "priority": prio if prio is not None else rows[0].get("alert_priority")}


def _code_finding(ctx, fk: str, prio, via: str, vuln_id: str | None = None) -> dict:
    """A code finding (SAST, IaC, secrets): decided on its own; its decision is its finding key."""
    _, fprio = _covering_entry(ctx, fk)
    return {"item_type": "code_finding", "via": via, "vuln_id": vuln_id, "finding_key": fk, "decision_key": fk,
            "priority": prio if prio is not None else fprio}


@rule("alerts.classify", 4)
def classify(ctx, alert_id: str) -> dict:
    """Which proof model an alert gets, and which decision it belongs to (first match wins):
    a parsable Container Analysis id, or a posture finding with a Container Analysis report → vuln_in_image;
    a posture finding `code|…` → code_finding; fix_key → fix_entry; mitigation_key → mitigation_entry;
    group_key posture|threat|… → threat_signal; group_key posture|… → posture_summary; an Inbox entry root
    upgrade.package.v1|<purl> / mitigate.package.v1|<purl> → fix_entry / mitigation_entry (see _entry_root);
    a scanner id whose report belongs to a `code|…` posture finding → code_finding; anything else → unmodelled.
    decision_key: the covering upgrade/mitigation entry of a finding, else cve|<cve>|<package>; a code finding's
    own key; fix|<fix_key>; mit|<mitigation_key>; the group_key; alert|<alert_id>.
    priority: the alert's alert_priority, else the finding's (or the entry row's).
    v2 (2026-10-07): code_finding and Inbox entry roots. Only branches that returned unmodelled in v1 changed.
    v3 (APP_PROFILES_SPEC): a group root (`group_role` root, with a group_key no earlier branch claimed)
    → group_check. Only the final unmodelled return changed.
    v4: a ROW of such a group (`group_role` member, owned by a root via `parent_alert_id`, carrying no finding id) →
    group_member, whose proof draws that row's own path (claims/group_member.py). Only the final unmodelled return
    changed, and the decision_key stays `alert|<id>`. MEASURED 2026-10-10 on localhost: cmdb_visibility rows only (T3 233;
    T1 and T2 VM members carry a finding id or a posture group_key, so earlier branches claim them first)."""
    a = ctx.row("api.alert", alert_id)
    if a is None:
        return {"item_type": "unmodelled", "decision_key": f"alert|{alert_id}", "vuln_id": None, "priority": None}
    prio = a.get("rule_run_results.0.alert_priority")
    vid = a.get("rule_run_results.0.torana_vulnerability_id")
    cve = a.get("rule_run_results.0.cve_id")
    parsed = parse_vuln_id(vid, cve)
    if parsed:
        rep = ctx.one("posture_scanner_reports", [["report_id", "=", vid]])
        cover, fprio = _covering_entry(ctx, rep.get("finding_key") if rep else None)
        return {"item_type": "vuln_in_image", "via": "scanner_id", "vuln_id": vid,
                "decision_key": cover or f"cve|{parsed['cve']}|{parsed['package']}",
                "priority": prio if prio is not None else fprio}
    fk = a.get("rule_run_results.0.finding_key")
    if fk and fk.startswith("code|"):
        return _code_finding(ctx, fk, prio, "posture_finding")
    if fk:
        reports = ctx.select("posture_scanner_reports", [["finding_key", "=", fk], ["scanner", "=", "gcp_container_analysis"]])
        cve = cve or fk.split("|")[0]
        rep = next((r for r in reports if parse_vuln_id(r.get("report_id"), cve)), None)
        cover, fprio = _covering_entry(ctx, fk)
        if rep is not None:
            parsed = parse_vuln_id(rep.get("report_id"), cve)
            return {"item_type": "vuln_in_image", "via": "posture_finding", "vuln_id": rep.get("report_id"),
                    "finding_key": fk, "report_key": rep.key,
                    "decision_key": cover or f"cve|{parsed['cve']}|{parsed['package']}",
                    "priority": prio if prio is not None else fprio}
        return {"item_type": "unmodelled", "vuln_id": None, "finding_key": fk,
                "decision_key": cover or f"alert|{alert_id}", "priority": prio if prio is not None else fprio}
    fix_key = a.get("rule_run_results.0.fix_key")
    if fix_key:
        return {"item_type": "fix_entry", "fix_key": fix_key, "decision_key": f"fix|{fix_key}", "priority": prio}
    mit_key = a.get("rule_run_results.0.mitigation_key")
    if mit_key:
        return {"item_type": "mitigation_entry", "mitigation_key": mit_key, "decision_key": f"mit|{mit_key}", "priority": prio}
    gk = a.get("rule_run_results.0.group_key") or ""
    if gk.startswith("posture|threat|"):
        return {"item_type": "threat_signal", "group_key": gk, "decision_key": gk, "priority": prio}
    if gk.startswith("posture|"):
        return {"item_type": "posture_summary", "group_key": gk, "decision_key": gk, "priority": prio}
    root = _entry_root(ctx, a, alert_id, prio)
    if root is not None:
        return root
    if vid:
        rep = next((r for r in sorted(ctx.select("posture_scanner_reports", [["report_id", "=", vid]]),
                                      key=lambda r: str(r.key))
                    if str(r.get("finding_key") or "").startswith("code|")), None)
        if rep is not None:
            return _code_finding(ctx, rep.get("finding_key"), prio, "scanner_id", vuln_id=vid)
    if gk:
        # v3: an alert that stands for a group its rule declared (DF rule.group_role='root'). Reached only by a
        # group_key no earlier branch claimed. MEASURED 2026-10-09: cmdb_visibility alone (APP_PROFILES_SPEC § 2.6), so
        # no stored VM record reads `group_role` on replay. A MEMBER keeps today's result exactly.
        if a.get("group_role") == "root":
            return {"item_type": "group_check", "group_key": gk, "decision_key": gk, "vuln_id": None, "priority": prio}
        if a.get("group_role") == "member" and not vid and _parent(a):
            return {"item_type": "group_member", "group_key": gk, "decision_key": f"alert|{alert_id}", "vuln_id": None,
                    "priority": prio}
    return {"item_type": "unmodelled", "vuln_id": vid or None, "decision_key": f"alert|{alert_id}", "priority": prio}


def _parent(a) -> str | None:
    """The root a member belongs to. Path guard: a record captured under v3 never read `parent_alert_id`, so it replays as
    v3 did (unmodelled, `rule_changed alerts.classify 3→4`) instead of raising NotCaptured."""
    try:
        return a.get("parent_alert_id")
    except NotCaptured:
        return None


@rule("alerts.target", 2)
def target(ctx, alert_id: str) -> dict:
    """What the alert is about: the finding id it carries, split into image, CVE and package.
    The id comes from alerts.classify, so a posture finding reaches the image model through its Container
    Analysis report. Modelled only when the id is gcp_ca_<image:…>_<CVE id>_<pkg:…@version>."""
    k = ctx.call("alerts.classify", alert_id=alert_id)
    vid = k["vuln_id"] or ""
    a = ctx.row("api.alert", alert_id)
    cve = a.get("rule_run_results.0.cve_id") if a else None
    if not cve and k.get("finding_key"):
        cve = k["finding_key"].split("|")[0]
    parsed = parse_vuln_id(vid, cve) if k["item_type"] == "vuln_in_image" else None
    if not parsed:
        return {"item_type": "unmodelled", "vuln_id": vid or None}
    return {"item_type": "vuln_in_image", "vuln_id": vid, **parsed}


@rule("alerts.is_stale", 1)
def is_stale(ctx, alert_id: str) -> dict:
    """Is the alert about the image that runs now?
    stale = the alert's image differs from the service's running image, the alert's image is not deployed,
    and no live (not deleted) finding row for this CVE remains on it."""
    t = ctx.call("alerts.target", alert_id=alert_id)
    img, cve = t["image"], t["cve"]
    svc = ctx.call("images.service_of", image=img)
    run_img = svc["running_image"]
    x = ctx.one("explore_images", [["image_key", "=", img]])
    deployed = x.get("is_deployed") if x else None
    findings = x.get("finding_count") if x else None
    live = ctx.select("vulnerabilities", [["torana_artifact_id", "=", img], ["cve_id", "=", cve], ["is_deleted", "=", False]])
    run_live = ctx.select("vulnerabilities", [["torana_artifact_id", "=", run_img], ["cve_id", "=", cve], ["is_deleted", "=", False]]) if run_img else []
    stale = bool(run_img) and img != run_img and str(deployed).lower() == "false" and not live
    return {"stale": stale, "alert_image_deployed": deployed, "alert_image_findings": findings,
            "alert_image_live_rows": len(live), "running_image_live_rows": len(run_live),
            "running_vuln_id": run_live[0].key if run_live else None}


@rule("alerts.severity_sources", 1)
def severity_sources(ctx, alert_id: str, vuln_id: str | None) -> dict:
    """Where each severity on the item comes from. mismatch = the rule's severity differs from the finding's."""
    a = ctx.row("api.alert", alert_id)
    if not a:
        return {"rule": None, "finding": None, "scanner": None, "mismatch": False}
    v = ctx.row("vulnerabilities", vuln_id) if vuln_id else None
    rule_sev, finding_sev = a.get("severity"), a.get("finding_severity")
    return {"rule": rule_sev, "finding": finding_sev, "scanner": v.get("severity") if v else None,
            "mismatch": (rule_sev or "").lower() != (finding_sev or "").lower()}


@rule("alerts.triage_state", 1)
def triage_state(ctx, alert_id: str) -> dict:
    """Has anyone judged the item? unjudged = triage failed and no verdict was recorded."""
    a = ctx.row("api.alert", alert_id)
    if not a:
        return {"failure_state": None, "verdict": None, "unjudged": False}
    state, verdict = a.get("triage_failure.state"), a.get("triage_verdict")
    return {"failure_state": state, "verdict": verdict, "unjudged": state == "failed" and verdict is None}


@rule("alerts.parent_link", 1)
def parent_link(ctx, alert_id: str, finding_key: str | None) -> dict:
    """Is the alert attached to the ranking entry that covers its finding?
    missing_link = an entry lists the finding while the alert's parent_alert_id is null."""
    a = ctx.row("api.alert", alert_id)
    if not a:
        return {"parent": None, "linked": False, "missing_link": False}
    parent = a.get("parent_alert_id")
    entry = ctx.call("posture.entry_for_finding", finding_key=finding_key) if finding_key else None
    has_entry = bool(entry and entry["entry_key"])
    return {"parent": parent, "linked": parent is not None, "missing_link": has_entry and parent is None}


@rule("alerts.age", 1)
def age(ctx, alert_id: str) -> dict:
    """Hours the alert has been open at build time (build clock minus created_at)."""
    from datetime import datetime
    a = ctx.row("api.alert", alert_id)
    if not a:
        return {"hours": None}
    created = a.get("created_at")
    if not created:
        return {"hours": None}
    now = datetime.fromisoformat(ctx.now.replace("Z", "+00:00"))
    return {"hours": int((now - datetime.fromisoformat(created.replace("Z", "+00:00"))).total_seconds() // 3600)}
