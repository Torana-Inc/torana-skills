"""Item types: a fix entry (posture_fixes: one upgrade) and a mitigation entry (posture_mitigations: one package
with no fix). Spec: pantheon-fe/docs/AI_HOME_V2_HOME_PROOF_SPEC.md § 3.4.1. Graph: the fan-out of its members."""
from ..core.engine import NotCaptured
from ..core.render import render
from .alert_facts import O, R, title_and_sub
from .effort import effort_claims
from .vuln_in_image import claim

CODE = "code: claims.entries (template + rules)"


def _opt(row, col):
    """A column that a record built before it existed never read: None instead of NotCaptured. ⛔ Row has no
    `in`/`__contains__` (core/engine.Row), so presence is checked by READING through this guard, never by
    membership — `"col" in row` raises TypeError against a live Row and was how A2 first shipped broken."""
    try:
        return row.get(col)
    except NotCaptured:
        return None


def _still(drift, verb: str, noun: str) -> dict:
    state = drift["state"]
    template = {"same": "Yes: it still " + verb + " {now} finding{now?|s}.",
                "changed": "Changed: raised " + ("clearing" if verb == "clears" else "covering") + " {then}, now {now}.",
                "gone": "Gone: the " + noun + " no longer exists.",
                "unrecorded": "Yes, as far as is recorded: it " + verb + " {now} finding{now?|s} now; the alert recorded no "
                              "count when it was raised (an Inbox entry), so there is nothing to compare."}[state]
    return claim("still", "state", "Is this entry still as raised?", template,
                 {"then": O(drift, "then"), "now": O(drift, "now")}, today=CODE)


def _running(mem, row) -> dict:
    slots = {"found": O(mem, "found"), "listed": O(mem, "listed"), "imgs": R(row, "member_images")}
    if mem["checked"]:
        return claim("running", "deep", "How many still run?",
                     "{found} of {listed} listed member finding{listed?|s} are in the ranking, on {imgs} running image{imgs?|s}.",
                     slots, today=CODE)
    return claim("running", "deep", "How many still run?",
                 "{listed} listed member finding{listed?|s}, on {imgs} running image{imgs?|s}.", slots,
                 missing=("Not re-selected: {listed} keys exceed what one proof record can carry.",
                          {"listed": O(mem, "listed")}), today=CODE)


def _target(row) -> list[dict]:
    """The upgrade's ONE target and the versions it was chosen from (posture_fixes, computed by the transformer:
    entry_version = the highest fixed version the ENTRY'S OWN members name, compared as versions; entry_fixed_versions
    = every one of them, each once). When the versions have different forms the transformer cannot order them:
    entry_version is then the list, and the claim says so instead of naming a target.

    ⛔ A2: this read `recommended_version`, which the transformer computes over `scope='ranked'` — every ranked
    finding for the package, a WIDER set than the entry's members. The claim then named a version the entry's own
    title contradicted (3 of 74 fixes, measured on T2/ACME 2026-10-11: litellm 1.96.2 against a title of 1.88.6).
    `recommended_version` is still the relation's own answer for the package everywhere it is vulnerable, and where
    it needs a higher version than the members do, `wider_version` carries it and the third claim names it apart.
    ⚠️ A relation built before those columns existed has neither, so the column names are chosen by presence
    (the path guard replay needs) and such a record still reads `recommended_version`."""
    entry_cols = _opt(row, "entry_version") is not None
    ver = "entry_version" if entry_cols else "recommended_version"
    vers = "entry_fixed_versions" if entry_cols else "fixed_versions"
    unchecked = row.get("entry_version_order_not_checked" if entry_cols
                        else "recommended_version_order_not_checked") is True
    slots = {"pkg": R(row, "package_name"), "eco": R(row, "ecosystem"), "used": R(row, "versions_in_use"),
             "rec": R(row, ver)}
    out = [claim("what", "deep", "What is the change?",
                 "Upgrade {pkg} ({eco}) from {used} to the highest of {rec}; these versions have different forms, so "
                 "their order is not checked." if unchecked else "Upgrade {pkg} ({eco}) from {used} to {rec}.",
                 slots, today=CODE)]
    if row.get(vers) is not None:      # absent on a relation built before the column existed
        out.append(claim("versions", "tech", "Which fixed versions do its members name?",
                         "{fv}. No single highest is computed: the forms differ." if unchecked else
                         "{fv}. {rec} is the highest, so it clears every one.",
                         {"fv": R(row, vers), "rec": R(row, ver)}, today=CODE))
    if _opt(row, "wider_version") is not None and (_opt(row, "beyond_members") or 0) > 0:
        out.append(claim("wider", "tech", "Does a higher version clear more?",
                         "{wv} clears {n} more finding{n?|s} the ranking routed elsewhere, so they are not members of "
                         "this entry.",
                         {"wv": R(row, "wider_version"), "n": R(row, "beyond_members")}, today=CODE))
    return out


def _item(alert_id, type_, key_field, key, package, title, sub, chips, claims, graph) -> dict:
    return {"alert_id": alert_id, "type": type_, key_field: key, "package": package, "stale": False,
            "title": title, "chips": chips, "sub": sub, "claims": claims, "graph": graph}


def entry_graph(ctx, alert_id: str, key: str) -> dict:
    """The entry's path from platform rows. Its anchor is its own open linked members (`path.entry_members`); nothing is read
    from the ranking's member list."""
    from .path import entry_path
    return entry_path(ctx, ctx.call("path.entry_members", alert_id=alert_id), key)


def build_fix_claims(build, alert_id: str) -> dict:
    ctx = build.ctx()
    k = ctx.call("alerts.classify", alert_id=alert_id)
    key = k["fix_key"]
    drift = ctx.call("entries.drift", alert_id=alert_id, table="posture_fixes", key=key,
                     then_path="rule_run_results.0.findings_cleared", now_col="findings_cleared")
    row = ctx.row("posture_fixes", key)
    title, sub = title_and_sub(ctx, alert_id)
    claims = [_still(drift, "clears", "fix entry")]
    chips = [{"cls": "", "spans": render("fix entry", {})}]
    if row is not None:
        mem = ctx.call("entries.members", table="posture_fixes", key=key)
        claims += [
            *_target(row),
            claim("clears", "deep", "What does it clear?",
                  "{fc} finding{fc?|s} ({mf} at or above your floor), {cves} CVE{cves?|s}, on {img} image{img?|s} and {svc} service{svc?|s}.",
                  {"fc": R(row, "findings_cleared"), "mf": R(row, "member_findings"), "cves": R(row, "cves_cleared"),
                   "img": R(row, "images"), "svc": R(row, "services")}, today=CODE),
            _running(mem, row),
            claim("exposure", "deep", "Is it exposed?", "{x} internet-facing service{x?|s}.",
                  {"x": R(row, "internet_facing_services")}, today=CODE),
            claim("where", "fix", "Where is the change made?", "In {cm}; {copies} cop{copies?y|ies} to change.",
                  {"cm": R(row, "change_made_in"), "copies": R(row, "copies_to_change")}, today=CODE),
            claim("places", "fix", "How far along?", "{todo} place{todo?|s} to do, {clean} clean, {unseen} unseen.",
                  {"todo": R(row, "places_to_do"), "clean": R(row, "places_clean"), "unseen": R(row, "places_unseen")},
                  today=CODE),
            claim("owner", "fix", "Who owns it?", "{owner}", {"owner": R(row, "owner")}, today=CODE),
        ]
        claims += effort_claims(ctx, row, key)
        chips.append({"cls": "", "spans": render("{n} finding{n?|s}", {"n": R(row, "findings_cleared")})})
    return _item(alert_id, "fix_entry", "fix_key", key, row.get("package_name") if row else None,
                 title, sub, chips, claims, entry_graph(ctx, alert_id, key))


def build_mitigation_claims(build, alert_id: str) -> dict:
    ctx = build.ctx()
    k = ctx.call("alerts.classify", alert_id=alert_id)
    key = k["mitigation_key"]
    drift = ctx.call("entries.drift", alert_id=alert_id, table="posture_mitigations", key=key,
                     then_path="rule_run_results.0.member_findings", now_col="member_findings")
    row = ctx.row("posture_mitigations", key)
    title, sub = title_and_sub(ctx, alert_id)
    claims = [_still(drift, "covers", "mitigation entry")]
    chips = [{"cls": "", "spans": render("mitigation entry", {})}]
    if row is not None:
        mem = ctx.call("entries.members", table="posture_mitigations", key=key)
        claims += [
            claim("what", "deep", "What is the change?", "No fix for {pkg} ({eco}); mitigate on {places} place{places?|s}.",
                  {"pkg": R(row, "package_name"), "eco": R(row, "ecosystem"), "places": R(row, "places")}, today=CODE),
            claim("clears", "deep", "What does it clear?", "{mf} finding{mf?|s}, {cves} CVE{cves?|s}, on {img} image{img?|s}.",
                  {"mf": R(row, "member_findings"), "cves": R(row, "cves"), "img": R(row, "member_images")}, today=CODE),
            _running(mem, row),
            claim("exposure", "deep", "Is it exposed?", "{x} internet-facing service{x?|s}; in front: {front}.",
                  {"x": R(row, "internet_facing_services"), "front": R(row, "services_in_front")}, today=CODE),
            claim("threat", "deep", "Is anyone exploiting it?",
                  "Known exploited: {kev}; public exploit: {exp}; worst severity {sev}.",
                  {"kev": R(row, "known_exploited", "yesno"), "exp": R(row, "exploit_available", "yesno"),
                   "sev": R(row, "worst_severity")}, today=CODE),
            claim("owner", "fix", "Who owns it?", "{owner}", {"owner": R(row, "owner")}, today=CODE),
        ]
        chips.append({"cls": "", "spans": render("{n} finding{n?|s}", {"n": R(row, "member_findings")})})
    return _item(alert_id, "mitigation_entry", "mitigation_key", key, row.get("package_name") if row else None,
                 title, sub, chips, claims, entry_graph(ctx, alert_id, key))
