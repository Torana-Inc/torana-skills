"""ownership — who owns an entity (entity graph `owns` edges)."""
from ..core.engine import rule


#: A team or value set in Torana (the Deployment's governance fields, the AWS integration-level declared value, and the cluster or project decorations
#: that copy them) is never a real value: the app ignores it, so no proof states it as an owner.
TORANA_GOVERNANCE = ("deployment", "aws_integration")
TORANA_DECORATIONS = ("decoration:governance_cluster", "decoration:governance_project")


def source_set_services(ctx, keys: list) -> set:
    """The service keys among `keys` with at least one live asset record whose values the customer set in the source system.
    A service key with none (every record stamped from a Deployment) has no owner the app counts."""
    wanted = sorted({k for k in keys if str(k).startswith("service:")})
    if not wanted:
        return set()
    rows = ctx.select("assets", [["torana_entity_id", "in", wanted], ["is_deleted", "=", False]],
                      ["torana_entity_id", "governance_source", "decoration_provenance"])
    return {r.get("torana_entity_id") for r in rows
            if r.get("governance_source") not in TORANA_GOVERNANCE and r.get("decoration_provenance") not in TORANA_DECORATIONS}


@rule("ownership.owner", 3)
def owner(ctx, entity: str) -> dict:
    """The team(s) an entity's live `owns` edges point at. v2 lists EVERY owner (v1 took the first edge, so an entity
    with two owners was shown with one, chosen by row order): `owner` is the names joined by ", ", `owners` the list,
    `several` says there is more than one, `edge` is the first edge and `edges` all of them."""
    es = ctx.select("entity_edges", [["edge_type", "=", "owns"], ["from_key", "=", entity], ["is_deleted", "=", False]])
    if es and str(entity).startswith("service:") and entity not in source_set_services(ctx, [entity]):
        es = []                          # v3: a service's team the Deployment stamped is not an owner
    es = sorted(es, key=lambda e: str(e.get("to_key")))
    owners = sorted({(e.get("to_key") or "").replace("team:", "") for e in es} - {""})
    return {"owner": ", ".join(owners) or None, "owners": owners, "several": len(owners) > 1,
            "edge": es[0].key if es else None, "edges": [e.key for e in es]}
