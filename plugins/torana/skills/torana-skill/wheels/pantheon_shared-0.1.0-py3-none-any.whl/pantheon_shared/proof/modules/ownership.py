"""ownership — who owns an entity (entity graph `owns` edges)."""
from ..core.engine import rule


@rule("ownership.owner", 2)
def owner(ctx, entity: str) -> dict:
    """The team(s) an entity's live `owns` edges point at. v2 lists EVERY owner (v1 took the first edge, so an entity
    with two owners was shown with one, chosen by row order): `owner` is the names joined by ", ", `owners` the list,
    `several` says there is more than one, `edge` is the first edge and `edges` all of them."""
    es = ctx.select("entity_edges", [["edge_type", "=", "owns"], ["from_key", "=", entity], ["is_deleted", "=", False]])
    es = sorted(es, key=lambda e: str(e.get("to_key")))
    owners = sorted({(e.get("to_key") or "").replace("team:", "") for e in es} - {""})
    return {"owner": ", ".join(owners) or None, "owners": owners, "several": len(owners) > 1,
            "edge": es[0].key if es else None, "edges": [e.key for e in es]}
