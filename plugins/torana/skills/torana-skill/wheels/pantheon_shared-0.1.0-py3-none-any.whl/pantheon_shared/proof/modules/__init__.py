"""Importing this package registers every module's rules."""
from . import alerts, code, controls, effort, entries, images, members, ownership, packages, path, posture, runtime, signals, vulnerabilities  # noqa: F401
