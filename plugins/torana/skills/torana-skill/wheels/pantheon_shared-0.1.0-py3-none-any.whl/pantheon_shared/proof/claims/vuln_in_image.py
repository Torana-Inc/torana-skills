"""Item type: a CVE in a package in a container image (Container Analysis finding behind an alert).

A claim = a question, a template, and slots. Every slot is (value, pointer[, formatter]) taken from
a rule output or a row read through the context, so the claim's proof is the closure of its slots.
gen = "c": every claim here can be produced by code. "today" says who produced it in this build.
"""
from ..core.engine import NotCaptured
from ..core.render import render
from .fanout import labels

SECTIONS = [
    {"id": "state", "title": "What is actually true", "sub": "Before anything else: is the item right?"},
    {"id": "deep", "title": "Deep-dive", "sub": "The CVE, the scanner, the package, where it runs"},
    {"id": "tech", "title": "Technical", "sub": "Versions, fix status, origin, how it got in"},
    {"id": "fix", "title": "Remediation", "sub": "The action, where to make it, what it touches"},
]

CODE = "code: claims.vuln_in_image (template + rules)"


def claim(cid, section, q, template, slots, missing=None, refs=(), gen="c", today=CODE):
    spans = render(template, slots)
    ptrs = [s["p"] for s in spans if s.get("p")]
    if missing:
        kind = "missing"
    elif any(p["k"] == "llm" for p in ptrs):
        kind = "ai"
    elif any(p.get("judgement") for p in ptrs):
        kind = "assessed"
    elif any(p["k"] in ("rule", "sel", "absent") for p in ptrs):
        kind = "derived"
    else:
        kind = "measured"
    return {"id": cid, "section": section, "q": q, "spans": spans, "kind": kind, "gen": gen, "today": today,
            "missing": render(*missing) if missing else None,
            "refs": [{"text": t, "p": p} for t, p in refs if p and t]}


def _business_context(ctx, image, service) -> tuple:
    """The service's resolved business context at this image, and whether the record holds that read. Path guard: a record
    captured before framework 0.7.6 never read posture_runtime_context, so its "env" claim replays from the asset's own
    columns, as it was built, instead of raising NotCaptured."""
    try:
        return ctx.one("posture_runtime_context", [["place_kind", "=", "image"], ["place_key", "=", image], ["service_key", "=", service]]), True
    except NotCaptured:
        return None, False


def _unmodelled_reason(ctx, alert_id: str, vuln_id: str | None) -> str:
    """Why an item has no proof model, as a clause the CLI and the FE print in parentheses.

    ⛔ IT WAS THE BARE FINDING ID. A Trivy SCA finding's id is a sha256, so the page read "No proof model
    for this item type yet (aedab10f…)" — an id in the place of an explanation (Bhakta, 2026-10-07). It now
    says what the finding IS, read from its own row (scanner, kind, CVE, package, where), and what the model
    covers. The id travels separately as `finding_id`."""
    if not vuln_id:
        # ⚠️ A posture alert (rule_finding_for_review, rule_new_critical, ...) carries a POSTURE finding key
        # ("CVE|ecosystem|package|version|image@sha256:…") and no scanner id. Say which, never "no finding id".
        a = ctx.row("api.alert", alert_id)
        fk = a.get("rule_run_results.0.finding_key") if a else None
        if fk:
            return (f"a posture finding ({fk}) with no Container Analysis report, so it cannot be proved "
                    "through the container-image model")
        return "the alert carries no finding id (an aggregate alert), so there is no single finding to prove"
    v = ctx.row("vulnerabilities", vuln_id)
    if v is None:
        return f"finding {vuln_id[:16]}… is not in the datalake"
    kind = " ".join(str(x) for x in (v.get("scanner_name") or v.get("source_system"), v.get("scan_type")) if x)
    what = v.get("cve_id") or v.get("finding_key")
    pkg = v.get("torana_package_id")
    where = v.get("torana_repository_id") or v.get("torana_artifact_id")
    said = f"a {kind} finding" if kind else "a finding"
    said += f" ({what})" if what else ""
    said += f" in {pkg}" if pkg else ""
    said += f" on {where}" if where else ""
    return f"{said}; only container-image CVEs from GCP Container Analysis have a proof model so far"


def build_claims(build, alert_id: str) -> dict:
    ctx = build.ctx()
    t = ctx.call("alerts.target", alert_id=alert_id)
    if t["item_type"] != "vuln_in_image":
        return {"alert_id": alert_id, "type": "unmodelled", "reason": _unmodelled_reason(ctx, alert_id, t["vuln_id"]),
                "finding_id": t["vuln_id"],
                "claims": [], "title": [], "chips": [], "sub": [], "graph": {"nodes": [], "edges": [], "blast": []}}
    cve, img = t.p("cve"), t.p("image")
    svc = ctx.call("images.service_of", image=img[0])
    run_img = svc.p("running_image")
    stale = ctx.call("alerts.is_stale", alert_id=alert_id)
    vid = stale["running_vuln_id"]
    v = ctx.row("vulnerabilities", vid) if vid else None
    a = ctx.row("api.alert", alert_id)
    m = ctx.row("vm_cve_metadata", cve[0])
    sev = ctx.call("alerts.severity_sources", alert_id=alert_id, vuln_id=vid)
    tri = ctx.call("alerts.triage_state", alert_id=alert_id)
    # I-133: several repositories are recorded as building the image (images.service_of v3). No builder is picked, so the
    # history is counted over this image only; the wording below says so, and cites `repos`.
    several_builders = bool(svc.outputs.get("several_builders"))
    first = (ctx.call("images.detections_on_image", image=img[0], cve=cve[0]) if several_builders else
             ctx.call("images.first_detection", repo=svc["repo"], cve=cve[0]))
    disc = ctx.call("vulnerabilities.disclosure_vs_detection", cve=cve[0], first_detected=first["first_detected"])
    origin = ctx.call("vulnerabilities.package_origin", vuln_id=vid) if vid else None
    # The image's own evidence (B7 row B): which layer and build step put the package there. Read only when the
    # scanner's occurrence names no layer (a Trivy- or SBOM-sourced finding). Path guard: a record built before
    # images.package_layer existed holds none of its reads, so it replays without it (pl = None) instead of
    # raising NotCaptured.
    pl = None
    if v is not None and not (origin is not None and origin.outputs.get("layer_diff")):
        try:
            # ⚠️ The package read is inside the guard too: a pre-0.7.10 record never captured that cell.
            _pkg = v.get("torana_package_id")
            if _pkg:
                pl = ctx.call("images.package_layer", image=run_img[0], package_id=_pkg)
        except NotCaptured:
            pl = None
    own_layer = pl is not None and pl.outputs.get("found") and pl.outputs.get("build_step")
    fresh = ctx.call("vulnerabilities.source_freshness", vuln_id=vid) if vid else None
    bins = ctx.call("packages.binaries_of", image=run_img[0], source_package=t["package"], version=t["version"])
    pf = ctx.call("posture.finding_at", image=run_img[0], cve=cve[0])
    f = ctx.row("posture_findings", pf["finding_key"]) if pf["finding_key"] else None
    sr = ctx.one("posture_scanner_reports", [["place_key", "=", run_img[0]], ["cve_id", "=", cve[0]]])
    entry = ctx.call("posture.entry_for_finding", finding_key=pf["finding_key"])
    link = ctx.call("alerts.parent_link", alert_id=alert_id, finding_key=pf["finding_key"])
    blast = ctx.call("posture.blast_radius", entry_key=entry["entry_key"]) if entry["entry_key"] else None
    expo = ctx.call("runtime.exposure", service=svc["service"])
    place = ctx.call("runtime.placement", service=svc["service"])
    so = ctx.call("ownership.owner", entity=svc["service"])
    ro = ctx.call("ownership.owner", entity=svc["repo"])
    ctl = ctx.call("controls.inventory")
    asset = ctx.row("assets", svc["service"])
    # the business context the app RANKS on for this service: the source's value, else the tenant's policy default, with the source stated
    # (never the raw asset column, which can hold a value set in Torana)
    rts, rts_read = _business_context(ctx, run_img[0], svc["service"])
    rt = ctx.one("posture_runtime_context", [["place_kind", "=", "image"], ["place_key", "=", run_img[0]]])
    kind = ctx.call("alerts.classify", alert_id=alert_id)
    via_finding = kind["via"] == "posture_finding"
    rep = ctx.row("posture_scanner_reports", kind["report_key"]) if via_finding else None

    def R(row, path, fmt=None):
        if row is None:
            return (None, None, fmt) if fmt else (None, None)
        val, ptr = row.p(path)
        return (val, ptr, fmt) if fmt else (val, ptr)

    def O(res, out, fmt=None):
        if res is None:
            return (None, None, fmt) if fmt else (None, None)
        val, ptr = res.p(out)
        return (val, ptr, fmt) if fmt else (val, ptr)

    def M(table, col):
        return ctx.meaning(table, col)

    # Wording is chosen by code from the values (each choice reads a recorded rule output); every value is a slot.
    is_stale, mismatch, unjudged = stale["stale"], sev["mismatch"], tri["unjudged"]
    fix = v.get("is_fix_available") if v else None
    one_scanner = (f.get("scanner_count") if f else None) == 1
    missing_link = link["missing_link"]
    # Images whose build edge is gone (retired) still count toward the history; the sentence says how many.
    retired = " ({ret} since retired)" if first.outputs.get("retired_images") else ""
    claims = [
        claim("stale", "state", "Is this item still true?",
              # No running image is known (no build record, several builders and the image not deployed, or not recorded):
              # neither yes nor no can be said.
              "The alert names image {a_img}; no running image is known for it, so whether this item is still true "
              "cannot be said." if run_img[0] is None else
              "Not as stated. The alert names image {a_img}, which is no longer deployed and now has {a_find} finding{a_find?|s}. "
              "{svc} runs image {r_img}, which still has {r_live} live finding{r_live?|s} for this CVE."
              if is_stale else "Yes. The alert names image {a_img}, which {svc} runs now ({r_live} live finding{r_live?|s} for this CVE).",
              {"a_img": (*img, "digest"), "a_find": O(stale, "alert_image_findings"), "svc": O(svc, "service", "svc"),
               "r_img": (*run_img, "digest"), "r_live": O(stale, "running_image_live_rows")}),
        claim("severity", "state", "How severe is it, really?",
              "{finding}, not {rule}. {rule_cap} is the severity of the rule that raised it ({rname}); the finding is {finding2} "
              "(CVSS 3.1 {c3}, CVSS 4.0 {c4})." if mismatch else
              "{finding} (CVSS 3.1 {c3}, CVSS 4.0 {c4}); the rule that raised it ({rname}) agrees.",
              {"finding": O(sev, "finding"), "finding2": O(sev, "finding"), "rule": O(sev, "rule"), "rule_cap": O(sev, "rule", "cap"),
               "rname": R(a, "rule_name"), "c3": R(m, "cvss3_base_score"), "c4": R(v, "cvss4_base_score")},
              refs=[M("vm_cve_metadata", "cvss3_base_score")]),
        claim("sla", "state", "Which deadline is this about?",
              "The alert's triage deadline was {a_sla}. The vulnerability's remediation deadline is {v_due}.",
              {"a_sla": R(a, "sla_due_at", "time"), "v_due": R(v, "vulnerability_due_date", "time")},
              refs=[M("vulnerabilities", "vulnerability_due_date")]),
        claim("triage", "state", "Why is it escalated to a person?",
              "Because nobody has judged it. The triage agent failed {att} of {mx} attempts ({kind}: \"{err}\") "
              "and the platform escalated automatically." if unjudged else "Triage recorded the verdict {vd}.",
              {"att": R(a, "triage_failure.attempts"), "mx": R(a, "triage_failure.max_attempts"),
               "kind": R(a, "triage_failure.error_kind"), "err": R(a, "triage_failure.error"), "vd": O(tri, "verdict")}),
        claim("fresh", "state", "How fresh is the source?",
              "The scanner last reported it {last}, {age} {age?hour|hours} before this page was built, from {n} source.",
              {"last": O(fresh, "last_reported", "time"), "age": O(fresh, "age_hours"), "n": O(fresh, "sources")}),
    ]
    if via_finding:
        claims.insert(1, claim("posture", "state", "Which posture finding raised this?",
                               "Raised from posture finding {fk}; its scanner report {rid} is {st}.",
                               {"fk": R(a, "rule_run_results.0.finding_key"), "rid": R(rep, "report_id"),
                                "st": R(rep, "status")}))
    claims += [
        claim("what", "deep", "What is this CVE?",
              "{desc} Weakness {cwe}, CVSS vector {vec}, published {pub}." if m and m.get("description") else
              "No written description is held. Known: weakness {cwe}, CVSS vector {vec}, published {pub}.",
              {"desc": R(m, "description"), "cwe": R(m, "cwe_id"), "vec": R(m, "cvss3_vector"), "pub": R(m, "published_date", "day")},
              missing=("The description column is empty for {cve}: {why}", {"cve": cve, "why": M("vm_cve_metadata", "description")})
              if m is None or not m.get("description") else None,
              refs=[M("vm_cve_metadata", "description")]),
        claim("threat", "deep", "Is anyone exploiting it?",
              "{kev} EPSS {epss} chance of exploitation in the next 30 days (percentile {pctl}). Exploit maturity per the scanner: {mat}.",
              {"kev": R(m, "kev_listed", "kev"), "epss": R(m, "epss_score", "pct"), "pctl": R(m, "epss_percentile"),
               "mat": R(v, "scan_output.vulnerability.cvssV4.exploitMaturity")},
              refs=[M("vm_cve_metadata", "kev_listed"), M("vm_cve_metadata", "epss_score")]),
        claim("scanner", "deep", "Which scanner found it?",
              ("{label} ({sys}), alone: {n} scanner reports it, so there is no second opinion. First reported on this image {fs}."
               if one_scanner else "{n} scanners report it, led by {label} ({sys}). First reported on this image {fs}."),
              {"label": R(sr, "scanner_label"), "sys": R(sr, "source_system"), "n": R(f, "scanner_count"), "fs": R(sr, "first_seen_at", "time")}),
        claim("package", "deep", "Which package is affected?",
              "{pkg} {ver}, an {ptype} package for {cpe}, read from {file}. The image's package list has it as {bins}, "
              "matched by name and version ({conf}).",
              {"pkg": O(origin, "affected_package"), "ver": O(origin, "affected_version"), "ptype": O(origin, "package_type"),
               "cpe": O(origin, "cpe"), "file": O(origin, "file"), "bins": O(bins, "binaries"), "conf": O(bins, "confidence")}),
        claim("env", "deep", "Where does it run?",
              ("{envv}, cluster {cl}, namespace {ns}, {reg}. Internet-facing through load balancer endpoint {ep}. " if expo["exposed"] else
               "{envv}, cluster {cl}, namespace {ns}, {reg}. No load balancer endpoint is recorded for it, so it is not shown as internet-facing. ")
              + ("Criticality {crit} ({crit_src}); holds customer data: {cd} ({cd_src})." if rts_read else
                 "Marked {crit}; holds customer data: {cd}."),            # a record built before 0.7.6 replays as it was built
              {"envv": R(asset, "asset_environment"), "cl": R(asset, "container_cluster_name"), "ns": R(asset, "namespace"),
               "reg": R(asset, "cloud_region"), "ep": O(expo, "endpoint"),
               **({"crit": R(rts, "criticality"), "crit_src": R(rts, "criticality_source", "ctxsource"),
                   "cd": R(rts, "customer_data", "yesno"), "cd_src": R(rts, "customer_data_source", "ctxsource")} if rts_read else
                  {"crit": R(asset, "criticality_name"), "cd": R(asset, "has_customer_data", "yesno")})}),
        claim("fixver", "tech", "Is there a fixed version?",
              ("No. No fixed version is recorded, and the scanner's fix kind is {fk}. Upstream status: {adv}." if fix is False else
               "Yes: {fv}. Upstream status: {adv}."),
              {"fv": R(v, "package_fixed_version"), "fk": O(origin, "fix_kind"), "adv": O(origin, "advisory")},
              refs=[M("vulnerabilities", "is_fix_available")]),
        (claim("origin", "tech", "Is it our code, open source, or a vendor image?",
               "The image's own record places it at {file}, in layer {li} ({diff}), added by build step {hi}: "
               "\u201c{cmd}\u201d (reported by {src}). No base image is recorded, so this names the step, not whose code it is.",
               {"file": O(pl, "file"), "li": O(pl, "layer_index"), "diff": O(pl, "layer_diff"), "hi": O(pl, "history_index"),
                "cmd": O(pl, "build_step"), "src": O(pl, "source")}) if own_layer else
         claim("origin", "tech", "Is it our code, open source, or a vendor image?",
              ("It ships in the base image {base}, not in our code: the scanner traces it to layer {diff}, built by \u201c{cmd}\u201d ({pt} package)."
               if origin is not None and origin.outputs.get("base_images") else
               "Where it entered is not recorded: the scanner names layer {diff}, built by \u201c{cmd}\u201d ({pt} package), "
               "but no base image is recorded for it, so this does not say whether it is our code."),
              {"pt": O(origin, "package_type"), "diff": O(origin, "layer_diff"), "cmd": O(origin, "layer_command"), "base": O(origin, "base_images")})),
        claim("introduced", "tech", "When and how did it get in? Who introduced it?",
              ("The CVE was published {pub} and first detected on this image on {fd}; {n} image{n?|s} {n?has|have} carried it, "
               "counting this image only: it is built by {nb} repositories ({repos}) and Torana does not pick one. "
               "The running image was pushed {push}." if several_builders and first["first_detected"] else
               "The CVE was published {pub}. No first-detection date is recorded on this image; {n} image{n?|s} {n?has|have} "
               "carried it, counting this image only: it is built by {nb} repositories ({repos}) and Torana does not pick one. "
               "The running image was pushed {push}." if several_builders else
               "Not by a change we can see: the CVE was published {pub}, on or before its first detection on this service "
               "({fd}, image {fi}), so it was disclosed against a package already there. {n} image{n?|s} {n?has|have} carried it" + retired + "; "
               "the running image was pushed {push}." if disc["relation"] == "disclosed_against_shipped" else
               "The CVE was published {pub} and first detected on this service on {fd} (image {fi}); {n} image{n?|s} {n?has|have} carried it" + retired + ". "
               "The running image was pushed {push}." if first["first_detected"] else
               # images.first_detection v4: no row carries a detection date, so none is shown (never a sentinel).
               "The CVE was published {pub}. No first-detection date is recorded on this service, so when it got in "
               "cannot be dated; {n} image{n?|s} {n?has|have} carried it" + retired + ". The running image was pushed {push}."),
              {"pub": R(m, "published_date", "day"), "fd": O(first, "first_detected", "day"), "fi": O(first, "first_image", "digest"),
               "n": O(first, "images_with_cve"), "ret": O(first, "retired_images"), "push": R(rt, "image_pushed_at", "time"),
               **({"nb": O(svc, "repos", "count"), "repos": O(svc, "repos", "repos")} if several_builders else {})},
              missing=(("Who introduced it is not recorded: {nb} repositories are recorded as building the image ({repos}), "
                        "and Torana does not pick one.", {"nb": O(svc, "repos", "count"), "repos": O(svc, "repos", "repos")})
                       if several_builders else
                       ("Who introduced it is not recorded: no edge from {repo} to a Dockerfile or the commit that set the base image.",
                        {"repo": O(svc, "repo", "repo")})),
              refs=[M("vulnerabilities", "scan_first_detected_date")]),
        claim("action", "fix", "What should happen?",
              "The ranking routes it to {route} ({reason}). {tier} It is covered by \u201c{title}\u201d. {ind}",
              {"route": R(f, "route"), "reason": R(f, "reason_label"), "tier": R(f, "tier_line"),
               "title": O(entry, "title"), "ind": R(f, "fix_indication")}),
        claim("link", "fix", "Is this alert attached to that entry?",
              "No. An entry covers this finding, but the alert's parent is {par}, so it is worked on its own." if missing_link else
              "Yes, through parent {par}.",
              {"par": O(link, "parent")}),
        (claim("where", "fix", "Which component needs the change?",
               "The {cm} of one of the {nb} repositories recorded as building it ({repos}); Torana does not pick one, "
               "so no repository owner is named.",
               {"cm": R(f, "change_made_in"), "nb": O(svc, "repos", "count"), "repos": O(svc, "repos", "repos")},
               missing=("Which repository needs the change is not proven: {nb} repositories are recorded as building the "
                        "image.", {"nb": O(svc, "repos", "count")}))
         if several_builders else
         claim("where", "fix", "Which component needs the change?",
               "The {cm} of {repo}, owned by {ro}.",
               {"cm": R(f, "change_made_in"), "repo": O(svc, "repo", "repo"), "ro": O(ro, "owner")})),
        claim("blast", "fix", "What is the blast radius of the fix?",
              "{f} finding{f?|s} ({cves}) across {s} service{s?|s}, {x} of them internet-facing, behind {lb} load balancer{lb?|s} on {n} node{n?|s}.",
              {"f": O(blast, "findings"), "cves": O(blast, "cves"), "s": O(blast, "services"), "x": O(blast, "exposed_services"),
               "lb": O(blast, "load_balancers"), "n": O(blast, "nodes")}),
        claim("controls", "fix", "What compensating controls exist?",
              "None recorded: the controls query returned {c} rows." if not ctl["count"] else "{c} control{c?|s} {c?is|are} inventoried.",
              {"c": O(ctl, "count")},
              missing=("So nothing is known about what filters traffic to {ep}.", {"ep": O(expo, "endpoint")}) if not ctl["count"] else None),
        (claim("owner", "fix", "Who owns it?",
               "Service owner {so}; no repository owner is named: {nb} repositories are recorded as building the image "
               "({repos}). The item is assigned to {at} {a}.",
               {"so": O(so, "owner"), "nb": O(svc, "repos", "count"), "repos": O(svc, "repos", "repos"),
                "at": R(a, "assignee_type"), "a": R(a, "assigned_to")})
         if several_builders else
         claim("owner", "fix", "Who owns it?",
               "Service owner {so}; repository owner {ro}. The item is assigned to {at} {a}.",
               {"so": O(so, "owner"), "ro": O(ro, "owner"), "at": R(a, "assignee_type"), "a": R(a, "assigned_to")})),
    ]

    title = render("{cve} in {pkg} on {svc}", {"cve": cve, "pkg": t.p("package"), "svc": O(svc, "service", "svc")})
    age = ctx.call("alerts.age", alert_id=alert_id)
    chips = [{"cls": "sev-" + str(sev["finding"]).lower(), "spans": render("{v} · finding", {"v": O(sev, "finding")})},
             {"cls": "", "spans": render("rule said {v}", {"v": O(sev, "rule")})},
             {"cls": "", "spans": render("{v}", {"v": R(a, "status")})},
             *([{"cls": "warn", "spans": render("internet-facing", {})}] if expo["exposed"] else []),
             {"cls": "", "spans": render("{h} h open", {"h": age.p("hours")})}]
    sub = (render("{base} base image · fix available: {fa} · owner not picked: {nb} repositories built it · {aid}",
                  {"base": O(origin, "base_images"), "fa": R(v, "is_fix_available", "yesno"), "nb": O(svc, "repos", "count"),
                   "aid": (alert_id[:8], R(a, "id")[1])}) if several_builders else
           render("{base} base image · fix available: {fa} · owner {ro} · {aid}",
                  {"base": O(origin, "base_images"), "fa": R(v, "is_fix_available", "yesno"), "ro": O(ro, "owner"),
                   "aid": (alert_id[:8], R(a, "id")[1])}))
    return {"alert_id": alert_id, "type": "vuln_in_image", "svc": str(svc["service"] or "").split(":", 1)[-1],
            "cve": cve[0], "package": t["package"], "stale": stale["stale"], "unjudged": unjudged, "alert_image": img[0], "running_image": run_img[0],
            "title": title, "chips": chips, "sub": sub, "claims": claims,
            "graph": graph(t, svc, stale, origin, bins, expo, place, so, ro, sev, m, blast),
            "head": {"finding_sev": sev["finding"]}}


def graph(t, svc, stale, origin, bins, expo, place, so, ro, sev, m, blast) -> dict:
    """Nodes and edges, each pointing at the row or rule output it was drawn from."""
    N, E = [], []
    rp = lambda res, out: res.p(out)[1] if res else None  # noqa: E731
    run_img = svc["running_image"]
    lab = labels([svc["service"], svc["repo"]])     # tells a service and a repository of one name apart
    N += [
        {"id": "endpoint", "col": 0, "row": 0, "t1": "Public endpoint", "t2": expo["endpoint"], "cls": "inet", "p": rp(expo, "endpoint")},
        {"id": "lb", "col": 1, "row": 0, "t1": "Load balancer", "t2": (expo["lb"] or "—").split("/")[-1][:12] + "…", "p": rp(expo, "lb")},
        {"id": "svc", "col": 2, "row": 0, "t1": lab.get(svc["service"], "—"), "t2": ("this item · one of %d services running it" % len(svc.outputs.get("services") or [])) if svc.outputs.get("several") else "this item · running", "me": True, "p": rp(svc, "service")},
        {"id": "img", "col": 3, "row": 0, "t1": "image " + (run_img or "").split("sha256:")[-1][:8], "t2": "running · has the CVE", "me": True, "p": rp(svc, "running_image")},
        {"id": "bin", "col": 4, "row": 0, "t1": bins["binaries"] or "—", "t2": t["version"], "p": rp(bins, "binaries")},
        {"id": "src", "col": 5, "row": 0, "t1": t["package"] + " (source)", "t2": (origin["cpe"] if origin else "") or "", "p": rp(origin, "affected_package")},
        {"id": "cve", "col": 6, "row": 0, "t1": t["cve"], "t2": f"{sev['finding']} · CVSS {m.get('cvss3_base_score') if m else '—'}", "cls": "cve", "p": rp(t, "cve")},
        {"id": "base", "col": 4, "row": -1, "t1": "base layer " + ((origin["layer_diff"] if origin else "") or "")[:8], "t2": (origin["base_images"] if origin else "") or "", "p": rp(origin, "layer_command")},
        # I-133: several repositories are recorded as building the image; the node says how many, and names none
        ({"id": "repo", "col": 3, "row": 1, "t1": "repo", "t2": "%d repositories" % len(svc.outputs.get("repos") or []),
          "p": rp(svc, "repos")} if svc.outputs.get("several_builders") else
         {"id": "repo", "col": 3, "row": 1, "t1": "repo", "t2": lab.get(svc["repo"], ""), "p": rp(svc, "repo")}),
    ]
    if so["owner"]:
        N.append({"id": "sowner", "col": 1, "row": 1, "t1": "service owner", "t2": so["owner"], "p": rp(so, "owner")})
    if ro["owner"]:
        N.append({"id": "rowner", "col": 4, "row": 1, "t1": "repo owner", "t2": ro["owner"], "p": rp(ro, "owner")})
    if place["host"]:
        N.append({"id": "host", "col": 2, "row": 1, "t1": "node", "t2": place["host"].split("-")[-1], "p": rp(place, "host")})
    if stale["stale"]:
        N.append({"id": "aimg", "col": 3, "row": -1, "t1": "image " + t["image"].split("sha256:")[-1][:8], "t2": "this alert · not deployed", "cls": "ghost", "p": rp(t, "image")})

    def edge(a, b, label, ptr, style="reported"):
        E.append({"from": a, "to": b, "label": label, "style": style, "p": ptr})
    edge("endpoint", "lb", "ip of", rp(expo, "edge"))
    edge("lb", "svc", "exposes", rp(expo, "edge"))
    edge("svc", "img", "runs", rp(svc, "deployed_edge"))
    edge("img", "bin", "contains", rp(bins, "edges"))
    edge("bin", "src", "of?", rp(bins, "confidence"), "heuristic")
    edge("src", "cve", "has", rp(origin, "occurrence"))
    edge("base", "bin", "ships", rp(origin, "layer_command"), "derived")
    edge("repo", "img", "builds_image", rp(svc, "builds_edge"))
    if so["owner"]:
        edge("svc", "sowner", "owns", rp(so, "edge"))
    if ro["owner"]:
        edge("repo", "rowner", "owns", rp(ro, "edge"))
    if place["host"]:
        edge("svc", "host", "runs_on", rp(place, "edge"))
    if stale["stale"]:
        edge("repo", "aimg", "built", rp(svc, "repo"), "derived")
    deployed = blast["deployed"] if blast else []
    blab = labels([d["service"] for d in deployed])
    blast_nodes = [{"service": d["service"], "image": d["image"], "label": blab[d["service"]], "p": rp(blast, "deployed")}
                   for d in deployed]
    return {"nodes": N, "edges": E, "blast": blast_nodes}
