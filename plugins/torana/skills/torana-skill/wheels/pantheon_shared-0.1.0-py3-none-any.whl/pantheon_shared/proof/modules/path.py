"""path — what the exposure-path card shows, read from PLATFORM rows only: entity edges (deployed_as, exposed_via,
builds_image, owns), assets, artifacts, repositories, vulnerabilities and the CVE table.

⭐ MEMBERS ARE AN ANCHOR, NOT A RESULT. The item says which findings it is about (an entry's member keys, a finding's key,
a code finding's repository and file). These rules never re-derive that set: they read the FACTS ABOUT it. Where a fact
differs from what the item says (an image GKE no longer runs), the difference is a fact about that node, sourced and timed.

Every read is a keyed, projected select: the columns named here only, never `scan_output` itself (the flagged source line).
Every output carries `source` (the user-facing name) and `as_of` (Pacific time) taken from the rows read.
"""
from __future__ import annotations

from ..core.engine import rule
from ..source_names import ASSET_INVENTORY, CVE_FEEDS, provenance
from ..times import latest, pt

PROV = ["source_system", "contributing_sources"]
EDGE = ["from_key", "to_key", "edge_type", "evidence", "last_seen", *PROV]
LIVE = ["is_deleted", "=", False]
LB_PREFIX = "cloud:gcp/lb-endpoint/"


def _prov(table: str, row) -> dict:
    return provenance(table, {c: row.get(c) for c in (*PROV, "last_seen")})


def _edge(row) -> dict:
    return {**_prov("entity_edges", row)}


def _endpoint(row) -> str | None:
    ev = row.get("evidence") or {}
    ref = ev.get("to_original") or ev.get("exposure_ref") or row.get("to_key")
    ref = str(ref or "")
    return ref[len(LB_PREFIX):] if ref.startswith(LB_PREFIX) else (ref or None)


@rule("path.deployment", 1)
def deployment(ctx, places: list) -> dict:
    """Which services run each place. An image: its live `deployed_as` edges. A repository: the images it builds
    (`builds_image`), then THEIR live `deployed_as` edges. A place no live edge reaches is "not deployed": a fact about
    that node, not a missing node."""
    images = sorted(p for p in places if is_image(p))
    repos = sorted(p for p in places if str(p).startswith("repo:"))
    built = ctx.select("entity_edges", [["edge_type", "=", "builds_image"], ["from_key", "in", repos], LIVE], EDGE) if repos else []
    repo_images: dict = {}
    build_prov: dict = {}
    for e in built:
        repo_images.setdefault(e.get("from_key"), []).append(e.get("to_key"))
        build_prov[e.get("from_key")] = _edge(e)
    all_images = sorted({*images, *(i for v in repo_images.values() for i in v if i)})
    dep = ctx.select("entity_edges", [["edge_type", "=", "deployed_as"], ["from_key", "in", all_images], LIVE], EDGE) if all_images else []
    image_services: dict = {}
    for e in dep:
        image_services.setdefault(e.get("from_key"), []).append({"service": e.get("to_key"), **_edge(e)})
    services: dict = {}
    for place in sorted(places):
        for img in ([place] if place in images else sorted(repo_images.get(place, []))):
            for s in image_services.get(img, []):
                d = services.setdefault(s["service"], {"places": [], "images": [], "source": s["source"], "as_of": s["as_of"]})
                d["places"] = sorted({*d["places"], place})
                d["images"] = sorted({*d["images"], img})
                d["as_of"] = latest([d["as_of"], s["as_of"]]) if False else (d["as_of"] or s["as_of"])
    deployed_places = {p for d in services.values() for p in d["places"]}
    return {"services": services, "image_services": image_services,
            "repo_images": {r: {"images": sorted(v), "deployed": sorted(i for i in v if i in image_services)}
                            for r, v in repo_images.items()},
            "build_edges": build_prov, "not_deployed": sorted(set(places) - deployed_places)}


@rule("path.ranking_running", 1)
def ranking_running(ctx, package: str, places: list, cves: list) -> dict:
    """What the ranking last scored for these places, to set beside the live edges: per image, whether any of the package's
    findings there read "running", and when the ranking last wrote them. A comparison only; the path never uses it."""
    images = sorted(p for p in places if str(p).startswith("image:"))
    if not package or not images:
        return {"states": {}}
    # The CVEs drawn only: a place's running state is the same on all its findings, and reading every finding of 6 places
    # (70 each for vim) tripled the record.
    where = [["package_name", "=", package], ["place_key", "in", images]] + ([["cve_id", "in", sorted(cves)]] if cves else [])
    rows = ctx.select("posture_findings", where, ["place_key", "running_state", "updated_at"])
    out: dict = {}
    for r in rows:
        d = out.setdefault(r.get("place_key"), {"running": False, "updated": None})
        d["running"] = d["running"] or r.get("running_state") == "running"
        u = str(r.get("updated_at") or "")
        d["updated"] = max(d["updated"] or "", u) or None
    return {"states": {k: {"running": v["running"], "as_of": pt(v["updated"])} for k, v in out.items()}}


@rule("path.exposure", 1)
def exposure(ctx, services: list) -> dict:
    """The public address each service is reachable at: its `exposed_via` edge's endpoint. A service with no such edge is
    simply not listed (nothing recorded), never "not exposed"."""
    rows = ctx.select("entity_edges", [["edge_type", "=", "exposed_via"], ["from_key", "in", sorted(services)], LIVE], EDGE) if services else []
    out: dict = {}
    for e in rows:
        out.setdefault(e.get("from_key"), {"endpoint": _endpoint(e), "target": e.get("to_key"), **_edge(e)})
    return {"exposed": out}


@rule("path.owners", 1)
def owners(ctx, entities: list) -> dict:
    """Every live `owns` edge into an entity (service or repository): all owners, never the first."""
    rows = ctx.select("entity_edges", [["edge_type", "=", "owns"], ["from_key", "in", sorted(entities)], LIVE], EDGE) if entities else []
    out: dict = {}
    for e in rows:
        d = out.setdefault(e.get("from_key"), {"owners": [], "source": None, "as_of": None})
        d["owners"] = sorted({*d["owners"], (e.get("to_key") or "").replace("team:", "")} - {""})
        p = _edge(e)
        d["source"], d["as_of"] = d["source"] or p["source"], d["as_of"] or p["as_of"]
    return {"owners": out}


SERVICE_COLS = ["asset_name", "container_cluster_name", "namespace", "asset_environment", "criticality_name",
                "has_customer_data", "asset_owner", "asset_launched_at", "asset_last_seen_at", "custom_attributes_value", *PROV]


@rule("path.service_facts", 1)
def service_facts(ctx, services: list) -> dict:
    """What the asset inventory and the cluster hold about each service (a workload asset keyed by the service key)."""
    rows = ctx.select("assets", [["torana_entity_id", "in", sorted(services)], LIVE], SERVICE_COLS) if services else []
    out: dict = {}
    for r in rows:
        attrs = r.get("custom_attributes_value") or {}
        pv = provenance("assets", {c: r.get(c) for c in (*PROV, "asset_last_seen_at")})
        out[r.key] = {"cluster": r.get("container_cluster_name"), "namespace": r.get("namespace"),
                      "environment": r.get("asset_environment"), "criticality": r.get("criticality_name"),
                      "customer_data": r.get("has_customer_data"), "owner": r.get("asset_owner"),
                      "running_since": pt(r.get("asset_launched_at")), "ingress": attrs.get("ingress_name"), "workload_kind": attrs.get("workload_kind"),
                      "endpoint": attrs.get("exposure_endpoint"), "source": f"{pv['source']} · {ASSET_INVENTORY}" if pv["source"] else ASSET_INVENTORY,
                      "as_of": pv["as_of"]}
    return {"services": out}


@rule("path.image_facts", 1)
def image_facts(ctx, images: list) -> dict:
    """When each image was last pushed to its registry (the registry inventory; absent where that integration does not run)."""
    rows = ctx.select("artifacts", [["torana_artifact_id", "in", sorted(images)], LIVE], ["artifact_last_pushed_date", *PROV]) if images else []
    out: dict = {}
    for r in rows:
        pv = provenance("artifacts", {c: r.get(c) for c in PROV})
        out[r.key] = {"pushed": pt(r.get("artifact_last_pushed_date")), "source": pv["source"], "as_of": pv["as_of"]}
    return {"images": out}


@rule("path.repo_facts", 1)
def repo_facts(ctx, repos: list) -> dict:
    """Who owns each repository and when it was last pushed. Its criticality is NOT read: the platform holds none for it."""
    rows = ctx.select("repositories", [["torana_repository_id", "in", sorted(repos)], LIVE],
                      ["owner_name", "owner_type", "last_push_date", "default_branch", *PROV]) if repos else []
    out: dict = {}
    for r in rows:
        pv = provenance("repositories", {c: r.get(c) for c in PROV})
        out[r.key] = {"owner": r.get("owner_name"), "owner_type": r.get("owner_type"), "last_push": pt(r.get("last_push_date")),
                      "default_branch": r.get("default_branch"), "source": pv["source"], "as_of": pv["as_of"]}
    return {"repos": out}


CVE_COLS = ["description", "cvss3_base_score", "epss_score", "epss_percentile", "kev_listed", "kev_date_added", "cwe_id",
            "published_date", "updated_at"]


@rule("path.cve_facts", 1)
def cve_facts(ctx, cves: list) -> dict:
    """The CVE table's facts for the CVEs shown (CVSS, EPSS, KEV, CWE, published, summary)."""
    rows = ctx.select("vm_cve_metadata", [["cve_id", "in", sorted(cves)], LIVE], CVE_COLS) if cves else []
    out: dict = {}
    for r in rows:
        out[r.key] = {"description": r.get("description"), "cvss": r.get("cvss3_base_score"), "epss": r.get("epss_score"),
                      "epss_percentile": r.get("epss_percentile"), "kev": r.get("kev_listed"), "kev_added": pt(r.get("kev_date_added")),
                      "cwe": r.get("cwe_id"), "published": pt(r.get("published_date")), "source": CVE_FEEDS,
                      "as_of": pt(r.get("updated_at"))}
    return {"cves": out}


FINDING_COLS = ["cve_id", "package_installed_version", "package_fixed_version", "scanner_name", "dependency_type",
                "source_file_path", "scan_first_detected_date", "scan_last_detected_date", "vulnerability_status", *PROV]


@rule("path.package_facts", 1)
def package_facts(ctx, package: str, versions: list, images: list, repos: list, cves: list, ecosystem: str | None = None) -> dict:
    """What the scanners record about a package at the given places: fixed versions, who reported it, direct or transitive,
    the manifest, first seen. Read for ONE place (the largest) and for the CVEs drawn, so the read stays small however many members the item has."""
    where = [["package_name", "=", package], LIVE]
    if versions:
        where.append(["package_installed_version", "in", sorted(versions)])
    if cves:
        where.append(["cve_id", "in", sorted(cves)])
    if images:
        where.append(["torana_artifact_id", "in", sorted(images)])
    elif repos:
        where.append(["torana_repository_id", "in", sorted(repos)])
    else:
        return {"found": False}
    rows = []
    if images and cves and ecosystem and versions:
        # A container-analysis finding's id is built from its parts (image, CVE, package URL), so the rows are read by key.
        # Filtering by package and image instead scans the package's rows (2.7 s for vim at 38k rows).
        ids = sorted(f"gcp_ca_{img}_{cve}_pkg:{ecosystem}/{package}@{ver}" for img in images for cve in cves for ver in versions)
        rows = ctx.select("vulnerabilities", [["torana_vulnerability_id", "in", ids], LIVE], FINDING_COLS)
    rows = rows or ctx.select("vulnerabilities", where, FINDING_COLS)
    if not rows:
        return {"found": False}
    fixed, scanners, deps, manifests, firsts, lasts, srcs = set(), set(), set(), set(), [], [], set()
    for r in rows:
        if r.get("package_fixed_version"):
            fixed.add(str(r.get("package_fixed_version")))
        pv = provenance("vulnerabilities", {c: r.get(c) for c in (*PROV, "scanner_name", "scan_last_detected_date")})
        if pv["source"]:
            srcs.add(pv["source"])
        scanners.add(r.get("scanner_name") or "")
        if r.get("dependency_type"):
            deps.add(str(r.get("dependency_type")))
        if r.get("source_file_path"):
            manifests.add(str(r.get("source_file_path")))
        firsts.append(r.get("scan_first_detected_date"))
        lasts.append(pv["when"])            # the raw time; the formatted one cannot be compared
    return {"found": True, "fixed_versions": sorted(fixed), "sources": sorted(srcs), "dependency": sorted(deps),
            "manifests": sorted(manifests)[:5], "first_seen": pt(min((f for f in firsts if f), default=None)),
            "as_of": pt(latest(lasts)), "rows": len(rows)}


CODE_COLS = ["cwe_id", "source_commit_id", "scan_first_detected_date", "scan_last_detected_date", "vulnerability_status",
             "is_suppressed", "is_false_positive", "scanner_name", "scan_type", "vulnerability_name", "scan_line", "scan_end_line",
             "scan_rule_id", "scan_rule_help_uri", "scan_confidence", "scan_impact", "scan_likelihood", *PROV]


@rule("path.code_facts", 1)
def code_facts(ctx, repo: str, path: str, scanner_rule: str | None, vuln_ids: list) -> dict:
    """The scanner's own record of a code finding (read by the scanner row ids when known): line, rule, confidence, CWE, commit, first and last reported and whether it
    is still reported. Derived columns extract the line and the rule fields, so the flagged source line is never read."""
    # The scanner row's own id is the primary key: a keyed read. Without it, repository + file is an unindexed scan of the
    # whole table (about 3 s at 336k rows), so it is only the fallback for an alert that carries no scanner id.
    where = [["torana_vulnerability_id", "in", sorted(vuln_ids)], LIVE] if vuln_ids else [["torana_repository_id", "=", repo], ["source_file_path", "=", path], LIVE]
    rows = ctx.select("vulnerabilities", where, CODE_COLS)
    rows = [r for r in rows if r.get("scan_type") != "SCA" and (not scanner_rule or r.get("scan_rule_id") in (None, scanner_rule))]
    if not rows:
        return {"found": False}
    r = rows[0]
    pv = provenance("vulnerabilities", {c: r.get(c) for c in (*PROV, "scanner_name", "scan_last_detected_date")})
    lines = sorted({int(x.get("scan_line")) for x in rows if str(x.get("scan_line") or "").isdigit()})
    return {"found": True, "lines": lines, "end_line": r.get("scan_end_line"), "rule": r.get("scan_rule_id") or scanner_rule,
            "rule_uri": r.get("scan_rule_help_uri"), "confidence": r.get("scan_confidence"), "impact": r.get("scan_impact"),
            "likelihood": r.get("scan_likelihood"), "cwe": r.get("cwe_id"), "commit": r.get("source_commit_id"),
            "first_seen": pt(r.get("scan_first_detected_date")), "last_reported": pt(r.get("scan_last_detected_date")),
            "status": r.get("vulnerability_status"), "suppressed": bool(r.get("is_suppressed")),
            "false_positive": bool(r.get("is_false_positive")), "name": r.get("vulnerability_name"),
            "source": pv["source"], "as_of": pv["as_of"], "rows": len(rows)}


def _parse_member(key: str) -> dict | None:
    """`finding:finding_key=CVE|ecosystem|package|version|place` (or the bare finding key) -> its parts."""
    k = str(key or "")
    k = k.split("finding_key=", 1)[-1] if k.startswith("finding:") else k
    parts = k.split("|", 4)
    if len(parts) < 5 or not parts[0] or not parts[4]:
        return None
    return {"cve": parts[0], "ecosystem": parts[1], "package": parts[2], "version": parts[3], "place": parts[4]}


def is_image(place) -> bool:
    return str(place).startswith(("image:", "image@"))


@rule("path.resolve_places", 1)
def resolve_places(ctx, places: list) -> dict:
    """A scanner finding names its image by digest only (`image@sha256:<digest>`); the entity graph keys it by registry path
    and digest (`image:<registry path>@sha256:<digest>`). Resolve each digest to the graph's key from the edges that name it
    (`deployed_as` from the image, `builds_image` to it). A digest no edge names stays as written: nothing reaches it."""
    digests = {p: str(p).split("@", 1)[1] for p in places if str(p).startswith("image@sha256:")}
    if not digests:
        return {"resolved": {}}
    tails = sorted({f"@{d}" for d in digests.values()})
    keys: dict = {}
    for col, kind in (("from_key", "deployed_as"), ("to_key", "builds_image")):
        for e in ctx.select("entity_edges", [["edge_type", "=", kind], [col, "suffix_any", tails], LIVE], [col, "edge_type", "is_deleted"]):
            k = e.get(col) or ""
            if k.startswith("image:"):
                keys[k.split("@", 1)[1]] = k
    return {"resolved": {p: keys[d] for p, d in digests.items() if d in keys}}


def _resolve(ctx, group: dict) -> dict:
    """The group with every place keyed the way the entity graph keys it."""
    mapping = ctx.call("path.resolve_places", places=sorted(group["places"]))["resolved"]
    if not mapping:
        return group
    places: dict = {}
    for p, d in group["places"].items():
        t = places.setdefault(mapping.get(p, p), {"cves": [], "versions": []})
        t["cves"] = sorted({*t["cves"], *d["cves"]})
        t["versions"] = sorted({*t["versions"], *d["versions"]})
    return {**group, "places": places}


def _group(parsed: list, other: int, total: int) -> dict:
    places: dict = {}
    for m in parsed:
        d = places.setdefault(m["place"], {"cves": [], "versions": []})
        d["cves"] = sorted({*d["cves"], m["cve"]})
        d["versions"] = sorted({*d["versions"], m["version"]})
    pkgs = sorted({m["package"] for m in parsed})
    return {"available": total > 0, "count": total, "parsed": len(parsed), "other": other, "places": places,
            "package": pkgs[0] if len(pkgs) == 1 else None, "packages": pkgs,
            "ecosystem": parsed[0]["ecosystem"] if parsed else None,
            "versions": sorted({m["version"] for m in parsed}), "cves": sorted({m["cve"] for m in parsed})}


@rule("path.entry_members", 1)
def entry_members(ctx, alert_id: str) -> dict:
    """The entry's own open members: its linked member alerts' finding keys, read once by the datalake route from the detection
    framework's `entry_members` view (one projected column) and served as `api.alert.entry_member_keys`. This is the ANCHOR:
    every member the entry counts, below-floor ones included, and none the ranking merely routed elsewhere."""
    a = ctx.row("api.alert", alert_id)
    keys = a.get("entry_member_keys") if a else None
    if not keys:
        return {"available": False, "count": 0, "parsed": 0, "other": 0, "places": {}, "package": None, "packages": [],
                "ecosystem": None, "versions": [], "cves": []}
    parsed = [m for m in (_parse_member(k) for k in keys) if m]
    return _resolve(ctx, _group(parsed, len(keys) - len(parsed), len(keys)))


@rule("path.finding_member", 1)
def finding_member(ctx, finding_key: str | None) -> dict:
    """A single finding as an anchor (a posture finding's own key): one member."""
    m = _parse_member(finding_key or "")
    return _resolve(ctx, _group([m] if m else [], 0 if m else (1 if finding_key else 0), 1 if finding_key else 0))
