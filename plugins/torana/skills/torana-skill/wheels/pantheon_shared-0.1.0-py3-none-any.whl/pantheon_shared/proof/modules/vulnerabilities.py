"""vulnerabilities — findings and what the scanner said about them.

Sources: vulnerabilities (canonical) and vm_cve_metadata (global CVE reference).
"""
from ..core.engine import rule

ISSUE = "scan_output.vulnerability.packageIssue.0"


@rule("vulnerabilities.package_origin", 1)
def package_origin(ctx, vuln_id: str) -> dict:
    """What the scanner says about the package: type, file, image layer, base image and fix kind
    (read from the raw occurrence the scanner sent)."""
    v = ctx.row("vulnerabilities", vuln_id)
    if not v:
        return {"found": False}
    bases = v.get(ISSUE + ".fileLocation.0.layerDetails.baseImages") or []
    return {
        "found": True,
        "affected_package": v.get(ISSUE + ".affectedPackage"),
        "affected_version": v.get(ISSUE + ".affectedVersion.fullName"),
        "package_type": v.get(ISSUE + ".packageType"),
        "cpe": v.get(ISSUE + ".affectedCpeUri"),
        "file": v.get(ISSUE + ".fileLocation.0.filePath"),
        "layer_command": v.get(ISSUE + ".fileLocation.0.layerDetails.command"),
        "layer_diff": (v.get(ISSUE + ".fileLocation.0.layerDetails.diffId") or "")[:12] or None,
        "base_images": ", ".join(f"{b.get('registry', '')}{b.get('repository', '')}" for b in bases) or None,
        "fix_kind": v.get(ISSUE + ".fixedVersion.kind"),
        "advisory": v.get("scan_output.vulnerability.relatedUrls.0.url"),
        "occurrence": v.get("scan_output.name"),
    }


@rule("vulnerabilities.disclosure_vs_detection", 1)
def disclosure_vs_detection(ctx, cve: str, first_detected: str | None) -> dict:
    """Was the package already shipped when the CVE was published?
    disclosed_against_shipped = published on or before the first detection on this service."""
    m = ctx.row("vm_cve_metadata", cve)
    pub = m.get("published_date") if m else None
    if not pub or not first_detected:
        return {"relation": "unknown", "published": pub}
    rel = "disclosed_against_shipped" if str(pub)[:19] <= str(first_detected)[:19] else "introduced_after_disclosure"
    return {"relation": rel, "published": pub}


@rule("vulnerabilities.source_freshness", 1)
def source_freshness(ctx, vuln_id: str) -> dict:
    """When the scanner last reported this finding (the newest last_seen across its contributing sources),
    and how old that is at build time. Recompute cannot make a source fresher; it can only say how fresh it is."""
    v = ctx.row("vulnerabilities", vuln_id)
    srcs = (v.get("contributing_sources") if v else None) or {}
    if isinstance(srcs, str):
        import json
        srcs = json.loads(srcs)
    last = max((s.get("last_seen") or "" for s in srcs.values()), default=None) or None
    now = ctx.now
    from datetime import datetime
    age_h = None
    if last:
        age_h = round((datetime.fromisoformat(now.replace("Z", "+00:00")) - datetime.fromisoformat(last.replace("Z", "+00:00"))).total_seconds() / 3600, 1)
    return {"last_reported": last, "age_hours": age_h, "sources": len(srcs)}
