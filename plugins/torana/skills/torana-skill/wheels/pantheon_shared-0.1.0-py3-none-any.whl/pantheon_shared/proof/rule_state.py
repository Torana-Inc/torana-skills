"""One definition of "a check failed", for the trust line (home.trust) and the health strip (health.health).

They disagreed: trust counted every status that was not SUCCESS (so a run still RUNNING, or CANCELLED, was "failed"),
health counted only FAILED. A check has failed only when its last run's status is FAILED and it has run at all.
"""
from __future__ import annotations


def last_run_failed(rule: dict) -> bool:
    return not rule.get("never_ran") and str(rule.get("last_status") or "").upper() == "FAILED"
