"""code — a code finding (SAST, IaC, secrets: one scanner rule in one file of one repository).

Source: the ranking's posture finding `code|<rule>|repo:<repo>|<file>` and the scanner reports merged into it
(posture_scanner_reports, one per flagged line: merge_rule "same scanner rule and file, several lines").
Path to running software (entity graph): repo -builds_image-> image -deployed_as-> service.

⚠️ A code scanner (Semgrep, claude_review) reports no lifecycle: it never closes a finding. A finding is gone only
when a later scan no longer lists it (posture_findings.closure_signal says so per row).
"""
from ..core.engine import rule


def _flagged(r, col: str) -> bool:
    return r.get(col) is True


@rule("code.reports", 1)
def reports(ctx, finding_key: str) -> dict:
    """What the scanner reports behind one code finding say: the flagged lines (each once, ascending), how many
    reports there are, when it was first and last reported, how many are withdrawn, suppressed, false positive or
    risk accepted, and the rule's own classification (rule_class, rule_confidence, rule_likelihood, rule_impact,
    scan_type), read from the first report in key order (every report of one finding is one rule)."""
    rows = sorted(ctx.select("posture_scanner_reports", [["finding_key", "=", finding_key]]), key=lambda r: str(r.key))
    lines = sorted({int(r.get("source_line")) for r in rows if str(r.get("source_line") or "").isdigit()})
    seen = [str(r.get("last_seen_at")) for r in rows if r.get("last_seen_at")]
    first = [str(r.get("first_seen_at")) for r in rows if r.get("first_seen_at")]
    r0 = rows[0] if rows else None
    meta = {c: (r0.get(c) if r0 else None) for c in ("rule_class", "rule_confidence", "rule_likelihood",
                                                     "rule_impact", "scan_type", "scanner_label")}
    # The scanner row ids (`report_id` is the vulnerabilities primary key): the path reads the scanner's own rows by key.
    ids = sorted({str(r.get("report_id")) for r in rows if r.get("report_id")})
    return {"reports": len(rows), "report_ids": ids, "lines": ", ".join(map(str, lines)) or None, "line_count": len(lines),
            "first_seen": min(first) if first else None, "last_seen": max(seen) if seen else None,
            "open": sum(1 for r in rows if r.get("status") == "open"),
            "withdrawn": sum(_flagged(r, "is_withdrawn") for r in rows),
            "suppressed": sum(_flagged(r, "is_suppressed") for r in rows),
            "false_positive": sum(_flagged(r, "is_false_positive") for r in rows),
            "risk_accepted": sum(_flagged(r, "is_risk_accepted") for r in rows),
            **meta}


@rule("code.ships", 1)
def ships(ctx, repo: str | None) -> dict:
    """Does the repository's code reach running software? Its builds_image edges (every image it built), the
    deployed_as edges from those images, and the services they reach (each once, sorted).
    recorded = the repository has at least one builds_image edge; without one, whether its code ships is not
    recorded (never "does not ship")."""
    if not repo:
        return {"recorded": False, "images": 0, "deployed_images": 0, "services": [], "service_count": 0}
    built = ctx.select("entity_edges", [["edge_type", "=", "builds_image"], ["from_key", "=", repo],
                                        ["is_deleted", "=", False]])
    imgs = sorted({e.get("to_key") for e in built if e.get("to_key")})
    dep = ctx.select("entity_edges", [["edge_type", "=", "deployed_as"], ["from_key", "in", imgs],
                                      ["is_deleted", "=", False]]) if imgs else []
    svcs = sorted({e.get("to_key") for e in dep if e.get("to_key")})
    return {"recorded": bool(imgs), "images": len(imgs), "deployed_images": len({e.get("from_key") for e in dep}),
            "services": svcs, "service_count": len(svcs)}
