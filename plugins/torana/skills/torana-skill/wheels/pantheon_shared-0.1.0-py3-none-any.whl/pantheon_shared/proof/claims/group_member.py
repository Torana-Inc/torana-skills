"""One ROW of a group check (APP_PROFILES_SPEC § 3.3.4): its own path, drawn from the columns the check's rule returned for
that row (the alert's `rule_run_results`) plus what the entity graph says around the row's node (modules/members.py).

A group check is a set, so its root has no graph; each row can. Nothing is added beyond the row and the graph. Edge
styles say how each link is known: a source observation the rule restates (SOC flagged it, the account logged on, the
firewall saw flows) is `reported`; the check's own conclusion (not through PAM, DR gap) is `derived`; a host NAME matched to
an inventory host is `heuristic`; an entity-graph edge (owns, runs_on) is `reported`.

⚠️ The rule lists some facts as separate lists that it never pairs (a PAM row's accounts and its source workstations), so
each list attaches to the row's node on its own; drawing account → workstation would state a pairing nobody reported.
"""
from __future__ import annotations

import json
import re

from .alert_facts import R, title_and_sub
from .path import _edge, _meta, _node
from .vuln_in_image import claim

RR = "rule_run_results.0."
SHOWN = 3                                              # names drawn per column before a "+K more" node
_SOC = re.compile(r"SOC-[A-Z]+-\d+")


def _list(v) -> list[str]:
    """A list the rule returned as text: `a, b`, `a; b`, or a JSON/Python list literal (`[443]`, `['x', 'y']`)."""
    if v in (None, "", "None"):
        return []
    if isinstance(v, (list, tuple)):
        return [str(x) for x in v if str(x).strip()]
    s = str(v).strip()
    if s.startswith("["):
        try:
            return [str(x) for x in json.loads(s.replace("'", '"')) if str(x).strip()]
        except ValueError:
            s = s.strip("[]")
    return [x.strip().strip("'\"") for x in re.split(r"[;,]", s) if x.strip().strip("'\"")]


def _badge(name) -> str | None:
    """The finding in the row's own words: its alert name up to the first ':' ("Not in CMDB: 10.20.23.33, …")."""
    return str(name).split(":", 1)[0].strip() if name else None


def _short(node_key: str) -> str:
    return node_key.split(":", 1)[-1].rsplit("/", 1)[-1]


def _names(nid, col, rows, names, t2, p, meta=None):
    """Up to SHOWN name nodes down one column (rows −1, 0, 1), the last one a "+K more" when there are more."""
    out = []
    shown = names if len(names) <= SHOWN else names[:SHOWN - 1]
    for i, n in enumerate(shown):
        out.append(_node(f"{nid}{i}", col, rows[i], n, t2, p, meta))
    if len(names) > SHOWN:
        hidden = names[SHOWN - 1:]
        out.append(_node(f"{nid}-more", col, rows[SHOWN - 1], f"+{len(hidden)} more", t2, p,
                         _meta([], None, None, None, [{"label": h, "url": None} for h in hidden])))
    return out


def build_group_member(build, alert_id: str) -> dict:
    ctx = build.ctx()
    a = ctx.row("api.alert", alert_id)
    title, sub = title_and_sub(ctx, alert_id)
    item = {"alert_id": alert_id, "type": "group_member", "finding_id": None, "chips": [], "title": title, "sub": sub,
            "claims": [claim("row", "row", "Which check is this a row of?", "A row of check {check} ({group}).",
                             {"check": R(a, RR + "check_id"), "group": R(a, RR + "group_key")},
                             today="code: claims.group_member")]}
    item["graph"] = _about(ctx, _graph(ctx, a))
    return item


def _graph(ctx, a) -> dict:
    v = lambda col: R(a, RR + col)                                  # noqa: E731 — (value, pointer) of one row cell
    entity, _ = R(a, "entity_type")
    rule_name, _ = R(a, "rule_name")
    name, name_p = R(a, "name")
    badge = _badge(name)
    src = {"source": f"check rule {rule_name}" if rule_name else None, "as_of": None}
    if entity == "identity":
        return _identity(ctx, v, badge, name_p, src)
    if entity == "network_host":
        return _network(v, badge, name_p, src)
    if entity == "dr_parity":
        return _parity(v, badge, name_p, src)
    return _host(ctx, v, badge, name_p, src)


def _host(ctx, v, badge, name_p, src) -> dict:
    key, key_p = v("ci_key")
    host, host_p = v("hostname")
    ip, _ = v("ip")
    role, _ = v("role")
    app, app_p = v("application")
    tier, _ = v("tier")
    env, _ = v("environment")
    N, E = [], []
    N.append(_node("h", 2, 0, host or _short(key or "") or "host", badge or "", host_p or key_p,
                   _meta([("IP", ip), ("Role", role), ("Application", app), ("Tier", tier), ("Environment", env),
                          ("Node", key)], None, src["source"]), me=True, _host=host))
    # The row's evidence: where the finding came from.
    rules, rules_p = v("internet_inbound_rule_ids")
    ports, _ = v("internet_inbound_port_labels")
    if rules:
        N.append(_node("inet", 0, 0, "Internet", "inbound", rules_p, cls="inet"))
        E.append(_edge("inet", "h", " · ".join(x for x in ("flagged by " + ", ".join(_list(rules)), ", ".join(_list(ports))) if x),
                       rules_p, src))
    srcs, srcs_p = v("outside_pam_src_hosts")
    if srcs:
        soc, _ = v("outside_pam_soc_rules")
        N.append(_node("ws", 0, 0, ", ".join(_list(srcs)), "source workstations", srcs_p))
        E.append(_edge("ws", "h", "privileged session, not via PAM" + (f" · {', '.join(_SOC.findall(str(soc)))}" if soc else ""),
                       srcs_p, src, style="derived"))
    accts, accts_p = v("outside_pam_accounts")
    if accts:
        # Column 1, not 0: two edges over one column pair share ONE label slot, and "as" would sit on the session curve.
        N.append(_node("acct", 1, 1, ", ".join(_list(accts)), "accounts", accts_p))
        E.append(_edge("acct", "h", "as", accts_p, src))
    fw, fw_p = v("fw_observed_ports")
    egress, egress_p = v("egress_unallowlisted_hits")
    if fw and not rules:
        N.append(_node("fw", 0, 0, "Firewall logs", "observed", fw_p))
        E.append(_edge("fw", "h", "ports " + ", ".join(_list(fw)), fw_p, src))
    elif egress:
        N.append(_node("fw", 0, 0, "Firewall logs", "egress", egress_p))
        E.append(_edge("h", "fw", f"{egress} egress hit(s) not allowlisted", egress_p, src))
    # What the row's CMDB columns say it is part of.
    if app:
        N.append(_node("app", 3, -1, str(app), " · ".join(str(x) for x in (tier, env) if x), app_p))
        E.append(_edge("h", "app", "part of", app_p, src))
    # What the entity graph says around the node.
    if key:
        res = ctx.call("members.neighbours", node=key, names=[])
        owners, owners_p = res.p("owners")
        services, services_p = res.p("services")
        prov = res.outputs.get("owners_prov") or {}
        if owners:
            N.append(_node("team", 3, 1, ", ".join(owners), "owning team", owners_p, _meta([], None, prov.get("source"), prov.get("as_of")),
                           _teams=owners))
            E.append(_edge("h", "team", "owned by", owners_p, prov))
        sprov = res.outputs.get("services_prov") or {}
        if services:                                   # one node (column 1, top): the first service, then "+K more"
            label = _short(services[0]) + (f" +{len(services) - 1} more" if len(services) > 1 else "")
            N.append(_node("svc0", 1, -1, label, "service" if len(services) == 1 else "services", services_p,
                           _meta([], None, sprov.get("source"), sprov.get("as_of"),
                                 [{"label": _short(x), "url": None} for x in services]) if len(services) > 1 else None))
            E.append(_edge("svc0", "h", "runs on", services_p, sprov))
    elif (owner := v("owner"))[0]:
        N.append(_node("team", 3, 1, str(owner[0]), "owner (CMDB)", owner[1], _teams=[str(owner[0])]))
        E.append(_edge("h", "team", "owned by", owner[1], src))
    return {"nodes": N, "edges": E, "note": None, "blast": []}


def _identity(ctx, v, badge, name_p, src) -> dict:
    acct, acct_p = v("account")
    kind, _ = v("account_kind")
    da, _ = v("is_domain_admin")
    N = [_node("acct", 1, 0, str(acct or "account"), badge or "", acct_p,
               _meta([("Kind", kind), ("Domain admin", "yes" if str(da) in ("True", "true") else "no" if da is not None else None)],
                     None, src["source"]), me=True)]
    E = []
    hosts, hosts_p = v("hosts_logged_into")
    label, style = "logged on to", "reported"
    if not hosts:
        hosts, hosts_p = v("hosts_outside_pam")
        soc, _ = v("soc_rules_outside_pam")
        label = "privileged session, not via PAM" + (f" · {', '.join(_SOC.findall(str(soc)))}" if soc else "")
        style = "derived"
    names = _list(hosts)
    srcs, srcs_p = v("src_hosts_outside_pam")
    if srcs:
        N.append(_node("ws", 0, 0, ", ".join(_list(srcs)), "source workstations", srcs_p))
        E.append(_edge("ws", "acct", "logged on from", srcs_p, src))
    if names:
        res = ctx.call("members.neighbours", node=None, names=names)
        by_name, by_name_p = res.p("by_name")
        owners_of = res.outputs.get("name_owners") or {}
        rows = [-1, 0, 1] if len(names) > 1 else [0]
        for n in _names("host", 2, rows, names, "server", hosts_p):
            if not n["id"].endswith("-more"):
                n["_host"] = n["t1"]
            N.append(n)
            E.append(_edge("acct", n["id"], label, hosts_p, src, style=style))
            key = (by_name or {}).get(str(n["t1"]).lower())
            teams = owners_of.get(key) if key else None
            if teams:
                tid = f"team-{n['id']}"
                N.append(_node(tid, 3, n["row"], ", ".join(teams), "owning team (by name)", by_name_p, _meta([("Inventory host", key)]),
                               _teams=teams))
                E.append(_edge(n["id"], tid, "owned by", by_name_p, None, style="heuristic"))
    return {"nodes": N, "edges": E, "note": None, "blast": []}


def _network(v, badge, name_p, src) -> dict:
    ip, ip_p = v("ip")
    ident, _ = v("identification")
    N = [_node("ip", 1, 0, str(ip or "IP"), badge or "", ip_p,
               _meta([("Identification", ident), ("Flows", v("fw_flow_count")[0]), ("First seen", v("fw_first_seen_at")[0]),
                      ("Last seen", v("last_seen_at")[0])], None, src["source"]), me=True)]
    E = []
    flows, flows_p = v("fw_flow_count")
    ports, _ = v("fw_observed_ports")
    if flows or ports:
        N.append(_node("fw", 0, 0, "Firewall logs", "observed", flows_p))
        E.append(_edge("fw", "ip", " · ".join(x for x in (f"{flows} flows" if flows else "", "port " + ", ".join(_list(ports)) if ports else "") if x),
                       flows_p, src))
    seen, seen_p = v("observed_hostnames")
    for i, h in enumerate(_list(seen)[:SHOWN]):
        N.append(_node(f"hn{i}", 2, [0, -1, 1][i], h, "observed name", seen_p, _host=h))
        E.append(_edge("ip", f"hn{i}", "seen as", seen_p, src))
    return {"nodes": N, "edges": E, "note": None, "blast": []}


def _parity(v, badge, name_p, src) -> dict:
    pk, pk_p = v("parity_key")
    prod, prod_p = v("production_hosts")
    dr, dr_p = v("dr_hosts")
    gap, gap_p = v("dr_gap")
    N = [_node("pk", 1, 0, str(pk or "application"), badge or "", pk_p, me=True),
         _node("prod", 0, 0, ", ".join(_list(prod)) or "none", "production", prod_p),
         _node("dr", 2, 0, ", ".join(_list(dr)) or "none", "DR", dr_p)]
    E = [_edge("prod", "pk", "production hosts", prod_p, src),
         _edge("pk", "dr", f"DR gap {gap}" if gap is not None else "in DR", gap_p, src, style="derived")]
    return {"nodes": N, "edges": E, "note": None, "blast": []}



# ── what a node IS (its panel) ───────────────────────────────────────────────────────────────────────────────────────────
_PLURAL = {"host": "hosts", "repo": "repositories", "service": "services", "image": "images", "identity": "identities"}


def _about(ctx, graph: dict) -> dict:
    """Fill each host and team node's panel with what the inventory says it is (members.node_facts): a host's CMDB record
    (description, role, OS, IP, location, status) and every other source that knows it (EDR, scanner), a team's identity
    row and what it owns. The `_host` / `_teams` tags the builders set are dropped here; a node the inventory does not know
    keeps the panel the row's own columns gave it."""
    nodes = graph.get("nodes") or []
    hosts = sorted({str(n["_host"]).lower() for n in nodes if n.get("_host")})
    teams = sorted({f"team:{t}" for n in nodes for t in n.get("_teams") or [] if t})
    facts = ctx.call("members.node_facts", hosts=hosts, teams=teams) if hosts or teams else None
    for n in nodes:
        host, tms = n.pop("_host", None), n.pop("_teams", None)
        if not facts:
            continue
        recs = (facts.get("hosts") or {}).get(str(host).lower()) if host else None
        if recs:
            n["meta"] = _host_meta(recs, n.get("meta"))
        elif tms:
            m = _team_meta([(t, (facts.get("teams") or {}).get(f"team:{t}")) for t in tms])
            if m:
                n["meta"] = m
    return graph


def _row_value(meta, label):
    return next((v for k, v in (meta or {}).get("rows") or [] if k == label and v != "unknown"), None)


def _host_meta(recs: list, fallback: dict | None) -> dict:
    """The CMDB record first (what the host is), then which sources know it. A host no CMDB record names says so: that is
    the finding for a shadow host, never left blank."""
    cmdb = next((r for r in recs if r["system"] == "servicenow"), None)
    c = cmdb or recs[0]
    first = lambda f: next((r[f] for r in recs if r.get(f)), None)       # noqa: E731 — the first source that states it
    rows = [("Description", c["description"]), ("Role", c["role"] or _row_value(fallback, "Role")),
            ("Application", c["application"] or _row_value(fallback, "Application")),
            ("Environment", c["environment"] or _row_value(fallback, "Environment")),
            ("Tier", c["tier"] or _row_value(fallback, "Tier")), ("Business impact", c["impact"]),
            ("Operating system", first("os")), ("IP", first("ip") or _row_value(fallback, "IP")), ("FQDN", first("fqdn")),
            ("Location", c["location"]), ("CI class", c["ci_class"]), ("Status", c["status"]), ("Owner", first("owner")),
            ("In the CMDB", "yes" if cmdb else "no"),
            ("Known to", ", ".join(dict.fromkeys(str(r["source"] or r["system"]) for r in recs)))]
    items = []
    for r in recs:                                    # one line per source record, in words: never its key (the panel's rule)
        bits = [x for x in (f"last seen {r['last_seen']}" if r["last_seen"] else None,
                            f"last scan {r['last_scan']}" if r["last_scan"] else None,
                            f"agent {r['agent']}" if r["agent"] else None) if x] or [f"{r['type'] or 'host'} record"]
        items.append({"label": f"{r['source'] or r['system']} — {' · '.join(bits)}", "url": None})
    m = _meta([(k, v) for k, v in rows if v not in (None, "", [])], None, c["source"], c["as_of"],
              items)
    return m or fallback


def _team_meta(teams: list) -> dict | None:
    """One team: its kind, status, how the platform knows it, and what it owns. Several (a node naming more than one): one
    line each."""
    known = [(t, f) for t, f in teams if f and (f.get("found") or f.get("owns"))]
    if not known:
        return None
    def owns(f):
        return ", ".join(f"{n} {_PLURAL.get(k, k) if n != 1 else k}" for k, n in (f.get("owns") or {}).items()) or None
    if len(known) == 1:
        t, f = known[0]
        return _meta([("Name", f.get("name") or t), ("Kind", f.get("type")), ("Status", f.get("status")), ("Owns", owns(f)),
                      ("Known from", str(f.get("how") or "").replace("_", " ") or None)], None, f.get("source"), f.get("as_of"))
    f0 = known[0][1]
    return _meta([], None, f0.get("source"), f0.get("as_of"),
                 [{"label": f"{t}" + (f" · owns {owns(f)}" if owns(f) else ""), "url": None} for t, f in known])
