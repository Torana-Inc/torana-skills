"""Is a Home card older than what it describes? (HB-7, 2026-10-14; Bhakta's decision: MARK THE CARD, never re-narrate.)

A page is narrated once. When an Inbox entry a card describes changes after that (its title, status, target version…),
the card keeps the old words: T1, entry 1bdc2f6a was corrected to "Upgrade litellm to 1.88.6" and Home still said
"Upgrade litellm to 1.96.2", with nothing on the page saying the card predates the change.

⭐ ONE COMPUTATION. `changes()` decides what changed and writes the words; `mark()` puts them on the needs-you lines.
The API serves both (`changes` on the page, the lines in `sections`); the screen and the CLI print them as sent.
PURE like home_sections: the caller reads the live rows (one batched read of the page's own ids) and passes them in.

What counts as a change is a fixed list of the alert's OWN fields that the page's words are built from, compared with
the snapshot the run stored when it was prepared (`facts.alerts.items`). `updated_at` alone is never a change: it moves
on every rule re-run whether or not anything the card says moved. An item with no stored snapshot (beyond the 200 the
collector reads) is not judged: no baseline, no claim.
"""
from __future__ import annotations

from datetime import datetime

from .home_sections import _line, _when

#: (alert field, what a reader calls it). Only fields the stored snapshot carries are compared, so a run stored before
#: a field was snapshotted never reads as changed on it.
CHANGE_FIELDS = (("name", "title"), ("status", "status"), ("severity", "severity"), ("triage_verdict", "verdict"),
                 ("remediation_target_version", "target version"), ("findings_cleared", "findings it clears"))
#: The needs-you line kinds that stand for an Inbox item, and where their alert id sits in `parts`.
_ITEM_KINDS = ("card", "row", "member")
#: At most this many ids are read live per page (the inter-service GET rule, root CLAUDE.md: limit=100).
MAX_IDS = 100
CHECK_FAILED = "Could not check whether these items changed since the page was prepared."


def _ids_of(ln: dict) -> list:
    p = ln.get("parts") or {}
    return [str(x) for x in (p.get("alert_id"), p.get("lead"), p.get("brief")) if x]


def page_alert_ids(sections: list | None) -> list:
    """The Inbox items the needs-you card describes, in page order, at most MAX_IDS."""
    block = next((b for b in sections or [] if b.get("key") == "needs_you"), None) or {}
    ids = [i for ln in block.get("lines") or [] if ln.get("kind") in _ITEM_KINDS for i in _ids_of(ln)]
    return list(dict.fromkeys(ids))[:MAX_IDS]


def _norm(field: str, v):
    if v is None:
        return None
    return str(v).strip().lower() if field in ("status", "severity", "triage_verdict") else v


def _show(v) -> str:
    s = str(v).replace("_", " ") if v is not None else "none"
    return f"“{s}”" if len(s) > 12 or " " in s else s


def changes(snapshot_items: list | None, current: dict, ids: list, *, prepared_at, tz: str | None = None) -> list:
    """One change per id whose live row differs from the run's snapshot on a CHANGE_FIELDS field, or which is no
    longer an Inbox entry (absent from `current`). `current` = {alert_id: live alert row} for exactly `ids`.
    Each: {alert_id, gone, fields: [{field, label, then, now}], changed_at, text}. `changed_at` is the live row's
    `updated_at`: the change happened after the page and at or before it."""
    snap = {str(a.get("id")): a for a in snapshot_items or [] if isinstance(a, dict) and a.get("id")}
    when_prepared = _when(prepared_at, tz)
    out = []
    for aid in ids:
        then = snap.get(aid)
        if then is None:
            continue
        now = current.get(aid)
        if now is None:
            text = ("May be out of date: since this page was prepared" + (f" {when_prepared}" if when_prepared else "")
                    + ", this item stopped being an Inbox entry (deleted, or merged into another).")
            out.append({"alert_id": aid, "gone": True, "fields": [], "changed_at": None, "text": text})
            continue
        fields = [{"field": f, "label": label, "then": then.get(f), "now": now.get(f)} for f, label in CHANGE_FIELDS
                  if f in then and f in now and _norm(f, then.get(f)) != _norm(f, now.get(f))]
        if not fields:
            continue
        what = "; ".join(f"its {x['label']} is now {_show(x['now'])} (was {_show(x['then'])})" for x in fields)
        updated = _when(now.get("updated_at"), tz)
        text = (f"May be out of date: since this page was prepared{' ' + when_prepared if when_prepared else ''}, "
                f"{what}" + (f". Last updated {updated}." if updated else "."))
        out.append({"alert_id": aid, "gone": False, "fields": fields, "changed_at": now.get("updated_at"), "text": text})
    return out


def summary(found: list) -> str | None:
    """The one sentence above the card list: how many items changed after the page was prepared."""
    n = len(found or [])
    if not n:
        return None
    return (f"◐ {n} item{'' if n == 1 else 's'} on this card changed after this page was prepared; "
            f"{'its line is' if n == 1 else 'their lines are'} marked “May be out of date”.")


def mark(sections: list | None, found: list | None, *, checked: bool = True) -> list | None:
    """The needs-you block with a `changed` line (marker `watch`, ◐) under every item line whose Inbox item changed,
    and the summary as its first note. `checked=False` (the live read failed) says so once instead of marking.
    Returns the same list, the needs-you block replaced; other blocks untouched."""
    if not sections:
        return sections
    by_id = {c["alert_id"]: c for c in found or []}
    out = []
    for b in sections:
        if b.get("key") != "needs_you":
            out.append(b)
            continue
        b = {**b, "notes": list(b.get("notes") or [])}
        if not checked:
            b["notes"].append(CHECK_FAILED)
            out.append(b)
            continue
        lines, seen = [], set()
        for ln in b.get("lines") or []:
            # A group card's lead is printed as its own row right under it, so only the INSIGHT card (whose lead is
            # not a row) is marked itself; every row and member line is marked under its own text.
            markable = ln.get("kind") in ("row", "member") or (
                ln.get("kind") == "card" and (ln.get("parts") or {}).get("card_kind") == "insight")
            hit = next((by_id[i] for i in _ids_of(ln) if i in by_id), None) if markable else None
            if hit is None or (hit["alert_id"], ln.get("kind")) in seen:
                lines.append(ln)
                continue
            seen.add((hit["alert_id"], ln.get("kind")))
            lines.append({**ln, "parts": {**(ln.get("parts") or {}), "out_of_date": True}})
            lines.append(_line("changed", hit["text"], marker="watch", indent=int(ln.get("indent") or 0) + 1,
                               commands=[f"torana alert {hit['alert_id']} inbox"],
                               source={"kind": "alert", "id": hit["alert_id"]},
                               parts={"alert_id": hit["alert_id"], "gone": hit["gone"], "fields": hit["fields"],
                                      "changed_at": hit["changed_at"]}))
        b["lines"] = lines
        s = summary([c for c in found or [] if any(c["alert_id"] in _ids_of(x) for x in lines
                                                   if x.get("kind") in _ITEM_KINDS)])
        if s:
            b["notes"].insert(0, s)
        out.append(b)
    return out


def page_changes(found: list | None, *, checked: bool, checked_at: datetime | None, prepared_at) -> dict:
    """The page-level field: what was checked, when, and every change found (the same objects the lines carry)."""
    return {"checked": checked, "checked_at": checked_at.isoformat() if checked_at else None,
            "prepared_at": prepared_at.isoformat() if isinstance(prepared_at, datetime) else prepared_at,
            "note": summary(found) if checked else CHECK_FAILED, "items": list(found or [])}
