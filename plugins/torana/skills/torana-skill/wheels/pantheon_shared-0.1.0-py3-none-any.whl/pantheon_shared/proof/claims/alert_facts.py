"""Claims every item carries about its own alert (section `alert`), so any row can cite what was raised and
where it stands. Also the unmodelled item: those claims and the reason there is no model (shared#152), and, when
the alert carries a posture finding that is in the ranking, that finding's fan-out graph."""
from ..core.render import render
from .vuln_in_image import _unmodelled_reason, claim


def R(row, path, fmt=None):
    """(value, pointer[, formatter]) for one cell of a row that may be absent."""
    if row is None:
        return (None, None, fmt) if fmt else (None, None)
    val, ptr = row.p(path)
    return (val, ptr, fmt) if fmt else (val, ptr)


def O(res, out, fmt=None):
    """(value, pointer[, formatter]) for one output of a rule result that may be absent."""
    if res is None:
        return (None, None, fmt) if fmt else (None, None)
    val, ptr = res.p(out)
    return (val, ptr, fmt) if fmt else (val, ptr)


def claims(build, alert_id: str) -> list[dict]:
    ctx = build.ctx()
    a = ctx.row("api.alert", alert_id)
    # The item's ONE severity in words (the finding's, or for a rule's own condition the rule's declared one; "Not recorded" / "Not declared"
    # when it has none). `severity` is the rule's stored placeholder, so it is read only from a server that does not send the label yet.
    sev_path = "entry_severity_label" if a is not None and a.get("entry_severity_label") is not None else "severity"
    return [
        claim("alert.raised", "alert", "What was raised?", "{name}", {"name": R(a, "name")}),
        claim("alert.state", "alert", "Where does it stand?", "{status}, severity {severity}, opened {created}.",
              {"status": R(a, "status"), "severity": R(a, sev_path), "created": R(a, "created_at", "time")}),
    ]


def title_and_sub(ctx, alert_id: str) -> tuple[list, list]:
    """The alert's own name as the title; the sub names the owner the alert carries and the alert id."""
    a = ctx.row("api.alert", alert_id)
    title = render("{name}", {"name": R(a, "name")})
    sub = render("owner {o} · {aid}", {"o": R(a, "rule_run_results.0.owner"), "aid": (alert_id[:8], R(a, "id")[1])})
    return title, sub


def build_unmodelled(build, alert_id: str) -> dict:
    ctx = build.ctx()
    k = ctx.call("alerts.classify", alert_id=alert_id)
    title, sub = title_and_sub(ctx, alert_id)
    # classify names the reason itself when it recognised the shape but found no ranking row (an Inbox entry root).
    reason = k.outputs.get("reason") or _unmodelled_reason(ctx, alert_id, k["vuln_id"])
    return {"alert_id": alert_id, "type": "unmodelled", "reason": reason,
            "finding_id": k["vuln_id"], "claims": [], "title": title, "chips": [], "sub": sub,
            "graph": finding_graph(ctx, alert_id, k)}


def build_group_check(build, alert_id: str) -> dict:
    """An alert that stands for a group its rule declared (APP_PROFILES_SPEC § 3.3.4). Its claims are the platform's own
    group counts on the alert (DF computes member_count / members_open), so they are re-readable cells, not a recount."""
    from .path import no_path
    ctx = build.ctx()
    a = ctx.row("api.alert", alert_id)
    title, sub = title_and_sub(ctx, alert_id)
    return {"alert_id": alert_id, "type": "group_check", "finding_id": None,
            "claims": [claim("size", "group", "How many rows does this check cover?",
                             "{open} open of {total} rows this check groups.",
                             {"open": R(a, "members_open"), "total": R(a, "member_count")},
                             today="code: claims.alert_facts.build_group_check")],
            "title": title, "chips": [], "sub": sub,
            "graph": no_path("A grouped check has no exposure path; its rows are listed in the Inbox under it.")}


def finding_graph(ctx, alert_id: str, k) -> dict:
    """One finding that has no image model (a repository SCA finding, a finding whose scan rows are gone): its own key is the
    anchor (the CVE, package, version and place the alert names); the path is read from the platform rows about it. When its
    scanner row is no longer in the datalake the card says so, as of this build."""
    from .path import NO_MEMBERS, entry_path, no_path
    from ..modules.alerts import parse_vuln_id
    from ..times import pt
    fk, vid = k.get("finding_key"), k.get("vuln_id")
    if not fk and vid:
        a = ctx.row("api.alert", alert_id)
        parts = parse_vuln_id(vid, a.get("rule_run_results.0.cve_id") if a else None)
        if parts:
            eco = parts["purl"][len("pkg:"):].rsplit("/", 1)[0]
            fk = f"{parts['cve']}|{eco}|{parts['package']}|{parts['version']}|{parts['image']}"
    if not fk:
        return no_path("No platform path for this kind of item yet.")
    anchor = ctx.call("path.finding_member", finding_key=fk)
    out = entry_path(ctx, anchor, fk)
    if out.get("note") == NO_MEMBERS:
        return no_path("The finding's key could not be read.")
    if vid and ctx.row("vulnerabilities", vid) is None:
        out["note"] = f"This finding is not in the datalake as of {pt(ctx.now)}."
    return out
