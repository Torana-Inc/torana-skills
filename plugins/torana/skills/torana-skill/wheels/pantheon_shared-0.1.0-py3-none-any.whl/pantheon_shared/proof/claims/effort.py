"""Section `effort`: how big a fix is, and what that rests on. PROOF_ASSESSMENTS_SPEC § 3.2.5."""
from ..core.engine import NotCaptured
from .alert_facts import O
from .vuln_in_image import claim

CODE = "code: claims.effort (template + rules)"
Q = "How big is it?"
EST = "{band}: {low} to {high} days (edit {edit}, review {review}, test {test}, rollout {rollout}). Basis: {basis}."


def _estimate_claim(est) -> dict:
    if est["low"] is None:
        return claim("effort.estimate", "effort", Q, "Not estimated: {why}.", {"why": O(est, "why")},
                     missing=("Not estimated: {why}.", {"why": O(est, "why")}), today=CODE)
    return claim("effort.estimate", "effort", Q, EST,
                 {"band": O(est, "band"), "low": O(est, "low", "days"), "high": O(est, "high", "days"),
                  "edit": O(est, "edit", "days"), "review": O(est, "review", "days"), "test": O(est, "test", "days"),
                  "rollout": O(est, "rollout", "days"), "basis": O(est, "basis")}, today=CODE)


def effort_claims(ctx, row, key: str) -> list[dict]:
    """A fix entry's section. `row` is the entry's posture_fixes Row (not None)."""
    try:      # Path guard (proof/CLAUDE.md, FRAMEWORK_VERSION rule): no record built before 0.7.0 read this cell.
        row.get("minimum_version_per_cve")
    except NotCaptured:
        return []
    est = ctx.call("effort.estimate", key=key)
    if est["low"] is None:
        return [_estimate_claim(est)]
    ct = ctx.call("effort.change_type", key=key)
    if ct["worst_from"] is None:          # the ranking could not order the fixed versions: `to` is its list of them
        out = [claim("effort.change", "effort", "What kind of change is it?",
                     "{words}: the fixed versions ({to}) could not be put in order.",
                     {"words": O(ct, "change", "change"), "to": O(ct, "to")}, today=CODE)]
    else:
        out = [claim("effort.change", "effort", "What kind of change is it?", "{words}: {frm} to {to}.",
                     {"words": O(ct, "change", "change"), "frm": O(ct, "worst_from"), "to": O(ct, "to")}, today=CODE)]
    ref = ctx.call("effort.reference", key=key)
    if ref["checked"]:
        q, n, k = "Does the target clear the exploited ones?", O(ref, "count"), O(ref, "listed")
        head = ("{k} of the {n} vulnerabilit{n?y|ies} with a fixed version for this package {k?is|are} on the "
                "known-exploited list; ")
        tail = {"below": "{v} clears {k?it|them}, below this entry's target.",
                "equal": "this entry's target is the version that clears {k?it|them}.",
                "above": "clearing {k?it|them} needs {v}, above this entry's target.",
                "unknown": "the versions could not be compared with this entry's target."}
        if ref["listed"]:
            slots = {"k": k, "n": n, **({"v": O(ref, "needs")} if ref["relation"] in ("below", "above") else {})}
            out.append(claim("effort.reference", "effort", q, head + tail[ref["relation"]], slots, today=CODE))
        else:
            out.append(claim("effort.reference", "effort", q,
                             "None of the {n} vulnerabilit{n?y|ies} with a fixed version for this package is on the "
                             "known-exploited list.", {"n": n}, today=CODE))
    out.append(_estimate_claim(est))
    return out


def code_effort_claims(ctx, f, finding_key: str) -> list[dict]:
    """A code finding's section. `f` is the finding's posture_findings Row, or None."""
    if f is None:
        return []
    try:      # Path guard: no record built before 0.7.0 read this cell of the finding's row.
        f.get("finding_key")
    except NotCaptured:
        return []
    return [_estimate_claim(ctx.call("effort.code_fix", finding_key=finding_key))]
