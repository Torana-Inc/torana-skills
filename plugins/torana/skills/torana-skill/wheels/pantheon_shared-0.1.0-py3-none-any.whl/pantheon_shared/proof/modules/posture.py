"""posture — the transformer component: bootstrap relations (posture_*) read as DERIVED evidence.

⛔ The framework never re-implements a transformer's logic. It reads the transformer's output rows and
cites them (the row's own created_at/updated_at say when the build wrote it). Where it combines
transformer rows with graph edges (blast_radius), it says so in the rule's doc.
"""
from ..core.engine import NotCaptured, rule


def ranking_row(ctx, finding_key):
    """`(row, from_ranking)`: the finding's `finding_ranking` row. Path guard: a record saved before DS3 captured the finding's
    `posture_findings` row and never read `finding_ranking`, so replaying it reads that row instead (`from_ranking` False) and the claim
    says what it said then. A live read never raises."""
    try:
        return ctx.row("finding_ranking", finding_key), True
    except NotCaptured:
        return ctx.row("posture_findings", finding_key), False


@rule("ranking.priority", 1)
def ranking_priority(ctx, finding_key: str) -> dict:
    """Why the item sits at its priority: the finding's `finding_ranking` row, cited. The step and modifier name the band, the order key
    its place within the priority, the reason is the ranking's own sentence. A finding the ranking does not hold returns all None."""
    f = ctx.row("finding_ranking", finding_key)
    cols = ("alert_priority", "deadline_class", "ranking_step", "priority_modifier", "priority_order_key", "ranking_reason")
    if f is None:
        return {"priority": None, "deadline_class": None, "step": None, "modifier": None, "order_key": None, "reason": None}
    v = {c: f.get(c) for c in cols}
    return {"priority": v["alert_priority"], "deadline_class": v["deadline_class"], "step": v["ranking_step"],
            "modifier": v["priority_modifier"], "order_key": v["priority_order_key"], "reason": v["ranking_reason"]}


@rule("posture.finding_at", 1)
def finding_at(ctx, image: str, cve: str) -> dict:
    """The ranking's finding row for a CVE at an image (posture_findings), with its route and reason."""
    f = ctx.one("posture_findings", [["place_key", "=", image], ["cve_id", "=", cve]])
    return {"finding_key": f.key if f else None, "built_at": f.get("updated_at") if f else None}


@rule("posture.entry_for_finding", 1)
def entry_for_finding(ctx, finding_key: str) -> dict:
    """Which ranking entry (posture_mitigations) lists this finding among its members.
    Only the entries for the finding's own package are read, so the proof depends on nothing else."""
    f = ctx.row("posture_findings", finding_key)
    if not f:
        return {"entry_key": None, "title": None, "members": None}
    for m in ctx.select("posture_mitigations", [["package_name", "=", f.get("package_name")], ["ecosystem", "=", f.get("ecosystem")]]):
        if finding_key in (m.get("member_finding_keys") or []):
            return {"entry_key": m.key, "title": m.get("alert_title"), "members": m.get("member_findings")}
    return {"entry_key": None, "title": None, "members": None}


@rule("posture.blast_radius", 2)
def blast_radius(ctx, entry_key: str) -> dict:
    """What one action on an entry touches. Combines the transformer's member list with graph edges:
    member findings -> places -> deployed services -> load balancers and nodes.

    A member's place (the last segment of its key) is an IMAGE ("image@sha256:<digest>") or a REPOSITORY
    ("repo:github.com/org/repo"). v2 follows both: an image by its digest (deployed_as), a repository through the
    images it builds (builds_image, then deployed_as). v1 read every key as an image digest, so a repository member
    (a code finding, a repository SCA finding) reached no service and the count silently left it out.
    `repository_members` says how many members sit on a repository, `repositories` how many repositories."""
    m = ctx.row("posture_mitigations", entry_key)
    keys = (m.get("member_finding_keys") if m else None) or []
    cves = sorted({k.split("|")[0] for k in keys})
    places = [k.split("|", 4)[-1] for k in keys]
    digests = sorted({p.split("sha256:")[-1] for p in places if "@sha256:" in p})
    repos = sorted({p for p in places if p.startswith("repo:")})
    built = ctx.select("entity_edges", [["edge_type", "=", "builds_image"], ["from_key", "in", repos],
                                        ["is_deleted", "=", False]]) if repos else []
    built_images = sorted({e.get("to_key") for e in built if e.get("to_key")})
    dep = ctx.select("entity_edges", [["edge_type", "=", "deployed_as"], ["from_key", "suffix_any", digests],
                                      ["is_deleted", "=", False]]) if digests else []
    dep += ctx.select("entity_edges", [["edge_type", "=", "deployed_as"], ["from_key", "in", built_images],
                                       ["is_deleted", "=", False]]) if built_images else []
    seen, uniq = set(), []
    for e in dep:                                         # an image reached both ways counts once
        if e.key not in seen:
            seen.add(e.key)
            uniq.append(e)
    dep = uniq
    svcs = sorted({e.get("to_key") for e in dep})
    around = ctx.select("entity_edges", [["edge_type", "in", ["exposed_via", "runs_on"]], ["from_key", "in", svcs], ["is_deleted", "=", False]]) if svcs else []
    lbs = {e.get("to_key") for e in around if e.get("edge_type") == "exposed_via"}
    hosts = {e.get("to_key") for e in around if e.get("edge_type") == "runs_on"}
    exposed = {e.get("from_key") for e in around if e.get("edge_type") == "exposed_via"}
    return {"findings": len(keys), "cves": ", ".join(cves) or None, "services": len(svcs), "service_keys": svcs,
            "deployed": [{"service": e.get("to_key"), "image": e.get("from_key"), "edge": e.key} for e in dep],
            "exposed_services": len(exposed), "load_balancers": len(lbs), "nodes": len(hosts),
            "repositories": len(repos), "repository_members": sum(1 for p in places if p.startswith("repo:"))}
