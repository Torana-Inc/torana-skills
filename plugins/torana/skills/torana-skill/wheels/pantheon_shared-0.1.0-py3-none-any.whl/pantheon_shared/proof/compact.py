"""Compact items: the page- and narrator-facing digest of one proof record (claim texts, no pointers).
Spec: pantheon-fe/docs/AI_HOME_V2_HOME_PROOF_SPEC.md § 3.4.2. Pure: no I/O."""
from __future__ import annotations


def _text(spans) -> str:
    return "".join(s["text"] for s in spans or [])


def compact_item(record: dict) -> dict:
    """One record → one CompactItem. cid = <first 8 chars of the alert id>:<claim id> (see dedupe_cids)."""
    it = record["item"]
    a8 = it["alert_id"][:8]
    return {
        "alert_id": it["alert_id"], "type": it["type"], "reason": it.get("reason"),
        "decision_key": it["decision_key"], "stale": bool(it.get("stale")), "unjudged": bool(it.get("unjudged")),
        "title": _text(it.get("title")),
        "priority": it.get("priority"),
        # Home's `why` (home.py): the ranking's wording for the band, who set the number, and the agent's reason while it holds it.
        "band": it.get("band"), "priority_source": it.get("priority_source"), "priority_reason": it.get("priority_reason"),
        "triage": it.get("triage"), "reachability": it.get("reachability"), "known_exploited_cves": it.get("known_exploited_cves"),
        # The page shows a Graph entry only when this is true: the code decided, the page never guesses (§ 3.4.2).
        "has_graph": bool((it.get("graph") or {}).get("nodes")),
        "source": {"kind": "alert", "id": it["alert_id"]},
        "claims": [{"cid": f"{a8}:{c['id']}", "id": c["id"], "section": c["section"], "q": c["q"],
                    "kind": c["kind"], "text": _text(c["spans"]),
                    "values": [s["text"] for s in c["spans"] if s.get("slot")]} for c in it["claims"]],
        "built_at": record["meta"]["now"], "framework": record["meta"]["framework"],
    }


def dedupe_cids(items: list[dict]) -> list[dict]:
    """cids must be unique across a run. When two items share an 8-char alert prefix, every item of the run
    switches to the full alert id (<alert_id>:<claim id>). Returns the same list, edited in place."""
    prefixes = [it["alert_id"][:8] for it in items]
    if len(set(prefixes)) == len(prefixes):
        return items
    for it in items:
        for c in it["claims"]:
            c["cid"] = f"{it['alert_id']}:{c['id']}"
    return items


def compact_items(records: list[dict]) -> list[dict]:
    return dedupe_cids([compact_item(r) for r in records])
