"""entries — the ranking's work entries (posture_fixes: one upgrade; posture_mitigations: one package to mitigate).

Read as DERIVED evidence, like posture.py: the framework cites the transformer's rows and never re-derives them.
Two things are computed here: whether the entry still says what the alert said (drift), and how many of its
listed member findings exist in the ranking (members). Neither reads a member row's cells: a mitigation lists up to
840 members, and the record must stay under the 1 MiB /verify cap (spec § 3.6.12).
"""
from ..core.engine import rule


@rule("entries.drift", 2)
def drift(ctx, alert_id: str, table: str, key: str, then_path: str, now_col: str) -> dict:
    """Is the entry still as raised? then = the count the alert recorded; now = the entry row's count.
    state: same (equal), changed (different), gone (the entry row no longer exists), unrecorded (the alert recorded
    no count: an Inbox entry root, whose rule_run_results are empty, so there is nothing to compare).
    v2: `unrecorded`; v1 read a root as changed from None."""
    a = ctx.row("api.alert", alert_id)
    then = a.get(then_path) if a else None
    row = ctx.row(table, key)
    if row is None:
        return {"state": "gone", "then": then, "now": None}
    now = row.get(now_col)
    if then is None:
        return {"state": "unrecorded", "then": None, "now": now}
    return {"state": "same" if then == now else "changed", "then": then, "now": now}


# A selection's WHERE carries every key, and the record stores it four times (leaf id, where, run input, SQL log):
# ~1.1 KB per key. 400 keys ≈ 450 KB, leaving room under the 1 MiB /verify cap for the rest of the record.
SELECT_MAX_KEYS = 400


@rule("entries.members", 1)
def members(ctx, table: str, key: str) -> dict:
    """How many of the entry's listed member findings exist in the ranking: ONE selection over posture_findings
    by the entry's member_finding_keys (listed = keys on the entry; found = keys the selection returned).
    Entries listing more than 400 keys are not re-selected (found = None, checked = False): the record would
    exceed the 1 MiB /verify cap. ⚠️ MEASURED 2026-10-07 (spec § 3.6.12): mitigate|vim (840 keys) was 1.63 MB with
    two selections and 947 KB with one. A second selection (members on running images) was dropped for the same
    reason; running images are the entry's own measured member_images cell instead."""
    row = ctx.row(table, key)
    keys = (row.get("member_finding_keys") if row else None) or []
    if not keys:
        return {"listed": 0, "found": 0, "checked": True}
    if len(keys) > SELECT_MAX_KEYS:
        return {"listed": len(keys), "found": None, "checked": False}
    found = ctx.select("posture_findings", [["finding_key", "in", keys]])
    return {"listed": len(keys), "found": len(found), "checked": True}
