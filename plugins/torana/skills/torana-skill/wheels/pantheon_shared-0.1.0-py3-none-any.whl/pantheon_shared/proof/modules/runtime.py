"""runtime — where a service runs and how it is reached (entity graph: exposed_via, runs_on)."""
from ...identity.scope_key import entry_base, entry_integration
from ..core.engine import NotCaptured, rule


@rule("runtime.exposure", 1)
def exposure(ctx, service: str) -> dict:
    """Is the service reachable from outside? = an exposed_via edge whose evidence names a load-balancer endpoint."""
    e = ctx.one("entity_edges", [["edge_type", "=", "exposed_via"], ["from_key", "=", service], ["is_deleted", "=", False]])
    if not e:
        return {"exposed": False, "edge": None, "endpoint": None, "lb": None}
    ep = e.get("evidence.to_original") or ""
    return {"exposed": True, "edge": e.key, "endpoint": ep.split("/")[-1] or None, "lb": e.get("to_key")}


@rule("runtime.exposure_answer", 1)
def exposure_answer(ctx, service: str, image: str) -> dict:
    """asset_context's ONE exposure answer for this claim (DS1b § 3.2.7): the claim's own posture_runtime_context row
    (image place × service) says True, False or None ("not measured": its cluster's or account's network reads failed or
    went stale). `measured` is False when there is no such row (no EPR app) or the record never read it (a record built
    before 0.7.15: path guard), and the caller then keeps runtime.exposure's edge answer and its v1 sentence."""
    try:
        rc = ctx.one("posture_runtime_context",
                     [["place_kind", "=", "image"], ["place_key", "=", image], ["service_key", "=", service],
                      ["is_deleted", "=", False]],
                     ["exposure_link_found", "exposure_basis", "exposure_sign_in"])
    except NotCaptured:
        rc = None
    if rc is None:
        return {"measured": False, "exposed": None, "basis": None, "sign_in": None}
    found = rc.get("exposure_link_found")
    return {"measured": True, "exposed": None if found is None else bool(found), "basis": rc.get("exposure_basis"),
            "sign_in": rc.get("exposure_sign_in")}


@rule("runtime.placement", 1)
def placement(ctx, service: str) -> dict:
    """The node a service runs on (runs_on edge)."""
    e = ctx.one("entity_edges", [["edge_type", "=", "runs_on"], ["from_key", "=", service], ["is_deleted", "=", False]])
    return {"host": e.get("to_key") if e else None, "edge": e.key if e else None}


_SCOPE_COLS = ["service_scope_key", "exposure_basis", "exposure_read_sources", "exposure_read_at",
               "running_basis", "running_read_sources", "running_read_at"]


def _read_labels(reads) -> list:
    """The reads a card names, one label per BASE (Q1: an entry is '<base>|<integration_id>'). The
    integration is named only when two connections read the same base; '!' markers are never labels."""
    by: dict = {}
    for k in (reads if isinstance(reads, dict) else {}):
        if not str(k).startswith("!"):
            by.setdefault(entry_base(k), set()).add(entry_integration(k))
    out = []
    for base in sorted(by):
        iids = sorted(by[base])
        out += ([f"{base} (connection {i})" if i else f"{base} (an earlier read)" for i in iids]
                if len(iids) > 1 else [base])
    return out


@rule("runtime.scope_reads", 2)
def scope_reads(ctx, service: str) -> dict:
    """What the app last read for the service's scope (D21). The JUDGEMENT is asset_context's (posture_runtime_context):
    this rule reads it, and the scope row's read record for the pointer, and decides nothing. A record captured before
    framework 0.7.14 never read these columns and replays with every field None (path guard). v2 (Q1): `read_labels`,
    the card's names for the record's reads (entry_base, the integration only when two read one base); `reads` stays
    the whole captured record, so an older record replays from its own capture."""
    empty = {"scope_key": None, "scope_row": None, "reads": None, "read_labels": None, **{c: None for c in _SCOPE_COLS[1:]}}
    try:
        rc = ctx.one("posture_runtime_context", [["service_key", "=", service], ["is_deleted", "=", False]], _SCOPE_COLS)
    except NotCaptured:
        return empty
    key = rc.get("service_scope_key") if rc else None
    if not key:
        return dict(empty, **({c: rc.get(c) for c in _SCOPE_COLS[1:]} if rc else {}))
    row = ctx.one("assets", [["torana_entity_id", "=", key]], ["torana_entity_id", "reads"])
    reads = row.get("reads") if row else None
    return {"scope_key": key, "scope_row": row.key if row else None, "reads": reads, "read_labels": _read_labels(reads),
            **{c: rc.get(c) for c in _SCOPE_COLS[1:]}}
