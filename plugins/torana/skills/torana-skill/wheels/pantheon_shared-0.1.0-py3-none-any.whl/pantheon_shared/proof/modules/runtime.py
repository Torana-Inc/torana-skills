"""runtime — where a service runs and how it is reached (entity graph: exposed_via, runs_on)."""
from ..core.engine import rule


@rule("runtime.exposure", 1)
def exposure(ctx, service: str) -> dict:
    """Is the service reachable from outside? = an exposed_via edge whose evidence names a load-balancer endpoint."""
    e = ctx.one("entity_edges", [["edge_type", "=", "exposed_via"], ["from_key", "=", service], ["is_deleted", "=", False]])
    if not e:
        return {"exposed": False, "edge": None, "endpoint": None, "lb": None}
    ep = e.get("evidence.to_original") or ""
    return {"exposed": True, "edge": e.key, "endpoint": ep.split("/")[-1] or None, "lb": e.get("to_key")}


@rule("runtime.placement", 1)
def placement(ctx, service: str) -> dict:
    """The node a service runs on (runs_on edge)."""
    e = ctx.one("entity_edges", [["edge_type", "=", "runs_on"], ["from_key", "=", service], ["is_deleted", "=", False]])
    return {"host": e.get("to_key") if e else None, "edge": e.key if e else None}
