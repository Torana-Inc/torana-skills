"""Item types: a threat signal (one strongest-signal group of running findings, recounted by
signals.threat_members) and a posture summary (recorded values only; not recomputed, spec § 3.10.1).
Spec: pantheon-fe/docs/AI_HOME_V2_HOME_PROOF_SPEC.md § 3.4.1. A threat signal has a fan-out graph (its members);
a posture summary has none: it records counts and enumerates no member to draw (signals.py build_summary_claims)."""
from ..core.render import render
from .alert_facts import O, R, title_and_sub
from .path import no_path as _no_path
from .vuln_in_image import claim

CODE = "code: claims.signals (template + rules)"
RRR = "rule_run_results.0"
# The edge from a CVE to the signal, by signal.
_SIGNAL_EDGE = {"cisa": "listed by", "zero_day": "zero-day", "exploit": "exploit for", "likely": "likely"}
# The count a summary covers, by the first field its rule records (above-floor, exposure, unseen).
_COVERS = [("findings_above_floor", "findings"), ("findings_carried", "findings"), ("findings", "findings"),
           ("images", "images")]


def build_threat_claims(build, alert_id: str) -> dict:
    ctx = build.ctx()
    k = ctx.call("alerts.classify", alert_id=alert_id)
    gk = k["group_key"]
    signal = gk.split("|")[2] if gk.count("|") >= 2 else ""
    m = ctx.call("signals.threat_members", signal=signal)
    a = ctx.row("api.alert", alert_id)
    title, sub = title_and_sub(ctx, alert_id)
    then_f, then_i = (a.get(RRR + ".findings"), a.get(RRR + ".images")) if a else (None, None)
    now_f, now_i = m["findings"], m["images"]
    if not now_f:
        still = "Gone: no open finding on a running image carries this signal now."
    elif (then_f, then_i) == (now_f, now_i):
        still = "Yes: still {nf} finding{nf?|s} on {ni} image{ni?|s}."
    else:
        still = "Changed: raised with {tf} finding{tf?|s} on {ti} image{ti?|s}, now {nf} on {ni}."
    claims = [
        claim("still", "state", "Is this signal still as raised?", still,
              {"tf": R(a, RRR + ".findings"), "ti": R(a, RRR + ".images"), "nf": O(m, "findings"), "ni": O(m, "images")},
              today=CODE),
        claim("what", "deep", "What is the signal?", "{kind}", {"kind": R(a, RRR + ".signal_kind")}, today=CODE),
        claim("size", "deep", "How big is it?", "{f} finding{f?|s}, {c} CVE{c?|s}, on {i} image{i?|s}.",
              {"f": O(m, "findings"), "c": O(m, "cves"), "i": O(m, "images")}, today=CODE),
        claim("exposure", "deep", "Is it exposed?", "{x} behind internet-facing service{x?|s}.",
              {"x": O(m, "internet_facing")}, today=CODE),
        claim("fix", "fix", "Can it be fixed?", "{w} {w?has|have} a fix; {wo} {wo?does|do} not.",
              {"w": O(m, "with_a_fix"), "wo": O(m, "without_a_fix")}, today=CODE),
        claim("critical", "deep", "How many are Critical?", "{c} Critical.", {"c": O(m, "critical")}, today=CODE),
    ]
    chips = [{"cls": "", "spans": render("threat signal", {})},
             {"cls": "", "spans": render("{n} finding{n?|s}", {"n": O(m, "findings")})}]
    return {"alert_id": alert_id, "type": "threat_signal", "group_key": gk, "signal": signal, "stale": False,
            "title": title, "chips": chips, "sub": sub, "claims": claims, "graph": threat_graph(ctx, signal, a)}


def threat_graph(ctx, signal: str, a) -> dict:
    """No platform path yet: the alert carries only counts, and its members are the ranking's own selection, which the path
    does not re-derive."""
    from .path import no_path
    return no_path()


def build_summary_claims(build, alert_id: str) -> dict:
    ctx = build.ctx()
    k = ctx.call("alerts.classify", alert_id=alert_id)
    a = ctx.row("api.alert", alert_id)
    title, sub = title_and_sub(ctx, alert_id)
    rec = (a.get(RRR) if a else None) or {}
    ints = sorted(f for f, v in rec.items() if isinstance(v, int) and not isinstance(v, bool) and f.isidentifier()
                  and f != "alert_priority")
    template = "As the rule recorded it: {title}." + ("" if not ints else " " + "; ".join(
        f"{f.replace('_', ' ')} {{{f}}}" for f in ints) + ".")
    slots = {"title": R(a, RRR + ".alert_title"), **{f: R(a, f"{RRR}.{f}") for f in ints}}
    cover, noun = next(((f, n) for f, n in _COVERS if f in ints), (None, "findings"))
    claims = [
        claim("recorded", "deep", "What did the rule record?", template, slots, today=CODE),
        claim("recount", "deep", "Is it recomputed?",
              "Not recomputed: this summary covers {n} " + noun + "; a proof that enumerates them is out of scope for now.",
              {"n": R(a, f"{RRR}.{cover}") if cover else (None, None)},
              missing=("The members are not enumerated: proving a count without listing every key needs an aggregate "
                       "pointer the framework does not have yet.", {}), today=CODE),
    ]
    chips = [{"cls": "", "spans": render("posture summary", {})}]
    return {"alert_id": alert_id, "type": "posture_summary", "group_key": k["group_key"], "stale": False,
            "title": title, "chips": chips, "sub": sub, "claims": claims, "graph": _no_path()}
