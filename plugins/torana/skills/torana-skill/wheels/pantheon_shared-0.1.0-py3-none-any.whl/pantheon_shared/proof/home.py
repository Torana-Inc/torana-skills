"""Decisions and the home summary over compact items. Spec: pantheon-fe/docs/AI_HOME_V2_HOME_PROOF_SPEC.md § 3.4.4.
Pure: every integer is counted from the items; nothing reads the platform."""
from __future__ import annotations

import hashlib

from pantheon_shared.assessments import for_item_type

from .health import health
from .rule_state import last_run_failed

HOME_RULES_VERSION = 17      # 2: whole-run `stale` + `rest`; 3: outcome-first `hero` + `funnel`; 4: `trust` + `highlight`;
#                              5: `cards`, the Needs-you arrangement (2026-10-07); 6: `health`, the "How this app is
#                              running" strip written by code (health.py), replacing the narrator's health_block (2026-10-07);
#                              7: health's sync_failing line carries `items` (one row per failing data sync, from the
#                              integration service's failing_sources) — the drawer behind the tile (2026-10-08);
#                              8: health lines in the customer's words; the raw error moves to a line's `detail` (2026-10-08);
#                              9: health writes times in PT, adds alert-routing lines, reads rule coverage from
#                              facts.attention, the timeline fallback reads roll-up members and the recorded HTTP
#                              status, and `trust` counts a check as failed only when its last run FAILED (2026-10-08);
#                              10: health's routing lines — "no route" alone is no longer a warning, since an unrouted
#                              alert goes to the workspace's triage agent; it warns only when there is neither (2026-10-08);
#                              11: every health line says what it costs and what to do: a blocked check carries its
#                              missing fields (`items`), a never-run check is one line each, agents name their job and
#                              who acts by HTTP status, unread sources are named in words (2026-10-08);
#                              12: a sync that FAILED inside the window is named even when the integration's failing_sources
#                              is empty, and "N rules ran" counts only runs inside the window (2026-10-08);
#                              13: profile-aware words, funnel note and highlight policy (facts.profile,
#                              APP_PROFILES_SPEC); group_check items (2026-10-09);
#                              14: the funnel's "proved" note says what proving MEANT per item type: "checked against
#                              live data" only for data-proved items; a group_check is "re-read as the check's own alert
#                              and its rows", an unmodelled item has "no proof model" (CMDB audit B6, 2026-10-09);
#                              16: health carries `heading` and every health line a `short` (one clause), so the
#                              strip lists one short line per problem instead of every `text` in a paragraph (2026-10-13)
#                              17: an "effort" chip per row (PROOF_ASSESSMENTS_SPEC § 3.2.6)
NOTICED_MAX = 4


def gid_of(decision_key: str) -> str:
    return "G" + hashlib.sha1(decision_key.encode()).hexdigest()[:8]


def _label(k: str) -> str:
    """cve|C|P → "C in P"; fix|K → "upgrade <package of K>"; mit|K → "mitigate <package of K>"; else k."""
    parts = k.split("|")
    if parts[0] == "cve" and len(parts) >= 3:
        return f"{parts[1]} in {parts[2]}"
    if parts[0] in ("fix", "mit") and len(parts) >= 2:
        return ("upgrade " if parts[0] == "fix" else "mitigate ") + parts[-1]
    if parts[0] == "code" and len(parts) >= 4:       # code|<rule>|repo:<repo>|<file> → "<rule> in <file>"
        return f"{parts[1].split('.')[-1]} in {parts[3]}"
    return k


def _plural(n: int, one: str, many: str) -> str:
    return one if n == 1 else many


def _is_drift(it: dict) -> bool:
    still = next((c for c in it.get("claims") or [] if c["id"] == "still"), None)
    return bool(still and (still["text"].startswith("Changed") or still["text"].startswith("Gone")))


def _group(k: str, its: list[dict]) -> dict:
    return {"gid": gid_of(k), "decision_key": k, "alert_ids": [i["alert_id"] for i in its],
            "stale": sum(bool(i["stale"]) for i in its), "unjudged": sum(bool(i["unjudged"]) for i in its),
            "text": f"{len(its)} rows are one decision ({_label(k)}).",
            "cites": [c["cid"] for i in its for c in i["claims"] if c["id"] == "alert.raised"]}


#: An item type in plain words (singular, plural), for the "the rest" line.
TYPE_WORDS = {
    "mitigation_entry": ("mitigation", "mitigations"), "fix_entry": ("fix", "fixes"),
    "vuln_in_image": ("image finding", "image findings"), "posture_summary": ("posture summary", "posture summaries"),
    "threat_signal": ("threat signal", "threat signals"), "code_finding": ("code finding", "code findings"),
    "unmodelled": ("other finding", "other findings"),
    "group_check": ("check", "checks"),     # the default words when a group root appears without a profile
}


def _by_key(items: list[dict]) -> dict[str, list[dict]]:
    by: dict[str, list[dict]] = {}
    for it in items:
        by.setdefault(it["decision_key"], []).append(it)
    return by


def stale_line(items: list[dict]) -> dict | None:
    """EVERY stale item of the run (not only the chosen rows), in proof order: the page's ▲ card and the CLI read it."""
    ids = [it["alert_id"] for it in items if it["stale"]]
    if not ids:
        return None
    n = len(ids)
    return {"kind": "stale", "alert_ids": ids, "text": _plural(
        n, "1 alert points at an image that no longer runs.", f"{n} alerts point at images that no longer run.")}


def rest_line(items: list[dict], chosen_rows: list[dict], words: dict | None = None) -> dict | None:
    """The run's decisions the page does not show: not a chosen row's decision (whose group card lists the group),
    and not the decision of any stale item (the ▲ card lists those). Counted per decision, by its FIRST item's type."""
    shown = {it["decision_key"] for it in chosen_rows} | {it["decision_key"] for it in items if it["stale"]}
    rest = [its for k, its in _by_key(items).items() if k not in shown]
    if not rest:
        return None
    by_type: dict[str, int] = {}
    for its in rest:
        by_type[its[0]["type"]] = by_type.get(its[0]["type"], 0) + 1
    order = sorted(by_type.items(), key=lambda kv: (-kv[1], kv[0]))
    parts = [f"{c} {(words or TYPE_WORDS).get(t, (t, t))[c != 1]}" for t, c in order]
    n = len(rest)
    return {"count": n, "by_type": dict(order),
            "text": f"{n} more {_plural(n, 'decision is', 'decisions are')} open ({', '.join(parts)})."}


def _n(n: int, one: str, many: str) -> str:
    return f"{n:,} {_plural(n, one, many)}"


def hero_text(acted: int, stale: int, rest: int) -> str:
    """Outcome first, a unit on every count: "6 decisions to act on first · 15 alerts to close · 143 more decisions".
    A zero part is left out, except the first."""
    parts = [f"{_n(acted, 'decision', 'decisions')} to act on first"]
    if stale:
        parts.append(f"{_n(stale, 'alert', 'alerts')} to close")
    if rest:
        parts.append(f"{rest:,} more {_plural(rest, 'decision', 'decisions')}")
    return " · ".join(parts)


#: ⭐ A note marks the words a reader should catch with `**…**` (the page bolds them, the CLI prints them bold).
#: The app's own notes (its bundle's `home_funnel`) may use the same marker.
def _step(stage: str, count: int | None, unit: str, note: str) -> dict:
    return {"stage": stage, "count": count, "unit": unit, "note": note}


def _proved_note(items: list[dict]) -> str:
    """What "proved" MEANT for these items, by proof type (CMDB audit B6, 2026-10-09).

    ⛔ "each checked against live data" is true only for an item whose claims re-read datalake rows. A `group_check`
    re-reads its OWN alert (title, state, row count), not the hosts behind it, and an `unmodelled` item has no proof
    model at all. Measured on T3: 15 group_check + 8 unmodelled read as "23 alerts, each checked against live data".
    Every item data-proved → the sentence is unchanged."""
    n_check = sum(1 for it in items if it.get("type") == "group_check")
    n_none = sum(1 for it in items if it.get("type") == "unmodelled")
    n_data = len(items) - n_check - n_none
    if not n_check and not n_none:
        return "each **checked against live data**, one by one"
    parts = ([f"{n_data:,} **checked against live data**"] if n_data else []) + (
        [f"{n_check:,} re-read as the check's own alert and its rows"] if n_check else []) + (
        [f"{n_none:,} with **no proof model**"] if n_none else [])
    return " · ".join(parts)


def funnel(items: list[dict], chosen_rows: list[dict], facts: dict | None, proof: dict | None,
           stale: dict | None, rest: dict | None, acted: int | None = None, *,
           profile: dict | None = None) -> list[dict]:
    """How much the run looked at and how it came down to the decisions: a STEPPED list (the stages are not nested, so
    no ratios), every count with its unit, every count from THIS run (facts + proof), copied, never estimated.

    1. the app's own steps (`facts.funnel`, its bundle's SQL), when it declares them;
    2. raised: open Inbox entries and the rules behind them (`facts.alerts.open_entries`);
    3. proved: proof items, and "N of M" with the reason whenever any open entry was not proved;
    4. decisions: distinct decision_key over the proved items;
    5. set aside: stale alerts (to close), when any;
    6. outcome: the decisions to act on first (`acted`: the cards that are not the retired card), and the rest left
       in the Inbox. Without `acted`, the chosen rows' distinct decisions (a caller with no cards)."""
    facts, proof = facts or {}, proof or {}
    out: list[dict] = []
    f = facts.get("funnel") or {}
    if f.get("declared") and f.get("available"):
        out += [_step(st["stage"], st["count"], st["unit"], st["note"]) for st in f.get("steps") or []]
    elif f.get("declared"):
        out.append(_step("scanned", None, "findings", f"The app's scan counts could not be read this run "
                                                      f"({f.get('error') or 'unknown error'})."))
    alerts = facts.get("alerts") or {}
    oe = alerts.get("open_entries") or {}
    open_n = oe.get("total") if oe.get("available") else alerts.get("open_total")
    if open_n is not None:
        rules = oe.get("rules") if oe.get("available") else None
        out.append(_step("raised", open_n, _plural(open_n, "open alert", "open alerts"),
                         f"in the Inbox, raised by **{_n(rules, 'rule', 'rules')}**" if rules is not None else "in the Inbox"))
    proved = len(items)
    note = _proved_note(items)
    if open_n is not None and proved < open_n:
        why = []
        if oe.get("truncated"):
            why.append(f"the first {oe.get('cap'):,} were taken")
        if proof.get("errors"):
            why.append(f"{_n(len(proof['errors']), 'proof', 'proofs')} failed")
        note = f"**proved {proved:,} of {open_n:,}**" + (f" ({'; '.join(why)})" if why else "") + f"; {note}"
    out.append(_step("proved", proved, _plural(proved, "alert", "alerts"), note))
    d_all = len(_by_key(items))
    out.append(_step("decisions", d_all, _plural(d_all, "decision", "decisions"),
                     profile["decision_note"] if profile else "alerts that are **one fix or one mitigation**, grouped"))
    if stale:
        ns = len(stale["alert_ids"])
        sk = len({it["decision_key"] for it in items if it["stale"]})
        out.append(_step("set_aside", ns, _plural(ns, "alert", "alerts"),
                         f"on **images that no longer run**, set aside to close ({_n(sk, 'decision', 'decisions')})"))
    d = acted if acted is not None else len({it["decision_key"] for it in chosen_rows})
    out.append(_step("outcome", d, _plural(d, "decision", "decisions"),
                     "**to act on first**" + (f" · {_n(rest['count'], 'more decision', 'more decisions')} in the Inbox"
                                          if rest else "")))
    return out


def _claims(it: dict) -> dict:
    return {c["id"]: c for c in it.get("claims") or []}


def effort_chip(it: dict) -> dict | None:
    """The one-line form of an item's effort assessment, for the Home card, the CLI row and the assessment route.
    `it` is a compact item. None when the item has no assessed estimate. `text` is the whole line; `short` is the
    same without the evidence count; `band` and `range` are its two halves."""
    est = _claims(it).get("effort.estimate")           # compact claim: {id, kind, text, values}
    if not est or est["kind"] != "assessed" or len(est.get("values") or []) < 3:
        return None
    v = est["values"]                                   # band, low, high, then the split and the basis
    q = next((x for x in for_item_type(it["type"]) if x.question == "effort"), None)
    cov = q.coverage(it["claims"]) if q else {"done": 0, "total": 0}
    band, days = v[0], f"{v[1]} to {v[2]} days"         # the Home card draws these as two lines; it splits nothing
    short = f"{band} · {days}"
    return {"kind": "effort", "done": cov["done"], "total": cov["total"], "band": band, "range": days, "short": short,
            "text": f"{short} · evidence {cov['done']} of {cov['total']}"}


def _int(v) -> int:
    try:
        return int(str(v).replace(",", ""))
    except (TypeError, ValueError):
        return 0


def _exploited(it: dict) -> bool:
    """Known exploited, from the claims the item already carries: a threat signal "Listed by CISA as exploited", a
    mitigation "Known exploited: yes", a CVE "Listed on CISA KEV as known-exploited." (proof/core/render.py)."""
    c = _claims(it)
    if it.get("type") == "threat_signal":
        return str((c.get("what") or {}).get("text") or "").startswith("Listed by CISA as exploited")
    t = c.get("threat") or {}
    if it.get("type") == "mitigation_entry":
        return str((t.get("values") or [""])[0]).strip().lower() == "yes"
    return str(t.get("text") or "").startswith("Listed on CISA KEV")


def _prio_of(its: list[dict]) -> int:
    """The lowest integer priority among a decision's items (0 is a priority); 10**9 when none carries one."""
    ps = [int(str(p)) for p in (i.get("priority") for i in its) if p is not None and str(p).lstrip("-").isdigit()]
    return min(ps, default=10**9)


def _live(it: dict, policy: str = "default") -> tuple[int, dict]:
    """(live findings on running software, {running service: live findings}) for one item, from its claims:
    a threat signal's `size`; an entry's `running` ("N of M ... on K running images"); a CVE alert on a retired image
    reads its `stale` claim (the service that still runs the CVE, and its live findings); a current one counts 1;
    a code finding counts 1 when its `ships` claim names at least one running service (its first value), else 0."""
    c, t = _claims(it), it.get("type")
    if t == "threat_signal":
        return _int(((c.get("size") or {}).get("values") or [0])[0]), {}
    if t in ("fix_entry", "mitigation_entry"):
        return _int(((c.get("running") or {}).get("values") or [0])[0]), {}
    if t == "code_finding":
        return (1 if _int(((c.get("ships") or {}).get("values") or [0])[0]) > 0 else 0), {}
    if t == "vuln_in_image":
        if not it.get("stale"):
            return 1, {}
        v = (c.get("stale") or {}).get("values") or []
        n = _int(v[4]) if len(v) >= 5 else 0
        return n, ({str(v[2]): n} if n and len(v) >= 3 else {})
    if t == "group_check" and policy == "priority":            # no profile → 0, today's result: never highlighted
        return _int(((c.get("size") or {}).get("values") or [0])[0]), {}
    return 0, {}


def _list(names: list[str], cap: int = 3) -> str:
    return ", ".join(names[:cap]) + (f" and {len(names) - cap} more" if len(names) > cap else "")


def _highlight_title(dk: str, its: list[dict], exploited: bool, live: int, services: dict) -> str:
    """Code writes the highlight from the claims: digits, a unit on every count."""
    first, n = its[0], len(its)
    c = _claims(first)
    if first.get("type") == "threat_signal":
        v = (c.get("size") or {}).get("values") or []
        f, cves, imgs = (_int(v[0]), _int(v[1]), _int(v[2])) if len(v) >= 3 else (live, 0, 0)
        exp = _int(((c.get("exposure") or {}).get("values") or [0])[0])
        what = "CISA lists as exploited" if exploited else str((c.get("what") or {}).get("text") or "flagged").lower()
        tail = (", all behind internet-facing services" if exp and exp == f
                else f", {_n(exp, 'behind an internet-facing service', 'behind internet-facing services')}" if exp else "")
        return (f"Torana noticed: {_n(cves, 'CVE', 'CVEs')} {what} {_plural(cves, 'is', 'are')} on "
                f"{_n(imgs, 'running image', 'running images')}: {_n(f, 'finding', 'findings')}{tail}.")
    parts = dk.split("|")
    if first.get("type") == "vuln_in_image" and len(parts) >= 3:
        cve, pkg = parts[1], parts[2]
        retired = sum(1 for i in its if i.get("stale"))
        head = (f"Torana noticed: {_n(n, f'{pkg} alert', f'{pkg} alerts')} {_plural(n, 'is', 'are')} one fix"
                + (f" for {cve}, which CISA lists as exploited" if exploited else ""))
        names = sorted(services)
        svc = (f"{_n(len(names), 'running service', 'running services')} ({_list(names)}) still "
               f"{_plural(len(names), 'has', 'have')} it" if names else f"{_n(live, 'live finding', 'live findings')} on running images")
        ret = ("" if not retired else "; every alert names a retired image" if retired == n
               else f"; {retired} of the {n} alerts name a retired image")
        return f"{head}: {svc}{ret}."
    title = str(first.get("title") or dk)
    return f"Torana noticed: {'CISA lists this as exploited. ' if exploited else ''}{title}."


def highlight(items: list[dict], groups: list[dict] | None = None, *, policy: str = "default") -> dict | None:
    """The ONE decision the page highlights, chosen across ALL proved decisions (single-alert ones too) by what needs
    doing: known exploited first, then live findings on running software, then the alert count, then decision_key
    (stable). A decision with NO live finding anywhere is never chosen (a retired image whose CVE still runs elsewhere
    IS live). None when nothing qualifies. Read by the page's highlight card and the CLI.
    policy "priority" (an app's profile.highlight, APP_PROFILES_SPEC § 3.3.5): the lowest alert_priority among decisions
    with something open, then open rows, alert count, decision_key. Any other value is "default"."""
    gids = {g["decision_key"]: g["gid"] for g in (groups if groups is not None else decisions(items))}
    best = None
    for dk, its in _by_key(items).items():
        exploited = any(_exploited(i) for i in its)
        live, services = 0, {}
        for i in its:
            n, s = _live(i, policy)
            live += n
            for k, v in s.items():
                services[k] = services.get(k, 0) + v
        if live <= 0:
            continue
        key = ((_prio_of(its), -live, -len(its), dk) if policy == "priority"
               else (not exploited, -live, -len(its), dk))
        if best is None or key < best[0]:
            best = (key, dk, its, exploited, live, services)
    if best is None:
        return None
    _, dk, its, exploited, live, services = best
    if policy == "priority":
        p = _prio_of(its)
        reason = " · ".join(([f"priority {p}"] if p < 10**9 else [])
                            + [_n(live, "open row", "open rows"), _n(len(its), "alert", "alerts")])
    else:
        reason = " · ".join(([ "known exploited"] if exploited else [])
                            + [_n(live, "live finding on running software", "live findings on running software"),
                               _n(len(its), "alert", "alerts")])
    return {"decision_key": dk, "gid": gids.get(dk), "alert_ids": [i["alert_id"] for i in its],
            "title": _highlight_title(dk, its, exploited, live, services), "reason": reason}


def rule_label(name: str) -> str:
    """A rule's display words. The rule facts carry no display name (only `name`, e.g. "rule_threat_status_changed",
    and `description`), so the id is humanized: "Threat status changed"."""
    w = str(name or "").strip()
    w = w[5:] if w.lower().startswith("rule_") else w
    w = w.replace("_", " ").replace("-", " ").strip()
    return (w[:1].upper() + w[1:]) if w else str(name or "")


def _names(names: list[str], cap: int = 3) -> str:
    shown = [rule_label(n) for n in names[:cap]]
    return ", ".join(shown) + (f" and {len(names) - cap} more" if len(names) > cap else "")


def _join(parts: list[str]) -> str:
    return parts[0] if len(parts) == 1 else ", ".join(parts[:-1]) + (", and " if len(parts) > 2 else " and ") + parts[-1]


def trust(facts: dict | None) -> list[dict]:
    """What could make this page WRONG, in plain words, only when something is: [] when every figure is measured
    and every rule ran with none blocked. Rules first ("your alert list may be incomplete"), then the figures' dates.
    Each line is {kind, glyph, text, see}: `see` names the page that explains it ("rule_supply": why a rule can never
    fire; "rule_runs": the rules and their runs; "measure_dates": the figures and their dates)."""
    facts = facts or {}
    out: list[dict] = []
    rules = ((facts.get("rules") or {}).get("items")) or []
    rc = ((facts.get("attention") or {}).get("rule_coverage")) or {}
    total_rules = len(rules) or int(rc.get("total") or 0)
    if not total_rules and (facts.get("rules") or rc):
        out.append({"kind": "rules", "glyph": "▲", "see": "rule_runs",
                    "text": "**Nothing is watching this app**: no checks are set up, so no alerts can be raised."})
    elif total_rules:
        never = [r.get("name") for r in rules if r.get("never_ran")]
        failed = [r.get("name") for r in rules if last_run_failed(r)]
        blocked = list(rc.get("blocked_rules") or [])
        n_blocked = int(rc.get("blocked") or 0) or len(blocked)
        parts = []
        if failed:
            parts.append(f"{len(failed)} check{_plural(len(failed), '', 's')} failed on "
                         f"{_plural(len(failed), 'its', 'their')} last run ({_names(failed)})")
        if never:
            parts.append(f"{len(never)} {_plural(len(never), 'has', 'have')} never run ({_names(never)})")
        if n_blocked:
            parts.append(f"{n_blocked} can never fire" + (f" ({_names(blocked)})" if blocked else ""))
        if parts:
            out.append({"kind": "rules", "glyph": "▲", "see": "rule_supply" if n_blocked else "rule_runs",
                        "text": f"**Your alert list may be incomplete**: {_join(parts)}."})
    mix = facts.get("coverage_mix") or {}
    m = {k: int(mix.get(k) or 0) for k in ("measured", "partial", "blind", "not_yet")}
    total = sum(m.values())
    if total and (m["partial"] or m["blind"] or m["not_yet"]):
        parts = []
        if m["partial"]:
            parts.append(f"**{m['partial']} of {total} figures {_plural(m['partial'], 'has', 'have')} no reliable "
                         f"date**, so we can't tell how fresh {_plural(m['partial'], 'it is', 'they are')}")
        if m["blind"]:
            parts.append(f"**{m['blind']} can't be answered** from the data connected")
        if m["not_yet"]:
            parts.append(f"**{m['not_yet']} {_plural(m['not_yet'], 'is', 'are')} set up but never recorded**")
        out.append({"kind": "dates", "glyph": "◐", "see": "measure_dates", "text": "; ".join(parts) + "."})
    return out


def funnel_summary(steps: list[dict]) -> str | None:
    """The collapsed line: "From 28,823 findings to 6 decisions" (first counted step → the outcome)."""
    first = next((s for s in steps if s["count"] is not None), None)
    last = steps[-1] if steps else None
    if not first or not last or first is last:
        return None
    return f"From {first['count']:,} {first['unit']} to {last['count']:,} {last['unit']}"


def decisions(items: list[dict]) -> list[dict]:
    """Group candidate items that are one decision (same decision_key). Only groups of ≥ 2 rows are returned."""
    return [_group(k, its) for k, its in sorted(_by_key(items).items()) if len(its) >= 2]


def _decision_label(dk: str, first: dict) -> str:
    """cve|CVE-2026-53613|util-linux → "CVE-2026-53613 in util-linux"; any other key → its first item's title."""
    p = dk.split("|")
    return f"{p[1]} in {p[2]}" if p[0] == "cve" and len(p) >= 3 else first.get("title") or dk


def cards(items: list[dict], chosen: list[str], groups: list[dict], hl: dict | None, stale: dict | None) -> list[dict]:
    """The Needs-you cards, in page order: the ONE computation behind the V2 page (v2-decisions.ts reads it; it keeps
    its own builder only for runs stored before v5) and `torana workspace <id> ai-home-v2 get`. Arranges ids only:
    titles and texts are code-written here; a card's lead row (headline, AI recommendation, citations) is the
    narrator's row `lead`, which the reader looks up.
    Kinds: `insight` = the highlight's decision (first); `group` = another decision of several alerts; `retired` = ONE
    card for EVERY item pointing at an image that no longer runs, sectioned by decision ("· shown above" when a member
    is on another card); `row` = a decision of one alert (title None: the lead's headline is the title).
    `chosen` = the narrator's rows in its order (the page's rows). A decision whose items are ALL stale is shown only on
    the retired card, unless it is the highlight."""
    by_id = {it["alert_id"]: it for it in items}
    dks = _by_key(items)
    multi_groups = {g["decision_key"]: g for g in groups if len(g["alert_ids"]) > 1}
    top = hl["decision_key"] if hl else None
    stale_ids = [a for a in (stale or {}).get("alert_ids") or [] if a in by_id]
    retired = {"kind": "retired", "key": "retired", "title": "", "text": "", "lead": None,
               "members": stale_ids, "sections": [], "brief": None} if stale_ids else None

    def hl_card(lead):
        return {"kind": "insight", "key": "hl:" + hl["decision_key"], "title": hl["title"], "text": "", "lead": lead,
                "members": list(hl["alert_ids"]), "sections": [{"key": "all", "label": None, "members": list(hl["alert_ids"])}],
                "brief": hl["alert_ids"][0]}

    out: list[dict] = []
    seen: set = set()
    for key in dict.fromkeys(chosen):
        it = by_id.get(key)
        dk = it["decision_key"] if it else None
        if dk and dk in seen:
            continue                                   # a second row of the same decision: already in its card
        if dk:
            seen.add(dk)
        g = multi_groups.get(dk) if dk else None
        if hl and dk == top:
            out.append(hl_card(key))                   # the highlight is a narrator row: its recommendation comes along
        elif retired and dk != top and ((dk and all(i["stale"] for i in dks[dk])) or (not dk and it and it["stale"])):
            if retired not in out:
                out.append(retired)                    # placed where the first stale row was
        elif g:
            out.append({"kind": "group", "key": "g:" + g["gid"], "title": g["text"], "text": g["text"], "lead": key,
                        "members": list(g["alert_ids"]), "brief": g["alert_ids"][0],
                        "sections": [{"key": "all", "label": None, "members": list(g["alert_ids"])}]})
        else:
            out.append({"kind": "row", "key": "r:" + key, "title": None, "text": "", "lead": key, "members": [],
                        "sections": [], "brief": None})
    if hl and not any(c["kind"] == "insight" for c in out):
        out.append(hl_card(None))                      # not a narrator row: no recommendation
    if retired:
        if retired not in out:
            out.append(retired)                        # no stale narrator row: still one card, at the end
        shown = {m for c in out if c is not retired for m in c["members"] + ([c["lead"]] if c["lead"] else [])}
        multi, single = [], []
        for dk, its in _by_key([by_id[a] for a in stale_ids]).items():
            ms = [i["alert_id"] for i in its]
            if len(ms) < 2:
                single += ms
                continue
            above = " · shown above" if any(m in shown for m in ms) else ""
            multi.append({"key": dk, "label": f"{len(ms)} rows · {_decision_label(dk, its[0])}{above}", "members": ms})
        multi.sort(key=lambda s: -len(s["members"]))
        retired["sections"] = multi + ([{"key": "single", "label": "Single rows" if multi else None, "members": single}]
                                       if single else [])
        n, dup = len(stale_ids), sum(1 for m in stale_ids if m in shown)
        retired["title"] = (f"{n} alert{' points at an image' if n == 1 else 's point at images'} that no longer "
                            f"run{'s' if n == 1 else ''}: close {'it' if n == 1 else 'them'}")
        retired["text"] = f"Includes the {dup} above." if dup else ""
    first = next((c for c in out if c["kind"] == "insight"), None)
    if first:
        out.remove(first)
        out.insert(0, first)
    return out


def summarize(items: list[dict], chosen: list[str], groups: list[dict] | None = None, *,
              facts: dict | None = None, proof: dict | None = None) -> dict:
    """Hero, noticed patterns and per-row chips over the rows the narrator chose (in its order).

    `groups` are the run's decision groups over ALL candidates (decisions(items) when None). A group is noticed
    when any chosen row belongs to it, AT ITS FULL SIZE. ⚠️ Deviation from spec § 3.4.4, MEASURED 2026-10-07: the
    narrator is offered one representative per group, so a group never has two chosen rows, and counting groups
    among chosen rows only could never say "12 rows are one decision".
    ⭐ v3: `hero` is outcome-first over the WHOLE run ("6 decisions to act on first · 15 alerts to close · 143 more
    decisions"); `rows` counts the chosen rows, `decisions` the act-first cards (v5: the cards that are not the
    retired one, which the hero and the funnel's outcome also count). `funnel` needs `facts` (and `proof` for its errors);
    without them it starts at "proved". v6: `health` (health.py) is the app's own state, from `facts`; None without them."""
    by_id = {it["alert_id"]: it for it in items}
    rows = [by_id[a] for a in dict.fromkeys(chosen) if a in by_id]
    by_key: dict[str, list[dict]] = {}
    for it in rows:
        by_key.setdefault(it["decision_key"], []).append(it)
    n = len(rows)
    run_groups = {g["decision_key"]: g for g in (groups if groups is not None else decisions(items))}
    groups = sorted((run_groups[k] for k in by_key if k in run_groups),
                    key=lambda g: (-len(g["alert_ids"]), g["decision_key"]))
    stale = stale_line(items)
    unjudged = [it["alert_id"] for it in rows if it["unjudged"]]
    drift = [it["alert_id"] for it in rows if _is_drift(it)]

    noticed = [{"kind": "group", "text": g["text"], "gid": g["gid"], "alert_ids": g["alert_ids"]} for g in groups]
    if stale:
        noticed.append(dict(stale, alert_ids=list(stale["alert_ids"])))
    if unjudged:
        noticed.append({"kind": "unjudged", "alert_ids": unjudged, "text": _plural(
            len(unjudged), "1 row was never judged by triage.", f"{len(unjudged)} rows were never judged by triage.")})
    if drift:
        noticed.append({"kind": "drift", "alert_ids": drift, "text": _plural(
            len(drift), "1 entry has changed since it was raised.", f"{len(drift)} entries have changed since they were raised.")})

    chips: dict[str, list[dict]] = {}
    gid_by_key = {g["decision_key"]: g for g in groups}
    for it in rows:
        c = []
        if it["stale"]:
            c.append({"kind": "stale", "text": "points at a retired image"})
        g = gid_by_key.get(it["decision_key"])
        if g:
            c.append({"kind": "group", "gid": g["gid"],
                      "text": (f"{g['alert_ids'].index(it['alert_id']) + 1} of {len(g['alert_ids'])} in one decision"
                               if it["alert_id"] in g["alert_ids"] else f"one of {len(g['alert_ids'])} in one decision")})
        if it["alert_id"] in drift:
            c.append({"kind": "drift", "text": "changed since raised"})
        if it["unjudged"]:
            c.append({"kind": "unjudged", "text": "never judged"})
        if it["type"] == "unmodelled":
            c.append({"kind": "unmodelled", "text": "no proof model"})
        e = effort_chip(it)
        if e:
            c.append(e)
        chips[it["alert_id"]] = c

    profile = (facts or {}).get("profile") or None
    words = ({**TYPE_WORDS, "group_check": (profile["item_noun"], profile["item_noun_plural"])} if profile else None)
    hl = highlight(items, list(run_groups.values()), policy=(profile or {}).get("highlight", "default"))
    rest = rest_line(items, rows + [i for i in items if hl and i["decision_key"] == hl["decision_key"]], words=words)
    cs = cards(items, chosen, list(run_groups.values()), hl, stale)
    # ⭐ "To act on first" IS the cards that are not the retired one (a narrator row whose decision is all-stale is
    # folded into the ▲ card, so it is a decision to close, not to act on). The hero, the funnel's outcome and
    # `decisions` all read this one count; `rest` already leaves out every stale decision, so nothing is counted twice.
    # MEASURED 2026-10-07, T2 run 9132592c: the hero said 5 over 4 act-first cards (the 5th, util-linux, all-stale).
    acted = sum(1 for c in cs if c["kind"] != "retired")
    steps = funnel(items, rows, facts, proof, stale, rest, acted, profile=profile)
    out = {"rows": n, "decisions": acted,
            "hero": hero_text(acted, len(stale["alert_ids"]) if stale else 0, rest["count"] if rest else 0),
            "noticed": noticed[:NOTICED_MAX], "chips": chips, "stale": stale, "rest": rest,
            "funnel": steps, "funnel_summary": funnel_summary(steps), "trust": trust(facts), "highlight": hl,
            "cards": cs, "health": health(facts), "version": HOME_RULES_VERSION}
    if profile:                    # ⛔ never a None key: a VM home keeps exactly today's keys (APP_PROFILES_SPEC K1)
        out["profile"] = profile
    return out
