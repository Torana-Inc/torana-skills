"""Link-outs: the provider's own page for a thing, built from values the platform stores. A link is returned only when
every input is present and its shape is recognised; otherwise None (no link, never a guess).

Pure functions, one per provider, so the page and the CLI print the same URL.
"""
from __future__ import annotations

import re
from urllib.parse import quote, urlparse

_IMAGE = re.compile(r"^image:([a-z0-9-]+)-docker\.pkg\.dev/([^/]+)/([^/]+)/(.+)@(sha256:[0-9a-f]{64})$")
_REPO = re.compile(r"^repo:github\.com/([^/]+)/([^/]+)$")
_DEPENDABOT = re.compile(r"^gh_dependabot_([^/]+)/(.+)_(\d+)$")
_CVE = re.compile(r"^CVE-\d{4}-\d{4,}$")
_RULE_HOSTS = {"semgrep.dev", "avd.aquasec.com"}


def gar_image_url(image_key: str | None) -> str | None:
    """Artifact Registry page of an image key `image:<region>-docker.pkg.dev/<project>/<repo>/<image>@sha256:<digest>`."""
    m = _IMAGE.match(image_key or "")
    if not m:
        return None
    region, project, repo, image, digest = m.groups()
    return (f"https://console.cloud.google.com/artifacts/docker/{project}/{region}/{repo}/"
            f"{quote(image, safe='')}/{digest}?project={project}")


def github_repo_url(repo_key: str | None) -> str | None:
    m = _REPO.match(repo_key or "")
    return f"https://github.com/{m.group(1)}/{m.group(2)}" if m else None


def github_file_url(repo_key, commit, path, line=None, end_line=None, default_branch=None) -> str | None:
    """The file at the scanned commit (else the default branch), at the flagged line(s)."""
    base, ref = github_repo_url(repo_key), commit or default_branch
    if not base or not ref or not path:
        return None
    url = f"{base}/blob/{quote(str(ref), safe='')}/{quote(str(path), safe='/')}"
    if str(line or "").isdigit():
        url += f"#L{int(line)}"
        if str(end_line or "").isdigit() and int(end_line) > int(line):
            url += f"-L{int(end_line)}"
    return url


def rule_url(uri: str | None) -> str | None:
    """The scanner's own rule page, only where the scanner gave one and it is on a known rule host."""
    try:
        u = urlparse(uri or "")
    except ValueError:
        return None
    return uri if u.scheme == "https" and u.hostname in _RULE_HOSTS else None


def nvd_url(cve: str | None) -> str | None:
    return f"https://nvd.nist.gov/vuln/detail/{cve}" if _CVE.match(cve or "") else None


def kev_url(cve: str | None) -> str | None:
    return f"https://www.cisa.gov/known-exploited-vulnerabilities-catalog?search_api_fulltext={cve}" if _CVE.match(cve or "") else None


def dependabot_url(vuln_id: str | None, alert_number=None, repo_key: str | None = None) -> str | None:
    """The alert's page. The number comes from `scan_output.alert_number` when the row has it (repo from the repository
    key); otherwise it is parsed from the finding id `gh_dependabot_<org>/<repo>_<n>`."""
    if str(alert_number or "").isdigit():
        base = github_repo_url(repo_key)
        if base:
            return f"{base}/security/dependabot/{int(alert_number)}"
    m = _DEPENDABOT.match(vuln_id or "")
    return f"https://github.com/{m.group(1)}/{m.group(2)}/security/dependabot/{m.group(3)}" if m else None


def gke_cluster_url(cluster_name: str | None) -> str | None:
    """Cluster page from `<project>/<location>/<cluster>`. (A workload page needs its kind, which is not stored.)"""
    parts = str(cluster_name or "").split("/")
    if len(parts) != 3 or not all(parts):
        return None
    project, location, cluster = parts
    return f"https://console.cloud.google.com/kubernetes/clusters/details/{location}/{cluster}/details?project={project}"


_WORKLOAD = {"Deployment": "deployment", "StatefulSet": "statefulset", "DaemonSet": "daemonset", "CronJob": "cronjob"}


def gke_workload_url(cluster_name, namespace, name, kind) -> str | None:
    """The workload's page, only when its kind is stored (`custom_attributes_value.workload_kind`); else None, and the
    caller falls back to the cluster page."""
    parts = str(cluster_name or "").split("/")
    path = _WORKLOAD.get(str(kind or ""))
    if len(parts) != 3 or not all(parts) or not path or not namespace or not name:
        return None
    project, location, cluster = parts
    return (f"https://console.cloud.google.com/kubernetes/{path}/{location}/{cluster}/{quote(str(namespace), safe='')}/"
            f"{quote(str(name), safe='')}/overview?project={project}")
