"""Item type: a code finding (SAST, IaC, secrets): one scanner rule in one file of one repository.
Spec: pantheon-fe/docs/AI_HOME_V2_HOME_PROOF_SPEC.md (code findings, 2026-10-07).

Evidence: the ranking's posture_findings row (state, rule, file, CWE, severity, repository, owner, running
and internet-facing services), the scanner reports merged into it (code.reports: lines, flags, the rule's own
classification), the repository row (its owner on the source host), and the entity graph (code.ships:
repo → images → services). Graph: internet → services → images → the repository → this file.
"""
from ..core.render import render
from .alert_facts import O, R, title_and_sub
from .effort import code_effort_claims
from .path import code_path
from .vuln_in_image import claim

CODE = "code: claims.code_finding (template + rules)"
COLS = {"inet": 0, "svc": 1, "img": 2, "repo": 3, "item": 4}
NO_LIFECYCLE = "no scanner reports a lifecycle"


def _state(f, rep) -> dict:
    """Still open? The ranking's state, and what can close it. A code scanner never reports a finding as closed."""
    slots = {"st": R(f, "status"), "is": R(f, "item_state"), "cs": R(f, "closure_signal"),
             "sc": O(rep, "scanner_label"), "last": O(rep, "last_seen", "time"), "n": O(rep, "reports")}
    if f is not None and f.get("closure_signal") == NO_LIFECYCLE:
        tpl = ("Yes: the ranking holds it as {st}, {is}. {sc} last reported it {last} ({n} report{n?|s}). Closure signal: {cs}. {sc} never "
               "reports a finding as closed; it only stops listing it, so this is gone only when a later scan no "
               "longer lists it.")
    else:
        tpl = "{st}, {is}. {sc} last reported it {last} ({n} report{n?|s}). Closure signal: {cs}."
    return claim("still", "state", "Is it still open?", tpl, slots,
                 missing=("No ranking row for this finding: its state is not recorded.", {}) if f is None else None,
                 today=CODE)


def _flags(rep) -> dict:
    slots = {"n": O(rep, "reports"), "w": O(rep, "withdrawn"), "s": O(rep, "suppressed"),
             "fp": O(rep, "false_positive"), "ra": O(rep, "risk_accepted")}
    none = rep is not None and not any(rep[k] for k in ("withdrawn", "suppressed", "false_positive", "risk_accepted"))
    return claim("flags", "state", "Has anyone set it aside?",
                 "No. Of its {n} scanner reports, {w} are withdrawn, {s} suppressed, {fp} marked false positive and "
                 "{ra} risk accepted." if none else
                 "Partly. Of its {n} scanner reports, {w} are withdrawn, {s} suppressed, {fp} marked false positive "
                 "and {ra} risk accepted.", slots, today=CODE)


def _ships(f, ships, repo_ref) -> dict:
    """Does this code ship? The ranking's running and internet-facing services (posture_findings) and the graph's
    path repo → images → deployed images. {svc} is the first slot in every wording (home.py _live reads it)."""
    slots = {"svc": R(f, "services"), "x": R(f, "internet_facing_services"), "repo": repo_ref,
             "imgs": O(ships, "images"), "dep": O(ships, "deployed_images"), "lb": R(f, "load_balancer_keys")}
    if not ships["recorded"]:
        return claim("ships", "deep", "Does this code ship?",
                     "{svc} running service{svc?|s} per the ranking ({x} internet-facing); the path from {repo} to them is "
                     "not recorded.", slots,
                     missing=("Not recorded: no builds_image edge from {repo}, so which images carry this code is "
                              "unknown.", {"repo": repo_ref}), today=CODE)
    running = (f.get("services") or 0) if f is not None else 0
    return claim("ships", "deep", "Does this code ship?",
                 ("Yes: {svc} running service{svc?|s}, {x} of them internet-facing, run images built from {repo} "
                  "(deployed images: {dep} of the {imgs} it built).") if running else
                 "{svc} running service{svc?|s}: no image built from {repo} runs (deployed images: {dep} of the {imgs} it "
                 "built).", slots, today=CODE)


def _owner(f, repo) -> dict:
    slots = {"o": R(f, "owner"), "ro": R(repo, "owner_name"), "rt": R(repo, "owner_type")}
    if repo is None:
        return claim("owner", "fix", "Who owns it?", "{o}, per the ranking.", slots,
                     missing=("The repository's own owner is not recorded: no repositories row for it.", {}),
                     today=CODE)
    differ = str(f.get("owner") if f is not None else "").lower() != str(repo.get("owner_name") or "").lower()
    return claim("owner", "fix", "Who owns it?",
                 "{o}, per the ranking; the repository's owner is {ro} ({rt}). These differ." if differ else
                 "{o}, per the ranking and the repository ({rt}).", slots, today=CODE)


def build_code_claims(build, alert_id: str) -> dict:
    ctx = build.ctx()
    k = ctx.call("alerts.classify", alert_id=alert_id)
    fk = k["finding_key"]
    f = ctx.row("posture_findings", fk)
    rep = ctx.call("code.reports", finding_key=fk)
    repo_key = (f.get("repository_key") if f is not None else None) or fk.split("|")[2]
    ships = ctx.call("code.ships", repo=repo_key)
    repo = ctx.row("repositories", repo_key)
    # The ranking row may not carry its repository (Classie: "plan.py in —"); the finding key and the repositories row do.
    repo_ref = (R(f, "repository_key", "repo") if f is not None and f.get("repository_key")
                else R(repo, "torana_repository_id", "repo") if repo is not None else R(f, "repository_key", "repo"))
    title, sub = title_and_sub(ctx, alert_id)
    claims = [
        _state(f, rep),
        _flags(rep),
        claim("where", "deep", "Where is it?",
              ("{file} in {repo}, line {lines}." if rep["line_count"] == 1 else
               "{file} in {repo}, lines {lines} ({n} lines flagged)."),
              {"file": R(f, "source_file_path"), "repo": repo_ref, "lines": O(rep, "lines"),
               "n": O(rep, "line_count")}, today=CODE),
        claim("rule", "deep", "What did the scanner flag?",
              "{name} Rule {rule}, weakness {cwe}, severity {sev}.",
              {"name": R(f, "vulnerability_name"), "rule": R(f, "rule_id"), "cwe": R(f, "cwe_id"),
               "sev": R(f, "severity")}, today=CODE),
        claim("class", "tech", "How sure is the rule?",
              "The rule classes it as {cls} ({scan}): confidence {conf}, likelihood {lik}, impact {imp}.",
              {"cls": O(rep, "rule_class"), "scan": O(rep, "scan_type"), "conf": O(rep, "rule_confidence"),
               "lik": O(rep, "rule_likelihood"), "imp": O(rep, "rule_impact")}, today=CODE),
        _ships(f, ships, repo_ref),
        claim("action", "fix", "What should happen?",
              "The ranking routes it to {route} ({reason}). {tier} {verdict}",
              {"route": R(f, "route"), "reason": R(f, "reason_label"), "tier": R(f, "tier_line"),
               "verdict": R(f, "verdict_reason")}, today=CODE),
        _owner(f, repo),
    ]
    claims += code_effort_claims(ctx, f, fk)
    sev = f.get("severity") if f is not None else None
    chips = [{"cls": "sev-" + str(sev).lower(), "spans": render("{v} · finding", {"v": R(f, "severity")})},
             {"cls": "", "spans": render("code finding", {})},
             *([{"cls": "warn", "spans": render("internet-facing", {})}]
               if f is not None and (f.get("internet_facing_services") or 0) else [])]
    return {"alert_id": alert_id, "type": "code_finding", "finding_key": fk, "stale": False,
            "title": title, "chips": chips, "sub": sub, "claims": claims, "graph": code_path(ctx, repo_key, fk.split("|", 3)[3] if fk.count("|") >= 3 else None,
                                                                                 fk.split("|")[1] if fk.count("|") >= 1 else None,
                                                                                 sorted({*(rep.get("report_ids") or []), *([k["vuln_id"]] if k.get("vuln_id") else [])}))}
