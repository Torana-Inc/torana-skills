"""Is the app itself working? AI Home V2's "How this app is running" strip and hero tile, written by code.
Part of the ONE home computation (home.summarize stores it as `proof.home.health`). Pure: reads only the facts
payload the collector already decided.

Ported from the narrator's health_block rules (pantheon-agent-builder prompts/ai_home_narration_agent.md
§ health_block), which the model applied unevenly: MEASURED 2026-10-07 on T2, the same recovered agent was `watch`
in run 67553f0a and `ok` in run bcef5874, under the titles "Running with one rule failure and one recovered agent"
and "Working, with one recovered agent failure to note".

⛔ A check whose query no longer compiles (rules[].query_valid False: the detection framework EXPLAINs it against
today's tables on every AI Home run) is ▲ "can no longer run", said before its next run fails; one whose CLOSING
query no longer compiles (closing_valid False) is ▲ "can't close its entries".

Inputs (pantheon-program-framework services/ai_home/collector.py):
  since.agent_runs   one entry per background agent that failed in the window, already decided: state failing |
                     recovered, the bounds, the counts, scope this_app | tenant | mixed (collector agent_run_health).
  rules              items[] {name, never_ran, last_status, last_run_at, last_trigger}; available.
  attention.rule_coverage  {available, blocked, blocked_rules[], blocked_detail[]} when the supply graph was read;
                     blocked_detail = per blocked check {name, owner_split, blocking[{table, column, meaning,
                     what_to_do, verdict_owner, filled_by[{name, status}]}]} (home v11).
  since.agent_runs[].description  the agent's own description (home v11), for what its failures cost.
  workspace.id       this app's id, so a suggested command runs as written.
  collector_errors   [{source, error}]: a source the collector could not read.
  syncs              {available, items[]}: every selected data source whose LATEST run failed or was partial
                     (collector _syncs ← integration sync-overview `failing_sources`). Kept on the sync_failing line as
                     `items` — the drawer behind the tile. Runs stored before it existed fall back to since.items.
  since.items        etl_sync items whose detail.status is "failed" (one item per sync key: its latest state).

Tone (glyph + word, never colour alone): bad ▲ = something is broken now (a failing agent, a rule whose last run
failed); watch ◐ = intermittent or incomplete (a flaky agent whose successes fell between failures, a source not read,
a sync failing, a rule that never ran or cannot fire, rule status unreadable); ok ✓ = nothing broken now, including an
agent whose failures were consecutive and then stopped (said in the past tense, with its times). Agent runs are
counted out of the window's total ("5 of 8 runs") when the facts carry it. ⛔ An agent whose scheduler is switched
off (`switched_off`, collector agent_schedulers) is never a live problem: ok, its own glyph ○, "is switched off". ⛔ ok is refused when any rule never ran (an app whose watches never fired is not a
quiet estate). The title is chosen from the lines' own facts by priority; it is never free text.

⭐ Two lengths of every line (home v16). `text` is the whole story (what it costs, who acts, how) and belongs to the
drawer and `ai-home get --section health`. `short` is one clause naming the thing and its consequence, for the strip
on the page, which lists one `short` per problem under `heading` ("3 things are affecting this app" when more than
one line is a problem, else the title). Bhakta, 2026-10-13, of the strip that joined every `text` into one paragraph:
"there's so much of text that nobody is going to read".
"""
from __future__ import annotations

import re
from contextvars import ContextVar
from datetime import datetime, timezone
from http import HTTPStatus
from zoneinfo import ZoneInfo

from .rule_state import last_run_failed

# ◐ for watch, not ◆: across V2 ◆ means "proven / derived" (cites, chips, Ledger). ○ (switched off) is set per line.
GLYPH = {"bad": "▲", "watch": "◐", "ok": "✓"}
_RANK = {"ok": 0, "watch": 1, "bad": 2}
NAMES_MAX = 3
DEFAULT_TZ = "America/Los_Angeles"
# The zone every time in the lines is written in (set by health(); a ContextVar keeps the helpers pure and thread-safe).
_TZ: ContextVar = ContextVar("proof_health_tz", default=ZoneInfo(DEFAULT_TZ))
# This app's id (facts.workspace.id), so a line's suggested command can be run as written.
_WS: ContextVar = ContextVar("proof_health_ws", default=None)

#: ⛔ EVERY LINE SAYS WHAT IT COSTS AND WHAT TO DO (Bhakta, 2026-10-08: "1 check cannot fire: the data it reads is
#: not supplied ('Aging tail')" — "It has no context and is totally useless"). A line names the thing, what the
#: customer loses because of it, and who acts and how — with a runnable command when the fix is theirs, and "nothing
#: for you to do" said plainly when it is Torana's. A read the collector could not make is said as transient.
_RETRY = (" This page checks again on its next refresh; if it keeps happening, it is a fault on Torana's side, not in "
          "your setup.")


def _ws() -> str:
    return _WS.get() or "<app id>"


def _dt(v) -> datetime | None:
    if not v:
        return None
    try:
        d = datetime.fromisoformat(str(v).replace("Z", "+00:00"))
    except ValueError:
        return None
    return d if d.tzinfo else d.replace(tzinfo=timezone.utc)      # the collector's naive times are UTC


def _local(v):
    """(local datetime, zone label) for a time: "PT" for America/Los_Angeles, else the zone's own abbreviation."""
    d = _dt(v)
    if not d:
        return None, ""
    z = _TZ.get()
    local = d.astimezone(z)
    return local, ("PT" if z.key == DEFAULT_TZ else local.strftime("%Z"))


def _hhmm(v) -> str:
    d, z = _local(v)
    return f"{d.strftime('%-I:%M %p')} {z}" if d else "—"


def _day_hhmm(v) -> str:
    d, z = _local(v)
    return f"{d.strftime('%-d %b %-I:%M %p')} {z}" if d else "—"


def _day(v) -> str:
    d, _ = _local(v)
    return d.strftime("%-d %b") if d else "—"


def _n(n: int, one: str, many: str) -> str:
    return f"{n} {one if n == 1 else many}"


def _check(name) -> str:
    """A rule in plain words, humanized as on the trust line (home.rule_label): 'Finding for review'."""
    from .home import rule_label          # lazy: home imports this module
    return f"'{rule_label(name)}'"


def _names(names: list[str]) -> str:
    shown = ", ".join(names[:NAMES_MAX])
    return shown + (f" and {len(names) - NAMES_MAX} more" if len(names) > NAMES_MAX else "")


def _scope(a: dict) -> str:
    return ("" if a.get("scope") == "this_app" else
            " These runs are not stamped with this app, so they may be another app's work.")


def _codes(a: dict) -> str:
    codes = a.get("status_codes") or []
    return f" (HTTP {', '.join(str(c) for c in codes)})" if codes else ""


def _failed_verb(a: dict) -> str:
    """"timed out" only when every recorded status code is a 504; otherwise "failed"."""
    codes = a.get("status_codes") or []
    return "timed out" if codes and all(int(c) == 504 for c in codes) else "failed"


def _of(a: dict, n: int) -> str:
    """"5 of 8 runs" when the facts carry the window's total (collector v2), else "5 runs"."""
    total = a.get("total_runs")
    return f"{n} of {total} runs" if total and int(total) > n else (f"all {n} runs" if total else _n(n, "run", "runs"))


def _agent_owner(a: dict) -> str:
    """Who acts on a failing agent, read from the HTTP status its runs recorded (pantheon-program-framework CLAUDE.md
    § Advisor sweep failed: 404 = not registered, 400 = not published/active, 422 = a prompt value missing for this
    account). Anything else (5xx, a timeout, no status) is Torana's own fault."""
    codes = {int(c) for c in a.get("status_codes") or [] if str(c).isdigit()}
    aid = a.get("agent_id") or "<agent id>"
    if 404 in codes:
        return (" The platform says this agent isn't installed on this account, so whoever manages agents here needs "
                "to install it (`torana agents list` shows what is installed).")
    if 400 in codes:
        return (" The agent is installed but not published and active, so it refuses to run: publish and activate "
                f"it (`torana agent {aid} publish`, then `torana agent {aid} activate`).")
    if 422 in codes:
        return (" Its prompt is missing a value set up for this account: reload it "
                f"(`torana agent {aid} reload-from-source`).")
    if codes & {401, 403}:
        return " It was refused access: check the permissions of the account it runs as."
    return " This is a fault on Torana's side, not in your setup; you don't need to do anything."


def _agent_job(a: dict, tail: str, fallback: str) -> str:
    """" It <does X>, <tail>" from the agent's own description (collector `description`), else the fallback."""
    job = _what_it_does(a.get("description"))
    return f" It {job}, {tail}" if job else fallback


def _agent_line(a: dict) -> dict:
    """failing (the newest run failed) → bad; flaky (the newest run succeeded, but successes fell between failures)
    → watch; recovered (consecutive failures, then only successes) → ok, in the past tense with its times. Each says
    what the agent's failures cost this app and who acts (`_agent_owner`)."""
    name, n = a.get("agent_name") or a.get("agent_id") or "A background agent", int(a.get("failed_count") or 0)
    verb = _failed_verb(a)
    codes = ", ".join(str(c) for c in a.get("status_codes") or []) if verb == "failed" else ""
    first, last = _hhmm(a.get("first_failed_at")), _hhmm(a.get("last_failed_at"))
    window = f"between {first} and {last}" if first != last else f"at {last}"
    paren = f" (HTTP {codes})" if codes else ""
    ok = int(a.get("ok_since_count") or 0)
    head = {"name": name, "of": _of(a, n)}
    if a.get("switched_off"):
        sc = a.get("scheduler") or {}
        last_any = max((x for x in (a.get("last_failed_at"), a.get("last_ok_at")) if x), key=lambda x: _dt(x),
                       default=None)
        back = (f" Torana's operators turn it back on with {sc['env_var']}=true." if sc.get("env_var") else
                " Torana's operators can turn its scheduler back on.")
        return {**head, "kind": "agent_off", "tone": "ok", "glyph": "○",
                "text": f"{name} is switched off ({sc.get('name') or 'its'} scheduler disabled); its last runs: "
                        f"{_of(a, n)} {verb}{paren}, the last at {_hhmm(last_any)}.{_scope(a)}"
                        f"{_agent_job(a, 'which no longer happens for this app.', ' Its work no longer happens for this app.')}"
                        f" If that is intended, there is nothing to do.{back}"}
    if a.get("state") == "failing":
        between = ", with successes in between" if a.get("interleaved") else ""
        return {**head, "kind": "agent_failing", "tone": "bad",
                "text": f"{name} is failing: {_of(a, n)} {verb} {window}{paren}{between}; no run has succeeded since "
                        f"{last}.{_scope(a)}"
                        f"{_agent_job(a, 'and that is not happening for this app while it fails.', ' Its work for this app is not getting done while it fails.')}"
                        f"{_agent_owner(a)}"}
    if a.get("state") == "flaky":
        return {**head, "kind": "agent_flaky", "tone": "watch",
                "text": f"{name} is flaky: {_of(a, n)} {verb} {window}{paren}, with successes in between; the last "
                        f"{_n(ok, 'run', 'runs')} succeeded.{_scope(a)}"
                        f"{_agent_job(a, 'and the failed runs did none of it.', ' The failed runs did none of its work.')}"
                        f"{_agent_owner(a)}"}
    rec = _hhmm(a.get("recovered_at"))
    since = (f"has run cleanly since {rec} ({_n(ok, 'run', 'runs')})" if a.get("recovered_at_exact", True) else
             f"was running cleanly again by {rec} (at least {_n(ok, 'run', 'runs')} since)")
    least = "at least " if a.get("count_is_floor") else ""
    return {**head, "kind": "agent_recovered", "tone": "ok",
            "text": f"{name} {verb} {least}{_of(a, n)}{paren}, in a row {window}, and {since}.{_scope(a)}"
                    " Nothing to do now."}


def _what_it_does(description) -> str | None:
    """The check's job in its own words: the first clause of its description ("Raises one inbox entry per finding the
    ranking cannot decide on its own"), cut before a parenthesis, a colon, ", with" / ", each" / ", listing" or "so the"; None when it
    has none."""
    d = re.sub(r"^\s*INTERNAL\.\s*", "", str(description or ""), flags=re.I).strip()
    d = re.split(r"\s*[(:;]|,\s*(?:with|each|listing)\s|\s+so the\s|\.\s", d, maxsplit=1)[0].rstrip(" .,")
    return (d[:1].lower() + d[1:]) if d else None


def _streak(r: dict) -> int:
    """Failed runs in a row (collector, 2026-10-08); 1 for facts collected before the streak was recorded."""
    return int(r.get("failed_in_a_row") or 1)


def _rule_failed_text(r: dict) -> str:
    """What failed, for how long, what the customer is missing, and who acts. MEASURED 2026-10-07: "Rule
    rule_finding_for_review failed its last run" was the card's title on T2 while the rule had failed every day since
    6 Oct; a customer could not tell what it meant, that it was ongoing, or that it was not theirs to fix."""
    name, n = _check(r.get("name")), _streak(r)
    if "failed_in_a_row" not in r:                      # facts before 2026-10-08: no streak, no owner
        return f"The {name} check failed its last run at {_hhmm(r.get('last_run_at'))}, so it raised nothing then."
    # ⚠️ ATTEMPTS, not runs: a failed scheduled run is retried and each attempt is its own log, unmarked
    # (MEASURED 2026-10-07: 2 scheduled runs on T2 = 6 FAILED logs, is_retry false on all). So the count is
    # called attempts and the duration is the date it began, which is true either way.
    least = "at least " if r.get("failed_in_a_row_is_floor") else ""
    when = (f"has failed on every attempt since {_day_hhmm(r.get('failing_since'))} ({least}{n} attempts)" if n > 1
            else f"failed its last run, at {_day_hhmm(r.get('last_run_at'))}")
    job = _what_it_does(r.get("description"))
    missing = (f" It {job}, so nothing new from it has reached your Inbox since." if job else
               " Nothing new from it has reached your Inbox since.")
    # Its query still matches the data (else it is rule_broken), so a check that came with the app is failing on
    # Torana's side: here "nothing for you to do" is TRUE, unlike a broken query, which needs the app's update.
    owner = (" This is a problem on Torana's side, not in your data; you don't need to do anything." if r.get("from_app")
             else " It was written for this workspace: whoever owns it should look at its query.")
    return f"The {name} check {when}.{missing}{owner}"


def _owner(r: dict) -> str:
    """Who fixes a broken check, in the customer's terms.

    ⛔ NOT "nothing for you to do". An app's checks change only when the CUSTOMER applies its update (the workspace's
    "Upgrade available" → bundle upgrade); nothing on Torana's side swaps them in. The old wording told the one person
    who could fix it that there was nothing to fix (Bhakta, 2026-10-08)."""
    if r.get("from_app"):
        return (" This is a fault in the app as Torana shipped it, not in your data: applying the latest update to "
                "this app fixes it.")
    return " This check was written for this workspace, so whoever owns it needs to update it."


def _rule_broken_text(r: dict) -> str:
    """A check whose query no longer compiles against today's data (collector query_valid False, a datalake EXPLAIN):
    it cannot run, said BEFORE its next run fails. Names what is missing and who acts; the database error goes in the
    line's `detail` (the drawer's technical detail), never in the sentence."""
    name, job = _check(r.get("name")), _what_it_does(r.get("description"))
    ran = ""
    if last_run_failed(r) and int(r.get("failed_in_a_row") or 0) > 1:
        ran = f" It has failed every time since {_day_hhmm(r.get('failing_since'))}."
    missing = (f" It {job}, so nothing new from it reaches your Inbox until it is fixed." if job else
               " Nothing new from it reaches your Inbox until it is fixed.")
    return f"The {name} check has stopped working: it no longer matches the data it reads.{ran}{missing}{_owner(r)}"


def _rule_cannot_close_text(r: dict) -> str:
    """A check whose CLOSING query no longer compiles (collector closing_valid False): its lifecycle refuses every
    close, so entries whose findings ended stay open. MEASURED 2026-10-07: T2 'Finding for review' left 57 such
    entries open after its own query was fixed (reason_sql compared a text[] column with text).
    ⭐ Said as what the customer SEES (Inbox items that are already resolved), what they can do meanwhile, and who
    fixes it; the database error is the line's `detail`."""
    return (f"Some items in your Inbox may already be resolved. The {_check(r.get('name'))} check can't currently tell "
            "when one of its findings has been fixed or has gone away, so those items stay open. You can close them "
            f"yourself in the meantime.{_owner(r)}")


def _rule_never_ran_text(r: dict) -> str:
    """A check with no run on record: what it would catch, that its silence means nothing, and the two ways to start it."""
    job = _what_it_does(r.get("description"))
    rid = r.get("id") or "<check id>"
    return (f"The {_check(r.get('name'))} check has never run.{f' It {job}.' if job else ''} Until it runs, nothing it "
            "would find reaches your Inbox, so its silence means nothing. Nothing has started it yet: check that it has "
            f"a schedule (`torana workspace {_ws()} schedulers list`), or run it once now (`torana rule {rid} execute`).")


def _field_label(column) -> str:
    """'is_patch_available' → 'patch available': a column as a reader says it."""
    c = re.sub(r"^(is|has)_", "", str(column or "").strip())
    return c.replace("_", " ") or "a field"


def _quoted(labels: list[str]) -> str:
    q = [f"'{x}'" for x in labels]
    return q[0] if len(q) == 1 else ", ".join(q[:-1]) + " and " + q[-1]


def _fills(fields: list[dict]) -> str:
    """How the missing fields would get filled, from the supply graph's own evidence: who records each, else its
    meaning. Fields that share one explanation are said once ("'a' and 'b' are filled only when …")."""
    groups: dict[tuple, list[str]] = {}
    for b in fields:
        who = [c for c in b.get("filled_by") or [] if c.get("name")]
        if who:
            name = str(who[0]["name"])
            name = f"`{name}`" if name.startswith("torana ") else name          # a CLI verb reads as a command to run
            how = " by hand" if all(str(c.get("status") or "") == "manual" for c in who) else ""
            key = ("who", name, how)
        elif b.get("meaning"):
            key = ("meaning", b["meaning"].rstrip("."))
        else:
            continue
        groups.setdefault(key, []).append(_field_label(b.get("column")))
    out = []
    for key, labels in groups.items():
        one = len(labels) == 1
        if key[0] == "who":
            out.append(f" {_quoted(labels)} {'is' if one else 'are'} filled only when {key[1]} records "
                       f"{'it' if one else 'them'}{key[2]}.")
        else:
            m = key[1]
            out.append(f" {_quoted(labels)}: {m[:1].lower()}{m[1:]}.")
    return "".join(out)


def _blocked_owner(d: dict, todo: str | None) -> str:
    """Whose fix it is, from the supply graph's ownership split of the missing fields."""
    split = d.get("owner_split") or {}
    ours, yours = int(split.get("torana") or 0), int(split.get("customer") or 0)
    act = f" {todo[:1].lower()}{todo[1:].rstrip('.')}." if todo else ""
    if ours and not yours:
        return " This is on Torana's side: the platform does not collect it yet, so there is nothing for you to do."
    if yours and ours:
        return f" Part of this is yours to fix and part is Torana's (not collected yet).{act}"
    return f" This is yours to fix:{act}" if act else " This is yours to fix."


def _rule_blocked_lines(coverage: dict, by_name: dict) -> list[dict]:
    """One line per check that can never fire, with the fields it is missing as the drawer's rows.

    ⭐ From `coverage.blocked_detail` (collector, from the supply graph): each check's missing fields with what fills
    them and whose fix it is. A run stored before that existed only has names, and says where to look."""
    b = int(coverage["blocked"])
    detail = [d for d in coverage.get("blocked_detail") or [] if isinstance(d, dict) and d.get("name")]
    if not detail:
        names = _names([_check(x) for x in coverage.get("blocked_rules") or []])
        return [{"kind": "rule_blocked", "tone": "watch", "count": b,
                 "text": f"{_n(b, 'check cannot', 'checks cannot')} fire: the data {'it reads is' if b == 1 else 'they read is'} "
                         f"not supplied ({names}), so {'it' if b == 1 else 'they'} will raise nothing until it is. Which "
                         "data, and who supplies it: `torana datalake supply questions`."}]
    out = []
    for d in detail:
        r = by_name.get(d["name"]) or {}
        job = _what_it_does(r.get("description") or d.get("description"))
        fields = [f for f in d.get("blocking") or [] if f.get("column")]
        labels = [_field_label(f["column"]) for f in fields]
        todo = next((f["what_to_do"] for f in fields if f.get("what_to_do")), None)
        depends = (f" It depends on {_quoted(labels)}, which nothing on this account fills, so it can never find a "
                   "match." if labels else "")
        out.append({
            "kind": "rule_blocked", "tone": "watch", "count": b, "name": d["name"], "fields": labels,
            "text": f"The {_check(d['name'])} check will never raise anything.{f' It {job}.' if job else ''}{depends}"
                    f"{_fills(fields)}{_blocked_owner(d, todo)}",
            "detail": ", ".join(f"{f.get('table')}.{f['column']}" for f in fields) or None,
            # The drawer: one row per missing field.
            "items": [{"field": _field_label(f["column"]), "column": f"{f.get('table')}.{f['column']}",
                       "filled_by": (f.get("filled_by") or [{}])[0].get("name"),
                       "meaning": f.get("meaning"), "what_to_do": f.get("what_to_do"),
                       "owner": f.get("verdict_owner")} for f in fields],
        })
    return out


def _rule_lines(rules: dict, coverage: dict) -> list[dict]:
    if rules.get("available") is False or rules.get("items") is None:
        return [{"kind": "rules_unknown", "tone": "watch",
                 "text": "This app's checks could not be read, so a quiet Inbox does not yet mean nothing was found."
                         + _RETRY}]
    items = rules.get("items") or []
    out = []
    broken = [r for r in items if r.get("query_valid") is False]
    for r in broken:
        out.append({"kind": "rule_broken", "tone": "bad", "name": r.get("name"), "text": _rule_broken_text(r),
                    "detail": r.get("query_error")})
    for r in items:
        if r.get("query_valid") is not False and r.get("closing_valid") is False:
            out.append({"kind": "rule_cannot_close", "tone": "bad", "name": r.get("name"),
                        "text": _rule_cannot_close_text(r), "detail": r.get("closing_error")})
    failed = [r for r in items if r.get("query_valid") is not False and last_run_failed(r)]
    for r in failed:
        out.append({"kind": "rule_failed", "tone": "bad", "name": r.get("name"), "streak": _streak(r),
                    "since": _day(r.get("failing_since")) if r.get("failing_since") else None,
                    "text": _rule_failed_text(r)})
    never = [r for r in items if r.get("never_ran")]
    for r in never:
        out.append({"kind": "rule_never_ran", "tone": "watch", "count": len(never), "name": r.get("name"),
                    "text": _rule_never_ran_text(r)})
    if (coverage or {}).get("available") and int(coverage.get("blocked") or 0):
        out += _rule_blocked_lines(coverage, {r.get("name"): r for r in items})
    return out


#: A sync's raw reason (error class or the integration service's short reason) → words a customer can read. ⚠️ The raw
#: value is kept as the row's `detail` (the drawer's technical detail); an unknown class reads "the sync failed" rather
#: than leaking a class name ("ExtractorError") into the sentence.
_PLAIN_REASON = {
    "extractorerror": "couldn't read from the source",
    "k8sclusterunreachable": "can't reach the cluster",
    "partial project scope": "some projects weren't collected",
    "stalltimeouterror": "stopped making progress", "stucktimeouterror": "stopped making progress",
    "stalled": "stopped making progress", "zero record regression": "returned no data",
    "permission denied": "access was denied", "credentials rejected": "the credentials were rejected",
    "api not enabled": "an API it needs is turned off", "not found": "something it reads no longer exists",
    "rate limited": "the source is rate-limiting us", "upstream error": "the source returned an error",
    "timed out": "timed out",
}


def _plain_reason(raw) -> str | None:
    if not raw:
        return None
    return _PLAIN_REASON.get(str(raw).strip().lower(), "the sync failed")


def _event_reason(d: dict) -> str | None:
    """What failed, as recorded on a sync event: "403 Forbidden", else "authentication failed", else its error class.
    The HTTP code is only ever the one the integration service recorded (`error_status`); never guessed from text."""
    code = d.get("error_status")
    if isinstance(code, int) or str(code or "").isdigit():
        try:
            return f"{int(code)} {HTTPStatus(int(code)).phrase}"
        except ValueError:
            return f"HTTP {int(code)}"
    if d.get("auth_failure"):
        return "authentication failed"
    return str(d.get("error_class") or "").strip() or None


def _is_plain(d: dict) -> bool:
    """An HTTP status or an auth failure already reads as words; an error class does not."""
    return bool(d.get("auth_failure")) or isinstance(d.get("error_status"), int) or str(d.get("error_status") or "").isdigit()


def _failed_syncs(items: list) -> list[dict]:
    """Every failed etl_sync event, roll-up members included (a head that moved records can hide a failed member)."""
    out = []
    for i in items or []:
        for m in [i] + list(i.get("members") or []):
            if m.get("producer", i.get("producer")) == "etl_sync" and \
                    str((m.get("detail") or {}).get("status") or "").lower() == "failed":
                out.append(m)
    return out


def _event_row(m: dict) -> dict:
    """A sync row from a failed etl_sync event. The integration's name is read off the event's title ("GitHub — ClassieAI/teams
    could not authenticate …") when the detail does not carry it."""
    d = m.get("detail") or {}
    raw = _event_reason(d)
    name = d.get("integration_name")
    if not name and d.get("data_source"):
        head = str(m.get("title") or "").partition(f"/{d['data_source']}")
        name = head[0].strip() if head[1] else None
    return {"integration_id": d.get("integration_id"), "integration_name": name,
            "data_source": d.get("data_source"), "status": "failed",
            "reason": raw if _is_plain(d) else _plain_reason(raw), "detail": raw,
            "failing_since": m.get("created_at"), "last_success_at": None}


def _in_window(m: dict, window: dict | None) -> bool:
    since = _dt((window or {}).get("since_at"))
    at = _dt(m.get("created_at"))
    return bool(since and at and at >= since)


def _sync_rows(syncs: dict | None, items: list, window: dict | None = None) -> list[dict] | None:
    """One row per data sync needing attention, the drawer behind the tile — or None when unknown.

    ⭐ From `syncs` (collector `_syncs`: sync-overview's `failing_sources`, the LATEST run of every selected data
    source, failed or partial) — the same list the integrations page reads, so the two cannot disagree. ⛔ PLUS every
    sync whose run FAILED inside the window (the timeline's etl_sync events, one per sync key: its latest state) that
    `syncs` does not list: the integration's top-level "healthy" must never hide a failed run (Classie 2026-10-08: the
    GitHub `teams` and `repo_teams` syncs failed on every run with "credentials rejected" while `syncs` was empty and
    the page read "All working"). A run stored before `syncs` existed uses the timeline events alone.
    """
    if isinstance(syncs, dict) and syncs.get("available") is False:
        return None
    rows: list[dict] = []
    if isinstance(syncs, dict) and isinstance(syncs.get("items"), list):
        rows = [{"integration_id": s.get("integration_id"), "integration_name": s.get("integration_name"),
                 "data_source": s.get("data_source"), "status": str(s.get("status") or "failed").lower(),
                 "reason": _plain_reason(s.get("reason")), "detail": s.get("reason"),
                 "failing_since": s.get("failing_since"),
                 "last_success_at": s.get("last_success_at")}
                for s in syncs["items"] if isinstance(s, dict)]
        events = [m for m in _failed_syncs(items) if _in_window(m, window)]       # only what the window itself shows
    else:
        events = _failed_syncs(items)
    seen = {(r["integration_id"], r["data_source"]) for r in rows}
    for m in events:
        row = _event_row(m)
        if (row["integration_id"], row["data_source"]) not in seen:
            seen.add((row["integration_id"], row["data_source"]))
            rows.append(row)
    return rows


def _sync_noun(rows: list[dict]) -> str:
    """'2 data syncs are failing' / '1 data sync is incomplete' / '3 data syncs are failing or incomplete'."""
    failed = sum(1 for r in rows if r["status"] != "partial")
    word = ("failing" if failed == len(rows) else "incomplete" if failed == 0 else "failing or incomplete")
    return f"{_n(len(rows), 'data sync is', 'data syncs are')} {word}"


#: The collector's source keys (`_get(source, …)`, `self.errors`) as a reader names them. A key ending in "_" is a
#: prefix (one key per rule or dashboard). An unknown key reads as "part of this page's data", never the raw key.
_SOURCE_LABEL = {
    "integration_syncs": "data-sync status", "alerts_inbox": "the Inbox", "alerts_all": "this app's alerts",
    "alerts_open_entries": "open Inbox entries", "alerts_open_total": "the open-alert count",
    "workspace_widgets": "this app's widgets", "supply_workspace": "which data each check and widget can use",
    "alert_routes": "alert routing", "triage_agents": "this app's triage agent",
    "rules_query_validity": "whether this app's checks still run", "rules_for_workspace": "this app's checks",
    "rule_runs_": "a check's run history", "workspace_dashboards": "this app's dashboards",
    "dashboard_detail_": "a dashboard's widgets", "timeline": "this app's activity", "workspace": "this app's details",
    "highlights": "highlights",
}


def _source_label(key: str) -> str:
    for k, v in _SOURCE_LABEL.items():
        if key == k or (k.endswith("_") and key.startswith(k)):
            return v
    return "part of this page's data"


def _source_lines(errors: list, items: list, syncs: dict | None = None, window: dict | None = None) -> list[dict]:
    out = []
    errs = [e for e in errors or [] if isinstance(e, dict)]
    srcs = sorted({str(e.get("source") or "a source") for e in errs})
    if srcs:
        labels = sorted({_source_label(s) for s in srcs})
        out.append({"kind": "source_unread", "tone": "watch", "count": len(srcs),
                    "text": f"Part of this page could not be read this time ({_names(labels)}), so anything built from "
                            f"{'it' if len(labels) == 1 else 'them'} may be missing or incomplete here." + _RETRY,
                    "detail": "; ".join(f"{e.get('source')}: {e.get('error')}" for e in errs)[:500] or None})
    rows = _sync_rows(syncs, items, window)
    if rows:
        reasons = sorted({str(r.get("reason") or "") for r in rows} - {""})
        raw = sorted({str(r.get("detail") or "") for r in rows} - {""})
        since = min((str(r["failing_since"]) for r in rows if r.get("failing_since")), default=None)
        names = sorted({str(r.get("integration_name")) for r in rows if r.get("integration_name")})
        where = f" across {_n(len(names), 'integration', 'integrations')} ({_names(names)})" if names else ""
        # ⭐ Said as what the customer SEES: which integrations, why in plain words, since when, and what that does to
        # the numbers on this page. The error classes go in `detail`. `items` STAYS on the stored line (health() pops
        # only the title helpers): it is the drawer; nothing here offers a re-sync — that is the integration page's.
        out.append({"kind": "sync_failing", "tone": "watch", "count": len(rows), "noun": _sync_noun(rows),
                    "where": f" across {_n(len(names), 'integration', 'integrations')}" if names else "",
                    "since": _day(since) if since else None,
                    "text": f"{_sync_noun(rows)}{where}"
                            f"{' since ' + _day_hhmm(since) if since else ''}"
                            f"{' (' + '; '.join(reasons) + ')' if reasons else ''}. Anything on this page built from "
                            f"{'its' if len(rows) == 1 else 'their'} data is as of the last successful sync. Fix "
                            f"{'it' if len(rows) == 1 else 'them'} on {'the' if len(names) <= 1 else 'each'} integration's page.",
                    "detail": ", ".join(raw) or None,
                    "items": rows})
    return out


def _routing_lines(routing) -> list[dict]:
    """Alerts that went nowhere (collector `routing`, absent on older runs). A read that failed says so; it never
    says "none".

    ⛔ ZERO ROUTES IS NOT "NOWHERE TO GO". An alert no route claims goes to the workspace's triage agent by default
    (detection-framework `routing_worker.py`, DEFAULT-TO-TRIAGE). So it goes nowhere only when there is no route
    AND no triage agent. Warning on routes alone told every Exposure Posture & Remediation workspace (whose bundle
    ships no routes, by design) that its alerts reached nobody, while its agent was triaging them (Classie
    2026-10-08: 53 of 64 alerts carried a verdict).
    `triage_agents` counts THIS workspace's triage attachments, the agent default triage actually resolves."""
    if not isinstance(routing, dict):
        return []
    if routing.get("available") is False:
        return [{"kind": "routing_unknown", "tone": "watch",
                 "text": "Whether this app's alerts reach anyone (its alert routes and triage agent) could not be "
                         "read." + _RETRY}]
    routes, agents = routing.get("alert_routes"), routing.get("triage_agents")
    attach = (f"attach a triage agent to this app (`torana workspace {_ws()} agents attach --agent-name <name> "
              "--role triage`)")
    if routes == 0 and agents == 0:
        return [{"kind": "no_alert_route", "tone": "watch",
                 "text": "No alert route is set and no triage agent is attached, so the alerts this app raises "
                         "reach nobody: they sit in the Inbox unjudged until a person opens them. To fix, "
                         f"{attach}, or add an alert route that sends them to a person or channel "
                         "(`torana alert-routes create --file route.yaml`)."}]
    if agents == 0:
        return [{"kind": "no_triage_agent", "tone": "watch",
                 "text": "No triage agent is attached, so alerts no route claims are not judged: they wait in the "
                         f"Inbox for a person. To fix, {attach}."}]
    return []


def _title(lines: list[dict]) -> str:
    """The worst fact, in plain words. Order: failing agent, a check that can no longer run, a check that can't
    close its entries, failed rule, flaky agent, unread source, failing sync,
    rule never ran, rule cannot fire, rule status unknown, recovered or switched-off agent, nothing."""
    by = {}
    for ln in lines:
        by.setdefault(ln["kind"], []).append(ln)
    if "agent_failing" in by:
        a = by["agent_failing"]
        return (f"{a[0]['name']} is failing: {a[0]['of']} failed" if len(a) == 1
                else f"{len(a)} background agents are failing")
    if "rule_broken" in by:
        r = by["rule_broken"]
        return (f"The {_check(r[0]['name'])} check can no longer run" if len(r) == 1
                else f"{len(r)} checks can no longer run")
    if "rule_cannot_close" in by:
        return "Some Inbox items may already be resolved"
    if "rule_failed" in by:
        r = by["rule_failed"]
        if len(r) > 1:
            return f"{len(r)} checks are failing"
        since = r[0].get("since")
        return (f"The {_check(r[0]['name'])} check has been failing since {since}" if r[0]["streak"] > 1 and since
                else f"The {_check(r[0]['name'])} check failed its last run")
    if "agent_flaky" in by:
        a = by["agent_flaky"]
        return (f"{a[0]['name']} is flaky: {a[0]['of']} failed" if len(a) == 1
                else f"{len(a)} background agents are flaky")
    if "source_unread" in by:
        return f"Some figures are incomplete: {_n(by['source_unread'][0]['count'], 'source', 'sources')} could not be read"
    if "sync_failing" in by:
        return f"Some data is out of date: {by['sync_failing'][0]['noun']}"
    if "no_alert_route" in by or "no_triage_agent" in by:
        return ("Alerts have nowhere to go" if "no_alert_route" in by else "Hard findings are not being judged")
    if "rule_never_ran" in by:
        c = len(by["rule_never_ran"])
        return "A check has never run" if c == 1 else f"{c} checks have never run"
    if "rule_blocked" in by:
        c = by["rule_blocked"][0]["count"]
        return "A check cannot fire" if c == 1 else f"{c} checks cannot fire"
    if "rules_unknown" in by:
        return "Rule runs could not be read"
    if "routing_unknown" in by:
        return "Alert routing could not be read"
    if "agent_recovered" in by or "agent_off" in by:
        off = by.get("agent_off") or []
        if not by.get("agent_recovered"):
            return (f"All working · {off[0]['name']} is switched off" if len(off) == 1
                    else f"All working · {len(off)} background agents are switched off")
        a = by["agent_recovered"]
        return (f"All working now · {a[0]['name']} recovered after {a[0]['of']} failed" if len(a) == 1
                else f"All working now · {len(a)} background agents recovered")
    return "All working"


def _short(ln: dict) -> str:
    """The line in one clause, for the strip: the thing and its consequence. The cost, the owner and the fix stay in
    `text` (the drawer). Built from the same helper facts the title reads, so the two cannot disagree."""
    k, name = ln["kind"], ln.get("name")
    if k == "agent_failing":
        return f"{name} is failing: {ln['of']} failed"
    if k == "agent_flaky":
        return f"{name} is flaky: {ln['of']} failed"
    if k == "agent_recovered":
        return f"{name} recovered after {ln['of']} failed"
    if k == "agent_off":
        return f"{name} is switched off"
    if k == "rule_broken":
        return f"The {_check(name)} check can no longer run"
    if k == "rule_cannot_close":
        return f"The {_check(name)} check can't close its items, so some Inbox items may already be resolved"
    if k == "rule_failed":
        since = ln.get("since")
        return (f"The {_check(name)} check has been failing since {since}" if ln["streak"] > 1 and since
                else f"The {_check(name)} check failed its last run")
    if k == "rule_never_ran":
        return f"The {_check(name)} check has never run"
    if k == "rule_blocked":
        if not name:                                        # a run stored before blocked_detail: names only
            return f"{_n(ln['count'], 'check cannot', 'checks cannot')} fire: the data is not supplied"
        fields = ln.get("fields") or []
        return f"The {_check(name)} check can never fire" + (f": nothing fills {_quoted(fields)}" if fields else "")
    if k == "rules_unknown":
        return "This app's checks could not be read"
    if k == "source_unread":
        return f"{_n(ln['count'], 'source', 'sources')} could not be read, so some figures may be incomplete"
    if k == "sync_failing":
        since = f" since {ln['since']}" if ln.get("since") else ""
        return f"{ln['noun']}{ln.get('where') or ''}{since}, so figures here are as of the last good sync"
    if k == "routing_unknown":
        return "Alert routing could not be read"
    if k == "no_alert_route":
        return "Alerts reach nobody: no alert route is set and no triage agent is attached"
    if k == "no_triage_agent":
        return "No triage agent is attached, so alerts no route claims wait for a person"
    return ln["text"]


def _heading(lines: list[dict], title: str) -> str:
    """The strip's own heading: how many lines are a problem when more than one is, else the title (the worst fact).
    The title alone named one problem of several (EPR 2026-10-13: three lines under "Some Inbox items may already
    be resolved")."""
    n = sum(1 for ln in lines if ln["tone"] != "ok")
    return f"{n} things are affecting this app" if n > 1 else title


def health(facts: dict | None, tz: str | None = None) -> dict | None:
    """{tone, glyph, title, heading, lines[{kind, tone, glyph, text, short}]} for the facts payload, or None without facts (a run
    stored before the facts existed keeps the narrator's health_block). Lines in order of severity, then input."""
    if not isinstance(facts, dict) or not facts:
        return None
    token = _TZ.set(ZoneInfo(tz or DEFAULT_TZ))
    ws_token = _WS.set(str((facts.get("workspace") or {}).get("id") or "") or None)
    try:
        return _health(facts)
    finally:
        _WS.reset(ws_token)
        _TZ.reset(token)


def _all_clear_text(facts: dict) -> str:
    """"2 of 5 checks ran in this window and none failed; the other 3 last ran 8 Oct 12:04 AM PT to 12:41 AM PT (before
    it) …" Counted by runs INSIDE the window: a check that last ran before it says so, never "ran"."""
    items = [r for r in (facts.get("rules") or {}).get("items") or [] if not r.get("never_ran")]
    tail = "; no background agent failed in this window."
    since = _dt((facts.get("window") or {}).get("since_at"))
    if not since:
        return f"{_n(len(items), 'rule', 'rules')} ran and none failed{tail}"
    inside = [r for r in items if (_dt(r.get("last_run_at")) or since) >= since]
    outside = sorted((r["last_run_at"] for r in items if r not in inside), key=lambda v: _dt(v))
    if not outside:
        return f"All {_n(len(items), 'check', 'checks')} ran in this window and none failed{tail}"
    first, last = _day_hhmm(outside[0]), _hhmm(outside[-1])
    when = first if first == _day_hhmm(outside[-1]) else (f"{first} to {last}" if _day(outside[0]) == _day(outside[-1]) else f"{first} to {_day_hhmm(outside[-1])}")
    return (f"{len(inside)} of {_n(len(items), 'check', 'checks')} ran in this window and none failed; the other {len(outside)} last ran "
            f"{when}, before it{tail}")


def _health(facts: dict) -> dict:
    since = facts.get("since") or {}
    lines = [_agent_line(a) for a in since.get("agent_runs") or [] if isinstance(a, dict)]
    lines += _rule_lines(facts.get("rules") or {}, (facts.get("attention") or {}).get("rule_coverage") or {})
    lines += _source_lines(facts.get("collector_errors") or [], since.get("items") or [], facts.get("syncs"), facts.get("window"))
    lines += _routing_lines(facts.get("routing"))
    lines.sort(key=lambda ln: -_RANK[ln["tone"]])          # stable: equal tones keep input order
    if not lines:
        lines = [{"kind": "all_clear", "tone": "ok", "text": _all_clear_text(facts)}]
    tone = max((ln["tone"] for ln in lines), key=lambda t: _RANK[t])
    title = _title(lines)
    heading = _heading(lines, title)
    for ln in lines:
        ln.setdefault("glyph", GLYPH[ln["tone"]])           # ○ = switched off: not running, and not a fault
        ln["short"] = _short(ln)
        for k in ("name", "count", "of", "streak", "since", "noun", "where", "fields"):
            ln.pop(k, None)
    return {"tone": tone, "glyph": GLYPH[tone], "title": title, "heading": heading, "lines": lines}


def as_strip(h: dict | None) -> dict | None:
    """The strip as the pages and the CLI draw it: {verdict, heading, body, tone, lines}. ONE mapping of health() for every
    surface (the V2 page, the classic page, `ai-home get`), so the words never differ between them."""
    if not h:
        return None
    return {"verdict": h["title"], "heading": h.get("heading") or h["title"], "body": " ".join(f"{ln['glyph']} {ln['text']}" for ln in h["lines"]),
            "tone": h["tone"], "lines": h["lines"]}
