"""effort — how big a fix is. PROOF_ASSESSMENTS_SPEC § 3.2.4. change_type and reference read the ranking's own rows
(derived). estimate and code_fix turn facts into days with the constants below: both are judgements."""
import math
import re

from ..core.engine import rule

_EPOCH = re.compile(r"^(\d+):")
_WORST = {"none": 0, "revision": 1, "patch": 2, "minor": 3, "major": 4, "unknown": 5}


def _order(v) -> list:
    """The ranking's own ordering key for a version: every run of digits, as numbers (the `fixed_order` expression of
    the posture_fixes definition, pantheon-data-transformers definitions.json)."""
    return [int(x) for x in re.findall(r"\d+", str(v or ""))]


def _shape(v) -> str:
    """The ranking's own test of whether two versions can be ordered against each other (`fixed_shape`): equal shapes."""
    return re.sub(r"[0-9.]+", "#", re.sub(r"([.]0+)+$", "", str(v or "")))


def _cmp(a, b) -> int:
    x, y = _order(a), _order(b)
    n = max(len(x), len(y))
    x, y = x + [0] * (n - len(x)), y + [0] * (n - len(y))
    return (x > y) - (x < y)


def _one(frm: str, to: str) -> str:
    """The kind of change from one version to another, by the first number that differs: the first is major, the
    second minor, the third patch, any later one a revision (a packaging revision or a pre-release step). `none` when
    the strings are the same or the version in use is past the target;
    `unknown` when a version has no number or the two carry different epochs ("1:9.2" against "2:1.0")."""
    if frm == to:
        return "none"
    ef, et = _EPOCH.match(frm), _EPOCH.match(to)
    if (ef.group(1) if ef else None) != (et.group(1) if et else None):
        return "unknown"
    a, b = _order(_EPOCH.sub("", frm)), _order(_EPOCH.sub("", to))
    if not a or not b:
        return "unknown"
    n = max(len(a), len(b))
    a, b = a + [0] * (n - len(a)), b + [0] * (n - len(b))
    if a > b and _shape(frm) == _shape(to):
        return "none"                    # past the target, by the ranking's own rule: same shape, greater key
    i = next((i for i in range(n) if a[i] != b[i]), n)
    return "major" if i == 0 else "minor" if i == 1 else "patch" if i == 2 else "revision"


def target_of(row):
    """(target version, its order was not checked). The entry's own members' version when the relation has it
    (framework 0.6.1), else the package-wide recommended_version: the same choice claims.entries._target makes for the
    `what` claim (a module cannot import a claim builder; tests/proof/test_effort.py pins that the two agree). T2 and
    Classie have no entry_version column (spec § 2.1.7, § 2.6.4); a live read of a missing column is None."""
    ev = row.get("entry_version")
    if ev is not None:
        return ev, row.get("entry_version_order_not_checked") is True or "," in str(ev)
    rv = row.get("recommended_version")      # a comma means the cell holds the list of fixed versions, not one target
    return rv, row.get("recommended_version_order_not_checked") is True or "," in str(rv or "")


@rule("effort.change_type", 1)
def change_type(ctx, key: str) -> dict:
    """What kind of version change the upgrade is: the largest change from any version in use to the target, with the
    version it came from (major, minor, patch, revision; `unknown` when the ranking could not order the fixed versions
    or a version cannot be read). `change` is None, with `why`, when there is nothing to change: no target, no version
    in use, every version in use already equal to the target, or the ranking's own finding that what is installed is
    at or above the fix."""
    row = ctx.row("posture_fixes", key)
    none = {"change": None, "worst_from": None, "to": None}
    if row is None:
        return {**none, "why": "the entry no longer exists"}
    to, unchecked = target_of(row)
    used = [v.strip() for v in str(row.get("versions_in_use") or "").split(",") if v.strip()]
    if to is None or not used:
        return {**none, "to": to, "why": "the entry has no version left to change"}
    both, comparable = row.get("members_with_both_versions"), row.get("comparable_members")
    # The definition's own three-part test (per_fix): every member carrying both versions is comparable, and all pass.
    if row.get("installed_at_or_above_fixed") is True and comparable and comparable == both:
        return {**none, "to": to, "why": "what is installed is already at or above the fixed version"}
    if unchecked:
        return {"change": "unknown", "worst_from": None, "to": to, "why": None}
    change, frm = max(((_one(v, str(to)), v) for v in used), key=lambda t: _WORST[t[0]])
    if change == "none":
        return {**none, "to": to, "why": "what is installed is already at or past the target version"}
    return {"change": change, "worst_from": frm, "to": to, "why": None}


REFERENCE_MAX = 50               # beyond this many vulnerabilities the pass reports that it did not check


def _pairs(text) -> list:
    """posture_fixes.minimum_version_per_cve is "<id> <version>; <id> <version>; …" (the definition's per_cve CTE:
    one fixed version per vulnerability id that has one, ids in order)."""
    out = []
    for part in str(text or "").split(";"):
        vid, _, ver = part.strip().partition(" ")
        if vid and ver.strip():
            out.append((vid, ver.strip()))
    return out


@rule("effort.reference", 1)
def reference(ctx, key: str) -> dict:
    """Of the vulnerabilities this package has a fixed version for anywhere in the estate
    (posture_fixes.minimum_version_per_cve), how many are on the known-exploited list (vm_cve_metadata.kev_listed is
    TRUE; anything else is not listed), and how the highest version those need compares with this entry's target:
    `below`, `equal` or `above`, or `unknown` when the target's order was not checked or the versions are not of one
    shape (the ranking's own condition for ordering two versions)."""
    row = ctx.row("posture_fixes", key)
    pairs = _pairs(row.get("minimum_version_per_cve")) if row else []
    if not pairs or len(pairs) > REFERENCE_MAX:
        return {"count": len(pairs), "listed": None, "needs": None, "relation": None, "checked": False}
    rows = ctx.select("vm_cve_metadata", [["cve_id", "in", sorted({c for c, _ in pairs})]], ["kev_listed", "is_deleted"])
    on_list = {r.key for r in rows if r.get("kev_listed") is True and r.get("is_deleted") is not True}
    listed = [v for c, v in pairs if c in on_list]
    out = {"count": len(pairs), "listed": len(listed), "needs": None, "relation": None, "checked": True}
    if not listed:
        return out
    target, unchecked = target_of(row)
    if unchecked or target is None or len({_shape(v) for v in [*listed, str(target)]}) != 1 or not _order(target):
        return {**out, "relation": "unknown"}
    top = listed[0]
    for v in listed[1:]:                                   # the highest; ties keep the greater string, as the ranking does
        if _cmp(v, top) > 0 or (_cmp(v, top) == 0 and v > top):
            top = v
    c = _cmp(top, str(target))
    return {**out, "needs": top, "relation": "below" if c < 0 else "equal" if c == 0 else "above"}


# ⭐ THE ONE PLACE the estimate's numbers live. Days. Starting values accepted by Bhakta 2026-10-13 (spec § 3.10.1):
# change one, bump the rule version, and every estimate moves together.
EDIT = 0.25                                   # one change; where the version is declared is a later pass (Manifests)
REVIEW = {"revision": 0.0, "patch": 0.0, "minor": 0.25, "major": 0.5, "unknown": 0.5}
TEST = {"revision": 0.25, "patch": 0.25, "minor": 1.0, "major": 2.0, "unknown": 2.0}
ROLLOUT_ONE, ROLLOUT_SEVERAL = 0.25, 0.5
SPREAD_NO_CODE = 2.0                          # the high end is the low end times this while no code has been read
# Why each part costs what it does, as a sentence a person reads beside the days (the drawer, the CLI).
CHANGE_WHY = {"major": "a major version change", "minor": "a minor version change", "patch": "a patch version change",
              "revision": "a packaging or pre-release revision", "unknown": "a change whose size is not known"}
BANDS = ((1.0, "Small"), (3.0, "Medium"))     # by the low end; else Large
CODE_FIX = {"edit": 0.25, "test": 0.25}


def _q(x: float) -> float:
    """To the nearest quarter day, halves up (round() would round half to even)."""
    return math.floor(x * 4 + 0.5) / 4


def _answer(parts: list) -> dict:
    low = _q(sum(p["days"] for p in parts))
    high = _q(low * SPREAD_NO_CODE)
    # Why the answer is a range, as the one sentence every surface prints: the platform writes it, number included.
    note = f"No code has been read yet, so allow up to double: {high:g} day{'' if high == 1 else 's'}."
    return {"low": low, "high": high, "band": next((n for top, n in BANDS if low <= top), "Large"),
            "spread": SPREAD_NO_CODE, "range_note": note, "parts": parts, "basis": "estate only",
            **{k: sum(p["days"] for p in parts if p["part"] == k) for k in ("edit", "review", "test", "rollout")}}


@rule("effort.estimate", 1, judgement=True)
def estimate(ctx, key: str) -> dict:
    """A range of days for an upgrade, with its split: edit (one change), review and test (by the kind of version
    change), rollout (one image or several). The high end is the low end times a spread. `low` is None, with `why`,
    when the entry is gone or has nothing left to change. The constants are at the top of this module."""
    row = ctx.row("posture_fixes", key)
    if row is None:
        return {"low": None, "why": "the entry no longer exists"}
    ct = ctx.call("effort.change_type", key=key)
    change = ct["change"]
    if change is None:
        return {"low": None, "why": ct["why"]}
    several = (row.get("images") or 0) > 1
    return _answer([{"part": "edit", "why": "one change to make", "days": EDIT},
                    {"part": "review", "why": CHANGE_WHY[change], "days": REVIEW[change]},
                    {"part": "test", "why": CHANGE_WHY[change], "days": TEST[change]},
                    {"part": "rollout", "why": "several images to rebuild" if several else "one image or none to rebuild",
                     "days": ROLLOUT_SEVERAL if several else ROLLOUT_ONE}])


@rule("effort.code_fix", 1, judgement=True)
def code_fix(ctx, finding_key: str) -> dict:
    """A range of days to fix one code finding: one file to edit, a test, and a rollout that is larger when the code
    reaches more than one service. `low` is None, with `why`, when the finding is gone."""
    f = ctx.row("posture_findings", finding_key)
    if f is None:
        return {"low": None, "why": "the finding no longer exists"}
    several = (f.get("services") or 0) > 1
    return _answer([{"part": "edit", "why": "one file to edit", "days": CODE_FIX["edit"]},
                    {"part": "review", "why": "a single-file fix, no separate review", "days": 0.0},
                    {"part": "test", "why": "testing a single-file fix", "days": CODE_FIX["test"]},
                    {"part": "rollout", "why": ("several services to roll out to" if several
                                                else "one service or none to roll out to"),
                     "days": ROLLOUT_SEVERAL if several else ROLLOUT_ONE}])
