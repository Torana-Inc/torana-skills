"""Times as a person reads them: Pacific time, never raw UTC. Naive timestamps from the datalake are UTC."""
from __future__ import annotations

from datetime import datetime, timezone
from zoneinfo import ZoneInfo

PT = ZoneInfo("America/Los_Angeles")


def parse(v) -> datetime | None:
    if not v:
        return None
    try:
        d = datetime.fromisoformat(str(v).replace("Z", "+00:00"))
    except ValueError:
        return None
    return d if d.tzinfo else d.replace(tzinfo=timezone.utc)


def pt(v) -> str | None:
    """"7 Oct 1:41 PM PT" for an ISO time, None when there is none."""
    d = parse(v)
    return f"{d.astimezone(PT).strftime('%-d %b %-I:%M %p')} PT" if d else None


def latest(values) -> str | None:
    """The newest of several ISO times, as given."""
    best = None
    for v in values:
        d = parse(v)
        if d and (best is None or d > best[0]):
            best = (d, v)
    return best[1] if best else None
