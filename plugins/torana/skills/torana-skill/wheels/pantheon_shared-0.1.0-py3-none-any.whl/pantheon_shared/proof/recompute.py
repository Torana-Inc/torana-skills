"""Recompute: compare a stored build with a rebuild — live (VERIFY: is it still true?) or captured (REPLAY:
was it computed from what it says?).

Per claim, the outcome is one of:
  unchanged        same text, and every leaf input has the same value
  aged             only the build clock moved (a time-relative claim, e.g. "20.8 h ago")
  inputs_moved     same text, but some input changed underneath (e.g. a selection gained a row)
  changed          the text changed
  evidence_gone    an input row no longer exists
and every changed/moved claim lists its REASONS, one per differing leaf:
  value_changed (cell)  membership_changed (selection)  row_gone (absence)  path_changed (read not made / newly made)
  rule_changed (code hash or version differs)  meaning_changed (platform description)  clock_moved
The clock (`now`) always moves; it is a reason only when the claim's text changed.
"""
from __future__ import annotations

from .core import pointers as P
from .core.engine import closure, rules_in_closure
from .core.render import plain


def _slot_ptrs(claim: dict) -> list[dict]:
    out = []
    for s in (claim.get("spans") or []) + (claim.get("missing") or []):
        p = s.get("p")
        if p:
            out.append(p["stored_as"] if p.get("k") == "llm" and p.get("stored_as") else p)
    return out + [r["p"] for r in claim.get("refs") or []]


def _leaf_map(record: dict, ptrs: list[dict]) -> dict:
    return {P.leaf_id(p): p for p in closure(record, ptrs)}


def _rule_versions(record: dict, ptrs: list[dict]) -> dict:
    out = {}
    for run in rules_in_closure(record, ptrs):
        r = record["runs"][run]
        out[r["rule"]] = (r["version"], r["code_hash"])
    return out


def _short(v) -> str:
    s = P.canon(v)
    return s if len(s) <= 140 else s[:137] + "…"


def compare_claim(old_rec: dict, new_rec: dict, old_c: dict, new_c: dict | None) -> dict:
    if new_c is None:
        return {"outcome": "evidence_gone", "reasons": [{"kind": "claim_not_produced"}]}
    o_ptrs, n_ptrs = _slot_ptrs(old_c), _slot_ptrs(new_c)
    o_leaf, n_leaf = _leaf_map(old_rec, o_ptrs), _leaf_map(new_rec, n_ptrs)
    reasons = []
    gone_rows = {(p["table"], P.key_str(p["key"])) for p in n_leaf.values() if p["k"] == "absent"}
    reported_gone = set()
    for lid in sorted(set(o_leaf) | set(n_leaf)):
        a, b = o_leaf.get(lid), n_leaf.get(lid)
        if lid == "now":
            continue
        row_id = (a or b).get("table"), P.key_str((a or b).get("key")) if (a or b).get("k") in ("cell", "absent") else None
        if a and not b and a["k"] == "cell" and row_id in gone_rows:
            if row_id not in reported_gone:
                reported_gone.add(row_id)
                reasons.append({"kind": "row_gone", "table": a["table"], "key": a["key"]})
            continue
        if b and not a and b["k"] == "absent" and row_id in gone_rows and any(
                o["k"] == "cell" and (o["table"], P.key_str(o["key"])) == row_id for o in o_leaf.values()):
            continue
        if a and b:
            if P.leaf_hash(a) == P.leaf_hash(b):
                continue
            if a["k"] == "sel":
                added, removed = [k for k in b["keys"] if k not in a["keys"]], [k for k in a["keys"] if k not in b["keys"]]
                reasons.append({"kind": "membership_changed", "table": a["table"], "where": a["where"], "added": added[:5], "removed": removed[:5],
                                "then": len(a["keys"]), "now": len(b["keys"])})
            elif b["k"] == "absent" and a["k"] != "absent":
                reasons.append({"kind": "row_gone", "table": a["table"], "key": a["key"]})
            elif a["k"] == "meaning":
                reasons.append({"kind": "meaning_changed", "table": a["table"], "column": a["column"]})
            else:
                reasons.append({"kind": "value_changed", "table": a.get("table"), "key": a.get("key"), "path": a.get("path"),
                                "then": _short(a.get("value")), "now": _short(b.get("value"))})
        else:
            p = a or b
            reasons.append({"kind": "path_changed", "read": "no longer made" if a else "newly made", "table": p.get("table"),
                            "key": p.get("key"), "path": p.get("path"), "where": p.get("where")})
    o_rules, n_rules = _rule_versions(old_rec, o_ptrs), _rule_versions(new_rec, n_ptrs)
    for rid in sorted(set(o_rules) & set(n_rules)):
        if o_rules[rid] != n_rules[rid]:
            reasons.append({"kind": "rule_changed", "rule": rid, "then": o_rules[rid][0], "now": n_rules[rid][0]})
    t_old, t_new = plain(old_c["spans"]), plain(new_c["spans"])
    gone = any(r["kind"] == "row_gone" for r in reasons)
    clock = "now" in o_leaf and "now" in n_leaf and o_leaf["now"]["value"] != n_leaf["now"]["value"]
    if clock and t_old != t_new:
        reasons.append({"kind": "clock_moved", "then": o_leaf["now"]["value"], "now": n_leaf["now"]["value"]})
    if t_old != t_new and clock and len(reasons) == 1:
        outcome = "aged"
    elif t_old != t_new:
        outcome = "evidence_gone" if gone else "changed"
    elif reasons:
        outcome = "inputs_moved"
    else:
        outcome = "unchanged"
    return {"outcome": outcome, "then": t_old, "now": t_new, "reasons": reasons}


def diff(old_rec: dict, new_rec: dict, mode: str) -> dict:
    new_claims = {c["id"]: c for c in (new_rec.get("item") or {}).get("claims") or []}
    claims = {c["id"]: compare_claim(old_rec, new_rec, c, new_claims.get(c["id"]))
              for c in (old_rec.get("item") or {}).get("claims") or []}
    counts: dict = {}
    for r in claims.values():
        counts[r["outcome"]] = counts.get(r["outcome"], 0) + 1
    return {"mode": mode, "alert_id": old_rec["meta"]["alert_id"], "then": old_rec["meta"]["now"], "now": new_rec["meta"]["now"],
            "then_schema": old_rec["meta"].get("schema_version"), "now_schema": new_rec["meta"].get("schema_version"),
            "counts": counts, "claims": claims}


def reproduced(old_rec: dict, new_rec: dict) -> dict:
    """Replay check: identical rendered text AND identical rule outputs, run for run (positional:
    valid only because a record holds exactly one item and replay re-runs the same build order)."""
    d = diff(old_rec, new_rec, "replay")
    same_runs = [r["outputs"] for r in old_rec["runs"].values()] == [r["outputs"] for r in new_rec["runs"].values()]
    ok = same_runs and all(r["outcome"] == "unchanged" for r in d["claims"].values())
    changed = {(r["rule"], r["then"], r["now"]) for c in d["claims"].values() for r in c["reasons"]
               if r["kind"] == "rule_changed"}
    return {"reproduced": ok, "runs_then": len(old_rec["runs"]), "runs_replayed": len(new_rec["runs"]),
            "rule_outputs_identical": same_runs, "claim_outcomes": d["counts"], "error": None,
            "rules_changed": [{"rule": r, "then": t, "now": n} for r, t, n in sorted(changed, key=str)]}
