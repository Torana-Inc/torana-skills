"""images — container images: who built them, what runs them, their history.

Paths used (entity graph): repo -builds_image-> image -deployed_as-> service.
Retired images often lose their graph edges; the platform keeps a build record per image
(explore_images.builder_repo_key), which is the declared fallback.
"""
from ..core.engine import NotCaptured, rule


@rule("images.builder_repo", 1)
def builder_repo(ctx, image: str) -> dict:
    """The repository that built an image: a builds_image edge, else the image's build record."""
    e = ctx.one("entity_edges", [["edge_type", "=", "builds_image"], ["to_key", "=", image], ["is_deleted", "=", False]])
    if e:
        return {"repo": e.get("from_key"), "via": "builds_image edge", "edge": e.key}
    x = ctx.one("explore_images", [["image_key", "=", image]])
    repo = x.get("builder_repo_key") if x else None
    return {"repo": repo, "via": "explore_images.builder_repo_key" if repo else None, "edge": None}


@rule("images.service_of", 2)
def service_of(ctx, image: str) -> dict:
    """Which service an image belongs to, without guessing from names:
    the repo that built it -> every image that repo built -> the ones deployed (deployed_as) -> their services.
    v2: when the alert's own image is deployed, only ITS deployed_as edges count (a monorepo's other images no longer
    supply the service); otherwise the repo's deployed images, in key order. `services` lists every service that
    qualifies and `several` says there is more than one, so the page never presents the first as the only one."""
    b = ctx.call("images.builder_repo", image=image)
    repo = b["repo"]
    if not repo:
        return {"service": None, "repo": None, "running_image": None, "why": "no build record for the image"}
    built = ctx.select("entity_edges", [["edge_type", "=", "builds_image"], ["from_key", "=", repo], ["is_deleted", "=", False]])
    imgs = [e.get("to_key") for e in built]
    deployed = ctx.select("entity_edges", [["edge_type", "=", "deployed_as"], ["from_key", "in", imgs], ["is_deleted", "=", False]]) if imgs else []
    if not deployed:
        return {"service": None, "repo": repo, "running_image": None, "why": "no image of this repo is deployed"}
    deployed = sorted(deployed, key=lambda e: (str(e.get("from_key")), str(e.get("to_key"))))
    own = [e for e in deployed if e.get("from_key") == image]
    pool = own or deployed
    d = pool[0]
    run_img = d.get("from_key")
    services = sorted({e.get("to_key") for e in pool if e.get("from_key") == run_img and e.get("to_key")})
    build_edge = next((e.key for e in built if e.get("to_key") == run_img), None)
    return {"service": d.get("to_key"), "services": services, "several": len(services) > 1, "repo": repo,
            "running_image": run_img, "deployed_edge": d.key, "builds_edge": build_edge, "alert_builds_edge": b["edge"],
            "repo_via": b["via"]}


@rule("images.first_detection", 3)
def first_detection(ctx, repo: str, cve: str) -> dict:
    """Earliest detection of a CVE on ANY image the repo built (retired images included).

    Retired images are included on purpose: their builds_image edge is soft-deleted when the image is retired, and
    the first detection is history that retirement does not erase. v2 does not hide them, it SAYS how many there are:
    `retired_images` = images carrying the CVE whose edge is deleted, so a reader never takes a dead edge for a live
    one. v3: the same outputs live; a record captured under v1 (no `is_deleted` read) replays with
    `retired_images: None` instead of raising NotCaptured (`_live_targets`)."""
    built = ctx.select("entity_edges", [["edge_type", "=", "builds_image"], ["from_key", "=", repo]])
    imgs = [e.get("to_key") for e in built]
    live = _live_targets(built)
    vulns = ctx.select("vulnerabilities", [["cve_id", "=", cve], ["torana_artifact_id", "in", imgs]]) if imgs else []
    dated = sorted(((v.get("scan_first_detected_date") or "9999"), v.key, v) for v in vulns)
    if not dated:
        return {"first_detected": None, "first_image": None, "images_with_cve": 0, "retired_images": 0}
    at, _, v = dated[0]
    out = {"first_detected": at, "first_image": v.get("torana_artifact_id"), "images_with_cve": len(dated)}
    if live is None:                       # a v1 record: it read neither is_deleted nor every row's artifact id
        return {**out, "retired_images": None}
    carrying = {x.get("torana_artifact_id") for _, _, x in dated}
    return {**out, "retired_images": len(carrying - live)}


def _live_targets(built) -> set | None:
    """The to_keys of the edges that are not soft-deleted; None when replaying a record captured before v2 read
    `is_deleted` (v1 read only `to_key`). Path guard: such a record replays with v1's outputs plus
    `retired_images: None` (unknown, never 0) and reports `rule_changed`, instead of raising NotCaptured. The
    caller then skips v2's other new read (every carrying row's artifact id) on the same path."""
    try:
        return {e.get("to_key") for e in built if not e.get("is_deleted")}
    except NotCaptured:
        return None
