"""images — container images: who built them, what runs them, their history, what is inside them.

Paths used (entity graph): repo -builds_image-> image -deployed_as-> service.
Retired images often lose their graph edges; the platform keeps a build record per image
(explore_images.builder_repo_key), which is the declared fallback.
Inside an image (B7 row B): image_components (package, path, layer) and image_layers (build history, each step
matched to its layer).
"""
import json

from ..core.engine import NotCaptured, rule


@rule("images.builder_repo", 2)
def builder_repo(ctx, image: str) -> dict:
    """The repository that built an image: a builds_image edge, else the image's build record.
    v2 (I-133): EVERY live builds_image edge to the image is read (v1 took the first row, so an image two repositories
    are recorded as building was credited to whichever sorted first). One repository: as v1, plus `repos`, `several`
    False and `edges`. Several: `repo` is None, `repos` lists them, `several` is True, and nothing downstream may treat
    one of them as the builder. An edge with no from_key names no builder. Builders are the repositories whose edges
    carry a build record, or every name match when none does (`_candidates`, the same set data-transformers counts).
    With no live edge, the build record (explore_images.builder_repo_key) is MIN(from_key) over every edge, deleted ones
    included, so the image's edges are read with deleted ones too: several repositories there are several builders.
    Path guards: a v1 record read only the first row's from_key (and no deleted edges); it replays with v1's
    `repo` / `via` / `edge` and `several` / `repos` / `edges` None (unknown, never False)."""
    es = ctx.select("entity_edges", [["edge_type", "=", "builds_image"], ["to_key", "=", image], ["is_deleted", "=", False]])
    if es:
        try:
            named = [(e.get("from_key"), e) for e in es]
        except NotCaptured:                 # a v1 record: only rows[0].from_key was read
            return {"repo": es[0].get("from_key"), "repos": None, "several": None, "via": "builds_image edge",
                    "edge": es[0].key, "edges": None}
        return _builders(_candidates(named), "builds_image edge", "builds_image edges")
    try:
        every = ctx.select("entity_edges", [["edge_type", "=", "builds_image"], ["to_key", "=", image]])
        retired = _candidates([(e.get("from_key"), e) for e in every])
    except NotCaptured:                     # a v1 record never read the deleted edges
        retired = None
    if retired is not None and len({r for r, _ in retired if r}) > 1:
        out = _builders(retired, None, "builds_image edges, all deleted")
        return {**out, "edge": None}
    x = ctx.one("explore_images", [["image_key", "=", image]])
    repo = x.get("builder_repo_key") if x else None
    known = retired is not None
    return {"repo": repo, "repos": ([repo] if repo else []) if known else None, "several": False if known else None,
            "via": "explore_images.builder_repo_key" if repo else None, "edge": None, "edges": [] if known else None}


def _is_build_record(e) -> bool:
    """Whether a builds_image edge carries a BUILD RECORD rather than a name match. The SAME test as data-transformers'
    posture_runtime_context.build_edge (lineage_source = 'build_record'): high confidence, and evidence (the source
    system's own entry, else the evidence without the reconciler's keys) that is not empty and is not a name match."""
    if e.get("confidence") != "high":
        return False
    ev = e.get("evidence")
    if isinstance(ev, str):
        try:
            ev = json.loads(ev)
        except ValueError:
            return False
    if not isinstance(ev, dict):
        return False
    src = e.get("source_system")
    sub = ev[src] if src is not None and src in ev else {k: v for k, v in ev.items() if k not in ("reconciler", "token")}
    return sub != {} and "repo_image_name_match" not in json.dumps(sub)


def _candidates(named: list) -> list:
    """I-133 (lead decision, one definition): the builders are every repository an edge WITH A BUILD RECORD names; only
    when no edge carries one do the name matches count. data-transformers' posture_runtime_context.build_candidate is
    the same set (contract test in data-transformers: tests/test_builder_definition_contract_i133.py). Path guard: a
    record that never read the edges' evidence counts every edge, as v2 first did."""
    named = [(r, e) for r, e in named if r]
    try:
        recorded = {r for r, e in named if _is_build_record(e)}
    except NotCaptured:
        return named
    return [(r, e) for r, e in named if r in recorded] if recorded else named


def _builders(named: list, one_via, several_via) -> dict:
    """builder_repo's outputs from (from_key, edge) pairs: edges with no from_key dropped, then one repository or several."""
    named = sorted(((r, e) for r, e in named if r), key=lambda re_: (str(re_[0]), str(re_[1].key)))
    repos = sorted({r for r, _ in named})
    edges = [e.key for _, e in named]
    if len(repos) > 1:
        return {"repo": None, "repos": repos, "several": True, "via": several_via, "edge": None, "edges": edges}
    if not named:
        return {"repo": None, "repos": [], "several": False, "via": None, "edge": None, "edges": []}
    return {"repo": repos[0], "repos": repos, "several": False, "via": one_via, "edge": named[0][1].key, "edges": edges}


@rule("images.service_of", 3)
def service_of(ctx, image: str) -> dict:
    """Which service an image belongs to, without guessing from names:
    the repo that built it -> every image that repo built -> the ones deployed (deployed_as) -> their services.
    v2: when the alert's own image is deployed, only ITS deployed_as edges count (a monorepo's other images no longer
    supply the service); otherwise the repo's deployed images, in key order. `services` lists every service that
    qualifies and `several` says there is more than one, so the page never presents the first as the only one.
    v3 (I-133): when several repositories are recorded as building the image (`images.builder_repo` v2), no builder is
    picked: `repo` is None and `repos` lists them. The image's OWN deployed_as edges still name its services (they do
    not depend on who built it); a service reached only through one builder's other images is never named."""
    b = ctx.call("images.builder_repo", image=image)
    repo = b["repo"]
    if b["several"]:
        return _service_of_several_builders(ctx, image, b)
    if not repo:
        return {"service": None, "repo": None, "running_image": None, "why": "no build record for the image"}
    built = ctx.select("entity_edges", [["edge_type", "=", "builds_image"], ["from_key", "=", repo], ["is_deleted", "=", False]])
    imgs = [e.get("to_key") for e in built]
    deployed = ctx.select("entity_edges", [["edge_type", "=", "deployed_as"], ["from_key", "in", imgs], ["is_deleted", "=", False]]) if imgs else []
    if not deployed:
        return {"service": None, "repo": repo, "running_image": None, "why": "no image of this repo is deployed"}
    deployed = sorted(deployed, key=lambda e: (str(e.get("from_key")), str(e.get("to_key"))))
    own = [e for e in deployed if e.get("from_key") == image]
    pool = own or deployed
    d = pool[0]
    run_img = d.get("from_key")
    services = sorted({e.get("to_key") for e in pool if e.get("from_key") == run_img and e.get("to_key")})
    build_edge = next((e.key for e in built if e.get("to_key") == run_img), None)
    return {"service": d.get("to_key"), "services": services, "several": len(services) > 1, "repo": repo,
            "running_image": run_img, "deployed_edge": d.key, "builds_edge": build_edge, "alert_builds_edge": b["edge"],
            "repo_via": b["via"]}


def _service_of_several_builders(ctx, image: str, b) -> dict:
    """service_of when several repositories built the image: only the image's own deployed_as edges may name a service.
    Path guard: that read is new in v3; a record that never made it replays with service, services and running_image None
    ("not recorded"), never as "not deployed"."""
    repos = b["repos"]
    why = (f"{len(repos)} repositories are recorded as building the image ({', '.join(repos)}); "
           "Torana does not pick one")
    try:
        own = ctx.select("entity_edges", [["edge_type", "=", "deployed_as"], ["from_key", "=", image], ["is_deleted", "=", False]])
        own_to = [(e.get("to_key"), e) for e in own]
    except NotCaptured:
        # Not "not deployed": the record never read it. Unknown, so no service and no running image is claimed.
        return {"repo": None, "repos": repos, "several_builders": True, "builds_edge": None, "alert_builds_edge": None,
                "repo_via": b["via"], "service": None, "services": None, "several": None, "running_image": None,
                "why": why + "; whether the image itself is deployed is not recorded"}
    own = [e for _, e in sorted(((t, e) for t, e in own_to if t), key=lambda te: str(te[0]))]
    services = sorted({t for t, _ in own_to if t})
    base = {"repo": None, "repos": repos, "several_builders": True, "builds_edge": None, "alert_builds_edge": None,
            "repo_via": b["via"], "why": why}
    if not own:
        return {**base, "service": None, "services": [], "several": False, "running_image": None,
                "why": why + "; the image itself is not deployed, and a service reached through one builder's other "
                             "images is not named"}
    return {**base, "service": own[0].get("to_key"), "services": services, "several": len(services) > 1,
            "running_image": image, "deployed_edge": own[0].key}


@rule("images.detections_on_image", 1)
def detections_on_image(ctx, image: str, cve: str) -> dict:
    """images.first_detection's outputs over ONE image, the alert's own (I-133). Used when several repositories are recorded
    as building it: the history of "the repository's images" would need one builder picked, so only what this image
    proves is counted (withdrawn rows included, as first_detection counts them)."""
    try:
        rows = ctx.select("vulnerabilities", [["cve_id", "=", cve], ["torana_artifact_id", "=", image]])
        dated = sorted((str(v.get("scan_first_detected_date")), v.key) for v in rows if v.get("scan_first_detected_date"))
    except NotCaptured:
        # Path guard: a record built before this rule existed never read these rows. Not recorded, never "none".
        return {"first_detected": None, "first_image": None, "images_with_cve": None, "retired_images": None,
                "undated_rows": None, "not_recorded": True}
    return {"first_detected": dated[0][0] if dated else None, "first_image": image if dated else None,
            "images_with_cve": 1 if rows else 0, "retired_images": 0, "undated_rows": len(rows) - len(dated)}


@rule("images.first_detection", 4)
def first_detection(ctx, repo: str, cve: str) -> dict:
    """Earliest detection of a CVE on ANY image the repo built (retired images included).

    Retired images are included on purpose: their builds_image edge is soft-deleted when the image is retired, and
    the first detection is history that retirement does not erase. v2 does not hide them, it SAYS how many there are:
    `retired_images` = images carrying the CVE whose edge is deleted, so a reader never takes a dead edge for a live
    one. v3: the same outputs live; a record captured under v1 (no `is_deleted` read) replays with
    `retired_images: None` instead of raising NotCaptured (`_live_targets`).
    v4: never a sentinel. A row with no `scan_first_detected_date` is counted but cannot be the first detection;
    when no row carries a date, `first_detected` and `first_image` are None and `undated_rows` says how many
    rows lacked one (v3 sorted an undated row as "9999" and returned that string as a date). Same reads as v3,
    so a v3 record replays with `rule_changed` only."""
    built = ctx.select("entity_edges", [["edge_type", "=", "builds_image"], ["from_key", "=", repo]])
    imgs = [e.get("to_key") for e in built]
    live = _live_targets(built)
    vulns = ctx.select("vulnerabilities", [["cve_id", "=", cve], ["torana_artifact_id", "in", imgs]]) if imgs else []
    rows = [(v.get("scan_first_detected_date"), v.key, v) for v in vulns]
    if not rows:
        return {"first_detected": None, "first_image": None, "images_with_cve": 0, "retired_images": 0,
                "undated_rows": 0}
    dated = sorted((str(at), k, v) for at, k, v in rows if at)
    first = dated[0] if dated else None
    out = {"first_detected": first[0] if first else None,
           "first_image": first[2].get("torana_artifact_id") if first else None,
           "images_with_cve": len(rows), "undated_rows": len(rows) - len(dated)}
    if live is None:                       # a v1 record: it read neither is_deleted nor every row's artifact id
        return {**out, "retired_images": None}
    carrying = {x.get("torana_artifact_id") for _, _, x in rows}
    return {**out, "retired_images": len(carrying - live)}


@rule("images.package_layer", 2)
def package_layer(ctx, image: str, package_id: str) -> dict:
    """Where a package sits inside an image and which build step put it there, from the image's own evidence
    (B7 row B): the `image_components` rows for (image, package) and the `image_layers` row whose diff_id is the
    component's layer. Observed rows only: no base image is inferred here.
    Keyed on `torana_package_id`, the column a vulnerability row carries (v1 keyed on a purl, which
    `vulnerabilities` does not have, so the claim never reached it).
    Several sources may describe the same package (Container Analysis gives the path and no layer; an SBOM gives
    both). The component WITH a layer is preferred, then the lowest path, so the answer does not depend on read
    order. When one layer's diff_id appears at several history entries, the earliest entry made it.
    `paths` counts the distinct paths the package was found at in this image."""
    comps = ctx.select("image_components", [["torana_artifact_id", "=", image], ["torana_package_id", "=", package_id],
                                            ["is_deleted", "=", False]])
    if not comps:
        return {"found": False, "file": None, "layer_diff": None, "layer_index": None, "history_index": None,
                "build_step": None, "source": None, "paths": 0, "component": None, "step_row": None}
    comps = sorted(comps, key=lambda c: (not c.get("layer_diff_id"), str(c.get("file_path") or ""),
                                         str(c.get("source_system") or "")))
    c = comps[0]
    diff = c.get("layer_diff_id")
    steps = (ctx.select("image_layers", [["torana_artifact_id", "=", image], ["diff_id", "=", diff],
                                         ["is_deleted", "=", False]]) if diff else [])
    steps = sorted(steps, key=lambda r: (r.get("history_index") is None, r.get("history_index") or 0, r.key))
    step = steps[0] if steps else None
    return {"found": True, "file": c.get("file_path") or None, "layer_diff": (diff or "")[7:19] or None,
            "layer_index": step.get("layer_index") if step else None,
            "history_index": step.get("history_index") if step else None,
            "build_step": step.get("created_by") if step else None,
            "source": c.get("source_system"),
            "paths": len({str(x.get("file_path") or "") for x in comps}),
            "component": c.key, "step_row": step.key if step else None}


def _live_targets(built) -> set | None:
    """The to_keys of the edges that are not soft-deleted; None when replaying a record captured before v2 read
    `is_deleted` (v1 read only `to_key`). Path guard: such a record replays with v1's outputs plus
    `retired_images: None` (unknown, never 0) and reports `rule_changed`, instead of raising NotCaptured. The
    caller then skips v2's other new read (every carrying row's artifact id) on the same path."""
    try:
        return {e.get("to_key") for e in built if not e.get("is_deleted")}
    except NotCaptured:
        return None
