"""Sources: where reads go. The framework never talks to a database or an API except through one.

  Source            protocol: sql(text) -> rows · api(path, params) -> json
  RecordingSource   wraps any Source: logs every call (the build's query log) and de-duplicates
                    identical calls within one build, so a proof names the exact query behind it.

The platform's Source is pantheon-datalake's in-process reader (torana_datalake/proof/reader.py), which runs
the datalake's read-only and tenant guards on every statement; nothing above this layer changes.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Protocol


class Source(Protocol):
    def sql(self, text: str) -> list[dict]: ...
    def api(self, path: str, params: dict | None = None) -> Any: ...


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


class RecordingSource:
    def __init__(self, inner: Source):
        self.inner = inner
        self.log: list[dict] = []
        self._cache: dict[str, tuple[str, Any]] = {}

    def _call(self, kind: str, text: str, fn):
        ck = f"{kind}|{text}"
        if ck in self._cache:
            return self._cache[ck]
        result = fn()
        qid = f"Q{len(self.log) + 1:04d}"
        rows = len(result) if isinstance(result, list) else (len(result.get("items", [])) if isinstance(result, dict) and "items" in result else 1)
        self.log.append({"q": qid, "kind": kind, "text": text, "executed_at": utcnow(), "rows": rows})
        self._cache[ck] = (qid, result)
        return qid, result

    def sql(self, text: str) -> tuple[str, list[dict]]:
        return self._call("sql", text, lambda: self.inner.sql(text))

    def api(self, path: str, params: dict | None = None) -> tuple[str, Any]:
        text = path + ("?" + "&".join(f"{k}={v}" for k, v in sorted(params.items())) if params else "")
        return self._call("api", text, lambda: self.inner.api(path, params))
