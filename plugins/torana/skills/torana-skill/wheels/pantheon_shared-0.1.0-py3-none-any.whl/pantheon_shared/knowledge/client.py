"""KnowledgeClient: how a service talks to Atlas (KNOWLEDGE_API.md § 3.4.2).

Built on `PantheonClient` (east-west, direct via KNOWLEDGE_SERVICE_URL, never nginx). Holds no DB session and neither may
the caller (defect B). A caller that needs context for an answer proceeds WITHOUT it when this raises `KnowledgeUnavailable`
and says "Atlas context unavailable" in its own output (ASSEMBLY D4.8)."""
from __future__ import annotations

import asyncio
import time
from typing import Any, Callable, TypeVar

import httpx
from pydantic import BaseModel, ValidationError

from pantheon_shared.http.client import PantheonClient
from pantheon_shared.knowledge.contract import (
    Answer,
    CallerFact,
    ErrorBody,
    FactsView,
    InferenceOptions,
    InternalAnswerRequest,
    InternalContextRequest,
    KeyIn,
    KnowledgeContext,
    MapView,
    SkillView,
)
from pantheon_shared.pantheon_services import PantheonService

API = "/api/v1/internal/atlas"
UNAVAILABLE_STATUSES = frozenset({502, 503, 504})
DEFAULT_TIMEOUT_S = 3.0          # context and the pulls (ASSEMBLY D4.8)
ASK_TIMEOUT_S = 10.0             # an ask only accepts; the session runs after the 202

M = TypeVar("M", bound=BaseModel)


class KnowledgeError(Exception):
    def __init__(self, status: int, body: ErrorBody):
        super().__init__(f"{body.error}: {body.message} (HTTP {status})")
        self.status = status
        self.body = body

    @property
    def code(self) -> str:
        return self.body.error

    @property
    def retryable(self) -> bool:
        return self.body.retryable

    @property
    def request_id(self) -> str | None:
        return self.body.request_id

    @property
    def trace_id(self) -> str | None:
        return self.body.trace_id


class KnowledgeUnavailable(KnowledgeError):
    """Atlas did not answer (connect error, timeout, 502/503/504). retryable=True. ASSEMBLY D4.8: callers that need
    context for an answer proceed WITHOUT it and say "Atlas context unavailable" in their own output."""


def _unavailable(message: str, status: int = 503) -> KnowledgeUnavailable:
    return KnowledgeUnavailable(status, ErrorBody(error="unavailable", message=message, retryable=True))


def _error_body(resp: httpx.Response) -> ErrorBody:
    """The one error shape: {"detail": {schema, error, message, retryable, ...}} (§ 3.4.4.1). Anything else (a proxy's
    HTML 502, FastAPI's own 422 list) is wrapped so callers always get an ErrorBody."""
    try:
        detail = resp.json().get("detail")
        if isinstance(detail, dict) and "error" in detail:
            return ErrorBody.model_validate(detail)
    except (ValueError, AttributeError, ValidationError):
        pass
    return ErrorBody(error="bad_response" if resp.status_code < 500 else "unavailable",
                     message=f"Atlas answered HTTP {resp.status_code} without the atlas/error.v1 shape",
                     retryable=resp.status_code in UNAVAILABLE_STATUSES)


def _keys(keys: list[KeyIn | str]) -> list[KeyIn]:
    return [k if isinstance(k, KeyIn) else KeyIn(key=k) for k in keys]


def _wire(model: BaseModel) -> dict:
    return model.model_dump(by_alias=True, exclude_none=True, mode="json")


class KnowledgeClient:
    def __init__(self, service_name: str, tenant_id: str, *, timeout_s: float = DEFAULT_TIMEOUT_S,
                 client: PantheonClient | None = None):
        self.service_name = service_name
        self.tenant_id = tenant_id
        self.timeout_s = timeout_s
        self._client = client or PantheonClient.for_service(
            service_name=service_name, target_service=PantheonService.KNOWLEDGE, tenant_id=tenant_id)

    # ── transport ──────────────────────────────────────────────────────────────────────────────

    async def _send(self, method: str, path: str, *, timeout_s: float, **kwargs: Any) -> httpx.Response:
        try:
            resp = await self._client.request(method, f"{API}{path}", timeout=timeout_s, **kwargs)
        except httpx.HTTPError as exc:                      # connect error, timeout, protocol error
            raise _unavailable(f"Atlas did not answer: {type(exc).__name__}") from exc
        if resp.status_code >= 400:
            body = _error_body(resp)
            cls = KnowledgeUnavailable if resp.status_code in UNAVAILABLE_STATUSES else KnowledgeError
            raise cls(resp.status_code, body)
        return resp

    async def _call(self, method: str, path: str, model: type[M], *, timeout_s: float, **kwargs: Any) -> M:
        resp = await self._send(method, path, timeout_s=timeout_s, **kwargs)
        try:
            return model.model_validate(resp.json())
        except (ValueError, ValidationError) as exc:
            raise KnowledgeError(resp.status_code, ErrorBody(
                error="bad_response", message=f"Atlas sent a body that is not {model.__name__}", retryable=False)) from exc

    def _tenant(self, **params: Any) -> dict:
        out = {"tenant": self.tenant_id}
        out.update({k: v for k, v in params.items() if v is not None})
        return out

    # ── Model 1: get knowledge, the caller infers ──────────────────────────────────────────────

    async def context(self, keys: list[KeyIn | str], *, question: str | None = None, delivery: str = "push",
                      caller_ref: str | None = None, idempotency_key: str | None = None, **options: Any) -> KnowledgeContext:
        req = InternalContextRequest(keys=_keys(keys), question=question, delivery=delivery, caller_ref=caller_ref,
                                     idempotency_key=idempotency_key, tenant_id=self.tenant_id, **options)
        return await self._call("POST", "/context", KnowledgeContext, timeout_s=self.timeout_s, json=_wire(req))

    # ── Model 2: ask, Atlas infers ─────────────────────────────────────────────────────────────

    async def ask(self, keys: list[KeyIn | str], question: str, *, context: list[CallerFact] | None = None,
                  caller_ref: str | None = None, idempotency_key: str | None = None,
                  inference: InferenceOptions | None = None, **options: Any) -> Answer:
        """Accepts the ask; the returned Answer has status "running" (use `wait`)."""
        req = InternalAnswerRequest(keys=_keys(keys), question=question, context=context or [], caller_ref=caller_ref,
                                    idempotency_key=idempotency_key, inference=inference, tenant_id=self.tenant_id, **options)
        return await self._call("POST", "/answers", Answer, timeout_s=ASK_TIMEOUT_S, json=_wire(req))

    async def answer(self, request_id: str) -> Answer:
        return await self._call("GET", f"/answers/{request_id}", Answer, timeout_s=ASK_TIMEOUT_S, params=self._tenant())

    async def wait(self, request_id: str, *, timeout_s: float, poll_s: float = 5.0) -> Answer:
        """Poll until the answer leaves "running" or `timeout_s` passes; on timeout the last (still running) Answer is
        returned, so the caller decides. No DB session is held between polls."""
        deadline = time.monotonic() + timeout_s
        while True:
            ans = await self.answer(request_id)
            if ans.status != "running" or time.monotonic() >= deadline:
                return ans
            await asyncio.sleep(max(0.0, min(poll_s, deadline - time.monotonic())))

    async def cancel(self, request_id: str) -> Answer:
        return await self._call("POST", f"/answers/{request_id}/cancel", Answer, timeout_s=ASK_TIMEOUT_S,
                                params=self._tenant())

    # ── pull: narrow, one thing each ───────────────────────────────────────────────────────────

    async def skill(self, name: str, *, file: str = "SKILL.md", terms: list[str] | None = None,
                    request_id: str | None = None) -> SkillView:
        return await self._call("GET", f"/skills/{name}", SkillView, timeout_s=self.timeout_s,
                                params=self._tenant(file=file, term=terms or None, request_id=request_id))

    async def facts(self, key: str, *, terms: list[str] | None = None, file: str | None = None,
                    request_id: str | None = None) -> FactsView:
        return await self._call("GET", "/facts", FactsView, timeout_s=self.timeout_s,
                                params=self._tenant(key=key, term=terms or None, file=file, request_id=request_id))

    async def map(self, name: str, *, key: str, limit: int = 50, request_id: str | None = None) -> MapView:
        return await self._call("GET", f"/maps/{name}", MapView, timeout_s=self.timeout_s,
                                params=self._tenant(key=key, limit=limit, request_id=request_id))

    async def bundle(self, request_id: str, *, kind: str = "context") -> bytes:
        """The tar of a context (`kind="context"`) or an answer (`kind="answers"`) request, rebuilt at the same versions."""
        if kind not in ("context", "answers"):
            raise ValueError("kind must be 'context' or 'answers'")
        resp = await self._send("GET", f"/{kind}/{request_id}/bundle", timeout_s=ASK_TIMEOUT_S, params=self._tenant())
        return resp.content

    def tool_functions(self, request_id: str) -> list[Callable]:
        """K-1: three async functions for an ADK/Gemini agent, bound to one context request. A tool that finds Atlas
        unavailable returns the string "Atlas unavailable", never an exception into the agent's loop."""

        async def open_skill(name: str, file: str = "SKILL.md", term: str | None = None) -> str:
            """Open one Atlas skill (or one file of it) that the context listed under pull.skills. `name` is the skill name,
            `file` defaults to SKILL.md; `term` is "field:value" and cuts a fact file to the records that match."""
            try:
                view = await self.skill(name, file=file, terms=[term] if term else None, request_id=request_id)
            except KnowledgeUnavailable:
                return "Atlas unavailable"
            except KnowledgeError as exc:
                return f"Atlas error: {exc.code}: {exc.body.message}"
            return view.text if view.text is not None else f"{file} has no text form; its size is listed under files"

        async def find_fact(key: str, term: str, file: str | None = None) -> str:
            """Find the records of an entity's facts that match a term. `key` is an entity key such as "repo:github.com/acme/api",
            `term` is "field:value" or a bare value such as a package name; `file` limits it to one fact file."""
            try:
                view = await self.facts(key, terms=[term], file=file, request_id=request_id)
            except KnowledgeUnavailable:
                return "Atlas unavailable"
            except KnowledgeError as exc:
                return f"Atlas error: {exc.code}: {exc.body.message}"
            return view.model_dump_json(by_alias=True, exclude={"slices": {"__all__": {"skill"}}})

        async def expand_map(map: str, key: str) -> str:
            """List the rows of a read-time map (for example "dependencies") that mention an entity key."""
            try:
                view = await self.map(map, key=key, request_id=request_id)
            except KnowledgeUnavailable:
                return "Atlas unavailable"
            except KnowledgeError as exc:
                return f"Atlas error: {exc.code}: {exc.body.message}"
            return view.model_dump_json(by_alias=True, include={"map", "columns", "rows", "total"})

        return [open_skill, find_fact, expand_map]

    async def close(self) -> None:
        await self._client.close()
