"""The knowledge-consent read model (SELECTION_ON_SYNC.md § 4.1, § 4.7; design § 3.18.5).

ONE definition for both sides: pantheon-integration produces `GET /internal/integrations/knowledge-consent?tenant=` and Atlas
reads it. Atlas keeps no copy of consent (one computation); the state is the latest row per (source_id, scope)."""
from __future__ import annotations

import re
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

INTEGRATION_PREFIX = "integration:"
PUSH_PREFIX = "push:"
UNTRACEABLE = "untraceable"

_UUID_RE = re.compile(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")
_PUSH_TYPE_RE = re.compile(r"^[a-z][a-z0-9_]{0,62}$")

ConsentScope = Literal["model_processing", "read_contents"]


class ConsentScopes(BaseModel):
    """`read_contents` is meaningless for pushed data (Torana already holds it): a push type offers `model_processing` only."""
    model_config = ConfigDict(extra="ignore")
    model_processing: bool = False
    read_contents: bool = False


class ConsentSource(BaseModel):
    """One consent record: `source_id` is an integration UUID or `push:<type>` (column `source_id varchar(64)`)."""
    model_config = ConfigDict(extra="ignore", protected_namespaces=())
    source_id: str = Field(min_length=1, max_length=64)
    scopes: ConsentScopes
    consent_text_version: str
    as_of: str                                   # the source's newest row across scopes
    #: {scope: ISO time of that scope's latest row}; only the scopes that HAVE a row. None = an older producer that does
    #: not send it (readers fall back to `as_of`, which is never earlier). Atlas times the consent purge by
    #: `scope_as_of["model_processing"]` (OI-169, pantheon-knowledge SECURITY.md § D8.4.1).
    scope_as_of: dict[ConsentScope, str] | None = None


class KnowledgeConsent(BaseModel):
    """`GET /internal/integrations/knowledge-consent?tenant=` → every source of the tenant, in one call."""
    model_config = ConfigDict(extra="ignore")
    sources: list[ConsentSource] = []

    def by_source(self) -> dict[str, ConsentSource]:
        return {s.source_id: s for s in self.sources}

    def granted(self, source_id: str, scope: ConsentScope) -> bool:
        """Fail closed: a source with no record, or a ref that is not a consent source, is NOT granted."""
        rec = self.by_source().get(source_id)
        return bool(rec and getattr(rec.scopes, scope))


# ── SourceRef: `integration:<uuid>` | `push:<type>` | `untraceable` ────────────────────────────────

def integration_ref(integration_id: str) -> str:
    if not _UUID_RE.match(str(integration_id)):
        raise ValueError(f"not an integration uuid: {integration_id!r}")
    return f"{INTEGRATION_PREFIX}{str(integration_id).lower()}"


def push_ref(push_type: str) -> str:
    if not _PUSH_TYPE_RE.match(push_type):
        raise ValueError(f"not a push type: {push_type!r}")
    return f"{PUSH_PREFIX}{push_type}"


def is_valid_source_ref(ref: str) -> bool:
    if ref == UNTRACEABLE:
        return True
    if ref.startswith(INTEGRATION_PREFIX):
        return bool(_UUID_RE.match(ref[len(INTEGRATION_PREFIX):]))
    if ref.startswith(PUSH_PREFIX):
        return bool(_PUSH_TYPE_RE.match(ref[len(PUSH_PREFIX):]))
    return False


def consent_source_id(ref: str) -> str | None:
    """The `source_id` to look a SourceRef up under: the uuid for an integration, `push:<type>` for pushed data, None for
    `untraceable` (always withheld, no consent record can exist)."""
    if not is_valid_source_ref(ref) or ref == UNTRACEABLE:
        return None
    return ref[len(INTEGRATION_PREFIX):] if ref.startswith(INTEGRATION_PREFIX) else ref


def source_granted(consent: KnowledgeConsent, ref: str, scope: ConsentScope = "model_processing") -> bool:
    """Is `ref` granted `scope`? Fail closed on `untraceable`, a malformed ref and an unknown source."""
    source_id = consent_source_id(ref)
    return source_id is not None and consent.granted(source_id, scope)


def all_granted(consent: KnowledgeConsent, refs: list[str], scope: ConsentScope = "model_processing") -> bool:
    """A mixed row is withheld unless EVERY contributor is granted (design § 3.18.6). No contributors = not granted."""
    return bool(refs) and all(source_granted(consent, r, scope) for r in refs)
