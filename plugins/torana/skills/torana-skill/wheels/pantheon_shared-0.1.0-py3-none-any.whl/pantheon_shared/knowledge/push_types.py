"""The PUSH-TYPE registry: data a tenant PUSHES to Torana (SARIF, asset inventories, manifests…) gets one knowledge consent
per push type, off by default (SELECTION_ON_SYNC § 4.7; design § 3.18.13).

ONE definition for both sides (OI-176): pantheon-integration serves the consent routes and its coverage test from it, and
Atlas's `source_ref()` maps a datalake `contributing_sources` entry to `push:<type>` with it. Pure data + pure functions.

Classification of a contributor (§ 4.7: "checks `data_source` first, then the prefix"):
  1. the mapping's `provider` (the pipeline `source`: asset, sarif, trivy…) and `data_source`, when the
     entry names them. Measured on localhost 2026-10-16: SARIF rows carry provider `sarif` while their
     key prefix is the ENGINE (`semgrep:push`, `trivy-fs:push`, `claude_review:push`), so the prefix
     alone cannot identify them.
  2. else the key prefix (the part before `:push`), EXACT match — `torana-entity-graph-reconciler` is
     NOT `torana-entity-graph`.
  3. else None → the fact is `untraceable` and withheld (never guessed).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Tuple

MODEL_PROCESSING = "model_processing"
PUSH_SOURCE_PREFIX = "push:"

@dataclass(frozen=True)
class PushType:
    type: str
    label: str
    text: str
    #: Ingest route paths (relative to `/api/v1/ingest`) that feed this type. A route may feed several.
    routes: Tuple[str, ...]
    #: Mapping `provider` values (the pipeline `source`, or a bookkeeping label the route stamps).
    providers: Tuple[str, ...] = ()
    #: When non-empty, a provider match also requires the mapping's data_source to be one of these.
    data_sources: Tuple[str, ...] = ()
    #: `<prefix>:push` contributor-key prefixes (exact match on the part before `:push`).
    key_prefixes: Tuple[str, ...] = ()
    scopes: Tuple[str, ...] = (MODEL_PROCESSING,)


PUSH_TYPES: Tuple[PushType, ...] = (
    PushType(
        "sarif", "Scan results (SARIF)",
        "Findings and packages from security scans you push, from any scanning engine.",
        routes=("/sarif",), providers=("sarif",)),
    PushType(
        "asset_inventory", "Asset inventories",
        "Repository identity you declare with an asset-inventory document.",
        routes=("/assets",), providers=("asset",), data_sources=("repositories",),
        key_prefixes=("asset_inventory",)),
    PushType(
        "governance", "Governance records",
        "Criticality, owner and data classification you declare for services and datastores.",
        routes=("/assets",), providers=("asset",), data_sources=("assets", "datastores"),
        key_prefixes=("governance",)),
    PushType(
        "trivy", "Container scan results (Trivy)",
        "Images, packages and vulnerabilities from Trivy reports you push.",
        routes=("/trivy",), providers=("trivy",)),
    PushType(
        # POST /ingest/image-evidence (PI 94b3f71): its own type, off by default (Bhakta 2026-11-02). Every row it writes
        # names provider `image_evidence` (PI _run_pipeline, T-21), so the provider alone classifies it.
        "image_evidence", "Container image evidence (SBOM / Trivy)",
        "What your container images contain and how they were built: SBOMs (CycloneDX) or Trivy reports you push, "
        "with the image config and build provenance.",
        routes=("/image-evidence",), providers=("image_evidence",)),
    PushType(
        "entity_graph", "Declared deployments and entity-graph edges",
        "Deployment manifests and entity-graph edges you push (for example from "
        "`torana entity-graph parse-manifests`).",
        routes=("/entity-edges", "/entity-edge-candidates", "/manifests"),
        providers=("entity_edges", "entity_edge", "entity_edge_candidates", "entity_edge_candidate",
                   "manifests"),
        key_prefixes=("entity_graph", "torana-entity-graph")),
    PushType(
        "build_provenance", "CI build records",
        "Records your CI pushes about which repository built which artifact.",
        routes=("/build-provenance",), providers=("build_provenance",), key_prefixes=("ci_build",)),
    PushType(
        "finding_updates", "Vulnerability updates and issue links",
        "Status updates and ticket links pushed for vulnerabilities.",
        routes=("/vulnerabilities/{torana_vulnerability_id}", "/vulnerabilities",
                "/vulnerability-issue-links"),
        providers=("vulnerability_update", "vulnerability_issue_links"),
        key_prefixes=("vulnerability_update", "vulnerability_issue_links")),
)

_BY_TYPE: Dict[str, PushType] = {p.type: p for p in PUSH_TYPES}


def push_type(type_id: str) -> Optional[PushType]:
    return _BY_TYPE.get(str(type_id or "").strip().lower())


def push_source_id(type_id: str) -> str:
    return f"{PUSH_SOURCE_PREFIX}{type_id}"


def push_types_for_route(path: str, registry: Tuple[PushType, ...] = PUSH_TYPES) -> Tuple[str, ...]:
    return tuple(p.type for p in registry if path in p.routes)


def classify_push_contributor(
    key: str,
    *,
    data_source: Optional[str] = None,
    provider: Optional[str] = None,
    registry: Tuple[PushType, ...] = PUSH_TYPES,
) -> Optional[str]:
    """Which push type a `contributing_sources` entry belongs to, or None (→ `untraceable`).

    Only a `<prefix>:push` key is a push contributor; `<prefix>:<integration uuid>` is an integration.
    """
    k = str(key or "")
    if not k.endswith(":push"):
        return None
    prefix = k[: -len(":push")]
    prov = str(provider or "").strip().lower()
    ds = str(data_source or "").strip().lower()
    if prov:
        for p in registry:
            if prov in p.providers and (not p.data_sources or ds in p.data_sources):
                return p.type
    for p in registry:
        if prefix in p.key_prefixes:
            return p.type
    return None
