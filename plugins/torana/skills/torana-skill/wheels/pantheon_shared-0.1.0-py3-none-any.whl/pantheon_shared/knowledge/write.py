"""The knowledge write models: deposits, corrections, retire, revert and the lifecycle bodies (KNOWLEDGE_API.md § 3.17.4.2).

Same `_In` / `_Out` bases as contract.py. There is NO certainty field on any write request (W-4): Atlas decides it."""
from __future__ import annotations

from typing import Literal

from pydantic import Field, model_validator

from pantheon_shared.knowledge.contract import Statement, _In, _Out

WRITE_REQUEST_SCHEMA, WRITE_RESULT_SCHEMA = "atlas/write-request.v1", "atlas/write-result.v1"


class OwnerStatementIn(_In):
    text: str = Field(min_length=3, max_length=1000, pattern=r"^[^\n\r]*$")     # one line: no newline
    section: int | None = Field(default=None, ge=1, le=8)
    anchors: list[str] = Field(default_factory=list, max_length=10)             # atlas:<this node>@<current version>#a:<n>

    @model_validator(mode="after")
    def _no_front_matter_break(self) -> "OwnerStatementIn":
        if "---" in self.text:
            raise ValueError("a statement must not contain '---' (front-matter break)")
        return self


class WriteIn(_In):
    schema_: Literal["atlas/write-request.v1"] = Field(default=WRITE_REQUEST_SCHEMA, alias="schema")
    reason: str = Field(min_length=3, max_length=500)                           # required on EVERY write (K-2: author + reason)
    via: Literal["api", "cli", "fe", "session"] = "api"                         # declared (W-11)
    idempotency_key: str | None = Field(default=None, min_length=8, max_length=128)


class DepositIn(WriteIn):
    title: str = Field(min_length=3, max_length=120, pattern=r"^[^\n\r]*$")
    statements: list[OwnerStatementIn] = Field(min_length=1, max_length=20)


class CorrectionTarget(_In):
    file: str = "SKILL.md"
    fingerprint: str = Field(pattern=r"^[0-9a-f]{12}$")


class CorrectionIn(WriteIn):
    target: CorrectionTarget
    action: Literal["replace", "retract"]
    replacement: OwnerStatementIn | None = None                                  # required for replace, forbidden for retract

    @model_validator(mode="after")
    def _replacement_matches_action(self) -> "CorrectionIn":
        if self.action == "replace" and self.replacement is None:
            raise ValueError("action 'replace' requires a replacement")
        if self.action == "retract" and self.replacement is not None:
            raise ValueError("action 'retract' must not carry a replacement")
        return self


# Retire, revert and the lifecycle verbs (pause / resume / rebuild / suppress / restore) take `WriteIn` (a reason) and nothing else.
DepositRequest = DepositIn
CorrectionRequest = CorrectionIn
RetireRequest = WriteIn
RevertRequest = WriteIn
LifecycleRequest = WriteIn


class OwnerEntryView(_Out):
    slug: str
    node_path: str
    skill_name: str
    kind: str
    status: str
    title: str
    author: str
    via: str
    reason: str
    created_at: str
    write_id: str
    statements: list[Statement] = []
    target: dict | None = None
    action: str | None = None
    conflict: bool = False
    target_gone: bool = False


class WriteResult(_Out):
    schema_: Literal["atlas/write-result.v1"] = Field(default=WRITE_RESULT_SCHEMA, alias="schema")
    write_id: str
    op: str
    status: str                                                                  # committed | rejected (open for readers)
    node_path: str
    skill_name: str | None
    entry: OwnerEntryView | None = None
    from_version: int | None = None
    to_version: int | None = None
    state_before: str | None = None
    state_after: str | None = None
    validation: dict | None = None                                               # {ok, items} for a content write
    cap_warnings: list[str] = []
    trace_id: str
    links: dict                                                                  # {self, node, trace, revert?}
