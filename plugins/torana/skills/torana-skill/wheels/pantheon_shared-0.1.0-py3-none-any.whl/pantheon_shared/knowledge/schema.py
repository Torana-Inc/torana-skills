"""Export the knowledge contract as JSON Schema (KNOWLEDGE_API.md § 3.4.3).

    python -m pantheon_shared.knowledge.schema export [--cli-dir DIR]
    python -m pantheon_shared.knowledge.schema export --check [--cli-dir DIR]     # exit 1 when a copy differs

The files in `knowledge/schemas/` are GENERATED from the models. The CLI has no pantheon-shared dependency, so it vendors a
copy (`pantheon-cli/torana_cli/contracts/atlas/`); `--cli-dir` names it, and `--check` compares it too when it exists."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from pydantic import TypeAdapter

from pantheon_shared.knowledge import contract as c
from pantheon_shared.knowledge import write as w

SCHEMA_DIR = Path(__file__).parent / "schemas"
FILE_FMT = "atlas.{name}.v1.json"

#: export name -> model (or a union of models: the write request is one of three bodies)
EXPORTS: dict[str, object] = {
    "context-request": c.ContextRequest,
    "context": c.KnowledgeContext,
    "answer-request": c.AnswerRequest,
    "answer": c.Answer,
    "answer-output": c.AnswerOut,
    "skill": c.SkillView,
    "facts": c.FactsView,
    "map": c.MapView,
    "error": c.ErrorBody,
    "kind": c.Kind,
    "kind-list": c.KindList,
    "write-request": w.DepositIn | w.CorrectionIn | w.WriteIn,
    "write-result": w.WriteResult,
}


def build_schemas() -> dict[str, dict]:
    return {name: TypeAdapter(model).json_schema(by_alias=True) for name, model in EXPORTS.items()}


def render(schema: dict) -> str:
    return json.dumps(schema, indent=2, sort_keys=True) + "\n"


def file_name(name: str) -> str:
    return FILE_FMT.format(name=name)


def load_exported(directory: Path = SCHEMA_DIR) -> dict[str, dict]:
    return {name: json.loads((directory / file_name(name)).read_text()) for name in EXPORTS}


def _default_cli_dir() -> Path | None:
    for parent in Path(__file__).resolve().parents:
        cand = parent.parent / "pantheon-cli" / "torana_cli" / "contracts" / "atlas"
        if cand.parent.parent.is_dir():
            return cand
    return None


def check(directories: list[Path]) -> list[str]:
    """Names of files that are missing or differ from the models, per directory."""
    problems = []
    for d in directories:
        for name, schema in build_schemas().items():
            p = d / file_name(name)
            if not p.exists():
                problems.append(f"{p}: missing")
            elif p.read_text() != render(schema):
                problems.append(f"{p}: differs from the models")
        if d.is_dir():
            known = {file_name(n) for n in EXPORTS}
            problems += [f"{p}: not exported by the models" for p in sorted(d.glob("atlas.*.json")) if p.name not in known]
    return problems


def export(directories: list[Path]) -> None:
    for d in directories:
        d.mkdir(parents=True, exist_ok=True)
        for name, schema in build_schemas().items():
            (d / file_name(name)).write_text(render(schema))


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m pantheon_shared.knowledge.schema")
    sub = ap.add_subparsers(dest="cmd", required=True)
    ex = sub.add_parser("export", help="write the JSON Schema files (or --check them)")
    ex.add_argument("--check", action="store_true", help="exit 1 when a copy differs from the models; writes nothing")
    ex.add_argument("--cli-dir", type=Path, default=None, help="the CLI's vendored copy (default: pantheon-cli next to this repo, if present)")
    args = ap.parse_args(argv)
    cli_dir = args.cli_dir or _default_cli_dir()
    targets = [SCHEMA_DIR] + ([cli_dir] if cli_dir and (args.cli_dir or cli_dir.is_dir()) else [])
    if args.check:
        problems = check(targets)
        for p in problems:
            print(p, file=sys.stderr)
        print("export --check: " + ("FAILED" if problems else f"ok ({len(targets)} location(s))"))
        return 1 if problems else 0
    export(targets)
    print("exported to " + ", ".join(str(t) for t in targets))
    return 0


if __name__ == "__main__":
    sys.exit(main())
