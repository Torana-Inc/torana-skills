"""The knowledge contract: what a caller sends Atlas and what it gets back (KNOWLEDGE_API.md § 3.4).

Rules (§ 3.4.3): additive-only within a version; requests are strict (extra="forbid"), responses are lenient
(extra="ignore"); every enum in a RESPONSE is open for readers (an unknown value is shown, never fatal)."""
from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

CONTRACT_VERSION = "1.0"                     # major = the schema suffix; minor = additive revisions
CONTEXT_REQUEST_SCHEMA = "atlas/context-request.v1"
CONTEXT_SCHEMA = "atlas/context.v1"
ANSWER_REQUEST_SCHEMA = "atlas/answer-request.v1"
ANSWER_SCHEMA = "atlas/answer.v1"
ANSWER_OUTPUT_SCHEMA = "atlas/answer-output.v1"   # what the SESSION must return (was "answer.v1" in the first draft)
SKILL_SCHEMA, FACTS_SCHEMA, MAP_SCHEMA = "atlas/skill.v1", "atlas/facts.v1", "atlas/map.v1"
ERROR_SCHEMA = "atlas/error.v1"

KEY_PATTERN = r"^[a-z][a-z0-9_.-]{0,31}:\S{1,1000}$"   # the platform identity key: <type>:<rest> (KINDS § 1.3)
NAME_PATTERN = r"^[a-z][a-z0-9:-]{0,63}$"              # layer / kind / role / rung / gap reason / fact source: open vocabularies
MAX_KEYS = 1000                                        # = assemble.max_keys_hard (ALERT_WALK § W9: hard 1,000, soft 100); the server re-checks. Keys past the soft cap are ranked by weight and listed in walk.not_considered
MAX_QUESTION_CHARS = 20_000                             # a row-size guard only; a question over 2,000 chars logs a warning (assemble.question_warn_chars; ALERT_WALK B5: no quality cap yet, warn and measure)
MAX_FACTS = 50                                         # caller facts per ask (tunable; warn-and-measure, § 3.16 D-8)
MAX_FACT_CHARS = 8_000                                 # one fact
MAX_FACTS_TOTAL_CHARS = 32_000                         # all facts of one ask


class _In(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)


class _Out(BaseModel):
    model_config = ConfigDict(extra="ignore", populate_by_name=True)


# ── requests ───────────────────────────────────────────────────────────────────────────────────

class KeyIn(_In):
    key: str = Field(pattern=KEY_PATTERN)
    weight: int = Field(default=1, ge=1, le=1_000_000)


class Freshness(_In):                                  # = ASSEMBLY D4.1 Freshness, moved here
    read_against: str | None = None
    max_age: str | None = None                         # ISO-8601 duration
    wait_for_fresh_s: int = Field(default=0, ge=0)   # Phase 1; 0 = never wait (unchanged from today)


class Include(_In):
    files: bool = True                                 # list each contribution's files (and build the bundle)
    statements: bool = False                           # parse each skill's SKILL.md and owner/ into statements (§ 3.11.3)


class _KnowledgeInput(_In):
    """The one input type the verbs share (K-7 "kept common")."""
    keys: list[KeyIn] = Field(default_factory=list, max_length=MAX_KEYS)   # [] = the tenant overview (root + indexes)
    goal: Literal["answer", "build", "deposit"] = "answer"                 # freshness rules (ASSEMBLY D4.5)
    harness: Literal["claude-code", "adk"] = "claude-code"                 # bundle layout (ASSEMBLY D4.4)
    budget_tokens: int | None = Field(default=None, ge=1000)
    freshness: Freshness = Field(default_factory=Freshness)
    include: Include = Field(default_factory=Include)
    explain: bool = False                                                  # adds resolution[].via and trimmed files
    caller_ref: str | None = Field(default=None, max_length=512)           # the caller's own label; Atlas never parses it
    idempotency_key: str | None = Field(default=None, min_length=8, max_length=128)


class ContextRequest(_KnowledgeInput):
    """POST /atlas/context — get knowledge; the caller does the inferring (Model 1). Sync."""
    schema_: Literal["atlas/context-request.v1"] = Field(default=CONTEXT_REQUEST_SCHEMA, alias="schema")
    question: str | None = Field(default=None, max_length=MAX_QUESTION_CHARS)   # optional; guides TRIMMING and focus terms only, never selects a node (ASSEMBLY D4.11 R-104.1; ALERT_WALK B5); kept 90 days (K-5)
    delivery: Literal["push", "pull", "hybrid"] | None = None            # K-1. None = the answer profile's context_mode (BUILDER_PROFILES § 3.2.1); recorded on the request row


class CallerFact(_In):
    """One fact the caller supplies for THIS answer only (K-7): labelled "caller-supplied" to the model, untrusted, never stored into knowledge."""
    source: str = Field(pattern=NAME_PATTERN)           # who says so: "detection", "program-framework", "user"
    label: str | None = Field(default=None, max_length=120)   # "vulnerability row", "alert summary"
    fact: str = Field(min_length=1, max_length=MAX_FACT_CHARS)


class InferenceOptions(_In):
    """May only LOWER what the answer-use profile allows (BUILDER_PROFILES § 3.2.1): None = the profile's value."""
    max_budget_usd: float | None = Field(default=None, gt=0)   # capped at the profile's cost_cap_usd (default $0.75, K-3)
    timeout_s: int | None = Field(default=None, ge=30)         # capped at the profile's timeout_s (default 900)


class AnswerRequest(_KnowledgeInput):
    """POST /atlas/answers — ask for an answer; Atlas infers (Model 2). Async 202."""
    schema_: Literal["atlas/answer-request.v1"] = Field(default=ANSWER_REQUEST_SCHEMA, alias="schema")
    harness: Literal["claude-code"] = "claude-code"                        # an Atlas-run session is Claude Code (ADK: 501 not_implemented)
    question: str = Field(min_length=1, max_length=MAX_QUESTION_CHARS)
    context: list[CallerFact] = Field(default_factory=list, max_length=MAX_FACTS)
    inference: InferenceOptions | None = None

    @model_validator(mode="after")
    def _facts_total(self) -> "AnswerRequest":
        if sum(len(f.fact) for f in self.context) > MAX_FACTS_TOTAL_CHARS:
            raise ValueError(f"caller facts exceed {MAX_FACTS_TOTAL_CHARS} characters in total")   # the route maps this to 422 caller_facts_too_large
        return self


class InternalContextRequest(ContextRequest):
    tenant_id: str = Field(min_length=1)               # east-west only; the caller SERVICE comes from its JWT, never the body


class InternalAnswerRequest(AnswerRequest):
    tenant_id: str = Field(min_length=1)


# ── response parts ─────────────────────────────────────────────────────────────────────────────

Certainty = Literal["evidenced", "believed", "not_known"]   # ✓ ? ○ (design § 3.19.3)


class SkillRef(_Out):
    name: str                  # skill_name(path) (design § 3.19.6): the folder name the agent sees
    path: str                  # "code/torana-inc/pantheon-agent-builder"; "" = the root
    version: int | None        # None for an index skill or a map (rendered at read time, D2.12)
    kind: str                  # META atlas-kind: repository | image | cluster | namespace | index | map | … (open)
    layer: str                 # the top-level part (§ 3.19.2): code | artifacts | runtime | identity | people | work | maps | "" (root)
    as_of: str | None          # current_as_of
    stale: bool
    digest: str                # sha256 of the sorted (file path, blob sha256) list served for it — which bytes, exactly


class EvidenceAnchor(_Out):
    ref: str                   # "atlas:<path>@<version>#<anchor id>" — global, resolvable as long as the version exists
    kind: str                  # file_line | row | issue | asset | node (contract § 5; open)
    target: str                # the anchor's `ref`: a file path, "<table>/<pk>", an issue key, an asset key, a node path
    line: int | None = None
    end_line: int | None = None
    at: str | None = None      # commit sha or watermark the evidence was read at
    quote: str | None = None   # ≤ 500 chars; dropped when the body is truncated
    resolved: bool             # the id exists in that version's anchors.jsonl


class Statement(_Out):
    id: str                    # "s:<n>", unique within the response
    section: int | None        # 1–8 (§ 3.19.3); None when the skill predates the eight sections
    text: str
    certainty: Certainty
    anchors: list[EvidenceAnchor] = []
    fingerprint: str | None = None     # 12 hex of the normalised text (§ 3.17.3.1): what a correction names. skill and owner statements only
    source: Literal["skill", "owner", "session"]       # "owner" = an owner/ entry (deposit or correction), § 3.17.3
    open_question: str | None = None   # "questions/open/<slug>.md" for a not_known statement
    author: str | None = None          # owner statements: "user:<id>" or "service:<name>"; "asserted by <author>" is shown when unanchored
    overridden_by: str | None = None   # a skill statement an owner correction replaces or retracts: that statement's id ("s:<n>")
    basis: str | None = None           # session statements resting only on caller facts: "caller-supplied" (never evidenced, § 3.11.4)
    facts_used: list[int] = []         # session statements: the numbers (Answer.caller_facts[].n) of the caller facts it relied on
    support: Literal["ok", "weak"] | None = None   # session statements with anchors: "weak" = no cited anchor shares a content word with the text (lexical check, warn-only); None = not checked


class SliceInfo(_Out):
    """ASSEMBLY D4.11 R-104.2/3: a fact file cut to the records a focus matched. ONE function (src/services/slices.py) computes it, for push and pull."""
    terms: list[str]           # "field:value", e.g. "package:litellm"
    kept: int
    total: int
    full_bytes: int
    complete: bool | None      # True only if every record of each matched group survived build-time truncation; None = file predates cut_groups.
    # A claim of ABSENCE made from a slice whose complete is not True is `?`, never `✓` (R-104.3, ALERT_WALK A4.3)


class FileRef(_Out):
    path: str                  # inside the skill folder
    bytes: int
    sha256: str
    included: bool             # False = trimmed for budget, or left out of a hybrid starter; fetch with GET /atlas/skills/{name}?file=
    reason: str | None = None  # "budget" | "starter" | "sliced" | …
    slice: SliceInfo | None = None   # set when `reason == "sliced"`: the part of the file that was kept


class CertaintyCounts(_Out):
    evidenced: int = 0
    believed: int = 0
    not_known: int = 0


class Contribution(_Out):
    id: str                    # "c:<n>"
    skill: SkillRef
    role: str                  # subject | linked | derived | index | map (open)
    distance: int
    portion: str               # full | facts | skill
    reason: str                # why it is here: "key:<key>" | "derives_from" | "index" | "root" | "link:<rel>" (open)
    from_keys: list[str] = []  # the request keys that led here
    files: list[FileRef] = []
    statements: list[Statement] = []
    certainty: CertaintyCounts = Field(default_factory=CertaintyCounts)
    owner_entries: int = 0     # live owner/ entries on this skill (deposits, corrections); 0 = none
    tokens: int


class ResolutionStep(_Out):
    """One entity reached from the request keys, or one key that reached nothing (ALERT_WALK B5 `resolved` / `unresolved`)."""
    key: str                   # the entity key reached (repo:…), or the request key that reached nothing
    from_keys: list[str] = []  # the request keys that led here
    weight: int
    rung: str                  # ALERT_WALK § W2: R0-direct | R0-image | R2-vulnerability | R3-image-name | R4-package | R5-none (open)
    certainty: Literal["evidenced", "believed", "none"]
    entity_key: str | None     # what the key resolved to (a repo:, image:, cloud: … key)
    skill: SkillRef | None     # the knowledge skill of that entity, when one exists
    label: str | None = None   # a believed link says so in words: "same image name; this digest has no build record" (ALERT_WALK A4.4)
    reason: str | None = None  # unresolved only: no-builder | ambiguous-builder:<n> | rung-unavailable:<what> | not-a-knowledge-question | no-match
    via: list[dict] = []       # explain only: proof-layer pointers to the datalake rows used (pantheon_shared.proof.core.pointers)


class Gap(_Out):
    id: str                    # "g:<n>"
    about: str                 # a key, a skill path, a layer, or "request"
    about_type: Literal["key", "skill", "layer", "section", "request"]
    reason: str                # the registry, § 3.4.4.2 (open)
    detail: str                # one sentence, for a person
    unlocks: str | None = None  # what would close it ("select code/acme/api", "connect a kubernetes integration")
    open_question: str | None = None


class NotIncluded(_Out):
    key: str
    entity: str
    reason: str                # "image card: not available yet", "base-defining repository: not selected" (ALERT_WALK W2.2)
    unlock: str | None = None


class WalkReport(_Out):
    """What the key walk did and did not do, so absence is never read as falsehood (ALERT_WALK A4.3). Every entry also yields a Gap."""
    packages: list[str] = []          # pkg: keys sent (R4 may be off; still used for focus)
    rungs_off: list[dict] = []        # [{rung, reason}] rungs that did not run: "R4: flag off", "R3: before image_names"
    not_considered: list[str] = []    # keys past the soft cap (100), ranked by weight
    collapsed: list[dict] = []        # ALERT_WALK W4.1: [{base, base_repository, services, weight_total}]
    not_included: list[NotIncluded] = []
    focus: list[str] = []             # ASSEMBLY D4.11 focus terms "field:value"


class SessionRef(_Out):
    session_id: str            # agent-builder's; also Claude's --session-id (§ 3.12.3)
    harness: str               # "claude-code@2.1.291"
    model: str
    status: str                # ok | failed | timeout | budget
    num_turns: int | None = None
    tool_calls: dict[str, int] = {}
    tokens_in: int = 0
    tokens_out: int = 0
    cost_usd: float = 0.0
    duration_ms: int = 0
    span_id: str | None = None  # the invoke_agent span


class AnswerBody(_Out):
    summary: str
    statements: list[Statement]   # source == "session"; certainty re-decided by Atlas (§ 3.11.4)


class CallerFactUsed(_Out):
    n: int                     # 1-based, the order sent
    source: str
    label: str | None
    chars: int
    sha8: str                  # sha256[:8] of the text (the text itself stays in the tenant's request row, § 3.3.1)
    cited_by: list[str] = []   # statement ids that relied on it


class BundleRef(_Out):
    bundle_id: str             # deterministic (ASSEMBLY D4.6)
    download: str              # GET /api/v1/atlas/bundles/{bundle_id} while it lives
    expires_at: str
    rebuild: str               # GET /api/v1/atlas/{context|answers}/{request_id}/bundle — always works while the versions exist
    tokens_total: int


class PullHints(_Out):
    """Hybrid delivery only: what the harness may fetch next, so a tool needs no guessing."""
    skills: list[str]          # skill names available for GET /atlas/skills/{name}
    maps: list[str]            # map names for GET /atlas/maps/{map}
    facts_keys: list[str]      # entity keys that answer GET /atlas/facts?key=
    caps: dict[str, int] = {}  # advisory: {"max_pulls": <profile.pull_max_calls, default 20>, "max_chars_per_pull": <answer.pull_max_chars>} (warn-and-measure, § 3.16 D-8)


class Usage(_Out):
    latency_ms: int
    tokens_total: int          # the bundle (estimate, ASSEMBLY D4.4)
    tokens_in: int = 0         # the session
    tokens_out: int = 0
    cost_usd: float = 0.0
    citations_weak: int = 0    # answers: statements whose cited anchors share no content word with the sentence (support "weak")


class Links(_Out):
    self: str                  # /api/v1/atlas/{context|answers}/{request_id}
    trace: str                 # /api/v1/jaeger/trace/{trace_id}


class ErrorBody(_Out):
    schema_: Literal["atlas/error.v1"] = Field(default=ERROR_SCHEMA, alias="schema")
    error: str                 # code, § 3.4.4.1
    message: str
    retryable: bool
    request_id: str | None = None
    trace_id: str | None = None
    detail: dict = {}


# ── responses ──────────────────────────────────────────────────────────────────────────────────

class _Envelope(_Out):
    """K-7: one envelope for all three read verbs."""
    request_id: str
    trace_id: str
    tenant_id: str
    kind: str                  # context | answer | pull
    status: str                # complete | running | failed | cancelled (open for readers)
    outcome: str | None        # §3.4.1 outcome table; None while running
    asked: dict                # {keys, question, goal, harness, caller_ref}
    gaps: list[Gap] = []
    as_of: str                 # ISO time Atlas computed this response
    usage: Usage
    error: ErrorBody | None = None
    links: Links
    truncated: bool = False


class LearnedFact(_Out):
    """One learned fact: the learning store's open sightings (`atlas_learning_claims`), never the live datalake graph.
    Every field but `words` is data; `words` is the server's sentence, printed verbatim by the CLI and FE."""
    claim_id: str              # the claim behind the fact: `torana atlas claims explain <id>`
    claim_type: str            # deploy.runs | image.running | image.source | image.base (open)
    env: str | None = None     # the environment label ("production") the fact is about
    workload: str | None = None   # "service:<cluster>/<namespace>/<name>"
    digest: str | None = None  # "sha256:…"
    repository: str | None = None   # the "repo:…" the image was built from
    commit: str | None = None  # the commit the image was built from, when known
    base: str | None = None    # "<repo>@<revision>" of the image's base, when known
    since: str | None = None   # ISO time: the oldest open sighting's valid_from
    conviction: str            # the source class's prior tier: observed | evidenced | inferred | asserted (open)
    words: str                 # one sentence, for a person or an agent


class LearnedContribution(_Out):
    """Learned facts for one request key: a contribution that is NOT a skill, so it is listed beside `contributions`,
    never in it (added 2026-11-13, P6 follow-up 1). Additive optional field read with extra="ignore": CONTRACT_VERSION
    stays "1.0"."""
    id: str                    # "l:<n>", unique within the response
    kind: str                  # "deployment_facts" (open)
    key: str                   # the request key it answers
    words: str                 # the heading sentence: what, how many, whether the budget cut it
    facts: list[LearnedFact] = []
    total: int = 0             # facts known before the budget cut
    tokens: int = 0            # what the shown facts cost


class KnowledgeContext(_Envelope):
    schema_: Literal["atlas/context.v1"] = Field(default=CONTEXT_SCHEMA, alias="schema")
    resolution: list[ResolutionStep] = []
    walk: WalkReport = Field(default_factory=WalkReport)
    contributions: list[Contribution] = []
    learned: list[LearnedContribution] = []       # learned facts (deployment) for the request keys, beside the skills
    bundle: BundleRef | None = None
    delivery: str = "push"
    pull: PullHints | None = None                  # hybrid only


class Answer(_Envelope):
    schema_: Literal["atlas/answer.v1"] = Field(default=ANSWER_SCHEMA, alias="schema")
    resolution: list[ResolutionStep] = []
    walk: WalkReport = Field(default_factory=WalkReport)
    contributions: list[Contribution] = []         # the knowledge the session was given
    answer: AnswerBody | None = None
    caller_facts: list[CallerFactUsed] = []
    bundle: BundleRef | None = None
    session: SessionRef | None = None
    profile: dict | None = None                    # {name, revision, sha, source}: the answer profile that ran (BUILDER_PROFILES § 3.2.3)


class SkillView(_Envelope):
    """GET /atlas/skills/{name}: one skill, or one file of it."""
    schema_: Literal["atlas/skill.v1"] = Field(default=SKILL_SCHEMA, alias="schema")
    skill: SkillRef
    file: str                  # "SKILL.md" by default
    text: str | None           # the file's text; None when binary or over the cap. With ?term= on a fact file: the sliced document (R-104.5)
    slice: SliceInfo | None = None
    files: list[FileRef] = []  # the skill's other files, so the next pull needs no guess


class FactSlice(_Out):
    skill: SkillRef
    file: str                  # inside the skill folder, e.g. "facts/usage.json"
    slice: SliceInfo
    records: list[dict]        # the matched records, exactly as stored (never cut in half)
    anchors: list[EvidenceAnchor] = []   # only the anchors those records cite


class FactsView(_Envelope):
    """GET /atlas/facts?key=&term=: the records of the facts of the skills a key resolves to that match a term. A thin wrapper
    over the SAME slice function the starter and the file route use (ASSEMBLY D4.11 R-104.5): one definition, one computation."""
    schema_: Literal["atlas/facts.v1"] = Field(default=FACTS_SCHEMA, alias="schema")
    key: str
    terms: list[str] = []      # "field:value", expanded from a bare `term` (R-104.1)
    resolution: list[ResolutionStep] = []
    slices: list[FactSlice] = []
    total: int = 0             # records kept across all slices


class MapView(_Envelope):
    """GET /atlas/maps/{map}?key=: the rows of a read-time map that touch a key."""
    schema_: Literal["atlas/map.v1"] = Field(default=MAP_SCHEMA, alias="schema")
    map: str                   # "dependencies"
    columns: list[str] = []
    rows: list[dict] = []
    total: int = 0


class AnswerOut(BaseModel):
    """atlas/answer-output.v1 — the JSON Schema handed to `claude -p --json-schema` for an answer session.
    Strict, and every field required (Claude accepts full JSON Schema; additionalProperties:false is part of it)."""
    model_config = ConfigDict(extra="forbid")
    summary: str = Field(max_length=2000)
    statements: list["AnswerStatementOut"] = Field(max_length=40)


class AnswerStatementOut(BaseModel):
    model_config = ConfigDict(extra="forbid")
    text: str = Field(max_length=1000)
    section: int | None = Field(ge=1, le=8)
    certainty: Certainty
    anchors: list[str] = Field(max_length=10)   # "<skill-name>#a:<n>", exactly as the session sees them
    facts_used: list[int] = Field(max_length=10)   # numbers of the caller facts relied on ("fact 3" in /scratch/caller_facts.md); [] if none


AnswerOut.model_rebuild()      # AnswerStatementOut is defined after AnswerOut (forward reference)


# ── the kinds API (S07, plan review PL-4.2) ────────────────────────────────────────────────────

KIND_SCHEMA, KIND_LIST_SCHEMA = "atlas/kind.v1", "atlas/kind-list.v1"


class Kind(_Out):
    """GET /atlas/kinds/{kind}: one knowledge kind. A tenant caller sees only kinds enabled for it; the SA sees every kind
    with `enabled` per `?tenant=`."""
    schema_: Literal["atlas/kind.v1"] = Field(default=KIND_SCHEMA, alias="schema")
    kind: str
    shape: str                 # skill | card | map | index (open for readers)
    version: int
    path_rule: str
    sections: list[str] = []
    card_fields: list[str] = []
    enabled: bool              # effective for the caller's tenant
    phase: int
    needs: list[str] = []
    limits: dict = {}          # {policy_key: value}
    nodes: int = 0


class KindList(_Out):
    """GET /atlas/kinds?page=&page_size= (max 100)."""
    schema_: Literal["atlas/kind-list.v1"] = Field(default=KIND_LIST_SCHEMA, alias="schema")
    items: list[Kind]
    total: int
    page: int
    page_size: int


# ── package provenance (pantheon-knowledge PACKAGE_PROVENANCE.md) ──────────────────────────────

PROVENANCE_REQUEST_SCHEMA, PROVENANCE_SCHEMA = "atlas/package-provenance-request.v1", "atlas/package-provenance.v1"


class ProvenanceRequest(_In):
    """POST /internal/atlas/package-provenance: does `package` reach the image `repository`'s build produces, and is its
    version inside the advisory's range. Exactly one of the fix(es) (`fixed_version`, and
    `fixed_versions` when the advisory fixes several release lines) or `vulnerable_range`."""
    schema_: Literal["atlas/package-provenance-request.v1"] = Field(default=PROVENANCE_REQUEST_SCHEMA, alias="schema")
    tenant_id: str
    repository: str            # repo:github.com/<org>/<repo>
    package: str
    ecosystem: str = "pypi"
    file: str | None = None    # the manifest the scanner reported
    fixed_version: str | None = None
    fixed_versions: list[str] | None = None    # one fix per release line, e.g. ["1.28.1", "2.0.0a2"] (F43)
    vulnerable_range: str | None = None
    commit: str | None = None  # the commit the finding was scanned at
    reported_version: str | None = None        # the scanner's version at `file`: words only, never compared (F43)
    observe: bool = True
    caller_ref: str | None = None

    @model_validator(mode="after")
    def _one_range(self):
        if bool(self.fixed_version or self.fixed_versions) == bool(self.vulnerable_range):
            raise ValueError("give exactly one of the fixed version(s) or vulnerable_range")
        return self


class ProvenanceWords(_Out):
    """A server-written state line: print `glyph` and `words` verbatim, never re-derive them."""
    state: str                 # open for readers
    glyph: str = ""
    words: str = ""


class ProvenanceKnowledge(ProvenanceWords):
    nodes: list[dict] = []     # {repository, node_path, snapshot, commit, state, glyph, words, behind, error_kind, since}


PIN_SET_SCHEMA, MOVE_SET_SCHEMA = "torana-reachability/pin-set.v1", "torana-reachability/move-set.v1"
MOVE_SET_LABEL = "Everything that must move together"


class Pin(_Out):
    """One place on the install path that holds the package (torana_reachability.move_together `pins_on_path`,
    FIX_KNOWLEDGE_CONVERGENCE § 3.4.2). Every key the library writes is listed, so `extra="ignore"` drops nothing.
    `role`: ships | source | request | patch (open for readers)."""
    role: str
    tree: str                          # the input label (the Atlas: the repository subject)
    name: str | None = None            # short repository name, for words
    repository: str | None = None
    commit: str | None = None
    file: str | None = None
    line: int | None = None
    anchor: str | None = None          # the record's first anchor in its snapshot
    ref: str | None = None             # Atlas ref of the anchor, as ShippedSource.ref (set by the Atlas, not the library)
    spec: str | None = None
    version: str | None = None
    syntax: str | None = None
    lock_format: str | None = None
    compiled_from: str | None = None   # ships: the lock's input file
    compiles_into: str | None = None   # source: the lock it is compiled into
    reached_by: str | None = None      # request through a wheel: "wheel <path>"
    via: str | None = None             # the install step id in the primary
    dockerfile: str | None = None      # patch
    copy_line: int | None = None
    apply_line: int | None = None
    method: str | None = None


class MoveEntry(Pin):
    """One `members` / `review` / `fine` / `undecidable` entry of a MoveSet: the pin plus the judgment. `repository`,
    `commit` and `anchor` are always present on the wire (null when unknown): link from the entry, never re-join it
    to the pins. Print `words` verbatim. `action`: bump | recompile (members only; open for readers)."""
    action: str | None = None
    from_: str | None = Field(default=None, alias="from")
    to: str | None = None              # null with `needs_human` on a member: a person must change the line
    needs_human: str | None = None
    then: str | None = None            # e.g. "recompile base-image/requirements.lock"
    why: str | None = None
    words: str = ""


class PinSet(_Out):
    """Every declaration, resolution and build patch of the package on the primary's install path. Target-free: a
    reader runs `must_move` with its own target. `complete` is false when `not_checked` names a gap."""
    schema_: Literal["torana-reachability/pin-set.v1"] = Field(default=PIN_SET_SCHEMA, alias="schema")
    ecosystem: str = "pypi"
    package: str
    scanned: str | None = None
    primary: str
    pins: list[Pin] = Field(default_factory=list)
    ignored: list[dict] = Field(default_factory=list)      # {tree, name, file, line, spec, why, words}
    checked: list[str] = Field(default_factory=list)
    not_checked: list[dict] = Field(default_factory=list)  # {tree, name, why, words}
    complete: bool


class MoveSet(_Out):
    """Which pins must change for the package to ship at `target` (`members`), which only need a person's check
    (`review`: a build patch), which already admit it (`fine`), and which the policy cannot judge (`undecidable`;
    `decided` is then false). `not_listed` is the library's fixed sentence about co-moving packages."""
    schema_: Literal["torana-reachability/move-set.v1"] = Field(default=MOVE_SET_SCHEMA, alias="schema")
    ecosystem: str = "pypi"
    package: str
    target: str
    members: list[MoveEntry] = Field(default_factory=list)
    review: list[MoveEntry] = Field(default_factory=list)
    fine: list[MoveEntry] = Field(default_factory=list)
    undecidable: list[MoveEntry] = Field(default_factory=list)
    ignored: list[dict] = Field(default_factory=list)
    not_checked: list[dict] = Field(default_factory=list)
    complete: bool
    decided: bool
    not_listed: str = ""
    label: str = MOVE_SET_LABEL        # server-written label: print verbatim


class PackageProvenance(_Out):
    """The verdict. `outcome`: not_shipped | fixed_in_shipped | vulnerable_in_shipped | unknown (open for readers).
    A caller must not treat `unknown` as "not shipped"; `missing` names the link Atlas could not follow, `knowledge`
    what Atlas had read, `as_of` the snapshots and commits the verdict was computed from.

    `pins` / `move_together` (FIX_KNOWLEDGE_CONVERGENCE § 3.4.4, added 2026-10-27): set when the final outcome is
    `vulnerable_in_shipped` (`move_together` only when the request had a `fixed_version`), else null. Additive optional
    fields read with extra="ignore", so CONTRACT_VERSION stays "1.0" (an older body validates unchanged)."""
    schema_: Literal["atlas/package-provenance.v1"] = Field(default=PROVENANCE_SCHEMA, alias="schema")
    request_id: str
    repository: str
    ecosystem: str
    package: str
    file: str | None = None
    vulnerable_range: str
    outcome: str
    verdict: ProvenanceWords
    knowledge: ProvenanceKnowledge
    file_status: dict | None = None
    shipped: list[dict] = []
    fix_at: dict | None = None
    missing: list[dict] = []
    running: ProvenanceWords
    chain: list[dict] = []
    as_of: list[dict] = []
    cost_usd: float = 0.0
    pins: PinSet | None = None
    move_together: MoveSet | None = None
