"""The must-move set's words from fixed codes plus locators (ATLAS_ALERT_SECTION_CONTRACT.md § 3a, Q5 option iii).

A stored move set keeps codes and locators only, never sentences (they carry names). Two services print the same words:
the Atlas keeps them on the wire (`/atlas/package-provenance`, `torana atlas provenance`), and DF's
`GET /alerts/{id}/fix-scope` renders them from the stored codes at read time. Both call `render` here, so the words
cannot drift between them.

- `annotate(move, pins)` adds the codes to every entry of a `torana-reachability/move-set.v1` body, in place:
  `why_code` (members), `review_code` (review), `decline_code` (a member a person must change, and every undecidable
  entry), plus `decline_spec` (the spec fragment a decline names) when the sentence needs it.
- `render(bucket, entry, ...)` returns `{"why", "words"}` from those codes and the entry's locators only. ⭐ For every
  code its output equals the words `torana_reachability.move_together.must_move` writes (pinned by a test that runs
  the real library), so the planner contract is unchanged.

Pure: no I/O, no clock, no PEP 440 checker (DF has none), which is why `decline_spec` is a stored locator."""
from __future__ import annotations

import re
from typing import Any, Mapping, Optional, Sequence

BUCKETS = ("members", "review", "fine", "undecidable")

#: members: why the place must move (the library's `why` sentence per code)
WHY = {"ships_it": "ships it", "pulls_back": "would pull the old version back"}
WHY_CODES = tuple(WHY)
#: review: what a person must check
REVIEW_CODES = ("patch_reapply",)
#: a member whose rewrite is a person's decision (`to: null`), and every undecidable entry
DECLINE_CODES = ("upper_bound_excludes", "no_mechanical_rewrite", "rewrite_not_admitting", "policy_undecidable")

_STUCK = (
    ("upper_bound_excludes", re.compile(r"^`(?P<spec>.*)` excludes .*: an upper bound or exclusion is not rewritten "
                                        r"mechanically$", re.S)),
    ("rewrite_not_admitting", re.compile(r"^the rewrite `(?P<spec>.*)` does not admit .*$", re.S)),
    ("no_mechanical_rewrite", re.compile(r"^no mechanical rewrite for `.*` \(.*\)$", re.S)),
)


def short_name(label: Optional[str]) -> str:
    """`repo:github.com/acme/billing-api` -> `billing-api` (the library's `short_name`)."""
    s = str(label or "")
    return s.removeprefix("repo:").rstrip("/").rsplit("/", 1)[-1] or s


def _name(e: Mapping[str, Any]) -> str:
    return short_name(e.get("tree"))


def _place(e: Mapping[str, Any]) -> str:
    return f"{_name(e)} {e.get('file')}" + (f":{e['line']}" if e.get("line") else "")


def _source_of(entry: Mapping[str, Any], pins: Optional[Sequence[Mapping[str, Any]]]) -> Optional[Mapping[str, Any]]:
    """The `source` pin a `ships` entry is compiled from: same tree, `compiles_into` == the entry's file."""
    for p in pins or ():
        if p.get("role") == "source" and p.get("tree") == entry.get("tree") and p.get("compiles_into") == entry.get("file"):
            return p
    return None


# ── codes ───────────────────────────────────────────────────────────────────────────────────────────────────────────

def _why_code(why: Optional[str]) -> Optional[str]:
    return next((c for c, w in WHY.items() if w == why), None)


def _decline(needs_human: str) -> tuple[Optional[str], Optional[str]]:
    for code, rx in _STUCK:
        m = rx.match(needs_human)
        if m:
            return code, m.groupdict().get("spec")
    return None, None


def annotate(move: dict, pins: Optional[Sequence[Mapping[str, Any]]] = None) -> dict:
    """Add the fixed codes to every members / review / undecidable entry of a move set, in place; returns `move`.
    Raises `ValueError` on a sentence this version does not know (a newer library): a code is never guessed."""
    del pins                                          # the codes need only the entry; kept for a symmetric call site
    for e in move.get("members") or ():
        code = _why_code(e.get("why"))
        if code is None:
            raise ValueError(f"unknown member why: {e.get('why')!r}")
        e["why_code"] = code
        if e.get("needs_human"):
            dc, spec = _decline(e["needs_human"])
            if dc is None:
                raise ValueError(f"unknown decline sentence: {e['needs_human']!r}")
            e["decline_code"] = dc
            if spec is not None:
                e["decline_spec"] = spec
    for e in move.get("review") or ():
        if e.get("role") != "patch":
            raise ValueError(f"unknown review entry role: {e.get('role')!r}")
        e["review_code"] = "patch_reapply"
    for e in move.get("undecidable") or ():
        e["decline_code"] = "policy_undecidable"
    return move


# ── words ───────────────────────────────────────────────────────────────────────────────────────────────────────────

#: printed where a version-spec key was dropped from the stored copy (it did not parse): fixed words, never "None"
NOT_STORED = "(not stored)"


def _v(e: Mapping[str, Any], key: str) -> str:
    v = e.get(key)
    return NOT_STORED if v is None else str(v)


def _stuck(e: Mapping[str, Any], ecosystem: str, target: str) -> str:
    code, frm = e.get("decline_code"), _v(e, "from")
    if code == "upper_bound_excludes":
        return f"`{_v(e, 'decline_spec')}` excludes {target}: an upper bound or exclusion is not rewritten mechanically"
    if code == "rewrite_not_admitting":
        return f"the rewrite `{_v(e, 'decline_spec')}` does not admit {target}"
    if code == "no_mechanical_rewrite":
        syntax = e.get("syntax") or ("pep508" if ecosystem == "pypi" else "")
        return f"no mechanical rewrite for `{frm}` ({syntax})"
    raise ValueError(f"unknown decline_code on a member: {code!r}")


def render(bucket: str, entry: Mapping[str, Any], *, ecosystem: str, package: str, target: str,
           pins: Optional[Sequence[Mapping[str, Any]]] = None) -> dict:
    """`{"why": <sentence | None>, "words": <sentence>}` for one entry of `bucket`, from its codes and locators only.
    `pins` = the stored `pins.pins[]` (a recompile member names its input's file:line from there). Raises
    `ValueError` on a code it does not know; a reader then prints no sentence rather than a guessed one."""
    eco = (ecosystem or "").lower()
    e = entry
    if bucket == "members":
        why = WHY.get(e.get("why_code") or "")
        if why is None:
            raise ValueError(f"unknown why_code: {e.get('why_code')!r}")
        if e.get("action") == "recompile":
            src = _source_of(e, pins) or {}
            return {"why": why, "words": f"{_place(e)} ships {e.get('version')}: recompile it ({why}; its input "
                                         f"{src.get('file')}:{src.get('line')} already admits {target})"}
        then = f"recompile {e.get('compiles_into')}" if e.get("role") == "source" else None
        tail = f", then {then}" if then else ""
        # a person's decision = a decline code (the library keeps `to: null` with it); a `to` merely dropped from the
        # stored copy is still a mechanical bump, printed as NOT_STORED
        if e.get("decline_code"):
            return {"why": why, "words": f"{_place(e)} `{_v(e, 'from')}` must change to admit {target} ({why}){tail}; "
                                         f"a person must change it: {_stuck(e, eco, target)}"}
        return {"why": why, "words": f"{_place(e)} `{_v(e, 'from')}` → `{_v(e, 'to')}` ({why}){tail}"}
    if bucket == "review":
        if e.get("review_code") != "patch_reapply":
            raise ValueError(f"unknown review_code: {e.get('review_code')!r}")
        step = f"{e.get('dockerfile')}:{e.get('apply_line')}" if e.get("dockerfile") else _place(e)
        return {"why": None, "words": f"{_name(e)} {step} runs {e.get('file')} on the installed {package}; "
                                      f"check it still applies to {target}"}
    if bucket == "undecidable":
        if e.get("decline_code") != "policy_undecidable":
            raise ValueError(f"unknown undecidable decline_code: {e.get('decline_code')!r}")
        spec = f">={target}" if e.get("role") == "ships" else (e.get("spec") if "spec" in e else NOT_STORED) or ""
        return {"why": None, "words": f"{_place(e)}: the policy cannot decide whether `{spec}` admits {target}"}
    if bucket == "fine":
        if e.get("role") == "ships":
            return {"why": None, "words": f"{_place(e)} already ships {e.get('version')}, at or above {target}"}
        spec = (e.get("spec") or "(any)") if "spec" in e else NOT_STORED
        return {"why": None, "words": f"{_place(e)} `{spec}` admits {target}"}
    raise ValueError(f"unknown bucket: {bucket!r}")


# ── what may be stored (contract § 3a: an ALLOW-list of locators, never a deny-list of names) ─────────────────────────

FIX_AT_KEYS = ("repository", "node_path", "file", "line", "spec", "ref")
ENTRY_KEYS = ("role", "tree", "repository", "commit", "file", "line", "anchor", "ref", "spec", "version", "syntax",
              "lock_format", "compiled_from", "compiles_into", "via", "dockerfile", "copy_line", "apply_line", "method")
MOVE_ENTRY_KEYS = ENTRY_KEYS + ("action", "from", "to", "why_code", "review_code", "decline_code", "decline_spec")
FLAG_KEYS = ("complete", "decided", "package", "target", "ecosystem")
AS_OF_KEYS = ("repository", "node_path", "snapshot", "commit")
#: k04 ruling 2026-11-12: a version specifier is a version (a locator) only if it PARSES as one; else it is dropped
SPEC_KEYS = ("spec", "from", "to", "decline_spec")
STORED_BUCKETS = ("members", "review", "undecidable")

_NPM_TOKEN = re.compile(r"^(\|\||-|\*|[xX]|[\^~]?(<=|>=|<|>|=)?v?(\d+|[xX*])(\.(\d+|[xX*])){0,2}"
                        r"(-[0-9A-Za-z.-]+)?(\+[0-9A-Za-z.-]+)?)$")


def is_version_spec(value: Any, ecosystem: str = "pypi", syntax: Optional[str] = None) -> bool:
    """True when `value` parses as a version specifier in its ecosystem's own grammar: a `packaging` SpecifierSet for
    pypi (PEP 440; the declaration's `syntax: poetry` alone also admits poetry's `^` / `~` ranges), the npm range
    grammar for npm, nothing for any other ecosystem. `""` (any version) parses. Free text, a requirement line and a
    URL never do."""
    if not isinstance(value, str) or len(value) > 512:
        return False
    s = value.strip()
    if not s:
        return True
    eco = (ecosystem or "pypi").lower()
    if eco == "pypi":
        try:
            from packaging.specifiers import InvalidSpecifier, SpecifierSet
        except ImportError:                              # fail closed: no checker, nothing is stored
            return False
        try:
            SpecifierSet(s)
            return True
        except InvalidSpecifier:
            if syntax != "poetry":
                return False
    elif eco != "npm":
        return False
    tokens = s.replace(",", " ").split()
    return bool(tokens) and all(_NPM_TOKEN.match(t) for t in tokens)


#: k3 + k04 (2026-11-12): an `undecidable` entry's spec is, by definition, one `packaging` rejects (`~=1`,
#: `>=1.80.*`), so that ONE slot is kept by a lexical grammar instead: comma-separated clauses, each at most 32
#: characters, an optional operator plus `\d+(\.[0-9A-Za-z*+!_-]{1,16})*`: digits first, then dot-separated short
#: segments. A bare token ("ghp_…"), a commit sha ("==3f2a…") and anything with a space, `/`, `:`, `@`, `;`, `#` or a
#: quote never pass.
_LEXICAL_CLAUSE = re.compile(r"^(~=|===|==|!=|<=|>=|<|>)?\d+(\.[0-9A-Za-z*+!_-]{1,16})*$")
LEXICAL_CLAUSE_MAX = 32


def is_lexical_spec(value: Any) -> bool:
    """The undecidable entry's `spec` grammar (above). `""` (any version) passes."""
    if not isinstance(value, str):
        return False
    return value == "" or all(len(c) <= LEXICAL_CLAUSE_MAX and _LEXICAL_CLAUSE.match(c) for c in value.split(","))


def _keep(d: Any, keys: Sequence[str], ecosystem: str, *, lexical_spec: bool = False) -> Optional[dict]:
    if not isinstance(d, Mapping):
        return None
    out = {}
    syntax = d.get("syntax") if isinstance(d.get("syntax"), str) else None
    for k in keys:
        if k not in d:
            continue
        v = d[k]
        if k == "spec" and lexical_spec and v is not None:
            if not is_lexical_spec(v):
                continue
        elif k in SPEC_KEYS and v is not None and not is_version_spec(v, ecosystem, syntax):
            continue
        if isinstance(v, (Mapping, list, tuple)):        # a locator is a scalar: nested content is never kept
            continue
        out[k] = v
    return out


def stored_copy(provenance: Optional[Mapping[str, Any]]) -> Optional[dict]:
    """The part of a ships row's `provenance: {fix_at, pins, move_together, as_of}` that may be stored on an alert:
    allow-listed locator keys only, every version-spec key parsed, every other key (any depth) dropped."""
    if not isinstance(provenance, Mapping):
        return None
    mt_in = provenance.get("move_together") if isinstance(provenance.get("move_together"), Mapping) else None
    pins_in = provenance.get("pins") if isinstance(provenance.get("pins"), Mapping) else None
    eco = str((mt_in or pins_in or {}).get("ecosystem") or "pypi")
    out: dict = {"fix_at": _keep(provenance.get("fix_at"), FIX_AT_KEYS, eco), "pins": None, "move_together": None,
                 "as_of": [x for x in (_keep(a, AS_OF_KEYS, eco) for a in provenance.get("as_of") or ()
                                       if isinstance(provenance.get("as_of"), list)) if x is not None]}
    if pins_in is not None:
        out["pins"] = {**_keep(pins_in, FLAG_KEYS, eco),
                       "pins": [x for x in (_keep(p, ENTRY_KEYS, eco) for p in pins_in.get("pins") or ()) if x]}
    if mt_in is not None:
        out["move_together"] = storable(mt_in, eco)
    return out


def storable(move: Mapping[str, Any], ecosystem: Optional[str] = None) -> dict:
    """The storable part of one move set: its flags and its members / review / undecidable entries, allow-listed keys
    only, each version-spec key kept only when it parses (k04 ruling, 2026-11-12)."""
    eco = str(ecosystem or move.get("ecosystem") or "pypi")
    return {**_keep(move, FLAG_KEYS, eco),
            **{b: [x for x in (_keep(e, MOVE_ENTRY_KEYS, eco, lexical_spec=(b == "undecidable"))
                               for e in move.get(b) or ()) if x] for b in STORED_BUCKETS}}


def render_set(move: Mapping[str, Any], pins: Optional[Sequence[Mapping[str, Any]]] = None) -> dict:
    """A copy of a stored move set with `why` / `words` rendered on every entry of every bucket it holds."""
    out = dict(move)
    kw = dict(ecosystem=move.get("ecosystem") or "pypi", package=move.get("package") or "", target=move.get("target") or "",
              pins=pins)
    for b in BUCKETS:
        if isinstance(move.get(b), list):
            rendered = []
            for e in move[b]:
                r = render(b, e, **kw)
                rendered.append({**e, "words": r["words"], **({"why": r["why"]} if r["why"] is not None else {})})
            out[b] = rendered
    return out
