"""Ledger write client. [DESIGN §4.3]

Two write paths (same pattern as audit client):
1. In-process (caller is pantheon-program-framework): direct DB insert within
   the caller's transaction via injected async session.
2. HTTP (all other callers): POST /audit/ledger on pantheon-program-framework
   via PantheonClient with a service JWT.

Pre-state >1MB is truncated to a placeholder before storage; Reverse-this is
then disabled for that entry. [DESIGN §4.5.4]
"""

from __future__ import annotations

import json
import os
from typing import List, Literal, Optional
from uuid import UUID

from pantheon_shared import get_logger
from pantheon_shared.iam.context import IAMContext
from pantheon_shared.http import PantheonClient
from pantheon_shared.pantheon_services import PantheonService, get_pantheon_service_url
from pantheon_shared.audit.correlation import correlation_id_header

logger = get_logger(__name__)

_SERVICE_NAME = os.getenv("APPLICATION_NAME", "pantheon-service")
_MAX_STATE_BYTES = 1_048_576  # 1 MiB


async def write_ledger_entry(
    *,
    iam_context: IAMContext,
    audit_record_id: UUID,
    correlation_id: UUID,
    target_kind: str,
    target_id: str,
    mutation_kind: Literal["create", "update", "delete", "state_change"],
    pre_state: Optional[dict],
    post_state: Optional[dict],
    mutated_fields: Optional[List[str]] = None,
    db=None,
) -> UUID:
    """Write a single ledger entry. Returns the new entry id.

    Args:
        iam_context: Caller's IAM context (supplies tenant_id / namespace_id).
        audit_record_id: The audit_record this entry is paired with.
        correlation_id: Mirrors the audit record's correlation_id.
        target_kind: Kind of mutated artifact (e.g. "rule", "proposal").
        target_id: ID of the mutated artifact.
        mutation_kind: "create", "update", "delete", or "state_change".
        pre_state: Full prior state; None for creates.
        post_state: Full new state; None for deletes.
        mutated_fields: List of changed field names; empty for create/delete.
        db: AsyncSession — in-process write when provided; HTTP otherwise.

    Returns:
        UUID of the created ledger entry.
    """
    pre_state = _truncate_if_needed(pre_state, "pre_state", str(audit_record_id))
    post_state = _truncate_if_needed(post_state, "post_state", str(audit_record_id))

    payload = {
        "tenant_id": str(iam_context.tenant_id),
        "namespace_id": str(iam_context.namespace_id or ""),
        "audit_record_id": str(audit_record_id),
        "correlation_id": str(correlation_id),
        "target_kind": target_kind,
        "target_id": str(target_id),
        "mutation_kind": mutation_kind,
        "pre_state": pre_state,
        "post_state": post_state,
        "mutated_fields": mutated_fields or [],
    }

    if db is not None:
        return await _write_in_process(payload, db)
    return await _write_via_http(payload, iam_context, correlation_id)


def _truncate_if_needed(state: Optional[dict], field: str, ref: str) -> Optional[dict]:
    """Replace oversized state blobs with a truncation placeholder."""
    if state is None:
        return None
    try:
        raw = json.dumps(state, separators=(",", ":"))
    except Exception:
        raw = str(state)
    size = len(raw.encode("utf-8"))
    if size <= _MAX_STATE_BYTES:
        return state
    logger.warning(
        "ledger %s truncated for audit_record %s: %d bytes > %d limit",
        field, ref, size, _MAX_STATE_BYTES,
    )
    import hashlib
    checksum = hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16]
    return {"truncated": True, "size_bytes": size, "checksum": checksum}


async def _write_in_process(payload: dict, db) -> UUID:
    """Direct DB insert — caller is pantheon-program-framework."""
    from uuid import uuid4
    from sqlalchemy import text

    entry_id = uuid4()
    payload = dict(payload)
    payload["id"] = str(entry_id)
    payload["is_deleted"] = False

    for jsonb_col in ("pre_state", "post_state"):
        val = payload[jsonb_col]
        if val is not None and not isinstance(val, str):
            payload[jsonb_col] = json.dumps(val)

    for arr_col in ("mutated_fields",):
        val = payload[arr_col]
        if isinstance(val, list) and not isinstance(val, str):
            payload[arr_col] = val  # psycopg handles list→array

    cols = ", ".join(payload.keys())
    placeholders = ", ".join(f":{k}" for k in payload.keys())
    stmt = text(
        f"INSERT INTO workspace_artifact_ledger ({cols}) VALUES ({placeholders})"  # noqa: S608
    )
    await db.execute(stmt, payload)
    return entry_id


async def _write_via_http(
    payload: dict, iam_context: IAMContext, correlation_id: UUID
) -> UUID:
    """HTTP path: POST /audit/ledger on pantheon-program-framework."""
    base_url = get_pantheon_service_url(PantheonService.PROGRAM_FRAMEWORK)
    client = PantheonClient(
        service_name=_SERVICE_NAME,
        tenant_id=iam_context.tenant_id,
        namespace_id=iam_context.namespace_id,
    )
    extra_headers = correlation_id_header(correlation_id)
    response = await client.post(
        f"{base_url}/api/v1/audit/ledger",
        json=payload,
        headers=extra_headers,
        timeout=10.0,
    )
    response.raise_for_status()
    data = response.json()
    from uuid import UUID as _UUID
    return _UUID(data["id"])
