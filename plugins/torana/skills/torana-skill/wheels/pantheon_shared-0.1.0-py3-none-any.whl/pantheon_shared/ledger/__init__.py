"""Workspace Artifact Ledger client. [DESIGN §4.3]"""

from pantheon_shared.ledger.client import write_ledger_entry

__all__ = ["write_ledger_entry"]
