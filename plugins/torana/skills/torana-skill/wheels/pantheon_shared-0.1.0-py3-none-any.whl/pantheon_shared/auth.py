"""
Authentication utilities for Pantheon microservices.

Provides FastAPI dependencies and utilities for JWT authentication
with internal service bypass support.
"""

import inspect
import os
import secrets
from typing import Optional, Dict, Any, Callable, List
from fastapi import HTTPException, Request, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, Field, ConfigDict
import structlog
from sqlalchemy import create_engine, text

from .jwt import decode_jwt_token

logger = structlog.get_logger(__name__)

# Security scheme for JWT tokens
security = HTTPBearer(auto_error=False)


def is_service_token(claims: Dict[str, Any]) -> bool:
    """Return True if the JWT claims belong to a service token.

    A service token is identified by a ``sub`` claim that starts with
    ``"service:"``.  This is the canonical check used throughout the
    platform — callers should import this function rather than
    duplicating the ``startswith`` logic inline.
    """
    return claims.get("sub", "").startswith("service:")


# Internal alias used by AuthenticatedUser.from_token so the local
# variable name ``is_service_token`` inside that method doesn't shadow
# the module-level function.
_is_service_token = is_service_token


class AuthenticatedUser(BaseModel):
    """Authenticated user information container."""

    # Basic user info
    id: str = Field(..., description="User unique identifier")
    email: str = Field(..., description="User email")
    name: Optional[str] = Field(None, description="User display name")
    tenant_id: str = Field(..., description="User's tenant ID")
    tenant_name: Optional[str] = Field(None, description="User's tenant name")
    namespace_id: Optional[str] = Field(None, description="User's namespace ID")

    # Authorization
    roles: List[str] = Field(default_factory=list, description="User roles")
    permissions: List[str] = Field(default_factory=list, description="User permissions")

    # Metadata
    is_internal: bool = Field(default=False, description="True if this is an internal service user")
    is_active: bool = Field(default=True, description="Whether the user is active")
    is_verified: bool = Field(default=False, description="Whether the user is verified")

    # Internal user info storage
    user_info: Dict[str, Any] = Field(default_factory=dict, description="Original user info from token")

    model_config = ConfigDict(arbitrary_types_allowed=True)

    @classmethod
    def from_token(cls, user_info: Dict[str, Any], is_internal: bool = False) -> "AuthenticatedUser":
        """Create AuthenticatedUser from token data."""

        # Check if this is a service token (has service_name field)
        is_service_token = not is_internal and _is_service_token(user_info)

        if is_service_token:
            # Handle service tokens
            # Use system UUID since DB audit columns (created_by/updated_by) require UUID type
            return cls(
                id="00000000-0000-0000-0000-000000000001",
                email=user_info.get("service_name", "") + "@service.pantheon.local",
                name=user_info.get("service_name", "Unknown Service"),
                tenant_id=user_info.get("tenant_id", "torana"),
                tenant_name=user_info.get("tenant_name"),
                namespace_id=user_info.get("namespace_id"),
                roles=["service"] + user_info.get("scopes", []),
                permissions=user_info.get("scopes", []),
                is_internal=False,  # Service tokens are not "internal" - they're valid JWT tokens
                is_active=True,
                is_verified=True,
                user_info=user_info
            )
        else:
            # Handle user tokens and service tokens: use the tenant_id /
            # namespace_id carried in user_info when the token provides them.
            return cls(
                # Delegated tokens set sub="user:<uuid>" but include a raw "user_id" field.
                # Prefer "user_id" (raw UUID) when present; otherwise strip "user:" prefix
                # from sub so downstream created_by/updated_by columns get a clean UUID.
                id=user_info.get("user_id") or user_info.get("sub", "").removeprefix("user:"),
                email=user_info.get("email") or ("internal@pantheon.local" if is_internal else ""),
                name=user_info.get("name") if not is_internal else "Internal Service",
                tenant_id=user_info.get("tenant_id"),  # Use from user_info (internal services get looked-up values)
                tenant_name=user_info.get("tenant_name"),
                namespace_id=user_info.get("namespace_id"),  # Use from user_info (internal services get looked-up values)
                roles=user_info.get("roles", []) if not is_internal else ["internal_service"],
                permissions=user_info.get("permissions", []) if not is_internal else ["*"],  # Wildcard for internal services
                is_internal=is_internal,
                is_active=user_info.get("is_active", True),
                is_verified=user_info.get("is_verified", False),
                user_info=user_info
            )

    def has_permission(self, permission: str) -> bool:
        """Check if user has a specific permission."""
        if self.is_internal:
            return True  # Internal services have all permissions
        return permission in self.permissions

    def has_role(self, role: str) -> bool:
        """Check if user has a specific role."""
        if self.is_internal:
            return True  # Internal services have all roles
        return role in self.roles

    def has_cross_tenant_access(self) -> bool:
        """Check if user has cross-tenant access permissions."""
        if self.is_internal:
            return True  # Internal services have cross-tenant access
        # ONE definition of the grant, shared with IAMContext.can_cross_tenant() (I-79 shared review 4).
        from .iam.context import has_cross_tenant_grant  # lazy: iam imports this module
        if not has_cross_tenant_grant(self.roles, self.permissions):
            return False
        # ⛔ OI-28: an admin role crosses tenants only in the PLATFORM tenant; a customer
        # tenant's own super_admin is confined to it. Role check first, so ordinary users
        # never trigger the auth-DB lookup.
        return self._in_platform_tenant()

    def _in_platform_tenant(self) -> bool:
        """The OI-28 platform-tenant rule, shared with IAMContext.can_cross_tenant()."""
        from .iam.bootstrap import IAMBootstrapHelper  # lazy: iam imports this module
        return IAMBootstrapHelper.is_platform_tenant(self.tenant_id)

    def is_impersonation_token(self) -> bool:
        """
        Check if this is an impersonation token.

        Returns:
            True if the token_type claim is "impersonation", False otherwise
        """
        return self.user_info.get("token_type") == "impersonation"

    def requires_tenant_scoping(self) -> bool:
        """
        Check if tenant scoping should be applied for this user.

        Returns:
            True if tenant scoping should be applied (impersonation token or non-super-admin),
            False if user can access all tenants (super_admin without impersonation)
        """
        # Internal services don't need scoping
        if self.is_internal:
            return False

        # Impersonation tokens always require scoping to the impersonated tenant
        if self.is_impersonation_token():
            return True

        # Non-super-admin users are scoped to their tenant
        if "super_admin" not in self.roles and "system_admin" not in self.roles:
            return True

        # ⛔ OI-28: only the PLATFORM tenant's super-admins (without impersonation) see all
        # tenants; a customer tenant's super_admin is scoped to its own tenant.
        return not self._in_platform_tenant()

    def get_tenant_scoping_filter(self) -> Optional[Dict[str, Any]]:
        """
        Get the tenant scoping filter for queries based on the token type.

        Returns:
            - None if no scoping needed (super-admin, internal service)
            - {"tenant_id": "<id>"} if scoping is required
        """
        if self.requires_tenant_scoping():
            return {"tenant_id": self.tenant_id}
        return None

    def to_dict(self) -> Dict[str, Any]:
        """Convert user to dictionary representation."""
        return {
            "id": self.id,
            "email": self.email,
            "name": self.name,
            "tenant_id": self.tenant_id,
            "namespace_id": self.namespace_id,
            "roles": self.roles,
            "permissions": self.permissions,
            "is_internal": self.is_internal,
            "is_active": self.is_active,
            "is_verified": self.is_verified,
        }


def _get_auth_db_url() -> Optional[str]:
    """
    Get the auth database URL from environment variables.

    Tries multiple environment variable patterns to find the auth database URL.

    Returns:
        Auth database URL or None if not found
    """
    # Try direct env var first
    auth_db_url = os.getenv("PANTHEON_AUTH_DATABASE_URL")
    if auth_db_url:
        return auth_db_url

    # Try to derive from another service's database URL
    # Pattern: replace the service name with "pantheon_auth"
    for env_key in ["PANTHEON_RAG_DATABASE_URL", "PANTHEON_DATABASE_URL", "DATABASE_URL"]:
        db_url = os.getenv(env_key)
        if db_url:
            # Convert: postgresql://.../pantheon_rag -> postgresql://.../pantheon_auth
            # or postgresql://.../torana -> postgresql://.../pantheon_auth
            auth_db_url = db_url.rsplit("/", 1)[0] + "/pantheon_auth"
            # Remove async driver if present
            if "asyncpg" in auth_db_url:
                auth_db_url = auth_db_url.replace("+asyncpg", "").replace("postgresql+asyncpg", "postgresql")
            return auth_db_url

    return None


def _lookup_tenant_id(tenant_name: str) -> Optional[str]:
    """
    Look up tenant ID from the auth database.

    Args:
        tenant_name: Name of the tenant to look up

    Returns:
        Tenant UUID or None if lookup fails
    """
    auth_db_url = _get_auth_db_url()
    if not auth_db_url:
        logger.warning(f"Could not find auth database URL for tenant lookup")
        return None

    try:
        # Set application_name for connection tracking
        app_name = os.getenv("APPLICATION_NAME", "pantheon-service")
        engine = create_engine(
            auth_db_url,
            connect_args={
                "application_name": f"{app_name}-tenant-lookup"
            }
        )
        with engine.connect() as conn:
            result = conn.execute(
                text("SELECT id FROM tenants WHERE name = :tenant_name"),
                {"tenant_name": tenant_name}
            ).fetchone()

            if result:
                tenant_id = str(result[0])
                logger.info(f"Resolved tenant_id={tenant_id} for tenant='{tenant_name}'")
                return tenant_id
            else:
                logger.warning(f"Tenant '{tenant_name}' not found in auth database")
                return None
    except Exception as e:
        logger.warning(f"Failed to look up tenant ID for '{tenant_name}': {e}")
        return None
    finally:
        if 'engine' in locals():
            engine.dispose()


def _lookup_namespace_id(tenant_id: str, namespace_name: str) -> Optional[str]:
    """
    Look up namespace ID from the auth database.

    Args:
        tenant_id: Tenant UUID
        namespace_name: Name of the namespace to look up

    Returns:
        Namespace UUID or None if lookup fails
    """
    auth_db_url = _get_auth_db_url()
    if not auth_db_url:
        logger.warning(f"Could not find auth database URL for namespace lookup")
        return None

    try:
        # Set application_name for connection tracking
        app_name = os.getenv("APPLICATION_NAME", "pantheon-service")
        engine = create_engine(
            auth_db_url,
            connect_args={
                "application_name": f"{app_name}-namespace-lookup"
            }
        )
        with engine.connect() as conn:
            result = conn.execute(
                text("""
                    SELECT id FROM namespaces
                    WHERE name = :namespace_name AND tenant_id = :tenant_id
                """),
                {"namespace_name": namespace_name, "tenant_id": tenant_id}
            ).fetchone()

            if result:
                namespace_id = str(result[0])
                logger.info(f"Resolved namespace_id={namespace_id} for namespace='{namespace_name}'")
                return namespace_id
            else:
                logger.warning(f"Namespace '{namespace_name}' not found for tenant_id={tenant_id}")
                return None
    except Exception as e:
        logger.warning(f"Failed to look up namespace ID for '{namespace_name}': {e}")
        return None
    finally:
        if 'engine' in locals():
            engine.dispose()


async def get_current_user(
    request: Request,
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
    jwt_secret_key: str = None,
    jwt_algorithm: str = "HS256",
    allow_testing_tokens: bool = False
) -> AuthenticatedUser:
    """
    Get current authenticated user with support for internal service bypass.

    SECURITY: ``jwt_secret_key``, ``jwt_algorithm`` and ``allow_testing_tokens``
    are TRUSTED, SERVER-SIDE parameters. They are deliberately hidden from FastAPI
    by the ``__signature__`` override applied immediately after this definition
    (see ``_http_safe_auth_signature``), so a caller can never supply them over
    HTTP. Do NOT remove that override: without it FastAPI treats these plain
    scalars as caller-supplied QUERY PARAMETERS, letting an attacker append
    ``?jwt_secret_key=<their-own-secret>`` and have the server validate a forged
    token against a key the attacker chose - a full authentication bypass on
    every endpoint that uses this function as a dependency (issue #247).

    Args:
        request: FastAPI request object
        credentials: JWT authorization credentials (optional)
        jwt_secret_key: Secret key for JWT validation (auto-read from JWT_SECRET_KEY env var if not provided).
            Server-side only - never accepted from the request.
        jwt_algorithm: JWT algorithm (auto-read from JWT_ALGORITHM env var if not provided).
            Server-side only - never accepted from the request.
        allow_testing_tokens: Allow fake tokens for testing. Server-side only.

    Returns:
        AuthenticatedUser: User information with internal service flag

    Raises:
        HTTPException: If authentication fails and no internal bypass header is present
        ValueError: If jwt_secret_key is not provided and not found in environment
    """
    # Auto-read JWT configuration from environment if not provided
    if jwt_secret_key is None:
        jwt_secret_key = os.getenv("JWT_SECRET_KEY")
        if jwt_secret_key is None:
            raise ValueError("jwt_secret_key must be provided or JWT_SECRET_KEY environment variable must be set")

    if jwt_algorithm == "HS256":  # Only override if it's the default
        env_algorithm = os.getenv("JWT_ALGORITHM")
        if env_algorithm:
            jwt_algorithm = env_algorithm

    # Require valid JWT token if credentials are provided
    if not credentials:
        raise HTTPException(
            status_code=401,
            detail="Authentication Required",
            headers={"WWW-Authenticate": "Bearer"}
        )

    try:
        # Validate JWT token
        user_info = decode_jwt_token(
            credentials.credentials,
            jwt_secret_key,
            jwt_algorithm,
            allow_testing_tokens
        )
    except ValueError as e:
        # JWT decode errors
        raise HTTPException(
            status_code=401,
            detail="Invalid or expired authentication token",
            headers={"WWW-Authenticate": "Bearer"}
        )

    if not user_info:
        raise HTTPException(
            status_code=401,
            detail="Invalid or expired authentication token",
            headers={"WWW-Authenticate": "Bearer"}
        )

    #logger.debug("JWT authentication successful",
    #           user_id=user_info.get("sub"),
    #           email=user_info.get("email"))

    user = AuthenticatedUser.from_token(user_info=user_info, is_internal=False)
    request.state.current_user = user
    # I-65: resolve_tenant_filter is handed only the user; it reads method/route/act-as headers from here.
    from .iam.cross_tenant import bind_request
    bind_request(request)
    return user


async def get_current_user_strict(
    request: Request,
    credentials: HTTPAuthorizationCredentials = Depends(HTTPBearer()),
    jwt_secret_key: str = None,
    jwt_algorithm: str = "HS256",
    allow_testing_tokens: bool = False
) -> AuthenticatedUser:
    """
    Get current authenticated user without internal service bypass.

    Use this endpoint for security-sensitive operations that should
    never allow internal bypass (e.g., password changes, SSO setup).

    SECURITY: as with ``get_current_user``, the JWT configuration parameters are
    server-side only and are hidden from FastAPI by the ``__signature__`` override
    applied below. See that function's docstring and issue #247.

    Args:
        credentials: JWT authorization credentials (required)
        jwt_secret_key: Secret key for JWT validation. Server-side only.
        jwt_algorithm: JWT algorithm (default: HS256). Server-side only.
        allow_testing_tokens: Allow fake tokens for testing. Server-side only.

    Returns:
        AuthenticatedUser: User information (internal flag always False)

    Raises:
        HTTPException: If authentication fails
        ValueError: If jwt_secret_key is not provided and JWT_SECRET_KEY is unset
    """
    # Read the JWT configuration from the environment when a trusted caller did
    # not supply it. This mirrors get_current_user and is REQUIRED now that the
    # parameters are no longer injectable over HTTP (issue #247): before the fix
    # this function could only be used as a bare FastAPI dependency by having
    # the caller supply the secret as a query parameter, which was the bug.
    if jwt_secret_key is None:
        jwt_secret_key = os.getenv("JWT_SECRET_KEY")
        if jwt_secret_key is None:
            raise ValueError(
                "jwt_secret_key must be provided or JWT_SECRET_KEY environment "
                "variable must be set"
            )

    if jwt_algorithm == "HS256":  # Only override if it's the default
        env_algorithm = os.getenv("JWT_ALGORITHM")
        if env_algorithm:
            jwt_algorithm = env_algorithm

    # Validate JWT token (no bypass allowed)
    try:
        user_info = decode_jwt_token(
            credentials.credentials,
            jwt_secret_key,
            jwt_algorithm,
            allow_testing_tokens
        )
    except ValueError:
        # decode_jwt_token raises ValueError for expired/invalid tokens. Without
        # this handler the exception escaped as a 500 with a stack trace instead
        # of the 401 the caller expects (and get_current_user already returns).
        raise HTTPException(
            status_code=401,
            detail="Invalid or expired authentication token",
            headers={"WWW-Authenticate": "Bearer"}
        )

    if not user_info:
        raise HTTPException(
            status_code=401,
            detail="Invalid or expired authentication token",
            headers={"WWW-Authenticate": "Bearer"}
        )

    logger.debug("Strict JWT authentication successful",
                 user_id=user_info.get("sub"),
                 email=user_info.get("email"))

    user = AuthenticatedUser.from_token(user_info=user_info, is_internal=False)
    request.state.current_user = user
    # I-65: resolve_tenant_filter is handed only the user; it reads method/route/act-as headers from here.
    from .iam.cross_tenant import bind_request
    bind_request(request)
    return user


# ---------------------------------------------------------------------------
# SECURITY (issue #247): hide the JWT configuration parameters from FastAPI.
#
# ``get_current_user`` / ``get_current_user_strict`` are used directly as
# FastAPI dependencies across 12 services. FastAPI builds a dependency's
# request-parsing contract by INTROSPECTING its signature, and any plain scalar
# parameter that is not a recognised request object becomes a caller-supplied
# QUERY PARAMETER. That turned ``jwt_secret_key`` into an attacker-controlled
# input: forge a token with your own secret, append
# ``?jwt_secret_key=<that-secret>``, and the server happily validates the
# forgery against the key you supplied - full authentication bypass on every
# endpoint using these dependencies (~1,300 operations).
#
# Overriding ``__signature__`` makes FastAPI see ONLY ``request`` and
# ``credentials``. The parameters remain real Python parameters, so trusted
# server-side callers (the dependency factories below, pantheon-admin's strict
# wrapper, and tests) can still pass them as keyword arguments - they simply
# can no longer be reached over HTTP, and they no longer appear in the
# generated OpenAPI schema.
#
# NOTE: making the parameters keyword-only (``*``) does NOT work - FastAPI
# still injects keyword-only scalars as query parameters. This was measured;
# do not "simplify" this back into a ``*`` and assume it is equivalent.
#
# ``test_auth_no_injectable_secret.py`` fails if these overrides are removed.
# ---------------------------------------------------------------------------

def _http_safe_auth_signature(credentials_default, credentials_annotation) -> inspect.Signature:
    """Build the signature FastAPI is allowed to see for an auth dependency."""
    return inspect.Signature([
        inspect.Parameter(
            "request",
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            annotation=Request,
        ),
        inspect.Parameter(
            "credentials",
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
            default=credentials_default,
            annotation=credentials_annotation,
        ),
    ])


# Names FastAPI must never see on an auth dependency, asserted by the tests.
NON_INJECTABLE_AUTH_PARAMS = ("jwt_secret_key", "jwt_algorithm", "allow_testing_tokens")

get_current_user.__signature__ = _http_safe_auth_signature(
    credentials_default=Depends(security),
    credentials_annotation=Optional[HTTPAuthorizationCredentials],
)

get_current_user_strict.__signature__ = _http_safe_auth_signature(
    credentials_default=Depends(HTTPBearer()),
    credentials_annotation=HTTPAuthorizationCredentials,
)


def require_permission(permission: str):
    """
    Dependency factory to require specific permission.

    Args:
        permission: Required permission name

    Returns:
        Dependency function that checks for the permission
    """
    async def permission_dependency(
        current_user: AuthenticatedUser = Depends(get_current_user)
    ) -> AuthenticatedUser:
        # Internal services have all permissions by default
        if current_user.is_internal:
            return current_user

        # Check if user has the required permission
        if not current_user.has_permission(permission):
            raise HTTPException(
                status_code=403,
                detail=f"Insufficient permissions. Required: {permission}",
                headers={"WWW-Authenticate": "Bearer"}
            )

        return current_user

    return permission_dependency


def require_role(role: str):
    """
    Dependency factory to require specific role.

    Args:
        role: Required role name

    Returns:
        Dependency function that checks for the role
    """
    async def role_dependency(
        current_user: AuthenticatedUser = Depends(get_current_user)
    ) -> AuthenticatedUser:
        # Internal services have all roles by default
        if current_user.is_internal:
            return current_user

        # Check if user has the required role
        if not current_user.has_role(role):
            raise HTTPException(
                status_code=403,
                detail=f"Insufficient role. Required: {role}",
                headers={"WWW-Authenticate": "Bearer"}
            )

        return current_user

    return role_dependency


def create_jwt_auth_dependency(
    jwt_secret_key: str,
    jwt_algorithm: str = "HS256",
    allow_testing_tokens: bool = False,
) -> Callable:
    """
    Factory to create JWT authentication dependencies with custom configuration.

    Args:
        jwt_secret_key: Secret key for JWT validation
        jwt_algorithm: JWT algorithm (default: HS256)
        allow_testing_tokens: Allow fake tokens for testing

    Returns:
        FastAPI dependency function
    """
    async def jwt_dependency(
        request: Request,
        credentials: Optional[HTTPAuthorizationCredentials] = Depends(security)
    ) -> AuthenticatedUser:
        return await get_current_user(
            request=request,
            credentials=credentials,
            jwt_secret_key=jwt_secret_key,
            jwt_algorithm=jwt_algorithm,
            allow_testing_tokens=allow_testing_tokens
        )

    return jwt_dependency


def create_permission_dependency(
    jwt_secret_key: str,
    permission: str,
    jwt_algorithm: str = "HS256",
    allow_testing_tokens: bool = False
) -> Callable:
    """
    Factory to create permission-based dependencies with custom JWT configuration.

    Args:
        jwt_secret_key: Secret key for JWT validation
        permission: Required permission
        jwt_algorithm: JWT algorithm (default: HS256)
        allow_testing_tokens: Allow fake tokens for testing

    Returns:
        FastAPI dependency function that checks for the permission
    """
    async def permission_dependency(
        request: Request,
        credentials: Optional[HTTPAuthorizationCredentials] = Depends(security)
    ) -> AuthenticatedUser:
        current_user = await get_current_user(
            request=request,
            credentials=credentials,
            jwt_secret_key=jwt_secret_key,
            jwt_algorithm=jwt_algorithm,
            allow_testing_tokens=allow_testing_tokens
        )

        if not current_user.has_permission(permission):
            raise HTTPException(
                status_code=403,
                detail=f"Insufficient permissions. Required: {permission}",
                headers={"WWW-Authenticate": "Bearer"}
            )

        return current_user

    return permission_dependency


# ---------------------------------------------------------------------------
# Internal-only endpoint dependency (issue #171)
#
# The replacement for the ``pantheon-app`` header bypass. Promoted into
# pantheon-shared from the proven original in pantheon-detection-framework
# (``api/routes/internal_query.py``) so every service uses one implementation.
#
# Apply it router-level at the include site, e.g.
#     internal_dep = [Depends(require_internal_caller)]
#     app.include_router(internal_cleanup.router, dependencies=internal_dep)
# ---------------------------------------------------------------------------

_internal_bearer = HTTPBearer(auto_error=False)

#: EM S-33: what `require_internal_caller` does with a caller it would refuse. `warn` (the code default, for now)
#: lets the call through and logs one `internal_caller.refused` WARNING; `enforce` answers 403. Read on every call,
#: so `dev-compose reload-env <svc>` flips it without a rebuild. Any other value is treated as `enforce`
#: (fail closed): a typo must never leave the door open.
INTERNAL_CALLER_GUARD_MODE_ENV = "INTERNAL_CALLER_GUARD_MODE"
INTERNAL_CALLER_GUARD_MODE_DEFAULT = "warn"


def internal_caller_guard_mode() -> str:
    """`warn` or `enforce` (EM S-33). Unset → the code default; anything unknown → `enforce`."""
    raw = (os.getenv(INTERNAL_CALLER_GUARD_MODE_ENV) or INTERNAL_CALLER_GUARD_MODE_DEFAULT).strip().lower()
    if raw in ("warn", "enforce"):
        return raw
    logger.error("internal_caller.guard_mode_invalid", value=raw, applied="enforce")
    return "enforce"


def internal_caller_refusal(user: AuthenticatedUser) -> Optional[str]:
    """Why `user` may NOT call an internal route, or None when it may (EM S-33, option B). Pure; tests use it.

    Allowed:
      - a PLATFORM service token: `sub` = `service:<name>` (`is_service_token`) and no `token_kind`.
        ⛔ pantheon-auth also mints `service:` tokens that a CUSTOMER holds: the CI scan tokens
        (`sub` = `service:github-ci-scan:<repo>`, `token_kind` = `ci_github_oidc` / `ci_gitlab_oidc`). They sit in a
        customer's CI runner, so they are refused here like any customer user token.
      - a PLATFORM super admin: the I-96/I-97 rule (`cross_tenant._platform_admin_refusal`): the super_admin role
        AND the platform tenant, never the role name alone, never an impersonation token.
      - a DELEGATED token (`is_delegated_token`): a platform service acting for a user, e.g. pantheon-program-framework
        installing an app bundle. pantheon-auth writes `delegated_by` only at POST /api/v1/internal/tokens/delegated,
        behind PANTHEON_SERVICE_MINT_SECRET; no public route sets it (Bhakta, 2026-11-07, option (i)).
    Refused: every other user token, including a customer tenant's own super_admin (OI-28); a delegated token that
    carries a `token_kind` (agent_tool, sandbox_cli) or is an impersonation token."""
    info = dict(user.user_info or {})
    kind = str(info.get("token_kind") or "")
    if kind:
        # Any kind, on ANY token (a delegated sandbox token is a user token): a customer holds or steers it.
        return f"a customer-held or customer-steered token (token_kind={kind}) is not a platform caller"
    if is_service_token(info):
        return None
    if is_delegated_token(info):
        return None
    from .iam.cross_tenant import _platform_admin_refusal  # lazy: iam imports this module
    reason = _platform_admin_refusal(user)
    if reason is None:
        return None
    return f"a user token must be a platform super admin ({reason})"


#: EM S-33 option (i): the services whose delegated tokens may call internal routes. Comma-separated; the code
#: default is the one caller that needs it today (the app-bundle install). ⛔ Never add pantheon-agent-builder: its
#: tool calls are LLM-steered (em5, 2026-11-07: an agent tool call reached another tenant's internal cleanup).
INTERNAL_DELEGATED_CALLERS_ENV = "INTERNAL_CALLER_DELEGATED_SERVICES"
INTERNAL_DELEGATED_CALLERS_DEFAULT = "pantheon-program-framework"
_DELEGATED_ISSUER = "pantheon-auth"
_DELEGATED_AUDIENCE = "pantheon-services"


def internal_delegated_callers() -> frozenset:
    """The allowlist, read on every call (like the guard mode). An empty value means no delegated caller at all."""
    raw = os.getenv(INTERNAL_DELEGATED_CALLERS_ENV)
    if raw is None:
        raw = INTERNAL_DELEGATED_CALLERS_DEFAULT
    return frozenset(s.strip() for s in raw.split(",") if s.strip())


def _audience_ok(aud) -> bool:
    if isinstance(aud, (list, tuple)):
        return _DELEGATED_AUDIENCE in aud
    return aud == _DELEGATED_AUDIENCE


def is_delegated_token(info: dict) -> bool:
    """A token pantheon-auth minted for an ALLOWLISTED platform service acting for a user (EM S-33, option (i)).

    All of: `delegated_by` is in `internal_delegated_callers()`, `sub` is `user:<id>`, `iss` = pantheon-auth and `aud`
    = pantheon-services (what pantheon-auth's delegated mint writes), no `token_kind` (agent_tool / sandbox_cli tokens
    are delegated too, but a customer steers them), and not an impersonation token."""
    return (
        str(info.get("delegated_by") or "").strip() in internal_delegated_callers()
        and str(info.get("sub") or "").startswith("user:")
        and info.get("iss") == _DELEGATED_ISSUER
        and _audience_ok(info.get("aud"))
        and not info.get("token_kind")
        and info.get("token_type") != "impersonation"
    )


def _caller_kind(user: AuthenticatedUser) -> str:
    info = dict(user.user_info or {})
    kind = str(info.get("token_kind") or "")
    if kind:
        # EM S-33 m1: the kind itself (agent_tool / sandbox_cli / ci_github_oidc / ...), never a lumped label.
        return kind
    if is_service_token(info):
        return "service"
    if info.get("token_type") == "impersonation":
        return "impersonation"
    if is_delegated_token(info):
        return "delegated"
    if "super_admin" in (user.roles or []):
        return "customer_super_admin"
    return "user"


def require_internal_caller(
    request: Request,
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(_internal_bearer),
) -> AuthenticatedUser:
    """Require a genuine Bearer JWT of a PLATFORM caller for an internal-only endpoint.

    Takes NO ``tenant_id`` (so it composes with ``/tenant/{tenant_id}`` path routes --
    ``IAMEndpoint.get_iam_context`` cannot: it declares ``tenant_id`` as a
    Query param and raises AssertionError at import time on such a route).
    ``request`` is read ONLY for the refusal log line (method + path); no header
    or other request field ever grants access.

    EM S-33 (option B): accepts a platform service token or a platform super admin
    (`internal_caller_refusal`). A token carrying any ``token_kind`` (agent_tool,
    sandbox_cli, a CI token) is 403 in EVERY mode. Any other refused caller: 403 under
    ``INTERNAL_CALLER_GUARD_MODE=enforce``, let through with one
    ``internal_caller.refused`` WARNING under ``warn`` (the current default), so a
    service that forwards a user token east-west shows up before enforcing.

    Returns a principal with ``is_internal=False`` on purpose -- ``True`` would
    force ``permissions=["*"]`` (see ``AuthenticatedUser.from_token``) and
    recreate the wildcard this replaces.
    """
    return _check_internal_caller(request, credentials, frozenset())


#: The only token_kind a route may opt in to (EM S-33, em5 M3 ruling B). sandbox_cli and CI kinds never.
OPT_IN_KINDS = frozenset({"agent_tool"})


def _opted_in_agent_call(user_info: dict, allow_kinds: frozenset) -> bool:
    """An agent tool call this route opted in to: an allowed kind, minted by pantheon-auth, never an impersonation."""
    kind = str(user_info.get("token_kind") or "")
    sub = str(user_info.get("sub") or "")
    return (
        kind in allow_kinds
        and info_is_platform_minted(user_info)
        and user_info.get("token_type") != "impersonation"
        and (sub.startswith("service:") or (sub.startswith("user:") and bool(user_info.get("delegated_by"))))
    )


def info_is_platform_minted(user_info: dict) -> bool:
    return user_info.get("iss") == _DELEGATED_ISSUER and _audience_ok(user_info.get("aud"))


def internal_caller(*, allow_kinds=frozenset()):
    """`require_internal_caller` with a per-route opt-in: `Depends(internal_caller(allow_kinds={"agent_tool"}))`.

    Only `agent_tool` may be opted in; anything else raises at DEFINITION time (import), never at request time.
    A route that opts in MUST take its tenant from the token (`refuse_tenant_mismatch`), because the LLM picks the
    arguments. Every other caller is judged exactly as by `require_internal_caller`."""
    kinds = frozenset(allow_kinds)
    bad = kinds - OPT_IN_KINDS
    if bad:
        raise ValueError(f"internal_caller: token kinds {sorted(bad)} may never be opted in (only {sorted(OPT_IN_KINDS)})")

    def _dep(
        request: Request,
        credentials: Optional[HTTPAuthorizationCredentials] = Depends(_internal_bearer),
    ) -> AuthenticatedUser:
        return _check_internal_caller(request, credentials, kinds)

    _dep.__name__ = f"internal_caller_{'_'.join(sorted(kinds)) or 'default'}"
    return _dep


def refuse_tenant_mismatch(caller: AuthenticatedUser, *named_tenant_ids) -> None:
    """403 when an opted-in agent call names a tenant (body / query / path) other than its token's (EM S-33)."""
    info = dict(caller.user_info or {})
    if not info.get("token_kind"):
        return
    own = str(info.get("tenant_id") or "").strip().lower()
    for named in named_tenant_ids:
        if named is None or str(named).strip() == "":
            continue
        if str(named).strip().lower() != own:
            logger.warning("internal_caller.tenant_mismatch", caller_kind=str(info.get("token_kind")),
                           token_tenant_id=own, named_tenant_id=str(named))
            raise HTTPException(status_code=403, detail={
                "error": "tenant_mismatch",
                "message": "An agent call may only act on the tenant its token carries.",
            })


def _check_internal_caller(
    request: Request,
    credentials: Optional[HTTPAuthorizationCredentials],
    allow_kinds: frozenset,
) -> AuthenticatedUser:
    if credentials is None or not credentials.credentials:
        raise HTTPException(
            status_code=401,
            detail="Authentication required",
            headers={"WWW-Authenticate": "Bearer"},
        )

    jwt_secret_key = os.getenv("JWT_SECRET_KEY")
    if not jwt_secret_key:
        # Fail closed: without a secret we cannot validate anything.
        logger.error("require_internal_caller: JWT_SECRET_KEY is not configured")
        raise HTTPException(status_code=500, detail="Authentication is not configured")

    try:
        user_info = decode_jwt_token(
            credentials.credentials,
            jwt_secret_key,
            os.getenv("JWT_ALGORITHM", "HS256"),
        )
    except ValueError:
        raise HTTPException(
            status_code=401,
            detail="Invalid or expired authentication token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if not user_info:
        raise HTTPException(
            status_code=401,
            detail="Invalid or expired authentication token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if not str(user_info.get("tenant_id") or "").strip():
        # EM S-33 m2: a genuine signature with no tenant is not a usable principal (from_token would raise -> 500).
        raise HTTPException(
            status_code=401,
            detail="Authentication token carries no tenant",
            headers={"WWW-Authenticate": "Bearer"},
        )

    user = AuthenticatedUser.from_token(user_info=user_info, is_internal=False)
    if allow_kinds and _opted_in_agent_call(user_info, allow_kinds):
        # EM S-33 (em5 M3, ruling B): this ROUTE declared it accepts agent tool calls. The token carries the user's
        # tenant; the route must take its tenant from the token (refuse_tenant_mismatch), never from a param.
        logger.info(
            "internal_caller.accepted",
            mode=internal_caller_guard_mode(),
            caller_kind=str(user_info.get("token_kind")),
            sub=str(user_info.get("sub") or ""),
            token_tenant_id=str(user_info.get("tenant_id") or ""),
            method=request.method,
            path=request.url.path,
            x_service_name=request.headers.get("x-service-name", ""),
        )
        return user
    reason = internal_caller_refusal(user)
    if reason is None:
        if is_delegated_token(user_info):
            # Option (i): admitted, and visible: which service acted for which user on which route.
            logger.info(
                "internal_caller.accepted",
                mode=internal_caller_guard_mode(),
                caller_kind="delegated",
                delegated_by=str(user_info.get("delegated_by") or ""),
                sub=str(user_info.get("sub") or ""),
                token_tenant_id=str(user_info.get("tenant_id") or ""),
                method=request.method,
                path=request.url.path,
                x_service_name=request.headers.get("x-service-name", ""),
            )
        return user

    mode = internal_caller_guard_mode()
    logger.warning(
        "internal_caller.refused",
        mode=mode,
        caller_kind=_caller_kind(user),
        sub=str(user_info.get("sub") or ""),
        token_tenant_id=str(user_info.get("tenant_id") or ""),
        method=request.method,
        path=request.url.path,
        reason=reason,
        # EM S-33 m1: where it came from. INFORMATIONAL ONLY: these are caller-supplied or network facts and never
        # decide access.
        x_service_name=request.headers.get("x-service-name", ""),
        request_id=request.headers.get("x-request-id", ""),
        client_host=(request.client.host if request.client else ""),
    )
    # EM S-33 (em4 M1, option 1): a token carrying ANY token_kind is refused in EVERY mode. `warn` exists only for
    # the legacy kind-less east-west callers; kinds are new, so nothing legitimate depends on warn for them, and an
    # agent's tool token or the sandboxed CLI must never reach an internal route while the switch is still `warn`.
    if mode == "enforce" or user_info.get("token_kind"):
        raise HTTPException(status_code=403, detail={
            "error": "internal_caller_required",
            "message": f"This is an internal route: {reason}.",
        })
    return user
