"""
Pantheon shared utilities library.
"""

# Import logging utilities
from .logging import get_logger, setup_logging, setup_library_logging

# Import auth utilities (from auth.py file)
from .auth import get_current_user

# Import JWT and inter-service authentication
from .jwt import decode_jwt_token, create_jwt_token, validate_jwt_claims, refresh_jwt_token

# Import JWT token management
from .auth_internal import (
    InternalJWTManager,
    TokenCache
)

# Import HTTP client utilities
from .http import (
    PantheonClient,
    PantheonSyncClient,
    EastWestLogLevel,
    create_pantheon_client,
    create_pantheon_sync_client
)

# Import HTTP authentication utilities
from .http.auth import (
    get_service_url
)

# Import metrics API
from .metrics import router as metrics_router

# Import tracing control API
from .tracing_api import router as tracing_router
from .tracing import is_tracing_enabled, set_tracing_enabled

# Import version utilities
from .version import (get_version, VersionInfo, get_service_commit_sha,
                      get_service_build_info)

# Import version API
from .version_api import router as version_router

# Import startup-health API (pairs with locking.startup_state)
from .startup_api import router as startup_router

# Import database utilities
from .db import (
    TenantAwareQueryBuilder,
    QueryExecutor,
    add_tenant_filter_to_sql
)

# Import interactive authentication
from .interactive_auth import (
    InteractiveAuth,
    AuthenticationError,
    get_authenticated_session
)

# Import tracing utilities (for distributed tracing)
from .tracing import (
    TraceContext,
    TracingMiddleware,
    TracingConfig,
    setup_tracing,
    get_current_trace_context,
    SpanManager,
)

# Import locking utilities (for multi-worker coordination)
from .locking import PostgresLockCoordinator, postgres_lock_coordinator

# Import LLM utilities (for retry logic on LLM API calls)
from .llm import (
    async_llm_retry,
    llm_retry,
    LLMRetryConfig,
    is_empty_llm_response,
    # Metrics
    LLMCallMetrics,
    LLM_METRICS_ENABLED,
    get_llm_metrics_registry,
    get_or_create_llm_metrics,
    reset_llm_metrics,
    get_all_llm_metrics,
    calculate_llm_summary,
)

# Import generic retry utilities (for health checks, service initialization, etc.)
from .utils import (
    async_retry,
    RetryConfig,
)

# Import cache context utilities (for identifying Gemini cache entries)
from .cache_context import (
    set_cache_context,
    get_cache_context,
    get_cache_context_suffix,
    clear_cache_context,
    CacheContext,
)

# Import database pool settings mixin
from .config.database_pool_settings import DatabasePoolSettings

__all__ = [
    # Logging
    "get_logger",
    "setup_logging",
    "setup_library_logging",

    # Original auth
    "get_current_user",

    # JWT utilities
    "decode_jwt_token",
    "create_jwt_token",
    "validate_jwt_claims",
    "refresh_jwt_token",

    # JWT token management
    "InternalJWTManager",
    "TokenCache",

    # HTTP clients
    "PantheonClient",
    "PantheonSyncClient",
    "EastWestLogLevel",
    "create_pantheon_client",
    "create_pantheon_sync_client",

    # HTTP authentication
    "get_service_url",

    # Metrics API
    "metrics_router",

    # Version
    "get_version",
    "VersionInfo",
    "get_service_build_info",
    "get_service_commit_sha",
    "version_router",
    "startup_router",

    # Database utilities
    "TenantAwareQueryBuilder",
    "QueryExecutor",
    "add_tenant_filter_to_sql",

    # Interactive authentication
    "InteractiveAuth",
    "AuthenticationError",
    "get_authenticated_session",

    # Distributed tracing
    "TraceContext",
    "TracingMiddleware",
    "TracingConfig",
    "setup_tracing",
    "get_current_trace_context",
    "SpanManager",
    "tracing_router",
    "is_tracing_enabled",
    "set_tracing_enabled",

    # Locking utilities
    "PostgresLockCoordinator",
    "postgres_lock_coordinator",

    # LLM utilities
    "async_llm_retry",
    "llm_retry",
    "LLMRetryConfig",
    "is_empty_llm_response",
    # LLM metrics
    "LLMCallMetrics",
    "LLM_METRICS_ENABLED",
    "get_llm_metrics_registry",
    "get_or_create_llm_metrics",
    "reset_llm_metrics",
    "get_all_llm_metrics",
    "calculate_llm_summary",

    # Generic retry utilities
    "async_retry",
    "RetryConfig",

    # Cache context utilities
    "set_cache_context",
    "get_cache_context",
    "get_cache_context_suffix",
    "clear_cache_context",
    "CacheContext",

    # Database pool settings mixin
    "DatabasePoolSettings",
]
