"""
Cross-service schemas for detection-framework signal endpoints (Phase 2 §2.1).

Imported by:
  - pantheon-detection-framework  (response serialization)
  - pantheon-program-framework    (signal tool deserialization)
"""
from __future__ import annotations

from datetime import datetime
from typing import Literal, Optional
from uuid import UUID

from pydantic import BaseModel, ConfigDict

ExecutionStatusLiteral = Literal[
    "SUCCESS", "FAILED", "TIMEOUT", "CANCELLED", "RUNNING", "QUEUED"
]


class CitationDataRef(BaseModel):
    """Reference to a specific column in a data source used to justify a proposal."""

    model_config = ConfigDict(extra="forbid")

    source: str
    column: str


class RuleRunStats(BaseModel):
    """Per-rule execution statistics over a lookback window."""

    model_config = ConfigDict(extra="forbid")

    rule_id: UUID
    rule_name: str
    runs: int
    alerts_emitted: int
    alert_emit_rate: float
    result_count_p50: Optional[float]
    result_count_p95: Optional[float]
    last_run_at: Optional[datetime]
    last_status: Optional[ExecutionStatusLiteral]


class RuleRunStatsResponse(BaseModel):
    """Response for GET /api/v1/rules/{rule_id}/run-stats."""

    model_config = ConfigDict(extra="forbid")

    stats: list[RuleRunStats]
    rules_total: int
    rules_returned: int
    truncated: bool


class AlertDispositionByRule(BaseModel):
    """Per-rule alert disposition breakdown."""

    model_config = ConfigDict(extra="forbid")

    rule_id: UUID
    open: int
    dispositions_recorded: int
    false_positive_rate: Optional[float]


class AlertDispositionStats(BaseModel):
    """Response for GET /api/v1/alerts/disposition-summary."""

    model_config = ConfigDict(extra="forbid")

    total_open: int
    total_closed: int
    unassigned: int
    total_dispositions_recorded: int
    by_severity: dict[str, int]
    by_rule: list[AlertDispositionByRule]
    median_time_to_triage_seconds: Optional[float]
    oldest_open_age_seconds: Optional[float]
    rules_total: int
    rules_returned: int
    truncated: bool
