"""The contract for a rule's `alert_field_map`, in ONE place.

⛔ WHY THIS MOVED OUT OF THE DETECTION FRAMEWORK. The rule's contract with the alert
— which keys a map may carry, which of them name a result column, what a display-column
entry looks like — was written twice by hand: in
`pantheon-detection-framework/src/pantheon/services/alert_field_map.py`, which owns it,
and again in `pantheon-program-framework/.../schemas/build_v2_definitions.py`, which
gates every bundle-authored rule at deposit. The second copy carried a comment saying
the first was the authority and that drift "fails loudly at deploy".

It does not fail loudly. It fails INVISIBLY, in both directions, and both happened:

  * `triage_fields` was added to the detection framework on 2026-09-24 with a column and
    a migration. program-framework's copy did not have it, so every bundle-authored rule
    carrying it was refused at deposit — "unknown key(s) ['triage_fields']" — and the key
    could never reach the platform at all. It was removed the next day, unused.
  * `group_attrs` went the other way, landing only in program-framework.

Neither was caught by `scripts/build_v2_contract_diff.py`, which compares Pydantic MODELS:
the allow-list is a frozenset inside a validator, so it is invisible to a model diff.

⭐ Living in `pantheon_shared` rather than being imported across services keeps the
program framework's original objection satisfied — it still does not depend on
detection-framework code — while making a second copy impossible.

⚠️ CHANGING THIS CHANGES BOTH SERVICES. The wheel is baked at image build, so a new key
reaches a running service only after that service is rebuilt. Add the key here, rebuild
detection-framework AND program-framework, then author a rule that uses it — in that
order, or the deposit refuses a key the platform already understands.
"""
from __future__ import annotations

from typing import Any, Dict, Optional

# Keys a rule's `alert_field_map` may carry.
ALERT_FIELD_MAP_KEYS = frozenset({
    "title", "description", "priority", "proposed_fix", "reason_code",
    "display_columns", "finding_severity",
})

# Of those, the ones whose value NAMES A COLUMN of the rule's result set (a non-empty
# string). `display_columns` is a list and is shape-checked separately.
ALERT_FIELD_MAP_COLUMN_KEYS = (
    "title", "description", "priority", "proposed_fix", "reason_code", "finding_severity",
)

MAX_DISPLAY_COLUMNS = 40

# What one `display_columns` entry may hold. `column` is required.
DISPLAY_COLUMN_ENTRY_KEYS = frozenset({"column", "label", "group"})


def validate_alert_field_map(
    value: Optional[Dict[str, Any]], *, prefix: str = "alert_field_map"
) -> Optional[Dict[str, Any]]:
    """Return the map unchanged, or raise ValueError naming exactly what is wrong.

    `prefix` is what the caller calls this field in ITS error messages — the detection
    framework says `alert_field_map`, the program framework says `rule.alert_field_map`
    — so one implementation can serve both without either service's messages changing.

    ⚠️ Validation only. Resolving a map against a matched row stays in the detection
    framework: that needs the row, and nothing else should be doing it.
    """
    if value is None:
        return None
    if not isinstance(value, dict):
        raise ValueError(f"{prefix} must be an object")

    unknown = sorted(set(value) - ALERT_FIELD_MAP_KEYS)
    if unknown:
        raise ValueError(
            f"{prefix} has unknown key(s) {unknown}; "
            f"allowed: {sorted(ALERT_FIELD_MAP_KEYS)}"
        )

    for key in ALERT_FIELD_MAP_COLUMN_KEYS:
        if key in value and (not isinstance(value[key], str) or not value[key].strip()):
            raise ValueError(f"{prefix}.{key} must name a result column")

    cols = value.get("display_columns")
    if cols is not None:
        if not isinstance(cols, list) or len(cols) > MAX_DISPLAY_COLUMNS:
            raise ValueError(
                f"{prefix}.display_columns must be a list of at most {MAX_DISPLAY_COLUMNS}"
            )
        for entry in cols:
            if not isinstance(entry, dict) or not isinstance(entry.get("column"), str) \
                    or not entry["column"].strip():
                raise ValueError(
                    f"each {prefix}.display_columns entry needs a 'column' string")
            extra = sorted(set(entry) - DISPLAY_COLUMN_ENTRY_KEYS)
            if extra:
                raise ValueError(
                    f"{prefix}.display_columns entry has unknown key(s) {extra}")
    return value


def alert_field_map_contract() -> Dict[str, Any]:
    """The contract as data, for publishing to a build driver.

    ⭐ So the build path can tell an author which keys exist BEFORE a deposit is spent,
    instead of discovering it from a refusal. Served on
    `GET /api/v1/build-v2/capabilities`.
    """
    return {
        "allowed_keys": sorted(ALERT_FIELD_MAP_KEYS),
        "column_keys": list(ALERT_FIELD_MAP_COLUMN_KEYS),
        "max_display_columns": MAX_DISPLAY_COLUMNS,
        "display_column_entry_keys": sorted(DISPLAY_COLUMN_ENTRY_KEYS),
    }
