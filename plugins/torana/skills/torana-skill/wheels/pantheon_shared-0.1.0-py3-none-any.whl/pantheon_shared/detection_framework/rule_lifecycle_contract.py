"""What a rule's `lifecycle` settings may say — the contract both services validate against.

⛔ WHY IT LIVES HERE. The same lesson as `alert_field_map_contract`: a rule key validated
in two hand-written places drifts in both directions. `triage_fields` was added to the
detection framework alone and refused at deposit by program-framework's own allow-list, so
it shipped unusable; `finding_severity` went the other way. One definition, imported by
both, makes that impossible.

⛔ WHY LIFECYCLE IS OPT-IN AT ALL. A rule's SQL does not say whether it describes a
standing condition or an event:

  * "this upgrade is still needed" — when the row stops matching, the item SHOULD end.
  * "a login from a new country happened" — when the row stops matching, the item MUST
    stay. The event still happened.

Closing an event item would destroy a record, so the platform must not guess. `NULL` means
off, which is every rule that exists today.
"""
from __future__ import annotations

from typing import Any, Dict, Optional

#: The resolution reasons ONLY the lifecycle may write, and therefore the only values a
#: rule's `reason_map`, `default_reason` or `absence_reason` may name.
#:
#: ⛔ IT LIVES HERE, NOT ONLY IN THE ALERT MODEL. The build path gates every
#: bundle-authored rule and cannot import the detection framework, so without this it
#: would accept a reason the platform then refuses — a rule that cooks, deploys and
#: silently never closes anything. That is the drift this package exists to stop.
#:
#: ⛔ `fixed` IS NOT IN THIS SET, deliberately. No reason the chain produces evidences a
#: repair by itself: "no longer reported by the scanner" is not a fix, and booking it as
#: one credits work nobody did. The fallback is `estate_resolved`.
LIFECYCLE_RESOLUTION_REASONS = frozenset({
    "closed_at_source", "dismissed_at_source", "no_longer_reported",
    "no_longer_deployed", "asset_removed", "merged",
    "below_policy", "out_of_scope",
    "rerouted", "condition_cleared",
    "estate_resolved",
})

#: Keys a `lifecycle` object may carry.
LIFECYCLE_KEYS = frozenset({
    "enabled", "reason_sql", "reason_map", "default_reason",
    "close_on_absence", "absence_reason", "conditions", "members_field",
})

#: The condition codes the PLATFORM emits. A rule's own declared condition may not reuse
#: one.
#:
#: ⛔ IT LIVES HERE FOR THE SAME REASON THE REASONS DO. The build path gates every
#: bundle-authored rule and cannot import the detection framework. Without this list it
#: would accept a rule declaring a condition called `high_close_share`, and the run record
#: would then carry two entries with that code meaning different things — one the
#: platform's measurement of the run, one the author's question about the data. A reader
#: could not tell them apart, and neither could an alert built on the code.
#:
#: ⚠️ ADDING A PLATFORM CODE CAN BREAK AN INSTALLED RULE. A code added here is refused on
#: the next save of any rule already declaring it. That is the right way round — the
#: platform's meaning wins — but it means a new code belongs in a release note, and the
#: name should be specific enough that nobody would have chosen it for their own question.
#:
#: ⚠️ RETIRED CODES STAY RESERVED so no rule author can claim one, but nothing emits them:
#:   `person_judged_not_closed` — retired by Phase 3 (the data may end work a person
#:   judged, keeping their verdict), with its emitter in the detection framework.
PLATFORM_CONDITION_CODES = frozenset({
    "rule_changed", "empty_answer", "all_items_closed", "high_close_share",
    "low_reason_share", "unexplained_absent",
    "person_judged_not_closed",  # retired, reserved (Phase 3)
    "rows_not_found", "live_without_item", "relation_not_swept", "stale_writes",
    "sweep_blocked", "relation_changed", "relation_not_tracked", "reasons_not_members",
    "condition_query_failed",
    # The box model (rows 3.33b and 3.33e).
    "reason_unknown", "person_override_held",
})

#: ⭐ OPTION B — a reason-map entry is either a reason string, or an object:
#:     "dismissed_by_triage": {"reason": "dismissed_at_source", "verdict": "false_positive"}
#: `verdict` is optional and allowed ONLY for these reasons. For every other reason the
#: platform's own table decides the verdict (closure_verdict in the detection framework),
#: so a verdict there is refused rather than silently ignored.
REASON_MAP_ENTRY_KEYS = frozenset({"reason", "verdict"})
REASON_MAP_VERDICTS = frozenset({"true_positive", "false_positive", "benign"})
REASON_MAP_VERDICT_REASONS = frozenset({"dismissed_at_source"})

#: The two columns a declared condition's `sql` must return.
CONDITION_SQL_COLUMNS = ("fired",)

#: The seven columns a `reason_sql` must return. The platform wraps the query with a
#: filter on the keys it needs and takes rank 1 as the headline.
#: Optional reason columns the platform reads when present (Phase 3 follow-up #3):
#:   `routed_to_key` — for a `rerouted` ending, the destination ENTRY's identity value (the
#:   value of its single identity field). With it the item shows "Moved to <entry>" when
#:   exactly one open entry carries that key; without it only the `routed_to` queue is named.
OPTIONAL_REASON_SQL_COLUMNS = ("routed_to_key",)

REASON_SQL_COLUMNS = (
    "entry_key", "reason_code", "reason_label", "reason_sentence",
    "routed_to", "n", "reason_rank",
)


def validate_rule_lifecycle(
    value: Optional[Dict[str, Any]],
    *,
    prefix: str = "lifecycle",
    allowed_reasons: Optional[frozenset] = LIFECYCLE_RESOLUTION_REASONS,
    emit_mode: Optional[str] = None,
    identity_fields: Optional[list] = None,
) -> Optional[Dict[str, Any]]:
    """Return the settings unchanged, or raise ValueError naming exactly what is wrong.

    `allowed_reasons` defaults to `LIFECYCLE_RESOLUTION_REASONS` above, so the build path
    and the platform refuse the same values without the build path importing the alert
    model. Pass `None` only to skip the check entirely.

    ⚠️ `emit_mode` and `identity_fields` are checked only when supplied. The build path
    knows both; a partial update may not, and re-deriving them here would mean guessing.
    """
    if value is None:
        return None
    if not isinstance(value, dict):
        raise ValueError(f"{prefix} must be an object")

    unknown = sorted(set(value) - LIFECYCLE_KEYS)
    if unknown:
        raise ValueError(
            f"{prefix} has unknown key(s) {unknown}; allowed: {sorted(LIFECYCLE_KEYS)}")

    enabled = value.get("enabled", False)
    if not isinstance(enabled, bool):
        raise ValueError(f"{prefix}.enabled must be true or false")
    if not enabled:
        return value                      # nothing else is load-bearing while it is off

    # ⛔ SELECTOR ONLY. A `sample` rule reports ten rows of many, so "not in the answer"
    # says nothing about the key — closing on it would end items at random. This is also
    # what excludes the older application's rules by KIND rather than by name.
    if emit_mode is not None and emit_mode != "selector":
        raise ValueError(
            f"{prefix}.enabled needs emit_mode 'selector'; this rule is '{emit_mode}'. "
            f"A sample rule reports a sample, so a key missing from its answer is not "
            f"evidence that anything ended.")
    if identity_fields is not None and not identity_fields:
        raise ValueError(f"{prefix}.enabled needs a non-empty identity_fields")

    for key in ("close_on_absence",):
        if key in value and not isinstance(value[key], bool):
            raise ValueError(f"{prefix}.{key} must be true or false")

    reason_map = value.get("reason_map")
    if reason_map is not None:
        if not isinstance(reason_map, dict):
            raise ValueError(f"{prefix}.reason_map must be an object of code -> reason")
        for code, entry in reason_map.items():
            if not isinstance(code, str) or not code.strip():
                raise ValueError(f"{prefix}.reason_map has a non-string code")
            _check_reason_map_entry(entry, f"{prefix}.reason_map[{code!r}]",
                                    allowed_reasons)

    for key in ("default_reason", "absence_reason"):
        if value.get(key) is not None:
            _check_reason(value[key], f"{prefix}.{key}", allowed_reasons)

    # ⛔ `close_on_absence` IS FOR A RULE WITH NO REASON QUERY, and reading it as "this
    # rule will not close on absence" is wrong — two careful readers did exactly that in
    # one evening (§ 3.10.15) and each filed a failed safety check. A rule WITH a reason
    # query closes an absent key whenever the estate explains where its findings went,
    # whatever this says, because that is evidence rather than silence. This setting
    # answers the other question: may a key that nothing can explain be closed merely for
    # having been gone for `rule_lifecycle_absence_runs` complete runs?
    if value.get("close_on_absence") and not value.get("absence_reason"):
        raise ValueError(
            f"{prefix}.close_on_absence needs an absence_reason: a key that stops being "
            f"reported has no reason of its own to read.")

    # ⛔ THE LIFECYCLE NEEDS A SINGLE-FIELD KEY — for EVERY rule, not only one with a
    # reason query. The platform has to recover a rule's identity VALUE from the Inbox key
    # (`<entity_type>:<field>=<value>`) twice over: to ask the reason query about a key,
    # and to fetch the row behind a reopen, a re-rate or a refresh. With several identity
    # fields that recovery is impossible — `compute_entity_id` joins `field=value` pairs
    # with "|" and does NOT escape a "|" inside a value, and real values contain them
    # ("CVE-2026-27448|pypi|pyop"), so the join cannot be undone.
    #
    # ⚠️ REFUSED AT SAVE TIME BECAUSE THE FAILURE IS SILENT. A multi-field rule would
    # save, run, and decide correctly — and then every write would find no row and be
    # skipped, the run would end `partial`, and nothing would error. A configuration that
    # looks like it works and does not is worse than one that is refused.
    #
    # This is a restriction, not an impossibility: the pass could store each row's
    # identity values on its observation and the worker could read them instead of
    # parsing the key. That needs a column, so it is a deliberate change, not a patch.
    if enabled and identity_fields is not None and len(identity_fields) > 1:
        raise ValueError(
            f"{prefix}.enabled needs a rule with exactly one identity field; this rule "
            f"has {len(identity_fields)}: {list(identity_fields)}. The lifecycle recovers "
            f"the identity value from an item's key to look up its reason and to fetch "
            f"its row, and with several fields that value cannot be recovered — the "
            f"separator also occurs inside real values, so the key cannot be split back "
            f"apart. Key the rule on one field to use the lifecycle.")

    _check_conditions(value.get("conditions"), prefix)

    sql = value.get("reason_sql")
    if sql is not None:
        if not isinstance(sql, str) or not sql.strip():
            raise ValueError(f"{prefix}.reason_sql must be a SELECT")
        lowered = sql.lower()
        if not lowered.lstrip().startswith(("select", "with")):
            raise ValueError(f"{prefix}.reason_sql must begin with SELECT or WITH")
        missing = [c for c in REASON_SQL_COLUMNS if c not in lowered]
        if missing:
            raise ValueError(
                f"{prefix}.reason_sql must return {list(REASON_SQL_COLUMNS)}; "
                f"missing: {missing}")
    return value


def _check_conditions(conditions: Any, prefix: str) -> None:
    """A rule's own questions about its data, checked at save time.

    ⛔ A DECLARED CONDITION DECIDES NOTHING, and that is why this is lenient about what
    the SQL asks and strict about what it returns. The platform runs it, reads `fired`,
    and records the author's sentence if it is true. It never changes an outcome. So the
    only things that can go wrong are a query that is not a SELECT, a query that does not
    return `fired`, and a code that collides — and each of those fails SILENTLY at run
    time (a recorded `condition_query_failed` nobody reads), which is why they are refused
    here instead.
    """
    if conditions is None:
        return
    if not isinstance(conditions, list):
        raise ValueError(f"{prefix}.conditions must be a list of "
                         f"{{code, sentence, sql}} objects")
    seen: set = set()
    for i, c in enumerate(conditions):
        at = f"{prefix}.conditions[{i}]"
        if not isinstance(c, dict):
            raise ValueError(f"{at} must be an object with code, sentence and sql")
        unknown = sorted(set(c) - {"code", "sentence", "sql"})
        if unknown:
            raise ValueError(f"{at} has unknown key(s) {unknown}; "
                             f"allowed: ['code', 'sentence', 'sql']")
        code = c.get("code")
        if not isinstance(code, str) or not code.strip():
            raise ValueError(f"{at}.code must be a non-empty string")
        code = code.strip()
        if code in PLATFORM_CONDITION_CODES:
            raise ValueError(
                f"{at}.code is {code!r}, which the platform itself emits. A run record "
                f"carrying two conditions with one code cannot be read, and an alert on "
                f"that code would fire for both. Choose another name. Reserved: "
                f"{sorted(PLATFORM_CONDITION_CODES)}")
        if code in seen:
            raise ValueError(f"{at}.code {code!r} is declared twice in this rule")
        seen.add(code)
        sentence = c.get("sentence")
        if not isinstance(sentence, str) or not sentence.strip():
            raise ValueError(
                f"{at}.sentence must say, in words a person reading the Inbox would "
                f"understand, what it means when this condition fires")
        sql = c.get("sql")
        if not isinstance(sql, str) or not sql.strip():
            raise ValueError(f"{at}.sql must be a SELECT")
        lowered = sql.lower()
        if not lowered.lstrip().startswith(("select", "with")):
            raise ValueError(f"{at}.sql must begin with SELECT or WITH")
        missing = [col for col in CONDITION_SQL_COLUMNS if col not in lowered]
        if missing:
            raise ValueError(
                f"{at}.sql must return {list(CONDITION_SQL_COLUMNS)}; missing: {missing}. "
                f"It returns ONE row: `fired` is true or false, and an optional integer "
                f"`n` carries the count behind it.")


def _check_reason(reason: Any, where: str, allowed: Optional[frozenset]) -> None:
    if not isinstance(reason, str) or not reason.strip():
        raise ValueError(f"{where} must name a resolution reason")
    if allowed is not None and reason not in allowed:
        raise ValueError(
            f"{where} is {reason!r}, which the lifecycle may not write. "
            f"Allowed: {sorted(allowed)}")


def _check_reason_map_entry(entry: Any, where: str, allowed: Optional[frozenset]) -> None:
    """A reason string, or {reason, verdict?} (option B)."""
    if not isinstance(entry, dict):
        _check_reason(entry, where, allowed)
        return
    unknown = sorted(set(entry) - REASON_MAP_ENTRY_KEYS)
    if unknown:
        raise ValueError(f"{where} has unknown key(s) {unknown}; allowed: "
                         f"{sorted(REASON_MAP_ENTRY_KEYS)}")
    _check_reason(entry.get("reason"), f"{where}.reason", allowed)
    verdict = entry.get("verdict")
    if verdict is None:
        return
    if verdict not in REASON_MAP_VERDICTS:
        raise ValueError(f"{where}.verdict is {verdict!r}; allowed: "
                         f"{sorted(REASON_MAP_VERDICTS)}")
    if entry["reason"] not in REASON_MAP_VERDICT_REASONS:
        raise ValueError(
            f"{where}.verdict is set for {entry['reason']!r}, but only "
            f"{sorted(REASON_MAP_VERDICT_REASONS)} takes its verdict from the app; the "
            f"platform decides the verdict for every other reason")


def rule_lifecycle_contract() -> Dict[str, Any]:
    """The contract as data, for a build driver to read before a deposit is spent."""
    return {
        "keys": sorted(LIFECYCLE_KEYS),
        "reason_sql_columns": list(REASON_SQL_COLUMNS),
        "optional_reason_sql_columns": list(OPTIONAL_REASON_SQL_COLUMNS),
        "condition_sql_columns": list(CONDITION_SQL_COLUMNS),
        "reserved_condition_codes": sorted(PLATFORM_CONDITION_CODES),
        "reason_map_entry": {
            "forms": ["<reason>", {"reason": "<reason>", "verdict": "<verdict>"}],
            "keys": sorted(REASON_MAP_ENTRY_KEYS),
            "verdicts": sorted(REASON_MAP_VERDICTS),
            "verdict_only_for": sorted(REASON_MAP_VERDICT_REASONS),
        },
        "requires": {"emit_mode": "selector", "identity_fields": "non-empty"},
    }
