"""The entry CATEGORY a rule declares — the inbox chip, without a platform vocabulary.

⛔ WHAT THIS REPLACES. A8 (2026-09-22) gave the inbox an Action chip by mapping three
`entity_type` values to labels IN THE FRONT END: `upgrade` → Upgrade, `mitigation` →
Mitigate, `finding` → Review. Those three words came from one app's bundle, and the alert
system had no notion of an entry kind before A8. Two things were wrong with it:

  * it taught the platform one app's vocabulary, so a new kind meant editing the front
    end — measured on T1 2026-09-25, the five posture rules raise 139 of 272 entries and
    declare `service`, `image`, `scanner` and `finding`, so 72 threat-change entries wore
    a Review chip while carrying a declared verdict and the rest showed no chip at all;
  * it overloaded `entity_type`, which is ALSO half the dedup key — `compute_finding_key`
    is literally `f"{entity_type}:{entity_id}"` — so every rule wanting the same chip had
    to share an identity prefix. Two jobs on one field.

The category is a separate, one-of, rule-declared field. `entity_type` goes back to being
the identity kind and drives nothing visible.

⭐ WHY `category` AND NOT THE ALTERNATIVES. `action` was right while the three values were
verbs; "Posture" is not one, and the next kind will not be either. `alert_type` dispatches
enrichers, `entity_type` is the identity, `tags` are rule-level and many-of and never
reach the alert. A one-of field on the alert, named for what a facet is, is the contract.

⚠️ Optional. A rule that declares nothing has no category, and its alerts are unlabelled —
the truthful state, not a default guessed from `entity_type`.
"""
from __future__ import annotations

import re
from typing import Any, Dict, Optional

# A facet value that travels to the API, the CLI and the inbox, so it is slug-shaped:
# lowercase, no spaces, stable enough to filter on and to appear in a URL.
CATEGORY_KEY_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,31}$")
CATEGORY_KEY_MAX = 32
CATEGORY_LABEL_MAX = 64
CATEGORY_ENTRY_KEYS = frozenset({"key", "label", "order"})


def validate_rule_category(
    value: Optional[Dict[str, Any]], *, prefix: str = "category"
) -> Optional[Dict[str, Any]]:
    """Return the category unchanged, or raise ValueError naming what is wrong.

    `{"key": "posture", "label": "Posture", "order": 40}` — `order` optional, and it is
    what the facet and `torana alerts list` sort by; without it the facet falls back to
    first appearance.

    `prefix` is what the caller calls this field in ITS messages, so the detection
    framework and the build path can share one implementation without either service's
    wording changing.
    """
    if value is None:
        return None
    if not isinstance(value, dict):
        raise ValueError(f"{prefix} must be an object with a 'key' and a 'label'")

    extra = sorted(set(value) - CATEGORY_ENTRY_KEYS)
    if extra:
        raise ValueError(
            f"{prefix} has unknown key(s) {extra}; allowed: {sorted(CATEGORY_ENTRY_KEYS)}")

    key = value.get("key")
    if not isinstance(key, str) or not CATEGORY_KEY_RE.match(key):
        raise ValueError(
            f"{prefix}.key must be lowercase letters, digits, '_' or '-', starting with "
            f"a letter or digit, at most {CATEGORY_KEY_MAX} characters — it is filtered "
            f"on by the API and the CLI and appears in a URL")

    label = value.get("label")
    if not isinstance(label, str) or not label.strip():
        raise ValueError(f"{prefix}.label must be the words a reader sees on the chip")
    if len(label) > CATEGORY_LABEL_MAX:
        raise ValueError(f"{prefix}.label must be at most {CATEGORY_LABEL_MAX} characters")

    order = value.get("order")
    if order is not None and (isinstance(order, bool) or not isinstance(order, int)):
        raise ValueError(f"{prefix}.order must be a whole number, or absent")
    return value


def rule_category_contract() -> Dict[str, Any]:
    """The contract as data, for a build driver to read before a deposit is spent."""
    return {
        "entry_keys": sorted(CATEGORY_ENTRY_KEYS),
        "required": ["key", "label"],
        "key_pattern": CATEGORY_KEY_RE.pattern,
        "key_max_length": CATEGORY_KEY_MAX,
        "label_max_length": CATEGORY_LABEL_MAX,
    }
