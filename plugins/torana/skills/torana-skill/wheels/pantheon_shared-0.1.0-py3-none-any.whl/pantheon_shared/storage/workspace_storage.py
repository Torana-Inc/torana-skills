"""
Workspace object store — the only path to MinIO from any Pantheon service.

All callers use the four public functions below. Bucket names and object keys
are derived internally; they never appear in calling code or in the database.

Bucket naming: torana-tenant-{tenant_id}  (one bucket per tenant)
Key encoding:  namespaces/{namespace_id}/workspaces/{workspace_id}/widgets/{widget_id}/{file_id}_{filename}

Config (read from environment):
  MINIO_ENDPOINT        host:port inside Docker network  (default: minio:9000)
  MINIO_ROOT_USER       MinIO access key                 (default: minioadmin)
  MINIO_ROOT_PASSWORD   MinIO secret key                 (default: minioadmin123)
  MINIO_SECURE          "true" for TLS                   (default: false)
"""

import os
from dataclasses import dataclass
from typing import IO, Iterator, List, Optional

from minio import Minio
from minio.error import S3Error

from pantheon_shared.iam.context import IAMContext
from pantheon_shared.logging import get_logger

logger = get_logger(__name__)

# ---------------------------------------------------------------------------
# Client singleton (process-scoped, thread-safe per minio-py docs)
# ---------------------------------------------------------------------------

_client: Optional[Minio] = None


def _get_client() -> Minio:
    global _client
    if _client is None:
        endpoint = os.environ.get("MINIO_ENDPOINT", "minio:9000")
        access_key = os.environ.get("MINIO_ROOT_USER", "minioadmin")
        secret_key = os.environ.get("MINIO_ROOT_PASSWORD", "minioadmin123")
        secure = os.environ.get("MINIO_SECURE", "false").lower() == "true"
        _client = Minio(endpoint, access_key=access_key, secret_key=secret_key, secure=secure)
        logger.debug("MinIO client initialised", endpoint=endpoint, secure=secure)
    return _client


# ---------------------------------------------------------------------------
# Internal helpers — callers never call these directly
# ---------------------------------------------------------------------------

def _bucket_name(tenant_id: str) -> str:
    # MinIO bucket names must be lowercase, 3-63 chars, DNS-compatible.
    # tenant_id is a UUID (lowercase hex + hyphens) — safe as-is.
    return f"torana-tenant-{tenant_id}"


def _object_key(namespace_id: str, workspace_id: str, widget_id: str, file_id: str, filename: str) -> str:
    return f"namespaces/{namespace_id}/workspaces/{workspace_id}/widgets/{widget_id}/{file_id}_{filename}"


def _ensure_bucket(client: Minio, bucket: str) -> None:
    """Create the bucket if it doesn't exist. Idempotent."""
    try:
        if not client.bucket_exists(bucket):
            client.make_bucket(bucket)
            logger.info("Created MinIO bucket", bucket=bucket)
    except S3Error as exc:
        # NoSuchBucket race (another request just created it) — safe to ignore
        if exc.code != "BucketAlreadyOwnedByYou":
            raise


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

@dataclass
class StoredFile:
    file_id: str
    filename: str
    size: int          # bytes
    etag: str
    object_key: str    # only for internal diagnostic use; never persisted


def put_workspace_file(
    iam_ctx: IAMContext,
    workspace_id: str,
    widget_id: str,
    file_id: str,
    filename: str,
    body: IO[bytes],
    length: int,
    content_type: str = "application/octet-stream",
) -> StoredFile:
    """
    Upload a file into the tenant's bucket.

    Args:
        iam_ctx:       The calling user's IAM context (determines bucket).
        workspace_id:  Workspace UUID.
        widget_id:     Widget UUID (the file_upload_widget that owns this file).
        file_id:       Caller-generated UUID for this file.
        filename:      Original filename (used in the key suffix).
        body:          Readable binary stream.
        length:        Total byte length of body (-1 to use streaming mode).
        content_type:  MIME type (defaults to octet-stream).

    Returns:
        StoredFile with metadata.
    """
    client = _get_client()
    bucket = _bucket_name(iam_ctx.tenant_id)
    namespace_id = iam_ctx.namespace_id or ""
    key = _object_key(namespace_id, workspace_id, widget_id, file_id, filename)

    _ensure_bucket(client, bucket)

    result = client.put_object(
        bucket_name=bucket,
        object_name=key,
        data=body,
        length=length,
        content_type=content_type,
    )

    logger.info(
        "Stored workspace file",
        tenant_id=iam_ctx.tenant_id,
        workspace_id=workspace_id,
        widget_id=widget_id,
        file_id=file_id,
        filename=filename,
    )

    return StoredFile(
        file_id=file_id,
        filename=filename,
        size=length if length >= 0 else -1,
        etag=result.etag,
        object_key=key,
    )


def get_workspace_file(
    iam_ctx: IAMContext,
    workspace_id: str,
    widget_id: str,
    file_id: str,
    filename: str,
) -> bytes:
    """
    Download a file from the tenant's bucket. Returns raw bytes.

    Raises S3Error (code=NoSuchKey) if the object does not exist.
    """
    client = _get_client()
    bucket = _bucket_name(iam_ctx.tenant_id)
    namespace_id = iam_ctx.namespace_id or ""
    key = _object_key(namespace_id, workspace_id, widget_id, file_id, filename)

    response = client.get_object(bucket_name=bucket, object_name=key)
    try:
        return response.read()
    finally:
        response.close()
        response.release_conn()


def list_workspace_files(
    iam_ctx: IAMContext,
    workspace_id: str,
    widget_id: Optional[str] = None,
) -> List[StoredFile]:
    """
    List objects in the tenant's bucket, scoped to a workspace (and optionally
    a widget). Returns only objects whose keys match the expected prefix —
    callers cannot enumerate other tenants' objects because the bucket name is
    derived from iam_ctx.tenant_id.
    """
    client = _get_client()
    bucket = _bucket_name(iam_ctx.tenant_id)
    namespace_id = iam_ctx.namespace_id or ""

    if widget_id:
        prefix = f"namespaces/{namespace_id}/workspaces/{workspace_id}/widgets/{widget_id}/"
    else:
        prefix = f"namespaces/{namespace_id}/workspaces/{workspace_id}/"

    try:
        objects: Iterator = client.list_objects(bucket_name=bucket, prefix=prefix, recursive=True)
    except S3Error as exc:
        if exc.code in ("NoSuchBucket", "BucketNotFound"):
            return []
        raise

    results: List[StoredFile] = []
    try:
        for obj in objects:
            # Key format: .../widgets/{widget_id}/{file_id}_{filename}
            key = obj.object_name or ""
            basename = key.rsplit("/", 1)[-1]
            # basename is {file_id}_{filename} — split on first underscore only
            parts = basename.split("_", 1)
            if len(parts) == 2:
                fid, fname = parts
            else:
                fid, fname = basename, basename

            results.append(StoredFile(
                file_id=fid,
                filename=fname,
                size=obj.size or 0,
                etag=obj.etag or "",
                object_key=key,
            ))
    except S3Error as exc:
        if exc.code in ("NoSuchBucket", "BucketNotFound"):
            return []
        raise

    return results


def delete_workspace_file(
    iam_ctx: IAMContext,
    workspace_id: str,
    widget_id: str,
    file_id: str,
    filename: str,
) -> None:
    """
    Delete a file from the tenant's bucket.

    Idempotent — silently succeeds if the object doesn't exist.
    """
    client = _get_client()
    bucket = _bucket_name(iam_ctx.tenant_id)
    namespace_id = iam_ctx.namespace_id or ""
    key = _object_key(namespace_id, workspace_id, widget_id, file_id, filename)

    client.remove_object(bucket_name=bucket, object_name=key)
    logger.info(
        "Deleted workspace file",
        tenant_id=iam_ctx.tenant_id,
        workspace_id=workspace_id,
        widget_id=widget_id,
        file_id=file_id,
    )
