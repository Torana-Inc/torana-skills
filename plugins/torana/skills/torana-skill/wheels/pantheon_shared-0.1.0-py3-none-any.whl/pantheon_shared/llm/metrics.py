"""
LLM Client Metrics Module.

This module provides comprehensive metrics tracking for LLM API calls across all Pantheon services.
It tracks retry behavior, latency, errors, token usage, and per-model statistics to help with
debugging and performance optimization.

Environment Variables:
    LLM_METRICS_ENABLED: Enable/disable LLM metrics collection (default: true)
    LLM_METRICS_SLOW_CALL_THRESHOLD: Threshold for slow LLM calls in seconds (default: 5)
    LLM_METRICS_VERY_SLOW_CALL_THRESHOLD: Threshold for very slow calls in seconds (default: 10)
    LLM_METRICS_MAX_MODEL_TRACKING: Maximum number of models to track individually (default: 20)
    LLM_METRICS_MAX_TENANT_TRACKING: Maximum number of tenants to track individually (default: 50)
"""

import os
import time
from dataclasses import dataclass, field
from threading import Lock
from typing import Dict, Optional, Any
from collections import defaultdict


# =============================================================================
# Configuration from Environment Variables
# =============================================================================

LLM_METRICS_ENABLED = os.getenv('LLM_METRICS_ENABLED', 'true').lower() == 'true'
LLM_METRICS_SLOW_CALL_THRESHOLD = float(os.getenv('LLM_METRICS_SLOW_CALL_THRESHOLD', '5'))
LLM_METRICS_VERY_SLOW_CALL_THRESHOLD = float(os.getenv('LLM_METRICS_VERY_SLOW_CALL_THRESHOLD', '10'))
LLM_METRICS_MAX_MODEL_TRACKING = int(os.getenv('LLM_METRICS_MAX_MODEL_TRACKING', '20'))
LLM_METRICS_MAX_TENANT_TRACKING = int(os.getenv('LLM_METRICS_MAX_TENANT_TRACKING', '50'))


# =============================================================================
# Metrics Data Classes
# =============================================================================

@dataclass
class LLMCallMetrics:
    """
    In-memory metrics tracking for LLM API operations.

    This class tracks various metrics related to LLM operations including:
    - Total calls and success/failure rates
    - Retry behavior (attempts, reasons, success after retry)
    - Latency (with percentiles for slow calls)
    - Token usage (prompt, completion, total)
    - Error counts (by type, by model)
    - Rate limit hits
    - Empty response occurrences

    Thread-safe: All methods use locks to ensure thread safety.
    """

    # Call Count Metrics
    total_calls: int = 0
    successful_calls: int = 0  # Including those that succeeded after retry
    failed_calls: int = 0  # Calls that failed after all retries
    calls_succeeded_without_retry: int = 0
    calls_succeeded_after_retry: int = 0

    # Latency Metrics (in seconds)
    total_latency: float = 0.0
    min_latency: float = float('inf')
    max_latency: float = 0.0
    slow_call_count: int = 0  # Calls > LLM_METRICS_SLOW_CALL_THRESHOLD
    very_slow_call_count: int = 0  # Calls > LLM_METRICS_VERY_SLOW_CALL_THRESHOLD

    # Retry Metrics
    total_retry_attempts: int = 0  # Total retry attempts across all calls
    calls_that_retried: int = 0  # Number of unique calls that had at least 1 retry

    # Retry reasons (what triggered retries)
    retry_on_empty_response: int = 0
    retry_on_value_error: int = 0  # e.g., "No message in response"
    retry_on_timeout: int = 0
    retry_on_connection_error: int = 0
    retry_on_rate_limit: int = 0
    retry_on_api_error: int = 0
    retry_on_other_error: int = 0

    # Token Usage Metrics
    total_prompt_tokens: int = 0
    total_completion_tokens: int = 0
    total_tokens: int = 0
    calls_with_token_data: int = 0

    # Error Metrics
    value_error_count: int = 0  # ValueError (e.g., "No message in response")
    timeout_error_count: int = 0
    connection_error_count: int = 0
    rate_limit_error_count: int = 0
    api_error_count: int = 0  # Generic API errors
    other_error_count: int = 0

    # Response Quality Metrics
    empty_response_count: int = 0  # Responses with null/empty content
    rate_limit_hit_count: int = 0  # Number of 429 responses

    # Per-Model Statistics (limited to MAX_MODEL_TRACKING entries)
    model_call_counts: Dict[str, int] = field(default_factory=dict)
    model_error_counts: Dict[str, int] = field(default_factory=dict)
    model_latency_totals: Dict[str, float] = field(default_factory=dict)

    # Per-Tenant Statistics (limited to MAX_TENANT_TRACKING entries)
    tenant_call_counts: Dict[str, int] = field(default_factory=dict)
    tenant_error_counts: Dict[str, int] = field(default_factory=dict)

    # Thread safety lock
    _lock: Lock = field(default_factory=Lock)

    # =============================================================================
    # Recording Methods
    # =============================================================================

    def record_call_start(self, model: str, tenant_id: Optional[str] = None) -> float:
        """
        Record the start of an LLM call and return start time.

        Args:
            model: The LLM model being called
            tenant_id: Optional tenant ID for multi-tenancy tracking

        Returns:
            Start time (for latency calculation)
        """
        with self._lock:
            self.total_calls += 1

            # Track per-model calls (with limit)
            if model not in self.model_call_counts:
                if len(self.model_call_counts) >= LLM_METRICS_MAX_MODEL_TRACKING:
                    # Remove oldest entry (FIFO)
                    oldest = next(iter(self.model_call_counts))
                    del self.model_call_counts[oldest]
                self.model_call_counts[model] = 0
            self.model_call_counts[model] += 1

            # Track per-tenant calls (with limit)
            if tenant_id:
                if tenant_id not in self.tenant_call_counts:
                    if len(self.tenant_call_counts) >= LLM_METRICS_MAX_TENANT_TRACKING:
                        # Remove oldest entry (FIFO)
                        oldest = next(iter(self.tenant_call_counts))
                        del self.tenant_call_counts[oldest]
                self.tenant_call_counts[tenant_id] = \
                    self.tenant_call_counts.get(tenant_id, 0) + 1

        return time.time()

    def record_call_success(
        self,
        start_time: float,
        num_retries: int,
        model: str,
        prompt_tokens: int = 0,
        completion_tokens: int = 0,
        total_tokens: int = 0,
        tenant_id: Optional[str] = None
    ) -> None:
        """
        Record a successful LLM call.

        Args:
            start_time: Start time from record_call_start()
            num_retries: Number of retry attempts made
            model: The LLM model that was called
            prompt_tokens: Number of prompt tokens used
            completion_tokens: Number of completion tokens generated
            total_tokens: Total tokens used
            tenant_id: Optional tenant ID
        """
        latency = time.time() - start_time

        with self._lock:
            self.successful_calls += 1
            self.total_latency += latency

            # Update min/max latency
            if latency < self.min_latency:
                self.min_latency = latency
            if latency > self.max_latency:
                self.max_latency = latency

            # Track slow calls
            if latency > LLM_METRICS_VERY_SLOW_CALL_THRESHOLD:
                self.very_slow_call_count += 1
            elif latency > LLM_METRICS_SLOW_CALL_THRESHOLD:
                self.slow_call_count += 1

            # Track retry behavior
            if num_retries > 0:
                self.calls_succeeded_after_retry += 1
                self.total_retry_attempts += num_retries
                self.calls_that_retried += 1
            else:
                self.calls_succeeded_without_retry += 1

            # Track token usage
            if total_tokens > 0:
                self.total_prompt_tokens += prompt_tokens
                self.total_completion_tokens += completion_tokens
                self.total_tokens += total_tokens
                self.calls_with_token_data += 1

            # Track per-model latency
            if model not in self.model_latency_totals:
                if len(self.model_latency_totals) >= LLM_METRICS_MAX_MODEL_TRACKING:
                    oldest = next(iter(self.model_latency_totals))
                    del self.model_latency_totals[oldest]
            self.model_latency_totals[model] = \
                self.model_latency_totals.get(model, 0.0) + latency

    def record_call_failure(
        self,
        start_time: float,
        num_retries: int,
        error_type: str,
        model: str,
        tenant_id: Optional[str] = None
    ) -> None:
        """
        Record a failed LLM call.

        Args:
            start_time: Start time from record_call_start()
            num_retries: Number of retry attempts made
            error_type: Type of error that caused failure
            model: The LLM model that was called
            tenant_id: Optional tenant ID
        """
        latency = time.time() - start_time

        with self._lock:
            self.failed_calls += 1
            self.total_latency += latency

            # Track retry attempts even for failed calls
            if num_retries > 0:
                self.total_retry_attempts += num_retries
                self.calls_that_retried += 1

            # Track error types
            error_type_lower = error_type.lower()
            if 'value' in error_type_lower:
                self.value_error_count += 1
            elif 'timeout' in error_type_lower:
                self.timeout_error_count += 1
            elif 'connection' in error_type_lower:
                self.connection_error_count += 1
            elif 'rate' in error_type_lower or '429' in error_type_lower:
                self.rate_limit_error_count += 1
            elif 'api' in error_type_lower:
                self.api_error_count += 1
            else:
                self.other_error_count += 1

            # Track per-model errors
            if model not in self.model_error_counts:
                if len(self.model_error_counts) >= LLM_METRICS_MAX_MODEL_TRACKING:
                    oldest = next(iter(self.model_error_counts))
                    del self.model_error_counts[oldest]
            self.model_error_counts[model] = \
                self.model_error_counts.get(model, 0) + 1

            # Track per-tenant errors
            if tenant_id:
                self.tenant_error_counts[tenant_id] = \
                    self.tenant_error_counts.get(tenant_id, 0) + 1

    def record_retry(self, reason: str) -> None:
        """
        Record a retry attempt with the reason.

        Args:
            reason: The reason for retry (e.g., 'empty_response', 'timeout', 'rate_limit')
        """
        with self._lock:
            self.total_retry_attempts += 1

            reason_lower = reason.lower()
            if 'empty' in reason_lower:
                self.retry_on_empty_response += 1
            elif 'value' in reason_lower:
                self.retry_on_value_error += 1
            elif 'timeout' in reason_lower:
                self.retry_on_timeout += 1
            elif 'connection' in reason_lower:
                self.retry_on_connection_error += 1
            elif 'rate' in reason_lower:
                self.retry_on_rate_limit += 1
            elif 'api' in reason_lower:
                self.retry_on_api_error += 1
            else:
                self.retry_on_other_error += 1

    def record_empty_response(self) -> None:
        """Record an empty/null response from an LLM."""
        with self._lock:
            self.empty_response_count += 1
            self.retry_on_empty_response += 1

    def record_rate_limit(self) -> None:
        """Record a rate limit (429) response."""
        with self._lock:
            self.rate_limit_hit_count += 1
            self.rate_limit_error_count += 1

    # =============================================================================
    # Export Methods
    # =============================================================================

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert metrics to a dictionary for serialization.

        Returns:
            Dictionary containing all metrics
        """
        with self._lock:
            avg_latency = (self.total_latency / self.total_calls) if self.total_calls > 0 else 0
            avg_prompt_tokens = (self.total_prompt_tokens / self.calls_with_token_data) if self.calls_with_token_data > 0 else 0
            avg_completion_tokens = (self.total_completion_tokens / self.calls_with_token_data) if self.calls_with_token_data > 0 else 0
            avg_total_tokens = (self.total_tokens / self.calls_with_token_data) if self.calls_with_token_data > 0 else 0

            success_rate = (self.successful_calls / self.total_calls * 100) if self.total_calls > 0 else 0
            retry_rate = (self.calls_that_retried / self.total_calls * 100) if self.total_calls > 0 else 0
            success_after_retry_rate = (self.calls_succeeded_after_retry / self.calls_that_retried * 100) if self.calls_that_retried > 0 else 0

            return {
                "call_metrics": {
                    "total_calls": self.total_calls,
                    "successful_calls": self.successful_calls,
                    "failed_calls": self.failed_calls,
                    "calls_succeeded_without_retry": self.calls_succeeded_without_retry,
                    "calls_succeeded_after_retry": self.calls_succeeded_after_retry,
                    "success_rate_percent": round(success_rate, 2),
                },
                "latency_metrics": {
                    "avg_latency_seconds": round(avg_latency, 3),
                    "min_latency_seconds": round(self.min_latency, 3) if self.min_latency != float('inf') else 0,
                    "max_latency_seconds": round(self.max_latency, 3),
                    "slow_call_count": self.slow_call_count,
                    "very_slow_call_count": self.very_slow_call_count,
                },
                "retry_metrics": {
                    "total_retry_attempts": self.total_retry_attempts,
                    "calls_that_retried": self.calls_that_retried,
                    "retry_rate_percent": round(retry_rate, 2),
                    "success_after_retry_rate_percent": round(success_after_retry_rate, 2),
                    "retry_reasons": {
                        "empty_response": self.retry_on_empty_response,
                        "value_error": self.retry_on_value_error,
                        "timeout": self.retry_on_timeout,
                        "connection_error": self.retry_on_connection_error,
                        "rate_limit": self.retry_on_rate_limit,
                        "api_error": self.retry_on_api_error,
                        "other_error": self.retry_on_other_error,
                    }
                },
                "token_metrics": {
                    "total_prompt_tokens": self.total_prompt_tokens,
                    "total_completion_tokens": self.total_completion_tokens,
                    "total_tokens": self.total_tokens,
                    "calls_with_token_data": self.calls_with_token_data,
                    "avg_prompt_tokens": round(avg_prompt_tokens, 2),
                    "avg_completion_tokens": round(avg_completion_tokens, 2),
                    "avg_total_tokens": round(avg_total_tokens, 2),
                },
                "error_metrics": {
                    "value_errors": self.value_error_count,
                    "timeout_errors": self.timeout_error_count,
                    "connection_errors": self.connection_error_count,
                    "rate_limit_errors": self.rate_limit_error_count,
                    "api_errors": self.api_error_count,
                    "other_errors": self.other_error_count,
                },
                "response_quality_metrics": {
                    "empty_responses": self.empty_response_count,
                    "rate_limit_hits": self.rate_limit_hit_count,
                },
                "per_model_stats": {
                    model: {
                        "calls": count,
                        "errors": self.model_error_counts.get(model, 0),
                        "avg_latency": round(self.model_latency_totals.get(model, 0.0) / count, 3) if count > 0 else 0
                    }
                    for model, count in self.model_call_counts.items()
                },
                "per_tenant_stats": {
                    tenant: {
                        "calls": count,
                        "errors": self.tenant_error_counts.get(tenant, 0)
                    }
                    for tenant, count in self.tenant_call_counts.items()
                },
            }


# =============================================================================
# Global Metrics Registry
# =============================================================================

_llm_metrics_registry: Dict[str, LLMCallMetrics] = {}
_llm_metrics_lock = Lock()


def get_llm_metrics_registry() -> Dict[str, LLMCallMetrics]:
    """
    Get the global LLM metrics registry.

    Returns:
        Dictionary mapping service names to their LLM metrics
    """
    return _llm_metrics_registry


def get_or_create_llm_metrics(service_name: str) -> LLMCallMetrics:
    """
    Get or create LLM metrics for a service.

    Args:
        service_name: Name of the service (e.g., 'pantheon-agent-builder')

    Returns:
        LLMCallMetrics instance for the service
    """
    with _llm_metrics_lock:
        if service_name not in _llm_metrics_registry:
            _llm_metrics_registry[service_name] = LLMCallMetrics()
        return _llm_metrics_registry[service_name]


def reset_llm_metrics(service_name: Optional[str] = None) -> bool:
    """
    Reset LLM metrics for a specific service or all services.

    Args:
        service_name: Optional service name. If None, resets all metrics.

    Returns:
        True if reset was successful, False otherwise
    """
    with _llm_metrics_lock:
        if service_name:
            if service_name in _llm_metrics_registry:
                _llm_metrics_registry[service_name] = LLMCallMetrics()
                return True
            return False
        else:
            # Reset all metrics
            for key in _llm_metrics_registry:
                _llm_metrics_registry[key] = LLMCallMetrics()
            return True


def get_all_llm_metrics() -> Dict[str, LLMCallMetrics]:
    """
    Get all LLM metrics across all services.

    Returns:
        Dictionary mapping service names to their metrics
    """
    return _llm_metrics_registry.copy()


def calculate_llm_summary() -> Dict[str, Any]:
    """
    Calculate summary metrics across all services.

    Returns:
        Summary dictionary with aggregated metrics
    """
    all_metrics = get_all_llm_metrics()

    total_calls = sum(m.total_calls for m in all_metrics.values())
    successful_calls = sum(m.successful_calls for m in all_metrics.values())
    failed_calls = sum(m.failed_calls for m in all_metrics.values())
    total_latency = sum(m.total_latency for m in all_metrics.values())
    total_retries = sum(m.total_retry_attempts for m in all_metrics.values())
    calls_that_retried = sum(m.calls_that_retried for m in all_metrics.values())

    total_tokens = sum(m.total_tokens for m in all_metrics.values())
    total_prompt_tokens = sum(m.total_prompt_tokens for m in all_metrics.values())
    total_completion_tokens = sum(m.total_completion_tokens for m in all_metrics.values())

    empty_responses = sum(m.empty_response_count for m in all_metrics.values())
    rate_limits = sum(m.rate_limit_hit_count for m in all_metrics.values())

    slow_calls = sum(m.slow_call_count for m in all_metrics.values())
    very_slow_calls = sum(m.very_slow_call_count for m in all_metrics.values())

    avg_latency = total_latency / total_calls if total_calls > 0 else 0
    success_rate = (successful_calls / total_calls * 100) if total_calls > 0 else 0
    retry_rate = (calls_that_retried / total_calls * 100) if total_calls > 0 else 0
    avg_tokens_per_call = total_tokens / total_calls if total_calls > 0 else 0

    return {
        "overall_metrics": {
            "total_calls": total_calls,
            "successful_calls": successful_calls,
            "failed_calls": failed_calls,
            "success_rate_percent": round(success_rate, 2),
            "avg_latency_seconds": round(avg_latency, 3),
        },
        "retry_summary": {
            "total_retry_attempts": total_retries,
            "calls_that_retried": calls_that_retried,
            "retry_rate_percent": round(retry_rate, 2),
        },
        "token_summary": {
            "total_prompt_tokens": total_prompt_tokens,
            "total_completion_tokens": total_completion_tokens,
            "total_tokens": total_tokens,
            "avg_tokens_per_call": round(avg_tokens_per_call, 2),
        },
        "quality_summary": {
            "empty_responses": empty_responses,
            "rate_limit_hits": rate_limits,
            "slow_calls": slow_calls,
            "very_slow_calls": very_slow_calls,
        },
        "active_services": len(all_metrics),
    }
