"""
Pantheon Shared LLM Retry Module

Provides robust retry logic for LLM API calls using tenacity.
Handles transient errors, empty responses, rate limits, and timeouts.
Supports both sync and async LLM calls.

Integrated with comprehensive metrics tracking for observability.
"""

from __future__ import annotations

import os
import time
import functools
from typing import (
    Any,
    Awaitable,
    Callable,
    Optional,
    TypeVar,
    ParamSpec,
)

from tenacity import (
    retry,
    stop_after_attempt,
    wait_random_exponential,
    retry_if_exception_type,
    retry_if_result,
)

# Try to import metrics; if not available, metrics will be disabled
try:
    from .metrics import (
        LLM_METRICS_ENABLED,
        get_or_create_llm_metrics,
    )
    METRICS_AVAILABLE = True
except ImportError:
    METRICS_AVAILABLE = False


__all__ = [
    "async_llm_retry",
    "llm_retry",
    "LLMRetryConfig",
    "is_empty_llm_response",
]


# Type variables for generic function signatures
P = ParamSpec("P")
R = TypeVar("R")
AsyncR = TypeVar("AsyncR")


# Default retry configuration - read from environment variables with fallback defaults
LLM_RETRY_MAX_ATTEMPTS: int = int(os.getenv("LLM_RETRY_MAX_ATTEMPTS", "3"))
LLM_RETRY_MIN_WAIT: float = float(os.getenv("LLM_RETRY_MIN_WAIT", "1.0"))  # seconds
LLM_RETRY_MAX_WAIT: float = float(os.getenv("LLM_RETRY_MAX_WAIT", "60.0"))  # seconds

# Service name for metrics (can be overridden via environment variable)
_LLM_METRICS_SERVICE_NAME = os.getenv("LLM_METRICS_SERVICE_NAME", "pantheon-service")


# Common LLM exceptions to retry
TRANSIENT_EXCEPTIONS = (
    ValueError,  # Google ADK raises ValueError("No message in response")
    TimeoutError,
    ConnectionError,
    OSError,
    # LiteLLM exceptions (may not all be available, so we check dynamically)
)


class LLMRetryConfig:
    """
    Configuration for LLM retry behavior.

    Attributes:
        max_attempts: Maximum number of retry attempts (default: 3)
        min_wait: Minimum wait time between retries in seconds (default: 1.0)
        max_wait: Maximum wait time between retries in seconds (default: 60.0)
        retry_on_empty_response: Whether to retry on empty/null responses (default: True)
        additional_exceptions: Additional exception types to retry
    """

    def __init__(
        self,
        max_attempts: int = LLM_RETRY_MAX_ATTEMPTS,
        min_wait: float = LLM_RETRY_MIN_WAIT,
        max_wait: float = LLM_RETRY_MAX_WAIT,
        retry_on_empty_response: bool = True,
        additional_exceptions: Optional[tuple[type[Exception], ...]] = None,
    ):
        self.max_attempts = max_attempts
        self.min_wait = min_wait
        self.max_wait = max_wait
        self.retry_on_empty_response = retry_on_empty_response
        self.additional_exceptions = additional_exceptions or ()


def is_empty_llm_response(response: Any) -> bool:
    """
    Check if an LLM response is empty or should be retried.

    This handles various LLM response formats:
    - LiteLLM ModelResponse objects with choices[0].message.content
    - Google ADK LlmResponse objects
    - Plain strings/dicts

    Args:
        response: The LLM response to check

    Returns:
        True if the response is empty/null/invalid and should be retried
    """
    # None is always empty
    if response is None:
        return True

    # Check LiteLLM-style responses with choices
    if hasattr(response, "choices"):
        try:
            if response.choices and len(response.choices) > 0:
                message = response.choices[0].message
                if hasattr(message, "content"):
                    content = message.content
                    return content is None or (isinstance(content, str) and content.strip() == "")
            return True  # No choices or empty choices
        except (AttributeError, IndexError):
            return True

    # Check Google ADK-style responses
    if hasattr(response, "parts"):
        try:
            return not response.parts or len(response.parts) == 0
        except (AttributeError, TypeError):
            return True

    # Check dict-style responses
    if isinstance(response, dict):
        # Check for choices key (LiteLLM dict format)
        choices = response.get("choices", [])
        if choices and len(choices) > 0:
            message = choices[0].get("message", {})
            content = message.get("content")
            return content is None or (isinstance(content, str) and content.strip() == "")
        return True

    # Check string responses
    if isinstance(response, str):
        return response.strip() == ""

    # Unknown format, assume non-empty
    return False


def _create_retry_predicate(config: LLMRetryConfig) -> Callable[[Any], bool]:
    """
    Create a retry predicate function based on configuration.

    Args:
        config: The retry configuration

    Returns:
        A function that returns True if the result should trigger a retry
    """

    def should_retry(result: Any) -> bool:
        if not config.retry_on_empty_response:
            return False
        return is_empty_llm_response(result)

    return should_retry


def _get_exception_types_to_retry(
    config: LLMRetryConfig,
) -> tuple[type[Exception], ...]:
    """
    Get the tuple of exception types to retry.

    Includes:
    - Built-in transient exceptions
    - User-specified additional exceptions
    - LiteLLM exceptions (if available)

    Args:
        config: The retry configuration

    Returns:
        Tuple of exception types to retry
    """
    exceptions = list(TRANSIENT_EXCEPTIONS)

    # Add LiteLLM-specific exceptions if available
    try:
        from litellm import (
            APIError,
            APIConnectionError,
            RateLimitError,
            ContextWindowExceededError,
        )
        exceptions.extend([APIError, APIConnectionError, RateLimitError, ContextWindowExceededError])
    except ImportError:
        # litellm not available or doesn't have these exceptions
        pass

    # Add user-specified exceptions
    if config.additional_exceptions:
        exceptions.extend(config.additional_exceptions)

    return tuple(exceptions)


def llm_retry(
    max_attempts: int = LLM_RETRY_MAX_ATTEMPTS,
    min_wait: float = LLM_RETRY_MIN_WAIT,
    max_wait: float = LLM_RETRY_MAX_WAIT,
    retry_on_empty_response: bool = True,
    additional_exceptions: Optional[tuple[type[Exception], ...]] = None,
) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """
    Decorator for adding retry logic to synchronous LLM calls.

    Retries on:
    - Transient exceptions (ValueError, TimeoutError, ConnectionError, etc.)
    - LiteLLM exceptions (APIError, RateLimitError, etc.) if available
    - Empty/null responses (configurable)

    Uses exponential backoff with jitter for retries.

    Args:
        max_attempts: Maximum number of retry attempts (default: 3)
        min_wait: Minimum wait time between retries in seconds (default: 1.0)
        max_wait: Maximum wait time between retries in seconds (default: 60.0)
        retry_on_empty_response: Whether to retry on empty/null responses (default: True)
        additional_exceptions: Additional exception types to retry

    Returns:
        A decorator function

    Example:
        ```python
        from litellm import completion

        @llm_retry(max_attempts=3)
        def my_llm_call(messages):
            return completion(model="gpt-4", messages=messages)

        response = my_llm_call([{"role": "user", "content": "Hello"}])
        ```
    """

    config = LLMRetryConfig(
        max_attempts=max_attempts,
        min_wait=min_wait,
        max_wait=max_wait,
        retry_on_empty_response=retry_on_empty_response,
        additional_exceptions=additional_exceptions,
    )

    exception_types = _get_exception_types_to_retry(config)
    retry_predicate = _create_retry_predicate(config)

    def decorator(func: Callable[P, R]) -> Callable[P, R]:
        @functools.wraps(func)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            # Get metrics instance if enabled
            metrics = get_or_create_llm_metrics(_LLM_METRICS_SERVICE_NAME) if METRICS_AVAILABLE else None

            # Extract model name from kwargs if available (for litellm calls)
            model = kwargs.get('model', 'unknown')

            # Record call start and get start time
            start_time = metrics.record_call_start(model) if metrics else time.time()

            # Try to extract tenant_id from kwargs for multi-tenant tracking
            tenant_id = kwargs.get('tenant_id') or kwargs.get('tenant')

            # Track retry attempts
            retry_count = [0]  # Use list to allow modification in nested function

            # Build the tenacity retry decorator
            tenacity_decorator = retry(
                # Stop after max attempts
                stop=stop_after_attempt(max_attempts),
                # Wait with exponential backoff with jitter
                wait=wait_random_exponential(multiplier=1, min=min_wait, max=max_wait),
                # Retry on specified exceptions
                retry=retry_if_exception_type(exception_types) | retry_if_result(retry_predicate),
                # Reraise the last exception if all retries fail
                reraise=True,
                # Record retry attempts
                before_sleep=lambda retry_state: retry_count.__setitem__(0, retry_count[0] + 1) if metrics else None,
            )

            # Apply tenacity to the original function
            retried_func = tenacity_decorator(func)

            try:
                result = retried_func(*args, **kwargs)

                # Extract token usage from result if available
                prompt_tokens = 0
                completion_tokens = 0
                total_tokens_val = 0

                # Handle litellm response format
                if hasattr(result, 'usage'):
                    usage = result.usage
                    if usage:
                        prompt_tokens = getattr(usage, 'prompt_tokens', 0)
                        completion_tokens = getattr(usage, 'completion_tokens', 0)
                        total_tokens_val = getattr(usage, 'total_tokens', 0)

                # Record success
                if metrics:
                    metrics.record_call_success(
                        start_time=start_time,
                        num_retries=retry_count[0],
                        model=model,
                        prompt_tokens=prompt_tokens,
                        completion_tokens=completion_tokens,
                        total_tokens=total_tokens_val,
                        tenant_id=tenant_id
                    )

                return result

            except Exception as e:
                # Record failure
                if metrics:
                    metrics.record_call_failure(
                        start_time=start_time,
                        num_retries=retry_count[0],
                        error_type=type(e).__name__,
                        model=model,
                        tenant_id=tenant_id
                    )
                raise

        return wrapper

    return decorator


def async_llm_retry(
    max_attempts: int = LLM_RETRY_MAX_ATTEMPTS,
    min_wait: float = LLM_RETRY_MIN_WAIT,
    max_wait: float = LLM_RETRY_MAX_WAIT,
    retry_on_empty_response: bool = True,
    additional_exceptions: Optional[tuple[type[Exception], ...]] = None,
) -> Callable[[Callable[P, Awaitable[AsyncR]]], Callable[P, Awaitable[AsyncR]]]:
    """
    Decorator for adding retry logic to asynchronous LLM calls.

    Retries on:
    - Transient exceptions (ValueError, TimeoutError, ConnectionError, etc.)
    - LiteLLM exceptions (APIError, RateLimitError, etc.) if available
    - Empty/null responses (configurable)

    Uses exponential backoff with jitter for retries.

    Args:
        max_attempts: Maximum number of retry attempts (default: 3)
        min_wait: Minimum wait time between retries in seconds (default: 1.0)
        max_wait: Maximum wait time between retries in seconds (default: 60.0)
        retry_on_empty_response: Whether to retry on empty/null responses (default: True)
        additional_exceptions: Additional exception types to retry

    Returns:
        A decorator function for async functions

    Example:
        ```python
        from litellm import acompletion

        @async_llm_retry(max_attempts=3)
        async def my_llm_call(messages):
            return await acompletion(model="gpt-4", messages=messages)

        response = await my_llm_call([{"role": "user", "content": "Hello"}])
        ```
    """

    config = LLMRetryConfig(
        max_attempts=max_attempts,
        min_wait=min_wait,
        max_wait=max_wait,
        retry_on_empty_response=retry_on_empty_response,
        additional_exceptions=additional_exceptions,
    )

    exception_types = _get_exception_types_to_retry(config)
    retry_predicate = _create_retry_predicate(config)

    def decorator(func: Callable[P, Awaitable[AsyncR]]) -> Callable[P, Awaitable[AsyncR]]:
        @functools.wraps(func)
        async def wrapper(*args: P.args, **kwargs: P.kwargs) -> AsyncR:
            # Get metrics instance if enabled
            metrics = get_or_create_llm_metrics(_LLM_METRICS_SERVICE_NAME) if METRICS_AVAILABLE else None

            # Extract model name from kwargs if available (for litellm calls)
            model = kwargs.get('model', 'unknown')

            # Record call start and get start time
            start_time = metrics.record_call_start(model) if metrics else time.time()

            # Try to extract tenant_id from kwargs for multi-tenant tracking
            tenant_id = kwargs.get('tenant_id') or kwargs.get('tenant')

            # Track retry attempts
            retry_count = [0]  # Use list to allow modification in nested function

            # Build the tenacity async retry decorator
            tenacity_decorator = retry(
                # Stop after max attempts
                stop=stop_after_attempt(max_attempts),
                # Wait with exponential backoff with jitter
                wait=wait_random_exponential(multiplier=1, min=min_wait, max=max_wait),
                # Retry on specified exceptions
                retry=retry_if_exception_type(exception_types) | retry_if_result(retry_predicate),
                # Reraise the last exception if all retries fail
                reraise=True,
                # Record retry attempts
                before_sleep=lambda retry_state: retry_count.__setitem__(0, retry_count[0] + 1) if metrics else None,
            )

            # Apply tenacity to the original function
            retried_func = tenacity_decorator(func)

            try:
                result = await retried_func(*args, **kwargs)

                # Extract token usage from result if available
                prompt_tokens = 0
                completion_tokens = 0
                total_tokens_val = 0

                # Handle litellm response format
                if hasattr(result, 'usage'):
                    usage = result.usage
                    if usage:
                        prompt_tokens = getattr(usage, 'prompt_tokens', 0)
                        completion_tokens = getattr(usage, 'completion_tokens', 0)
                        total_tokens_val = getattr(usage, 'total_tokens', 0)

                # Record success
                if metrics:
                    metrics.record_call_success(
                        start_time=start_time,
                        num_retries=retry_count[0],
                        model=model,
                        prompt_tokens=prompt_tokens,
                        completion_tokens=completion_tokens,
                        total_tokens=total_tokens_val,
                        tenant_id=tenant_id
                    )

                return result

            except Exception as e:
                # Record failure
                if metrics:
                    metrics.record_call_failure(
                        start_time=start_time,
                        num_retries=retry_count[0],
                        error_type=type(e).__name__,
                        model=model,
                        tenant_id=tenant_id
                    )
                raise

        return wrapper

    return decorator
