"""
Pantheon Shared LLM Module

Provides utilities for working with LLM APIs across Pantheon services.

Current features:
- Retry logic with exponential backoff for transient LLM errors
- Empty response detection and retry
- Support for both sync and async LLM calls
- Comprehensive metrics tracking for observability

Example usage:

```python
from pantheon_shared.llm import async_llm_retry, is_empty_llm_response
from litellm import acompletion

@async_llm_retry(max_attempts=3)
async def my_llm_call(messages):
    return await acompletion(model="gpt-4", messages=messages)

# Or use the utility function directly
response = await acompletion(model="gpt-4", messages=messages)
if is_empty_llm_response(response):
    # Handle empty response
    pass
```
"""

from .retry import (
    # Decorators
    async_llm_retry,
    llm_retry,
    # Configuration
    LLMRetryConfig,
    # Utility functions
    is_empty_llm_response,
)

from .metrics import (
    # Metrics classes
    LLMCallMetrics,
    # Configuration
    LLM_METRICS_ENABLED,
    LLM_METRICS_SLOW_CALL_THRESHOLD,
    LLM_METRICS_VERY_SLOW_CALL_THRESHOLD,
    LLM_METRICS_MAX_MODEL_TRACKING,
    LLM_METRICS_MAX_TENANT_TRACKING,
    # Functions
    get_llm_metrics_registry,
    get_or_create_llm_metrics,
    reset_llm_metrics,
    get_all_llm_metrics,
    calculate_llm_summary,
)

__all__ = [
    # Decorators
    "async_llm_retry",
    "llm_retry",
    # Configuration
    "LLMRetryConfig",
    # Utility functions
    "is_empty_llm_response",
    # Metrics classes
    "LLMCallMetrics",
    # Metrics configuration
    "LLM_METRICS_ENABLED",
    "LLM_METRICS_SLOW_CALL_THRESHOLD",
    "LLM_METRICS_VERY_SLOW_CALL_THRESHOLD",
    "LLM_METRICS_MAX_MODEL_TRACKING",
    "LLM_METRICS_MAX_TENANT_TRACKING",
    # Metrics functions
    "get_llm_metrics_registry",
    "get_or_create_llm_metrics",
    "reset_llm_metrics",
    "get_all_llm_metrics",
    "calculate_llm_summary",
]
