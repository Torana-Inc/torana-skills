"""
Pantheon HTTP Client with JWT-based inter-service authentication.

This module provides a centralized HTTP client that automatically handles
authentication for inter-service communication by fetching JWT tokens from pantheon-auth.
"""

import os
import time
import uuid
from typing import Optional, Dict, Any, List, TYPE_CHECKING, Union
from datetime import datetime
import json
from dataclasses import dataclass, field
import httpx

import structlog

from ..auth_internal.token_cache import TokenCache, get_global_token_cache

# Avoid circular import
if TYPE_CHECKING:
    from ..pantheon_services import PantheonService

logger = structlog.get_logger(__name__)


# ---------------------------------------------------------------------------
# East-west connection keepalive (issue #50)
#
# A pooled client connection must never out-live the idle timeout of whatever
# sits on the other end. If it does, the peer closes a socket the client still
# believes is usable, the client reuses it, and the caller gets a
# RemoteProtocolError("Server disconnected") - intermittently, and only after
# enough uptime for a connection to sit idle that long.
#
# Measured on this platform (2026-08-24):
#   nginx  keepalive_timeout  = 65s   (pantheon-deploy/.../nginx/nginx.conf)
#   httpx  keepalive_expiry   = 5.0s  (httpx.Limits() default)
#
# so the client already expires ~13x sooner than the server and the race cannot
# occur today. That safety margin is INCIDENTAL - it is httpx's default, not a
# decision anyone recorded - and raising it past 65s would silently reintroduce
# the bug. Pinning it here makes the constraint explicit and greppable.
#
# PANTHEON_HTTP_KEEPALIVE_EXPIRY overrides it. Keep any override comfortably
# below the smallest idle timeout on the path (nginx's 65s); values at or above
# it are rejected at construction rather than failing intermittently in prod.
# ---------------------------------------------------------------------------

#: Idle timeout of the nginx in front of every east-west call.
NGINX_KEEPALIVE_TIMEOUT_SECONDS = 65.0

#: Client-side idle expiry. Must stay well under NGINX_KEEPALIVE_TIMEOUT_SECONDS.
DEFAULT_KEEPALIVE_EXPIRY_SECONDS = 5.0


def get_keepalive_expiry() -> float:
    """Resolve the pooled-connection idle expiry for east-west HTTP clients.

    Raises:
        ValueError: if the configured value is not safely below the nginx idle
            timeout - that configuration would resurrect issue #50.
    """
    raw = os.getenv("PANTHEON_HTTP_KEEPALIVE_EXPIRY")
    if raw is None:
        return DEFAULT_KEEPALIVE_EXPIRY_SECONDS

    try:
        expiry = float(raw)
    except ValueError:
        raise ValueError(
            f"PANTHEON_HTTP_KEEPALIVE_EXPIRY must be a number, got {raw!r}"
        )

    if expiry <= 0:
        raise ValueError(
            f"PANTHEON_HTTP_KEEPALIVE_EXPIRY must be positive, got {expiry}"
        )

    # Leave headroom so a connection cannot be handed out just as the peer
    # closes it. 80% of the peer's idle timeout is the guard rail.
    ceiling = NGINX_KEEPALIVE_TIMEOUT_SECONDS * 0.8
    if expiry > ceiling:
        raise ValueError(
            f"PANTHEON_HTTP_KEEPALIVE_EXPIRY={expiry}s is too close to the "
            f"nginx keepalive_timeout of {NGINX_KEEPALIVE_TIMEOUT_SECONDS}s. "
            f"Keep it at or below {ceiling}s so the client always closes an "
            "idle connection before the server does (issue #50)."
        )
    return expiry


def default_http_limits() -> httpx.Limits:
    """Connection-pool limits shared by the async and sync Pantheon clients."""
    return httpx.Limits(keepalive_expiry=get_keepalive_expiry())


class EastWestLogLevel:
    """
    East-west logging levels for PantheonClient (bit flags for combinable levels).

    Levels are bit flags that can be combined:
    - 1 (ERRORS_ONLY): Log non-2xx responses
    - 2 (ACCESS_LOGS): Log: method, url, status, duration (nginx-style)
    - 4 (REQUEST_DETAILED): Log: request headers, body
    - 8 (RESPONSE_DETAILED): Log: response headers, body

    Examples:
        level=1 → Only errors
        level=3 → Errors + access logs (1 | 2)
        level=15 → All logging (1 | 2 | 4 | 8)
    """
    NONE = 0
    ERRORS_ONLY = 1
    ACCESS_LOGS = 2
    REQUEST_DETAILED = 4
    RESPONSE_DETAILED = 8
    ALL = ERRORS_ONLY | ACCESS_LOGS | REQUEST_DETAILED | RESPONSE_DETAILED  # 15

    @classmethod
    def get_flag_names(cls, level: int) -> List[str]:
        """Get list of enabled flag names for a given level"""
        flags = []
        if level & cls.ERRORS_ONLY:
            flags.append("ERRORS_ONLY")
        if level & cls.ACCESS_LOGS:
            flags.append("ACCESS_LOGS")
        if level & cls.REQUEST_DETAILED:
            flags.append("REQUEST_DETAILED")
        if level & cls.RESPONSE_DETAILED:
            flags.append("RESPONSE_DETAILED")
        return flags

    @classmethod
    def get_human_readable(cls, level: int) -> List[str]:
        """Get human-readable descriptions of enabled flags"""
        descriptions = []
        if level & cls.ERRORS_ONLY:
            descriptions.append("Errors (non-2xx responses)")
        if level & cls.ACCESS_LOGS:
            descriptions.append("Access logs (method, url, status, duration)")
        if level & cls.REQUEST_DETAILED:
            descriptions.append("Request details (headers, body)")
        if level & cls.RESPONSE_DETAILED:
            descriptions.append("Response details (headers, body)")
        return descriptions


@dataclass
class ClientMetrics:
    """In-memory metrics tracking for HTTP client operations"""
    num_2xx: int = 0
    num_3xx: int = 0
    num_4xx: int = 0
    num_5xx: int = 0
    total_requests: int = 0
    total_response_time: float = 0.0

    def record_response(self, status_code: int, response_time: float):
        """Record a response status code and response time"""
        if status_code < 300:
            self.num_2xx += 1
        elif status_code < 400:
            self.num_3xx += 1
        elif status_code < 500:
            self.num_4xx += 1
        else:
            self.num_5xx += 1
        self.total_requests += 1
        self.total_response_time += response_time

    def to_dict(self) -> Dict[str, Any]:
        """Convert metrics to dictionary for JSON serialization"""
        avg_response_time = self.total_response_time / self.total_requests if self.total_requests > 0 else 0
        return {
            "num_2xx": self.num_2xx,
            "num_3xx": self.num_3xx,
            "num_4xx": self.num_4xx,
            "num_5xx": self.num_5xx,
            "total_requests": self.total_requests,
            "total_response_time": round(self.total_response_time, 3),
            "avg_response_time": round(avg_response_time, 3)
        }


def _mint_headers() -> Dict[str, str]:
    """Headers for the service-token mint call (issue #171).

    The minter is the one genuinely circular endpoint -- a caller cannot present
    a JWT to the endpoint that ISSUES JWTs -- so it is gated by a bootstrap
    secret (``PANTHEON_SERVICE_MINT_SECRET``) instead.

    The legacy ``pantheon-app`` marker was dropped in F1 Stage 4 -- the minter
    now enforces the secret and nothing else.
    """
    headers: Dict[str, str] = {}
    mint_secret = os.getenv("PANTHEON_SERVICE_MINT_SECRET")
    if mint_secret:
        headers["pantheon-mint-secret"] = mint_secret
    return headers


class PantheonClientConfigError(ValueError):
    """A PantheonClient was constructed with arguments it cannot work with.

    ⛔ WHY THIS IS A ValueError AND NOT `sys.exit(1)`.
    These checks fire on CALLER ARGUMENTS (a missing `tenant_id`), not on service
    configuration. Every construction site is reachable from a REQUEST — there are ~289
    of them across 15 services, most inside handlers — so the failure must be one a
    handler can catch and turn into a response.

    `sys.exit(1)` raises `SystemExit`, which derives from `BaseException`, NOT `Exception`.
    It therefore escapes every `except Exception` a handler has and kills the gunicorn
    worker mid-request. Measured in pantheon-viz: one widget-verdict call with an
    unresolvable tenant returned HTTP 500 and respawned the worker on EVERY call — a
    degradable diagnostic turned into an outage.

    Subclasses `ValueError` (not bare `Exception`) so existing `except ValueError` handlers
    around client construction keep working, and so the type says what it is: a bad
    argument.
    """


def _fail_fast_on_config_error(error_msg: str) -> None:
    """Raise on a client-construction config error.

    ⚠️ NAME KEPT for compatibility — it is referenced at four call sites and in service-side
    comments. The BEHAVIOUR changed deliberately: it raises instead of exiting.

    Fail-fast is right at STARTUP, where a misconfigured service should refuse to boot. It
    is wrong inside a request handler, where the same call converts one bad request into a
    dead worker. Callers that genuinely want boot-time fail-fast should catch this at
    startup and exit there, where the intent is explicit and the blast radius is one
    process that was never going to work anyway.
    """
    logger.error(
        "PantheonClient configuration error",
        error=error_msg,
        hint="PantheonClient requires service_name and one of tenant_id/tenant_name",
    )
    raise PantheonClientConfigError(error_msg)


def _host_from_url(candidate: str) -> str:
    """Pull the bare host (no scheme, no port, no path) from a URL / base_url string.
    Returns '' if there's no scheme://host to parse."""
    if not candidate or "://" not in candidate:
        return ""
    after_scheme = candidate.split("://", 1)[1]
    authority = after_scheme.split("/", 1)[0]      # host[:port] before any path
    return authority.split(":", 1)[0]              # strip :port


def _resolve_target_service(url, client) -> str:
    """Resolve the east-west target service host for observability.

    Resolve from the actual REQUEST url FIRST — it always carries the real host, whereas the
    client's base_url is frequently EMPTY (callers pass a full URL to .post()/.get() at call time
    rather than constructing the client with a base_url). httpx's AsyncClient always HAS a
    `base_url` attribute (defaults to an empty URL("")), so the old `hasattr(...) and base_url`
    guard was truthy-on-attribute but falsy-on-value → it took neither branch cleanly and left
    target_service='unknown' (the pantheon-program-framework calls that logged it). Returns
    'unknown' only when neither url nor base_url yields a host."""
    try:
        host = _host_from_url(str(url))
        if not host and client is not None and getattr(client, "base_url", None):
            host = _host_from_url(str(client.base_url))
        return host or "unknown"
    except Exception:
        return "unknown"


class PantheonClient:
    """Centralized HTTP client with JWT-based inter-service authentication"""

    # Class-level metrics registry (shared across all instances)
    _metrics_registry: Dict[str, ClientMetrics] = {}

    # Class-level east-west logging configuration (shared across all instances)
    # Format: {service_name: log_level}
    _logging_config: Dict[str, int] = {}

    def __init__(
        self,
        service_name: str,
        tenant_id: Optional[str] = None,
        tenant_name: Optional[str] = None,
        namespace_id: Optional[str] = None,
        namespace_name: Optional[str] = None,
        workspace_id: Optional[str] = None,
        base_url: Optional[str] = None,
        target_service: Optional[Union[str, "PantheonService"]] = None,
        debug: bool = False,
        access_log_level: str = "DEBUG",
        impersonation_context: Optional[Dict[str, Any]] = None,
        user_id: Optional[str] = None,
        **kwargs
    ):
        # Validate required parameters
        if not service_name:
            _fail_fast_on_config_error(
                "PantheonClient: service_name is required. "
                "PantheonClient must be initialized with: "
                "service_name, tenant_name, and namespace_name"
            )

        if not tenant_name and not tenant_id:
            _fail_fast_on_config_error(
                "PantheonClient: Either tenant_name or tenant_id must be provided. "
                "PantheonClient must be initialized with: "
                "service_name, tenant_name, and namespace_name"
            )

        # Namespace is optional - if neither is provided, use "default" as fallback
        if not namespace_name and not namespace_id:
            namespace_name = "default"
            logger.debug(
                "PantheonClient: No namespace provided, using default namespace",
                service=service_name
            )

        self.service_name = service_name
        self.tenant_id = tenant_id
        self.tenant_name = tenant_name
        self.namespace_id = namespace_id
        self.namespace_name = namespace_name
        self.workspace_id = workspace_id
        self.user_id = user_id
        self.debug = debug
        self.access_log_level = access_log_level.upper()
        self.impersonation_context = impersonation_context

        # Get pantheon-auth URL using service registry
        from ..pantheon_services import get_pantheon_service_url, PantheonService
        self.auth_base_url = get_pantheon_service_url(
            PantheonService.AUTH,
            url_env_var="AUTH_SERVICE_URL"
        )

        # Get base_url from target_service if provided, otherwise use explicit base_url
        if target_service and not base_url:
            base_url = get_pantheon_service_url(target_service)

        # Store base_url for API requests (optional, for routing to specific services)
        self.base_url = base_url

        # Initialize token cache - use global singleton to share tokens across all client instances
        self.token_cache = get_global_token_cache()

        # Initialize underlying httpx client with base_url if provided
        if base_url:
            kwargs['base_url'] = base_url
        # Enable redirect following to handle 307/308 redirects from services
        kwargs.setdefault('follow_redirects', True)
        # Pin the pooled-connection idle expiry below nginx's (issue #50).
        kwargs.setdefault('limits', default_http_limits())
        self._client = httpx.AsyncClient(**kwargs)

        # Create or get metrics instance for this service
        if service_name not in self._metrics_registry:
            self._metrics_registry[service_name] = ClientMetrics()
        self.metrics = self._metrics_registry[service_name]

        # Initialize east-west logging level from environment variable or default to NONE
        # PANTHEON_EAST_WEST_LOG_LEVEL is a global setting across all services
        if service_name not in self._logging_config:
            default_level = int(os.getenv("PANTHEON_EAST_WEST_LOG_LEVEL", "0"))
            self._logging_config[service_name] = default_level

        # Initialize access logger with configurable level - use same logger as main client
        self.access_logger = logger  # Use the same logger instance

        # PantheonClient initialization logging
        logger.debug(
            f"PantheonClient Initialized for {service_name}"
        )

        if self.debug:
            logger.debug(
                "PantheonClient DEBUG MODE - initialized",
                service=service_name,
                tenant=tenant_id,
                namespace=namespace_id,
                httpx_config=kwargs
            )

    @classmethod
    def for_service(
        cls,
        service_name: str,
        target_service: Union[str, "PantheonService"],
        tenant_id: Optional[str] = None,
        tenant_name: Optional[str] = None,
        namespace_id: Optional[str] = None,
        namespace_name: Optional[str] = None,
        debug: bool = False,
        access_log_level: str = "DEBUG",
        impersonation_context: Optional[Dict[str, Any]] = None,
        user_id: Optional[str] = None,
        **kwargs
    ) -> "PantheonClient":
        """
        Create a PantheonClient configured for a specific target service.

        This is a convenience factory method that automatically resolves the target
        service's URL using the Pantheon service registry.

        Args:
            service_name: Name of the calling service (e.g., "pantheon-integration")
            target_service: The PantheonService enum or service name to connect to
            tenant_id: Optional tenant ID
            tenant_name: Optional tenant name
            namespace_id: Optional namespace ID
            namespace_name: Optional namespace name
            debug: Enable debug mode
            access_log_level: Access log level (default: "DEBUG")
            impersonation_context: Optional impersonation context to preserve across services
            **kwargs: Additional arguments passed to httpx.AsyncClient

        Returns:
            A configured PantheonClient instance with base_url set to the target service

        Examples:
            >>> from pantheon_shared.http import PantheonClient
            >>> from pantheon_shared.pantheon_services import PantheonService
            >>>
            >>> # Create a client for the workflow framework
            >>> client = PantheonClient.for_service(
            ...     service_name="pantheon-integration",
            ...     target_service=PantheonService.WORKFLOW_FRAMEWORK,
            ...     tenant_name="default",
            ...     namespace_name="default"
            ... )
            >>> response = await client.get("/api/v1/providers")
        """
        return cls(
            service_name=service_name,
            tenant_id=tenant_id,
            tenant_name=tenant_name,
            namespace_id=namespace_id,
            namespace_name=namespace_name,
            target_service=target_service,
            debug=debug,
            access_log_level=access_log_level,
            impersonation_context=impersonation_context,
            user_id=user_id,
            **kwargs
        )

    # =========================================================================
    # East-West Logging Configuration Methods
    # =========================================================================

    @classmethod
    def set_logging_level(cls, service_name: str, level: int) -> None:
        """
        Set east-west logging level for a service.

        Args:
            service_name: Name of the service (e.g., "pantheon-integration")
            level: Logging level (bitmask: 1=errors, 2=access, 4=req-detail, 8=resp-detail)
        """
        cls._logging_config[service_name] = level

    @classmethod
    def get_logging_level(cls, service_name: str) -> int:
        """
        Get east-west logging level for a service.

        Args:
            service_name: Name of the service

        Returns:
            Logging level (0-15)
        """
        return cls._logging_config.get(service_name, EastWestLogLevel.NONE)

    @classmethod
    def get_logging_config_dict(cls, service_name: str) -> Dict[str, Any]:
        """
        Get logging configuration as a dictionary with human-readable flags.

        Args:
            service_name: Name of the service

        Returns:
            Dictionary with level, flags, and is_all fields
        """
        level = cls.get_logging_level(service_name)
        return {
            "service_name": service_name,
            "level": level,
            "flags": EastWestLogLevel.get_flag_names(level),
            "is_all": level == EastWestLogLevel.ALL
        }

    @classmethod
    def get_all_logging_configs(cls) -> Dict[str, Any]:
        """
        Get logging configurations for all services.

        Returns:
            Dictionary with service names as keys and their configs as values
        """
        return {
            service_name: cls.get_logging_config_dict(service_name)
            for service_name in cls._logging_config
        }

    async def request(
        self,
        method: str,
        url: str,
        context: Optional[Dict[str, Any]] = None,  # Additional context to pass
        **kwargs
    ) -> httpx.Response:
        """Make authenticated HTTP request with proper context"""

        # DB session-lifetime guard. This is the single funnel every east-west
        # call passes through (get/post/paginated_get all route here), so it is
        # the one place that can see "a network round trip is starting".
        #
        # Holding a pooled DB connection across this call is what wedged
        # detection-framework, workflow-framework and program-framework (8 sites
        # found 2026-08-12; holds of 50s, 330s and 600s on pools of 3-8). Strict
        # by default — set DB_GUARD_STRICT_DISABLE=true to downgrade to warning.
        #
        # Deliberately NOT wrapped in try/except: a guard that swallows its own
        # failure is not a guard. It only trips when a caller has explicitly
        # marked a session open via db_guard.session_scope().
        from ..db_guard import assert_no_session_held
        assert_no_session_held(f"{method} {url}")

        # Get calling function for access logging
        import inspect
        calling_fn = "unknown"
        try:
            frame = inspect.currentframe()
            if frame and frame.f_back:
                calling_fn = frame.f_back.f_code.co_name
        except:
            pass

        if self.debug:
            logger.debug(
                "PantheonClient DEBUG - request called",
                service=self.service_name,
                method=method,
                url=url,
                context=context,
                kwargs_keys=list(kwargs.keys())
            )

        # Prepare headers
        headers = kwargs.setdefault("headers", {})

        # Inject trace context for distributed tracing
        # If we have a current trace context, create a child span and propagate headers
        try:
            from ..tracing import get_current_trace_context, TraceContext
            trace_ctx = get_current_trace_context()
            if trace_ctx:
                # Create child span context for this outgoing call
                child_ctx = TraceContext.from_parent(
                    parent_trace_id=trace_ctx.trace_id,
                    parent_span_id=trace_ctx.span_id,
                    service_name=self.service_name,
                    operation_name=f"{method} {url}",
                )
                headers.update(child_ctx.to_headers())
                request_id = child_ctx.trace_id
            else:
                # No trace context - generate new request ID
                request_id = headers.get("x-request-id", str(uuid.uuid4()))
                headers["x-request-id"] = request_id
                headers["X-Trace-ID"] = request_id
        except ImportError:
            # Tracing module not available - fallback to old behavior
            request_id = headers.get("x-request-id", str(uuid.uuid4()))
            headers["x-request-id"] = request_id

        # Add service identity headers
        headers["x-service-name"] = self.service_name
        if self.tenant_name:
            headers["x-tenant-name"] = self.tenant_name
        if self.namespace_name:
            headers["x-namespace-name"] = self.namespace_name

        # Add JWT authentication
        token = await self._get_token()
        headers["Authorization"] = f"Bearer {token}"

        # Add additional context if provided
        if context:
            headers["x-context"] = str(context)

        if self.debug:
            logger.debug(
                "PantheonClient DEBUG - headers prepared",
                service=self.service_name,
                request_id=request_id,
                all_headers=dict(headers),
                context=context,
                token_preview=f"{token[:20]}..." if len(token) > 20 else token
            )

        # =========================================================================
        # East-West Logging: Get logging level and prepare request details
        # =========================================================================
        log_level = self.get_logging_level(self.service_name)

        # Resolve target service host for observability (request URL first, base_url fallback).
        target_service = _resolve_target_service(url, getattr(self, "_client", None))

        # Capture request details for REQUEST_DETAILED logging
        request_headers_copy = None
        request_body_copy = None
        if log_level & EastWestLogLevel.REQUEST_DETAILED:
            # Make a copy of headers (excluding sensitive auth header)
            request_headers_copy = {k: v for k, v in headers.items() if k.lower() != "authorization"}
            # Capture request body if present
            request_body_copy = kwargs.get("json") or kwargs.get("data")

        # Log request for observability
        start_time = time.time()
        logger.debug(
            "inter-service-request-start",
            service=self.service_name,
            target_service=target_service,
            method=method,
            url=url,
            request_id=request_id,
            has_context=bool(context)
        )

        try:
            response = await self._client.request(method, url, **kwargs)
            duration = time.time() - start_time

            # Record metrics
            self.metrics.record_response(response.status_code, duration)

            # =========================================================================
            # East-West Logging: Log based on configured level
            # =========================================================================
            try:
                # 1. ERRORS_ONLY: Log non-2xx responses
                if (log_level & EastWestLogLevel.ERRORS_ONLY) and (response.status_code >= 300 and response.status_code != 409):
                    logger.error(
                        "east-west-error",
                        service=self.service_name,
                        target_service=target_service,
                        method=method,
                        url=str(url),
                        status=response.status_code,
                        duration_ms=round(duration * 1000, 2),
                        request_id=request_id
                    )

                # 2. ACCESS_LOGS: Log all requests (nginx-style access log)
                if log_level & EastWestLogLevel.ACCESS_LOGS:
                    # Use error level for non-2xx responses, info for success
                    log_fn = logger.error if (response.status_code >= 300 and response.status_code != 409) else logger.info
                    log_fn(
                        "east-west-access",
                        service=self.service_name,
                        target_service=target_service,
                        method=method,
                        url=str(url),
                        status=response.status_code,
                        duration_ms=round(duration * 1000, 2),
                        request_id=request_id
                    )

                # 3. REQUEST_DETAILED: Log request headers and body
                if log_level & EastWestLogLevel.REQUEST_DETAILED:
                    logger.info(
                        "east-west-request-detail",
                        service=self.service_name,
                        target_service=target_service,
                        method=method,
                        url=str(url),
                        headers=request_headers_copy,
                        body=request_body_copy,
                        request_id=request_id
                    )

                # 4. RESPONSE_DETAILED: Log response headers and body
                if log_level & EastWestLogLevel.RESPONSE_DETAILED:
                    # Limit response body size to avoid huge logs (10KB max)
                    response_body = None
                    try:
                        if hasattr(response, 'text') and response.text:
                            response_body = response.text[:10000] if len(response.text) > 10000 else response.text
                    except Exception:
                        response_body = "<unable to decode response body>"

                    logger.info(
                        "east-west-response-detail",
                        service=self.service_name,
                        target_service=target_service,
                        method=method,
                        url=str(url),
                        status=response.status_code,
                        headers=dict(response.headers),
                        body=response_body,
                        request_id=request_id
                    )
            except Exception as log_error:
                # East-west logging should never break the request
                logger.warning(
                    "east-west-logging-error",
                    service=self.service_name,
                    error=str(log_error),
                    request_id=request_id
                )

            # Existing debug logging
            if self.debug:
                logger.debug(
                    "PantheonClient DEBUG - HTTP response received",
                    service=self.service_name,
                    request_id=request_id,
                    status=response.status_code,
                    headers=dict(response.headers),
                    duration_ms=duration * 1000
                )

            logger.debug(
                "inter-service-request-complete",
                service=self.service_name,
                method=method,
                url=url,
                request_id=request_id,
                status=response.status_code,
                duration_ms=duration * 1000
            )

            return response

        except Exception as e:
            duration = time.time() - start_time

            # Record metrics for errors (treat as 5xx)
            self.metrics.record_response(500, duration)

            # =========================================================================
            # East-West Logging: Log exceptions if ERRORS_ONLY is enabled
            # =========================================================================
            try:
                if log_level & EastWestLogLevel.ERRORS_ONLY:
                    logger.error(
                        "east-west-error",
                        service=self.service_name,
                        target_service=target_service,
                        method=method,
                        url=str(url),
                        error_type=type(e).__name__,
                        error_message=str(e),
                        duration_ms=round(duration * 1000, 2),
                        request_id=request_id
                    )
            except Exception:
                # East-west logging should never break the request
                pass

            # Access logging is handled by the enhanced debug logging below

            if self.debug:
                logger.debug(
                    "PantheonClient DEBUG - HTTP request failed with exception",
                    service=self.service_name,
                    request_id=request_id,
                    exception_type=type(e).__name__,
                    exception_message=str(e),
                    exception_details=e.__dict__ if hasattr(e, '__dict__') else None
                )

            logger.error(
                "inter-service-request-error",
                service=self.service_name,
                method=method,
                url=url,
                request_id=request_id,
                error=str(e),
                duration_ms=duration * 1000
            )
            raise

    async def _get_token(self) -> str:
        """Get JWT token from pantheon-auth API"""

        # Build cache key including tenant_name, namespace_name, user_id, and impersonation context for uniqueness
        impersonation_key = ""
        if self.impersonation_context:
            # Add impersonation context to cache key to get separate tokens for impersonated requests
            impersonation_key = f":imp:{self.impersonation_context.get('token_type')}:{self.impersonation_context.get('original_tenant_id')}"
        user_key = f":user:{self.user_id}" if self.user_id else ""
        cache_key = f"service:{self.service_name}:{self.tenant_id}:{self.tenant_name}:{self.namespace_id}:{self.namespace_name}{user_key}{impersonation_key}"

        # Check cache first
        cached_token = self.token_cache.get(cache_key)
        if cached_token:
            return cached_token

        # Request new token from pantheon-auth
        token_validity = int(os.getenv("PANTHEON_SERVICE_TOKEN_VALIDITY", "3600"))

        # Use delegated token endpoint when user_id is provided to carry real user identity
        if self.user_id:
            request_data = {
                "service_name": self.service_name,
                "user_id": str(self.user_id),
                "scopes": [],
            }
            if self.tenant_id:
                request_data["tenant_id"] = str(self.tenant_id)
            elif self.tenant_name:
                request_data["tenant_name"] = self.tenant_name
            if self.namespace_id:
                request_data["namespace_id"] = str(self.namespace_id)
            elif self.namespace_name:
                request_data["namespace_name"] = self.namespace_name
            token_url = f"{self.auth_base_url}/api/v1/internal/tokens/delegated"
        else:
            request_data = {
                "service_name": self.service_name,
                "token_validity": token_validity
            }

            # Add tenant information (coerce UUIDs to strings for JSON serialization)
            if self.tenant_id:
                request_data["tenant_id"] = str(self.tenant_id)
            elif self.tenant_name:
                request_data["tenant_name"] = self.tenant_name

            if self.namespace_id:
                request_data["namespace_id"] = str(self.namespace_id)
            elif self.namespace_name:
                request_data["namespace_name"] = self.namespace_name

            # Add impersonation context if present
            if self.impersonation_context:
                request_data["impersonation_context"] = self.impersonation_context

            token_url = f"{self.auth_base_url}/api/v1/internal/tokens/service"

        # Use a separate httpx client for auth calls to avoid circular dependency
        # but still record metrics for internal auth requests
        try:

            # Record metrics for internal auth request
            start_time = time.time()
            request_id = str(uuid.uuid4())[:8]

            if self.access_logger:
                self.access_logger.debug(
                    "🔥 ACCESS_LOG - INTERNAL AUTH REQUEST",
                    http_method="POST",
                    http_url=token_url,
                    request_id=request_id,
                    user_agent="pantheon-shared/internal-auth",
                    content_length=len(str(request_data)),
                    service_name=self.service_name
                )

            async with httpx.AsyncClient(timeout=30.0, follow_redirects=True) as auth_client:
                response = await auth_client.post(
                    token_url,
                    json=request_data,
                    headers=_mint_headers()
                )

                response.raise_for_status()
                token_data = response.json()
                token = token_data["access_token"]
                expires_in = token_data.get("expires_in", 3600)

                # Calculate response time and record in metrics
                response_time = time.time() - start_time
                self.metrics.record_response(response.status_code, response_time)

                if self.access_logger:
                    self.access_logger.debug(
                        "🔥 ACCESS_LOG - INTERNAL AUTH RESPONSE",
                        http_method="POST",
                        http_url=token_url,
                        status_code=response.status_code,
                        response_time=response_time,
                        response_length=len(response.content),
                        request_id=request_id,
                        user_agent="pantheon-shared/internal-auth",
                        service_name=self.service_name
                    )

                # Cache token at a percentage of the actual token lifetime returned by the
                # auth service (expires_in), not the requested token_validity. This is critical
                # for delegated tokens: the auth service issues them with a fixed 30-minute
                # lifetime regardless of what token_validity was requested, and expires_in
                # reflects that actual lifetime. Using token_validity (3600s default) would
                # cache a 30-minute delegated token for 48 minutes, causing _get_token() to
                # return a cached-but-JWT-expired token during the 30-48 minute window.
                cache_percentage = float(os.getenv("PANTHEON_SERVICE_TOKEN_CACHE_PERCENTAGE", "0.8"))
                cache_ttl_seconds = int(expires_in * cache_percentage)
                self.token_cache.set(cache_key, token, expires_in_seconds=cache_ttl_seconds)

                logger.debug(
                    "  - PantheonClient ASYNC new token cached and returned",
                    service=self.service_name,
                    cache_key=cache_key,
                    token_preview=f"{token[:20]}..." if len(token) > 20 else token
                )

                return token

        except Exception as e:
            # Record metrics for auth errors (treat as 5xx)
            duration = time.time() - start_time if 'start_time' in locals() else 0.0
            self.metrics.record_response(500, duration)

            #  DEBUG: Async token request failure
            logger.error(
                "  - PantheonClient ASYNC FAILED to get token from pantheon-auth",
                service=self.service_name,
                token_url=token_url,
                request_data=request_data,
                error_type=type(e).__name__,
                error_message=str(e),
                exception_details=e.__dict__ if hasattr(e, '__dict__') else None
            )
            raise

    # Convenience methods
    async def get(self, url: str, context: Optional[Dict[str, Any]] = None, **kwargs) -> httpx.Response:
        """GET request"""
        return await self.request("GET", url, context=context, **kwargs)

    async def paginated_get(
        self,
        url: str,
        items_key: str = "items",
        context: Optional[Dict[str, Any]] = None,
        max_pages: int = 10,
        **kwargs
    ) -> List[Dict[str, Any]]:
        """
        GET request with automatic pagination support.

        Fetches all pages from a paginated endpoint and returns all items.
        Supports page/size pagination with configurable max pages.

        Args:
            url: The URL to fetch (can include query parameters)
            items_key: The key in the response JSON that contains the items array
            context: Optional context dict for logging
            max_pages: Maximum number of pages to fetch (default: 10, safety limit)
            **kwargs: Additional arguments passed to httpx get()

        Returns:
            List of all items from all pages

        Example:
            # Fetch all APIs (handles pagination automatically)
            apis = await client.paginated_get(
                "/api/v1/apis",
                items_key="apis",
                params={"api_group_id": group_id, "size": 100}
            )
        """
        all_items = []
        page = 1

        # Extract params if provided
        params = kwargs.get("params", {})
        if isinstance(params, dict):
            params = params.copy()
        else:
            params = {}

        # Set a reasonable default page size if not specified
        if "size" not in params:
            params["size"] = 100

        # Set initial page
        params["page"] = page
        kwargs["params"] = params

        while page <= max_pages:
            response = await self.get(url, context=context, **kwargs)

            if response.status_code != 200:
                logger.warning(
                    "paginated_get failed",
                    url=url,
                    status_code=response.status_code,
                    page=page
                )
                break

            data = response.json()
            items = data.get(items_key, [])

            if not items:
                # No more items
                break

            all_items.extend(items)
            page += 1

            # Check if there are more pages
            # If we got fewer items than requested, we're on the last page
            requested_size = params.get("size", 100)
            if len(items) < requested_size:
                break

            # Update page for next request
            params["page"] = page
            kwargs["params"] = params

        if page > max_pages:
            logger.warning(
                "paginated_get reached max_pages limit",
                url=url,
                max_pages=max_pages,
                total_items=len(all_items)
            )

        return all_items

    async def post(self, url: str, context: Optional[Dict[str, Any]] = None, **kwargs) -> httpx.Response:
        """POST request"""
        return await self.request("POST", url, context=context, **kwargs)

    async def put(self, url: str, context: Optional[Dict[str, Any]] = None, **kwargs) -> httpx.Response:
        """PUT request"""
        return await self.request("PUT", url, context=context, **kwargs)

    async def delete(self, url: str, context: Optional[Dict[str, Any]] = None, **kwargs) -> httpx.Response:
        """DELETE request"""
        return await self.request("DELETE", url, context=context, **kwargs)

    async def close(self):
        """Close the underlying httpx client"""
        await self._client.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()


class PantheonSyncClient:
    """Synchronous version of PantheonClient for non-async contexts"""

    # Class-level east-west logging configuration (shared across all instances)
    # Format: {service_name: log_level}
    _logging_config: Dict[str, int] = {}

    def __init__(
        self,
        service_name: str,
        tenant_id: Optional[str] = None,
        tenant_name: Optional[str] = None,
        namespace_id: Optional[str] = None,
        namespace_name: Optional[str] = None,
        workspace_id: Optional[str] = None,
        base_url: Optional[str] = None,
        target_service: Optional[Union[str, "PantheonService"]] = None,
        debug: bool = False,
        access_log_level: str = "DEBUG",
        impersonation_context: Optional[Dict[str, Any]] = None,
        **kwargs
    ):
        # Validate required parameters
        if not service_name:
            _fail_fast_on_config_error(
                "PantheonSyncClient: service_name is required. "
                "PantheonClient must be initialized with: "
                "service_name, tenant_name, and namespace_name"
            )

        if not tenant_name and not tenant_id:
            _fail_fast_on_config_error(
                "PantheonSyncClient: Either tenant_name or tenant_id must be provided. "
                "PantheonClient must be initialized with: "
                "service_name, tenant_name, and namespace_name"
            )

        # Namespace is optional - if neither is provided, use "default" as fallback
        if not namespace_name and not namespace_id:
            namespace_name = "default"
            logger.debug(
                "PantheonSyncClient: No namespace provided, using default namespace",
                service=service_name
            )

        self.service_name = service_name
        self.tenant_id = tenant_id
        self.tenant_name = tenant_name
        self.namespace_id = namespace_id
        self.namespace_name = namespace_name
        self.workspace_id = workspace_id
        self.debug = debug
        self.access_log_level = access_log_level.upper()
        self.impersonation_context = impersonation_context

        # Get pantheon-auth URL using service registry
        from ..pantheon_services import get_pantheon_service_url, PantheonService
        self.auth_base_url = get_pantheon_service_url(
            PantheonService.AUTH,
            url_env_var="AUTH_SERVICE_URL"
        )

        # Get base_url from target_service if provided, otherwise use explicit base_url
        if target_service and not base_url:
            base_url = get_pantheon_service_url(target_service)

        # Store base_url for API requests (optional, for routing to specific services)
        self.base_url = base_url

        # Initialize token cache - use global singleton to share tokens across all client instances
        self.token_cache = get_global_token_cache()

        # Initialize underlying httpx client with base_url if provided
        if base_url:
            kwargs['base_url'] = base_url
        # Enable redirect following to handle 307/308 redirects from services
        kwargs.setdefault('follow_redirects', True)
        # Pin the pooled-connection idle expiry below nginx's (issue #50).
        kwargs.setdefault('limits', default_http_limits())
        self._client = httpx.Client(**kwargs)

        # Create or get metrics instance for this service (reuse registry from PantheonClient)
        if service_name not in PantheonClient._metrics_registry:
            PantheonClient._metrics_registry[service_name] = ClientMetrics()
        self.metrics = PantheonClient._metrics_registry[service_name]

        # Initialize east-west logging level from environment variable or default to NONE
        # PANTHEON_EAST_WEST_LOG_LEVEL is a global setting across all services
        if service_name not in self._logging_config:
            default_level = int(os.getenv("PANTHEON_EAST_WEST_LOG_LEVEL", "0"))
            self._logging_config[service_name] = default_level

        # Initialize access logger with configurable level - use same logger as main client
        self.access_logger = logger  # Use the same logger instance

        if self.debug:
            logger.debug(
                "PantheonSyncClient DEBUG MODE - initialized",
                service=service_name,
                tenant=tenant_id,
                namespace=namespace_id,
                httpx_config=kwargs
            )

        logger.debug(
            "PantheonSyncClient initialized",
            service=service_name,
            tenant=tenant_id,
            namespace=namespace_id,
            debug_mode=debug
        )

    @classmethod
    def for_service(
        cls,
        service_name: str,
        target_service: Union[str, "PantheonService"],
        tenant_id: Optional[str] = None,
        tenant_name: Optional[str] = None,
        namespace_id: Optional[str] = None,
        namespace_name: Optional[str] = None,
        debug: bool = False,
        access_log_level: str = "DEBUG",
        impersonation_context: Optional[Dict[str, Any]] = None,
        **kwargs
    ) -> "PantheonSyncClient":
        """
        Create a PantheonSyncClient configured for a specific target service.

        This is a convenience factory method that automatically resolves the target
        service's URL using the Pantheon service registry.

        Args:
            service_name: Name of the calling service (e.g., "pantheon-integration")
            target_service: The PantheonService enum or service name to connect to
            tenant_id: Optional tenant ID
            tenant_name: Optional tenant name
            namespace_id: Optional namespace ID
            namespace_name: Optional namespace name
            debug: Enable debug mode
            access_log_level: Access log level (default: "DEBUG")
            impersonation_context: Optional impersonation context to preserve across services
            **kwargs: Additional arguments passed to httpx.Client

        Returns:
            A configured PantheonSyncClient instance with base_url set to the target service

        Examples:
            >>> from pantheon_shared.http import PantheonSyncClient
            >>> from pantheon_shared.pantheon_services import PantheonService
            >>>
            >>> # Create a client for the workflow framework
            >>> client = PantheonSyncClient.for_service(
            ...     service_name="pantheon-integration",
            ...     target_service=PantheonService.WORKFLOW_FRAMEWORK,
            ...     tenant_name="default",
            ...     namespace_name="default"
            ... )
            >>> response = client.get("/api/v1/providers")
        """
        return cls(
            service_name=service_name,
            tenant_id=tenant_id,
            tenant_name=tenant_name,
            namespace_id=namespace_id,
            namespace_name=namespace_name,
            target_service=target_service,
            debug=debug,
            access_log_level=access_log_level,
            impersonation_context=impersonation_context,
            **kwargs
        )

    # =========================================================================
    # East-West Logging Configuration Methods
    # =========================================================================

    @classmethod
    def set_logging_level(cls, service_name: str, level: int) -> None:
        """
        Set east-west logging level for a service.

        Args:
            service_name: Name of the service (e.g., "pantheon-integration")
            level: Logging level (bitmask: 1=errors, 2=access, 4=req-detail, 8=resp-detail)
        """
        cls._logging_config[service_name] = level

    @classmethod
    def get_logging_level(cls, service_name: str) -> int:
        """
        Get east-west logging level for a service.

        Args:
            service_name: Name of the service

        Returns:
            Logging level (0-15)
        """
        return cls._logging_config.get(service_name, EastWestLogLevel.NONE)

    @classmethod
    def get_logging_config_dict(cls, service_name: str) -> Dict[str, Any]:
        """
        Get logging configuration as a dictionary with human-readable flags.

        Args:
            service_name: Name of the service

        Returns:
            Dictionary with level, flags, and is_all fields
        """
        level = cls.get_logging_level(service_name)
        return {
            "service_name": service_name,
            "level": level,
            "flags": EastWestLogLevel.get_flag_names(level),
            "is_all": level == EastWestLogLevel.ALL
        }

    @classmethod
    def get_all_logging_configs(cls) -> Dict[str, Any]:
        """
        Get logging configurations for all services.

        Returns:
            Dictionary with service names as keys and their configs as values
        """
        return {
            service_name: cls.get_logging_config_dict(service_name)
            for service_name in cls._logging_config
        }

    def request(
        self,
        method: str,
        url: str,
        context: Optional[Dict[str, Any]] = None,
        **kwargs
    ) -> httpx.Response:
        """Make authenticated HTTP request with proper context"""

        # DB session-lifetime guard — see the note on PantheonClient.request().
        # The SYNC client needs it at least as much as the async one: every
        # confirmed session-across-IO site found so far (action_worker,
        # invocation_worker, scheduler_service) is synchronous code holding a
        # sync Session across a blocking east-west call.
        from ..db_guard import assert_no_session_held
        assert_no_session_held(f"{method} {url}")

        # Get calling function for access logging
        import inspect
        calling_fn = "unknown"
        try:
            frame = inspect.currentframe()
            if frame and frame.f_back:
                calling_fn = frame.f_back.f_code.co_name
        except:
            pass

        if self.debug:
            logger.debug(
                "PantheonSyncClient DEBUG - request called",
                service=self.service_name,
                method=method,
                url=url,
                context=context,
                kwargs_keys=list(kwargs.keys())
            )

        # Prepare headers
        headers = kwargs.setdefault("headers", {})

        # Inject trace context for distributed tracing
        # If we have a current trace context, create a child span and propagate headers
        try:
            from ..tracing import get_current_trace_context, TraceContext
            trace_ctx = get_current_trace_context()
            if trace_ctx:
                # Create child span context for this outgoing call
                child_ctx = TraceContext.from_parent(
                    parent_trace_id=trace_ctx.trace_id,
                    parent_span_id=trace_ctx.span_id,
                    service_name=self.service_name,
                    operation_name=f"{method} {url}",
                )
                headers.update(child_ctx.to_headers())
                request_id = child_ctx.trace_id
            else:
                # No trace context - generate new request ID
                request_id = headers.get("x-request-id", str(uuid.uuid4()))
                headers["x-request-id"] = request_id
                headers["X-Trace-ID"] = request_id
        except ImportError:
            # Tracing module not available - fallback to old behavior
            request_id = headers.get("x-request-id", str(uuid.uuid4()))
            headers["x-request-id"] = request_id

        # Add service identity headers
        headers["x-service-name"] = self.service_name
        if self.tenant_name:
            headers["x-tenant-name"] = self.tenant_name
        if self.namespace_name:
            headers["x-namespace-name"] = self.namespace_name

        # Add JWT authentication
        token = self._get_token()
        headers["Authorization"] = f"Bearer {token}"

        # Add additional context if provided
        if context:
            headers["x-context"] = str(context)

        if self.debug:
            logger.debug(
                "PantheonSyncClient DEBUG - headers prepared",
                service=self.service_name,
                request_id=request_id,
                all_headers=dict(headers),
                context=context,
                token_preview=f"{token[:20]}..." if len(token) > 20 else token
            )

        # =========================================================================
        # East-West Logging: Get logging level and prepare request details
        # =========================================================================
        log_level = self.get_logging_level(self.service_name)

        # Resolve target service host for observability (request URL first, base_url fallback).
        target_service = _resolve_target_service(url, getattr(self, "_client", None))

        # Capture request details for REQUEST_DETAILED logging
        request_headers_copy = None
        request_body_copy = None
        if log_level & EastWestLogLevel.REQUEST_DETAILED:
            # Make a copy of headers (excluding sensitive auth header)
            request_headers_copy = {k: v for k, v in headers.items() if k.lower() != "authorization"}
            # Capture request body if present
            request_body_copy = kwargs.get("json") or kwargs.get("data")

        # Log request for observability
        start_time = time.time()
        logger.debug(
            "inter-service-request-start",
            service=self.service_name,
            target_service=target_service,
            method=method,
            url=url,
            request_id=request_id,
            has_context=bool(context),
            client_type="sync"
        )

        try:
            if self.debug:
                logger.debug(
                    "PantheonSyncClient DEBUG - sending HTTP request",
                    service=self.service_name,
                    request_id=request_id,
                    full_kwargs=kwargs
                )

            response = self._client.request(method, url, **kwargs)
            duration = time.time() - start_time

            # Record metrics
            self.metrics.record_response(response.status_code, duration)

            # =========================================================================
            # East-West Logging: Log based on configured level
            # =========================================================================
            try:
                # 1. ERRORS_ONLY: Log non-2xx responses
                if (log_level & EastWestLogLevel.ERRORS_ONLY) and (response.status_code >= 300 and response.status_code != 409):
                    logger.error(
                        "east-west-error",
                        service=self.service_name,
                        target_service=target_service,
                        method=method,
                        url=str(url),
                        status=response.status_code,
                        duration_ms=round(duration * 1000, 2),
                        request_id=request_id,
                        client_type="sync"
                    )

                # 2. ACCESS_LOGS: Log all requests (nginx-style access log)
                if log_level & EastWestLogLevel.ACCESS_LOGS:
                    # Use error level for non-2xx responses, info for success
                    log_fn = logger.error if (response.status_code >= 300 and response.status_code != 409) else logger.info
                    log_fn(
                        "east-west-access",
                        service=self.service_name,
                        target_service=target_service,
                        method=method,
                        url=str(url),
                        status=response.status_code,
                        duration_ms=round(duration * 1000, 2),
                        request_id=request_id,
                        client_type="sync"
                    )

                # 3. REQUEST_DETAILED: Log request headers and body
                if log_level & EastWestLogLevel.REQUEST_DETAILED:
                    logger.info(
                        "east-west-request-detail",
                        service=self.service_name,
                        target_service=target_service,
                        method=method,
                        url=str(url),
                        headers=request_headers_copy,
                        body=request_body_copy,
                        request_id=request_id,
                        client_type="sync"
                    )

                # 4. RESPONSE_DETAILED: Log response headers and body
                if log_level & EastWestLogLevel.RESPONSE_DETAILED:
                    # Limit response body size to avoid huge logs (10KB max)
                    response_body = None
                    try:
                        if hasattr(response, 'text') and response.text:
                            response_body = response.text[:10000] if len(response.text) > 10000 else response.text
                    except Exception:
                        response_body = "<unable to decode response body>"

                    logger.info(
                        "east-west-response-detail",
                        service=self.service_name,
                        target_service=target_service,
                        method=method,
                        url=str(url),
                        status=response.status_code,
                        headers=dict(response.headers),
                        body=response_body,
                        request_id=request_id,
                        client_type="sync"
                    )
            except Exception as log_error:
                # East-west logging should never break the request
                logger.warning(
                    "east-west-logging-error",
                    service=self.service_name,
                    error=str(log_error),
                    request_id=request_id,
                    client_type="sync"
                )

            if self.debug:
                logger.debug(
                    "PantheonSyncClient DEBUG - HTTP response received",
                    service=self.service_name,
                    request_id=request_id,
                    status=response.status_code,
                    headers=dict(response.headers),
                    duration_ms=duration * 1000
                )

            logger.debug(
                "inter-service-request-complete",
                service=self.service_name,
                method=method,
                url=url,
                request_id=request_id,
                status=response.status_code,
                duration_ms=duration * 1000
            )

            return response

        except Exception as e:
            duration = time.time() - start_time

            # Record metrics for errors (treat as 5xx)
            self.metrics.record_response(500, duration)

            # =========================================================================
            # East-West Logging: Log exceptions if ERRORS_ONLY is enabled
            # =========================================================================
            try:
                if log_level & EastWestLogLevel.ERRORS_ONLY:
                    logger.error(
                        "east-west-error",
                        service=self.service_name,
                        target_service=target_service,
                        method=method,
                        url=str(url),
                        error_type=type(e).__name__,
                        error_message=str(e),
                        duration_ms=round(duration * 1000, 2),
                        request_id=request_id,
                        client_type="sync"
                    )
            except Exception:
                # East-west logging should never break the request
                pass

            if self.debug:
                logger.debug(
                    "PantheonSyncClient DEBUG - HTTP request failed with exception",
                    service=self.service_name,
                    request_id=request_id,
                    exception_type=type(e).__name__,
                    exception_message=str(e),
                    exception_details=e.__dict__ if hasattr(e, '__dict__') else None
                )

            logger.error(
                "inter-service-request-error",
                service=self.service_name,
                method=method,
                url=url,
                request_id=request_id,
                error=str(e),
                duration_ms=duration * 1000
            )
            raise

    def _get_token(self) -> str:
        """Get JWT token from pantheon-auth API"""

        # Build cache key including tenant_name, namespace_name, and impersonation context for uniqueness
        impersonation_key = ""
        if self.impersonation_context:
            # Add impersonation context to cache key to get separate tokens for impersonated requests
            impersonation_key = f":imp:{self.impersonation_context.get('token_type')}:{self.impersonation_context.get('original_tenant_id')}"
        cache_key = f"service:{self.service_name}:{self.tenant_id}:{self.tenant_name}:{self.namespace_id}:{self.namespace_name}{impersonation_key}"

        #  DEBUG: Token request initiation
        logger.debug(
            "  - PantheonClient requesting JWT token",
            service=self.service_name,
            tenant_id=self.tenant_id,
            tenant_name=self.tenant_name,
            namespace_id=self.namespace_id,
            namespace_name=self.namespace_name,
            cache_key=cache_key,
            auth_base_url=self.auth_base_url
        )

        # Check cache first
        cached_token = self.token_cache.get(cache_key)
        if cached_token:
            logger.debug(
                "  - Using CACHED token (cache hit)",
                service=self.service_name,
                cache_key=cache_key,
                token_preview=f"{cached_token[:20]}..." if len(cached_token) > 20 else cached_token
            )
            return cached_token

        #  DEBUG: Cache miss - requesting new token
        logger.debug(
            "  - Cache miss - requesting NEW token from pantheon-auth",
            service=self.service_name,
            cache_key=cache_key
        )

        # : Token request logging as requested
        logger.debug(
            f"Requesting token for service: {self.service_name}"
        )

        # Request new token from pantheon-auth
        token_validity = int(os.getenv("PANTHEON_SERVICE_TOKEN_VALIDITY", "3600"))
        request_data = {
            "service_name": self.service_name,
            "token_validity": token_validity
        }

        # Add tenant information (coerce UUIDs to strings for JSON serialization)
        if self.tenant_id:
            request_data["tenant_id"] = str(self.tenant_id)
        elif self.tenant_name:
            request_data["tenant_name"] = self.tenant_name

        if self.namespace_id:
            request_data["namespace_id"] = str(self.namespace_id)
        elif self.namespace_name:
            request_data["namespace_name"] = self.namespace_name

        # Add impersonation context if present
        if self.impersonation_context:
            request_data["impersonation_context"] = self.impersonation_context
            logger.info(
                "Requesting service token with impersonation context",
                service=self.service_name,
                impersonation_context=self.impersonation_context
            )

        token_url = f"{self.auth_base_url}/api/v1/internal/tokens/service"

        #  DEBUG: Detailed token request information
        logger.debug(
            "  - Making token request to pantheon-auth",
            service=self.service_name,
            token_url=token_url,
            request_data=request_data,
            headers=_mint_headers(),
        )

        # Use a separate httpx client for auth calls to avoid circular dependency
        # but still record metrics for internal auth requests
        try:
            # Record metrics for internal auth request
            start_time = time.time()
            request_id = str(uuid.uuid4())[:8]

            if self.access_logger:
                self.access_logger.debug(
                    "🔥 ACCESS_LOG - INTERNAL AUTH REQUEST",
                    http_method="POST",
                    http_url=token_url,
                    request_id=request_id,
                    user_agent="pantheon-shared/internal-auth",
                    content_length=len(str(request_data)),
                    service_name=self.service_name,
                    client_type="sync"
                )

            response = httpx.post(
                token_url,
                json=request_data,
                headers=_mint_headers(),
                timeout=30.0,
                follow_redirects=True
            )

            response.raise_for_status()
            token_data = response.json()
            token = token_data["access_token"]
            expires_in = token_data.get("expires_in", 3600)

            # Calculate response time and record in metrics
            response_time = time.time() - start_time
            self.metrics.record_response(response.status_code, response_time)

            if self.access_logger:
                self.access_logger.debug(
                    "🔥 ACCESS_LOG - INTERNAL AUTH RESPONSE",
                    http_method="POST",
                    http_url=token_url,
                    status_code=response.status_code,
                    response_time=response_time,
                    response_length=len(response.content),
                    request_id=request_id,
                    user_agent="pantheon-shared/internal-auth",
                    service_name=self.service_name,
                    client_type="sync"
                )

            # Cache token at a percentage of the actual token lifetime returned by the
            # auth service (expires_in), not the requested token_validity. This is critical
            # for delegated tokens: the auth service issues them with a fixed 30-minute
            # lifetime regardless of what token_validity was requested, and expires_in
            # reflects that actual lifetime. Using token_validity (3600s default) would
            # cache a 30-minute delegated token for 48 minutes, causing _get_token() to
            # return a cached-but-JWT-expired token during the 30-48 minute window.
            cache_percentage = float(os.getenv("PANTHEON_SERVICE_TOKEN_CACHE_PERCENTAGE", "0.8"))
            cache_ttl_seconds = int(expires_in * cache_percentage)
            self.token_cache.set(cache_key, token, expires_in_seconds=cache_ttl_seconds)

            logger.debug(
                "  - New token cached and returned",
                service=self.service_name,
                cache_key=cache_key,
                token_preview=f"{token[:20]}..." if len(token) > 20 else token
            )

            return token

        except Exception as e:
            # Record metrics for auth errors (treat as 5xx)
            duration = time.time() - start_time if 'start_time' in locals() else 0.0
            self.metrics.record_response(500, duration)

            # DEBUG: Token request failure
            logger.error(
                "  - PantheonSyncClient FAILED to get token from pantheon-auth",
                service=self.service_name,
                token_url=token_url,
                request_data=request_data,
                error_type=type(e).__name__,
                error_message=str(e),
                exception_details=e.__dict__ if hasattr(e, '__dict__') else None
            )
            raise

    # Convenience methods
    def get(self, url: str, context: Optional[Dict[str, Any]] = None, **kwargs) -> httpx.Response:
        """GET request"""
        return self.request("GET", url, context=context, **kwargs)

    def paginated_get(
        self,
        url: str,
        items_key: str = "items",
        context: Optional[Dict[str, Any]] = None,
        max_pages: int = 10,
        **kwargs
    ) -> List[Dict[str, Any]]:
        """
        GET request with automatic pagination support.

        Fetches all pages from a paginated endpoint and returns all items.
        Supports page/size pagination with configurable max pages.

        Args:
            url: The URL to fetch (can include query parameters)
            items_key: The key in the response JSON that contains the items array
            context: Optional context dict for logging
            max_pages: Maximum number of pages to fetch (default: 10, safety limit)
            **kwargs: Additional arguments passed to httpx get()

        Returns:
            List of all items from all pages

        Example:
            # Fetch all APIs (handles pagination automatically)
            apis = client.paginated_get(
                "/api/v1/apis",
                items_key="apis",
                params={"api_group_id": group_id, "size": 100}
            )
        """
        all_items = []
        page = 1

        # Extract params if provided
        params = kwargs.get("params", {})
        if isinstance(params, dict):
            params = params.copy()
        else:
            params = {}

        # Set a reasonable default page size if not specified
        if "size" not in params:
            params["size"] = 100

        # Set initial page
        params["page"] = page
        kwargs["params"] = params

        while page <= max_pages:
            response = self.get(url, context=context, **kwargs)

            if response.status_code != 200:
                logger.warning(
                    "paginated_get failed",
                    url=url,
                    status_code=response.status_code,
                    page=page,
                    client_type="sync"
                )
                break

            data = response.json()
            items = data.get(items_key, [])

            if not items:
                # No more items
                break

            all_items.extend(items)
            page += 1

            # Check if there are more pages
            # If we got fewer items than requested, we're on the last page
            requested_size = params.get("size", 100)
            if len(items) < requested_size:
                break

            # Update page for next request
            params["page"] = page
            kwargs["params"] = params

        if page > max_pages:
            logger.warning(
                "paginated_get reached max_pages limit",
                url=url,
                max_pages=max_pages,
                total_items=len(all_items),
                client_type="sync"
            )

        return all_items

    def post(self, url: str, context: Optional[Dict[str, Any]] = None, **kwargs) -> httpx.Response:
        """POST request"""
        return self.request("POST", url, context=context, **kwargs)

    def put(self, url: str, context: Optional[Dict[str, Any]] = None, **kwargs) -> httpx.Response:
        """PUT request"""
        return self.request("PUT", url, context=context, **kwargs)

    def delete(self, url: str, context: Optional[Dict[str, Any]] = None, **kwargs) -> httpx.Response:
        """DELETE request"""
        return self.request("DELETE", url, context=context, **kwargs)

    def close(self):
        """Close the underlying httpx client"""
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
