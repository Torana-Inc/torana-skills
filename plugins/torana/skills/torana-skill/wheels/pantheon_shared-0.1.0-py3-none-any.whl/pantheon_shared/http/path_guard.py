"""Refuse an east-west request whose URL PATH could reach a route its caller did not write (EM S-33, em5 M3).

Callers build URLs with f-strings: `f"{base}/api/v1/workspaces/{ws}/agents/{agent_id}"`. When an id comes from an
LLM (agent-builder's function tools) it is not encoded, and httpx normalises `.`/`..` segments and cuts at `#`.
em5 (2026-11-07): `detach_agent(ws, "../../../internal/x#")` sent `DELETE /api/v1/internal/x`, and
`cooking_start("../internal/reconcile-orphaned-cooks#")` reached a cross-tenant sweep. This is the funnel every
PantheonClient / PantheonSyncClient request passes, so the refusal lives here, before anything is sent.

Refused (`UnsafeRequestPath`, one `east_west.unsafe_path_refused` line):
  - a `#` before the query (how a crafted id cuts the rest of the path off; one after `?` only cuts the query);
  - a `.` or `..` segment in the path, raw or percent-encoded (decoded up to three rounds);
  - an encoded separator (`%2f`, `%5c`) or a raw backslash in the path, at any decode depth;
  - an encoded `?` or `#` (`%3f`, `%23`) in the path.
The query string is not judged (it is the receiver's to parse).
"""
from __future__ import annotations

import re
from typing import Optional
from urllib.parse import unquote, urlsplit

import structlog

logger = structlog.get_logger(__name__)

_ENCODED_BAD = re.compile(r"%(2f|5c|3f|23)", re.IGNORECASE)


class UnsafeRequestPath(ValueError):
    """The URL's path could reach a different route than the one written; the request was not sent."""


def unsafe_path_reason(url: str) -> Optional[str]:
    """Why `url` must not be requested, or None when it may."""
    text = str(url)
    if "#" in text.split("?", 1)[0]:
        return "contains '#'"
    path = urlsplit(text).path
    layers = [path]
    for _ in range(3):
        nxt = unquote(layers[-1])
        if nxt == layers[-1]:
            break
        layers.append(nxt)
    for layer in layers:
        if "\\" in layer:
            return "contains a backslash"
        if _ENCODED_BAD.search(layer):
            return "contains an encoded '/', '\\', '?' or '#'"
        if any(seg in (".", "..") for seg in layer.split("/")):
            return "contains a '.' or '..' segment"
        if "#" in layer or "?" in layer:
            return "contains an encoded '?' or '#'"
    return None


def refuse_unsafe_path(method: str, url: str, service_name: str = "") -> None:
    """Raise `UnsafeRequestPath` (after one log line) when `url` is unsafe; fails CLOSED on an unparsable URL."""
    try:
        reason = unsafe_path_reason(url)
    except Exception as e:  # noqa: BLE001 — a URL this cannot read is not sent
        reason = f"could not be parsed ({type(e).__name__})"
    if reason is None:
        return
    logger.warning("east_west.unsafe_path_refused", method=method, url=str(url)[:300], reason=reason,
                   service=service_name)
    raise UnsafeRequestPath(f"{method} {str(url)[:300]}: the path {reason}; the request was not sent")
