"""
Authentication utilities for Pantheon services.
"""

import os
import requests
from typing import Optional, Dict, Any


# NOTE (issue #171): the ``ServiceAuth`` helper was removed here.
# It existed only to hand out the ``pantheon-app: true`` bypass header (and it
# fell back to hardcoded bootstrap admin credentials to fetch a token). It had
# ZERO consumers across the platform -- verified by grep -- so it was dead code
# whose only remaining effect would have been to teach the next reader to use a
# bypass that no longer works. Service-to-service callers use ``PantheonClient``,
# which attaches a real ``Authorization: Bearer <service jwt>``.


def get_service_url(service_name: str) -> str:
    """
    Get the base URL for a Pantheon service.

    Args:
        service_name: Name of the service (e.g., 'datalake', 'auth', 'viz')

    Returns:
        Full base URL for the service
    """
    # Standard environment variable naming convention
    env_var = f"PANTHEON_{service_name.upper().replace('-', '_')}"

    # Check for combined HOST:PORT or separate variables
    service_url = os.getenv(env_var)
    if service_url:
        return service_url if service_url.startswith('http') else f"http://{service_url}"

    # Try separate HOST and PORT variables
    host = os.getenv(f"{env_var}_HOST", "localhost")
    port = os.getenv(f"{env_var}_PORT")

    # Default ports for common services
    default_ports = {
        "auth": "8012",
        "datalake": "8002",
        "viz": "8004",
        "detection": "8001",
        "integration": "8003",
        "transformers": "8007",
        "workflow": "8005",
        "rag": "8015",
        "agent_builder": "8010",
        "program_framework": "8009"
    }

    if not port:
        port = default_ports.get(service_name.lower(), "8000")

    return f"http://{host}:{port}"