"""
Authentication utilities for Pantheon services.
"""

import requests
from typing import Optional, Dict, Any


# NOTE (issue #171): the ``ServiceAuth`` helper was removed here.
# It existed only to hand out the ``pantheon-app: true`` bypass header (and it
# fell back to hardcoded bootstrap admin credentials to fetch a token). It had
# ZERO consumers across the platform -- verified by grep -- so it was dead code
# whose only remaining effect would have been to teach the next reader to use a
# bypass that no longer works. Service-to-service callers use ``PantheonClient``,
# which attaches a real ``Authorization: Bearer <service jwt>``.


def get_service_url(service_name: str) -> str:
    """Base URL of a Pantheon service, from its ``*_SERVICE_URL`` variable.

    Kept for import compatibility; delegates to
    ``pantheon_services.get_pantheon_service_url``. It used to read ``PANTHEON_<NAME>``
    and default to ``localhost`` with a hardcoded port table.
    """
    from pantheon_shared.pantheon_services import get_pantheon_service_url
    name = service_name.lower().replace("_", "-")
    if not name.startswith("pantheon-"):
        name = f"pantheon-{name}"
    return get_pantheon_service_url(name)