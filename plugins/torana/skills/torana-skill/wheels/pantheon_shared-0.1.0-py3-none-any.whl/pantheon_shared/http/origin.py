"""
Call origin: WHO started an east-west call (F2, 2026-10-01 log triage).

An agent guessing a table name and being rejected by the SQL guard or the datalake is expected
behaviour; a CODE path sending a bad query is a bug. Both used to log the same WARN/ERROR line. The
``x-pantheon-origin`` header lets the receiver tell them apart:

- ``cli``       the ``torana`` CLI driven by a human
- ``cli-llm``   the ``torana`` CLI driven by an LLM (Claude Code: ``CLAUDECODE`` set)
- ``llm-tool``  an agent-builder tool call the LLM chose (``traced_call``)
- absent        ``code`` -- the default; anything unknown is ``code`` as well, so a stray value can
                never demote a real failure.

Propagation: the inbound origin is bound to a ContextVar while a request is handled
(`bind_inbound_origin`, called by the tracing middleware), and PantheonClient forwards it on every
east-west call made inside that request (`outgoing_origin_headers`). So a datalake query that DF
runs on behalf of an agent tool call still says ``llm-tool``.
"""

from contextvars import ContextVar, Token
from typing import Any, Dict, Mapping, Optional

ORIGIN_HEADER = "x-pantheon-origin"

ORIGIN_CODE = "code"
ORIGIN_CLI = "cli"
ORIGIN_CLI_LLM = "cli-llm"
ORIGIN_LLM_TOOL = "llm-tool"

# Values that may travel on the wire. ``code`` never does: it is the absence of the header.
WIRE_ORIGINS = frozenset({ORIGIN_CLI, ORIGIN_CLI_LLM, ORIGIN_LLM_TOOL})
ALL_ORIGINS = WIRE_ORIGINS | {ORIGIN_CODE}
# Origins whose failures are the LLM's guess, not a platform defect.
LLM_ORIGINS = frozenset({ORIGIN_CLI_LLM, ORIGIN_LLM_TOOL})

_current_origin: ContextVar[str] = ContextVar("pantheon_call_origin", default=ORIGIN_CODE)


def normalize_origin(raw: Optional[str]) -> str:
    """A closed-set origin from a raw header value. Missing or unknown -> ``code``."""
    value = (raw or "").strip().lower()
    return value if value in WIRE_ORIGINS else ORIGIN_CODE


def _headers_of(request_or_headers: Any) -> Optional[Mapping[str, str]]:
    if request_or_headers is None:
        return None
    headers = getattr(request_or_headers, "headers", request_or_headers)
    return headers if hasattr(headers, "get") else None


def origin_of(request_or_headers: Any) -> str:
    """Origin of a request (Starlette/FastAPI ``Request``) or a headers mapping.

    Header lookup is case-insensitive for plain dicts as well as Starlette ``Headers``.
    """
    headers = _headers_of(request_or_headers)
    if not headers:
        return ORIGIN_CODE
    raw = headers.get(ORIGIN_HEADER)
    if raw is None and isinstance(headers, dict):
        raw = next((v for k, v in headers.items() if str(k).lower() == ORIGIN_HEADER), None)
    return normalize_origin(raw)


def is_llm_origin(origin: Optional[str]) -> bool:
    """True when a failure under this origin is an LLM's guess (``cli-llm`` / ``llm-tool``)."""
    return origin in LLM_ORIGINS


def bind_inbound_origin(request_or_headers: Any) -> Token:
    """Bind the inbound request's origin for the rest of this request (tracing middleware)."""
    return _current_origin.set(origin_of(request_or_headers))


def set_current_origin(origin: str) -> Token:
    """Bind an origin explicitly (e.g. a tool call made in-process). Returns the reset token."""
    return _current_origin.set(normalize_origin(origin) if origin != ORIGIN_CODE else ORIGIN_CODE)


def reset_current_origin(token: Token) -> None:
    _current_origin.reset(token)


def current_origin() -> str:
    """Origin of the request being handled; ``code`` outside one."""
    return _current_origin.get()


def outgoing_origin_headers(existing: Optional[Mapping[str, str]] = None) -> Dict[str, str]:
    """Origin header to add to an outgoing east-west call.

    An origin the caller already set explicitly (e.g. ``traced_call`` -> ``llm-tool``) wins; else
    the inbound origin is forwarded. ``code`` adds nothing.
    """
    if existing and any(str(k).lower() == ORIGIN_HEADER for k in existing):
        return {}
    origin = current_origin()
    return {ORIGIN_HEADER: origin} if origin in WIRE_ORIGINS else {}
