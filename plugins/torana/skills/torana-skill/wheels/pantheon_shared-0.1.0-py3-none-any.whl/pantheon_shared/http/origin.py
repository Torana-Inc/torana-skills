"""
Call origin: WHO started an east-west call (F2, 2026-10-01 log triage).

An agent guessing a table name and being rejected by the SQL guard or the datalake is expected
behaviour; a CODE path sending a bad query is a bug. Both used to log the same WARN/ERROR line. The
``x-pantheon-origin`` header lets the receiver tell them apart:

- ``cli``       the ``torana`` CLI driven by a human
- ``cli-llm``   the ``torana`` CLI driven by an LLM (Claude Code: ``CLAUDECODE`` set)
- ``llm-tool``  an agent-builder tool call the LLM chose (``traced_call``)
- absent        ``code`` -- the default; anything unknown is ``code`` as well, so a stray value can
                never demote a real failure.

Propagation: the inbound origin is bound to a ContextVar while a request is handled
(`bind_inbound_origin`, called by the tracing middleware), and PantheonClient forwards it on every
east-west call made inside that request (`outgoing_origin_headers`). So a datalake query that DF
runs on behalf of an agent tool call still says ``llm-tool``.

The CALLER (F7): an ``llm-tool`` call also names the agent (``x-pantheon-agent``) and the tool
(``x-pantheon-tool``) that made it. Both travel with the origin, hop by hop, and the shared log
processor (`add_call_origin` in ``pantheon_shared.logging``) stamps ``origin`` / ``agent`` / ``tool``
on every structlog line written while the request is handled, so any service's lines for an agent's
tool call can be filtered (``origin="llm-tool"``) or scoped to one tool. Unlike the origin they are
free text, reduced to a header-safe charset and capped, because the agent/tool set is open.

LLM OUTPUT (the other direction): code that calls an agent and then JUDGES its reply (the AI Home
narrator's draft refused for a noun slip, say) runs under origin ``code`` -- a scheduler started it --
so its warnings looked like platform defects. ``judging_llm_output(agent)`` binds ``llm-output`` and
the agent for exactly that block, and `add_call_origin` stamps both on its lines. ``llm-output`` is
LOCAL: it is never sent as a header and an inbound header can never claim it (it is not a wire origin).
"""

import re
from contextlib import contextmanager
from contextvars import ContextVar, Token
from typing import Any, Dict, Iterator, Mapping, Optional

ORIGIN_HEADER = "x-pantheon-origin"
AGENT_HEADER = "x-pantheon-agent"
TOOL_HEADER = "x-pantheon-tool"

ORIGIN_CODE = "code"
ORIGIN_CLI = "cli"
ORIGIN_CLI_LLM = "cli-llm"
ORIGIN_LLM_TOOL = "llm-tool"
ORIGIN_LLM_OUTPUT = "llm-output"

# Values that may travel on the wire. ``code`` never does: it is the absence of the header.
WIRE_ORIGINS = frozenset({ORIGIN_CLI, ORIGIN_CLI_LLM, ORIGIN_LLM_TOOL})
ALL_ORIGINS = WIRE_ORIGINS | {ORIGIN_CODE, ORIGIN_LLM_OUTPUT}
# Origins whose failures are the LLM's guess, not a platform defect.
LLM_ORIGINS = frozenset({ORIGIN_CLI_LLM, ORIGIN_LLM_TOOL, ORIGIN_LLM_OUTPUT})

_current_origin: ContextVar[str] = ContextVar("pantheon_call_origin", default=ORIGIN_CODE)
_current_agent: ContextVar[Optional[str]] = ContextVar("pantheon_call_agent", default=None)
_current_tool: ContextVar[Optional[str]] = ContextVar("pantheon_call_tool", default=None)

_UNSAFE_NAME_CHARS = re.compile(r"[^A-Za-z0-9_.:\-]")
NAME_MAX_LEN = 128


def normalize_origin(raw: Optional[str]) -> str:
    """A closed-set origin from a raw header value. Missing or unknown -> ``code``."""
    value = (raw or "").strip().lower()
    return value if value in WIRE_ORIGINS else ORIGIN_CODE


def safe_caller_name(raw: Any) -> Optional[str]:
    """An agent or tool name reduced to a header- and log-safe charset, capped. Empty -> None.

    ⛔ The value lands in log lines verbatim, so a newline or quote must never survive: every
    character outside ``[A-Za-z0-9_.:-]`` becomes ``_``.
    """
    value = _UNSAFE_NAME_CHARS.sub("_", str(raw or "").strip())[:NAME_MAX_LEN]
    return value or None


def _headers_of(request_or_headers: Any) -> Optional[Mapping[str, str]]:
    if request_or_headers is None:
        return None
    headers = getattr(request_or_headers, "headers", request_or_headers)
    return headers if hasattr(headers, "get") else None


def _header(headers: Mapping[str, str], name: str) -> Optional[str]:
    """Case-insensitive lookup for plain dicts as well as Starlette/httpx ``Headers``."""
    raw = headers.get(name)
    if raw is None and isinstance(headers, dict):
        raw = next((v for k, v in headers.items() if str(k).lower() == name), None)
    return raw


def origin_of(request_or_headers: Any) -> str:
    """Origin of a request (Starlette/FastAPI ``Request``) or a headers mapping.

    Header lookup is case-insensitive for plain dicts as well as Starlette ``Headers``.
    """
    headers = _headers_of(request_or_headers)
    if not headers:
        return ORIGIN_CODE
    return normalize_origin(_header(headers, ORIGIN_HEADER))


def caller_of(request_or_headers: Any) -> Dict[str, Optional[str]]:
    """``{"origin", "agent", "tool"}`` of a request or headers mapping; names are sanitized or None."""
    headers = _headers_of(request_or_headers)
    if not headers:
        return {"origin": ORIGIN_CODE, "agent": None, "tool": None}
    return {"origin": normalize_origin(_header(headers, ORIGIN_HEADER)),
            "agent": safe_caller_name(_header(headers, AGENT_HEADER)),
            "tool": safe_caller_name(_header(headers, TOOL_HEADER))}


def is_llm_origin(origin: Optional[str]) -> bool:
    """True when a failure under this origin is an LLM's guess (``cli-llm`` / ``llm-tool``)."""
    return origin in LLM_ORIGINS


def bind_inbound_origin(request_or_headers: Any) -> Token:
    """Bind the inbound request's origin, agent and tool for the rest of this request (tracing
    middleware). All three are bound on EVERY request, absent ones as None, so nothing leaks from a
    previous request on the same worker. Returns the origin's reset token."""
    caller = caller_of(request_or_headers)
    _current_agent.set(caller["agent"])
    _current_tool.set(caller["tool"])
    return _current_origin.set(caller["origin"])


def set_current_origin(origin: str) -> Token:
    """Bind an origin explicitly (e.g. a tool call made in-process). Returns the reset token."""
    return _current_origin.set(normalize_origin(origin) if origin != ORIGIN_CODE else ORIGIN_CODE)


def bind_caller(origin: str, agent: Optional[str] = None, tool: Optional[str] = None) -> None:
    """Bind origin, agent and tool for the CURRENT context (e.g. one agent tool call in-process).

    ⛔ Context-scoped by design: agent-builder calls it at the start of each ADK tool call, and ADK
    runs every call in its own asyncio task, so the binding covers exactly that call (its
    PantheonClient requests and its log lines) and never a sibling call or the rest of the turn.
    """
    _current_origin.set(normalize_origin(origin))
    _current_agent.set(safe_caller_name(agent))
    _current_tool.set(safe_caller_name(tool))


@contextmanager
def judging_llm_output(agent: Optional[str]) -> Iterator[None]:
    """Mark every log line inside the block as a verdict on ``agent``'s reply: ``origin=llm-output agent=...``.

    Wrap the code that VALIDATES an agent's output and logs what it refused, not the agent call
    itself. The previous origin, agent and tool are restored on exit, so a ``code`` request stays
    ``code`` after the block. ⚠️ An east-west call made inside the block forwards neither the origin
    nor the agent (`outgoing_origin_headers`): the judgement is this process's, not the callee's.
    """
    tokens = (_current_origin.set(ORIGIN_LLM_OUTPUT), _current_agent.set(safe_caller_name(agent)),
              _current_tool.set(None))
    try:
        yield
    finally:
        _current_tool.reset(tokens[2])
        _current_agent.reset(tokens[1])
        _current_origin.reset(tokens[0])


def reset_current_origin(token: Token) -> None:
    _current_origin.reset(token)


def current_origin() -> str:
    """Origin of the request being handled; ``code`` outside one."""
    return _current_origin.get()


def current_caller() -> Dict[str, Optional[str]]:
    """``{"origin", "agent", "tool"}`` of the request being handled (``code``/None/None outside one)."""
    return {"origin": _current_origin.get(), "agent": _current_agent.get(), "tool": _current_tool.get()}


def outgoing_origin_headers(existing: Optional[Mapping[str, str]] = None) -> Dict[str, str]:
    """Origin, agent and tool headers to add to an outgoing east-west call.

    Each header the caller already set explicitly (e.g. ``traced_call`` -> ``llm-tool`` plus its
    agent and tool) wins; else the inbound value is forwarded. ``code`` adds no origin header, and
    an agent or tool is forwarded only when one was bound.
    """
    have = {str(k).lower() for k in (existing or {})}
    out: Dict[str, str] = {}
    origin = current_origin()
    if ORIGIN_HEADER not in have and origin in WIRE_ORIGINS:
        out[ORIGIN_HEADER] = origin
    if origin == ORIGIN_LLM_OUTPUT:
        return out                    # a local judgement: the agent it names is not the callee's caller
    for header, var in ((AGENT_HEADER, _current_agent), (TOOL_HEADER, _current_tool)):
        value = var.get()
        if value and header not in have:
            out[header] = value
    return out
