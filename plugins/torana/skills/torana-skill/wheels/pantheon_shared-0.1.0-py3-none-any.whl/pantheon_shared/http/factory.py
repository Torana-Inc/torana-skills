"""
Factory for creating Pantheon HTTP clients with proper configuration.

This module provides factory functions to create PantheonClient instances
with consistent configuration across services.
"""

import os
from typing import Optional, Dict, Any
import httpx

import structlog

from .client import PantheonClient, PantheonSyncClient

logger = structlog.get_logger(__name__)


def create_pantheon_client(
    service_name: Optional[str] = None,
    tenant_id: Optional[str] = None,
    tenant_name: Optional[str] = None,
    namespace_id: Optional[str] = None,
    namespace_name: Optional[str] = None,
    base_url: Optional[str] = None,
    timeout: float = 30.0,
    debug: bool = False,
    **kwargs
) -> PantheonClient:
    """
    Create a PantheonClient with sensible defaults.

    Args:
        service_name: Name of the calling service (auto-detected if not provided)
        tenant_id: Tenant ID for context (from env if not provided)
        tenant_name: Tenant name for context (from env if not provided, used if tenant_id not provided)
        namespace_id: Namespace ID for context (from env if not provided)
        namespace_name: Namespace name for context (from env if not provided, used if namespace_id not provided)
        base_url: Base URL for requests
        timeout: Request timeout in seconds
        debug: Enable debug logging with extensive details
        **kwargs: Additional httpx.AsyncClient arguments

    Returns:
        Configured PantheonClient instance
    """
    # Auto-detect service name if not provided
    if service_name is None:
        service_name = os.getenv("SERVICE_NAME", "unknown-service")
        logger.warning(
            "Service name not provided, using environment variable",
            service_name=service_name
        )

    # Get tenant ID from environment if not provided
    if tenant_id is None:
        tenant_id = os.getenv("SERVICE_TENANT_ID")

    # Get tenant name from environment if not provided
    if tenant_name is None:
        tenant_name = os.getenv("SERVICE_TENANT_NAME")

    # Get namespace ID from environment if not provided
    if namespace_id is None:
        namespace_id = os.getenv("SERVICE_NAMESPACE_ID")

    # Get namespace name from environment if not provided
    if namespace_name is None:
        namespace_name = os.getenv("SERVICE_NAMESPACE_NAME")

    # Prepare httpx client configuration
    client_config = {
        "timeout": httpx.Timeout(timeout),
        "follow_redirects": True,
        **kwargs
    }

    if base_url:
        client_config["base_url"] = base_url

    # Create and return client
    client = PantheonClient(
        service_name=service_name,
        tenant_id=tenant_id,
        tenant_name=tenant_name,
        namespace_id=namespace_id,
        namespace_name=namespace_name,
        debug=debug,
        **client_config
    )

    logger.info(
        "PantheonClient created via factory",
        service=service_name,
        tenant=tenant_id or tenant_name,
        namespace=namespace_id,
        base_url=base_url,
        debug=debug
    )

    return client


def create_pantheon_sync_client(
    service_name: Optional[str] = None,
    tenant_id: Optional[str] = None,
    tenant_name: Optional[str] = None,
    namespace_id: Optional[str] = None,
    namespace_name: Optional[str] = None,
    base_url: Optional[str] = None,
    timeout: float = 30.0,
    debug: bool = False,
    **kwargs
) -> PantheonSyncClient:
    """
    Create a PantheonSyncClient with sensible defaults.

    Args:
        service_name: Name of the calling service (auto-detected if not provided)
        tenant_id: Tenant ID for context (from env if not provided)
        tenant_name: Tenant name for context (from env if not provided, used if tenant_id not provided)
        namespace_id: Namespace ID for context (from env if not provided)
        namespace_name: Namespace name for context (from env if not provided, used if namespace_id not provided)
        base_url: Base URL for requests
        timeout: Request timeout in seconds
        debug: Enable debug logging with extensive details
        **kwargs: Additional httpx.Client arguments

    Returns:
        Configured PantheonSyncClient instance
    """
    # Auto-detect service name if not provided
    if service_name is None:
        service_name = os.getenv("SERVICE_NAME", "unknown-service")
        logger.warning(
            "Service name not provided, using environment variable",
            service_name=service_name
        )

    # Get tenant ID from environment if not provided
    if tenant_id is None:
        tenant_id = os.getenv("SERVICE_TENANT_ID")

    # Get tenant name from environment if not provided
    if tenant_name is None:
        tenant_name = os.getenv("SERVICE_TENANT_NAME")

    # Get namespace ID from environment if not provided
    if namespace_id is None:
        namespace_id = os.getenv("SERVICE_NAMESPACE_ID")

    # Get namespace name from environment if not provided
    if namespace_name is None:
        namespace_name = os.getenv("SERVICE_NAMESPACE_NAME")

    # Prepare httpx client configuration
    client_config = {
        "timeout": httpx.Timeout(timeout),
        "follow_redirects": True,
        **kwargs
    }

    if base_url:
        client_config["base_url"] = base_url

    # Create and return client
    client = PantheonSyncClient(
        service_name=service_name,
        tenant_id=tenant_id,
        tenant_name=tenant_name,
        namespace_id=namespace_id,
        namespace_name=namespace_name,
        debug=debug,
        **client_config
    )

    logger.info(
        "PantheonSyncClient created via factory",
        service=service_name,
        tenant=tenant_id,
        namespace=namespace_id,
        base_url=base_url,
        debug=debug
    )

    return client