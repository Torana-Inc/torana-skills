"""
Generic retry utilities for async operations.

Provides simple retry decorators with exponential backoff for:
- Health checks during service startup
- Transient error handling
- Service dependency initialization

This is a lightweight alternative to tenacity for common retry scenarios.
"""

from __future__ import annotations

import asyncio
import functools
from typing import (
    Awaitable,
    Callable,
    Optional,
    TypeVar,
    ParamSpec,
)

from pantheon_shared import get_logger

__all__ = [
    "async_retry",
    "RetryConfig",
]

P = ParamSpec("P")
R = TypeVar("R")


class RetryConfig:
    """
    Configuration for retry behavior.

    Attributes:
        max_retries: Maximum number of retry attempts (default: 12)
        initial_delay: Initial delay before first retry in seconds (default: 1.0)
        max_delay: Maximum delay between retries in seconds (default: 10.0)
        exponential_backoff: Use exponential backoff (default: True)
        retry_on_exceptions: Tuple of exception types to retry (default: all)
    """

    def __init__(
        self,
        max_retries: int = 12,
        initial_delay: float = 1.0,
        max_delay: float = 10.0,
        exponential_backoff: bool = True,
        retry_on_exceptions: Optional[tuple[type[Exception], ...]] = None,
    ):
        self.max_retries = max_retries
        self.initial_delay = initial_delay
        self.max_delay = max_delay
        self.exponential_backoff = exponential_backoff
        self.retry_on_exceptions = retry_on_exceptions


def async_retry(
    max_retries: int = 12,
    initial_delay: float = 1.0,
    max_delay: float = 10.0,
    exponential_backoff: bool = True,
    retry_on_exceptions: Optional[tuple[type[Exception], ...]] = None,
) -> Callable[[Callable[P, Awaitable[R]]], Callable[P, Awaitable[R]]]:
    """
    Decorator for adding retry logic to async functions.

    Retries on any exception (or specific exceptions if provided).
    Uses exponential backoff with jitter.

    Args:
        max_retries: Maximum number of retry attempts (default: 12)
        initial_delay: Initial delay before first retry in seconds (default: 1.0)
        max_delay: Maximum delay between retries in seconds (default: 10.0)
        exponential_backoff: Use exponential backoff (default: True)
        retry_on_exceptions: Tuple of exception types to retry (default: all exceptions)

    Returns:
        A decorator function for async functions

    Example:
        ```python
        from pantheon_shared.utils.retry import async_retry

        @async_retry(max_retries=12, initial_delay=1.0)
        async def check_service_health():
            async with aiohttp.ClientSession() as session:
                async with session.get("http://service/health") as resp:
                    return resp.status == 200

        is_healthy = await check_service_health()
        ```

    Example with specific exceptions:
        ```python
        @async_retry(retry_on_exceptions=(ConnectionError, TimeoutError))
        async def fetch_data():
            return await api_call()
        ```
    """

    config = RetryConfig(
        max_retries=max_retries,
        initial_delay=initial_delay,
        max_delay=max_delay,
        exponential_backoff=exponential_backoff,
        retry_on_exceptions=retry_on_exceptions,
    )

    def decorator(func: Callable[P, Awaitable[R]]) -> Callable[P, Awaitable[R]]:
        @functools.wraps(func)
        async def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            logger = get_logger(__name__)
            last_exception = None

            for attempt in range(config.max_retries):
                try:
                    result = await func(*args, **kwargs)

                    # Log success if we retried
                    if attempt > 0:
                        logger.info(
                            f"{func.__name__} succeeded on attempt {attempt + 1}/{config.max_retries}"
                        )

                    return result

                except Exception as e:
                    last_exception = e

                    # Check if we should retry this exception type
                    if config.retry_on_exceptions and not isinstance(
                        e, config.retry_on_exceptions
                    ):
                        raise

                    # Log retry attempt
                    logger.debug(
                        f"{func.__name__} attempt {attempt + 1}/{config.max_retries} failed: {e}"
                    )

                    # If this isn't the last attempt, wait before retrying
                    if attempt < config.max_retries - 1:
                        if config.exponential_backoff:
                            # Exponential backoff: 1s, 2s, 4s, 8s, ... (capped at max_delay)
                            delay = min(
                                config.initial_delay * (2**attempt),
                                config.max_delay,
                            )
                        else:
                            delay = config.initial_delay

                        logger.debug(
                            f"Retrying {func.__name__} in {delay:.1f}s... "
                            f"(attempt {attempt + 1}/{config.max_retries})"
                        )
                        await asyncio.sleep(delay)

            # All retries exhausted
            logger.warning(
                f"{func.__name__} failed after {config.max_retries} attempts"
            )
            raise last_exception

        return wrapper

    return decorator
