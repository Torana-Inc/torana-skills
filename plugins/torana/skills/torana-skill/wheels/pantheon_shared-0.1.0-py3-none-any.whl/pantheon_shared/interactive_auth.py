#!/usr/bin/env python3
"""
Common Authentication Module for Interactive Test Scripts

This module provides JWT-based authentication for all interactive test client scripts.
It uses the get_token.sh script to obtain JWT tokens and creates authenticated sessions.
"""

import os
import subprocess
import sys
from pathlib import Path
from typing import Optional, Dict, Any
import requests


class AuthenticationError(Exception):
    """Raised when authentication fails"""
    pass


class InteractiveAuth:
    """
    Handles JWT-based authentication for interactive test scripts.

    This class:
    1. Locates and calls get_token.sh to obtain JWT tokens
    2. Creates authenticated requests.Session objects
    3. Provides helper methods for common auth operations

    Environment Variables:
        TOKEN_USER: Optional override for user email (default: uses .env BOOTSTRAP_ADMIN_EMAIL)
        TOKEN_PASSWORD: Optional override for password (default: uses .env BOOTSTRAP_ADMIN_PASSWORD)
        TORANA_ROOT: Root directory of Torana installation (auto-detected if not set)
    """

    def __init__(self, torana_root: Optional[str] = None):
        """
        Initialize the authentication handler.

        Args:
            torana_root: Path to Torana root directory. If not provided, will auto-detect.

        Raises:
            AuthenticationError: If get_token.sh cannot be found or accessed
        """
        self.torana_root = self._find_torana_root(torana_root)
        self.get_token_script = self.torana_root / "pantheon-deploy" / "scripts" / "get_token.sh"
        self._token: Optional[str] = None
        self._validate_setup()

    def _find_torana_root(self, provided_root: Optional[str] = None) -> Path:
        """
        Find the Torana root directory.

        Args:
            provided_root: Optional explicit path to Torana root

        Returns:
            Path to Torana root directory

        Raises:
            AuthenticationError: If root cannot be determined
        """
        if provided_root:
            root = Path(provided_root)
            if root.exists():
                return root.resolve()
            raise AuthenticationError(f"Provided TORANA_ROOT does not exist: {provided_root}")

        # Try environment variable
        env_root = os.getenv('TORANA_ROOT')
        if env_root:
            root = Path(env_root)
            if root.exists():
                return root.resolve()
            raise AuthenticationError(f"TORANA_ROOT from environment does not exist: {env_root}")

        # Try to auto-detect by looking for pantheon-deploy directory
        current = Path.cwd()

        # Search upwards from current directory
        for parent in [current] + list(current.parents):
            deploy_dir = parent / "pantheon-deploy"
            if deploy_dir.exists() and deploy_dir.is_dir():
                return parent.resolve()

        # Last resort: check common locations
        home = Path.home()
        common_locations = [
            home / "dev" / "torana",
            home / "projects" / "torana",
            home / "torana",
            Path("/opt/torana"),
        ]

        for location in common_locations:
            if location.exists() and (location / "pantheon-deploy").exists():
                return location.resolve()

        raise AuthenticationError(
            "Could not locate TORANA_ROOT. Please set TORANA_ROOT environment variable "
            "or run from within a Torana project directory."
        )

    def _validate_setup(self):
        """
        Validate that get_token.sh exists and is executable.

        Raises:
            AuthenticationError: If get_token.sh is not found or not executable
        """
        if not self.get_token_script.exists():
            raise AuthenticationError(
                f"get_token.sh not found at: {self.get_token_script}\n"
                f"Expected location: $TORANA_ROOT/pantheon-deploy/scripts/get_token.sh\n"
                f"Please ensure pantheon-deploy is properly set up."
            )

        if not os.access(self.get_token_script, os.X_OK):
            raise AuthenticationError(
                f"get_token.sh is not executable: {self.get_token_script}\n"
                f"Run: chmod +x {self.get_token_script}"
            )

    def get_token(self, user: Optional[str] = None, password: Optional[str] = None,
                  force_refresh: bool = False) -> str:
        """
        Get JWT authentication token.

        Args:
            user: Optional user email to override default
            password: Optional password to override default
            force_refresh: If True, always fetch new token even if cached

        Returns:
            JWT token string

        Raises:
            AuthenticationError: If token retrieval fails
        """
        # Return cached token if available and not forcing refresh
        if self._token and not force_refresh:
            return self._token

        # Prepare environment for subprocess
        env = os.environ.copy()
        if user:
            env['TOKEN_USER'] = user
        if password:
            env['TOKEN_PASSWORD'] = password

        try:
            # Call get_token.sh
            result = subprocess.run(
                [str(self.get_token_script)],
                capture_output=True,
                text=True,
                env=env,
                check=False
            )

            if result.returncode != 0:
                error_msg = result.stderr.strip() if result.stderr else "Unknown error"
                raise AuthenticationError(
                    f"Failed to obtain JWT token:\n{error_msg}\n\n"
                    f"Debug: Run {self.get_token_script} --debug for more information"
                )

            token = result.stdout.strip()
            if not token:
                raise AuthenticationError(
                    "get_token.sh returned empty token. "
                    f"Run {self.get_token_script} --debug to troubleshoot."
                )

            # Cache the token
            self._token = token
            return token

        except subprocess.CalledProcessError as e:
            raise AuthenticationError(
                f"Failed to execute get_token.sh: {e}\n"
                f"stderr: {e.stderr}"
            )
        except Exception as e:
            raise AuthenticationError(f"Unexpected error getting token: {e}")

    def create_session(self, user: Optional[str] = None, password: Optional[str] = None) -> requests.Session:
        """
        Create an authenticated requests.Session with JWT token.

        Args:
            user: Optional user email to override default
            password: Optional password to override default

        Returns:
            Authenticated requests.Session object with Authorization header set

        Raises:
            AuthenticationError: If authentication fails
        """
        token = self.get_token(user, password)

        session = requests.Session()
        session.headers.update({
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        })

        return session

    def get_auth_headers(self, user: Optional[str] = None, password: Optional[str] = None) -> Dict[str, str]:
        """
        Get authentication headers dict for use with requests.

        Args:
            user: Optional user email to override default
            password: Optional password to override default

        Returns:
            Dict with Authorization and Content-Type headers

        Raises:
            AuthenticationError: If authentication fails
        """
        token = self.get_token(user, password)

        return {
            'Authorization': f'Bearer {token}',
            'Content-Type': 'application/json'
        }

    def refresh_token(self, user: Optional[str] = None, password: Optional[str] = None) -> str:
        """
        Force refresh the JWT token.

        Args:
            user: Optional user email to override default
            password: Optional password to override default

        Returns:
            New JWT token string

        Raises:
            AuthenticationError: If token refresh fails
        """
        return self.get_token(user, password, force_refresh=True)

    @staticmethod
    def print_auth_info():
        """Print helpful information about authentication setup."""
        print("🔐 JWT Authentication Setup")
        print("=" * 70)
        print("\nThis script uses JWT tokens for authentication.")
        print("\nDefault credentials:")
        print("  - User: From .env BOOTSTRAP_ADMIN_EMAIL (Super Admin)")
        print("  - Password: From .env BOOTSTRAP_ADMIN_PASSWORD")
        print("\nTo use different credentials:")
        print("  TOKEN_USER=admin@t1.com TOKEN_PASSWORD=Torana@123 python script.py")
        print("\nToken location:")
        print("  $TORANA_ROOT/pantheon-deploy/scripts/get_token.sh")
        print("=" * 70)


def get_authenticated_session(torana_root: Optional[str] = None,
                              user: Optional[str] = None,
                              password: Optional[str] = None,
                              verbose: bool = False) -> requests.Session:
    """
    Convenience function to quickly get an authenticated session.

    Args:
        torana_root: Optional path to Torana root directory
        user: Optional user email
        password: Optional password
        verbose: If True, print authentication info

    Returns:
        Authenticated requests.Session

    Raises:
        AuthenticationError: If authentication fails
    """
    try:
        auth = InteractiveAuth(torana_root)
        if verbose:
            auth.print_auth_info()
        return auth.create_session(user, password)
    except AuthenticationError as e:
        print(f"\n❌ Authentication Error: {e}\n", file=sys.stderr)
        sys.exit(1)


# Example usage
if __name__ == "__main__":
    print("Testing Interactive Authentication Module")
    print("=" * 70)

    try:
        # Test 1: Create auth handler
        print("\n1. Creating InteractiveAuth...")
        auth = InteractiveAuth()
        print(f"   ✅ TORANA_ROOT: {auth.torana_root}")
        print(f"   ✅ get_token.sh: {auth.get_token_script}")

        # Test 2: Get token
        print("\n2. Getting JWT token...")
        token = auth.get_token()
        print(f"   ✅ Token obtained (length: {len(token)})")
        print(f"   Token preview: {token[:50]}...")

        # Test 3: Create session
        print("\n3. Creating authenticated session...")
        session = auth.create_session()
        print(f"   ✅ Session created")
        print(f"   Authorization header: {session.headers.get('Authorization', 'N/A')[:60]}...")

        # Test 4: Get headers
        print("\n4. Getting auth headers...")
        headers = auth.get_auth_headers()
        print(f"   ✅ Headers obtained")
        for key, value in headers.items():
            if key == 'Authorization':
                print(f"   {key}: {value[:60]}...")
            else:
                print(f"   {key}: {value}")

        print("\n" + "=" * 70)
        print("✅ All tests passed!")
        print("=" * 70)

    except AuthenticationError as e:
        print(f"\n❌ Authentication failed: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
