"""Transaction-scoped PostgreSQL advisory locks — the BLESSED single-runner primitive.

Use this whenever you need "exactly one worker does X at a time" for a bounded unit of
work: a per-tenant refresh, a materialization, a scheduled sweep, a reconcile pass.

WHY THIS MODULE EXISTS
----------------------
The platform had three different advisory-lock implementations that were NOT equivalent,
and two of them were wrong in the same way:

  * `derived_state.py::_try_claim_lock`  — pg_try_advisory_XACT_lock  ✅ correct
  * `context_lake/scheduler.py::_advisory_lock` — pg_try_advisory_lock on a POOLED
    session ❌ session-scoped; the lock is released the moment the session returns to
    the pool, while the caller still believes it holds it
  * ETL leader election — same defect, and it is a KNOWN LIVE BUG: every worker becomes
    leader, so scheduled jobs run N times per tenant

The failure mode is silent and specific, and `pantheon-integration/torana_mesh/etl/boot.py`
records what it cost:

    "pg_advisory_lock is CONNECTION-scoped, so it must be pinned — borrowing a pooled
     session let the connection return to the pool, silently releasing the lock while
     _is_leader stayed True. That is how 4 workers ended up all believing they were
     leader with ZERO advisory locks actually held."

A session-scoped lock is only safe on a connection you own for the lock's whole lifetime.
With SQLAlchemy's pool you almost never do. A **transaction**-scoped lock has no lifetime
to mismanage: Postgres releases it at COMMIT or ROLLBACK, so a crashed worker cannot wedge
the resource and a pooled connection cannot silently drop it.

**Default to `try_xact_lock`. Reach for a session-scoped lock only if you are pinning a
dedicated connection, and say so in a comment.**

WHAT THIS DOES NOT GIVE YOU
---------------------------
A lock alone admits one runner *right now*; it does not make the work idempotent, and it
does not stop a reader seeing a half-written generation. The reference implementation
(`pantheon-integration/torana_mesh/services/derived_state.py`) pairs the lock with two
further things, and if your work writes a whole generation of rows you probably need both:

  1. a `state='idle'` **compare-and-swap** in the claim UPDATE, so the loser does not
     merely fail to lock but observes it lost, and
  2. a **generation fence** (`claimed_generation`), so a stale drainer whose row was
     reclaimed as stuck cannot write over the newer one.

See that module's docstring before designing a new claim loop.
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from typing import AsyncIterator

from sqlalchemy import text


def _lock_key(namespace: str, *parts: str) -> str:
    """Build the string hashed into the 64-bit advisory-lock space.

    Every part is coerced to `str` deliberately: a `None` interpolated into an f-string
    becomes the literal ``'None'``, which is a DIFFERENT key from ``''`` — so two callers
    that meant the same resource would each take their own lock and both proceed. That
    exact bug is called out in `derived_state.py::_try_claim_lock`. Normalising here means
    a caller cannot reintroduce it.
    """
    return ":".join([namespace, *("" if p is None else str(p) for p in parts)])


async def try_xact_lock(session, namespace: str, *parts: str) -> bool:
    """Try to take a transaction-scoped advisory lock. Non-blocking.

    Returns True if this transaction now holds the lock, False if another holds it.
    The lock is released automatically at COMMIT or ROLLBACK — there is nothing to
    release by hand, and a crash cannot leak it.

    MUST be called inside a transaction. Outside one, SQLAlchemy's autocommit ends the
    implicit transaction immediately and the lock evaporates before you use it.

        if await try_xact_lock(session, "policy_materialize", tenant_id, namespace_id):
            ...   # exactly one worker reaches here
            await session.commit()          # <- lock released here
        else:
            return                          # someone else has it; do nothing
    """
    got = await session.execute(
        text("SELECT pg_try_advisory_xact_lock(hashtext(:k))"),
        {"k": _lock_key(namespace, *parts)},
    )
    return bool(got.scalar())


@asynccontextmanager
async def xact_lock(session, namespace: str, *parts: str) -> AsyncIterator[bool]:
    """Context-manager form of :func:`try_xact_lock`.

    Yields True if the lock was acquired, False otherwise. Yielding False rather than
    raising is deliberate — "someone else is already doing this" is the normal, expected
    outcome under multiple workers, not an error.

        async with xact_lock(session, "decoration_refresh", tenant_id) as got:
            if not got:
                return          # another worker is on it
            await do_the_work()
            await session.commit()
    """
    yield await try_xact_lock(session, namespace, *parts)
