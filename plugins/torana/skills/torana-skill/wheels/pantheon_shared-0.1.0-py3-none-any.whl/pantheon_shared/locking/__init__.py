"""
PostgreSQL Advisory Lock-based coordination utilities for Pantheon services.

This module provides coordination primitives for multi-worker scenarios using
PostgreSQL advisory locks. Use cases include:
- Startup task coordination (victor runs once, losers wait)
- Cache invalidation coordination
- Periodic reconciliation
- Any single-worker-per-cluster operation

Key classes:
    PostgresLockCoordinator: Coordinates operations across gunicorn workers

Example usage:
    from pantheon_shared.locking import PostgresLockCoordinator

    async with PostgresLockCoordinator(
        lock_key="my_task",
        get_db_session=get_db_session,
        startup_flags_table="my_task_flags"
    ) as coordinator:
        if coordinator.is_victor:
            await run_once_per_cluster()
        # All workers wait here until victor completes
"""

from .startup import PostgresLockCoordinator, postgres_lock_coordinator, get_startup_flags, clear_startup_flags
from .xact_lock import try_xact_lock, xact_lock
from . import startup_state

__all__ = [
    "PostgresLockCoordinator",
    "postgres_lock_coordinator",
    "get_startup_flags",
    "clear_startup_flags",
    # TRANSACTION-scoped advisory lock — the blessed single-runner primitive.
    # Prefer these over a bare pg_try_advisory_lock: session-scoped locks on a POOLED
    # session release silently when the connection returns to the pool, which is the
    # documented cause of the ETL leader-election bug (every worker becomes leader).
    # See xact_lock.py's docstring.
    "try_xact_lock",
    "xact_lock",
    # Per-worker record of startup outcomes, read by health endpoints so a
    # partially-failed startup cannot keep reporting "healthy".
    "startup_state",
]
