"""Process-local record of how a service's startup actually went.

Why this exists
---------------
Every Pantheon service shares the same startup shape: a victor-elected worker
runs one-time tasks, and the whole lifespan sits inside a broad
``except Exception`` that logs a warning and continues. Combined with a health
endpoint that only probes *liveness* (can I reach the database?), this makes a
specific and very expensive failure mode invisible:

    a startup task raises → the blanket handler swallows it → every statement
    after the raise is skipped → the service reports ``{"status": "healthy"}``
    forever, while being materially broken.

This was found in pantheon-workflow-framework: a missing ``ui_components``
table made the victor's ``init_database()`` raise, which skipped the
``asyncio.create_task(...)`` that self-registers the service's own APIs into
the catalogue. The service never published its APIs, three agent-builder agents
fell to 0.0 health, and *nothing anywhere reported a problem* — three of four
workers logged a clean startup and health said "healthy" throughout.

"Am I alive?" and "did I finish starting up correctly?" are different
questions. Services were only ever answering the first.

The contract
------------
Startup steps that matter record their outcome here; the health endpoint reads
it. A recorded critical failure makes health report ``unhealthy`` and names the
failed step and its error, so the problem is obvious from the outside instead
of buried in one WARNING line among thousands.

Usage::

    from pantheon_shared.locking import startup_state

    try:
        await do_critical_startup_work()
        startup_state.mark_ok("critical_step")
    except Exception as exc:
        startup_state.mark_failed("critical_step", exc, critical=True)
    ...
    startup_state.mark_startup_completed()   # end of the lifespan startup path

and in the health route::

    startup_ok = startup_state.is_healthy()
    status = "healthy" if (database_connected and startup_ok) else "unhealthy"

Scope and concurrency (R9)
--------------------------
State is a plain module-level dict — **per process, per gunicorn worker**, and
deliberately so:

* It describes *this worker's* startup, which is inherently process-local.
* Startup runs once in the lifespan before the worker serves traffic, so the
  writes happen-before any read. Reads are single-dict lookups on the running
  loop. No lock is needed and none is used.

One consequence to design around: only the victor runs victor-only steps, so
only the victor can record a victor-step failure. A load-balanced ``/health``
may hit a non-victor and see clean state. Two mitigations, in order of
preference:

1. Record steps that every worker performs (DB connectivity, migrations check)
   in every worker, so any worker's health reflects them.
2. For victor-only work whose failure must be visible cluster-wide, persist the
   outcome (e.g. to the service's startup-flags table) in addition to calling
   ``mark_failed`` — a follow-up, not provided here.

Expose ``snapshot()`` on a ``/health/startup`` route to see the raw per-worker
view; it carries ``worker_pid`` so you know which worker answered.
"""
from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from pantheon_shared import get_logger

logger = get_logger(__name__)


# step name -> {status, error, at, critical}
_STEPS: Dict[str, Dict[str, Any]] = {}

# Set once the lifespan reaches the end of its startup path.
_STARTUP_COMPLETED: bool = False


def reset() -> None:
    """Clear recorded state. Used by tests; never called in production."""
    global _STARTUP_COMPLETED
    _STEPS.clear()
    _STARTUP_COMPLETED = False


def mark_ok(step: str) -> None:
    """Record that ``step`` completed successfully."""
    _STEPS[step] = {
        "status": "ok",
        "error": None,
        "at": datetime.now(timezone.utc).isoformat(),
        "critical": False,
    }


def mark_failed(step: str, error: BaseException | str, *, critical: bool = True) -> None:
    """Record that ``step`` failed.

    ``critical=True`` (the default) means a failure of this step must make the
    service report unhealthy. Pass ``critical=False`` for genuinely optional
    subsystems whose absence degrades but does not break the service.
    """
    message = f"{type(error).__name__}: {error}" if isinstance(error, BaseException) else str(error)
    _STEPS[step] = {
        "status": "failed",
        "error": message,
        "at": datetime.now(timezone.utc).isoformat(),
        "critical": critical,
    }
    # Loud on the way in, so the log has one unambiguous line to grep for.
    logger.error(
        "STARTUP STEP FAILED step=%s critical=%s error=%s",
        step,
        critical,
        message,
    )


def mark_startup_completed() -> None:
    """Record that the lifespan reached the end of its startup path."""
    global _STARTUP_COMPLETED
    _STARTUP_COMPLETED = True


async def publish_failures(
    session_factory: Any,
    table: str,
    *,
    flag_prefix: str = "startup_failed:",
) -> None:
    """Persist this worker's critical failures so OTHER workers can see them.

    Why this is not optional
    ------------------------
    Victor-only steps run in exactly one worker, so only that worker's in-memory
    state knows they failed. A load-balanced ``/health`` almost never lands on
    the victor — measured in practice: the victor answered 0 of 30 probes — so a
    purely in-memory signal reports "healthy" from every worker that answers and
    the failure stays invisible. That is the same blind spot the whole fix
    exists to close.

    Writing a row per failed step turns the victor's private knowledge into a
    fact every worker can read via :func:`load_published_failures`.

    Best-effort by design: a failure to record a failure must never itself break
    startup, so all exceptions are swallowed after logging.
    """
    critical = failed_steps(critical_only=True)

    # Publish AND retract in one call, so this is safe to invoke unconditionally
    # from every worker at the end of startup.
    #
    # Retraction must not be gated on being the victor: the victor election is
    # skipped entirely on a plain restart (the completion flag from the previous
    # boot is still set), so a victor-only clear leaves a fixed service reporting
    # a stale failure forever. Observed exactly that: table restored, every
    # worker started cleanly, yet /health stayed unhealthy on a dead row.
    #
    # Each worker only ever retracts steps IT ran and IT saw succeed, so a
    # non-victor cannot erase a victor's genuine failure.
    succeeded = [
        name for name, s in _STEPS.items() if s["status"] == "ok"
    ]
    if not critical and not succeeded:
        return

    try:
        from sqlalchemy import text

        async with session_factory() as session:
            for step in critical:
                await session.execute(
                    text(
                        f"INSERT INTO {table} (flag_key, flag_value, created_at) "
                        "VALUES (:k, true, now()) ON CONFLICT (flag_key) DO NOTHING"
                    ),
                    {"k": f"{flag_prefix}{step}"},
                )
            for step in succeeded:
                await session.execute(
                    text(f"DELETE FROM {table} WHERE flag_key = :k"),
                    {"k": f"{flag_prefix}{step}"},
                )
            await session.commit()
    except Exception as exc:  # noqa: BLE001 — never break startup over telemetry
        logger.warning("Could not publish startup failures: %s", exc)


async def load_published_failures(
    session_factory: Any,
    table: str,
    *,
    flag_prefix: str = "startup_failed:",
) -> List[str]:
    """Read failures published by ANY worker (see :func:`publish_failures`).

    Returns the step names another worker recorded as critically failed. Used by
    health endpoints so a non-victor can report a victor-only failure.
    """
    try:
        from sqlalchemy import text

        async with session_factory() as session:
            result = await session.execute(
                text(
                    f"SELECT flag_key FROM {table} "
                    "WHERE flag_key LIKE :p AND flag_value = true"
                ),
                {"p": f"{flag_prefix}%"},
            )
            return sorted(r[0][len(flag_prefix):] for r in result.fetchall())
    except Exception as exc:  # noqa: BLE001 — a probe must never raise
        logger.warning("Could not load published startup failures: %s", exc)
        return []


async def clear_published_failures(
    session_factory: Any,
    table: str,
    *,
    flag_prefix: str = "startup_failed:",
) -> None:
    """Delete published failure rows.

    MUST be called by the victor at the START of startup, before any step runs,
    so a previous boot's failures do not make a now-healthy service look broken.
    """
    try:
        from sqlalchemy import text

        async with session_factory() as session:
            await session.execute(
                text(f"DELETE FROM {table} WHERE flag_key LIKE :p"),
                {"p": f"{flag_prefix}%"},
            )
            await session.commit()
    except Exception as exc:  # noqa: BLE001
        logger.warning("Could not clear published startup failures: %s", exc)


async def check_health(
    session_factory: Any,
    table: str,
    *,
    flag_prefix: str = "startup_failed:",
) -> tuple:
    """One-call helper for health endpoints: ``(startup_ok, startup_error)``.

    Combines this worker's in-memory record with failures published by other
    workers, so a non-victor correctly reports a victor-only failure. Never
    raises — a health probe must not 500 because its own diagnostics failed.

    Typical use::

        startup_ok, startup_error = await startup_state.check_health(
            get_db_session, "myservice_startup_flags"
        )
        status = "healthy" if (db_connected and startup_ok) else "unhealthy"
    """
    startup_ok = is_healthy()
    startup_error = summary_error()

    if startup_ok:
        published = await load_published_failures(
            session_factory, table, flag_prefix=flag_prefix
        )
        if published:
            startup_ok = False
            startup_error = (
                "critical startup step(s) failed on another worker: "
                + ", ".join(published)
            )

    return startup_ok, startup_error


def failed_steps(critical_only: bool = True) -> List[str]:
    """Names of steps that failed, worst-first (critical before non-critical)."""
    out = [
        name
        for name, s in _STEPS.items()
        if s["status"] == "failed" and (s["critical"] or not critical_only)
    ]
    return sorted(out, key=lambda n: (not _STEPS[n]["critical"], n))


def is_healthy() -> bool:
    """True when no critical startup step failed and startup ran to completion."""
    return _STARTUP_COMPLETED and not failed_steps(critical_only=True)


def snapshot() -> Dict[str, Any]:
    """Full per-worker view, for ``/health/startup`` and debugging."""
    return {
        "worker_pid": os.getpid(),
        "startup_completed": _STARTUP_COMPLETED,
        "healthy": is_healthy(),
        "failed_steps": failed_steps(critical_only=False),
        "critical_failures": failed_steps(critical_only=True),
        "steps": dict(_STEPS),
    }


def summary_error() -> Optional[str]:
    """One-line reason for the unhealthy verdict, or None when healthy."""
    if not _STARTUP_COMPLETED:
        return "startup did not run to completion"
    critical = failed_steps(critical_only=True)
    if not critical:
        return None
    parts = [f"{name} ({_STEPS[name]['error']})" for name in critical]
    return "critical startup step(s) failed: " + "; ".join(parts)
