"""
PostgreSQL-based Startup Coordinator.

Ensures exactly one worker (the "Victor") runs startup tasks while all
others wait. Uses PostgreSQL advisory locks for atomic election and a
database table for persistent coordination.

Design:
- Advisory lock serializes workers during election (held ~milliseconds)
- Table row tracks state: no row=first, FALSE=in-progress, TRUE=complete
- Lock released after election; table row prevents duplicate Victors
- Handles stale flags from crashed previous boot cycles via age check

Flow:
1. Workers serialize through pg_advisory_xact_lock (blocking, transaction-level)
2. First worker sees no row (or stale row) → claims Victor
3. Advisory lock released after election
4. Victor runs startup tasks, then sets flag_value=TRUE
5. Losers poll until flag_value=TRUE or timeout

Example:
    from pantheon_shared.locking import PostgresLockCoordinator

    async with PostgresLockCoordinator(
        lock_key="my_task",
        get_db_session=get_db_session
    ) as coordinator:
        if coordinator.is_victor:
            # Run task (only executed by one worker)
            await do_something_once()
        # All workers wait here until victor completes
"""

from __future__ import annotations

import asyncio
import hashlib
import os
from contextlib import AbstractAsyncContextManager, asynccontextmanager
from typing import AsyncGenerator, Callable

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession


from pantheon_shared.logging import get_logger

logger = get_logger(__name__)

# Default table name for startup flags
DEFAULT_STARTUP_FLAGS_TABLE = "startup_flags"


class PostgresLockCoordinator:
    """
    Coordinates startup tasks across multiple workers using PostgreSQL.

    Only one worker becomes the "victor" and executes startup tasks. All other
    workers wait for the victor to complete by polling a completion flag in
    a PostgreSQL table.

    Election uses pg_advisory_xact_lock to serialize workers, then a table row
    to persistently record who is Victor. The advisory lock is held only
    during the brief election check (~milliseconds), NOT during the actual
    startup work.

    Attributes:
        is_victor: True if this worker won the election
        worker_pid: Process ID of this worker (for logging)

    Example:
        async with PostgresLockCoordinator(
            lock_key="agent_builder_startup",
            get_db_session=get_db_session,
            timeout_seconds=60
        ) as coordinator:
            if coordinator.is_victor:
                await initialize_service()
            # All workers wait here
    """

    def __init__(
        self,
        lock_key: str,
        get_db_session: Callable[[], AbstractAsyncContextManager[AsyncSession]],
        startup_flags_table: str = DEFAULT_STARTUP_FLAGS_TABLE,
        timeout_seconds: int = 60,
        poll_interval_seconds: float = 0.2,
        clear_stale_flags: bool = True,
    ):
        """
        Initialize the coordinator.

        Args:
            lock_key: Unique key for this operation (used for advisory lock hash)
            get_db_session: Async context manager function that yields database sessions
            startup_flags_table: Name of table to store completion flags
            timeout_seconds: Maximum time to wait for victor completion (default: 60)
            poll_interval_seconds: How often to poll for completion flag (default: 0.2)
            clear_stale_flags: Kept for backward compatibility; staleness is
                               handled internally by _elect_victor()
        """
        self.lock_key = lock_key
        self.get_db_session = get_db_session
        self.timeout_seconds = timeout_seconds
        self.poll_interval_seconds = poll_interval_seconds
        self.startup_flags_table = startup_flags_table

        self.is_victor: bool = False
        self.worker_pid: int = 0
        self._completion_flag_key: str = f"{lock_key}_complete"

    @property
    def _lock_hash(self) -> int:
        """Convert lock key to numeric hash for PostgreSQL advisory lock."""
        return int(hashlib.md5(self.lock_key.encode()).hexdigest()[:8], 16)

    async def _ensure_startup_flags_table(self) -> None:
        """
        Ensure the startup_flags table exists for all workers.

        This must be called BEFORE victor/loser logic to prevent
        "relation does not exist" errors when losers poll for completion.

        Made idempotent to handle race conditions when multiple workers
        try to create the table simultaneously.
        """
        try:
            async with self.get_db_session() as db:
                await db.execute(text(f"""
                    CREATE TABLE IF NOT EXISTS {self.startup_flags_table} (
                        flag_key VARCHAR(255) PRIMARY KEY,
                        flag_value BOOLEAN NOT NULL DEFAULT FALSE,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """))
                await db.commit()
        except Exception as e:
            error_str = str(e).lower()
            if "duplicate key" not in error_str and "already exists" not in error_str:
                logger.warning(f"Unexpected error ensuring startup_flags table: {e}")

    async def _elect_victor(self) -> bool:
        """
        Elect exactly one worker as Victor using serialized table-based election.

        Uses pg_advisory_lock (blocking) to serialize all workers, then
        checks/updates a table row to determine and record the Victor.
        The advisory lock is released after election — the committed table
        row prevents any subsequent worker from also becoming Victor.

        Algorithm:
        1. Delete stale flags (age > timeout) from previous crashed boot cycles
        2. Check remaining flag state:
           - No row exists → first worker → Victor (INSERT FALSE)
           - flag_value=FALSE → Victor is running → Loser
           - flag_value=TRUE → Victor already completed → Loser

        Returns:
            True if this worker is the Victor, False otherwise
        """
        is_victor = False
        async with self.get_db_session() as db:
            # Use a TRANSACTION-LEVEL advisory lock (pg_advisory_xact_lock).
            # Transaction-level locks are automatically released at commit or
            # rollback — no explicit pg_advisory_unlock is needed. This avoids
            # the session-level lock leak that occurs in SQLAlchemy 2.0 where
            # session.commit() returns the connection to the pool while the
            # session-level advisory lock remains on the original backend
            # connection, causing pg_advisory_unlock to run on a different
            # physical connection and return False.
            await db.execute(
                text("SELECT pg_advisory_xact_lock(:hash)"),
                {"hash": self._lock_hash}
            )

            # Step 1: Delete STALE flags from previous boot cycles.
            # A flag older than timeout_seconds is from a previous boot
            # (either completed or crashed). Remove it so a fresh
            # election can happen.
            await db.execute(text(f"""
                DELETE FROM {self.startup_flags_table}
                WHERE flag_key = :key
                AND EXTRACT(EPOCH FROM (NOW() - created_at)) > :timeout
            """), {
                "key": self._completion_flag_key,
                "timeout": self.timeout_seconds
            })

            # Step 2: Check current flag state (after stale cleanup)
            result = await db.execute(text(f"""
                SELECT flag_value FROM {self.startup_flags_table}
                WHERE flag_key = :key
            """), {"key": self._completion_flag_key})
            row = result.fetchone()

            if row is None:
                # No flag (or stale one was just deleted) → Victor
                await db.execute(text(f"""
                    INSERT INTO {self.startup_flags_table} (flag_key, flag_value)
                    VALUES (:key, FALSE)
                """), {"key": self._completion_flag_key})
                is_victor = True
            else:
                # Flag exists and is recent (age <= timeout):
                # FALSE → another worker is currently Victor
                # TRUE  → Victor already completed this boot cycle
                # Either way, this worker is a Loser.
                is_victor = False

            # Commit releases both the transaction and the advisory lock
            # atomically. The committed flag row guarantees subsequent workers
            # see it and become Losers — no explicit unlock required.
            await db.commit()

        return is_victor

    async def _set_completion_flag(self) -> None:
        """Set the completion flag in PostgreSQL to signal other workers."""
        async with self.get_db_session() as db:
            await db.execute(text(f"""
                INSERT INTO {self.startup_flags_table} (flag_key, flag_value)
                VALUES (:flag_key, TRUE)
                ON CONFLICT (flag_key) DO UPDATE SET flag_value = TRUE
            """), {"flag_key": self._completion_flag_key})
            await db.commit()

    async def _wait_for_completion_flag(self) -> None:
        """
        Poll for completion flag set by victor worker.

        Raises:
            TimeoutError: If victor doesn't complete within timeout_seconds
        """
        wait_start = asyncio.get_event_loop().time()

        while True:
            try:
                async with self.get_db_session() as db:
                    result = await db.execute(text(f"""
                        SELECT flag_value FROM {self.startup_flags_table}
                        WHERE flag_key = :flag_key
                    """), {"flag_key": self._completion_flag_key})
                    row = result.fetchone()
                    if row and row[0] is True:
                        logger.info(
                            f"Worker {self.worker_pid}: Victor completed startup tasks"
                        )
                        return
            except Exception as e:
                logger.warning(f"Error checking completion flag: {e}")

            # Check for timeout
            if asyncio.get_event_loop().time() - wait_start > self.timeout_seconds:
                logger.warning(
                    f"Worker {self.worker_pid}: TIMEOUT waiting for Victor "
                    f"— proceeding anyway"
                )
                return

            await asyncio.sleep(self.poll_interval_seconds)

    async def __aenter__(self) -> "PostgresLockCoordinator":
        """
        Enter the startup coordination context.

        Performs victor election using a serialized table-based approach.
        The victor can execute startup tasks in the user code block.
        Losers will wait in __aexit__ for victor to complete.

        Returns:
            PostgresLockCoordinator with is_victor attribute set
        """
        self.worker_pid = os.getpid()

        # Ensure table exists for ALL workers (before election)
        try:
            await self._ensure_startup_flags_table()
        except Exception as e:
            logger.warning(f"Failed to ensure startup_flags table exists: {e}")

        # Victor election
        try:
            self.is_victor = await self._elect_victor()

            if self.is_victor:
                logger.debug(
                    f"Worker {self.worker_pid}: I am the VICTOR! "
                    f"Acquired startup lock for '{self.lock_key}'"
                )
            else:
                logger.debug(
                    f"Worker {self.worker_pid}: I did not win the VICTOR election — "
                    f"another worker holds the lock for '{self.lock_key}', waiting..."
                )
        except Exception as e:
            logger.warning(f"Failed during victor election: {e}")
            # Fallback: mark as loser and wait
            self.is_victor = False
            logger.debug(
                f"Worker {self.worker_pid}: FALLBACK — marking as loser due to election error"
            )

        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """
        Exit the startup coordination context.

        Victor: Sets completion flag to unblock losers.
        Loser: Waits for victor to set completion flag (blocking).

        This ensures all workers wait for victor to complete startup tasks
        before the context manager exits.
        """
        if self.is_victor:
            # Set completion flag to signal other workers
            try:
                await self._set_completion_flag()
                logger.debug(
                    f"Worker {self.worker_pid}: Startup tasks complete — "
                    f"signaled in PostgreSQL table '{self.startup_flags_table}'"
                )
            except Exception as e:
                logger.warning(f"Failed to set completion flag: {e}")
        else:
            # Losers wait for victor to set completion flag
            await self._wait_for_completion_flag()

        return None


async def get_startup_flags(
    session: AsyncSession,
    table: str,
) -> list[dict]:
    """Return all rows from a startup flags table as plain dicts."""
    result = await session.execute(text(f"""
        SELECT flag_key, flag_value, created_at
        FROM {table}
        ORDER BY created_at ASC
    """))
    rows = result.fetchall()
    return [
        {"flag_key": r[0], "flag_value": r[1], "created_at": r[2].isoformat() if r[2] else None}
        for r in rows
    ]


async def clear_startup_flags(
    session: AsyncSession,
    table: str,
) -> int:
    """Delete all rows from a startup flags table. Returns number of rows deleted."""
    result = await session.execute(text(f"DELETE FROM {table}"))
    await session.commit()
    return result.rowcount


@asynccontextmanager
async def postgres_lock_coordinator(
    lock_key: str,
    get_db_session: Callable[[], AbstractAsyncContextManager[AsyncSession]],
    startup_flags_table: str = DEFAULT_STARTUP_FLAGS_TABLE,
    timeout_seconds: int = 60,
    poll_interval_seconds: float = 0.2,
    clear_stale_flags: bool = True,
) -> AsyncGenerator[PostgresLockCoordinator, None]:
    """
    Context manager for coordinating operations across multiple workers.

    This is a convenience function that creates a PostgresLockCoordinator
    and provides it as a context manager.

    Args:
        lock_key: Unique key for this operation
        get_db_session: Async context manager function that yields database sessions
        startup_flags_table: Name of table to store completion flags
        timeout_seconds: Maximum time to wait for victor completion
        poll_interval_seconds: How often to poll for completion flag
        clear_stale_flags: Kept for backward compatibility

    Yields:
        PostgresLockCoordinator: The coordinator instance with is_victor attribute

    Example:
        async with postgres_lock_coordinator(
            lock_key="my_task",
            get_db_session=get_db_session,
            startup_flags_table="my_task_flags"
        ) as coordinator:
            if coordinator.is_victor:
                await do_something_once()
    """
    coordinator = PostgresLockCoordinator(
        lock_key=lock_key,
        get_db_session=get_db_session,
        timeout_seconds=timeout_seconds,
        poll_interval_seconds=poll_interval_seconds,
        startup_flags_table=startup_flags_table,
        clear_stale_flags=clear_stale_flags,
    )

    async with coordinator as coord:
        yield coord
