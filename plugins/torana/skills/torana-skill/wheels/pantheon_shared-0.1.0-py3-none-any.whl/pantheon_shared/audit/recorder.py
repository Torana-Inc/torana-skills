"""The change-audit recorder (write) + query/history interface.

Part of the shared change-audit primitive (sibling of the autonomous-action
``client.py``). See ``docs/Pantheon_Shared_Audit_Primitive_Design.md`` § 3.2/§ 3.3.

Two write styles (§ 3.2.1):

* **Explicit** ``record_change(...)`` — *the default; the path C4 uses*. The audit
  row is inserted into the caller's ``AsyncSession`` and **co-commits** with the
  audited write (D-3: strongly atomic — rolls back together, commits together).
* **Listener** ``register_change_listener(...)`` — a convenience for service-DB ORM
  models. Mirrors ``rule_audit_listener.py`` exactly: accumulate in ``session.info``
  during ``before_flush`` (the no-SQL zone), bulk-insert in ``after_commit`` in a
  separate transaction, log-not-raise on failure. **Best-effort, not co-committed.**
  Use the explicit path when a lost audit row is unacceptable.

Reads are tenant-scoped in-code (D-5 — there is no ``PantheonDB`` auto-filter on a
bare-``Base`` table), newest-first, ``limit`` clamped to 100, ``has_more`` via a
``limit+1`` fetch.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Optional
from uuid import UUID, uuid4

from sqlalchemy import event, insert, select, text
from sqlalchemy.ext.asyncio import AsyncSession

from pantheon_shared.iam.context import IAMContext
from pantheon_shared.audit.schemas import (
    AuditActorError,
    AuditActorType,
    AuditEventResponse,
    AuditPage,
    AuditValidationError,
    SYSTEM_PRINCIPAL_EMAIL,
)

logger = logging.getLogger(__name__)

_MAX_LIMIT = 100  # platform pagination rule


def diff(
    before: dict, after: dict, fields: list[str]
) -> tuple[Optional[dict], Optional[dict]]:
    """Build minimal old/new maps for the changed ``fields`` only.

    Returns ``(None, None)`` when nothing in ``fields`` changed, so callers can
    skip a no-op audit. Only keys present in ``fields`` are considered; a missing
    key is treated as ``None`` on that side.
    """
    old_map: dict = {}
    new_map: dict = {}
    for f in fields:
        old_v = before.get(f)
        new_v = after.get(f)
        if old_v != new_v:
            old_map[f] = old_v
            new_map[f] = new_v
    if not new_map:
        return None, None
    return old_map, new_map


class AuditRecorder:
    """The single write path + the read/history interface for one audit table."""

    def __init__(
        self,
        session: AsyncSession,
        audit_model: type,
        *,
        iam_context: IAMContext,
        allowed_change_types: Optional[set[str]] = None,
    ) -> None:
        self.session = session
        self.model = audit_model
        self.iam = iam_context
        self.allowed_change_types = allowed_change_types

    # ------------------------------------------------------------------ #
    # actor resolution (D-4) — caller-supplied-first, never forgeable    #
    # ------------------------------------------------------------------ #
    def _resolve_actor(self) -> str:
        if self.iam is None:
            raise AuditActorError(
                "record_change requires an IAM context to attribute the change; "
                "background paths must pass a system IAM context."
            )
        actor = self.iam.email or self.iam.user_id
        if not actor:
            raise AuditActorError("IAM context has neither email nor user_id.")
        return actor

    def _resolve_actor_type(self, explicit: Optional[str]) -> str:
        if explicit:
            return explicit
        if self.iam is not None and self.iam.email == SYSTEM_PRINCIPAL_EMAIL:
            return AuditActorType.SYSTEM
        return AuditActorType.USER

    # ------------------------------------------------------------------ #
    # write (explicit path) — co-commits with the caller's transaction   #
    # ------------------------------------------------------------------ #
    async def record_change(
        self,
        *,
        entity_type: str,
        entity_id: Optional[str],
        change_type: str,
        old_value: Optional[dict],
        new_value: Optional[dict],
        reason: Optional[str] = None,
        source: Optional[str] = None,
        actor_type: Optional[str] = None,
        correlation_id: Optional[UUID] = None,
    ) -> UUID:
        """Append one immutable audit row IN THE CALLER'S TRANSACTION (D-3).

        ``actor``/``actor_type``/tenant/ns/workspace are pulled from the IAM
        context — never trusted from the caller. The row is flushed (so the PK is
        available) but NOT committed here; it commits when the caller commits and
        rolls back if the caller rolls back.

        Raises ``AuditValidationError`` if ``change_type`` is outside
        ``allowed_change_types`` (when that set was supplied); ``AuditActorError``
        if no IAM actor is available.
        """
        if (
            self.allowed_change_types is not None
            and change_type not in self.allowed_change_types
        ):
            raise AuditValidationError(
                f"change_type {change_type!r} not in allowed set "
                f"{sorted(self.allowed_change_types)}"
            )

        actor = self._resolve_actor()
        row_id = uuid4()
        values = {
            "id": row_id,
            "entity_type": entity_type,
            "entity_id": entity_id,
            "change_type": change_type,
            "old_value": old_value,
            "new_value": new_value,
            "actor": actor,
            "actor_type": self._resolve_actor_type(actor_type),
            "reason": reason,
            "source": source,
            "correlation_id": correlation_id,
            "tenant_id": self.iam.tenant_id,
            "namespace_id": self.iam.namespace_id,
            "workspace_id": getattr(self.iam, "workspace_id", None),
        }
        await self.session.execute(insert(self.model).values(**values))
        # Flush so the row is queryable within the same transaction; commit stays
        # with the caller (co-commit, D-3).
        await self.session.flush()
        return row_id

    # ------------------------------------------------------------------ #
    # query / history — tenant-scoped in-code (D-5)                      #
    # ------------------------------------------------------------------ #
    def _scope(self, stmt):
        m = self.model
        stmt = stmt.where(m.tenant_id == self.iam.tenant_id)
        if self.iam.namespace_id is not None:
            stmt = stmt.where(m.namespace_id == self.iam.namespace_id)
        return stmt

    @staticmethod
    def _clamp(limit: int) -> int:
        return max(1, min(limit, _MAX_LIMIT))

    async def _page(self, stmt, *, limit: int, offset: int) -> AuditPage:
        limit = self._clamp(limit)
        offset = max(0, offset)
        m = self.model
        stmt = (
            self._scope(stmt)
            .order_by(m.created_at.desc(), m.id.desc())
            .offset(offset)
            .limit(limit + 1)  # fetch one extra to compute has_more
        )
        rows = (await self.session.execute(stmt)).scalars().all()
        has_more = len(rows) > limit
        items = [AuditEventResponse.model_validate(r) for r in rows[:limit]]
        return AuditPage(items=items, limit=limit, offset=offset, has_more=has_more)

    async def history(
        self,
        *,
        entity_type: str,
        entity_id: Optional[str],
        limit: int = 50,
        offset: int = 0,
    ) -> AuditPage:
        """History for one entity. ``entity_id=None`` reads batch/sweep rows
        (uses ``IS NULL``, never ``= NULL``)."""
        m = self.model
        stmt = select(m).where(m.entity_type == entity_type)
        if entity_id is None:
            stmt = stmt.where(m.entity_id.is_(None))
        else:
            stmt = stmt.where(m.entity_id == entity_id)
        return await self._page(stmt, limit=limit, offset=offset)

    async def history_by_actor(
        self, *, actor: str, limit: int = 50, offset: int = 0
    ) -> AuditPage:
        """"What did actor X change?" across all entities in scope (§ 1.2.1)."""
        stmt = select(self.model).where(self.model.actor == actor)
        return await self._page(stmt, limit=limit, offset=offset)

    async def history_by_correlation(self, *, correlation_id: UUID) -> AuditPage:
        """All rows from one logical action. Single page (no offset paging)."""
        stmt = select(self.model).where(
            self.model.correlation_id == correlation_id
        )
        return await self._page(stmt, limit=_MAX_LIMIT, offset=0)

    async def tenant_timeline(
        self, *, limit: int = 50, offset: int = 0
    ) -> AuditPage:
        """The full tenant-wide audit timeline, newest-first."""
        stmt = select(self.model)
        return await self._page(stmt, limit=limit, offset=offset)


# ----------------------------------------------------------------------- #
# Listener (best-effort) write style — mirrors rule_audit_listener.py     #
# ----------------------------------------------------------------------- #

def register_change_listener(
    audit_model: type,
    watched_model: type,
    fields: list[str],
    *,
    change_type_for: Optional[Any] = None,
) -> None:
    """Attach ``before_flush``/``after_commit`` listeners that audit changes to
    ``watched_model``'s ``fields`` into ``audit_model`` (§ 3.2.1).

    **Best-effort, NOT co-committed (D-3).** SQLAlchemy forbids emitting SQL in
    ``before_flush``, so we accumulate in ``session.info`` and bulk-insert in
    ``after_commit`` in a separate transaction; a failed insert is logged, not
    raised, and the audit row is lost for that change. This mirrors the existing
    detection-fw behaviour exactly. Use ``record_change`` when that is
    unacceptable.

    ``change_type_for(field, old, new) -> str`` lets the caller map a changed
    field to a ``change_type``; defaults to ``"<field>_changed"``.
    """
    from sqlalchemy.orm import Session as _Session

    pending_key = f"_audit_pending_{audit_model.__tablename__}"

    def _change_type(field: str, old: Any, new: Any) -> str:
        if change_type_for is not None:
            return change_type_for(field, old, new)
        return f"{field}_changed"

    def _user_id(session) -> str:  # noqa: ANN001
        return session.info.get("current_user_id", "system")

    def _before_flush(session, flush_context, instances):  # noqa: ANN001
        rows: list[dict] = []
        actor = _user_id(session)
        actor_type = (
            AuditActorType.SYSTEM if actor == "system" else AuditActorType.USER
        )
        for obj in list(session.dirty):
            if not isinstance(obj, watched_model):
                continue
            for field in fields:
                hist = getattr(type(obj), field).get_history(obj, True)
                if not hist.added and not hist.deleted:
                    continue
                old_v = hist.deleted[0] if hist.deleted else None
                new_v = hist.added[0] if hist.added else None
                if old_v == new_v:
                    continue
                rows.append({
                    "id": str(uuid4()),
                    "entity_type": watched_model.__tablename__,
                    "entity_id": str(getattr(obj, "id", "") or "") or None,
                    "change_type": _change_type(field, old_v, new_v),
                    "old_value": None if old_v is None
                    else json.dumps({field: old_v}, default=str),
                    "new_value": None if new_v is None
                    else json.dumps({field: new_v}, default=str),
                    "actor": actor,
                    "actor_type": actor_type,
                    "reason": None,
                    "source": None,
                    "correlation_id": None,
                    "tenant_id": str(getattr(obj, "tenant_id", "") or ""),
                    "namespace_id": str(getattr(obj, "namespace_id", "") or "")
                    or None,
                    "workspace_id": str(getattr(obj, "workspace_id", "") or "")
                    or None,
                })
        if rows:
            session.info.setdefault(pending_key, []).extend(rows)

    def _after_commit(session):  # noqa: ANN001
        rows = session.info.pop(pending_key, [])
        if not rows:
            return
        cols = (
            "id, entity_type, entity_id, change_type, old_value, new_value, "
            "actor, actor_type, reason, source, correlation_id, "
            "tenant_id, namespace_id, workspace_id"
        )
        # CAST(... AS jsonb), NOT the `::jsonb` shorthand — `::` collides with
        # `:param` bind syntax in text() (the rule_audit A8 root cause).
        stmt = text(
            f"INSERT INTO {audit_model.__tablename__} ({cols}) VALUES "
            "(:id, :entity_type, :entity_id, :change_type, "
            "CAST(:old_value AS jsonb), CAST(:new_value AS jsonb), "
            ":actor, :actor_type, :reason, :source, :correlation_id, "
            ":tenant_id, :namespace_id, :workspace_id)"
        )
        try:
            with session.bind.begin() as conn:
                conn.execute(stmt, rows)
        except Exception as exc:  # noqa: BLE001 — log-not-raise (best-effort, D-3)
            logger.error(
                "audit_listener_insert_failed: %s: %s (row_count=%d, table=%s)",
                type(exc).__name__, str(exc), len(rows), audit_model.__tablename__,
            )

    event.listen(_Session, "before_flush", _before_flush)
    event.listen(_Session, "after_commit", _after_commit)
    logger.info(
        "audit_change_listener_registered table=%s watched=%s fields=%s",
        audit_model.__tablename__, watched_model.__tablename__, fields,
    )
