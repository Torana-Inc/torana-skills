"""Correlation ID helpers. [DESIGN §2.3.3]

The correlation_id groups all audit records produced by a single autonomous
trigger (e.g. one event:data_source_added can spawn many audit records).

Rules:
- Generated at the outermost entry point (trigger handler, endpoint).
- Propagated in-process via function arguments.
- Propagated cross-service via X-Pantheon-Correlation-Id HTTP header.
- Reversal records reuse the same correlation_id as the action they reverse.
- We generate our own UUID4, separate from OTel trace_id (which is sampling-
  driven and not guaranteed to be unique).
"""

from uuid import UUID, uuid4

CORRELATION_HEADER = "X-Pantheon-Correlation-Id"


def generate_correlation_id() -> UUID:
    """Return a fresh UUID4 to start a new correlated action group."""
    return uuid4()


def correlation_id_header(correlation_id: UUID) -> dict:
    """Return the HTTP header dict for propagating correlation_id cross-service."""
    return {CORRELATION_HEADER: str(correlation_id)}
