"""Security-event audit client (OI-133): one row in pantheon-auth's `audit_logs`.

A third sibling in this package, distinct from the autonomous-action client (`client.py`, agent
actions with mode vectors) and the change-audit primitive (`recorder.py`, per-service tables).
This one records WHO did WHAT to WHICH TENANT in the platform security log, the table
`impersonation.start` already writes and `GET /audit-logs` / `torana audit-logs` read.

First use: a super admin reading another tenant's data (`audit_cross_tenant_read`).

Write path: `POST {AUTH_SERVICE_URL}/api/v1/internal/audit-logs` with a service JWT (east-west,
never nginx). Call it with NO database session open (root CLAUDE.md, defect B).
"""

from __future__ import annotations

import os
from typing import Any, Awaitable, Callable, Optional

from pantheon_shared import get_logger
from pantheon_shared.http import PantheonClient
from pantheon_shared.pantheon_services import PantheonService

logger = get_logger(__name__)

_SERVICE_NAME = os.getenv("APPLICATION_NAME", "pantheon-service")

#: ⛔ THE fail-mode switch for cross-tenant reads, and the only one (OI-133; Bhakta's security call).
#: False = best-effort: a failed audit write is logged at ERROR and the read still returns.
#: True  = fail-closed: the caller must refuse the read when the audit write fails
#:         (`audit_cross_tenant_read` raises `AuditWriteFailed`).
CROSS_TENANT_AUDIT_FAIL_CLOSED = False

#: `tenant_id` value meaning "every tenant" (an SA list that named no tenant). Defined once, in iam/cross_tenant.
from pantheon_shared.iam.cross_tenant import ALL_TENANTS  # noqa: E402,F401  (re-exported)


class AuditWriteFailed(RuntimeError):
    """The security audit row could not be written (raised only when fail-closed)."""


#: I-65 condition 1: pantheon-auth must not call ITSELF over HTTP. Auth registers an in-process writer at
#: startup (`register_local_security_event_writer`); `write_security_event` then uses it instead of the
#: east-west route. Every other service leaves it None and goes over HTTP.
_local_writer: Optional[Callable[..., Awaitable[str]]] = None


def register_local_security_event_writer(writer: Optional[Callable[..., Awaitable[str]]]) -> None:
    """Install (or clear, with None) the in-process writer. Called only by pantheon-auth."""
    global _local_writer
    _local_writer = writer


async def write_security_event(
    *,
    action: str,
    resource_type: str,
    tenant_id: Optional[str],
    user_id: Optional[str],
    user_email: Optional[str],
    caller_tenant_id: str,
    request_id: Optional[str] = None,
    details: Optional[dict[str, Any]] = None,
    timeout: float = 5.0,
) -> str:
    """Write one `event_type=security` audit row in pantheon-auth. Returns its id; raises on any failure.

    `caller_tenant_id` scopes the service token of this hop (the acting user's own tenant); the row's
    `tenant_id` is the tenant the event is ABOUT."""
    if _local_writer is not None:
        return await _local_writer(action=action, resource_type=resource_type, tenant_id=tenant_id,
                                   user_id=user_id, user_email=user_email, request_id=request_id,
                                   details=details or {}, recorded_by=_SERVICE_NAME)
    client = PantheonClient(service_name=_SERVICE_NAME, tenant_id=str(caller_tenant_id),
                            target_service=PantheonService.AUTH)
    response = await client.post(
        "/api/v1/internal/audit-logs",
        json={"action": action, "resource_type": resource_type, "tenant_id": tenant_id,
              "user_id": user_id, "user_email": user_email, "request_id": request_id,
              "status": "success", "details": details or {}},
        timeout=timeout,
    )
    response.raise_for_status()
    return response.json()["id"]


async def audit_cross_tenant_read(
    *,
    resource_type: str,
    route: str,
    target_tenant_id: str,
    actor_user_id: Optional[str],
    actor_email: Optional[str],
    own_tenant_id: str,
    request_id: Optional[str] = None,
    details: Optional[dict[str, Any]] = None,
) -> Optional[str]:
    """Record that a super admin read another tenant's data (`target_tenant_id`, or `ALL_TENANTS`), awaited.

    I-65: a thin caller of `pantheon_shared.iam.cross_tenant` — the same record (`CrossTenantAccess`) and the
    same row as the `?tenant_id=` swap. Kept for a read whose target is NOT the swap (datalake `POST /query`
    takes it in the body). `route` is "<METHOD> <template>". Best-effort or fail-closed per
    `CROSS_TENANT_AUDIT_FAIL_CLOSED`. Returns the audit row id, or None when the write failed best-effort.
    """
    from pantheon_shared.iam.cross_tenant import CrossTenantAccess, _trace_id, _write
    method, _, template = route.partition(" ")
    if not template:
        method, template = "GET", route
    access = CrossTenantAccess(
        actor_user_id=str(actor_user_id) if actor_user_id else None, actor_email=actor_email,
        home_tenant_id=str(own_tenant_id), target_tenant_id=str(target_tenant_id), method=method.upper(),
        route=template, trace_id=request_id or _trace_id(), reason=None, resource_type=resource_type[:50],
        read_only=True)
    try:
        return await _write(access, extra=details)
    except Exception as e:
        logger.error("cross_tenant_read.audit_write_failed", resource_type=resource_type, route=route,
                     target_tenant_id=str(target_tenant_id), actor_user_id=actor_user_id,
                     fail_closed=CROSS_TENANT_AUDIT_FAIL_CLOSED, error=str(e))
        if CROSS_TENANT_AUDIT_FAIL_CLOSED:
            raise AuditWriteFailed(str(e)) from e
        return None
