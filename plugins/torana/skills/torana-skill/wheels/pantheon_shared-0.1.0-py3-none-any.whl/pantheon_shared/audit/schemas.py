"""Canonical change-audit response shapes, constants, and errors.

Part of the shared change-audit primitive (sibling of the autonomous-action
``client.py``). See ``docs/Pantheon_Shared_Audit_Primitive_Design.md`` § 3.3/§ 3.4.

This module is dependency-light on purpose: it is imported by both the model
mixin and the recorder, and consumed verbatim by every adopting service's
history endpoint + the shared FE timeline.
"""

from __future__ import annotations

from datetime import datetime
from typing import Optional
from uuid import UUID

from pydantic import BaseModel, Field


# --------------------------------------------------------------------------- #
# Constants (the magic strings live in exactly one place)                     #
# --------------------------------------------------------------------------- #

class AuditSource:
    """How a change entered the system (§ 3.4). Not who did it."""

    UI = "ui"
    CLI = "cli"
    API = "api"
    SYNC = "sync"
    AGENT = "agent"

    ALL = frozenset({UI, CLI, API, SYNC, AGENT})


class AuditActorType:
    """Who did it — the actor discriminator (§ 3.4, D-4)."""

    USER = "user"
    SYSTEM = "system"
    AGENT = "agent"

    ALL = frozenset({USER, SYSTEM, AGENT})


# The system-principal email used by IAMBootstrapHelper.get_system_iam_context()
# (iam/bootstrap.py:318). D-4 derives actor_type=SYSTEM from this as a *fallback*
# when the caller does not pass actor_type explicitly. Kept here so the string is
# defined once.
SYSTEM_PRINCIPAL_EMAIL = "system@pantheon.internal"


# --------------------------------------------------------------------------- #
# Errors                                                                      #
# --------------------------------------------------------------------------- #

class AuditError(Exception):
    """Base class for all change-audit primitive errors."""


class AuditValidationError(AuditError):
    """Raised when ``change_type`` is outside ``allowed_change_types`` (D-7)."""


class AuditImmutabilityError(AuditError):
    """Raised when something attempts to mutate or delete a persisted audit row.

    Append-only is enforced for the ORM unit-of-work path via mapper events
    (§ 3.1). Bulk Core ``update()``/``delete()`` bypass this and are unsupported.
    """


class AuditActorError(AuditError):
    """Raised when no IAM actor is available to attribute the change to.

    An audit row with a forged or absent actor is worse than no audit row, so
    the recorder refuses to write one (§ 3.6).
    """


# --------------------------------------------------------------------------- #
# Response shapes                                                             #
# --------------------------------------------------------------------------- #

class AuditEventResponse(BaseModel):
    """The ONE shape every service's history endpoint returns and the FE renders.

    Mirrors the canonical ``AuditEventMixin`` columns (§ 3.1) minus the IAM
    scope columns (tenant/namespace/workspace are request context, not payload).
    """

    id: UUID
    entity_type: str
    entity_id: Optional[str] = None
    change_type: str
    old_value: Optional[dict] = None
    new_value: Optional[dict] = None
    actor: str
    actor_type: str
    reason: Optional[str] = None
    source: Optional[str] = None
    correlation_id: Optional[UUID] = None
    created_at: datetime

    model_config = {"from_attributes": True}


class AuditPage(BaseModel):
    """A page of audit events (§ 3.3).

    ``items`` IS the ``AuditEventResponse[]`` an adopter may return as a bare
    array (C4 reconciliation, § 3.3). ``has_more`` is computed via a ``limit+1``
    fetch — no ``COUNT(*)`` on an unbounded table.
    """

    items: list[AuditEventResponse] = Field(default_factory=list)
    limit: int
    offset: int
    has_more: bool
