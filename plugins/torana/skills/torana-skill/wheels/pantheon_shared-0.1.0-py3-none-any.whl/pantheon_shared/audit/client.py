"""Audit write client. [DESIGN §2.3]

Two write paths:
1. In-process (caller is pantheon-program-framework): direct DB insert via
   an injected async session, within the caller's transaction.
2. HTTP (all other callers): POST /audit/records on pantheon-program-framework
   via PantheonClient with a service JWT.

The caller selects the path by passing `db` (in-process) or leaving it None
(HTTP). The HTTP path is best-effort durable — see audit-write-failure policy
[DESIGN §11.4].
"""

import os
from typing import Literal, Optional
from uuid import UUID

from pantheon_shared import get_logger
from pantheon_shared.iam.context import IAMContext
from pantheon_shared.http import PantheonClient
from pantheon_shared.pantheon_services import PantheonService, get_pantheon_service_url
from pantheon_shared.audit.correlation import correlation_id_header

logger = get_logger(__name__)

_SERVICE_NAME = os.getenv("APPLICATION_NAME", "pantheon-service")


async def write_audit_record(
    *,
    iam_context: IAMContext,
    agent: str,
    action_kind: str,
    target_kind: str,
    target_id: str,
    actor_kind: Literal["system", "user", "system_on_behalf_of_user"],
    actor_id: Optional[UUID],
    justification: dict,
    evidence_ref: dict,
    reversal_plan: Optional[dict],
    correlation_id: UUID,
    mode_vector: object,
    db=None,
) -> UUID:
    """Write a single audit record. Returns the new record id.

    Atomicity contract: best-effort durable. The audit record write may fail
    independently of the action it describes. [DESIGN §11.4]

    Args:
        iam_context: IAM context of the calling agent (sets tenant_id/namespace_id).
        agent: Logical agent name (e.g. "builder", "triage").
        action_kind: What type of action occurred (e.g. "proposal_created").
        target_kind: What was acted on (e.g. "proposal", "rule").
        target_id: UUID or identifier of the target.
        actor_kind: "system", "user", or "system_on_behalf_of_user".
        actor_id: UUID of the acting user/service when applicable.
        justification: Structured reason dict.
        evidence_ref: Pointer dict (simulation_run_id, ledger_entry_id, etc.).
        reversal_plan: Typed reversal plan dict, or None for irreversible actions.
        correlation_id: UUID grouping all records from a single trigger event.
        mode_vector: Resolved ModeVector (or dict/dataclass with .preset and
                     serialisable attributes) used to gate this action.
        db: AsyncSession — if provided, writes in-process within caller's
            transaction. If None, uses HTTP path.

    Returns:
        UUID of the created audit record.
    """
    mode_vector_dict = _serialize_mode_vector(mode_vector)
    mode_at_action = mode_vector_dict.get("preset", "unknown")
    reversal_status = "irreversible" if reversal_plan is None else "not_attempted"

    payload = {
        "tenant_id": str(iam_context.tenant_id),
        "namespace_id": str(iam_context.namespace_id or ""),
        "agent": agent,
        "mode_at_action": mode_at_action,
        "mode_vector_at_action": mode_vector_dict,
        "action_kind": action_kind,
        "target_kind": target_kind,
        "target_id": str(target_id),
        "actor_kind": actor_kind,
        "actor_id": str(actor_id) if actor_id else None,
        "justification": justification,
        "evidence_ref": evidence_ref,
        "reversal_plan": reversal_plan,
        "reversal_status": reversal_status,
        "correlation_id": str(correlation_id),
    }

    if db is not None:
        return await _write_in_process(payload, db)
    return await _write_via_http(payload, iam_context, correlation_id)


async def _write_in_process(payload: dict, db) -> UUID:
    """Direct DB insert — caller is pantheon-program-framework."""
    import json
    from uuid import uuid4
    from sqlalchemy import text

    record_id = uuid4()
    payload["id"] = str(record_id)

    # asyncpg requires JSONB parameters to be JSON strings, not Python dicts,
    # when using raw text() queries.
    _JSONB_FIELDS = {"mode_vector_at_action", "justification", "evidence_ref", "reversal_plan"}
    serialized = {
        k: (json.dumps(v) if k in _JSONB_FIELDS and v is not None else v)
        for k, v in payload.items()
    }

    cols = ", ".join(serialized.keys())
    placeholders = ", ".join(f":{k}" for k in serialized.keys())
    stmt = text(f"INSERT INTO audit_record ({cols}) VALUES ({placeholders})")
    await db.execute(stmt, serialized)
    return record_id


async def _write_via_http(
    payload: dict, iam_context: IAMContext, correlation_id: UUID
) -> UUID:
    """HTTP path: POST /audit/records on pantheon-program-framework."""
    base_url = get_pantheon_service_url(PantheonService.PROGRAM_FRAMEWORK)
    client = PantheonClient(
        service_name=_SERVICE_NAME,
        tenant_id=iam_context.tenant_id,
        namespace_id=iam_context.namespace_id,
    )
    extra_headers = correlation_id_header(correlation_id)
    response = await client.post(
        f"{base_url}/api/v1/audit/records",
        json=payload,
        headers=extra_headers,
        timeout=10.0,
    )
    response.raise_for_status()
    data = response.json()
    from uuid import UUID as _UUID
    return _UUID(data["id"])


def _serialize_mode_vector(mode_vector: object) -> dict:
    """Convert ModeVector (dataclass or dict) to a plain dict for storage."""
    if mode_vector is None:
        return {"preset": "unknown", "schema_version": 1}
    if isinstance(mode_vector, dict):
        return mode_vector
    if hasattr(mode_vector, "__dataclass_fields__"):
        import dataclasses
        return dataclasses.asdict(mode_vector)
    if hasattr(mode_vector, "model_dump"):
        return mode_vector.model_dump()
    if hasattr(mode_vector, "__dict__"):
        return {
            k: v for k, v in mode_vector.__dict__.items()
            if not k.startswith("_")
        }
    return {"preset": str(mode_vector), "schema_version": 1}
