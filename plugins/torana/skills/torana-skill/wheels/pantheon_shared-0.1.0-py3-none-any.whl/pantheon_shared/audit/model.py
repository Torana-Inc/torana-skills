"""The change-audit model mixin (`AuditEventMixin`) + `audit_indexes()` helper.

Part of the shared change-audit primitive. See
``docs/Pantheon_Shared_Audit_Primitive_Design.md`` § 3.1.

WHY A MIXIN, NOT A BASE TABLE
-----------------------------
Each service owns its own Postgres DB; a single shared table is architecturally
impossible. The mixin gives identical columns/indexes/contract; each service
subclasses it on **bare ``Base``** and runs its own Alembic migration to create
*its* table. One schema definition, N physical tables, zero divergence.

BASE CLASS (D-5)
----------------
Subclass on bare SQLAlchemy ``Base`` — **never** ``PantheonDB``/``BaseModel``.
``PantheonDB`` forces ``is_deleted``/``updated_at``/``updated_by`` and filters
``is_deleted = False`` on every read. An append-only audit table must have none
of those. Consequence: adopters do not get ``PantheonDB``'s CRUD/IAM-read
filtering for free — the recorder hand-rolls tenant scoping on reads.

PLATFORM-INVARIANT DEVIATION (D-6)
----------------------------------
CLAUDE.md requires ``is_deleted`` and ``description`` on "all DB entities". An
immutable, append-only audit row is the explicit exception: it is never
soft-deleted (``is_deleted`` is meaningless) and each row's "description" *is*
its ``change_type`` + ``reason`` (a separate ``description`` column is
redundant). This deviation is intentional, not a defect.

IMMUTABILITY (§ 3.1)
--------------------
The recorder exposes no update/delete path. The mixin additionally installs
``before_update``/``before_delete`` **mapper** events on each concrete subclass
that raise ``AuditImmutabilityError``. These fire for ORM unit-of-work writes —
the only supported path. Bulk Core ``update()``/``delete()`` bypass the unit of
work and are therefore declared unsupported; adopters needing defense-in-depth
add a DB trigger in their migration (see the adopter guide, § 4).
"""

from __future__ import annotations

from datetime import datetime, timezone
from uuid import uuid4

from uuid import UUID

from sqlalchemy import CHAR, Column, DateTime, Index, String, event
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.types import JSON, TypeDecorator

from pantheon_shared.audit.schemas import AuditImmutabilityError


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


class GUID(TypeDecorator):
    """Platform-independent UUID.

    Uses Postgres ``UUID`` natively (so production columns are true ``uuid`` —
    D-1) and falls back to ``CHAR(36)`` everywhere else (e.g. SQLite under test).
    Values round-trip as ``uuid.UUID`` on both backends.
    """

    impl = CHAR
    cache_ok = True

    def load_dialect_impl(self, dialect):  # noqa: ANN001
        if dialect.name == "postgresql":
            return dialect.type_descriptor(PG_UUID(as_uuid=True))
        return dialect.type_descriptor(CHAR(36))

    def process_bind_param(self, value, dialect):  # noqa: ANN001
        if value is None:
            return None
        if dialect.name == "postgresql":
            return value if isinstance(value, UUID) else UUID(str(value))
        return str(value)

    def process_result_value(self, value, dialect):  # noqa: ANN001
        if value is None:
            return None
        return value if isinstance(value, UUID) else UUID(str(value))


# Portable column types: real Postgres types in production, SQLite-friendly
# fallbacks under test.
_UUID = GUID()
_JSON = JSON().with_variant(JSONB, "postgresql")


class AuditEventMixin:
    """Canonical change-audit columns + the append-only/immutable contract.

    Materialize a table by subclassing on bare ``Base``::

        class GovernanceChangeAudit(Base, AuditEventMixin):
            __tablename__ = "governance_change_audit"
            __table_args__ = tuple(audit_indexes("governance_change_audit"))
    """

    # --- identity -------------------------------------------------------- #
    id = Column(_UUID, primary_key=True, default=uuid4)

    # --- what changed ---------------------------------------------------- #
    entity_type = Column(String(64), nullable=False)
    entity_id = Column(String(255), nullable=True)
    change_type = Column(String(48), nullable=False)
    old_value = Column(_JSON, nullable=True)
    new_value = Column(_JSON, nullable=True)

    # --- who / why / how ------------------------------------------------- #
    actor = Column(String(255), nullable=False)
    actor_type = Column(String(16), nullable=False)
    reason = Column(String, nullable=True)  # Text in PG; unbounded String elsewhere
    source = Column(String(16), nullable=True)
    correlation_id = Column(_UUID, nullable=True)

    # --- when (append-only — no updated_at) ------------------------------ #
    created_at = Column(DateTime(timezone=True), nullable=False, default=_utc_now)

    # --- IAM scope (String(255) to match how every service overrides these) #
    tenant_id = Column(String(255), nullable=False)
    namespace_id = Column(String(255), nullable=True)
    workspace_id = Column(String(255), nullable=True)

    @classmethod
    def __declare_last__(cls) -> None:
        """Install the immutability guard once the mapper is configured.

        ``__declare_last__`` runs after each concrete subclass is mapped, so the
        listeners attach to the real table class (not the abstract mixin).
        Idempotent: guarded by a per-class flag so re-imports don't stack
        listeners.
        """
        if getattr(cls, "_audit_immutability_installed", False):
            return

        def _block(mapper, connection, target):  # noqa: ANN001
            raise AuditImmutabilityError(
                f"{type(target).__name__} is append-only — audit rows cannot be "
                f"updated or deleted (id={getattr(target, 'id', None)})."
            )

        event.listen(cls, "before_update", _block)
        event.listen(cls, "before_delete", _block)
        cls._audit_immutability_installed = True


def audit_indexes(table_name: str) -> list[Index]:
    """Return the four canonical indexes for an audit table (§ 3.1).

    Each adopter spreads these into ``__table_args__`` so they are emitted with
    the adopter's own table name (index names are namespaced by table to avoid
    collisions when multiple audit tables live in one DB).
    """
    return [
        # entity history reads
        Index(
            f"ix_{table_name}_entity",
            "tenant_id", "entity_type", "entity_id", "created_at",
        ),
        # "what did user X change?" (§ 1.2.1)
        Index(
            f"ix_{table_name}_actor",
            "tenant_id", "actor", "created_at",
        ),
        # tenant-wide timeline
        Index(
            f"ix_{table_name}_tenant_time",
            "tenant_id", "created_at",
        ),
        # correlation grouping
        Index(
            f"ix_{table_name}_correlation",
            "correlation_id",
        ),
    ]
