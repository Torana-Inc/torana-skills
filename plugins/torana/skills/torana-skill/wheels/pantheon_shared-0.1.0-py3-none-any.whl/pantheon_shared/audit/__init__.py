"""Audit package.

Two sibling concerns live here (do not conflate them):

1. **Autonomous-action audit client** (original) — ``write_audit_record`` records
   *autonomous agent actions* with mode-vector/reversal-plan semantics.
2. **Change-audit primitive** (newer) — a reusable entity-change-audit
   (``AuditEventMixin`` + ``AuditRecorder`` + ``AuditEventResponse``) so services
   stop hand-rolling near-identical audit tables. See
   ``docs/Pantheon_Shared_Audit_Primitive_Design.md``.

Both share ``correlation.py``. Consumers import only from this barrel.
"""

# --- autonomous-action client (existing — unchanged) ---------------------- #
from pantheon_shared.audit.client import write_audit_record
from pantheon_shared.audit.correlation import (
    correlation_id_header,
    generate_correlation_id,
)

# --- change-audit primitive (new) ----------------------------------------- #
from pantheon_shared.audit.model import AuditEventMixin, audit_indexes
from pantheon_shared.audit.recorder import (
    AuditRecorder,
    diff,
    register_change_listener,
)
from pantheon_shared.audit.schemas import (
    SYSTEM_PRINCIPAL_EMAIL,
    AuditActorError,
    AuditActorType,
    AuditError,
    AuditEventResponse,
    AuditImmutabilityError,
    AuditPage,
    AuditSource,
    AuditValidationError,
)

__all__ = [
    # autonomous-action client
    "write_audit_record",
    "generate_correlation_id",
    "correlation_id_header",
    # change-audit primitive — model
    "AuditEventMixin",
    "audit_indexes",
    # change-audit primitive — recorder
    "AuditRecorder",
    "diff",
    "register_change_listener",
    # change-audit primitive — schemas / constants / errors
    "AuditEventResponse",
    "AuditPage",
    "AuditSource",
    "AuditActorType",
    "SYSTEM_PRINCIPAL_EMAIL",
    "AuditError",
    "AuditValidationError",
    "AuditImmutabilityError",
    "AuditActorError",
]
