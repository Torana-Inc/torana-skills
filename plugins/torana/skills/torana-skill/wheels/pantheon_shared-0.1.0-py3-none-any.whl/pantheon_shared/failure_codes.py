"""The C-01 failure registry: the units, the error classes and the error codes `log_failure` accepts.

One registry for the whole platform (EM C-01, docs/FAILURE_CONVENTION.md). Stream C alerts on
`<unit>.failed` lines and routes them by `error_class`; `error_code` is carried for drill-down.

To add a code: add one line to `FAILURE_CODES` below, with the class it usually has. A call site may
still pass a different `error_class` for one occurrence. A code that is not listed here is NOT
dropped: `log_failure` logs it as `<domain>.unknown` and keeps the original in `error_code_raw`, so
a missing line shows up in Loki instead of disappearing.
"""

from typing import Dict, FrozenSet

#: The units of work a failure line can be about. Stream C keys one alert rule on each
#: `<unit>.failed` name, so a new unit is a convention change, not a call-site choice.
FAILURE_UNITS: FrozenSet[str] = frozenset({
    "api.request",
    "agent.turn",
    "sync.run",
    "rule.run",
    "pr.action",
    "home.source",        # G4 #9: a Home data source the collector could not read (Torana's side; never Home text)
    "engagement.derive",  # the App Landing Page: deriving the app's Intent or Goals failed (Torana's side; the last good one stays)
})

#: How a failure is routed (C-02): `config` → the tenant's owner, `bug` → engineering,
#: `transient` → only after repeats, `upstream` → a provider we depend on, `permanent` → the
#: request can never succeed as sent (no retry will help).
ERROR_CLASSES: FrozenSet[str] = frozenset({
    "transient",
    "permanent",
    "config",
    "upstream",
    "bug",
})

#: The domains an `error_code` may start with.
ERROR_DOMAINS: FrozenSet[str] = frozenset({
    "api", "agent", "sync", "rule", "pr", "db", "auth", "llm", "home", "engagement",
})

#: Every known `error_code` → its usual `error_class`.
FAILURE_CODES: Dict[str, str] = {
    # api — an HTTP request answered 5xx or raised
    "api.internal_error": "bug",
    "api.upstream_error": "upstream",
    "api.unhandled_exception": "bug",
    # agent — an agent turn that did not succeed
    "agent.turn_error": "bug",
    "agent.timeout": "transient",
    "agent.tool_error": "bug",
    # llm — the model provider
    "llm.rate_limited": "transient",
    "llm.timeout": "transient",
    "llm.malformed_response": "upstream",
    "llm.provider_error": "upstream",
    "llm.auth_failed": "config",
    # home — a Home data source the collector could not read (G4 #9). Retried on the next refresh.
    "home.source_unread": "transient",      # a timeout, a throttle or a 5xx: retried on the next refresh
    "home.app_health_red": "bug",    # an App Health row whose cause is Torana's own: engineering fixes it
    "home.source_bug": "bug",               # a ValueError / misconfiguration / a 4xx our own service refused
    # engagement — the App Landing Page's Intent and Goals derivation
    "engagement.derivation_failed": "bug",      # the derivation raised or returned nothing usable: engineering fixes it
    "engagement.links_unreadable": "transient",  # the app's links could not be read this time: retried on the next refresh
    # sync — an ETL run
    "sync.run_error": "bug",
    "sync.stall_timeout": "transient",
    # EM S-07b: a CI scan pull that failed its third attempt (PI services/ci_scan_pull.py; the row stays `failed`)
    "sync.ci_scan_pull_failed": "transient",
    # EM B-02: a scheduled fire the ETL scheduler dropped (later than its misfire grace; PI etl/scheduler.py).
    # `bug`, not `transient`: with the 300 s grace a drop means the leader's loop was blocked for 5+ minutes,
    # which is an engineering defect, and one drop must page (transient waits for repeats).
    "sync.schedule_missed": "bug",
    "sync.stuck_timeout": "transient",
    "sync.mapping_not_found": "config",
    "sync.mapping_invalid": "config",
    "sync.auth_failed": "config",
    "sync.provider_error": "upstream",
    # Torana's OWN identity mint failed (e.g. the laptop's ADC is not impersonated): Torana's side, not the customer's
    # to fix, so `bug` (engineering), never `config` (which routes to the tenant owner).
    "sync.credential_mint_failed": "bug",
    # T3-1: the datastore re-key's supersede UPDATE failed after a completed full walk (PI
    # etl/supersede_legacy_keys.py). The data landed; the legacy row was not withdrawn, the sweep
    # skipped, the run marked partial. `bug`: the statement is fixed SQL, a failure is a defect.
    "sync.supersede_failed": "bug",
    # rule — a rule run
    "rule.engine_error": "bug",
    "rule.execution_failed": "transient",
    "rule.permanent_refusal": "permanent",
    # pr — a fix-PR action on the platform side
    "pr.already_tracked": "permanent",
    "pr.invalid_transition": "permanent",
    "pr.not_found": "permanent",
    "pr.action_error": "bug",
    # db / auth — shared causes any unit may report
    "db.unavailable": "transient",
    "db.integrity_error": "bug",
    "auth.refused": "config",
}

#: The class of a `<domain>.unknown` code: a failure nobody has named yet is engineering's.
UNKNOWN_CLASS = "bug"

# Every registered code must use a known domain and class (checked at import, so a typo here
# fails the first test run, not a production line).
for _code, _cls in FAILURE_CODES.items():
    assert _code.split(".", 1)[0] in ERROR_DOMAINS, _code
    assert _cls in ERROR_CLASSES, _code
