"""SQL parsing + lineage utilities.

Currently exposes ``extract_source_tables`` for deriving the set of base
tables a SQL statement reads. Used by:

  - pantheon-detection-framework: populates ``queries.source_tables`` at
    create/update time so the FE can render rule → table lineage.
  - pantheon-data-transformers: populates ``transformers.source_tables``
    when the caller did not supply it, so transformer → table lineage is
    always available.
"""

from pantheon_shared.sql.lineage import (
    COLUMN_LINEAGE_VERSION,
    columns_read_from,
    extract_column_lineage,
    extract_source_tables,
)
from pantheon_shared.sql.grain import (
    FANOUT,
    GRAIN_CHECK_VERSION,
    GrainResult,
    PASS,
    SKIPPED,
    VACUOUS,
    build_grain_query,
    check_grain,
    infer_key_columns,
    neutralize_binds,
    strip_trailing_order_by,
)
from pantheon_shared.sql.why_plan import (
    WHY_PLAN_VERSION,
    build_why_plan,
)

__all__ = [
    "check_grain",
    "GrainResult",
    "GRAIN_CHECK_VERSION",
    "build_grain_query",
    "infer_key_columns",
    "neutralize_binds",
    "strip_trailing_order_by",
    "PASS",
    "FANOUT",
    "VACUOUS",
    "SKIPPED",
    "extract_source_tables",
    "extract_column_lineage",
    "columns_read_from",
    "COLUMN_LINEAGE_VERSION",
    "build_why_plan",
    "WHY_PLAN_VERSION",
]
