"""Build the "why is this number what it is?" PLAN from a widget query's SQL.

The plan is the deterministic half of the predicate-funnel feature (see
pantheon-viz/docs/WIDGET_WHY_SPEC.md). Given a widget's `sql_command`, it splits
the top-level `WHERE ... AND ...` into an ordered predicate list and produces the
layered `COUNT(*)` slice-SQL that a consumer runs to show WHERE the row set
collapses:

    base (no WHERE)                          -> COUNT(*) FROM R
    + predicate[0]                           -> COUNT(*) FROM R WHERE p0
    + predicate[0] AND predicate[1]          -> COUNT(*) FROM R WHERE p0 AND p1
    ...

WHY THIS IS COMPUTED AT AUTHOR TIME, NOT AT REQUEST TIME
--------------------------------------------------------
The decomposition is a PURE FUNCTION OF THE SQL — no data is involved. So it is
computed once, when the query is saved (pantheon-detection-framework, beside
`extract_source_tables`), and persisted on the query row. The consumer
(pantheon-viz) READS the plan and only EXECUTES the counts; it never re-parses
SQL at request time. The counts themselves are live data-facts and are run
dynamically by the consumer — they are deliberately NOT part of the plan.

WHAT IS DECOMPOSABLE, AND THE HONEST BOUNDARY
---------------------------------------------
Decomposable: a single-relation `FROM` with a `WHERE` whose root is a chain of
top-level `AND`s. Each `AND` branch becomes one funnel step. This covers the
common widget shape (a COUNT/aggregate over one transformer output).

NOT decomposable (marked `decomposable=False`, consumer shows the single final
count honestly):
  - `FROM` is a join or subquery (more than one base relation / a derived table)
    — attributing a collapse to one relation needs join analysis (Tier 3, later).
  - `WHERE` root is an `OR` — removing an OR branch GROWS the set, so a cumulative
    funnel would be misleading. Kept as a single step.
  - no `FROM` table at all, or unparseable SQL.

NEVER RAISES. Any parse problem yields `{decomposable: False, ...}` with a reason;
the caller still writes the row and the consumer degrades to the final count.
"""

from __future__ import annotations

from typing import List, Optional

import sqlglot
from sqlglot import exp

# Bump when the persisted plan shape changes so a consumer can detect a stale
# backfill and (the detection-framework) recompute.
WHY_PLAN_VERSION = 1


def _split_top_level_and(node) -> List:
    """Flatten a boolean tree's TOP-LEVEL AND chain into a predicate list.

    `a AND b AND c` -> [a, b, c]. An `OR` anywhere at the root returns a single
    element (the whole expression) — we never split an OR (see module docstring).
    """
    if isinstance(node, exp.And):
        return _split_top_level_and(node.this) + _split_top_level_and(node.expression)
    return [node]


def _single_from_table(tree, dialect: str):
    """The one base table in FROM. Returns (bare_name, from_sql) or (None, None).

    - `bare_name`: the real table name, for the column-health probe (which queries
      the actual table, un-aliased).
    - `from_sql`: the FROM expression WITH its alias preserved (e.g.
      `prioritized_vulnerabilities AS t`), so predicates that qualify columns by
      the alias (`t.severity`) still resolve in the rebuilt COUNT SQL.

    None when: not a SELECT, no FROM, the FROM expression is not a plain table
    (a subquery / derived table), or there is any JOIN (more than one relation).
    """
    select = tree.find(exp.Select)
    if select is None:
        return None, None
    frm = tree.find(exp.From)                       # sqlglot arg key varies; find is robust
    if frm is None:
        return None, None
    if list(select.find_all(exp.Join)):             # any JOIN → multi-relation
        return None, None
    if not isinstance(frm.this, exp.Table):         # subquery / derived table
        return None, None
    from_tables = list(frm.find_all(exp.Table))
    if len(from_tables) != 1:
        return None, None
    tbl = from_tables[0]
    return tbl.name, tbl.sql(dialect=dialect)       # name, "table AS alias" (alias if any)


def _predicate_columns(pred, relation: str, alias_to_table: dict) -> List[str]:
    """Columns of `relation` a predicate references (for the consumer's Tier-2
    column-health probe). Bare columns in a single-relation query belong to it."""
    cols: List[str] = []
    for c in pred.find_all(exp.Column):
        tbl = alias_to_table.get((c.table or "").lower()) if c.table else relation
        if tbl == relation and c.name and c.name not in cols:
            cols.append(c.name)
    return cols


def build_why_plan(sql: Optional[str], *, dialect: str = "postgres") -> dict:
    """Return the persistable why-plan for a widget query's SQL.

    Shape:
        {
          "version": 1,
          "decomposable": bool,
          "reason": str|None,            # why not decomposable (when False)
          "relation": str|None,          # the single FROM relation (when decomposable)
          "steps": [                     # ordered; step 0 is the base (no WHERE)
            { "label": str,              # human label ("base (no filter)" | predicate SQL)
              "predicate": str|None,     # this step's ADDED predicate (None for base)
              "columns": [str, ...],     # relation columns the predicate names (Tier 2)
              "count_sql": str },        # COUNT(*) with predicates[0..this] applied
            ...
          ]
        }

    Never raises. Non-decomposable inputs return a valid plan with steps=[] and a
    reason; the consumer then shows the single final count.
    """
    not_ok = lambda reason: {                       # noqa: E731 - tiny local helper
        "version": WHY_PLAN_VERSION, "decomposable": False,
        "reason": reason, "relation": None, "steps": [],
    }

    if not sql or not sql.strip():
        return not_ok("empty SQL")
    try:
        tree = sqlglot.parse_one(sql, read=dialect)
    except (sqlglot.errors.ParseError, sqlglot.errors.TokenError):
        return not_ok("SQL could not be parsed")

    if tree.find(exp.Select) is None:
        return not_ok("not a SELECT query")

    relation, from_sql = _single_from_table(tree, dialect)
    if relation is None:
        return not_ok("query reads more than one relation (join/subquery); "
                      "per-predicate funnel needs join analysis")

    alias_to_table = {(t.alias or t.name or "").lower(): (t.name or "").lower()
                      for t in tree.find_all(exp.Table)}
    base_sql = f"SELECT COUNT(*) AS _n FROM {from_sql}"      # alias preserved

    where = tree.find(exp.Where)
    # No WHERE → the number IS the full row count. One base step.
    if where is None:
        return {
            "version": WHY_PLAN_VERSION, "decomposable": True, "reason": None,
            "relation": relation,
            "steps": [{
                "label": "base (no filter)", "predicate": None, "columns": [],
                "count_sql": base_sql,
            }],
        }

    # OR at the WHERE root → do not split (removing an OR branch grows the set).
    if isinstance(where.this, exp.Or):
        pred_sql = where.this.sql(dialect=dialect)
        return {
            "version": WHY_PLAN_VERSION, "decomposable": True,
            "reason": "filter root is an OR; shown as a single step (an OR cannot be "
                      "split into a cumulative funnel)",
            "relation": relation,
            "steps": [
                {"label": "base (no filter)", "predicate": None, "columns": [],
                 "count_sql": base_sql},
                {"label": pred_sql, "predicate": pred_sql,
                 "columns": _predicate_columns(where.this, relation, alias_to_table),
                 "count_sql": f"{base_sql} WHERE {pred_sql}"},
            ],
        }

    preds = _split_top_level_and(where.this)
    steps = [{
        "label": "base (no filter)", "predicate": None, "columns": [],
        "count_sql": base_sql,
    }]
    acc: List[str] = []
    for p in preds:
        p_sql = p.sql(dialect=dialect)
        acc.append(p_sql)
        where_clause = " AND ".join(acc)
        steps.append({
            "label": p_sql,
            "predicate": p_sql,
            "columns": _predicate_columns(p, relation, alias_to_table),
            "count_sql": f"{base_sql} WHERE {where_clause}",
        })

    return {
        "version": WHY_PLAN_VERSION, "decomposable": True, "reason": None,
        "relation": relation, "steps": steps,
    }
