"""Grain verification for a SQL candidate — does it produce the rows it claims?

Spec: pantheon-datalake/docs/Torana_Domain_Primitives_Spec.md § 3.16.2.

A candidate declares a GRAIN ("one row per open finding on one asset"). This module
checks that claim against the planner and, optionally, against data:

    SELECT COUNT(*) AS rows, COUNT(DISTINCT (<key_cols>)) AS distinct_keys
    FROM (<candidate sql>) q

``rows > distinct_keys`` means a join fans out and the declared grain is WRONG — the
single most valuable check in the validation set, because a fan-out silently inflates
every count computed downstream.

Three verdicts, deliberately distinct
-------------------------------------
``PASS``    rows == distinct_keys, with rows > 0. Real evidence.
``FANOUT``  rows > distinct_keys. The declared grain is wrong.
``VACUOUS`` the relation is empty, so 0 == 0. The check RAN but proved nothing.
``SKIPPED`` no key could be resolved from the declared grain (see below).

``VACUOUS`` is never reported as ``PASS``. A check with no evidence behind it must not
read like one that had evidence — on an empty tenant every query "passes" trivially,
and that is exactly when a reviewer most needs to know the check was hollow.

Why key inference is conservative
---------------------------------
The grain is English prose; the key columns are SQL identifiers. Inferring one from the
other is guesswork, and an earlier iteration of this check guessed badly enough to
produce false FANOUTs — it scraped candidate words out of the grain sentence and
produced "keys" like ``assets`` and ``open``, asserting things no author ever claimed.

So a token counts as a key ONLY if it is a real output column of the query, resolved by
asking the planner for the result's column list. A bad guess degrades to ``SKIPPED``,
never to a false ``FANOUT``. The cost is honest: most candidates report ``SKIPPED``,
because prose rarely names its own columns. That is a limit of the evidence, not a pass.

Bugs this module exists to not repeat
-------------------------------------
Four bugs in the throwaway harness that produced this check each yielded a FALSE
VERDICT before being caught. They are fixed here by construction and covered by tests:

1. **Bind substitution corrupting casts.** Replacing ``:(\\w+)`` turns Postgres
   ``value::text`` into ``value:NULL`` and ``'1 day'::interval`` into junk. The pattern
   must be ``(?<!:):(?!:)`` — see :func:`neutralize_binds`.
2. **Depth-blind ORDER BY stripping.** Matching the last ``ORDER BY`` hits one inside a
   window function's ``OVER (...)``. Scanning must be paren-depth aware — see
   :func:`strip_trailing_order_by`.
3. **Verdict in the body, not the status code.** A backend can answer HTTP 200 while
   reporting failure in the payload. Callers must read the returned verdict, never
   infer success from "no exception".
4. **Empty schema reads as success.** A caller scoped to the wrong tenant sees no
   tables, every probe trivially succeeds, and the whole run is vacuously green. Hence
   ``VACUOUS`` being a first-class verdict rather than folded into ``PASS``.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Callable, Optional, Sequence

GRAIN_CHECK_VERSION = 1

PASS = "pass"
FANOUT = "fanout"
VACUOUS = "vacuous"
SKIPPED = "skipped"
ERROR = "error"

# Words that appear in almost every grain sentence and never name a column.
_STOPWORDS = frozenset({
    "one", "row", "rows", "per", "and", "or", "the", "a", "an", "with", "each",
    "its", "for", "from", "that", "this", "plus", "combination", "pair", "of",
    "in", "on", "at", "by", "to", "carrying", "listing", "labelled", "labeled",
    "where", "which", "who", "what", "when", "over", "into", "it", "is", "are",
    "has", "have", "been", "being", "was", "were", "be", "as", "so", "than",
})

# A bind parameter — :name — but NEVER a ``::type`` cast. Both lookarounds are
# load-bearing: (?<!:) rejects the second colon of ``::``, and (?!:) rejects the first.
_BIND_RE = re.compile(r"(?<!:):(?!:)([a-zA-Z_]\w*)")

_IDENT_RE = re.compile(r"[a-z_][a-z0-9_]*")


@dataclass
class GrainResult:
    """Outcome of one grain check. ``verdict`` is one of the module constants."""

    verdict: str
    detail: str
    rows: Optional[int] = None
    distinct_keys: Optional[int] = None
    key_columns: Sequence[str] = field(default_factory=tuple)
    version: int = GRAIN_CHECK_VERSION

    @property
    def is_evidence(self) -> bool:
        """True only when the check actually had data behind it.

        ``VACUOUS`` and ``SKIPPED`` are False — neither proves the grain is right.
        Use this rather than ``verdict != FANOUT`` when deciding whether a candidate
        has been verified.
        """
        return self.verdict in (PASS, FANOUT)


def neutralize_binds(sql: str, replacement: str = "NULL") -> str:
    """Replace ``:bind`` parameters so a parameterized query can be planned.

    Leaves Postgres ``::type`` casts intact. This is bug (1) in the module docstring:
    a naive ``:(\\w+)`` turns ``created_at::date`` into ``created_at:NULL`` and
    ``INTERVAL '1 day'`` survives only by luck.

    >>> neutralize_binds("SELECT a::text FROM t WHERE id = :wanted")
    'SELECT a::text FROM t WHERE id = NULL'
    >>> neutralize_binds("SELECT now()::date - :start_date")
    'SELECT now()::date - NULL'
    """
    return _BIND_RE.sub(replacement, sql)


def strip_trailing_order_by(sql: str) -> str:
    """Remove a statement-level trailing ``ORDER BY``, ignoring nested ones.

    Wrapping a query as a subselect makes its ORDER BY useless work, and on some
    planners illegal. But the LAST ``ORDER BY`` in the text is frequently inside a
    window function's ``OVER (...)`` — stripping that changes the query's MEANING.
    This is bug (2): scanning must be paren-depth aware and only cut at depth 0.

    >>> strip_trailing_order_by("SELECT rank() OVER (ORDER BY a) FROM t ORDER BY b")
    'SELECT rank() OVER (ORDER BY a) FROM t'
    >>> strip_trailing_order_by("SELECT rank() OVER (ORDER BY a) FROM t")
    'SELECT rank() OVER (ORDER BY a) FROM t'
    """
    depth = 0
    in_str = False
    cut = -1
    i = 0
    n = len(sql)
    while i < n:
        ch = sql[i]
        if in_str:
            # '' is an escaped quote inside a string literal, not a terminator.
            if ch == "'":
                if i + 1 < n and sql[i + 1] == "'":
                    i += 2
                    continue
                in_str = False
        elif ch == "'":
            in_str = True
        elif ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        elif depth == 0 and (ch in "oO") and sql[i:i + 8].upper() == "ORDER BY":
            before_ok = i == 0 or not (sql[i - 1].isalnum() or sql[i - 1] == "_")
            if before_ok:
                cut = i
        i += 1
    return sql[:cut].rstrip() if cut >= 0 else sql


def count_grain_key_hints(grain: str) -> int:
    """How many distinct key-ish tokens the grain prose names, resolvable or not.

    Used to detect a PARTIAL key match. A grain reading "one row per (team,
    environment, severity)" names three; if only two resolve to result columns,
    comparing against those two is comparing against the WRONG key and will report a
    fan-out that is not there.
    """
    seen: set[str] = set()
    for tok in _IDENT_RE.findall((grain or "").lower()):
        if tok in _STOPWORDS or tok in seen:
            continue
        seen.add(tok)
    return len(seen)


def infer_key_columns(grain: str, result_columns: Sequence[str]) -> list[str]:
    """Pick key columns named by the grain prose AND present in the result.

    Conservative by design: a token is only a key if it is genuinely an output column.
    Returns [] when nothing resolves, which the caller must treat as ``SKIPPED`` — not
    as a reason to invent a key.

    Note the real-world failure this guards: a query may alias ``severity`` as
    ``risk_level``, so the word in the grain does not appear in the result at all. That
    yields [] and a ``SKIPPED``, which is correct — better than comparing against a
    partial key and reporting a false FANOUT.

    >>> infer_key_columns("one row per team and severity", ["team", "severity", "n"])
    ['team', 'severity']
    >>> infer_key_columns("one row per asset", ["torana_entity_id", "n"])
    []
    """
    available = {c.lower(): c for c in result_columns}
    seen: set[str] = set()
    keys: list[str] = []
    for tok in _IDENT_RE.findall((grain or "").lower()):
        if tok in _STOPWORDS or tok in seen:
            continue
        if tok in available:
            seen.add(tok)
            keys.append(available[tok])
    return keys


def build_grain_query(sql: str, key_columns: Sequence[str]) -> str:
    """Build the rows-vs-distinct-keys probe for a candidate.

    The candidate is bind-neutralized and stripped of its statement-level ORDER BY
    before being wrapped, so the probe plans on parameterized queries too.
    """
    if not key_columns:
        raise ValueError("build_grain_query requires at least one key column")
    inner = strip_trailing_order_by(neutralize_binds(sql)).rstrip().rstrip(";")
    key_expr = ", ".join(key_columns)
    # A single column needs no ROW() wrapper; multiple columns compare as a tuple,
    # which is what makes a COMPOSITE grain check correct rather than partial.
    distinct = key_expr if len(key_columns) == 1 else f"({key_expr})"
    return (
        f"SELECT COUNT(*) AS rows, COUNT(DISTINCT {distinct}) AS distinct_keys "
        f"FROM ({inner}) _grain"
    )


def check_grain(
    sql: str,
    grain: str,
    *,
    result_columns: Optional[Sequence[str]] = None,
    run_query: Optional[Callable[[str], Any]] = None,
    key_columns: Optional[Sequence[str]] = None,
) -> GrainResult:
    """Verify a candidate produces the grain it declares (§ 3.16.2).

    Args:
        sql: the candidate query.
        grain: the declared grain, in prose.
        result_columns: the query's output columns. Required unless ``key_columns``
            is given explicitly — without it no key can be resolved and the result
            is ``SKIPPED``.
        run_query: callable taking the probe SQL and returning ``(rows, distinct_keys)``,
            a mapping with those keys, or a one-row sequence of them. Omit to build the
            probe without executing it (returns ``SKIPPED`` with the query in ``detail``).
        key_columns: bypass inference and state the key directly. Use this when the
            grain prose does not name its columns — it is the difference between a
            real ``PASS`` and a ``SKIPPED``.

    Returns:
        A :class:`GrainResult`. Callers deciding "is this candidate verified" should
        read ``is_evidence``, not merely check for absence of ``FANOUT``.
    """
    inferred = not key_columns
    keys = list(key_columns) if key_columns else infer_key_columns(grain, result_columns or ())
    if not keys:
        cols = ", ".join(result_columns or ()) or "(none supplied)"
        return GrainResult(
            SKIPPED,
            f"grain names no resolvable result column; result columns: {cols}",
        )

    probe = build_grain_query(sql, keys)
    if run_query is None:
        return GrainResult(SKIPPED, f"not executed; probe: {probe}", key_columns=keys)

    try:
        raw = run_query(probe)
    except Exception as exc:  # noqa: BLE001 - surface any backend error as a verdict
        return GrainResult(ERROR, f"probe failed: {exc}", key_columns=keys)

    parsed = _parse_counts(raw)
    if parsed is None:
        return GrainResult(ERROR, f"unreadable probe result: {raw!r}", key_columns=keys)
    rows, distinct = parsed

    if rows == 0:
        return GrainResult(
            VACUOUS, "0 rows — the check ran but has no evidence either way",
            rows=0, distinct_keys=0, key_columns=keys,
        )
    if rows > distinct:
        # A PARTIAL key cannot prove a fan-out. If the grain reads "one row per
        # (team, environment, severity)" and only `team` resolved, then rows >
        # distinct is the EXPECTED shape of a correct query — it says nothing about
        # the declared grain. Reporting FANOUT here is the false positive that
        # discredited the previous harness (EM-034: 4 rows / 1 distinct team, but
        # 4 / 4 on the full composite). Degrade to SKIPPED and say why.
        if inferred and _looks_partial(grain, keys):
            return GrainResult(
                SKIPPED,
                f"{rows} rows, {distinct} distinct on the PARTIAL key "
                f"({', '.join(keys)}) — the grain names more key parts than resolved "
                "to result columns, so this cannot prove a fan-out. Pass key_columns "
                "explicitly to check it.",
                rows=rows, distinct_keys=distinct, key_columns=keys,
            )
        return GrainResult(
            FANOUT,
            f"{rows} rows but {distinct} distinct on ({', '.join(keys)}) — "
            "a join fans out and the declared grain is wrong",
            rows=rows, distinct_keys=distinct, key_columns=keys,
        )
    return GrainResult(
        PASS, f"{rows} rows, {distinct} distinct on ({', '.join(keys)})",
        rows=rows, distinct_keys=distinct, key_columns=keys,
    )


def _looks_partial(grain: str, keys: Sequence[str]) -> bool:
    """True when the grain prose appears to name MORE key parts than we resolved.

    Deliberately crude and biased toward caution: a parenthesised, comma-separated
    grain head ("one row per (a, b, c)") is the corpus's convention for a composite
    key, so if it lists more parts than we matched, the key is partial.
    """
    g = (grain or "").lower()
    head = re.search(r"per\s*\(([^)]*)\)", g)
    if head:
        declared = [p for p in (x.strip() for x in head.group(1).split(",")) if p]
        return len(declared) > len(keys)

    # No parenthesised head. The grain names its key in the clause BEFORE the first
    # comma or "with" — everything after that describes the row's PAYLOAD, not its
    # identity. A token matched only in the payload is a verdict/measure column, not
    # a key, and comparing against it produces a guaranteed false FANOUT.
    #
    # Real case: EM-025 declares "one row per asset, with a single ownership_status
    # verdict (...)". `ownership_status` is a five-valued verdict; keying on it gave
    # 1259 rows / 2 distinct. The true key is torana_entity_id — 1259 / 1259.
    head_clause = re.split(r"[,;]|\bwith\b|\bcarrying\b|\blisting\b", g, maxsplit=1)[0]
    if any(k.lower() not in head_clause for k in keys):
        return True

    # Otherwise: the grain reads as a conjunction but we resolved fewer than two parts.
    return bool(re.search(r"\bper\b[^.]*\band\b", g)) and len(keys) < 2


def _parse_counts(raw: Any) -> Optional[tuple[int, int]]:
    """Read (rows, distinct_keys) out of whatever shape the runner returned."""
    if raw is None:
        return None
    # A one-row result set: unwrap to the row.
    if isinstance(raw, (list, tuple)) and len(raw) == 1 and isinstance(raw[0], (dict, list, tuple)):
        raw = raw[0]
    if isinstance(raw, dict):
        lowered = {str(k).lower(): v for k, v in raw.items()}
        if "rows" in lowered and "distinct_keys" in lowered:
            try:
                return int(lowered["rows"]), int(lowered["distinct_keys"])
            except (TypeError, ValueError):
                return None
        return None
    if isinstance(raw, (list, tuple)) and len(raw) >= 2:
        try:
            return int(raw[0]), int(raw[1])
        except (TypeError, ValueError):
            return None
    return None
