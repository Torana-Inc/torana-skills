"""Extract source-table and column dependencies from a SQL statement.

Implementation uses ``sqlglot`` so the parser handles real SQL constructs
(CTEs, subqueries, schema-qualified names, function-internal ``EXTRACT(...
FROM ...)``, comments, string literals) rather than the brittle regex we'd
otherwise have to maintain. The parser is bounded by the dialect; we pass
``postgres`` because that's what the datalake speaks.

Two public entry points:

- ``extract_source_tables`` — the flat set of base tables a query reads.
- ``extract_column_lineage`` — per-output-column lineage: which input table(s)
  and column(s) each SELECT column derives from, whether it's an aggregate, and
  the query's ROW-SOURCE tables (driving side of the joins).

WHY COLUMN LINEAGE IS COMPUTED HERE (AT AUTHOR TIME), NOT IN A CONSUMER
----------------------------------------------------------------------
A transformer's column lineage is a pure function of its SQL, known the moment
the transformer is saved. Computing it once at author time and persisting the
result on the transformer row turns provenance resolution into a graph READ:
no consumer re-parses SQL, the lineage can't drift from the SQL (recomputed on
every save), and it reflects the exact SQL version that produced the table.
pantheon-data-transformers calls this in its create/update path, exactly as it
already calls ``extract_source_tables`` and ``extract_group_by_columns``.

Both functions return degraded-but-safe results on unparseable / unusual SQL
(empty list, or per-column ``traceable=False``) rather than raising — callers
still write the row, and a follow-up backfill can refine later.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Set

import sqlglot
from sqlglot import exp


def extract_source_tables(sql: Optional[str], *, dialect: str = "postgres") -> List[str]:
    """Return the deduped, sorted, lower-cased list of base tables a SQL
    statement reads. See module docstring for the full contract.

    >>> extract_source_tables("SELECT * FROM vulnerabilities v JOIN repositories r ON ...")
    ['repositories', 'vulnerabilities']

    >>> extract_source_tables("WITH cte AS (SELECT * FROM real_table) SELECT * FROM cte")
    ['real_table']

    >>> extract_source_tables("SELECT EXTRACT(EPOCH FROM x) FROM events")
    ['events']

    >>> extract_source_tables(None)
    []
    """
    if not sql or not sql.strip():
        return []
    try:
        tree = sqlglot.parse_one(sql, read=dialect)
    except (sqlglot.errors.ParseError, sqlglot.errors.TokenError):
        return []

    cte_names = {
        (c.alias_or_name or "").lower()
        for c in tree.find_all(exp.CTE)
    }

    tables: set[str] = set()
    for t in tree.find_all(exp.Table):
        name = (t.name or "").strip().lower()
        if not name:
            continue
        if name in cte_names:
            continue
        tables.add(name)

    return sorted(tables)


# ---------------------------------------------------------------------------
# Column lineage
# ---------------------------------------------------------------------------

# Schema version of the persisted artifact. Bump when the shape changes so a
# consumer can detect a stale backfill and recompute.
COLUMN_LINEAGE_VERSION = 1


def _cte_names(tree) -> set:
    """Names bound by WITH clauses, lower-cased.

    ⚠️ A CTE REFERENCE PARSES AS `exp.Table`. Without this, `_alias_to_table`
    registers the CTE name as if it were a real base table, and an output alias
    defined INSIDE the CTE is then reported as a column OF that table — a source
    that does not exist. For `WITH sub AS (SELECT severity AS sev FROM
    vulnerabilities) SELECT sub.sev AS label FROM sub` the artifact claimed
    `via={"sub": ["sev"]}, traceable=True`: a fabricated table AND a fabricated
    column, asserted with full confidence.

    That is worse than an unknown. Provenance consumers scope what a query reads
    to `via`, so a fabricated entry silently scopes to the wrong thing with no
    error to notice.
    """
    return {
        (cte.alias_or_name or "").lower()
        for cte in tree.find_all(exp.CTE)
        if (cte.alias_or_name or "")
    }


def _alias_to_table(tree, cte_names: Optional[set] = None) -> Dict[str, str]:
    """Map every table alias (and bare table name, lower-cased) to its real name.

    ⚠️ CTE names are EXCLUDED — see `_cte_names`. A CTE is not a base table, and
    treating it as one fabricates lineage.
    """
    ctes = cte_names if cte_names is not None else _cte_names(tree)
    out: Dict[str, str] = {}
    for t in tree.find_all(exp.Table):
        real = (t.name or "").lower()
        if not real or real in ctes:
            continue
        out[(t.alias or t.name or "").lower()] = real
        out[real] = real
    return out


def _row_source_tables(tree, dialect: str) -> Optional[List[str]]:
    """Which input tables determine the query's row COUNT — the driving side.

    An aggregate over a LEFT/RIGHT/FULL-joined chain counts the rows of the
    driving side only; an outer join for enrichment cannot add or drop driving
    rows. Row-contributing = the FROM table + any INNER/CROSS join. Returns None
    when it can't tell (subquery FROM, comma join) — the caller then keeps all
    inputs, never narrows an aggregate on doubt.
    """
    frm = tree.find(exp.From)
    if frm is None:
        return None
    from_tables = list(frm.find_all(exp.Table))
    if len(from_tables) != 1:
        return None
    contributing: List[str] = [(from_tables[0].name or "").lower()]
    for j in tree.find_all(exp.Join):
        side = (j.args.get("side") or "").upper()
        if side in ("LEFT", "RIGHT", "FULL"):
            continue  # outer join → enrichment, not row-affecting
        for t in j.find_all(exp.Table):
            contributing.append((t.name or "").lower())
    seen: Set[str] = set()
    out: List[str] = []
    for t in contributing:
        if t and t not in seen:
            seen.add(t)
            out.append(t)
    return out


def columns_read_from(sql: Optional[str], relation: str, *,
                      dialect: str = "postgres") -> Optional[List[str]]:
    """Which columns of `relation` does `sql` reference — ANYWHERE (SELECT, WHERE,
    GROUP BY, ORDER BY)? Used on a WIDGET's query to seed column-scoped provenance:
    a widget filtering on `asset_environment` genuinely depends on that column even
    if it never SELECTs it.

    Returns a sorted list, or None to mean "cannot restrict — treat as all columns":
    a parse failure, a `SELECT *`, or a column ref that can't be tied to `relation`.
    None is the safe answer (keep everything in scope), never the empty list.

    Unlike extract_column_lineage this is a transient, per-request read (the widget
    query is not a stored entity), but it lives here so there is ONE sqlglot
    implementation and viz never imports sqlglot directly.
    """
    if not sql or not sql.strip():
        return None
    try:
        tree = sqlglot.parse_one(sql, read=dialect)
    except (sqlglot.errors.ParseError, sqlglot.errors.TokenError):
        return None
    # A genuine `SELECT *` projection means we can't restrict — but `COUNT(*)` also
    # contains a Star, and that is NOT a projection star. Only bail when a top-level
    # SELECT expression IS itself a bare Star (or a table-qualified `t.*`).
    select = tree.find(exp.Select)
    if select is not None:
        for e in select.expressions:
            if isinstance(e, exp.Star) or (isinstance(e, exp.Column) and isinstance(e.this, exp.Star)):
                return None  # SELECT * / SELECT t.* — cannot restrict
    tables = list(tree.find_all(exp.Table))
    alias2table = {(t.alias or t.name or "").lower(): (t.name or "").lower() for t in tables}
    single = (tables[0].name or "").lower() if len(tables) == 1 else None
    target = (relation or "").lower()
    cols: Set[str] = set()
    for c in tree.find_all(exp.Column):
        tbl = alias2table.get((c.table or "").lower()) if c.table else single
        if tbl == target and c.name:
            cols.add(c.name)
    return sorted(cols)


#: ⛔ THE LOAD-BEARING RULE. A column reference is load-bearing when removing it
#: would change WHICH ROWS are returned or how they are CLASSIFIED. Walk the
#: reference's ancestors outward; it is load-bearing if any ancestor is a member.
#:
#: ⛔ POSITIVE MEMBERSHIP TEST, deliberately — never "everything except ORDER BY".
#: An exclusion list breaks silently the day sqlglot grows a node type; a
#: membership test cannot. A bare `ORDER BY t.x` reaches `Select` without touching
#: any member and returns False naturally, so no ORDER BY exclusion is needed and
#: adding one would be a bug.
#:
#: ⚠️ `exp.Func` subsumes several members in practice (`exp.If` — what a CASE arm
#: parses to — is a Func, so it matches before `exp.Case` is reached). The
#: redundancy is KEPT because the SET is the specification: dropping `Case`
#: because `Func` happens to catch today's parse shape would make the rule depend
#: on sqlglot's class hierarchy staying put.
#:
#: ⚠️ This mirrors `LOAD_BEARING_ANCESTORS` in the `torana-text-to-sql` gate
#: script. It lives HERE because a packaged Claude skill cannot be imported by a
#: service; the skill and the bundle validator must nonetheless agree, and two
#: copies of a rule is exactly the drift S18 exists to remove.
LOAD_BEARING_ANCESTORS = (
    exp.Where, exp.Join, exp.Having, exp.Qualify,   # filters
    exp.Group, exp.Window,                          # grain (GROUP BY / PARTITION BY)
    exp.Case, exp.Filter, exp.Func,                 # computes a value acted upon
)


def _is_load_bearing_node(node) -> bool:
    """Is THIS reference load-bearing? Computed from the parse tree.

    ⚠️ SUBQUERIES: the walk does NOT stop at the enclosing SELECT, it continues to
    the root. A column inside a subquery in a WHERE clause IS load-bearing for the
    outer query; stopping at the boundary would report it as a harmless projection.
    """
    cur = node.parent
    while cur is not None:
        if isinstance(cur, LOAD_BEARING_ANCESTORS):
            return True
        cur = cur.parent
    return False


def load_bearing_columns_read_from(
    sql: Optional[str], relation: str, *, dialect: str = "postgres"
) -> Optional[Dict[str, bool]]:
    """`{column: is_load_bearing}` for every reference to `relation` in `sql`.

    The companion to `columns_read_from`, which answers only WHICH columns. This
    adds the axis a caller needs to rank harm: a caller-only column in a bare
    projection renders a blank cell, while the SAME column in a WHERE or an
    anti-join changes which rows exist at all.

    ⚠️ OR-REDUCED PER COLUMN, not per reference. A column very often appears BOTH
    as a bare projection and inside a CASE; classifying per reference yields
    [False, True] for one column and invites a reader to act on the False — which
    is the exact error this axis exists to prevent. The answer is per-QUERY.

    Returns None for "cannot restrict" on the same terms as `columns_read_from`
    (parse failure / `SELECT *` / unattributable ref), never an empty dict — an
    empty dict would read as "no columns referenced", which is a different claim.
    """
    if not sql or not sql.strip():
        return None
    try:
        tree = sqlglot.parse_one(sql, read=dialect)
    except (sqlglot.errors.ParseError, sqlglot.errors.TokenError):
        return None
    select = tree.find(exp.Select)
    if select is not None:
        for e in select.expressions:
            if isinstance(e, exp.Star) or (isinstance(e, exp.Column) and isinstance(e.this, exp.Star)):
                return None  # SELECT * / SELECT t.* — cannot restrict
    tables = list(tree.find_all(exp.Table))
    alias2table = {(t.alias or t.name or "").lower(): (t.name or "").lower() for t in tables}
    single = (tables[0].name or "").lower() if len(tables) == 1 else None
    target = (relation or "").lower()
    if target not in {(t.name or "").lower() for t in tables}:
        return {}      # `relation` genuinely absent — a real, empty answer

    out: Dict[str, bool] = {}
    for c in tree.find_all(exp.Column):
        if not c.name:
            continue
        if c.table:
            tbl = alias2table.get(c.table.lower())
        elif single:
            tbl = single
        else:
            # ⛔ UNQUALIFIED COLUMN IN A MULTI-TABLE STATEMENT — unattributable.
            #
            # ⚠️ Returning here (rather than skipping the column) is the whole point. The
            # tempting alternative — ignore what we cannot attribute and answer with the
            # rest — yields `{}` for a query that genuinely reads the target table, and `{}`
            # reads as "no caller-only columns found": a CLEAN BILL produced by not looking.
            # Measured on exactly this shape:
            #     SELECT 1 FROM assets WHERE torana_entity_id IN (
            #         SELECT torana_entity_id FROM vulnerabilities WHERE is_patch_available)
            # `is_patch_available` IS caller-only and IS load-bearing, and the skip-version
            # reported nothing. None means "cannot restrict" and every caller already
            # handles it; silence does not.
            return None
        if tbl == target:
            name = c.name.lower()
            out[name] = out.get(name, False) or _is_load_bearing_node(c)
    return out


def extract_column_lineage(sql: Optional[str], *, dialect: str = "postgres") -> dict:
    """Per-output-column lineage for one transformer's SQL.

    Returns a persistable artifact:

        {
          "version": 1,
          "parsed": bool,                 # False → SQL unparseable / SELECT *; treat
                                          #         every consumer column as untraceable
          "row_source_tables": [t, ...],  # driving tables (aggregate row source); [] if unknown
          "columns": {
             "<output_col>": {
                "tables":     [t, ...],   # input tables this output derives from
                "via":        {t: [col, ...]},  # per-table source columns (plain projections)
                "is_aggregate": bool,
                "traceable":  bool,       # False for aggregate/expression/SELECT *
             }, ...
          }
        }

    The artifact is everything a consumer needs to scope provenance to the
    columns a downstream query reads WITHOUT re-parsing: `via` maps output→input
    columns for plain projections, `row_source_tables` handles aggregates, and
    `traceable=False` marks the honest boundary where source columns can't be named.
    """
    empty = {"version": COLUMN_LINEAGE_VERSION, "parsed": False,
             "row_source_tables": [], "columns": {}}
    if not sql or not sql.strip():
        return empty
    try:
        tree = sqlglot.parse_one(sql, read=dialect)
    except (sqlglot.errors.ParseError, sqlglot.errors.TokenError):
        return empty
    select = tree.find(exp.Select)
    if select is None:
        return empty

    cte_names = _cte_names(tree)
    alias2table = _alias_to_table(tree, cte_names)
    row_src = _row_source_tables(tree, dialect) or []
    all_inputs = sorted(set(alias2table.values()))

    columns: Dict[str, dict] = {}
    parsed = True
    for expr in select.expressions:
        name = expr.alias_or_name
        if isinstance(expr, exp.Star) or not name:
            # SELECT * — we cannot attribute per column. Mark the whole artifact
            # unparsed-for-scoping; consumers keep all inputs in scope.
            parsed = False
            continue

        is_agg = bool(list(expr.find_all(exp.AggFunc)))
        via: Dict[str, List[str]] = {}
        for c in expr.find_all(exp.Column):
            qual = (c.table or "").lower()
            if qual and qual in cte_names:
                # ⚠️ Qualified by a CTE. The name after the dot is an alias bound
                # INSIDE the CTE, not a column of any base table — naming a source
                # here would fabricate one. Fall through with tbl=None so the
                # column ends up `traceable=False`: an honest unknown.
                tbl = None
            elif qual:
                tbl = alias2table.get(qual)
            else:
                # Unqualified. Attribute to the single input only when there IS
                # exactly one — and never when a CTE is in play, since the real
                # source then sits behind it.
                tbl = all_inputs[0] if (len(all_inputs) == 1 and not cte_names) else None
            if tbl:
                via.setdefault(tbl, [])
                if c.name and c.name not in via[tbl]:
                    via[tbl].append(c.name)

        if is_agg:
            # Row-source tables drive the aggregate; union any columns it names.
            tables = sorted(set(via.keys()) | set(row_src)) or all_inputs
            columns[name] = {
                "tables": tables,
                "via": {t: sorted(cols) for t, cols in via.items()},
                "is_aggregate": True,
                "traceable": False,
            }
        elif via:
            columns[name] = {
                "tables": sorted(via.keys()),
                "via": {t: sorted(cols) for t, cols in via.items()},
                "is_aggregate": False,
                "traceable": True,
            }
        else:
            # Literal / expression with no resolvable column ref.
            columns[name] = {
                "tables": all_inputs,
                "via": {},
                "is_aggregate": False,
                "traceable": False,
            }

    return {
        "version": COLUMN_LINEAGE_VERSION,
        "parsed": parsed,
        "row_source_tables": row_src,
        "columns": columns,
    }
