"""Extract source-table and column dependencies from a SQL statement.

Implementation uses ``sqlglot`` so the parser handles real SQL constructs
(CTEs, subqueries, schema-qualified names, function-internal ``EXTRACT(...
FROM ...)``, comments, string literals) rather than the brittle regex we'd
otherwise have to maintain. The parser is bounded by the dialect; we pass
``postgres`` because that's what the datalake speaks.

Two public entry points:

- ``extract_source_tables`` — the flat set of base tables a query reads.
- ``extract_column_lineage`` — per-output-column lineage: which input table(s)
  and column(s) each SELECT column derives from, whether it's an aggregate, and
  the query's ROW-SOURCE tables (driving side of the joins).

WHY COLUMN LINEAGE IS COMPUTED HERE (AT AUTHOR TIME), NOT IN A CONSUMER
----------------------------------------------------------------------
A transformer's column lineage is a pure function of its SQL, known the moment
the transformer is saved. Computing it once at author time and persisting the
result on the transformer row turns provenance resolution into a graph READ:
no consumer re-parses SQL, the lineage can't drift from the SQL (recomputed on
every save), and it reflects the exact SQL version that produced the table.
pantheon-data-transformers calls this in its create/update path, exactly as it
already calls ``extract_source_tables`` and ``extract_group_by_columns``.

Both functions return degraded-but-safe results on unparseable / unusual SQL
(empty list, or per-column ``traceable=False``) rather than raising — callers
still write the row, and a follow-up backfill can refine later.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Set, Tuple

import sqlglot
from sqlglot import exp


def extract_source_tables(sql: Optional[str], *, dialect: str = "postgres") -> List[str]:
    """Return the deduped, sorted, lower-cased list of base tables a SQL
    statement reads. See module docstring for the full contract.

    >>> extract_source_tables("SELECT * FROM vulnerabilities v JOIN repositories r ON ...")
    ['repositories', 'vulnerabilities']

    >>> extract_source_tables("WITH cte AS (SELECT * FROM real_table) SELECT * FROM cte")
    ['real_table']

    >>> extract_source_tables("SELECT EXTRACT(EPOCH FROM x) FROM events")
    ['events']

    >>> extract_source_tables(None)
    []
    """
    if not sql or not sql.strip():
        return []
    try:
        tree = sqlglot.parse_one(sql, read=dialect)
    except (sqlglot.errors.ParseError, sqlglot.errors.TokenError):
        return []

    cte_names = {
        (c.alias_or_name or "").lower()
        for c in tree.find_all(exp.CTE)
    }

    tables: set[str] = set()
    for t in tree.find_all(exp.Table):
        name = (t.name or "").strip().lower()
        if not name:
            continue
        if name in cte_names:
            continue
        tables.add(name)

    return sorted(tables)


# ---------------------------------------------------------------------------
# Column lineage
# ---------------------------------------------------------------------------

# Schema version of the persisted artifact. Bump when the shape changes so a
# consumer can detect a stale backfill and recompute.
# v2 adds `tables_exact` per column and resolves CTE-qualified columns to the base
# tables behind the CTE instead of falling back to every input in the query.
# v3 resolves a CTE's USE-SITE ALIAS (`JOIN running_image r` → `r.k`), a CTE reading
# from a derived subquery, and an unambiguous single-driver `COUNT(*)`.
#
# ⛔ BUMP THIS WHENEVER THE ANALYZER GETS SMARTER, not only when the SHAPE changes.
# The backfill skips any row already at the current version, so a parser improvement
# shipped without a bump leaves every stored artifact on the old, worse answer and
# reports "Skipped (already current)" — which reads as success.
# v4 names the REAL input COLUMNS behind CTEs, resolved per CTE scope (`_cte_output_columns`),
# so an aggregate or pass-through over a CTE chain carries `via` instead of `{}`.
COLUMN_LINEAGE_VERSION = 5


def _cte_names(tree) -> set:
    """Names bound by WITH clauses, lower-cased.

    ⚠️ A CTE REFERENCE PARSES AS `exp.Table`. Without this, `_alias_to_table`
    registers the CTE name as if it were a real base table, and an output alias
    defined INSIDE the CTE is then reported as a column OF that table — a source
    that does not exist. For `WITH sub AS (SELECT severity AS sev FROM
    vulnerabilities) SELECT sub.sev AS label FROM sub` the artifact claimed
    `via={"sub": ["sev"]}, traceable=True`: a fabricated table AND a fabricated
    column, asserted with full confidence.

    That is worse than an unknown. Provenance consumers scope what a query reads
    to `via`, so a fabricated entry silently scopes to the wrong thing with no
    error to notice.
    """
    return {
        (cte.alias_or_name or "").lower()
        for cte in tree.find_all(exp.CTE)
        if (cte.alias_or_name or "")
    }


def _cte_output_sources(tree, dialect: str = "postgres") -> Dict[str, Dict[str, List[str]]]:
    """Resolve each CTE's OUTPUT columns to the base tables behind them.

    Returns `{cte_name: {output_alias: [base_table, ...]}}`, lower-cased.

    ⭐ WHY THIS EXISTS. The caller refuses to guess at a CTE boundary — correctly,
    since naming a CTE as a source fabricates a table that does not exist. But it
    then fell back to "every input table in the query", and MEASURED across all 11
    transformers with uncertain columns, that fallback was the transformer's entire
    declared source list VERBATIM in every single case. So `traceable=False` was
    honest but carried no information: `classie_em_assets.cve_count` reported
    `[assets, vulnerabilities]` when the CTE behind it reads ONLY `vulnerabilities`.

    The information was always recoverable — `WITH f AS (SELECT … FROM
    vulnerabilities)` says exactly where `f.cve_count` comes from. This walks one
    CTE's SELECT to find it, so a column qualified by a CTE resolves to real tables
    instead of the whole query's inputs.

    ⚠️ Resolution is TRANSITIVE and cycle-guarded: a CTE selecting from another CTE
    resolves through it. A self- or mutually-recursive WITH (legal SQL) would
    otherwise loop forever, so `_resolve` tracks the chain it is inside.

    ⛔ Still never invents a source. A CTE output the walk cannot resolve — a
    literal, an expression over another unresolved CTE — is simply ABSENT from the
    map, and the caller keeps its existing honest-unknown behaviour for it.
    """
    ctes: Dict[str, exp.Expression] = {}
    for cte in tree.find_all(exp.CTE):
        nm = (cte.alias_or_name or "").lower()
        if nm:
            ctes[nm] = cte

    out: Dict[str, Dict[str, List[str]]] = {}

    def _resolve(name: str, seen: frozenset) -> Dict[str, List[str]]:
        if name in out:
            return out[name]
        if name in seen:          # recursive CTE — stop rather than loop
            return {}
        cte = ctes.get(name)
        if cte is None:
            return {}
        sel = cte.this.find(exp.Select) if cte.this is not None else None
        if sel is None:
            return {}

        inner_ctes = set(ctes.keys())
        # ⚠️ A UNION CTE has SEVERAL branches and `find(exp.Select)` returns only the
        # FIRST. `population AS (SELECT … FROM entity_edges UNION SELECT … FROM
        # workload_image)` would resolve to `entity_edges` alone, losing the other
        # branch's tables — a narrower answer than the SQL supports, asserted as exact.
        # Every branch contributes rows, so every branch's tables are sources.
        branches = list(cte.this.find_all(exp.Select)) if cte.this is not None else [sel]
        # Base tables this CTE reads DIRECTLY (CTE refs excluded), across ALL branches.
        local: Dict[str, str] = {}
        for t in (t for b in branches for t in b.find_all(exp.Table)):
            real = (t.name or "").lower()
            if not real or real in inner_ctes:
                continue
            local[(t.alias or t.name or "").lower()] = real
            local[real] = real
        # ⚠️ A CTE may read from a DERIVED SUBQUERY rather than a table
        # (`FROM (SELECT … FROM live_deploy UNION …) s`). `find_all(exp.Table)` then
        # finds only the CTEs inside it, so `local` is empty and every output falls
        # through unresolved — MEASURED on `explore_findings.service_count`, an
        # aggregate over exactly that shape. Resolve the inner CTE refs so the
        # subquery contributes its real base tables.
        for _t in (t for b in branches for t in b.find_all(exp.Table)):
            _n = (_t.name or "").lower()
            if _n in inner_ctes:
                for _bt in _resolve(_n, seen | {name}).values():
                    for _x in _bt:
                        local[_x] = _x
        local_tables = sorted(set(local.values()))

        mapping: Dict[str, List[str]] = {}
        # Walk every branch, unioning per-alias sources (branch 1's `image_key` and
        # branch 2's `image_key` are the same output column from different tables).
        for e in (e for b in branches for e in b.expressions):
            alias = (e.alias_or_name or "").lower()
            if not alias or isinstance(e, exp.Star):
                continue
            tables: set = set()
            for c in e.find_all(exp.Column):
                qual = (c.table or "").lower()
                if qual and qual in inner_ctes:
                    # Nested CTE — resolve through it for THIS column name.
                    nested = _resolve(qual, seen | {name})
                    tables |= set(nested.get((c.name or "").lower(), []))
                elif qual:
                    if qual in local:
                        tables.add(local[qual])
                elif len(local_tables) == 1 and not any(
                    (t.name or "").lower() in inner_ctes
                    for b in branches for t in b.find_all(exp.Table)
                ):
                    # Unqualified inside a single-base-table CTE: unambiguous.
                    tables.add(local_tables[0])
            if not tables:
                # A branch selecting from a NESTED CTE (`SELECT w.image_key FROM
                # workload_image w`) has its column qualified by that CTE's ALIAS, not
                # its name, so the `qual in inner_ctes` test above misses it. Resolve
                # the alias back to the CTE it stands for.
                for b in branches:
                    for t in b.find_all(exp.Table):
                        tn = (t.name or "").lower()
                        if tn in inner_ctes and (t.alias or tn).lower() in {
                            (c.table or "").lower() for c in e.find_all(exp.Column)
                        }:
                            nested = _resolve(tn, seen | {name})
                            for c in e.find_all(exp.Column):
                                tables |= set(nested.get((c.name or "").lower(), []))
            if not tables and len(local_tables) == 1:
                # ⭐ COUNT(*) AND FRIENDS. An expression with NO column reference —
                # `COUNT(*) AS finding_count` is the real case — leaves `tables` empty,
                # so the walk above finds nothing to attribute. But a CTE reading
                # exactly ONE base table can only be counting THAT table's rows, so the
                # source is unambiguous even though no column is named.
                #
                # ⛔ Guarded on a single base table. With two, `COUNT(*)` counts the
                # JOINED rows and naming either one alone would be a guess — those fall
                # through unresolved, which is the honest answer.
                tables.add(local_tables[0])
            if tables:
                mapping[alias] = sorted(set(mapping.get(alias, [])) | tables)
        out[name] = mapping
        return mapping

    for nm in ctes:
        _resolve(nm, frozenset())
    return out


def _branches(body) -> List[exp.Select]:
    """The SELECTs that produce a CTE's (or a query's) rows: the body itself, or every
    branch of a UNION/INTERSECT/EXCEPT. A SELECT nested in a subquery is NOT a branch."""
    if body is None:
        return []
    if isinstance(body, exp.Select):
        return [body]
    if isinstance(body, exp.SetOperation) if hasattr(exp, "SetOperation") else isinstance(body, exp.Union):
        return _branches(body.this) + _branches(body.expression)
    if isinstance(body, exp.Subquery):
        return _branches(body.this)
    return []


def _own_sources(select: exp.Select, cte_names: set) -> Dict[str, Tuple[str, object]]:
    """alias -> ("table", base) | ("cte", name) | ("derived", body), for THIS select's own
    FROM and JOINs only. ⛔ Per scope: an alias reused in another CTE (`FROM assigned a`
    here, `FROM assets a` there) is invisible to this one, which is the defect a query-wide
    map had. A derived table (`FROM (SELECT …) p`) resolves like an anonymous CTE."""
    out: Dict[str, Tuple[str, object]] = {}
    nodes = []
    frm = select.args.get("from") or select.args.get("from_")
    if frm is not None and frm.this is not None:
        nodes.append(frm.this)
    for j in select.args.get("joins") or []:
        if j.this is not None:
            nodes.append(j.this)
    for node in nodes:
        if isinstance(node, exp.Table):
            real = (node.name or "").lower()
            if not real:
                continue
            ref = ("cte", real) if real in cte_names else ("table", real)
            out[(node.alias or node.name or "").lower()] = ref
            out.setdefault(real, ref)
        elif isinstance(node, exp.Subquery) and node.alias:
            out[node.alias.lower()] = ("derived", node.this)
    return out


class _ScopeResolver:
    """Resolve a column name read from a source (a base table, a CTE, a derived table) to
    the REAL `table -> {columns}` behind it, per scope and transitively.

    ⭐ WHY (Classie, 2026-09-30): `posture_findings.zero_day` is `BOOL_OR(r.is_zero_day)`
    four CTEs and two derived tables deep, carried along by `t.*`, and lineage recorded
    `via: {}` for it. With no input column, the supply trace could not run "worst input
    wins" and the rule read LINEAGE_AMBIGUOUS.

    ⛔ Never invents a column: a column is named only when it is read off a real base table
    in its own scope, carried by name out of an explicit projection, or carried by a star
    with EXACTLY ONE source (with several, which source has it is unknown without a
    schema, so it resolves to nothing).
    """

    def __init__(self, tree):
        self.ctes = {(c.alias_or_name or "").lower(): c.this for c in tree.find_all(exp.CTE)
                     if (c.alias_or_name or "")}
        self.names = set(self.ctes)
        self._outputs: Dict[int, tuple] = {}

    def outputs(self, body, seen: frozenset):
        """(explicit {alias: {table: cols}}, stars [source]) for one scope's body."""
        key = id(body)
        if key in self._outputs:
            return self._outputs[key]
        if key in seen:
            return {}, []
        explicit: Dict[str, Dict[str, set]] = {}
        stars: list = []
        for br in _branches(body):
            local = _own_sources(br, self.names)
            refs = list(dict.fromkeys(local.values()))
            for e in br.expressions:
                if isinstance(e, exp.Star):
                    stars.extend(refs)
                    continue
                if isinstance(e, exp.Column) and isinstance(e.this, exp.Star):
                    src = local.get((e.table or "").lower())
                    if src is not None:
                        stars.append(src)
                    continue
                alias = (e.alias_or_name or "").lower()
                if not alias:
                    continue
                cols = explicit.setdefault(alias, {})
                for t, cs in self.expression_inputs(e, local, refs, seen | {key}).items():
                    cols.setdefault(t, set()).update(cs)
        self._outputs[key] = (explicit, stars)
        return explicit, stars

    def expression_inputs(self, expr, local, refs, seen) -> Dict[str, set]:
        out: Dict[str, set] = {}
        for c in expr.find_all(exp.Column):
            if isinstance(c.this, exp.Star):
                continue
            q, n = (c.table or "").lower(), (c.name or "").lower()
            src = local.get(q) if q else (refs[0] if len(refs) == 1 else None)
            if src is None or not n:
                continue
            for t, cs in self.column_of(src, n, seen).items():
                out.setdefault(t, set()).update(cs)
        return out

    def column_of(self, src, name: str, seen: frozenset) -> Dict[str, set]:
        kind, ref = src
        if kind == "table":
            return {ref: {name}}
        body = self.ctes.get(ref) if kind == "cte" else ref
        if body is None or id(body) in seen:
            return {}
        explicit, stars = self.outputs(body, seen)
        if name in explicit:
            return explicit[name]
        uniq = list(dict.fromkeys(stars))
        if len(uniq) == 1:
            return self.column_of(uniq[0], name, seen | {id(body)})
        # Several star sources (`SELECT f.*, pol.*`): pick the ONE that definitely produces
        # the name. A base table's columns are unknown here, so any table among them means
        # the answer is unknown, and nothing is guessed.
        if any(k == "table" for k, _ in uniq):
            return {}
        having = [src for src in uniq if self.produces(src, name, seen | {id(body)})]
        if len(having) == 1:
            return self.column_of(having[0], name, seen | {id(body)})
        return {}

    def names_of(self, src, seen: frozenset) -> Optional[List[str]]:
        """Every output name a CTE/derived source produces, in order, or None when a star
        in it reaches a base table (whose columns are unknown without a schema)."""
        kind, ref = src
        if kind == "table":
            return None
        body = self.ctes.get(ref) if kind == "cte" else ref
        if body is None or id(body) in seen:
            return None
        explicit, stars = self.outputs(body, seen)
        names = list(explicit)
        for x in dict.fromkeys(stars):
            inner = self.names_of(x, seen | {id(body)})
            if inner is None:
                return None
            names.extend(n for n in inner if n not in names)
        return names

    def produces(self, src, name: str, seen: frozenset) -> bool:
        """Does this CTE/derived source definitely output `name`? (Never asked of a table.)"""
        kind, ref = src
        if kind == "table":
            return False
        body = self.ctes.get(ref) if kind == "cte" else ref
        if body is None or id(body) in seen:
            return False
        explicit, stars = self.outputs(body, seen)
        if name in explicit:
            return True
        uniq = list(dict.fromkeys(stars))
        if any(k == "table" for k, _ in uniq):
            return False
        return any(self.produces(x, name, seen | {id(body)}) for x in uniq)


def _alias_to_table(tree, cte_names: Optional[set] = None) -> Dict[str, str]:
    """Map every table alias (and bare table name, lower-cased) to its real name.

    ⚠️ CTE names are EXCLUDED — see `_cte_names`. A CTE is not a base table, and
    treating it as one fabricates lineage.
    """
    ctes = cte_names if cte_names is not None else _cte_names(tree)
    out: Dict[str, str] = {}
    for t in tree.find_all(exp.Table):
        real = (t.name or "").lower()
        if not real or real in ctes:
            continue
        out[(t.alias or t.name or "").lower()] = real
        out[real] = real
    return out


def _row_source_tables(tree, dialect: str,
                       cte_base: Optional[Dict[str, List[str]]] = None) -> Optional[List[str]]:
    """Which input tables determine the query's row COUNT — the driving side.

    An aggregate over a LEFT/RIGHT/FULL-joined chain counts the rows of the
    driving side only; an outer join for enrichment cannot add or drop driving
    rows. Row-contributing = the FROM table + any INNER/CROSS join. Returns None
    when it can't tell (subquery FROM, comma join) — the caller then keeps all
    inputs, never narrows an aggregate on doubt.

    ⛔ A CTE NAME IS NOT A TABLE, and returning one is a FABRICATION — the exact
    failure `_cte_names` exists to prevent, one level up. MEASURED: 14 columns across
    `explore_image_exposure`, `explore_images`, `explore_packages` and
    `prioritize_runtime_context` reported a source table `population`, which is a CTE
    (`population AS (SELECT … UNION …)`). A reader cannot look that table up, and a
    provenance consumer scoping to it scopes to nothing. So a CTE in the driving
    position is RESOLVED to the base tables behind it via `cte_base`, and dropped when
    it cannot be resolved rather than passed through as if real.
    """
    frm = tree.find(exp.From)
    if frm is None:
        return None
    from_tables = list(frm.find_all(exp.Table))
    if len(from_tables) != 1:
        return None
    contributing: List[str] = [(from_tables[0].name or "").lower()]
    for j in tree.find_all(exp.Join):
        side = (j.args.get("side") or "").upper()
        if side in ("LEFT", "RIGHT", "FULL"):
            continue  # outer join → enrichment, not row-affecting
        for t in j.find_all(exp.Table):
            contributing.append((t.name or "").lower())
    # Resolve any CTE in the driving position to the real tables behind it; a CTE
    # that cannot be resolved is DROPPED, never emitted as though it were a table.
    cte_base = cte_base or {}
    resolved: List[str] = []
    for t in contributing:
        if not t:
            continue
        if t in cte_base:
            resolved.extend(cte_base[t])
        elif t in _cte_names(tree):
            continue          # unresolvable CTE — say nothing rather than fabricate
        else:
            resolved.append(t)
    seen: Set[str] = set()
    out: List[str] = []
    for t in resolved:
        if t and t not in seen:
            seen.add(t)
            out.append(t)
    return out


def columns_read_from(sql: Optional[str], relation: str, *,
                      dialect: str = "postgres") -> Optional[List[str]]:
    """Which columns of `relation` does `sql` reference — ANYWHERE (SELECT, WHERE,
    GROUP BY, ORDER BY)? Used on a WIDGET's query to seed column-scoped provenance:
    a widget filtering on `asset_environment` genuinely depends on that column even
    if it never SELECTs it.

    Returns a sorted list, or None to mean "cannot restrict — treat as all columns":
    a parse failure, a `SELECT *`, or a column ref that can't be tied to `relation`.
    None is the safe answer (keep everything in scope), never the empty list.

    Unlike extract_column_lineage this is a transient, per-request read (the widget
    query is not a stored entity), but it lives here so there is ONE sqlglot
    implementation and viz never imports sqlglot directly.
    """
    if not sql or not sql.strip():
        return None
    try:
        tree = sqlglot.parse_one(sql, read=dialect)
    except (sqlglot.errors.ParseError, sqlglot.errors.TokenError):
        return None
    # A genuine `SELECT *` projection means we can't restrict — but `COUNT(*)` also
    # contains a Star, and that is NOT a projection star. Only bail when a top-level
    # SELECT expression IS itself a bare Star (or a table-qualified `t.*`).
    select = tree.find(exp.Select)
    if select is not None:
        for e in select.expressions:
            if isinstance(e, exp.Star) or (isinstance(e, exp.Column) and isinstance(e.this, exp.Star)):
                return None  # SELECT * / SELECT t.* — cannot restrict
    tables = list(tree.find_all(exp.Table))
    single = (tables[0].name or "").lower() if len(tables) == 1 else None
    target = (relation or "").lower()
    cols: Set[str] = set()

    # ⛔ QUALIFIED refs resolve PER SCOPE. A query-wide alias map is last-wins, and an
    # alias reused across scopes is ordinary SQL: `WITH change AS (… FROM
    # prioritize_mitigations m …) SELECT m.finding_key … LEFT JOIN members m` binds the
    # outer `m` to the `members` CTE. The global map pinned `m.finding_key` on
    # prioritize_mitigations, and the bundle shape check REFUSED
    # exposure_posture_remediation on 23 columns that relation never had to carry.
    # Unqualified refs keep the whole-query single-table rule unchanged.
    try:
        from sqlglot.optimizer.scope import traverse_scope
        def _sources(scope):
            src = {}
            for name, source in scope.selected_sources.items():
                node = source[1] if isinstance(source, tuple) else source
                src[(name or "").lower()] = (
                    (node.name or "").lower() if isinstance(node, exp.Table) else None)
            return src

        for scope in traverse_scope(tree):
            for c in scope.columns:
                if not c.table:
                    tbl = single
                else:
                    # Nearest enclosing scope that binds the alias — a correlated
                    # subquery's `f.x` belongs to the OUTER `f`.
                    tbl, s, alias = None, scope, c.table.lower()
                    while s is not None:
                        src = _sources(s)
                        if alias in src:
                            tbl = src[alias]
                            break
                        s = s.parent
                if tbl == target and c.name:
                    cols.add(c.name)
        return sorted(cols)
    except Exception:  # noqa: BLE001 — fall back to the query-wide map below
        cols = set()

    alias2table = {(t.alias or t.name or "").lower(): (t.name or "").lower() for t in tables}
    for c in tree.find_all(exp.Column):
        tbl = alias2table.get((c.table or "").lower()) if c.table else single
        if tbl == target and c.name:
            cols.add(c.name)
    return sorted(cols)


#: ⛔ THE LOAD-BEARING RULE. A column reference is load-bearing when removing it
#: would change WHICH ROWS are returned or how they are CLASSIFIED. Walk the
#: reference's ancestors outward; it is load-bearing if any ancestor is a member.
#:
#: ⛔ POSITIVE MEMBERSHIP TEST, deliberately — never "everything except ORDER BY".
#: An exclusion list breaks silently the day sqlglot grows a node type; a
#: membership test cannot. A bare `ORDER BY t.x` reaches `Select` without touching
#: any member and returns False naturally, so no ORDER BY exclusion is needed and
#: adding one would be a bug.
#:
#: ⚠️ `exp.Func` subsumes several members in practice (`exp.If` — what a CASE arm
#: parses to — is a Func, so it matches before `exp.Case` is reached). The
#: redundancy is KEPT because the SET is the specification: dropping `Case`
#: because `Func` happens to catch today's parse shape would make the rule depend
#: on sqlglot's class hierarchy staying put.
#:
#: ⚠️ This mirrors `LOAD_BEARING_ANCESTORS` in the `torana-text-to-sql` gate
#: script. It lives HERE because a packaged Claude skill cannot be imported by a
#: service; the skill and the bundle validator must nonetheless agree, and two
#: copies of a rule is exactly the drift S18 exists to remove.
LOAD_BEARING_ANCESTORS = (
    exp.Where, exp.Join, exp.Having, exp.Qualify,   # filters
    exp.Group, exp.Window,                          # grain (GROUP BY / PARTITION BY)
    exp.Case, exp.Filter, exp.Func,                 # computes a value acted upon
)


def _is_load_bearing_node(node) -> bool:
    """Is THIS reference load-bearing? Computed from the parse tree.

    ⚠️ SUBQUERIES: the walk does NOT stop at the enclosing SELECT, it continues to
    the root. A column inside a subquery in a WHERE clause IS load-bearing for the
    outer query; stopping at the boundary would report it as a harmless projection.
    """
    cur = node.parent
    while cur is not None:
        if isinstance(cur, LOAD_BEARING_ANCESTORS):
            return True
        cur = cur.parent
    return False


def load_bearing_columns_read_from(
    sql: Optional[str], relation: str, *, dialect: str = "postgres"
) -> Optional[Dict[str, bool]]:
    """`{column: is_load_bearing}` for every reference to `relation` in `sql`.

    The companion to `columns_read_from`, which answers only WHICH columns. This
    adds the axis a caller needs to rank harm: a caller-only column in a bare
    projection renders a blank cell, while the SAME column in a WHERE or an
    anti-join changes which rows exist at all.

    ⚠️ OR-REDUCED PER COLUMN, not per reference. A column very often appears BOTH
    as a bare projection and inside a CASE; classifying per reference yields
    [False, True] for one column and invites a reader to act on the False — which
    is the exact error this axis exists to prevent. The answer is per-QUERY.

    Returns None for "cannot restrict" on the same terms as `columns_read_from`
    (parse failure / `SELECT *` / unattributable ref), never an empty dict — an
    empty dict would read as "no columns referenced", which is a different claim.
    """
    if not sql or not sql.strip():
        return None
    try:
        tree = sqlglot.parse_one(sql, read=dialect)
    except (sqlglot.errors.ParseError, sqlglot.errors.TokenError):
        return None
    select = tree.find(exp.Select)
    if select is not None:
        for e in select.expressions:
            if isinstance(e, exp.Star) or (isinstance(e, exp.Column) and isinstance(e.this, exp.Star)):
                return None  # SELECT * / SELECT t.* — cannot restrict
    tables = list(tree.find_all(exp.Table))
    alias2table = {(t.alias or t.name or "").lower(): (t.name or "").lower() for t in tables}
    single = (tables[0].name or "").lower() if len(tables) == 1 else None
    target = (relation or "").lower()
    if target not in {(t.name or "").lower() for t in tables}:
        return {}      # `relation` genuinely absent — a real, empty answer

    out: Dict[str, bool] = {}
    for c in tree.find_all(exp.Column):
        if not c.name:
            continue
        if c.table:
            tbl = alias2table.get(c.table.lower())
        elif single:
            tbl = single
        else:
            # ⛔ UNQUALIFIED COLUMN IN A MULTI-TABLE STATEMENT — unattributable.
            #
            # ⚠️ Returning here (rather than skipping the column) is the whole point. The
            # tempting alternative — ignore what we cannot attribute and answer with the
            # rest — yields `{}` for a query that genuinely reads the target table, and `{}`
            # reads as "no caller-only columns found": a CLEAN BILL produced by not looking.
            # Measured on exactly this shape:
            #     SELECT 1 FROM assets WHERE torana_entity_id IN (
            #         SELECT torana_entity_id FROM vulnerabilities WHERE is_patch_available)
            # `is_patch_available` IS caller-only and IS load-bearing, and the skip-version
            # reported nothing. None means "cannot restrict" and every caller already
            # handles it; silence does not.
            return None
        if tbl == target:
            name = c.name.lower()
            out[name] = out.get(name, False) or _is_load_bearing_node(c)
    return out


def _star_sources(expr, outer_local, outer_refs) -> Optional[list]:
    """The sources a projected star reads (`*` → every FROM/JOIN source, `x.*` → x), or
    None when the expression is not a star. An unknown qualifier gives [None]."""
    if isinstance(expr, exp.Star):
        return list(outer_refs)
    if isinstance(expr, exp.Column) and isinstance(expr.this, exp.Star):
        return [outer_local.get((expr.table or "").lower())]
    return None


def _expand_star(resolver: "_ScopeResolver", sources: list,
                 all_inputs: List[str]) -> Optional[Dict[str, dict]]:
    """One lineage entry per name a star carries, or None when any source's names are
    unknown (a base table, an unknown alias)."""
    owner: Dict[str, object] = {}
    for src in sources:
        names = resolver.names_of(src, frozenset()) if src is not None else None
        if names is None:
            return None
        for n in names:
            owner.setdefault(n, src)
    out: Dict[str, dict] = {}
    for n, src in owner.items():
        named = resolver.column_of(src, n, frozenset())
        via = {t: sorted(cs) for t, cs in named.items()}
        if any(via.values()):
            out[n] = {"tables": sorted(via), "via": via, "is_aggregate": False,
                      "traceable": True, "tables_exact": True}
        else:
            # A literal / expression with no input column: a candidate set, never exact.
            out[n] = {"tables": all_inputs, "via": {}, "is_aggregate": False,
                      "traceable": False, "tables_exact": False}
    return out


def extract_column_lineage(sql: Optional[str], *, dialect: str = "postgres") -> dict:
    """Per-output-column lineage for one transformer's SQL.

    Returns a persistable artifact:

        {
          "version": 1,
          "parsed": bool,                 # False → SQL unparseable / SELECT *; treat
                                          #         every consumer column as untraceable
          "row_source_tables": [t, ...],  # driving tables (aggregate row source); [] if unknown
          "columns": {
             "<output_col>": {
                "tables":     [t, ...],   # input tables this output derives from
                "via":        {t: [col, ...]},  # per-table source columns (plain projections)
                "is_aggregate": bool,
                "traceable":  bool,       # False for aggregate/expression/SELECT *
             }, ...
          }
        }

    The artifact is everything a consumer needs to scope provenance to the
    columns a downstream query reads WITHOUT re-parsing: `via` maps output→input
    columns for plain projections, `row_source_tables` handles aggregates, and
    `traceable=False` marks the honest boundary where source columns can't be named.
    """
    empty = {"version": COLUMN_LINEAGE_VERSION, "parsed": False,
             "row_source_tables": [], "columns": {}}
    if not sql or not sql.strip():
        return empty
    try:
        tree = sqlglot.parse_one(sql, read=dialect)
    except (sqlglot.errors.ParseError, sqlglot.errors.TokenError):
        return empty
    select = tree.find(exp.Select)
    if select is None:
        return empty

    cte_names = _cte_names(tree)
    alias2table = _alias_to_table(tree, cte_names)
    cte_sources = _cte_output_sources(tree, dialect)
    resolver = _ScopeResolver(tree)
    # The outer SELECT's OWN sources, per scope (see `_own_sources`).
    outer_local = _own_sources(select, cte_names)
    outer_refs = list(dict.fromkeys(outer_local.values()))
    # ⚠️ ALIAS -> CTE NAME for the outer query. A CTE is almost always aliased at the
    # use site (`… LEFT JOIN running_image r ON …`), so the column arrives qualified
    # by `r`, which is NOT in `cte_names` — the CTE branch below never fired and the
    # column fell through to the every-input fallback. MEASURED on
    # `explore_findings.on_running_image`, whose CTE resolves perfectly but whose
    # alias hid it.
    cte_alias: Dict[str, str] = {}
    for _t in tree.find_all(exp.Table):
        _n = (_t.name or "").lower()
        if _n in cte_names:
            cte_alias[(_t.alias or _n).lower()] = _n
    # CTE -> the base tables behind it, for resolving a CTE in the DRIVING position.
    # Union of every output column's sources: the CTE's rows come from those tables.
    cte_base: Dict[str, List[str]] = {}
    for _cte, _cols in cte_sources.items():
        _u: Set[str] = set()
        for _tbls in _cols.values():
            _u |= set(_tbls)
        if _u:
            cte_base[_cte] = sorted(_u)
    row_src = _row_source_tables(tree, dialect, cte_base) or []
    all_inputs = sorted(set(alias2table.values()))

    # ⚠️ A CTE reference in the outer FROM contributes its OWN base tables to the
    # query's inputs. Without this, a query whose every real table sits inside CTEs
    # reports `all_inputs=[]` and the fallback has nothing to name.
    for _m in cte_sources.values():
        for _tbls in _m.values():
            all_inputs = sorted(set(all_inputs) | set(_tbls))

    columns: Dict[str, dict] = {}
    parsed = True
    for expr in select.expressions:
        star_sources = _star_sources(expr, outer_local, outer_refs)
        if star_sources is not None:
            # ⭐ v5: a star over CTEs / derived tables expands to their output names, each
            # traced through `_ScopeResolver`. ⛔ A star reaching a base table still marks
            # the artifact unparsed: its columns are unknown without a schema.
            expanded = _expand_star(resolver, star_sources, all_inputs)
            if expanded is None:
                parsed = False
            else:
                for _n, _entry in expanded.items():
                    columns.setdefault(_n, _entry)
            continue
        name = expr.alias_or_name
        if not name:
            parsed = False
            continue

        is_agg = bool(list(expr.find_all(exp.AggFunc)))
        via: Dict[str, List[str]] = {}
        cte_resolved = False
        for c in expr.find_all(exp.Column):
            raw_qual = (c.table or "").lower()
            # ⭐ v4: the outer scope's own alias first. A CTE source carries its REAL input
            # columns out (`_cte_output_columns`); a base table is read directly.
            own = (outer_local.get(raw_qual) if raw_qual
                   else (outer_refs[0] if len(outer_refs) == 1 else None))
            if own is not None and own[0] in ("cte", "derived"):
                named = resolver.column_of(own, (c.name or "").lower(), frozenset())
                if named:
                    for _t, _cs in named.items():
                        via.setdefault(_t, [])
                        for _c in _cs:
                            if _c not in via[_t]:
                                via[_t].append(_c)
                    continue
            elif own is not None and own[0] == "table":
                via.setdefault(own[1], [])
                if c.name and c.name not in via[own[1]]:
                    via[own[1]].append(c.name)
                continue
            qual = cte_alias.get(raw_qual, raw_qual)      # resolve a CTE's use-site alias
            if qual and qual in cte_names:
                # ⭐ Qualified by a CTE. The name after the dot is an alias bound
                # INSIDE the CTE, so it is not a column of any base table — but the
                # CTE's own SELECT says which base tables it reads, and
                # `_cte_output_sources` has already resolved that. Attribute to those
                # REAL tables rather than falling back to every input in the query.
                #
                # ⛔ Still no fabrication: `via` is left empty for these, because the
                # OUTPUT alias is not a column name on the base table. We can name the
                # table honestly; we cannot name the column.
                tbl = None
                for _t in cte_sources.get(qual, {}).get((c.name or "").lower(), []):
                    via.setdefault(_t, [])
                    cte_resolved = True
            elif qual:
                tbl = alias2table.get(qual)
            else:
                # Unqualified. Attribute to the single input only when there IS
                # exactly one — and never when a CTE is in play, since the real
                # source then sits behind it.
                tbl = all_inputs[0] if (len(all_inputs) == 1 and not cte_names) else None
            if tbl:
                via.setdefault(tbl, [])
                if c.name and c.name not in via[tbl]:
                    via[tbl].append(c.name)

        if is_agg:
            # Row-source tables drive the aggregate; union any columns it names.
            #
            # ⭐ When the aggregate's inputs ALL resolved (directly or through a CTE),
            # `via` already names the real tables — do NOT union `row_src` into it.
            # `row_src` is the driving side of the OUTER query, which for an aggregate
            # pulled from a CTE is the wrong table: `classie_em_assets.cve_count`
            # counts `vulnerabilities` rows but the outer query drives off `assets`,
            # so unioning produced `[assets, vulnerabilities]` — the exact spurious
            # pair this fix removes.
            # ⭐ `COUNT(*)` NAMES NO COLUMN, so `via` is empty — but when the whole
            # query drives off exactly ONE table it can only be counting that table's
            # rows, which is as exact as an answer gets. Same reasoning as the
            # single-base-table case inside a CTE. With two driving tables it counts
            # the JOINED rows and naming either alone would be a guess, so those stay
            # a candidate set.
            # ⛔ `exact` must never be claimed over an EMPTY table list — that asserts
            # certainty about nothing. Compute the tables first, then let exactness
            # follow from them.
            single_driver = len(set(row_src)) == 1
            tables = (sorted(via.keys()) if via
                      else (sorted(set(row_src)) or all_inputs))
            exact = bool(tables) and (bool(via) or single_driver)
            columns[name] = {
                "tables": tables,
                "via": {t: sorted(cols) for t, cols in via.items()},
                "is_aggregate": True,
                "traceable": False,
                "tables_exact": exact,
            }
        elif via:
            # ⚠️ `traceable` means "the exact SOURCE COLUMN is named", which is what a
            # provenance consumer scopes on — so a CTE-resolved column is NOT traceable
            # even though its table is now known exactly. Claiming otherwise would put
            # an empty `via` behind a `traceable=True`, and a consumer reading `via` to
            # scope columns would silently scope to nothing.
            #
            # ⭐ `tables_exact` is the new, narrower promise: these tables are proven,
            # not a candidate set. That is the distinction a UI needs — "came from
            # vulnerabilities (column unknown)" is a far better answer than "came from
            # one of assets, vulnerabilities".
            resolved_only = cte_resolved and not any(via.values())
            columns[name] = {
                "tables": sorted(via.keys()),
                "via": {t: sorted(cols) for t, cols in via.items()},
                "is_aggregate": False,
                "traceable": not resolved_only,
                "tables_exact": True,
            }
        else:
            # Literal / expression with no resolvable column ref. `tables` here is a
            # CANDIDATE SET (every input), never a proven answer — hence exact=False.
            columns[name] = {
                "tables": all_inputs,
                "via": {},
                "is_aggregate": False,
                "traceable": False,
                "tables_exact": False,
            }

    return {
        "version": COLUMN_LINEAGE_VERSION,
        "parsed": parsed,
        "row_source_tables": row_src,
        "columns": columns,
    }
