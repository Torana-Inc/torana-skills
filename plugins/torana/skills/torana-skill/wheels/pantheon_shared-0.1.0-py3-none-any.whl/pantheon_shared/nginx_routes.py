"""Parse an nginx config into its `server {}` and `location` blocks.

One definition of "what does this nginx conf route, and who may call it" for every service
that reads one: the Kubernetes gateway reader (pantheon-integration) and the Atlas
`ingress-config` extractor (pantheon-knowledge). INGRESS_ROUTES.md § 3.3 and § 3.8.

Pure and stdlib-only: a function of the text (plus an optional include resolver). It reads
only what the file says (DECLARED, never observed) and judges nothing about the cluster.
Shadowing, prefixes and the `target_env` are the Atlas extractor's job, not this module's.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple

#: Sentinel `backend_service` for `proxy_pass http://$1` (a regex capture): the upstream cannot
#: be resolved statically and, in a non-internal block, is SSRF-shaped, so it is surfaced.
DYNAMIC_BACKEND = "*dynamic*"

#: The only directives read from an included file (INGRESS_ROUTES.md § 3.10).
_INCLUDE_DIRECTIVES = {"auth_request", "allow", "deny", "internal", "proxy_pass", "set"}

#: `set $NAME "host:port";` — the quotes are required by nginx for a value containing a colon.
_SET_HOST = re.compile(r"""set\s+\$(?P<var>\w+)\s+["'](?P<host>[^"'\s;]+)["']\s*;""")
#: `set $backend $other_backend;` — the alias form. ONE level is followed, deliberately.
_SET_ALIAS = re.compile(r"""set\s+\$(?P<var>\w+)\s+\$(?P<src>\w+)\s*;""")
_PROXY_VAR = re.compile(r"""proxy_pass\s+https?://\$(?P<var>\w+)""")
_PROXY_LITERAL = re.compile(r"""proxy_pass\s+https?://(?P<host>[A-Za-z0-9._-]+(?::\d+)?)""")
_LOCATION = re.compile(r"""(?<![^\s;{}])location\s+(?P<match>[^{;]+?)\s*\{""")
_SERVER = re.compile(r"""(?<![^\s;{}])server\s*\{""")
_INCLUDE = re.compile(r"""(?<![\w$])include\s+(?P<target>[^;\s]+)\s*;""")


@dataclass
class Location:
    """One `location` block. Every field is read from the text; nothing is inferred."""
    matcher: str                 # raw, e.g. "~ ^/api/v1/audit/records(/.*)?$"
    match_type: str              # exact | prefix_stop | prefix | regex | regex_ci | named
    pattern: str                 # the matcher without its modifier
    line: int                    # 1-based line of the `location` header
    order: int                   # position among all locations of the file
    server: int                  # index of the enclosing `server {}` (0 when there is none)
    kind: str                    # proxy | redirect | deny | respond | static | named | other
    internal: bool               # `internal;` or a named location: never externally reachable
    backend_host: str = ""       # host[:port] as written
    backend_service: str = ""    # first DNS label verbatim, DYNAMIC_BACKEND, or ""
    backend_namespace: str = ""  # <ns> of <svc>.<ns>.svc[.cluster.local], else ""
    backend_line: int = 0        # line of the `set $X "host"` (or literal proxy_pass) directive
    dynamic: bool = False
    auth_request: str = ""       # the block's own `auth_request` argument ("off", "/x") or ""
    has_allow: bool = False
    deny_all: bool = False
    edge_auth: str = "public"    # token_required | public | ip_restricted | denied
    status: int = 0              # the `return` status code, when there is one
    return_to: str = ""          # the `return` target (URL or text) after the code; additive (F1a redirects)


@dataclass
class Server:
    index: int
    line: int
    listen: List[str] = field(default_factory=list)
    server_name: List[str] = field(default_factory=list)
    auth_request: str = ""       # server-level `auth_request` argument ("" when none)
    # TLS and redirect facts (pantheon-knowledge DEPLOYMENT_KIND.md § 3.2 F1a), additive: each with its own 1-based
    # line in the parsed file (0 = not stated in the server's own body, e.g. only through an include)
    listen_lines: List[int] = field(default_factory=list)          # parallel to `listen`
    ssl_certificate: str = ""
    ssl_certificate_line: int = 0
    ssl_certificate_key: str = ""
    ssl_certificate_key_line: int = 0
    returns: List[dict] = field(default_factory=list)              # server-level `return`: {code, to, line}
    resolver: str = ""
    resolver_line: int = 0


@dataclass
class IncludeRef:
    target: str
    count: int
    resolved: bool


@dataclass
class NginxConf:
    servers: List[Server]
    locations: List[Location]
    includes: List[IncludeRef]

    @property
    def includes_unresolved(self) -> bool:
        return any(not i.resolved for i in self.includes)


IncludeResolver = Callable[[str], Optional[str]]


def service_name_from_upstream(host: str) -> str:
    """`pantheon-admin.torana.svc.cluster.local:8011` -> `pantheon-admin`; '' when not a
    resolvable in-cluster service reference (empty, or a bare IP).

    Verbatim: a `-dev` suffix is NOT stripped here (that is the Atlas join's second try).
    """
    h = (host or "").strip().split("/")[0]
    if not h:
        return ""
    h = h.split(":")[0]
    if not h or h.replace(".", "").isdigit():
        return ""
    return h.split(".")[0]


def namespace_from_upstream(host: str) -> str:
    """`<svc>.<ns>.svc[.cluster.local][:port]` -> `<ns>`, else ''."""
    h = (host or "").strip().split("/")[0].split(":")[0]
    parts = h.split(".")
    if len(parts) >= 3 and parts[2] == "svc":
        return parts[1]
    return ""


def _blank_comments(conf: str) -> str:
    """Replace every `#` comment with spaces (newlines kept, so offsets and lines survive).
    A `#` inside a quoted string is not a comment."""
    out: List[str] = []
    for line in conf.split("\n"):
        quote = ""
        cut = -1
        for i, c in enumerate(line):
            if quote:
                if c == quote:
                    quote = ""
            elif c in "\"'":
                quote = c
            elif c == "#" and (i == 0 or line[i - 1].isspace() or line[i - 1] in ";{}"):
                cut = i
                break
        out.append(line if cut < 0 else line[:cut] + " " * (len(line) - cut))
    return "\n".join(out)


def _block_end(text: str, start: int) -> int:
    """Index just past the `}` closing the block whose body starts at `start`, or -1.
    Brace-balanced: a location body legitimately holds nested `if (...) { }` blocks."""
    depth = 1
    i = start
    while i < len(text) and depth:
        c = text[i]
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
        i += 1
    return i if depth == 0 else -1


def _top_level(body: str) -> str:
    """The body with every nested `{...}` block (and its header) removed."""
    out: List[str] = []
    depth = 0
    for c in body:
        if c == "{":
            if depth == 0:
                cut = max(("".join(out)).rfind(x) for x in ";{}")
                if cut >= 0:
                    del out[cut + 1:]
                else:
                    out.clear()
            depth += 1
        elif c == "}":
            depth = max(depth - 1, 0)
        elif depth == 0:
            out.append(c)
    return "".join(out)


def _top_level_at(body: str) -> List[Tuple[str, str, int]]:
    """[(name, args, offset in body)] for every top-level `;`-terminated statement of `body` (comments already
    blanked). A statement that opens a nested block is not one."""
    out: List[Tuple[str, str, int]] = []
    depth, start = 0, 0
    for i, c in enumerate(body):
        if c == "{":
            depth += 1
            if depth == 1:
                start = i + 1
        elif c == "}":
            depth = max(depth - 1, 0)
            if depth == 0:
                start = i + 1
        elif c == ";" and depth == 0:
            stmt = body[start:i]
            words = stmt.split(None, 1)
            if words:
                lead = len(stmt) - len(stmt.lstrip())
                out.append((words[0], words[1].strip() if len(words) > 1 else "", start + lead))
            start = i + 1
    return out


def _server_tls(srv: "Server", body: str, body_offset: int, line_of: Callable[[int], int]) -> None:
    """Fill the F1a fields from the server's OWN top-level statements (lines need the text they came from)."""
    for name, args, off in _top_level_at(body):
        line = line_of(body_offset + off)
        if name == "listen":
            srv.listen_lines.append(line)
        elif name == "ssl_certificate":
            srv.ssl_certificate, srv.ssl_certificate_line = args, line
        elif name == "ssl_certificate_key":
            srv.ssl_certificate_key, srv.ssl_certificate_key_line = args, line
        elif name == "resolver":
            srv.resolver, srv.resolver_line = args, line
        elif name == "return":
            parts = args.split(None, 1)
            code = int(parts[0]) if parts and parts[0].isdigit() else 0
            srv.returns.append({"code": code, "to": (parts[1] if len(parts) > 1 else "").strip(), "line": line})


def _directives(text: str) -> List[Tuple[str, str]]:
    """[(name, args)] for every `;`-terminated statement of already top-level `text`."""
    out: List[Tuple[str, str]] = []
    for stmt in text.split(";")[:-1] if ";" in text else []:
        words = stmt.split(None, 1)
        if words:
            out.append((words[0], words[1].strip() if len(words) > 1 else ""))
    return out


def _included_text(body: str, resolve: Optional[IncludeResolver]) -> str:
    """The allow-listed directives of every include in `body`, as text to append to it."""
    if resolve is None:
        return ""
    extra: List[str] = []
    for m in _INCLUDE.finditer(body):
        text = resolve(m.group("target"))
        if not text:
            continue
        for name, args in _directives(_top_level(_blank_comments(text))):
            if name in _INCLUDE_DIRECTIVES:
                extra.append(f"{name} {args};".replace("  ", " "))
    return "\n".join(extra)


def _match_type(matcher: str) -> Tuple[str, str]:
    m = matcher.strip()
    if m.startswith("@"):
        return "named", m
    for mod, kind in (("^~", "prefix_stop"), ("~*", "regex_ci"), ("=", "exact"), ("~", "regex")):
        if m.startswith(mod) and (len(m) == len(mod) or m[len(mod)].isspace()):
            return kind, m[len(mod):].strip()
    return "prefix", m


def _resolve_backend(body: str) -> Tuple[str, str, bool, int, int]:
    """(host, service, dynamic, directive_offset, has_proxy); `has_proxy` is 0 or 1."""
    proxy = _PROXY_VAR.search(body)
    if proxy:
        var = proxy.group("var")
        sets = {m.group("var"): m for m in _SET_HOST.finditer(body)}
        if var not in sets:
            alias = {m.group("var"): m.group("src") for m in _SET_ALIAS.finditer(body)}
            var = alias.get(var, var)
        hit = sets.get(var)
        if hit is None:
            # A variable upstream we cannot resolve in-block. From a regex capture it is
            # dynamic; say so rather than dropping it silently.
            return "", DYNAMIC_BACKEND if var.isdigit() else "", var.isdigit(), proxy.start(), 1
        host = hit.group("host")
        return host, service_name_from_upstream(host), False, hit.start(), 1
    lit = _PROXY_LITERAL.search(body)
    if lit:
        host = lit.group("host")
        return host, service_name_from_upstream(host), False, lit.start(), 1
    if re.search(r"(?:^|[;{}])\s*proxy_pass\s", body):
        return "", "", False, 0, 1          # a proxy_pass we cannot read (e.g. an unix: socket)
    return "", "", False, 0, 0


def _kind(match_type: str, top: List[Tuple[str, str]], has_proxy: bool) -> Tuple[str, int]:
    if match_type == "named":
        return "named", 0
    if has_proxy:
        return "proxy", 0
    args = next((a for n, a in top if n == "return"), None)
    if args is not None:
        first = args.split()[0] if args.split() else ""
        code = int(first) if first.isdigit() else 302     # `return https://…` is a redirect
        if 300 <= code < 400:
            return "redirect", code
        if code == 444 or code >= 400:
            return "deny", code
        return "respond", code
    if any(n in ("root", "alias", "try_files") for n, _ in top):
        return "static", 0
    return "other", 0


def _edge_auth(kind: str, own: str, server: str, has_allow: bool, deny_all: bool) -> str:
    """`token_required` | `public` | `ip_restricted` | `denied` (INGRESS_ROUTES.md § 3.3.1).

    The block's own `auth_request` wins, else its SERVER's. `off` plus an allow list that ends
    in `deny all` is `ip_restricted` (unverified: behind a load balancer every client can look
    internal). No `auth_request` anywhere means no token check at the edge: `public`.
    """
    if kind == "deny":
        return "denied"
    effective = own or server
    if effective and effective != "off":
        return "token_required"
    if has_allow and deny_all:
        return "ip_restricted"
    return "public"


def parse_nginx_conf(conf: str, resolve_include: Optional[IncludeResolver] = None) -> NginxConf:
    """Parse `conf`. `resolve_include(target)` returns the text of an included file (or None);
    from it only `auth_request`, `allow`, `deny`, `internal`, `proxy_pass`, `set` are read."""
    text = _blank_comments(conf or "")
    line_of = _line_index(text)

    servers: List[Server] = []
    spans: List[Tuple[int, int]] = []
    for m in _SERVER.finditer(text):
        end = _block_end(text, m.end())
        if end < 0 or any(s <= m.start() < e for s, e in spans):
            continue
        body = text[m.end():end - 1]
        full = body + "\n" + _included_text(body, resolve_include)
        top = _directives(_top_level(full))
        srv = Server(index=len(servers), line=line_of(m.start()))
        for name, args in top:
            if name == "listen":
                srv.listen.append(args)
            elif name == "server_name":
                srv.server_name.extend(args.split())
            elif name == "auth_request":
                srv.auth_request = args
        _server_tls(srv, body, m.end(), line_of)
        servers.append(srv)
        spans.append((m.start(), end))

    locations: List[Location] = []
    for m in _LOCATION.finditer(text):
        end = _block_end(text, m.end())
        if end < 0:
            continue
        body = text[m.end():end - 1]
        full = body + "\n" + _included_text(body, resolve_include)
        top = _directives(_top_level(full))
        sidx = next((i for i, (s, e) in enumerate(spans) if s <= m.start() < e), 0)
        matcher = " ".join(m.group("match").split())
        match_type, pattern = _match_type(matcher)
        host, service, dynamic, off, has_proxy = _resolve_backend(full)
        kind, status = _kind(match_type, top, bool(has_proxy))
        own = next((a for n, a in top if n == "auth_request"), "")
        has_allow = any(n == "allow" for n, _ in top)
        deny_all = any(n == "deny" and a == "all" for n, a in top)
        server_auth = servers[sidx].auth_request if sidx < len(servers) else ""
        internal = match_type == "named" or any(n == "internal" for n, _ in top)
        locations.append(Location(
            matcher=matcher, match_type=match_type, pattern=pattern,
            line=line_of(m.start()), order=len(locations), server=sidx, kind=kind,
            internal=internal, backend_host=host, backend_service=service,
            backend_namespace=namespace_from_upstream(host),
            backend_line=line_of(m.end() + off) if (host or dynamic) and off < len(body) else 0,
            dynamic=dynamic, auth_request=own, has_allow=has_allow, deny_all=deny_all,
            edge_auth=_edge_auth(kind, own, server_auth, has_allow, deny_all), status=status,
            return_to=next(((a.split(None, 1) + [""])[1].strip() for n, a in top if n == "return"), ""),
        ))

    counts: Dict[str, int] = {}
    for m in _INCLUDE.finditer(text):
        counts[m.group("target")] = counts.get(m.group("target"), 0) + 1
    includes = [
        IncludeRef(target=t, count=n, resolved=bool(resolve_include and resolve_include(t) is not None))
        for t, n in counts.items()
    ]
    return NginxConf(servers=servers, locations=locations, includes=includes)


def parse_nginx_locations(conf: str, resolve_include: Optional[IncludeResolver] = None) -> List[Location]:
    """Every `location` block of `conf`, in file order."""
    return parse_nginx_conf(conf, resolve_include).locations


def _line_index(text: str) -> Callable[[int], int]:
    starts = [0]
    for m in re.finditer(r"\n", text):
        starts.append(m.end())

    def line_of(offset: int) -> int:
        lo, hi = 0, len(starts)
        while lo < hi - 1:
            mid = (lo + hi) // 2
            if starts[mid] <= offset:
                lo = mid
            else:
                hi = mid
        return lo + 1
    return line_of
