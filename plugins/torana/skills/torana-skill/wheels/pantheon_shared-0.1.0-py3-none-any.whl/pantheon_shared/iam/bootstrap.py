"""
IAM Bootstrap Helper

Provides functionality for services to look up tenant and namespace IDs
from the auth database during initialization. This is used for system-level
operations that run before user authentication (bootstrap, startup, background tasks).

Usage:
    from pantheon_shared.iam import IAMBootstrapHelper

    # Get system IAM context for internal operations
    iam_context = IAMBootstrapHelper.get_system_iam_context()

    # Or get individual IDs
    tenant_id = IAMBootstrapHelper.get_bootstrap_tenant_id()
    namespace_id = IAMBootstrapHelper.get_bootstrap_namespace_id()

Environment Variables:
    SERVICE_AUTH_TENANT_NAME: Tenant name to lookup (e.g., "Torana")
    SERVICE_AUTH_TENANT_NS_NAME: Namespace name to lookup (default: "default")
    BOOTSTRAP_TENANT_NAME: Fallback tenant name for migration containers
    PANTHEON_AUTH_DATABASE_URL: Direct auth DB URL (optional)
"""

import os
import re
from typing import Optional
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine
from sqlalchemy.pool import NullPool

from .. import get_logger

logger = get_logger(__name__)


class IAMBootstrapHelper:
    """
    Helper for bootstrapping IAM tenant/namespace context.

    Provides methods to look up tenant and namespace IDs from the auth database
    for system-level operations. Results are cached for the lifetime of the process.

    This class is designed to be used by services that need to create system-level
    records (templates, prompts, agents) before user authentication is available.
    """

    # Cache for tenant and namespace IDs
    _tenant_id_cache: Optional[str] = None
    _namespace_id_cache: Optional[str] = None
    _auth_engine: Optional[Engine] = None

    @classmethod
    def _get_auth_db_url(cls) -> str:
        """
        Get the auth database URL.

        Tries multiple sources in order:
        1. PANTHEON_AUTH_DATABASE_URL environment variable (explicit)
        2. Derive from any service's DATABASE_URL by replacing DB name

        Returns:
            str: PostgreSQL connection URL for pantheon_auth database

        Raises:
            ValueError: If no database URL can be determined
        """
        # Try explicit auth database URL first
        auth_db_url = os.getenv("PANTHEON_AUTH_DATABASE_URL")
        if auth_db_url:
            # Convert async to sync if needed
            return cls._convert_to_sync_url(auth_db_url)

        # Try to derive from service's DATABASE_URL
        service_db_url = os.getenv("DATABASE_URL")
        if service_db_url:
            # Replace any pantheon_* database name with pantheon_auth
            auth_db_url = re.sub(
                r'/pantheon_[a-z_]+',
                '/pantheon_auth',
                service_db_url
            )
            return cls._convert_to_sync_url(auth_db_url)

        raise ValueError(
            "Cannot determine auth database URL. "
            "Set PANTHEON_AUTH_DATABASE_URL or DATABASE_URL environment variable."
        )

    @classmethod
    def _convert_to_sync_url(cls, url: str) -> str:
        """
        Convert async database URL to sync URL.

        Replaces async drivers (asyncpg, aiomysql, aiosqlite) with their
        synchronous equivalents.

        Args:
            url: Database URL (may have async driver)

        Returns:
            str: Database URL with sync driver
        """
        if "asyncpg" in url:
            url = url.replace("+asyncpg", "").replace("postgresql+asyncpg", "postgresql")
        elif "aiomysql" in url:
            url = url.replace("+aiomysql", "").replace("mysql+aiomysql", "mysql+pymysql")
        elif "aiosqlite" in url:
            url = url.replace("+aiosqlite", "").replace("sqlite+aiosqlite", "sqlite")
        return url

    @classmethod
    def _get_auth_engine(cls) -> Engine:
        """
        Get or create a database engine for the auth database.

        The engine is cached and reused for all lookups.

        Returns:
            Engine: SQLAlchemy engine connected to pantheon_auth database
        """
        if cls._auth_engine is None:
            auth_db_url = cls._get_auth_db_url()

            # NullPool: bootstrap lookups are one-shot at startup — no need to
            # keep idle connections open afterwards. Opens/closes per query.
            app_name = os.getenv("APPLICATION_NAME", os.getenv("SERVICE_NAME", "pantheon-service"))
            cls._auth_engine = create_engine(
                auth_db_url,
                poolclass=NullPool,
                connect_args={
                    "application_name": f"{app_name}-bootstrap-lookup"
                }
            )
            logger.debug("Created auth database engine for bootstrap lookup")

        return cls._auth_engine

    @classmethod
    def _get_tenant_name(cls) -> str:
        """
        Get the tenant name from environment variables.

        Checks in order:
        1. SERVICE_AUTH_TENANT_NAME (standard for services)
        2. BOOTSTRAP_TENANT_NAME (for migration containers)
        3. Falls back to "Torana" (default bootstrap tenant)

        Returns:
            str: Tenant name to lookup
        """
        tenant_name = os.getenv("SERVICE_AUTH_TENANT_NAME")
        if tenant_name:
            return tenant_name

        tenant_name = os.getenv("BOOTSTRAP_TENANT_NAME")
        if tenant_name:
            return tenant_name

        return "Torana"

    @classmethod
    def _get_namespace_name(cls) -> str:
        """
        Get the namespace name from environment variables.

        Returns:
            str: Namespace name to lookup (default: "default")
        """
        return os.getenv("SERVICE_AUTH_TENANT_NS_NAME", "default")

    @classmethod
    def get_bootstrap_tenant_id(cls) -> str:
        """
        Get the tenant ID for the configured tenant name.

        Looks up the tenant ID from the pantheon_auth database based on
        SERVICE_AUTH_TENANT_NAME (or BOOTSTRAP_TENANT_NAME for migrations).

        Results are cached for the lifetime of the process.

        Returns:
            str: The tenant UUID

        Raises:
            ValueError: If tenant is not found or database connection fails
        """
        if cls._tenant_id_cache:
            return cls._tenant_id_cache

        tenant_name = cls._get_tenant_name()

        try:
            engine = cls._get_auth_engine()

            with engine.connect() as conn:
                result = conn.execute(
                    text("SELECT id FROM tenants WHERE name = :tenant_name"),
                    {"tenant_name": tenant_name}
                ).fetchone()

                if not result:
                    raise ValueError(
                        f"Tenant '{tenant_name}' not found in pantheon_auth database. "
                        f"Please ensure the tenant exists before starting services."
                    )

                tenant_id = str(result[0])
                cls._tenant_id_cache = tenant_id
                logger.debug(f"Resolved bootstrap tenant_id: {tenant_id} for tenant '{tenant_name}'")
                return tenant_id

        except ValueError:
            raise
        except Exception as e:
            logger.error(f"Failed to look up tenant ID for '{tenant_name}': {e}")
            raise ValueError(
                f"Could not resolve tenant ID for '{tenant_name}'. "
                f"Ensure the pantheon_auth database is accessible and contains the tenant."
            ) from e

    @classmethod
    def get_bootstrap_namespace_id(cls) -> str:
        """
        Get the namespace ID for the configured namespace name.

        Looks up the namespace ID from the pantheon_auth database based on
        SERVICE_AUTH_TENANT_NS_NAME within the bootstrap tenant.

        Results are cached for the lifetime of the process.

        Returns:
            str: The namespace UUID

        Raises:
            ValueError: If namespace is not found or database connection fails
        """
        if cls._namespace_id_cache:
            return cls._namespace_id_cache

        namespace_name = cls._get_namespace_name()
        tenant_name = cls._get_tenant_name()

        try:
            engine = cls._get_auth_engine()

            # First get tenant_id
            tenant_id = cls.get_bootstrap_tenant_id()

            with engine.connect() as conn:
                result = conn.execute(
                    text("""
                        SELECT id FROM namespaces
                        WHERE name = :namespace_name AND tenant_id = :tenant_id
                    """),
                    {"namespace_name": namespace_name, "tenant_id": tenant_id}
                ).fetchone()

                if not result:
                    raise ValueError(
                        f"Namespace '{namespace_name}' not found for tenant '{tenant_name}' "
                        f"in pantheon_auth database. Please ensure the namespace exists."
                    )

                namespace_id = str(result[0])
                cls._namespace_id_cache = namespace_id
                logger.debug(f"Resolved bootstrap namespace_id: {namespace_id} for namespace '{namespace_name}'")
                return namespace_id

        except ValueError:
            raise
        except Exception as e:
            logger.error(f"Failed to look up namespace ID for '{namespace_name}': {e}")
            raise ValueError(
                f"Could not resolve namespace ID for '{namespace_name}'. "
                f"Ensure the pantheon_auth database is accessible and contains the namespace."
            ) from e

    @classmethod
    def get_bootstrap_user_id(cls) -> str:
        """
        Get a system user ID for internal service operations.

        Returns a fixed UUID for the system user used for bootstrapping
        and internal operations.

        Returns:
            str: The system user UUID (00000000-0000-0000-0000-000000000001)
        """
        return "00000000-0000-0000-0000-000000000001"

    @classmethod
    def get_system_iam_context(cls):
        """
        Get a system IAM context for internal operations.

        Creates an IAMContext with bootstrap tenant/namespace and system user
        credentials. Use this for operations that run before user authentication:
        - Bootstrap/seed data loading
        - Background tasks and schedulers
        - Service-to-service calls without user context
        - Cache invalidation helpers

        Returns:
            IAMContext: System context with super_admin role

        Example:
            iam_context = IAMBootstrapHelper.get_system_iam_context()
            # Use for creating system records
            template.tenant_id = iam_context.tenant_id
            template.namespace_id = iam_context.namespace_id
            template.created_by = iam_context.user_id
        """
        from .context import IAMContext

        return IAMContext(
            user_id=cls.get_bootstrap_user_id(),
            email="system@pantheon.internal",
            tenant_id=cls.get_bootstrap_tenant_id(),
            tenant_name=cls._get_tenant_name(),
            namespace_id=cls.get_bootstrap_namespace_id(),
            roles=["super_admin"]
        )

    @classmethod
    def clear_cache(cls) -> None:
        """
        Clear the cached tenant and namespace IDs.

        Useful for testing or when tenant configuration changes.
        """
        cls._tenant_id_cache = None
        cls._namespace_id_cache = None
        if cls._auth_engine:
            cls._auth_engine.dispose()
            cls._auth_engine = None
        logger.debug("Cleared IAMBootstrapHelper cache")
