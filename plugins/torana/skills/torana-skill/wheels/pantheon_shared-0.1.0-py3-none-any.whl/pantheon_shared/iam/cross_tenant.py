"""I-65: every cross-tenant request a super admin makes is recorded, and a cross-tenant WRITE needs a declared act-as.

ONE definition (`guard_cross_tenant`) for every place a request switches tenant:

- the `?tenant_id=` swap in `IAMEndpoint.get_iam_context` (iam/api.py), the generic path every IAM route uses;
- `resolve_tenant_filter` (iam/filtering.py) for an `AuthenticatedUser` caller (pantheon-auth's own routes);
- `require_act_as` / `act_as_body_tenant`, for a WRITE route that takes its target tenant in the request BODY;
- `guard_query_tenant(name)`, for a service that swaps on a query parameter with ANOTHER name (Atlas `?tenant=`).

What it STOPS and what it does NOT (the honest scope of this control):

- STOPS an accidental or unrecorded cross-tenant WRITE: POST/PUT/PATCH/DELETE on another tenant is refused (403)
  unless the request declares `X-Torana-Act-As-Tenant: <that tenant>` and a non-empty `X-Torana-Act-As-Reason`.
- RECORDS every swapped-tenant request, read and write, in the platform security log (pantheon-auth `audit_logs`,
  action `cross_tenant.read` / `cross_tenant.write`) with actor, home tenant, target tenant, method, route
  template, trace id and the declared reason.
- Does NOT stop a super admin who MEANS to write to another tenant: anyone allowed to cross tenants can send the
  two headers. It is an audit and a deliberate-step control, NOT an authorization boundary. Who may cross tenants
  at all is still `IAMContext.can_cross_tenant()` / `AuthenticatedUser.has_cross_tenant_access()` (OI-28).
- Does NOT apply to service tokens (`sub` "service:..."), internal callers (`AuthenticatedUser.is_internal`, whose
  role is "internal_service"), or impersonation tokens: a service mints a token FOR the tenant it acts on; an
  impersonation token's home IS the target. ⛔ Decided from the token, never a role name (`is_platform_caller`).

Audit timing (root CLAUDE.md rule B: no DB session is held across the auth call by this module):
- a WRITE is audited BEFORE the handler runs and FAILS CLOSED (503 when the row cannot be written);
- a READ is audited by a DETACHED task scheduled when the swap is decided (never awaited, so no latency) and fails
  open, deduplicated per worker for `READ_DEDUP_SECONDS` on (actor, target, method, route template). ⛔ Not a FastAPI
  BackgroundTask: FastAPI drops those when the route raises, so a cross-tenant read answering 404/403 (probing another
  tenant's ids, the case an audit exists for) left no row (I-82).

⛔ The reason is operator text: capped at `REASON_MAX_CHARS`, control characters stripped, stored in the audit row
only. Never put it in a log message or a metric label.
"""

from __future__ import annotations

import asyncio
import threading
import time
import unicodedata
import uuid
from contextvars import ContextVar
from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional, Set, Tuple

from fastapi import BackgroundTasks, HTTPException, Request

from ..logging import get_logger

logger = get_logger(__name__)

ACT_AS_TENANT_HEADER = "X-Torana-Act-As-Tenant"
ACT_AS_REASON_HEADER = "X-Torana-Act-As-Reason"
WRITE_METHODS = frozenset({"POST", "PUT", "PATCH", "DELETE"})
REASON_MAX_CHARS = 500
READ_DEDUP_SECONDS = 60.0
_DEDUP_MAX_ENTRIES = 10_000
#: `target_tenant_id` meaning "every tenant" (an SA list that named no tenant).
ALL_TENANTS = "*"

CLI_HINT = "torana --act-as-tenant <tenant-id> --act-as-reason \"<why>\" ..."

#: The request of the call in progress, bound by `pantheon_shared.auth.get_current_user` so that
#: `resolve_tenant_filter` (which is handed only a user) can still see method, route and headers.
_current_request: ContextVar[Optional[Request]] = ContextVar("pantheon_cross_tenant_request", default=None)


def bind_request(request: Optional[Request]) -> None:
    """Make `request` visible to `resolve_tenant_filter` for the rest of this call."""
    _current_request.set(request)


def current_request() -> Optional[Request]:
    return _current_request.get()


@dataclass(frozen=True)
class CrossTenantAccess:
    """One swapped-tenant request: the single record every caller of this module computes."""
    actor_user_id: Optional[str]
    actor_email: Optional[str]
    home_tenant_id: str
    target_tenant_id: str
    method: str
    route: str
    trace_id: Optional[str]
    reason: Optional[str]
    resource_type: str
    #: A POST that only reads (datalake `POST /query`): recorded as a read whatever its method.
    read_only: bool = False

    @property
    def is_write(self) -> bool:
        return not self.read_only and self.method in WRITE_METHODS

    @property
    def action(self) -> str:
        return "cross_tenant.write" if self.is_write else "cross_tenant.read"


# ── who the caller is ───────────────────────────────────────────────────────────────────────

def _roles(ctx: Any) -> list:
    return list(getattr(ctx, "roles", None) or [])


def _user_info(ctx: Any) -> Dict[str, Any]:
    return dict(getattr(ctx, "user_info", None) or {})


def home_tenant_of(ctx: Any) -> Optional[str]:
    """The tenant the verified token was issued for. For an `IAMContext` after the `?tenant_id=` swap,
    `ctx.tenant_id` is already the TARGET, so the claims win (iam/api.py carries them across the swap)."""
    home = _user_info(ctx).get("tenant_id") or getattr(ctx, "tenant_id", None)
    return str(home) if home else None


def normalize_tenant_id(value: Any) -> str:
    """ONE spelling per tenant id: stripped, lowercased, one pair of `{}` braces removed, and a UUID in its canonical
    form (`uuid.UUID`). A non-UUID id (e.g. "torana") stays the lowercased string. "" for None/blank.

    I-100 review: `ABC...` or `{abc...}` naming the caller's OWN tenant was compared byte-for-byte with the token's
    tenant and refused 403. Only spelling is folded; two different UUIDs or strings never become equal."""
    text = str(value).strip().lower() if value is not None else ""
    if len(text) >= 2 and text[0] == "{" and text[-1] == "}":
        text = text[1:-1].strip()
    try:
        return str(uuid.UUID(text))
    except (ValueError, AttributeError, TypeError):
        return text


def same_tenant(a: Any, b: Any) -> bool:
    """True when `a` and `b` name the same tenant (`normalize_tenant_id`). Blank never equals anything."""
    na, nb = normalize_tenant_id(a), normalize_tenant_id(b)
    return bool(na) and na == nb


def is_platform_caller(ctx: Any) -> bool:
    """A service token or an internal caller, decided from the TOKEN, never from a role NAME (I-79 re-review N1/N2).

    - service token: the verified claims' `sub` starts with "service:" (`auth.is_service_token`); no user token has it.
    - internal caller: `AuthenticatedUser.is_internal`, an attribute set by code, never read from a claim. An
      `IAMContext` has no such attribute, so it never matches there.
    ⛔ Never `"service" in roles`: pantheon-auth puts DB role names into the JWT and accepts any ^[a-z0-9_]+$ name,
    so a super admin could create a role "service" (or "internal_service") and exempt itself."""
    from ..auth import is_service_token
    if getattr(ctx, "is_internal", False) is True:
        return True
    return is_service_token(_user_info(ctx))


def is_exempt(ctx: Any) -> bool:
    """Callers this control never applies to: service tokens and internal callers (`is_platform_caller`, decided
    from the token), and impersonation tokens (their home IS the tenant they act on)."""
    if ctx is None:
        return True
    if is_platform_caller(ctx):
        return True
    return _user_info(ctx).get("token_type") == "impersonation"


def can_cross(ctx: Any) -> bool:
    if hasattr(ctx, "can_cross_tenant"):
        return bool(ctx.can_cross_tenant())
    if hasattr(ctx, "has_cross_tenant_access"):
        return bool(ctx.has_cross_tenant_access())
    return False


# ── what the request is ─────────────────────────────────────────────────────────────────────

def route_template(request: Optional[Request]) -> str:
    """The route TEMPLATE (`/api/v1/alerts/{alert_id}`), never the concrete path with ids in it."""
    if request is None:
        return "unknown"
    route = request.scope.get("route")
    return getattr(route, "path", None) or request.url.path


def _trace_id() -> Optional[str]:
    try:
        from ..tracing.context import get_current_trace_context
        tc = get_current_trace_context()
        if tc and tc.trace_id:
            return str(tc.trace_id)
    except Exception:  # noqa: BLE001 - tracing is optional here
        pass
    try:
        from opentelemetry import trace as otel_trace
        span_ctx = otel_trace.get_current_span().get_span_context()
        if span_ctx and span_ctx.trace_id:
            return format(span_ctx.trace_id, "032x")
    except Exception:  # noqa: BLE001
        pass
    return None


def clean_reason(raw: Optional[str]) -> Optional[str]:
    """Control characters (Unicode category C*) become spaces, whitespace collapses, length is capped.
    None/blank -> None."""
    if not raw:
        return None
    text = "".join(" " if unicodedata.category(ch).startswith("C") else ch for ch in raw)
    text = " ".join(text.split())[:REASON_MAX_CHARS]
    return text or None


def describe(request: Optional[Request], ctx: Any, target_tenant_id: Optional[str], *,
             resource_type: Optional[str] = None, method: Optional[str] = None) -> Optional[CrossTenantAccess]:
    """The record for this request, or None when it is not a cross-tenant request this control covers
    (no target, same tenant, exempt caller, or a caller that cannot cross tenants at all)."""
    if not target_tenant_id or is_exempt(ctx) or not can_cross(ctx):
        return None
    home = home_tenant_of(ctx)
    target = str(target_tenant_id).strip()
    if not home or same_tenant(target, home):
        return None
    headers = request.headers if request is not None else {}
    return CrossTenantAccess(
        actor_user_id=str(getattr(ctx, "user_id", None) or getattr(ctx, "id", None) or "") or None,
        actor_email=getattr(ctx, "email", None),
        home_tenant_id=home,
        target_tenant_id=target,
        method=(method or (request.method if request is not None else "GET")).upper(),
        route=route_template(request),
        trace_id=_trace_id(),
        reason=clean_reason(headers.get(ACT_AS_REASON_HEADER)),
        resource_type=(resource_type or "api_route")[:50],
    )


# ── the act-as rule ─────────────────────────────────────────────────────────────────────────

def check_act_as(request: Optional[Request], access: CrossTenantAccess) -> None:
    """Refuse a cross-tenant WRITE that did not declare act-as for exactly this tenant, with a reason."""
    if not access.is_write:
        return
    declared = (request.headers.get(ACT_AS_TENANT_HEADER) if request is not None else None) or ""
    if declared.strip() != access.target_tenant_id or not access.reason:
        raise HTTPException(status_code=403, detail={
            "error": "act_as_required",
            "message": (f"This {access.method} changes tenant {access.target_tenant_id}, not your own tenant. "
                        f"Declare it: send header {ACT_AS_TENANT_HEADER}: {access.target_tenant_id} and a non-empty "
                        f"{ACT_AS_REASON_HEADER}. CLI: {CLI_HINT}"),
            "target_tenant_id": access.target_tenant_id,
            "declared_tenant_id": declared.strip() or None,
        })


# ── the audit row ───────────────────────────────────────────────────────────────────────────

_dedup_lock = threading.Lock()
_dedup_seen: Dict[Tuple[str, str, str, str], float] = {}
_detached: Set[asyncio.Task] = set()


def _first_in_window(access: CrossTenantAccess) -> bool:
    """True when this (actor, target, method, route) has not been audited by this worker in the window."""
    key = (access.actor_user_id or access.actor_email or "", access.target_tenant_id, access.method, access.route)
    now = time.monotonic()
    with _dedup_lock:
        last = _dedup_seen.get(key)
        if last is not None and now - last < READ_DEDUP_SECONDS:
            return False
        if len(_dedup_seen) >= _DEDUP_MAX_ENTRIES:
            cutoff = now - READ_DEDUP_SECONDS
            for k in [k for k, t in _dedup_seen.items() if t < cutoff]:
                del _dedup_seen[k]
            if len(_dedup_seen) >= _DEDUP_MAX_ENTRIES:
                _dedup_seen.clear()
        _dedup_seen[key] = now
        return True


def _reset_dedup() -> None:
    """Tests only."""
    with _dedup_lock:
        _dedup_seen.clear()


async def _write(access: CrossTenantAccess, extra: Optional[Dict[str, Any]] = None) -> str:
    """The ONE row shape for every cross-tenant event (raises on failure; callers choose fail-open/closed)."""
    from ..audit.security_event import write_security_event
    # `route` / `own_tenant_id` keep the OI-133 row shape ("GET /api/v2/alerts", the caller's home tenant).
    details = {"route": f"{access.method} {access.route}", "route_template": access.route, "method": access.method,
               "own_tenant_id": access.home_tenant_id, "target_tenant_id": access.target_tenant_id,
               "trace_id": access.trace_id, "reason": access.reason, **(extra or {})}
    return await write_security_event(
        action=access.action,
        resource_type=access.resource_type,
        tenant_id=None if access.target_tenant_id == ALL_TENANTS else access.target_tenant_id,
        user_id=access.actor_user_id,
        user_email=access.actor_email,
        caller_tenant_id=access.home_tenant_id,
        request_id=(access.trace_id or None) and access.trace_id[:100],
        details=details,
    )


async def _write_read_best_effort(access: CrossTenantAccess) -> None:
    try:
        await _write(access)
    except Exception as e:  # noqa: BLE001 - reads fail open
        logger.error("cross_tenant.read_audit_failed", route=access.route, method=access.method,
                     target_tenant_id=access.target_tenant_id, actor_user_id=access.actor_user_id, error=str(e))


def _schedule_read(access: CrossTenantAccess, background_tasks: Optional[BackgroundTasks] = None) -> None:
    """Audit a read in a DETACHED task (a strong reference in `_detached` until done), never blocking the request.

    ⛔ I-82: `background_tasks` is accepted and IGNORED. FastAPI runs BackgroundTasks only when the route returns; a
    route that raises (404 on another tenant's id, 403) dropped them, so exactly the probing reads went unrecorded.
    The detached task is independent of the handler's outcome. With no running loop (a sync caller in the
    threadpool) it runs on a daemon thread with its own loop. Holds no DB session (rule B)."""
    del background_tasks
    if not _first_in_window(access):
        return
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None
    if loop is not None:
        task = loop.create_task(_write_read_best_effort(access))
        _detached.add(task)
        task.add_done_callback(_detached.discard)
    else:   # a sync handler in the threadpool: its own short-lived loop on a daemon thread
        threading.Thread(target=lambda: asyncio.run(_write_read_best_effort(access)), daemon=True,
                         name="cross-tenant-read-audit").start()


async def _write_or_refuse(access: CrossTenantAccess) -> None:
    """A write is audited before it runs; no row, no write (fail-closed, Bhakta/lead D2 2026-10-21)."""
    try:
        await _write(access)
    except Exception as e:  # noqa: BLE001
        logger.error("cross_tenant.write_audit_failed", route=access.route, method=access.method,
                     target_tenant_id=access.target_tenant_id, actor_user_id=access.actor_user_id, error=str(e))
        raise HTTPException(status_code=503,
                            detail="Cross-tenant write refused: the audit record could not be written")


# ── the entry points ────────────────────────────────────────────────────────────────────────

async def guard_cross_tenant(request: Optional[Request], ctx: Any, target_tenant_id: Optional[str], *,
                             background_tasks: Optional[BackgroundTasks] = None,
                             resource_type: Optional[str] = None,
                             method: Optional[str] = None) -> Optional[CrossTenantAccess]:
    """THE cross-tenant control (see the module docstring for what it stops and what it does not).

    Returns the record, or None when the request is not cross-tenant. A write without a matching act-as
    declaration raises 403; a write whose audit row cannot be written raises 503. A read never raises."""
    access = describe(request, ctx, target_tenant_id, resource_type=resource_type, method=method)
    if access is None:
        return None
    check_act_as(request, access)
    if access.is_write:
        await _write_or_refuse(access)
    else:
        _schedule_read(access, background_tasks)
    return access


def guard_cross_tenant_sync(ctx: Any, target_tenant_id: Optional[str]) -> Optional[CrossTenantAccess]:
    """The same control for a SYNC call site that has only the user (`resolve_tenant_filter`). The request
    comes from `bind_request` (set by `get_current_user`).

    A read is scheduled exactly like `guard_cross_tenant`'s. A write is checked for act-as, then audited
    fail-closed BEFORE this returns: on this thread when no event loop runs here (a `def` handler in the
    threadpool), else on a short-lived helper thread with its own loop, joined (an `async def` handler such as
    datalake's `DELETE /tables/{name}/drop`; it blocks that loop for one in-cluster call to pantheon-auth, on a
    rare, deliberate super-admin write). The in-process writer (pantheon-auth) is bound to its service loop, so
    there a write on a running loop is refused instead — none exists: auth's `resolve_tenant_filter` routes are
    all GET."""
    request = current_request()
    access = describe(request, ctx, target_tenant_id)
    if access is None:
        return None
    check_act_as(request, access)
    if not access.is_write:
        _schedule_read(access, None)
        return access
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        asyncio.run(_write_or_refuse(access))
        return access
    from ..audit import security_event
    if security_event._local_writer is not None:
        raise HTTPException(status_code=403, detail={
            "error": "act_as_route_not_supported",
            "message": "This route cannot audit a cross-tenant write here; it must use require_act_as (I-65)."})
    _run_on_helper_thread(_write_or_refuse(access))
    return access


def _run_on_helper_thread(coro: Any, timeout: float = 15.0) -> None:
    """Run `coro` to completion on a new thread with its own loop; re-raise what it raised (fail-closed)."""
    outcome: Dict[str, BaseException] = {}

    def _target() -> None:
        try:
            asyncio.run(coro)
        except BaseException as e:  # noqa: BLE001 - re-raised on the caller's thread
            outcome["error"] = e

    worker = threading.Thread(target=_target, daemon=True, name="cross-tenant-write-audit")
    worker.start()
    worker.join(timeout)
    if worker.is_alive():
        raise HTTPException(status_code=503,
                            detail="Cross-tenant write refused: the audit record could not be written")
    if "error" in outcome:
        raise outcome["error"]


async def require_act_as(request: Request, ctx: Any, target_tenant_id: Optional[str], *,
                         resource_type: Optional[str] = None) -> Optional[CrossTenantAccess]:
    """For a WRITE route whose target tenant is NOT the `?tenant_id=` swap (it is in the body, or a differently
    named field). Calls `guard_cross_tenant`, so the rule and the audit row are the same as for the swap."""
    return await guard_cross_tenant(request, ctx, target_tenant_id, resource_type=resource_type)


def act_as_body_tenant(field: str = "tenant_id", *, resource_type: Optional[str] = None) -> Callable:
    """Route dependency: `dependencies=[Depends(act_as_body_tenant())]` on a write route that takes its target
    tenant in the JSON body. Reads the body once (Starlette caches it, so the handler's model still parses) and
    runs before the handler, so no DB session of the handler is open during the audit write."""
    from .api import IAMEndpoint
    from fastapi import Depends

    async def _dependency(request: Request,
                          ctx: Any = Depends(IAMEndpoint.get_iam_context)) -> Optional[CrossTenantAccess]:
        target = None
        try:
            body = await request.json()
            if isinstance(body, dict):
                target = body.get(field)
        except Exception:  # noqa: BLE001 - no/invalid JSON: the handler reports that; nothing to guard
            target = None
        return await require_act_as(request, ctx, str(target) if target else None, resource_type=resource_type)

    return _dependency


def guard_query_tenant(name: str = "tenant", *, resource_type: Optional[str] = None) -> Callable:
    """Dependency for a service whose routes swap tenant on a query parameter OTHER than `tenant_id` (Atlas's
    `?tenant=`, its own `resolve_tenant`). Put it on the router include (`dependencies=[Depends(...)]`): a read
    naming another tenant is recorded, a write needs act-as — the same rule as the `?tenant_id=` swap."""
    from .api import IAMEndpoint
    from fastapi import Depends

    async def _dependency(request: Request, background_tasks: BackgroundTasks,
                          ctx: Any = Depends(IAMEndpoint.get_iam_context)) -> Optional[CrossTenantAccess]:
        target = request.query_params.get(name)
        return await guard_cross_tenant(request, ctx, target, background_tasks=background_tasks,
                                        resource_type=resource_type)

    return _dependency


def audit_all_tenants_read(request: Optional[Request], ctx: Any, *, resource_type: str,
                           route: Optional[str] = None,
                           background_tasks: Optional[BackgroundTasks] = None) -> None:
    """A read across EVERY tenant (an SA list with no `?tenant_id=`). The swap point cannot see it, so the list
    route calls this; same record, target `ALL_TENANTS`."""
    if ctx is None or is_exempt(ctx) or not can_cross(ctx):
        return
    home = home_tenant_of(ctx)
    if not home:
        return
    access = CrossTenantAccess(
        actor_user_id=str(getattr(ctx, "user_id", None) or "") or None, actor_email=getattr(ctx, "email", None),
        home_tenant_id=home, target_tenant_id=ALL_TENANTS, method="GET", route=route or route_template(request),
        trace_id=_trace_id(), reason=None, resource_type=resource_type[:50])
    _schedule_read(access, background_tasks)



# ── I-96: the ONE platform-admin check for super-admin-only routes ──────────────────────────────

#: An all-tenants WRITE declares itself with this header (+ ACT_AS_REASON_HEADER). Deliberately NOT "*" in
#: ACT_AS_TENANT_HEADER: `check_act_as` compares that header for exact equality with ONE tenant, so a single-tenant
#: declaration can never satisfy an all-tenants write and this header never satisfies a single-tenant one (I-95).
ACT_AS_ALL_TENANTS_HEADER = "X-Torana-Act-As-All-Tenants"
CLI_HINT_ALL_TENANTS = "torana --act-as-all-tenants --act-as-reason \"<why>\" ..."


def _get_current_user_dependency() -> Callable:
    from ..auth import get_current_user
    return get_current_user


def _platform_admin_refusal(user: Any) -> Optional[str]:
    """Why `user` is not a platform admin, or None when it is. Pure function (tests and the lint use it)."""
    if user is None:
        return "no authenticated caller"
    if is_platform_caller(user):
        # Review 3: from_token gives a service token roles ["service"] + its SCOPES, so a scope "super_admin" would
        # pass the role test. A service or internal token is never a (human) platform admin.
        return "a service or internal token is not a platform admin"
    if "super_admin" not in _roles(user):
        return "the super_admin role is required"
    if _user_info(user).get("token_type") == "impersonation":
        return "an impersonation token acts as its tenant, not as the platform"
    if not can_cross(user):
        return "the super_admin role of a CUSTOMER tenant does not administer the platform"
    return None


async def require_platform_admin(user: Any = None) -> Any:  # noqa: B008 - default bound below
    """⭐ THE dependency for super-admin-only routes (I-96): the `super_admin` ROLE **and** the platform tenant.

    Mount it on the ROUTER of SA-only routes: `APIRouter(dependencies=[Depends(require_platform_admin)])`. It replaces
    `"super_admin" in user.roles` / `has_role("super_admin")`, which a CUSTOMER tenant's own super_admin also passes
    (OI-28). The platform test is `can_cross` (→ `IAMBootstrapHelper.is_platform_tenant`), the same rule
    `guard_cross_tenant` uses. Service tokens and impersonation tokens are refused: neither is a platform admin.
    Refusal: 403 `platform_admin_required`."""
    reason = _platform_admin_refusal(user)
    if reason:
        raise HTTPException(status_code=403, detail={
            "error": "platform_admin_required",
            "message": f"This is a platform administration route: {reason}.",
        })
    return user


def _bind_platform_admin_signature() -> None:
    """Give `require_platform_admin` its FastAPI dependency default lazily (auth imports iam)."""
    import inspect
    from fastapi import Depends
    sig = inspect.signature(require_platform_admin)
    param = sig.parameters["user"].replace(default=Depends(_get_current_user_dependency()))
    require_platform_admin.__signature__ = sig.replace(parameters=[param])


# ── the named-target guard (moved from agent-builder, I-79): a route that names its target tenant in its OWN
#    parameter ({target_tenant_id}, ?scope_tenant_id=, vm_policy's ?tenant=) instead of the `?tenant_id=` swap ─────

#: Default WIRE names (path first, then query), in priority order. ⛔ Wire names, not Python names: a parameter
#: declared `Query(alias="tenant")` is `tenant` on the wire.
TARGET_TENANT_PARAMS = ("target_tenant_id", "scope_tenant_id")


def named_target_tenant(request: Request, params: Any = TARGET_TENANT_PARAMS) -> Optional[str]:
    """The tenant this request names in one of `params` (path wins over query), else None."""
    for name in params:
        value = request.path_params.get(name) or request.query_params.get(name)
        if value:
            return str(value)
    return None


def refuse_if_cannot_cross(ctx: Any, target: str, request: Optional[Request] = None) -> None:
    """403 `cross_tenant_forbidden` when a caller who CANNOT cross tenants names a tenant other than its own.

    THE rule for a named tenant (one definition): `named_target_guard`, the `?tenant_id=` swap in
    `IAMEndpoint.get_iam_context` and `resolve_tenant_filter` all call it. Naming the caller's OWN tenant is always
    allowed. A caller who can cross (a platform super admin) passes; the caller then records or swaps.

    `describe()` returns None for such a caller (there is no cross-tenant request to record), and handlers that check
    the `super_admin` ROLE would then act on the named tenant: a customer tenant's super_admin (OI-28) or an
    impersonation token reaching another tenant. Not `act_as_required`: no declaration makes it legitimate. Service
    tokens are refused too; only a code-set internal caller (`is_internal`) passes.

    I-100: each refusal logs `cross_tenant.forbidden` (caller kind, token tenant, named tenant, route), so a caller
    that used to be silently served its own tenant shows up in the logs."""
    if ctx is None:
        return
    home = home_tenant_of(ctx)
    if home and same_tenant(target, home):
        return
    if is_platform_caller(ctx):
        # Review 2: pantheon-auth also mints "service:..." tokens FOR A CUSTOMER tenant (CI scan tokens,
        # sub "service:github-ci-scan:<repo>"). A platform service always mints for the tenant it acts on
        # (PantheonClient(tenant_id=...) scopes its token to that tenant, http/client.py `_token_scope`), so a service
        # token naming ANOTHER tenant is refused; only a code-set internal caller (no claims) passes.
        if getattr(ctx, "is_internal", False) is True:
            return
        _refuse_named_tenant(ctx, "service", home, target, request,
                             f"This service token was issued for tenant {home}, not {target}.")
    impersonation = _user_info(ctx).get("token_type") == "impersonation"
    if impersonation or not can_cross(ctx):
        _refuse_named_tenant(ctx, "impersonation" if impersonation else "user", home, target, request,
                             f"This request names tenant {target}, but your account can act only on its own tenant.")


def _refuse_named_tenant(ctx: Any, caller_kind: str, home: Optional[str], target: str,
                         request: Optional[Request], message: str) -> None:
    request = request if request is not None else current_request()
    logger.warning("cross_tenant.forbidden", caller_kind=caller_kind, token_tenant_id=home,
                   named_tenant_id=str(target), route=route_template(request),
                   method=getattr(request, "method", None), user_id=getattr(ctx, "user_id", None) or getattr(ctx, "id", None))
    raise HTTPException(status_code=403, detail={
        "error": "cross_tenant_forbidden",
        "message": message,
        "target_tenant_id": str(target),
    })


def named_target_guard(*, resource_type: str, params: Any = TARGET_TENANT_PARAMS,
                       read_only_endpoints: Any = ()) -> Callable:
    """Router dependency: `APIRouter(dependencies=[Depends(named_target_guard(resource_type=...))])`.

    For every route on the router that names a tenant in one of `params` (wire names):
    - a caller who cannot cross naming another tenant -> 403 `cross_tenant_forbidden` (`refuse_if_cannot_cross`);
    - a WRITE to another tenant -> `guard_cross_tenant`: 403 `act_as_required` without the declaration, else audited
      BEFORE the handler, fail-closed;
    - a READ -> audited by a detached task. `read_only_endpoints` names handlers (`__name__`) that are POSTs which
      only read (a semantic recall): audited as reads, never gated.
    On the ROUTER, so a route added later is covered. It runs before the handler's own dependencies, so no DB
    session of the handler is open during the audit call (rule B)."""
    from .api import IAMEndpoint
    from fastapi import Depends
    names = tuple(params)
    read_only = frozenset(read_only_endpoints)

    async def _named_target_guard(request: Request,
                                  ctx: Any = Depends(IAMEndpoint.get_iam_context)) -> Optional[CrossTenantAccess]:
        target = named_target_tenant(request, names)
        if not target:
            return None
        refuse_if_cannot_cross(ctx, target)
        endpoint = request.scope.get("endpoint")
        method = "GET" if getattr(endpoint, "__name__", None) in read_only else None
        return await guard_cross_tenant(request, ctx, target, resource_type=resource_type, method=method)

    _named_target_guard.is_named_target_guard = True   # lets tests and the lint find it on a route
    _named_target_guard.target_params = names
    return _named_target_guard


def routes_missing_dependency(router: Any, marker: str = "is_named_target_guard") -> list:
    """`METHOD path` of every APIRoute on `router` lacking a dependency whose callable carries `marker`
    (`is_named_target_guard`, or `is_platform_admin` for `require_platform_admin`)."""
    from fastapi.routing import APIRoute
    missing = []
    for route in getattr(router, "routes", []):
        if not isinstance(route, APIRoute):
            continue
        if not any(getattr(dep.dependency, marker, False) for dep in route.dependencies):
            missing.append(f"{','.join(sorted(route.methods))} {route.path}")
    return missing


# ── I-95: a WRITE across ALL tenants needs its own declaration ──────────────────────────────────

def require_act_as_all_tenants(*, resource_type: str) -> Callable:
    """Route dependency for a WRITE that by design acts on EVERY tenant (e.g. a populator run across all tenants).

    - any service or internal token: 403 `platform_admin_required` (review 2: a customer's CI token is "service:...");
    - a caller who cannot cross tenants: 403 `cross_tenant_forbidden` (it may not act on other tenants at all);
    - a crosser who is not a human platform super admin: 403 `platform_admin_required`;
    - otherwise the request must carry `X-Torana-Act-As-All-Tenants: true` AND a non-empty `X-Torana-Act-As-Reason`,
      else 403 `act_as_all_tenants_required`. A single-tenant `X-Torana-Act-As-Tenant` never satisfies it;
    - the write is audited BEFORE the handler, target "*" (`cross_tenant.write`), fail-closed (503)."""
    from .api import IAMEndpoint
    from fastapi import Depends

    async def _require_all_tenants(request: Request,
                                   ctx: Any = Depends(IAMEndpoint.get_iam_context)) -> Optional[CrossTenantAccess]:
        if ctx is None or is_platform_caller(ctx):
            # Review 2: never a service/internal token, whichever tenant minted it (a customer's CI token included).
            raise HTTPException(status_code=403, detail={
                "error": "platform_admin_required",
                "message": "A write across every tenant needs a platform super admin, not a service token.",
            })
        if not can_cross(ctx) or _user_info(ctx).get("token_type") == "impersonation":
            raise HTTPException(status_code=403, detail={
                "error": "cross_tenant_forbidden",
                "message": "This changes every tenant, but your account can act only on its own tenant.",
                "target_tenant_id": ALL_TENANTS,
            })
        refusal = _platform_admin_refusal(ctx)          # a HUMAN platform super admin, not just any crosser
        if refusal:
            raise HTTPException(status_code=403, detail={"error": "platform_admin_required",
                                                         "message": f"A write across every tenant: {refusal}."})
        declared = (request.headers.get(ACT_AS_ALL_TENANTS_HEADER) or "").strip().lower() == "true"
        reason = clean_reason(request.headers.get(ACT_AS_REASON_HEADER))
        if not declared or not reason:
            raise HTTPException(status_code=403, detail={
                "error": "act_as_all_tenants_required",
                "message": (f"This {request.method} changes EVERY tenant. Declare it: send header "
                            f"{ACT_AS_ALL_TENANTS_HEADER}: true and a non-empty {ACT_AS_REASON_HEADER}. "
                            f"CLI: {CLI_HINT_ALL_TENANTS}"),
                "target_tenant_id": ALL_TENANTS,
            })
        access = CrossTenantAccess(
            actor_user_id=str(getattr(ctx, "user_id", None) or getattr(ctx, "id", None) or "") or None,
            actor_email=getattr(ctx, "email", None), home_tenant_id=home_tenant_of(ctx) or "",
            target_tenant_id=ALL_TENANTS, method=request.method.upper(), route=route_template(request),
            trace_id=_trace_id(), reason=reason, resource_type=resource_type[:50])
        await _write_or_refuse(access)
        return access

    _require_all_tenants.is_all_tenants_guard = True
    return _require_all_tenants


_bind_platform_admin_signature()
require_platform_admin.is_platform_admin = True   # lets tests and the lint find it on a route
