"""
IAM Decorators Module

Provides decorators for common IAM patterns to be used across all services.
These decorators simplify the implementation of IAM security in API endpoints.
"""

import functools
from typing import Optional, List, Any, Callable
from fastapi import HTTPException, Depends, Query
from uuid import UUID
from .context import IAMContext
from .api import IAMEndpoint
from .utils import check_tenant_access, check_namespace_access, add_iam_fields_to_response


def require_tenant_access(func: Callable) -> Callable:
    """
    Decorator to ensure the user can access resources in their tenant only.

    This decorator filters a list of resources to only include those belonging
    to the user's tenant. It expects the function to return a list of resources.

    Usage:
        @require_tenant_access
        async def list_resources():
            return backend.get_all_resources()
    """
    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        # Extract iam_context from kwargs
        iam_context = kwargs.get('iam_context')
        if not iam_context:
            # Try to get it from function parameters
            for arg in args:
                if isinstance(arg, IAMContext):
                    iam_context = arg
                    break

        if not iam_context:
            raise HTTPException(
                status_code=500,
                detail="IAM context not found. Ensure endpoint uses IAMEndpoint.get_iam_context dependency."
            )

        # Call the original function
        result = await func(*args, **kwargs)

        # If result is a list, filter by tenant
        if isinstance(result, list):
            filtered_result = []
            for resource in result:
                if isinstance(resource, dict):
                    if check_tenant_access(resource, iam_context):
                        filtered_result.append(add_iam_fields_to_response(resource))
                # Handle SQLAlchemy objects
                elif hasattr(resource, 'tenant_id'):
                    if check_tenant_access({'tenant_id': resource.tenant_id}, iam_context):
                        filtered_result.append(resource)
            result = filtered_result
        # If result is a single resource, check access
        elif isinstance(result, dict):
            if not check_tenant_access(result, iam_context):
                raise HTTPException(
                    status_code=404,
                    detail="Resource not found or access denied"
                )
            result = add_iam_fields_to_response(result)
        # Handle SQLAlchemy objects
        elif hasattr(result, 'tenant_id'):
            if not check_tenant_access({'tenant_id': result.tenant_id}, iam_context):
                raise HTTPException(
                    status_code=404,
                    detail="Resource not found or access denied"
                )

        return result

    return wrapper


def filter_by_namespace(func: Callable) -> Callable:
    """
    Decorator to filter resources by namespace if provided in query parameters.

    This decorator adds optional namespace_id query parameter support to endpoints.
    If namespace_id is provided, it filters the results accordingly.

    Usage:
        @filter_by_namespace
        async def list_resources(
            iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context),
            namespace_id: Optional[UUID] = Query(None)
        ):
            return backend.get_all_resources()
    """
    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        # Extract parameters
        iam_context = kwargs.get('iam_context')
        namespace_id = kwargs.get('namespace_id')

        if not iam_context:
            raise HTTPException(
                status_code=500,
                detail="IAM context not found. Ensure endpoint uses IAMEndpoint.get_iam_context dependency."
            )

        # Call the original function
        result = await func(*args, **kwargs)

        # If namespace_id is provided, filter results
        if namespace_id and isinstance(result, list):
            namespace_id_str = str(namespace_id)
            filtered_result = []
            for resource in result:
                if isinstance(resource, dict):
                    if check_namespace_access(resource, iam_context, namespace_id_str):
                        filtered_result.append(add_iam_fields_to_response(resource))
                # Handle SQLAlchemy objects
                elif hasattr(resource, 'namespace_id'):
                    if check_namespace_access(
                        {'namespace_id': resource.namespace_id},
                        iam_context,
                        namespace_id_str
                    ):
                        filtered_result.append(resource)
            result = filtered_result

        return result

    return wrapper


def validate_iam_ownership(func: Callable) -> Callable:
    """
    Decorator to validate IAM ownership for single resource operations.

    This decorator ensures that operations on single resources (GET, PUT, DELETE)
    are only allowed if the resource belongs to the user's tenant.

    Usage:
        @validate_iam_ownership
        async def get_resource(resource_id: str):
            return backend.get_resource(resource_id)
    """
    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        # Extract iam_context from kwargs
        iam_context = kwargs.get('iam_context')
        if not iam_context:
            for arg in args:
                if isinstance(arg, IAMContext):
                    iam_context = arg
                    break

        if not iam_context:
            raise HTTPException(
                status_code=500,
                detail="IAM context not found. Ensure endpoint uses IAMEndpoint.get_iam_context dependency."
            )

        # Call the original function
        result = await func(*args, **kwargs)

        # Validate ownership
        if result:
            if isinstance(result, dict):
                if not check_tenant_access(result, iam_context):
                    raise HTTPException(
                        status_code=404,
                        detail="Resource not found or access denied"
                    )
                result = add_iam_fields_to_response(result)
            # Handle SQLAlchemy objects
            elif hasattr(result, 'tenant_id'):
                if not check_tenant_access({'tenant_id': result.tenant_id}, iam_context):
                    raise HTTPException(
                        status_code=404,
                        detail="Resource not found or access denied"
                    )
        else:
            raise HTTPException(
                status_code=404,
                detail="Resource not found"
            )

        return result

    return wrapper


def add_iam_context_to_create(func: Callable) -> Callable:
    """
    Decorator to automatically add IAM context to resource creation requests.

    This decorator extracts IAM fields from the context and adds them to the
    resource data before passing it to the backend.

    Usage:
        @add_iam_context_to_create
        async def create_resource(data: ResourceCreateRequest):
            return backend.create_resource(data.dict())
    """
    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        # Extract parameters
        data = kwargs.get('data')
        iam_context = kwargs.get('iam_context')

        if not iam_context:
            for arg in args:
                if isinstance(arg, IAMContext):
                    iam_context = arg
                    break

        if not iam_context:
            raise HTTPException(
                status_code=500,
                detail="IAM context not found. Ensure endpoint uses IAMEndpoint.get_iam_context dependency."
            )

        # Extract namespace_id from data if present
        namespace_id = None
        if hasattr(data, 'namespace_id'):
            namespace_id = data.namespace_id

        # Add IAM fields to data
        from .utils import ensure_iam_fields, extract_iam_fields_from_request

        if hasattr(data, 'dict'):
            # Pydantic model
            data_dict = data.dict()
        else:
            # Regular dict
            data_dict = data

        # Add IAM fields
        iam_fields = extract_iam_fields_from_request(iam_context, namespace_id)
        data_dict.update(iam_fields)

        # Update kwargs with modified data
        kwargs['data'] = data_dict

        # Call the original function
        return await func(*args, **kwargs)

    return wrapper


# Combine decorators for common patterns
def tenant_aware_list(func: Callable) -> Callable:
    """
    Combined decorator for tenant-aware list endpoints.

    This combines @require_tenant_access and @filter_by_namespace
    for common list endpoint patterns.
    """
    return require_tenant_access(filter_by_namespace(func))


def tenant_aware_crud(func: Callable) -> Callable:
    """
    Combined decorator for tenant-aware CRUD operations.

    This applies tenant validation for single resource operations.
    """
    return validate_iam_ownership(func)