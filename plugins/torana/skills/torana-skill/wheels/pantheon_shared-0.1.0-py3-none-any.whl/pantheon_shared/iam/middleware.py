"""
IAM Middleware Module

Provides decorators and middleware functions for enforcing IAM policies
including permission checks, role validation, and tenant isolation.
"""

import functools
import inspect
from typing import List, Optional, Union, Callable, Any
from fastapi import HTTPException, Depends
from fastapi.security import HTTPBearer

from .context import IAMContext, get_iam_context
from ..auth import get_current_user, AuthenticatedUser


security = HTTPBearer(auto_error=False)


class IAMError(Exception):
    """Base exception for IAM-related errors."""
    pass


class PermissionDeniedError(IAMError):
    """Raised when a user lacks required permissions."""
    pass


class RoleRequiredError(IAMError):
    """Raised when a user lacks required roles."""
    pass


class TenantAccessDeniedError(IAMError):
    """Raised when user cannot access a tenant."""
    pass


def require_permissions(
    permissions: Union[str, List[str]],
    require_all: bool = True,
    allow_cross_tenant: bool = False,
    error_message: Optional[str] = None
):
    """
    Decorator to require specific permissions for endpoint access.

    Args:
        permissions: Permission(s) required to access the endpoint
        require_all: If True, user must have all permissions;
                    if False, user needs any one of the permissions
        allow_cross_tenant: If True, allow cross-tenant access for admin permissions
        error_message: Custom error message for denied access

    Returns:
        Decorator function

    Example:
        @require_permissions("users:read")
        @require_permissions(["users:create", "users:read"], require_all=False)
    """
    if isinstance(permissions, str):
        permissions = [permissions]

    def decorator(func: Callable) -> Callable:
        # Check if function is async
        is_async = inspect.iscoroutinefunction(func)

        if is_async:
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                # Extract IAM context from kwargs or create it
                iam_context = kwargs.get('iam_context')
                if not iam_context:
                    # Try to get from authenticated user
                    current_user = kwargs.get('current_user')
                    if not current_user:
                        raise PermissionDeniedError("Authentication required")
                    iam_context = await get_iam_context(current_user)

                # Check cross-tenant access
                if not allow_cross_tenant and not iam_context.can_cross_tenant():
                    # Tenant isolation check will be handled by repository
                    pass

                # Check permissions
                if require_all:
                    if not all(iam_context.has_permission(p) for p in permissions):
                        raise PermissionDeniedError(
                            error_message or f"Required permissions: {', '.join(permissions)}"
                        )
                else:
                    if not any(iam_context.has_permission(p) for p in permissions):
                        raise PermissionDeniedError(
                            error_message or f"One of these permissions required: {', '.join(permissions)}"
                        )

                return await func(*args, **kwargs)
            return async_wrapper
        else:
            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                # Extract IAM context from kwargs or create it
                iam_context = kwargs.get('iam_context')
                if not iam_context:
                    # Try to get from authenticated user
                    current_user = kwargs.get('current_user')
                    if not current_user:
                        raise PermissionDeniedError("Authentication required")
                    # For sync functions, we can't await, so create context synchronously
                    iam_context = IAMContext(
                        user_id=getattr(current_user, 'user_id', str(getattr(current_user, 'sub', ''))),
                        email=getattr(current_user, 'email', ''),
                        tenant_id=getattr(current_user, 'tenant_id', ''),
                        permissions=set(getattr(current_user, 'permissions', [])),
                        roles=getattr(current_user, 'roles', [])
                    )

                # Check permissions
                if require_all:
                    if not all(iam_context.has_permission(p) for p in permissions):
                        raise PermissionDeniedError(
                            error_message or f"Required permissions: {', '.join(permissions)}"
                        )
                else:
                    if not any(iam_context.has_permission(p) for p in permissions):
                        raise PermissionDeniedError(
                            error_message or f"One of these permissions required: {', '.join(permissions)}"
                        )

                return func(*args, **kwargs)
            return sync_wrapper

    return decorator


def require_roles(
    roles: Union[str, List[str]],
    require_all: bool = True,
    check_scope: Optional[str] = None,
    error_message: Optional[str] = None
):
    """
    Decorator to require specific roles for endpoint access.

    Args:
        roles: Role(s) required to access the endpoint
        require_all: If True, user must have all roles;
                    if False, user needs any one of the roles
        check_scope: Optional scope to check (tenant, namespace, platform)
        error_message: Custom error message for denied access

    Returns:
        Decorator function

    Example:
        @require_roles("admin")
        @require_roles(["editor", "viewer"], require_all=False)
    """
    if isinstance(roles, str):
        roles = [roles]

    def decorator(func: Callable) -> Callable:
        # Check if function is async
        is_async = inspect.iscoroutinefunction(func)

        if is_async:
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                # Extract IAM context from kwargs or create it
                iam_context = kwargs.get('iam_context')
                if not iam_context:
                    current_user = kwargs.get('current_user')
                    if not current_user:
                        raise RoleRequiredError("Authentication required")
                    iam_context = await get_iam_context(current_user)

                # Check roles
                if require_all:
                    if not all(iam_context.has_role(r) for r in roles):
                        raise RoleRequiredError(
                            error_message or f"Required roles: {', '.join(roles)}"
                        )
                else:
                    if not any(iam_context.has_role(r) for r in roles):
                        raise RoleRequiredError(
                            error_message or f"One of these roles required: {', '.join(roles)}"
                        )

                # Check scope if specified
                if check_scope:
                    # TODO: Implement scope checking
                    pass

                return await func(*args, **kwargs)
            return async_wrapper
        else:
            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                # Extract IAM context from kwargs or create it
                iam_context = kwargs.get('iam_context')
                if not iam_context:
                    current_user = kwargs.get('current_user')
                    if not current_user:
                        raise RoleRequiredError("Authentication required")
                    iam_context = IAMContext(
                        user_id=getattr(current_user, 'user_id', str(getattr(current_user, 'sub', ''))),
                        email=getattr(current_user, 'email', ''),
                        tenant_id=getattr(current_user, 'tenant_id', ''),
                        roles=getattr(current_user, 'roles', [])
                    )

                # Check roles
                if require_all:
                    if not all(iam_context.has_role(r) for r in roles):
                        raise RoleRequiredError(
                            error_message or f"Required roles: {', '.join(roles)}"
                        )
                else:
                    if not any(iam_context.has_role(r) for r in roles):
                        raise RoleRequiredError(
                            error_message or f"One of these roles required: {', '.join(roles)}"
                        )

                return func(*args, **kwargs)
            return sync_wrapper

    return decorator


def tenant_isolation(func: Callable) -> Callable:
    """
    Decorator to automatically apply tenant filtering to a function.

    This decorator adds tenant_id to kwargs and ensures the function
    operates within the user's tenant scope unless they have cross-tenant access.

    Returns:
        Decorator function
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        # Extract IAM context
        iam_context = kwargs.get('iam_context')
        if not iam_context:
            current_user = kwargs.get('current_user')
            if not current_user:
                raise TenantAccessDeniedError("Authentication required")
            # Create basic context for sync functions
            iam_context = IAMContext(
                user_id=getattr(current_user, 'user_id', str(getattr(current_user, 'sub', ''))),
                email=getattr(current_user, 'email', ''),
                tenant_id=getattr(current_user, 'tenant_id', ''),
                permissions=set(getattr(current_user, 'permissions', []))
            )

        # Add tenant_id to kwargs
        if 'tenant_id' not in kwargs:
            kwargs['tenant_id'] = iam_context.tenant_id

        return func(*args, **kwargs)
    return wrapper


def owner_only(func: Callable) -> Callable:
    """
    Decorator to ensure only resource owners can access the endpoint.

    This requires the resource to have an owner_id field that matches
    the current user's ID.

    Returns:
        Decorator function
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        # Extract IAM context
        iam_context = kwargs.get('iam_context')
        if not iam_context:
            current_user = kwargs.get('current_user')
            if not current_user:
                raise PermissionDeniedError("Authentication required")
            iam_context = IAMContext(
                user_id=getattr(current_user, 'user_id', str(getattr(current_user, 'sub', ''))),
                email=getattr(current_user, 'email', ''),
                tenant_id=getattr(current_user, 'tenant_id', ''),
                permissions=set(getattr(current_user, 'permissions', []))
            )

        # Check ownership for resources that have owner_id
        resource = kwargs.get('resource')
        if resource and hasattr(resource, 'owner_id'):
            if resource.owner_id != iam_context.user_id:
                # Also check if user has admin permissions
                if not iam_context.has_permission('system:admin'):
                    raise PermissionDeniedError("Access denied: Not the resource owner")

        return func(*args, **kwargs)
    return wrapper


# FastAPI dependency providers
def require_permission_dep(
    permission: str,
    error_message: Optional[str] = None
):
    """
    FastAPI dependency for checking a single permission.

    Args:
        permission: The permission required
        error_message: Custom error message

    Returns:
        Dependency function
    """
    def permission_checker(
        iam_context: IAMContext = Depends(get_iam_context)
    ) -> IAMContext:
        if not iam_context.has_permission(permission):
            raise HTTPException(
                status_code=403,
                detail=error_message or f"Permission required: {permission}"
            )
        return iam_context

    return permission_checker


def require_role_dep(
    role: str,
    error_message: Optional[str] = None
):
    """
    FastAPI dependency for checking a single role.

    Args:
        role: The role required
        error_message: Custom error message

    Returns:
        Dependency function
    """
    def role_checker(
        iam_context: IAMContext = Depends(get_iam_context)
    ) -> IAMContext:
        if not iam_context.has_role(role):
            raise HTTPException(
                status_code=403,
                detail=error_message or f"Role required: {role}"
            )
        return iam_context

    return role_checker


# Convert IAM exceptions to HTTP responses
def iam_exception_handler(request, exc):
    """
    Convert IAM exceptions to appropriate HTTP responses.

    Args:
        request: The request object
        exc: The exception

    Returns:
        HTTPException with appropriate status code
    """
    if isinstance(exc, PermissionDeniedError):
        raise HTTPException(
            status_code=403,
            detail=str(exc)
        )
    elif isinstance(exc, RoleRequiredError):
        raise HTTPException(
            status_code=403,
            detail=str(exc)
        )
    elif isinstance(exc, TenantAccessDeniedError):
        raise HTTPException(
            status_code=403,
            detail=str(exc)
        )
    else:
        # Re-raise other exceptions
        raise exc