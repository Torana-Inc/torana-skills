"""
IAM Tenant Filtering Module

Provides unified tenant filtering logic across all Pantheon services.

This module handles the resolution of tenant_id for filtering operations,
respecting both explicit query parameters and cross-tenant access permissions.

The key design principle: tenant filtering is just one filter among many.
This module provides the resolved tenant_id value, which services can then
use in their preferred query pattern (repository, direct SQLAlchemy, etc.).

Usage:
    from pantheon_shared.iam import resolve_tenant_filter

    # In endpoint with AuthenticatedUser
    @router.get("/users")
    async def list_users(
        current_user: AuthenticatedUser = Depends(get_current_user),
        tenant_id: Optional[str] = Query(None, description="Filter by tenant ID (admin only)")
    ):
        filter_tenant_id = resolve_tenant_filter(tenant_id, current_user)
        # Use filter_tenant_id in your query...

    # In endpoint with IAMContext
    @router.get("/apis")
    async def list_apis(
        iam_context: IAMContext = Depends(get_iam_context),
        tenant_id: Optional[str] = Query(None, description="Filter by tenant ID (admin only)")
    ):
        filter_tenant_id = resolve_tenant_filter(tenant_id, iam_context)
        # Use filter_tenant_id in your query...
"""

from typing import Optional, Union
from fastapi import HTTPException

from .context import IAMContext
from ..auth import AuthenticatedUser


def resolve_tenant_filter(
    requested_tenant_id: Optional[str],
    user_context: Union[AuthenticatedUser, IAMContext]
) -> Optional[str]:
    """
    Resolve the effective tenant_id for database filtering operations.

    This function provides consistent tenant filtering behavior across all services,
    supporting both the AuthenticatedUser (pantheon-auth) and IAMContext (other services)
    patterns.

    The resolved tenant_id follows this logic:
    1. If the user has an impersonation token:
       - Always scope to the impersonated tenant_id
       - Ignore cross-tenant access (SA in impersonation mode is scoped)
    2. If tenant_id explicitly provided in query params:
       - Check cross-tenant access permission
       - If allowed: use the explicit tenant_id
       - If not allowed: raise 403 Forbidden
    3. If no tenant_id provided:
       - If user has cross-tenant access: return None (show all tenants)
       - If user doesn't have cross-tenant access: return user's tenant_id

    Cross-tenant access is determined by:
    - IAMContext: Has specific permissions (tenants:read_all, users:read_all, etc.)
                  OR has super_admin/system_admin role
    - AuthenticatedUser: Has admin, super_admin, or system_admin role
                  OR is_internal=True

    This allows:
    - Impersonation tokens to always be scoped to the impersonated tenant
    - Cross-tenant users to see all tenants by default (no filter)
    - Cross-tenant users to filter to specific tenant when needed (?tenant_id=xyz)
    - Regular users to only see their own tenant

    Args:
        requested_tenant_id: Explicit tenant_id from query parameter
        user_context: The user context (AuthenticatedUser or IAMContext)

    Returns:
        - User's tenant_id if using impersonation token (always scoped)
        - Explicit tenant_id if provided AND user has cross-tenant access
        - User's tenant_id if no cross-tenant access
        - None if cross-tenant access and no explicit filter (show all)

    Raises:
        HTTPException 403: If non-admin user requests different tenant

    Example:
        # Endpoint with explicit tenant filter
        filter_tenant_id = resolve_tenant_filter(tenant_id, iam_context)

        # Apply to repository pattern
        result = await repository.get_all(
            cross_tenant=(filter_tenant_id is None)
        )

        # OR apply to direct SQLAlchemy query
        query = select(Model)
        if filter_tenant_id is not None:
            query = query.where(Model.tenant_id == filter_tenant_id)
    """
    # SECURITY: Impersonation tokens are ALWAYS scoped to the impersonated tenant
    # This prevents super-admins in impersonation mode from seeing other tenants
    if _is_impersonation_token(user_context):
        return _get_user_tenant_id(user_context)

    # Explicit tenant_id parameter takes precedence
    if requested_tenant_id:
        user_tenant_id = _get_user_tenant_id(user_context)
        # Requesting your OWN tenant is always allowed — only a DIFFERENT tenant
        # requires cross-tenant access. Normalize to str so a UUID-object vs str
        # (or whitespace) mismatch can't produce a false-positive 403. Without this
        # same-tenant guard, a non-cross-tenant caller that passes its own tenant_id
        # (e.g. when agent-builder's traced_call auto-injects the caller's tenant_id
        # into a tool request) is wrongly rejected as cross-tenant. Mirrors the
        # correct logic in validate_tenant_access() below.
        if str(requested_tenant_id) != str(user_tenant_id):
            if not _can_cross_tenant(user_context):
                raise HTTPException(
                    status_code=403,
                    detail=f"Cross-tenant access not permitted. You belong to tenant {user_tenant_id}"
                )
        return requested_tenant_id

    # No explicit filter
    if not _can_cross_tenant(user_context):
        return _get_user_tenant_id(user_context)

    # Cross-tenant user with no explicit filter → show all
    return None


def _can_cross_tenant(user_context: Union[AuthenticatedUser, IAMContext]) -> bool:
    """
    Check if user can cross tenant boundaries.

    This works with both IAMContext and AuthenticatedUser.

    Args:
        user_context: The user context

    Returns:
        True if user has cross-tenant access, False otherwise
    """
    if user_context is None:
        return False

    if isinstance(user_context, IAMContext):
        # IAMContext has its own can_cross_tenant() method
        # which checks permissions AND super_admin role
        return user_context.can_cross_tenant()
    elif isinstance(user_context, AuthenticatedUser):
        # AuthenticatedUser has has_cross_tenant_access() method
        # which checks admin roles and is_internal flag
        return user_context.has_cross_tenant_access()

    return False


def _is_impersonation_token(user_context: Union[AuthenticatedUser, IAMContext]) -> bool:
    """
    Check if the current token is an impersonation token.

    This is critical for tenant scoping - impersonation tokens should
    ALWAYS be scoped to the impersonated tenant, regardless of the
    original user's cross-tenant access permissions.

    Args:
        user_context: The user context

    Returns:
        True if this is an impersonation token, False otherwise
    """
    if user_context is None:
        return False

    if isinstance(user_context, IAMContext):
        # IAMContext stores token info in user_info
        return user_context.user_info.get("token_type") == "impersonation"
    elif isinstance(user_context, AuthenticatedUser):
        # AuthenticatedUser has is_impersonation_token() method
        return user_context.is_impersonation_token()

    return False


def _get_user_tenant_id(user_context: Union[AuthenticatedUser, IAMContext]) -> Optional[str]:
    """
    Get the user's tenant_id from either context type.

    Args:
        user_context: The user context

    Returns:
        The user's tenant_id or None if not available
    """
    if user_context is None:
        return None

    if isinstance(user_context, IAMContext):
        return user_context.tenant_id
    elif isinstance(user_context, AuthenticatedUser):
        return user_context.tenant_id

    return None


def validate_tenant_access(
    requested_tenant_id: Optional[str],
    user_context: Union[AuthenticatedUser, IAMContext]
) -> None:
    """
    Validate that a user can access the requested tenant.

    This is useful for validating access before performing operations
    that might involve multiple tenants.

    Args:
        requested_tenant_id: The tenant_id being requested
        user_context: The user context

    Raises:
        HTTPException 403: If user cannot access the requested tenant

    Example:
        # Validate before operation
        validate_tenant_access(requested_tenant_id, iam_context)
        # Proceed with operation...
    """
    # Normalize to str so a UUID-object vs str (or whitespace) mismatch can't
    # produce a false-positive cross-tenant 403 when the ids are actually equal.
    if requested_tenant_id and str(requested_tenant_id) != str(_get_user_tenant_id(user_context)):
        if not _can_cross_tenant(user_context):
            raise HTTPException(
                status_code=403,
                detail=f"Cross-tenant access not permitted. You belong to tenant {_get_user_tenant_id(user_context)}"
            )
