"""
IAM Utilities Module

Provides common utility functions for IAM operations across all services.
This module contains reusable helpers for tenant/namespace management,
resource filtering, and IAM context handling.
"""

import uuid
import hashlib
import os
import time
from typing import Optional, Dict, Any, Union
from .context import IAMContext

# Cache for tenant default namespace IDs: {tenant_id: namespace_id}
# Cached indefinitely since default namespace ID never changes for a tenant
_tenant_namespace_cache: Dict[str, str] = {}

# Environment variable to disable caching (for debugging/emergency fixes)
# Set DISABLE_TENANT_NS_CACHE=true to bypass cache
_disable_cache = os.getenv('DISABLE_TENANT_NS_CACHE', 'false').lower() in ('true', '1', 'yes')


def get_or_create_default_namespace_id(iam_context_or_tenant_id: Union[str, IAMContext], db_session=None) -> Optional[str]:
    """
    Get the namespace_id from IAM context or tenant_id, or fetch the tenant's default namespace from the database.

    This utility function queries the namespaces table for the tenant's "default" namespace.
    Each tenant should have a default namespace created when the tenant is created.

    The default namespace ID is cached indefinitely since it never changes for a tenant.
    Cache can be disabled via DISABLE_TENANT_NS_CACHE environment variable for debugging
    or emergency fixes.

    Args:
        iam_context_or_tenant_id: Either an IAMContext instance or a tenant_id string
        db_session: Optional database session for querying namespaces

    Returns:
        Optional[str]: The namespace_id UUID string, or None if not found and db_session is None

    Note: The namespaces are created when a tenant is created by the bootstrap process.
    They MUST exist in the database.
    """
    import logging
    logger = logging.getLogger(__name__)

    # Extract tenant_id from either IAMContext or string
    if isinstance(iam_context_or_tenant_id, str):
        tenant_id = iam_context_or_tenant_id
        iam_context = None
    else:
        iam_context = iam_context_or_tenant_id
        tenant_id = str(iam_context.tenant_id)

    # Check cache first (unless caching is disabled)
    if not _disable_cache:
        if tenant_id in _tenant_namespace_cache:
            return _tenant_namespace_cache[tenant_id]

    # Return namespace_id from IAM context if present
    if iam_context and iam_context.namespace_id:
        # Update cache
        if not _disable_cache:
            _tenant_namespace_cache[tenant_id] = iam_context.namespace_id
        return iam_context.namespace_id

    # If database session is provided, query for the actual default namespace with retries
    if db_session:
        max_retries = 3
        retry_delay = 0.5  # seconds

        for attempt in range(max_retries):
            try:
                from sqlalchemy import text

                # Query the namespaces table for the tenant's default namespace
                query = text("""
                    SELECT id FROM namespaces
                    WHERE tenant_id = :tenant_id AND name = 'default'
                    LIMIT 1
                """)
                result = db_session.execute(query, {"tenant_id": tenant_id})
                row = result.fetchone()
                if row:
                    namespace_id = str(row[0])
                    # Update cache
                    if not _disable_cache:
                        _tenant_namespace_cache[tenant_id] = namespace_id
                    return namespace_id

                # If no row found, this is not a transient error - don't retry
                logger.warning(f"Default namespace not found for tenant {tenant_id} (attempt {attempt + 1}/{max_retries})")
                break

            except Exception as e:
                # Log error and retry if not the last attempt
                if attempt < max_retries - 1:
                    logger.warning(f"Failed to query default namespace for tenant {tenant_id} (attempt {attempt + 1}/{max_retries}): {e}. Retrying in {retry_delay}s...")
                    time.sleep(retry_delay)
                    retry_delay *= 2  # Exponential backoff
                else:
                    logger.error(f"Failed to query default namespace for tenant {tenant_id} after {max_retries} attempts: {e}")
                    raise ValueError(f"Default namespace not found for tenant {tenant_id} after {max_retries} retries. Please ensure the tenant has been properly bootstrapped with a default namespace.") from e

    # No database session provided and no namespace_id in IAM context
    return None


def clear_tenant_namespace_cache() -> None:
    """
    Clear the tenant namespace cache.

    This is primarily useful for testing to ensure clean state between tests.
    In production, the cache should persist for the lifetime of the service.
    """
    global _tenant_namespace_cache
    _tenant_namespace_cache = {}


def get_tenant_namespace_cache_size() -> int:
    """
    Get the current size of the tenant namespace cache.

    Useful for monitoring and debugging.

    Returns:
        int: Number of cached tenant namespace IDs
    """
    return len(_tenant_namespace_cache)


def ensure_iam_fields(obj_data: Dict[str, Any], iam_context: IAMContext,
                     namespace_id: Optional[str] = None) -> Dict[str, Any]:
    """
    Ensure IAM fields are present in object data.

    This utility function adds tenant_id and namespace_id to any
    object data dictionary, ensuring proper ownership tracking.

    Args:
        obj_data: The object data dictionary to update
        iam_context: The IAM context containing tenant information
        namespace_id: Optional namespace_id override

    Returns:
        Dict[str, Any]: The updated object data with IAM fields
    """
    if not obj_data:
        obj_data = {}

    # Always add tenant_id from IAM context
    obj_data['tenant_id'] = iam_context.tenant_id

    # Use provided namespace_id, namespace from context, or generate default
    if namespace_id:
        obj_data['namespace_id'] = namespace_id
    elif iam_context.namespace_id:
        obj_data['namespace_id'] = iam_context.namespace_id
    else:
        obj_data['namespace_id'] = get_or_create_default_namespace_id(iam_context)

    return obj_data


def check_tenant_access(resource: Dict[str, Any], iam_context: IAMContext) -> bool:
    """
    Check if a resource belongs to the user's tenant.

    Args:
        resource: Dictionary containing resource data with tenant_id
        iam_context: The IAM context containing user's tenant information

    Returns:
        bool: True if user can access the resource, False otherwise
    """
    resource_tenant_id = resource.get('tenant_id')
    if not resource_tenant_id:
        return False

    return str(resource_tenant_id) == str(iam_context.tenant_id)


def check_namespace_access(resource: Dict[str, Any], iam_context: IAMContext,
                          namespace_id: Optional[str] = None) -> bool:
    """
    Check if a resource belongs to the specified namespace or user's default namespace.

    Args:
        resource: Dictionary containing resource data with namespace_id
        iam_context: The IAM context containing user's information
        namespace_id: Optional namespace_id to check against

    Returns:
        bool: True if user can access the resource, False otherwise
    """
    # First check tenant access
    if not check_tenant_access(resource, iam_context):
        return False

    # If no specific namespace requested, allow access to any namespace in tenant
    if not namespace_id:
        return True

    resource_namespace_id = resource.get('namespace_id')
    if not resource_namespace_id:
        return False

    return str(resource_namespace_id) == str(namespace_id)


def add_iam_fields_to_response(resource_dict: Dict[str, Any]) -> Dict[str, Any]:
    """
    Ensure IAM fields are properly formatted in API responses.

    This utility function ensures tenant_id and namespace_id are
    properly formatted as strings in API responses.

    Args:
        resource_dict: The resource dictionary from the database

    Returns:
        Dict[str, Any]: The formatted resource dictionary
    """
    if not resource_dict:
        return resource_dict

    # Ensure IAM fields are strings
    if 'tenant_id' in resource_dict and resource_dict['tenant_id']:
        resource_dict['tenant_id'] = str(resource_dict['tenant_id'])

    if 'namespace_id' in resource_dict and resource_dict['namespace_id']:
        resource_dict['namespace_id'] = str(resource_dict['namespace_id'])

    # Ensure is_deleted is boolean
    if 'is_deleted' in resource_dict:
        resource_dict['is_deleted'] = bool(resource_dict['is_deleted'])

    return resource_dict


def extract_iam_fields_from_request(iam_context: IAMContext,
                                   request_namespace_id: Optional[str] = None) -> Dict[str, str]:
    """
    Extract IAM fields from IAM context and request.

    This is a convenience function to extract tenant_id and namespace_id
    for database operations.

    Args:
        iam_context: The IAM context from the authenticated user
        request_namespace_id: Optional namespace_id from the request body/params

    Returns:
        Dict[str, str]: Dictionary with tenant_id and namespace_id
    """
    iam_fields = {
        'tenant_id': iam_context.tenant_id
    }

    if request_namespace_id:
        iam_fields['namespace_id'] = request_namespace_id
    elif iam_context.namespace_id:
        iam_fields['namespace_id'] = iam_context.namespace_id
    else:
        iam_fields['namespace_id'] = get_or_create_default_namespace_id(iam_context)

    return iam_fields
