"""
IAM API Utilities Module

Provides FastAPI dependencies and utilities for implementing
IAM-protected endpoints with consistent patterns.
"""

from typing import List, Optional, Type, TypeVar, Union, TYPE_CHECKING, Any
from uuid import UUID
from fastapi import BackgroundTasks, Depends, Query, HTTPException, Request
from fastapi.security import HTTPBearer

from .context import IAMContext, get_iam_context
from .middleware import require_permissions, require_roles
from ..auth import AuthenticatedUser, get_current_user

if TYPE_CHECKING:
    from .database import IAMRepository


ModelType = TypeVar('ModelType')


security = HTTPBearer(auto_error=False)


class IAMEndpoint:
    """
    Utilities for implementing IAM-protected endpoints.
    """

    @staticmethod
    async def get_iam_context(
        request: Request,
        current_user: AuthenticatedUser = Depends(get_current_user),
        tenant_id: Optional[str] = Query(None, include_in_schema=False),
        namespace_id: Optional[UUID] = Query(None, include_in_schema=False),
        background_tasks: BackgroundTasks = None,   # injected by FastAPI; None when called directly
    ) -> IAMContext:
        """
        Dependency to get IAM context with optional tenant/namespace override.

        NAMESPACE RESOLUTION (in order of priority):
        1. X-Namespace-ID header (for future namespace switching)
        2. namespace_id query parameter (for filtering)
        3. Tenant's "default" namespace (auto-derived from database)

        Args:
            request: FastAPI request for reading headers
            current_user: Authenticated user from token (JWT has tenant_id, NOT namespace_id)
            tenant_id: Optional tenant override (for admins only)
            namespace_id: Optional namespace filter

        Returns:
            IAMContext instance with resolved namespace_id
        """
        # Check for X-Namespace-ID header first (future namespace switching)
        header_namespace_id = request.headers.get("X-Namespace-ID")
        if header_namespace_id:
            try:
                namespace_id = UUID(header_namespace_id)
            except ValueError:
                pass  # Invalid UUID, ignore header

        # Get base context (will auto-derive namespace if None)
        iam_context = await get_iam_context(current_user)

        # Apply namespace from header or query param if provided
        if namespace_id:
            iam_context.namespace_id = str(namespace_id)

        # I-100: naming a tenant you may not act on is a 403, never silently your own tenant
        # (cross_tenant.refuse_if_cannot_cross, the one rule). An internal caller passes: `is_internal` is on
        # the AuthenticatedUser, set by code, and IAMContext does not carry it.
        if tenant_id and getattr(current_user, "is_internal", False) is not True:
            from .cross_tenant import refuse_if_cannot_cross
            refuse_if_cannot_cross(iam_context, tenant_id, request)

        # Apply tenant override if provided and user has cross-tenant access
        if tenant_id and iam_context.can_cross_tenant():
            # ⛔ I-65: THE swap point. Recorded every time; a cross-tenant WRITE must declare act-as
            # (iam/cross_tenant.py says what this stops and what it does not). Raises before the swap.
            from .cross_tenant import guard_cross_tenant
            await guard_cross_tenant(request, iam_context, tenant_id, background_tasks=background_tasks)
            # A31: fall back to None (not the CALLER's iam_context.namespace_id) so
            # IAMContext.__init__ derives the TARGET tenant's own default namespace
            # (context.py:65-67, _derive_namespace_id) — the caller's namespace must
            # never ride along onto a tenant it doesn't belong to.
            # The canonical id, not the request's spelling: an SA naming `AE53...` or `{ae53...}` must filter on the
            # stored `ae53...`, or every query matches nothing (I-100 review). The guard above keeps the request's
            # spelling, so the act-as header comparison (check_act_as) is unchanged.
            from .cross_tenant import normalize_tenant_id
            iam_context = IAMContext(
                user_id=iam_context.user_id,
                email=iam_context.email,
                tenant_id=normalize_tenant_id(tenant_id),
                namespace_id=str(namespace_id) if namespace_id else None,
                roles=iam_context.roles.copy(),
                permissions=iam_context.permissions.copy(),
                # Carry the verified claims: can_cross_tenant() reads the HOME tenant
                # from user_info["tenant_id"], so the platform admin stays one on the
                # tenant it selected (OI-28).
                user_info=dict(iam_context.user_info or {}),
            )

        return iam_context

    @staticmethod
    def get_iam_repository(
        model_class: Type[ModelType],
        iam_context: IAMContext = Depends(get_iam_context)
    ) -> "IAMRepository[ModelType]":
        """
        Get a repository with IAM filtering automatically applied.

        Args:
            model_class: SQLAlchemy model class
            iam_context: IAM context from dependency

        Returns:
            IAMRepository instance
        """
        from ..database import get_db_session  # Lazy import to avoid circular imports
        db_session = get_db_session()
        return IAMRepository(model_class, db_session, iam_context)

    @staticmethod
    def require_permission(
        permission: str,
        error_message: Optional[str] = None
    ):
        """
        Endpoint dependency for permission checking.

        Args:
            permission: Permission required to access the endpoint
            error_message: Custom error message

        Returns:
            IAMContext if permission check passes

        Example:
            @router.get("/users")
            async def list_users(
                iam_context: IAMContext = Depends(IAMEndpoint.require_permission("users:read"))
            ):
                # Implementation here
        """
        def permission_checker(
            # IAMEndpoint.get_iam_context, NOT the bare name: inside a function the bare
            # name is context.get_iam_context(user, db_session) — not a dependency; FastAPI
            # read `user` as a required body and 422'd every GET (OI-28).
            iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)
        ) -> IAMContext:
            if not iam_context.has_permission(permission):
                raise HTTPException(
                    status_code=403,
                    detail=error_message or f"Permission required: {permission}"
                )
            return iam_context

        return permission_checker

    @staticmethod
    def require_role(
        role: str,
        error_message: Optional[str] = None
    ):
        """
        Endpoint dependency for role checking.

        Args:
            role: Role required to access the endpoint
            error_message: Custom error message

        Returns:
            IAMContext if role check passes

        Example:
            @router.post("/admin")
            async def admin_action(
                iam_context: IAMContext = Depends(IAMEndpoint.require_role("admin"))
            ):
                # Implementation here
        """
        def role_checker(
            # IAMEndpoint.get_iam_context, NOT the bare name: inside a function the bare
            # name is context.get_iam_context(user, db_session) — not a dependency; FastAPI
            # read `user` as a required body and 422'd every GET (OI-28).
            iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)
        ) -> IAMContext:
            if not iam_context.has_role(role):
                raise HTTPException(
                    status_code=403,
                    detail=error_message or f"Role required: {role}"
                )
            return iam_context

        return role_checker

    @staticmethod
    def require_any_permission(
        permissions: List[str],
        error_message: Optional[str] = None
    ):
        """
        Endpoint dependency requiring any of the specified permissions.

        Args:
            permissions: List of permissions, any one is sufficient
            error_message: Custom error message

        Returns:
            IAMContext if permission check passes
        """
        def permission_checker(
            # IAMEndpoint.get_iam_context, NOT the bare name: inside a function the bare
            # name is context.get_iam_context(user, db_session) — not a dependency; FastAPI
            # read `user` as a required body and 422'd every GET (OI-28).
            iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)
        ) -> IAMContext:
            if not iam_context.has_any_permission(permissions):
                raise HTTPException(
                    status_code=403,
                    detail=error_message or f"One of these permissions required: {', '.join(permissions)}"
                )
            return iam_context

        return permission_checker

    @staticmethod
    def require_all_permissions(
        permissions: List[str],
        error_message: Optional[str] = None
    ):
        """
        Endpoint dependency requiring all of the specified permissions.

        Args:
            permissions: List of permissions, all are required
            error_message: Custom error message

        Returns:
            IAMContext if permission check passes
        """
        def permission_checker(
            # IAMEndpoint.get_iam_context, NOT the bare name: inside a function the bare
            # name is context.get_iam_context(user, db_session) — not a dependency; FastAPI
            # read `user` as a required body and 422'd every GET (OI-28).
            iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)
        ) -> IAMContext:
            if not iam_context.has_all_permissions(permissions):
                raise HTTPException(
                    status_code=403,
                    detail=error_message or f"All these permissions required: {', '.join(permissions)}"
                )
            return iam_context

        return permission_checker


class IAMQueryParams:
    """
    Standard IAM query parameters for consistent endpoint patterns.

    These parameters can be used across all IAM-protected endpoints
    to provide consistent filtering and pagination.
    """

    def __init__(
        self,
        namespace_id: Optional[UUID] = Query(
            None,
            description="Filter by namespace"
        ),
        include_all_tenants: bool = Query(
            False,
            description="Include all tenants (admin only)"
        ),
        include_deleted: bool = Query(
            False,
            description="Include deleted records"
        ),
        limit: Optional[int] = Query(
            None,
            ge=1,
            le=1000,
            description="Maximum number of items to return"
        ),
        offset: Optional[int] = Query(
            None,
            ge=0,
            description="Number of items to skip for pagination"
        )
    ):
        self.namespace_id = namespace_id
        self.include_all_tenants = include_all_tenants
        self.include_deleted = include_deleted
        self.limit = limit
        self.offset = offset

    def apply_filters(self, query, iam_context: IAMContext):
        """
        Apply IAM filters to a query.

        Args:
            query: SQLAlchemy query to filter
            iam_context: IAM context for permission checking

        Returns:
            Filtered query
        """
        # Apply tenant filtering
        if not self.include_all_tenants or not iam_context.can_cross_tenant():
            # Query will be filtered by repository automatically
            pass

        # Apply namespace filtering if specified
        if self.namespace_id:
            query = query.filter(
                getattr(query.column_descriptions[0]['type'], 'namespace_id') == self.namespace_id
            )

        # Apply deleted flag filtering
        if not self.include_deleted:
            query = query.filter(
                getattr(query.column_descriptions[0]['type'], 'is_deleted') == False
            )

        return query

    def apply_pagination(self, query):
        """
        Apply pagination to a query.

        Args:
            query: SQLAlchemy query to paginate

        Returns:
            Query with pagination applied
        """
        if self.limit:
            query = query.limit(self.limit)
        if self.offset:
            query = query.offset(self.offset)

        return query

    def to_dict(self):
        """Convert query parameters to dictionary."""
        return {
            'namespace_id': self.namespace_id,
            'include_all_tenants': self.include_all_tenants,
            'include_deleted': self.include_deleted,
            'limit': self.limit,
            'offset': self.offset
        }


class IAMPagination:
    """
    Pagination helper for IAM endpoints.
    """

    @staticmethod
    def paginate_response(
        items: List[Any],
        total: int,
        limit: Optional[int] = None,
        offset: Optional[int] = None
    ) -> dict:
        """
        Create a paginated response.

        Args:
            items: List of items to return
            total: Total number of items available
            limit: Limit applied
            offset: Offset applied

        Returns:
            Dictionary with pagination metadata
        """
        response = {
            'items': items,
            'total': total,
            'limit': limit,
            'offset': offset,
            'has_next': False,
            'has_prev': False
        }

        if limit and offset:
            response['has_next'] = offset + limit < total
            response['has_prev'] = offset > 0
        elif limit:
            response['has_next'] = len(items) == limit
            response['has_prev'] = False
        else:
            response['has_next'] = False
            response['has_prev'] = False

        return response

    @staticmethod
    def calculate_pagination(total: int, page: int, page_size: int = 20) -> tuple:
        """
        Calculate pagination parameters.

        Args:
            total: Total number of items
            page: Current page number (1-based)
            page_size: Number of items per page

        Returns:
            Tuple of (offset, limit, total_pages)
        """
        total_pages = (total + page_size - 1) // page_size
        offset = (page - 1) * page_size
        limit = page_size

        return offset, limit, total_pages


# Common dependency providers that can be used directly
def get_current_iam_context() -> IAMContext:
    """
    FastAPI dependency to get current IAM context.
    """
    return Depends(IAMEndpoint.get_iam_context)


def require_permission(permission: str) -> IAMContext:
    """
    FastAPI dependency requiring a specific permission.
    """
    return Depends(IAMEndpoint.require_permission(permission))


def require_role(role: str) -> IAMContext:
    """
    FastAPI dependency requiring a specific role.
    """
    return Depends(IAMEndpoint.require_role(role))