"""
IAM Database Module

Provides database utilities for IAM integration including base models,
repositories, and tenant filtering utilities.
"""

from typing import Type, TypeVar, Optional, List, Any, Dict, Union
from uuid import UUID
from datetime import datetime, timezone

from sqlalchemy import Column, String, ForeignKey, DateTime, Boolean, text, and_, func
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import Session, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.sql import select, update, delete
from pydantic import BaseModel

from .context import IAMContext


T = TypeVar('T')


def _utc_now() -> datetime:
    """Get current UTC datetime using the new timezone-aware API."""
    return datetime.now(timezone.utc)


class IAMModel:
    """
    Mixin class for IAM-enabled database models.

    This mixin adds tenant_id and namespace_id fields to ensure
    all models support multi-tenancy and namespace isolation.
    """

    # Tenant ID for multi-tenancy
    tenant_id = Column(
        PG_UUID(as_uuid=True),
        nullable=False,
        index=True,
        comment="Tenant ID for multi-tenancy"
    )

    # Namespace ID for resource organization within a tenant
    # Every object must belong to both a tenant and a namespace
    namespace_id = Column(
        PG_UUID(as_uuid=True),
        nullable=False,
        index=True,
        comment="Namespace ID for resource organization (required)"
    )

    # Soft delete support
    is_deleted = Column(
        Boolean,
        default=False,
        nullable=False,
        index=True,
        comment="Soft delete flag"
    )

    # Audit fields
    created_at = Column(
        DateTime(timezone=True),
        default=_utc_now,
        nullable=False,
        comment="Creation timestamp"
    )

    updated_at = Column(
        DateTime(timezone=True),
        default=_utc_now,
        nullable=False,
        onupdate=_utc_now,
        comment="Last update timestamp"
    )

    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary."""
        return {
            c.name: getattr(self, c.name)
            for c in self.__table__.columns
        }

    @classmethod
    def get_tenant_filtered_query(
        cls,
        db_session: Union[Session, AsyncSession],
        tenant_id: Optional[str],
        namespace_id: Optional[UUID] = None,
        include_deleted: bool = False
    ) -> Union[Query, any]:
        """
        Get a query or select statement automatically filtered by tenant and optionally namespace.

        Args:
            db_session: Database session (sync or async)
            tenant_id: Tenant ID to filter by (None for system operations)
            namespace_id: Optional namespace ID to filter by
            include_deleted: Whether to include deleted records

        Returns:
            SQLAlchemy Query/Select object with filters applied
        """
        # Build select statement using sqlalchemy.sql.select for both sync and async
        stmt = select(cls)

        # Only filter by tenant_id if it's provided (not None)
        # This allows system operations to access all tenants
        if tenant_id is not None:
            stmt = stmt.where(cls.tenant_id == tenant_id)

        if namespace_id:
            stmt = stmt.where(cls.namespace_id == namespace_id)

        if not include_deleted:
            stmt = stmt.where(cls.is_deleted == False)

        return stmt

    @classmethod
    def get_cross_tenant_query(
        cls,
        db_session: Union[Session, AsyncSession],
        include_deleted: bool = False
    ) -> Union[Query, any]:
        """
        Get a query/Select for cross-tenant access (admin only).

        Args:
            db_session: Database session (sync or async)
            include_deleted: Whether to include deleted records

        Returns:
            SQLAlchemy Query/Select object without tenant filter
        """
        stmt = select(cls)

        if not include_deleted:
            stmt = stmt.where(cls.is_deleted == False)

        return stmt


class IAMRepository:
    """
    Base repository class for IAM-aware database operations.

    This repository provides common CRUD operations with automatic
    tenant isolation and permission checking.
    Supports both sync and async sessions.
    """

    def __init__(
        self,
        model_class: Type[T],
        db_session: Union[Session, AsyncSession],
        iam_context: IAMContext
    ):
        """
        Initialize the repository.

        Args:
            model_class: The SQLAlchemy model class
            db_session: Database session (sync or async)
            iam_context: IAM context for permission checking
        """
        self.model_class = model_class
        self.db = db_session
        self.iam = iam_context
        self._is_async = isinstance(db_session, AsyncSession)

    def get_base_stmt(self, cross_tenant: bool = False) -> any:
        """
        Get base select statement with appropriate tenant filtering.

        Args:
            cross_tenant: Whether to allow cross-tenant access

        Returns:
            SQLAlchemy select statement
        """
        if cross_tenant and self.iam.can_cross_tenant():
            return self.model_class.get_cross_tenant_query(self.db)
        else:
            return self.model_class.get_tenant_filtered_query(
                self.db,
                self.iam.tenant_id,
                self.iam.namespace_id
            )

    def get_base_query(self, cross_tenant: bool = False) -> any:
        """
        Get base select statement (alias for get_base_stmt for backward compatibility).

        Args:
            cross_tenant: Whether to allow cross-tenant access

        Returns:
            SQLAlchemy select statement
        """
        return self.get_base_stmt(cross_tenant)

    async def create(self, obj_data: Dict[str, Any]) -> T:
        """
        Create a new record with automatic tenant assignment.

        Args:
            obj_data: Dictionary with model data

        Returns:
            Created model instance
        """
        # Auto-assign tenant and namespace ownership
        obj_data['tenant_id'] = self.iam.tenant_id
        obj_data['namespace_id'] = self.iam.namespace_id  # Required for all objects

        # Set audit fields only if the model has them
        if hasattr(self.model_class, 'created_by'):
            obj_data['created_by'] = self.iam.user_id

        db_obj = self.model_class(**obj_data)
        self.db.add(db_obj)

        if self._is_async:
            await self.db.commit()
            await self.db.refresh(db_obj)
        else:
            self.db.commit()
            self.db.refresh(db_obj)

        return db_obj

    async def get_by_id(
        self,
        obj_id: UUID,
        cross_tenant: bool = False
    ) -> Optional[T]:
        """
        Get a record by ID with tenant filtering.

        Args:
            obj_id: UUID of the record
            cross_tenant: Whether to allow cross-tenant access

        Returns:
            Model instance or None if not found
        """
        stmt = self.get_base_stmt(cross_tenant).where(
            self.model_class.id == obj_id
        )

        if self._is_async:
            result = await self.db.execute(stmt)
            return result.scalar_one_or_none()
        else:
            result = self.db.execute(stmt)
            return result.scalar_one_or_none()

    async def get_all(
        self,
        cross_tenant: bool = False,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        skip: Optional[int] = None,
        filters: Optional[Dict[str, Any]] = None
    ) -> List[T]:
        """
        Get all records with tenant filtering.

        Args:
            cross_tenant: Whether to allow cross-tenant access
            limit: Optional limit for pagination
            offset: Optional offset for pagination
            skip: Alias for offset (for backward compatibility)
            filters: Optional dictionary of field/value pairs to filter by

        Returns:
            List of model instances
        """
        stmt = self.get_base_stmt(cross_tenant)

        # Apply filters if provided
        if filters:
            for field, value in filters.items():
                if hasattr(self.model_class, field):
                    stmt = stmt.where(getattr(self.model_class, field) == value)

        # Use skip as alias for offset (skip takes precedence)
        pagination_offset = skip if skip is not None else offset
        if pagination_offset is not None:
            stmt = stmt.offset(pagination_offset)
        if limit:
            stmt = stmt.limit(limit)

        if self._is_async:
            result = await self.db.execute(stmt)
            return list(result.scalars().all())
        else:
            result = self.db.execute(stmt)
            return list(result.scalars().all())

    async def update(
        self,
        obj_id: UUID,
        update_data: Dict[str, Any],
        cross_tenant: bool = False
    ) -> Optional[T]:
        """
        Update a record with permission checking.

        Args:
            obj_id: UUID of the record to update
            update_data: Dictionary with fields to update
            cross_tenant: Whether to allow cross-tenant access

        Returns:
            Updated model instance or None if not found
        """
        # Don't allow updating tenant or ownership fields
        restricted_fields = {'tenant_id', 'namespace_id', 'created_by'}
        for field in restricted_fields:
            update_data.pop(field, None)

        # Set audit fields
        update_data['updated_at'] = _utc_now()
        if hasattr(self.model_class, 'updated_by'):
            update_data['updated_by'] = self.iam.user_id

        # First get the object to return it
        obj = await self.get_by_id(obj_id, cross_tenant)
        if not obj:
            return None

        # Build where clause for tenant filtering
        stmt = (
            update(self.model_class)
            .where(self.model_class.id == obj_id)
        )

        # Add tenant filtering for non-cross-tenant updates
        if not cross_tenant:
            if self.iam.tenant_id is not None:
                stmt = stmt.where(self.model_class.tenant_id == self.iam.tenant_id)
            if self.iam.namespace_id:
                stmt = stmt.where(self.model_class.namespace_id == self.iam.namespace_id)

        stmt = stmt.values(**update_data).returning(self.model_class)

        if self._is_async:
            result = await self.db.execute(stmt)
            await self.db.commit()
            # Refresh and return the object
            await self.db.refresh(obj)
        else:
            result = self.db.execute(stmt)
            self.db.commit()
            self.db.refresh(obj)

        return obj

    async def delete(
        self,
        obj_id: UUID,
        hard_delete: bool = False,
        cross_tenant: bool = False
    ) -> bool:
        """
        Delete a record (soft delete by default).

        Args:
            obj_id: UUID of the record to delete
            hard_delete: Whether to hard delete instead of soft delete
            cross_tenant: Whether to allow cross-tenant access

        Returns:
            True if deleted, False if not found
        """
        if hard_delete:
            stmt = delete(self.model_class).where(
                self.model_class.id == obj_id
            )
        else:
            stmt = (
                update(self.model_class)
                .where(self.model_class.id == obj_id)
                .values(
                    is_deleted=True,
                    updated_at=_utc_now(),
                    **({"updated_by": self.iam.user_id} if hasattr(self.model_class, 'updated_by') else {})
                )
            )

        # Add tenant filtering for non-cross-tenant deletes
        if not cross_tenant:
            if self.iam.tenant_id is not None:
                stmt = stmt.where(self.model_class.tenant_id == self.iam.tenant_id)
            if self.iam.namespace_id:
                stmt = stmt.where(self.model_class.namespace_id == self.iam.namespace_id)

        if self._is_async:
            result = await self.db.execute(stmt)
            await self.db.commit()
        else:
            result = self.db.execute(stmt)
            self.db.commit()

        return result.rowcount > 0

    async def filter(
        self,
        filters: Dict[str, Any],
        cross_tenant: bool = False,
        limit: Optional[int] = None,
        offset: Optional[int] = None
    ) -> List[T]:
        """
        Filter records based on criteria.

        Args:
            filters: Dictionary of field/value pairs to filter by
            cross_tenant: Whether to allow cross-tenant access
            limit: Optional limit for pagination
            offset: Optional offset for pagination

        Returns:
            List of filtered model instances
        """
        stmt = self.get_base_stmt(cross_tenant)

        # Apply filters
        for field, value in filters.items():
            if hasattr(self.model_class, field):
                stmt = stmt.where(getattr(self.model_class, field) == value)

        if limit:
            stmt = stmt.limit(limit)
        if offset:
            stmt = stmt.offset(offset)

        if self._is_async:
            result = await self.db.execute(stmt)
            return list(result.scalars().all())
        else:
            result = self.db.execute(stmt)
            return list(result.scalars().all())

    async def count(
        self,
        filters: Optional[Dict[str, Any]] = None,
        cross_tenant: bool = False
    ) -> int:
        """
        Count records matching criteria.

        Args:
            filters: Optional dictionary of field/value pairs to filter by
            cross_tenant: Whether to allow cross-tenant access

        Returns:
            Number of matching records
        """
        stmt = self.get_base_stmt(cross_tenant)

        if filters:
            for field, value in filters.items():
                if hasattr(self.model_class, field):
                    stmt = stmt.where(getattr(self.model_class, field) == value)

        # Convert to count query
        count_stmt = select(func.count()).select_from(stmt.subquery())

        if self._is_async:
            result = await self.db.execute(count_stmt)
            return result.scalar_one()
        else:
            result = self.db.execute(count_stmt)
            return result.scalar_one()

    async def exists(
        self,
        obj_id: UUID,
        cross_tenant: bool = False
    ) -> bool:
        """
        Check if a record exists.

        Args:
            obj_id: UUID of the record to check
            cross_tenant: Whether to allow cross-tenant access

        Returns:
            True if record exists, False otherwise
        """
        return await self.get_by_id(obj_id, cross_tenant) is not None

    def bulk_create(
        self,
        objects_data: List[Dict[str, Any]]
    ) -> List[T]:
        """
        Bulk create multiple records.

        Args:
            objects_data: List of dictionaries with model data

        Returns:
            List of created model instances
        """
        db_objects = []
        for obj_data in objects_data:
            # Auto-assign tenant and namespace ownership
            obj_data['tenant_id'] = self.iam.tenant_id
            obj_data['namespace_id'] = self.iam.namespace_id  # Required for all objects

            # Set audit fields
            if hasattr(self.model_class, 'created_by'):
                obj_data['created_by'] = self.iam.user_id
            obj_data['created_at'] = _utc_now()

            db_obj = self.model_class(**obj_data)
            db_objects.append(db_obj)

        self.db.add_all(db_objects)

        if self._is_async:
            # For async, we need to handle this differently - this is a sync method
            # Raise an error for now
            raise RuntimeError("bulk_create is not supported for AsyncSession. Use create() in a loop.")
        else:
            self.db.commit()

            for db_obj in db_objects:
                self.db.refresh(db_obj)

        return db_objects
