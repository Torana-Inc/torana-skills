"""
IAM Context Module

Provides the IAMContext class for managing user identity, roles, and permissions
with caching support for performance optimization.
"""

import uuid
from typing import List, Optional, Set, Dict, Any, Union
from functools import lru_cache
from datetime import datetime, timedelta, timezone
from pydantic import BaseModel, Field, ConfigDict
from contextvars import ContextVar

from ..auth import AuthenticatedUser


class IAMContext(BaseModel):
    """
    Enhanced user context with IAM capabilities

    This class extends the basic authenticated user with IAM-specific
    functionality including role inheritance, permission resolution,
    and caching for performance.

    NAMESPACE RESOLUTION:
    - If X-Namespace-ID header is provided → use it
    - Else → derive tenant's "default" namespace from database
    - This allows JWT to NOT include namespace_id, avoiding stale tokens
    """

    # Basic user info from AuthenticatedUser
    user_id: str
    email: str
    tenant_id: str
    tenant_name: Optional[str] = None  # Tenant display name
    namespace_id: Optional[str] = None  # Will be derived if not provided

    # IAM-specific fields
    roles: List[str] = Field(default_factory=list)
    permissions: Set[str] = Field(default_factory=set)

    # Original user info from token (for impersonation context and other metadata)
    user_info: Dict[str, Any] = Field(default_factory=dict)

    # Performance optimization
    permissions_cache: Dict[str, bool] = Field(default_factory=dict)
    cache_expiry: Optional[datetime] = None
    cache_ttl: timedelta = Field(default=timedelta(minutes=5))

    # Cross-tenant access flag (cached result)
    _can_cross_tenant_cached: Optional[bool] = None

    model_config = ConfigDict(
        arbitrary_types_allowed=True,
        json_encoders={
            set: lambda v: list(v)
        },
        json_decoders={
            list: lambda v: set(v)
        }
    )

    def __init__(self, **data):
        # Derive namespace_id if not provided
        if 'namespace_id' not in data or data['namespace_id'] is None:
            data['namespace_id'] = self._derive_namespace_id(data.get('tenant_id'))
        super().__init__(**data)
        # Invalidate cache when permissions change
        if self.permissions and not self.cache_expiry:
            self._invalidate_cache()

    @staticmethod
    def _derive_namespace_id(tenant_id: str) -> Optional[str]:
        """
        Derive the default namespace_id for a tenant.

        This queries the database for the tenant's "default" namespace.
        Uses retries to handle transient database errors.

        Args:
            tenant_id: The tenant UUID

        Returns:
            Namespace UUID or None if lookup fails

        Raises:
            ValueError: If namespace cannot be found after retries
        """
        import os
        import time
        import logging
        from sqlalchemy import create_engine, text

        logger = logging.getLogger(__name__)

        # Get auth database URL
        auth_db_url = os.getenv("PANTHEON_AUTH_DATABASE_URL")
        if not auth_db_url:
            # Try to derive from another service's database URL
            for env_key in ["PANTHEON_RAG_DATABASE_URL", "PANTHEON_DATABASE_URL", "DATABASE_URL"]:
                db_url = os.getenv(env_key)
                if db_url:
                    auth_db_url = db_url.rsplit("/", 1)[0] + "/pantheon_auth"
                    if "asyncpg" in auth_db_url:
                        auth_db_url = auth_db_url.replace("+asyncpg", "").replace("postgresql+asyncpg", "postgresql")
                    break

        if not auth_db_url:
            raise ValueError(f"Cannot derive namespace for tenant {tenant_id}: No auth database URL configured")

        # Query for default namespace with retries
        max_retries = 3
        retry_delay = 0.5  # seconds

        for attempt in range(max_retries):
            try:
                # Query for default namespace
                # Set application_name for connection tracking
                app_name = os.getenv("APPLICATION_NAME", "pantheon-service")
                engine = create_engine(
                    auth_db_url,
                    connect_args={
                        "application_name": f"{app_name}-default-namespace-lookup"
                    }
                )
                try:
                    with engine.connect() as conn:
                        result = conn.execute(
                            text("SELECT id FROM namespaces WHERE tenant_id = :tenant_id AND name = 'default' LIMIT 1"),
                            {"tenant_id": str(tenant_id)}
                        ).fetchone()

                        if result:
                            return str(result[0])
                        else:
                            # No namespace found - not a transient error, don't retry
                            logger.warning(f"Default namespace not found for tenant {tenant_id}")
                            break
                finally:
                    engine.dispose()

            except Exception as e:
                # Log error and retry if not the last attempt
                if attempt < max_retries - 1:
                    logger.warning(f"Failed to derive namespace for tenant {tenant_id} (attempt {attempt + 1}/{max_retries}): {e}. Retrying in {retry_delay}s...")
                    time.sleep(retry_delay)
                    retry_delay *= 2  # Exponential backoff
                else:
                    logger.error(f"Failed to derive namespace for tenant {tenant_id} after {max_retries} attempts: {e}")
                    raise ValueError(f"Default namespace not found for tenant {tenant_id} after {max_retries} retries. Please ensure the tenant has been properly bootstrapped with a default namespace.") from e

        return None

    def has_permission(self, permission: str) -> bool:
        """
        Simplified permission check - direct lookup.

        SUPER_ADMIN and PLATFORM_ADMIN roles have hardcoded full access to handle
        bootstrap situations when database might not be ready.

        Based on the simplified IAM architecture with 4 core roles:
        - super_admin: ["*"] - HARDCODED full access (no DB dependency)
        - super_admin: ["*"] - from database
        - tenant_admin: ["integrations:*", "agents:*", "workflow:*", "viz:*", "dashboard:*", "widgets:*", "graph:*", "profile:manage"]
        - tenant_user: ["integrations:read", "agents:read", "workflow:read", "viz:read"]
        - readonly: ["integrations:read", "agents:read", "workflow:read", "viz:read"]
        - namespace_admin: REMOVED - namespaces not exposed in UI

        Args:
            permission: The permission to check (e.g., "integrations:read")

        Returns:
            True if user has the permission, False otherwise
        """
        # Check cache first
        if self._is_cache_valid():
            if permission in self.permissions_cache:
                return self.permissions_cache[permission]
        else:
            self._invalidate_cache()

        # SUPER_ADMIN HARDCODED FULL ACCESS - no database dependency for bootstrap scenarios
        if self.has_role("super_admin"):
            self._cache_permission_result(permission, True)
            return True

        # PLATFORM_ADMIN from database - also has full access
        if self.has_role("super_admin"):
            self._cache_permission_result(permission, True)
            return True

        # Global wildcard permission check (for service accounts)
        if "*" in self.permissions:
            self._cache_permission_result(permission, True)
            return True

        # Direct permission check
        if permission in self.permissions:
            self._cache_permission_result(permission, True)
            return True

        # Wildcard support for resource-level permissions
        if ":" in permission:
            resource, action = permission.split(":", 1)
            wildcard_perm = f"{resource}:*"
            if wildcard_perm in self.permissions:
                self._cache_permission_result(permission, True)
                return True

        # Cache the negative result
        self._cache_permission_result(permission, False)
        return False

    def has_role(self, role: str) -> bool:
        """
        Check if user has a specific role.

        Args:
            role: The role to check

        Returns:
            True if user has the role, False otherwise
        """
        return role in self.roles

    def _is_admin(self) -> bool:
        """
        Check if user has admin privileges.

        Both super_admin and super_admin have access to all permissions in the simplified model.

        Returns:
            True if user has super_admin or super_admin role, False otherwise
        """
        # Both super_admin and super_admin get full access in simplified model
        return self.has_role("super_admin") or self.has_role("super_admin")

    def has_any_permission(self, permissions: List[str]) -> bool:
        """
        Check if user has any of the specified permissions.

        Args:
            permissions: List of permissions to check

        Returns:
            True if user has any of the permissions, False otherwise
        """
        return any(self.has_permission(p) for p in permissions)

    def has_all_permissions(self, permissions: List[str]) -> bool:
        """
        Check if user has all of the specified permissions.

        Args:
            permissions: List of permissions to check

        Returns:
            True if user has all permissions, False otherwise
        """
        return all(self.has_permission(p) for p in permissions)

    def can_cross_tenant(self) -> bool:
        """
        Check if user can access across tenants.

        This is determined by checking for:
        1. Specific cross-tenant permissions (tenants:read_all, users:read_all, etc.)
        2. Admin roles that grant cross-tenant access (super_admin, system_admin)

        This aligns with AuthenticatedUser.has_cross_tenant_access() to ensure
        consistent behavior across services.

        Returns:
            True if user can cross tenant boundaries, False otherwise
        """
        if self._can_cross_tenant_cached is not None:
            return self._can_cross_tenant_cached

        # Check for cross-tenant permissions
        cross_tenant_perms = [
            'tenants:read_all',
            'users:read_all',
            'users:manage_all',
            'system:admin'
        ]

        if any(self.has_permission(p) for p in cross_tenant_perms):
            self._can_cross_tenant_cached = True
            return True

        # Also check for admin roles (for parity with AuthenticatedUser.has_cross_tenant_access())
        # Note: tenant_admin should NOT have cross-tenant access - only platform admins
        admin_roles = ["super_admin", "system_admin"]
        if any(role in self.roles for role in admin_roles):
            self._can_cross_tenant_cached = True
            return True

        self._can_cross_tenant_cached = False
        return False

    def get_tenant_scoped_permissions(self) -> Set[str]:
        """
        Get permissions that are scoped to the current tenant.

        Returns:
            Set of permissions that don't grant cross-tenant access
        """
        return {p for p in self.permissions if not p.endswith('_all')}

    def get_effective_permissions(self, resource: Optional[str] = None) -> Set[str]:
        """
        Get all effective permissions, optionally filtered by resource.

        Args:
            resource: Optional resource to filter permissions for

        Returns:
            Set of effective permissions
        """
        if resource:
            return {p for p in self.permissions if p.startswith(f"{resource}:")}
        return self.permissions.copy()

    def get_effective_roles(self) -> List[str]:
        """
        Get the effective list of roles for the user.

        This includes direct role assignments and any inherited roles
        based on role hierarchy.

        Returns:
            List of effective roles
        """
        return self.roles.copy()

    def add_permission(self, permission: str) -> None:
        """
        Add a permission to the user's context.

        Args:
            permission: The permission to add
        """
        self.permissions.add(permission)
        self._invalidate_cache()

    def remove_permission(self, permission: str) -> None:
        """
        Remove a permission from the user's context.

        Args:
            permission: The permission to remove
        """
        self.permissions.discard(permission)
        self._invalidate_cache()

    def require_permission(self, permission: str) -> None:
        """
        Require a specific permission, raising an exception if not granted.

        This is a convenience method for endpoints that need to enforce
        permission checks programmatically instead of using decorators.

        Args:
            permission: The required permission

        Raises:
            PermissionError: If the user doesn't have the required permission
        """
        if not self.has_permission(permission):
            from fastapi import HTTPException
            raise HTTPException(
                status_code=403,
                detail=f"Permission denied - requires {permission}"
            )

    def add_role(self, role: str) -> None:
        """
        Add a role to the user's context.

        Args:
            role: The role to add
        """
        if role not in self.roles:
            self.roles.append(role)

    def remove_role(self, role: str) -> None:
        """
        Remove a role from the user's context.

        Args:
            role: The role to remove
        """
        if role in self.roles:
            self.roles.remove(role)

    def _is_cache_valid(self) -> bool:
        """Check if the permission cache is still valid."""
        if not self.cache_expiry:
            return False
        return datetime.now(timezone.utc) < self.cache_expiry

    def _invalidate_cache(self) -> None:
        """Invalidate the permission cache."""
        self.permissions_cache.clear()
        self.cache_expiry = None
        self._can_cross_tenant_cached = None

    def _cache_permission_result(self, permission: str, result: bool) -> None:
        """Cache a permission check result."""
        if not self.cache_expiry:
            self.cache_expiry = datetime.now(timezone.utc) + self.cache_ttl
        self.permissions_cache[permission] = result


class UserContextManager:
    """
    Manager for creating and managing IAM contexts.

    This class handles the creation of IAMContext instances
    from authenticated users, including loading roles and permissions
    from the database with caching support.
    """

    @staticmethod
    async def create_context(
        user: AuthenticatedUser,
        db_session = None,
        load_permissions: bool = True,
        load_roles: bool = True
    ) -> IAMContext:
        """
        Create an IAM context from an authenticated user.

        Args:
            user: The authenticated user
            db_session: Database session for loading IAM data
            load_permissions: Whether to load permissions from database
            load_roles: Whether to load roles from database

        Returns:
            An IAMContext instance with the user's IAM data
        """
        # Base context from authenticated user
        # Note: namespace_id will be auto-derived by IAMContext.__init__ if None
        context_data = {
            'user_id': user.id,
            'email': user.email,
            'tenant_id': user.tenant_id,
            'tenant_name': user.tenant_name,
            'namespace_id': user.namespace_id,  # May be None - will be auto-derived to default
            'user_info': user.user_info if hasattr(user, 'user_info') else {}  # Preserve original token claims
        }

        # Load roles and permissions from database if session is provided
        if db_session:
            if load_roles:
                context_data['roles'] = await UserContextManager._load_user_roles(
                    context_data['user_id'],
                    db_session
                )

            if load_permissions:
                # Load permissions directly or derive from roles
                context_data['permissions'] = await UserContextManager._load_user_permissions(
                    context_data['user_id'],
                    context_data.get('roles', []),
                    db_session
                )
        else:
            # Use permissions from JWT token if available
            if hasattr(user, 'permissions'):
                context_data['permissions'] = set(user.permissions or [])
            if hasattr(user, 'roles'):
                context_data['roles'] = user.roles or []

        return IAMContext(**context_data)

    @staticmethod
    async def _load_user_roles(user_id: str, db_session) -> List[str]:
        """
        Load user roles from the database.

        Args:
            user_id: The user ID to load roles for
            db_session: Database session

        Returns:
            List of role names
        """
        try:
            # Query user_roles and roles tables to get active roles for this user
            query = """
                SELECT DISTINCT r.name
                FROM roles r
                JOIN user_roles ur ON r.id = ur.role_id
                WHERE ur.user_id = :user_id
                  AND ur.is_active = true
                  AND r.is_active = true
                  AND (ur.expires_at IS NULL OR ur.expires_at > NOW())
            """

            result = await db_session.execute(query, {"user_id": user_id})
            roles = [row[0] for row in result.fetchall()]
            return roles

        except Exception as e:
            # Log error but don't fail - fall back to empty list
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"Failed to load user roles for {user_id}: {e}")
            return []

    @staticmethod
    async def _load_user_permissions(
        user_id: str,
        roles: List[str],
        db_session
    ) -> Set[str]:
        """
        Load user permissions from the database.

        Args:
            user_id: The user ID to load permissions for
            roles: List of role names
            db_session: Database session

        Returns:
            Set of permission names
        """
        try:
            # If no roles, return empty permissions
            if not roles:
                return set()

            # Query permissions for all roles the user has
            query = """
                SELECT DISTINCT r.permissions
                FROM roles r
                WHERE r.name = ANY(:roles)
                  AND r.is_active = true
            """

            result = await db_session.execute(query, {"roles": roles})
            permission_rows = result.fetchall()

            # Combine all permissions from all roles
            all_permissions = set()
            for row in permission_rows:
                # permissions is stored as JSON
                role_permissions = row[0]
                if isinstance(role_permissions, list):
                    all_permissions.update(role_permissions)

            return all_permissions

        except Exception as e:
            # Log error but don't fail - fall back to empty set
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"Failed to load user permissions for {user_id}: {e}")
            return set()


# Convenience function for creating IAM context
async def get_iam_context(
    user: AuthenticatedUser,
    db_session = None
) -> IAMContext:
    """
    Convenience function to create an IAM context.

    Args:
        user: The authenticated user
        db_session: Optional database session

    Returns:
        An IAMContext instance
    """
    return await UserContextManager.create_context(user, db_session)


# ============================================================================
# ContextVar for request-scoped IAM context (async-safe)
# ============================================================================

# ContextVar for storing IAM context in async-safe manner
_iam_context_var: ContextVar[Optional[IAMContext]] = ContextVar(
    "iam_context", default=None
)


def get_current_iam_context() -> Optional[IAMContext]:
    """
    Get the current IAM context for this async request.

    This uses ContextVar which is async-safe and automatically
    scoped to the current async context (similar to thread-local
    but for async tasks).

    Returns:
        The current IAMContext or None if not set

    Example:
        iam_context = get_current_iam_context()
        if iam_context:
            tenant_id = iam_context.tenant_id
    """
    return _iam_context_var.get()


def set_current_iam_context(iam_context: IAMContext) -> None:
    """
    Set the IAM context for the current async request.

    This is typically called by middleware or endpoint handlers
    to make IAM context available throughout the request lifecycle.

    Args:
        iam_context: The IAM context to set

    Example:
        @router.post("/chat")
        async def chat(iam_context: IAMContext = Depends(IAMEndpoint.get_iam_context)):
            set_current_iam_context(iam_context)
            # Now any code called from here can access the context
    """
    _iam_context_var.set(iam_context)


def clear_current_iam_context() -> None:
    """Clear the IAM context after request completes."""
    _iam_context_var.set(None)