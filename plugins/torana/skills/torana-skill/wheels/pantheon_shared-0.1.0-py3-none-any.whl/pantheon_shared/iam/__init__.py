"""
IAM Module for Pantheon Shared

This module provides comprehensive Identity and Access Management (IAM) functionality
for all pantheon services, including:

- IAMContext: User identity and permission management with caching
- IAMRepository: Database repository with automatic tenant filtering
- IAMEndpoint: FastAPI utilities for IAM-protected endpoints
- IAM middleware: Decorators for permission and role checking
- Tenant filtering: Unified tenant filtering with cross-tenant support
- Database utilities: Mixins and helpers for IAM-enabled models
- Frontend types: TypeScript interfaces for frontend integration

Key Features:
- Multi-tenant architecture with tenant isolation
- Role-based access control (RBAC) with hierarchical permissions
- Permission caching for performance optimization
- Soft delete support with audit trails
- Cross-tenant access for administrators with query parameter support
- Namespace-based resource organization
"""

from .context import (
    IAMContext,
    get_iam_context,
    UserContextManager,
    get_current_iam_context,
    set_current_iam_context,
    clear_current_iam_context,
)
from .database import IAMModel, IAMRepository
from .api import IAMEndpoint, IAMQueryParams, IAMPagination
from .middleware import (
    require_permissions,
    require_roles,
    tenant_isolation,
    owner_only,
    require_permission_dep,
    require_role_dep,
    IAMError,
    PermissionDeniedError,
    RoleRequiredError,
    TenantAccessDeniedError,
    iam_exception_handler
)
from .openapi_extensions import (
    has_permission,
    public_endpoint,
    require_scope,
    merge_extensions,
    create_custom_openapi
)
from .utils import (
    get_or_create_default_namespace_id,
    ensure_iam_fields,
    check_tenant_access,
    check_namespace_access,
    add_iam_fields_to_response,
    extract_iam_fields_from_request,
    clear_tenant_namespace_cache,
    get_tenant_namespace_cache_size
)
from .decorators import (
    require_tenant_access,
    filter_by_namespace,
    validate_iam_ownership,
    add_iam_context_to_create,
    tenant_aware_list,
    tenant_aware_crud
)
from .filtering import (
    resolve_tenant_filter,
    validate_tenant_access as validate_tenant_access_filter
)
from .bootstrap import IAMBootstrapHelper

__all__ = [
    # Core context
    'IAMContext',
    'get_iam_context',
    'UserContextManager',
    'get_current_iam_context',
    'set_current_iam_context',
    'clear_current_iam_context',

    # Database utilities
    'IAMModel',
    'IAMRepository',

    # API utilities
    'IAMEndpoint',
    'IAMQueryParams',
    'IAMPagination',

    # Middleware decorators
    'require_permissions',
    'require_roles',
    'tenant_isolation',
    'owner_only',
    'require_permission_dep',
    'require_role_dep',

    # Exception handling
    'IAMError',
    'PermissionDeniedError',
    'RoleRequiredError',
    'TenantAccessDeniedError',
    'iam_exception_handler',

    # OpenAPI extensions
    'has_permission',
    'public_endpoint',
    'require_scope',
    'merge_extensions',
    'create_custom_openapi',

    # IAM utilities
    'get_or_create_default_namespace_id',
    'ensure_iam_fields',
    'check_tenant_access',
    'check_namespace_access',
    'add_iam_fields_to_response',
    'extract_iam_fields_from_request',
    'clear_tenant_namespace_cache',
    'get_tenant_namespace_cache_size',

    # IAM decorators
    'require_tenant_access',
    'filter_by_namespace',
    'validate_iam_ownership',
    'add_iam_context_to_create',
    'tenant_aware_list',
    'tenant_aware_crud',

    # IAM filtering
    'resolve_tenant_filter',
    'validate_tenant_access_filter',

    # Bootstrap helper
    'IAMBootstrapHelper',
]

# Version information
__version__ = '1.0.0'

# Module metadata
__author__ = 'Pantheon Team'
__description__ = 'Identity and Access Management for Pantheon Services'
