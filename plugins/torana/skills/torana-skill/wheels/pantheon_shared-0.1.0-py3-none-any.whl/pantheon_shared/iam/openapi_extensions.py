"""
OpenAPI extensions for IAM documentation
"""
from typing import Optional, List, Dict, Any, Callable
from dataclasses import dataclass
from fastapi import FastAPI
from fastapi.openapi.utils import get_openapi


@dataclass
class _OpenAPIExtensions:
    """Container for OpenAPI extension data"""
    extensions: Dict[str, Any]

    @property
    def openapi_kwargs(self) -> Dict[str, Any]:
        """Return extensions formatted for FastAPI's openapi_extra parameter"""
        return {"openapi_extra": self.extensions} if self.extensions else {}


def has_permission(
    permission: str,
    scope: Optional[List[str]] = None,
    ownership_check: bool = False,
    permission_description: Optional[str] = None
) -> _OpenAPIExtensions:
    """
    Generate OpenAPI extensions for permission-based access control

    Args:
        permission: Required permission in format "resource:action"
        scope: List of valid scopes for this permission
        ownership_check: Whether ownership validation is required
        permission_description: Human-readable description of the permission

    Returns:
        OpenAPI extensions container
    """
    extensions = {
        "x-permission": permission,
        "x-auth-required": True,
        "x-scope": scope or ["tenant", "namespace"],
        "x-ownership-check": ownership_check
    }

    if permission_description:
        extensions["x-permission-description"] = permission_description

    return _OpenAPIExtensions(extensions)


def public_endpoint() -> _OpenAPIExtensions:
    """
    Generate OpenAPI extensions for public endpoints (no authentication required)

    Returns:
        OpenAPI extensions container
    """
    extensions = {
        "x-auth-required": False,
        "x-scope": ["public"]
    }

    return _OpenAPIExtensions(extensions)


def require_scope(
    scopes: List[str],
    description: Optional[str] = None
) -> _OpenAPIExtensions:
    """
    Generate OpenAPI extensions for scope-based access control

    Args:
        scopes: List of required scopes
        description: Description of scope requirements

    Returns:
        OpenAPI extensions container
    """
    extensions = {
        "x-auth-required": True,
        "x-scope": scopes
    }

    if description:
        extensions["x-scope-description"] = description

    return _OpenAPIExtensions(extensions)


def merge_extensions(*extension_containers: _OpenAPIExtensions) -> _OpenAPIExtensions:
    """
    Merge multiple OpenAPI extension containers

    Args:
        *extension_containers: Variable number of extension containers

    Returns:
        Merged OpenAPI extensions container
    """
    merged_extensions = {}

    for container in extension_containers:
        if container and container.extensions:
            merged_extensions.update(container.extensions)

    return _OpenAPIExtensions(merged_extensions)


def create_custom_openapi(
    app_instance: FastAPI,
    title: str = None,
    description: str = None,
    version: str = None,
    servers: List[Dict[str, str]] = None
) -> Callable:
    """
    Create a custom OpenAPI schema generator that includes permission extensions in the info section.

    This function creates a custom OpenAPI schema generator that enhances the default FastAPI
    OpenAPI generation with comprehensive permission information and security documentation.

    Args:
        app_instance: FastAPI application instance
        title: Optional custom title (defaults to app title if not provided)
        description: Optional custom description (if not provided, includes permission info)
        version: Optional custom version (defaults to app version if not provided)
        servers: Optional list of server URLs (if not provided, includes localhost)

    Returns:
        Custom OpenAPI function that can be assigned to app.openapi

    Example:
        app = FastAPI(title="My Service")
        app.openapi = create_custom_openapi(
            app,
            description="My service with permissions"
        )
    """
    def custom_openapi():
        if app_instance.openapi_schema:
            return app_instance.openapi_schema

        # Use provided values or fall back to app defaults
        final_title = title or getattr(app_instance, 'title', 'API')
        final_version = version or getattr(app_instance, 'version', '1.0.0')

        # Default description with permission information if not provided
        if description:
            final_description = description
        else:
            final_description = f"""
            ## {final_title} API

            ### 🔒 API Permissions Information

            This API includes comprehensive permission information for each endpoint using OpenAPI extensions:

            * **x-permission**: Required permission string (e.g., "integrations:read")
            * **x-auth-required**: Boolean indicating if JWT authentication is required
            * **x-scope**: Array of required scopes ["tenant", "namespace", "global"]
            * **x-ownership-check**: Boolean for resource ownership validation

            The permission information is visible in the endpoint details below and in the raw OpenAPI specification.

            ### Security & Authentication

            This API uses JWT (JSON Web Token) based authentication. Include the token in the Authorization header:

            ```
            Authorization: Bearer <your-jwt-token>
            ```

            ### Permission Scopes

            * **tenant**: Requires tenant-level access
            * **namespace**: Requires namespace-level access
            * **global**: Requires global/system-level access
            * **public**: No authentication required
            """

        openapi_schema = get_openapi(
            title=final_title,
            version=final_version,
            description=final_description,
            routes=app_instance.routes,
            servers=servers or [
                {"url": "http://localhost:8000", "description": "Development server"},
            ],
        )

        # Add permission extensions information to the schema info
        openapi_schema["info"]["x-api-permissions"] = {
            "description": "API permissions and security information",
            "extensions": {
                "x-permission": "Required permission string (e.g., 'resource:action')",
                "x-auth-required": "Boolean indicating if JWT authentication is required",
                "x-scope": "Array of required scopes ['tenant', 'namespace', 'global', 'public']",
                "x-ownership-check": "Boolean for resource ownership validation",
                "x-permission-description": "Human-readable description of the permission"
            },
            "note": "Permission extensions are available for each endpoint in the paths section"
        }

        # Add security scheme information if not already present
        if "components" not in openapi_schema:
            openapi_schema["components"] = {}

        if "securitySchemes" not in openapi_schema["components"]:
            openapi_schema["components"]["securitySchemes"] = {
                "BearerAuth": {
                    "type": "http",
                    "scheme": "bearer",
                    "bearerFormat": "JWT",
                    "description": "JWT token from pantheon-auth service"
                }
            }

        app_instance.openapi_schema = openapi_schema
        return app_instance.openapi_schema

    return custom_openapi