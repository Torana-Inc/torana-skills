"""
LLM-originated SQL rejections: one INFO line + a bounded counter (F6/F7, 2026-10-01 log triage).

An agent guessing a table or column is expected behaviour, not a platform defect. When the call's
origin (`pantheon_shared.http.origin`) is ``llm-tool`` or ``cli-llm``, an emitter (the datalake's
query routes, agent-builder's SQL column guard) logs ONE ``llm_sql_rejected`` INFO line through
`log_llm_sql_rejected` instead of WARN/ERROR, and counts it. A ``code``-originated failure keeps
its WARN/ERROR: that is how a real bug (F19's 42601 from program-framework) stays visible.

Counter: ``llm_sql_rejected_total{agent,table,column}``, per worker process, read through the
shared metrics router (``GET /api/v1/metrics/llm-sql-rejections``).

⚠️ Label cardinality: table and column names come from an LLM, so they are unbounded. Each label
keeps at most `LABEL_CAP` distinct values per process (first come, first kept); anything beyond is
counted under ``other``. Values are lower-cased, reduced to ``[a-z0-9_.]`` and cut to 64 chars.
A known-column allowlist would not work here: a rejected column is by definition not in the schema.
"""

import re
import threading
from typing import Any, Dict, Optional, Tuple

LABEL_CAP = 50
OTHER = "other"
UNKNOWN = "unknown"
EVENT = "llm_sql_rejected"

_SAFE = re.compile(r"[^a-z0-9_.]")
_lock = threading.Lock()
_seen: Dict[str, set] = {"agent": set(), "table": set(), "column": set()}
_counts: Dict[Tuple[str, str, str], int] = {}
_overflowed: Dict[str, int] = {"agent": 0, "table": 0, "column": 0}

# Postgres messages that name the guessed identifier.
_RELATION = re.compile(r'relation "([^"]+)" does not exist', re.IGNORECASE)
_COLUMN = re.compile(r'column "?([A-Za-z0-9_.]+(?:"\."?[A-Za-z0-9_]+)?)"? does not exist',
                     re.IGNORECASE)


def _clean(value: Optional[str]) -> str:
    v = _SAFE.sub("_", str(value or "").strip().lower())[:64]
    return v or UNKNOWN


def _bounded(dim: str, value: Optional[str]) -> str:
    v = _clean(value)
    seen = _seen[dim]
    if v in seen:
        return v
    if len(seen) < LABEL_CAP:
        seen.add(v)
        return v
    _overflowed[dim] += 1
    return OTHER


def record_llm_sql_rejection(agent: Optional[str], table: Optional[str],
                             column: Optional[str], n: int = 1) -> Tuple[str, str, str]:
    """Count one rejection; returns the (bounded) label tuple it was counted under."""
    with _lock:
        key = (_bounded("agent", agent), _bounded("table", table), _bounded("column", column))
        _counts[key] = _counts.get(key, 0) + n
    return key


def llm_sql_rejections_snapshot() -> Dict[str, Any]:
    with _lock:
        rows = [{"agent": a, "table": t, "column": c, "count": n}
                for (a, t, c), n in sorted(_counts.items(), key=lambda kv: -kv[1])]
        return {
            "metric": "llm_sql_rejected_total",
            "labels": ["agent", "table", "column"],
            "label_cap": LABEL_CAP,
            "overflowed_to_other": dict(_overflowed),
            "total": sum(_counts.values()),
            "series": rows,
            "scope": "this worker process",
        }


def reset_llm_sql_rejections() -> None:
    with _lock:
        _counts.clear()
        for dim in _seen:
            _seen[dim].clear()
            _overflowed[dim] = 0


def table_column_from_error(message: Optional[str]) -> Tuple[Optional[str], Optional[str]]:
    """(table, column) named by a Postgres 'does not exist' error; either may be None.

    ``column t.x does not exist`` gives ("t", "x"); ``t`` may be an alias, not a table.
    """
    text = str(message or "")
    m = _RELATION.search(text)
    if m:
        return m.group(1).split(".")[-1], None
    m = _COLUMN.search(text)
    if m:
        ident = m.group(1).replace('"', "")
        if "." in ident:
            qualifier, col = ident.rsplit(".", 1)
            return qualifier.split(".")[-1], col
        return None, ident
    return None, None


def log_llm_sql_rejected(logger: Any, *, origin: str, emitter: str, agent: Optional[str],
                         table: Optional[str], column: Optional[str], reason: str,
                         n: int = 1, **fields: Any) -> None:
    """The ONE INFO line for an LLM-originated SQL rejection, plus the counter.

    The message starts with ``llm_sql_rejected`` and names agent/table/column/origin, so a
    pipeline that drops key/value fields still shows them.

    ``reason`` is the rejection text (cut to 300 chars); never pass headers or tokens in fields.
    """
    labels = record_llm_sql_rejection(agent, table, column, n=n)
    reason = " ".join(str(reason).split())[:300]
    # The message carries the fields itself: Classie's pipeline renders only the event text (F10).
    message = (f"{EVENT} agent={agent or UNKNOWN} table={table or UNKNOWN} "
               f"column={column or UNKNOWN} origin={origin} emitter={emitter}: {reason}")
    logger.info(message, event_name=EVENT, origin=origin, emitter=emitter, agent=agent or UNKNOWN,
                table=table or UNKNOWN, column=column or UNKNOWN,
                metric_labels=dict(zip(("agent", "table", "column"), labels)),
                reason=reason, **fields)
