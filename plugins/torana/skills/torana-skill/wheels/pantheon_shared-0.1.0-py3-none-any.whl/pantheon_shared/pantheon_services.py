"""
Pantheon Service Registry

Centralized registry for all Pantheon microservices with their default configurations.
Services should use this module to get service URLs instead of directly accessing
environment variables.
"""

import os
from enum import Enum
from typing import Optional, Union

from pantheon_shared import get_logger

logger = get_logger(__name__)


class PantheonService(str, Enum):
    """
    Enumeration of all Pantheon microservices.

    Each service has:
    - A canonical name used for environment variable lookups
    - Default service name (docker container name)
    - Default port
    """
    # Core Infrastructure Services
    AUTH = "pantheon-auth"
    WORKFLOW_FRAMEWORK = "pantheon-workflow-framework"
    DATALAKE = "pantheon-datalake"
    INTEGRATION = "pantheon-integration"
    DATA_TRANSFORMERS = "pantheon-data-transformers"
    API_GW = "pantheon-api-gw"

    # Framework Services
    PROGRAM_FRAMEWORK = "pantheon-program-framework"
    DETECTION_FRAMEWORK = "pantheon-detection-framework"

    # User Interface Services
    ADMIN = "pantheon-admin"
    PLAYGROUND = "pantheon-playground"
    VIZ = "pantheon-viz"

    # Specialized Services
    AGENT_BUILDER = "pantheon-agent-builder"
    RAG = "pantheon-rag"

    # Database Services
    POSTGRES = "postgres"
    KEYCLOAK = "keycloak"

    def __str__(self) -> str:
        return self.value


# Service configuration: (service_name_env_var, port_env_var, default_service_name, default_port)
_SERVICE_CONFIG = {
    # Core Infrastructure
    PantheonService.AUTH: (
        "PANTHEON_AUTH_SERVICE",
        "PANTHEON_AUTH_PORT",
        "pantheon-auth",
        "8000"
    ),
    PantheonService.WORKFLOW_FRAMEWORK: (
        "WORKFLOW_FRAMEWORK_SERVICE",
        "WORKFLOW_FRAMEWORK_PORT",
        "pantheon-workflow-framework",
        "8005"
    ),
    PantheonService.DATALAKE: (
        "PANTHEON_DATALAKE_SERVICE",
        "PANTHEON_DATALAKE_PORT",
        "pantheon-datalake",
        "8002"
    ),
    PantheonService.INTEGRATION: (
        "PANTHEON_INTEGRATION_SERVICE",
        "PANTHEON_INTEGRATION_PORT",
        "pantheon-integration",
        "8003"
    ),
    PantheonService.DATA_TRANSFORMERS: (
        "PANTHEON_DATA_TRANSFORMERS_SERVICE",
        "PANTHEON_DATA_TRANSFORMERS_PORT",
        "pantheon-data-transformers",
        "8006"
    ),
    PantheonService.API_GW: (
        "PANTHEON_API_GW_SERVICE",
        "PANTHEON_API_GW_PORT",
        "pantheon-api-gw",
        "8080"
    ),

    # Framework Services
    PantheonService.PROGRAM_FRAMEWORK: (
        "PANTHEON_PROGRAM_FRAMEWORK_SERVICE",
        "PANTHEON_PROGRAM_FRAMEWORK_PORT",
        "pantheon-program-framework",
        "8009"
    ),
    PantheonService.DETECTION_FRAMEWORK: (
        "PANTHEON_DETECTION_FRAMEWORK_SERVICE",
        "PANTHEON_DETECTION_FRAMEWORK_PORT",
        "pantheon-detection-framework",
        "8010"
    ),

    # User Interface Services
    PantheonService.ADMIN: (
        "PANTHEON_ADMIN_SERVICE",
        "PANTHEON_ADMIN_PORT",
        "pantheon-admin",
        "8011"
    ),
    PantheonService.PLAYGROUND: (
        "PANTHEON_PLAYGROUND_SERVICE",
        "PANTHEON_PLAYGROUND_PORT",
        "pantheon-playground",
        "8012"
    ),
    PantheonService.VIZ: (
        "PANTHEON_VIZ_SERVICE",
        "PANTHEON_VIZ_PORT",
        "pantheon-viz",
        "8013"
    ),

    # Specialized Services
    PantheonService.AGENT_BUILDER: (
        "PANTHEON_AGENT_BUILDER_SERVICE",
        "PANTHEON_AGENT_BUILDER_PORT",
        "pantheon-agent-builder",
        "8014"
    ),
    PantheonService.RAG: (
        "PANTHEON_RAG_SERVICE",
        "PANTHEON_RAG_PORT",
        "pantheon-rag",
        "8015"
    ),
}


def get_pantheon_service_url(
    service: Union[PantheonService, str],
    url_env_var: Optional[str] = None
) -> str:
    """
    Get the full URL for a Pantheon service.

    This function looks up service URLs in the following order:
    1. Direct URL environment variable (if url_env_var is provided)
    2. Individual service environment variables (SERVICE_NAME and PORT)
    3. Default service name and port

    Args:
        service: The PantheonService enum or string name of the service
        url_env_var: Optional environment variable name for a direct URL override
                     (e.g., "PANTHEON_AUTH_URL")

    Returns:
        The full URL for the service (e.g., "http://pantheon-auth:8000")

    Raises:
        ValueError: If the service name is not recognized

    Examples:
        >>> from pantheon_shared.pantheon_services import get_pantheon_service_url, PantheonService
        >>> # Using enum
        >>> url = get_pantheon_service_url(PantheonService.AUTH)
        >>> # Using string
        >>> url = get_pantheon_service_url("pantheon-auth")
        >>> # With URL override
        >>> url = get_pantheon_service_url(PantheonService.AUTH, url_env_var="PANTHEON_AUTH_URL")
    """
    # Convert string to enum if needed
    if isinstance(service, str):
        try:
            # Try to find by enum value
            service = PantheonService(service)
        except ValueError:
            # Try to find by case-insensitive match
            service_lower = service.lower().replace("-", "_").replace(" ", "_")
            for s in PantheonService:
                if s.value.lower().replace("-", "_") == service_lower:
                    service = s
                    break
            else:
                raise ValueError(
                    f"Unknown Pantheon service: '{service}'. "
                    f"Valid services are: {', '.join([s.value for s in PantheonService])}"
                )

    # Check for direct URL override first
    if url_env_var:
        url = os.getenv(url_env_var)
        if url:
            logger.debug(f"Using direct URL from {url_env_var}: {url}")
            return url

    # Get service configuration
    if service not in _SERVICE_CONFIG:
        raise ValueError(
            f"Service '{service}' is not configured. "
            f"Valid services are: {', '.join([s.value for s in _SERVICE_CONFIG.keys()])}"
        )

    service_name_env, port_env, default_service_name, default_port = _SERVICE_CONFIG[service]

    # Build URL from environment variables or defaults
    service_host = os.getenv(service_name_env, default_service_name)
    service_port = os.getenv(port_env, default_port)
    url = f"http://{service_host}:{service_port}"

    logger.debug(f"Resolved {service.value} URL: {url}")
    return url


def get_pantheon_service_urls() -> dict[PantheonService, str]:
    """
    Get URLs for all configured Pantheon services.

    Returns:
        Dictionary mapping PantheonService enums to their URLs

    Examples:
        >>> from pantheon_shared.pantheon_services import get_pantheon_service_urls
        >>> urls = get_pantheon_service_urls()
        >>> auth_url = urls[PantheonService.AUTH]
    """
    return {service: get_pantheon_service_url(service) for service in PantheonService}
