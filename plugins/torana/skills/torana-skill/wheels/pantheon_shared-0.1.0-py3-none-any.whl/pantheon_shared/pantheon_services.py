"""
Pantheon Service Registry

Centralized registry for all Pantheon microservices with their default configurations.
Services should use this module to get service URLs instead of directly accessing
environment variables.
"""

import os
from enum import Enum
from typing import Optional, Union

from pantheon_shared import get_logger

logger = get_logger(__name__)


class PantheonService(str, Enum):
    """
    Enumeration of all Pantheon microservices.

    Each service has:
    - A canonical name used for environment variable lookups
    - Default service name (docker container name)
    - Default port
    """
    # Core Infrastructure Services
    AUTH = "pantheon-auth"
    WORKFLOW_FRAMEWORK = "pantheon-workflow-framework"
    DATALAKE = "pantheon-datalake"
    INTEGRATION = "pantheon-integration"
    DATA_TRANSFORMERS = "pantheon-data-transformers"
    API_GW = "pantheon-api-gw"

    # Framework Services
    PROGRAM_FRAMEWORK = "pantheon-program-framework"
    DETECTION_FRAMEWORK = "pantheon-detection-framework"

    # User Interface Services
    ADMIN = "pantheon-admin"
    PLAYGROUND = "pantheon-playground"
    VIZ = "pantheon-viz"

    # Specialized Services
    AGENT_BUILDER = "pantheon-agent-builder"
    RAG = "pantheon-rag"
    SDG = "pantheon-sdg"

    # Database Services
    POSTGRES = "postgres"
    KEYCLOAK = "keycloak"

    def __str__(self) -> str:
        return self.value


#: The ONE place a service's address comes from: its ``*_SERVICE_URL`` environment
#: variable. ⛔ No host/port defaults in code. They drifted from pantheon-deploy/.env and
#: were masked only while the env var was set: this table defaulted AUTH to :8000
#: (real 8012), VIZ to :8013 (8004) and AGENT_BUILDER to :8014 (8010), and
#: `PantheonClient(target_service=…)` never read `*_SERVICE_URL` at all. A missing
#: variable is a deployment defect, so it raises naming the variable rather than
#: silently dialling a guessed address. Every var below is set in pantheon-deploy/.env
#: (→ Compose and the GKE render) and classie-env-files/.env.
SERVICE_URL_ENV: dict[PantheonService, str] = {
    PantheonService.AUTH: "AUTH_SERVICE_URL",
    PantheonService.WORKFLOW_FRAMEWORK: "WORKFLOW_SERVICE_URL",
    PantheonService.DATALAKE: "DATALAKE_SERVICE_URL",
    PantheonService.INTEGRATION: "INTEGRATION_SERVICE_URL",
    PantheonService.DATA_TRANSFORMERS: "TRANSFORMERS_SERVICE_URL",
    PantheonService.API_GW: "API_GW_SERVICE_URL",
    PantheonService.PROGRAM_FRAMEWORK: "PROGRAM_SERVICE_URL",
    PantheonService.DETECTION_FRAMEWORK: "DETECTION_SERVICE_URL",
    PantheonService.ADMIN: "ADMIN_SERVICE_URL",
    PantheonService.VIZ: "VIZ_SERVICE_URL",
    PantheonService.AGENT_BUILDER: "AGENT_BUILDER_SERVICE_URL",
    PantheonService.RAG: "RAG_SERVICE_URL",
    PantheonService.SDG: "SDG_SERVICE_URL",
}


class ServiceUrlNotConfigured(ValueError):
    """A service's ``*_SERVICE_URL`` variable is unset or empty."""


def require_service_url(env_var: str) -> str:
    """The value of one ``*_SERVICE_URL`` variable, without a trailing slash.

    Raises ServiceUrlNotConfigured when it is unset or empty: never a guessed default.
    """
    url = (os.getenv(env_var) or "").strip().rstrip("/")
    if not url:
        raise ServiceUrlNotConfigured(
            f"{env_var} is not set. Service addresses come ONLY from *_SERVICE_URL "
            "variables: set it in pantheon-deploy/.env (Compose + GKE) and "
            "pantheon-deploy/classie-env-files/.env."
        )
    return url


def _as_service(service: Union[PantheonService, str]) -> PantheonService:
    if isinstance(service, PantheonService):
        return service
    try:
        return PantheonService(service)
    except ValueError:
        wanted = service.lower().replace("-", "_").replace(" ", "_")
        for s in PantheonService:
            if s.value.lower().replace("-", "_") == wanted:
                return s
    raise ValueError(
        f"Unknown Pantheon service: '{service}'. "
        f"Valid services are: {', '.join(s.value for s in SERVICE_URL_ENV)}"
    )


def get_pantheon_service_url(
    service: Union[PantheonService, str],
    url_env_var: Optional[str] = None
) -> str:
    """The base URL of a Pantheon service, from its ``*_SERVICE_URL`` variable.

    Args:
        service: The PantheonService enum or its string value.
        url_env_var: Read this variable instead of the service's canonical one.

    Raises:
        ServiceUrlNotConfigured: the variable is unset or empty.
        ValueError: the service is unknown or has no ``*_SERVICE_URL`` (e.g. POSTGRES).

    Examples:
        >>> get_pantheon_service_url(PantheonService.AUTH)   # reads AUTH_SERVICE_URL
    """
    svc = _as_service(service)
    env_var = url_env_var or SERVICE_URL_ENV.get(svc)
    if not env_var:
        raise ValueError(f"'{svc.value}' has no *_SERVICE_URL; it is not an HTTP service")
    return require_service_url(env_var)


def get_pantheon_service_urls() -> dict[PantheonService, str]:
    """Base URLs of every HTTP service in SERVICE_URL_ENV (raises if any is unset)."""
    return {service: get_pantheon_service_url(service) for service in SERVICE_URL_ENV}
