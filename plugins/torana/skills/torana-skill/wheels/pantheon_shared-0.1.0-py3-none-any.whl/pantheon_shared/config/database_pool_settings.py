import os
from typing import ClassVar
from pydantic import BaseModel, model_validator


class DatabasePoolSettings(BaseModel):
    _service_prefix: ClassVar[str] = ""

    database_pool_size: int = 5
    database_max_overflow: int = 10
    # Seconds a caller waits for a free pooled connection before failing fast
    # (vs. stalling ~30s). Mirrors the DATABASE_POOL_TIMEOUT env default used in
    # pantheon_shared/database.py. Added because callers (e.g. agent-builder
    # core/database.py) read settings.database_pool_timeout.
    database_pool_timeout: int = 10

    @model_validator(mode="before")
    @classmethod
    def apply_pool_cascade(cls, values):
        prefix = cls._service_prefix
        if prefix:
            svc_pool = os.environ.get(f"{prefix}_DATABASE_POOL_SIZE")
            svc_overflow = os.environ.get(f"{prefix}_DATABASE_MAX_OVERFLOW")
            svc_timeout = os.environ.get(f"{prefix}_DATABASE_POOL_TIMEOUT")
            if svc_pool:
                values.setdefault("database_pool_size", int(svc_pool))
            if svc_overflow:
                values.setdefault("database_max_overflow", int(svc_overflow))
            if svc_timeout:
                values.setdefault("database_pool_timeout", int(svc_timeout))
        base_pool = os.environ.get("DATABASE_POOL_SIZE")
        base_overflow = os.environ.get("DATABASE_MAX_OVERFLOW")
        base_timeout = os.environ.get("DATABASE_POOL_TIMEOUT")
        if base_pool:
            values.setdefault("database_pool_size", int(base_pool))
        if base_overflow:
            values.setdefault("database_max_overflow", int(base_overflow))
        if base_timeout:
            values.setdefault("database_pool_timeout", int(base_timeout))
        return values
