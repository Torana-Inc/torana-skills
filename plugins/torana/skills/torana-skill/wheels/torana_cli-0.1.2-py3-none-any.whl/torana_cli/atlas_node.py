"""torana atlas node <PATH> … — instance operations on one Atlas node, run, exclusion or enrolment.

Collection operations (tree, nodes list, runs list, …) are in atlas.py.

PATH is the node's path in the tree, slashes included (`code/acme/api`, `runtime/gcp-prod`); it is
sent as-is because the routes take `{path:path}`.

Spec: pantheon-knowledge/docs/design/SURFACES.md § D5.2 / § D5.3.
"""

import click

from torana_cli.atlas import (
    _call, _client, _fmt, already_building, extract_tar, hidden_hint, human_time, is_hidden_error,
    report_written, say_already_building, say_trace, snapshot_state_label, state_line, version_hidden_label,
    wait_for_run,
    wait_options,
)
from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, handle_api_error, handle_auth_error
from torana_cli.confirm import confirm as _confirm
from torana_cli.output import output


def _node_path(ctx) -> str:
    return (ctx.obj.get("_atlas_node_path", "") if ctx.obj else "").strip("/")


def _node_url(ctx, suffix: str = "") -> str:
    return f"atlas/nodes/{_node_path(ctx)}{suffix}"


def _keep_tenant(ctx, _param, value):
    if value:
        ctx.ensure_object(dict)
        ctx.obj["_atlas_tenant"] = value
    return value


#: `--tenant` on every instance leaf: the API takes `?tenant=` (SA only, an enrolled tenant for writes).
tenant_option = click.option("--tenant", default=None, expose_value=False, callback=_keep_tenant,
                             help="Act on another tenant's node (SA only).")


def _scope(ctx, params: dict | None = None) -> dict | None:
    """`params` plus `tenant` when --tenant was given; None when there is nothing to send."""
    out = dict(params or {})
    tenant = ctx.obj.get("_atlas_tenant") if ctx.obj else None
    if tenant:
        out["tenant"] = tenant
    return out or None


# ---------------------------------------------------------------------------
# torana atlas node <PATH>
# ---------------------------------------------------------------------------

@click.group(name="node", invoke_without_command=True)
@click.argument("node_path", metavar="PATH")
@click.pass_context
def node(ctx, node_path):
    """Operate on one Atlas node by path (slashes included).

    Reads need atlas:read; rebuild, suppress and restore need atlas:admin.

    \b
    Examples:
      torana atlas node code/acme/api get
      torana atlas node code/acme/api diff --from 3 --to 4
    """
    ctx.ensure_object(dict)
    ctx.obj["_atlas_node_path"] = node_path
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@node.command(name="get")
@tenant_option
@click.pass_context
def node_get(ctx):
    """Get the node: whether it is selected and failing, the last run's error, state, tier, inputs (and whether each
    moved), current version, edges, open questions.

    \b
    Examples:
      torana atlas node code/acme/api get
      torana atlas node code/acme/api get --json
    """
    fmt, _, fields = _fmt(ctx)
    data = _call(_client(ctx).get, _node_url(ctx), params=_scope(ctx))
    status = (node_status_lines(_node_path(ctx), data.get("node") or {}, data.get("current"),
                                code=data.get("code"), skill=data.get("skill")) if isinstance(data, dict) else "")
    if fmt == "text" and not fields and status:
        click.echo(status)
    output(data, fmt=fmt, fields=fields)


def node_status_lines(path: str, node: dict, current: dict | None = None, *, code: dict | None = None,
                      skill: dict | None = None) -> str:
    """`selected`, `failing` and `last_run_error` in words, above the detail (new on the node row, OI-30/OI-33).
    `failing` is optional until every server sends it. A current version consent hides says so first (OI-166).
    OI-180: the server's two lines, "Code facts" (the model-free snapshot) and "Skill" (the written version), first."""
    lines = [ln for ln in (state_line("Code facts", code), state_line("Skill", skill)) if ln]
    if (current or {}).get("hidden"):
        lines.append(f"{version_hidden_label(current)}: version {current.get('version')} is not readable")
    if node.get("skill_name"):                            # the folder name an agent sees: `torana atlas skill NAME`
        lines.append(f"skill name: {node['skill_name']}")
    if node.get("index_card"):                            # the one-paragraph card its parent index shows
        lines.append(f"index card: {node['index_card']}")
    if "selected" not in node:                           # root/category, or a server without selection yet
        pass
    elif node["selected"]:
        lines.append("selected: yes")
    else:
        lines.append(f"selected: no — nothing is written until it is (torana atlas selection add {path})")
    if node.get("failing"):
        lines.append("failing: yes — selected, and its latest run since selection failed")
    elif node.get("failing") is False and node.get("selected"):
        lines.append("failing: no")
    if node.get("last_run_error"):
        lines.append(f"last run error: {node['last_run_error']}")
    return "\n".join(lines) + "\n" if lines else ""


@node.command(name="log")
@tenant_option
@click.pass_context
def node_log(ctx):
    """List the node's versions, newest first: when built, by which harness and model, at what cost.

    \b
    Examples:
      torana atlas node code/acme/api log
    """
    fmt, raw, fields = _fmt(ctx)
    data = _call(_client(ctx).get, _node_url(ctx, "/versions"), params=_scope(ctx))
    columns = [
        ("version", "VER", 4), ("built_at", "BUILT", 20), ("harness", "HARNESS", 18), ("model", "MODEL", 20),
        ("content_unchanged", "UNCHANGED", 9), ("published", "PUBLISHED", 9), ("cost_usd", "COST USD", 8),
    ]
    items = data.get("items") if isinstance(data, dict) else None
    if fmt not in ("json", "yaml") and items:           # JSON keeps the API shape; only the table gets flat cells
        # BUILDER_PROFILES § 3.4.2 / B3: a tenant is served no trial version, so TRIAL and LINE (spend line) appear only
        # when the answer carries them (a trial row or a platform line); PROFILE shows whenever a version recorded one.
        flat = [{**i, "profile_name": (i.get("profile") or {}).get("name"),
                 "hidden_label": version_hidden_label(i)} for i in items]
        if any(i.get("hidden") for i in items):         # OI-166/169: the row stays, its content is not readable
            columns.append(("hidden_label", "CONSENT", 56))
        privileged = any(i.get("trial") or i.get("spend_line") == "platform" for i in items)
        columns.append(("profile_name", "PROFILE", 24))
        if privileged:
            columns += [("trial", "TRIAL", 5), ("spend_line", "LINE", 8)]
        data = {**data, "items": flat}
    output(data, fmt=fmt, raw=raw, fields=fields, columns=columns)


@node.command(name="show")
@click.option("--version", "version", type=click.IntRange(min=1), default=None,
              help="Version number (default: the current one).")
@click.option("--file", "file_path", default=None,
              help="Print this file of the version (a path inside the node, e.g. SKILL.md or facts/usage.json).")
@click.option("--term", "terms", multiple=True, metavar="FIELD:VALUE",
              help="With --file on a fact file (current version only): just the records matching this "
                   "(repeatable; a bare value is expanded). A file that cannot be sliced comes back whole.")
@click.option("--header", "header", is_flag=True, default=False,
              help="With --file index/imports.json or index/callgraph.json: only the code index header and counts "
                   "(files, languages, parse failures, defs, entry points, import sites). Without it the whole index "
                   "is fetched, which can be megabytes. Reads the latest code snapshot unless --version is given.")
@click.option("--snapshot", "snapshot", type=click.IntRange(min=1), default=None,
              help="Read this code snapshot (model-free facts and index at one commit) instead of a skill version.")
@tenant_option
@click.pass_context
def node_show(ctx, version, file_path, terms, header, snapshot):
    """Show the node's files, or with --file the body of one file.

    Without --version: the node as it is NOW, which is its current version or, for the root and category
    nodes, a render of their children made at read time (they have no versions). With --snapshot: one code
    snapshot, the facts, anchors and code index Atlas computed without the model at one commit.

    \b
    Examples:
      torana atlas node code/acme/api show
      torana atlas node code show --file facts/children.yaml
      torana atlas node code/acme/api show --version 3 --file SKILL.md
      torana atlas node code/acme/api show --file facts/usage.json --term package:litellm
      torana atlas node code/acme/api show --file index/imports.json --header
      torana atlas node code/acme/api show --snapshot 3 --file facts/build.json
    """
    fmt, _, fields = _fmt(ctx)
    client = _client(ctx)
    if version and snapshot:
        raise click.UsageError("--version and --snapshot are exclusive: a skill version or a code snapshot")
    if terms and not (file_path and not version and not snapshot):
        raise click.UsageError("--term goes with --file on the current version (not --version or --snapshot)")
    if header:
        if not file_path or not file_path.strip("/").startswith("index/") or terms:
            raise click.UsageError("--header goes with --file index/imports.json or --file index/callgraph.json")
        snap = None if version else _snapshot_row(ctx, snapshot, required=bool(snapshot))
        if snap is None:                        # --version, or a node with no snapshot yet: the version's own index
            n = _anchor_version(ctx, version)
            url = _node_url(ctx, f"/versions/{n}/files/{file_path.strip('/')}")
        else:
            url = _node_url(ctx, f"/snapshots/{snap['seq']}/files/{file_path.strip('/')}")
        data = _call(client.get, url, params=_scope(ctx, {"header": "true"}))
        if fmt == "text" and not fields and snap is not None:
            click.echo(snapshot_label(snap))
        output(data, fmt=fmt if fmt != "text" else "yaml", fields=fields)
        return
    if snapshot:
        _show_snapshot(ctx, client, fmt, fields, snapshot, file_path)
        return
    base = f"/versions/{version}" if version else ""
    if not file_path:
        data = _call(client.get, _node_url(ctx, f"{base}/files" if not version else base), params=_scope(ctx))
        if version and fmt == "text" and isinstance(data, dict):     # {version, files}: a header, then the files
            v = data.get("version") or {}
            click.echo(f"{_node_path(ctx)}  v{v.get('version')}  built {v.get('built_at')}  {v.get('harness')}"
                       f"  {v.get('model') or ''}  ${v.get('cost_usd') or 0}"
                       + ("  (content unchanged)" if v.get("content_unchanged") else ""))
            data = {"items": data.get("files") or [], "total": len(data.get("files") or [])}
        output(data, fmt=fmt, fields=fields, columns=[("path", "PATH", 40), ("size", "BYTES", 8),
                                                      ("media_type", "TYPE", 18)])
        return
    try:
        content, _ = client.get_bytes(_node_url(ctx, f"{base}/files/{file_path.lstrip('/')}"),
                                      params=_scope(ctx, {"term": list(terms)} if terms else None))
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        if is_hidden_error(e):                  # OI-166/169: hidden or deleted by consent, not missing: no repo pointer
            try:
                handle_api_error(e)
            finally:
                click.echo(hidden_hint(e), err=True)
            return
        if e.status_code == 404:                # not a file of the node: say where the repository's own copy is
            for line in _repo_file_hint(ctx, client, version, file_path):
                click.echo(line, err=True)
        handle_api_error(e)
        return
    text = content.decode("utf-8", errors="replace")
    if fmt == "text":
        click.echo(text, nl=not text.endswith("\n"))
        return
    output({"path": _node_path(ctx), "version": version, "file": file_path, "content": text}, fmt=fmt)


def _repo_file_hint(ctx, client, version, file_path: str) -> list[str]:
    """For a 404 on `show --file`: where the REPOSITORY's copy of that path is, at the commit the version was built
    against (OI-133). Atlas does not serve repository bytes (SECURITY.md D8.2), so this is a pointer, never content.
    Best effort: any failure here yields no hint, and the 404 is reported as usual."""
    try:
        if version:
            data = client.get(_node_url(ctx, f"/versions/{version}"), params=_scope(ctx)) or {}
            built_from = (data.get("version") or {}).get("built_from")
        else:
            data = client.get(_node_url(ctx), params=_scope(ctx)) or {}
            built_from = (data.get("current") or {}).get("built_from")
    except Exception:
        return []
    path = file_path.lstrip("/")
    out = []
    for inp in built_from or []:
        sha = inp.get("built_against") if isinstance(inp, dict) else None
        if inp.get("kind") != "git_ref" or not isinstance(sha, str) or not sha:
            continue
        location = str(inp.get("ref", "")).rsplit("#", 1)[0]
        out.append(f"{path} is not a file of this node version. The repository's copy at the built commit:")
        if location.startswith("github.com/") and location.count("/") == 2:
            out.append(f"  https://{location}/blob/{sha}/{path}")
        out.append(f"  git show {sha}:{path}      # in a clone of {location or 'the repository'}")
    return out


def snapshot_label(snap: dict) -> str:
    """`snapshot 3 · commit abc1234`: which code snapshot a read came from (OI-180)."""
    commit = (snap.get("commit") or "")[:7] or "commit not known"
    return f"snapshot {snap.get('seq')} · commit {commit}"


def _snapshot_row(ctx, seq: int | None, *, required: bool = True) -> dict | None:
    """The SnapshotRow to read: `seq`, else the node's latest (the node detail's top-level `snapshot`, contract C1).
    A node with no snapshot yet: None, or an error when `required`."""
    if seq:
        return _call(_client(ctx).get, _node_url(ctx, f"/snapshots/{seq}"), params=_scope(ctx)) or {"seq": seq}
    data = _call(_client(ctx).get, _node_url(ctx), params=_scope(ctx))
    snap = data.get("snapshot") if isinstance(data, dict) else None
    if isinstance(snap, dict) and snap.get("seq"):
        return snap
    if required:
        raise click.ClickException(f"{_node_path(ctx)} has no code snapshot yet (not indexed): "
                                   f"SA: torana atlas jobs build --stage index --node {_node_path(ctx)} --tenant <TENANT_ID>")
    return None


def _show_snapshot(ctx, client, fmt, fields, seq: int, file_path: str | None) -> None:
    """`show --snapshot K`: the snapshot's file table under its label, or with --file one file's body."""
    if not file_path:
        data = _call(client.get, _node_url(ctx, f"/snapshots/{seq}/files"), params=_scope(ctx))
        if fmt == "text" and not fields:
            click.echo(snapshot_label(_snapshot_row(ctx, seq)))
        output(data, fmt=fmt, fields=fields, columns=[("path", "PATH", 40), ("size", "BYTES", 8),
                                                      ("media_type", "TYPE", 18)])
        return
    content, _ = _call(client.get_bytes, _node_url(ctx, f"/snapshots/{seq}/files/{file_path.lstrip('/')}"),
                       params=_scope(ctx))
    text = content.decode("utf-8", errors="replace")
    if fmt == "text":
        click.echo(text, nl=not text.endswith("\n"))
        return
    output({"path": _node_path(ctx), "snapshot": seq, "file": file_path, "content": text}, fmt=fmt)


SNAPSHOT_COLUMNS = [("seq", "SEQ", 4), ("commit", "COMMIT", 8), ("built_at", "INDEXED", 18), ("origin", "ORIGIN", 8),
                    ("state_label", "STATE", 48)]


def _snapshot_cells(s: dict) -> dict:
    return {**s, "commit": (s.get("commit") or "")[:7] or "—", "built_at": human_time(s.get("built_at")),
            "state_label": snapshot_state_label(s)}


@node.command(name="snapshots")
@click.option("--page", type=click.IntRange(min=1), default=1, show_default=True)
@click.option("--page-size", type=click.IntRange(1, 100), default=50, show_default=True)
@tenant_option
@click.pass_context
def node_snapshots(ctx, page, page_size):
    """List the node's code snapshots, newest first: what code and data said at each commit, computed without the
    model (free). A snapshot consent hides keeps its row, with its state in words.

    \b
    Examples:
      torana atlas node code/acme/api snapshots
      torana atlas node code/acme/api snapshots --json
    """
    fmt, raw, fields = _fmt(ctx)
    data = _call(_client(ctx).get, _node_url(ctx, "/snapshots"),
                 params=_scope(ctx, {"page": page, "page_size": page_size}))
    if fmt not in ("json", "yaml") and isinstance(data, dict) and data.get("items"):
        data = {**data, "items": [_snapshot_cells(s) for s in data["items"]]}
    output(data, fmt=fmt, raw=raw, fields=fields, columns=SNAPSHOT_COLUMNS)


@node.command(name="snapshot")
@click.argument("seq", metavar="[SEQ]", type=click.IntRange(min=1), required=False)
@tenant_option
@click.pass_context
def node_snapshot(ctx, seq):
    """Get one code snapshot (default: the latest) and its files.

    \b
    Examples:
      torana atlas node code/acme/api snapshot
      torana atlas node code/acme/api snapshot 3 --json
    """
    fmt, raw, fields = _fmt(ctx)
    snap = _snapshot_row(ctx, seq)
    files = _call(_client(ctx).get, _node_url(ctx, f"/snapshots/{snap['seq']}/files"), params=_scope(ctx)) or {}
    if fmt != "text" or fields:
        output({"snapshot": snap, "files": files.get("items") or []}, fmt=fmt, raw=raw, fields=fields)
        return
    click.echo(f"{_node_path(ctx)}  {snapshot_label(snap)}  indexed {human_time(snap.get('built_at')) or '—'}"
               f"  {snap.get('origin') or ''}  {snapshot_state_label(snap)}".rstrip())
    if snap.get("as_of"):
        click.echo(f"  as of: {snap['as_of']}")
    if snap.get("written_versions"):
        click.echo("  skill versions written from it: " + ", ".join(
            f"v{v.get('version') if isinstance(v, dict) else v}" for v in snap["written_versions"]))
    if files.get("items"):
        click.echo("")
        output(files, fmt=fmt, columns=[("path", "PATH", 40), ("size", "BYTES", 8), ("media_type", "TYPE", 18)])


def _anchor_version(ctx, version):
    """The version to read anchors of: --version, else the node's current one (a node never built has none)."""
    if version:
        return version
    data = _call(_client(ctx).get, _node_url(ctx), params=_scope(ctx))
    current = ((data or {}).get("node") or {}).get("current_version") if isinstance(data, dict) else None
    if not current:
        raise click.ClickException(f"{_node_path(ctx)} has no built version (no anchors); build it or name --version")
    return current


ANCHOR_COLUMNS = [("id", "ID", 7), ("kind", "KIND", 10), ("ref", "REF", 48), ("line", "LINE", 5),
                  ("end_line", "END", 5), ("at", "AT", 12), ("quote", "QUOTE", 40), ("source", "SOURCE", 32)]

NOT_RECORDED = "not recorded (built before source tracking)"


def anchor_source_text(rec: dict) -> str:
    """Where an anchor's evidence came from, in words (OI-177): the API's `src_text`, else its raw `src`, else that the
    version predates source tracking. Never a colour or a code alone."""
    words = rec.get("src_text") or rec.get("src")
    return "; ".join(str(w) for w in words) if isinstance(words, list) and words else NOT_RECORDED


#: `--snapshot K` on anchors/anchor: read a code snapshot's anchors instead of a skill version's (OI-180).
snapshot_option = click.option("--snapshot", "snapshot", type=click.IntRange(min=1), default=None,
                               help="A code snapshot's anchors instead of a skill version's (exclusive with --version).")


def _anchor_base(ctx, version, snapshot) -> tuple[str, str]:
    """(route prefix, ref suffix) for a version's or a snapshot's anchors: (`/versions/3`, `3`) or (`/snapshots/2`, `s2`)."""
    if version and snapshot:
        raise click.UsageError("--version and --snapshot are exclusive: a skill version or a code snapshot")
    if snapshot:
        return f"/snapshots/{snapshot}", f"s{snapshot}"
    n = _anchor_version(ctx, version)
    return f"/versions/{n}", str(n)


@node.command(name="anchors")
@click.option("--version", "version", type=click.IntRange(min=1), default=None,
              help="Version number (default: the current one).")
@snapshot_option
@click.option("--page", type=click.IntRange(min=1), default=1, show_default=True)
@click.option("--page-size", type=click.IntRange(1, 100), default=50, show_default=True)
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Every page, one result.")
@tenant_option
@click.pass_context
def node_anchors(ctx, version, snapshot, page, page_size, fetch_all):
    """List a version's anchors (the evidence its statements cite) in id order, or a code snapshot's with --snapshot.

    \b
    Examples:
      torana atlas node code/acme/api anchors
      torana atlas node code/acme/api anchors --version 3 --all --json
      torana atlas node code/acme/api anchors --snapshot 2
    """
    fmt, raw, fields = _fmt(ctx)
    base, _ = _anchor_base(ctx, version, snapshot)
    client = _client(ctx)
    url = _node_url(ctx, f"{base}/anchors")
    if not fetch_all:
        data = _call(client.get, url, params=_scope(ctx, {"page": page, "page_size": page_size}))
    else:
        items, p, data = [], 1, {}
        while True:
            data = _call(client.get, url, params=_scope(ctx, {"page": p, "page_size": 100}))
            got = data.get("items") or []
            items.extend(got)
            if len(got) < 100 or len(items) >= (data.get("total") or 0):
                break
            p += 1
        data = {**data, "items": items, "total": len(items), "page": 1, "page_size": len(items)}
    if fmt == "text" and not fields and isinstance(data, dict):
        data = {**data, "items": [{**a, "source": anchor_source_text(a)} for a in data.get("items") or []]}
    output(data, fmt=fmt, raw=raw, fields=fields, columns=ANCHOR_COLUMNS)


@node.command(name="anchor")
@click.argument("anchor_id", metavar="ID")
@click.option("--version", "version", type=click.IntRange(min=1), default=None,
              help="Version number (default: the current one).")
@snapshot_option
@tenant_option
@click.pass_context
def node_anchor(ctx, anchor_id, version, snapshot):
    """Open ONE anchor of this node's version: what it points at, the quote, the source link (source_url), and the
    first version that cited it. ID is `a:17` or `17`, or a code-index anchor `ix:imports:<f>:<line>` /
    `ix:callgraph:<f>:<line>` (what `torana atlas reachability` cites), or a whole ref `atlas:<path>@<n>#<id>` or
    `atlas:<path>@s<k>#<id>` (a code snapshot) as a response prints it (then the ref's own node and version or
    snapshot are read). --snapshot K reads a code snapshot's anchor instead of a version's.

    \b
    Examples:
      torana atlas node code/acme/api anchor a:17
      torana atlas node code/acme/api anchor 17 --version 3 --json
      torana atlas node code/acme/api anchor ix:imports:4:12 --version 2
      torana atlas node code/acme/api anchor ix:imports:4:12 --snapshot 3
      torana atlas node code/acme/api anchor 'atlas:code/acme/api@s3#ix:imports:4:12'
    """
    fmt, _, fields = _fmt(ctx)
    if anchor_id.startswith("atlas:") and (version or snapshot):
        raise click.UsageError("a whole atlas: ref names its own version or snapshot: drop --version/--snapshot")
    if anchor_id.startswith(("atlas:", "ix:")):
        ref = anchor_id if anchor_id.startswith("atlas:") else \
            f"atlas:{_node_path(ctx)}@{_anchor_base(ctx, version, snapshot)[1]}#{anchor_id}"
        _print_resolved(ctx, fmt, fields, _call(_client(ctx).get, "atlas/anchors", params=_scope(ctx, {"ref": ref})))
        return
    base, at = _anchor_base(ctx, version, snapshot)
    data = _call(_client(ctx).get, _node_url(ctx, f"{base}/anchors/{anchor_id}"), params=_scope(ctx))
    if fmt == "text" and not fields and isinstance(data, dict):
        label = f"snapshot {snapshot}" if snapshot else f"v{at}"
        click.echo(f"{_node_path(ctx)} {label} {data.get('id')}  {data.get('kind')}  {data.get('ref')}"
                   + (f":{data['line']}" if data.get("line") else "")
                   + (f"-{data['end_line']}" if data.get("end_line") else ""))
        if data.get("quote"):
            click.echo(f"  quote: {data['quote']}")
        if data.get("at"):
            click.echo(f"  at: {data['at']}")
        if data.get("source_url"):
            click.echo(f"  source: {data['source_url']}")
        click.echo(f"  from: {anchor_source_text(data)}")
        first = data.get("first_cited_in")
        before = data.get("first_cited_in_before")
        click.echo(f"  first cited in: v{first}" if first else
                   (f"  first cited in: before v{before} (older than the lookback)" if before else ""))
        return
    output(data, fmt=fmt, fields=fields)


def _print_resolved(ctx, fmt, fields, data) -> None:
    """`GET /atlas/anchors?ref=`'s answer: the record, where it lives, and the source link. A withheld or cut span comes
    back as its marker (`[withheld]`, `[cut]`), never its text: printed as is, with why."""
    if fmt != "text" or fields or not isinstance(data, dict):
        output(data, fmt=fmt, fields=fields)
        return
    rec, node_ = data.get("anchor") or {}, data.get("node") or {}
    where = f"snapshot {node_['snapshot']}" if node_.get("snapshot") and not node_.get("version") else \
        f"v{node_.get('version')}"
    click.echo(f"{node_.get('path')} {where} {rec.get('id')}  {rec.get('kind')}  {rec.get('ref')}"
               + (f":{rec['line']}" if rec.get("line") else "") + (f"-{rec['end_line']}" if rec.get("end_line") else ""))
    if rec.get("quote"):
        why = (f"  (withheld: {rec['withheld']})" if rec.get("withheld") else
               "  (cut: too long to store whole)" if rec.get("cut") else "")
        click.echo(f"  quote: {rec['quote']}{why}")
    if rec.get("at"):
        click.echo(f"  at: {rec['at']}")
    if data.get("source_url"):
        click.echo(f"  source: {data['source_url']}")
    click.echo(f"  from: {anchor_source_text(rec)}")
    if data.get("file_url"):
        click.echo(f"  stored in: {data['file_url']}")


@node.command(name="diff")
@click.option("--from", "from_version", type=click.IntRange(min=1), required=True, help="Older version.")
@click.option("--to", "to_version", type=click.IntRange(min=1), required=True, help="Newer version.")
@click.option("--file", "file_path", default=None, help="Only this file (adds a unified diff).")
@tenant_option
@click.pass_context
def node_diff(ctx, from_version, to_version, file_path):
    """Compare two versions: which files were added, changed or removed, and the unified diff.

    \b
    Examples:
      torana atlas node code/acme/api diff --from 3 --to 4
      torana atlas node code/acme/api diff --from 3 --to 4 --file SKILL.md
    """
    fmt, _, _ = _fmt(ctx)
    params = {"from": from_version, "to": to_version}
    if file_path:
        params["file"] = file_path
    data = _call(_client(ctx).get, _node_url(ctx, "/diff"), params=_scope(ctx, params))
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt)
        return
    changes = data.get("changes") or []
    click.echo(f"{_node_path(ctx)}  v{data.get('from', from_version)} → v{data.get('to', to_version)}  "
               f"({len(changes)} files changed)")
    for c in changes:
        click.echo(f"  {c.get('change', '?'):<9} {c.get('path')}")
    if data.get("unified"):
        click.echo("")
        click.echo(data["unified"], nl=not data["unified"].endswith("\n"))


@node.command(name="export")
@click.option("--version", "version", type=click.IntRange(min=1), default=None,
              help="Version number (default: the current one).")
@click.option("--out", "out_dir", required=True, metavar="DIR", help="Directory to unpack the node into.")
@tenant_option
@click.pass_context
def node_export(ctx, version, out_dir):
    """Export one version of the node (its whole folder) into a directory.

    \b
    Examples:
      torana atlas node code/acme/api export --out ./api-skill
      torana atlas node code/acme/api export --version 3 --out ./api-skill-v3
    """
    params = {"format": "tar"}
    if version:
        params["version"] = version
    content, _ = _call(_client(ctx).get_bytes, _node_url(ctx, "/export"), params=_scope(ctx, params))
    files = extract_tar(content, out_dir)
    report_written(ctx, {"path": _node_path(ctx), "version": version, "out": out_dir, "files": len(files)},
                   f"exported {len(files)} files of {_node_path(ctx)} to {out_dir}")


@node.command(name="rebuild")
@click.option("--full", is_flag=True, default=False, help="Rebuild from scratch, not incrementally.")
@click.option("--profile", "profile", default=None, metavar="NAME",
              help="SA only. Pin this builder profile for the run (the platform's spend line).")
@click.option("--trial", is_flag=True, default=False,
              help="SA only. Run --profile as a trial: the result stays out of the tenant's view. Needs --profile.")
@wait_options
@tenant_option
@click.pass_context
def node_rebuild(ctx, full, profile, trial, wait, poll, wait_timeout):
    """Queue a rebuild of the node now (needs atlas:admin). Returns the run id; --wait follows it to the end.

    --profile / --trial are a super-admin's platform decision (403 otherwise).

    \b
    Examples:
      torana atlas node code/acme/api rebuild
      torana atlas node code/acme/api rebuild --full --json
      torana atlas node code/acme/api rebuild --wait
      TORANA_PROFILE=SA torana atlas node code/acme/api rebuild --profile cheap-warm --trial --wait
    """
    fmt, _, _ = _fmt(ctx)
    if trial and not profile:
        raise click.UsageError("--trial runs a named profile: add --profile NAME")
    client = _client(ctx)
    body = {"full": full}
    if profile:
        body["profile"] = profile
    if trial:
        body["trial"] = True
    data = _call(client.post, _node_url(ctx, "/rebuild"), json=body, params=_scope(ctx))
    run_id = data.get("run_id") if isinstance(data, dict) else None
    building = already_building(data)
    if wait and run_id:
        if building:
            say_already_building(run_id)
        wait_for_run(ctx, client, run_id, (ctx.obj or {}).get("_atlas_tenant"), poll, wait_timeout)
        return
    if fmt == "text" and run_id:
        click.echo(f"already building: run {run_id}, no second build started  (follow it: torana atlas run {run_id} get)"
                   if building else f"queued run {run_id}  (follow it: torana atlas run {run_id} get)")
        return
    output(data, fmt=fmt)


@node.command(name="suppress")
@click.option("--reason", required=True, help="Why the node is suppressed (kept on the exclusion).")
@tenant_option
@click.pass_context
def node_suppress(ctx, reason):
    """Suppress the node (needs atlas:admin): no more builds, and an exclusion is written for its subject.

    \b
    Examples:
      torana atlas node code/acme/legacy suppress --reason "archived repository"
    """
    fmt, _, _ = _fmt(ctx)
    output(_call(_client(ctx).post, _node_url(ctx, "/suppress"), json={"reason": reason}, params=_scope(ctx)),
           fmt=fmt)


@node.command(name="restore")
@tenant_option
@click.pass_context
def node_restore(ctx):
    """Restore a suppressed node (needs atlas:admin): it builds again.

    \b
    Examples:
      torana atlas node code/acme/legacy restore
    """
    fmt, _, _ = _fmt(ctx)
    output(_call(_client(ctx).post, _node_url(ctx, "/restore"), json={}, params=_scope(ctx)), fmt=fmt)


# ---------------------------------------------------------------------------
# torana atlas run <ID>
# ---------------------------------------------------------------------------

@click.group(name="run", invoke_without_command=True)
@click.argument("run_id", metavar="RUN_ID")
@click.pass_context
def run(ctx, run_id):
    """Operate on one build run.

    \b
    Examples:
      torana atlas run <RUN_ID> get
    """
    ctx.ensure_object(dict)
    ctx.obj["_atlas_run_id"] = run_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@run.command(name="get")
@tenant_option
@click.pass_context
def run_get(ctx):
    """Get one run: its phase, status, error, trace id and the version it produced. Prints where its trace (Jaeger)
    and its logs (the Loki query) are.

    \b
    Examples:
      torana atlas run <RUN_ID> get --json
    """
    fmt, _, fields = _fmt(ctx)
    body = _call(_client(ctx).get, f"atlas/runs/{ctx.obj['_atlas_run_id']}", params=_scope(ctx))
    say_trace(ctx, (body or {}).get("run"))         # stderr: the run's Jaeger link and Loki query
    output(body, fmt=fmt, fields=fields)


# ---------------------------------------------------------------------------
# torana atlas exclusion <ID>
# ---------------------------------------------------------------------------

@click.group(name="exclusion", invoke_without_command=True)
@click.argument("exclusion_id", metavar="EXCLUSION_ID")
@click.pass_context
def exclusion(ctx, exclusion_id):
    """Operate on one exclusion.

    \b
    Examples:
      torana atlas exclusion <EXCLUSION_ID> delete --yes
    """
    ctx.ensure_object(dict)
    ctx.obj["_atlas_exclusion_id"] = exclusion_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@exclusion.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip the confirmation.")
@tenant_option
@click.pass_context
def exclusion_delete(ctx, yes):
    """Delete an exclusion (needs atlas:admin): matching subjects get nodes again at the next reconcile.

    \b
    Examples:
      torana atlas exclusion <EXCLUSION_ID> delete --yes
    """
    xid = ctx.obj["_atlas_exclusion_id"]
    _confirm(f"Delete Atlas exclusion {xid}?", yes=yes)
    _call(_client(ctx).delete, f"atlas/exclusions/{xid}", params=_scope(ctx))
    report_written(ctx, {"id": xid, "deleted": True}, f"deleted exclusion {xid}")


# ---------------------------------------------------------------------------
# torana atlas enrolment <TENANT_ID>  (SA)
# ---------------------------------------------------------------------------

@click.group(name="enrolment", invoke_without_command=True)
@click.argument("tenant_id", metavar="TENANT_ID")
@click.pass_context
def enrolment(ctx, tenant_id):
    """SA only. Operate on one tenant's enrolment.

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas enrolment <TENANT_ID> delete --yes
    """
    ctx.ensure_object(dict)
    ctx.obj["_atlas_enrolment_tenant"] = tenant_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@enrolment.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip the confirmation.")
@click.pass_context
def enrolment_delete(ctx, yes):
    """SA only. Un-enrol a tenant: all Atlas work for it stops. Its nodes stay until a purge.

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas enrolment <TENANT_ID> delete --yes
    """
    tid = ctx.obj["_atlas_enrolment_tenant"]
    _confirm(f"Stop all Atlas work for tenant {tid}?", yes=yes)
    _call(_client(ctx).delete, f"atlas/enrolments/{tid}")
    report_written(ctx, {"tenant_id": tid, "enrolled": False}, f"un-enrolled tenant {tid}")
