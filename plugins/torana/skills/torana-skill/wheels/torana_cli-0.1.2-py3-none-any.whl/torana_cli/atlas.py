"""torana atlas — the tenant knowledge tree (pantheon-knowledge), collection operations.

Atlas keeps one generated skill per node of a tenant's knowledge tree (`code/<org>/<repo>`,
`runtime/…`, …), versioned, rebuilt when its inputs move. This file holds the collection side:
`tree`, `nodes list`, `runs list|causes`, `producers list`, `exclusions list|add`, `selection list|add|remove`,
`summary`, `enrolments list|add`, `ownership-ladder show|set|reset`, `assemble`, `export`, `plan`, `metrics` and the SA-only `jobs …` triggers.

Instance operations live in atlas_node.py: `torana atlas node <PATH> …`, `torana atlas run <ID> get`,
`torana atlas exclusion <ID> delete`, `torana atlas enrolment <TENANT_ID> delete`.

Spec: pantheon-knowledge/docs/design/SURFACES.md § D5.2 (routes) and § D5.3 (commands).

⚠️ File output is `--out`, never `-o`: the root group lifts `-o` anywhere on the line as the
global `--format` flag, so `-o DIR` would be read as an output format.
"""

import datetime
import io
import os
import re
import sys
import tarfile
import time

import click

from torana_cli.confirm import confirm as _confirm

from torana_cli.client.auth import AuthError
from torana_cli.client.base import EXIT_RUN_FAILED, APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output

#: The API's page-size ceiling (SURFACES.md § D5.2: "Page size max 100").
MAX_PAGE_SIZE = 100

NODE_COLUMNS = [
    ("path", "PATH", 44),
    ("template", "TEMPLATE", 14),
    ("selected", "SELECTED", 8),
    ("state", "STATE", 11),
    ("tier", "TIER", 5),
    ("current_version", "VER", 4),
    ("current_as_of", "AS OF", 20),
    ("next_due_at", "NEXT DUE", 20),
    ("due_reason", "DUE REASON", 12),
    ("last_run_status", "LAST RUN", 11),
]

RUN_COLUMNS = [
    ("id", "RUN ID", 36),
    ("node_path", "NODE", 34),
    ("trigger", "TRIGGER", 12),
    ("phase", "PHASE", 8),
    ("status", "STATUS", 11),
    ("started_at", "STARTED", 20),
    ("result_version", "VER", 4),
    ("cost_usd", "COST USD", 8),
    ("stage", "STAGE", 5),                  # OI-180: index | write | all
    ("outcome_words", "OUTCOME", 44),       # the server's words, e.g. "indexed; skill waiting for the model"
]


# ---------------------------------------------------------------------------
# Shared helpers (atlas_node.py imports these)
# ---------------------------------------------------------------------------

def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    return ToranaClient(base_url=get_settings(profile).base_url)


def say_trace(ctx, run: dict | None) -> None:
    """To STDERR (stdout stays one object for --json): where a run's trace and logs are, from the server's `links`
    (OBSERVABILITY § D6.1). Nothing is built here; a run without a trace id prints nothing."""
    links = (run or {}).get("links") or {}
    trace_id = (run or {}).get("trace_id")
    if not trace_id or not links:
        return
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    base = get_settings(profile).base_url.rstrip("/")
    click.echo(f"trace  {trace_id}  {base}{links.get('trace', '')}", err=True)
    click.echo(f"logs   {links.get('logs_query', '')}   (Grafana Explore > Loki; on a dev host: "
               f"pantheon-deploy/scripts/query_loki.py 24h --all-levels -g {trace_id})", err=True)


def _fmt(ctx):
    """(format, raw, fields) from the root context."""
    obj = ctx.obj or {}
    return obj.get(CTX_FORMAT, "text"), obj.get(CTX_RAW, False), obj.get(CTX_FIELDS)


#: 409 codes whose next step the server's sentence does not name (SELECTION_AND_ADMIN_PAGE.md § 1).
CONFLICT_HINTS = {
    "not_selected": "Nothing is written unless it is selected: torana atlas selection add <PATH>, then build again.",
    "excluded": "The subject is on the never-include list: torana atlas exclusions list "
                "(delete its exclusion first to select it).",
}


#: OI-166: the words every surface uses for a version consent hides (the FE shows the same, with its glyph).
HIDDEN_WORDS = "Hidden: consent withdrawn"
HIDDEN_GLYPH = "⊘"
#: OI-169: the words for a version the consent purge deleted (the row stays; its files are gone for good).
PURGED_WORDS = "Deleted: consent withdrawn"
PURGED_GLYPH = "✕"
HIDDEN_CODES = ("consent_missing", "consent_purged")


def is_hidden_error(e: APIError) -> bool:
    """A 404 `consent_missing` (hidden) or `consent_purged` (deleted): the version exists, but a source it was built
    from no longer has the tenant's consent."""
    return e.status_code == 404 and isinstance(e.detail, dict) and e.detail.get("error") in HIDDEN_CODES


def hidden_hint(e: APIError | None = None) -> str:
    if e is not None and isinstance(e.detail, dict) and e.detail.get("error") == "consent_purged":
        return (f"{PURGED_WORDS}: a source this version was built from had its consent withdrawn, and the version's files "
                "were deleted. Granting it again does not bring them back; the node must be rebuilt.")
    return (f"{HIDDEN_WORDS}: a source this version was built from no longer has the tenant's consent. Grant it again "
            "(torana integrations knowledge-consent) before it is deleted to restore it; when: torana atlas consent purges.")


def version_hidden_label(v: dict) -> str:
    """One version row's consent state in words (OI-166, OI-169): '' when readable."""
    if v.get("hidden") == "consent_purged":
        return f"{PURGED_GLYPH} {PURGED_WORDS}" + (f", {human_time(v['purged_at'])}" if v.get("purged_at") else "")
    if v.get("hidden"):
        due = v.get("purge_due_at")
        return f"{HIDDEN_GLYPH} {HIDDEN_WORDS}" + (f"; deleted by {human_time(due)}" if due else "")
    return ""


def state_line(label: str, words: dict | None) -> str:
    """One server-computed StateWords `{state, glyph, words}` as `Label: glyph words` (OI-180 D14): rendered
    verbatim, glyph beside the words, never colour alone. '' when the server sent none."""
    if not isinstance(words, dict) or not words.get("words"):
        return ""
    glyph = words.get("glyph")
    return f"{label}: {glyph + ' ' if glyph else ''}{words['words']}"


def snapshot_state_label(s: dict) -> str:
    """One snapshot row's state as the server words it (`state_words`, OI-180), plus "(latest)" on the newest."""
    words = s.get("state_words") or s.get("state") or ""
    return f"{words} (latest)" if s.get("latest") else words


def _call(fn, *args, **kwargs):
    """Run one client call; an API or auth error prints and exits with the contract's code."""
    try:
        return fn(*args, **kwargs)
    except AuthError as e:
        handle_auth_error(e)
    except APIError as e:
        hint = (CONFLICT_HINTS.get(e.detail.get("error")) if e.status_code == 409 and isinstance(e.detail, dict)
                else hidden_hint(e) if is_hidden_error(e) else None)
        try:
            handle_api_error(e)
        finally:
            if hint:
                click.echo(hint, err=True)


def _params(**kw) -> dict:
    """Query parameters without the unset ones (None / False)."""
    return {k: v for k, v in kw.items() if v is not None and v is not False}


_SINCE_RE = re.compile(r"^(\d+)([mhd])$")
_SINCE_UNITS = {"m": "minutes", "h": "hours", "d": "days"}


def human_time(value):
    """An ISO time as `14 Oct 11:43 UTC` for the human views (JSON keeps the raw value). Unparseable → as given."""
    if not value:
        return value
    try:
        t = datetime.datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return value
    if t.tzinfo is not None:
        t = t.astimezone(datetime.timezone.utc)
    return f"{t.day} {t.strftime('%b %H:%M')} UTC"


def _human_items(data, keys):
    """A copy of a collection with `keys` of every item in human time (text views only)."""
    if not isinstance(data, dict) or not isinstance(data.get("items"), list):
        return data
    return {**data, "items": [{**i, **{k: human_time(i.get(k)) for k in keys if k in i}} for i in data["items"]]}


def since_to_iso(since):
    """`24h` / `7d` / `30m` → an ISO-8601 UTC start time; an ISO timestamp passes through unchanged."""
    if not since:
        return None
    m = _SINCE_RE.match(since.strip().lower())
    if not m:
        return since.strip()
    start = datetime.datetime.now(datetime.timezone.utc) - datetime.timedelta(
        **{_SINCE_UNITS[m.group(2)]: int(m.group(1))})
    return start.strftime("%Y-%m-%dT%H:%M:%SZ")


def extract_tar(content: bytes, out_dir: str) -> list:
    """Unpack a tarball into `out_dir`, refusing any member that would land outside it."""
    os.makedirs(out_dir, exist_ok=True)
    root = os.path.realpath(out_dir)
    with tarfile.open(fileobj=io.BytesIO(content), mode="r:*") as tar:
        members = tar.getmembers()
        for m in members:
            target = os.path.realpath(os.path.join(root, m.name))
            if target != root and not target.startswith(root + os.sep):
                raise click.ClickException(f"refusing tar member outside {out_dir}: {m.name}")
            if m.issym() or m.islnk():
                raise click.ClickException(f"refusing link in tar: {m.name}")
        if hasattr(tarfile, "data_filter"):
            tar.extractall(root, filter="data")
        else:
            tar.extractall(root)
    return [m.name for m in members if m.isfile()]


def report_written(ctx, summary: dict, line: str):
    """After writing files: JSON callers get `summary`, humans get one line."""
    fmt, _, _ = _fmt(ctx)
    if fmt == "text":
        click.echo(line)
    else:
        output(summary, fmt=fmt)


#: A run in one of these finished well; any other terminal status (failed, quarantined, cancelled) is exit 8.
RUN_OK = ("succeeded", "unchanged", "indexed")


def wait_for_run(ctx, client, run_id: str, tenant: str | None, poll: float, timeout: float):
    """Poll GET /atlas/runs/{run_id} until it leaves `running`; every phase or status change goes to STDERR, the
    final `run get` body to stdout (so --json stays one object). Exit 0 when it succeeded or was unchanged, 8 when
    it failed, was quarantined or cancelled, or the wait timed out. Ctrl-C stops the watching, never the run."""
    fmt, _, _ = _fmt(ctx)
    params = _params(tenant=tenant) or None
    deadline, last, body = time.monotonic() + timeout, None, None
    try:
        while True:
            body = _call(client.get, f"atlas/runs/{run_id}", params=params)
            run = (body or {}).get("run") or {}
            state = (run.get("phase"), run.get("status"))
            if state != last:
                click.echo(f"run {run_id}: phase {state[0]}, status {state[1]}", err=True)
                last = state
            if run.get("status") != "running":
                break
            if time.monotonic() >= deadline:
                click.echo(f"run {run_id} still running after {int(timeout)}s; stopped waiting "
                           f"(follow it: torana atlas run {run_id} get)", err=True)
                output(body, fmt=fmt)
                sys.exit(EXIT_RUN_FAILED)
            time.sleep(poll)
    except KeyboardInterrupt:
        click.echo(f"\nstopped watching; the run continues (torana atlas run {run_id} get)", err=True)
        sys.exit(130)
    if (body.get("run") or {}).get("outcome_words"):       # OI-180: what the run did, in the server's words
        click.echo(f"run {run_id}: {body['run']['outcome_words']}", err=True)
    say_trace(ctx, body.get("run"))
    output(body, fmt=fmt)
    if (body.get("run") or {}).get("status") not in RUN_OK:
        sys.exit(EXIT_RUN_FAILED)


def already_building(data) -> bool:
    """OI-155: True when the API started NO second build because one of the node is in flight (`run_id` is that
    build; --wait follows it like any other run)."""
    return isinstance(data, dict) and bool(data.get("already_building"))


def say_already_building(run_id: str) -> None:
    """On STDERR, so stdout stays the API body or the followed run (--json is one object)."""
    click.echo(f"already building: run {run_id}; no second build started (follow it: torana atlas run {run_id} get)",
               err=True)


def wait_options(f):
    """--wait / --poll / --timeout, shared by `jobs build` and `node … rebuild`."""
    f = click.option("--timeout", "wait_timeout", type=click.FloatRange(min=1), default=1800.0, show_default=True,
                     help="With --wait: stop waiting after this many seconds (exit 8; the run continues).")(f)
    f = click.option("--poll", type=click.FloatRange(min=1), default=5.0, show_default=True,
                     help="With --wait: seconds between status checks.")(f)
    return click.option("--wait", is_flag=True, default=False,
                        help="Follow the run until it finishes: phases on stderr, the final run on stdout; "
                             "exit 0 succeeded/unchanged, 8 failed or timed out.")(f)


# ---------------------------------------------------------------------------
# torana atlas
# ---------------------------------------------------------------------------

@click.group(name="atlas", invoke_without_command=True)
@click.pass_context
def atlas(ctx):
    """Atlas: the tenant knowledge tree (one generated skill per node, versioned).

    Nothing is written unless it is selected (`selection add`). Read commands need `atlas:read` (every
    tenant user). `node … rebuild|suppress|restore`, `selection add|remove`, `exclusions add`,
    `exclusion … delete` and `plan` need `atlas:admin`. `enrolments`, `enrolment`
    and `jobs` are SA only (a super-admin of the bootstrap tenant). `--tenant` is SA only too:
    anyone else is pinned to their own tenant.

    \b
    Examples:
      torana atlas summary
      torana atlas tree
      torana atlas selection list --available
      torana atlas nodes list --due
      torana atlas node code/acme/api get
      torana atlas assemble --subject repo:github.com/acme/api --explain
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


# --- tree -------------------------------------------------------------------

def _tree_label(n: dict) -> str:
    """One node's line: name, then labels in words (never colour alone)."""
    path = n.get("path") or ""
    name = path.rsplit("/", 1)[-1] if path else f"({n.get('template') or 'root'})"   # the root's path is ""
    bits = []
    if n.get("tier"):
        bits.append(f"[{n['tier']}]")
    if n.get("rendered"):                         # root/category: rendered from children at read time (D2.12)
        return f"{name}  {' '.join(bits + ['rendered from children'])}".rstrip()
    if n.get("selected") is False:                # nothing is written unless selected (OI-30)
        bits.append("not selected")
    if n.get("state") and n["state"] != "active":
        bits.append(f"state:{n['state']}")
    if n.get("due_reason") and n.get("next_due_at"):
        bits.append(f"due:{n['due_reason']}")
    if n.get("current_version"):
        bits.append(f"v{n['current_version']}")
    if n.get("current_as_of"):
        bits.append(f"as of {n['current_as_of']}")
    if n.get("last_run_status") and n["last_run_status"] not in ("succeeded", "unchanged"):
        bits.append(f"last run {n['last_run_status']}")
    return f"{name}  {' '.join(bits)}".rstrip()


def render_tree(root: dict) -> str:
    """The ASCII tree of the Atlas contract § 15."""
    lines = [_tree_label(root)]

    def walk(children, prefix):
        for i, child in enumerate(children):
            last = i == len(children) - 1
            lines.append(f"{prefix}{'└── ' if last else '├── '}{_tree_label(child)}")
            walk(child.get("children") or [], prefix + ("    " if last else "│   "))

    walk(root.get("children") or [], "")
    return "\n".join(lines)


@atlas.command(name="tree")
@click.option("--depth", type=click.IntRange(min=0), default=None, help="Levels below the root to show.")
@click.option("--tier", type=click.Choice(["hot", "warm", "cold"]), default=None, help="Only nodes of this tier.")
@click.option("--state", default=None, help="Only nodes in this state (active, due, orphaned, suppressed, …).")
@click.option("--tenant", default=None, help="Another tenant's tree (SA only).")
@click.pass_context
def atlas_tree(ctx, depth, tier, state, tenant):
    """Show the knowledge tree: every node with its tier, state, version and due reason.

    \b
    Examples:
      torana atlas tree
      torana atlas tree --depth 2 --tier hot
      torana atlas tree --tenant <TENANT_ID> --json
    """
    fmt, _, _ = _fmt(ctx)
    data = _call(_client(ctx).get, "atlas/tree",
                 params=_params(depth=depth, tier=tier, state=state, tenant=tenant))
    if fmt == "text" and isinstance(data, dict) and "root" in data:
        enrolled = "enrolled" if data.get("enrolled") else "NOT enrolled"
        click.echo(f"tenant {data.get('tenant_id', '?')}  ({enrolled})")
        if isinstance(data.get("root"), dict):
            click.echo(render_tree(data["root"]))
        else:
            click.echo("no nodes yet" + ("" if data.get("enrolled") else
                                          ": Atlas does nothing for a tenant until it is enrolled (SA: atlas enrolments add)"))
        return
    output(data, fmt=fmt)


# --- nodes ------------------------------------------------------------------

@atlas.group(name="nodes", invoke_without_command=True)
@click.pass_context
def atlas_nodes(ctx):
    """Atlas nodes as a flat list. One node: `torana atlas node <PATH> …`.

    \b
    Examples:
      torana atlas nodes list --template repository
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@atlas_nodes.command(name="list")
@click.option("--template", default=None, help="Only nodes of this template (repository, category, …).")
@click.option("--state", default=None, help="Only nodes in this state.")
@click.option("--tier", type=click.Choice(["hot", "warm", "cold"]), default=None, help="Only nodes of this tier.")
@click.option("--due", is_flag=True, default=False, help="Only nodes that are due for a build.")
@click.option("--tenant", default=None, help="Another tenant's nodes (SA only).")
@click.option("--page", type=click.IntRange(min=1), default=1, show_default=True)
@click.option("--page-size", type=click.IntRange(1, MAX_PAGE_SIZE), default=50, show_default=True)
@click.pass_context
def atlas_nodes_list(ctx, template, state, tier, due, tenant, page, page_size):
    """List nodes with their state, tier, current version and when they are next due.

    \b
    Examples:
      torana atlas nodes list
      torana atlas nodes list --due --tier hot
      torana atlas nodes list --tenant <TENANT_ID> --json
    """
    fmt, raw, fields = _fmt(ctx)
    params = _params(template=template, state=state, tier=tier, tenant=tenant,
                     page=page, page_size=page_size)
    if due:
        params["due"] = "true"
    data = _call(_client(ctx).get, "atlas/nodes", params=params)
    output(data, fmt=fmt, raw=raw, fields=fields, columns=NODE_COLUMNS)


# --- runs -------------------------------------------------------------------

@atlas.group(name="runs", invoke_without_command=True)
@click.pass_context
def atlas_runs(ctx):
    """Build runs. One run: `torana atlas run <ID> get`.

    \b
    Examples:
      torana atlas runs list --status failed --since 24h
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@atlas_runs.command(name="list")
@click.option("--node", "node_path", default=None, metavar="PATH", help="Only runs of this node.")
@click.option("--producer", default=None, help="Only runs of this producer.")
@click.option("--status", default=None,
              help="running, succeeded, failed, unchanged, indexed (code facts stored, no skill written), quarantined "
                   "or cancelled.")
@click.option("--stage", type=click.Choice(["index", "write", "all"]), default=None,
              help="Only runs of this stage: index (code facts only, free), write (the skill), all (both).")
@click.option("--since", default=None, help="Started within this window: 30m, 24h, 7d, or an ISO time.")
@click.option("--tenant", default=None, help="Another tenant's runs (SA only).")
@click.option("--page", type=click.IntRange(min=1), default=1, show_default=True)
@click.option("--page-size", type=click.IntRange(1, MAX_PAGE_SIZE), default=50, show_default=True)
@click.pass_context
def atlas_runs_list(ctx, node_path, producer, status, stage, since, tenant, page, page_size):
    """List build runs: trigger, phase, status, the version produced, the cost, the stage and what it did in words.

    \b
    Examples:
      torana atlas runs list --since 24h
      torana atlas runs list --node code/acme/api --status failed --json
      torana atlas runs list --status indexed --stage all
    """
    fmt, raw, fields = _fmt(ctx)
    params = _params(node=node_path, producer=producer, status=status, stage=stage, since=since_to_iso(since),
                     tenant=tenant, page=page, page_size=page_size)
    data = _call(_client(ctx).get, "atlas/runs", params=params)
    output(data, fmt=fmt, raw=raw, fields=fields, columns=RUN_COLUMNS)


@atlas_runs.command(name="causes")
@click.option("--since", default="30d", show_default=True, help="Failed within this window: 24h, 7d, 30d, or an ISO time.")
@click.option("--node", "node_path", default=None, metavar="PATH", help="Only runs of this node.")
@click.option("--tenant", default=None, help="Another tenant's runs (SA only).")
@click.pass_context
def atlas_runs_causes(ctx, since, node_path, tenant):
    """Failed runs grouped by cause (the server's one normaliser): count, first and last time, an example run.

    \b
    Examples:
      torana atlas runs causes
      torana atlas runs causes --since 7d --node code/acme/api --json
    """
    fmt, raw, fields = _fmt(ctx)
    data = _call(_client(ctx).get, "atlas/runs/causes",
                 params=_params(since=since_to_iso(since), node=node_path, tenant=tenant))
    if isinstance(data, dict) and "total" not in data:          # fallback: the API returns `total` (contract § 3)
        data = {**data, "total": len(data.get("items") or [])}
    if fmt == "text" and isinstance(data, dict):
        click.echo(f"{data.get('failed_runs', 0)} of {data.get('total_runs', 0)} runs failed since {since}"
                   + (f" ({node_path})" if node_path else ""))
        if data.get("by_kind"):
            click.echo(by_kind_line(data["by_kind"]))
        if not data.get("items"):
            return
    if fmt == "text":
        data = _human_items(data, ("first_at", "last_at"))
    output(data, fmt=fmt, raw=raw, fields=fields, columns=[
        ("count", "RUNS", 5), ("kind", "KIND", 19), ("cause", "CAUSE", 60), ("last_at", "LAST", 16),
        ("first_at", "FIRST", 16), ("example_run_id", "EXAMPLE RUN", 36),
    ])


def by_kind_line(by_kind: list, count: str = "count", lead: str = "By kind") -> str:
    """`By kind: infrastructure 157 · fetch 11`: the server's atlas_runs.error_kind counts, in its order."""
    return f"{lead}: " + " · ".join(f"{k.get('kind')} {k.get(count, 0)}" for k in by_kind)


# --- producers --------------------------------------------------------------

@atlas.group(name="producers", invoke_without_command=True)
@click.pass_context
def atlas_producers(ctx):
    """Producers: the builders that write node versions, with 30-day rollups.

    \b
    Examples:
      torana atlas producers list
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@atlas_producers.command(name="list")
@click.option("--tenant", default=None, help="Another tenant's producers (SA only).")
@click.pass_context
def atlas_producers_list(ctx, tenant):
    """List producers with runs, failure rate and cost over the last 30 days.

    \b
    Examples:
      torana atlas producers list
      torana atlas producers list --json
    """
    fmt, raw, fields = _fmt(ctx)
    data = _call(_client(ctx).get, "atlas/producers", params=_params(tenant=tenant) or None)
    output(data, fmt=fmt, raw=raw, fields=fields, columns=[
        ("name", "NAME", 24), ("version", "VER", 4), ("harness", "HARNESS", 18),
        ("runs_30d", "RUNS 30D", 8), ("failure_rate_30d", "FAIL 30D", 8), ("cost_30d", "COST 30D", 9),
    ])


# --- exclusions -------------------------------------------------------------

@atlas.group(name="exclusions", invoke_without_command=True)
@click.pass_context
def atlas_exclusions(ctx):
    """Exclusions: subjects Atlas must not build a node for. Delete one: `torana atlas exclusion <ID> delete`.

    \b
    Examples:
      torana atlas exclusions list
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@atlas_exclusions.command(name="list")
@click.option("--tenant", default=None, help="Another tenant's exclusions (SA only).")
@click.pass_context
def atlas_exclusions_list(ctx, tenant):
    """List exclusions (needs atlas:read).

    \b
    Examples:
      torana atlas exclusions list --json
    """
    fmt, raw, fields = _fmt(ctx)
    data = _call(_client(ctx).get, "atlas/exclusions", params=_params(tenant=tenant) or None)
    output(data, fmt=fmt, raw=raw, fields=fields, columns=[
        ("id", "ID", 36), ("template", "TEMPLATE", 14), ("subject_pattern", "SUBJECT", 34),
        ("reason", "REASON", 30), ("until", "UNTIL", 20),
    ])


@atlas_exclusions.command(name="add")
@click.option("--template", required=True, help="The node template the exclusion applies to (e.g. repository).")
@click.option("--subject", "subject_pattern", required=True,
              help="SQL LIKE pattern on the subject key, e.g. 'repo:github.com/acme/legacy-%'.")
@click.option("--reason", required=True, help="Why it is excluded (kept on the row).")
@click.option("--until", default=None, help="ISO time the exclusion lapses (default: never).")
@click.pass_context
def atlas_exclusions_add(ctx, template, subject_pattern, reason, until):
    """Add an exclusion (needs atlas:admin). Matching subjects get no node.

    \b
    Examples:
      torana atlas exclusions add --template repository --subject 'repo:github.com/acme/legacy-%' --reason "archived"
    """
    fmt, _, _ = _fmt(ctx)
    body = {"template": template, "subject_pattern": subject_pattern, "reason": reason, "until": until}
    output(_call(_client(ctx).post, "atlas/exclusions", json=body), fmt=fmt)


# --- selection (the inclusion list) -----------------------------------------

#: The API's ceiling on subjects per PUT /atlas/selection (SELECTION_AND_ADMIN_PAGE.md § 3).
MAX_SELECTION_BATCH = 100

REFUSAL_HINTS = {
    "excluded": "on the never-include list (torana atlas exclusions list)",
    "unknown_subject": "no node has this subject (torana atlas selection list --q TEXT)",
}

SELECTION_COLUMNS = [
    ("path", "PATH", 44),
    ("selected", "SELECTED", 8),
    ("excluded", "EXCLUDED", 8),
    ("failing", "FAILING", 7),
    ("tier", "TIER", 5),
    ("current_version", "VER", 4),
    ("last_run_status", "LAST RUN", 11),
    ("selected_by", "BY", 26),
    ("selected_at", "SELECTED AT", 16),
]


@atlas.group(name="selection", invoke_without_command=True)
@click.pass_context
def atlas_selection(ctx):
    """The inclusion list: which subjects get a skill. Nothing is written unless it is selected.

    Every synced subject is listed as a node for free; only a selected one is ever due, claimed or built.
    `list` needs atlas:read; `add` and `remove` need atlas:admin (super-admin in Phase 0).

    \b
    Examples:
      torana atlas selection list --available
      torana atlas selection add code/acme/api repo:github.com/acme/web
      torana atlas selection remove code/acme/api
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@atlas_selection.command(name="list")
@click.option("--template", default="repository", show_default=True, help="Which template's subjects.")
@click.option("--selected", "only_selected", is_flag=True, default=False, help="Only selected subjects.")
@click.option("--available", "only_available", is_flag=True, default=False,
              help="Only subjects not selected (available to select).")
@click.option("--q", "query", default=None, metavar="TEXT", help="Only paths or subjects containing TEXT.")
@click.option("--tier", type=click.Choice(["hot", "warm", "cold"]), default=None,
              help="Only subjects of this tier (priority: hot = High, warm = Normal, cold = Low).")
@click.option("--tenant", default=None, help="Another tenant's selection (SA only).")
@click.option("--page", type=click.IntRange(min=1), default=1, show_default=True)
@click.option("--page-size", type=click.IntRange(1, MAX_PAGE_SIZE), default=50, show_default=True)
@click.pass_context
def atlas_selection_list(ctx, template, only_selected, only_available, query, tier, tenant, page, page_size):
    """List subjects with whether each is selected, excluded, failing, and written (version, last run).

    \b
    Examples:
      torana atlas selection list
      torana atlas selection list --available --q payments
      torana atlas selection list --available --tier hot
      torana atlas selection list --selected --tenant <TENANT_ID> --json
    """
    if only_selected and only_available:
        raise click.UsageError("--selected and --available are exclusive; give neither to list both.")
    fmt, raw, fields = _fmt(ctx)
    state = "selected" if only_selected else "available" if only_available else "all"
    data = _call(_client(ctx).get, "atlas/selection", params=_params(
        template=template, state=state, q=query, tier=tier, tenant=tenant, page=page, page_size=page_size))
    if fmt == "text" and isinstance(data, dict):
        c = data.get("counts") or {}
        click.echo(f"{c.get('selected', 0)} selected · {c.get('available', 0)} available · "
                   f"{c.get('excluded', 0)} never include (excluded)")
        data = _human_items(data, ("selected_at",))
    output(data, fmt=fmt, raw=raw, fields=fields, columns=SELECTION_COLUMNS)


def _is_subject(value: str) -> bool:
    """`repo:github.com/acme/api` is a subject key; `code/acme/api` is a node path."""
    return ":" in value


def _resolve_subjects(client, items, template: str, tenant: str | None) -> list:
    """Each argument as a subject: subjects pass through, node paths resolve via GET /atlas/nodes/{path}."""
    out = []
    for item in items:
        if _is_subject(item):
            out.append(item)
            continue
        path = item.strip("/")
        body = _call(client.get, f"atlas/nodes/{path}", params=_params(tenant=tenant) or None) or {}
        node = body.get("node") or {}
        if not node.get("subject"):
            raise click.ClickException(f"{path} has no subject (a root or category node is never selected); "
                                       "select the repositories under it")
        if node.get("template") and node["template"] != template:
            raise click.ClickException(f"{path} is a {node['template']} node, not {template}: "
                                       f"pass --template {node['template']}")
        out.append(node["subject"])
    return list(dict.fromkeys(out))                                   # order kept, duplicates dropped


def _put_selection(ctx, items, template: str, tenant: str | None, selected: bool):
    """PUT /atlas/selection in batches of at most 100; prints the merged result; exit 1 if anything was refused."""
    fmt, _, _ = _fmt(ctx)
    client = _client(ctx)
    subjects = _resolve_subjects(client, items, template, tenant)
    merged = {"changed": [], "unchanged": [], "refused": []}
    scope = _params(tenant=tenant) or None
    for i in range(0, len(subjects), MAX_SELECTION_BATCH):
        body = {"template": template, "subjects": subjects[i:i + MAX_SELECTION_BATCH], "selected": selected}
        data = _call(client.put, "atlas/selection", json=body, params=scope) or {}
        for key in merged:
            merged[key] += data.get(key) or []
    if fmt != "text":
        output(merged, fmt=fmt)
    else:
        verb, already = ("selected", "already selected") if selected else ("deselected", "already not selected")
        click.echo(f"{verb} {len(merged['changed'])}, {already} {len(merged['unchanged'])}, "
                   f"refused {len(merged['refused'])}")
        for s in merged["changed"]:
            click.echo(f"  {verb}  {s}")
        for r in merged["refused"]:
            hint = REFUSAL_HINTS.get(r.get("error"))
            click.echo(f"  refused   {r.get('subject')}: {r.get('error')}" + (f" — {hint}" if hint else ""))
        if selected and merged["changed"]:
            click.echo("selected nodes are due now; the background builders write them when workers > 0, "
                       "or write one now: torana atlas node <PATH> rebuild")
    if merged["refused"]:
        sys.exit(1)


@atlas_selection.command(name="add")
@click.argument("items", nargs=-1, required=True, metavar="SUBJECT_OR_PATH...")
@click.option("--template", default="repository", show_default=True, help="The template of the subjects.")
@click.option("--tenant", default=None, help="Select for another (enrolled) tenant (SA only).")
@click.pass_context
def atlas_selection_add(ctx, items, template, tenant):
    """Select subjects (atlas:admin): each becomes due like a first build. Takes node paths or subjects.

    Exit 1 when any subject was refused (excluded or unknown); the others are still selected.

    \b
    Examples:
      torana atlas selection add code/acme/api
      torana atlas selection add repo:github.com/acme/api repo:github.com/acme/web --json
      TORANA_PROFILE=SA torana atlas selection add code/acme/api --tenant <TENANT_ID>
    """
    _put_selection(ctx, items, template, tenant, selected=True)


@atlas_selection.command(name="remove")
@click.argument("items", nargs=-1, required=True, metavar="SUBJECT_OR_PATH...")
@click.option("--template", default="repository", show_default=True, help="The template of the subjects.")
@click.option("--tenant", default=None, help="Deselect for another (enrolled) tenant (SA only).")
@click.pass_context
def atlas_selection_remove(ctx, items, template, tenant):
    """Deselect subjects (atlas:admin): no longer due or built; written versions stay readable.

    \b
    Examples:
      torana atlas selection remove code/acme/legacy
      torana atlas selection remove repo:github.com/acme/legacy --json
    """
    _put_selection(ctx, items, template, tenant, selected=False)


# --- enrolments (SA) --------------------------------------------------------

@atlas.group(name="enrolments", invoke_without_command=True)
@click.pass_context
def atlas_enrolments(ctx):
    """SA only. Enrolments: the opt-in. Atlas does no work for a tenant that is not enrolled.

    Remove one: `torana atlas enrolment <TENANT_ID> delete`.

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas enrolments list
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@atlas_enrolments.command(name="list")
@click.pass_context
def atlas_enrolments_list(ctx):
    """SA only. List enrolled tenants with clone consent and daily budget.

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas enrolments list
    """
    fmt, raw, fields = _fmt(ctx)
    data = _call(_client(ctx).get, "atlas/enrolments")
    output(data, fmt=fmt, raw=raw, fields=fields, columns=[
        ("tenant_id", "TENANT", 36), ("clone_allowed", "CLONE", 6), ("daily_budget_usd", "BUDGET USD/DAY", 14),
        ("ownership_ladder_source", "OWNER LADDER", 12), ("enrolled_by", "BY", 26), ("enrolled_at", "AT", 20),
    ])


@atlas_enrolments.command(name="add")
@click.option("--tenant", "tenant_id", required=True, help="The tenant to enrol.")
@click.option("--clone-allowed", is_flag=True, default=False,
              help="Consent to platform-side cloning of the tenant's repositories.")
@click.option("--daily-budget", "daily_budget_usd", type=click.FloatRange(min=0), default=None,
              help="Daily build budget in USD (default: the platform's per-tenant budget).")
@click.pass_context
def atlas_enrolments_add(ctx, tenant_id, clone_allowed, daily_budget_usd):
    """SA only. Enrol a tenant: Atlas starts reconciling its tree.

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas enrolments add --tenant <TENANT_ID> --clone-allowed --daily-budget 20
    """
    fmt, _, _ = _fmt(ctx)
    body = {"tenant_id": tenant_id, "clone_allowed": clone_allowed, "daily_budget_usd": daily_budget_usd}
    output(_call(_client(ctx).post, "atlas/enrolments", json=body), fmt=fmt)


# --- ownership ladder (OWNERSHIP_LADDER.md) ---------------------------------

def _ladder_lines(rungs: list) -> list:
    """`1. codeowners  the CODEOWNERS file, per path  (known; answers)` per rung."""
    out = []
    for r in rungs or []:
        params = ", ".join(f"{k}={v}" for k, v in (r.get("params") or {}).items())
        answers = "answers" if r.get("counts_as_answered") else "shown, not an answer"
        out.append(f"  {r.get('rung')}. {r.get('resolver')}{f' ({params})' if params else ''}: {r.get('plain')}  "
                   f"[{r.get('certainty')}; {answers}]")
    return out


def _read_ladder(path: str) -> list:
    """A ladder file (YAML or JSON): a list of rungs, or a mapping whose `rungs` is that list."""
    import yaml
    try:
        with open(path, encoding="utf-8") as fh:
            doc = yaml.safe_load(fh)
    except (OSError, yaml.YAMLError) as e:
        raise click.BadParameter(f"cannot read {path}: {e}", param_hint="--file")
    if isinstance(doc, dict) and "rungs" in doc:
        doc = doc["rungs"]
    if not isinstance(doc, list):
        raise click.BadParameter("the file must hold a list of rungs (or `rungs:` with one)", param_hint="--file")
    return doc


def _require_enrolled(ctx, tenant: str) -> None:
    """set/reset write through POST /atlas/enrolments, which would ENROL an unenrolled tenant: refuse instead."""
    data = _call(_client(ctx).get, "atlas/ownership-ladder", params={"tenant": tenant}) or {}
    if not data.get("enrolled"):
        raise click.ClickException(f"tenant {tenant} is not enrolled in Atlas; enrol it first "
                                   "(torana atlas enrolments add --tenant <TENANT_ID>)")


def _post_ladder(ctx, tenant: str, ladder):
    fmt, _, _ = _fmt(ctx)
    _require_enrolled(ctx, tenant)
    _call(_client(ctx).post, "atlas/enrolments", json={"tenant_id": tenant, "ownership_ladder": ladder})
    data = _call(_client(ctx).get, "atlas/ownership-ladder", params={"tenant": tenant})
    if fmt != "text":
        output(data, fmt=fmt)
        return
    _echo_ladder(data)
    click.echo("the tenant's selected repository skills are due again (the watermark moved); "
               "they are rewritten when builders run, or now: torana atlas node <PATH> rebuild")


def _echo_ladder(data: dict) -> None:
    source = "set for this tenant" if data.get("source") == "tenant" else "platform default"
    click.echo(f"Who owns a repository, tenant {data.get('tenant_id')}: {source} (sha {str(data.get('sha'))[:12]})")
    click.echo("The first rung that finds an owner answers; the rungs below it are not consulted.")
    for line in _ladder_lines(data.get("effective")):
        click.echo(line)
    if data.get("source") == "tenant":
        click.echo("\nplatform default (torana atlas ownership-ladder reset --tenant <TENANT_ID>):")
        for line in _ladder_lines(data.get("default")):
            click.echo(line)
    if not data.get("enrolled", True):
        click.echo("\n(this tenant is not enrolled in Atlas: nothing is built for it)")


@atlas.group(name="ownership-ladder", invoke_without_command=True)
@click.pass_context
def atlas_ownership_ladder(ctx):
    """Who owns a repository: the ordered rungs Atlas tries (CODEOWNERS, recorded owner, teams, organisation).

    The first rung that finds an owner answers, and the skill says which rung it was. `show` needs
    atlas:read; `set` and `reset` are SA only. Changing the ladder makes the tenant's selected repository
    skills due again.

    \b
    Examples:
      torana atlas ownership-ladder show
      TORANA_PROFILE=SA torana atlas ownership-ladder set --tenant <TENANT_ID> --file ladder.yaml
      TORANA_PROFILE=SA torana atlas ownership-ladder reset --tenant <TENANT_ID>
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@atlas_ownership_ladder.command(name="show")
@click.option("--tenant", default=None, help="Another tenant's ladder (SA only).")
@click.pass_context
def atlas_ownership_ladder_show(ctx, tenant):
    """Show the effective ownership ladder, whether it is the platform default or set for the tenant.

    \b
    Examples:
      torana atlas ownership-ladder show
      TORANA_PROFILE=SA torana atlas ownership-ladder show --tenant <TENANT_ID> --json
    """
    fmt, raw, fields = _fmt(ctx)
    data = _call(_client(ctx).get, "atlas/ownership-ladder", params=_params(tenant=tenant))
    if fmt == "text" and isinstance(data, dict):
        _echo_ladder(data)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@atlas_ownership_ladder.command(name="set")
@click.option("--tenant", required=True, help="The (enrolled) tenant whose ladder to set.")
@click.option("--file", "path", required=True, type=click.Path(exists=True, dir_okay=False),
              help="YAML or JSON: a list of rungs, each {resolver, params?, certainty?, counts_as_answered?}.")
@click.pass_context
def atlas_ownership_ladder_set(ctx, tenant, path):
    """SA only. Set a tenant's own ownership ladder (replaces the platform default for that tenant).

    Resolvers: codeowners, recorded_owner, team_access (params: min_permission = admin|maintain|push|
    triage|pull), organization. Refused with exit 6 (invalid_ownership_ladder) for an unknown resolver or
    param, or an empty ladder. A ladder-only change keeps the enrolment's consent and budget.

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas ownership-ladder set --tenant <TENANT_ID> --file ladder.yaml
    \b
    ladder.yaml:
      - resolver: codeowners
      - resolver: team_access
        params: {min_permission: maintain}
      - resolver: recorded_owner
    """
    _post_ladder(ctx, tenant, _read_ladder(path))


@atlas_ownership_ladder.command(name="reset")
@click.option("--tenant", required=True, help="The (enrolled) tenant whose ladder goes back to the default.")
@click.pass_context
def atlas_ownership_ladder_reset(ctx, tenant):
    """SA only. Put a tenant back on the platform default ownership ladder.

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas ownership-ladder reset --tenant <TENANT_ID>
    """
    _post_ladder(ctx, tenant, None)


# --- assemble ---------------------------------------------------------------

def _label(path) -> str:
    return path or "(root)"                       # the root node's path is ""


def _render_assemble(data: dict):
    click.echo(f"bundle {data.get('bundle_id', '?')}  subject {data.get('subject', '?')}  "
               f"tokens {data.get('tokens_total', '?')}" + ("  (some content is stale)" if data.get("stale_any")
                                                             else ""))
    included = data.get("included") or []
    click.echo(f"\nincluded ({len(included)} nodes)")
    for n in included:
        stale = " stale" if n.get("stale") else ""
        ver = f"v{n.get('version')}" if n.get("version") else "rendered"      # root/category: no versions
        click.echo(f"  {_label(n.get('path'))}  {ver}  {n.get('portion')}  "
                   f"{n.get('tokens')} tokens  reason {n.get('reason')}{stale}")
    excluded = data.get("excluded") or []
    if excluded:
        click.echo(f"\nexcluded ({len(excluded)} nodes)")
        for n in excluded:
            click.echo(f"  {_label(n.get('path'))}  reason {n.get('reason')}")
    trimmed = data.get("trimmed") or []
    if trimmed:
        click.echo(f"\ntrimmed to fit the budget ({len(trimmed)} files; fetch with: torana atlas node <PATH> show --file F)")
        for t in trimmed:
            click.echo(f"  {t.get('path')}  {t.get('bytes')} bytes")
    pending = data.get("pending") or []
    if pending:
        click.echo(f"\npending ({len(pending)} nodes asked to build; not in this bundle)")
        for p in pending:
            click.echo(f"  {_label(p)}")


@atlas.command(name="assemble")
@click.option("--subject", required=True,
              help="What to assemble context for: tenant, repo:<key> or alert:<id>.")
@click.option("--goal", type=click.Choice(["answer", "build"]), default="answer", show_default=True,
              help="answer = read context for a question; build = context for a build session.")
@click.option("--budget", "budget_tokens", type=click.IntRange(min=1000), default=None,
              help="Token budget for the bundle (default: the platform's).")
@click.option("--explain", is_flag=True, default=False, help="Say why each node was included or left out.")
@click.option("--out", "out_file", default=None, metavar="FILE",
              help="Also download the bundle tarball to FILE.")
@click.option("--tenant", default=None, help="Assemble for another (enrolled) tenant (SA only).")
@click.pass_context
def atlas_assemble(ctx, subject, goal, budget_tokens, explain, out_file, tenant):
    """Assemble the context bundle for a subject: which node versions, which portion, how many tokens.

    \b
    Examples:
      torana atlas assemble --subject repo:github.com/acme/api --explain
      torana atlas assemble --subject tenant --budget 40000 --out bundle.tar
      TORANA_PROFILE=SA torana atlas assemble --subject tenant --tenant <TENANT_ID> --explain
    """
    fmt, _, _ = _fmt(ctx)
    client = _client(ctx)
    body = _params(subject=subject, goal=goal, budget_tokens=budget_tokens)
    body["explain"] = explain
    scope = _params(tenant=tenant)
    data = _call(client.post, "atlas/assemble", json=body, params=scope or None)
    if out_file and isinstance(data, dict) and data.get("bundle_id"):
        content, _ = _call(client.get_bytes, f"atlas/bundles/{data['bundle_id']}", params=scope or None)
        with open(out_file, "wb") as f:
            f.write(content)
        if fmt == "text":
            click.echo(f"wrote {out_file} ({len(content)} bytes)", err=True)
    if fmt == "text" and isinstance(data, dict):
        _render_assemble(data)
        return
    output(data, fmt=fmt)


# --- export -----------------------------------------------------------------

@atlas.command(name="export")
@click.option("--out", "out_dir", required=True, metavar="DIR", help="Directory to unpack the tree into.")
@click.option("--path", "path", default=None, metavar="PATH",
              help="Only this node and everything under it (rendered indexes and cards included); default: the whole tree.")
@click.option("--tenant", default=None, help="Export another (enrolled) tenant's tree (SA only).")
@click.pass_context
def atlas_export(ctx, out_dir, path, tenant):
    """Export the whole tenant tree, or one node and what is under it (every node's current version), into a directory.

    The layout is flat, the Agent Skills one: `skills/<skill-name>/SKILL.md` (and the rest of each skill) beside
    `index.json`; a skill name is what `torana atlas skill NAME` takes (`node <PATH> get` prints it).
    Code indexes are left out (`index.json` lists them under `omitted`); download a node to get them
    (`torana atlas node <PATH> export`), or ask through `torana atlas reachability`.

    \b
    Examples:
      torana atlas export --out ./atlas-export
      torana atlas export --path code/acme/api --out ./api-skills
      TORANA_PROFILE=SA torana atlas export --tenant <TENANT_ID> --out ./t2-atlas
    """
    content, _ = _call(_client(ctx).get_bytes, "atlas/export",
                          params={"format": "tar", **_params(path=path, tenant=tenant)})
    files = extract_tar(content, out_dir)
    report_written(ctx, {"out": out_dir, "files": len(files)},
                   f"exported {len(files)} files to {out_dir}")


# --- plan -------------------------------------------------------------------

@atlas.command(name="plan")
@click.option("--template", "templates", multiple=True,
              help="Limit the plan to this template (repeatable for reconcile; one for --rebuild), e.g. repository.")
@click.option("--tenant", default=None, help="Plan another tenant (SA only; default: your own).")
@click.option("--bump-kind", "bump_kind", default=None, metavar="KIND",
              help="Instead: what bumping this kind's version would cost (nodes that go due, projected $).")
@click.option("--rebuild", "rebuild", is_flag=True, default=False,
              help="Instead (SA only): plan a bulk rebuild; narrow it with --tier/--profile/--effective/--trial.")
@click.option("--tier", type=click.Choice(["hot", "warm", "cold"]), default=None, help="With --rebuild: only this tier.")
@click.option("--profile", "profile", default=None, metavar="NAME", help="With --rebuild: only nodes last built with / pinned to this profile.")
@click.option("--effective", is_flag=True, default=False, help="With --rebuild: use the profile that would run now.")
@click.option("--trial", is_flag=True, default=False, help="With --rebuild: plan it as a trial of --profile.")
@click.option("--include-tier-drift", "include_tier_drift", is_flag=True, default=False,
              help="With --rebuild: include nodes whose tier changed since their last build.")
@click.pass_context
def atlas_plan(ctx, templates, tenant, bump_kind, rebuild, tier, profile, effective, trial, include_tier_drift):
    """Dry run (needs atlas:admin): which nodes a reconcile would create or orphan, and the projected cost.

    With --bump-kind K: the nodes a kind-version bump would make due, and the cost. With --rebuild (SA only):
    the nodes and projected cost of a bulk rebuild. Writes nothing.

    \b
    Examples:
      torana atlas plan
      torana atlas plan --template repository --json
      torana atlas plan --bump-kind repository
      TORANA_PROFILE=SA torana atlas plan --rebuild --tenant <TENANT_ID> --template repository --tier warm --effective
    """
    fmt, _, _ = _fmt(ctx)
    if bump_kind and rebuild:
        raise click.UsageError("--bump-kind and --rebuild are separate plans: pick one")
    sub = _params(tier=tier, profile=profile, effective=effective, trial=trial, include_tier_drift=include_tier_drift)
    if sub and not rebuild:
        raise click.UsageError("--tier, --profile, --effective, --trial and --include-tier-drift go with --rebuild")
    body = {"templates": list(templates)}
    if tenant:
        body["tenant"] = tenant
    if bump_kind:
        body["bump_kind"] = bump_kind
    if rebuild:
        if len(templates) > 1:
            raise click.UsageError("--rebuild takes one --template")
        body["templates"] = []
        body["rebuild"] = {**sub, **({"template": templates[0]} if templates else {}),
                           **({"tenant": tenant} if tenant else {})}
    output(_call(_client(ctx).post, "atlas/plan", json=body), fmt=fmt)


# --- prune ------------------------------------------------------------------

@atlas.command(name="prune")
@click.option("--tenant", default=None, help="Prune another tenant (SA only; default: your own).")
@click.option("--yes", "-y", is_flag=True, default=False, help="Delete. Without it the command only reports what it would delete.")
@click.pass_context
def atlas_prune(ctx, tenant, yes):
    """Delete the nodes of every kind switched off for the tenant (needs atlas:write; SA may pass --tenant).

    Disabling a kind (`kind.enabled`) only hides it. This removes the node rows of the disabled card and map kinds
    (image, namespace, cluster by default). Built skills are never touched. Without --yes it is a dry run.
    Turn a kind back on with `policy set kind.enabled`, then the next reconcile recreates its nodes.

    \b
    Examples:
      torana atlas prune                      # dry run: what would go
      torana atlas prune --yes
      TORANA_PROFILE=SA torana atlas prune --tenant <TENANT_ID> --yes
    """
    fmt, _, _ = _fmt(ctx)
    if yes:
        _confirm("Delete the nodes of every disabled card/map kind?", yes=True)
    data = _call(_client(ctx).post, "atlas/prune", json={"dry_run": not yes}, params=_params(tenant=tenant))
    output(data, fmt=fmt)


# --- metrics ----------------------------------------------------------------

@atlas.command(name="metrics")
@click.option("--since", default=None, help="Window: 24h, 7d, 30d, or an ISO time (default: the server's).")
@click.option("--tenant", default=None, help="Another tenant's metrics (SA only).")
@click.pass_context
def atlas_metrics(ctx, since, tenant):
    """Show Atlas health as one object: health now, store, lifecycle, runs and stages, failures by kind and cause,
    sessions, assembly, requests, consumers, quality, cost. The same SQL as the Grafana dashboard `pantheon-atlas`.
    Text output leads with the health line; --json is the server's object unchanged.

    \b
    Examples:
      torana atlas metrics --since 7d
      torana atlas metrics --json | jq .failures.by_kind
    """
    fmt, _, _ = _fmt(ctx)
    data = _call(_client(ctx).get, "atlas/metrics", params=_params(since=since_to_iso(since), tenant=tenant))
    if fmt == "text" and isinstance(data, dict) and data.get("health"):
        click.echo(metrics_health_line(data["health"]))
        if (data.get("failures") or {}).get("by_kind"):
            click.echo(by_kind_line(data["failures"]["by_kind"], count="failed_runs",
                                    lead=f"Failed since {data.get('since', '')}, by kind"))
    output(data, fmt=fmt)


def metrics_health_line(h: dict) -> str:
    """The health row in words, ✗ on what needs a person (stuck, degraded). Every number is the server's."""
    def n(key: str) -> int:
        return int(h.get(key) or 0)
    flag = "✗ " if n("stuck_runs") or n("degraded_nodes") else "✓ "
    return (f"{flag}{n('running_runs')} running · {n('stuck_runs')} stuck · {n('failed_runs_24h')} failed (24 h) · "
            f"{n('degraded_nodes')} degraded · {n('writes_deferred')} writes deferred · "
            f"${float(h.get('spent_today_usd') or 0):.2f} of ${float(h.get('limit_today_usd') or 0):.2f} spent today")


# --- summary ----------------------------------------------------------------

def summary_sentence(s: dict) -> str:
    """The one-sentence reading of GET /atlas/summary. Words only; every number comes from the server."""
    if not s.get("enrolled"):
        return "Atlas is off for this tenant: it is not enrolled (SA: torana atlas enrolments add)."
    k, b = s.get("skills") or {}, s.get("builders") or {}
    builders = ("builders paused (none configured)" if b.get("paused")
                else f"{b.get('running', 0)} of {b.get('configured', 0)} builders running")
    return (f"{k.get('selected', 0)} of {k.get('total', 0)} skills selected: {k.get('written', 0)} written, "
            f"{k.get('not_written', 0)} not written yet, {k.get('failing', 0)} failing; {builders}.")


def summary_snapshot_lines(s: dict) -> list:
    """OI-180 (contract C3): `Code facts: 7 of 7 indexed · Skills: 5 written, 2 waiting for the model`, then the
    server's skill-writing words. Every count is the server's; a server without snapshots prints nothing."""
    snaps, k = s.get("snapshots"), s.get("skills") or {}
    if not isinstance(snaps, dict):
        return []
    indexed, missing = snaps.get("indexed", 0), snaps.get("not_indexed", 0)
    skills = f"{k.get('written', 0)} written, {k.get('waiting_for_model', 0)} waiting for the model"
    other = {r: n for r, n in (k.get("deferred_by_reason") or {}).items()
             if n and r not in ("harness_unavailable", "auth_failed")}
    skills += "".join(f", {n} waiting ({r.replace('_', ' ')})" for r, n in sorted(other.items()))
    out = [f"Code facts: {indexed} of {indexed + missing} indexed · Skills: {skills}"]
    writing = state_line("Skill writing", s.get("skill_writing"))
    return out + ([writing] if writing else [])


def build_cost(spend: dict) -> str:
    """`a build costs about $0.63, at most $2.00`; `typical_build_usd` null = no build history yet."""
    typical, cap = spend.get("typical_build_usd"), spend.get("build_cap_usd")
    most = f", at most ${float(cap):.2f}" if cap is not None else ""
    if typical is None:
        return "no cost history yet" + most
    return f"a build costs about ${float(typical):.2f}{most}"


def _when(event: dict | None, with_cause: bool = False) -> str:
    if not event:
        return "none"
    out = f"{event.get('path') or '?'} at {human_time(event.get('at')) or '?'}"
    return out + (f" ({event['cause']})" if with_cause and event.get("cause") else "")


@atlas.command(name="summary")
@click.option("--tenant", default=None, help="Another tenant's summary (SA only).")
@click.pass_context
def atlas_summary(ctx, tenant):
    """One reading of the tenant's Atlas: skills selected/written/failing, builders, spend, last success/failure.

    The server computes every count (the admin page reads the same payload).

    \b
    Examples:
      torana atlas summary
      TORANA_PROFILE=SA torana atlas summary --tenant <TENANT_ID> --json
    """
    fmt, _, _ = _fmt(ctx)
    data = _call(_client(ctx).get, "atlas/summary", params=_params(tenant=tenant) or None)
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt)
        return
    click.echo(summary_sentence(data))
    k, b, sp = data.get("skills") or {}, data.get("builders") or {}, data.get("spend") or {}
    for line in summary_snapshot_lines(data):
        click.echo(line)
    rows = [
        ("tenant", data.get("tenant_id")),
        ("enrolled", "yes" if data.get("enrolled") else "no"),
        ("skills total", k.get("total")),
        ("selected", k.get("selected")),
        ("available (not selected)", k.get("available")),
        ("written", k.get("written")),
        ("not written yet", k.get("not_written")),
        ("failing", k.get("failing")),
        ("never include (excluded)", k.get("excluded")),
        ("builders", f"{b.get('running', 0)} running of {b.get('configured', 0)} configured"
                     + (" (paused)" if b.get("paused") else "")),
        ("spend today", f"${float(sp.get('today_usd') or 0):.2f} of ${float(sp.get('limit_usd') or 0):.2f}"),
        *([("build cost", build_cost(sp))] if "typical_build_usd" in sp or "build_cap_usd" in sp else []),
        ("last success", _when(data.get("last_success"))),
        ("last failure", _when(data.get("last_failure"), with_cause=True)),
    ]
    width = max(len(name) for name, _ in rows)
    click.echo("")
    for name, value in rows:
        click.echo(f"  {name.ljust(width)}  {value if value is not None else '—'}")


# --- consent purge (OI-169) -------------------------------------------------

@atlas.group(name="consent", invoke_without_command=True)
@click.pass_context
def atlas_consent(ctx):
    """What Atlas holds and deletes when a tenant withdraws a source's consent (grant/revoke: torana integrations
    knowledge-consent)."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def purges_sentence(data: dict) -> str:
    """The one-sentence reading of GET /atlas/consent/purges. Every number and time comes from the server."""
    h = data.get("purge_within_h")
    if not data.get("enforced"):
        return "Consent is not enforced for this tenant: nothing is hidden or deleted for consent."
    items = data.get("items") or []
    if not items:
        return f"No source's consent is withdrawn. A withdrawn source's knowledge is hidden at once and deleted within {h} h."
    pending = sum(int(i.get("pending_versions") or 0) for i in items)
    purged = sum(int(i.get("purged_versions") or 0) for i in items)
    if any("pending_snapshots" in i or "purged_snapshots" in i for i in items):     # OI-180: code snapshots too
        ps = sum(int(i.get("pending_snapshots") or 0) for i in items)
        ds = sum(int(i.get("purged_snapshots") or 0) for i in items)
        return (f"{pending} version(s) and {ps} code snapshot(s) hidden and waiting to be deleted, {purged} version(s) "
                f"and {ds} code snapshot(s) deleted, across {len(items)} source(s). "
                f"Knowledge from a withdrawn source is deleted within {h} h; granting it again before then restores it.")
    return (f"{pending} version(s) hidden and waiting to be deleted, {purged} deleted, across {len(items)} source(s). "
            f"Knowledge from a withdrawn source is deleted within {h} h; granting it again before then restores it.")


@atlas_consent.command(name="purges")
@click.option("--tenant", default=None, help="Another tenant's purge state (SA only).")
@click.pass_context
def atlas_consent_purges(ctx, tenant):
    """Per source whose consent was withdrawn: when, by when its hidden versions are deleted, how many wait, how many
    were deleted and when (SECURITY.md § D8.4.1 of pantheon-knowledge).

    \b
    Examples:
      torana atlas consent purges
      TORANA_PROFILE=SA torana atlas consent purges --tenant <TENANT_ID> --json
    """
    fmt, raw, fields = _fmt(ctx)
    data = _call(_client(ctx).get, "atlas/consent/purges", params=_params(tenant=tenant) or None)
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt, raw=raw, fields=fields)
        return
    click.echo(purges_sentence(data))
    items = [{**i, "state": ("withdrawn" if i.get("revoked") else "granted again"),
              "revoked_at": human_time(i.get("revoked_at")) or "—", "purge_due_at": human_time(i.get("purge_due_at")) or "—",
              "last_purged_at": human_time(i.get("last_purged_at")) or "—"} for i in data.get("items") or []]
    if items:
        click.echo("")
        output({"items": items, "total": len(items)}, fmt=fmt, raw=raw, fields=fields, columns=[
            ("source", "SOURCE", 48), ("state", "STATE", 13), ("revoked_at", "WITHDRAWN", 18),
            ("purge_due_at", "DELETED BY", 18), ("pending_versions", "WAITING", 7), ("purged_versions", "DELETED", 7),
            *([("pending_snapshots", "PENDING SNAPSHOTS", 17), ("purged_snapshots", "DELETED SNAPSHOTS", 17)]
              if any("pending_snapshots" in i or "purged_snapshots" in i for i in items) else []),
            ("last_purged_at", "LAST DELETED", 18)])


# --- jobs (SA) --------------------------------------------------------------

@atlas.group(name="jobs", invoke_without_command=True)
@click.pass_context
def atlas_jobs(ctx):
    """SA only. Run one Atlas job by hand: reconcile, due, build, reap, reset-failures, restamp-source-sets,
    backfill-snapshots; or read
    job status.

    Every job needs a super-admin of the bootstrap tenant (TORANA_PROFILE=SA) plus atlas:admin.

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas jobs status
      TORANA_PROFILE=SA torana atlas jobs reconcile --tenant <TENANT_ID> --dry-run
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@atlas_jobs.command(name="reconcile")
@click.option("--tenant", "tenant_id", required=True, help="The tenant to reconcile.")
@click.option("--template", default=None, help="Only this template.")
@click.option("--dry-run", "preview", is_flag=True, default=False, help="Return the diff without writing.")
@click.pass_context
def atlas_jobs_reconcile(ctx, tenant_id, template, preview):
    """SA only. Reconcile once: create, orphan and re-parent nodes to match the tenant's data.

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas jobs reconcile --tenant <TENANT_ID> --dry-run
    """
    fmt, _, _ = _fmt(ctx)
    body = _params(tenant_id=tenant_id, template=template)
    body["dry_run"] = preview
    output(_call(_client(ctx).post, "atlas/jobs/reconcile", json=body), fmt=fmt)


@atlas_jobs.command(name="due")
@click.option("--tenant", "tenant_id", required=True, help="The tenant to recompute.")
@click.pass_context
def atlas_jobs_due(ctx, tenant_id):
    """SA only. Recompute which nodes are due once and return the due list.

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas jobs due --tenant <TENANT_ID>
    """
    fmt, _, _ = _fmt(ctx)
    output(_call(_client(ctx).post, "atlas/jobs/due", json={"tenant_id": tenant_id}), fmt=fmt)


@atlas_jobs.command(name="build")
@click.option("--tenant", "tenant_id", required=True, help="The tenant that owns the node.")
@click.option("--node", "node_path", required=True, metavar="PATH", help="The node to build, e.g. code/acme/api.")
@click.option("--phase", type=click.Choice(["fetch", "session", "validate", "all"]), default="all",
              show_default=True,
              help="Stop after this phase. The run then stays `running` and keeps its directory; a second `jobs build` of the "
                   "same node resumes it. Cannot be combined with --wait.")
@click.option("--harness", type=click.Choice(["claude-code", "noop"]), default=None,
              help="The session harness for THIS run; it wins over the node's builder profile (OI-215). Default: the "
                   "profile's harness. noop ($0) only on a development stack with the noop harness enabled.")
@click.option("--stage", type=click.Choice(["index", "write", "all"]), default="all", show_default=True,
              help="index: only the code facts and code index (free, no model, never touches the skill); write: the "
                   "skill (refused with the reasons when the model or the budget is not available); all: both.")
@wait_options
@click.option("--keep", is_flag=True, default=False, help="Keep the build's output directory for inspection.")
@click.pass_context
def atlas_jobs_build(ctx, tenant_id, node_path, phase, harness, stage, wait, poll, wait_timeout, keep):
    """SA only. Force a build of one node (bypasses tier and the no-change skip, not the lease or budget).

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas jobs build --tenant <TENANT_ID> --node code/acme/api --phase fetch --keep
      TORANA_PROFILE=SA torana atlas jobs build --tenant <TENANT_ID> --node code/acme/api --wait
      TORANA_PROFILE=SA torana atlas jobs build --tenant <TENANT_ID> --node code/acme/api --stage index --wait

    A `--phase` other than `all` stops the run there ("a phase-stopped run returns running and keeps its run dir"), so
    `--wait` with it could never finish: it is refused. Stop at a phase, look, then run `jobs build` again (no `--phase`)
    to resume the same run, and `--wait` on that one.
    """
    if stage == "index" and phase in ("session", "validate"):
        raise click.UsageError(f"--stage index runs no session: --phase {phase} does not apply (use fetch or all).")
    if wait and phase != "all":
        raise click.UsageError(f"--wait cannot be combined with --phase {phase}: a phase-stopped run stays `running` until a "
                               "second `jobs build` resumes it, so --wait would never return. Drop --phase, or drop --wait.")
    fmt, _, _ = _fmt(ctx)
    client = _client(ctx)
    body = {"tenant_id": tenant_id, "node": node_path, "phase": phase, "keep": keep}
    if harness:                             # omitted = the node's profile decides (OI-215); explicit = it wins
        body["harness"] = harness
    if stage != "all":                      # the server's default; an older server never sees the field
        body["stage"] = stage
    data = _call(client.post, "atlas/jobs/build", json=body)        # answers at once; --wait polls the run
    run_id = data.get("run_id") if isinstance(data, dict) else None
    if already_building(data):
        say_already_building(run_id)
    if isinstance(data, dict) and data.get("harness"):  # the harness the run's session uses, as the server resolved it
        click.echo(f"harness: {data['harness']}", err=True)
    if not wait or not run_id:
        output(data, fmt=fmt)
        return
    wait_for_run(ctx, client, run_id, tenant_id, poll, wait_timeout)


@atlas_jobs.command(name="reap")
@click.option("--tenant", "tenant_id", required=True, help="The tenant to reap.")
@click.option("--dry-run", "preview", is_flag=True, default=False, help="Return what would be reaped.")
@click.pass_context
def atlas_jobs_reap(ctx, tenant_id, preview):
    """SA only. Reap once: tombstone and delete orphaned nodes past their grace period.

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas jobs reap --tenant <TENANT_ID> --dry-run
    """
    fmt, _, _ = _fmt(ctx)
    output(_call(_client(ctx).post, "atlas/jobs/reap",
                 json={"tenant_id": tenant_id, "dry_run": preview}), fmt=fmt)


@atlas_jobs.command(name="reset-failures")
@click.option("--tenant", "tenant_id", required=True, help="The tenant whose failed nodes to reset.")
@click.option("--node", "node_path", default=None, metavar="PATH", help="Only this node (default: every node).")
@click.pass_context
def atlas_jobs_reset_failures(ctx, tenant_id, node_path):
    """SA only. After fixing what made builds fail, clear the retry state: degraded nodes go back to active
    with retry_count 0, so the scheduler builds them again. Prints how many nodes were reset.

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas jobs reset-failures --tenant <TENANT_ID>
      TORANA_PROFILE=SA torana atlas jobs reset-failures --tenant <TENANT_ID> --node code/acme/api
    """
    fmt, _, _ = _fmt(ctx)
    body = _params(tenant_id=tenant_id, node_path=node_path)
    data = _call(_client(ctx).post, "atlas/jobs/reset-failures", json=body)
    if fmt == "text" and isinstance(data, dict):
        count = next((v for k, v in data.items() if isinstance(v, int)), None)
        click.echo(f"reset {count if count is not None else data} node(s) for tenant {tenant_id}"
                   + (f" ({node_path})" if node_path else ""))
        return
    output(data, fmt=fmt)


def restamp_sentence(data: dict) -> str:
    """The restamp report in one paragraph (OI-178)."""
    n, done = data.get("examined", 0), data.get("stamped", 0)
    head = (f"Dry run: would stamp {done} of {n} unstamped version(s)" if data.get("dry_run")
            else f"Stamped {data.get('written', 0)} of {n} unstamped version(s)")
    head += f" for tenant {data.get('tenant_id')}; {data.get('untraceable', 0)} untraceable (hidden until rebuilt once " \
            "consent is enforced)"
    lines = [head + "."]
    if data.get("already_stamped"):
        lines.append(f"{data['already_stamped']} were stamped meanwhile by another run.")
    if data.get("skipped"):
        why = ", ".join(f"{k}: {v}" for k, v in sorted((data.get("skipped_reasons") or {}).items()))
        lines.append(f"Skipped {data['skipped']} (left unstamped, run again): {why}.")
    if data.get("remaining"):
        lines.append(f"{data['remaining']} more wait beyond --limit: run again.")
    if data.get("dry_run") and done:
        lines.append("Nothing was written. Add --apply to stamp them.")
    return "\n".join(lines)


@atlas_jobs.command(name="restamp-source-sets")
@click.option("--tenant", "tenant_id", required=True, help="The tenant whose versions to stamp.")
@click.option("--apply", "apply", is_flag=True, default=False, help="Write the stamps. Without it, a dry run.")
@click.option("--limit", type=click.IntRange(1, 5000), default=None,
              help="Versions per call (server default 500); `remaining` says how many wait.")
@click.pass_context
def atlas_jobs_restamp_source_sets(ctx, tenant_id, apply, limit):
    """SA only. Give every knowledge version built before source tracking its source set (which integrations and
    pushed-data types it was built from), recomputed from its cited rows and its repository's integration. No model
    is called. A version that cannot be traced is stamped `untraceable`: once consent is enforced it stays hidden
    until rebuilt. Run this, and see it report clean, before turning `consent.enforced` on.

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas jobs restamp-source-sets --tenant <TENANT_ID>
      TORANA_PROFILE=SA torana atlas jobs restamp-source-sets --tenant <TENANT_ID> --apply
    """
    fmt, raw, fields = _fmt(ctx)
    body = {"tenant_id": tenant_id, "dry_run": not apply}
    if limit is not None:
        body["limit"] = limit
    data = _call(_client(ctx).post, "atlas/jobs/restamp-source-sets", json=body)
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt, raw=raw, fields=fields)
        return
    click.echo(restamp_sentence(data))
    per = [{"source": k, "versions": v} for k, v in sorted((data.get("per_source") or {}).items())]
    if per:
        click.echo("")
        output({"items": per, "total": len(per)}, fmt=fmt, raw=raw, fields=fields,
               columns=[("source", "SOURCE", 60), ("versions", "VERSIONS", 9)])


def backfill_sentence(data: dict) -> str:
    """The backfill-snapshots report in words (OI-180 § 3.3.3). Every count is the server's."""
    head = (f"Dry run: would copy {data.get('created', 0)} of {data.get('examined', 0)} node(s)' code facts into snapshots"
            if data.get("dry_run") else
            f"Copied {data.get('created', 0)} of {data.get('examined', 0)} node(s)' code facts into snapshots")
    lines = [head + " (free: no model, clone or datalake call)."]
    skipped = {k: v for k, v in (data.get("skipped") or {}).items() if v}
    if skipped:
        lines.append("Skipped: " + ", ".join(f"{k.replace('_', ' ')} {v}" for k, v in sorted(skipped.items())) + ".")
    if data.get("remaining"):
        lines.append(f"{data['remaining']} more wait beyond --limit: run again.")
    if data.get("dry_run") and data.get("created"):
        lines.append("Nothing was written. Add --apply to copy them.")
    return "\n".join(lines)


@atlas_jobs.command(name="backfill-snapshots")
@click.option("--tenant", "tenant_id", required=True, help="The tenant whose written versions to copy.")
@click.option("--apply", "apply", is_flag=True, default=False, help="Write the snapshots. Without it, a dry run.")
@click.option("--limit", type=click.IntRange(1, 500), default=None,
              help="Nodes per call (server default 50); `remaining` says how many wait.")
@click.pass_context
def atlas_jobs_backfill_snapshots(ctx, tenant_id, apply, limit):
    """SA only. Copy the model-free part of every node's current written version (code facts, extractor anchors, code
    index) into its first code snapshot, so readers have a snapshot before the node is indexed again. Records the
    model wrote are dropped. No model, clone or datalake call. The scheduler also does this a few nodes at a time.

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas jobs backfill-snapshots --tenant <TENANT_ID>
      TORANA_PROFILE=SA torana atlas jobs backfill-snapshots --tenant <TENANT_ID> --apply --limit 20
    """
    fmt, raw, fields = _fmt(ctx)
    body = {"tenant_id": tenant_id, "dry_run": not apply}
    if limit is not None:
        body["limit"] = limit
    data = _call(_client(ctx).post, "atlas/jobs/backfill-snapshots", json=body)
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt, raw=raw, fields=fields)
        return
    click.echo(backfill_sentence(data))
    if data.get("items"):
        click.echo("")
        output({"items": data["items"], "total": len(data["items"])}, fmt=fmt, raw=raw, fields=fields, columns=[
            ("path", "NODE", 44), ("version", "FROM VER", 8), ("files", "FILES", 6),
            ("llm_records_dropped", "MODEL RECORDS DROPPED", 21)])


@atlas_jobs.command(name="status")
@click.pass_context
def atlas_jobs_status(ctx):
    """SA only. Show the scheduler leader, workers, running runs, queue depth, and whether skills can be written here
    (the model harness: available, not available and why, or not known).

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas jobs status
      TORANA_PROFILE=SA torana atlas jobs status --json
    """
    fmt, _, _ = _fmt(ctx)
    data = _call(_client(ctx).get, "atlas/jobs/status")
    line = state_line("Skill writing", (data or {}).get("harness")) if isinstance(data, dict) else ""
    if fmt == "text" and line:
        click.echo(line)
    output(data, fmt=fmt)
