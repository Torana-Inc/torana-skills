"""torana audit-logs — audit log commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output

_LIST_COLS = [
    ("id", "ID", 36),
    ("action", "ACTION", 25),
    ("resource_type", "RESOURCE", 20),
    ("resource_id", "RESOURCE_ID", 36),
    ("user_email", "USER", 35),
    ("created_at", "TIMESTAMP", 20),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(name="audit-logs")
def audit_logs():
    """View audit logs.

    \b
    Examples:
      torana audit-logs list
      torana audit-logs list --action create --resource rules
      torana audit-logs get <UUID>
      torana audit-logs stats
    """


@audit_logs.command(name="list")
@click.option("--action", default=None, help="Filter by action (create, update, delete, etc.).")
@click.option("--resource", default=None, help="Filter by resource type.")
@click.option("--user", default=None, help="Filter by user email.")
@click.option("--since", default=None, help="ISO datetime lower bound.")
@click.option("--until", default=None, help="ISO datetime upper bound.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.pass_context
def audit_logs_list(ctx, action, resource, user, since, until, page, page_size, fetch_all):
    """List audit log entries.

    \b
    Examples:
      torana audit-logs list
      torana audit-logs list --action delete --since 2026-08-01
      torana audit-logs list --user <USER_ID> --resource rule
      torana audit-logs list --json | jq '.items[] | {action, resource, created_at}'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if action:
        params["action"] = action
    if resource:
        params["resource_type"] = resource
    if user:
        params["user_email"] = user
    if since:
        params["since"] = since
    if until:
        params["until"] = until

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                p.update({k: v for k, v in params.items() if k not in ("skip", "limit")})
                data = client.get("audit-logs/", params=p)
                items = data.get("items", data if isinstance(data, list) else [])
                all_items.extend(items)
                total = data.get("total", len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items), "page": 1,
                      "page_size": len(all_items)}
        else:
            data = client.get("audit-logs/", params=params)
            result = data if isinstance(data, dict) and "items" in data else {
                "items": data if isinstance(data, list) else [],
                "total": len(data) if isinstance(data, list) else 0,
                "page": page, "page_size": effective_page_size
            }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@audit_logs.command(name="get")
@click.argument("log_id", metavar="LOG_ID")
@click.pass_context
def audit_logs_get(ctx, log_id):
    """Get details for a specific audit log entry.

    \b
    Examples:
      torana audit-logs list                   # find the log id
      torana audit-logs get <LOG_ID>
      torana audit-logs log <LOG_ID> tools     # per-tool execution detail for this turn
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"audit-logs/{log_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@audit_logs.command(name="stats")
@click.option("--since", default=None, help="ISO datetime lower bound.")
@click.option("--until", default=None, help="ISO datetime upper bound.")
@click.pass_context
def audit_logs_stats(ctx, since, until):
    """Get audit log statistics (action counts, top users, etc.)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    params = {}
    if since:
        params["since"] = since
    if until:
        params["until"] = until

    client = _client(ctx)
    try:
        data = client.get("audit-logs/stats/", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt if fmt != "text" else "json")


@audit_logs.command(name="summary")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--start-date", "start_date", default=None, help="Start date for filtering")
@click.option("--end-date", "end_date", default=None, help="End date for filtering")
@click.option("--user-id", "user_id", default=None, help="Filter by user ID")
@click.option("--model-name", "model_name", default=None, help="Filter by model name")
@click.option("--agent-id", "agent_id", default=None, help="Filter by agent ID")
@click.pass_context
def audit_summary(ctx, start_date, end_date, user_id, model_name, agent_id, page, page_size, fetch_all):
    """Get Token Summary."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "audit/analytics/tokens/summary"
    params = {}
    if start_date is not None:
        params["start_date"] = start_date
    if end_date is not None:
        params["end_date"] = end_date
    if user_id is not None:
        params["user_id"] = user_id
    if model_name is not None:
        params["model_name"] = model_name
    if agent_id is not None:
        params["agent_id"] = agent_id
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@audit_logs.command(name="by-model")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--start-date", "start_date", default=None, help="Start date for filtering")
@click.option("--end-date", "end_date", default=None, help="End date for filtering")
@click.option("--user-id", "user_id", default=None, help="Filter by user ID")
@click.option("--model-name", "model_name", default=None, help="Filter by model name")
@click.option("--agent-id", "agent_id", default=None, help="Filter by agent ID")
@click.option("--limit", "limit", type=int, default=10, help="Maximum number of results")
@click.pass_context
def audit_by_model(ctx, start_date, end_date, user_id, model_name, agent_id, limit, page, page_size, fetch_all):
    """Get Cost By Model."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "audit/analytics/cost/by-model"
    params = {}
    if start_date is not None:
        params["start_date"] = start_date
    if end_date is not None:
        params["end_date"] = end_date
    if user_id is not None:
        params["user_id"] = user_id
    if model_name is not None:
        params["model_name"] = model_name
    if agent_id is not None:
        params["agent_id"] = agent_id
    if limit is not None:
        params["limit"] = limit
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@audit_logs.command(name="tokens-by-model")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--start-date", "start_date", default=None, help="Start date for filtering")
@click.option("--end-date", "end_date", default=None, help="End date for filtering")
@click.option("--user-id", "user_id", default=None, help="Filter by user ID")
@click.option("--model-name", "model_name", default=None, help="Filter by model name")
@click.option("--agent-id", "agent_id", default=None, help="Filter by agent ID")
@click.option("--limit", "limit", type=int, default=10, help="Maximum number of results")
@click.pass_context
def audit_logs_tokens_by_model(ctx, start_date, end_date, user_id, model_name, agent_id, limit, page, page_size, fetch_all):
    """Get Tokens By Model."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "audit/analytics/tokens/by-model"
    params = {}
    if start_date is not None:
        params["start_date"] = start_date
    if end_date is not None:
        params["end_date"] = end_date
    if user_id is not None:
        params["user_id"] = user_id
    if model_name is not None:
        params["model_name"] = model_name
    if agent_id is not None:
        params["agent_id"] = agent_id
    if limit is not None:
        params["limit"] = limit
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@audit_logs.command(name="cache")
@click.argument("SESSION_ID", metavar="SESSION_ID")
@click.pass_context
def audit_cache(ctx, session_id):
    """Get Session Cache Analytics."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"audit/analytics/sessions/{session_id}/cache"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@audit_logs.command(name="analytics-summary")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--start-date", "start_date", default=None, help="Start date for filtering")
@click.option("--end-date", "end_date", default=None, help="End date for filtering")
@click.option("--user-id", "user_id", default=None, help="Filter by user ID")
@click.option("--model-name", "model_name", default=None, help="Filter by model name")
@click.option("--agent-id", "agent_id", default=None, help="Filter by agent ID")
@click.pass_context
def audit_logs_analytics_summary(ctx, start_date, end_date, user_id, model_name, agent_id, page, page_size, fetch_all):
    """Get Analytics Summary."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "audit/analytics/summary"
    params = {}
    if start_date is not None:
        params["start_date"] = start_date
    if end_date is not None:
        params["end_date"] = end_date
    if user_id is not None:
        params["user_id"] = user_id
    if model_name is not None:
        params["model_name"] = model_name
    if agent_id is not None:
        params["agent_id"] = agent_id
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@audit_logs.command(name="logs")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--user-id", "user_id", default=None, help="Filter by user ID")
@click.option("--model-name", "model_name", default=None, help="Filter by model name")
@click.option("--agent-id", "agent_id", default=None, help="Filter by agent ID")
@click.option("--execution-status", "execution_status", default=None, help="Filter by execution status")
@click.option("--start-date", "start_date", default=None, help="Start date for filtering")
@click.option("--end-date", "end_date", default=None, help="End date for filtering")
@click.option("--search-query", "search_query", default=None, help="Search in request/response text")
@click.option("--min-cost", "min_cost", default=None, help="Minimum cost threshold")
@click.option("--limit", "limit", type=int, default=50, help="Number of results per page")
@click.option("--offset", "offset", type=int, default=0, help="Number of results to skip")
@click.pass_context
def audit_logs_list_all(ctx, user_id, model_name, agent_id, execution_status, start_date, end_date, search_query, min_cost, limit, offset, page, page_size, fetch_all):
    """Get Audit Logs."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "audit/logs"
    params = {}
    if user_id is not None:
        params["user_id"] = user_id
    if model_name is not None:
        params["model_name"] = model_name
    if agent_id is not None:
        params["agent_id"] = agent_id
    if execution_status is not None:
        params["execution_status"] = execution_status
    if start_date is not None:
        params["start_date"] = start_date
    if end_date is not None:
        params["end_date"] = end_date
    if search_query is not None:
        params["search_query"] = search_query
    if min_cost is not None:
        params["min_cost"] = min_cost
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


# ──────────────────────────────────────────────────────────────────────────
# Instance reads regrouped from `<noun>-by-<param>` leaves onto verbs
# (CLI Discoverability Contract, rule 2 — see ../CLAUDE.md). The route
# parameter belongs in the positional ARGUMENT, not in the command name.
#
# Old flat names remain as HIDDEN aliases for ONE release (D4).
# ──────────────────────────────────────────────────────────────────────────


@audit_logs.group(name="log")
def audit_logs_log_grp():
    """One audit log entry, by id.

    Examples:
      torana audit-logs log get --help
    """


@audit_logs.group(name="compaction-artifact")
def audit_logs_compaction_artifact_grp():
    """One compaction artifact, by id.

    Examples:
      torana audit-logs compaction-artifact get --help
    """


@audit_logs_log_grp.command(name="get")
@click.argument("LOG_ID", metavar="LOG_ID")
@click.option("--include-tools", "include_tools", type=bool, default=True, help="Include tool execution details")
@click.pass_context
def audit_logs_by_log_id(ctx, log_id, include_tools):
    """Get Audit Log By Id."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"audit/logs/{log_id}"
    params = {}
    if include_tools is not None:
        params["include_tools"] = include_tools

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@audit_logs_log_grp.command(name="tools")
@click.argument("LOG_ID", metavar="LOG_ID")
@click.pass_context
def audit_tools_by_log_id(ctx, log_id):
    """Get Tool Execution Details."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"audit/tools/{log_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@audit_logs.command(name="metrics")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--start-date", "start_date", default=None, help="Start date for filtering")
@click.option("--end-date", "end_date", default=None, help="End date for filtering")
@click.option("--user-id", "user_id", default=None, help="Filter by user ID")
@click.option("--model-name", "model_name", default=None, help="Filter by model name")
@click.option("--agent-id", "agent_id", default=None, help="Filter by agent ID")
@click.pass_context
def audit_metrics(ctx, start_date, end_date, user_id, model_name, agent_id, page, page_size, fetch_all):
    """Get System Metrics."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "audit/metrics"
    params = {}
    if start_date is not None:
        params["start_date"] = start_date
    if end_date is not None:
        params["end_date"] = end_date
    if user_id is not None:
        params["user_id"] = user_id
    if model_name is not None:
        params["model_name"] = model_name
    if agent_id is not None:
        params["agent_id"] = agent_id
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@audit_logs.command(name="health")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def audit_health(ctx, page, page_size, fetch_all):
    """Health Check."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "audit/health"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@audit_logs.command(name="sessions")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--start-date", "start_date", default=None, help="Start date for filtering")
@click.option("--end-date", "end_date", default=None, help="End date for filtering")
@click.option("--agent-id", "agent_id", default=None, help="Filter by agent ID")
@click.option("--user-id", "user_id", default=None, help="Filter by user ID")
@click.option("--session-status", "session_status", default=None, help="Filter by status (active, archived, deleted)")
@click.option("--search-query", "search_query", default=None, help="Search in message content, session name, and agent name")
@click.option("--limit", "limit", type=int, default=100, help="Maximum number of sessions to return")
@click.option("--offset", "offset", type=int, default=0, help="Number of sessions to skip")
@click.pass_context
def audit_sessions(ctx, start_date, end_date, agent_id, user_id, session_status, search_query, limit, offset, page, page_size, fetch_all):
    """Get Chat Sessions."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "audit/sessions"
    params = {}
    if start_date is not None:
        params["start_date"] = start_date
    if end_date is not None:
        params["end_date"] = end_date
    if agent_id is not None:
        params["agent_id"] = agent_id
    if user_id is not None:
        params["user_id"] = user_id
    if session_status is not None:
        params["session_status"] = session_status
    if search_query is not None:
        params["search_query"] = search_query
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@audit_logs.command(name="forks")
@click.argument("SESSION_ID", metavar="SESSION_ID")
@click.option("--count-only", "count_only", type=bool, default=False, help="Return only the fork count")
@click.option("--limit", "limit", type=int, default=5, help="Maximum forks to return")
@click.option("--offset", "offset", type=int, default=0, help="Number of forks to skip")
@click.pass_context
def audit_forks(ctx, session_id, count_only, limit, offset):
    """Get Session Forks."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"audit/sessions/{session_id}/forks"
    params = {}
    if count_only is not None:
        params["count_only"] = count_only
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@audit_logs.command(name="messages")
@click.argument("SESSION_ID", metavar="SESSION_ID")
@click.pass_context
def audit_messages(ctx, session_id):
    """Get Session Messages."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"audit/sessions/{session_id}/messages"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@audit_logs.command(name="trace")
@click.argument("SESSION_ID", metavar="SESSION_ID")
@click.pass_context
def audit_trace(ctx, session_id):
    """Get session trace timeline with phases."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"audit/sessions/{session_id}/trace"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@audit_logs.command(name="session")
@click.argument("TRACE_ID", metavar="TRACE_ID")
@click.pass_context
def audit_session(ctx, trace_id):
    """Find session ID for a given OTel trace ID."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"audit/traces/{trace_id}/session"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@audit_logs.command(name="explain-session")
@click.argument("TRACE_ID", metavar="TRACE_ID")
@click.pass_context
def audit_explain_session(ctx, trace_id):
    """Find or create an AI explanation session for a trace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"audit/traces/{trace_id}/explain-session"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@audit_logs.command(name="explain-session-upsert")
@click.argument("SESSION_ID", metavar="SESSION_ID")
@click.pass_context
def audit_logs_explain_session_upsert(ctx, session_id):
    """Find or create an AI explanation session for a chat session."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"audit/sessions/{session_id}/explain-session"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@audit_logs.command(name="trace-summary")
@click.argument("TRACE_ID", metavar="TRACE_ID")
@click.pass_context
def audit_logs_trace_summary(ctx, trace_id):
    """Lightweight summary of a Jaeger trace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"audit/traces/{trace_id}/summary"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@audit_logs.command(name="latency-analysis")
@click.argument("TRACE_ID", metavar="TRACE_ID")
@click.pass_context
def audit_latency_analysis(ctx, trace_id):
    """Analyze LLM response latency from Jaeger trace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"audit/traces/{trace_id}/latency-analysis"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@audit_logs_compaction_artifact_grp.command(name="get")
@click.argument("ARTIFACT_ID", metavar="ARTIFACT_ID")
@click.pass_context
def audit_compaction_artifacts_by_artifact_id(ctx, artifact_id):
    """Get Compaction Artifact."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"audit/compaction-artifacts/{artifact_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@audit_logs.command(name="statistics")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--tenant-id", "tenant_id", default=None, help="Filter by tenant ID")
@click.option("--date-from", "date_from", default=None, help="Filter from date (ISO format)")
@click.option("--date-to", "date_to", default=None, help="Filter to date (ISO format)")
@click.pass_context
def audit_logs_statistics(ctx, tenant_id, date_from, date_to, page, page_size, fetch_all):
    """Get Audit Log Statistics."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "audit-logs/statistics"
    params = {}
    if tenant_id is not None:
        params["tenant_id"] = tenant_id
    if date_from is not None:
        params["date_from"] = date_from
    if date_to is not None:
        params["date_to"] = date_to
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@audit_logs.command(name="security-events")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--tenant-id", "tenant_id", default=None, help="Filter by tenant ID")
@click.option("--hours", "hours", type=int, default=24, help="Look back this many hours (max 168 = 7 days)")
@click.option("--page", "page", type=int, default=1, help="Page number")
@click.option("--page-size", "page_size", type=int, default=50, help="Items per page")
@click.pass_context
def audit_logs_security_events(ctx, tenant_id, hours, page, page_size, fetch_all):
    """Get Security Events."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "audit-logs/security-events"
    params = {}
    if tenant_id is not None:
        params["tenant_id"] = tenant_id
    if hours is not None:
        params["hours"] = hours
    if page is not None:
        params["page"] = page
    if page_size is not None:
        params["page_size"] = page_size
    if page_size is not None:
        params["page_size"] = min(page_size, 100)

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "page": page_num}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


# ---------------------------------------------------------------------------
# audit-logs invokes
# ---------------------------------------------------------------------------

_INVOKES_COLS = [
    ("session_id", "SESSION_ID", 22),
    ("agent_name", "AGENT", 30),
    ("execution_status", "STATUS", 10),
    ("model_name", "MODEL", 24),
    ("input_tokens", "IN_TOK", 8),
    ("output_tokens", "OUT_TOK", 8),
    ("tool_calls_count", "TOOLS", 5),
    ("duration_ms", "MS", 7),
    ("execution_start_time", "STARTED", 26),
]


@audit_logs.command(name="invokes")
@click.option("--agent-id", "agent_id", default=None, help="Filter by agent ID.")
@click.option("--status", "execution_status", default=None,
              help="Filter by execution status (SUCCESS, FAILED, etc.).")
@click.option("--workspace-id", "workspace_id", default=None, help="Filter by workspace ID.")
@click.option("--start-date", "start_date", default=None, help="ISO datetime lower bound.")
@click.option("--end-date", "end_date", default=None, help="ISO datetime upper bound.")
@click.option("--limit", "limit", type=int, default=None, help="Max results (default page_size).")
@click.option("--offset", "offset", type=int, default=0, show_default=True, help="Skip N results.")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate all results.")
@click.pass_context
def audit_logs_invokes(ctx, agent_id, execution_status, workspace_id, start_date, end_date,
                       limit, offset, fetch_all):
    """List invoke sessions (stateful agent invocations without a chat UI).

    \b
    Examples:
      torana audit-logs invokes
      torana audit-logs invokes --workspace-id <UUID>
      torana audit-logs invokes --agent-id <UUID> --status SUCCESS
      torana audit-logs invokes --all --format json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_limit = limit if limit is not None else settings.page_size
    params = {"limit": effective_limit, "offset": offset}
    if agent_id:
        params["agent_id"] = agent_id
    if execution_status:
        params["execution_status"] = execution_status
    if workspace_id:
        params["workspace_id"] = workspace_id
    if start_date:
        params["start_date"] = start_date
    if end_date:
        params["end_date"] = end_date

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            cur_offset = offset
            while True:
                p = {**params, "offset": cur_offset, "limit": effective_limit}
                data = client.get("audit/invokes", params=p)
                items = data.get("items", data) if isinstance(data, dict) else data
                all_items.extend(items if isinstance(items, list) else [])
                total = data.get("total") if isinstance(data, dict) else None
                cur_offset += len(items) if isinstance(items, list) else 0
                if not items or (total is not None and cur_offset >= total):
                    break
            result = {"items": all_items, "total": len(all_items)}
        else:
            result = client.get("audit/invokes", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_INVOKES_COLS)


# ──────────────────────────────────────────────────────────────────────────
# BACK-COMPAT — hidden aliases for the old `<noun>-by-<param>` names.
# ⏳ ONE RELEASE ONLY (decision D4). Delete this block next release.
# ──────────────────────────────────────────────────────────────────────────

_LEGACY_BY_PARAM_AUDIT_LOGS = {
    "compaction-artifacts-by-artifact-id": ("compaction-artifact", "get"),
    "logs-by-log-id": ("log", "get"),
    "tools-by-log-id": ("log", "tools"),
}


def _register_legacy_audit_logs_by_param() -> None:
    """Old flat names, hidden so they cannot be discovered anew."""
    import copy
    for _old, (_sub, _verb) in _LEGACY_BY_PARAM_AUDIT_LOGS.items():
        _grp = audit_logs.commands.get(_sub)
        if not isinstance(_grp, click.Group):
            continue
        _cmd = _grp.commands.get(_verb)
        if _cmd is None:
            continue
        # ⛔ Never let an alias overwrite a real group of the same name.
        if isinstance(audit_logs.commands.get(_old), click.Group):
            continue
        _alias = copy.copy(_cmd)
        _alias.name = _old
        _alias.hidden = True
        audit_logs.add_command(_alias)


_register_legacy_audit_logs_by_param()
