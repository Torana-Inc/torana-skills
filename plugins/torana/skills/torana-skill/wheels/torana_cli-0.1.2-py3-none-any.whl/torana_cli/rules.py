"""torana rules — detection rule management commands."""

import json
import sys
from pathlib import Path
import click
import yaml

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_DRY_RUN, CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW, CollectionGroup
from torana_cli.output import output
from torana_cli.confirm import confirm as _confirm

# Display columns for list output
_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 30),
    ("severity", "SEVERITY", 10),
    ("state", "STATE", 8),
    ("workspace_id", "WORKSPACE", 36),
]

_GET_COLS = None  # Use kv display for single resource


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _load_input_file(file_path: str) -> dict:
    """Load a JSON or YAML input file. '-' reads from stdin."""
    if file_path == "-":
        content = click.get_text_stream("stdin").read()
    else:
        path = Path(file_path)
        if not path.exists():
            click.echo(f"ERROR: File not found: {file_path}", err=True)
            sys.exit(2)
        content = path.read_text()

    # Try JSON first, then YAML
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        pass
    try:
        return yaml.safe_load(content) or {}
    except yaml.YAMLError as e:
        click.echo(f"ERROR: Cannot parse input file: {e}", err=True)
        sys.exit(6)


@click.group(cls=CollectionGroup, singular="rule")
def rules():
    """Manage detection rules (collection operations).

    \b
    Examples:
      torana rules list
      torana rules list --severity high --format json
      torana rules create --name "SSH Brute Force" --severity high --sql "SELECT ..." --workspace-id <UUID>

    \b
    Instance operations (get, update, delete, execute, etc.) use the singular form:
      torana rule <UUID> get
      torana rule <UUID> execute
      torana rule <UUID> update --severity critical
      torana rule <UUID> delete --yes
    """


@rules.command(name="list")
@click.option("--severity", default=None,
              type=click.Choice(["low", "medium", "high", "critical"], case_sensitive=False),
              help="Filter by severity.")
@click.option("--state", default=None,
              type=click.Choice(["active", "inactive", "draft"], case_sensitive=False),
              help="Filter by state.")
@click.option("--workspace-id", default=None, help="Filter by workspace UUID.")
@click.option("--search", default=None, help="Search by name or description.")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", default=None, type=int,
              help="Results per page (max 100, default from config).")
@click.option("--all", "fetch_all", is_flag=True, default=False,
              help="Auto-paginate and return all results.")
@click.option("--validate-sql", "validate_sql", is_flag=True, default=False,
              help="Dry-run each rule's SQL against the datalake (EXPLAIN). Adds a "
                   "tri-state SQL status (valid | invalid | unchecked) + detail per "
                   "rule; invalid sort first, then unchecked (orphaned), then valid.")
@click.pass_context
def rules_list(ctx, severity, state, workspace_id, search, page, page_size, fetch_all,
               validate_sql):
    """List detection rules.

    \b
    Examples:
      torana rules list
      torana rules list --severity high
      torana rules list --workspace-id <UUID> --format table
      torana rules list --validate-sql
      torana rules list --validate-sql --json | jq '.items[] | select(.sql_status == "invalid")'
    """
    list_rules_core(ctx, severity=severity, state=state, workspace_id=workspace_id,
                    search=search, page=page, page_size=page_size, fetch_all=fetch_all,
                    validate_sql=validate_sql)


def list_rules_core(ctx, *, severity=None, state=None, workspace_id=None, search=None,
                    page=1, page_size=None, fetch_all=False, validate_sql=False):
    """Shared rules-list routine.

    Both `torana rules list` (no workspace context) and
    `torana workspace <id> rules list` (workspace-filtered) call this. The ONLY
    difference between them is whether `workspace_id` is bound — the endpoint,
    columns, pagination, and --validate-sql behaviour are identical. Keep this
    the single source of truth; never reimplement a parallel list path.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)

    params = {"page": page, "page_size": effective_page_size}
    if severity:
        params["severity"] = severity
    if state:
        params["state"] = state
    if workspace_id:
        params["workspace_id"] = workspace_id
    if search:
        params["search"] = search
    if validate_sql:
        params["validate_sql"] = "true"

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"page": page_num, "page_size": effective_page_size}
                p.update({k: v for k, v in params.items() if k not in ("page", "page_size")})
                data = client.get("api/v2/rules", params=p)
                items = data.get("items", [])
                all_items.extend(items)
                if len(all_items) >= data.get("total", len(all_items)):
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items), "page": 1,
                      "page_size": len(all_items)}
        else:
            result = client.get("api/v2/rules", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # ⛔ The list endpoint projects `watermark` as null for EVERY rule, including rules
    # that have run and carry a real watermark on `rule <id> get`. A false null is worse
    # than an absent field: it reads as "this rule has never run" and gets used to rule
    # the watermark out of a diagnosis. Drop the key rather than assert something untrue —
    # `rule <id> get` is the surface that can answer it.
    if isinstance(result, dict):
        for _item in result.get("items", []):
            if isinstance(_item, dict) and _item.get("watermark") is None:
                _item.pop("watermark", None)

    columns = _LIST_COLS
    if validate_sql:
        # sql_status is tri-state: valid | invalid | unchecked (orphaned/infra).
        columns = _LIST_COLS + [("sql_status", "SQL", 9), ("sql_error", "SQL_DETAIL", 40)]

    output(result, fmt=fmt, raw=raw, fields=fields, columns=columns)


@rules.command(name="create")
@click.option("--name", default=None, help="Rule name.")
@click.option("--severity", default=None,
              type=click.Choice(["low", "medium", "high", "critical"], case_sensitive=False),
              help="Severity level.")
@click.option("--sql", "sql_command", default=None, help="SQL detection query (SELECT or WITH). "
              "Creates a NEW query inline. Mutually exclusive with --query-id.")
@click.option("--query-id", "query_id", default=None,
              help="Bind an EXISTING query by id (reuses it; no new query is created). "
                   "Mutually exclusive with --sql.")
@click.option("--workspace-id", default=None, help="Target workspace UUID.")
@click.option("--entity-type", default=None,
              help="Entity the rule raises alerts about, e.g. vulnerability, identity, "
                   "issue. REQUIRED by the API.")
@click.option("--identity-fields", default=None,
              help="Comma-separated columns that identify one alert, e.g. "
                   "'torana_vulnerability_id'. REQUIRED by the API. ⛔ Choose carefully: "
                   "the key must be SHORT (alert creation fails silently above ~130 "
                   "chars), stable across runs, and at the grain you want alerts at — "
                   "and it CANNOT be changed after the rule is created.")
@click.option("--description", default=None, help="Rule description.")
@click.option("--state", default=None,
              type=click.Choice(["active", "inactive", "draft"], case_sensitive=False),
              help="Initial state (default: active).")
@click.option("--alert-enabled/--no-alert-enabled", default=None,
              help="Enable/disable alert generation.")
@click.option("--file", "input_file", default=None, metavar="FILE",
              help="Load rule(s) from JSON/YAML file (single object or list). Use '-' for stdin.")
@click.option("--if-not-exists", is_flag=True, default=False,
              help="Return existing rule if one with the same name exists in the workspace.")
@click.pass_context
def rules_create(ctx, name, severity, sql_command, query_id, workspace_id, entity_type,
                 identity_fields, description, state,
                 alert_enabled, input_file, if_not_exists):
    """Create a new detection rule (or batch-create from a file containing a list).

    \b
    Examples:
      torana rules create \\
        --name "SSH Brute Force" \\
        --severity high \\
        --sql "SELECT src_ip, count(*) FROM logs WHERE action='failed_login' GROUP BY src_ip HAVING count(*) > 10" \\
        --workspace-id <UUID>

    \b
      torana rules create --file rule.yaml
      torana rules create --file rules-batch.yaml   # file contains a list of rules
      cat rule.yaml | torana rules create --file -

    \b
      torana --dry-run rules create --file rule.yaml  # preview without API call
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    dry_run = ctx.obj.get(CTX_DRY_RUN, False) if ctx.obj else False

    # Start with file data if provided
    body = {}
    if input_file:
        body = _load_input_file(input_file)

    # Batch mode: file returned a list of rule objects
    if isinstance(body, list):
        _rules_create_batch(ctx, body, fmt, dry_run, if_not_exists)
        return

    # Inline flags override file values
    if name:
        body["name"] = name
    if severity:
        body["severity"] = severity
    if sql_command:
        body["sql_command"] = sql_command
    if query_id:
        body["query_id"] = query_id
    if workspace_id:
        body["workspace_id"] = workspace_id
    if entity_type:
        body["entity_type"] = entity_type
    if identity_fields:
        # The API requires a list; a bare string 422s. Accept the comma-separated
        # form the flag documents and coerce it here.
        body["identity_fields"] = [f.strip() for f in identity_fields.split(",") if f.strip()]
    if description:
        body["description"] = description
    if state:
        body["state"] = state
    if alert_enabled is not None:
        body["alert_enabled"] = alert_enabled

    # Decide the create mode:
    #   - bind-existing-query  → POST /rules  (RuleCreate; requires query_id,
    #     entity_type, identity_fields). Reuses the query; nothing new is made.
    #   - inline-query         → POST /rules/with-query (RuleCreateWithQuery;
    #     requires sql_command; creates a NEW named query then the rule).
    # query_id wins when both are present is rejected (ambiguous).
    if body.get("query_id") and body.get("sql_command"):
        click.echo(
            "ERROR: provide EITHER --query-id (bind an existing query) OR --sql "
            "(create a new inline query), not both.",
            err=True,
        )
        sys.exit(2)

    bind_existing = bool(body.get("query_id"))

    if bind_existing:
        # POST /rules path — pass query_id straight through to the API contract.
        path = "rules"
        # entity_type + identity_fields are mandatory in RuleCreate. They commonly
        # come from the file; only error if truly absent.
        missing = [f for f in ("name", "severity", "workspace_id", "query_id",
                               "entity_type", "identity_fields") if not body.get(f)]
        if missing:
            click.echo(
                f"ERROR: Missing required fields for query-bound rule: "
                f"{', '.join(missing)}",
                err=True,
            )
            click.echo("\nWhen binding an existing query (--query-id / query_id in file), "
                       "the rule must also declare:", err=True)
            click.echo("  name, severity, workspace_id, query_id, entity_type, identity_fields",
                       err=True)
            sys.exit(2)
    else:
        # POST /rules/with-query path — inline query creation (the original behavior).
        path = "rules/with-query"
        # Auto-derive query_name + query_description from rule name if the user
        # didn't supply them (the inline query is saved as a named, reusable query).
        if body.get("name") and not body.get("query_name"):
            import re as _re
            slug = _re.sub(r"[^a-z0-9_]+", "_", body["name"].lower())
            slug = _re.sub(r"_+", "_", slug).strip("_")[:200]
            body["query_name"] = f"q_{slug}" if slug else "q_unnamed_rule"
        if body.get("name") and not body.get("query_description"):
            body["query_description"] = f"Inline query for rule: {body['name']}"

        missing = [f for f in ("name", "severity", "sql_command", "workspace_id",
                               "entity_type", "identity_fields")
                   if not body.get(f)]
        if missing:
            click.echo(
                f"ERROR: Missing required fields: "
                f"{', '.join('--' + f.replace('_', '-') for f in missing)}",
                err=True,
            )
            click.echo("\nRequired fields (inline query):", err=True)
            click.echo("  --name          Rule name", err=True)
            click.echo("  --severity      Severity: low|medium|high|critical", err=True)
            click.echo("  --entity-type      Entity the rule alerts on, "
                       "e.g. vulnerability", err=True)
            click.echo("  --identity-fields  Comma-separated identity columns, "
                       "e.g. torana_vulnerability_id", err=True)
            click.echo("  --sql           SQL detection query "
                       "(or use --query-id to bind an existing query)", err=True)
            click.echo("  --workspace-id  Workspace UUID (use 'torana workspaces list')", err=True)
            click.echo("\nRun 'torana rules create --help' for full documentation.", err=True)
            sys.exit(2)

        # Validate SQL
        sql = body["sql_command"].strip().upper()
        if not sql.startswith(("SELECT", "WITH")):
            click.echo("ERROR: sql_command must be a SELECT query or CTE "
                       "(starts with SELECT or WITH).", err=True)
            sys.exit(6)

    # Dry-run: show what would be sent
    if dry_run:
        click.echo(f"[dry-run] Would POST to {path}:")
        click.echo(json.dumps(body, indent=2, default=str))
        return

    client = _client(ctx)

    # --if-not-exists: check for existing rule with same name
    if if_not_exists:
        try:
            existing = client.get(
                "rules/",
                params={"workspace_id": body["workspace_id"], "search": body["name"], "limit": 10}
            )
            # The /rules endpoint returns either a {items: [...]} envelope
            # or a bare list depending on the route variant. Handle both.
            if isinstance(existing, list):
                items = existing
            elif isinstance(existing, dict):
                items = existing.get("items", [])
            else:
                items = []
            for item in items:
                if item.get("name") == body["name"]:
                    click.echo(
                        "Warning: Rule already exists with this name — returning existing.",
                        err=True,
                    )
                    output(item, fmt=fmt)
                    return
        except (APIError, AuthError):
            pass  # Proceed to create

    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created rule: {data.get('id', 'unknown')}")
        click.echo(f"  Name:     {data.get('name', '')}")
        click.echo(f"  Severity: {data.get('severity', '')}")
        click.echo(f"  State:    {data.get('state', '')}")


def _rules_create_batch(ctx, rules_list, fmt, dry_run, if_not_exists):
    """Create multiple rules from a list (batch mode)."""
    if dry_run:
        click.echo(f"[dry-run] Would create {len(rules_list)} rule(s):")
        for i, rule in enumerate(rules_list, 1):
            click.echo(f"  [{i}] {rule.get('name', '(unnamed)')} "
                       f"({rule.get('severity', '?')})")
        return

    import re as _re

    client = _client(ctx)
    created = []
    errors = []
    for i, rule_body in enumerate(rules_list, 1):
        try:
            # Per-rule mode: bind existing query (query_id) → POST /rules,
            # else inline query (sql_command) → POST /rules/with-query.
            if rule_body.get("query_id") and not rule_body.get("sql_command"):
                path = "rules"
            else:
                path = "rules/with-query"
                if rule_body.get("name") and not rule_body.get("query_name"):
                    slug = _re.sub(r"[^a-z0-9_]+", "_", rule_body["name"].lower())
                    slug = _re.sub(r"_+", "_", slug).strip("_")[:200]
                    rule_body["query_name"] = f"q_{slug}" if slug else "q_unnamed_rule"
                if rule_body.get("name") and not rule_body.get("query_description"):
                    rule_body["query_description"] = f"Inline query for rule: {rule_body['name']}"
            data = client.post(path, json=rule_body)
            created.append(data)
            click.echo(f"[{i}/{len(rules_list)}] Created: {data.get('id', '?')} "
                       f"— {rule_body.get('name', '?')}")
        except (APIError, AuthError) as e:
            errors.append((i, rule_body.get("name", "?"), str(e)))
            click.echo(f"[{i}/{len(rules_list)}] ERROR: {rule_body.get('name', '?')} — {e}",
                       err=True)

    click.echo(f"\nBatch complete: {len(created)} created, {len(errors)} failed.")
    if fmt != "text" and created:
        output({"items": created, "total": len(created)}, fmt=fmt)


@rules.command(name="recent")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--limit", "limit", type=int, default=50)
@click.pass_context
def rules_recent(ctx, limit, page, page_size, fetch_all):
    """Get recent rule executions."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "rules/executions/recent"
    params = {}
    if limit is not None:
        params["limit"] = limit
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@rules.command(name="with-query")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with request body. Use '-' for stdin.")
@click.option("--name", "name", required=True, help="Name of the rule")
@click.option("--description", "description", default=None, help="Description of the rule")
@click.option("--alert-enabled", "alert_enabled", type=bool, default=False, help="Whether alerts are enabled for this rule")
@click.option("--severity", "severity", type=click.Choice(["low", "medium", "high", "critical"], case_sensitive=False), default=None)
@click.option("--labels", "labels", default=None, help="Rule labels as key-value pairs")
@click.option("--alert-tags", "alert_tags", default=None, help="Tags to apply to alerts generated by this rule")
@click.option("--tags", "tags", default=None, help="Tags for organizing and filtering rules")
@click.option("--workspace-id", "workspace_id", required=True, help="Workspace ID")
@click.option("--query-name", "query_name", required=True, help="Name of the query")
@click.option("--query-description", "query_description", default=None, help="Description of the query")
@click.option("--sql-command", "sql_command", required=True, help="SQL command for the query")
@click.option("--natural-language-query", "natural_language_query", default=None, help="Natural language description of the query")
@click.option("--query-labels", "query_labels", default=None, help="Query labels as key-value pairs")
# entity_type + identity_fields are MANDATORY in RuleCreateWithQuery (api/schemas.py:257-266).
# They were missing here, so every flag-driven invocation 422'd and only --file worked (FT-26).
# Not `required=True`: --file supplies the whole body, so requiring them would break that path.
# Absence is checked below, after the file/flag merge, and reported with the fix.
@click.option("--entity-type", "entity_type", default=None,
              help="Kind of entity a match identifies, e.g. 'vulnerability'. REQUIRED unless --file supplies it.")
@click.option("--identity-fields", "identity_fields", default=None,
              help="Comma-separated result columns that name the entity, e.g. "
                   "'torana_vulnerability_id'. REQUIRED unless --file supplies it.")
@click.option("--group-attrs", "group_attrs", default=None,
              help="Optional comma-separated clustering attributes → incidents, e.g. 'cve_id'.")
@click.pass_context
def rules_with_query(ctx, name, description, alert_enabled, severity, labels, alert_tags, tags, workspace_id, query_name, query_description, sql_command, natural_language_query, query_labels, entity_type, identity_fields, group_attrs, input_file):
    """Create rule with inline query."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "rules/with-query"
    if input_file:
        body = _load_input_file(input_file)
    else:
        body = {}
        body["name"] = name
        if description is not None:
            body["description"] = description
        if alert_enabled is not None:
            body["alert_enabled"] = alert_enabled
        if severity is not None:
            body["severity"] = severity
        if labels is not None:
            body["labels"] = labels
        if alert_tags is not None:
            body["alert_tags"] = alert_tags
        if tags is not None:
            body["tags"] = tags
        body["workspace_id"] = workspace_id
        body["query_name"] = query_name
        if query_description is not None:
            body["query_description"] = query_description
        body["sql_command"] = sql_command
        if natural_language_query is not None:
            body["natural_language_query"] = natural_language_query
        if query_labels is not None:
            body["query_labels"] = query_labels
        if entity_type is not None:
            body["entity_type"] = entity_type
        if identity_fields is not None:
            body["identity_fields"] = [f.strip() for f in identity_fields.split(",") if f.strip()]
        if group_attrs is not None:
            body["group_attrs"] = [f.strip() for f in group_attrs.split(",") if f.strip()]

    # Fail here with the fix rather than letting the API 422 with a bare
    # "Field required" that names no flag (FT-26). Checked after the file/flag merge
    # so a --file that carries them is accepted.
    missing = [f for f in ("entity_type", "identity_fields") if not body.get(f)]
    if missing:
        click.echo(
            f"ERROR: Missing required field(s): {', '.join(missing)}", err=True)
        click.echo(
            "\nA rule must declare WHAT entity a match identifies, so alerts dedupe on the\n"
            "entity instead of on a row hash. Supply them as flags:\n"
            "    --entity-type vulnerability --identity-fields torana_vulnerability_id\n"
            "or include entity_type / identity_fields in --file.", err=True)
        sys.exit(6)

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@rules.command(name="alert-enabled")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def rules_alert_enabled(ctx, page, page_size, fetch_all):
    """Get alert-enabled rules."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "rules/alert-enabled"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@rules.command(name="filter")
@click.option("--filters", "filters", default={})
@click.option("--limit", "limit", type=int, default=100)
@click.option("--offset", "offset", type=int, default=0)
@click.option("--suite-id", "suite_id", default=None)
@click.pass_context
def rules_filter(ctx, filters, limit, offset, suite_id):
    """Filter rules with complex criteria."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "rules/filter"
    body = {}
    if filters is not None:
        body["filters"] = filters
    if limit is not None:
        body["limit"] = limit
    if offset is not None:
        body["offset"] = offset
    if suite_id is not None:
        body["suite_id"] = suite_id

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@rules.command(name="count")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--suite-id", "suite_id", default=None)
@click.pass_context
def rules_count(ctx, suite_id, page, page_size, fetch_all):
    """Get rules count."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "rules/count"
    params = {}
    if suite_id is not None:
        params["suite_id"] = suite_id
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


# ---------------------------------------------------------------------------
# rule-execution-logs commands
# ---------------------------------------------------------------------------

@click.group(name="rule-execution-logs")
def rule_execution_logs():
    """Rule execution logs — did the rule run, and what did it see?

    \b
    First stop when a rule "produces no alerts": the log says whether it ran at
    all, and how many rows it matched. No log = it never ran (schedule/state),
    which is a different problem from matching nothing.

    \b
    ⚠️ `clear` resets the run WATERMARK — the rule will re-evaluate rows it has
    already processed and may re-raise alerts for them. Not a tidy-up command.

    \b
    Examples:
      torana rule-execution-logs list --rule-id <RULE_ID>
      torana rule-execution-logs get <LOG_ID>
      torana rule-execution-logs list --json | jq '.items[] | {started_at, status, matched}'
    """


@rule_execution_logs.command(name="list")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--rule-id", "rule_id", default=None)
@click.option("--failed-only", "failed_only", type=bool, default=False)
@click.pass_context
def rule_execution_logs_list(ctx, rule_id, failed_only, page, page_size, fetch_all):
    """List rule execution logs."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "rule-execution-logs"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if rule_id is not None:
        params["rule_id"] = rule_id
    if failed_only is not None:
        params["failed_only"] = failed_only

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@rule_execution_logs.command(name="get")
@click.argument("LOG_ID", metavar="LOG_ID")
@click.option("--rule-id", "rule_id", default=None,
              help="Rule UUID. Pass this when LOG_ID is the id returned by "
                   "'rule <id> execute' (a rule_run_jobs queue-job id). The CLI "
                   "resolves it to the real execution-log id via the status endpoint "
                   "(which accepts both id shapes) before fetching.")
@click.pass_context
def rule_execution_logs_get(ctx, log_id, rule_id):
    """Get a rule execution log.

    \b
    LOG_ID may be either:
      - a rule_execution_logs id (direct lookup), OR
      - the id printed by 'torana rule <id> execute' (a rule_run_jobs queue-job
        id) — pass --rule-id <RID> so the CLI can resolve it to the real log id.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)

    # If a rule_id is supplied, resolve LOG_ID through the dual-id status endpoint
    # first. That endpoint accepts BOTH a log id and a queue-job id, and once the
    # job is terminal it returns the real execution_log_id — exactly what the
    # direct /rule-execution-logs/{id} lookup needs.
    if rule_id:
        try:
            status_data = client.get(f"rules/{rule_id}/executions/{log_id}/status")
            resolved = status_data.get("execution_log_id") if isinstance(status_data, dict) else None
            if resolved:
                log_id = resolved
        except (APIError, AuthError):
            # Fall through to a direct lookup; if that 404s the hint below fires.
            pass

    try:
        data = client.get(f"rule-execution-logs/{log_id}")
    except APIError as e:
        if getattr(e, "status_code", None) == 404 and not rule_id:
            click.echo(
                "ERROR: no execution log with that id.\n"
                "If this id came from 'torana rule <id> execute', it's a queue-job "
                "id, not a log id. Re-run with --rule-id <RULE_ID> so the CLI can "
                "resolve it, e.g.:\n"
                f"  torana rule-execution-logs get {log_id} --rule-id <RULE_ID>",
                err=True,
            )
            raise SystemExit(3)
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@rule_execution_logs.command(name="delete")
@click.argument("LOG_ID", metavar="LOG_ID")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def rule_execution_logs_delete(ctx, log_id, yes):
    """Delete a rule execution log."""
    _confirm(f"Delete rule execution log {log_id}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"rule-execution-logs/{log_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted rule execution log: {log_id}")


@rule_execution_logs.command(name="clear")
@click.option("--rule-id", "rule_id", default=None,
              help="Clear execution logs for this rule only (resets its watermark).")
@click.option("--all", "clear_all", is_flag=True, default=False,
              help="Clear ALL execution logs for this tenant (resets every rule's watermark).")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def rule_execution_logs_clear(ctx, rule_id, clear_all, yes):
    """Clear rule execution logs to reset the run watermark.

    A rule only processes rows ingested since its last successful run. Clearing
    the logs makes the next run treat existing data as new and re-fire alerts.

    \b
    Examples:
      torana rule-execution-logs clear --rule-id <UUID>
      torana rule-execution-logs clear --all --yes
    """
    if not rule_id and not clear_all:
        raise click.UsageError("Provide --rule-id <UUID> to clear one rule, or --all to clear all.")

    if clear_all and not yes:
        _confirm("Clear ALL rule execution logs? This resets every rule's watermark.", yes=False)
    elif rule_id and not yes:
        _confirm(f"Clear execution logs for rule {rule_id}?", yes=False)
    client = _client(ctx)
    params = {}
    if rule_id:
        params["rule_id"] = rule_id
    else:
        params["confirm"] = "true"

    try:
        data = client.delete("rule-execution-logs", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    count = data.get("deleted_count", 0) if isinstance(data, dict) else 0
    scope = f"rule {rule_id}" if rule_id else "all rules"
    click.echo(f"Cleared {count} execution log(s) for {scope}. Next run will re-process existing data.")


# ⛔ SURFACE PARITY — see torana_cli/supply_health.py. One renderer for every
# artifact kind, so `rules health` cannot drift from `widgets health`.
from torana_cli.supply_health import health_command  # noqa: E402
rules.add_command(health_command("rule"))
