"""AI Home V2 "What matters to you" — the questions an app's team tracks on its Home.

Spec: pantheon-fe/docs/AI_HOME_V2_WHAT_MATTERS_SPEC.md § 3.4.14 (API: § 3.4.1 – § 3.4.13).

Commands hang under `workspace <id> ai-home`, where every write command of the Home already lives:

    questions list | catalog | ask          the collection
    question <QID> get | confirm | edit | discard-reading | reread | refresh | move | remove | restore | answers

⛔ `ask` and `reread` only START a reading. Nothing is answered on Home until the asker runs `confirm`
with the reading's token, after seeing what will be measured. No command here confirms on its own.
"""

import re
import time

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, handle_api_error, handle_auth_error
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_RAW
from torana_cli.output import output

#: `ask --wait` polls GET one. A picked question reads in seconds; a typed one waits on the Text-to-SQL Agent.
_WAIT_POLL_S = 3
_WAIT_MAX_S = 8 * 60

#: ⚠️ GLYPH + WORD, never colour alone (the same six states the FE card shows, spec § 3.5.3).
_STATE = {
    "answered": "◆ Answered",
    "partial": "◐ Partial",
    "cannot_answer": "⊘ Can't answer yet",
    "needs_confirmation": "◌ Needs confirmation",
    "reading": "◌ Reading…",
    "stopped": "⚠ Stopped answering",
}
_LIFT = {"stopped_answering": "stopped answering", "needs_confirmation": "needs confirmation",
         "threshold_crossed": "threshold crossed"}
_OPS = ("gt", "gte", "lt", "lte", "eq", "ne")
_OP_WORD = {"gt": "above", "gte": "at or above", "lt": "below", "lte": "at or below",
            "eq": "equal to", "ne": "not equal to"}
_OFF = "What matters to you is turned off in this environment."


def _ctx(ctx):
    """(fmt, raw, fields) — the three output knobs every command threads through."""
    o = ctx.obj or {}
    return o.get(CTX_FORMAT, "text"), o.get(CTX_RAW, False), o.get(CTX_FIELDS)


def _num(v) -> str:
    """A value with at most one decimal: 123.0 → 123, 4.25 → 4.2."""
    if v is None:
        return "—"
    try:
        f = float(v)
    except (TypeError, ValueError):
        return str(v)
    return f"{f:,.0f}" if f == int(f) else f"{f:,.1f}"


def _when(ts) -> str:
    return f"{str(ts)[:16].replace('T', ' ')} UTC" if ts else "not run yet"


def _unit(card: dict) -> str:
    return (card.get("unit") or card.get("unit_default") or "").strip()


def _answer_cell(card: dict) -> str:
    """The answer as the card shows it. ⛔ `—` is not 0: no value means no number."""
    state, ans = card.get("state"), card.get("answer") or {}
    if state in ("reading", "needs_confirmation", "cannot_answer", "stopped") or ans.get("value") is None:
        return "—"
    unit = _unit(card)
    if ans.get("shape") == "list" and ans.get("capped"):
        return f"{_num(ans.get('total_rows'))}+ {unit}".strip()
    return f"{_num(ans.get('value'))} {unit}".strip()


def _threshold_words(t) -> str:
    return f"{_OP_WORD.get(t.get('op'), t.get('op'))} {_num(t.get('value'))}" if t else ""


def _threshold_of(card: dict) -> str:
    """What the card's threshold compares, in the API's words. ⛔ Never rebuilt from op and value here: only
    the API knows whether the card's value, its row count or a column is compared (the fallback is for an
    older API that sent no `threshold_text`)."""
    text = card.get("threshold_text") or _threshold_words(card.get("threshold"))
    if card.get("threshold_hits") is not None:
        text += f"  ·  {card['threshold_hits']} of {card.get('threshold_checked')} rows"
    return text


def _target_lines(card: dict, indent="  "):
    """What a threshold can be set on (`threshold_targets`), each with the option that picks it."""
    targets = card.get("threshold_targets")
    if targets is None:                                      # an older API: say nothing rather than guess
        return
    if not targets:
        click.echo(f"{indent}a threshold cannot be set here: the rows are a time series or a fixed breakdown "
                   "with no numeric column, so neither the row count nor a column says anything")
        return
    click.echo(f"{indent}a threshold can be set on:")
    for t in targets:
        how = f"--threshold-column {t['column']}" if t.get("column") else "no --threshold-column"
        click.echo(f"{indent}  {t.get('label')}  ({how})")


def _parse_threshold(text: str, column=None, match=None) -> dict:
    """`"gt 0"` → {"op": "gt", "value": 0.0}; with a column: + {"column": …, "match": …}."""
    parts = (text or "").split()
    if len(parts) != 2 or parts[0] not in _OPS:
        raise click.UsageError(f'--threshold is "<op> <number>", op one of {", ".join(_OPS)}. '
                               'Example: --threshold "gt 0"')
    try:
        out = {"op": parts[0], "value": float(parts[1])}
    except ValueError:
        raise click.UsageError(f"--threshold: '{parts[1]}' is not a number.")
    if column:
        out["column"] = column
    if match:
        out["match"] = match
    return out


def _threshold_options(fn):
    """--threshold-column / --threshold-match, shared by `confirm` and `edit`."""
    fn = click.option("--threshold-match", "threshold_match", type=click.Choice(["any", "all"]), default=None,
                      help="With --threshold-column: crossed when ANY row satisfies it (default) or when ALL do.")(fn)
    return click.option("--threshold-column", "threshold_column", default=None, metavar="NAME",
                        help="Compare a numeric column of the answer's rows instead of the card's own value "
                             "(`get` lists the columns on offer).")(fn)


def _threshold_body(threshold, column, match):
    if threshold is None and (column or match):
        raise click.UsageError('--threshold-column and --threshold-match go with --threshold "<op> <number>".')
    return _parse_threshold(threshold, column, match)


def _reason_lines(reason, indent="    "):
    """The fixed sentence and what to do about it. ⛔ Always printed for a partial answer."""
    if not reason:
        return
    click.echo(f"{indent}why: {reason.get('text') or reason.get('code')}")
    if reason.get("what_to_do"):
        click.echo(f"{indent}what to do: {reason['what_to_do']}")


def _answer_line(ans: dict, indent="    "):
    """The written answer of THIS answer, or why there is none. ⛔ Never an older answer's sentence."""
    n = (ans or {}).get("narration") or {}
    if n.get("status") == "ready":
        # `**` marks the narrator's key phrases: a terminal shows them bold, a pipe gets the plain sentence.
        text = n.get("text") or ""
        text = re.sub(r"\*\*(.+?)\*\*", lambda m: click.style(m.group(1), bold=True), text)
        click.echo(f"{indent}answer: {'▲ needs attention: ' if n.get('attention') else ''}{text}")
    elif n.get("status") == "pending":
        click.echo(f"{indent}answer: ◌ being written (the rows are in; check again in a few seconds)")
    elif n.get("status") == "unavailable":
        click.echo(f"{indent}answer: none written for this result (read the rows; the next answer is written afresh)")


def _figures_line(ans: dict, indent="    "):
    """The headline figures of THIS answer: totals code computed over the question's full result. Nothing is
    printed when the question declares none."""
    figures = ((ans or {}).get("display") or {}).get("figures") or []
    if figures:
        # the API rounds a figure to 2 decimals: print every digit it has (the written answer quotes the same ones)
        click.echo(f"{indent}figures: " + "  ·  ".join(f"{float(f.get('value') or 0):,.2f}".rstrip("0").rstrip(".")
                                                       + f" {f.get('label')}" for f in figures))


def _cell(v) -> str:
    if v is None or v == "" or v == []:
        return "—"
    if isinstance(v, list):
        return ", ".join(_cell(x) for x in v)
    return "yes" if v is True else "no" if v is False else str(v)


def _rows(rows, columns, limit, indent="    ", display=None):
    """Rows read by column name, never by key order. With `display` (an answer's own): the columns and labels the
    API chose for a reader. Without (a reading's first answer, an older API): the first four raw columns."""
    cols = [(c.get("column"), c.get("label") or c.get("column"), c.get("or"))
            for c in (display or {}).get("columns") or []]
    cols = cols or [(c, c, None) for c in list(columns or [])[:4]]
    for r in (rows or [])[:limit]:
        # `or`: the column shown when the first is empty in this row (an asset's name, else the place's id)
        click.echo(indent + "  ·  ".join(
            f"{label}={_cell(r.get(col) if r.get(col) not in (None, '', []) else r.get(alt) if alt else None)}"
            for col, label, alt in cols))


def _print_list(data: dict, removed: bool = False):
    if not (data or {}).get("enabled", True):
        click.echo(_OFF)
        return
    items = (data or {}).get("items") or []
    if not items:
        click.echo("No removed questions to restore." if removed else
                   "No questions yet. Add one: questions catalog, then questions ask --pick <ID> --wait")
    for i, c in enumerate(items, 1):
        ans = c.get("answer") or {}
        line = f"{i:>2}  {_STATE.get(c.get('state'), c.get('state'))}  ·  {_answer_cell(c)}"
        if c.get("threshold_breached"):
            line += f"  ·  ▲ Threshold crossed ({_threshold_of(c)})"
        click.echo(line)
        click.echo(f"    {c.get('question_text')}")
        _answer_line(ans)
        _figures_line(ans)
        tail = f"    id {c.get('id')}  ·  as of {_when(ans.get('as_of'))}"
        if removed:
            tail += f"  ·  removed {_when(c.get('deleted_at'))}"
        if c.get("lifted"):
            tail += f"  ·  ↑ moved up: {_LIFT.get(c.get('lift_reason'), c.get('lift_reason'))}"
        click.echo(tail)
        if c.get("state") in ("partial", "stopped"):
            _reason_lines(ans.get("reason"))
        elif c.get("state") == "cannot_answer":
            _reason_lines((c.get("reading") or {}).get("reason"))
        pend = c.get("pending") or {}
        if pend.get("status"):
            click.echo(f"    ◌ new reading: {pend['status']} (by {pend.get('by')})")
    click.echo("")
    foot = f"{data.get('total', len(items))} question(s)"
    if not removed and data.get("removed_count"):
        foot += f"  ·  {data['removed_count']} removed (questions list --removed)"
    if not data.get("custom_questions_enabled"):
        foot += "  ·  ready-made list only (typed questions are off)"
    click.echo(foot)


def _print_reading(r: dict, title: str):
    """One reading, as the asker must see it before confirming: what, outcome, why, first answer, SQL."""
    click.echo(f"  {title}")
    click.echo(f"    what will be measured: {r.get('summary') or r.get('question_text')}")
    click.echo(f"    outcome: {r.get('outcome') or r.get('status')}"
               + (f"  ·  shape: {r['shape']}" if r.get("shape") else ""))
    _reason_lines(r.get("reason"))
    if r.get("data_quality_note"):
        click.echo(f"    data quality: {r['data_quality_note']}")
    fa = r.get("first_answer") or {}
    if fa:
        n = f"{_num(fa.get('total_rows'))}+" if fa.get("capped") else _num(fa.get("value"))
        click.echo(f"    first answer: {n} {r.get('unit_default') or ''}".rstrip() + f"  ({fa.get('state')})")
        _rows(fa.get("rows"), fa.get("columns"), 3, indent="      ")
        if (fa.get("total_rows") or 0) > 3 and fa.get("rows"):
            click.echo(f"      … and {fa['total_rows'] - 3} more")
    if r.get("sql"):
        click.echo("    SQL:")
        for ln in r["sql"].splitlines():
            click.echo(f"      {ln}")


def _print_card(c: dict, wid: str):
    """GET one, in text: the card, its answer, the reading in force and any unconfirmed reading."""
    ans = c.get("answer") or {}
    click.echo(f"{_STATE.get(c.get('state'), c.get('state'))}  ·  {_answer_cell(c)}")
    click.echo(f"  {c.get('question_text')}")
    src = f"ready-made {c.get('catalog_question_id')}" if c.get("source") == "catalog" else "typed"
    who = (c.get("asked_by") or {})
    click.echo(f"  id {c.get('id')}  ·  {src}  ·  added by {'you' if who.get('is_me') else who.get('email')}")
    if ans:
        click.echo(f"  ▣ measured  ·  as of {_when(ans.get('as_of'))}  ·  trigger {ans.get('trigger')}")
        ch = ans.get("change") or {}
        if ch:
            arrow = {"up": "▲", "down": "▼"}.get(ch.get("direction"))
            click.echo("  change: " + (f"{arrow} {_num(abs(ch.get('delta') or 0))}" if arrow else "no change")
                       + f" since {_when(ch.get('since'))}")
    if c.get("threshold"):
        click.echo(f"  threshold: {_threshold_of(c)}"
                   + ("  ·  ▲ crossed" if c.get("threshold_breached") else "  ·  not crossed"))
    _target_lines(c)
    _answer_line(ans, indent="  ")
    _figures_line(ans, indent="  ")
    display = ans.get("display") or {}
    if display.get("counts"):
        click.echo(f"  what this counts: {display['counts']}")
    if c.get("state") in ("partial", "stopped"):
        _reason_lines(ans.get("reason"), indent="  ")
    if ans.get("rows"):
        shown = min(len(ans["rows"]), 10)
        click.echo(f"  rows (first {shown} of {_num(ans.get('total_rows'))}"
                   + ("+, the query's own cap" if ans.get("capped") else "") + "):")
        focus = display.get("focus") or {}
        if focus.get("count"):
            click.echo(f"    {_num(focus['count'])} of them are {focus.get('label')}")
        _rows(ans["rows"], ans.get("columns"), 10, display=display)
    click.echo("")
    if c.get("reading"):
        _print_reading(c["reading"], f"Reading in force (version {c['reading'].get('version')})")
    pend = c.get("pending")
    if pend:
        click.echo("")
        _print_pending(pend, c.get("id"), wid)


def _print_pending(pend: dict, qid: str, wid: str):
    """An unconfirmed reading and its token. ⛔ Prints the confirm command; never runs it."""
    status = pend.get("status")
    if status == "reading":
        click.echo(f"  ◌ Reading the question… (started by {pend.get('by')}). Check again: "
                   f"torana workspace {wid} ai-home question {qid} get")
        return
    _print_reading(pend, f"Unconfirmed reading ({status}, by {pend.get('by')})")
    click.echo(f"    reading_token: {pend.get('token')}")
    base = f"torana workspace {wid} ai-home question {qid}"
    if status == "ready":
        click.echo("  Not answered on Home until the asker confirms that this SQL means what was asked:")
        click.echo(f"    {base} confirm --token {pend.get('token')}")
    else:
        click.echo(f"  The reading failed. Try again: {base} reread")


def _call(fn):
    """Run one API call with the CLI's standard error exits (3 = 404, 4 = 403, 6 = 422)."""
    try:
        return fn()
    except APIError as e:
        handle_api_error(e)
    except AuthError as e:
        handle_auth_error(e)
    raise SystemExit(1)


def register(ai_home_group, client_factory):
    """Attach `questions` and `question <QID>` to the `workspace <id> ai-home` group."""

    def _wid(ctx) -> str:
        return ctx.obj.get("_workspace_id", "") if ctx.obj else ""

    def _base(ctx) -> str:
        return f"workspaces/{_wid(ctx)}/ai-home/questions"

    def _one(ctx) -> str:
        return f"{_base(ctx)}/{ctx.obj.get('_question_id', '')}"

    # ── the collection ───────────────────────────────────────────────────────

    @ai_home_group.group(name="questions", invoke_without_command=True)
    @click.pass_context
    def questions(ctx):
        """"What matters to you": the questions this app's team tracks on its Home.

        \b
        Examples:
          torana workspace <id> ai-home questions list
          torana workspace <id> ai-home questions catalog
          torana workspace <id> ai-home questions ask --pick EM-011 --wait
        """
        ctx.ensure_object(dict)
        if ctx.invoked_subcommand is None:
            click.echo(ctx.get_help())

    @questions.command(name="list")
    @click.option("--removed", is_flag=True, default=False,
                  help="Show the removed questions that can still be restored (30 days).")
    @click.pass_context
    def questions_list(ctx, removed):
        """The app's questions, in Home order, each with its state and latest answer.

        ⛔ `—` is not 0: a question that can't answer, has stopped, or returned no value has no number.
        `100+` means the list hit the query's own cap. An answer is measured, not proven.

        \b
        Examples:
          torana workspace <id> ai-home questions list
          torana workspace <id> ai-home questions list --removed
          torana workspace <id> ai-home questions list -o json
        """
        fmt, raw, fields = _ctx(ctx)
        data = _call(lambda: client_factory(ctx).get(_base(ctx), params={"removed": "true"} if removed else None))
        if fmt in ("json", "yaml"):
            output(data, fmt=fmt, raw=raw, fields=fields)
            return
        _print_list(data, removed=removed)

    @questions.command(name="catalog")
    @click.option("--search", "search", default=None,
                  help="Narrow the list to the questions closest in meaning to this text, best first "
                       "(only where search is on; a 403 question_search_disabled means it is off).")
    @click.option("--use-case", "use_cases", multiple=True,
                  help="Keep only this category (the [use_case] column), e.g. sla_management. Repeat for several.")
    @click.pass_context
    def questions_catalog(ctx, search, use_cases):
        """The ready-made questions this tenant's data can answer. Pick one with `ask --pick <ID>`.

        With --search the list is narrowed to the questions closest in MEANING to your text, best
        first (a paraphrase with no word in common still matches); the first column is the match
        strength. If the embedding model cannot be reached it falls back to a word match and says
        so. It ranks candidates, it does not pick one: read the top few. Text about something else
        prints nothing but the count.

        --use-case keeps one category (or several). The footer lists every category with its
        count, so run it bare first to see which exist. It combines with --search.

        \b
        Examples:
          torana workspace <id> ai-home questions catalog
          torana workspace <id> ai-home questions catalog --use-case sla_management
          torana workspace <id> ai-home questions catalog --search "duplicate findings"
        """
        fmt, raw, fields = _ctx(ctx)
        q = (search or "").strip()
        params = {**({"q": q} if q else {}), **({"use_case": list(use_cases)} if use_cases else {})}
        data = _call(lambda: client_factory(ctx).get(f"{_base(ctx)}/catalog", params=params or None))
        if fmt in ("json", "yaml"):
            output(data, fmt=fmt, raw=raw, fields=fields)
            return
        if not (data or {}).get("available"):
            click.echo("The ready-made list could not be loaded.")
            return
        for it in data.get("items") or []:
            mark = "✓ added" if it.get("added") else "       "
            match = f"{it.get('match'):.2f}  " if q and it.get("match") is not None else ""
            click.echo(f"{match}{it.get('question_id'):<8} {mark}  [{it.get('use_case')}]  {it.get('question')}")
        click.echo("")
        cats = "Categories: " + ", ".join(f"{u.get('use_case')} ({u.get('count')})" for u in data.get("use_cases") or [])
        if use_cases:
            click.echo(f"Showing only: {', '.join(data.get('use_case') or use_cases)}")
        if q:
            how = {"semantic": "by meaning", "lexical": "by words only: the embedding model was not reached"}
            click.echo(f"{data.get('total', 0)} of {data.get('ready_total', 0)} ready-made question(s) match "
                       f"\"{q}\" ({how.get(data.get('method'), data.get('method'))})"
                       + ("" if data.get("total") else "  ·  run without --search to see them all"))
            if data.get("use_cases"):
                click.echo(cats)
            return
        foot = f"{data.get('total', 0)} ready-made question(s)"
        if data.get("not_ready_count"):
            foot += f"  ·  {data['not_ready_count']} more need data this tenant does not have yet"
        click.echo(foot)
        if data.get("use_cases"):
            click.echo(cats)

    @questions.command(name="ask")
    @click.option("--pick", "catalog_id", default=None,
                  help="A ready-made question id from `questions catalog`, e.g. EM-011.")
    @click.option("--text", default=None,
                  help="Your own question (only where typed questions are turned on).")
    @click.option("--wait", is_flag=True, default=False,
                  help="Wait for the reading (polls every 3 s, at most 8 min) and print it with its token.")
    @click.pass_context
    def questions_ask(ctx, catalog_id, text, wait):
        """Add a question. This STARTS a reading; it is not on Home until the asker confirms it.

        ⛔ Try the catalog first: `--pick` always works, `--text` only where typed questions are on
        (a 403 custom_questions_disabled means they are off: offer the catalog).
        ⛔ Show the user the printed reading (what will be measured, first answer, SQL) BEFORE
        running `question <QID> confirm`. Confirming is the user agreeing the SQL means what they asked.

        \b
        Examples:
          torana workspace <id> ai-home questions ask --pick EM-011 --wait
          torana workspace <id> ai-home questions ask --text "How many criticals are past SLA?" --wait
        """
        fmt, raw, fields = _ctx(ctx)
        if bool(catalog_id) == bool((text or "").strip()):
            raise click.UsageError("Give exactly one of --pick <CATALOG_ID> or --text \"…\".")
        body = {"catalog_question_id": catalog_id} if catalog_id else {"text": text.strip()}
        client = client_factory(ctx)
        card = _call(lambda: client.post(_base(ctx), body))
        qid = card.get("id")
        if wait:
            deadline = time.monotonic() + _WAIT_MAX_S
            while True:
                card = _call(lambda: client.get(f"{_base(ctx)}/{qid}"))
                if ((card.get("pending") or {}).get("status")) != "reading":
                    break
                if time.monotonic() >= deadline:
                    click.echo(f"Still reading after {_WAIT_MAX_S // 60} min. Check later: "
                               f"torana workspace {_wid(ctx)} ai-home question {qid} get", err=True)
                    break
                time.sleep(_WAIT_POLL_S)
        if fmt in ("json", "yaml"):
            output(card, fmt=fmt, raw=raw, fields=fields)
            return
        click.echo(f"✓ Question added: {qid}")
        click.echo(f"  {card.get('question_text')}")
        if card.get("pending"):
            _print_pending(card["pending"], qid, _wid(ctx))

    # ── one question ─────────────────────────────────────────────────────────

    @ai_home_group.group(name="question", invoke_without_command=True)
    @click.argument("question_id", metavar="QID")
    @click.pass_context
    def question(ctx, question_id):
        """One "What matters to you" question, by id (ids from `questions list`).

        \b
        Examples:
          torana workspace <id> ai-home question <QID> get
          torana workspace <id> ai-home question <QID> confirm --token <T> --unit findings --threshold "gt 0"
          torana workspace <id> ai-home question <QID> move --top
        """
        ctx.ensure_object(dict)
        ctx.obj["_question_id"] = question_id
        if ctx.invoked_subcommand is None:
            click.echo(ctx.get_help())

    def _show_card(ctx, card, done=None):
        fmt, raw, fields = _ctx(ctx)
        if fmt in ("json", "yaml"):
            output(card, fmt=fmt, raw=raw, fields=fields)
            return
        if done:
            click.echo(done)
        _print_card(card, _wid(ctx))

    @question.command(name="get")
    @click.pass_context
    def question_get(ctx):
        """The question in full: its answer and rows, the reading in force with its SQL, any unconfirmed reading.

        \b
        Examples:
          torana workspace <id> ai-home question <QID> get
          torana workspace <id> ai-home question <QID> get -o json
        """
        _show_card(ctx, _call(lambda: client_factory(ctx).get(_one(ctx))))

    @question.command(name="confirm")
    @click.option("--token", required=True, help="The reading_token printed by `ask --wait` or `get`.")
    @click.option("--unit", default=None, help="What the number counts, e.g. findings (max 40 characters).")
    @click.option("--threshold", default=None, help='Mark the card when crossed: "<op> <number>", e.g. "gt 0".')
    @_threshold_options
    @click.pass_context
    def question_confirm(ctx, token, unit, threshold, threshold_column, threshold_match):
        """Confirm a reading: from now on Home answers the question with this SQL.

        ⛔ Only after the user has SEEN the reading (what will be measured, the first answer, the SQL).
        Only the asker can confirm: a 403 not_the_asker is not a bug.

        A threshold compares the card's own value (a number card's figure, a list card's row count) unless
        --threshold-column names a numeric column of the rows. A crossed threshold marks the card and moves
        it up; it never sends a message. A target the reading does not offer is refused with 422.

        \b
        Examples:
          torana workspace <id> ai-home question <QID> confirm --token <T>
          torana workspace <id> ai-home question <QID> confirm --token <T> --unit findings --threshold "gt 0"
          torana workspace <id> ai-home question <QID> confirm --token <T> --threshold "gt 30" --threshold-column median_days_to_remediate
        """
        body = {"reading_token": token}
        if unit is not None:
            body["unit"] = unit
        if threshold is not None or threshold_column or threshold_match:
            body["threshold"] = _threshold_body(threshold, threshold_column, threshold_match)
        _show_card(ctx, _call(lambda: client_factory(ctx).post(f"{_one(ctx)}/confirm", body)), "✓ Confirmed")

    @question.command(name="edit")
    @click.option("--text", default=None, help="New wording (typed questions only; starts a new reading to confirm).")
    @click.option("--unit", default=None, help="What the number counts, e.g. findings.")
    @click.option("--clear-unit", is_flag=True, default=False, help="Go back to the default unit.")
    @click.option("--threshold", default=None, help='"<op> <number>", e.g. "gte 10".')
    @_threshold_options
    @click.option("--clear-threshold", is_flag=True, default=False, help="Remove the threshold.")
    @click.pass_context
    def question_edit(ctx, text, unit, clear_unit, threshold, threshold_column, threshold_match, clear_threshold):
        """Change the unit, the threshold, or (typed questions) the wording.

        A ready-made question's wording is fixed (422 catalog_question_text_fixed). New wording starts a
        new reading; the live answer is untouched until that reading is confirmed.

        A threshold compares the card's own value (a number card's figure, a list card's row count) unless
        --threshold-column names a numeric column of the rows; --threshold-match all needs every row to
        satisfy it. `get` lists what a threshold can be set on. A crossed threshold marks the card and
        moves it up; it never sends a message. Refused with 422: threshold_target_not_offered (the row
        count of a time series or fixed breakdown means nothing: pick a column), threshold_column_unknown,
        threshold_match_needs_column.

        \b
        Examples:
          torana workspace <id> ai-home question <QID> edit --unit findings --threshold "gt 0"
          torana workspace <id> ai-home question <QID> edit --threshold "gt 30" --threshold-column median_days_to_remediate
          torana workspace <id> ai-home question <QID> edit --threshold "gt 30" --threshold-column median_days_to_remediate --threshold-match all
          torana workspace <id> ai-home question <QID> edit --clear-threshold
        """
        if unit is not None and clear_unit:
            raise click.UsageError("Give --unit or --clear-unit, not both.")
        if (threshold is not None or threshold_column or threshold_match) and clear_threshold:
            raise click.UsageError("Give --threshold or --clear-threshold, not both.")
        body = {}
        if text is not None:
            body["text"] = text
        if unit is not None or clear_unit:
            body["unit"] = None if clear_unit else unit
        if threshold is not None or threshold_column or threshold_match or clear_threshold:
            body["threshold"] = (None if clear_threshold
                                 else _threshold_body(threshold, threshold_column, threshold_match))
        if not body:
            raise click.UsageError("Nothing to change. Give --text, --unit, --clear-unit, --threshold "
                                   "or --clear-threshold.")
        _show_card(ctx, _call(lambda: client_factory(ctx).patch(_one(ctx), body)), "✓ Updated")

    @question.command(name="discard-reading")
    @click.option("--token", required=True, help="The reading_token of the unconfirmed reading.")
    @click.pass_context
    def question_discard_reading(ctx, token):
        """Drop an unconfirmed reading and keep the confirmed one (asker only).

        A question that was never confirmed has nothing to keep: use `remove` (409 use_delete).

        \b
        Examples:
          torana workspace <id> ai-home question <QID> discard-reading --token <T>
        """
        data = _call(lambda: client_factory(ctx).post(f"{_one(ctx)}/discard-reading", {"reading_token": token}))
        _show_card(ctx, data, "✓ Reading discarded")

    @question.command(name="reread")
    @click.pass_context
    def question_reread(ctx):
        """Read the question again (after "can't answer", a schema change, or a failed reading).

        Starts a new reading that must be confirmed; the caller becomes the one who can confirm it.

        \b
        Examples:
          torana workspace <id> ai-home question <QID> reread
          torana workspace <id> ai-home question <QID> get        # then: see the reading and its token
        """
        _show_card(ctx, _call(lambda: client_factory(ctx).post(f"{_one(ctx)}/reread", {})), "✓ Re-reading")

    @question.command(name="refresh")
    @click.pass_context
    def question_refresh(ctx):
        """Answer the question again now, with the confirmed SQL (no new reading).

        \b
        Examples:
          torana workspace <id> ai-home question <QID> refresh
          torana workspace <id> ai-home question <QID> get        # a few seconds later: the new answer
        """
        fmt, raw, fields = _ctx(ctx)
        data = _call(lambda: client_factory(ctx).post(f"{_one(ctx)}/refresh", {}))
        if fmt in ("json", "yaml"):
            output(data, fmt=fmt, raw=raw, fields=fields)
            return
        click.echo("✓ Refresh started" if (data or {}).get("started")
                   else f"Already refreshing ({(data or {}).get('reason')}); nothing new started.")

    @question.command(name="move")
    @click.option("--top", "to", flag_value="top", default=None, help="Move to the top.")
    @click.option("--bottom", "to", flag_value="bottom", help="Move to the bottom.")
    @click.option("--before", "before_id", default=None, metavar="QID", help="Place before this question.")
    @click.option("--after", "after_id", default=None, metavar="QID", help="Place after this question.")
    @click.pass_context
    def question_move(ctx, to, before_id, after_id):
        """Change the question's place on Home, for everyone in the app. Prints the new order.

        \b
        Examples:
          torana workspace <id> ai-home question <QID> move --top
          torana workspace <id> ai-home question <QID> move --after <OTHER_QID>
        """
        fmt, raw, fields = _ctx(ctx)
        if sum(1 for v in (to, before_id, after_id) if v) != 1:
            raise click.UsageError("Give exactly one of --top, --bottom, --before <QID>, --after <QID>.")
        body = {"to": to} if to else {"before_id": before_id} if before_id else {"after_id": after_id}
        data = _call(lambda: client_factory(ctx).post(f"{_one(ctx)}/move", body))
        if fmt in ("json", "yaml"):
            output(data, fmt=fmt, raw=raw, fields=fields)
            return
        click.echo("✓ Moved")
        _print_list(data)

    @question.command(name="remove")
    @click.pass_context
    def question_remove(ctx):
        """Stop tracking the question, for everyone in the app. Restorable for 30 days; answers are kept.

        \b
        Examples:
          torana workspace <id> ai-home question <QID> remove
          torana workspace <id> ai-home question <QID> restore
        """
        fmt, raw, fields = _ctx(ctx)
        data = _call(lambda: client_factory(ctx).delete(_one(ctx)))
        if fmt in ("json", "yaml"):
            output(data, fmt=fmt, raw=raw, fields=fields)
            return
        click.echo(f"✓ Removed {(data or {}).get('id')} for everyone in this app")
        if (data or {}).get("deleted_at"):
            click.echo(f"  Undo within 30 days: torana workspace {_wid(ctx)} ai-home question "
                       f"{ctx.obj.get('_question_id')} restore")
        else:
            click.echo("  It was never confirmed, so there is nothing to restore.")

    @question.command(name="restore")
    @click.pass_context
    def question_restore(ctx):
        """Bring a removed question back, with its history (within 30 days of removal).

        \b
        Examples:
          torana workspace <id> ai-home questions list --removed
          torana workspace <id> ai-home question <QID> restore
        """
        _show_card(ctx, _call(lambda: client_factory(ctx).post(f"{_one(ctx)}/restore", {})), "✓ Restored")

    @question.command(name="answers")
    @click.option("--limit", default=50, show_default=True, type=click.IntRange(1, 100),
                  help="How many answers, newest first.")
    @click.option("--before", default=None, help="Only answers before this ISO time (to page back).")
    @click.pass_context
    def question_answers(ctx, limit, before):
        """The question's past answers, newest first, across every reading version (rows are not included).

        \b
        Examples:
          torana workspace <id> ai-home question <QID> answers
          torana workspace <id> ai-home question <QID> answers --limit 10 -o json
        """
        fmt, raw, fields = _ctx(ctx)
        params = {"limit": limit}
        if before:
            params["before"] = before
        data = _call(lambda: client_factory(ctx).get(f"{_one(ctx)}/answers", params=params))
        if fmt in ("json", "yaml"):
            output(data, fmt=fmt, raw=raw, fields=fields)
            return
        for a in (data or {}).get("items") or []:
            val = f"{_num(a.get('total_rows'))}+" if a.get("capped") else _num(a.get("value"))
            click.echo(f"{_when(a.get('as_of'))}  {_STATE.get(a.get('state'), a.get('state')):<12} {val:>10}  "
                       f"v{a.get('reading_version')}  {a.get('trigger')} by {a.get('triggered_by')}")
            if a.get("narration_text"):
                click.echo(f"    answer: {a['narration_text'].replace('**', '')}")
            if a.get("state") != "answered":
                _reason_lines(a.get("reason"))
        shown, total = len((data or {}).get("items") or []), (data or {}).get("total", 0)
        click.echo(f"\n{shown} of {total} answer(s)" if shown != total else f"\n{total} answer(s)")
