"""torana vulnerabilities — query datalake vulnerability records.

All reads use the datalake's /tables/vulnerabilities/data endpoint.
Instance commands (get, update) are under: torana vulnerability <ID> <verb>
"""

import json
import sys

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output


_VULN_COLS = [
    ("torana_vulnerability_id", "ID", 36),
    ("title", "TITLE", 40),
    ("severity", "SEVERITY", 10),
    ("vulnerability_status", "STATUS", 14),
    ("source_system", "SOURCE", 18),
    ("torana_repository_id", "REPO", 30),
    ("is_false_positive", "FP", 5),
    ("is_risk_accepted", "RA", 5),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _normalize_list_response(data: dict) -> dict:
    """Normalize datalake /tables/{name}/data response to {items, total} shape."""
    if "data" in data:
        return {"items": data["data"], "total": data.get("count", len(data["data"]))}
    if "items" in data:
        return data
    return {"items": data if isinstance(data, list) else [], "total": 0}


# Stored vulnerability_status / severity values are Title Case in the datalake
# (e.g. 'Open', 'In Progress', 'Critical'). Users naturally type lowercase, which
# silently matches zero rows. Normalize known multi-word/Title-Case values so the
# filter behaves case-insensitively for the common cases.
_STATUS_CANON = {
    "open": "Open",
    "fixed": "Fixed",
    "accepted": "Accepted",
    "in progress": "In Progress",
    "in-progress": "In Progress",
}
_SEVERITY_CANON = {
    "critical": "Critical", "high": "High", "medium": "Medium",
    "low": "Low", "info": "Info", "informational": "Info",
}


def _canon_status(value):
    if value is None:
        return None
    return _STATUS_CANON.get(value.strip().lower(), value)


def _canon_severity(value):
    if value is None:
        return None
    return _SEVERITY_CANON.get(value.strip().lower(), value)


def _sql_lit(value: str) -> str:
    """Single-quote a SQL string literal, escaping embedded quotes."""
    return "'" + str(value).replace("'", "''") + "'"


def _build_where(filters: dict) -> str:
    """Build a WHERE clause from {column: value} equality filters (already canon)."""
    clauses = [f"{col} = {_sql_lit(val)}" for col, val in filters.items() if val is not None]
    return (" WHERE " + " AND ".join(clauses)) if clauses else ""


def _resolve_repo_id(client, repo: str) -> str:
    """Resolve a --repo value to an exact torana_repository_id.

    A full node key (starts with 'repo:') is used as-is. Anything else is
    treated as a friendly name and matched against the repositories sink
    table (substring on torana_repository_id, exact-name preferred). Exits
    with a clean error when nothing matches or the name is ambiguous.
    """
    if repo.startswith("repo:"):
        return repo

    like = _sql_lit("%" + repo + "%")
    sql = (
        "SELECT torana_repository_id, name, full_name FROM repositories"
        f" WHERE torana_repository_id LIKE {like}"
        " AND (is_deleted = false OR is_deleted IS NULL)"
    )
    try:
        data = client.post("/query", json={"query": sql})
    except (APIError, AuthError):
        data = None
    rows = data.get("results") if isinstance(data, dict) else None
    if not rows:
        click.echo(
            f"ERROR: no repository matching {repo!r} found in the repositories table.\n"
            "Pass the full key instead, e.g. --repo repo:github.com/<org>/<name>.",
            err=True,
        )
        raise SystemExit(3)

    if len(rows) > 1:
        exact = [
            r for r in rows
            if r.get("name") == repo
            or r.get("full_name") == repo
            or str(r.get("torana_repository_id", "")).endswith("/" + repo)
        ]
        if len(exact) == 1:
            rows = exact
        else:
            candidates = "\n  ".join(str(r.get("torana_repository_id")) for r in rows[:10])
            click.echo(
                f"ERROR: --repo {repo!r} is ambiguous; matches:\n  {candidates}\n"
                "Pass the full repo: key to disambiguate.",
                err=True,
            )
            raise SystemExit(6)

    return str(rows[0]["torana_repository_id"])


def _count_vulnerabilities(client, filters: dict):
    """Accurate total via COUNT(*) over the working /query SQL path. Returns int or None."""
    sql = "SELECT count(*) AS n FROM vulnerabilities" + _build_where(filters)
    try:
        data = client.post("/query", json={"query": sql})
    except (APIError, AuthError):
        return None
    rows = data.get("results") if isinstance(data, dict) else None
    if rows and isinstance(rows, list):
        first = rows[0]
        if isinstance(first, dict):
            # column key is 'n'
            return first.get("n", next(iter(first.values()), None))
    return None


@click.group()
def vulnerabilities():
    """Query vulnerability records in the datalake (collection operations).

    \b
    Instance commands (get, update) are under:
      torana vulnerability <ID> <verb>

    \b
    Examples:
      torana vulnerabilities list --source-system semgrep
      torana vulnerabilities list --severity Critical --status Open
      torana vulnerabilities list --repo my-service
    """


@vulnerabilities.command(name="list")
@click.option("--source-system", default=None, help="Filter by source_system (e.g. semgrep, claude_review).")
@click.option("--status", default=None, help="Filter by vulnerability_status (e.g. Open, Fixed).")
@click.option("--severity", default=None, help="Filter by severity (e.g. Critical, High, Medium, Low).")
@click.option("--repo", default=None,
              help="Filter by repository: full key (repo:github.com/org/name) or a name to resolve.")
@click.option("--limit", default=None, type=int, help="Max records to return (default 50).")
@click.option("--offset", default=None, type=int, help="Pagination offset (default 0).")
@click.option("--page", default=None, type=int, help="Page number (alias; 1-indexed).")
@click.option("--page-size", "page_size", default=None, type=int,
              help="Results per page (alias of --limit).")
@click.pass_context
def list_vulnerabilities(ctx, source_system, status, severity, repo, limit, offset,
                         page, page_size):
    """List vulnerability records from the datalake.

    \b
    Examples:
      torana vulnerabilities list --source-system semgrep --status Open
      torana vulnerabilities list --severity Critical --limit 20
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    # Note: don't filter on is_deleted client-side. Many datalake rows have
    # is_deleted=NULL (rather than false) and a literal `is_deleted='false'`
    # filter would exclude them all. Tenant-scoped queries already handle
    # soft-delete semantics at the storage layer.
    # Accept both pagination conventions: --limit/--offset (native) and
    # --page/--page-size (alias). resolve_limit_offset() collapses them.
    from torana_cli.pagination import resolve_limit_offset
    limit, offset = resolve_limit_offset(page, page_size, limit, offset, default_limit=50)

    # Canonicalize Title-Case enum values so lowercase input matches stored rows.
    status = _canon_status(status)
    severity = _canon_severity(severity)

    client = _client(ctx)

    params = {"limit": limit, "offset": offset}
    eq_filters = {}
    if source_system:
        params["source_system"] = source_system
        eq_filters["source_system"] = source_system
    if status:
        params["vulnerability_status"] = status
        eq_filters["vulnerability_status"] = status
    if severity:
        params["severity"] = severity
        eq_filters["severity"] = severity
    if repo:
        repo_id = _resolve_repo_id(client, repo)
        params["torana_repository_id"] = repo_id
        eq_filters["torana_repository_id"] = repo_id

    try:
        data = client.get("/tables/vulnerabilities/data", params=params)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    normalized = _normalize_list_response(data)
    # The datalake list endpoint only returns the page count, not a true total.
    # Issue a COUNT(*) with the same filters so callers get the real total and
    # don't have to page through everything to learn "how many".
    total = _count_vulnerabilities(client, eq_filters)
    if total is not None:
        normalized["total"] = total
        normalized["page_count"] = len(normalized.get("items", []))
    output(normalized, fmt=fmt, raw=raw, fields=fields, columns=_VULN_COLS)


@vulnerabilities.command(name="count")
@click.option("--source-system", default=None, help="Filter by source_system.")
@click.option("--status", default=None,
              help="Filter by vulnerability_status (case-insensitive: open|fixed|accepted|'in progress').")
@click.option("--severity", default=None, help="Filter by severity (case-insensitive: critical|high|...).")
@click.option("--repo", default=None,
              help="Filter by repository: full key (repo:github.com/org/name) or a name to resolve.")
@click.pass_context
def count_vulnerabilities(ctx, source_system, status, severity, repo):
    """Count vulnerability records matching the given filters (accurate total).

    \b
    Examples:
      torana vulnerabilities count --status Open --severity Critical
      torana vulnerabilities count --status open          # case-insensitive
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)

    eq_filters = {}
    if source_system:
        eq_filters["source_system"] = source_system
    if status:
        eq_filters["vulnerability_status"] = _canon_status(status)
    if severity:
        eq_filters["severity"] = _canon_severity(severity)
    if repo:
        eq_filters["torana_repository_id"] = _resolve_repo_id(client, repo)

    total = _count_vulnerabilities(client, eq_filters)
    if total is None:
        click.echo("ERROR: count query failed.", err=True)
        raise SystemExit(1)

    if fmt in ("json", "yaml"):
        output({"total": total, "filters": eq_filters}, fmt=fmt)
    else:
        click.echo(str(total))


# ── The TICKET-LINK caller — BRIDGE-TICKET-001 ──────────────────────────────
#
# ⛔ THIS COMMAND IS THE CALLER, and it is the one that cannot be back-filled.
#
# `vulnerabilities.torana_issue_id` — "the ticket tracking remediation" — was
# declared, documented, and written by NOTHING. Worse than an ordinary empty
# column: `issues.torana_issue_id` IS reachable (it is the issue's own PK,
# written by three mappings), so BOTH sides of the join look present, the join is
# written with confidence, and it parses, EXPLAINs, runs — and returns ZERO ROWS
# forever. 8 corpus refusals turn on exactly this.
#
# ⚠️ `kind=correlation`, and that is the whole urgency. A `value` bridge (triage,
# above) can be filled at any later time — an analyst can assess a year-old
# finding. This association exists for ONE INSTANT: when somebody opens a ticket
# for a finding, while both ids are in hand. Nobody reconstructs six months later
# which of 82k findings a given ticket was opened for. Every day without a caller
# is remediation history permanently lost.
#
# ⚠️ VENDOR-NEUTRAL BY CONSTRUCTION — do not let this become a Jira-only path.
# `torana_issue_id` is `<source>_<kind>_<native id>`: `jira_issue_10432`,
# `gitlab_issue_77`, `gitlab_mr_8891`. Measured on t1, 445 of 660 issues are
# GitLab, NOT Jira, and a merge request is as valid a remediation target as a
# ticket. A raw vendor key ('SEC-4421'), a numeric id, or a ticket URL is refused
# by the endpoint — it would join to nothing, reproducing the silent-empty-join
# this exists to prevent.
#
# Batched because the real cardinality is N:1 — "upgrade log4j everywhere" is ONE
# ticket covering many findings — so the common case must not need N round-trips.
#
# ⛔ ON CHANGING THIS FILE: `_LINK_VULN_ISSUE_WRITER.expected_caller.status` in
# pantheon-integration/torana_mesh/api/routes/ingest.py is `manual` BECAUSE this
# command exists. Delete or rename it and that field silently becomes a lie —
# flip it back to `none` in the same change.
@vulnerabilities.command(name="link-issue")
@click.option("--vulnerability", "vulnerability_id", default=None,
              help="torana_vulnerability_id to link (repeat with --issue for a single pair).")
@click.option("--issue", "issue_id", default=None,
              help="torana_issue_id — e.g. jira_issue_10432, gitlab_issue_77, gitlab_mr_8891. "
                   "NOT a vendor key like SEC-4421, and not a URL.")
@click.option("--from-file", "from_file", type=click.Path(exists=True, dir_okay=False),
              default=None,
              help="JSON file of pairs: [{\"torana_vulnerability_id\":..., \"torana_issue_id\":...}] "
                   "— the N:1 case, one ticket covering many findings.")
@click.pass_context
def link_issue(ctx, vulnerability_id, issue_id, from_file):
    """Record that a ticket tracks remediation of a finding.

    Writes the vulnerabilities side of the link. Both ids are TORANA ids; the
    endpoint verifies both exist before writing anything, so an unresolvable id
    is refused rather than stored as a link that joins to nothing.

    \b
    Examples:
      torana vulnerabilities link-issue --vulnerability <VID> --issue gitlab_mr_8891
      torana vulnerabilities link-issue --vulnerability <VID> --issue jira_issue_10432
      torana vulnerabilities link-issue --from-file links.json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    if from_file and (vulnerability_id or issue_id):
        click.echo("ERROR: --from-file is exclusive with --vulnerability/--issue.", err=True)
        sys.exit(6)

    links = []
    if from_file:
        try:
            with open(from_file, "r", encoding="utf-8") as fh:
                parsed = json.load(fh)
        except (OSError, ValueError) as e:
            click.echo(f"ERROR: could not read {from_file}: {e}", err=True)
            sys.exit(6)
        if isinstance(parsed, dict):
            parsed = parsed.get("links", parsed)
        if not isinstance(parsed, list) or not parsed:
            click.echo(
                "ERROR: --from-file must contain a non-empty JSON array of "
                "{torana_vulnerability_id, torana_issue_id} objects.",
                err=True,
            )
            sys.exit(6)
        links = parsed
    else:
        if not vulnerability_id or not issue_id:
            click.echo(
                "ERROR: --vulnerability and --issue must BOTH be provided "
                "(or use --from-file for a batch).\n"
                "--issue takes a TORANA issue id (jira_issue_10432, gitlab_mr_8891), "
                "not a vendor key like SEC-4421.",
                err=True,
            )
            sys.exit(6)
        links = [{"torana_vulnerability_id": vulnerability_id, "torana_issue_id": issue_id}]

    client = _client(ctx)
    try:
        result = client.post("ingest/vulnerability-issue-links", json={"links": links})
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields)
