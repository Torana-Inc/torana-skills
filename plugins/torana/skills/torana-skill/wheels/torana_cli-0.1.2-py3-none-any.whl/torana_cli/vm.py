"""torana vm — the Vulnerability Management semantic CLI parent group.

This module exists ONLY to define the shared ``torana vm`` group and the helper
that lets the VM capability specs attach their own subgroups onto it. It carries
no commands of its own.

Ownership (VM design spec set, R5 CLI-group hand-off):
  - **Spec A — App Templates** creates this group (this file) and registers it in
    ``main.py``. Its own commands live under ``torana workspaces app-templates`` /
    ``torana workspaces create --app-template`` (starter apps are a workspace-creation
    concern, not a ``vm`` subgroup) — so Spec A attaches NO subgroup here.
  - **Spec B — Transformer Catalog** attaches ``torana vm transformers``.
  - **Spec C — Domain Vocabulary & Policy Binding** attaches ``torana vm policy``.

Each spec's CLI module defines its OWN subgroup and attaches it via
``register_vm_subgroup(<subgroup>)`` — no spec re-defines the ``vm`` group, so the
three implementation sessions can build in parallel without colliding on this file.
This mirrors the existing ``register_workspace_build_v2(workspace)`` pattern in
``build_v2.py``.

Usage from a capability CLI module (e.g. ``vm_transformers.py`` / ``vm_policy.py``)::

    import click
    from torana_cli.vm import register_vm_subgroup

    @click.group(name="transformers")
    def transformers():
        \"\"\"Manage the VM transformer catalog and materializations.\"\"\"

    # ... define subcommands on `transformers` ...

    register_vm_subgroup(transformers)

Then, in ``main.py`` ``_register_commands()``, import the capability module so its
``register_vm_subgroup(...)`` call runs (import side effect), and ensure ``vm`` itself
is registered once via ``cli.add_command(vm)`` (done here's caller).
"""

import click


@click.group(name="vm")
def vm():
    """Vulnerability Management — pre-built programs, transformer catalog, and policy.

    \b
    Subgroups are attached by the VM capability specs:
      torana vm transformers   (Spec B — transformer catalog & materialization)
      torana vm policy         (Spec C — domain vocabulary & policy binding)
      torana vm properties     (Spec G — domain property registry)
    (Spec A app templates live under `torana workspaces app-templates`.)

    \b
    ⚠️ ORDER MATTERS: policy vocabulary BINDS before transformers render. A
    transformer materialized against unbound vocabulary renders against unset
    values and returns rows that look fine and mean nothing. Bind first.

    \b
    Examples:
      torana vm policy vocabulary                    the keys and their bound values
      torana vm policy vocabulary-browse             rollup + categories
      torana vm transformers catalog list            reviewed definitions — read before authoring SQL
      torana vm transformers catalog show <ENTRY_ID>
      torana vm transformers materialized            this tenant's built tables
      torana vm properties --help
    """


def register_vm_subgroup(subgroup: click.Command) -> None:
    """Attach a capability subgroup (e.g. ``transformers``, ``policy``, ``usecases``) onto ``torana vm``.

    Idempotent: attaching a subgroup whose name is already present is a no-op, so
    parallel imports / double-registration never raise. This is what lets Specs A/B/C
    each own their subgroup file without coordinating on the ``vm`` group definition.
    """
    name = subgroup.name
    if name in vm.commands:
        # Already attached (e.g. module imported twice) — do not clobber or raise.
        return
    vm.add_command(subgroup)
