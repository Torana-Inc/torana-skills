"""torana admin — admin service commands."""

import json
import os
import urllib.parse
import urllib.request

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.confirm import confirm as _confirm


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group()
def admin():
    """Admin service operations.

    \b
    Examples:
      torana admin health
      torana admin schema --service pantheon-auth
      torana admin metrics --service pantheon-detection
      torana admin cleanup orphaned
    """


@admin.command(name="health")
@click.option("--service", default=None, help="Specific service name to check.")
@click.pass_context
def admin_health(ctx, service):
    """Check health status of all services (or a specific service)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        if service:
            data = client.get(f"admin/service-info/health/{service}/")
        else:
            data = client.get("admin/service-info/health/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        if isinstance(data, dict):
            for svc, status in data.items():
                click.echo(f"  {svc}: {status}")
        else:
            click.echo(str(data))


@admin.command(name="startup-health")
@click.option("--failed-only", is_flag=True, help="Show only services that failed startup or are unreachable.")
@click.pass_context
def admin_startup_health(ctx, failed_only):
    """Show whether each service finished starting up correctly.

    Different question from `admin health`: that one asks "are you alive?"
    (can the service reach its database). This one asks "did you finish
    starting up?". A worker whose startup partially failed still passes a
    liveness probe, so it can look healthy while being materially broken —
    which is exactly how a missing table silently disabled API
    self-registration and took three agents to 0.0 health.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get("startup-health")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
        return

    services = data.get("services", []) if isinstance(data, dict) else []
    if failed_only:
        services = [s for s in services if s.get("healthy") is False or not s.get("reachable", True)]

    if not services:
        click.echo("No services to report." if failed_only else "No startup health data returned.")
        return

    click.echo(f"{'SERVICE':32} {'STARTUP':12} DETAIL")
    for s in services:
        name = s.get("service", "?")
        if not s.get("reachable", True):
            # Not a failure — most likely the service has not adopted the
            # shared startup_router yet. Labelled so it does not read as broken.
            state, detail = "n/a", s.get("error", "") or ""
        elif s.get("healthy") is False:
            state = "FAILED"
            crit = s.get("critical_failures") or []
            detail = ", ".join(crit) if crit else "startup did not complete"
        else:
            state, detail = "ok", ""
        click.echo(f"  {name:30} {state:12} {detail}")

    unhealthy = data.get("unhealthy_count", 0)
    unreachable = data.get("unreachable_count", 0)
    if unhealthy:
        click.echo(f"\n{unhealthy} service(s) failed a critical startup step.")
    if unreachable:
        click.echo(f"{unreachable} service(s) did not report startup health.")


@admin.command(name="schema")
@click.option("--service", default=None, help="Service name to inspect schema for.")
@click.option("--database", default=None, help="Database name.")
@click.option("--table", default=None, help="Table name.")
@click.pass_context
def admin_schema(ctx, service, database, table):
    """Inspect database schema across services.

    \b
    Examples:
      torana admin schema
      torana admin schema --service pantheon-auth
      torana admin schema --service pantheon-auth --table users
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if service:
        params["service"] = service
    if database:
        params["database"] = database
    if table:
        params["table"] = table

    client = _client(ctx)
    try:
        data = client.get("admin/schema/", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@admin.group(name="services")
def admin_services():
    """Service build identity, composed overview, and connection info.

    \b
      torana admin services list      what code is each service running
      torana admin services overview  health + startup + traffic + version
      torana admin services info      raw service connection info
    """


def _fmt_commit_time(raw) -> str:
    """ISO-8601 commit time -> compact 'YYYY-MM-DD HH:MM' in local time.

    ⚠️ "unknown" is passed through UNCHANGED, never rendered as a date or as an
    em-dash that could read as "no commits". An image built before the
    PANTHEON_COMMIT_TIME build arg existed genuinely cannot say how old it is, and
    saying so is the honest answer — a plausible-but-wrong build date is worse than
    an absent one because it reads as authoritative.
    """
    s = str(raw or "").strip()
    if not s or s == "unknown":
        return "unknown"
    try:
        from datetime import datetime
        return datetime.fromisoformat(s).astimezone().strftime("%Y-%m-%d %H:%M")
    except (ValueError, TypeError):
        return s[:16]


def _age_note(raw) -> str:
    """Human age of a commit, e.g. '3d ago'. Empty when it cannot be computed."""
    s = str(raw or "").strip()
    if not s or s == "unknown":
        return ""
    try:
        from datetime import datetime, timezone
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        secs = (datetime.now(timezone.utc) - dt).total_seconds()
        if secs < 0:
            return ""
        if secs < 3600:
            return f"{int(secs // 60)}m ago"
        if secs < 86400:
            return f"{int(secs // 3600)}h ago"
        return f"{int(secs // 86400)}d ago"
    except (ValueError, TypeError):
        return ""


@admin_services.command(name="list")
@click.option("--full-sha", is_flag=True, help="Show full 40-char commit SHAs instead of the short form.")
@click.pass_context
def admin_services_build_list(ctx, full_sha):
    """Build identity for every service: commit, commit time, and shared lib.

    Answers "what code is actually deployed, and how old is it?" — one bulk admin
    call that fans out server-side, rather than the client issuing one request per
    service.

    \b
    Three things per service:
      COMMIT       the service repo's commit SHA (+ branch, dirty marker)
      COMMITTED    committer date of that SHA, with a relative age
      SHARED       the pantheon-shared wheel baked into the image

    SHARED drifts INDEPENDENTLY of COMMIT: rebuilding a service without running
    update-dist.sh first leaves new service code running an old shared lib. If the
    SHARED column is not uniform, that is what a "my pantheon_shared fix isn't
    taking effect" bug looks like.

    ⚠️ "unknown" in COMMITTED means the image predates the commit-time build arg —
    rebuild it to populate the field. It is never approximated.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get("services/list")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        # The asking CLI is part of the answer in every format, not just text.
        from torana_cli import __version__, __commit_sha__, __dirty__, __built_at__
        if isinstance(data, dict):
            data = dict(data)
            data["cli"] = {
                "version": __version__,
                "commit": __commit_sha__,
                "dirty": bool(__dirty__),
                "built_at": __built_at__,
                "source_staleness": _cli_source_staleness(),
            }
        output(data, fmt=fmt)
        return

    services = data.get("services", []) if isinstance(data, dict) else []
    if not services:
        click.echo("No services returned.")
        return

    # ── Table 1: services ────────────────────────────────────────────────────
    # SHARED is a short REFERENCE into table 2, not the full build — repeating a
    # 40-char SHA and its date on every row buries the one fact that matters
    # (which services disagree) under twelve identical strings.
    width = 42 if full_sha else 12
    click.echo(f"  {'SERVICE':30} {'VERSION':9} {'COMMIT':{width}} {'COMMITTED':26} SHARED")
    for s in services:
        name = s.get("service", "?")
        if not s.get("reachable", True):
            click.echo(f"  {name:30} {'-':9} {'unreachable':{width}} "
                       f"{(s.get('error') or '')[:24]:26} -")
            continue

        sha = str(s.get("commit_sha") or "unknown")
        sha_disp = sha if full_sha else sha[:8]
        if s.get("dirty"):
            sha_disp += "*"

        committed = _fmt_commit_time(s.get("commit_time"))
        age = _age_note(s.get("commit_time"))
        when = f"{committed}  ({age})" if age else committed

        shared = str(s.get("shared_commit_sha") or "unknown")
        shared_disp = shared if full_sha else shared[:8]
        if s.get("shared_dirty"):
            shared_disp += "*"

        click.echo(f"  {name:30} {str(s.get('version') or '-'):9} "
                   f"{sha_disp:{width}} {when:26} {shared_disp}")

    if data.get("dirty_count"):
        click.echo(f"\n* {data['dirty_count']} service(s) built from a DIRTY tree — "
                   f"the SHA does not fully describe the running code.")

    if data.get("unreachable_count"):
        click.echo(f"{data['unreachable_count']} service(s) unreachable.")

    if any(str(s.get("commit_time") or "unknown") == "unknown"
           for s in services if s.get("reachable", True)):
        click.echo("Some images predate the commit-time stamp and report "
                   "COMMITTED=unknown; rebuild them to populate it.")

    # ── Table 2: the shared libs those SHARED values point at ────────────────
    _echo_shared_table(services, data, full_sha)

    _echo_client_build()


def _echo_shared_table(services, data, full_sha):
    """Expand each distinct pantheon-shared build the services above reference.

    ⛔ WHY A SECOND TABLE. The shared wheel is a SECOND build axis, independent of
    the service commit: rebuilding a service without running update-dist.sh first
    leaves new service code on an old shared lib. That is invisible per-row —
    "19f897e6" on eight rows says nothing on its own. Grouping by SHA makes the
    split, and which services fall on each side of it, the thing you actually read.
    """
    import collections

    groups = collections.OrderedDict()
    for s in services:
        if not s.get("reachable", True):
            continue
        sha = str(s.get("shared_commit_sha") or "unknown")
        g = groups.setdefault(sha, {
            "commit_time": s.get("shared_commit_time"),
            "branch": s.get("shared_branch"),
            "dirty": bool(s.get("shared_dirty")),
            "services": [],
        })
        g["services"].append(s.get("service", "?"))

    if not groups:
        return

    click.echo("")
    click.echo("pantheon-shared builds in use:")

    width = 42 if full_sha else 12
    click.echo(f"  {'SHARED':{width}} {'BRANCH':30} {'COMMITTED':26} USED BY")
    for sha, g in groups.items():
        disp = sha if full_sha else sha[:8]
        if g["dirty"]:
            disp += "*"

        committed = _fmt_commit_time(g["commit_time"])
        age = _age_note(g["commit_time"])
        when = f"{committed}  ({age})" if age else committed

        names = g["services"]
        # Name every service on the MINORITY builds — those are the ones someone
        # has to go rebuild. Collapse only a large uniform group, where the list
        # is noise rather than a work item.
        if len(names) > 4:
            used_by = f"{len(names)} services"
        else:
            used_by = ", ".join(names)

        click.echo(f"  {disp:{width}} {str(g['branch'] or '-'):30} {when:26} {used_by}")

    variants = data.get("shared_sha_variants", 0)
    if variants > 1:
        click.echo(f"\n⚠️  {variants} different pantheon-shared builds across the fleet. "
                   f"A shared-lib change is live in some services and not others.")
        click.echo("   Rebuild:  $TORANA_ROOT/pantheon-deploy/scripts/update-dist.sh "
                   "&& dev-compose rebuild <service>")


def _echo_client_build():
    """Report the build identity of the CLIENT asking the question.

    ⛔ NOT decoration. The services above are one half of "which build answered
    me?" — the other half is the CLI that asked. This is the CLI-44 / CLI-51 /
    CLI-52 complaint: a stale `torana` reports a capability missing when it is
    merely absent from THIS build, and a version string cannot distinguish two
    builds where a commit can. It lives here because this is now the one command
    whose whole job is "what code is running where".
    """
    from torana_cli import __version__, __commit_sha__, __dirty__, __built_at__

    sha = str(__commit_sha__ or "unknown")
    line = f"\ntorana CLI {__version__}  {sha[:8]}"
    if __dirty__:
        line += "*"
    if __built_at__ and __built_at__ != "unknown":
        line += f"  built {str(__built_at__)[:16]}"
    click.echo(line)

    stale = _cli_source_staleness()
    if stale.get("checked") and stale.get("stale"):
        behind = stale.get("commits_behind")
        how_far = f"{behind} commit(s) behind" if behind else "diverged from"
        click.echo(f"⚠️  STALE CLI — this build is {how_far} the pantheon-cli source "
                   f"({str(stale.get('source_commit') or '?')[:8]}).")
        click.echo("   A command that looks missing may simply be absent from THIS build.")
        click.echo("   Rebuild:  $TORANA_ROOT/pantheon-deploy/scripts/update-dist.sh")


def _cli_source_staleness() -> dict:
    """Compare the INSTALLED CLI against the pantheon-cli source tree, when reachable.

    ⚠️ Not-checked is reported as UNKNOWN, never as up-to-date — claiming currency
    we did not verify is the same false confidence this exists to remove.
    """
    import subprocess
    from pathlib import Path
    from torana_cli import __commit_sha__

    out = {"checked": False, "stale": None, "commits_behind": None, "source_commit": None}

    installed = str(__commit_sha__ or "").strip()
    if not installed or installed == "unknown":
        return out

    here = Path(__file__).resolve()
    repo = None
    for parent in here.parents:
        if (parent / ".git").exists() and (parent / "torana_cli").is_dir():
            repo = parent
            break
    if repo is None:
        return out

    def _git(*args):
        return subprocess.run(["git", "-C", str(repo), *args],
                              capture_output=True, text=True, timeout=10)

    try:
        head = _git("rev-parse", "HEAD")
        if head.returncode != 0:
            return out
        source_commit = head.stdout.strip()
        out["source_commit"] = source_commit
        if source_commit == installed:
            out.update(checked=True, stale=False, commits_behind=0)
            return out
        if _git("merge-base", "--is-ancestor", installed, "HEAD").returncode == 0:
            cnt = _git("rev-list", "--count", f"{installed}..HEAD")
            behind = int(cnt.stdout.strip()) if cnt.returncode == 0 and cnt.stdout.strip() else None
            out.update(checked=True, stale=True, commits_behind=behind)
        else:
            out.update(checked=True, stale=True, commits_behind=None)
        return out
    except (subprocess.SubprocessError, OSError, ValueError):
        return out


@admin_services.command(name="info")
@click.pass_context
def admin_services_info(ctx):
    """Raw service connection information."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get("admin/service-info/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


def _render_services_overview(ctx, problems_only):
    """Shared body for `services overview` and its deprecated flat alias."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get("services/overview")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
        return

    services = data.get("services", []) if isinstance(data, dict) else []
    if problems_only:
        services = [s for s in services if s.get("status") != "healthy" or not s.get("reachable", True)]

    if not services:
        click.echo("All services healthy." if problems_only else "No services returned.")
        return

    click.echo(f"{'SERVICE':32} {'STATUS':13} {'STARTUP':10} {'TRAFFIC':22} VERSION")
    for s in services:
        name = s.get("service", "?")
        status = "unreachable" if not s.get("reachable", True) else str(s.get("status", "unknown"))

        ok = s.get("startup_ok")
        startup = "ok" if ok is True else ("FAILED" if ok is False else "n/a")

        if s.get("has_metrics"):
            traffic = (
                f"{s.get('total_requests') or 0} req"
                f" / {s.get('errors_4xx') or 0} 4xx"
                f" / {s.get('errors_5xx') or 0} 5xx"
            )
        else:
            traffic = "none yet"

        click.echo(f"  {name:30} {status:13} {startup:10} {traffic:22} {s.get('version') or '-'}")

    bad = data.get("unhealthy_count", 0) + data.get("unreachable_count", 0)
    if bad:
        click.echo(f"\n{bad} service(s) need attention.")
    if data.get("degraded_count"):
        click.echo(f"{data['degraded_count']} service(s) degraded.")


@admin_services.command(name="overview")
@click.option("--problems-only", is_flag=True, help="Show only services that are not healthy.")
@click.pass_context
def admin_services_overview_cmd(ctx, problems_only):
    """Composed per-service overview: health + startup + version + traffic.

    Backed by ONE bulk admin endpoint that fans out server-side. The same view
    in the FE previously existed only as browser-side fan-out (~24 requests),
    so there was nothing scriptable to call — this closes that gap.

    Note on the TRAFFIC column: inter-service client metrics only populate once
    a service makes an OUTBOUND call to another service. "none" means no
    traffic yet, NOT a problem — conflating those two is what used to show
    healthy services as Error.

    For build identity (commit SHA / commit time / shared lib) see
    `torana admin services list`.
    """
    _render_services_overview(ctx, problems_only)


@admin.command(name="services-overview", hidden=True)
@click.option("--problems-only", is_flag=True, help="Show only services that are not healthy.")
@click.pass_context
def admin_services_overview(ctx, problems_only):
    """Deprecated alias for `torana admin services overview`."""
    click.echo("note: `torana admin services-overview` is deprecated; "
               "use `torana admin services overview`.", err=True)
    _render_services_overview(ctx, problems_only)


@admin.command(name="metrics")
@click.option("--service", default=None, help="Service name.")
@click.pass_context
def admin_metrics(ctx, service):
    """View service metrics.

    \b
    Example:
      torana admin metrics --service pantheon-detection
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    params = {}
    if service:
        params["service"] = service

    client = _client(ctx)
    try:
        data = client.get("admin/metrics/", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@admin.group(name="cleanup")
def admin_cleanup():
    """Admin cleanup operations.

    \b
    Examples:
      torana admin cleanup orphaned
      torana admin cleanup permissions-audit
    """


@admin_cleanup.command(name="orphaned")
@click.option("--dry-run", is_flag=True, default=False,
              help="Show what would be cleaned without deleting.")
@click.pass_context
def cleanup_orphaned(ctx, dry_run):
    """Clean up orphaned data."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    params = {}
    if dry_run:
        params["dry_run"] = "true"

    client = _client(ctx)
    try:
        data = client.post("admin/cleanup/orphaned/", json=params or {})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo("Cleanup complete." if not dry_run else "Dry run complete (no changes made).")
        if isinstance(data, dict):
            for k, v in data.items():
                click.echo(f"  {k}: {v}")


@admin_cleanup.command(name="permissions-audit")
@click.pass_context
def cleanup_permissions_audit(ctx):
    """Run a permissions audit."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get("admin/cleanup/permissions-audit/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@admin.group(name="tenant-management")
def admin_tenant_management():
    """Admin tenant management operations.

    \b
    Examples:
      torana admin tenant-management preview <TENANT_ID>
      torana admin tenant-management hard-delete <TENANT_ID> --yes
    """


@admin_tenant_management.command(name="preview")
@click.argument("tenant_id", metavar="TENANT_ID")
@click.pass_context
def tenant_management_preview(ctx, tenant_id):
    """Preview what would be deleted for a tenant hard-delete."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(f"admin/tenant-management/{tenant_id}/preview/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@admin_tenant_management.command(name="hard-delete")
@click.argument("tenant_id", metavar="TENANT_ID")
@click.option("--yes", is_flag=True, default=False,
              help="Confirm destructive tenant deletion.")
@click.pass_context
def tenant_management_hard_delete(ctx, tenant_id, yes):
    """Hard-delete all data for a tenant (DESTRUCTIVE — cannot be undone)."""
    _confirm(f"PERMANENTLY delete ALL data for tenant {tenant_id}? This cannot be undone.", yes=yes)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"admin/tenant-management/{tenant_id}/hard-delete/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Hard-deleted tenant: {tenant_id}")


@admin.command(name="running")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def admin_running(ctx, page, page_size, fetch_all):
    """Get Running Sessions."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "admin/sessions/running"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@admin.command(name="cancel")
@click.argument("SESSION_ID", metavar="SESSION_ID")
@click.pass_context
def admin_cancel(ctx, session_id):
    """Cancel Running Session."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"admin/sessions/{session_id}/cancel"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ──────────────────────────────────────────────────────────────────────────
# Instance reads regrouped from `<noun>-by-<param>` leaves onto verbs
# (CLI Discoverability Contract, rule 2 — see ../CLAUDE.md). The route
# parameter belongs in the positional ARGUMENT, not in the command name.
#
# Old flat names remain as HIDDEN aliases for ONE release (D4).
# ──────────────────────────────────────────────────────────────────────────


@admin.group(name="table")
def admin_table_grp():
    """One datalake table's schema, by name.

    Examples:
      torana admin table get --help
    """


@admin.group(name="turn")
def admin_turn_grp():
    """One session turn, by id.

    Examples:
      torana admin turn delete --help
    """


@admin.group(name="workspace-sweep")
def admin_workspace_sweep_grp():
    """One workspace's sweep state, by workspace id.

    Examples:
      torana admin workspace-sweep get --help
    """


@admin.group(name="workspace-admin")
def admin_workspace_admin_grp():
    """Cross-tenant workspace admin actions.

    Examples:
      torana admin workspace-admin update --help
    """


@admin_turn_grp.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("SESSION_ID", metavar="SESSION_ID")
@click.argument("TURN_ID", metavar="TURN_ID")
@click.option("--reason", "reason", default=None)
@click.pass_context
def admin_turns_by_turn_id(ctx, session_id, turn_id, reason, yes):
    """Delete Session Turn."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"admin/sessions/{session_id}/turns/{turn_id}"
    body = {}
    if reason is not None:
        body["reason"] = reason

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@admin.command(name="restore")
@click.argument("SESSION_ID", metavar="SESSION_ID")
@click.argument("TURN_ID", metavar="TURN_ID")
@click.pass_context
def admin_restore(ctx, session_id, turn_id):
    """Restore Session Turn."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"admin/sessions/{session_id}/turns/{turn_id}/restore"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@admin.command(name="deleted-turns")
@click.argument("SESSION_ID", metavar="SESSION_ID")
@click.pass_context
def admin_deleted_turns(ctx, session_id):
    """Get Deleted Turns."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"admin/sessions/{session_id}/deleted-turns"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@admin.command(name="sweep-status")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def admin_status(ctx, page, page_size, fetch_all):
    """Get workspace sweep scheduler status (super_admin only)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "admin/sweep-scheduler/status"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@admin.command(name="impersonate")
@click.option("--tenant-id", "tenant_id", required=True, help="ID of the tenant to impersonate")
@click.option("--namespace-id", "namespace_id", default=None, help="Optional namespace ID within the tenant")
@click.pass_context
def admin_impersonate(ctx, tenant_id, namespace_id):
    """Impersonate Tenant."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "admin/impersonate"
    body = {}
    body["tenant_id"] = tenant_id
    if namespace_id is not None:
        body["namespace_id"] = namespace_id

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@admin.command(name="exit-impersonation")
@click.pass_context
def admin_exit_impersonation(ctx):
    """Exit Impersonation."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "admin/exit-impersonation"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@admin.command(name="impersonation-status")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def admin_impersonation_status(ctx, page, page_size, fetch_all):
    """Get Impersonation Status."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "admin/impersonation-status"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@admin.command(name="stats")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--tenant-id", "tenant_id", default=None, help="Filter by tenant ID")
@click.option("--days-back", "days_back", type=int, default=30, help="Days to look back for activity metrics")
@click.pass_context
def overview_stats(ctx, tenant_id, days_back, page, page_size, fetch_all):
    """Get Iam Overview Stats."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "overview/stats"
    params = {}
    if tenant_id is not None:
        params["tenant_id"] = tenant_id
    if days_back is not None:
        params["days_back"] = days_back
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@admin.command(name="detailed")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--tenant-id", "tenant_id", default=None, help="Filter by tenant ID")
@click.option("--days-back", "days_back", type=int, default=30, help="Days to look back for activity metrics")
@click.pass_context
def overview_detailed(ctx, tenant_id, days_back, page, page_size, fetch_all):
    """Get Detailed Iam Stats."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "overview/stats/detailed"
    params = {}
    if tenant_id is not None:
        params["tenant_id"] = tenant_id
    if days_back is not None:
        params["days_back"] = days_back
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@admin.command(name="workspace-sweeps")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def admin_workspace_sweeps(ctx, page, page_size, fetch_all):
    """List all workspaces with sweep state (super_admin only)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "admin/workspace-sweeps"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@admin_workspace_sweep_grp.command(name="get")
@click.argument("WORKSPACE_ID", metavar="WORKSPACE_ID")
@click.pass_context
def admin_workspace_sweeps_by_workspace_id(ctx, workspace_id):
    """Get workspace sweep detail (super_admin only)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"admin/workspace-sweeps/{workspace_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@admin.command(name="trigger")
@click.argument("WORKSPACE_ID", metavar="WORKSPACE_ID")
@click.pass_context
def admin_trigger(ctx, workspace_id):
    """Trigger workspace sweep (super_admin only)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"admin/workspace-sweeps/{workspace_id}/trigger"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@admin_workspace_admin_grp.command(name="update")
@click.argument("WORKSPACE_ID", metavar="WORKSPACE_ID")
@click.option("--agent-id", "agent_id", default=None)
@click.option("--agent-name", "agent_name", default=None)
@click.option("--builder-agent-id", "builder_agent_id", default=None)
@click.option("--builder-agent-name", "builder_agent_name", default=None)
@click.pass_context
def admin_workspaces_by_workspace_id(ctx, workspace_id, agent_id, agent_name, builder_agent_id, builder_agent_name):
    """Update workspace agent assignments (super_admin only)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"admin/workspaces/{workspace_id}"
    body = {}
    if agent_id is not None:
        body["agent_id"] = agent_id
    if agent_name is not None:
        body["agent_name"] = agent_name
    if builder_agent_id is not None:
        body["builder_agent_id"] = builder_agent_id
    if builder_agent_name is not None:
        body["builder_agent_name"] = builder_agent_name

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@admin.command(name="tables")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--service", "service", required=True, help="Service name (e.g., 'pantheon-auth'). Required parameter.")
@click.pass_context
def schemas_tables(ctx, service, page, page_size, fetch_all):
    """List All Tables."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "schemas/tables"
    params = {}
    if service is not None:
        params["service"] = service
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@admin_table_grp.command(name="get")
@click.argument("TABLE_NAME", metavar="TABLE_NAME")
@click.option("--service", "service", required=True, help="Service name (e.g., 'pantheon-auth'). Required parameter.")
@click.pass_context
def schemas_tables_by_table_name(ctx, table_name, service):
    """Get Table Schema."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"schemas/tables/{table_name}"
    params = {}
    if service is not None:
        params["service"] = service

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@admin.command(name="list")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--service", "service", required=True, help="Service name (e.g., 'pantheon-auth'). Required parameter.")
@click.pass_context
def schemas_list(ctx, service, page, page_size, fetch_all):
    """Get All Schemas."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "schemas"
    params = {}
    if service is not None:
        params["service"] = service
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@admin.command(name="data")
@click.argument("TABLE_NAME", metavar="TABLE_NAME")
@click.option("--service", "service", required=True, help="Service name (e.g., 'pantheon-auth'). Required parameter.")
@click.option("--limit", "limit", type=int, default=50, help="Maximum number of records to return")
@click.option("--cursor", "cursor", default=None, help="Cursor for pagination")
@click.option("--order-by", "order_by", default=None, help="Ordering fields (e.g., 'created_at:desc,name:asc')")
@click.option("--count", "count", type=bool, default=False, help="Include total count (expensive operation)")
@click.pass_context
def schemas_data(ctx, table_name, service, limit, cursor, order_by, count):
    """Get Table Data."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"schemas/tables/{table_name}/data"
    params = {}
    if service is not None:
        params["service"] = service
    if limit is not None:
        params["limit"] = limit
    if cursor is not None:
        params["cursor"] = cursor
    if order_by is not None:
        params["order_by"] = order_by
    if count is not None:
        params["count"] = count

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


def _render_services_registered(ctx):
    """Shared body for `services registered` and its deprecated flat alias."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("services/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@admin_services.command(name="registered")
@click.pass_context
def admin_services_registered(ctx):
    """List registered services and their database mapping.

    This is the SERVICE REGISTRY (which services exist and which database each
    owns) — not build identity. For "what code is deployed", use
    `torana admin services list`.
    """
    _render_services_registered(ctx)


@admin.command(name="services-list", hidden=True)
@click.pass_context
def admin_services_list_flat(ctx):
    """Deprecated alias for `torana admin services registered`."""
    click.echo("note: `torana admin services-list` is deprecated; "
               "use `torana admin services registered`.", err=True)
    _render_services_registered(ctx)


@admin.command(name="services-db-metrics")
@click.pass_context
def admin_services_db_metrics(ctx):
    """Get database metrics for all services."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("services/database/metrics")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ---------------------------------------------------------------------------
# startup-flags — cross-service feature flag management (SA only)
# ---------------------------------------------------------------------------

@admin.group(name="startup-flags")
def admin_startup_flags():
    """Manage service startup flags (super-admin only).

    \b
    Examples:
      torana admin startup-flags list
      torana admin startup-flags list --service pantheon-detection-framework
      torana admin startup-flags clear
      torana admin startup-flags clear --service pantheon-detection-framework
    """


@admin_startup_flags.command(name="list")
@click.option("--service", default=None, help="Filter to a specific service name.")
@click.pass_context
def admin_startup_flags_list(ctx, service):
    """List startup flags across all services (or for a specific service)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        if service:
            data = client.get(f"startup-flags/{service}")
        else:
            data = client.get("startup-flags")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@admin_startup_flags.command(name="clear")
@click.option("--service", default=None, help="Clear flags for a specific service only.")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def admin_startup_flags_clear(ctx, service, yes):
    """Clear startup flags (all services, or a specific service)."""
    target = service or "all services"
    _confirm(f"Clear startup flags for {target}?", yes=yes)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        if service:
            data = client.delete(f"startup-flags/{service}")
        else:
            data = client.delete("startup-flags")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Cleared startup flags for {target}.")


# ---------------------------------------------------------------------------
# Chat sessions (SA only) — /api/v1/audit/sessions
# ---------------------------------------------------------------------------

_SESSION_LIST_COLS = [
    ("session_id", "SESSION_ID", 75),
    ("tenant_id", "TENANT_ID", 36),
    ("agent_name", "AGENT", 42),
    ("status", "STATUS", 10),
    ("message_count", "MSGS", 6),
    ("last_message_at", "LAST_MSG", 32),
]


@admin.group(name="chats")
def admin_chats():
    """Chat sessions (SA only) — agent chat sessions across all tenants.

    \b
    Filtering options (see 'list --help' for full detail):
      --search      Full-text search across session name, agent name, and message content.
      --agent-id    Narrow to one agent.
      --user-id     Narrow to one user.
      --status      Filter by lifecycle state: active | archived | deleted.
      --start-date  Sessions created on or after this date (ISO 8601).
      --end-date    Sessions created on or before this date (ISO 8601).

    \b
    Examples:
      torana admin chats list
      torana admin chats list --search "CVE-2024"
      torana admin chats list --agent-id <UUID> --status active
      torana admin chats list --start-date 2026-06-01 --end-date 2026-06-17
      torana admin chats list --user-id <UUID> --limit 20
    """


@admin_chats.command(name="list")
@click.option("--agent-id", "agent_id", default=None,
              help="Filter by agent UUID. Returns only sessions for this agent.")
@click.option("--user-id", "user_id", default=None,
              help="Filter by user UUID. Returns only sessions initiated by this user.")
@click.option("--status", "status", default=None,
              help="Filter by session status: active | archived | deleted.")
@click.option("--search", "search_query", default=None,
              help=(
                  "Full-text search (case-insensitive). Matches against session name, "
                  "agent name, and the content of all messages in the session. "
                  "Example: --search \"CVE-2024-1234\" surfaces every session where "
                  "that string appears anywhere in the conversation."
              ))
@click.option("--start-date", "start_date", default=None,
              help="Return sessions created on or after this date (ISO 8601, e.g. 2026-06-01).")
@click.option("--end-date", "end_date", default=None,
              help="Return sessions created on or before this date (ISO 8601, e.g. 2026-06-17).")
@click.option("--limit", "limit", type=int, default=None,
              help="Maximum number of sessions to return (1–1000, default 50).")
@click.option("--offset", "offset", type=int, default=0,
              help="Number of sessions to skip (for pagination).")
@click.pass_context
def admin_chats_list(ctx, agent_id, user_id, status, search_query, start_date, end_date,
                     limit, offset):
    """List chat sessions across all tenants.

    \b
    Filtering:
      --search      Full-text search across session name, agent name, and ALL message
                    content (case-insensitive substring). Use this to find sessions that
                    discussed a specific CVE, asset, or keyword.
      --agent-id    Narrow to one agent UUID.
      --user-id     Narrow to one user UUID.
      --status      Lifecycle filter: active | archived | deleted.
      --start-date  Sessions created >= this date (ISO 8601).
      --end-date    Sessions created <= this date (ISO 8601).

    \b
    Examples:
      torana admin chats list --search "CVE-2024-1234"
      torana admin chats list --search "vulnerability" --status active --limit 20
      torana admin chats list --agent-id <UUID>
      torana admin chats list --user-id <UUID> --start-date 2026-06-01
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    params = {"limit": limit if limit is not None else settings.page_size, "offset": offset}
    if agent_id:
        params["agent_id"] = agent_id
    if user_id:
        params["user_id"] = user_id
    if status:
        params["session_status"] = status
    if search_query:
        params["search_query"] = search_query
    if start_date:
        params["start_date"] = start_date
    if end_date:
        params["end_date"] = end_date

    client = _client(ctx)
    try:
        data = client.get("audit/sessions", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Normalize envelope: API returns total_count/limit/offset, not items/total/page/page_size
    if isinstance(data, dict) and "items" in data and "total" not in data:
        data["total"] = data.get("total_count", len(data["items"]))

    output(data, fmt=fmt, raw=raw, fields=fields, columns=_SESSION_LIST_COLS)


# ---------------------------------------------------------------------------
# Chat session instance commands (SA only) — /api/v1/audit/sessions/{id}/*
# ---------------------------------------------------------------------------


@admin.group(name="chat", invoke_without_command=True)
@click.argument("session_id", metavar="SESSION_ID")
@click.pass_context
def admin_chat(ctx, session_id):
    """Per-session instance commands (SA only).

    \b
    Examples:
      torana admin chat <SESSION_ID> messages
      torana admin chat <SESSION_ID> info
      torana admin chat <SESSION_ID> forks
      torana admin chat <SESSION_ID> intents
    """
    ctx.ensure_object(dict)
    ctx.obj["_chat_session_id"] = session_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _csid(ctx) -> str:
    return ctx.obj.get("_chat_session_id", "") if ctx.obj else ""


@admin_chat.command(name="messages")
@click.option("--limit", type=int, default=None, help="Maximum messages to return.")
@click.option("--offset", type=int, default=0)
@click.pass_context
def admin_chat_messages(ctx, limit, offset):
    """Get messages for a chat session."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    params = {"limit": limit if limit is not None else settings.page_size, "offset": offset}
    client = _client(ctx)
    try:
        data = client.get(f"audit/sessions/{_csid(ctx)}/messages", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@admin_chat.command(name="info")
@click.pass_context
def admin_chat_info(ctx):
    """Get summary info for a chat session."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get(f"audit/sessions/{_csid(ctx)}/info")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@admin_chat.command(name="forks")
@click.pass_context
def admin_chat_forks(ctx):
    """List forked sessions derived from this session."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get(f"audit/sessions/{_csid(ctx)}/forks")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@admin_chat.command(name="intents")
@click.pass_context
def admin_chat_intents(ctx):
    """List detected intents for a chat session."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get(f"audit/sessions/{_csid(ctx)}/intents")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


def _chat_trace_chain(ctx, session_id):
    """Return the session's trace_chain (one entry per turn) from the info endpoint.

    A chat session spans many turns; each turn is its own Jaeger trace. The
    audit info endpoint already carries the full ordered chain, so both
    `traces` and `trace <id>` derive from it — no extra backend needed.
    """
    client = _client(ctx)
    info = client.get(f"audit/sessions/{session_id}/info")
    chain = info.get("trace_chain", []) if isinstance(info, dict) else []
    return chain


_CHAT_TRACES_COLS = [
    ("turn_index", "TURN", 5),
    ("trace_id", "TRACE_ID", None),        # id — never truncate (feed to `trace <id>`)
    ("execution_status", "STATUS", 10),
    ("outcome", "OUTCOME", 12),
    ("started_at", "STARTED", 27),
    ("duration_seconds", "DUR_S", 9),
    ("turn_type", "TURN_TYPE", 18),
]


def _fetch_trace(ctx, trace_id):
    """GET one trace via the authenticated Jaeger proxy. Returns the raw dict.

    Raises APIError / AuthError to the caller. Returns None if the proxy
    responds 200 but with no trace data (empty/purged).
    """
    client = _client(ctx)
    data = client.get(f"jaeger/api/traces/{trace_id}")
    if not isinstance(data, dict) or not data.get("data"):
        return None
    return data


def _save_trace(data, out_path):
    """Write a fetched trace dict to out_path. Returns the span count."""
    with open(out_path, "w") as f:
        json.dump(data, f)
    return len(data["data"][0].get("spans", []))


@admin_chat.group(name="traces", invoke_without_command=True)
@click.pass_context
def admin_chat_traces(ctx):
    """Jaeger traces for this chat session — one trace per turn.

    \b
    A chat session has multiple turns; each turn is a separate trace.
      torana admin chat <SESSION_ID> traces list       # list them
      torana admin chat <SESSION_ID> traces save-all   # save all to files
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@admin_chat_traces.command(name="list")
@click.pass_context
def admin_chat_traces_list(ctx):
    """List every Jaeger trace (one per turn) for this chat session.

    \b
    Lists turns in order with turn index, trace id, status and timing. Copy a
    TRACE_ID and fetch the raw trace with:

    \b
      torana admin chat <SESSION_ID> trace <TRACE_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    try:
        chain = _chat_trace_chain(ctx, _csid(ctx))
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    data = {"items": chain, "total": len(chain), "page": 1, "page_size": len(chain) or 1}
    output(data, fmt=fmt, raw=raw, fields=fields, columns=_CHAT_TRACES_COLS)


@admin_chat_traces.command(name="save-all")
@click.option(
    "--dir", "out_dir", default=".", metavar="DIR",
    help="Directory to write the trace files into (default: current directory).",
)
@click.option(
    "--prefix", "prefix", default="", metavar="PREFIX",
    help="Optional filename prefix, e.g. 'turn' → turn_<TRACE_ID>.json.",
)
@click.pass_context
def admin_chat_traces_save_all(ctx, out_dir, prefix):
    """Fetch EVERY turn's trace for this chat session and save each to a file.

    \b
    Writes one <TRACE_ID>.json per turn (optionally prefixed) into --dir. Each
    file is the exact format the analyzer reads:

    \b
      python analyze_jaeger_llm_latency.py --analyze <TRACE_ID>.json --knob summary
    """
    try:
        chain = _chat_trace_chain(ctx, _csid(ctx))
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if not chain:
        click.echo("No traces for this session.", err=True)
        ctx.exit(3)

    if out_dir and not os.path.isdir(out_dir):
        try:
            os.makedirs(out_dir, exist_ok=True)
        except OSError as e:
            click.echo(f"Error creating {out_dir}: {e}", err=True)
            ctx.exit(1)

    saved = 0
    failed = 0
    for turn in chain:
        tid = turn.get("trace_id")
        if not tid:
            continue
        fname = f"{prefix}{tid}.json" if prefix else f"{tid}.json"
        out_path = os.path.join(out_dir, fname)
        try:
            data = _fetch_trace(ctx, tid)
        except (APIError, AuthError) as e:
            click.echo(f"  turn {turn.get('turn_index')}: fetch failed for {tid}: {e}", err=True)
            failed += 1
            continue
        if data is None:
            click.echo(f"  turn {turn.get('turn_index')}: trace {tid} not found/empty (skipped)", err=True)
            failed += 1
            continue
        try:
            n_spans = _save_trace(data, out_path)
        except OSError as e:
            click.echo(f"  turn {turn.get('turn_index')}: write failed for {out_path}: {e}", err=True)
            failed += 1
            continue
        click.echo(f"  turn {turn.get('turn_index')}: {out_path} ({n_spans} spans)")
        saved += 1

    click.echo(f"Saved {saved}/{len(chain)} traces to {out_dir}" + (f" ({failed} failed)" if failed else ""))
    if saved == 0:
        ctx.exit(3)


@admin_chat.command(name="trace")
@click.argument("TRACE_ID", metavar="TRACE_ID")
@click.option(
    "--save", "save_file", default=None, metavar="FILE",
    help="Write the raw trace JSON to FILE (default: <TRACE_ID>.json in the current directory). "
         "This is the exact format analyze_jaeger_llm_latency.py --analyze reads.",
)
@click.option(
    "--stdout", "to_stdout", is_flag=True, default=False,
    help="Print the trace JSON to stdout instead of saving to a file.",
)
@click.pass_context
def admin_chat_trace(ctx, trace_id, save_file, to_stdout):
    """Fetch ONE trace (turn) of this chat session and save it to <TRACE_ID>.json.

    \b
    Retrieves the full trace via the authenticated Jaeger proxy
    (GET /api/v1/jaeger/api/traces/{TRACE_ID}) and writes it in the exact
    {"data":[{"traceID","spans":[...]}]} shape the analyzer consumes:

    \b
      python analyze_jaeger_llm_latency.py --analyze <TRACE_ID>.json --knob summary

    Get the TRACE_ID from `torana admin chat <SESSION_ID> traces list`.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    try:
        data = _fetch_trace(ctx, trace_id)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if data is None:
        click.echo(f"Trace not found or empty: {trace_id}", err=True)
        ctx.exit(3)

    if to_stdout:
        output(data, fmt=fmt if fmt in ("json", "yaml") else "json")
        return

    out_path = save_file or f"{trace_id}.json"
    try:
        n_spans = _save_trace(data, out_path)
    except OSError as e:
        click.echo(f"Error writing {out_path}: {e}", err=True)
        ctx.exit(1)

    click.echo(f"Trace {trace_id} saved to {out_path} ({n_spans} spans)")
    click.echo(
        f"Analyze it with: python analyze_jaeger_llm_latency.py --analyze {out_path} --knob summary"
    )


# ---------------------------------------------------------------------------
# Invoke sessions (SA only) — /api/v1/audit/invokes
#
# Storage note: invoke sessions don't have their own table — they're projected
# from agent_execution_audit_logs filtered by source='invoke'. The session id
# is the synthetic correlation id ("invoke_<hex>"). Despite the underlying
# table, these are SA-only diagnostic operations, so they live under `admin`,
# not under `audit-logs` (tenant-facing).
# ---------------------------------------------------------------------------

_INVOKE_LIST_COLS = [
    ("session_id", "SESSION_ID", None),   # id — never truncate (must be copy-pasteable)
    ("agent_name", "AGENT", None),       # never truncate — full agent name must be readable
    ("execution_status", "STATUS", 10),
    ("execution_start_time", "STARTED", 25),
    ("duration_ms", "DUR_MS", 8),
    ("otel_trace_id", "TRACE_ID", None),  # id — never truncate (jump to Jaeger)
    ("correlation_id", "CORR_ID", None),  # id — never truncate
]


@admin.group(name="invokes")
def admin_invokes():
    """Invoke sessions (SA only) — agent invocations made via the invoke API.

    \b
    Examples:
      torana admin invokes list
      torana admin invokes list --limit 100 --status SUCCESS
      torana admin invokes list --agent-id <UUID> --since 2026-05-07T00:00:00Z
      torana admin invokes get <SESSION_ID>
      torana admin invokes trace-id <SESSION_ID>
    """


@admin_invokes.command(name="list")
@click.option("--limit", "limit", type=int, default=None,
              help="Maximum number of invoke sessions to return (max 1000, default 100).")
@click.option("--offset", "offset", type=int, default=0,
              help="Number of invoke sessions to skip.")
@click.option("--status", "execution_status", default=None,
              help="Filter by status: RUNNING | SUCCESS | ERROR.")
@click.option("--agent-id", "agent_id", default=None, help="Filter by agent UUID.")
@click.option("--search", "search_query", default=None,
              help="Search in user_request text.")
@click.option("--since", "start_date", default=None,
              help="ISO timestamp lower bound (e.g. 2026-05-07T00:00:00Z).")
@click.option("--until", "end_date", default=None,
              help="ISO timestamp upper bound.")
@click.pass_context
def admin_invokes_list(ctx, limit, offset, execution_status, agent_id,
                       search_query, start_date, end_date):
    """List invoke sessions with optional filters."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {"limit": limit if limit is not None else 100, "offset": offset}
    if execution_status:
        params["execution_status"] = execution_status
    if agent_id:
        params["agent_id"] = agent_id
    if search_query:
        params["search_query"] = search_query
    if start_date:
        params["start_date"] = start_date
    if end_date:
        params["end_date"] = end_date

    client = _client(ctx)
    try:
        data = client.get("audit/invokes", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields, columns=_INVOKE_LIST_COLS)


@admin_invokes.command(name="get")
@click.argument("session_id", metavar="SESSION_ID")
@click.pass_context
def admin_invokes_get(ctx, session_id):
    """Get full detail for an invoke session by its session_id (invoke_<hex>)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        # Invoke sessions store audit-log rows (source='invoke'), NOT chat messages — so we
        # query the invokes audit endpoint filtered to this session_id, not the chat-messages
        # endpoint (which 404s for invoke sessions). SA cross-tenant scoping is server-side.
        data = client.get("audit/invokes", params={"session_id": session_id, "limit": 100})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Unwrap the single session's rows for a cleaner "get" view.
    items = data.get("items", []) if isinstance(data, dict) else data
    if not items:
        click.echo(f"No invoke session found for session_id={session_id}")
        return
    output(data, fmt=fmt, fields=fields)


@admin_invokes.command(name="get-session-info")
@click.argument("session_id", metavar="SESSION_ID")
@click.option("--jaeger-url", default="http://localhost:16686",
              help="Jaeger UI base URL (for the trace deep-link).")
@click.pass_context
def admin_invokes_get_session_info(ctx, session_id, jaeger_url):
    """Print a readable summary of one invoke session — identity, execution, usage, and the
    trace deep-link — in labeled sections (nicer than the wide `get` table).

    Honors --json / --yaml for machine output; default is the human-readable view."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get("audit/invokes", params={"session_id": session_id, "limit": 1})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    items = data.get("items", []) if isinstance(data, dict) else data
    if not items:
        click.echo(f"No invoke session found for session_id={session_id}")
        ctx.exit(3)
    s = items[0]

    if fmt in ("json", "yaml"):
        output(s, fmt=fmt)
        return

    def _row(label, value):
        if value is None or value == "":
            value = "—"
        click.echo(f"  {label:<20} {value}")

    tid = s.get("otel_trace_id")
    dur = s.get("duration_ms")
    dur_s = f"{dur / 1000:.1f}s" if isinstance(dur, (int, float)) else "—"
    cost = s.get("estimated_cost_usd")
    cost_s = f"${cost:.6f}" if isinstance(cost, (int, float)) else "—"

    click.echo(f"\nInvoke Session  {s.get('session_id')}\n" + "─" * 60)
    click.echo("Identity")
    _row("Agent", s.get("agent_name"))
    _row("Agent ID", s.get("agent_id"))
    _row("Correlation ID", s.get("correlation_id"))
    _row("Model", s.get("model_name"))
    click.echo("Execution")
    _row("Status", s.get("execution_status"))
    _row("Started", s.get("execution_start_time"))
    _row("Ended", s.get("execution_end_time"))
    _row("Duration", dur_s)
    _row("Tool calls", s.get("tool_calls_count"))
    _row("LLM calls", s.get("llm_call_count"))
    click.echo("Usage")
    _row("Input tokens", s.get("input_tokens"))
    _row("Output tokens", s.get("output_tokens"))
    _row("Est. cost", cost_s)
    click.echo("Trace")
    _row("Trace ID", tid)
    _row("Jaeger", f"{jaeger_url.rstrip('/')}/trace/{tid}" if tid else "—")
    req = (s.get("user_request") or "").strip()
    resp = (s.get("agent_response") or "").strip()
    if req:
        click.echo("Request")
        click.echo("  " + (req[:500] + ("…" if len(req) > 500 else "")).replace("\n", "\n  "))
    if resp:
        click.echo("Response")
        click.echo("  " + (resp[:800] + ("…" if len(resp) > 800 else "")).replace("\n", "\n  "))
    click.echo("")


@admin_invokes.command(name="trace-id")
@click.argument("session_id", metavar="SESSION_ID")
@click.option("--service", default="pantheon-agent-builder",
              help="Jaeger service name (default: pantheon-agent-builder).")
@click.option("--jaeger-url", default="http://localhost:16686",
              help="Jaeger UI / API base URL.")
@click.pass_context
def admin_invokes_trace_id(ctx, session_id, service, jaeger_url):
    """Resolve an invoke session id to its Jaeger trace id.

    \b
    The invoke session id ("invoke_<hex>") is recorded as a span tag named
    'session_id' in Jaeger. This command queries Jaeger for the matching
    trace and prints the trace_id. Useful for chaining:

    \b
      torana advisor sweeps get <SWEEP> --include-llm-calls --json \\
          | jq -r '.llm_turn_summary[0].invoke_session_id' \\
          | xargs torana admin invokes trace-id

    Output: the trace_id on stdout, or exit code 3 if no matching trace.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    # PREFER the authoritative otel_trace_id stored on the invoke audit row. This is more
    # robust than a Jaeger tag search: it survives Jaeger retention AND session_id renames
    # (the DB row's trace_id is canonical; Jaeger span tags are immutable and can drift from
    # the row). Fall back to the Jaeger tag search only if the audit row lacks a trace_id.
    trace_id = None
    try:
        client = _client(ctx)
        audit = client.get("audit/invokes", params={"session_id": session_id, "limit": 1})
        items = audit.get("items", []) if isinstance(audit, dict) else audit
        if items:
            trace_id = items[0].get("otel_trace_id")
    except (APIError, AuthError):
        pass  # fall through to Jaeger search
    except Exception:
        pass

    if not trace_id:
        tag_query = json.dumps({"session_id": session_id})
        url = (
            f"{jaeger_url.rstrip('/')}/api/traces"
            f"?service={urllib.parse.quote(service)}"
            f"&tags={urllib.parse.quote(tag_query)}"
            f"&limit=1"
        )
        try:
            with urllib.request.urlopen(url, timeout=10) as resp:
                body = json.loads(resp.read().decode("utf-8"))
        except Exception as e:
            click.echo(f"ERROR: could not query Jaeger: {e}", err=True)
            ctx.exit(1)

        data = body.get("data", [])
        if not data:
            click.echo(
                f"ERROR: no trace found for session_id={session_id} "
                f"(no otel_trace_id on the audit row, and no Jaeger match for "
                f"service={service}). Jaeger retention may apply.",
                err=True,
            )
            ctx.exit(3)
        trace_id = data[0].get("traceID")
    if fmt == "json":
        output({"session_id": session_id, "trace_id": trace_id,
                "url": f"{jaeger_url.rstrip('/')}/trace/{trace_id}"}, fmt="json")
    else:
        click.echo(trace_id)


# ---------------------------------------------------------------------------
# build_v2 SA cross-tenant read (SA only) — mirrors the /admin/build-v2 API.
# ---------------------------------------------------------------------------

@admin.group(name="build")
def admin_build_v2():
    """Build SA cross-tenant observability (SA only).

    \b
    Examples:
      torana admin build proposals list
      torana admin build proposals list --state failed
      torana admin build proposals list --tenant-id <UUID>
      torana admin build lifecycle <PROPOSAL_ID>
    """


@admin_build_v2.command(name="catalog-coverage")
@click.option("--since", default=None, metavar="ISO_DATE",
              help="Only artifacts deposited on/after this date. Default: all time.")
@click.option("--tenant-id", "tenant_id", default=None, help="Narrow to one tenant.")
@click.pass_context
def admin_build_v2_catalog_coverage(ctx, since, tenant_id):
    """Is the reviewed SQL catalog actually being reused? (SA only)

    The catalog-gap queue (`vm transformers catalog decisions list`) records catalog
    MISSES but has no denominator, so an empty queue is ambiguous — it looks the same
    whether the catalog served every need, no build ran, or builds authored their own
    SQL and skipped the gate entirely. This supplies the denominator.

    \b
    Every transformer artifact lands in exactly one bucket:
      reused       pointed at a reviewed catalog entry instead of writing SQL
      accountable  wrote its own SQL, but recorded WHY no entry fit
      unaccounted  wrote its own SQL with no recorded reason  ← the number that matters

    \b
      TORANA_PROFILE=SA torana admin build catalog-coverage
      TORANA_PROFILE=SA torana admin build catalog-coverage --since 2026-08-04
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    params = {}
    if since:
        params["since"] = since
    if tenant_id:
        params["tenant_id"] = tenant_id
    client = _client(ctx)
    try:
        data = client.get("admin/build-v2/catalog-coverage", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, fields=fields)
        return

    total = data.get("transformer_artifacts", 0)
    reused = data.get("reused_catalog_entry", 0)
    acct = data.get("authored_accountable", 0)
    unacct = data.get("authored_unaccounted", 0)
    win = data.get("window", {}) or {}

    click.echo("Catalog reuse coverage")
    scope = f"since {since}" if since else "all time"
    if win.get("oldest_artifact"):
        scope += f"  ({win['oldest_artifact'][:10]} → {win['newest_artifact'][:10]})"
    click.echo(f"  scope : {scope}")
    click.echo(f"  gate  : {'ENFORCING' if data.get('gate_enforcing') else 'DISABLED (kill-switch on)'}")
    click.echo("")
    click.echo(f"  Transformer artifacts deposited : {total}")
    if not total:
        click.echo("")
        click.echo("  No transformer artifacts in this window — no signal either way.")
        return
    click.echo(f"    reused a catalog entry       : {reused}")
    click.echo(f"    authored their own SQL       : {total - reused}")
    click.echo(f"      with a recorded reason     : {acct}")
    click.echo(f"      WITHOUT one                : {unacct}")
    rate = data.get("reuse_rate")
    click.echo("")
    if rate is None:
        click.echo(f"  Reuse rate: not reported (n={total} is too small to be meaningful).")
    else:
        click.echo(f"  Reuse rate: {rate:.0%}")
    if unacct:
        click.echo("")
        click.echo(f"  ⚠ {unacct} artifact(s) authored SQL with no recorded reason. Either they")
        click.echo("    predate the gate, or it was bypassed/disabled when they were deposited.")
        click.echo("    Use --since to exclude the pre-gate backlog and see the ongoing rate.")


@admin_build_v2.group(name="proposals")
def admin_build_v2_proposals():
    """build_v2 proposals across ALL tenants (SA). Use `list`."""


@admin_build_v2_proposals.command(name="list")
@click.option("--state", "state", default=None,
              help="Filter by state: cooking | failed | rolled_back | deployable | deployed | ...")
@click.option("--blueprint-state", "blueprint_state", default=None,
              help="Filter by blueprint_state: authoring | ready | approved | none.")
@click.option("--tenant-id", "tenant_id", default=None, help="Narrow to one tenant (SA sees all if omitted).")
@click.option("--built-via", "built_via", default=None,
              help="Filter by the SURFACE that built it: claude_skill | platform_agent | "
                   "bundle_install | cli | ui | unknown.")
@click.option("--page", "page", type=int, default=1)
@click.option("--page-size", "page_size", type=int, default=50)
@click.pass_context
def admin_build_v2_proposals_list(ctx, state, blueprint_state, tenant_id, built_via, page, page_size):
    """List build_v2 proposals across all tenants (find stuck/failed cooks). SA only."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    params = {"page": page, "page_size": page_size}
    if state:
        params["state"] = state
    if blueprint_state:
        params["blueprint_state"] = blueprint_state
    if tenant_id:
        params["tenant_id"] = tenant_id
    if built_via:
        params["built_via"] = built_via
    client = _client(ctx)
    try:
        data = client.get("admin/build-v2/proposals", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields, columns=[
        ("id", "ID", 36), ("tenant_id", "TENANT", 36), ("title", "TITLE", 32),
        ("state", "STATE", 14), ("blueprint_state", "BLUEPRINT", 12),
        # § 3.11.5.1c/d — a row is one VERSION of an app, built by one HARNESS. Without
        # these two columns the list cannot answer either question.
        ("blueprint_version", "VER", 4), ("built_via", "BUILT VIA", 15),
    ])


@admin_build_v2.command(name="lifecycle")
@click.argument("proposal_id", metavar="PROPOSAL_ID")
@click.pass_context
def admin_build_v2_lifecycle(ctx, proposal_id):
    """Show a proposal's lifecycle chain (blueprint/cook/deploy runs) across any tenant. SA only.

    Each run carries its otel_trace_id for jumping to Jaeger."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.get(f"admin/build-v2/proposals/{proposal_id}/lifecycle")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt in ("json", "yaml"):
        output(data, fmt=fmt)
        return
    click.echo(f"\nProposal {data.get('proposal_id')}  (tenant {data.get('tenant_id')})")
    click.echo(f"  intent: {(data.get('intent_text') or '')[:100]}")
    click.echo(f"  state:  {data.get('state')}   runs: {data.get('total_runs')}\n")
    _render_lifecycle(data)


@admin.command(name="question-resolve")
@click.argument("text", metavar="TEXT")
@click.option("--top-k", "top_k", type=int, default=5, help="How many candidates to weigh.")
@click.pass_context
def admin_question_resolve(ctx, text, top_k):
    """Resolve a phrasing to its canonical corpus question.

    The same question asked five ways should reach the SAME SQL. An UNRESOLVED answer is a
    result, not an error — it is recorded as demand, and demand is what tells curators which
    question to add to the corpus next.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.post("corpus/resolve", json={"text": text, "top_k": top_k})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt in ("json", "yaml"):
        output(data, fmt=fmt)
        return

    qid = data.get("question_id")
    conf = data.get("confidence", 0)
    click.echo(f"\nASKED   {data.get('asked_text')}")
    strength = data.get("resolve_strength")
    if qid:
        # ⛔ A `weak` resolve is a CANDIDATE, not an answer. Measured 2026-08-26: a
        # worklist ask landed on EM-038 (a MONTHLY TREND question) at 35% — ABOVE two real
        # paraphrases, which scored 0.29. The lexical score has no notion of GRAIN, so the
        # bands overlap and no threshold separates them. Saying "RESOLVED" flat lets a
        # caller tag an artifact with the wrong question_id and poison the curation queue.
        if strength == "weak":
            click.echo(f"RESOLVED (WEAK)  [{qid}]  confidence {conf:.0%}  "
                       f"via {data.get('method')}")
            click.echo(f"          {data.get('question')}")
            click.echo("          ⛔ WEAK — a CANDIDATE, not an answer. CONFIRM the grain "
                       "matches before tagging anything with this id.")
        else:
            click.echo(f"RESOLVED  [{qid}]  confidence {conf:.0%}  via {data.get('method')}")
            click.echo(f"          {data.get('question')}")
    else:
        # Say what this MEANS, not just that it failed — an unresolved question is the
        # signal that the corpus is missing something.
        click.echo(f"UNRESOLVED  (best {conf:.0%}, below threshold)")
        click.echo("          Recorded as demand — this is what tells curators what to add.")
    alts = data.get("alternatives") or []
    if alts:
        click.echo("\nAMBIGUOUS — these scored within the margin; pick one deliberately:")
        for a in alts:
            click.echo(f"  {a['question_id']:10} {a['confidence']:.0%}  {a['question'][:70]}")
    near = data.get("nearest") or []
    if near and not qid:
        click.echo("\nNEAREST")
        for n in near:
            click.echo(f"  {n['question_id']:10} {n['confidence']:.0%}  {n['question'][:70]}")
    click.echo("")


@admin.command(name="verdicts")
@click.option("--verdict", default=None,
              type=click.Choice(["blocked", "empty", "stale", "live", "unknown"]),
              help="Narrow to one verdict.")
@click.option("--owner", default=None, help="Narrow to one owner (tenant | nobody | ...).")
@click.option("--tenant", "tenant_id", default=None, help="Narrow to one tenant.")
@click.pass_context
def admin_verdicts(ctx, verdict, owner, tenant_id):
    """Which tenants are BLOCKED, and on what. SA only.

    The fleet form of `torana widgets verdict`: not "why is this widget empty" but "which of
    our tenants cannot see something, and what would unblock them".
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    params = {}
    if verdict:
        params["verdict"] = verdict
    if owner:
        params["owner"] = owner
    if tenant_id:
        params["tenant_id"] = tenant_id
    client = _client(ctx)
    try:
        data = client.get("render/admin/verdicts", params=params or None)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt in ("json", "yaml"):
        output(data, fmt=fmt)
        return
    t = data.get("totals") or {}
    click.echo("\nFLEET VERDICTS")
    click.echo(f"  blocked {t.get('blocked', 0)}   empty {t.get('empty', 0)}   "
               f"stale {t.get('stale', 0)}   live {t.get('live', 0)}   "
               f"unknown {t.get('unknown', 0)}")
    cov = data.get("coverage") or {}
    if cov.get("measured") is False:
        # Say plainly that the zeros are unmeasured — an operator reading "0 blocked" as
        # good news is exactly the misdirection this line prevents.
        click.echo(f"\n  ! NOT MEASURED: {cov.get('reason')}")
    for i in data.get("items", []):
        click.echo(f"  {i}")
    click.echo("")


@admin_build_v2.command(name="versions")
@click.argument("workspace_id", metavar="WORKSPACE_ID")
@click.pass_context
def admin_build_v2_versions(ctx, workspace_id):
    """Every build_v2 VERSION of one app, newest first. SA only.

    The Build page shows one card per deployed version; this is the same series in the
    terminal, so you can pick a version and pass its id to `trace`.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.get(f"admin/build-v2/workspaces/{workspace_id}/versions")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt in ("json", "yaml"):
        output(data, fmt=fmt)
        return
    click.echo(f"\nWorkspace {data.get('workspace_id')}   "
               f"{data.get('total')} version(s), {data.get('deployed')} deployed\n")
    output({"items": data.get("items", [])}, fmt="text", columns=[
        ("id", "ID", 36), ("blueprint_version", "VER", 4), ("title", "TITLE", 34),
        ("state", "STATE", 12), ("built_via", "BUILT VIA", 15),
    ])


@admin_build_v2.command(name="build-health")
@click.option("--since", "since_days", type=int, default=7, help="Look-back window in days.")
@click.option("--built-via", "built_via", default=None, help="Narrow to one harness.")
@click.pass_context
def admin_build_v2_build_health(ctx, since_days, built_via):
    """How the build system is operating, split by HARNESS. SA only.

    The comparison is the point: both harnesses drive the same FSM through the same gates,
    so a gate that refuses one far more than the other is a defect in that consumer's
    wiring, not in the gate.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    params = {"since_days": since_days}
    if built_via:
        params["built_via"] = built_via
    client = _client(ctx)
    try:
        data = client.get("admin/build-v2/build-health", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt in ("json", "yaml"):
        output(data, fmt=fmt)
        return

    hs = data.get("harnesses") or {}
    click.echo(f"\nBUILD HEALTH   last {data.get('since_days')} days"
               f"   ({(data.get('totals') or {}).get('proposals', 0)} proposals, "
               f"{(data.get('totals') or {}).get('gate_evidence_rows', 0)} gate rows)\n")
    if not hs:
        click.echo("  No builds in this window.\n")
        return
    names = sorted(hs)
    w = max(22, max(len(n) for n in names) + 2)
    def row(label, fn):
        click.echo(f"  {label:<32}" + "".join(f"{str(fn(hs[n])):>{w}}" for n in names))
    click.echo(f"  {'':<32}" + "".join(f"{n:>{w}}" for n in names))
    click.echo("  " + "-" * (32 + w * len(names)))
    row("proposals started",        lambda h: h.get("proposals_started", 0))
    row("reached deployed",         lambda h: h.get("reached_deployed", 0))
    row("gates passed",             lambda h: h.get("gates_passed", 0))
    row("gate refusals",            lambda h: h.get("gate_refusals", 0))
    row("top refusing gate",        lambda h: h.get("top_refusing_gate") or "-")
    row("catalog reuses",           lambda h: h.get("catalog_reuses", 0))
    row("median attempts/artifact", lambda h: h.get("median_attempts_per_artifact", 0))
    row("vocab reuse warnings",     lambda h: h.get("vocab_reuse_warnings", 0))
    click.echo("")


@admin_build_v2.command(name="trace")
@click.argument("proposal_id", metavar="PROPOSAL_ID")
@click.option("--step", default=None, help="Narrow to one blueprint step_id (e.g. 1.2).")
@click.option("--gates-only", is_flag=True, default=False, help="Gates only; omit step prose.")
@click.option("--failed-only", is_flag=True, default=False, help="Only steps carrying a refusal.")
@click.pass_context
def admin_build_v2_trace(ctx, proposal_id, step, gates_only, failed_only):
    """The full build trace: intent -> blueprint -> steps -> decisions -> gates -> deploy. SA only.

    One view of what a build actually did. Where `lifecycle` shows which phases ran and
    `gate-evidence` shows the raw gate rows, this stitches them onto the blueprint so each
    STEP shows the artifact it produced and the decisions behind it.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    params = {}
    if step:
        params["step"] = step
    if gates_only:
        params["gates_only"] = "true"
    if failed_only:
        params["failed_only"] = "true"
    client = _client(ctx)
    try:
        data = client.get(f"admin/build-v2/proposals/{proposal_id}/trace", params=params or None)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt in ("json", "yaml"):
        output(data, fmt=fmt)
        return
    _render_trace(data)


def _render_trace(d):
    """Render the build trace (§ 3.11.3). Glyph + text on every state — never colour alone."""
    s = d.get("summary") or {}
    click.echo(f"\nBUILD TRACE  {d.get('title')}")
    click.echo(f"  proposal {d.get('proposal_id')}  ·  v{d.get('blueprint_version')}  ·  "
               f"{(d.get('state') or '').upper()}")
    click.echo(f"  built_via {d.get('built_via')}   tenant {d.get('tenant_id')}")
    click.echo("")
    click.echo(f"INTENT\n  {(d.get('intent_text') or '')[:160]}")

    g = d.get("grounding") or {}
    if g:
        click.echo("\nGROUNDING")
        for k, v in list(g.items())[:5]:
            click.echo(f"  {k:22} {str(v)[:96]}")

    phases = d.get("phases") or []
    if phases:
        click.echo("\nPHASES")
        for p in phases:
            click.echo(f"  [{(p.get('phase') or ''):9}] {(p.get('status') or ''):11} "
                       f"{p.get('summary') or p.get('failure_reason') or ''}")
    else:
        # An honest gap: builds that ran before the lifecycle spine landed have no phases.
        click.echo("\nPHASES\n  (none recorded — this build predates the lifecycle spine)")

    for st in d.get("steps", []):
        click.echo("")
        arts = ", ".join(a["artifact_key"] for a in st.get("artifacts", [])) or "NOT BUILT"
        click.echo(f"STEP {st.get('step_id')}  {st.get('artifact_type') or ''}  {arts}")
        if st.get("title"):
            click.echo(f"  {st['title']}")
        if st.get("policy_basis"):
            click.echo(f"  policy      {str(st['policy_basis'])[:110]}")

        dec = st.get("decisions") or {}
        if dec:
            # ⭐ § 3.11.3.1 — the six elements, IN THE ORDER THE SPEC LISTS THEM:
            #   1 corpus · 2 catalog · 3 authored(+ratio) · 4 vocabulary · 5 values ·
            #   6 reachability
            # The order is not cosmetic: it is the order the decisions were MADE, so a
            # reader follows the build's reasoning top to bottom.
            #
            # ⚠️ Every status marker is a WORD ([HIT]/[MISS]/[WARN]/[OK]), never a colour.
            # Same reason the rest of this file uses words: a colour-only cue is invisible
            # to a red/green colour-blind reader.
            click.echo("  DECISIONS")

            corpus = dec.get("corpus")
            if corpus:
                if corpus.get("resolved"):
                    click.echo(f"    corpus      [HIT] {corpus.get('question_id')}")
                else:
                    # An unresolved question is a RESULT, not a failure (§ 3.6.1). Say so —
                    # "[MISS]" alone would read as an error the operator should fix.
                    click.echo("    corpus      [UNRESOLVED] recorded as demand "
                               "(§ 3.6.1) — not a failure")

            cat = dec.get("catalog")
            if cat:
                path = (cat.get("path") or "n/a").upper()
                extra = cat.get("catalog_entry_id") or cat.get("catalog_decision_id") or ""
                click.echo(f"    catalog     [{path}] {extra}")
            au = dec.get("authored")
            if au:
                pct = f"{au['vocab_reuse_ratio']:.0%}"
                mark = "WARN" if au.get("warning") else "OK"
                click.echo(f"    authored    [{mark}] vocab reuse {pct}")
                for h in (au.get("hardcoded") or [])[:3]:
                    click.echo(f"                hardcoded: {h}")

            vocab = dec.get("vocabulary")
            if vocab and (vocab.get("keys") or vocab.get("hardcoded")):
                keys = ", ".join(vocab.get("keys") or []) or "none"
                click.echo(f"    vocabulary  [{len(vocab.get('keys') or [])} keys] {keys[:80]}")
                if vocab.get("resolved_at"):
                    click.echo(f"                bound at {vocab['resolved_at']}")

            vals = dec.get("values")
            if vals:
                mark = "WARN" if vals.get("warning") else "OK"
                n = vals.get("checked_count") or len(vals.get("checked") or [])
                click.echo(f"    values      [{mark}] {n} literal(s) grounded against "
                           f"DECLARED domains")
                for v in (vals.get("violations") or [])[:3]:
                    click.echo(f"                {str(v)[:96]}")

            reach = dec.get("reachability")
            if reach:
                mark = "OK" if reach.get("agrees") else "MISMATCH"
                click.echo(f"    reachability[{mark}] declared "
                           f"{reach.get('declared') or []} · derived "
                           f"{reach.get('derived') or []}")

        gates = st.get("gates") or []
        if gates:
            click.echo("  GATES")
            for gt in gates:
                # Three outcomes, not two. `else -> REFUSED` printed a refusal for an
                # ADVISORY finding (outcome `noted`), which is the exact false signal the
                # NOTED outcome was added to remove -- and it also hid that finding's
                # reason, since the reason line tested `== "refused"`.
                mark = {"passed": "PASS   ", "refused": "REFUSED",
                        "noted": "NOTED  "}.get(gt["outcome"], gt["outcome"][:7].upper())
                att = f"  attempt {gt['attempt']}" if (gt.get("attempt") or 1) > 1 else ""
                click.echo(f"    [{mark}] {gt['gate_name']}{att}")
                if gt["outcome"] in ("refused", "noted") and gt.get("reason"):
                    click.echo(f"             {str(gt['reason']).strip().splitlines()[0][:104]}")
        else:
            click.echo("  GATES       (none recorded — predates gate evidence)")

    if d.get("orphan_artifacts"):
        click.echo(f"\nARTIFACTS WITH NO BLUEPRINT STEP: {', '.join(d['orphan_artifacts'])}")

    click.echo("")
    click.echo(f"SUMMARY  steps {s.get('steps_shown')}/{s.get('steps_total')} · "
               f"artifacts {s.get('artifacts')} · gates {s.get('gates_passed')} PASS "
               f"{s.get('gates_refused')} REFUSED · catalog reuses {s.get('catalog_reuses')} · "
               f"max attempt {s.get('max_attempt')}")
    if s.get("vocab_reuse_warnings"):
        # ⚠️ WORDING IS THE PRODUCT HERE. "hardcoded a policy value" reads as a DEFECT, and
        # a literal is often the CORRECT call — a user asking for Critical-only must not have
        # `severity_floor` (at-or-above, = Medium on most tenants) substituted for it. So this
        # says what was OBSERVED and points at where the reasoning lives, rather than
        # convicting a decision the author may have made deliberately and documented.
        click.echo(f"  ! {s['vocab_reuse_warnings']} artifact(s) used a literal where a "
                   f"{{{{vocab:...}}}} key exists — check each step's DECISIONS for whether "
                   f"that was deliberate")
    click.echo("")


@admin_build_v2.command(name="gate-evidence")
@click.argument("proposal_id", metavar="PROPOSAL_ID")
@click.option("--gate", default=None, help="Narrow to one gate_name.")
@click.option("--outcome", default=None, type=click.Choice(["passed", "refused"]),
              help="Show only passes or only refusals.")
@click.option("--failed-only", is_flag=True, default=False,
              help="Shorthand for --outcome refused.")
@click.pass_context
def admin_build_v2_gate_evidence(ctx, proposal_id, gate, outcome, failed_only):
    """Show every GATE this proposal's artifacts were evaluated by. SA only.

    `lifecycle` answers "which phases ran". This answers "which decisions were made, and why
    did it stop" — the grain that was missing. A retry loop shows as repeated rows with a
    rising attempt number, which is exactly the signature that was invisible before.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    params = {}
    if gate:
        params["gate"] = gate
    eff_outcome = "refused" if failed_only else outcome
    if eff_outcome:
        params["outcome"] = eff_outcome
    try:
        data = client.get(f"admin/build-v2/proposals/{proposal_id}/gate-evidence",
                          params=params or None)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt in ("json", "yaml"):
        output(data, fmt=fmt)
        return
    _render_gate_evidence(data)


def _render_gate_evidence(data):
    """Render the gate-evidence trace, grouped by artifact (§ 3.11.3)."""
    s = data.get("summary") or {}
    click.echo(f"\nProposal {data.get('proposal_id')}  (tenant {data.get('tenant_id')})")
    click.echo(f"  built_via: {data.get('built_via')}    state: {data.get('state')}")
    click.echo(f"  gates: {s.get('passed', 0)} PASS  {s.get('refused', 0)} REFUSED   "
               f"artifacts: {s.get('artifacts_evaluated', 0)}   max attempt: {s.get('max_attempt', 0)}")
    if s.get("top_refusing_gate"):
        click.echo(f"  top refusing gate: {s['top_refusing_gate']}")
    if s.get("vocab_reuse_warnings"):
        # A warning, never a refusal (§ 3.11.3.1) — some relations are legitimately policy-free.
        click.echo(f"  ! {s['vocab_reuse_warnings']} artifact(s) used a literal where a "
                   f"{{{{vocab:...}}}} key exists — deliberate or not, the DECISIONS block says which")
    click.echo("")

    by_artifact = {}
    for i in data.get("items", []):
        by_artifact.setdefault(i.get("artifact_key") or "(proposal-level)", []).append(i)

    for key, rows in by_artifact.items():
        click.echo(f"  {key}")
        for r in rows:
            mark = "PASS   " if r.get("outcome") == "passed" else "REFUSED"
            ratio = r.get("vocab_reuse_ratio")
            ratio_s = "" if ratio is None else f"  vocab_reuse={ratio:.0%}"
            att = f"  attempt {r.get('attempt')}" if (r.get("attempt") or 1) > 1 else ""
            click.echo(f"    [{mark}] {r.get('gate_name'):<32}{att}{ratio_s}")
            if r.get("outcome") == "refused" and r.get("reason"):
                first = str(r["reason"]).strip().splitlines()[0]
                click.echo(f"             {first[:110]}")
        click.echo("")


def _render_lifecycle(data):
    """Shared lifecycle-chain renderer (used by flat `lifecycle` + `proposal <id> lifecycle`)."""
    click.echo(f"\nProposal {data.get('proposal_id')}  (tenant {data.get('tenant_id')})")
    click.echo(f"  intent: {(data.get('intent_text') or '')[:100]}")
    click.echo(f"  state:  {data.get('state')}   runs: {data.get('total_runs')}\n")
    for r in data.get("runs", []):
        dur = r.get("duration_seconds")
        dur_s = f"{dur:.1f}s" if isinstance(dur, (int, float)) else "—"
        click.echo(f"  [{r.get('phase'):9}] {r.get('status'):10} {dur_s:>8}  "
                   f"trace={r.get('otel_trace_id') or '—'}  {r.get('summary') or r.get('failure_reason') or ''}")
    click.echo("")


# ── singular instance group: `admin build-v2 proposal <ID> ...` (SA, per CLI pattern) ──

@admin_build_v2.group(name="proposal", invoke_without_command=True)
@click.argument("proposal_id", metavar="PROPOSAL_ID")
@click.pass_context
def admin_build_v2_proposal(ctx, proposal_id):
    """Operate on ONE build_v2 proposal (any tenant, SA). Bare form shows help.

    \b
      torana admin build proposal <ID> show
      torana admin build proposal <ID> lifecycle
      torana admin build proposal <ID> provenance
      torana admin build proposal <ID> deploy-status
    """
    ctx.ensure_object(dict)
    ctx.obj["_bv2_proposal_id"] = proposal_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _bv2_pid(ctx) -> str:
    return ctx.obj.get("_bv2_proposal_id", "") if ctx.obj else ""


@admin_build_v2_proposal.command(name="show")
@click.pass_context
def admin_build_v2_proposal_show(ctx):
    """Full detail: proposal (incl. cook_state), blueprint, artifacts. SA, any tenant."""
    pid = _bv2_pid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.get(f"admin/build-v2/proposals/{pid}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt in ("json", "yaml"):
        output(data, fmt=fmt)
        return
    p = data.get("proposal", {})
    click.echo(f"\nProposal {p.get('id')}  (tenant {p.get('tenant_id')})")
    click.echo(f"  title:   {p.get('title')}")
    click.echo(f"  state:   {p.get('state')}   blueprint: {p.get('blueprint_state')}")
    if p.get("failure_reason"):
        click.echo(f"  failure: {p.get('failure_reason')}")
    cs = p.get("cook_state") or {}
    if cs:
        done = sum(1 for s in cs.get("steps", []) if s.get("validated"))
        click.echo(f"  cook:    {done}/{cs.get('total_steps')} validated  "
                   f"(iters {cs.get('iters_spent')}/{cs.get('budget_steps')}, "
                   f"current={cs.get('current_step')})")
    click.echo(f"  artifacts: {len(data.get('artifacts', []))}   "
               f"blueprint: {'present' if data.get('blueprint') else 'none'}\n")


@admin_build_v2_proposal.command(name="lifecycle")
@click.pass_context
def admin_build_v2_proposal_lifecycle(ctx):
    """Lifecycle chain (blueprint/cook/deploy runs) with otel_trace_ids. SA, any tenant."""
    pid = _bv2_pid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.get(f"admin/build-v2/proposals/{pid}/lifecycle")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt in ("json", "yaml"):
        output(data, fmt=fmt)
        return
    _render_lifecycle(data)


@admin_build_v2_proposal.command(name="provenance")
@click.pass_context
def admin_build_v2_proposal_provenance(ctx):
    """Provenance chain: intent → blueprint step → artifacts (+ unattributed). SA, any tenant."""
    pid = _bv2_pid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.get(f"admin/build-v2/proposals/{pid}/provenance")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt in ("json", "yaml"):
        output(data, fmt=fmt)
        return
    click.echo(f"\nProvenance {data.get('proposal_id')}  (blueprint {data.get('blueprint_state')})")
    click.echo(f"  intent: {(data.get('intent_text') or '')[:100]}\n")
    for s in data.get("steps", []):
        arts = s.get("artifacts", [])
        click.echo(f"  step {s.get('step_id')} [{s.get('artifact_type')}] {s.get('title') or ''}")
        for a in arts:
            click.echo(f"     └─ {a.get('artifact_key')} ({a.get('state')})")
    un = data.get("unattributed_artifacts", [])
    if un:
        click.echo(f"  ⚠ unattributed artifacts: {len(un)}")
    click.echo("")


@admin_build_v2_proposal.command(name="deploy-status")
@click.pass_context
def admin_build_v2_proposal_deploy_status(ctx):
    """Deploy ledger: per-artifact deploy state + deployed_artifact_id. SA, any tenant."""
    pid = _bv2_pid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.get(f"admin/build-v2/proposals/{pid}/deploy-status")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt in ("json", "yaml"):
        output(data, fmt=fmt)
        return
    p = data.get("proposal", {})
    click.echo(f"\nDeploy status {p.get('id')}  state={p.get('state')}  "
               f"manifest={p.get('manifest_hash') or '—'}\n")
    for a in data.get("artifacts", []):
        click.echo(f"  {a.get('artifact_key'):28} {a.get('state'):10} "
                   f"deployed_id={a.get('deployed_artifact_id') or '—'}")
    click.echo("")


# ---------------------------------------------------------------------------
# App Bundles SA cross-tenant visibility (SA only) — /admin/build-v2/bundles.
# The catalog of installable chained-proposal app packs: intent, blueprints,
# artifacts, the ordered links AS stages, and the vocabulary variables each
# artifact uses (where + how). Mirrors the SA "App Bundles" FE page.
# ---------------------------------------------------------------------------

@admin_build_v2.group(name="app-bundles")
def admin_app_bundles():
    """App bundles across ALL tenants (SA). Use `list` / `show <id>`.

    \b
    Examples:
      torana admin build app-bundles list
      torana admin build app-bundles list --type vulnerability_management_v2
      torana admin build app-bundles show ciso_posture
    """


@admin_app_bundles.command(name="list")
@click.option("--tenant-id", "tenant_id", default=None, help="Narrow to one tenant (SA sees all if omitted).")
@click.option("--type", "workspace_type", default=None, help="Filter by workspace type.")
@click.option("--no-system", "no_system", is_flag=True, help="Exclude code-defined system bundles.")
@click.pass_context
def admin_app_bundles_list(ctx, tenant_id, workspace_type, no_system):
    """List app bundles across all tenants (system + tenant-captured). SA only."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    params = {"include_system": (not no_system)}
    if tenant_id:
        params["tenant_id"] = tenant_id
    if workspace_type:
        params["workspace_type"] = workspace_type
    client = _client(ctx)
    try:
        data = client.get("admin/build-v2/bundles", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt != "text":
        output(data, fmt=fmt, fields=fields)
        return
    rows = []
    for b in data.get("items", []):
        rows.append({
            "id": b.get("id"),
            "name": b.get("name"),
            "type": b.get("workspace_type"),
            "system": "yes" if b.get("is_system") else "",
            "tenant": (b.get("tenant_id") or "—")[:12] if b.get("tenant_id") else "—",
            "links": b.get("link_count", 0),
            "ver": b.get("version"),
        })
    output({"items": rows, "total": data.get("total", len(rows))}, fmt="text", columns=[
        ("id", "ID", 24), ("name", "NAME", 28), ("type", "TYPE", 26),
        ("system", "SYS", 4), ("tenant", "TENANT", 12), ("links", "LINKS", 5), ("ver", "VER", 4)])


@admin_app_bundles.command(name="show")
@click.argument("bundle_id", metavar="BUNDLE_ID")
@click.option("--tenant-id", "tenant_id", default=None, help="Owning tenant (for a tenant-captured bundle).")
@click.option("--version", "version", type=int, default=None, help="Specific version (latest if omitted).")
@click.pass_context
def admin_app_bundles_show(ctx, bundle_id, tenant_id, version):
    """Full app-bundle detail: intent, stages, blueprints, artifacts, and the vocabulary
    variables each artifact uses (where + how). SA only.

    Use --format json for the complete document (all artifact definitions / SQL)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    params = {}
    if tenant_id:
        params["tenant_id"] = tenant_id
    if version is not None:
        params["version"] = version
    client = _client(ctx)
    try:
        data = client.get(f"admin/build-v2/bundles/{bundle_id}", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt in ("json", "yaml"):
        output(data, fmt=fmt)
        return

    # Header + intent.
    sysflag = "system" if data.get("is_system") else f"tenant {data.get('tenant_id') or '?'}"
    click.echo(f"\n{data.get('name')}  ·  {data.get('workspace_type')}  ·  "
               f"{sysflag}  ·  v{data.get('version')}")
    if data.get("description"):
        click.echo(f"  {data['description']}")
    click.echo("")

    # Vocab usages grouped by (link, artifact) so we can print variables under each artifact.
    usages = data.get("vocab_usages", [])
    defs = data.get("vocab_definitions", {})
    by_art = {}
    for u in usages:
        by_art.setdefault((u.get("link_id"), u.get("artifact_key")), []).append(u)

    doc = data.get("document", {})
    links_by_id = {ln.get("link_id"): ln for ln in (doc.get("links") or [])}

    # Stages (the ordered links).
    click.echo(f"STAGES ({len(data.get('stages', []))})")
    for st in data.get("stages", []):
        dep = (" reads " + ", ".join(st["depends_on"])) if st.get("depends_on") else " (foundation)"
        pol = "  +policy" if st.get("has_policy") else ""
        click.echo(f"  [{st.get('order')}] {st.get('title')}{dep}{pol}")
        click.echo(f"      intent: {(st.get('intent_text') or '')[:100]}")
        # Artifacts of this stage + the variables each uses.
        ln = links_by_id.get(st.get("link_id"), {})
        for art in (ln.get("artifacts") or []):
            ak = art.get("artifact_key")
            vs = by_art.get((st.get("link_id"), ak), [])
            click.echo(f"      • {ak}  ({art.get('artifact_type')})")
            for u in vs:
                crit = " ⚠crit" if defs.get(u["key"], {}).get("security_critical") else ""
                fld = (u.get("field_path") or "").replace("definition.", "")
                click.echo(f"          {u['key']}  [{fld} · {u.get('render') or 'scalar'}]{crit}")
    click.echo("")

    # Vocabulary variables (the reverse index) + definitions.
    click.echo(f"VOCABULARY VARIABLES ({len(data.get('vocab_keys', []))} keys · {len(usages)} usages)")
    for key in data.get("vocab_keys", []):
        d = defs.get(key, {})
        crit = " ⚠security-critical" if d.get("security_critical") else ""
        n = sum(1 for u in usages if u["key"] == key)
        click.echo(f"  {key}  ({d.get('shape') or '?'} · default "
                   f"{json.dumps(d.get('conservative_default'))}){crit}")
        if d.get("meaning"):
            click.echo(f"      {d['meaning']}")
        click.echo(f"      used in {n} place(s)")
    click.echo("")


# ---------------------------------------------------------------------------
# A2A diagnostics (SA / dev soak tooling) — Track-2 reload validation.
#
# These are OUR soak/debug tools, NOT customer features — they validate the
# `CHAT_RELOAD_FROM_ENVELOPE` cutover. They live under `admin` so a future
# "customer build" (non-admin commands only) drops them for free.
#
# `admin a2a` (diagnostic surface) deliberately shares the `a2a` name with
# `agent <id> a2a` (the protocol surface) under a different parent. See
# pantheon-cli/docs/AGUI_AGENTS_REFACTOR.md.
# ---------------------------------------------------------------------------

@admin.group(name="a2a")
def admin_a2a():
    """A2A reload diagnostics (SA / dev soak tooling).

    \b
    Examples:
      torana admin a2a envelope <AGENT_ID> <SESSION_ID>
      torana admin a2a compare-reload <AGENT_ID> <SESSION_ID>
      torana admin a2a compare-reload <AGENT_ID> <SESSION_ID> --show-diff
    """


@admin_a2a.command(name="envelope")
@click.argument("agent_id", metavar="AGENT_ID")
@click.argument("session_id", metavar="SESSION_ID")
@click.option("--no-snapshot", is_flag=True, default=False,
              help="Do not include the envelope-built MessagesSnapshot.")
@click.pass_context
def admin_a2a_envelope(ctx, agent_id, session_id, no_snapshot):
    """Inspect the a2a_tasks commitment envelope for a session (Track 2).

    Shows each per-turn task: state, the lossy A2A projection (message/artifacts),
    and the full-fidelity ui_messages used for byte-identical chat reload. By
    default also returns the MessagesSnapshot rebuilt FROM the envelope.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    params = {"include_snapshot": "false"} if no_snapshot else None
    try:
        data = client.get(
            f"agents/{agent_id}/sessions/{session_id}/a2a/envelope", params=params
        )
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # For text/table, render a per-task summary; json/yaml print the full body.
    if fmt in ("json", "yaml") or raw:
        output(data, fmt=fmt, raw=raw, fields=fields)
        return
    tasks = data.get("tasks", [])
    rows = [
        {
            "task_id": t.get("task_id"),
            "state": t.get("state"),
            "ui_messages": len(t.get("ui_messages") or []),
            "artifacts": len(t.get("artifacts") or []),
            "turn_id": t.get("turn_id"),
        }
        for t in tasks
    ]
    click.echo(f"session {session_id}: {data.get('task_count', 0)} task(s)")
    output(
        {"items": rows, "total": len(rows)},
        fmt="text",
        columns=[
            ("task_id", "TASK ID", 30),
            ("state", "STATE", 16),
            ("ui_messages", "UI MSGS", 8),
            ("artifacts", "ARTIFACTS", 10),
            ("turn_id", "TURN ID", 40),
        ],
    )


@admin_a2a.command(name="compare-reload")
@click.argument("agent_id", metavar="AGENT_ID")
@click.argument("session_id", metavar="SESSION_ID")
@click.option("--show-diff", "show_diff", is_flag=True, default=False,
              help="Print a unified diff when the two snapshots differ.")
@click.pass_context
def admin_a2a_compare_reload(ctx, agent_id, session_id, show_diff):
    """Compare the LIVE-FOLD reload vs the ENVELOPE reload for a session.

    \b
    Fetches two reconstructions of the same conversation:
      • live  — GET /agui/snapshot (folds agent_formatted_responses live)
      • env   — the snapshot rebuilt from a2a_tasks.ui_messages (the envelope)
    and reports whether they are BYTE-IDENTICAL — the Track-2 (Option A) reload
    contract. This is the soak tool: a mismatch means the envelope would NOT
    reproduce the live reload, so the cutover (CHAT_RELOAD_FROM_ENVELOPE) is unsafe.
    Exits 1 on mismatch.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)

    try:
        live = client.get(f"agents/{agent_id}/sessions/{session_id}/agui/snapshot")
        env = client.get(f"agents/{agent_id}/sessions/{session_id}/a2a/envelope")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    live_messages = live.get("messages", [])
    env_snapshot = env.get("envelope_snapshot", {})
    env_messages = env_snapshot.get("messages", [])

    live_json = json.dumps(live_messages, sort_keys=True)
    env_json = json.dumps(env_messages, sort_keys=True)
    identical = live_json == env_json

    result = {
        "session_id": session_id,
        "agent_id": agent_id,
        "byte_identical": identical,
        "live_message_count": len(live_messages),
        "envelope_message_count": len(env_messages),
        "envelope_task_count": env.get("task_count", 0),
    }

    if fmt in ("json", "yaml"):
        output(result, fmt=fmt)
    else:
        status = click.style("BYTE-IDENTICAL ✓", fg="green") if identical \
            else click.style("MISMATCH ✗", fg="red")
        click.echo(f"compare-reload  session={session_id}")
        click.echo(f"  live (fold)   messages: {result['live_message_count']}")
        click.echo(f"  envelope      messages: {result['envelope_message_count']}  "
                   f"(tasks: {result['envelope_task_count']})")
        click.echo(f"  result: {status}")

    if not identical and show_diff:
        import difflib
        live_pretty = json.dumps(live_messages, indent=2, sort_keys=True).splitlines()
        env_pretty = json.dumps(env_messages, indent=2, sort_keys=True).splitlines()
        click.echo("\n--- diff (live → envelope) ---")
        for line in difflib.unified_diff(live_pretty, env_pretty, "live", "envelope", lineterm=""):
            color = "green" if line.startswith("+") else "red" if line.startswith("-") else None
            click.echo(click.style(line, fg=color) if color else line)

    if not identical:
        raise SystemExit(1)


# ---------------------------------------------------------------------------
# AG-UI / A2UI catalog diagnostics (SA / dev). The customer-facing catalog READ
# lives at `torana agent <id> catalog`; this is the version/drift diagnostic.
# ---------------------------------------------------------------------------

@admin.group(name="agui")
def admin_agui():
    """AG-UI / A2UI catalog diagnostics (SA / dev).

    \b
    Examples:
      torana admin agui catalog
      torana admin agui catalog --version-check
    """


@admin_agui.command(name="catalog")
@click.option("--version-check", "version_check", is_flag=True, default=False,
              help="Print just the catalog specVersion (for drift checks).")
@click.pass_context
def admin_agui_catalog(ctx, version_check):
    """Show the A2UI catalog manifest, or just its specVersion for drift checks."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("agui/catalog")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if version_check:
        spec = data.get("specVersion") if isinstance(data, dict) else None
        if fmt in ("json", "yaml"):
            output({"specVersion": spec, "version": data.get("version")}, fmt=fmt)
        else:
            click.echo(spec or "<no specVersion in manifest>")
        return

    output(
        data,
        fmt=fmt,
        raw=raw,
        fields=fields,
        columns=[
            ("version", "CATALOG VERSION", 16),
            ("catalogId", "CATALOG ID", 50),
            ("specVersion", "A2UI SPEC", 12),
        ],
    )


# ---------------------------------------------------------------------------
# ETL admin (SA only, cross-tenant) — /api/v1/admin/etl/*
#
# Same SA endpoints the FE run-detail page uses. `run <RUN_ID>` is the admin
# equivalent of /administration/data-pipeline/runs/<run_id> and surfaces trace_id (the
# Jaeger deep-link source) alongside operator metrics, drift, and DLQ entries.
# ---------------------------------------------------------------------------

_ETL_RUN_LIST_COLS = [
    ("run_id", "RUN ID", 36),
    ("data_source", "DATA SOURCE", 16),
    ("status", "STATUS", 10),
    ("records_in", "EXTRACTED", 10),
    ("records_out", "LOADED", 8),
    ("dlq_count", "DLQ", 6),
    ("started_at", "STARTED", 24),
    ("trace_id", "TRACE ID", 32),
]


@admin.group(name="etl")
def admin_etl():
    """ETL admin operations (SA only, cross-tenant) — /api/v1/admin/etl/*.

    \b
    Examples:
      torana admin etl runs
      torana admin etl run <RUN_ID>
      torana admin etl stats
    """


@admin_etl.command(name="runs")
@click.option("--limit", "limit", type=int, default=20, show_default=True,
              help="Number of runs to return.")
@click.option("--offset", "offset", type=int, default=0, show_default=True,
              help="Offset for pagination.")
@click.option("--status", "status", default=None,
              help="Filter by status: success | failed | partial | running | skipped | cancelled.")
@click.option("--integration-id", "integration_id", default=None,
              help="Filter by integration UUID.")
@click.pass_context
def admin_etl_runs(ctx, limit, offset, status, integration_id):
    """SA: list ETL runs across all tenants."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {"limit": limit, "offset": offset}
    if status:
        params["status"] = status
    if integration_id:
        params["integration_id"] = integration_id

    client = _client(ctx)
    try:
        data = client.get("admin/etl/runs", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields, columns=_ETL_RUN_LIST_COLS)


@admin_etl.command(name="run")
@click.argument("run_id", metavar="RUN_ID")
@click.pass_context
def admin_etl_run(ctx, run_id):
    """SA: run detail (trace_id, operator metrics, drift, DLQ entries).

    \b
    The admin equivalent of the FE run-detail page
    (/administration/data-pipeline/runs/<RUN_ID>). The 'trace_id' field is the Jaeger
    deep-link source shown on that page's Distributed Trace card.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"admin/etl/runs/{run_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@admin_etl.command(name="stats")
@click.pass_context
def admin_etl_stats(ctx):
    """SA: aggregate ETL run stats across all tenants."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("admin/etl/stats")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ---------------------------------------------------------------------------
# torana admin agents  (collection)  /  torana admin agent <id>  (instance)
# SA-focused agent introspection: health (incl. prompt substitution status)
# and the stored vs rendered system prompt.
# ---------------------------------------------------------------------------

_AGENT_HEALTH_COLS = [
    ("agent_name", "AGENT", 40),
    ("agent_type", "TYPE", 8),
    ("health_status", "HEALTH", 9),
    ("health_score", "SCORE", 6),
    ("missing_tools", "MISSING", 8),
    ("substitution_failed", "SUB_FAIL", 9),
    ("is_active", "ACTIVE", 7),
]

_AGENT_LIST_COLS = [
    ("agent_id", "ID", 36),
    ("agent_name", "NAME", 40),
    ("agent_type", "TYPE", 8),
    ("health_status", "HEALTH", 9),
    ("substitution_failed", "SUB_FAIL", 9),
    ("is_active", "ACTIVE", 7),
]


@admin.group(name="agents")
def admin_agents():
    """Agent introspection (SA) — health + substitution status.

    \b
    Examples:
      torana admin agents health-summary
      torana admin agents health-summary --health-status error
      torana admin agents list
    """


@admin_agents.command(name="health-summary")
@click.option("--health-status", "health_status", default=None,
              help="Filter: healthy | degraded | error | unknown.")
@click.option("--agent-type", "agent_type", default=None, help="Filter by agent type.")
@click.option("--sort-by", "sort_by", default=None, help="Sort field (e.g. health_score).")
@click.option("--show-test", "show_test", is_flag=True, default=False,
              help="Include test agents (test-agent:true).")
@click.pass_context
def admin_agents_health_summary(ctx, health_status, agent_type, sort_by, show_test):
    """Health summary for all agents, including prompt-substitution health."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    params = {"show_test": show_test}
    if health_status is not None:
        params["health_status"] = health_status
    if agent_type is not None:
        params["agent_type"] = agent_type
    if sort_by is not None:
        params["sort_by"] = sort_by
    client = _client(ctx)
    try:
        data = client.get("agents/health-summary", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    # health-summary returns {agents: [...], counts...}; normalize to the
    # {items, total} envelope output() renders as a table.
    if isinstance(data, dict) and "agents" in data:
        data = {"items": data["agents"], "total": data.get("total_agents", len(data["agents"]))}
    output(data, fmt=fmt, raw=raw, fields=fields, columns=_AGENT_HEALTH_COLS)


@admin_agents.command(name="list")
@click.option("--state", default=None, help="Filter by state (draft|published).")
@click.option("--search", default=None, help="Search by name/description.")
@click.pass_context
def admin_agents_list(ctx, state, search):
    """List agents (collection)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    effective_page_size = min(settings.page_size, 100)
    params = {"skip": 0, "limit": effective_page_size}
    if state is not None:
        params["state"] = state
    if search is not None:
        params["search"] = search
    # Source from health-summary so the list carries health + substitution status
    # (the plain agents/ list has neither). show_test=True to include test agents.
    params["show_test"] = True
    client = _client(ctx)
    try:
        data = client.get("agents/health-summary", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    items = data.get("agents", []) if isinstance(data, dict) else (data or [])
    # Client-side filters (health-summary doesn't take state/search)
    if state is not None:
        items = [a for a in items if str(a.get("state", "")).lower() == state.lower()
                 or (state == "published") == bool(a.get("is_published"))]
    if search is not None:
        s = search.lower()
        items = [a for a in items if s in str(a.get("agent_name", "")).lower()]
    data = {"items": items, "total": len(items)}
    output(data, fmt=fmt, raw=raw, fields=fields, columns=_AGENT_LIST_COLS)


@admin.group(name="agent", invoke_without_command=True)
@click.argument("agent_id", metavar="AGENT_ID")
@click.pass_context
def admin_agent(ctx, agent_id):
    """Per-agent instance commands (SA).

    \b
    Examples:
      torana admin agent <AGENT_ID> get
      torana admin agent <AGENT_ID> health
      torana admin agent <AGENT_ID> prompt
      torana admin agent <AGENT_ID> prompt --rendered
      torana admin agent <AGENT_ID> tools
      torana admin agent <AGENT_ID> tools --configured
      torana admin agent <AGENT_ID> resync
      torana admin agent <AGENT_ID> resync --dry-run
    """
    ctx.ensure_object(dict)
    ctx.obj["_admin_agent_id"] = agent_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _aaid(ctx) -> str:
    return ctx.obj.get("_admin_agent_id", "") if ctx.obj else ""


@admin_agent.command(name="get")
@click.pass_context
def admin_agent_get(ctx):
    """Get an agent by id."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get(f"agents/{_aaid(ctx)}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@admin_agent.command(name="health")
@click.pass_context
def admin_agent_health(ctx):
    """Detailed health for a single agent (tools + substitution)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get(f"agents/{_aaid(ctx)}/health")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@admin_agent.command(name="prompt")
@click.option("--rendered", is_flag=True, default=False,
              help="Show the fully-rendered prompt (runtime substitutions applied) "
                   "instead of the stored template (markers visible).")
@click.pass_context
def admin_agent_prompt(ctx, rendered):
    """Show the agent's system prompt.

    Default: the STORED template from the DB with substitution markers
    (e.g. {datalake-schema}) visible. --rendered: the prompt as it would be
    sent to the LLM, with schema_injected indicating whether the runtime
    substitution actually resolved.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    path = (
        f"agents/{_aaid(ctx)}/rendered-prompt" if rendered
        else f"agents/{_aaid(ctx)}/resolved-prompt"
    )
    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


_AGENT_EFFECTIVE_TOOL_COLS = [
    ("source", "SOURCE", 14),
    ("name", "NAME", 34),
    ("hitl", "HITL", 5),
    ("tool_reference", "REFERENCE", 44),
    ("description", "DESCRIPTION", 60),
]

_AGENT_CONFIGURED_TOOL_COLS = [
    ("tool_type", "TYPE", 12),
    ("name", "NAME", 34),
    ("tool_reference", "REFERENCE", 44),
]


@admin_agent.command(name="tools")
@click.option("--configured", is_flag=True, default=False,
              help="Show the CONFIGURED tool rows (agent_tools) instead of the "
                   "effective list the LLM receives.")
@click.option("--source", "source_filter", default=None,
              help="Filter the effective list by source "
                   "(integration, agent, function, plan, ag_ui_widget, skill).")
@click.pass_context
def admin_agent_tools(ctx, configured, source_filter):
    """Show the tools attached to an agent.

    \b
    Default: the EFFECTIVE list — the function declarations the LLM actually
    receives each turn, from the built ADK agent. This is the tool-side
    counterpart to `prompt --rendered`.
    --configured: the stored agent_tools rows instead.

    The two counts legitimately differ: one configured API row expands into
    every callable operation, and AG-UI widget / plan / skill tools are
    injected at build time with no stored row at all. When an agent did not
    call a tool you expected, the effective list is the one that explains it.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)

    if configured:
        try:
            rows = client.get(f"agents/{_aaid(ctx)}/tools")
        except APIError as e:
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return
        items = list(rows or [])
        output({"items": items, "total": len(items)},
               fmt=fmt, raw=raw, fields=fields,
               columns=_AGENT_CONFIGURED_TOOL_COLS)
        return

    try:
        data = client.get(f"agents/{_aaid(ctx)}/effective-tools")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # A build failure is reported as an error, never as an empty list — "could
    # not determine the tools" and "has no tools" are different answers.
    err = (data or {}).get("error")
    if err:
        click.echo(f"Could not determine the effective tool list: {err}", err=True)
        raise SystemExit(1)

    items = list((data or {}).get("tools") or [])
    if source_filter:
        items = [t for t in items if str(t.get("source", "")) == source_filter]

    # Flatten booleans into grep-friendly text for the column view.
    for t in items:
        t["hitl"] = "HITL" if t.get("is_long_running") else ""
        if t.get("tool_reference") is None:
            t["tool_reference"] = "-"

    payload = {
        "agent_id": (data or {}).get("agent_id"),
        "agent_name": (data or {}).get("agent_name"),
        "counts_by_source": (data or {}).get("counts_by_source", {}),
        "items": items,
        "total": len(items),
    }
    output(payload, fmt=fmt, raw=raw, fields=fields,
           columns=_AGENT_EFFECTIVE_TOOL_COLS)


def _resync_tool_refs(client, agent_id):
    """The agent's live agent_tools rows as a {tool_reference} set.

    Returns None when the rows cannot be read — distinct from an empty set,
    so a failed probe is never reported as "the agent has no tools".
    """
    try:
        rows = client.get(f"agents/{agent_id}/tools")
    except (APIError, AuthError):
        return None
    return {str(r.get("tool_reference")) for r in (rows or [])}


@admin_agent.command(name="resync")
@click.option("--dry-run", is_flag=True, default=False,
              help="Preview only — report what WOULD change and write nothing.")
@click.option("--remove-stale", is_flag=True, default=False,
              help="Also drop tool rows whose underlying API/agent no longer "
                   "resolves. Off by default: a transient Workflow-Framework "
                   "outage makes every tool look stale.")
@click.option("--reconcile-only", is_flag=True, default=False,
              help="Skip step 1 — do not re-read the source JSON. Binds only "
                   "what the stored declaration already names.")
@click.pass_context
def admin_agent_resync(ctx, dry_run, remove_stale, reconcile_only):
    """Re-sync an agent from its source JSON — declaration AND tool bindings.

    \b
    Two stores have to move for a tool change to take effect, and they are
    updated by different endpoints:
      step 1  reload-from-source   agents/<name>.json  ->  source_config
      step 2  reconcile            source_config       ->  agent_tools

    Step 1 alone is NOT enough for an API tool. reload-from-source syncs
    custom_tools and prunes dropped rows, but never binds a newly declared
    `apis` entry — so the declaration gains the API, agent_tools does not,
    and the agent cannot call it. The endpoint reports success either way.

    This command runs both and prints the agent_tools count before and
    after, because that count is the only evidence the binding landed.

    \b
    Examples:
      torana admin agent <AGENT_ID> resync
      torana admin agent <AGENT_ID> resync --dry-run
      torana admin agent <AGENT_ID> resync --remove-stale
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    agent_id = _aaid(ctx)
    client = _client(ctx)

    before = _resync_tool_refs(client, agent_id)
    steps = []

    # Step 1 — declaration. Skipped under --dry-run because reload-from-source
    # has no preview mode: it writes source_config unconditionally, so running
    # it here would make a "preview" mutate the thing being previewed.
    if reconcile_only:
        steps.append({"step": "reload-from-source", "status": "skipped",
                      "detail": "--reconcile-only"})
    elif dry_run:
        steps.append({"step": "reload-from-source", "status": "skipped",
                      "detail": "--dry-run (endpoint has no preview mode)"})
    else:
        try:
            client.post(f"agents/{agent_id}/reload-from-source/", json={})
            steps.append({"step": "reload-from-source", "status": "ok",
                          "detail": "source_config refreshed from file"})
        except APIError as e:
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return

    # Step 2 — bindings. This is the half that resolves declared `apis` by
    # name into agent_tools rows.
    try:
        rec = client.post(
            f"agents/{agent_id}/reconcile",
            json={},
            params={"dry_run": str(bool(dry_run)).lower(),
                    "remove_stale": str(bool(remove_stale)).lower()},
        )
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    steps.append({"step": "reconcile", "status": "ok",
                  "detail": "dry-run — nothing written" if dry_run
                            else "agent_tools bound from source_config"})

    after = None if dry_run else _resync_tool_refs(client, agent_id)

    payload = {
        "agent_id": agent_id,
        "dry_run": bool(dry_run),
        "steps": steps,
        "tools_before": None if before is None else len(before),
        "tools_after": None if after is None else len(after),
        "tools_added": sorted(after - before)
                       if (before is not None and after is not None) else [],
        "tools_removed": sorted(before - after)
                         if (before is not None and after is not None) else [],
        "reconcile": rec,
    }

    if fmt == "text":
        for s in steps:
            click.echo(f"  {s['status']:8} {s['step']:20} {s['detail']}")
        if before is None:
            # Never print "0" for a count that could not be read.
            click.echo("\n  tools: could not read agent_tools before the run")
        elif dry_run:
            click.echo(f"\n  tools: {len(before)} (dry-run — unchanged)")
        elif after is None:
            click.echo(f"\n  tools: {len(before)} -> could not re-read")
        else:
            arrow = "->" if len(after) != len(before) else "=="
            click.echo(f"\n  tools: {len(before)} {arrow} {len(after)}")
            for ref in payload["tools_added"]:
                click.echo(f"    + {ref}")
            for ref in payload["tools_removed"]:
                click.echo(f"    - {ref}")
            if not payload["tools_added"] and not payload["tools_removed"]:
                click.echo("    (no binding change)")
        return

    output(payload, fmt=fmt, raw=raw, fields=fields)


# ---------------------------------------------------------------------------
# torana admin prompts  (collection)  /  torana admin prompt <id>  (instance)
# SA-focused prompt-library introspection: drift across the whole library
# and, per prompt, its drift detail + the agents that reference it. Mirrors
# the admin agents / admin agent split above.
# ---------------------------------------------------------------------------

_PROMPT_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 40),
    ("category", "CATEGORY", 16),
    ("drift", "DRIFT", 11),
    ("is_public", "PUBLIC", 7),
]

_PROMPT_AGENTS_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 40),
    ("agent_type", "TYPE", 8),
    ("state", "STATE", 10),
    ("is_active", "ACTIVE", 7),
    ("usage_type", "USAGE", 10),
]


def _prompt_drift_label(item):
    """DRIFT / UP-TO-DATE from the API's has_drift bool (grep-friendly)."""
    return "DRIFT" if item.get("has_drift") else "UP-TO-DATE"


@admin.group(name="prompts")
def admin_prompts():
    """Prompt-library introspection (SA) — drift across the library.

    \b
    Examples:
      torana admin prompts list
      torana admin prompts list --show-drift
    """


@admin_prompts.command(name="list")
@click.option("--search", default=None, help="Search by name.")
@click.option("--show-drift", "show_drift", is_flag=True, default=False,
              help="Show ONLY prompts that have drifted from their source file.")
@click.pass_context
def admin_prompts_list(ctx, search, show_drift):
    """List prompts across the library, each with its source-drift status.

    The DRIFT column is always shown (DRIFT / UP-TO-DATE):
      torana admin prompts list | grep DRIFT      # only drifted prompts
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    effective_page_size = min(settings.page_size, 100)
    params = {"skip": 0, "limit": effective_page_size, "show_drift": "true"}
    if search is not None:
        params["search"] = search
    client = _client(ctx)
    try:
        data = client.get("prompts/", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if isinstance(data, dict) and "prompts" in data:
        items = data["prompts"]
        total = data.get("total", len(items))
    elif isinstance(data, dict) and "items" in data:
        items = data["items"]
        total = data.get("total", len(items))
    else:
        items = data if isinstance(data, list) else []
        total = len(items)
    for item in items:
        if isinstance(item, dict):
            item["drift"] = _prompt_drift_label(item)
    if show_drift:
        items = [i for i in items if isinstance(i, dict) and i.get("has_drift")]
        total = len(items)
    output({"items": items, "total": total}, fmt=fmt, raw=raw, fields=fields,
           columns=_PROMPT_LIST_COLS)


@admin.group(name="prompt", invoke_without_command=True)
@click.argument("prompt_id", metavar="PROMPT_ID")
@click.pass_context
def admin_prompt(ctx, prompt_id):
    """Per-prompt instance commands (SA).

    \b
    Examples:
      torana admin prompt <PROMPT_ID> get
      torana admin prompt <PROMPT_ID> drift
      torana admin prompt <PROMPT_ID> agents
    """
    ctx.ensure_object(dict)
    ctx.obj["_admin_prompt_id"] = prompt_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _apid(ctx) -> str:
    return ctx.obj.get("_admin_prompt_id", "") if ctx.obj else ""


@admin_prompt.command(name="get")
@click.pass_context
def admin_prompt_get(ctx):
    """Get a prompt by id (stored template + metadata)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get(f"prompts/{_apid(ctx)}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@admin_prompt.command(name="drift")
@click.pass_context
def admin_prompt_drift(ctx):
    """Config drift for a single prompt (DB template vs source file)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get(f"prompts/{_apid(ctx)}/drift")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@admin_prompt.command(name="agents")
@click.pass_context
def admin_prompt_agents(ctx):
    """List the agents that reference this prompt."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get(f"prompts/{_apid(ctx)}/agents")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    # {prompt_id, prompt_name, agents: [...], total_count} → items envelope
    if isinstance(data, dict) and "agents" in data:
        data = {"items": data["agents"],
                "total": data.get("total_count", len(data["agents"]))}
    output(data, fmt=fmt, raw=raw, fields=fields, columns=_PROMPT_AGENTS_COLS)


# ---------------------------------------------------------------------------
# Detection pipeline diagnostics (SA) — /api/v1/pipeline/*
#
# The unified pipeline-status view across all three detection subsystems
# (rule-run, signals/findings, alert events/actions/triage). Read-only —
# answers "are the subsystems moving, at what rate, how deep" in one call.
# Requires permission rule-run-queue:read.
# ---------------------------------------------------------------------------

_PIPELINE_QUEUE_COLS = [
    ("subsystem", "SUBSYSTEM", 18),
    ("key", "KEY", 14),
    ("depth", "IN_FLIGHT", 10),
    ("queued", "QUEUED", 8),
    ("running", "RUNNING", 8),
    ("failed", "FAILED", 8),
    ("dead", "DEAD", 6),
    ("throughput_per_min", "THRU/MIN", 9),
    ("oldest_queued_age_seconds", "OLDEST_S", 10),
]


@admin.group(name="detection")
def admin_detection():
    """Detection pipeline diagnostics (SA only).

    \b
    Examples:
      torana admin detection pipeline-status
      torana admin detection pipeline-status --window-seconds 600
      torana admin detection pipeline-status --json
    """


@admin_detection.command(name="pipeline-status")
@click.option("--window-seconds", "window_seconds", type=click.IntRange(30, 3600),
              default=None,
              help="Throughput window in seconds (rate = items finished in this "
                   "window). Range 30-3600. Server default is 300 when omitted.")
@click.pass_context
def admin_detection_pipeline_status(ctx, window_seconds):
    """Whole-pipeline status across every detection queue.

    \b
    Each queue's depth-by-status (queued/running/failed/dead) + oldest-queued
    age + recent throughput, in pipeline order, plus rolled-up totals
    (in_flight depth, dead, and a 'moving' flag). The time window is optional:

    \b
      torana admin detection pipeline-status                    # server default (300s)
      torana admin detection pipeline-status --window-seconds 600
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if window_seconds is not None:
        params["window_seconds"] = window_seconds

    client = _client(ctx)
    try:
        data = client.get("pipeline/status", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # json/yaml/raw: pass the full structured body through unchanged.
    if fmt in ("json", "yaml") or raw:
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    # text/table: render the per-queue rows as a table, with a totals header.
    queues = data.get("queues", []) if isinstance(data, dict) else []
    totals = data.get("totals", {}) if isinstance(data, dict) else {}
    win = data.get("window_seconds", window_seconds or 300) if isinstance(data, dict) else window_seconds

    moving = totals.get("moving")
    moving_str = (
        click.style("MOVING ✓", fg="green") if moving
        else click.style("STALLED ✗", fg="red") if moving is not None
        else "n/a"
    )
    click.echo(
        f"pipeline status  (window={win}s)  "
        f"in_flight={totals.get('in_flight_depth', 'n/a')}  "
        f"dead={totals.get('dead', 'n/a')}  {moving_str}"
    )
    output(
        {"items": queues, "total": len(queues)},
        fmt="table",
        fields=fields,
        columns=_PIPELINE_QUEUE_COLS,
    )


# ─── admin deployments (cross-tenant, super-admin) ──────────────────────────

# Cross-tenant deployment columns: TENANT + INT# (owned-integration count) are the
# operational adds over the tenant-scoped `torana deployments list` columns.
_ADMIN_DEPLOYMENT_COLS = [
    ("id", "ID", 36),
    ("tenant_id", "TENANT", 36),
    ("name", "NAME", 16),
    ("cluster_host", "HOST", 8),            # gke|eks|aks|generic (hosting cloud is a property)
    ("env_label", "ENV", 8),
    ("cluster_ref", "CLUSTER", 24),
    ("integration_count", "INT#", 5),       # how many live integrations this deployment owns
    ("api_server", "API-SERVER", 36),       # WHERE the cluster is (tells a real endpoint from a mock)
    ("internet_facing", "PUBLIC", 7),
    ("criticality", "CRIT", 9),
]


@admin.group(name="deployments", invoke_without_command=True)
@click.pass_context
def admin_deployments(ctx):
    """Deployments across ALL tenants (super-admin). Use `list` to list them.

    \b
    Examples:
      torana admin deployments list
      torana admin deployments list --format json
    """
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@admin_deployments.command(name="list")
@click.option("--limit", default=100, type=int, help="Max rows (<=100).")
@click.option("--offset", default=0, type=int, help="Pagination offset.")
@click.pass_context
def admin_deployments_list(ctx, limit, offset):
    """List deployments across all tenants (super-admin only).

    Each row carries its owning TENANT and INT# — the count of live integrations the
    deployment owns (via owner_deployment_id). Requires the super_admin role (403 otherwise).
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get("admin/deployments", params={"limit": limit, "offset": offset})
    except APIError as e:
        handle_api_error(e); return
    except AuthError as e:
        handle_auth_error(e); return
    data = {"items": data.get("deployments", []), "total": data.get("count", 0),
            "page": 1, "page_size": limit}
    output(data, fmt=fmt, raw=raw, fields=fields, columns=_ADMIN_DEPLOYMENT_COLS)


# ─── admin integrations (cross-tenant, super-admin) ─────────────────────────

# Cross-tenant integration columns. OWNER-DEP is non-empty for internal/deployment-owned
# integrations (owner_deployment_id) — the ones hidden from the per-tenant list.
_ADMIN_INTEGRATION_COLS = [
    ("id", "ID", 36),
    ("tenant_id", "TENANT", 36),
    ("name", "NAME", 26),
    ("provider", "PROVIDER", 12),
    ("owner_deployment_id", "OWNER-DEP", 36),   # non-empty ⇒ internal/deployment-owned
    ("status", "STATE", 10),
    ("last_sync_time", "LAST SYNC", 20),
]


@admin.group(name="integrations", invoke_without_command=True)
@click.pass_context
def admin_integrations(ctx):
    """Integrations across ALL tenants (super-admin). Use `list` to list them.

    \b
    Includes internal/deployment-owned integrations (hidden from the per-tenant list).
    The OWNER-DEP column names the deployment that created each internal integration.

    \b
    Examples:
      torana admin integrations list
      torana admin integrations list --format json
    """
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@admin_integrations.command(name="list")
@click.option("--include-deleted", is_flag=True, default=False, help="Include deleted integrations.")
@click.pass_context
def admin_integrations_list(ctx, include_deleted):
    """List integrations across all tenants (super-admin only).

    Includes internal/deployment-owned integrations that are hidden from the per-tenant
    list. Each row shows its owning TENANT and, for internal ones, OWNER-DEP (the
    deployment that created it). Requires the super_admin role (403 otherwise).
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    params = {}
    if include_deleted:
        params["include_deleted"] = "true"
    client = _client(ctx)
    try:
        data = client.get("admin/integrations", params=params)
    except APIError as e:
        handle_api_error(e); return
    except AuthError as e:
        handle_auth_error(e); return
    data = {"items": data.get("integrations", []), "total": data.get("count", 0),
            "page": 1, "page_size": len(data.get("integrations", []))}
    output(data, fmt=fmt, raw=raw, fields=fields, columns=_ADMIN_INTEGRATION_COLS)


# ---------------------------------------------------------------------------
# torana admin engagement — Build-V2 Engagement sweep (SA, Spec F)
#   sweep trigger [--tenant]   |   sweeps list
# ---------------------------------------------------------------------------

@admin.group(name="engagement", invoke_without_command=True)
@click.pass_context
def admin_engagement(ctx):
    """Super-admin Engagement sweep controls.

    \b
    Examples:
      torana admin engagement sweep trigger              # sweep the caller's tenant
      torana admin engagement sweep trigger --tenant <T> # sweep a specific tenant
      torana admin engagement sweeps list                # past sweep runs + results
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@admin_engagement.group(name="sweep", invoke_without_command=True)
@click.pass_context
def admin_engagement_sweep(ctx):
    """Trigger the source-aware Engagement sweep. Use `trigger`."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@admin_engagement_sweep.command(name="trigger")
@click.option("--tenant", "tenant_id", default=None,
              help="Target tenant UUID. Omit to sweep the caller's tenant.")
@click.pass_context
def admin_engagement_sweep_trigger(ctx, tenant_id):
    """Trigger the source-aware Engagement sweep (super-admin).

    For each in-scope app: derive Intent/Goals from deployed Build-V2 proposals
    when it has shipped, else fall back to chat-memory synthesis. Runs in the
    background under an advisory lock (one worker at a time). Poll
    `torana admin engagement sweeps list` for status + results.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    params = {}
    if tenant_id:
        params["scope_tenant_id"] = tenant_id
    try:
        data = client.post("context-lake/engagement/sweep", json={}, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt)


@admin_engagement.group(name="sweeps", invoke_without_command=True)
@click.pass_context
def admin_engagement_sweeps(ctx):
    """Past Engagement sweep runs. Use `list`."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@admin_engagement_sweeps.command(name="list")
@click.option("--tenant", "tenant_id", default=None, help="Filter by targeted tenant.")
@click.option("--limit", default=50, show_default=True)
@click.pass_context
def admin_engagement_sweeps_list(ctx, tenant_id, limit):
    """List past Engagement sweep runs (newest first) with counts + status."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    params = {"limit": limit}
    if tenant_id:
        params["scope_tenant_id"] = tenant_id
    try:
        data = client.get("context-lake/engagement/sweeps", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, columns=[
        ("status", "STATUS", 10),
        ("trigger", "TRIGGER", 10),
        ("workspaces_evaluated", "WS", 4),
        ("build_v2_derived", "V2", 4),
        ("chat_memory_synthesized", "CHAT", 5),
        ("skipped_idempotent", "SKIP", 5),
        ("intents_written", "INTENTS", 8),
        ("goals_written", "GOALS", 6),
        ("started_at", "STARTED", 20),
    ])


# ---------------------------------------------------------------------------
# question-coverage — the Domain Primitives corpus (spec § 4.18, surface 2)
#
# SUPER-ADMIN ONLY, and it lives under `admin` for the same reason the FE hides
# the `questions` and `primitives` blocks from the tenant mount
# (pantheon-fe/.../tenant-semantic-model-page.component.ts, PLATFORM_CURATION):
#
#   the question catalog is PLATFORM CURATION — which questions the platform
#   intends to answer — not a fact about any tenant's own data. A tenant cannot
#   add a question or author a prepared view, so showing them an empty or partial
#   catalog would read as THEIR gap when it is OURS.
#
# The three surfaces must agree on this. Putting it under `torana datalake` would
# have exposed to every tenant exactly what the FE deliberately hides.
# ---------------------------------------------------------------------------

# ⛔ THE CORPUS IS FETCHED FROM THE API, NEVER READ FROM DISK.
#
# This command used to load `questions.csv` + `question_sql.csv` off a local
# checkout. Three things were wrong with that and all three bit:
#
#   1. It read `question_sql.csv`, which is SUPERSEDED. The CLI printed the retired
#      vocabulary (`executed`/`explained`/`retired`) while the API served the live
#      one (`validated`/`not_validated`) — two surfaces disagreeing about the same
#      corpus, which is the exact drift R8 exists to prevent.
#   2. It only worked inside a Torana checkout.
#   3. It was blind to `blocker_evidence_json` — the measured evidence of why a
#      question cannot be answered — because that column does not exist in the
#      file it was reading.
#
# ⚠️ A parallel session writes the corpus CSVs continuously, so a disk read is
# racing an author. The API is the only surface that is both current and gated.


def _corpus_get(ctx, path: str, params: dict = None):
    """GET a corpus endpoint, or exit with a message a human can act on.

    ⚠️ `/corpus/*` is gated on super_admin. A tenant token gets 403, and a bare
    stack trace would read as a broken command rather than the wrong profile —
    so that case is named explicitly.
    """
    client = _client(ctx)
    try:
        return client.get(path, params=params or {})
    except APIError as e:
        if e.status_code == 403:
            click.echo(
                "Forbidden. The domain-question corpus is PLATFORM CURATION and is "
                "gated on super_admin — a tenant token cannot read it.\n"
                "Retry with:  TORANA_PROFILE=SA torana admin corpus ...",
                err=True,
            )
            ctx.exit(e.exit_code)
        handle_api_error(e)
        ctx.exit(1)
    except AuthError as e:
        handle_auth_error(e)
        ctx.exit(1)


def _corpus_questions(ctx) -> list:
    return _corpus_get(ctx, "corpus/questions").get("items") or []


def _read_corpus(ctx) -> list:
    """The rows `question-coverage` prints, from the API rather than the CSVs."""
    rows = []
    for r in _corpus_questions(ctx):
        rows.append({
            "question_id": r.get("question_id") or "",
            "question": (r.get("question") or "")[:70],
            "answerable": r.get("answerable_by_schema") or "",
            # Absent SQL is meaningful: the question has no SQL shape at all.
            "has_sql": "yes" if r.get("has_sql") else "no",
            # ⭐ The LIVE vocabulary — validated | not_validated.
            "validation": r.get("validation_status") or "",
            # A grain check that was SKIPPED is not a pass — surfaced verbatim so
            # nobody reads an empty column as verified.
            "grain_check": r.get("grain_check") or "",
            "decision": r.get("decision") or "",
            "classification": r.get("classification") or "",
            "entry": r.get("target_entry_id") or "",
            # ⚠️ Whether measured evidence exists for the refusal. `-` means the
            # question carries none, NOT that nothing blocks it.
            "evidence": "yes" if r.get("blocker_evidence_json") else "-",
        })
    return rows


_QUESTION_COLS = [
    ("question_id", "ID", 8),
    ("question", "QUESTION", 52),
    ("answerable", "SCHEMA?", 9),
    ("has_sql", "SQL", 5),
    ("validation", "VALIDATION", 12),
    ("grain_check", "GRAIN", 9),
    ("decision", "DECISION", 13),
    ("classification", "CLASS", 12),
    ("evidence", "EVID", 6),
]


@admin.command(name="question-coverage")
@click.option("--answerable", "answerable", default=None,
              type=click.Choice(["yes", "no", "partial"]),
              help="Only questions with this schema-answerability verdict.")
@click.option("--decision", "decision", default=None, metavar="DECISION",
              help="Only candidates with this Pass Three decision (keep, merge, defer, ...).")
@click.option("--unanswered", is_flag=True, default=False,
              help="Only questions with no SQL — the ones no query can answer.")
@click.pass_context
def datalake_question_coverage(ctx, answerable, decision, unanswered):
    """Report the domain question corpus by answerability and validation (SA only).

    Platform curation, not tenant data: this is which questions the PLATFORM
    intends to answer. Reads GET /api/v1/corpus/questions — never the repo CSVs,
    so it agrees with the FE and works outside a checkout.

    Answers two different questions that are easy to conflate:

    \b
      SCHEMA?  can the schema answer this AT ALL? (independent of today's data)
      GRAIN    was the declared grain mechanically VERIFIED against real rows?

    A `skipped` grain check is NOT a pass — it means no key could be resolved from
    the grain prose, so the claim is unverified. It is shown verbatim rather than
    blanked so an empty result never reads as a clean one.

    \b
    Examples:
      TORANA_PROFILE=SA torana admin question-coverage
      TORANA_PROFILE=SA torana admin question-coverage --unanswered
      TORANA_PROFILE=SA torana admin question-coverage --decision defer
    """
    import collections

    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW) if ctx.obj else False

    rows = _read_corpus(ctx)
    if not rows:
        # ⛔ An EMPTY corpus is not the same as a corpus that failed to load — the
        # API says which files it found, and a 403/500 has already exited above.
        click.echo("The corpus endpoint returned no questions.", err=True)
        ctx.exit(1)

    if answerable:
        rows = [r for r in rows if r["answerable"] == answerable]
    if decision:
        rows = [r for r in rows if r["decision"] == decision]
    if unanswered:
        rows = [r for r in rows if r["has_sql"] == "no"]

    if raw or fmt == "json":
        output(rows, fmt=fmt, raw=raw, columns=_QUESTION_COLS)
        return

    output(rows, fmt=fmt, raw=raw, columns=_QUESTION_COLS)

    # The summary is the point of the command; the table is the detail behind it.
    total = len(rows)
    ans = collections.Counter(r["answerable"] for r in rows)
    dec = collections.Counter(r["decision"] for r in rows if r["decision"])
    grain = collections.Counter(r["grain_check"] for r in rows if r["grain_check"])
    no_sql = sum(1 for r in rows if r["has_sql"] == "no")

    click.echo("")
    click.echo(f"  {total} questions  ·  {total - no_sql} with SQL  ·  {no_sql} without")
    if ans:
        click.echo("  schema-answerable: " + "  ".join(
            f"{k}={v}" for k, v in sorted(ans.items()) if k))
    if dec:
        click.echo("  decisions:         " + "  ".join(
            f"{k}={v}" for k, v in dec.most_common()))
    if grain:
        verified = grain.get("pass", 0)
        click.echo("  grain checks:      " + "  ".join(
            f"{k}={v}" for k, v in grain.most_common()))
        click.echo(
            f"  ⚠ only {verified} of {sum(grain.values())} grains are mechanically "
            "verified; `skipped` and `vacuous` are NOT passes."
        )


# ---------------------------------------------------------------------------
# torana admin corpus — summary · roadmap · show
#
# ⛔ SA ONLY, and under `admin` for the reason at the top of the question-coverage
# section: the catalog is which questions the PLATFORM intends to answer, not a
# fact about any tenant's data. The API enforces it (super_admin); this placement
# agrees with it rather than relying on it.
#
# ⭐ THIN WRAPPERS. Every number is computed server-side by /corpus/summary so the
# CLI, the FE and the API cannot drift on what "answered" or "blocked" means —
# R8: three surfaces, one backend, no reimplementation.
#
# ⛔ NEVER reads the corpus CSVs. A parallel session writes them continuously; the
# API is the only surface that is both current and gated.
# ---------------------------------------------------------------------------

# ⚠️ COLOUR-BLIND SAFE. Each state pairs a GLYPH with the state WORD; colour is
# never the only signal — and in a terminal it may not exist at all. The
# vocabulary is copied verbatim from the API (§ 2.4): do not invent a fifth value
# here, add it at the source.
_STATE_GLYPH = {
    "no_such_column": "⛔",
    "reachable_but_empty": "◐",
    "reachable_constant": "✓",
    "wrong_grain": "⚠",
}


def _state_face(state: str) -> str:
    """`⛔ no_such_column` — glyph AND word, always."""
    return f"{_STATE_GLYPH.get(state, '·')} {state or 'unspecified'}"


def _as_json(ctx, as_json: bool) -> bool:
    fmt = ctx.obj.get(CTX_FORMAT) if ctx.obj else None
    return bool(as_json or fmt in ("json", "yaml"))


@admin.group(name="corpus")
def admin_corpus():
    """The domain-question corpus: coverage, what blocks it, one question in full.

    \b
    Examples:
      TORANA_PROFILE=SA torana admin corpus summary
      TORANA_PROFILE=SA torana admin corpus roadmap
      TORANA_PROFILE=SA torana admin corpus show EM-002
    """


@admin_corpus.command(name="summary")
@click.option("--json", "as_json", is_flag=True, default=False,
              help="Emit the raw summary payload.")
@click.pass_context
def admin_corpus_summary(ctx, as_json):
    """Coverage of the question corpus, by validation and by use case.

    \b
      VALIDATED     proved to run — NOT merely "has SQL". Rows carry SQL text that
                    was never validated, so the two counts differ.
      BY USE CASE   answered of asked. The most diagnostic cut in the dataset:
                    a flat total hides that prioritization is 2 of 13.
    """
    data = _corpus_get(ctx, "corpus/summary")
    if _as_json(ctx, as_json):
        output(data, fmt="json")
        return

    total = data.get("total_questions", 0)
    validated = data.get("validated", 0)
    click.echo("")
    click.echo(f"  {total} questions  ·  {validated} validated  ·  "
               f"{total - validated} not validated")
    click.echo(f"  {data.get('with_evidence', 0)} carry measured blocker evidence")

    # ⛔ VALIDATED IS NOT ANSWERABLE, and printing only the first overstates the platform.
    # `validated` certifies the SQL RUNS; `answers_question` certifies it ANSWERS. Measured
    # 2026-08-27, they differ by 12 rows: queries that execute cleanly and return nothing, or
    # whose every dimension holds ONE value. Both numbers are printed side by side because a
    # reader shown only "34 validated" concludes the corpus answers 34 questions.
    ans_q = data.get("by_answers_question") or {}
    if ans_q:
        yes = ans_q.get("yes", 0)
        click.echo(f"  ⭐ {yes} ANSWER their question  ·  "
                   + "  ".join(f"{k}={v}" for k, v in sorted(ans_q.items())))
        dead = data.get("with_dead_limbs", 0)
        if dead:
            # A dead limb is a derivation producing ONE distinct value — the question's own
            # concept failing to discriminate. No existing gate reports it.
            click.echo(f"  ⚠️  {dead} carry a DEAD LIMB "
                       f"(a dimension the question asks about holds one value)")
    click.echo("")

    outcome = data.get("by_outcome") or {}
    if outcome:
        click.echo("  outcome:            "
                   + "  ".join(f"{k}={v}" for k, v in sorted(outcome.items())))
    ans = data.get("by_answerability") or {}
    if ans:
        click.echo("  schema-answerable:  "
                   + "  ".join(f"{k}={v}" for k, v in sorted(ans.items())))

    uc = data.get("by_use_case") or {}
    if uc:
        click.echo("")
        click.echo("  BY USE CASE                answered / asked")
        # Biggest gap first — that is the question this cut exists to answer.
        for k in sorted(uc, key=lambda x: -(uc[x]["total"] - uc[x]["answered"])):
            v = uc[k]
            gap = v["total"] - v["answered"]
            mark = "⛔" if v["answered"] == 0 else ("⚠" if gap else "✓")
            click.echo(f"    {mark} {k:<26} {v['answered']:>3} / {v['total']:<3}")

    ls = data.get("by_limb_state") or {}
    if ls:
        click.echo("")
        click.echo("  BLOCKED LIMBS BY STATE")
        for k, v in sorted(ls.items(), key=lambda kv: -kv[1]):
            click.echo(f"    {_state_face(k):<30} {v}")
    click.echo("")


@admin_corpus.command(name="questions")
@click.option("--use-case", "use_case", default=None, metavar="USE_CASE",
              help="Only questions in this use case (see `corpus summary`).")
@click.option("--blocked", is_flag=True, default=False,
              help="Only questions that were never validated.")
@click.option("--with-evidence", "with_evidence", is_flag=True, default=False,
              help="Only questions carrying measured blocker evidence.")
@click.option("--json", "as_json", is_flag=True, default=False,
              help="Emit the raw question records.")
@click.pass_context
def admin_corpus_questions(ctx, use_case, blocked, with_evidence, as_json):
    """EVERY question in the corpus — the ledger the FE's first tab shows.

    \b
    ⭐ The companion to `corpus roadmap`: the same 100 questions, listed rather
    than grouped by what blocks them. Neither view truncates.

    \b
    Examples:
      TORANA_PROFILE=SA torana admin corpus questions
      TORANA_PROFILE=SA torana admin corpus questions --use-case prioritization
      TORANA_PROFILE=SA torana admin corpus questions --blocked --with-evidence
    """
    rows = _corpus_questions(ctx)
    if use_case:
        rows = [r for r in rows if (r.get("use_case") or "") == use_case]
    if blocked:
        rows = [r for r in rows if r.get("validation_status") != "validated"]
    if with_evidence:
        rows = [r for r in rows if r.get("blocker_evidence_json")]

    if _as_json(ctx, as_json):
        output(rows, fmt="json")
        return

    if not rows:
        # ⚠️ An empty FILTER result is not an empty corpus — say which.
        click.echo("\n  No question matches that filter.\n")
        return

    click.echo("")
    click.echo(f"  {'ID':<8} {'STATE':<14} {'USE CASE':<22} {'EVID':<5} QUESTION")
    for r in rows:
        validated = r.get("validation_status") == "validated"
        state = "validated" if validated else (
            "retired" if r.get("outcome") == "retired" else "not_validated")
        # ⚠️ Glyph AND word — a terminal may render no colour at all.
        mark = "✓" if validated else ("·" if state == "retired" else "⛔")
        evid = "◆" if r.get("blocker_evidence_json") else "-"
        q = (r.get("question") or "")[:60]
        click.echo(f"  {r.get('question_id', ''):<8} {mark} {state:<12} "
                   f"{(r.get('use_case') or '—'):<22} {evid:<5} {q}")

    # ⛔ The population this list describes, so a filtered view never reads as
    # the whole corpus.
    click.echo("")
    shown = len(rows)
    filt = " (filtered)" if (use_case or blocked or with_evidence) else ""
    click.echo(f"  {shown} questions{filt} · "
               f"{sum(1 for r in rows if r.get('validation_status') == 'validated')} validated · "
               f"{sum(1 for r in rows if r.get('blocker_evidence_json'))} with evidence")
    click.echo("")


@admin_corpus.command(name="roadmap")
@click.option("--json", "as_json", is_flag=True, default=False,
              help="Emit the raw roadmap payload.")
@click.pass_context
def admin_corpus_roadmap(ctx, as_json):
    """What blocks the corpus, ranked by how many questions each would unblock.

    \b
    ⚠️ A row is a BLOCKED COLUMN — or, where the record names one, the capability
    slug covering it. Two columns can be one project, so this is an UPPER BOUND on
    distinct work, never a project count.

    \b
    ⛔ SCHEMA ADDITIONS are listed separately: those limbs name no column at all
    (the concept has nowhere to live), which makes them both the most expensive
    work and the worst-bucketed. Mixed in, they are invisible.
    """
    data = _corpus_get(ctx, "corpus/summary")
    if _as_json(ctx, as_json):
        output({
            "schema_additions": data.get("top_schema_additions") or [],
            "blocked_columns": data.get("top_blocked_columns") or [],
            "schema_additions_total": data.get("schema_additions", 0),
            "blocked_columns_total": data.get("blocked_columns", 0),
        }, fmt="json")
        return

    def _group(title, glyph, rows, total, note):
        click.echo("")
        click.echo(f"  {glyph} {title}  ({total})")
        click.echo(f"     {note}")
        click.echo("")
        for b in rows:
            ids = " · ".join(b.get("questions") or [])
            click.echo(f"    {b.get('key', '')}")
            click.echo(f"       unblocks {b.get('unblocks', 0)}   {ids}")
        # ⛔ Say what was dropped, IF anything was. The endpoint is complete by
        # default (limit=0), so this normally prints nothing — but it stays,
        # because a silent top-N reads as "this is all of it" and the day someone
        # reintroduces a cap is the day this line has to already be here.
        hidden = max(0, total - len(rows))
        if hidden:
            click.echo(f"       … {hidden} more not shown (showing "
                       f"{len(rows)} of {total})")

    _group("SCHEMA ADDITIONS", "⛔",
           data.get("top_schema_additions") or [], data.get("schema_additions", 0),
           "No column exists to fill. Needs a schema change before any ETL helps.")
    _group("BLOCKED COLUMNS", "◐",
           data.get("top_blocked_columns") or [], data.get("blocked_columns", 0),
           "The column exists — empty, constant, or at the wrong grain.")
    click.echo("")


@admin_corpus.command(name="show")
@click.argument("question_id", metavar="QUESTION_ID")
@click.option("--json", "as_json", is_flag=True, default=False,
              help="Emit the raw question record, evidence included.")
@click.option("--sql", "want_sql", is_flag=True, default=False,
              help="Print ONLY the question's SQL text, for piping into a file or a query.")
@click.pass_context
def admin_corpus_show(ctx, question_id, as_json, want_sql):
    """ONE question in full — including WHY it cannot be answered.

    \b
    This is the page's drawer in a terminal: the question, its grain and tables,
    then the measured evidence — which limb is blocked, by how much, and what
    capability would unblock it.

    \b
    --sql prints the QUERY TEXT and nothing else, so it pipes cleanly:
      TORANA_PROFILE=SA torana admin corpus show EM-011 --sql > q.sql
    ⚠️ The list view reports `sql_length` but never the text — 100 rows of
    query text is payload nobody reads. This flag is that text's only path
    through the CLI; before it existed the SQL could be read only out of a
    repo checkout, which defeats the point of having an API at all.

    \b
    Example:
      TORANA_PROFILE=SA torana admin corpus show EM-002
    """
    # ⚠️ --sql needs the SINGLE-question route: the list deliberately omits the
    # text, so filtering the list (what the human-readable path below does)
    # can never produce it.
    if want_sql:
        wanted = question_id.strip().upper()
        # ⚠️ The /sql route, NOT /corpus/questions/{id} — that path is the one
        # CLOSED_LOOP_DATASET_SPEC § 2.6 pins and the closed-loop runner calls.
        # One contract, so the CLI and the runner cannot drift apart.
        row = _corpus_get(ctx, f"corpus/questions/{wanted}/sql")
        sql = (row or {}).get("sql")
        if not sql:
            # `sql: null` is a real, non-error answer (9 of 101 are
            # no_sql_authored, 51 retired) — say which, and still exit
            # non-zero so a script that expected text does not pipe an
            # empty file onward believing it succeeded.
            click.echo(
                f"No SQL authored for {question_id!r} "
                f"(outcome: {(row or {}).get('outcome') or 'unknown'}). "
                f"48 of the 101 corpus questions carry SQL.", err=True)
            ctx.exit(1)
        click.echo(sql)
        return

    rows = _corpus_questions(ctx)
    wanted = question_id.strip().upper()
    row = next((r for r in rows if (r.get("question_id") or "").upper() == wanted), None)
    if not row:
        # ⚠️ Name real neighbours rather than only reporting the miss — ids are
        # easy to mistype and the corpus is not memorisable.
        sample = ", ".join((r.get("question_id") or "") for r in rows[:3])
        click.echo(f"No question {question_id!r} in the corpus. "
                   f"Ids look like: {sample}", err=True)
        ctx.exit(1)

    if _as_json(ctx, as_json):
        output(row, fmt="json")
        return

    ev = row.get("blocker_evidence_json") or {}
    validated = row.get("validation_status") == "validated"
    # BLOCKED vs RETIRED are different facts: retired was withdrawn, blocked was
    # never proved. Collapsing them would misreport 59 rows.
    state = "VALIDATED" if validated else (
        "RETIRED" if row.get("outcome") == "retired" else "BLOCKED")
    cuts = " · ".join(x for x in (
        row.get("domain"), row.get("use_case"), row.get("persona"),
        row.get("decision_level")) if x)

    click.echo("")
    click.echo(f"{row.get('question_id')} · {state}" + (f" · {cuts}" if cuts else ""))
    click.echo(f"  {row.get('question', '')}")
    click.echo("")
    click.echo(f"  grain    {row.get('expected_grain') or row.get('grain') or '—'}")
    click.echo(f"  tables   {' · '.join(row.get('source_tables') or []) or '—'}")
    click.echo(f"  answerable  {row.get('answerable_by_schema') or '—'}"
               f"      sql  {row.get('sql_length') or 0} chars")

    if not ev:
        note = row.get("refusal_note") or ""
        click.echo("")
        if note:
            click.echo("  RECORDED REASON")
            click.echo(f"    {note}")
        else:
            # ⚠️ Not "nothing blocks it" — no evidence was recorded.
            click.echo("  No blocker evidence recorded for this question.")
        click.echo("")
        return

    if ev.get("why_no_data_helps"):
        click.echo("")
        click.echo("  WHY NO AMOUNT OF DATA HELPS")
        click.echo(f"    {ev['why_no_data_helps']}")

    limbs = ev.get("limbs") or []
    blocked = [x for x in limbs if x.get("state") != "reachable_constant"]
    if limbs:
        click.echo("")
        click.echo(f"  LIMBS ({len(blocked)} of {len(limbs)} blocked)")
        for limb in limbs:
            click.echo(f"    {_state_face(limb.get('state'))}"
                       f"   {limb.get('column') or '(no column exists)'}")
            click.echo(f"       {limb.get('limb', '')}")
            if limb.get("measured"):
                click.echo(f"       measured   {limb['measured']}")
            if limb.get("capability_needed"):
                click.echo(f"       needs      {limb['capability_needed']}")
            if limb.get("capability_id"):
                click.echo(f"       capability {limb['capability_id']}")

    if ev.get("stale_reason_to_correct"):
        click.echo("")
        click.echo("  ⚠ STORED REASON IS STALE")
        click.echo(f"    {ev['stale_reason_to_correct']}")

    if ev.get("unblocks_if_built"):
        click.echo("")
        click.echo("  ALSO UNBLOCKS   " + " · ".join(ev["unblocks_if_built"]))
    click.echo("")


# ──────────────────────────────────────────────────────────────────────────
# BACK-COMPAT — hidden aliases for the old `<noun>-by-<param>` names.
# ⏳ ONE RELEASE ONLY (decision D4). Delete this block next release.
# ──────────────────────────────────────────────────────────────────────────

_LEGACY_BY_PARAM_ADMIN = {
    "tables-by-table-name": ("table", "get"),
    "turns-by-turn-id": ("turn", "delete"),
    "workspace-sweeps-by-workspace-id": ("workspace-sweep", "get"),
    "workspaces-by-workspace-id": ("workspace-admin", "update"),
}


def _register_legacy_admin_by_param() -> None:
    """Old flat names, hidden so they cannot be discovered anew."""
    import copy
    for _old, (_sub, _verb) in _LEGACY_BY_PARAM_ADMIN.items():
        _grp = admin.commands.get(_sub)
        if not isinstance(_grp, click.Group):
            continue
        _cmd = _grp.commands.get(_verb)
        if _cmd is None:
            continue
        # ⛔ Never let an alias overwrite a real group of the same name.
        if isinstance(admin.commands.get(_old), click.Group):
            continue
        _alias = copy.copy(_cmd)
        _alias.name = _old
        _alias.hidden = True
        admin.add_command(_alias)


_register_legacy_admin_by_param()


@admin.command(name="internal-auth-status")
@click.option("--problems-only", is_flag=True, help="Show only services that are NOT enforcing.")
@click.pass_context
def admin_internal_auth_status(ctx, problems_only):
    """Show internal-auth (#171) enforcement for every service.

    \b
    Answers: "is the `pantheon-app` bypass actually gone everywhere?"

    The server does not read this from config — it sends a REAL unauthenticated
    request to each service's destructive /internal/cleanup route. A row reads
    ENFORCED only when that request is rejected, so it reflects what an attacker
    would actually get rather than what a flag claims.

    \b
    An UNREACHABLE service is reported NOT-ENFORCED, never as OK: an unknown
    shown as green is the exact failure this command exists to prevent.

    \b
    Examples:
      TORANA_PROFILE=SA torana admin internal-auth-status
      TORANA_PROFILE=SA torana admin internal-auth-status --problems-only
      TORANA_PROFILE=SA torana admin internal-auth-status --format json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get("internal-auth/status")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
        return

    services = data.get("services", [])
    if problems_only:
        services = [s for s in services if not s.get("enforced")]

    if not services:
        click.echo("All services enforce internal auth." if problems_only
                   else "No services reported.")
        return

    # State is carried by the WORD, not by colour — colour is decoration only,
    # and this output must stay readable to a red/green colour-blind reader and
    # in a pipe where colour is stripped entirely.
    click.echo(f"{'SERVICE':<32} {'STATE':<16} {'PROBE':<8} NOTE")
    for s in services:
        enforced = s.get("enforced")
        state = "OK ENFORCED" if enforced else "!! NOT-ENFORCED"
        probe = s.get("cleanup_probe_status")
        probe_s = str(probe) if probe is not None else "-"
        note = "" if enforced else (s.get("error") or "unauthenticated request was ACCEPTED")
        line = f"{s.get('service',''):<32} {state:<16} {probe_s:<8} {note}"
        click.echo(click.style(line, fg="green" if enforced else "red") if enforced is not None else line)

    click.echo("")
    click.echo(
        f"{data.get('enforced_count', 0)}/{data.get('total_count', 0)} services enforcing"
        + ("" if data.get("all_enforced") else "   !! NOT ALL SERVICES ENFORCE")
    )


# ── torana admin cli — run a CLI command THROUGH pantheon-admin ────────────────

@admin.group(name="cli")
def admin_cli():
    """Run a `torana` command through pantheon-admin, as an agent would.

    ⭐ WHY THIS EXISTS. pantheon-admin exposes an endpoint that runs THIS SAME CLI
    in-process on a caller's behalf — that is how an agent uses the platform without
    a parallel, drifting tool implementation. This command drives that endpoint from
    a terminal, so the agent's exact path is reproducible by a human:

        laptop -> torana cli -> pantheon-admin -> torana cli -> nginx -> service

    ⚠️ It is a DIAGNOSTIC, not a shortcut. Running `torana datalake list-existing`
    directly is faster and does the same thing. Use this to answer questions about
    the AGENT path specifically: is a command admitted, does it return what the
    shell returns, is the round trip working at all.

    \b
    Examples:
      torana admin cli exec "auth me"
      torana admin cli exec "datalake list-existing --json"
      torana admin cli exec "datalake clear-all"      # refused — shows the reason
      torana admin cli check "build proposal deploy"  # ask WITHOUT running it
    """


# ⛔ `ignore_unknown_options` + `allow_extra_args` — WITHOUT THESE, `--help` NEVER
# REACHES THE PLATFORM. Click parses the COMMAND string's own flags as flags on THIS
# command, so `torana admin cli exec "--help"` printed exec's help instead of the
# root CLI's, and `... exec "rules list --json"` would have had --json stolen the same
# way. The endpoint handles both correctly; only the wrapper was eating them.
# Reported 2026-08-28 by someone reasonably expecting the two to match.
@admin_cli.command(
    name="exec",
    # ⚠️ `help_option_names: []` is REQUIRED on top of ignore_unknown_options —
    # Click treats --help specially and intercepts it BEFORE unknown-option handling,
    # so without this `exec "--help"` prints THIS command's help instead of the
    # platform's root help. Disabling the built-in option is the only way to let
    # `--help` through as an argument. Use `torana admin cli --help` for this
    # command's own help (the GROUP still has it).
    context_settings={
        "ignore_unknown_options": True,
        "allow_extra_args": True,
        "help_option_names": [],
    },
)
@click.argument("command", metavar="COMMAND")
@click.option("--show-envelope", is_flag=True, default=False,
              help="Print the endpoint's JSON envelope instead of just the output.")
@click.pass_context
def admin_cli_exec(ctx, command, show_envelope):
    """Run COMMAND through pantheon-admin and print what it returned.

    COMMAND is a torana command WITHOUT the leading `torana`, quoted as one argument.

    ⚠️ The exit code is the COMMAND's, not the tool's. The round trip succeeding and
    the command succeeding are different things, and this deliberately keeps them
    distinct: a refused or failing command still means the tool worked.

    \b
    Examples:
      torana admin cli exec "auth me"
      torana admin cli exec "vm policy vocabulary"
      torana admin cli exec "datalake clear-all"
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.post("admin/cli/execute", json={"command": command})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if show_envelope or fmt in ("json", "yaml"):
        output(data, fmt=fmt if fmt != "text" else "json")
        return

    # Default: behave like the command itself — its output on stdout, its exit code
    # as ours. A refusal or truncation is a note on stderr, so piping stays clean.
    click.echo(data.get("output", ""), nl=False)
    if not str(data.get("output", "")).endswith("\n"):
        click.echo("")
    if data.get("truncated"):
        click.echo("[output truncated by the endpoint's size cap]", err=True)
    if data.get("refused"):
        click.echo("[refused before execution — nothing was sent to the platform]", err=True)
    rc = int(data.get("exit_code", 0) or 0)
    if rc:
        ctx.exit(rc)


# Same flag-passthrough treatment as `exec` — see the comment there.
@admin_cli.command(
    name="check",
    context_settings={
        "ignore_unknown_options": True,
        "allow_extra_args": True,
        "help_option_names": [],
    },
)
@click.argument("command", metavar="COMMAND")
@click.pass_context
def admin_cli_check(ctx, command):
    """Ask whether COMMAND would be ADMITTED — without running it.

    ⭐ The question the refusal log answers in aggregate, asked about one command.
    Use it to find out why something is withheld before building a flow around it.

    \b
    Examples:
      torana admin cli check "datalake list-existing"
      torana admin cli check "build proposal deploy"
      torana admin cli check "datalake clear-all"
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.post("admin/cli/check", json={"command": command})
    except APIError as e:
        # ⛔ NO FALLBACK TO `exec`. An earlier version fell back to the execute
        # endpoint and inferred admission from `refused` — which RAN every admitted
        # command. `check` promises to answer WITHOUT running anything; a fallback
        # that executes turns a question into an action, and the one case where that
        # matters most (a command with side effects) is exactly where it would bite.
        if getattr(e, "status_code", None) == 404:
            click.echo(
                "This server does not expose admin/cli/check — it is a newer endpoint "
                "than the running pantheon-admin. Upgrade it, or use `torana admin cli "
                "exec` and read the `refused` field (⚠️ that RUNS the command if it is "
                "admitted).", err=True)
            ctx.exit(3)
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml"):
        output(data, fmt=fmt)
        return
    admitted = data.get("admitted")
    click.echo(f"COMMAND    {data.get('command', command)}")
    click.echo(f"ADMITTED   {admitted}")
    if data.get("reason"):
        click.echo(f"REASON     {data.get('reason')}")
    if data.get("detail"):
        click.echo(f"DETAIL     {str(data.get('detail'))[:400]}")


# ─────────────────────────────────────────────────────────────────────────────
# AI Home — the CROSS-TENANT plane only.
#
# ⛔ Inspecting ONE run is NOT here. A run belongs to a workspace, so it lives at
# `torana workspace <id> ai-home run-detail <run_id>` — beside the page it
# produced, matching `workspace <id> sweeps get`. Only questions with no single
# owning workspace belong under `admin`.
# ─────────────────────────────────────────────────────────────────────────────

@admin.group(name="ai-home", invoke_without_command=True)
@click.pass_context
def admin_ai_home(ctx):
    """AI Home across ALL tenants (SA). Use `fleet`, `metrics` or `feedback`."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@admin_ai_home.command(name="fleet")
@click.option("--tenant-id", default=None)
@click.option("--workspace-id", default=None)
@click.option("--status", default=None,
              help="success | partial | failed | timeout | in_progress")
@click.option("--produced-by", default=None,
              help="claude_code_skill | torana_agent")
@click.option("--page", default=1, show_default=True, type=int)
@click.option("--page-size", default=20, show_default=True, type=int)
@click.pass_context
def admin_ai_home_fleet(ctx, tenant_id, workspace_id, status, produced_by,
                        page, page_size):
    """List AI Home runs across every tenant.

    Examples:
      torana admin ai-home fleet
      torana admin ai-home fleet --status failed
      torana admin ai-home fleet --produced-by torana_agent
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {"page": page, "page_size": page_size}
    for k, v in (("tenant_id", tenant_id), ("workspace_id", workspace_id),
                 ("status", status), ("produced_by", produced_by)):
        if v:
            params[k] = v
    try:
        data = _client(ctx).get("admin/ai-home/fleet", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields, columns=[
        ("run_id", "RUN", 38),
        ("status", "STATUS", 9),
        # ⭐ Which harness wrote it — the two are meant to be compared.
        ("produced_by", "BY", 18),
        ("workspace_id", "WORKSPACE", 38),
        ("started_at", "STARTED", 20),
    ])


@admin_ai_home.command(name="metrics")
@click.option("--days", default=30, show_default=True, type=int)
@click.pass_context
def admin_ai_home_metrics(ctx, days):
    """Platform health: coverage mix, cap-hit rate, durations.

    Examples:
      torana admin ai-home metrics
      torana admin ai-home metrics --days 7 --format json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    try:
        d = _client(ctx).get("admin/ai-home/metrics", params={"days": days})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml"):
        output(d, fmt=fmt, raw=raw, fields=fields)
        return

    click.echo("")
    click.echo(f"  window    last {d.get('window_days')} days")
    click.echo(f"  runs      {d.get('runs')}")
    if d.get("by_status"):
        click.echo("  status    " + "  ".join(
            f"{k} {v}" for k, v in sorted(d["by_status"].items())))
    if d.get("by_producer"):
        click.echo("  harness   " + "  ".join(
            f"{k} {v}" for k, v in sorted(d["by_producer"].items())))

    mix = d.get("coverage_mix") or {}
    share = d.get("coverage_share")
    click.echo("")
    # ⭐ The headline metric. A rising blind share is the platform going dark.
    click.echo("  COVERAGE MIX (the platform-health signal)")
    for k in ("measured", "partial", "blind"):
        pctv = f"  {share[k] * 100:5.1f}%" if share else ""
        click.echo(f"    {k:9s} {mix.get(k, 0):6d}{pctv}")
    if not share:
        # ⚠️ No measures at all is NOT "0% blind" — opposite conclusions.
        click.echo("    (no measures in this window — not the same as 0% blind)")

    c = d.get("critique") or {}
    click.echo("")
    click.echo("  CRITIQUE")
    click.echo(f"    avg rounds   {c.get('avg_rounds')}")
    rate = c.get("cap_hit_rate")
    # ⚠️ A rising cap-hit rate is a PROMPT defect (narrator and critic
    # systematically disagree), not a data problem.
    click.echo(f"    cap hits     {c.get('cap_hits')}"
               + (f"  ({rate * 100:.1f}% of runs)" if rate is not None else ""))

    dur = d.get("duration_ms") or {}
    click.echo("")
    click.echo(f"  duration  p50 {dur.get('p50')}ms   p95 {dur.get('p95')}ms")
    click.echo(f"  runs with unread sources  {d.get('runs_with_collector_errors')}")
    click.echo("")


@admin_ai_home.command(name="feedback")
@click.option("--days", default=90, show_default=True, type=int)
@click.pass_context
def admin_ai_home_feedback(ctx, days):
    """Feedback grouped by the prompt/schema version that produced the page.

    ⭐ This is how "did last week's prompt change help?" gets answered: feedback
    is joined to the config fingerprint that produced the page it rated.

    Examples:
      torana admin ai-home feedback
      torana admin ai-home feedback --days 30 --format json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    try:
        d = _client(ctx).get("admin/ai-home/feedback", params={"days": days})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml"):
        output(d, fmt=fmt, raw=raw, fields=fields)
        return

    click.echo("")
    click.echo(f"  window          last {d.get('window_days')} days")
    click.echo(f"  total feedback  {d.get('total_feedback')}")

    fps = d.get("by_fingerprint") or []
    if fps:
        click.echo("")
        click.echo("  BY PROMPT VERSION")
        for f in fps:
            sc = f.get("score")
            click.echo(f"    {str(f.get('prompt_hash'))[:34]:34s} "
                       f"+{f.get('up')} -{f.get('down')}"
                       + (f"   score {sc:+.2f}" if sc is not None else "   (unrated)"))

    zones = d.get("by_zone") or {}
    if zones:
        click.echo("")
        # ⚠️ Zone-level, because "the questions are useless but the blind block
        # is the best thing here" is actionable and a page thumb is not.
        click.echo("  BY ZONE")
        for z, v in sorted(zones.items()):
            click.echo(f"    {z:6s} +{v.get('up')} -{v.get('down')}")
    click.echo("")
