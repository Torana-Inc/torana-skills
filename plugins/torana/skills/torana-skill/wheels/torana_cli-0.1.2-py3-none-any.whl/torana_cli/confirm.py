"""Confirmation that fails LOUDLY when there is nobody to answer it.

⛔ THE DEFECT THIS CLOSES. `click.confirm(..., abort=True)` with no usable stdin aborts —
which is SAFE (nothing destructive runs) but USELESS, because the caller cannot tell why.
Measured 2026-08-28 on a minimal reproduction, no Torana code involved:

    exit_code : 1
    output    : "Aborted!\\nAre you sure? [y/N]:"
    exception : SystemExit

A human sees a half-rendered prompt. An automated caller sees exit 1 and a bare "Aborted!",
retries the identical command, hits the identical abort, and burns its budget — the exact
stall pattern already measured on this platform, where a refusal whose message the caller
cannot act on turns a wrong answer into an expensive loop.

⭐ THE FIX IS A BETTER ERROR, NOT AN AUTOMATIC YES. This never answers on the caller's
behalf. It refuses with a message naming the flag that would have worked, and a dedicated
exit code so a caller can branch without parsing prose. Auto-answering `yes` for an
unattended caller is how a destructive verb runs with nobody watching.

⚠️ WHY THIS LIVES IN THE CLI AND THE ALLOWLIST DOES NOT. The test is: would a laptop user
piping this CLI in a shell script want the same behaviour? For "I cannot prompt without a
TTY" — yes: a cron job, a CI step and a pipeline all want it. For "this command is not
permitted for you" — no, that is caller-specific policy and belongs in the calling service.
See STREAM_CLI_TOOL_POC.md § G.
"""
from __future__ import annotations

import sys
from contextvars import ContextVar


import click

#: Exit code for "a confirmation was required and could not be obtained".
#:
#: Deliberately NOT 1. Click's own `abort=True` exits 1, and so does almost every other
#: failure, so 1 tells a caller nothing. 125 is unused by this CLI and distinct from
#: 126 (which pantheon-admin's runner uses for "refused before execution") — so a caller
#: can branch on the number alone and never parse the message.
EXIT_CONFIRMATION_UNAVAILABLE = 125

# ⛔ A ContextVar, deliberately NOT an environment variable, and NOT an isatty() sniff.
#
# Not an env var: `os.environ` is process-global, and a host embedding this CLI (see
# pantheon-admin's cli_runner) is multi-worker and serves concurrent tenants — a global
# would race across requests. Mirrors `client/auth.py`'s injected-token ContextVar.
#
# ⚠️ NOT isatty(): the obvious test, `sys.stdin.isatty()`, is ALSO false for an ordinary
# shell pipeline (`echo y | torana …`, a cron job, a CI step). Sniffing the TTY would
# silently change behaviour for people scripting this CLI today. So non-interactivity is
# something the EMBEDDER declares, never something we infer. A plain terminal user is
# unaffected because nothing sets it.
_non_interactive: ContextVar[bool] = ContextVar("torana_non_interactive", default=False)


def set_non_interactive(value: bool = True):
    """Declare that no human can answer a prompt in this context. Returns the reset token.

    A host process (e.g. an agent-facing runner) calls this before invoking the CLI and
    resets it after:

        tok = set_non_interactive(True)
        try:
            ...invoke the CLI...
        finally:
            reset_non_interactive(tok)
    """
    return _non_interactive.set(bool(value))


def reset_non_interactive(token) -> None:
    """Restore the previous value. Always call this in a `finally`."""
    try:
        _non_interactive.reset(token)
    except (ValueError, LookupError):  # set in a different context — nothing to restore
        pass


def is_non_interactive() -> bool:
    """True when a prompt cannot be answered here.

    Declared mode wins. Otherwise fall back to "stdin is not readable at all", which is a
    genuinely unanswerable prompt (no stdin object, or it is closed) rather than the merely
    non-TTY case a pipeline produces.
    """
    if _non_interactive.get():
        return True
    stdin = getattr(sys, "stdin", None)
    if stdin is None:
        return True
    try:
        return bool(stdin.closed)
    except Exception:  # noqa: BLE001 — an exotic stdin is not our problem to diagnose
        return False


def confirm(
    message: str,
    *,
    yes: bool = False,
    flag: str = "--yes",
    abort: bool = True,
    default: bool = False,
) -> bool:
    """Ask for confirmation, or fail with an actionable error when nobody can answer.

    Three paths:
      1. `yes=True`               → proceed silently (the caller already decided).
      2. a human can answer       → `click.confirm`, behaviour unchanged.
      3. nobody can answer        → raise `ClickException` naming `flag`, exit code 125.

    Args:
        message: The question, e.g. "Delete workspace X?".
        yes:     The command's own `--yes/-y` flag value.
        flag:    The flag to name in the error — override when it is not `--yes`.
        abort:   Abort on a "no" answer (Click's default for destructive commands).
        default: Default answer at an interactive prompt.
    """
    if yes:
        return True

    if is_non_interactive():
        raise ConfirmationUnavailable(message=message, flag=flag)

    return click.confirm(message, abort=abort, default=default)


class ConfirmationUnavailable(click.ClickException):
    """Raised when confirmation is required but no one can give it.

    ⭐ Carries its own exit code so a caller branches on a NUMBER, not on prose. The
    message names the specific flag that would have worked — an agent that reads it can
    act, where Click's bare "Aborted!" left it with nothing to do but retry.
    """

    exit_code = EXIT_CONFIRMATION_UNAVAILABLE

    def __init__(self, *, message: str, flag: str = "--yes"):
        self.prompt = message
        self.flag = flag
        super().__init__(
            f"Cannot prompt for confirmation in non-interactive mode: {message!r}\n"
            f"Re-run with {flag} to proceed, or run this command interactively.\n"
            f"Nothing was changed."
        )
