"""torana service — cross-cutting service health, metrics, tracing, and version commands.

These endpoints exist on every Pantheon service. The `service` group provides
a unified interface to query them without needing admin privileges.

Available services: auth, detection, agents, programs, workflows, integrations,
                    datalake, transformers, viz, rag, admin
"""

import json

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm


# Path prefix for each service (as routed through nginx)
_SERVICE_PREFIXES = {
    "auth": "auth",
    "detection": "detection",
    "agents": "agents",
    "programs": "programs",
    "workflows": "workflows",
    "integrations": "integrations",
    "datalake": "datalake",
    "transformers": "transformers",
    "viz": "viz",
    "rag": "rag",
    "admin": "admin",
}

_ALL_SERVICES = sorted(_SERVICE_PREFIXES.keys())


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group()
def service():
    """Cross-cutting service commands: health, metrics, tracing, version.

    These endpoints exist on every Pantheon service. Omit --service to
    query all services at once.

    \b
    Examples:
      torana service health
      torana service health --service detection
      torana service metrics --service agents
      torana service version
      torana service tracing status --service workflows
    """


# ── health ────────────────────────────────────────────────────────────────────

@service.command(name="health")
@click.option(
    "--service", "svc",
    default=None,
    type=click.Choice(_ALL_SERVICES, case_sensitive=False),
    help="Specific service to check (default: all services).",
)
@click.option(
    "--check",
    default=None,
    type=click.Choice(["liveness", "readiness"], case_sensitive=False),
    help="Specific health check type (default: general health).",
)
@click.pass_context
def service_health(ctx, svc, check):
    """Check health status of one or all services.

    \b
    Examples:
      torana service health
      torana service health --service detection
      torana service health --service agents --check liveness
      torana service health --service programs --check readiness
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)

    if svc:
        prefix = _SERVICE_PREFIXES[svc]
        if check:
            path = f"{prefix}/health/{check}"
        else:
            path = f"{prefix}/health"
        try:
            data = client.get(path)
        except APIError as e:
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return

        if fmt != "text":
            output(data, fmt=fmt)
        else:
            _print_health(svc, data)
    else:
        # Query all services
        results = {}
        for name, prefix in _SERVICE_PREFIXES.items():
            path = f"{prefix}/health/{check}" if check else f"{prefix}/health"
            try:
                results[name] = client.get(path)
            except (APIError, AuthError, Exception) as e:
                results[name] = {"status": "unavailable", "error": str(e)}

        if fmt != "text":
            output(results, fmt=fmt)
        else:
            for name, data in results.items():
                _print_health(name, data)


def _print_health(name: str, data):
    if isinstance(data, dict):
        status = data.get("status", data.get("health", data.get("state", "unknown")))
        icon = "✓" if str(status).lower() in ("ok", "healthy", "up", "running") else "✗"
        click.echo(f"  {icon} {name:<20} {status}")
        for k, v in data.items():
            if k not in ("status", "health", "state"):
                click.echo(f"      {k}: {v}")
    else:
        click.echo(f"  {name:<20} {data}")


# ── metrics ───────────────────────────────────────────────────────────────────

@service.command(name="metrics")
@click.option(
    "--service", "svc",
    required=True,
    type=click.Choice(_ALL_SERVICES, case_sensitive=False),
    help="Service to query metrics from.",
)
@click.option(
    "--type",
    "metric_type",
    default=None,
    type=click.Choice(
        ["summary", "data-lake", "llm", "service-clients", "logging-config"],
        case_sensitive=False,
    ),
    help="Metric category (default: summary).",
)
@click.pass_context
def service_metrics(ctx, svc, metric_type):
    """View metrics for a specific service.

    \b
    Examples:
      torana service metrics --service detection
      torana service metrics --service agents --type llm
      torana service metrics --service transformers --type data-lake
      torana service metrics --service detection --type service-clients
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    prefix = _SERVICE_PREFIXES[svc]
    if metric_type:
        path = f"{prefix}/metrics/{metric_type}"
    else:
        path = f"{prefix}/metrics/summary"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ── version ───────────────────────────────────────────────────────────────────

@service.command(name="version")
@click.option(
    "--service", "svc",
    default=None,
    type=click.Choice(_ALL_SERVICES, case_sensitive=False),
    help="Specific service to check (default: all services).",
)
@click.pass_context
def service_version(ctx, svc):
    """Show version information for one or all services.

    \b
    Examples:
      torana service version
      torana service version --service detection
      torana service version --service agents --format json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)

    if svc:
        prefix = _SERVICE_PREFIXES[svc]
        try:
            data = client.get(f"{prefix}/version")
        except APIError as e:
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return

        if fmt != "text":
            output(data, fmt=fmt)
        else:
            ver = (data.get("version", data.get("app_version", str(data)))
                   if isinstance(data, dict) else str(data))
            click.echo(f"  {svc}: {ver}")
    else:
        results = {}
        for name, prefix in _SERVICE_PREFIXES.items():
            try:
                data = client.get(f"{prefix}/version")
                if isinstance(data, dict):
                    results[name] = data.get("version", data.get("app_version", data))
                else:
                    results[name] = str(data)
            except (APIError, AuthError, Exception):
                results[name] = "unavailable"

        if fmt != "text":
            output(results, fmt=fmt)
        else:
            click.echo("Service versions:")
            for name, ver in results.items():
                click.echo(f"  {name:<20} {ver}")


# ── tracing ───────────────────────────────────────────────────────────────────

@service.group(name="tracing")
def service_tracing():
    """Manage distributed tracing for a service.

    \b
    Examples:
      torana service tracing status --service detection
      torana service tracing enable --service agents
      torana service tracing disable --service agents
      torana service tracing info --service programs
    """


@service_tracing.command(name="fetch")
@click.argument("TRACE_ID", metavar="TRACE_ID")
@click.option(
    "--save", "save_file", default=None, metavar="FILE",
    help="Write the raw trace JSON to FILE instead of printing it. This is the same "
         "format the Jaeger trace analyzer reads (analyze_jaeger_llm_latency.py --analyze FILE).",
)
@click.pass_context
def tracing_fetch(ctx, trace_id, save_file):
    """Fetch a distributed trace by ID (via the authenticated Jaeger proxy).

    Retrieves the full trace — every span, tag, and log — through
    GET /api/v1/jaeger/api/traces/{TRACE_ID}. The payload is the exact
    {"data":[{"traceID","spans":[...]}]} shape the Jaeger trace analyzer consumes,
    so a saved file feeds straight into:

        python analyze_jaeger_llm_latency.py --analyze FILE --knob summary

    \b
    Examples:
      # Save the raw trace to a file, then analyze it offline
      torana service tracing fetch c04229eb3e121a8aad06c50c6c908f35 --save trace.json

    \b
      # Print the trace JSON to stdout (pipe into jq or the analyzer's stdin mode)
      torana service tracing fetch c04229eb3e121a8aad06c50c6c908f35 --json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)

    try:
        data = client.get(f"jaeger/api/traces/{trace_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # A trace that doesn't exist comes back as an empty data array (HTTP 200).
    if not isinstance(data, dict) or not data.get("data"):
        click.echo(f"Trace not found or empty: {trace_id}", err=True)
        raise click.exceptions.Exit(3)

    if save_file:
        try:
            with open(save_file, "w") as f:
                json.dump(data, f)
        except OSError as e:
            click.echo(f"Error writing {save_file}: {e}", err=True)
            raise click.exceptions.Exit(1)
        n_spans = len(data["data"][0].get("spans", []))
        click.echo(f"Trace {trace_id} saved to {save_file} ({n_spans} spans)")
        click.echo(
            f"Analyze it with: python analyze_jaeger_llm_latency.py --analyze {save_file} --knob summary"
        )
        return

    # No --save: emit the raw JSON. Force json unless the user asked for yaml.
    output(data, fmt=fmt if fmt in ("json", "yaml") else "json")


@service_tracing.command(name="status")
@click.option(
    "--service", "svc",
    required=True,
    type=click.Choice(_ALL_SERVICES, case_sensitive=False),
    help="Service to query.",
)
@click.pass_context
def tracing_status(ctx, svc):
    """Show current tracing status for a service."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    prefix = _SERVICE_PREFIXES[svc]
    client = _client(ctx)
    try:
        data = client.get(f"{prefix}/tracing/status")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        if isinstance(data, dict):
            enabled = data.get("enabled", data.get("tracing_enabled", "unknown"))
            click.echo(f"  {svc}: tracing={'enabled' if enabled else 'disabled'}")
            for k, v in data.items():
                if k not in ("enabled", "tracing_enabled"):
                    click.echo(f"    {k}: {v}")
        else:
            click.echo(f"  {svc}: {data}")


@service_tracing.command(name="enable")
@click.option(
    "--service", "svc",
    required=True,
    type=click.Choice(_ALL_SERVICES, case_sensitive=False),
    help="Service to enable tracing on.",
)
@click.pass_context
def tracing_enable(ctx, svc):
    """Enable distributed tracing for a service."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    prefix = _SERVICE_PREFIXES[svc]
    client = _client(ctx)
    try:
        data = client.post(f"{prefix}/tracing/enable", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Tracing enabled for {svc}.")


@service_tracing.command(name="disable")
@click.option(
    "--service", "svc",
    required=True,
    type=click.Choice(_ALL_SERVICES, case_sensitive=False),
    help="Service to disable tracing on.",
)
@click.pass_context
def tracing_disable(ctx, svc):
    """Disable distributed tracing for a service."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    prefix = _SERVICE_PREFIXES[svc]
    client = _client(ctx)
    try:
        data = client.post(f"{prefix}/tracing/disable", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Tracing disabled for {svc}.")


@service_tracing.command(name="info")
@click.option(
    "--service", "svc",
    required=True,
    type=click.Choice(_ALL_SERVICES, case_sensitive=False),
    help="Service to query.",
)
@click.pass_context
def tracing_info(ctx, svc):
    """Show detailed tracing configuration for a service."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    prefix = _SERVICE_PREFIXES[svc]
    client = _client(ctx)
    try:
        data = client.get(f"{prefix}/tracing/info")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@service.command(name="list")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def resource_list(ctx, page, page_size, fetch_all):
    """Root."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = ""
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@service.command(name="service")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with request body. Use '-' for stdin.")
@click.option("--service-name", "service_name", required=True, help="Name of the service registering")
@click.option("--service-version", "service_version", required=True, help="Version of the service")
@click.option("--api-spec", "api_spec", required=True, help="OpenAPI specification")
@click.option("--base-url", "base_url", required=True, help="Base URL for the service API")
@click.option("--capabilities", "capabilities", default=None, help="Service capabilities")
@click.option("--tags", "tags", default=None, help="Service tags")
@click.pass_context
def register_service(ctx, service_name, service_version, api_spec, base_url, capabilities, tags, input_file):
    """Register Service."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "register/service"
    if input_file:
        body = _load_input_file(input_file)
    else:
        body = {}
        body["service_name"] = service_name
        body["service_version"] = service_version
        body["api_spec"] = api_spec
        body["base_url"] = base_url
        if capabilities is not None:
            body["capabilities"] = capabilities
        if tags is not None:
            body["tags"] = tags

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ──────────────────────────────────────────────────────────────────────────
# Instance reads regrouped from `<noun>-by-<param>` leaves onto verbs
# (CLI Discoverability Contract, rule 2 — see ../CLAUDE.md). The route
# parameter belongs in the positional ARGUMENT, not the command name.
#
# Old flat names remain as HIDDEN aliases for ONE release (D4).
# ──────────────────────────────────────────────────────────────────────────


@service.group(name="registration")
def service_registration_grp():
    """Service registration entries.

    Examples:
      torana service registration unregister --help
    """


@service_registration_grp.command(name="unregister")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("SERVICE_NAME", metavar="SERVICE_NAME")
@click.pass_context
def register_service_by_service_name(ctx, service_name, yes):
    """Unregister Service."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"register/service/{service_name}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@service.command(name="services")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def register_services(ctx, page, page_size, fetch_all):
    """List Registered Services."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "register/services"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@service.command(name="options")
@click.argument("PATH", metavar="PATH")
@click.pass_context
def jaeger_path__options(ctx, path):
    """Jaeger Proxy."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"jaeger{path}"

    client = _client(ctx)
    try:
        data = client.get(path)  # TODO: OPTIONS
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@service.command(name="create")
@click.argument("PATH", metavar="PATH")
@click.pass_context
def jaeger_path__create(ctx, path):
    """Jaeger Proxy."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"jaeger{path}"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@service.command(name="update")
@click.argument("PATH", metavar="PATH")
@click.pass_context
def jaeger_path__update(ctx, path):
    """Jaeger Proxy."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"jaeger{path}"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@service.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("PATH", metavar="PATH")
@click.pass_context
def jaeger_path__delete(ctx, path, yes):
    """Jaeger Proxy."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"jaeger{path}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@service.command(name="jaeger-proxy")
@click.argument("PATH", metavar="PATH")
@click.pass_context
def service_jaeger_proxy(ctx, path):
    """Jaeger Proxy."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"jaeger{path}"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@service.command(name="connections")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def services_connections(ctx, page, page_size, fetch_all):
    """Get Database Connections."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "services/database/connections"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@service.command(name="tables")
@click.argument("SERVICE_NAME", metavar="SERVICE_NAME")
@click.pass_context
def services_tables(ctx, service_name):
    """Get Tables for Service."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"services/{service_name}/tables"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@service.command(name="schema")
@click.argument("SERVICE_NAME", metavar="SERVICE_NAME")
@click.argument("TABLE_NAME", metavar="TABLE_NAME")
@click.pass_context
def services_schema(ctx, service_name, table_name):
    """Get Service Table Schema."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"services/{service_name}/tables/{table_name}/schema"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@service.command(name="data")
@click.argument("SERVICE_NAME", metavar="SERVICE_NAME")
@click.argument("TABLE_NAME", metavar="TABLE_NAME")
@click.option("--limit", "limit", type=int, default=50, help="Maximum number of records to return")
@click.option("--cursor", "cursor", default=None, help="Cursor for pagination")
@click.option("--order-by", "order_by", default=None, help="Ordering fields (e.g., 'created_at:desc,name:asc')")
@click.option("--count", "count", type=bool, default=False, help="Include total count (expensive operation)")
@click.pass_context
def services_data(ctx, service_name, table_name, limit, cursor, order_by, count):
    """Get Service Table Data."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"services/{service_name}/tables/{table_name}/data"
    params = {}
    if limit is not None:
        params["limit"] = limit
    if cursor is not None:
        params["cursor"] = cursor
    if order_by is not None:
        params["order_by"] = order_by
    if count is not None:
        params["count"] = count

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ──────────────────────────────────────────────────────────────────────────
# BACK-COMPAT — hidden aliases for the old `<noun>-by-<param>` names.
# ⏳ ONE RELEASE ONLY (decision D4). Delete this block next release.
# ──────────────────────────────────────────────────────────────────────────

_LEGACY_BY_PARAM_SERVICE = {
    "service-by-service-name": ("registration", "unregister"),
}


def _register_legacy_service_by_param() -> None:
    """Old flat names, hidden so they cannot be discovered anew."""
    import copy
    for _old, (_sub, _verb) in _LEGACY_BY_PARAM_SERVICE.items():
        _grp = service.commands.get(_sub)
        if not isinstance(_grp, click.Group):
            continue
        _cmd = _grp.commands.get(_verb)
        if _cmd is None:
            continue
        # ⛔ Never let an alias overwrite a real group of the same name.
        if isinstance(service.commands.get(_old), click.Group):
            continue
        _alias = copy.copy(_cmd)
        _alias.name = _old
        _alias.hidden = True
        service.add_command(_alias)


_register_legacy_service_by_param()
