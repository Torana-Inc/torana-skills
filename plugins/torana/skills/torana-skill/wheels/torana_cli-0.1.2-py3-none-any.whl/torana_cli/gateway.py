"""torana gateway — API gateway management commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FORMAT, CTX_PROFILE, CTX_RAW, CTX_FIELDS
from torana_cli.output import output
from torana_cli.confirm import confirm as _confirm


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group()
def gateway():
    """API gateway operations.

    \b
    Examples:
      torana gateway stats
      torana gateway health
      torana gateway stats --metric requests
    """


@gateway.command(name="stats")
@click.option("--metric", default=None,
              type=click.Choice(["requests", "performance", "errors", "usage", "overview"],
                                case_sensitive=False),
              help="Specific metric category to retrieve.")
@click.pass_context
def gateway_stats(ctx, metric):
    """View API gateway statistics.

    \b
    Examples:
      torana gateway stats
      torana gateway stats --metric requests
      torana gateway stats --metric errors
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        if metric:
            data = client.get(f"gateway/stats/{metric}/")
        else:
            data = client.get("gateway/stats/overview/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@gateway.command(name="health")
@click.pass_context
def gateway_health(ctx):
    """Check API gateway health."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get("gateway/health/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        if isinstance(data, dict):
            status = data.get("status", data.get("health", "unknown"))
            click.echo(f"Gateway: {status}")
            for k, v in data.items():
                if k not in ("status", "health"):
                    click.echo(f"  {k}: {v}")
        else:
            click.echo(str(data))


@gateway.command(name="proxy")
@click.option("--method", default="GET",
              type=click.Choice(["GET", "POST", "PUT", "DELETE", "PATCH"],
                                case_sensitive=False))
@click.option("--path", required=True, help="API path to proxy.")
@click.option("--body", default=None, metavar="JSON", help="Request body JSON.")
@click.pass_context
def gateway_proxy(ctx, method, path, body):
    """Proxy a raw request through the API gateway.

    \b
    Example:
      torana gateway proxy --path /api/v1/rules/ --method GET
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        params_body = None
        if body:
            import json
            try:
                params_body = json.loads(body)
            except json.JSONDecodeError as exc:
                click.echo(f"ERROR: Invalid JSON in --body: {exc}", err=True)
                import sys
                sys.exit(6)

        method_upper = method.upper()
        if method_upper == "GET":
            data = client.get(path.lstrip("/"))
        elif method_upper == "POST":
            data = client.post(path.lstrip("/"), json=params_body or {})
        elif method_upper == "PUT":
            data = client.put(path.lstrip("/"), json=params_body or {})
        elif method_upper == "DELETE":
            data = client.delete(path.lstrip("/"))
        else:
            data = client.get(path.lstrip("/"))
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt if fmt != "text" else "json")


@gateway.command(name="update")
@click.argument("API_ID", metavar="API_ID")
@click.argument("PATH", metavar="PATH")
@click.pass_context
def proxy_update(ctx, api_id, path):
    """Proxy authenticated API request."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"proxy/{api_id}/{path}"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@gateway.command(name="create")
@click.argument("API_ID", metavar="API_ID")
@click.argument("PATH", metavar="PATH")
@click.pass_context
def proxy_create(ctx, api_id, path):
    """Proxy authenticated API request."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"proxy/{api_id}/{path}"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@gateway.command(name="options")
@click.argument("API_ID", metavar="API_ID")
@click.argument("PATH", metavar="PATH")
@click.pass_context
def proxy_options(ctx, api_id, path):
    """Proxy authenticated API request."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"proxy/{api_id}/{path}"

    client = _client(ctx)
    try:
        data = client.get(path)  # TODO: OPTIONS
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@gateway.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("API_ID", metavar="API_ID")
@click.argument("PATH", metavar="PATH")
@click.pass_context
def proxy_delete(ctx, api_id, path, yes):
    """Proxy authenticated API request."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"proxy/{api_id}/{path}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@gateway.command(name="get")
@click.argument("API_ID", metavar="API_ID")
@click.argument("PATH", metavar="PATH")
@click.pass_context
def proxy_get(ctx, api_id, path):
    """Proxy authenticated API request."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"proxy/{api_id}/{path}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@gateway.command(name="head")
@click.argument("API_ID", metavar="API_ID")
@click.argument("PATH", metavar="PATH")
@click.pass_context
def proxy_head(ctx, api_id, path):
    """Proxy authenticated API request."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"proxy/{api_id}/{path}"

    client = _client(ctx)
    try:
        data = client.get(path)  # TODO: HEAD
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ──────────────────────────────────────────────────────────────────────────
# Instance reads regrouped from `<noun>-by-<param>` leaves onto verbs
# (CLI Discoverability Contract, rule 2 — see ../CLAUDE.md). The route
# parameter belongs in the positional ARGUMENT, not the command name.
#
# Old flat names remain as HIDDEN aliases for ONE release (D4).
# ──────────────────────────────────────────────────────────────────────────


@gateway.group(name="openapi")
def gateway_openapi_grp():
    """OpenAPI spec for a proxied API.

    Examples:
      torana gateway openapi get --help
    """


@gateway_openapi_grp.command(name="get")
@click.argument("API_ID", metavar="API_ID")
@click.pass_context
def proxy_openapi_by_api_id(ctx, api_id):
    """Get modified OpenAPI spec for API."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"proxy/openapi/{api_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ─────────────────────────────────────────────────────────────────────────────
# SDG admin proxy — `gateway admin proxy <method> <PATH>`.
#
# Regrouped from the flat `admin-by-path` / `admin-proxy-post` / `admin-proxy-get`
# / `admin-proxy-delete` / `admin-proxy-post-2` leaves (CLI Discoverability
# Contract, rule 2). Here the HTTP method IS the domain verb — a proxy passes
# methods through — so `proxy post` is correct noun-verb, not a leaked method.
#
# ⚠️ `admin-by-path`, `admin-proxy-post` and `admin-proxy-post-2` were THREE
# byte-identical POST commands (generator collisions, not capabilities). They
# collapse to the single `proxy post` below; all three old names still resolve
# via the hidden aliases at the foot of this file.
# ─────────────────────────────────────────────────────────────────────────────


@gateway.group(name="admin")
def gateway_admin():
    """SDG admin operations (super admin only)."""


@gateway_admin.group(name="proxy")
def gateway_admin_proxy():
    """Proxy an SDG admin request. The HTTP method is the verb.

    Examples:
      torana gateway admin proxy get datasets
      torana gateway admin proxy post datasets/reseed
      torana gateway admin proxy delete datasets/abc --yes
    """


@gateway_admin_proxy.command(name="post")
@click.argument("PATH", metavar="PATH")
@click.pass_context
def sdg_admin_by_path(ctx, path):
    """POST an SDG admin request (super admin only)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"sdg/admin/{path}"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@gateway_admin_proxy.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("PATH", metavar="PATH")
@click.pass_context
def gateway_admin_proxy_delete(ctx, path, yes):
    """Proxy an SDG admin request (super admin only)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"sdg/admin/{path}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@gateway_admin_proxy.command(name="get")
@click.argument("PATH", metavar="PATH")
@click.pass_context
def gateway_admin_proxy_get(ctx, path):
    """Proxy an SDG admin request (super admin only)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"sdg/admin/{path}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@gateway.command(name="list")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def stats_list(ctx, page, page_size, fetch_all):
    """Get API Gateway statistics."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "stats"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@gateway.command(name="requests")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--limit", "limit", type=int, default=100, help="Number of recent requests to return")
@click.pass_context
def stats_requests(ctx, limit, page, page_size, fetch_all):
    """Get recent request logs."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "stats/requests"
    params = {}
    if limit is not None:
        params["limit"] = limit
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@gateway.command(name="overview")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def stats_overview(ctx, page, page_size, fetch_all):
    """Get quick stats overview."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "stats/overview"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@gateway.command(name="performance")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def stats_performance(ctx, page, page_size, fetch_all):
    """Get performance metrics."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "stats/performance"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@gateway.command(name="errors")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def stats_errors(ctx, page, page_size, fetch_all):
    """Get error statistics."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "stats/errors"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@gateway.command(name="usage")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def stats_usage(ctx, page, page_size, fetch_all):
    """Get usage statistics."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "stats/usage"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


# ─────────────────────────────────────────────────────────────────────────────
# BACK-COMPAT — hidden aliases for the flat names the SDG admin proxy used to
# have. ⏳ ONE RELEASE ONLY (decision D4): scripts pinned to the old names keep
# working, `hidden=True` keeps them out of --help so nobody learns them anew.
# Delete this block next release.
#
# ⚠️ `admin-by-path`, `admin-proxy-post` and `admin-proxy-post-2` were three
# byte-identical POST commands; all three now forward to the single `proxy post`.
# ─────────────────────────────────────────────────────────────────────────────

_LEGACY_GATEWAY_ALIASES = {
    "admin-by-path": "post",
    "admin-proxy-post": "post",
    "admin-proxy-post-2": "post",
    "admin-proxy-get": "get",
    "admin-proxy-delete": "delete",
}

# `proxy-post` was byte-identical to the `create` leaf (same args, same
# POST to proxy/{api_id}/{path}) — another generator duplicate, not a
# capability. It now forwards to `create`.
_LEGACY_GATEWAY_TOP_ALIASES = {"proxy-post": "create"}


def _register_legacy_gateway_aliases() -> None:
    """Re-register each regrouped proxy command under its OLD flat name, hidden."""
    import copy
    for _old, _verb in _LEGACY_GATEWAY_ALIASES.items():
        _cmd = gateway_admin_proxy.commands.get(_verb)
        if _cmd is None:
            continue
        _alias = copy.copy(_cmd)
        _alias.name = _old
        _alias.hidden = True
        gateway.add_command(_alias)


_register_legacy_gateway_aliases()


def _register_legacy_gateway_top_aliases() -> None:
    import copy
    for _old, _target in _LEGACY_GATEWAY_TOP_ALIASES.items():
        _cmd = gateway.commands.get(_target)
        if _cmd is None:
            continue
        _alias = copy.copy(_cmd)
        _alias.name = _old
        _alias.hidden = True
        gateway.add_command(_alias)


_register_legacy_gateway_top_aliases()


# ──────────────────────────────────────────────────────────────────────────
# BACK-COMPAT — hidden aliases for the old `<noun>-by-<param>` names.
# ⏳ ONE RELEASE ONLY (decision D4). Delete this block next release.
# ──────────────────────────────────────────────────────────────────────────

_LEGACY_BY_PARAM_GATEWAY = {
    "openapi-by-api-id": ("openapi", "get"),
}


def _register_legacy_gateway_by_param() -> None:
    """Old flat names, hidden so they cannot be discovered anew."""
    import copy
    for _old, (_sub, _verb) in _LEGACY_BY_PARAM_GATEWAY.items():
        _grp = gateway.commands.get(_sub)
        if not isinstance(_grp, click.Group):
            continue
        _cmd = _grp.commands.get(_verb)
        if _cmd is None:
            continue
        # ⛔ Never let an alias overwrite a real group of the same name.
        if isinstance(gateway.commands.get(_old), click.Group):
            continue
        _alias = copy.copy(_cmd)
        _alias.name = _old
        _alias.hidden = True
        gateway.add_command(_alias)


_register_legacy_gateway_by_param()
