"""Torana Security Platform CLI."""

try:
    from torana_cli._version import VERSION as __version__
except ImportError:
    __version__ = "0.1.0"

# Build identity (CLI-44). Sourced from _version.py, which build_version.py generates.
# ⚠️ Each field is read INDEPENDENTLY with its own fallback: a wheel built before these
# fields existed still has VERSION and COMMIT_SHA, and a single try/except around all
# four would silently blank the commit for those builds — reintroducing the exact
# "cannot tell which build this is" defect on the older wheels that need it most.
try:
    from torana_cli._version import COMMIT_SHA as __commit_sha__
except ImportError:
    __commit_sha__ = "unknown"

try:
    from torana_cli._version import DIRTY as __dirty__
except ImportError:
    __dirty__ = False

try:
    from torana_cli._version import BUILT_AT as __built_at__
except ImportError:
    __built_at__ = "unknown"
