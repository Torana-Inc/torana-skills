"""torana context-lake — context lake commands (memory, preferences, entity links, feedback)."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm

_MEMORY_COLS = [
    ("id", "ID", 36),
    ("content", "CONTENT", 60),
    ("memory_type", "TYPE", 15),
    ("created_at", "CREATED", 20),
]

_PREF_COLS = [
    ("id", "ID", 36),
    ("key", "KEY", 30),
    ("value", "VALUE", 40),
    ("updated_at", "UPDATED", 20),
]

_ENTITY_LINK_COLS = [
    ("id", "ID", 36),
    ("source_type", "SOURCE TYPE", 20),
    ("source_id", "SOURCE ID", 36),
    ("target_type", "TARGET TYPE", 20),
    ("target_id", "TARGET ID", 36),
    ("relationship", "RELATIONSHIP", 20),
]

_FEEDBACK_COLS = [
    ("id", "ID", 36),
    ("session_id", "SESSION_ID", 36),
    ("rating", "RATING", 8),
    ("comment", "COMMENT", 50),
    ("created_at", "CREATED", 20),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(name="context-lake")
def context_lake():
    """Context lake operations (memory, preferences, entity links, feedback).

    \b
    Examples:
      torana context-lake memory list
      torana context-lake preferences list
      torana context-lake entity-links list
      torana context-lake feedback list
    """


# ---------------------------------------------------------------------------
# memory sub-group
# ---------------------------------------------------------------------------

@context_lake.group(name="memory")
def cl_memory():
    """User memory operations.

    \b
    Examples:
      torana context-lake memory list
      torana context-lake memory get <UUID>
      torana context-lake memory create --content "User prefers dark mode"
      torana context-lake memory delete <UUID>
    """


@cl_memory.command(name="list")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def memory_list(ctx, page, page_size):
    """List memory entries."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        data = client.get("context-lake/memory/", params=params)
        result = data if isinstance(data, dict) and "items" in data else {
            "items": data if isinstance(data, list) else [],
            "total": len(data) if isinstance(data, list) else 0,
            "page": page, "page_size": effective_page_size
        }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_MEMORY_COLS)


@cl_memory.command(name="get")
@click.argument("memory_id", metavar="MEMORY_ID")
@click.pass_context
def memory_get(ctx, memory_id):
    """Get a specific memory entry."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(f"context-lake/memory/{memory_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@cl_memory.command(name="create")
@click.option("--content", required=True, help="Memory content text.")
@click.option("--type", "memory_type", default=None, help="Memory type.")
@click.pass_context
def memory_create(ctx, content, memory_type):
    """Create a memory entry."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {"content": content}
    if memory_type:
        body["memory_type"] = memory_type

    client = _client(ctx)
    try:
        data = client.post("context-lake/memory/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created memory: {data.get('id', 'unknown')}")


@cl_memory.command(name="delete")
@click.argument("memory_id", metavar="MEMORY_ID")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def memory_delete(ctx, memory_id, yes):
    """Delete a memory entry."""
    _confirm(f"Delete memory {memory_id}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"context-lake/memory/{memory_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted memory: {memory_id}")


# ---------------------------------------------------------------------------
# preferences sub-group
# ---------------------------------------------------------------------------

@context_lake.group(name="preferences")
def cl_preferences():
    """User preference operations.

    \b
    Examples:
      torana context-lake preferences list
      torana context-lake preferences get <KEY>
      torana context-lake preferences set --key theme --value dark
      torana context-lake preferences delete <KEY>
    """


@cl_preferences.command(name="list")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def preferences_list(ctx, page, page_size):
    """List user preferences."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        data = client.get("context-lake/preferences/", params=params)
        result = data if isinstance(data, dict) and "items" in data else {
            "items": data if isinstance(data, list) else [],
            "total": len(data) if isinstance(data, list) else 0,
            "page": page, "page_size": effective_page_size
        }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_PREF_COLS)


@cl_preferences.command(name="get")
@click.argument("key", metavar="KEY")
@click.pass_context
def preferences_get(ctx, key):
    """Get a specific preference by key."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(f"context-lake/preferences/{key}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@cl_preferences.command(name="set")
@click.option("--key", required=True, help="Preference key.")
@click.option("--value", required=True, help="Preference value.")
@click.pass_context
def preferences_set(ctx, key, value):
    """Set a user preference."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {"key": key, "value": value}

    client = _client(ctx)
    try:
        data = client.post("context-lake/preferences/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Set preference: {key} = {value}")


@cl_preferences.command(name="delete")
@click.argument("key", metavar="KEY")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def preferences_delete(ctx, key, yes):
    """Delete a user preference."""
    _confirm(f"Delete preference '{key}'?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"context-lake/preferences/{key}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted preference: {key}")


# ---------------------------------------------------------------------------
# entity-links sub-group
# ---------------------------------------------------------------------------

@context_lake.group(name="entity-links")
def cl_entity_links():
    """Entity link operations.

    \b
    Examples:
      torana context-lake entity-links list
      torana context-lake entity-links get <UUID>
      torana context-lake entity-links create --file link.yaml
      torana context-lake entity-links delete <UUID>
    """


@cl_entity_links.command(name="list")
@click.option("--source-type", default=None, help="Filter by source entity type.")
@click.option("--target-type", default=None, help="Filter by target entity type.")
@click.option("--relationship", default=None, help="Filter by relationship type.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def entity_links_list(ctx, source_type, target_type, relationship, page, page_size):
    """List entity links."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if source_type:
        params["source_type"] = source_type
    if target_type:
        params["target_type"] = target_type
    if relationship:
        params["relationship"] = relationship

    client = _client(ctx)
    try:
        data = client.get("context-lake/entity-links/", params=params)
        result = data if isinstance(data, dict) and "items" in data else {
            "items": data if isinstance(data, list) else [],
            "total": len(data) if isinstance(data, list) else 0,
            "page": page, "page_size": effective_page_size
        }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_ENTITY_LINK_COLS)


@cl_entity_links.command(name="get")
@click.argument("link_id", metavar="LINK_ID")
@click.pass_context
def entity_links_get(ctx, link_id):
    """Get a specific entity link."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(f"context-lake/entity-links/{link_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@cl_entity_links.command(name="create")
@click.option("--file", "input_file", default=None, metavar="FILE",
              help="YAML/JSON file with link definition.")
@click.pass_context
def entity_links_create(ctx, input_file):
    """Create an entity link (from file)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    if not input_file:
        click.echo("ERROR: --file is required.", err=True)
        import sys
        sys.exit(2)

    body = _load_input_file(input_file)

    client = _client(ctx)
    try:
        data = client.post("context-lake/entity-links/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created entity link: {data.get('id', 'unknown')}")


@cl_entity_links.command(name="delete")
@click.argument("link_id", metavar="LINK_ID")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def entity_links_delete(ctx, link_id, yes):
    """Delete an entity link."""
    _confirm(f"Delete entity link {link_id}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"context-lake/entity-links/{link_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted entity link: {link_id}")


# ---------------------------------------------------------------------------
# feedback sub-group
# ---------------------------------------------------------------------------

@context_lake.group(name="feedback")
def cl_feedback():
    """Feedback operations.

    \b
    Examples:
      torana context-lake feedback list
      torana context-lake feedback get <UUID>
      torana context-lake feedback submit --session-id <UUID> --rating 5
    """


@cl_feedback.command(name="list")
@click.option("--session-id", default=None, help="Filter by session UUID.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def feedback_list(ctx, session_id, page, page_size):
    """List feedback entries."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if session_id:
        params["session_id"] = session_id

    client = _client(ctx)
    try:
        data = client.get("context-lake/feedback/", params=params)
        result = data if isinstance(data, dict) and "items" in data else {
            "items": data if isinstance(data, list) else [],
            "total": len(data) if isinstance(data, list) else 0,
            "page": page, "page_size": effective_page_size
        }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_FEEDBACK_COLS)


@cl_feedback.command(name="get")
@click.argument("feedback_id", metavar="FEEDBACK_ID")
@click.pass_context
def feedback_get(ctx, feedback_id):
    """Get a specific feedback entry."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(f"context-lake/feedback/{feedback_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@cl_feedback.command(name="submit")
@click.option("--session-id", required=True, help="Session UUID.")
@click.option("--rating", type=click.IntRange(1, 5), required=True, help="Rating 1-5.")
@click.option("--comment", default=None, help="Optional comment.")
@click.pass_context
def feedback_submit(ctx, session_id, rating, comment):
    """Submit feedback for a session."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {"session_id": session_id, "rating": rating}
    if comment:
        body["comment"] = comment

    client = _client(ctx)
    try:
        data = client.post("context-lake/feedback/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Submitted feedback: {data.get('id', 'unknown')}")


# ──────────────────────────────────────────────────────────────────────────
# Admin / super-admin scopes — regrouped from flat `admin-*` / `superadmin-*`
# leaves into noun-verb sub-groups (CLI Discoverability Contract, rule 2).
#
# ⚠️ The old flat names remain registered as HIDDEN aliases for ONE release
# (decision D4) so scripts and CI jobs do not break mid-flight. They are
# hidden=True, so they do not appear in --help and cannot be discovered anew.
# Delete `_ALIASES` and the loop at the bottom of this file next release.
# ──────────────────────────────────────────────────────────────────────────


@context_lake.group(name="admin")
def cl_admin():
    """Tenant-admin Context Lake operations."""


@cl_admin.group(name="candidate-context")
def cl_admin_candidate_context():
    """Candidate context operations."""


@cl_admin.group(name="settings")
def cl_admin_settings():
    """Context Lake settings (tenant admin)."""


@cl_admin.group(name="entity-links")
def cl_admin_entity_links():
    """Entity links operations."""


@cl_admin.group(name="feedback")
def cl_admin_feedback():
    """Feedback operations."""


@cl_admin.group(name="memory")
def cl_admin_memory():
    """Memory operations."""


@cl_admin.group(name="org-memory")
def cl_admin_org_memory():
    """Org memory operations."""


@cl_admin.group(name="preferences")
def cl_admin_preferences():
    """Preferences operations."""


@cl_admin.group(name="session")
def cl_admin_session():
    """Session operations."""


@cl_admin.group(name="tenant-intelligence")
def cl_admin_tenant_intelligence():
    """Tenant intelligence operations."""


@context_lake.group(name="superadmin")
def cl_superadmin():
    """Super-admin Context Lake operations (cross-tenant)."""


@cl_superadmin.group(name="assembly")
def cl_superadmin_assembly():
    """Assembly operations."""


@cl_superadmin.group(name="candidate-context")
def cl_superadmin_candidate_context():
    """Candidate context operations."""


@cl_superadmin.group(name="domain-profile")
def cl_superadmin_domain_profile():
    """Domain profile operations."""


@cl_superadmin.group(name="entity-links")
def cl_superadmin_entity_links():
    """Entity links operations."""


@cl_superadmin.group(name="feedback")
def cl_superadmin_feedback():
    """Feedback operations."""


@cl_superadmin.group(name="injection")
def cl_superadmin_injection():
    """Injection operations."""


@cl_superadmin.group(name="memory")
def cl_superadmin_memory():
    """Memory operations."""


@cl_superadmin.group(name="org-memory")
def cl_superadmin_org_memory():
    """Org memory operations."""


@cl_superadmin.group(name="sessions")
def cl_superadmin_sessions():
    """Sessions operations."""


@cl_superadmin.group(name="settings")
def cl_superadmin_settings():
    """Settings operations."""


@cl_superadmin.group(name="tenant-intelligence")
def cl_superadmin_tenant_intelligence():
    """Tenant intelligence operations."""


@cl_superadmin.group(name="users")
def cl_superadmin_users():
    """Users operations."""


@context_lake.group(name="candidate-context")
def cl_candidate_context():
    """Candidate context — what WOULD be injected for a session."""


@context_lake.group(name="session-context")
def cl_session_context():
    """Per-session context reads (recall, entity context)."""


@context_lake.group(name="model-limits")
def cl_model_limits():
    """Model token-limit configuration."""


@context_lake.command(name="summary")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--hours", "hours", type=int, default=24, help="Lookback window in hours")
@click.option("--agent-id", "agent_id", default=None, help="Filter by agent ID")
@click.option("--model-name", "model_name", default=None, help="Filter by model name")
@click.option("--limit", "limit", type=int, default=50, help="Max entries to return")
@click.pass_context
def context_lake_summary(ctx, hours, agent_id, model_name, limit, page, page_size, fetch_all):
    """Get Context Utilization Summary."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/utilization/summary"
    params = {}
    if hours is not None:
        params["hours"] = hours
    if agent_id is not None:
        params["agent_id"] = agent_id
    if model_name is not None:
        params["model_name"] = model_name
    if limit is not None:
        params["limit"] = limit
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@cl_model_limits.command(name="list")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--provider", "provider", default=None, help="Filter by provider")
@click.option("--is-active", "is_active", default=None, help="Filter by active status")
@click.option("--limit", "limit", type=int, default=100, help="Max results to return")
@click.pass_context
def context_lake_model_limits(ctx, provider, is_active, limit, page, page_size, fetch_all):
    """List Model Limits."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/model-limits"
    params = {}
    if provider is not None:
        params["provider"] = provider
    if is_active is not None:
        params["is_active"] = is_active
    if limit is not None:
        params["limit"] = limit
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@cl_model_limits.command(name="create")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with request body. Use '-' for stdin.")
@click.option("--model-name", "model_name", required=True)
@click.option("--provider", "provider", required=True)
@click.option("--max-input-tokens", "max_input_tokens", type=int, required=True)
@click.option("--max-output-tokens", "max_output_tokens", type=int, required=True)
@click.option("--max-total-tokens", "max_total_tokens", type=int, required=True)
@click.option("--is-active", "is_active", type=bool, default=True)
@click.pass_context
def context_lake_create_model_limit(ctx, model_name, provider, max_input_tokens, max_output_tokens, max_total_tokens, is_active, input_file):
    """Create Model Limit."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "context-lake/model-limits"
    if input_file:
        body = _load_input_file(input_file)
    else:
        body = {}
        body["model_name"] = model_name
        body["provider"] = provider
        body["max_input_tokens"] = max_input_tokens
        body["max_output_tokens"] = max_output_tokens
        body["max_total_tokens"] = max_total_tokens
        if is_active is not None:
            body["is_active"] = is_active

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_model_limits.command(name="get")
@click.argument("MODEL_NAME", metavar="MODEL_NAME")
@click.option("--provider", "provider", default=None, help="Provider filter")
@click.pass_context
def context_lake_model_limits_by_model_name(ctx, model_name, provider):
    """Get Model Limit."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/model-limits/{model_name}"
    params = {}
    if provider is not None:
        params["provider"] = provider

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_model_limits.command(name="update")
@click.argument("LIMIT_ID", metavar="LIMIT_ID")
@click.option("--max-input-tokens", "max_input_tokens", default=None)
@click.option("--max-output-tokens", "max_output_tokens", default=None)
@click.option("--max-total-tokens", "max_total_tokens", default=None)
@click.option("--is-active", "is_active", default=None)
@click.pass_context
def context_lake_model_limits_by_limit_id(ctx, limit_id, max_input_tokens, max_output_tokens, max_total_tokens, is_active):
    """Update Model Limit."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/model-limits/{limit_id}"
    body = {}
    if max_input_tokens is not None:
        body["max_input_tokens"] = max_input_tokens
    if max_output_tokens is not None:
        body["max_output_tokens"] = max_output_tokens
    if max_total_tokens is not None:
        body["max_total_tokens"] = max_total_tokens
    if is_active is not None:
        body["is_active"] = is_active

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_model_limits.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("LIMIT_ID", metavar="LIMIT_ID")
@click.pass_context
def context_lake_delete_model_limit(ctx, limit_id, yes):
    """Delete Model Limit."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"context-lake/model-limits/{limit_id}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_model_limits.command(name="seed-defaults")
@click.pass_context
def context_lake_seed_defaults(ctx):
    """Seed Default Model Limits."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "context-lake/model-limits/seed-defaults"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="ui-enabled")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--tenant-id", "tenant_id", default=None, help="SA only: resolve for this tenant UUID instead of the caller's tenant.")
@click.pass_context
def context_lake_ui_enabled(ctx, tenant_id, page, page_size, fetch_all):
    """Check whether Context Lake admin UI is enabled for this tenant."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/ui-enabled"
    params = {}
    if tenant_id is not None:
        params["tenant_id"] = tenant_id
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@context_lake.command(name="feedback-enabled")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def context_lake_feedback_enabled(ctx, page, page_size, fetch_all):
    """Check whether Context Lake feedback (thumbs up/down) is enabled for this tenant."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/feedback-enabled"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@context_lake.command(name="memory-enabled")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def context_lake_memory_enabled(ctx, page, page_size, fetch_all):
    """Check whether user memory saving is enabled for this tenant."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/memory-enabled"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@cl_candidate_context.command(name="get")
@click.argument("SESSION_ID", metavar="SESSION_ID")
@click.pass_context
def context_lake_candidate_context_by_session_id(ctx, session_id):
    """Get Candidate Context."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/candidate-context/{session_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="sessions")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--page", "page", type=int, default=1)
@click.option("--page-size", "page_size", type=int, default=20)
@click.option("--sort-by", "sort_by", default="created_at")
@click.option("--sort-dir", "sort_dir", default="desc")
@click.option("--tenant-id", "tenant_id", default=None)
@click.option("--agent-id", "agent_id", default=None)
@click.option("--injection-status", "injection_status", default=None)
@click.option("--extraction-status", "extraction_status", default=None)
@click.pass_context
def context_lake_sessions(ctx, page, page_size, sort_by, sort_dir, tenant_id, agent_id, injection_status, extraction_status, fetch_all):
    """Admin List Sessions."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/admin/sessions"
    params = {}
    if page is not None:
        params["page"] = page
    if page_size is not None:
        params["page_size"] = page_size
    if sort_by is not None:
        params["sort_by"] = sort_by
    if sort_dir is not None:
        params["sort_dir"] = sort_dir
    if tenant_id is not None:
        params["tenant_id"] = tenant_id
    if agent_id is not None:
        params["agent_id"] = agent_id
    if injection_status is not None:
        params["injection_status"] = injection_status
    if extraction_status is not None:
        params["extraction_status"] = extraction_status
    if page_size is not None:
        params["page_size"] = min(page_size, 100)

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "page": page_num}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@cl_admin_candidate_context.command(name="get")
@click.argument("SESSION_ID", metavar="SESSION_ID")
@click.pass_context
def context_lake_admin_candidate_context(ctx, session_id):
    """Admin Get Candidate Context."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/admin/candidate-context/{session_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_admin_session.command(name="get")
@click.argument("SESSION_ID", metavar="SESSION_ID")
@click.pass_context
def context_lake_sessions_by_session_id(ctx, session_id):
    """Admin Get Session."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/admin/sessions/{session_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="injection-override")
@click.argument("SESSION_ID", metavar="SESSION_ID")
@click.option("--override", "override", default=None)
@click.pass_context
def context_lake_injection_override(ctx, session_id, override):
    """Admin Set Session Injection Override."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/admin/sessions/{session_id}/injection-override"
    body = {}
    if override is not None:
        body["override"] = override

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="assembly-stats")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--period-days", "period_days", type=int, default=30)
@click.pass_context
def context_lake_assembly_stats(ctx, period_days, page, page_size, fetch_all):
    """Admin Get Assembly Stats."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/admin/assembly-stats"
    params = {}
    if period_days is not None:
        params["period_days"] = period_days
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@context_lake.command(name="budget-config")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def context_lake_budget_config(ctx, page, page_size, fetch_all):
    """Admin Get Budget Config."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/admin/budget-config"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@context_lake.command(name="assembly-config")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def context_lake_assembly_config(ctx, page, page_size, fetch_all):
    """Admin Get Assembly Config."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/admin/assembly-config"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@context_lake.command(name="settings")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def context_lake_settings(ctx, page, page_size, fetch_all):
    """Admin Get Settings."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/admin/settings"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@cl_admin_settings.command(name="update")
@click.argument("KEY", metavar="KEY")
@click.option("--value", "value", type=bool, required=True)
@click.pass_context
def context_lake_settings_by_key(ctx, key, value):
    """Admin Update Setting."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/admin/settings/{key}"
    body = {}
    body["value"] = value

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="emergent-topics")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--status-filter", "status_filter", default=None, help="Filter by status: proposed, approved, rejected, or None for all")
@click.pass_context
def context_lake_emergent_topics(ctx, status_filter, page, page_size, fetch_all):
    """Admin Get Emergent Topics."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/admin/emergent-topics"
    params = {}
    if status_filter is not None:
        params["status_filter"] = status_filter
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@context_lake.command(name="approve")
@click.argument("DOMAIN_ID", metavar="DOMAIN_ID")
@click.pass_context
def context_lake_approve(ctx, domain_id):
    """Admin Approve Emergent Topic."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/admin/emergent-topics/{domain_id}/approve"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="reject")
@click.argument("DOMAIN_ID", metavar="DOMAIN_ID")
@click.pass_context
def context_lake_reject(ctx, domain_id):
    """Admin Reject Emergent Topic."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/admin/emergent-topics/{domain_id}/reject"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="tenants")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--page", "page", type=int, default=1)
@click.option("--page-size", "page_size", type=int, default=20)
@click.pass_context
def context_lake_tenants(ctx, page, page_size, fetch_all):
    """Superadmin List Tenants."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/superadmin/tenants"
    params = {}
    if page is not None:
        params["page"] = page
    if page_size is not None:
        params["page_size"] = page_size
    if page_size is not None:
        params["page_size"] = min(page_size, 100)

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "page": page_num}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@cl_superadmin_assembly.command(name="stats")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.option("--period-days", "period_days", type=int, default=30)
@click.pass_context
def context_lake_superadmin_assembly_stats(ctx, target_tenant_id, period_days):
    """Superadmin Get Tenant Assembly Stats."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/assembly-stats"
    params = {}
    if period_days is not None:
        params["period_days"] = period_days

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_superadmin_candidate_context.command(name="get")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.argument("SESSION_ID", metavar="SESSION_ID")
@click.pass_context
def context_lake_superadmin_candidate_context(ctx, target_tenant_id, session_id):
    """Superadmin Get Tenant Candidate Context."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/candidate-context/{session_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="extraction-stats")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.pass_context
def context_lake_extraction_stats(ctx, target_tenant_id):
    """Superadmin Get Extraction Stats."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/extraction-stats"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_superadmin_sessions.command(name="list")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.option("--extraction-status", "extraction_status", default=None, help="Filter by extraction status. Use 'pending' to get sessions with no extraction st")
@click.option("--page", "page", type=int, default=1)
@click.option("--page-size", "page_size", type=int, default=10)
@click.pass_context
def context_lake_superadmin_sessions(ctx, target_tenant_id, extraction_status, page, page_size):
    """Superadmin List Tenant Sessions."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/sessions"
    params = {}
    if extraction_status is not None:
        params["extraction_status"] = extraction_status
    if page is not None:
        params["page"] = page
    if page_size is not None:
        params["page_size"] = page_size

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="extract-now")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.option("--session-id", "session_id", default=None, help="Extract a specific session; omit to process all pending")
@click.option("--force", "force", type=bool, default=False, help="Re-extract sessions that have already been extracted")
@click.option("--limit", "limit", type=int, default=20, help="Max sessions to process in one call")
@click.pass_context
def context_lake_extract_now(ctx, target_tenant_id, session_id, force, limit):
    """Superadmin Extract Now."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/extract-now"
    params = {}
    if session_id is not None:
        params["session_id"] = session_id
    if force is not None:
        params["force"] = force
    if limit is not None:
        params["limit"] = limit

    client = _client(ctx)
    try:
        data = client.post(path, json={}, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_superadmin_injection.command(name="override")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.argument("SESSION_ID", metavar="SESSION_ID")
@click.option("--override", "override", default=None)
@click.pass_context
def context_lake_superadmin_injection_override(ctx, target_tenant_id, session_id, override):
    """Superadmin Set Session Injection Override."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/sessions/{session_id}/injection-override"
    body = {}
    if override is not None:
        body["override"] = override

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_superadmin_settings.command(name="list")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.pass_context
def context_lake_superadmin_settings(ctx, target_tenant_id):
    """Superadmin Get Tenant Settings."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/settings"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_superadmin_settings.command(name="update")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.argument("KEY", metavar="KEY")
@click.option("--value", "value", type=bool, required=True)
@click.pass_context
def context_lake_superadmin_update_setting(ctx, target_tenant_id, key, value):
    """Superadmin Update Tenant Setting."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/settings/{key}"
    body = {}
    body["value"] = value

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="preference-definitions")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def context_lake_preference_definitions(ctx, page, page_size, fetch_all):
    """List Preference Definitions."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/preference-definitions"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@cl_session_context.command(name="recall")
@click.argument("SESSION_ID", metavar="SESSION_ID")
@click.pass_context
def context_lake_session_recall_by_session_id(ctx, session_id):
    """Get Session Recall."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/session-recall/{session_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="my-data")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def context_lake_my_data(ctx, yes):
    """Erase My Data."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = "context-lake/my-data"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="users")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--page", "page", type=int, default=1)
@click.option("--page-size", "page_size", type=int, default=20)
@click.pass_context
def context_lake_users(ctx, page, page_size, fetch_all):
    """Admin List Users."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/admin/users"
    params = {}
    if page is not None:
        params["page"] = page
    if page_size is not None:
        params["page_size"] = page_size
    if page_size is not None:
        params["page_size"] = min(page_size, 100)

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "page": page_num}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@cl_admin_memory.command(name="list")
@click.argument("USER_ID", metavar="USER_ID")
@click.option("--page", "page", type=int, default=1)
@click.option("--page-size", "page_size", type=int, default=20)
@click.option("--memory-type", "memory_type", default=None)
@click.option("--domain", "domain", default=None)
@click.pass_context
def context_lake_admin_user_memory(ctx, user_id, page, page_size, memory_type, domain):
    """Admin Get User Memory."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/admin/users/{user_id}/memory"
    params = {}
    if page is not None:
        params["page"] = page
    if page_size is not None:
        params["page_size"] = page_size
    if memory_type is not None:
        params["memory_type"] = memory_type
    if domain is not None:
        params["domain"] = domain

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_admin_memory.command(name="delete-all")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("USER_ID", metavar="USER_ID")
@click.pass_context
def context_lake_admin_delete_user_memory(ctx, user_id, yes):
    """Admin Bulk Delete User Memory."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"context-lake/admin/users/{user_id}/memory"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_admin_memory.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("USER_ID", metavar="USER_ID")
@click.argument("MEMORY_ID", metavar="MEMORY_ID")
@click.pass_context
def context_lake_admin_delete_memory_item(ctx, user_id, memory_id, yes):
    """Admin Delete User Memory Item."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"context-lake/admin/users/{user_id}/memory/{memory_id}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="data")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("USER_ID", metavar="USER_ID")
@click.pass_context
def context_lake_data(ctx, user_id, yes):
    """Admin Erase User Data."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"context-lake/admin/users/{user_id}/data"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_admin_preferences.command(name="list")
@click.argument("USER_ID", metavar="USER_ID")
@click.pass_context
def context_lake_admin_user_preferences(ctx, user_id):
    """Admin Get User Preferences."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/admin/users/{user_id}/preferences"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_admin_preferences.command(name="set")
@click.argument("USER_ID", metavar="USER_ID")
@click.argument("KEY", metavar="KEY")
@click.option("--target-tenant-id", "target_tenant_id", default=None)
@click.option("--value", "value", required=True)
@click.pass_context
def context_lake_admin_upsert_preference(ctx, user_id, key, target_tenant_id, value):
    """Admin Upsert User Preference."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/admin/users/{user_id}/preferences/{key}"
    params = {}
    if target_tenant_id is not None:
        params["target_tenant_id"] = target_tenant_id
    body = {}
    body["value"] = value

    client = _client(ctx)
    try:
        data = client.post(path, json=body, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_admin_preferences.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("USER_ID", metavar="USER_ID")
@click.argument("KEY", metavar="KEY")
@click.option("--target-tenant-id", "target_tenant_id", default=None)
@click.pass_context
def context_lake_admin_delete_preference(ctx, user_id, key, target_tenant_id, yes):
    """Admin Delete User Preference."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"context-lake/admin/users/{user_id}/preferences/{key}"
    params = {}
    if target_tenant_id is not None:
        params["target_tenant_id"] = target_tenant_id

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_admin_session.command(name="recall")
@click.argument("SESSION_ID", metavar="SESSION_ID")
@click.pass_context
def context_lake_admin_session_recall(ctx, session_id):
    """Admin Get Session Recall."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/admin/session-recall/{session_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="memory-stats")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def context_lake_memory_stats(ctx, page, page_size, fetch_all):
    """Admin Get Memory Stats."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/admin/memory-stats"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@cl_superadmin_users.command(name="list")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.option("--page", "page", type=int, default=1)
@click.option("--page-size", "page_size", type=int, default=20)
@click.pass_context
def context_lake_superadmin_users(ctx, target_tenant_id, page, page_size):
    """Superadmin List Tenant Users."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/users"
    params = {}
    if page is not None:
        params["page"] = page
    if page_size is not None:
        params["page_size"] = page_size

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_superadmin_memory.command(name="list")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.argument("USER_ID", metavar="USER_ID")
@click.option("--page", "page", type=int, default=1)
@click.option("--page-size", "page_size", type=int, default=20)
@click.option("--memory-type", "memory_type", default=None)
@click.option("--domain", "domain", default=None)
@click.pass_context
def context_lake_superadmin_user_memory(ctx, target_tenant_id, user_id, page, page_size, memory_type, domain):
    """Superadmin Get User Memory."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/users/{user_id}/memory"
    params = {}
    if page is not None:
        params["page"] = page
    if page_size is not None:
        params["page_size"] = page_size
    if memory_type is not None:
        params["memory_type"] = memory_type
    if domain is not None:
        params["domain"] = domain

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_superadmin_memory.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.argument("USER_ID", metavar="USER_ID")
@click.argument("MEMORY_ID", metavar="MEMORY_ID")
@click.pass_context
def context_lake_superadmin_delete_memory_item(ctx, target_tenant_id, user_id, memory_id, yes):
    """Superadmin Delete User Memory Item."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"context-lake/superadmin/tenants/{target_tenant_id}/users/{user_id}/memory/{memory_id}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_superadmin_users.command(name="erase")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.argument("USER_ID", metavar="USER_ID")
@click.pass_context
def context_lake_superadmin_erase_user_data(ctx, target_tenant_id, user_id, yes):
    """Superadmin Erase User Data."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"context-lake/superadmin/tenants/{target_tenant_id}/users/{user_id}/data"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_superadmin_memory.command(name="stats")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.pass_context
def context_lake_superadmin_memory_stats(ctx, target_tenant_id):
    """Superadmin Get Tenant Memory Stats."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/memory-stats"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="tenant-intelligence")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def context_lake_tenant_intelligence(ctx, page, page_size, fetch_all):
    """Get Tenant Intelligence."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/tenant-intelligence"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@context_lake.command(name="refresh")
@click.pass_context
def context_lake_refresh(ctx):
    """Trigger Tenant Intelligence Refresh."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "context-lake/admin/tenant-intelligence/refresh"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="pending")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--page", "page", type=int, default=1)
@click.option("--page-size", "page_size", type=int, default=20)
@click.pass_context
def context_lake_pending(ctx, page, page_size, fetch_all):
    """List Pending Memories."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/memory/pending"
    params = {}
    if page is not None:
        params["page"] = page
    if page_size is not None:
        params["page_size"] = page_size
    if page_size is not None:
        params["page_size"] = min(page_size, 100)

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "page": page_num}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@context_lake.command(name="approve-memory")
@click.argument("MEMORY_ID", metavar="MEMORY_ID")
@click.pass_context
def context_lake_approve_memory(ctx, memory_id):
    """Approve Memory."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/memory/{memory_id}/approve"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="reject-memory")
@click.argument("MEMORY_ID", metavar="MEMORY_ID")
@click.option("--reason", "reason", default=None)
@click.pass_context
def context_lake_reject_memory(ctx, memory_id, reason):
    """Reject Memory."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/memory/{memory_id}/reject"
    body = {}
    if reason is not None:
        body["reason"] = reason

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="promote")
@click.argument("MEMORY_ID", metavar="MEMORY_ID")
@click.option("--target-scope", "target_scope", required=True)
@click.pass_context
def context_lake_promote(ctx, memory_id, target_scope):
    """Promote Memory."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/admin/memory/{memory_id}/promote"
    body = {}
    body["target_scope"] = target_scope

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_admin_tenant_intelligence.command(name="get")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def context_lake_admin_tenant_intelligence(ctx, page, page_size, fetch_all):
    """Admin Get Tenant Intelligence."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/admin/tenant-intelligence"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@context_lake.command(name="org-memory")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--scope", "scope", default=None, help="Filter by scope: workspace, namespace, or tenant")
@click.option("--workspace-id", "workspace_id", default=None, help="Filter by workspace UUID")
@click.option("--page", "page", type=int, default=1)
@click.option("--page-size", "page_size", type=int, default=20)
@click.pass_context
def context_lake_org_memory(ctx, scope, workspace_id, page, page_size, fetch_all):
    """Admin List Org Memories."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/admin/org-memory"
    params = {}
    if scope is not None:
        params["scope"] = scope
    if workspace_id is not None:
        params["workspace_id"] = workspace_id
    if page is not None:
        params["page"] = page
    if page_size is not None:
        params["page_size"] = page_size
    if page_size is not None:
        params["page_size"] = min(page_size, 100)

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "page": page_num}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@cl_admin_org_memory.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("MEMORY_ID", metavar="MEMORY_ID")
@click.pass_context
def context_lake_org_memory_by_memory_id(ctx, memory_id, yes):
    """Admin Delete Org Memory."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"context-lake/admin/org-memory/{memory_id}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_admin_org_memory.command(name="pending")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--page", "page", type=int, default=1)
@click.option("--page-size", "page_size", type=int, default=20)
@click.pass_context
def context_lake_admin_pending(ctx, page, page_size, fetch_all):
    """Admin List Pending Memories."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/admin/memory/pending"
    params = {}
    if page is not None:
        params["page"] = page
    if page_size is not None:
        params["page_size"] = page_size
    if page_size is not None:
        params["page_size"] = min(page_size, 100)

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "page": page_num}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@cl_admin_org_memory.command(name="approve")
@click.argument("MEMORY_ID", metavar="MEMORY_ID")
@click.pass_context
def context_lake_admin_approve_memory(ctx, memory_id):
    """Admin Approve Memory."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/admin/memory/{memory_id}/approve"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_admin_org_memory.command(name="reject")
@click.argument("MEMORY_ID", metavar="MEMORY_ID")
@click.option("--reason", "reason", default=None)
@click.pass_context
def context_lake_admin_reject_memory(ctx, memory_id, reason):
    """Admin Reject Memory."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/admin/memory/{memory_id}/reject"
    body = {}
    if reason is not None:
        body["reason"] = reason

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_superadmin_tenant_intelligence.command(name="get")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.pass_context
def context_lake_superadmin_tenant_intelligence(ctx, target_tenant_id):
    """Superadmin Get Tenant Intelligence."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/tenant-intelligence"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_superadmin_tenant_intelligence.command(name="refresh")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.pass_context
def context_lake_superadmin_refresh(ctx, target_tenant_id):
    """Superadmin Refresh Tenant Intelligence."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/tenant-intelligence/refresh"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_superadmin_tenant_intelligence.command(name="topics")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.option("--status-filter", "status_filter", default=None, help="Filter by status: proposed, approved, rejected, or None for all")
@click.pass_context
def context_lake_superadmin_emergent_topics(ctx, target_tenant_id, status_filter):
    """Superadmin Get Tenant Emergent Topics."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/emergent-topics"
    params = {}
    if status_filter is not None:
        params["status_filter"] = status_filter

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="intelligence-overview")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def context_lake_intelligence_overview(ctx, page, page_size, fetch_all):
    """Superadmin Get Intelligence Overview."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/superadmin/intelligence-overview"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@cl_superadmin_org_memory.command(name="list")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.option("--scope", "scope", default=None)
@click.option("--workspace-id", "workspace_id", default=None)
@click.option("--page", "page", type=int, default=1)
@click.option("--page-size", "page_size", type=int, default=20)
@click.pass_context
def context_lake_superadmin_org_memory(ctx, target_tenant_id, scope, workspace_id, page, page_size):
    """Superadmin List Tenant Org Memories."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/org-memory"
    params = {}
    if scope is not None:
        params["scope"] = scope
    if workspace_id is not None:
        params["workspace_id"] = workspace_id
    if page is not None:
        params["page"] = page
    if page_size is not None:
        params["page_size"] = page_size

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_superadmin_org_memory.command(name="create")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.option("--content", "content", required=True)
@click.option("--memory-type", "memory_type", default="fact")
@click.option("--scope", "scope", default="namespace")
@click.option("--confidence", "confidence", type=float, default=1.0)
@click.pass_context
def context_lake_superadmin_create_org_memory(ctx, target_tenant_id, content, memory_type, scope, confidence):
    """Superadmin Create Tenant Org Memory."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/org-memory"
    body = {}
    body["content"] = content
    if memory_type is not None:
        body["memory_type"] = memory_type
    if scope is not None:
        body["scope"] = scope
    if confidence is not None:
        body["confidence"] = confidence

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="recall")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.option("--query", "query", required=True)
@click.option("--scope", "scope", default="namespace")
@click.option("--top-k", "top_k", type=int, default=10)
@click.pass_context
def context_lake_recall(ctx, target_tenant_id, query, scope, top_k):
    """Superadmin Recall Tenant Org Memories."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/org-memory/recall"
    body = {}
    body["query"] = query
    if scope is not None:
        body["scope"] = scope
    if top_k is not None:
        body["top_k"] = top_k

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_superadmin_org_memory.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.argument("MEMORY_ID", metavar="MEMORY_ID")
@click.pass_context
def context_lake_superadmin_delete_org_memory(ctx, target_tenant_id, memory_id, yes):
    """Superadmin Delete Tenant Org Memory."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"context-lake/superadmin/tenants/{target_tenant_id}/org-memory/{memory_id}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="org-memory-templates")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def context_lake_org_memory_templates(ctx, page, page_size, fetch_all):
    """Superadmin List Org Memory Templates."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/superadmin/org-memory-templates"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@context_lake.command(name="seed")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.option("--template-id", "template_id", required=True)
@click.option("--scope", "scope", default="namespace")
@click.option("--items", "items", required=True)
@click.pass_context
def context_lake_seed(ctx, target_tenant_id, template_id, scope, items):
    """Superadmin Seed Tenant Org Memory."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/org-memory/seed"
    body = {}
    body["template_id"] = template_id
    if scope is not None:
        body["scope"] = scope
    body["items"] = items

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_superadmin_org_memory.command(name="pending")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.option("--page", "page", type=int, default=1)
@click.option("--page-size", "page_size", type=int, default=20)
@click.pass_context
def context_lake_superadmin_pending(ctx, target_tenant_id, page, page_size):
    """Superadmin List Tenant Pending Memories."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/memory/pending"
    params = {}
    if page is not None:
        params["page"] = page
    if page_size is not None:
        params["page_size"] = page_size

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_superadmin_org_memory.command(name="approve")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.argument("MEMORY_ID", metavar="MEMORY_ID")
@click.pass_context
def context_lake_superadmin_approve_memory(ctx, target_tenant_id, memory_id):
    """Superadmin Approve Tenant Memory."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/memory/{memory_id}/approve"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_superadmin_org_memory.command(name="reject")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.argument("MEMORY_ID", metavar="MEMORY_ID")
@click.option("--reason", "reason", default=None)
@click.pass_context
def context_lake_superadmin_reject_memory(ctx, target_tenant_id, memory_id, reason):
    """Superadmin Reject Tenant Memory."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/memory/{memory_id}/reject"
    body = {}
    if reason is not None:
        body["reason"] = reason

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="graph")
@click.argument("ENTITY_TYPE", metavar="ENTITY_TYPE")
@click.argument("ENTITY_ID", metavar="ENTITY_ID")
@click.option("--depth", "depth", type=int, default=1, help="Traversal depth (1-3)")
@click.pass_context
def context_lake_graph(ctx, entity_type, entity_id, depth):
    """Get Entity Graph."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/entity-links/{entity_type}/{entity_id}/graph"
    params = {}
    if depth is not None:
        params["depth"] = depth

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="provenance")
@click.argument("ENTITY_TYPE", metavar="ENTITY_TYPE")
@click.argument("ENTITY_ID", metavar="ENTITY_ID")
@click.pass_context
def context_lake_provenance(ctx, entity_type, entity_id):
    """Get Entity Provenance."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/entity-links/{entity_type}/{entity_id}/provenance"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_entity_links.command(name="by-entity")
@click.argument("ENTITY_TYPE", metavar="ENTITY_TYPE")
@click.argument("ENTITY_ID", metavar="ENTITY_ID")
@click.pass_context
def context_lake_entity_links_by_entity_id(ctx, entity_type, entity_id):
    """Get Entity Links."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/entity-links/{entity_type}/{entity_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="chain")
@click.argument("ALERT_ID", metavar="ALERT_ID")
@click.pass_context
def context_lake_chain(ctx, alert_id):
    """Get Alert Detection Chain."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/entity-links/alert/{alert_id}/chain"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_session_context.command(name="entity-context")
@click.argument("SESSION_ID", metavar="SESSION_ID")
@click.pass_context
def context_lake_session_entity_context_by_session_id(ctx, session_id):
    """Get Session Entity Context."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/session-entity-context/{session_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_admin_entity_links.command(name="summary")
@click.argument("ENTITY_TYPE", metavar="ENTITY_TYPE")
@click.argument("ENTITY_ID", metavar="ENTITY_ID")
@click.pass_context
def context_lake_admin_entity_link_summary(ctx, entity_type, entity_id):
    """Admin Get Entity Link Summary."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/admin/entity-links/{entity_type}/{entity_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_admin_entity_links.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("LINK_ID", metavar="LINK_ID")
@click.pass_context
def context_lake_entity_links_by_link_id(ctx, link_id, yes):
    """Admin Delete Entity Link."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"context-lake/admin/entity-links/{link_id}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="entity-link-stats")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def context_lake_entity_link_stats(ctx, page, page_size, fetch_all):
    """Admin Get Entity Link Stats."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/admin/entity-link-stats"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@cl_admin_session.command(name="entity-context")
@click.argument("SESSION_ID", metavar="SESSION_ID")
@click.pass_context
def context_lake_admin_session_entity_context(ctx, session_id):
    """Admin Get Session Entity Context."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/admin/session-entity-context/{session_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_superadmin_entity_links.command(name="list")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.option("--entity-type", "entity_type", default=None)
@click.option("--service", "service", default=None)
@click.option("--relationship-type", "relationship_type", default=None)
@click.option("--page", "page", type=int, default=1)
@click.option("--page-size", "page_size", type=int, default=20)
@click.pass_context
def context_lake_superadmin_entity_links(ctx, target_tenant_id, entity_type, service, relationship_type, page, page_size):
    """Superadmin List Entity Links."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/entity-links"
    params = {}
    if entity_type is not None:
        params["entity_type"] = entity_type
    if service is not None:
        params["service"] = service
    if relationship_type is not None:
        params["relationship_type"] = relationship_type
    if page is not None:
        params["page"] = page
    if page_size is not None:
        params["page_size"] = page_size

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_superadmin_entity_links.command(name="summary")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.argument("ENTITY_TYPE", metavar="ENTITY_TYPE")
@click.argument("ENTITY_ID", metavar="ENTITY_ID")
@click.pass_context
def context_lake_superadmin_entity_link_summary(ctx, target_tenant_id, entity_type, entity_id):
    """Superadmin Get Entity Link Summary."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/entity-links/{entity_type}/{entity_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_superadmin_entity_links.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.argument("LINK_ID", metavar="LINK_ID")
@click.pass_context
def context_lake_superadmin_delete_entity_link(ctx, target_tenant_id, link_id, yes):
    """Superadmin Delete Entity Link."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"context-lake/superadmin/tenants/{target_tenant_id}/entity-links/{link_id}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_superadmin_entity_links.command(name="stats")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.pass_context
def context_lake_superadmin_entity_link_stats(ctx, target_tenant_id):
    """Superadmin Get Entity Link Stats."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/entity-link-stats"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_superadmin_entity_links.command(name="refresh")
@click.option("--jobs", "jobs", default=None)
@click.pass_context
def context_lake_superadmin_entity_link_refresh(ctx, jobs):
    """Superadmin Trigger Entity Link Refresh."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "context-lake/superadmin/entity-links/refresh"
    body = {}
    if jobs is not None:
        body["jobs"] = jobs

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="my-feedback")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--page", "page", type=int, default=1)
@click.option("--page-size", "page_size", type=int, default=20)
@click.option("--sort-dir", "sort_dir", default="desc")
@click.option("--session-id", "session_id", default=None)
@click.pass_context
def context_lake_my_feedback(ctx, page, page_size, sort_dir, session_id, fetch_all):
    """List My Feedback."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/feedback"
    params = {}
    if page is not None:
        params["page"] = page
    if page_size is not None:
        params["page_size"] = page_size
    if sort_dir is not None:
        params["sort_dir"] = sort_dir
    if session_id is not None:
        params["session_id"] = session_id
    if page_size is not None:
        params["page_size"] = min(page_size, 100)

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "page": page_num}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@context_lake.command(name="my-summary")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def context_lake_my_summary(ctx, page, page_size, fetch_all):
    """Get My Feedback Summary."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/feedback/my-summary"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@cl_admin_feedback.command(name="list")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--page", "page", type=int, default=1)
@click.option("--page-size", "page_size", type=int, default=20)
@click.option("--sort-dir", "sort_dir", default="desc")
@click.option("--feedback-type", "feedback_type", default=None)
@click.option("--agent-id", "agent_id", default=None)
@click.option("--user-id", "user_id", default=None)
@click.option("--date-from", "date_from", default=None)
@click.option("--date-to", "date_to", default=None)
@click.option("--session-id", "session_id", default=None)
@click.pass_context
def context_lake_admin_feedback(ctx, page, page_size, sort_dir, feedback_type, agent_id, user_id, date_from, date_to, session_id, fetch_all):
    """Admin List Feedback."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/admin/feedback"
    params = {}
    if page is not None:
        params["page"] = page
    if page_size is not None:
        params["page_size"] = page_size
    if sort_dir is not None:
        params["sort_dir"] = sort_dir
    if feedback_type is not None:
        params["feedback_type"] = feedback_type
    if agent_id is not None:
        params["agent_id"] = agent_id
    if user_id is not None:
        params["user_id"] = user_id
    if date_from is not None:
        params["date_from"] = date_from
    if date_to is not None:
        params["date_to"] = date_to
    if session_id is not None:
        params["session_id"] = session_id
    if page_size is not None:
        params["page_size"] = min(page_size, 100)

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "page": page_num}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@cl_admin_feedback.command(name="summary")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def context_lake_admin_feedback_summary(ctx, page, page_size, fetch_all):
    """Admin Get Feedback Summary."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/admin/feedback/summary"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@context_lake.command(name="quality-dashboard")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--period-days", "period_days", type=int, default=30)
@click.pass_context
def context_lake_quality_dashboard(ctx, period_days, page, page_size, fetch_all):
    """Admin Get Quality Dashboard."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/admin/quality-dashboard"
    params = {}
    if period_days is not None:
        params["period_days"] = period_days
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@cl_admin_feedback.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("FEEDBACK_ID", metavar="FEEDBACK_ID")
@click.pass_context
def context_lake_feedback_by_feedback_id(ctx, feedback_id, yes):
    """Admin Delete Feedback."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"context-lake/admin/feedback/{feedback_id}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_superadmin_feedback.command(name="list")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.option("--page", "page", type=int, default=1)
@click.option("--page-size", "page_size", type=int, default=20)
@click.option("--sort-dir", "sort_dir", default="desc")
@click.option("--feedback-type", "feedback_type", default=None)
@click.option("--agent-id", "agent_id", default=None)
@click.option("--user-id", "user_id", default=None)
@click.option("--date-from", "date_from", default=None)
@click.option("--date-to", "date_to", default=None)
@click.pass_context
def context_lake_superadmin_feedback(ctx, target_tenant_id, page, page_size, sort_dir, feedback_type, agent_id, user_id, date_from, date_to):
    """Superadmin List Feedback."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/feedback"
    params = {}
    if page is not None:
        params["page"] = page
    if page_size is not None:
        params["page_size"] = page_size
    if sort_dir is not None:
        params["sort_dir"] = sort_dir
    if feedback_type is not None:
        params["feedback_type"] = feedback_type
    if agent_id is not None:
        params["agent_id"] = agent_id
    if user_id is not None:
        params["user_id"] = user_id
    if date_from is not None:
        params["date_from"] = date_from
    if date_to is not None:
        params["date_to"] = date_to

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@cl_superadmin_feedback.command(name="quality-dashboard")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.option("--period-days", "period_days", type=int, default=30)
@click.pass_context
def context_lake_superadmin_quality_dashboard(ctx, target_tenant_id, period_days):
    """Superadmin Get Tenant Quality Dashboard."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/quality-dashboard"
    params = {}
    if period_days is not None:
        params["period_days"] = period_days

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="quality-overview")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def context_lake_quality_overview(ctx, page, page_size, fetch_all):
    """Superadmin Get Quality Overview."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/superadmin/quality-overview"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@cl_superadmin_feedback.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.argument("FEEDBACK_ID", metavar="FEEDBACK_ID")
@click.pass_context
def context_lake_superadmin_delete_feedback(ctx, target_tenant_id, feedback_id, yes):
    """Superadmin Delete Feedback."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"context-lake/superadmin/tenants/{target_tenant_id}/feedback/{feedback_id}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="jobs")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def context_lake_jobs(ctx, page, page_size, fetch_all):
    """Get Scheduler Jobs."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/superadmin/scheduler/jobs"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@context_lake.command(name="domain-profile")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def context_lake_domain_profile(ctx, page, page_size, fetch_all):
    """Admin Get Domain Profile."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/admin/domain-profile"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@cl_superadmin_domain_profile.command(name="get")
@click.argument("TARGET_TENANT_ID", metavar="TARGET_TENANT_ID")
@click.pass_context
def context_lake_superadmin_domain_profile(ctx, target_tenant_id):
    """Superadmin Get Tenant Domain Profile."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"context-lake/superadmin/tenants/{target_tenant_id}/domain-profile"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@context_lake.command(name="taxonomy")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def context_lake_taxonomy(ctx, page, page_size, fetch_all):
    """Admin Get Taxonomy."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "context-lake/admin/taxonomy"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


# ---------------------------------------------------------------------------
# engagement sub-group — cross-App Engagement roster (AM-8)
#   fleet list                 |   show <WORKSPACE_ID>
# ---------------------------------------------------------------------------

_ENGAGEMENT_FLEET_COLS = [
    ("name", "APP", 30),
    ("source", "SOURCE", 12),
    ("intent_state", "INTENT", 16),
    ("goal_count", "GOALS", 6),
    ("memory_total", "MEMORIES", 9),
    ("updated_at", "UPDATED", 20),
    ("workspace_id", "WORKSPACE_ID", 36),
]


@context_lake.group(name="engagement")
def cl_engagement():
    """Engagement across Apps (Intent + Goals + memory).

    \b
    Examples:
      torana context-lake engagement fleet list        # every App's engagement summary
      torana context-lake engagement show <WORKSPACE>  # one App's summary row
    """


@cl_engagement.group(name="fleet", invoke_without_command=True)
@click.pass_context
def cl_engagement_fleet(ctx):
    """Cross-App engagement roster. Use `list`."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@cl_engagement_fleet.command(name="list")
@click.pass_context
def cl_engagement_fleet_list(ctx):
    """List engagement across all Apps in the tenant (one summary row per App).

    Aggregate of the per-App Engagement page: each App's source (build_v2 /
    chat_memory), whether it has a current Intent (and its state), current Goal
    count, and typed-memory total. Newest-updated App first.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("context-lake/engagement/fleet")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    items = data.get("items", []) if isinstance(data, dict) else []
    result = {
        "items": items,
        "total": len(items),
        "page": 1,
        "page_size": len(items),
    }
    output(result, fmt=fmt, raw=raw, fields=fields, columns=_ENGAGEMENT_FLEET_COLS)


@cl_engagement.command(name="show")
@click.argument("workspace_id", metavar="WORKSPACE_ID")
@click.pass_context
def cl_engagement_show(ctx, workspace_id):
    """Show one App's engagement summary row (from the fleet roster)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("context-lake/engagement/fleet")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    items = data.get("items", []) if isinstance(data, dict) else []
    match = next((it for it in items if it.get("workspace_id") == workspace_id), None)
    if match is None:
        click.echo(f"No engagement summary found for workspace {workspace_id}.", err=True)
        raise SystemExit(3)
    output(match, fmt=fmt, fields=fields)


# ──────────────────────────────────────────────────────────────────────────
# BACK-COMPAT — hidden aliases for the flat names these commands used to have.
#
# ⏳ ONE RELEASE ONLY (decision D4). Scripts and CI jobs pinned to the old flat
# names keep working; `hidden=True` keeps them out of --help so nobody LEARNS
# them. Delete this whole block — and _LEGACY_ALIASES — next release.
#
# ⚠️ Registered by walking the real command objects, so an alias can never drift
# from the command it forwards to: there is only one implementation.
# ──────────────────────────────────────────────────────────────────────────

# by-param leaves folded onto verbs; parent group + verb per entry.
# The flat model-limit family, folded under the `model-limits` group.
# NOTE: "model-limits" itself is NOT aliased — it is now the GROUP name.
# Registering it would overwrite the group and hide every verb under it.
# `torana context-lake model-limits` now prints the group help, which is
# the desired shape anyway (rule 4).
_LEGACY_MODEL_LIMITS = {
    "create-model-limit": "create",
    "delete-model-limit": "delete",
    "seed-defaults": "seed-defaults",
}

_LEGACY_BY_PARAM = {
    "candidate-context-by-session-id": ("cl_candidate_context", "get"),
    "entity-links-by-entity-id": ("cl_entity_links", "by-entity"),
    "entity-links-by-link-id": ("cl_admin_entity_links", "delete"),
    "feedback-by-feedback-id": ("cl_admin_feedback", "delete"),
    "model-limits-by-limit-id": ("cl_model_limits", "update"),
    "model-limits-by-model-name": ("cl_model_limits", "get"),
    "org-memory-by-memory-id": ("cl_admin_org_memory", "delete"),
    "session-entity-context-by-session-id": ("cl_session_context", "entity-context"),
    "session-recall-by-session-id": ("cl_session_context", "recall"),
    "sessions-by-session-id": ("cl_admin_session", "get"),
    "settings-by-key": ("cl_admin_settings", "update"),
}

_LEGACY_ALIASES = {
    "admin-approve-memory": ("admin", "org-memory approve"),
    "admin-candidate-context": ("admin", "candidate-context get"),
    "admin-delete-memory-item": ("admin", "memory delete"),
    "admin-delete-preference": ("admin", "preferences delete"),
    "admin-delete-user-memory": ("admin", "memory delete-all"),
    "admin-entity-link-summary": ("admin", "entity-links summary"),
    "admin-feedback": ("admin", "feedback list"),
    "admin-feedback-summary": ("admin", "feedback summary"),
    "admin-pending": ("admin", "org-memory pending"),
    "admin-reject-memory": ("admin", "org-memory reject"),
    "admin-session-entity-context": ("admin", "session entity-context"),
    "admin-session-recall": ("admin", "session recall"),
    "admin-tenant-intelligence": ("admin", "tenant-intelligence get"),
    "admin-upsert-preference": ("admin", "preferences set"),
    "admin-user-memory": ("admin", "memory list"),
    "admin-user-preferences": ("admin", "preferences list"),
    "superadmin-approve-memory": ("superadmin", "org-memory approve"),
    "superadmin-assembly-stats": ("superadmin", "assembly stats"),
    "superadmin-candidate-context": ("superadmin", "candidate-context get"),
    "superadmin-create-org-memory": ("superadmin", "org-memory create"),
    "superadmin-delete-entity-link": ("superadmin", "entity-links delete"),
    "superadmin-delete-feedback": ("superadmin", "feedback delete"),
    "superadmin-delete-memory-item": ("superadmin", "memory delete"),
    "superadmin-delete-org-memory": ("superadmin", "org-memory delete"),
    "superadmin-domain-profile": ("superadmin", "domain-profile get"),
    "superadmin-emergent-topics": ("superadmin", "tenant-intelligence topics"),
    "superadmin-entity-link-refresh": ("superadmin", "entity-links refresh"),
    "superadmin-entity-link-stats": ("superadmin", "entity-links stats"),
    "superadmin-entity-link-summary": ("superadmin", "entity-links summary"),
    "superadmin-entity-links": ("superadmin", "entity-links list"),
    "superadmin-erase-user-data": ("superadmin", "users erase"),
    "superadmin-feedback": ("superadmin", "feedback list"),
    "superadmin-injection-override": ("superadmin", "injection override"),
    "superadmin-memory-stats": ("superadmin", "memory stats"),
    "superadmin-org-memory": ("superadmin", "org-memory list"),
    "superadmin-pending": ("superadmin", "org-memory pending"),
    "superadmin-quality-dashboard": ("superadmin", "feedback quality-dashboard"),
    "superadmin-refresh": ("superadmin", "tenant-intelligence refresh"),
    "superadmin-reject-memory": ("superadmin", "org-memory reject"),
    "superadmin-sessions": ("superadmin", "sessions list"),
    "superadmin-settings": ("superadmin", "settings list"),
    "superadmin-tenant-intelligence": ("superadmin", "tenant-intelligence get"),
    "superadmin-update-setting": ("superadmin", "settings update"),
    "superadmin-user-memory": ("superadmin", "memory list"),
    "superadmin-users": ("superadmin", "users list"),
}


def _register_legacy_aliases() -> None:
    """Re-register each regrouped command under its OLD flat name, hidden."""
    for _old, (_scope, _path) in _LEGACY_ALIASES.items():
        _noun, _verb = _path.split()
        _grp = context_lake.commands.get(_scope)
        if _grp is None:
            continue
        _sub = _grp.commands.get(_noun)
        if _sub is None:
            continue
        _cmd = _sub.commands.get(_verb)
        if _cmd is None:
            continue
        import copy
        _alias = copy.copy(_cmd)
        _alias.name = _old
        _alias.hidden = True
        _existing = context_lake.commands.get(_old)
        if isinstance(_existing, click.Group):
            # ⛔ Never let a back-compat alias overwrite a real group that
            # now owns this name — that hides every verb underneath it.
            continue
        context_lake.add_command(_alias)


_register_legacy_aliases()


def _register_legacy_by_param_aliases() -> None:
    """Old `<noun>-by-<param>` names, hidden. ⏳ ONE RELEASE (D4)."""
    import copy
    _groups = {
        'cl_candidate_context': cl_candidate_context,
        'cl_session_context': cl_session_context,
        'cl_model_limits': cl_model_limits,
        'cl_entity_links': cl_entity_links,
        'cl_admin_entity_links': cl_admin_entity_links,
        'cl_admin_feedback': cl_admin_feedback,
        'cl_admin_org_memory': cl_admin_org_memory,
        'cl_admin_session': cl_admin_session,
        'cl_admin_settings': cl_admin_settings,
    }
    for _old, (_gname, _verb) in _LEGACY_BY_PARAM.items():
        _grp = _groups.get(_gname)
        if _grp is None:
            continue
        _cmd = _grp.commands.get(_verb)
        if _cmd is None:
            continue
        _alias = copy.copy(_cmd)
        _alias.name = _old
        _alias.hidden = True
        _existing = context_lake.commands.get(_old)
        if isinstance(_existing, click.Group):
            # ⛔ Never let a back-compat alias overwrite a real group that
            # now owns this name — that hides every verb underneath it.
            continue
        context_lake.add_command(_alias)


_register_legacy_by_param_aliases()


def _register_legacy_model_limit_aliases() -> None:
    """Old flat model-limit names, hidden. ⏳ ONE RELEASE (D4)."""
    import copy
    for _old, _verb in _LEGACY_MODEL_LIMITS.items():
        _cmd = cl_model_limits.commands.get(_verb)
        if _cmd is None:
            continue
        _alias = copy.copy(_cmd)
        _alias.name = _old
        _alias.hidden = True
        _existing = context_lake.commands.get(_old)
        if isinstance(_existing, click.Group):
            # ⛔ Never let a back-compat alias overwrite a real group that
            # now owns this name — that hides every verb underneath it.
            continue
        context_lake.add_command(_alias)


_register_legacy_model_limit_aliases()
