"""torana dashboards — dashboard collection management commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW, CollectionGroup
from torana_cli.output import output
from torana_cli.rules import _load_input_file

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 35),
    ("workspace_id", "WORKSPACE_ID", 36),
    ("is_default", "DEFAULT", 7),
    ("widget_count", "WIDGETS", 7),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(cls=CollectionGroup, singular="dashboard")
def dashboards():
    """Manage dashboards (collection operations).

    \b
    Instance commands (get, update, delete, etc.) are under:
      torana dashboard <UUID> <verb>

    \b
    Examples:
      torana dashboards list
      torana dashboards create --name "Security Overview" --workspace-id <UUID>
    """


@dashboards.command(name="list")
@click.option("--workspace-id", default=None, help="Filter by workspace UUID.")
@click.option("--search", default=None, help="Search by name.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def dashboards_list(ctx, workspace_id, search, page, page_size, fetch_all):
    """List dashboards."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"page": page, "page_size": effective_page_size}
    if workspace_id:
        params["workspace_id"] = workspace_id
    if search:
        params["search"] = search

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"page": page_num, "page_size": effective_page_size}
                p.update({k: v for k, v in params.items() if k not in ("page", "page_size")})
                data = client.get("api/v2/dashboards", params=p)
                items = data.get("items", [])
                all_items.extend(items)
                if len(all_items) >= data.get("total", len(all_items)):
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items), "page": 1,
                      "page_size": len(all_items)}
        else:
            result = client.get("api/v2/dashboards", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@dashboards.command(name="create")
@click.option("--name", default=None)
@click.option("--workspace-id", default=None, help="Workspace UUID.")
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def dashboards_create(ctx, name, workspace_id, input_file):
    """Create a new dashboard."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if workspace_id:
        body["workspace_id"] = workspace_id

    if not body.get("name"):
        click.echo("ERROR: --name is required.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post("dashboards/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created dashboard: {data.get('id', 'unknown')}")
