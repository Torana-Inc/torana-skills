"""torana dashboards — dashboard collection commands (list, create).

Instance commands live in dashboard.py (`torana dashboard <ID> <verb>`).
"""

import sys

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW, CollectionGroup
from torana_cli.output import output
from torana_cli.pagination import PagingError, fetch_all_pages
from torana_cli.rules import _load_input_file
from torana_cli.section_descriptions import fill_help_marker

#: The screen's list route returns at most this many dashboards per call and no total, so a
#: list is only complete once it has been walked page by page.
_PAGE = 100

START_HERE = """\b
    Start here:
      List an app's dashboards            torana dashboards list --app-id <APP_ID>
      Read a dashboard as the screen does torana dashboard <ID> render
      Read one widget                     torana widget <ID> render
      Sweep an app for stale or broken    torana app <APP_ID> widgets list --fail-on stale --fail-on error
      Find the app id                     torana apps list

    \b
    Ask a question about a widget:
      Why is it empty, who fixes it       torana widget <ID> render --section empty --section health
      Why is the number what it is        torana widget <ID> why
      Where the data comes from           torana widget <ID> provenance
      Which records are behind a number   torana widget <ID> decompose --key <COL>=<VALUE>
      More rows than the card shows       torana widget <ID> explore --page 2"""


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def fetch_dashboards(client, app_id=None) -> list:
    """Every dashboard of an app (or of the tenant), in the order the screen shows them.

    Calls the route the screen calls (`GET dashboards?workspace_id=&skip=&limit=`). It returns
    a bare list with no total, so the only way to know the list is complete is to walk it:
    a single call would silently drop the 101st dashboard. Each item embeds its `widgets`.
    """
    def page(index):
        params = {"skip": index * _PAGE, "limit": _PAGE}
        if app_id:
            params["workspace_id"] = app_id
        data = client.get("dashboards", params=params)
        rows = data.get("items", []) if isinstance(data, dict) else (data or [])
        return rows, None

    rows, _ = fetch_all_pages(page, page_size=_PAGE)
    return rows


def list_dashboards_core(ctx, *, app_id=None, search=None, page=None, page_size=None) -> None:
    """The one dashboards list, shared by `dashboards list` and `app <APP_ID> dashboards list`."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    try:
        rows = fetch_dashboards(_client(ctx), app_id)
    except PagingError as e:
        click.echo(f"ERROR: could not list every dashboard: {e}", err=True)
        sys.exit(1)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if search:
        needle = search.lower()
        rows = [d for d in rows if needle in (d.get("name") or "").lower()]
    total = len(rows)
    for d in rows:
        d["widget_count"] = len(d.get("widgets") or [])
    if page_size:
        start = ((page or 1) - 1) * page_size
        rows = rows[start:start + page_size]

    cols = [("id", "ID", None), ("name", "NAME", 40), ("widget_count", "WIDGETS", 7)]
    if not app_id:
        cols.append(("workspace_id", "APP_ID", None))
    cols.append(("description", "DESCRIPTION", 60))
    output({"items": rows, "total": total, "page": page or 1, "page_size": page_size or len(rows)},
           fmt=fmt, raw=raw, fields=fields, columns=cols)


@click.group(cls=CollectionGroup, singular="dashboard")
def dashboards():
    """Dashboards: list an app's dashboards, or create one.

    A dashboard is one tab of an app's Dashboards page: a named set of widgets.

    {START_HERE}

    \b
    Examples:
      torana dashboards list --app-id <APP_ID>
      torana dashboards create --name "Security Overview" --app-id <APP_ID>

    To read, change or delete one dashboard use the singular form, `torana dashboard <ID> ...`.
    """


def with_start_here(group):
    """Fill the `{START_HERE}` marker in a group's help with the shared Dashboards block."""
    group.help = fill_help_marker(group.help, "START_HERE", START_HERE)   # any indent: see fill_help_marker (B-55)
    return group


with_start_here(dashboards)


@dashboards.command(name="list")
@click.option("--app-id", "app_id", default=None,
              help="Only this app's dashboards (the id from `torana apps list`).")
@click.option("--search", default=None, help="Only dashboards whose name contains this text.")
@click.option("--page", default=None, type=int, help="Page to print, with --page-size.")
@click.option("--page-size", default=None, type=int, help="Rows per page. Default: every dashboard.")
@click.pass_context
def dashboards_list(ctx, app_id, search, page, page_size):
    """List the dashboards of an app, in the order the screen shows them.

    Use it to find a dashboard's id before reading it. The list is always complete: it is
    read page by page from the server. Without --app-id it lists every dashboard you can
    see, with the app each belongs to.

    \b
    Prints: ID, NAME, WIDGETS (how many widgets are on it), DESCRIPTION.
    Next:   torana dashboard <ID> render

    \b
    Examples:
      torana dashboards list --app-id <APP_ID>
      torana dashboards list --app-id <APP_ID> --search remediation
      torana dashboards list --app-id <APP_ID> --json
    """
    list_dashboards_core(ctx, app_id=app_id, search=search, page=page, page_size=page_size)


@dashboards.command(name="create")
@click.option("--name", default=None, help="The dashboard's name (the tab's label).")
@click.option("--app-id", "app_id", default=None, help="The app the dashboard belongs to.")
@click.option("--file", "input_file", default=None, metavar="FILE",
              help="JSON/YAML body (name, description, labels, app_id). Options override it.")
@click.pass_context
def dashboards_create(ctx, name, app_id, input_file):
    """Create a dashboard in an app.

    The new dashboard is empty. Add widgets with `torana widgets create --dashboard-id <ID>
    --file w.json` (a new widget) or `torana dashboard <ID> widgets add <WIDGET_ID>` (an
    existing one).

    \b
    Examples:
      torana dashboards create --name "Security Overview" --app-id <APP_ID>
      torana dashboards create --file dashboard.json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if app_id:
        body["workspace_id"] = app_id

    if not body.get("name"):
        click.echo("ERROR: --name is required.", err=True)
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post("dashboards/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created dashboard: {data.get('id', 'unknown')}")
