"""AI Home CLI — the surface the `torana-ai-home` skill drives.

Spec: pantheon-agent-builder/docs/Torana-AI-Home.md § 3.4.4

⭐ THIS MODULE IS WHAT MAKES HARNESS A POSSIBLE. The Claude Code skill has no
special access: it reads the facts through `ai-home facts`, writes the prose
itself, and posts the finished run back through `ai-home deposit`. So every
capability the skill needs MUST exist here — which makes the skill's requirements
the CLI-parity test, discovered at build time rather than at review (spec R-AH-45).

Commands live under the existing `workspace <id>` group; no new top-level group.
"""

import json
from datetime import datetime, timezone

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, handle_api_error, handle_auth_error
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_RAW
from torana_cli.output import output


#: ⭐ A RUN IS AN LLM CALL, NOT A QUERY. Narration plus a critic, up to the round
#: cap, over however many measures the app has — 66s on a 27-measure app, past 90
#: on a 54-measure one. The client's default read deadline is 90s, so the CLI
#: reported `The read operation timed out` on a run that SUCCEEDED server-side,
#: and the obvious next move for the operator is to start a second one.
#:
#: ⚠️ Matched to the nginx location for the same path (600s). Two deadlines sit on
#: this request and the shorter one is the one the user meets.
_RUN_TIMEOUT = 600.0

#: ⭐ AI Home V2 Phase C: a run is either the classic narrated page or a PROVEN page (rows proven before
#: narration, every sentence citing claim ids). Spec: pantheon-fe/docs/AI_HOME_V2_HOME_PROOF_SPEC.md § 3.4.7.
_KIND_OPTION = dict(type=click.Choice(["classic", "proven"]), default="classic", show_default=True,
                    help="Run kind: classic (the narrated page) or proven (AI Home V2: rows proven first, "
                         "every sentence cites proven claims).")
_WAIT_POLL_S = 5
#: Covers both passes of a proven run (Phase C.1): proving, the narrate queue (≤ AI_HOME_PROVEN_NARRATE_INTERVAL_SECONDS)
#: and narration (≤ 3 LLM rounds).
_WAIT_MAX_S = 20 * 60
_TERMINAL = ("success", "partial", "data_only", "failed", "timeout")


def _ctx(ctx):
    """(fmt, raw, fields) — the three output knobs every command threads through."""
    o = ctx.obj or {}
    return (
        o.get(CTX_FORMAT, "text"),
        o.get(CTX_RAW, False),
        o.get(CTX_FIELDS),
    )


#: Glyphs for the three coverage states.
#: ⚠️ GLYPH + LABEL, NEVER COLOUR ALONE. A red/green-only encoding is unreadable
#: for a colour-blind reader, and the shipped build_v2 iterations view already
#: sets this precedent.
_COVERAGE_GLYPH = {"measured": "●", "partial": "◐", "blind": "⊘", "not_yet": "○"}

# ⭐ DISPLAY LABELS, DELIBERATELY NOT THE WIRE VALUES. The resolver's `measured`
# asserts exactly one thing — rows arrived on a clock we trust — and readers hear it
# as "this number is trustworthy". Those differ, and the gap is worst on a ZERO:
# "KEV Exposure  0  [measured]" reads as a verified all-clear, when what was verified
# is that the query ran. "0 [live]" says the true thing.
#
# ⛔ The STATE KEY stays `measured` on the wire and in storage. 24 stored runs carry it
# in coverage_mix JSONB, and ai_home_admin.py aggregates history BY THAT KEY — renaming
# the value would silently zero every historical run's count, breaking the trend data
# just as we start using it, and would break any client on an older build.
_COVERAGE_LABEL = {
    "measured": "live", "partial": "stale", "blind": "blind",
    # ⭐ NOT A KIND OF BLINDNESS. The platform can measure this; nobody has recorded
    # anything into it yet. Reporting that as "blind" loses twice — the user never
    # learns the capability exists, and never learns they are not using it.
    "not_yet": "not yet",
}


def _age(seconds) -> str:
    """A page's age in plain words ("45 s", "10 min", "2.0 h")."""
    if seconds is None:
        return "unknown age"
    seconds = int(seconds)
    if seconds < 90:
        return f"{seconds} s"
    if seconds < 5400:
        return f"{round(seconds / 60)} min"
    return f"{seconds / 3600:.1f} h"


def _cov(state: str) -> str:
    """Glyph + label for a coverage state, e.g. '● live'."""
    return f"{_COVERAGE_GLYPH.get(state, '·')} {_COVERAGE_LABEL.get(state, state)}"


def register(workspace_group, client_factory):
    """Attach the `ai-home` sub-group to the `workspace <id>` group.

    Registered from workspace.py so this module owns its own commands without
    that file growing another 300 lines.
    """

    def _wid(ctx) -> str:
        return ctx.obj.get("_workspace_id", "") if ctx.obj else ""

    @workspace_group.group(name="ai-home", invoke_without_command=True)
    @click.pass_context
    def ai_home(ctx):
        """The AI Home page: what needs you, what changed, what we cannot see."""
        ctx.ensure_object(dict)
        if ctx.invoked_subcommand is None:
            click.echo(ctx.get_help())

    # ── read ─────────────────────────────────────────────────────────────────

    @ai_home.command(name="facts")
    # ⭐ SURFACE PARITY. The API takes `?template=`; without the same option here
    # the CLI (and therefore the skill, which drives the CLI) could only ever see
    # the default arrangement — so a template would be testable from curl and not
    # from the surface people actually use.
    @click.option("--template", "template", default=None,
                  help="Page template: home (default), console, briefing, or assessment.")
    @click.option("--output", "out_file", default=None,
                  help="Write the payload to a file instead of stdout.")
    @click.pass_context
    def ai_home_facts(ctx, template, out_file):
        """Assemble the facts payload WITHOUT narrating it.

        ⭐ The skill's input. Runs the whole data layer — measures with resolved
        coverage, the since-window, attention items, supply gaps — and returns it
        un-narrated, so Claude can write the prose and deposit the result.
        """
        fmt, raw, fields = _ctx(ctx)
        try:
            path = f"workspaces/{_wid(ctx)}/ai-home/facts"
            if template:
                path += f"?template={template}"
            data = client_factory(ctx).get(path)
        except APIError as e:
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return

        if out_file:
            with open(out_file, "w") as fh:
                json.dump(data, fh, indent=2)
            mix = (data or {}).get("coverage_mix") or {}
            click.echo(
                f"✓ Wrote facts to {out_file} "
                f"({len((data or {}).get('measures') or [])} measures; "
                f"live {mix.get('measured', 0)} / stale {mix.get('partial', 0)} "
                f"/ blind {mix.get('blind', 0)})"
            )
            return

        output(data, fmt=(fmt if fmt in ("json", "yaml") else "json"),
               raw=raw, fields=fields)

    # ── the editable instruction ─────────────────────────────────────────────
    # ⭐ THE PAGE SAYS WHY THESE THINGS AND NOT OTHERS. Each section follows one
    # line of plain English, and the reader can change it. Surfaced here as well
    # as in the UI because the narrator drives the CLI: an instruction it cannot
    # read is an instruction the page cannot follow.

    @ai_home.group(name="highlights", invoke_without_command=True)
    @click.pass_context
    def ai_home_highlights(ctx):
        """What this app highlights in each section. Use `list` to see them."""
        ctx.ensure_object(dict)
        if ctx.invoked_subcommand is None:
            click.echo(ctx.get_help())

    @ai_home_highlights.command(name="list")
    @click.pass_context
    def ai_home_highlights_list(ctx):
        """Show each section's instruction, and whose words it is.

        Examples:
          torana workspace <id> ai-home highlights list
        """
        fmt, raw, fields = _ctx(ctx)
        try:
            data = client_factory(ctx).get(
                f"workspaces/{_wid(ctx)}/ai-home/highlights"
            )
        except APIError as e:
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return

        if fmt in ("json", "yaml"):
            output(data, fmt=fmt, raw=raw, fields=fields)
            return
        for name, sec in ((data or {}).get("sections") or {}).items():
            # ⚠️ The SOURCE is shown beside every line. "Whose words is the page
            # following?" is the question this surface exists to answer, and a
            # bare list of sentences cannot answer it.
            tag = "[app]" if sec.get("source") == "app" else "[default]"
            click.echo(f"\n  {name}  {tag}")
            click.echo(f"    {sec.get('text')}")

    @ai_home_highlights.command(name="set")
    @click.option("--section", required=True,
                  help="Which section: needs_you, handled, rules, dashboards, health.")
    @click.option("--text", default=None,
                  help="The instruction, in plain English.")
    @click.option("--reset", is_flag=True, default=False,
                  help="Restore this section's default instruction.")
    @click.pass_context
    def ai_home_highlights_set(ctx, section, text, reset):
        """Set what a section highlights, in plain English.

        ⛔ AN INSTRUCTION SELECTS, IT NEVER CALCULATES. It can say which findings
        lead; it can never change a number, a coverage state, or empty a section.

        Examples:
          torana workspace <id> ai-home highlights set --section dashboards \
            --text "Lead with what to fix first; upgrades second."
          torana workspace <id> ai-home highlights set --section handled --reset
        """
        fmt, raw, fields = _ctx(ctx)
        if reset:
            text = None
        elif not (text or "").strip():
            raise click.UsageError("Give --text, or --reset to restore the default.")
        try:
            data = client_factory(ctx).put(
                f"workspaces/{_wid(ctx)}/ai-home/highlights",
                {"sections": {section: text}},
            )
        except APIError as e:
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return

        if fmt in ("json", "yaml"):
            output(data, fmt=fmt, raw=raw, fields=fields)
            return
        sec = ((data or {}).get("sections") or {}).get(section) or {}
        state = "reset to the default" if sec.get("source") != "app" else "set"
        click.echo(f"✓ {section} {state}")
        click.echo(f"  {sec.get('text')}")
        # ⚠️ THE PAGE DOES NOT CHANGE UNTIL IT IS REGENERATED. Saying so here
        # stops the next command being "why did nothing happen?".
        click.echo("  Takes effect on the next run: "
                   f"torana workspace {_wid(ctx)} ai-home run")

    @ai_home.command(name="get")
    @click.option("--run", "run_id", default=None,
                  help="Show this earlier run's page instead of the latest "
                       "(ids from `ai-home runs`; only finished runs have a page).")
    @click.option("--kind", **_KIND_OPTION)
    @click.pass_context
    def ai_home_get(ctx, run_id, kind):
        """Show the latest generated AI Home page, or an earlier run's with --run.

        --kind proven prints the proven run's head, then the classic layout. To see the AI Home V2 page as it
        shows it (decision cards, in page order), use `torana workspace <ID> ai-home-v2 get`.

        Examples:
          torana workspace <ID> ai-home get
          torana workspace <ID> ai-home get --kind proven
          torana workspace <ID> ai-home get --kind proven --format json
        """
        fmt, raw, fields = _ctx(ctx)
        params = {"kind": kind}
        if run_id:
            params["run_id"] = run_id
        try:
            data = client_factory(ctx).get(f"workspaces/{_wid(ctx)}/ai-home", params=params)
        except APIError as e:
            # ⚠️ 404 here is a STATE, not an error: the page has never been
            # generated. Say so plainly and name the command that fixes it,
            # rather than printing a bare "not found".
            if getattr(e, "status_code", None) == 404 and not run_id:
                if kind == "proven":
                    _first_proven_hint(_wid(ctx))
                    return
                click.echo("No AI Home page yet for this workspace.")
                click.echo("  Generate one:  torana workspace <id> ai-home run")
                return
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return

        if fmt in ("json", "yaml"):
            output(data, fmt=fmt, raw=raw, fields=fields)
            return

        if (data or {}).get("produced_by") == "torana_proven":
            _render_proven_head(data, _wid(ctx))
            data = {**data, "narration": _flatten_cited(data.get("narration"))}
        _render_page(data)

    @ai_home.command(name="proof")
    @click.option("--run", "run_id", default=None, help="A proven run id (from `ai-home runs --kind proven`); "
                  "default: the latest proven page.")
    @click.pass_context
    def ai_home_proof(ctx, run_id):
        """Show the proof behind the latest (or a given) proven AI Home page.

        Prints how many candidates were proven, the proven items by type, the decision groups (rows that are one
        decision), the home summary computed by code over the chosen rows, and any item that could not be proven.
        Read-only.

        Examples:
          torana workspace <ID> ai-home proof
          torana workspace <ID> ai-home proof --run <RUN_ID>
          torana workspace <ID> ai-home proof --format json
        """
        fmt, raw, fields = _ctx(ctx)
        params = {"kind": "proven"}
        if run_id:
            params["run_id"] = run_id
        try:
            data = client_factory(ctx).get(f"workspaces/{_wid(ctx)}/ai-home", params=params)
        except APIError as e:
            if getattr(e, "status_code", None) == 404 and not run_id:
                _first_proven_hint(_wid(ctx))
                return
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return
        proof = (data or {}).get("proof") or {}
        if fmt in ("json", "yaml"):
            output(proof, fmt=fmt, raw=raw, fields=fields)
            return
        _render_proof(data.get("run_id"), proof, _wid(ctx))

    @ai_home.command(name="gaps")
    @click.pass_context
    def ai_home_gaps(ctx):
        """What this app CANNOT answer yet, and who can fix it."""
        fmt, raw, fields = _ctx(ctx)
        try:
            data = client_factory(ctx).get(f"workspaces/{_wid(ctx)}/ai-home/gaps")
        except APIError as e:
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return

        if fmt in ("json", "yaml"):
            output(data, fmt=fmt, raw=raw, fields=fields)
            return

        if not (data or {}).get("available"):
            # ⛔ NOT "no gaps". We could not check, and claiming a clean bill of
            # health from a failed check is the exact dishonesty this page exists
            # to remove.
            click.echo("⚠ Could not check what this app cannot answer right now.")
            return

        arts = (data or {}).get("artifacts") or []
        click.echo(f"Checked {len(arts)} deployed artifact(s).")

        # ⛔ FIELD NAMES ARE THE PAYLOAD'S, NOT GUESSES. This block rendered 68 rows of
        # "?  -" until 2026-09-06 because it read `verdict`/`name`, which the gaps payload
        # has never emitted — it carries `answerable`/`artifact_name`. Every fallback in the
        # chain missed, so the failure looked like "no data" rather than "wrong key", and the
        # whole owner/blocking story the supply graph already computes stayed invisible.
        # If you add a field here, read it from a live payload first.
        summary = (data or {}).get("summary") or {}
        if summary:
            click.echo("  " + "  ".join(f"{k}={v}" for k, v in sorted(summary.items())))
            click.echo("")

        for a in arts:
            verdict = a.get("answerable") or "?"
            name = a.get("artifact_name") or a.get("artifact_id") or "-"
            owner = a.get("owner") or ""
            click.echo(f"  {verdict:26s} {name:34s} {owner}")
            # The blocking column IS the fix instruction — without it the row says a thing
            # is unanswerable but not what would answer it.
            for b in (a.get("blocking") or [])[:3]:
                click.echo(
                    f"      blocked by {b.get('table')}.{b.get('column')} "
                    f"[{b.get('verdict')}]"
                )

    @ai_home.command(name="runs")
    @click.option("--limit", default=20, show_default=True, type=int)
    @click.option("--kind", **_KIND_OPTION)
    @click.pass_context
    def ai_home_runs(ctx, limit, kind):
        """List AI Home runs for this workspace.

        Examples:
          torana workspace <ID> ai-home runs
          torana workspace <ID> ai-home runs --kind proven
        """
        fmt, raw, fields = _ctx(ctx)
        try:
            data = client_factory(ctx).get(
                f"workspaces/{_wid(ctx)}/ai-home/runs", params={"limit": limit, "kind": kind}
            )
        except APIError as e:
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return

        items = (data or {}).get("items", [])
        wrapped = {"items": items, "total": len(items), "page": 1,
                   "page_size": len(items)}
        # ⛔ THE ENDPOINT ALREADY RETURNS coverage_mix PER RUN AND THIS TABLE DROPPED IT.
        # The page reports levels and never change — "is 10 blind better or worse than
        # yesterday?" had no answer on any surface, though every run persists its mix in
        # `ai_home_runs.coverage_mix` and `GET .../ai-home/runs` serves it. One column
        # turns this list into the trend view, with no new endpoint and no new store.
        for it in items:
            m = it.get("coverage_mix") or {}
            it["coverage"] = (
                f"{m.get('measured', 0)}/{m.get('partial', 0)}/{m.get('blind', 0)}"
                if m else "—"
            )
        # ⭐ WHICH RUN IS THE PAGE READERS SEE. A run that could not read a source is recorded as failed and the
        # previous good page stays shown; without these two columns a column of `failed` looked like "no page".
        for it in items:
            it["shown"] = "◀ shown" if it.get("is_shown") else ""
            it["error"] = (it.get("error") or "")[:60]
        shown_page = (data or {}).get("shown_page") or {}
        if fmt not in ("json", "yaml") and shown_page:
            click.echo(f"Page shown: run {shown_page.get('run_id')} · {_age(shown_page.get('age_seconds'))} old")
        elif fmt not in ("json", "yaml"):
            click.echo("Page shown: none yet")
        sched = (data or {}).get("schedule") or {}
        if fmt not in ("json", "yaml") and sched:
            if sched.get("enabled"):
                nxt = sched.get("next_due_at") or ("— (generate a page once to start it)" if kind == "classic" else "the next prove tick (first page)")
                click.echo(f"Scheduled: every {sched.get('refresh_minutes')} min · next due {nxt}")
            else:
                click.echo("Scheduled: off (AI_HOME_SCHEDULER_ENABLED=false)" if kind == "classic"
                           else "Scheduled: off (AI_HOME_PROVEN_SCHEDULER_DISABLED=true)")
        output(wrapped, fmt=fmt, raw=raw, fields=fields, columns=[
            ("run_id", "RUN", 38),
            ("status", "STATUS", 9),
            # Proven runs (Phase C.1): proving → queued_for_llm → writing → done; classic: running → done.
            ("stage", "STAGE", 15),
            # Who started it: 'scheduled' (the AI Home scheduler) or 'manual'.
            ("trigger", "TRIGGER", 10),
            # ⭐ Which harness wrote it — the SA must always be able to tell.
            ("produced_by", "BY", 18),
            ("critique_rounds_used", "RNDS", 5),
            # live/stale/blind at that run — read DOWN the column to see the trend.
            ("coverage", "L/S/B", 10),
            ("started_at", "STARTED", 20),
            # The run's own words when it failed ("render_widgets timed out after 120 s (ReadTimeout)").
            ("error", "ERROR", 60),
            ("shown", "SHOWN", 9),
        ])

    @ai_home.command(name="run-detail")
    @click.argument("run_id")
    @click.pass_context
    def ai_home_run_detail(ctx, run_id):
        """Inspect ONE run: stages, critique rounds, findings, why it said that.

        ⛔ Deliberately NOT under `torana admin`. A run belongs to a workspace, so
        its detail sits beside the page it produced — matching the shipped Advisor
        precedent (`workspace <id> sweeps get`). Only genuinely CROSS-TENANT views
        live under `admin`; forcing a tenant to leave their own app to see why
        their own page says what it says would be the wrong shape.
        """
        fmt, raw, fields = _ctx(ctx)
        try:
            data = client_factory(ctx).get(
                f"workspaces/{_wid(ctx)}/ai-home/runs/{run_id}"
            )
        except APIError as e:
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return

        if fmt in ("json", "yaml"):
            output(data, fmt=fmt, raw=raw, fields=fields)
            return

        d = data or {}
        click.echo("")
        click.echo(f"  run       {d.get('run_id')}")
        click.echo(f"  status    {d.get('status')}   stage {d.get('stage')}   by {d.get('produced_by')}")
        # ⭐ A run that could not read a source says why, and which page readers are still shown instead.
        if d.get("error"):
            click.echo(f"  error     {d.get('error')}")
        sp = d.get("shown_page") or {}
        if d.get("is_shown"):
            click.echo("  shown     this run is the page readers are shown")
        elif sp:
            click.echo(f"  shown     run {sp.get('run_id')} · {_age(sp.get('age_seconds'))} old")
        if d.get("note"):
            click.echo(f"  note      {d.get('note')}")
        click.echo(f"  window    {d.get('since_at')} → {d.get('now_at')}")
        mix = d.get("coverage_mix") or {}
        if mix:
            click.echo(
                f"  coverage  live {mix.get('measured', 0)}  "
                f"stale {mix.get('partial', 0)}  blind {mix.get('blind', 0)}  "
                f"not yet {mix.get('not_yet', 0)}"
            )
        fp = d.get("config_fingerprint") or {}
        if fp:
            # ⭐ What produced this page. Without it, "did last week's prompt
            # change help?" has no answer.
            click.echo(f"  prompt    {fp.get('prompt_hash')}")
            click.echo(f"  schema    {fp.get('output_schema_hash')}")

        errs = d.get("collector_errors") or []
        if errs:
            click.echo("")
            click.echo(f"  {len(errs)} source(s) could not be read:")
            for e in errs:
                click.echo(f"    {e.get('source')} — {e.get('error')}")

        rounds = d.get("rounds") or []
        click.echo("")
        cap = " (cap exhausted)" if d.get("cap_exhausted") else ""
        click.echo(f"  {len(rounds)} critique round(s){cap}")
        for r in rounds:
            # ⚠️ critic_ran=False means the critic was UNAVAILABLE and the run
            # degraded open — the page shipped un-critiqued. That is a different
            # thing from a clean review and must not read the same.
            probs = (r.get("findings") or {}).get("problems") if isinstance(r.get("findings"), dict) else None
            if probs is not None:
                # A proven run: the CODE critic ran; its problems were fed back to the narrator verbatim.
                verdict = "accepted" if r.get("verdict_valid") else f"{len(probs)} problem(s)"
                click.echo(f"    #{r.get('round_index')}  code critic: {verdict}")
                for p in probs[:10]:
                    click.echo(f"        {str(p)[:110]}")
                continue
            if not r.get("critic_ran"):
                click.echo(f"    #{r.get('round_index')}  critic did not run "
                           f"— page shipped un-critiqued")
                continue
            verdict = "valid" if r.get("verdict_valid") else "NOT valid"
            click.echo(f"    #{r.get('round_index')}  {verdict}")
            fnd = (r.get("findings") or {}).get("findings") or []
            for f in fnd:
                click.echo(f"        [{f.get('severity')}] {f.get('category')}: "
                           f"{str(f.get('message'))[:88]}")

        note = d.get("llm_calls_note")
        if note:
            click.echo("")
            click.echo(f"  {note}")
        click.echo("")

    # ── write ────────────────────────────────────────────────────────────────

    @ai_home.command(name="run")
    # Same parity point as `facts` above — the agent path must be able to pick a
    # template too, or the two producers of a page disagree about its shape.
    @click.option("--template", "template", default=None,
                  help="Page template: console (default), briefing, or assessment.")
    @click.option("--kind", **_KIND_OPTION)
    @click.option("--wait", is_flag=True, default=False,
                  help="Proven runs return at once: poll every 5 s (up to 20 min) through proving and the narrate "
                       "pass, and print the terminal status.")
    @click.pass_context
    def ai_home_run(ctx, template, kind, wait):
        """Generate a new AI Home page (Torana harness).

        Examples:
          torana workspace <ID> ai-home run
          torana workspace <ID> ai-home run --kind proven --wait
        """
        fmt, raw, fields = _ctx(ctx)
        try:
            rpath = f"workspaces/{_wid(ctx)}/ai-home/run?kind={kind}"
            if template:
                rpath += f"&template={template}"
            data = client_factory(ctx).post(rpath, {}, timeout=_RUN_TIMEOUT)
        except APIError as e:
            # ⚠️ 409 means a run is already in flight — a normal, expected state
            # under concurrent triggers, not a failure the user should decode.
            if getattr(e, "status_code", None) == 409:
                click.echo("A run is already in progress for this workspace.")
                return
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return

        if wait and data.get("status") == "in_progress":
            data = _wait_for_run(ctx, client_factory, _wid(ctx), data.get("run_id")) or data
        if fmt in ("json", "yaml"):
            output(data, fmt=fmt, raw=raw, fields=fields)
            return
        click.echo(f"✓ Run {data.get('run_id')} — {data.get('status')}")
        if data.get("status") == "in_progress" and not wait:
            click.echo(f"  Follow it:  torana workspace {_wid(ctx)} ai-home run-detail {data.get('run_id')}")

    @ai_home.command(name="deposit")
    @click.option("-f", "--file", "in_file", required=True,
                  help="JSON file: {facts_payload, narration, rounds?, config_fingerprint?}.")
    @click.pass_context
    def ai_home_deposit(ctx, in_file):
        """Deposit a complete run produced by the Claude Code harness.

        ⛔ The server runs the SAME mechanical validation as the agent path. A 422
        names the offending claim and persists nothing — a citation that is not in
        the facts payload is rejected, never quietly kept.
        """
        fmt, raw, fields = _ctx(ctx)
        try:
            with open(in_file) as fh:
                body = json.load(fh)
        except (OSError, ValueError) as e:
            raise click.ClickException(f"Could not read {in_file}: {e}")

        if "facts_payload" not in body:
            raise click.ClickException(
                "The file must contain 'facts_payload' (from `ai-home facts`) "
                "and 'narration'."
            )

        try:
            data = client_factory(ctx).post(
                f"workspaces/{_wid(ctx)}/ai-home/runs", body
            )
        except APIError as e:
            if getattr(e, "status_code", None) == 422:
                click.echo("✗ The narration failed validation. Nothing was saved.")
                # ⭐ NAMING THE OFFENDING CLAIM IS THE POINT. The skill's
                # self-correction loop reads these lines to fix its own output; a
                # bare "validation error" would make the loop guess.
                # ⚠️ The attribute is `detail` (APIError.__init__), NOT
                # `response_data` — and the server nests the list under
                # detail.detail.problems.
                detail = getattr(e, "detail", None)
                problems = []
                if isinstance(detail, dict):
                    inner = detail.get("detail")
                    if isinstance(inner, dict):
                        problems = inner.get("problems") or []
                    elif isinstance(detail.get("problems"), list):
                        problems = detail["problems"]
                for p in problems[:10]:
                    click.echo(f"  - {p}")
                if not problems:
                    click.echo(f"  {e}")
                raise SystemExit(1)
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return

        if fmt in ("json", "yaml"):
            output(data, fmt=fmt, raw=raw, fields=fields)
            return
        click.echo(f"✓ Deposited run {data.get('run_id')} ({data.get('status')})")

    @ai_home.command(name="feedback")
    @click.option("--run-id", required=True)
    @click.option("--zone", required=True,
                  help="Z0..Z6, or 'page' for the whole render.")
    @click.option("--rating", required=True, type=int, help="+1 or -1.")
    @click.option("--comment", default=None)
    @click.pass_context
    def ai_home_feedback(ctx, run_id, zone, rating, comment):
        """Give per-ZONE feedback on a generated page.

        ⭐ Zone-level, because "the questions are useless but the blind block is
        the best thing here" is actionable and a page-level thumb is not.
        """
        body = {"run_id": run_id, "zone": zone, "rating": rating}
        if comment:
            body["comment"] = comment
        try:
            client_factory(ctx).post(
                f"workspaces/{_wid(ctx)}/ai-home/feedback", body
            )
        except APIError as e:
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return
        click.echo(f"✓ Recorded {'+1' if rating > 0 else '-1'} on {zone}")

    return ai_home


def _first_proven_hint(wid: str) -> None:
    """No proven page yet: the scheduler prepares the first one (Phase C.1); nobody has to generate it."""
    click.echo("The first proven page is being prepared; it appears within a few minutes.")
    click.echo(f"  Follow it:  torana workspace {wid} ai-home runs --kind proven")


def _wait_for_run(ctx, client_factory, wid, run_id):
    """Poll GET …/ai-home/runs/{run_id} until it is terminal (or 20 min), printing each stage change on stderr
    (proving → queued_for_llm → writing). Returns {run_id, status} or None."""
    import time
    deadline = time.monotonic() + _WAIT_MAX_S
    seen = None
    while time.monotonic() < deadline:
        time.sleep(_WAIT_POLL_S)
        try:
            d = client_factory(ctx).get(f"workspaces/{wid}/ai-home/runs/{run_id}")
        except (APIError, AuthError):
            continue
        stage = (d or {}).get("stage")
        if stage and stage != seen and stage != "done":
            click.echo(f"  … {stage}", err=True)
            seen = stage
        if (d or {}).get("status") in _TERMINAL:
            return {"run_id": run_id, "status": d["status"]}
    click.echo(f"Still running after {_WAIT_MAX_S // 60} min; check `ai-home run-detail {run_id}`.")
    return None


def _cited_text(v) -> str:
    return v.get("text", "") if isinstance(v, dict) else (v or "")


def _flatten_cited(narr):
    """A proven narration in the classic shape: every CitedText replaced by its text (review G7)."""
    if not isinstance(narr, dict):
        return narr
    out = dict(narr)
    for k in ("title_sentence", "scope_sentence"):
        if k in out:
            out[k] = _cited_text(out[k])
    out["attention_items"] = [
        {**a, "headline": _cited_text(a.get("headline")), "recommendation": _cited_text(a.get("recommendation"))}
        for a in narr.get("attention_items") or []]
    return out


_NOTICED_GLYPH = {"group": "◆", "stale": "▲", "unjudged": "○", "drift": "◇"}
#: The Inbox's "open" (non-terminal) statuses: what the page's "See them in the Inbox →" filters to.
_OPEN_STATUSES = "open,queued,triaging,awaiting_input,pending_remediation,escalated"


def _home_lines(home: dict, workspace_id, indent: str) -> list:
    """The noticed lines, then home v2's whole-run stale line and "the rest" (pantheon_shared.proof.home), as the
    page shows them. A run stored before home v2 has no `stale`/`rest` key: its noticed lines are printed as stored."""
    has_stale = "stale" in home
    out = [f"{indent}{_NOTICED_GLYPH.get(n.get('kind'), '·')} {n.get('text')}"
           for n in home.get("noticed") or [] if not (has_stale and n.get("kind") == "stale")]
    if home.get("stale"):
        out.append(f"{indent}▲ {home['stale'].get('text')}")
    rest = home.get("rest")
    if rest:
        out.append(f"{indent}⋯ {rest.get('text')}")
        out.append(f"{indent}  see them: torana alerts list --workspace-id {workspace_id or '<UUID>'} --status {_OPEN_STATUSES}")
    return out


def _bold_marked(note) -> str:
    """A funnel note marks the words to catch with `**…**` (pantheon_shared.proof.home): print them bold."""
    parts = str(note or "").split("**")
    return "".join(click.style(p, bold=True) if i % 2 else p for i, p in enumerate(parts))


def _funnel_lines(home: dict, indent: str) -> list:
    """"How we got here" (home v3, pantheon_shared.proof.home.funnel): the page's collapsed line, then every step as
    the page lists it, count WITH its unit and what was done. Read, never computed. A pre-v3 run prints nothing."""
    steps = home.get("funnel") or []
    if not steps or not home.get("funnel_summary"):
        return []
    out = [f"{indent}▽ {home['funnel_summary']} · how we got here:"]
    for i, st in enumerate(steps, 1):
        n = "—" if st.get("count") is None else f"{st['count']:,}"
        out.append(f"{indent}  {i}. {n} {st.get('unit')} · {_bold_marked(st.get('note'))}")
    return out


#: Where each "can I trust this page" line is explained (home v4 `trust[].see`). The page links the same places;
#: measure dates have no CLI listing with dates, so that line carries no command.
_TRUST_SEE = {"rule_supply": "torana workspace {ws} ai-home gaps", "rule_runs": "torana workspace {ws} rules list"}


def _trust_lines(home: dict, workspace_id, indent: str) -> list:
    """Z2 on a proven page (pantheon_shared.proof.home.trust): one plain sentence per problem, rules first; nothing
    when every figure is measured and every rule ran with none blocked. Read, never computed."""
    out = []
    for t in home.get("trust") or []:
        out.append(f"{indent}{t.get('glyph')} {_bold_marked(t.get('text'))}")
        cmd = _TRUST_SEE.get(t.get("see"))
        if cmd:
            out.append(f"{indent}  see why: {cmd.format(ws=workspace_id or '<UUID>')}")
    return out


def _render_proven_head(data: dict, workspace_id=None) -> None:
    """The proven page's own lines, before the classic render: hero, noticed, rows with their citations."""
    proof = data.get("proof") or {}
    home = proof.get("home") or {}
    narr = data.get("narration") or {}
    click.echo("")
    click.echo(f"  PROVEN · {home.get('hero') or '—'}   (proved {proof.get('built_at') or '—'})")
    # The highlight (home v4, pantheon_shared.proof.home.highlight): chosen by what needs doing, written by code.
    if home.get("highlight"):
        click.echo(f"  ◆ {home['highlight'].get('title')}")
        click.echo(f"    why this one: {home['highlight'].get('reason')}")
    for line in _funnel_lines(home, "  "):
        click.echo(line)
    for line in _trust_lines(home, workspace_id, "  "):
        click.echo(line)
    for line in _home_lines(home, workspace_id, "  "):
        click.echo(line)
    if not narr:
        click.echo("  (no accepted narration: rows are shown from facts; `ai-home run-detail` says why)")
    chips = home.get("chips") or {}
    for i, a in enumerate(narr.get("attention_items") or [], 1):
        key = a.get("item_key")
        click.echo("")
        click.echo(f"  {i}. {_cited_text(a.get('headline'))}")
        click.echo(f"     → {_cited_text(a.get('recommendation'))}")
        cites = list(dict.fromkeys((a.get("headline") or {}).get("cites", []) +
                                   (a.get("recommendation") or {}).get("cites", [])))
        click.echo(f"     cites: {', '.join(cites)}")
        tags = [c.get("text") for c in chips.get(key) or []]
        if tags:
            click.echo(f"     [{'] ['.join(tags)}]")
        click.echo(f"     proof: torana alert {key} proof")
    click.echo("")
    click.echo("  ── classic render ──")


def _render_proof(run_id, proof: dict, workspace_id=None) -> None:
    from collections import Counter
    items = proof.get("items") or []
    click.echo(f"Proven run {run_id} · built {proof.get('built_at')} · framework {proof.get('framework')}")
    click.echo(f"  candidates {proof.get('candidates')} · proven {len(items)} · errors {len(proof.get('errors') or [])}")
    drawn = Counter(it.get("type") for it in items if it.get("has_graph"))
    for t, n in Counter(it.get("type") for it in items).most_common():
        click.echo(f"    {n:4d}  {t}  · {drawn.get(t, 0)} with a graph")
    groups = proof.get("groups") or []
    click.echo(f"  decision groups: {len(groups)}")
    for g in groups:
        click.echo(f"    {g.get('gid')}  {g.get('text')}")
    home = proof.get("home") or {}
    if home:
        click.echo(f"  home: {home.get('hero')}")
        for line in _funnel_lines(home, "    "):
            click.echo(line)
        for line in _home_lines(home, workspace_id, "    "):
            click.echo(line)
    for e in proof.get("errors") or []:
        click.echo(f"  ✗ {e.get('alert_id')}  {e.get('status')}  {str(e.get('detail'))[:90]}")


def _ago(iso) -> str:
    try:
        dt = datetime.fromisoformat(str(iso).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return str(iso)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    secs = max(0, (datetime.now(timezone.utc) - dt).total_seconds())
    if secs < 90:
        return "just now"
    if secs < 5400:
        return f"{int(secs // 60)}m ago"
    if secs < 172800:
        return f"{int(secs // 3600)}h ago"
    return f"{int(secs // 86400)}d ago"


def _clock_line(measure: dict) -> str:
    """The three clocks of one measure, read together, on the detail line.

    ⛔ R-AH-13: the headline keeps ONE clock. This line sits under the number, beside
    its provenance, because "computed recently" and "data is recent" are different
    claims and a reader who sees only one takes it for both.

    T-21: a PUSHED source (a SARIF upload) has no schedule, so it never sets "data as of"
    or the verdict; its age is shown beside it instead ("pushed data last push 3d ago").
    When every source is pushed there is no data clock at all, only "pushed data · last
    push X". Same wording as the FE's measure-clocks pipe.
    """
    as_of, ran = measure.get("as_of"), measure.get("query_ran_at")
    pushed = measure.get("pushed_as_of")
    if not (as_of or ran or pushed):
        return ""
    push_only = measure.get("freshness") == "pushed"
    if push_only:
        data_part = "pushed data"
    else:
        data_part = f"data as of {_ago(as_of)}" if as_of else "data age unknown"
    push_part = ""
    if pushed:
        oldest = measure.get("pushed_oldest_as_of")
        lead = "last push" if push_only else "pushed data last push"
        push_part = f" · {lead} {_ago(pushed)}" + (
            f", oldest sender {_ago(oldest)}" if oldest else "")
    ran_part = f" · computed {_ago(ran)}" if ran else ""
    return f"viewed now · {data_part}{push_part}{ran_part}"


def _render_page(data: dict, only: set | None = None) -> None:
    """Render the page as an operator would read it — zones in fixed order.

    `only`: print just these template zones (no header, counters or masthead). `ai-home-v2 get` calls it once per
    zone it shares with the classic page, in the V2 template's order, so the two never render a zone two ways.

    ⚠️ This mirrors the FE's zone order deliberately (spec § 3.0.0a). The order is
    the order a person can act in: what needs you, what is wrong, what you cannot
    see. Reordering here would teach a different page than the UI shows.
    """
    ws = (data.get("facts") or {}).get("workspace") or {}
    narr = data.get("narration") or {}
    full = only is None
    if not full:
        data = {**data, "_only_zones": set(only)}

    # ── Z0 header ────────────────────────────────────────────────────────────
    # ⛔ `source_bundle_id` IS NOT "WHERE THIS PAGE'S CONTENT CAME FROM". It is stamped
    # when an install STARTS and never cleared on failure, and it is last-write-wins across
    # bundles. Measured on Classie 2026-09-06: the header read "(remediation_ops v9)" while
    # that install had FAILED (3 of 4 links deployed, then a name collision rolled back the
    # rest) — and two other bundles had contributed most of the page. A bare chip states a
    # clean provenance the workspace does not have, so the status rides with it.
    chip = ""
    if ws.get("source_bundle_id"):
        _st = (ws.get("install_status") or "").lower()
        _note = {
            "install_failed": ", install failed",
            "installing": ", installing",
        }.get(_st, "")
        chip = (
            f"  ({ws.get('source_bundle_id')} v{ws.get('source_bundle_version')}"
            f"{_note}; most recent install only)"
        )
    if full:
        click.echo(f"\n{ws.get('name') or 'Workspace'}{chip}")
        click.echo(f"{data.get('window_label') or ''} · generated {data.get('generated_at')}")
        click.echo(f"produced by {data.get('produced_by')} · status {data.get('status')}")

    if full and not narr:
        # ⛔ THE DEGRADATION PATH IS A FIRST-CLASS RENDER, not an error. Narration
        # failed (or was never written); the numbers, coverage and gaps are all
        # still here, so the page is useful — it just does not read as prose.
        click.echo("\n(no narration — showing measured data only)")

    # ── Z1 answer sentence ───────────────────────────────────────────────────
    if full and narr.get("title_sentence"):
        click.echo(f"\n{narr['title_sentence']}")
    # ⭐ THE DENOMINATOR, directly under the headline. The title says what is
    # wrong; this says over what estate — and a count without its population
    # cannot be told apart from a small sample.
    if full and narr.get("scope_sentence"):
        click.echo(f"{narr['scope_sentence']}")

    # ── Z0 act-first ─────────────────────────────────────────────────────────
    # ⭐ THE PAGE'S ANSWER TO "what do I do now?", above every piece of evidence.
    # Measured before this existed: the first actionable block sat 5,047px down a
    # 12,112px page, so the page showed a great deal and instructed nothing.
    _af = narr.get("act_first") or []
    if _zone_shown(data, "Z0") and _af:
        click.echo(f"\n{_zone_title(data, 'Z0', 'Act on these first')}")
        for i, it in enumerate(_af, 1):
            click.echo(f"\n  {i}  {it.get('claim')}")
            click.echo(f"     {it.get('why_first')}")

    # ── Z2 counters ──────────────────────────────────────────────────────────
    mix = data.get("coverage_mix") or {}
    _total = sum(int(mix.get(k) or 0) for k in ("measured", "partial", "blind", "not_yet"))
    if full:
        click.echo(
            f"\ncoverage of {_total} measures: ● live {mix.get('measured', 0)}"
            f"  ◐ stale {mix.get('partial', 0)}"
            f"  ⊘ blind {mix.get('blind', 0)}"
            f"  ○ not yet {mix.get('not_yet', 0)}"
        )
        # ⛔ THE PAGE OPENED WITH THREE UNDEFINED GLYPHS. "Ten measures are blind" and
        # "● ◐ ⊘" were the first things a reader met, and nothing on the page said what a
        # MEASURE was, what the states meant, or whether blind was their fault or ours.
        # A reader who cannot tell those apart cannot act on any of it — and the glyphs
        # were the ONLY encoding, so anything stripping symbols lost the distinction too.
        #
        # ⚠️ One line each, printed every time. A legend behind a flag is a legend nobody
        # reads, and this is the vocabulary the whole page is written in.
        click.echo("  ● live   answered now, on fresh data")
        click.echo("  ◐ stale  answered, but the data is old — the number under-counts")
        click.echo("  ⊘ blind  cannot be answered — see 'what this page cannot see'")
        click.echo("  ○ not yet  we can measure this — nothing has been recorded into it yet")
    # ── masthead ─────────────────────────────────────────────────────────────
    # ⭐ WHAT WAS ASSESSED, OVER WHAT SCOPE. The page's counts are meaningless
    # without the estate they were drawn from, which is why this sits above the
    # findings rather than in a footer.
    # ⚠️ Every row is omitted when its value is absent — a masthead line reading
    # "Scope: None" states a fact about our plumbing, not about the estate.
    _hdr = ((data.get("facts") or {}).get("header") or {}) if full else {}
    if _hdr:
        rows = [
            ("Assessed", (_hdr.get("assessed_at") or "")[:10]),
            ("Scope", _hdr.get("scope")),
        ]
        m = _hdr.get("measures") or {}
        if m:
            # ⛔ LABELLED "measures", NOT "findings". Jay's study counts findings;
            # our unit is a measure, and borrowing the word would be a category
            # error a reader cannot detect from the number alone.
            parts = [f"{v} {k}" for k, v in m.items() if v]
            rows.append(("Measures", " · ".join(parts)))
        shown = [(k, v) for k, v in rows if v]
        if shown:
            click.echo()
            for k, v in shown:
                click.echo(f"  {k:<10} {v}")


    # ── Z3 needs you now ─────────────────────────────────────────────────────
    # ⭐ THE ALERT'S OWN COLUMNS, beside the narrated sentence. Severity, status
    # and how long it has waited are measured; the headline and recommendation
    # are written. Neither side can contradict the other because neither writes
    # the other's half — the same split the FE renders.
    _alert_by_id = {
        str(a.get("id")): a
        for a in (((data.get("facts") or {}).get("alerts") or {}).get("items") or [])
        if isinstance(a, dict) and a.get("id")
    }
    items = narr.get("attention_items") if full else None
    if items:
        click.echo(f"\n{_zone_title(data, 'Z3', 'Needs you now')}")
        for it in items[:5]:
            labels = " · ".join(it.get("labels") or [])
            click.echo(f"  ▸ {it.get('headline')}")
            _a = _alert_by_id.get(str(it.get("item_key"))) or {}
            _facts = [str(x) for x in (
                (_a.get("severity") or "").upper(),
                str(_a.get("status") or "").replace("_", " "),
                "owned by a person" if _a.get("assigned_to") else "",
                # ⛔ "still here" SAYS YOU SAW THIS AND IT IS STILL SITTING HERE —
                # the one thing an age cannot say on its own. Absent when the page
                # has no previous capture, never "new" by default.
                {"still_here": "STILL HERE", "new": "NEW",
                 "resolved": "RESOLVED"}.get(str(_a.get("change") or ""), ""),
            ) if x]
            if _facts:
                click.echo(f"    {' · '.join(_facts)}")
            if labels:
                click.echo(f"    {labels}")
            if it.get("recommendation"):
                click.echo(f"    {it['recommendation']}")
            # ⭐ THE DRILL, in the form a terminal can offer: the command that
            # opens the thing. The FE links the headline to `/alerts/:id`; here
            # the equivalent is the id and how to use it, so both surfaces let a
            # reader reach the alert rather than only read about it (§ 3.5).
            # ⚠️ `item_key` IS the alert id — the server validates every key
            # against the attention payload, so this can only name a real alert.
            drill = _artifact_command(it.get("source"))
            if drill:
                click.echo(f"    → {drill}")
            # ⭐ What doing it CLOSES — the difference between a queue and a plan.
            # Without it a reader cannot tell whether the work clears one item or
            # fifty, so they cannot sequence anything.
            if it.get("clears"):
                click.echo(f"    clears: {it['clears']}")
    elif full and narr:
        # ⭐ An EMPTY attention list is a real, reassuring state and renders as a
        # sentence — never a blank panel. Distinct from Z6, where ABSENCE is the
        # signal. Two different emptinesses, shown differently on purpose.
        #
        # ⛔ BUT AN EMPTY INBOX IS NOT EVIDENCE OF A QUIET ESTATE. Measured on Classie
        # 2026-09-06: this printed above 80 open vulnerabilities and 15 internet-reachable
        # assets, while 6 of the tenant's 9 detection rules were structurally unable to
        # fire (`rule_internet_exploitable` among them). Zero has two opposite causes —
        # everything was handled, or nothing ever ran — and they warrant opposite
        # responses. The server resolves which in `facts.attention.rule_coverage`; this
        # only refuses to state the reassuring one without checking.
        #
        # ⚠️ The server-side validator guards the NARRATOR's title_sentence. This
        # sentence is the CLI's own, so the rule has to live here too — the first fix
        # missed it for exactly that reason.
        _rc = (((data.get("facts") or {}).get("attention") or {}).get("rule_coverage")) or {}
        if _rc.get("available") and _rc.get("blocked"):
            _names = ", ".join(_rc.get("blocked_rules") or [])
            click.echo(
                f"\nNothing is in your inbox — but {_rc.get('blocked')} of "
                f"{_rc.get('total')} watches cannot fire, so this is not an all-clear."
            )
            if _names:
                click.echo(f"  not watching: {_names}")
        else:
            click.echo("\nNothing needs you right now.")

    # ── Z4 since ─────────────────────────────────────────────────────────────
    if (full or _zone_shown(data, "Z4")) and narr.get("since_summary"):
        click.echo(f"\n{data.get('window_label') or 'Recently'}")
        click.echo(f"  {narr['since_summary']}")

    # ── Z8/Z9/Z10 assessment ─────────────────────────────────────────────────
    # ⭐ RENDERED ONLY WHEN THE TEMPLATE ASKS FOR THE ZONE. The facts are on every
    # payload (switching template must not change what is true), so the zone list
    # is what decides whether they are drawn.
    #
    # ⛔ THE RATIO IS PRINTED FROM THE FACTS, THE SENTENCE FROM THE NARRATION.
    # `reach.display` is computed server-side; the narrator's `reading` never
    # contains a number. Printing both from one source would let a narration slip
    # rewrite a measurement.
    _asmt = (data.get("facts") or {}).get("assessment") or {}
    _notes = {
        str(n.get("block_key")): n.get("reading")
        for n in (narr.get("assessment_notes") or [])
        if isinstance(n, dict) and n.get("block_key")
    }
    if _zone_shown(data, "Z8") and _asmt.get("populations"):
        click.echo(f"\n{_zone_title(data, 'Z8', 'What is being evaluated')}")
        for pop in _asmt["populations"]:
            unit = f" {pop.get('unit')}" if pop.get("unit") else ""
            click.echo(f"\n  {pop.get('title')}: {pop.get('total')}{unit}")
            for seg in pop.get("segments") or []:
                click.echo(f"    {seg.get('count'):>6}  {seg.get('label')}")
            # ⚠️ Say what the segments do NOT cover. Segments are not padded to
            # sum to the total, so silence here would imply they are exhaustive.
            if pop.get("unattributed"):
                click.echo(f"    {pop['unattributed']:>6}  not attributed")
            if pop.get("note"):
                click.echo(f"    {pop['note']}")
            if _notes.get(str(pop.get("population_key"))):
                click.echo(f"    → {_notes[str(pop['population_key'])]}")

    # ── the reading guide ────────────────────────────────────────────────────
    # ⭐ THE TWO LABELS EVERY FINDING CARRIES, stated before the findings. A
    # reader who meets "Significant Deficiency" for the first time inside a
    # finding has to reverse-engineer the scale from one example.
    # ⛔ RENDERED UNDER ITS OWN ZONE (Z11), NOT INSIDE Z9. It used to live in the
    # instrumentation block and therefore inherited Z9's position — 3,747px down,
    # AFTER three zones that use the very terms it defines. A legend below the
    # content it explains is a legend nobody reads.
    _guide = _asmt.get("reading_guide") or {}
    if _zone_shown(data, "Z11") and _guide:
        for axis_key in ("deficiency_axis", "materiality_axis"):
            ax = _guide.get(axis_key) or {}
            if not ax.get("entries"):
                continue
            click.echo(f"\n  {ax.get('title')}")
            for e in ax["entries"]:
                click.echo(f"    {e['label']:<24} {e['meaning']}")
            # ⛔ AN AXIS STATES ITS OWN REACH. A legend listing four tiers over an
            # estate that can be placed in none is a legend overstating the
            # analysis, and the reader cannot tell without being told.
            if ax.get("population"):
                extra = (f", {ax['ungradeable']} not gradeable"
                         if ax.get("ungradeable") else "")
                click.echo(f"    → placed on {ax['placed']} of "
                           f"{ax['population']}{extra}")
            elif ax.get("blocked_by"):
                click.echo(f"    → not placed: {ax['blocked_by']}")

    if _zone_shown(data, "Z9") and _asmt.get("controls"):
        # ⛔ FALLBACK MATCHES `templates.py`. "What is instrumented" read as a
        # claim about the PLATFORM's reach, so "Secret scanning 0 / 28" looked
        # like "we cannot see it" when the data says GitHub answered for all 28
        # and the control is off on every one.
        click.echo(f"\n{_zone_title(data, 'Z9', 'Which security controls are switched on')}")
        for c in _asmt["controls"]:
            reach = (c.get("reach") or {}).get("display")
            # ⛔ "not readable" IS NOT "none". A control the platform could not
            # inspect and a control confirmed off need different fixes, and this
            # is the last place the distinction can be lost.
            shown = reach if reach else ("not readable" if c.get("state") == "unknown" else "—")
            click.echo(f"\n  {str(c.get('surface') or ''):<8} {c.get('control')}")
            # The grade rides WITH the ratio — the two are one statement, and
            # splitting them across the page would let a reader take either alone.
            _d = c.get("deficiency") or {}
            click.echo(f"    {shown}" + (f"   [{_d['label']}]" if _d else ""))
            if c.get("detail"):
                click.echo(f"    {c['detail']}")
            if _notes.get(str(c.get("control_key"))):
                click.echo(f"    → {_notes[str(c['control_key'])]}")

    if _zone_shown(data, "Z10"):
        claims = _asmt.get("covered_claims") or []
        if claims:
            click.echo(f"\n{_zone_title(data, 'Z10', 'What is working well')}")
            click.echo("  (only fully covered claims appear here)")
            for cl in claims:
                click.echo(f"\n  {cl.get('claim')}")
                click.echo(f"    {(cl.get('reach') or {}).get('display')}")
                if _notes.get(str(cl.get("claim_key"))):
                    click.echo(f"    → {_notes[str(cl['claim_key'])]}")
        elif _asmt:
            # ⭐ SAID OUT LOUD, not omitted. An empty Z10 means nothing on this
            # estate is fully covered — that is a finding, and a silent section
            # would read as "we did not check".
            click.echo(f"\n{_zone_title(data, 'Z10', 'What is working well')}")
            click.echo("  Nothing is fully covered yet — no claim reaches its whole population.")

    # ── Z7 cross-findings ────────────────────────────────────────────────────
    # ⭐ BEFORE Z5, matching the page. A cross-finding changes how the answers
    # below should be READ, so a reader who meets it afterwards has already taken
    # those numbers at face value.
    cfs = narr.get("cross_findings") or []
    # ⛔ GATED ON THE TEMPLATE, like every other zone. This drew unconditionally,
    # so the CLI and the FE disagreed about what the page contains the moment a
    # template stopped listing Z7 — and the CLI is the surface used to check what
    # the page says. One arrangement, read by both renderers, or neither can be
    # used to verify the other.
    if cfs and _zone_shown(data, "Z7"):
        # ⭐ TITLE FROM THE TEMPLATE, not a literal. This string used to be
        # hardcoded here AND in the FE — one decision written twice, which drifted.
        click.echo(f"\n{_zone_title(data, 'Z7', 'What these numbers say together')}")
        click.echo("  (no single card shows this)")
        # The computed relations, keyed for the evidence join.
        rel_by_key = {
            str(r.get("relation_key")): r
            for r in ((data.get("facts") or {}).get("relations") or [])
        }
        for cf in cfs:
            click.echo(f"\n  {cf.get('headline')}")
            click.echo(f"    {cf.get('so_what')}")
            rel = rel_by_key.get(str(cf.get("relation_key"))) or {}
            _echo_evidence(rel.get("evidence"))
            if rel.get("provenance"):
                click.echo(f"    reads {rel['provenance']}")
            titles = cf.get("measure_titles") or []
            if titles:
                click.echo(f"    spans: {' · '.join(str(t) for t in titles)}")
    # ⛔ NO else branch — same rule as Z6. An app with no cross-measure finding
    # shows no section, rather than a line saying there is nothing to report.

    # ⭐ THE WATCH CLAUSE — the second half of the denominator, beside the
    # coverage counts. Unconditional on both surfaces: an inbox is only as
    # trustworthy as the rules that fill it.
    if full:                    # V2 says this through its trust lines (Z2), not here
        click.echo(f"\n  {_watch_line(data)}")

    # ── Zhealth: is the app itself working ───────────────────────────────────
    # ⭐ BEFORE ANY FINDING, because every number below is only as good as the
    # machinery that produced it. ⛔ Silent when the narrator had nothing to say
    # — a permanently green line is a line nobody reads.
    _health = narr.get("health_block") or {}
    if _zone_shown(data, "Zhealth") and _health.get("verdict"):
        click.echo(f"\n{_zone_title(data, 'Zhealth', 'How this app is running')}")
        click.echo(f"  {_health['verdict']}")
        if _health.get("body"):
            click.echo(f"    {_health['body']}")

    # ── Zrules: did the watches run ──────────────────────────────────────────
    # ⭐ THE SECTION THAT SEPARATES "ALL HANDLED" FROM "NOTHING RAN". Every other
    # zone reports what the app FOUND; this reports whether it looked, and a rule
    # that ran and raised nothing exists nowhere else on the page.
    _rules = ((data.get("facts") or {}).get("rules") or {}).get("items") or []
    _al = (data.get("facts") or {}).get("alerts") or {}
    if _zone_shown(data, "Zrules") and (_rules or _al.get("available")):
        click.echo(f"\n{_zone_title(data, 'Zrules', 'Detection and alerts')}")
        _sum = _rules_summary(((data.get("facts") or {}).get("rules") or {}))
        if _sum:
            click.echo(f"  {_sum}")
        # ⚠️ AT MOST FIVE, MOST RECENTLY RUN FIRST — and never-run rules lead,
        # because a watch that has never fired outranks one that ran.
        # ⚠️ NOT windowed: a rule that last ran 25 hours ago is exactly what a
        # reader needs to see, so it stays listed with its age.
        _sorted = sorted(
            _rules,
            key=lambda r: (bool(r.get("never_ran")), str(r.get("last_run_at") or "")),
            reverse=True,
        )[:5]
        for r in _sorted:
            _state = "never ran" if r.get("never_ran") else str(r.get("last_status") or "").lower()
            click.echo(f"\n  {r.get('name')}  [{_state}]")
            if r.get("description"):
                click.echo(f"    {str(r['description'])[:150]}")
            _bits = []
            if r.get("last_run_at"):
                _bits.append(f"last ran {str(r['last_run_at'])[:16].replace('T', ' ')}")
            if str(r.get("last_trigger") or "").upper() == "MANUAL":
                _bits.append("manual run")
            _bits.append(_rule_outcome(r))
            click.echo(f"    {' · '.join(_bits)}")
        if len(_rules) > 5:
            click.echo(f"\n  … {len(_rules) - 5} more — torana workspace "
                       f"{data.get('workspace_id')} rules list")
        # ⚠️ The counters after the detections, matching the page: a reader meets
        # what is watching before the tally of what it raised.
        click.echo(
            f"\n  {_al.get('open_count', 0)} open now · "
            f"{_al.get('closed_count', 0)} closed in total"
        )

    # ── Zdash: how things are going ──────────────────────────────────────────
    # ⭐ THE MEASURES IN THE APP'S OWN GROUPING. Z5 below lists every measure, one
    # paragraph each; this says the same things three at a time, in the dashboards
    # someone named when they built the app. Templates carrying Zdash drop Z5, so
    # the two never both draw — but nothing here assumes that, because a template
    # is data and may pair them.
    #
    # ⚠️ EVERY CARD STILL OPENS. The cap is on what is WRITTEN, never on what is
    # reachable — each card prints the command that shows its rows, exactly as Z5
    # does, so a shorter page is not a smaller one.
    blocks = narr.get("dashboard_blocks") or []
    if _zone_shown(data, "Zdash") and blocks:
        click.echo(f"\n{_zone_title(data, 'Zdash', 'How things are going')}")
        # The captured dashboards, for the name and the purpose the app itself
        # states. ⛔ Read from the facts, never re-typed into the narration — a
        # dashboard renamed in the app would otherwise keep its old name here.
        _dash_by_id = {
            str(d.get("id")): d
            for d in (((data.get("facts") or {}).get("dashboards") or {}).get("items") or [])
            if isinstance(d, dict) and d.get("id")
        }
        _measure_by_widget = {
            str(m.get("widget_id")): m
            for m in ((data.get("facts") or {}).get("measures") or [])
            if m.get("widget_id")
        }
        for blk in blocks:
            _d = _dash_by_id.get(str(blk.get("dashboard_id"))) or {}
            _name = _d.get("name") or "(dashboard)"
            _cards = blk.get("cards") or []
            _total = _d.get("widget_count")
            _more = ""
            if isinstance(_total, int) and _total > len(_cards):
                # ⭐ SAY WHAT WAS LEFT OUT. A page that shows three of fifteen
                # without saying so is a page the reader thinks is complete.
                _more = f" — {len(_cards)} of {_total} views"
            click.echo(f"\n  {_name}{_more}")
            if blk.get("lead"):
                click.echo(f"    {blk['lead']}")
            for card in _cards:
                state = card.get("coverage_state") or "?"
                badge = _cov(state)
                click.echo(f"\n    · {card.get('headline')}")
                if card.get("number") is not None:
                    note = f" — {card['coverage_note']}" if card.get("coverage_note") else ""
                    click.echo(
                        f"      {card['number']} {card.get('number_label') or ''}"
                        f"   [{badge}{note}]"
                    )
                else:
                    click.echo(f"      [{badge}]")
                click.echo(f"      {card.get('so_what') or ''}")
                _clocks = _clock_line(_measure_by_widget.get(str(card.get("widget_id"))) or {})
                if _clocks:
                    click.echo(f"      {_clocks}")
                if state not in ("blind", "not_yet"):
                    _ref = card.get("source") or (
                        {"kind": "widget", "id": card["widget_id"]}
                        if card.get("widget_id") else None
                    )
                    _cmd = _artifact_command(_ref)
                    if _cmd:
                        click.echo(f"      records: {_cmd}")

    # ── Z5 questions ─────────────────────────────────────────────────────────
    qas = (narr.get("question_answers") or []) if full else []
    if qas:
        # ⛔ EVERY NUMBER ON THIS PAGE WAS TERMINAL. There was no way to ask, of any
        # measure, which tables it reads — so "where does 80 come from?" had no answer
        # from this surface, on a page whose whole contract is that a number arrives
        # with its provenance. The server resolves each measure's source tables
        # (facts.measures[].source_tables, from the supply graph); this joins them back
        # by title, which matches 38/38 on the live page.
        #
        # ⚠️ TABLES, not SQL. The query is one hop away (`torana widget <id> get` then
        # `torana query <id> get`); a second copy of it here would be free to drift.
        _by_title = {
            m.get("title"): m
            for m in ((data.get("facts") or {}).get("measures") or [])
            if m.get("title")
        }
        click.echo(f"\n{len(qas)} question(s) this app can answer right now")
        for qa in qas:
            state = qa.get("coverage_state") or "?"
            badge = _cov(state)
            click.echo(f"\n  {qa.get('heading')}")
            if qa.get("verdict"):
                click.echo(f"    {qa['verdict']}. {qa.get('evidence') or ''}")
            else:
                click.echo(f"    {qa.get('evidence') or ''}")
            # ⛔ A blind measure shows NO number — it states an absence. Rendering
            # a zero here is the defect the whole page exists to remove.
            if qa.get("number") is not None:
                note = f" — {qa['coverage_note']}" if qa.get("coverage_note") else ""
                click.echo(
                    f"    {qa['number']} {qa.get('number_label') or ''}"
                    f"   [{badge}{note}]"
                )
            else:
                click.echo(f"    [{badge}]")
            _m = _by_title.get(qa.get("heading")) or {}
            _src = _m.get("source_tables") or []
            if _src:
                click.echo(f"    from {', '.join(_src)}")
            _clocks = _clock_line(_m)
            if _clocks:
                click.echo(f"    {_clocks}")
            # ⭐ THE PROOF, same as the FE's "records →" link. `question_key` IS
            # the widget id, so the command that shows the rows behind this answer
            # is free. An answer nobody can check is a claim, not a finding.
            # ⚠️ Not offered for blind/not_yet — there are no rows to show, and a
            # command that returns nothing reads as a broken command.
            # ⚠️ Routed through `_artifact_command` rather than spelled here, so
            # the CLI and the FE cannot drift about what a `widget` ref opens.
            # Falls back to `question_key` for a page persisted before provenance
            # shipped — those carry no `source`.
            if state not in ("blind", "not_yet"):
                _ref = qa.get("source") or (
                    {"kind": "widget", "id": qa["question_key"]}
                    if qa.get("question_key") else None
                )
                _cmd = _artifact_command(_ref)
                if _cmd:
                    click.echo(f"    records: {_cmd}")

    # ── Z5b: what you have not started ───────────────────────────────────────
    # ⭐ THE ONBOARDING HALF. A page that only shows what IS happening is a
    # dashboard; one that also shows what the platform could do for you that you
    # are NOT using yet is an onboarding surface — and for a customer still
    # lighting things up, that is the more valuable half.
    #
    # ⚠️ Rendered ONLY when something is in this state, and its instruction comes
    # from the supply graph VERBATIM (`gap_what_to_do`) — the page must never
    # paraphrase what the platform said to do.
    _not_yet = [
        m for m in ((data.get("facts") or {}).get("measures") or [])
        if ((m.get("coverage") or {}).get("state")) == "not_yet"
    ]
    if full and _not_yet:
        click.echo(f"\nWhat you have not started yet ({len(_not_yet)})")
        click.echo("  These are ready to measure — nothing has been recorded into them.")
        for m in _not_yet:
            click.echo(f"  ○ {m.get('title')}")
            if m.get("gap_what_to_do"):
                click.echo(f"      {m['gap_what_to_do']}")

    # ── Z6 blind block ───────────────────────────────────────────────────────
    bb = narr.get("blind_block") if full or _zone_shown(data, "Z6") else None
    if bb:
        click.echo(f"\n{_zone_title(data, 'Z6', 'What this page cannot see')}")
        click.echo(f"  {bb.get('lead')}")
        for b in bb.get("items") or []:
            click.echo(f"  - {b.get('measure_name')}: {b.get('why')}")
            if b.get("filling_source"):
                click.echo(f"    would be filled by: {b['filling_source']}")
    # ⛔ NO else branch, and that is the design. When nothing is blind the whole
    # zone disappears — its ABSENCE is the signal (spec R-AH-4). Printing
    # "nothing is blind" here would destroy exactly that.

    errs = (data.get("collector_errors") or []) if full else []
    if errs:
        click.echo(f"\n⚠ {len(errs)} source(s) could not be read:")
        for e in errs[:5]:
            click.echo(f"  - {e.get('source')}: {e.get('error')}")
    if full:
        click.echo("")




def _rule_outcome(r: dict) -> str:
    """Did it look and find nothing, or find something and act — or not act.

    ⛔ THREE OUTCOMES, NOT TWO. "raised nothing" hid the difference between a rule
    that looked at a clean estate and one that matched findings and raised none of
    them. Only the first is good news, and a page that cannot tell them apart
    cannot be trusted about either.
    """
    if r.get("never_ran"):
        return "never ran"
    matched = r.get("last_result_count")
    if not matched:
        return "matched nothing"
    if r.get("last_raised_alert"):
        return f"matched {matched}, raised alerts"
    return f"matched {matched}, raised nothing"


def _rules_summary(rules: dict) -> str:
    """What five rows cannot say about the rest."""
    total = int(rules.get("total") or len(rules.get("items") or []))
    if not total:
        return ""
    # ⚠️ "detections", matching the section title and the link — the API calls
    # these rules, the page never does.
    parts = [f"{total}{'+' if rules.get('total_capped') else ''} detection"
             + ("" if total == 1 else "s")]
    # ⛔ "no scheduled run recorded", never "not scheduled" — a schedule may exist
    # and simply not have fired inside the logs we fetched.
    seen = int(rules.get("scheduled_runs_seen") or 0)
    parts.append(f"{seen} scheduled run(s) recorded" if seen
                 else "no scheduled run recorded")
    if int(rules.get("never_ran_count") or 0):
        parts.append(f"{rules['never_ran_count']} never ran")
    return " · ".join(parts)


def _watch_line(data: dict) -> str:
    """What the app is WATCHING — the second half of the page's denominator.

    ⭐ THE MEASURE CLAUSE SAYS WHAT THE APP CAN ANSWER; THIS SAYS WHAT IT WATCHES.
    An inbox is only as trustworthy as the rules that fill it, and this fact was
    previously rendered only when the inbox happened to be EMPTY — so the page
    stated watch coverage exactly on the days it mattered least.

    ⚠️ TWO SOURCES, TWO QUESTIONS. `rules[]` (execution logs) answers "did it
    run"; `rule_coverage` (supply graph) answers "could it ever fire". A rule can
    succeed every hour and be structurally unable to raise anything — the worst
    case, because the log reads SUCCESS.
    """
    facts = data.get("facts") or {}
    rules = ((facts.get("rules") or {}).get("items")) or []
    rc = ((facts.get("attention") or {}).get("rule_coverage")) or {}
    total = len(rules) or int(rc.get("total") or 0)
    if not total:
        # ⛔ The loudest state, never a blank line. An app nothing watches cannot
        # have a quiet estate, only an unobserved one.
        return "No watches configured — nothing is raising alerts for this app."
    noun = "watch" if total == 1 else "watches"
    never = sum(1 for r in rules if r.get("never_ran"))
    failed = sum(
        1 for r in rules
        if not r.get("never_ran")
        and str(r.get("last_status") or "").upper() != "SUCCESS"
    )
    blocked = int(rc.get("blocked") or 0)
    parts = []
    if never:
        parts.append(f"{never} never ran")
    if failed:
        parts.append(f"{failed} failed on its last run")
    if blocked:
        names = ", ".join((rc.get("blocked_rules") or [])[:3])
        parts.append(f"{blocked} cannot fire" + (f": {names}" if names else ""))
    if not parts:
        return f"{total} {noun} — all ran, none blocked."
    return f"{total} {noun} — {', '.join(parts)}."


def _zone_shown(data: dict, zone_id: str) -> bool:
    """Whether the active template draws this zone.

    ⚠️ Defaults to FALSE for a zone the template does not name. That is the right
    default only for ADDITIVE zones (Z8/Z9/Z10): the older templates predate them
    and must not suddenly grow sections. A zone whose absence would hide a gap
    (Z2, Z6) is unsuppressible in `templates.py` and never reaches this test.
    """
    zones = ((data.get("facts") or {}).get("template") or {}).get("zones") or []
    only = data.get("_only_zones")
    return (only is None or zone_id in only) and any(str(z.get("id")) == zone_id for z in zones)


def _artifact_command(ref) -> str:
    """The command that opens the artifact a narrated item came from.

    ⭐ THE CLI'S HALF OF THE ONE ROUTE TABLE. The FE turns `{kind, id}` into a
    router link; a terminal cannot hyperlink, so the equivalent is the command
    that reaches the same record. Both surfaces read the SAME `kind` vocabulary
    (`ai_home/artifacts.py`), so a new artifact class is one entry here rather
    than a per-zone edit.

    ⛔ `query` RETURNS ITS TABLE AS TEXT, NOT A COMMAND. An assessment block comes
    from SQL, not a record with an id — there is nothing to open — and printing a
    command that fails is worse than printing nothing.

    ⚠️ EVERY VERB HERE WAS VERIFIED BY RUNNING IT. Two of the first four guesses
    were wrong: `torana alerts get <id>` does not exist (the verb is in the
    SINGULAR group) and `torana widget <id> rows` does not exist (it is
    `decompose`). A route table written from memory ships commands that fail.
    """
    if not isinstance(ref, dict):
        return ""
    kind, key = str(ref.get("kind") or ""), str(ref.get("id") or "")
    if not key:
        return ""
    if kind == "alert":
        return f"torana alert {key} get"
    if kind == "widget":
        return f"torana widget {key} decompose"
    if kind == "vulnerability":
        return f"torana vulnerabilities list --id {key}"
    if kind == "query":
        return f"reads {ref.get('detail') or key}"
    return ""

def _zone_title(data: dict, zone_id: str, fallback: str) -> str:
    """The section heading the backend's template chose for a zone.

    ⭐ ONE SOURCE FOR THE ARRANGEMENT. The FE reads the same `template.zones`
    list, so the two surfaces cannot disagree about what a section is called.
    ⚠️ Falls back for a run persisted before templates shipped — an old page
    renders with the old heading rather than a blank one.
    """
    zones = ((data.get("facts") or {}).get("template") or {}).get("zones") or []
    for z in zones:
        if str(z.get("id")) == zone_id:
            return str(z.get("title") or fallback)
    return fallback


def _echo_evidence(ev: dict) -> None:
    """The finding's evidence table, as fixed-width text.

    ⛔ Read from FACTS, never from the narration — the numbers are the
    platform's. Column widths are measured from the content so figures line up
    down the column; a ragged table is harder to disagree with than a neat one.
    """
    if not ev or not ev.get("rows"):
        return
    cols = [str(c) for c in (ev.get("columns") or [])]
    rows = [[str(c) for c in r] for r in ev["rows"]]
    numeric = set(ev.get("numeric_columns") or [])
    widths = [
        max([len(cols[i])] + [len(r[i]) for r in rows if i < len(r)])
        for i in range(len(cols))
    ]
    click.echo(f"      {str(ev.get('title') or '').upper()}")

    def line(cells):
        out = []
        for i, c in enumerate(cells):
            out.append(c.rjust(widths[i]) if i in numeric else c.ljust(widths[i]))
        return "      " + "  ".join(out).rstrip()

    click.echo(line(cols))
    for r in rows:
        click.echo(line(r))
