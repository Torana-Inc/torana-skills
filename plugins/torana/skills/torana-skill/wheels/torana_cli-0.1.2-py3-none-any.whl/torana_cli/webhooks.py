"""torana webhooks — inbound webhook delivery observability (github + gitlab)."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    return ToranaClient(base_url=get_settings(profile).base_url)


_DELIVERY_COLUMNS = [
    ("received_at", "RECEIVED", 24),
    ("provider", "PROVIDER", 8),
    ("event_type", "EVENT", 22),
    ("action", "ACTION", 12),
    ("outcome", "OUTCOME", 10),
    ("repo", "REPO", 30),
    ("pr_number", "PR", 6),
    ("remediation_id", "REMEDIATION", 38),
    ("latency_ms", "MS", 6),
]


def list_webhook_deliveries_core(ctx, *, integration_id=None, provider=None, outcome=None,
                                 since_hours=None, page=1, page_size=50, unattributed=True):
    """Shared list routine — reused by `torana webhooks deliveries list` and
    `torana integration <id> webhook-deliveries list` (the latter binds integration_id).

    I-40: with `unattributed` (the default) it also asks for the deliveries no tenant owns that name this tenant's
    installation or BYO App (rejected: bad signature; unmapped: unknown installation) and prints them after the
    table: verified first, then the UNVERIFIED group, each with the server's reason verbatim."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {"page": page, "page_size": page_size}
    if integration_id:
        params["integration_id"] = integration_id
    if provider:
        params["provider"] = provider
    if outcome:
        params["outcome"] = outcome
    if since_hours:
        params["since_hours"] = since_hours
    if unattributed:
        params["include_unattributed"] = "true"

    client = _client(ctx)
    try:
        data = client.get("webhook-deliveries", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields, columns=_DELIVERY_COLUMNS)
    if fmt == "text" and not raw:               # json/yaml already carry `unattributed` whole
        _print_unattributed((data or {}).get("unattributed"))


def _delivery_line(d) -> str:
    claim = f"installation {d['installation_id']}" if d.get("installation_id") else f"app {d.get('app_id') or '-'}"
    return (f"  {d.get('received_at') or '-':<26} {d.get('event_type') or '-':<20} {d.get('outcome') or '-':<10} "
            f"{claim}")


def _print_unattributed(groups) -> None:
    """The two groups the server returns, in its order, with its words. Prints nothing when it sent none."""
    if not groups:
        return
    titles = {"verified": "Not owned by any integration, signature verified",
              "unverified": "UNVERIFIED: signature failed, so the claim to be yours is not proven"}
    for name in ("verified", "unverified"):
        g = groups.get(name) or {}
        total = g.get("total") or 0
        click.echo("")
        click.echo(f"{titles[name]} ({total})" + (f", newest {g.get('shown')} shown" if g.get("more") else ""))
        if g.get("note"):
            click.echo(f"  {g['note']}")
        if not total:
            click.echo("  none")
            continue
        for d in g.get("items") or []:
            click.echo(_delivery_line(d))
            click.echo(f"      {d.get('reason') or ''}")
        if g.get("more"):
            click.echo(f"  … {g['more']} more not shown")


@click.group(name="webhooks", invoke_without_command=True)
@click.pass_context
def webhooks(ctx):
    """Inbound webhook delivery observability (github + gitlab).

    \b
    Examples:
      torana webhooks stats
      torana webhooks deliveries list --provider gitlab --since-hours 24
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@webhooks.group(name="deliveries", invoke_without_command=True)
@click.pass_context
def webhooks_deliveries(ctx):
    """Webhook deliveries. Use `list` to list them."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@webhooks_deliveries.command(name="list")
@click.option("--provider", type=click.Choice(["github", "gitlab"]), default=None)
@click.option("--integration-id", default=None, help="Filter by integration id.")
@click.option("--outcome", default=None,
              help="Filter by outcome (created|set_state|no_match|ignored|unmapped|rejected|error).")
@click.option("--since-hours", type=int, default=None, help="Only deliveries in the last N hours.")
@click.option("--page", type=int, default=1)
@click.option("--page-size", type=int, default=50)
@click.option("--unattributed/--no-unattributed", default=True,
              help="Also show deliveries no integration owns that name your installation or App "
                   "(rejected / unmapped); on by default.")
@click.pass_context
def webhooks_deliveries_list(ctx, provider, integration_id, outcome, since_hours, page, page_size, unattributed):
    """List recent webhook deliveries.

    \b
    After the table: deliveries Torana could not attribute to an integration that name your
    installation or BYO App. Verified ones first; then UNVERIFIED ones (bad signature: anyone can
    send one), newest 50. Each carries the server's reason, e.g. a webhook-secret mismatch.
    """
    list_webhook_deliveries_core(ctx, integration_id=integration_id, provider=provider,
                                 outcome=outcome, since_hours=since_hours, page=page,
                                 page_size=page_size, unattributed=unattributed)


_UNATTRIBUTED_COLUMNS = [
    ("received_at", "RECEIVED", 24),
    ("event_type", "EVENT", 18),
    ("outcome", "OUTCOME", 10),
    ("verified", "VERIFIED", 8),
    ("installation_id", "INSTALLATION", 12),
    ("app_id", "APP", 8),
    ("reason", "REASON", 60),
]


@webhooks_deliveries.command(name="unattributed")
@click.option("--provider", type=click.Choice(["github", "gitlab"]), default=None)
@click.option("--outcome", default=None, help="Filter by outcome (rejected|unmapped|ignored|bad_json|…).")
@click.option("--since-hours", type=int, default=168, help="Only deliveries in the last N hours (default 7d).")
@click.option("--page", type=int, default=1)
@click.option("--page-size", type=int, default=50)
@click.pass_context
def webhooks_deliveries_unattributed(ctx, provider, outcome, since_hours, page, page_size):
    """SUPER ADMIN: every delivery no tenant owns, with the reason.

    \b
    The vendor App's pings, installations no integration is bound to, bad signatures. Each row
    names the tenant its installation id belongs to when the registry knows it (also when
    uninstalled). A tenant sees its own share in `deliveries list`.
      TORANA_PROFILE=SA torana webhooks deliveries unattributed --outcome rejected --since-hours 24
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    params = {"page": page, "page_size": page_size, "since_hours": since_hours}
    if provider:
        params["provider"] = provider
    if outcome:
        params["outcome"] = outcome
    try:
        data = _client(ctx).get("webhook-deliveries/unattributed", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields, columns=_UNATTRIBUTED_COLUMNS)


@webhooks.command(name="stats")
@click.option("--provider", type=click.Choice(["github", "gitlab"]), default=None)
@click.option("--integration-id", default=None, help="Filter by integration id.")
@click.option("--since-hours", type=int, default=168, help="Window in hours (default 7d).")
@click.pass_context
def webhooks_stats(ctx, provider, integration_id, since_hours):
    """Aggregate webhook-delivery counts by provider + outcome."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    params = {"since_hours": since_hours}
    if provider:
        params["provider"] = provider
    if integration_id:
        params["integration_id"] = integration_id

    client = _client(ctx)
    try:
        data = client.get("webhook-deliveries/stats", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)
