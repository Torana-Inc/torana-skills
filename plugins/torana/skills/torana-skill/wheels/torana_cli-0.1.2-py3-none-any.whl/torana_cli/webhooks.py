"""torana webhooks — inbound webhook delivery observability (github + gitlab)."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    return ToranaClient(base_url=get_settings(profile).base_url)


_DELIVERY_COLUMNS = [
    ("received_at", "RECEIVED", 24),
    ("provider", "PROVIDER", 8),
    ("event_type", "EVENT", 22),
    ("action", "ACTION", 12),
    ("outcome", "OUTCOME", 10),
    ("repo", "REPO", 30),
    ("pr_number", "PR", 6),
    ("latency_ms", "MS", 6),
]


def list_webhook_deliveries_core(ctx, *, integration_id=None, provider=None, outcome=None,
                                 since_hours=None, page=1, page_size=50):
    """Shared list routine — reused by `torana webhooks deliveries list` and
    `torana integration <id> webhook-deliveries list` (the latter binds integration_id)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {"page": page, "page_size": page_size}
    if integration_id:
        params["integration_id"] = integration_id
    if provider:
        params["provider"] = provider
    if outcome:
        params["outcome"] = outcome
    if since_hours:
        params["since_hours"] = since_hours

    client = _client(ctx)
    try:
        data = client.get("webhook-deliveries", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields, columns=_DELIVERY_COLUMNS)


@click.group(name="webhooks", invoke_without_command=True)
@click.pass_context
def webhooks(ctx):
    """Inbound webhook delivery observability (github + gitlab).

    \b
    Examples:
      torana webhooks stats
      torana webhooks deliveries list --provider gitlab --since-hours 24
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@webhooks.group(name="deliveries", invoke_without_command=True)
@click.pass_context
def webhooks_deliveries(ctx):
    """Webhook deliveries. Use `list` to list them."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@webhooks_deliveries.command(name="list")
@click.option("--provider", type=click.Choice(["github", "gitlab"]), default=None)
@click.option("--integration-id", default=None, help="Filter by integration id.")
@click.option("--outcome", default=None,
              help="Filter by outcome (created|set_state|no_match|ignored|unmapped|rejected|error).")
@click.option("--since-hours", type=int, default=None, help="Only deliveries in the last N hours.")
@click.option("--page", type=int, default=1)
@click.option("--page-size", type=int, default=50)
@click.pass_context
def webhooks_deliveries_list(ctx, provider, integration_id, outcome, since_hours, page, page_size):
    """List recent webhook deliveries."""
    list_webhook_deliveries_core(ctx, integration_id=integration_id, provider=provider,
                                 outcome=outcome, since_hours=since_hours, page=page,
                                 page_size=page_size)


@webhooks.command(name="stats")
@click.option("--provider", type=click.Choice(["github", "gitlab"]), default=None)
@click.option("--integration-id", default=None, help="Filter by integration id.")
@click.option("--since-hours", type=int, default=168, help="Window in hours (default 7d).")
@click.pass_context
def webhooks_stats(ctx, provider, integration_id, since_hours):
    """Aggregate webhook-delivery counts by provider + outcome."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    params = {"since_hours": since_hours}
    if provider:
        params["provider"] = provider
    if integration_id:
        params["integration_id"] = integration_id

    client = _client(ctx)
    try:
        data = client.get("webhook-deliveries/stats", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)
