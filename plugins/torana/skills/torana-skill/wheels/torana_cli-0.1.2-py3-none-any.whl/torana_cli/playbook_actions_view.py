"""Text views shared by `torana playbook …` and `torana playbooks …` for declarative playbook actions (OI-188 b).

A playbook can declare `notify` (Slack) / `ticket` (Jira) actions that the platform renders and delivers WITHOUT a
model; each delivery to one recipient group is an "action run". These helpers turn the API's JSON into the tables
the CLI prints. JSON/YAML output is never reshaped: it is the API's own response.
"""
from __future__ import annotations

import sys
from typing import Any, Dict, List

import click

from torana_cli.client.base import APIError, handle_api_error


def _short(text: Any, n: int = 60) -> str:
    s = " ".join(str(text or "").split())
    return s if len(s) <= n else s[: n - 1] + "…"


def action_rows(actions: List[Dict[str, Any]]) -> List[Dict[str, str]]:
    """One row per declared action: key, type, target, groups, template."""
    rows = []
    for a in actions or []:
        if a.get("type") == "notify":
            groups, target = ", ".join(a.get("recipient_groups") or []), a.get("channel") or "slack"
            template = a.get("message_template")
        else:
            groups, target = a.get("recipient_group") or "", a.get("system") or "jira"
            template = a.get("summary_template")
        rows.append({"key": a.get("key", ""), "type": a.get("type", ""), "target": target, "groups": groups,
                     "template": _short(template)})
    return rows


def external_ref_text(ref: Any) -> str:
    """Slack ts or Jira key (with its URL), the thing a reader would go and open."""
    if not isinstance(ref, dict):
        return ""
    if ref.get("kind") == "slack_message":
        return f"slack {ref.get('channel', '')} ts={ref.get('ts', '')}"
    if ref.get("kind") == "jira_issue":
        return f"jira {ref.get('key', '')} {ref.get('url', '')}".strip()
    return ""


_STATUS_WORD = {"delivered": "✓ delivered", "failed": "✗ failed", "pending": "… pending",
                "sending": "… sending", "cancelled": "– cancelled"}


def run_rows(runs: List[Dict[str, Any]]) -> List[Dict[str, str]]:
    """One row per action run: group, status (glyph AND word), attempts, error_kind, reference."""
    rows = []
    for r in runs or []:
        status = str(r.get("status") or "")
        rows.append({"action": r.get("action_key", ""), "group": r.get("recipient_group", ""),
                     "status": _STATUS_WORD.get(status, status),
                     "attempts": f"{r.get('attempts', 0)}/{r.get('max_attempts', 5)}",
                     "error_kind": r.get("error_kind") or "",
                     "reference": external_ref_text(r.get("external_ref")),
                     "missing_vars": ", ".join(r.get("missing_vars") or [])})
    return rows


RUN_COLUMNS = [("action", "ACTION", 16), ("group", "GROUP", 20), ("status", "STATUS", 13), ("attempts", "ATTEMPTS", 8),
               ("error_kind", "ERROR", 24), ("reference", "SLACK TS / JIRA KEY", 40), ("missing_vars", "MISSING", 24)]
ACTION_COLUMNS = [("key", "KEY", 18), ("type", "TYPE", 7), ("target", "TARGET", 6), ("groups", "GROUPS", 30),
                  ("template", "TEMPLATE", 60)]
PREVIEW_COLUMNS = [("action", "ACTION", 16), ("target", "TARGET", 6), ("group", "GROUP", 20),
                   ("resolution", "RESOLUTION", 19), ("missing_vars", "MISSING", 24), ("truncated", "TRUNC", 5),
                   ("text", "TEXT", 80)]


def issue_line(issue: Dict[str, Any]) -> str:
    where = ".".join(x for x in (issue.get("action_key"), issue.get("field")) if x)
    var = f" <<{issue['variable']}>>" if issue.get("variable") else ""
    return f"  [{issue.get('level', 'error')}] {where}{var}: {issue.get('message', '')}"


def echo_warnings(data: Any) -> None:
    """The server's template warnings from a create/update, one per line (stderr: stdout stays the result)."""
    warnings = data.get("warnings") if isinstance(data, dict) else None
    for w in warnings or []:
        click.echo(issue_line({"level": "warning", **w}), err=True)


def handle_playbook_error(e: APIError) -> None:
    """A 422 carrying the action template issues prints them one per line (exit 6); anything else as usual."""
    detail = e.detail
    if e.status_code == 422 and isinstance(detail, dict) and isinstance(detail.get("errors"), list):
        click.echo(f"\nERROR: {detail.get('message') or 'validation failed'} (HTTP 422)", err=True)
        for issue in detail["errors"]:
            click.echo(issue_line(issue) if isinstance(issue, dict) else f"  {issue}", err=True)
        sys.exit(6)
    handle_api_error(e)
