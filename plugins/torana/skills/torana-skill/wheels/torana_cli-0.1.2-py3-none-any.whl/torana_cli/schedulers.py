"""torana schedulers — scheduler management commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.time_util import format_next_run
from torana_cli.confirm import confirm as _confirm

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 30),
    ("state", "STATE", 10),
    ("schedule", "SCHEDULE", 20),
    ("last_run_at", "LAST RUN", 20),
]

# Columns for the `scheduler/tasks` list (the current scheduled-task endpoint).
# In text mode we add a computed `next_run_display` column (relative + exact).
_TASK_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 30),
    ("status", "STATUS", 9),
    ("schedule_expression", "SCHEDULE", 16),
    ("next_run_display", "NEXT RUN", 40),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group()
def schedulers():
    """Manage schedulers.

    \b
    Examples:
      torana schedulers list
      torana schedulers get <UUID>
      torana schedulers create --file scheduler.yaml
      torana schedulers pause <UUID>
      torana schedulers resume <UUID>
    """


@schedulers.command(name="list")
@click.option("--workspace-id", default=None, help="Filter by workspace UUID.")
@click.option("--state", default=None, help="Filter by state (active, paused).")
@click.option("--search", default=None, help="Search by name.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def schedulers_list(ctx, workspace_id, state, search, page, page_size, fetch_all):
    """List schedulers.

    \b
    Examples:
      torana schedulers list
      torana schedulers list --state active
      torana schedulers list --workspace-id <UUID>
      torana schedulers list --json | jq '.items[] | {name, schedule, state}'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"page": page, "page_size": effective_page_size}
    if state:
        params["state"] = state
    if search:
        params["search"] = search

    # There is no server-side workspace filter for schedulers, but every task row
    # carries `workspace_id`, so scope client-side. Read every page first —
    # filtering one page would silently drop a workspace's later rows.
    if workspace_id:
        fetch_all = True

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"page": page_num, "page_size": effective_page_size}
                p.update({k: v for k, v in params.items() if k not in ("page", "page_size")})
                data = client.get("api/v2/scheduler/tasks", params=p)
                items = data.get("items", [])
                all_items.extend(items)
                if len(all_items) >= data.get("total", len(all_items)):
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items), "page": 1,
                      "page_size": len(all_items)}
        else:
            result = client.get("api/v2/scheduler/tasks", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if workspace_id and isinstance(result, dict):
        scoped = [t for t in result.get("items", [])
                  if str(t.get("workspace_id") or "") == str(workspace_id)]
        result = {"items": scoped, "total": len(scoped), "page": 1,
                  "page_size": len(scoped)}

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@schedulers.command(name="get")
@click.argument("scheduler_id", metavar="SCHEDULER_ID")
@click.pass_context
def schedulers_get(ctx, scheduler_id):
    """Get details for a specific scheduler.

    \b
    Examples:
      torana schedulers list                   # find the id
      torana schedulers get <SCHEDULER_ID>
      torana scheduler <SCHEDULER_ID> execute  # run it now, off-schedule
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"scheduler/tasks/{scheduler_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@schedulers.command(name="create")
@click.option("--name", default=None)
@click.option("--schedule", default=None, help="Cron expression (e.g. '0 */6 * * *').")
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def schedulers_create(ctx, name, schedule, input_file):
    """Create a new scheduler.

    \b
    Examples:
      torana schedulers create --name "Nightly VM suite" --schedule "0 2 * * *"
      torana schedulers create --file scheduler.yaml

    \b
      ⚠️ The schedule is a 5-field cron expression (min hour dom mon dow), UTC.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if schedule:
        body["schedule"] = schedule

    if not body.get("name"):
        click.echo("ERROR: --name is required (or provide --file with 'name' field).", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post("scheduler/tasks", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created scheduler: {data.get('id', 'unknown')}")


@schedulers.command(name="update")
@click.argument("scheduler_id", metavar="SCHEDULER_ID")
@click.option("--name", default=None)
@click.option("--schedule", default=None)
@click.option("--transformer-id", "transformer_id", default=None,
              help="Repoint this schedule at a different transformer.")
@click.option("--rule-id", "rule_id", default=None,
              help="Repoint this schedule at a different detection rule.")
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def schedulers_update(ctx, scheduler_id, name, schedule, transformer_id, rule_id, input_file):
    """Update a scheduler.

    \b
    Examples:
      torana schedulers update <ID> --schedule "0 5 * * *"
      torana schedulers update <ID> --transformer-id <NEW_TRANSFORMER_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if schedule:
        # The API field is `schedule_expression`, not `schedule` — a body keyed
        # `schedule` is accepted and discarded, so the command reported success
        # while the scheduler kept its old cron. `schedule_type` must accompany it.
        body["schedule_expression"] = schedule
        body.setdefault("schedule_type", "cron")
    if transformer_id:
        body["transformer_id"] = transformer_id
    if rule_id:
        body["rule_id"] = rule_id

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"scheduler/tasks/{scheduler_id}", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Confirm the cron actually changed rather than reporting a success the
    # server may have discarded — this verb's whole failure mode was a silent
    # no-op that left an app looking scheduled when it was not.
    requested_cron = body.get("schedule_expression")
    if requested_cron and isinstance(data, dict):
        applied = data.get("schedule_expression")
        if applied != requested_cron:
            click.echo(
                f"ERROR: schedule was NOT applied — the server kept the old value.\n"
                f"       requested: {requested_cron}\n"
                f"       still is:  {applied}",
                err=True)
            import sys
            sys.exit(1)

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        msg = f"Updated scheduler: {scheduler_id}"
        if requested_cron:
            msg += f" (schedule: {requested_cron})"
        click.echo(msg)


@schedulers.command(name="delete")
@click.argument("scheduler_id", metavar="SCHEDULER_ID")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def schedulers_delete(ctx, scheduler_id, yes):
    """Delete a scheduler."""
    _confirm(f"Delete scheduler {scheduler_id}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"scheduler/tasks/{scheduler_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted scheduler: {scheduler_id}")


@schedulers.command(name="execute")
@click.argument("scheduler_id", metavar="SCHEDULER_ID")
@click.pass_context
def schedulers_execute(ctx, scheduler_id):
    """Trigger immediate execution of a scheduler."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"scheduler/tasks/{scheduler_id}/execute")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Executed scheduler: {scheduler_id}")


@schedulers.command(name="pause")
@click.argument("scheduler_id", metavar="SCHEDULER_ID")
@click.pass_context
def schedulers_pause(ctx, scheduler_id):
    """Pause a scheduler."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"scheduler/tasks/{scheduler_id}/pause")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Paused scheduler: {scheduler_id}")


@schedulers.command(name="resume")
@click.argument("scheduler_id", metavar="SCHEDULER_ID")
@click.pass_context
def schedulers_resume(ctx, scheduler_id):
    """Resume a paused scheduler."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"scheduler/tasks/{scheduler_id}/resume")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Resumed scheduler: {scheduler_id}")


@schedulers.command(name="available-tasks")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def scheduler_available_tasks(ctx, page, page_size, fetch_all):
    """Get Available Tasks."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "scheduler/available-tasks"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@schedulers.command(name="tasks")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--page", "page", type=int, default=1, help="Page number")
@click.option("--size", "size", type=int, default=20, help="Items per page")
@click.option("--task-type", "task_type", default=None, help="Filter by task type")
@click.option("--status", "status", default=None, help="Filter by status")
@click.option("--is-enabled", "is_enabled", default=None, help="Filter by enabled status")
@click.option("--search", "search", default=None, help="Search in name and description")
@click.option("--tag", "tag", default=None, help="Filter by program tag (e.g., 'program=my-program')")
@click.option("--ids", "ids", default=None, help="Comma-separated UUIDs to filter by ID")
@click.option("--workspace-id", "workspace_id", default=None, help="Filter by workspace ID")
@click.option("--updated-since", "updated_since", default=None, help="Return only records whose updated_at >= this timestamp. Includes soft-deleted re")
@click.pass_context
def scheduler_tasks(ctx, page, size, task_type, status, is_enabled, search, tag, ids, workspace_id, updated_since, page_size, fetch_all):
    """List Scheduled Tasks."""
    list_schedulers_core(ctx, page=page, size=size, task_type=task_type, status=status,
                         is_enabled=is_enabled, search=search, tag=tag, ids=ids,
                         workspace_id=workspace_id, updated_since=updated_since,
                         fetch_all=fetch_all)


def list_schedulers_core(ctx, *, page=1, size=20, task_type=None, status=None,
                         is_enabled=None, search=None, tag=None, ids=None,
                         workspace_id=None, updated_since=None, fetch_all=False):
    """Shared scheduled-tasks list routine.

    `torana schedulers list` and `torana workspace <id> schedulers list` both call
    this; the workspace form just pre-binds `workspace_id`. Single source of truth
    — same endpoint, columns, pagination. In text mode each row is augmented with
    a `next_run_display` (human-readable relative time + exact UTC) derived from
    `next_execution_at`.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "scheduler/tasks"
    params = {}
    if page is not None:
        params["page"] = page
    if size is not None:
        params["size"] = size
    if task_type is not None:
        params["task_type"] = task_type
    if status is not None:
        params["status"] = status
    if is_enabled is not None:
        params["is_enabled"] = is_enabled
    if search is not None:
        params["search"] = search
    if tag is not None:
        params["tag"] = tag
    if ids is not None:
        params["ids"] = ids
    if workspace_id is not None:
        params["workspace_id"] = workspace_id
    if updated_since is not None:
        params["updated_since"] = updated_since

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "page": page_num}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Text/table mode: add a computed NEXT RUN column (relative + exact). Added as
    # a sibling field so json/yaml output keeps the raw `next_execution_at`.
    columns = None
    if fmt in ("text", "table"):
        items = data.get("items", []) if isinstance(data, dict) else (data or [])
        for it in items:
            if isinstance(it, dict):
                it["next_run_display"] = format_next_run(it.get("next_execution_at"))
        columns = _TASK_LIST_COLS

    output(data, fmt=fmt, fields=fields, raw=raw, columns=columns)


@schedulers.command(name="create-task")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with request body. Use '-' for stdin.")
@click.option("--name", "name", required=True, help="Name of the scheduled task")
@click.option("--description", "description", default=None, help="Description of the task")
@click.option("--semantic-description", "semantic_description", default=None, help="Semantic description used for AI-powered search and discovery")
@click.option("--task-type", "task_type", type=click.Choice(["workflow", "suite", "rule", "transformer"], case_sensitive=False), required=True, help="Task type enumeration.")
@click.option("--schedule-type", "schedule_type", type=click.Choice(["cron", "interval", "once"], case_sensitive=False), required=True, help="Schedule type enumeration.")
@click.option("--schedule-expression", "schedule_expression", required=True, help="Cron expression, interval, or date")
@click.option("--timezone", "timezone", default="UTC", help="Timezone for schedule")
@click.option("--is-enabled", "is_enabled", type=bool, default=False, help="Whether the task is enabled (starts disabled for draft state)")
@click.option("--start-date", "start_date", default=None, help="When schedule becomes active")
@click.option("--end-date", "end_date", default=None, help="When schedule expires")
@click.option("--max-executions", "max_executions", default=None, help="Maximum number of executions")
@click.option("--parameters", "parameters", default=None, help="Task parameters")
@click.option("--default-inputs", "default_inputs", default=None, help="Default inputs for workflows")
@click.option("--on-failure", "on_failure", type=click.Choice(["continue", "pause", "disable"], case_sensitive=False), default=None, help="Action to take on failure.")
@click.option("--max-failures", "max_failures", type=int, default=5, help="Max failures before action")
@click.option("--notify-on-success", "notify_on_success", type=bool, default=False, help="Notify on successful execution")
@click.option("--notify-on-failure", "notify_on_failure", type=bool, default=True, help="Notify on failed execution")
@click.option("--notification-emails", "notification_emails", default=None, help="Email addresses for notifications")
@click.option("--notification-webhooks", "notification_webhooks", default=None, help="Webhook URLs for notifications")
@click.option("--labels", "labels", default=None, help="Key-value labels for categorization")
@click.option("--workspace-id", "workspace_id", required=True, help="Workspace ID")
@click.option("--workflow-id", "workflow_id", default=None, help="Workflow ID (for workflow tasks)")
@click.option("--suite-id", "suite_id", default=None, help="Suite ID (for suite tasks)")
@click.option("--rule-id", "rule_id", default=None, help="Rule ID (for rule tasks)")
@click.option("--transformer-id", "transformer_id", default=None, help="Transformer ID (for transformer tasks)")
@click.pass_context
def schedulers_create_task(ctx, name, description, semantic_description, task_type, schedule_type, schedule_expression, timezone, is_enabled, start_date, end_date, max_executions, parameters, default_inputs, on_failure, max_failures, notify_on_success, notify_on_failure, notification_emails, notification_webhooks, labels, workspace_id, workflow_id, suite_id, rule_id, transformer_id, input_file):
    """Create Scheduled Task."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "scheduler/tasks"
    if input_file:
        body = _load_input_file(input_file)
    else:
        body = {}
        body["name"] = name
        if description is not None:
            body["description"] = description
        if semantic_description is not None:
            body["semantic_description"] = semantic_description
        body["task_type"] = task_type
        body["schedule_type"] = schedule_type
        body["schedule_expression"] = schedule_expression
        if timezone is not None:
            body["timezone"] = timezone
        if is_enabled is not None:
            body["is_enabled"] = is_enabled
        if start_date is not None:
            body["start_date"] = start_date
        if end_date is not None:
            body["end_date"] = end_date
        if max_executions is not None:
            body["max_executions"] = max_executions
        if parameters is not None:
            body["parameters"] = parameters
        if default_inputs is not None:
            body["default_inputs"] = default_inputs
        if on_failure is not None:
            body["on_failure"] = on_failure
        if max_failures is not None:
            body["max_failures"] = max_failures
        if notify_on_success is not None:
            body["notify_on_success"] = notify_on_success
        if notify_on_failure is not None:
            body["notify_on_failure"] = notify_on_failure
        if notification_emails is not None:
            body["notification_emails"] = notification_emails
        if notification_webhooks is not None:
            body["notification_webhooks"] = notification_webhooks
        if labels is not None:
            body["labels"] = labels
        body["workspace_id"] = workspace_id
        if workflow_id is not None:
            body["workflow_id"] = workflow_id
        if suite_id is not None:
            body["suite_id"] = suite_id
        if rule_id is not None:
            body["rule_id"] = rule_id
        if transformer_id is not None:
            body["transformer_id"] = transformer_id

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ──────────────────────────────────────────────────────────────────────────
# Instance reads regrouped from `<noun>-by-<param>` leaves onto verbs
# (CLI Discoverability Contract, rule 2 — see ../CLAUDE.md). The route
# parameter belongs in the positional ARGUMENT, not the command name.
#
# Old flat names remain as HIDDEN aliases for ONE release (D4).
# ──────────────────────────────────────────────────────────────────────────


@schedulers.group(name="task")
def schedulers_task_grp():
    """One scheduled task, by id.

    Examples:
      torana schedulers task get --help
    """


@schedulers_task_grp.command(name="get")
@click.argument("TASK_ID", metavar="TASK_ID")
@click.pass_context
def scheduler_tasks_by_task_id(ctx, task_id):
    """Get Scheduled Task."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"scheduler/tasks/{task_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@schedulers.command(name="update-task")
@click.argument("TASK_ID", metavar="TASK_ID")
@click.option("--name", "name", default=None)
@click.option("--description", "description", default=None)
@click.option("--semantic-description", "semantic_description", default=None)
@click.option("--schedule-type", "schedule_type", default=None)
@click.option("--schedule-expression", "schedule_expression", default=None)
@click.option("--timezone", "timezone", default=None)
@click.option("--is-enabled", "is_enabled", default=None)
@click.option("--start-date", "start_date", default=None)
@click.option("--end-date", "end_date", default=None)
@click.option("--max-executions", "max_executions", default=None)
@click.option("--parameters", "parameters", default=None)
@click.option("--default-inputs", "default_inputs", default=None)
@click.option("--on-failure", "on_failure", default=None)
@click.option("--max-failures", "max_failures", default=None)
@click.option("--notify-on-success", "notify_on_success", default=None)
@click.option("--notify-on-failure", "notify_on_failure", default=None)
@click.option("--notification-emails", "notification_emails", default=None)
@click.option("--notification-webhooks", "notification_webhooks", default=None)
@click.option("--labels", "labels", default=None)
@click.pass_context
def schedulers_update_task(ctx, task_id, name, description, semantic_description, schedule_type, schedule_expression, timezone, is_enabled, start_date, end_date, max_executions, parameters, default_inputs, on_failure, max_failures, notify_on_success, notify_on_failure, notification_emails, notification_webhooks, labels):
    """Update Scheduled Task."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"scheduler/tasks/{task_id}"
    body = {}
    if name is not None:
        body["name"] = name
    if description is not None:
        body["description"] = description
    if semantic_description is not None:
        body["semantic_description"] = semantic_description
    if schedule_type is not None:
        body["schedule_type"] = schedule_type
    if schedule_expression is not None:
        body["schedule_expression"] = schedule_expression
    if timezone is not None:
        body["timezone"] = timezone
    if is_enabled is not None:
        body["is_enabled"] = is_enabled
    if start_date is not None:
        body["start_date"] = start_date
    if end_date is not None:
        body["end_date"] = end_date
    if max_executions is not None:
        body["max_executions"] = max_executions
    if parameters is not None:
        body["parameters"] = parameters
    if default_inputs is not None:
        body["default_inputs"] = default_inputs
    if on_failure is not None:
        body["on_failure"] = on_failure
    if max_failures is not None:
        body["max_failures"] = max_failures
    if notify_on_success is not None:
        body["notify_on_success"] = notify_on_success
    if notify_on_failure is not None:
        body["notify_on_failure"] = notify_on_failure
    if notification_emails is not None:
        body["notification_emails"] = notification_emails
    if notification_webhooks is not None:
        body["notification_webhooks"] = notification_webhooks
    if labels is not None:
        body["labels"] = labels

    client = _client(ctx)
    try:
        # Backend route is @router.put("/tasks/{task_id}") — must be PUT, not POST
        # (POST here returns HTTP 405 Method Not Allowed).
        data = client.put(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@schedulers_task_grp.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("TASK_IDENTIFIER", metavar="TASK_IDENTIFIER")
@click.pass_context
def scheduler_tasks_by_task_identifier(ctx, task_identifier, yes):
    """Delete Scheduled Task."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"scheduler/tasks/{task_identifier}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@schedulers.command(name="executions")
@click.argument("TASK_ID", metavar="TASK_ID")
@click.option("--page", "page", type=int, default=1, help="Page number")
@click.option("--size", "size", type=int, default=20, help="Items per page")
@click.option("--status", "status", default=None, help="Filter by status")
@click.pass_context
def scheduler_executions(ctx, task_id, page, size, status):
    """Get Task Execution Logs."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"scheduler/tasks/{task_id}/executions"
    params = {}
    if page is not None:
        params["page"] = page
    if size is not None:
        params["size"] = size
    if status is not None:
        params["status"] = status

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@schedulers.command(name="all-executions")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--page", "page", type=int, default=1, help="Page number")
@click.option("--size", "size", type=int, default=20, help="Items per page")
@click.option("--task-type", "task_type", default=None, help="Filter by task type")
@click.option("--status", "status", default=None, help="Filter by status")
@click.pass_context
def schedulers_all_executions(ctx, page, size, task_type, status, page_size, fetch_all):
    """List All Execution Logs."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "scheduler/executions"
    params = {}
    if page is not None:
        params["page"] = page
    if size is not None:
        params["size"] = size
    if task_type is not None:
        params["task_type"] = task_type
    if status is not None:
        params["status"] = status

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "page": page_num}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@schedulers.command(name="reload")
@click.pass_context
def scheduler_reload(ctx):
    """Reload Schedules."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "scheduler/reload"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@schedulers.command(name="move")
@click.argument("TASK_ID", metavar="TASK_ID")
@click.option("--target-workspace-id", "target_workspace_id", required=True)
@click.pass_context
def scheduler_move(ctx, task_id, target_workspace_id):
    """Move scheduled task to a different workspace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"scheduler/tasks/{task_id}/move"
    body = {}
    body["target_workspace_id"] = target_workspace_id

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@schedulers.command(name="task-pause")
@click.argument("TASK_ID", metavar="TASK_ID")
@click.pass_context
def scheduler_task_pause(ctx, task_id):
    """Pause a scheduled task."""
    client = _client(ctx)
    try:
        client.post(f"scheduler/tasks/{task_id}/pause")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Paused task: {task_id}")


@schedulers.command(name="task-resume")
@click.argument("TASK_ID", metavar="TASK_ID")
@click.pass_context
def scheduler_task_resume(ctx, task_id):
    """Resume a paused scheduled task."""
    client = _client(ctx)
    try:
        client.post(f"scheduler/tasks/{task_id}/resume")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Resumed task: {task_id}")


@schedulers.command(name="task-execute")
@click.argument("TASK_ID", metavar="TASK_ID")
@click.pass_context
def scheduler_task_execute(ctx, task_id):
    """Trigger immediate execution of a scheduled task."""
    client = _client(ctx)
    try:
        client.post(f"scheduler/tasks/{task_id}/execute")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Executed task: {task_id}")


# ── bulk ops (CLI-4) ─────────────────────────────────────────────────────────
# No server-side bulk endpoint exists; these loop the per-instance pause/resume
# calls. run_bulk reports per-item outcomes and exits non-zero on any failure.

@schedulers.group(name="bulk", invoke_without_command=True)
@click.pass_context
def schedulers_bulk(ctx):
    """Bulk operations across schedulers. Use `resume` / `pause`."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _bulk_scheduler_ids(client, want_enabled):
    """Ids of scheduled tasks filtered by current enabled state."""
    from torana_cli.bulk import resolve_ids

    def _pred(item):
        enabled = item.get("is_enabled", item.get("enabled"))
        return (enabled is True) if want_enabled else (enabled is False)

    return resolve_ids(client, "scheduler/tasks", params={"limit": 100}, predicate=_pred)


@schedulers_bulk.command(name="resume")
@click.option("--all-paused", is_flag=True, default=False,
              help="Target every currently-disabled schedule (the demo-prep recovery case).")
@click.option("--id", "ids", multiple=True, help="Explicit scheduler id (repeatable).")
@click.option("--dry-run", is_flag=True, default=False, help="Show what would change.")
@click.pass_context
def schedulers_bulk_resume(ctx, all_paused, ids, dry_run):
    """Resume many schedulers at once."""
    from torana_cli.bulk import run_bulk
    client = _client(ctx)
    target = list(ids) if ids else (_bulk_scheduler_ids(client, want_enabled=False)
                                    if all_paused else [])
    if not target and not ids and not all_paused:
        click.echo("ERROR: pass --id <id> (repeatable) or --all-paused.", err=True)
        ctx.exit(2)
    run_bulk(ctx, target,
             lambda sid: client.post(f"scheduler/tasks/{sid}/resume"),
             label="resume schedulers", dry_run=dry_run)


@schedulers_bulk.command(name="pause")
@click.option("--all-active", is_flag=True, default=False,
              help="Target every currently-enabled schedule.")
@click.option("--id", "ids", multiple=True, help="Explicit scheduler id (repeatable).")
@click.option("--dry-run", is_flag=True, default=False, help="Show what would change.")
@click.pass_context
def schedulers_bulk_pause(ctx, all_active, ids, dry_run):
    """Pause many schedulers at once."""
    from torana_cli.bulk import run_bulk
    client = _client(ctx)
    target = list(ids) if ids else (_bulk_scheduler_ids(client, want_enabled=True)
                                    if all_active else [])
    if not target and not ids and not all_active:
        click.echo("ERROR: pass --id <id> (repeatable) or --all-active.", err=True)
        ctx.exit(2)
    run_bulk(ctx, target,
             lambda sid: client.post(f"scheduler/tasks/{sid}/pause"),
             label="pause schedulers", dry_run=dry_run)


# ──────────────────────────────────────────────────────────────────────────
# BACK-COMPAT — hidden aliases for the old `<noun>-by-<param>` names.
# ⏳ ONE RELEASE ONLY (decision D4). Delete this block next release.
# ──────────────────────────────────────────────────────────────────────────

_LEGACY_BY_PARAM_SCHEDULERS = {
    "tasks-by-task-id": ("task", "get"),
    "tasks-by-task-identifier": ("task", "delete"),
}


def _register_legacy_schedulers_by_param() -> None:
    """Old flat names, hidden so they cannot be discovered anew."""
    import copy
    for _old, (_sub, _verb) in _LEGACY_BY_PARAM_SCHEDULERS.items():
        _grp = schedulers.commands.get(_sub)
        if not isinstance(_grp, click.Group):
            continue
        _cmd = _grp.commands.get(_verb)
        if _cmd is None:
            continue
        # ⛔ Never let an alias overwrite a real group of the same name.
        if isinstance(schedulers.commands.get(_old), click.Group):
            continue
        _alias = copy.copy(_cmd)
        _alias.name = _old
        _alias.hidden = True
        schedulers.add_command(_alias)


_register_legacy_schedulers_by_param()
