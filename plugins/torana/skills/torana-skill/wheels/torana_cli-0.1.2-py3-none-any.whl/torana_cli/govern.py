"""torana govern — set human-judgment governance on assets (EM C4).

Governance is the facts no scanner can discover: how critical a service is, who
owns it, and which datastore holds customer data. These drive A6 shadow detection
(the GOVERNED set) and the C6 prioritization rule (the customer-data clause).

All verbs are thin, ergonomic wrappers over POST /api/v1/ingest/assets — they
build an asset_inventory.v1 document with the right `asset_kind` and post it (the
same endpoint the `torana ingest assets` file-push uses, but flag-driven).

Subcommands
-----------
  service   <service-key>   --criticality … --owner … --env …
  datastore <ident>         --engine … --classification … --sensitivity … [--pii]
  repo      <repo-ref>      --criticality … --owner … --env …
  show      <entity-key>    read current governance on a node

Grouped under a single semantic parent (`govern`) per the CLI grouping convention.
"""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import (
    APIError,
    ToranaClient,
    handle_api_error,
    handle_auth_error,
)
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output


_RECEIPT_COLS = [
    ("scan_id", "SCAN ID", 40),
    ("source", "SOURCE", 12),
    ("received_at", "RECEIVED", 28),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    return ToranaClient(base_url=get_settings(profile).base_url)


def _ctx(ctx):
    return (
        ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text",
        ctx.obj.get(CTX_RAW, False) if ctx.obj else False,
        ctx.obj.get(CTX_FIELDS) if ctx.obj else None,
    )


def _post_govern(ctx, doc: dict):
    """POST an asset_inventory.v1 governance document; render the receipt."""
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        receipt = client.post("ingest/assets", json=doc)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(receipt, fmt=fmt, raw=raw, fields=fields, columns=_RECEIPT_COLS)


# ─── parent group ───────────────────────────────────────────────────────────────

@click.group(name="govern")
def govern():
    """Set governance (criticality / owner / data-classification) on assets.

    \b
    Governance is the facts NO SCANNER CAN KNOW — who owns a thing, how critical
    it is, what class of data it holds. The graph supplies the topology; this
    supplies the judgment, and exposure scoring needs both.

    \b
    Examples:
      torana govern show service:prod/billing-api
      torana govern service service:prod/billing-api \\
          --criticality high --owner payments-team --environment prod
      torana govern repo repo:github.com/acme/billing-api --criticality high
      torana govern datastore <IDENT> --data-classification pii --pii
      torana govern history service:prod/billing-api      who changed what, when
    """


# ─── service ────────────────────────────────────────────────────────────────────

@govern.command(name="service")
@click.argument("service_key")
@click.option("--criticality", type=click.Choice(["Critical", "High", "Medium", "Low"]), default=None)
@click.option("--owner", default=None, help="Owning team or handle.")
@click.option("--owner-email", default=None)
@click.option("--env", "environment", type=click.Choice(["production", "staging", "development", "test"]), default=None)
@click.option("--name", "name", default=None, help="Service short name (defaults from the key tail).")
@click.option("--desc", "description", default=None, help="Semantic description of the service.")
@click.option("--reason", default=None, help="Why this governance change (recorded on the audit trail).")
@click.pass_context
def govern_service(ctx, service_key, criticality, owner, owner_email, environment, name, description, reason):
    """Govern a running SERVICE node (its `service:` key). Sets criticality/owner/
    environment — which move it out of A6's shadow set and into the GOVERNED set."""
    gov = {}
    if criticality is not None:
        gov["criticality_name"] = criticality
    if owner is not None:
        gov["owner_name"] = owner
    if owner_email is not None:
        gov["owner_email"] = owner_email
    if environment is not None:
        gov["environment"] = environment
    if not name:
        name = service_key.rstrip("/").split("/")[-1]
    doc = {
        "schema_version": "asset_inventory.v1",
        "asset_kind": "service",
        "asset_ref": service_key,
        "description": description or f"Service {name}",
        "service": {"name": name},
        "governance": gov,
    }
    if reason is not None:
        doc["reason"] = reason
    _post_govern(ctx, doc)


# ─── datastore ──────────────────────────────────────────────────────────────────

@govern.command(name="datastore")
@click.argument("ident")
@click.option("--engine", required=True, help="e.g. postgres, mysql, redis.")
@click.option("--provider", default="self-hosted", show_default=True)
@click.option("--classification", "data_classification",
              type=click.Choice(["customer-data", "pii", "phi", "internal", "public"]), default=None)
@click.option("--sensitivity", "data_sensitivity", type=click.Choice(["High", "Medium", "Low"]), default=None)
@click.option("--pii", is_flag=True, default=False, help="Mark the store as holding PII.")
@click.option("--owner", default=None)
@click.option("--steward", "data_steward", default=None)
@click.option("--desc", "description", default=None, help="Semantic description of the datastore.")
@click.option("--reason", default=None, help="Why this governance change (recorded on the audit trail).")
@click.pass_context
def govern_datastore(ctx, ident, engine, provider, data_classification, data_sensitivity,
                     pii, owner, data_steward, description, reason):
    """Govern a DATASTORE — mark its data classification/sensitivity. Keyed
    datastore_key(provider, engine, ident); the customer-data classification is
    what the C6 prioritization rule gates on."""
    ds = {"provider": provider, "engine": engine, "ident": ident}
    if data_classification is not None:
        ds["data_classification"] = data_classification
    if data_sensitivity is not None:
        ds["data_sensitivity"] = data_sensitivity
    if pii:
        ds["pii"] = True
    if owner is not None:
        ds["owner"] = owner
    if data_steward is not None:
        ds["data_steward"] = data_steward
    doc = {
        "schema_version": "asset_inventory.v1",
        "asset_kind": "datastore",
        "description": description or f"Datastore {ident}",
        "datastore": ds,
    }
    if reason is not None:
        doc["reason"] = reason
    _post_govern(ctx, doc)


# ─── repo ─────────────────────────────────────────────────────────────────────--

@govern.command(name="repo")
@click.argument("repo_ref")
@click.option("--criticality", type=click.Choice(["Critical", "High", "Medium", "Low"]), default=None)
@click.option("--owner", default=None)
@click.option("--owner-email", default=None)
@click.option("--env", "environment", type=click.Choice(["production", "staging", "development", "test"]), default=None)
@click.option("--desc", "description", default=None)
@click.option("--reason", default=None, help="Why this governance change (recorded on the audit trail).")
@click.pass_context
def govern_repo(ctx, repo_ref, criticality, owner, owner_email, environment, description, reason):
    """Govern a REPOSITORY (criticality/owner/environment)."""
    gov = {}
    if criticality is not None:
        gov["criticality_name"] = criticality
    if owner is not None:
        gov["owner_name"] = owner
    if owner_email is not None:
        gov["owner_email"] = owner_email
    if environment is not None:
        gov["environment"] = environment
    doc = {
        "schema_version": "asset_inventory.v1",
        "asset_kind": "repository",
        "asset_ref": repo_ref,
        "description": description or f"Repository {repo_ref}",
        "governance": gov,
    }
    if reason is not None:
        doc["reason"] = reason
    _post_govern(ctx, doc)


# ─── show ─────────────────────────────────────────────────────────────────────--

#: How a subject `state` reads to a human. The whole point of CLI-19: an edge-less
#: node used to render EXACTLY like a non-existent one (`EDGES [] / NODES []`), so the
#: reader could not tell "this repo is not on the platform" from "this repo is on the
#: platform and simply has no edges yet". Those are different problems with different
#: owners, and the CLI now says which one it is.
_SUBJECT_VERDICT = {
    "resolved": ("EXISTS", "backed by an inventory row in {home}"),
    "referenced": (
        "NOT IN INVENTORY",
        "no row in its home table — an onboarded integration could have produced "
        "one but has not (an ingestion gap worth chasing)",
    ),
    "unclaimed": (
        "NOT IN INVENTORY",
        "no row in its home table, and nothing onboarded claims authority for it "
        "(expected — not a defect)",
    ),
}


def _print_subject(entity_key, subject, edge_count):
    """Render the subject verdict, then the edge count, in that order.

    ⛔ The verdict comes FIRST and is stated in words, not inferred from an empty
    list. A reader who sees `EDGES []` alone cannot distinguish absence-of-node from
    absence-of-edges; that ambiguity IS CLI-19.
    """
    state = (subject or {}).get("state")
    home = (subject or {}).get("home_table") or "its home table"
    verdict, detail = _SUBJECT_VERDICT.get(
        state, ("UNKNOWN", "the server did not report a subject state"),
    )
    click.echo(f"KEY       {entity_key}")
    click.echo(f"SUBJECT   {verdict}  ({detail.format(home=home)})")
    if edge_count:
        click.echo(f"EDGES     {edge_count}")
    elif verdict == "EXISTS":
        click.echo("EDGES     0 — the node exists but nothing connects it yet "
                   "(no governance can be inherited through the graph)")
    else:
        click.echo("EDGES     0")


@govern.command(name="show")
@click.argument("entity_key")
@click.pass_context
def govern_show(ctx, entity_key):
    """Show the current governance on a node (criticality/owner/classification).

    Reads the entity-graph node by key. (The change HISTORY — who changed what,
    old→new — is `torana govern history <key>`, added with the audit phase.)

    ⭐ CLI-19 — the SUBJECT verdict is printed before the edges. Previously an
    edge-less node rendered `KEY … / EDGES [] / NODES []`, which looks like a
    populated record and is indistinguishable from a key that does not exist at
    all. The server now resolves the subject against its home inventory table
    (#67), and this prints that verdict in words.
    """
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.get("entity-graph/neighbors", params={"key": entity_key, "direction": "both"})
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    # json/raw callers get the envelope untouched — `subject` is additive, so any
    # existing script reading edges/nodes is unaffected.
    if fmt != "text" or raw:
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    subject = (data or {}).get("subject")
    edges = (data or {}).get("edges") or []
    if subject is None:
        # Older server without #67 — say so rather than silently rendering the
        # ambiguous shape this row exists to kill.
        click.echo(f"KEY       {entity_key}")
        click.echo("SUBJECT   UNKNOWN  (server did not return a subject — "
                   "upgrade pantheon-integration for the #67 resolution)")
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    _print_subject(entity_key, subject, len(edges))
    if edges:
        click.echo("")
        output({"items": edges}, fmt=fmt, raw=raw, fields=fields)


# ─── history (first-class audit trail) ──────────────────────────────────────────

@govern.command(name="history")
@click.argument("entity_key")
@click.option("--limit", default=50, type=int, help="Max rows (<=100).")
@click.option("--offset", default=0, type=int)
@click.pass_context
def govern_history(ctx, entity_key, limit, offset):
    """Show the governance CHANGE HISTORY for a node — who changed which field,
    old→new, when, and why. Immutable, append-only (the C4 audit trail)."""
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    from urllib.parse import quote
    path = f"entity-graph/governance/{quote(entity_key, safe='')}/history"
    try:
        data = client.get(path, params={"limit": limit, "offset": offset})
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)
