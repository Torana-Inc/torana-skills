"""torana controls — compensating controls collection (T10).

Collection ops for the WAF/compensating-control store (the `controls` datalake
table). Reads go through the generic /tables/controls/data route; creates
through the integration route (POST /api/v1/compensating-controls).

Instance ops (get / promote / retire / efficacy) live in the singular
`torana control <id>` group (control.py).

    torana controls list
    torana controls list --status active
    torana controls create --engine-rule-id r1 --name "block sqli" --expression '...'
"""

import datetime as _dt
import json

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    return ToranaClient(base_url=get_settings(profile).base_url)


def _fmt(ctx):
    return (
        ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text",
        ctx.obj.get(CTX_RAW, False) if ctx.obj else False,
        ctx.obj.get(CTX_FIELDS) if ctx.obj else None,
    )


def _normalize(data: dict) -> dict:
    """Datalake /tables/{name}/data → {items,total,page,page_size}."""
    if isinstance(data, dict) and "items" in data:
        return data
    rows = (data.get("data") or data.get("rows") or []) if isinstance(data, dict) else []
    return {"items": rows, "total": len(rows), "page": 1, "page_size": len(rows)}


# #115 — a compensating control is a TEMPORARY mitigation with a review-by
# date, but nothing surfaced the ones that had sailed past it. These helpers
# are the operator-facing half of that sweep.
#
# ⚠️ The review-by is read out of `custom_attributes`, NOT a column. The
# shipped `controls` sink declares 16 columns and `expires_at` is not among
# them, so the server packs it into the VARIANT blob (which is what makes the
# value survive at all). That blob is explicitly "for investigation only", so
# this filtering is necessarily CLIENT-SIDE over the fetched page rather than
# a server-side WHERE. A first-class `review_by` column in pantheon-shared is
# what would make it a real query — that repo is out of this stream's scope
# and is raised as a cross-repo handoff.
_TERMINAL_STATUSES = ("retired", "expired")


def _coerce_attrs(row: dict) -> dict:
    """Return a row's custom_attributes as a dict ({} when absent/unparseable)."""
    attrs = row.get("custom_attributes")
    if isinstance(attrs, str):
        try:
            attrs = json.loads(attrs)
        except Exception:
            attrs = None
    return attrs if isinstance(attrs, dict) else {}


def _review_by(row: dict):
    """The control's review-by datetime (tz-aware UTC), or None if it has none.

    Prefers a real column so this keeps working unchanged the day a first-class
    one lands, and falls back to the packed blob as things stand today.
    """
    raw = row.get("expires_at") or _coerce_attrs(row).get("expires_at")
    if not raw:
        return None
    try:
        dt = _dt.datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
    except Exception:
        return None
    return dt.replace(tzinfo=_dt.timezone.utc) if dt.tzinfo is None else dt


def _annotate_review(rows: list) -> list:
    """Add the display-only REVIEW_BY / OVERDUE columns to each row.

    ⛔ Deliberately underscore-prefixed. These are DERIVED for presentation and
    must never be mistaken for stored datalake columns (the platform's
    never-augment-a-datalake-read rule); nothing writes them back.
    """
    now = _dt.datetime.now(_dt.timezone.utc)
    for row in rows:
        due = _review_by(row)
        row["_review_by"] = due.date().isoformat() if due else "—"
        # Terminal first: a retired/expired control is done, so it is neither
        # overdue nor an unbounded mitigation — flagging it either way would
        # put noise in the sweep it is meant to be exempt from.
        if str(row.get("status") or "").lower() in _TERMINAL_STATUSES:
            row["_overdue"] = "-"
        elif due is None:
            row["_overdue"] = "no-expiry"
        else:
            row["_overdue"] = "YES" if due < now else "-"
    return rows


def _past_review(rows: list) -> list:
    """Controls that are still live and are at or past their review-by.

    A control with NO review-by is included: an unbounded temporary mitigation
    is exactly the condition being swept for, and silently dropping it would
    hide the worst case.
    """
    now = _dt.datetime.now(_dt.timezone.utc)
    out = []
    for row in rows:
        if str(row.get("status") or "").lower() in _TERMINAL_STATUSES:
            continue
        due = _review_by(row)
        if due is None or due < now:
            out.append(row)
    return out


def list_controls_core(ctx, *, status=None, efficacy_status=None, limit=50, offset=0,
                       past_review=False):
    """Shared list routine — the single fetch/normalize/output path for controls.

    Both `torana controls list` and any future workspace-scoped list call this so
    they can never drift (surface-parity rule)."""
    fmt, raw, fields = _fmt(ctx)
    params = {"limit": limit, "offset": offset}
    if status:
        params["status"] = status
    if efficacy_status:
        params["efficacy_status"] = efficacy_status
    client = _client(ctx)
    try:
        data = client.get("/tables/controls/data", params=params)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    normalized = _normalize(data)
    rows = _annotate_review(normalized.get("items") or [])
    if past_review:
        rows = _past_review(rows)
        # Say what was filtered, so an empty result is never read as
        # "nothing is overdue" when it was really "nothing was fetched".
        click.echo(
            f"Past review-by: {len(rows)} of {normalized.get('total', len(rows))} "
            f"control(s) fetched (limit={limit}, offset={offset}).",
            err=True,
        )
    normalized["items"] = rows
    normalized["total"] = len(rows) if past_review else normalized.get("total", len(rows))
    output(normalized, fmt=fmt, raw=raw, fields=fields, columns=[
        ("torana_control_id", "CONTROL_ID", 32),
        ("status", "STATUS", 10),
        ("action", "ACTION", 8),
        ("efficacy_status", "EFFICACY", 10),
        ("_review_by", "REVIEW_BY", 12),
        ("_overdue", "OVERDUE", 10),
        ("name", "NAME", 30),
    ])


@click.group(name="controls", invoke_without_command=True)
@click.pass_context
def controls(ctx):
    """Compensating controls (WAF rules) — collection ops (T10).

    \b
    Examples:
      torana controls list --status active
      torana controls list --efficacy-status blocked
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@controls.command(name="list")
@click.option("--status", default=None,
              type=click.Choice(["shadow", "active", "retired", "expired"]),
              help="Filter by lifecycle status.")
@click.option("--efficacy-status", "efficacy_status", default=None,
              type=click.Choice(["blocked", "bypassed", "partial", "untested"]),
              help="Filter by before/after efficacy verdict.")
@click.option("--past-review", is_flag=True, default=False,
              help="Only controls that are still live and are at/past their "
                   "review-by date — including any with NO expiry at all, which "
                   "is the unbounded-mitigation case this sweeps for.")
@click.option("--limit", default=50, type=int)
@click.option("--offset", default=0, type=int)
@click.pass_context
def controls_list(ctx, status, efficacy_status, past_review, limit, offset):
    """List compensating controls (with their efficacy verdicts).

    \b
    Every listing shows REVIEW_BY and OVERDUE. A compensating control is a
    TEMPORARY mitigation, so use --past-review to sweep the ones that have
    outlived their review date (or never had one):

      torana controls list --past-review
    """
    list_controls_core(ctx, status=status, efficacy_status=efficacy_status,
                       past_review=past_review, limit=limit, offset=offset)


@controls.command(name="create")
@click.option("--engine-rule-id", "engine_rule_id", default=None,
              help="Provider rule id (Cloudflare rule id). Derives the control id if no --id.")
@click.option("--control-id", "torana_control_id", default=None, help="Explicit PK (optional).")
@click.option("--name", default=None)
@click.option("--expression", default=None, help="WAF match expression.")
@click.option("--action", default=None, type=click.Choice(["log", "block"]),
              help="log = shadow, block = active.")
@click.option("--status", default="shadow",
              type=click.Choice(["shadow", "active", "retired", "expired"]))
@click.option("--vulnerability-id", "torana_vulnerability_id", default=None)
@click.option("--alert-id", "torana_alert_id", default=None)
@click.option("--description", default="")
@click.option("--expires-at", "expires_at", default=None, metavar="ISO8601",
              help="Review-by date for this TEMPORARY mitigation "
                   "(e.g. 2026-12-01T00:00:00Z). Omit and the server derives "
                   "one, so a control never becomes silently permanent.")
@click.pass_context
def controls_create(ctx, engine_rule_id, torana_control_id, name, expression, action,
                    status, torana_vulnerability_id, torana_alert_id, description,
                    expires_at):
    """Record a compensating control.

    \b
    A compensating control is a TEMPORARY mitigation. If you do not pass
    --expires-at the server derives a review-by date rather than leaving the
    control permanent; `torana controls list --past-review` shows the ones
    that are due.
    """
    fmt, raw, fields = _fmt(ctx)
    body = {"status": status, "description": description}
    for k, v in dict(engine_rule_id=engine_rule_id, torana_control_id=torana_control_id,
                     name=name, expression=expression, action=action,
                     expires_at=expires_at,
                     torana_vulnerability_id=torana_vulnerability_id,
                     torana_alert_id=torana_alert_id).items():
        if v is not None:
            body[k] = v
    client = _client(ctx)
    try:
        data = client.post("compensating-controls", json=body)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)
