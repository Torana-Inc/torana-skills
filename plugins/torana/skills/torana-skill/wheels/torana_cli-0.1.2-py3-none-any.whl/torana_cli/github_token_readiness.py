"""Text view of a GitHub integration's token readiness (A1b, B22 shape), printed by `integration <id> token-readiness`
and after `integration <id> test-auth`.

⛔ The server writes every sentence (`words`, `label`, the summary `words`, `token_scope.note`); this module only lays
them out. ⛔ Icon AND word on every line: state is never carried by colour alone.
"""
from typing import Any, Dict, List

_MARK = {"ready": "✔ ready  ", "missing": "✖ MISSING", "partial": "◐ PARTIAL", "unknown": "? unknown"}
_VERDICT = {True: "READY", False: "NOT READY", None: "UNKNOWN (could not check everything)"}


def render(result: Dict[str, Any]) -> str:
    if not result.get("applicable", True):
        return f"GitHub token readiness: not applicable\n  {result.get('words') or ''}".rstrip()
    out: List[str] = [f"GitHub token readiness: {_VERDICT.get(result.get('ready'), 'UNKNOWN')}"]
    if result.get("words"):
        out.append(f"  {result['words']}")
    who = result.get("token_login")
    kind = result.get("token_kind")
    if who or kind:
        out.append(f"  Token: {kind or 'unknown kind'}{f', owner {who}' if who else ''}")
    scope = result.get("token_scope") or {}
    if scope.get("note"):
        out.append(f"  Scope: {scope['note']}")
    out.append("")
    for c in result.get("checks") or []:
        state = c.get("state") or {True: "ready", False: "missing", None: "unknown"}[c.get("ok")]
        out.append(f"  {_MARK.get(state, state)}  {c.get('label') or c.get('check')}")
        if c.get("words"):
            out.append(f"      {c['words']}")
            owners = c.get("who_fixes_all") or ([c["who_fixes"]] if c.get("who_fixes") else [])
            if owners:
                out.append(f"      Who fixes it: {', '.join(owners)}")
    return "\n".join(out)
