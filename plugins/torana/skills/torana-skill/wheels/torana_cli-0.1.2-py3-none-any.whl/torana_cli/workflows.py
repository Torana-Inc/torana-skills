"""torana workflows — workflow management commands (enhanced-workflows API)."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW, CollectionGroup
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 40),
    ("state", "STATE", 12),
    ("version", "VERSION", 8),
    ("description", "DESCRIPTION", 40),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(cls=CollectionGroup, singular="workflow")
def workflows():
    """Manage workflows (collection operations).

    \b
    CLI commands map to /api/v1/enhanced-workflows/ (active workflows).
    Legacy import/export map to /api/v1/workflows/.

    \b
    Instance commands (get, update, delete, execute, etc.) are under:
      torana workflow <UUID> <verb>

    \b
    Examples:
      torana workflows list
      torana workflows create --file workflow.yaml
      torana workflows import --file workflow.yaml
    """


@workflows.command(name="list")
@click.option("--state", default=None, help="Filter by state (active, draft, archived).")
@click.option("--search", default=None, help="Search by name.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.pass_context
def workflows_list(ctx, state, search, page, page_size, fetch_all):
    """List workflows.

    \b
    Examples:
      torana workflows list
      torana workflows list --state published --search enrich
      torana workflows list --json | jq '.items[] | {name, state, version}'
    """
    list_workflows_core(ctx, state=state, search=search, page=page,
                        page_size=page_size, fetch_all=fetch_all)


def list_workflows_core(ctx, *, workspace_id=None, state=None, search=None,
                        page=1, page_size=None, fetch_all=False):
    """Shared workflows-list routine.

    `torana workflows list` (all workflows) and
    `torana workspace <id> workflows list` (this workspace) both call this.
    When `workspace_id` is bound, the workspace-scoped endpoint is used; the
    fetch/paginate/normalize/output flow is identical. Single source of truth.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    endpoint = f"workspaces/{workspace_id}/workflows" if workspace_id else "api/v2/workflows"

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"page": page, "page_size": effective_page_size}
    if state:
        params["state"] = state
    if search:
        params["search"] = search

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"page": page_num, "page_size": effective_page_size}
                p.update({k: v for k, v in params.items() if k not in ("page", "page_size")})
                data = client.get(endpoint, params=p)
                items = data.get("items", [])
                all_items.extend(items)
                if len(all_items) >= data.get("total", len(all_items)):
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items), "page": 1,
                      "page_size": len(all_items)}
        else:
            result = client.get(endpoint, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # The workspace-scoped endpoint nests rows under "workflows"; normalize to
    # the {items, total, ...} envelope output() expects.
    if isinstance(result, dict) and "items" not in result and "workflows" in result:
        result = {"items": result.get("workflows", []), "total": result.get("total", 0),
                  "page": page, "page_size": effective_page_size}

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@workflows.command(name="create")
@click.option("--name", default=None)
@click.option("--description", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def workflows_create(ctx, name, description, input_file):
    """Create a new workflow.

    \b
    Examples:
      torana workflows create --file workflow.yaml
      torana workflows create --name "Enrich alert" --description "..."

    \b
      Only a `published` workflow can execute:
        torana workflow <WORKFLOW_ID> publish
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if description:
        body["description"] = description

    if not body.get("name"):
        click.echo("ERROR: --name is required (or provide --file with 'name' field).", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post("enhanced-workflows/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created workflow: {data.get('id', 'unknown')}")
        click.echo(f"  Name: {data.get('name', '')}")


@workflows.command(name="import")
@click.option("--file", "input_file", required=True, metavar="FILE",
              help="YAML or JSON file to import.")
@click.pass_context
def workflows_import(ctx, input_file):
    """Import a workflow from a file (legacy endpoint).

    \b
    Example:
      torana workflows import --file workflow.yaml
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = _load_input_file(input_file)

    client = _client(ctx)
    try:
        data = client.post("workflows/import/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Imported workflow: {data.get('id', 'unknown')}")


@workflows.command(name="executions")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--status", "status", default=None, help="Filter by status")
@click.option("--limit", "limit", type=int, default=50, help="Maximum results")
@click.option("--offset", "offset", type=int, default=0, help="Offset for pagination")
@click.pass_context
def enhanced_workflows_executions(ctx, status, limit, offset, page, page_size, fetch_all):
    """List All Executions."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "enhanced-workflows/executions"
    params = {}
    if status is not None:
        params["status"] = status
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


# ──────────────────────────────────────────────────────────────────────────
# Instance reads regrouped from `<noun>-by-<param>` leaves onto verbs
# (CLI Discoverability Contract, rule 2 — see ../CLAUDE.md). The route
# parameter belongs in the positional ARGUMENT, not in the command name.
#
# Old flat names remain as HIDDEN aliases for ONE release (D4).
# ──────────────────────────────────────────────────────────────────────────


@workflows.group(name="builder")
def workflows_builder_grp():
    """Visual workflow builder — flows, steps, data paths.

    Examples:
      torana workflows builder get --help
    """


@workflows.group(name="execution")
def workflows_execution_grp():
    """One workflow execution, by id.

    Examples:
      torana workflows execution get --help
    """


@workflows_execution_grp.command(name="get")
@click.argument("EXECUTION_ID", metavar="EXECUTION_ID")
@click.pass_context
def enhanced_workflows_executions_by_execution_id(ctx, execution_id):
    """Get Execution Status."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"enhanced-workflows/executions/{execution_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workflows.command(name="logs")
@click.argument("EXECUTION_ID", metavar="EXECUTION_ID")
@click.pass_context
def enhanced_workflows_logs(ctx, execution_id):
    """Get Execution Logs."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"enhanced-workflows/executions/{execution_id}/logs"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workflows.command(name="flow-executions")
@click.argument("FLOW_ID", metavar="FLOW_ID")
@click.option("--status", "status", default=None, help="Filter by status")
@click.option("--limit", "limit", type=int, default=50, help="Maximum results")
@click.option("--offset", "offset", type=int, default=0, help="Offset for pagination")
@click.pass_context
def workflows_flow_executions(ctx, flow_id, status, limit, offset):
    """List Flow Executions."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"enhanced-workflows/{flow_id}/executions"
    params = {}
    if status is not None:
        params["status"] = status
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workflows.command(name="enhanced-validate")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with request body. Use '-' for stdin.")
@click.option("--flow-id", "flow_id", default=None, help="Optional flow ID for context")
@click.option("--workspace-id", "workspace_id", required=True, help="Workspace ID")
@click.option("--id", "id", default=None, help="Flow ID")
@click.option("--name", "name", required=True, help="Flow name")
@click.option("--description", "description", default=None, help="Flow description")
@click.option("--version", "version", default="1.0.0", help="Flow version")
@click.option("--tags", "tags", default=None, help="Flow tags")
@click.option("--author", "author", default=None, help="Flow author")
@click.option("--status", "status", type=click.Choice(["draft", "published", "archived"], case_sensitive=False), default=None, help="Flow status enumeration.")
@click.option("--steps", "steps", required=True, help="Flow steps with enhanced features")
@click.option("--timeout-seconds", "timeout_seconds", type=int, default=3600, help="Overall flow timeout")
@click.option("--parallel-execution", "parallel_execution", type=bool, default=False, help="Enable parallel step execution")
@click.option("--error-handling", "error_handling", default=None, help="Error handling configuration")
@click.option("--ui-metadata", "ui_metadata", default=None, help="UI-specific metadata")
@click.option("--created-at", "created_at", default=None, help="Creation timestamp")
@click.option("--updated-at", "updated_at", default=None, help="Last update timestamp")
@click.option("--created-by", "created_by", default=None, help="User ID who created this workflow")
@click.pass_context
def enhanced_workflows_validate(ctx, flow_id, workspace_id, id, name, description, version, tags, author, status, steps, timeout_seconds, parallel_execution, error_handling, ui_metadata, created_at, updated_at, created_by, input_file):
    """Validate Enhanced Flow."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "enhanced-workflows/validate"
    params = {}
    if flow_id is not None:
        params["flow_id"] = flow_id
    if input_file:
        body = _load_input_file(input_file)
    else:
        body = {}
        body["workspace_id"] = workspace_id
        if id is not None:
            body["id"] = id
        body["name"] = name
        if description is not None:
            body["description"] = description
        if version is not None:
            body["version"] = version
        if tags is not None:
            body["tags"] = tags
        if author is not None:
            body["author"] = author
        if status is not None:
            body["status"] = status
        body["steps"] = steps
        if timeout_seconds is not None:
            body["timeout_seconds"] = timeout_seconds
        if parallel_execution is not None:
            body["parallel_execution"] = parallel_execution
        if error_handling is not None:
            body["error_handling"] = error_handling
        if ui_metadata is not None:
            body["ui_metadata"] = ui_metadata
        if created_at is not None:
            body["created_at"] = created_at
        if updated_at is not None:
            body["updated_at"] = updated_at
        if created_by is not None:
            body["created_by"] = created_by

    client = _client(ctx)
    try:
        data = client.post(path, json=body, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workflows.command(name="step-definitions")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def workflows_step_definitions(ctx, page, page_size, fetch_all):
    """Get Step Definitions."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "workflows/builder/step-definitions"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@workflows_builder_grp.command(name="data-paths")
@click.argument("FLOW_ID", metavar="FLOW_ID")
@click.argument("STEP_ID", metavar="STEP_ID")
@click.pass_context
def workflows_data_paths_by_step_id(ctx, flow_id, step_id):
    """Get Available Data Paths."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"workflows/builder/data-paths/{flow_id}/{step_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workflows.command(name="builder-validate")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with request body. Use '-' for stdin.")
@click.option("--workspace-id", "workspace_id", required=True, help="Workspace ID")
@click.option("--id", "id", default=None, help="Flow ID")
@click.option("--name", "name", required=True, help="Flow name")
@click.option("--description", "description", default=None, help="Flow description")
@click.option("--version", "version", default="1.0.0", help="Flow version")
@click.option("--tags", "tags", default=None, help="Flow tags")
@click.option("--author", "author", default=None, help="Flow author")
@click.option("--status", "status", type=click.Choice(["draft", "published", "archived"], case_sensitive=False), default=None, help="Flow status enumeration.")
@click.option("--steps", "steps", required=True, help="Flow steps with enhanced features")
@click.option("--timeout-seconds", "timeout_seconds", type=int, default=3600, help="Overall flow timeout")
@click.option("--parallel-execution", "parallel_execution", type=bool, default=False, help="Enable parallel step execution")
@click.option("--error-handling", "error_handling", default=None, help="Error handling configuration")
@click.option("--ui-metadata", "ui_metadata", default=None, help="UI-specific metadata")
@click.option("--created-at", "created_at", default=None, help="Creation timestamp")
@click.option("--updated-at", "updated_at", default=None, help="Last update timestamp")
@click.option("--created-by", "created_by", default=None, help="User ID who created this workflow")
@click.pass_context
def workflows_validate(ctx, workspace_id, id, name, description, version, tags, author, status, steps, timeout_seconds, parallel_execution, error_handling, ui_metadata, created_at, updated_at, created_by, input_file):
    """Validate Flow."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "workflows/builder/validate"
    if input_file:
        body = _load_input_file(input_file)
    else:
        body = {}
        body["workspace_id"] = workspace_id
        if id is not None:
            body["id"] = id
        body["name"] = name
        if description is not None:
            body["description"] = description
        if version is not None:
            body["version"] = version
        if tags is not None:
            body["tags"] = tags
        if author is not None:
            body["author"] = author
        if status is not None:
            body["status"] = status
        body["steps"] = steps
        if timeout_seconds is not None:
            body["timeout_seconds"] = timeout_seconds
        if parallel_execution is not None:
            body["parallel_execution"] = parallel_execution
        if error_handling is not None:
            body["error_handling"] = error_handling
        if ui_metadata is not None:
            body["ui_metadata"] = ui_metadata
        if created_at is not None:
            body["created_at"] = created_at
        if updated_at is not None:
            body["updated_at"] = updated_at
        if created_by is not None:
            body["created_by"] = created_by

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workflows_builder_grp.command(name="save")
@click.argument("FLOW_ID", metavar="FLOW_ID")
@click.option("--nodes", "nodes", required=True, help="Visual nodes")
@click.option("--connections", "connections", required=True, help="Visual connections")
@click.option("--canvas-size", "canvas_size", default={'width': 2000, 'height': 2000}, help="Canvas dimensions")
@click.option("--zoom-level", "zoom_level", type=float, default=1.0, help="Current zoom level")
@click.option("--viewport", "viewport", default={'x': 0, 'y': 0, 'width': 1000, 'height': 600}, help="Current viewport")
@click.option("--metadata", "metadata", default=None, help="Additional metadata")
@click.pass_context
def workflows_save_by_flow_id(ctx, flow_id, nodes, connections, canvas_size, zoom_level, viewport, metadata):
    """Save Visual Flow Data."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"workflows/builder/visual/save/{flow_id}"
    body = {}
    body["nodes"] = nodes
    body["connections"] = connections
    if canvas_size is not None:
        body["canvas_size"] = canvas_size
    if zoom_level is not None:
        body["zoom_level"] = zoom_level
    if viewport is not None:
        body["viewport"] = viewport
    if metadata is not None:
        body["metadata"] = metadata

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workflows_builder_grp.command(name="get")
@click.argument("FLOW_ID", metavar="FLOW_ID")
@click.pass_context
def workflows_visual_by_flow_id(ctx, flow_id):
    """Get Visual Flow Data."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"workflows/builder/visual/{flow_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workflows_builder_grp.command(name="visualize")
@click.argument("EXECUTION_ID", metavar="EXECUTION_ID")
@click.pass_context
def workflows_visualize_by_execution_id(ctx, execution_id):
    """Get Execution Visualization."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"workflows/builder/execution/visualize/{execution_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workflows.command(name="dry-run")
@click.option("--flow", "flow", required=True, help="Enhanced flow definition with full data flow support.")
@click.option("--test-inputs", "test_inputs", required=True)
@click.pass_context
def workflows_dry_run(ctx, flow, test_inputs):
    """Test Flow Dry Run."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "workflows/builder/test/dry-run"
    body = {}
    body["flow"] = flow
    body["test_inputs"] = test_inputs

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workflows.command(name="bulk")
@click.option("--format", "format", default="json", help="Export format: json or yaml")
@click.option("--workflow-ids", "workflow_ids", required=True, help="List of workflow UUIDs to export")
@click.pass_context
def workflows_bulk(ctx, format, workflow_ids):
    """Export Workflows Bulk."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "workflows/export/bulk"
    params = {}
    if format is not None:
        params["format"] = format
    body = {}
    body["workflow_ids"] = workflow_ids

    client = _client(ctx)
    try:
        data = client.post(path, json=body, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workflows.command(name="import-json")
@click.option("--import-data", "import_data", required=True)
@click.option("--author", "author", default=None, help="Author to assign to imported workflow")
@click.option("--overwrite-ids", "overwrite_ids", type=bool, default=True, help="Generate new IDs for imported workflow")
@click.pass_context
def workflows_import_json(ctx, import_data, author, overwrite_ids):
    """Import Workflow Json."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "workflows/import/json"
    body = {}
    body["import_data"] = import_data
    if author is not None:
        body["author"] = author
    if overwrite_ids is not None:
        body["overwrite_ids"] = overwrite_ids

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workflows.command(name="import-yaml")
@click.pass_context
def workflows_import_yaml(ctx):
    """Import Workflow Yaml."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "workflows/import/yaml"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workflows.command(name="import-bulk")
@click.pass_context
def workflows_import_bulk(ctx):
    """Import Workflows Bulk."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "workflows/import/bulk"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workflows.command(name="import-package")
@click.pass_context
def workflows_import_package(ctx):
    """Import Workflow Package."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "workflows/import/package"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workflows.command(name="formats")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def workflows_formats(ctx, page, page_size, fetch_all):
    """Get Supported Formats."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "workflows/export/formats"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


# ---------------------------------------------------------------------------
# detection-workflows commands (detection framework's own workflow CRUD)
# ---------------------------------------------------------------------------

@click.group(name="detection-workflows")
def detection_workflows():
    """Detection-framework workflows (distinct from `torana workflows`).

    \b
    ⚠️ These are the DETECTION framework's own workflows. The general automation
    workflows live under `torana workflows` / `torana playbooks` — different
    service, different objects. Check which one you mean before creating.

    \b
    Examples:
      torana detection-workflows list
      torana detection-workflows get <WORKFLOW_ID>
      torana detection-workflows create --help
      torana detection-workflows update <WORKFLOW_ID> --help
    """


@detection_workflows.command(name="list")
@click.option("--workspace-id", "workspace_id", default=None)
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", "page_size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.pass_context
def detection_workflows_list(ctx, workspace_id, page, page_size, fetch_all):
    """List detection workflows."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "workflows/"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if workspace_id is not None:
        params["workspace_id"] = workspace_id

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@detection_workflows.command(name="get")
@click.argument("WORKFLOW_ID", metavar="WORKFLOW_ID")
@click.pass_context
def detection_workflows_get(ctx, workflow_id):
    """Get a detection workflow."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"workflows/{workflow_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@detection_workflows.command(name="create")
@click.option("--input", "input_file", default=None, help="JSON/YAML file with workflow body.")
@click.option("--name", default=None)
@click.option("--workspace-id", "workspace_id", default=None)
@click.pass_context
def detection_workflows_create(ctx, input_file, name, workspace_id):
    """Create a detection workflow."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = _load_input_file(input_file) if input_file else {}
    if name is not None:
        body["name"] = name
    if workspace_id is not None:
        body["workspace_id"] = workspace_id

    client = _client(ctx)
    try:
        data = client.post("workflows/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@detection_workflows.command(name="update")
@click.argument("WORKFLOW_ID", metavar="WORKFLOW_ID")
@click.option("--input", "input_file", default=None, help="JSON/YAML file with updated fields.")
@click.option("--name", default=None)
@click.pass_context
def detection_workflows_update(ctx, workflow_id, input_file, name):
    """Update a detection workflow."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = _load_input_file(input_file) if input_file else {}
    if name is not None:
        body["name"] = name

    client = _client(ctx)
    try:
        data = client.put(f"workflows/{workflow_id}", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@detection_workflows.command(name="delete")
@click.argument("WORKFLOW_ID", metavar="WORKFLOW_ID")
@click.option("--yes", "-y", is_flag=True, default=False)
@click.pass_context
def detection_workflows_delete(ctx, workflow_id, yes):
    """Delete a detection workflow."""
    _confirm(f"Delete detection workflow {workflow_id}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"workflows/{workflow_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted detection workflow: {workflow_id}")


@workflows.command(name="builder-flow-move")
@click.argument("FLOW_ID", metavar="FLOW_ID")
@click.option("--target-workflow-id", "target_workflow_id", required=True)
@click.pass_context
def workflows_builder_flow_move(ctx, flow_id, target_workflow_id):
    """Move a builder flow to a different workflow."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = {"target_workflow_id": target_workflow_id}
    client = _client(ctx)
    try:
        data = client.post(f"workflows/builder/flows/{flow_id}/move", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workflows.command(name="validate-import")
@click.option("--input", "input_file", default=None, help="JSON/YAML file with workflow import data.")
@click.pass_context
def workflows_validate_import(ctx, input_file):
    """Validate a workflow import package."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = _load_input_file(input_file) if input_file else {}
    client = _client(ctx)
    try:
        data = client.post("workflows/validate/import", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ──────────────────────────────────────────────────────────────────────────
# BACK-COMPAT — hidden aliases for the old `<noun>-by-<param>` names.
# ⏳ ONE RELEASE ONLY (decision D4). Delete this block next release.
# ──────────────────────────────────────────────────────────────────────────

_LEGACY_BY_PARAM_WORKFLOWS = {
    "data-paths-by-step-id": ("builder", "data-paths"),
    "executions-by-execution-id": ("execution", "get"),
    "save-by-flow-id": ("builder", "save"),
    "visual-by-flow-id": ("builder", "get"),
    "visualize-by-execution-id": ("builder", "visualize"),
}


def _register_legacy_workflows_by_param() -> None:
    """Old flat names, hidden so they cannot be discovered anew."""
    import copy
    for _old, (_sub, _verb) in _LEGACY_BY_PARAM_WORKFLOWS.items():
        _grp = workflows.commands.get(_sub)
        if not isinstance(_grp, click.Group):
            continue
        _cmd = _grp.commands.get(_verb)
        if _cmd is None:
            continue
        # ⛔ Never let an alias overwrite a real group of the same name.
        if isinstance(workflows.commands.get(_old), click.Group):
            continue
        _alias = copy.copy(_cmd)
        _alias.name = _old
        _alias.hidden = True
        workflows.add_command(_alias)


_register_legacy_workflows_by_param()
