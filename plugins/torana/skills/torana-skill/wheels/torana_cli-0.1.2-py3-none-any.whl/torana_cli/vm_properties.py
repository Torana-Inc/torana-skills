"""torana vm properties — Domain Property Registry & per-tenant coverage (Spec G).

Attaches the ``properties`` subgroup onto the shared ``torana vm`` parent via
``register_vm_subgroup`` (see vm.py) — this module never re-defines ``vm``.

Sibling of ``torana vm policy``: the vocabulary registry governs policy VALUES
(what a domain word means for this tenant); this registry governs decoration
PROPERTIES (which column carries a fact, who supplies it, how it propagates,
how covered it is). Both live under the same parent so an operator who knows
one already knows the other.

Three-surface parity (R8): every capability here exists on the API
(/api/v1/properties*) and on the FE — tenant Data Readiness on the policy page,
SA Data Properties tab in the Policy Workbench. ``--tenant-id`` is the SA
cross-tenant variant; a non-SA caller passing it gets the API's 403.

Spec: pantheon-program-framework/docs/VM/09_SpecG_Domain_Property_Registry.md § 3.4.2
"""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.vm import register_vm_subgroup

_BASE = "properties"

_REGISTRY_COLS = [
    ("key", "KEY", 30),
    ("entity", "ENTITY", 14),
    ("scope", "SCOPE", 8),
    ("domain", "DOMAIN", 8),
    ("provenance_class", "CLASS", 11),
    ("consumers", "USED BY", 8),
    ("column", "COLUMN", 22),
]

_COVERAGE_COLS = [
    ("key", "KEY", 30),
    # Spec H § 4.12.1a / § 4.12.12 — the tenant-facing NAME, alongside (not replacing) the key:
    # operators script on `key`, humans read `label`. Dropping the key would break the former.
    ("label", "NAME", 26),
    # Spec H § 3.15 — was "COMES FROM" showing the registry CLASS, which reads as provenance
    # and was wrong on every row (Environment said SCANNED; zero values came from a scan).
    ("supplied", "WHO SUPPLIED IT", 24),
    ("verdict", "VERDICT", 13),
    ("column_cov", "COLUMN", 13),
    ("resolved_cov", "RESOLVED", 10),
    ("coverage_via", "VIA", 11),
]

_SOURCE_COLS = [
    ("id", "SOURCE", 20),
    ("category", "COMES FROM", 13),
    ("writes", "WRITES", 40),
    ("system", "OWNED BY", 46),
]

#: The six user-facing category labels — the SAME words the FE badges use, so an
#: operator reading a terminal and a tenant reading the UI share one vocabulary.
#: Spec H § 3.15.5a — these name the KIND of fact, NOT who supplied this tenant's values.
#: They read "YOU SET IT"/"SCANNED" until `supplied_by` shipped beside them and made the
#: contradiction visible on one line (SCANNED 1 next to "29 set · 29 inherited", zero scanned).
_CATEGORY_LABEL = {
    "you_set_it": "DECLARED",
    "your_policy": "FROM POLICY",
    "scanned": "OBSERVED",
    "calculated": "COMPUTED",
    "inherited": "INHERITED",
    "not_set": "NOT SET",
}


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _fmt(ctx) -> str:
    return ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"


def _tenant_params(tenant_id):
    """SA cross-tenant override — omitted entirely when not supplied."""
    return {"tenant_id": tenant_id} if tenant_id else {}


@click.group(name="properties")
def properties():
    """Domain property registry — what decoration properties exist, who supplies
    them, and how covered they are for a tenant.

    Examples:
      torana vm properties list
      torana vm properties coverage
      torana vm properties resolve image:us-west1-docker.pkg.dev/p/r/img
      torana vm properties rebuild
    """


@properties.command(name="list")
@click.option("--entity", default=None,
              help="Filter by entity family (asset | vulnerability | repository).")
@click.option("--scope", multiple=True,
              help="Filter by scope (repeatable, OR): entity | domain. "
                   "`entity` = a shared fact about the entity; `domain` = owned by one "
                   "domain and shown with that domain, not on the platform policy page.")
@click.pass_context
def properties_list(ctx, entity, scope):
    """List the registry — every property, its class, and its canonical column.

    The registry is platform code (not tenant data), so this is the same answer
    for every tenant. Use `coverage` for the per-tenant picture.
    """
    client = _client(ctx)
    params = {"entity": entity} if entity else {}
    if scope:
        params["scope"] = list(scope)
    try:
        data = client.get(f"{_BASE}", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(
        data, fmt=_fmt(ctx),
        raw=ctx.obj.get(CTX_RAW, False) if ctx.obj else False,
        fields=ctx.obj.get(CTX_FIELDS) if ctx.obj else None,
        columns=_REGISTRY_COLS,
    )


@properties.command(name="why")
@click.argument("key", metavar="PROPERTY_KEY")
@click.pass_context
def properties_why(ctx, key):
    """Why does governing this property matter? — what breaks, per domain.

    The count in `list` (USED BY) says HOW MANY domains depend on a fact; this says WHAT
    happens in each when the value is wrong. Named outcomes, not mechanism.
    """
    client = _client(ctx)
    try:
        data = client.get(f"{_BASE}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    item = next((i for i in (data.get("items") or []) if i.get("key") == key), None)
    if item is None:
        click.echo(f"No such property: {key}", err=True)
        raise SystemExit(3)
    cons = item.get("consequences") or {}
    # Spec H § 4.12.12 (R8 gate) — `composed_of` was API+FE only; the CLI could not answer
    # "which input do I fix?" for a COMPUTED property. `why` is its home: this verb already
    # answers "what breaks", and composition answers "what would I change".
    parts = item.get("composed_of") or []
    label = item.get("label") or ""
    if _fmt(ctx) in ("json", "yaml"):
        output({"key": key, "label": label, "meaning": item.get("meaning") or "",
                "consumers": len(cons), "consequences": cons, "composed_of": parts},
               fmt=_fmt(ctx))
        return
    click.echo(f"\n{key}{' — ' + label if label else ''} — used by {len(cons)} domain(s)\n")
    if item.get("meaning"):
        click.echo(f"  {item['meaning']}\n")
    if parts:
        # Same shape the FE renders: "Past SLA = when it was found + your remediation window".
        click.echo(f"  {label or key} = " + " + ".join(p.get("input", "?") for p in parts))
        for p in parts:
            src = p.get("source_kind", "?")
            pk = p.get("policy_key")
            click.echo(f"    · {p.get('input', '?')}  ({src}{': ' + pk if pk else ''})")
        click.echo("")
    for dom, txt in sorted(cons.items()):
        click.echo(f"  If this is wrong, in {dom}:")
        click.echo(f"    {txt}\n")


@properties.command(name="entities")
@click.option("--ungoverned", is_flag=True, default=False,
              help="Show the remainder instead — governable entities governance has not reached.")
@click.option("--kind", default=None, help="service | image")
@click.option("--limit", default=100, show_default=True)
@click.option("--tenant-id", default=None, help="Super-admin only: another tenant.")
@click.pass_context
def properties_entities(ctx, ungoverned, kind, limit, tenant_id):
    """WHICH entities does governance reach — the list, not just the count.

    The page reported "58 governed entities" and gave no way to see which 58. `--ungoverned`
    returns the remainder, restricted to kinds governance can actually reach: listing cloud
    resources nobody can govern would read as a backlog rather than as "not addressable".
    """
    client = _client(ctx)
    params = _tenant_params(tenant_id)
    params["governed"] = "false" if ungoverned else "true"
    params["limit"] = limit
    if kind:
        params["kind"] = kind
    try:
        data = client.get(f"{_BASE}/entities", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if not data.get("items"):
        click.echo("\nNo ungoverned entities — governance reaches every service and running "
                   "image.\n" if ungoverned else "\nNo governed entities yet.\n")
        return
    output(
        data, fmt=_fmt(ctx),
        raw=ctx.obj.get(CTX_RAW, False) if ctx.obj else False,
        fields=ctx.obj.get(CTX_FIELDS) if ctx.obj else None,
        columns=[("entity_kind", "KIND", 8), ("entity_key", "ENTITY", 58),
                 ("asset_team", "TEAM", 18), ("asset_environment", "ENV", 8)],
    )


@properties.command(name="estate")
@click.option("--tenant-id", default=None, help="Super-admin only: report on another tenant.")
@click.pass_context
def properties_estate(ctx, tenant_id):
    """How much of your estate does governance actually reach? — per entity kind.

    Reported PER KIND, never as one fraction: each kind's inventory lives in a different
    table, so a blended "58 of 1,321" would mix populations that share no members (it counted
    services + images over services + cloud resources). Images are the ones RUNNING in your
    cluster, not everything in your registry — governance flows service -> image over a
    deployed_as edge, so an image that deploys nowhere cannot inherit it.
    """
    client = _client(ctx)
    try:
        data = client.get(f"{_BASE}/coverage", params=_tenant_params(tenant_id))
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    estate = data.get("estate") or []
    if _fmt(ctx) in ("json", "yaml"):
        output({"items": estate, "total": len(estate)}, fmt=_fmt(ctx))
        return
    click.echo("\nGovernance reaches:\n")
    for e in estate:
        if e.get("governable"):
            line = f"  {e['governed']} of {e['total']} {e['label'].lower()}"
        else:
            line = f"  {e['total']} {e['label'].lower()} — {e.get('note') or ''}"
        click.echo(line)
        if e.get("governable") and e.get("note"):
            click.echo(f"      ({e['note']})")
    click.echo()


@properties.command(name="sources")
@click.pass_context
def properties_sources(ctx):
    """Who can supply each fact — the supply-source census.

    Answers "where do these values actually come from?" without grepping ETL
    mappings: every source, what it writes, and which system owns it.
    """
    client = _client(ctx)
    try:
        data = client.get(f"{_BASE}/sources")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if fmt != "text":
        output(data, fmt=fmt, raw=ctx.obj.get(CTX_RAW, False) if ctx.obj else False,
               fields=ctx.obj.get(CTX_FIELDS) if ctx.obj else None)
        return
    rows = []
    for i in data.get("items", []):
        rows.append({
            "id": i.get("id"),
            "category": _CATEGORY_LABEL.get(i.get("category"), i.get("nature") or "-"),
            "writes": ", ".join(i.get("writes") or [])[:38],
            "system": (i.get("system") or "")[:44],
        })
    output({"items": rows, "total": len(rows)}, fmt="text", columns=_SOURCE_COLS)


@properties.command(name="coverage")
@click.option("--from", "from_", multiple=True,
              help="Filter by category (repeatable, OR): you_set_it | your_policy | "
                   "scanned | calculated | inherited | not_set.")
@click.option("--scope", multiple=True,
              help="Filter by scope (repeatable, OR): entity | domain. "
                   "`--scope entity --user-facing` reproduces exactly what the tenant "
                   "sees on Context -> Policy.")
@click.option("--entity", "entity_", multiple=True,
              help="Filter by entity family (repeatable, OR), e.g. asset.")
@click.option("--user-facing", is_flag=True, default=False,
              help="Exclude numeric mirrors the tenant panel folds away. Off by default "
                   "so operators lose nothing.")
@click.option("--tenant-id", default=None,
              help="Super-admin only: report on another tenant.")
@click.pass_context
def properties_coverage(ctx, from_, scope, entity_, user_facing, tenant_id):
    """Per-tenant coverage — how populated is each property, and what to do about it.

    Verdicts: ok (>=80% populated) · partial · unconfigured (nothing supplies it)
    · computed (materialized at transform time, no lake column to count).
    An `unconfigured` property is why a widget renders empty; the remedy names
    the fix, which differs by provenance class.
    """
    client = _client(ctx)
    try:
        params = _tenant_params(tenant_id)
        if from_:
            params["from"] = list(from_)
        if scope:
            params["scope"] = list(scope)
        if entity_:
            params["entity"] = list(entity_)
        if user_facing:
            params["user_facing"] = "true"
        data = client.get(f"{_BASE}/coverage", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if fmt != "text":
        output(data, fmt=fmt, raw=ctx.obj.get(CTX_RAW, False) if ctx.obj else False,
               fields=ctx.obj.get(CTX_FIELDS) if ctx.obj else None)
        return

    click.echo(f"tenant: {data.get('tenant_id')}   "
               f"resolution rows: {data.get('resolution_rows', 0)}")
    # The counts line mirrors the FE filter row — and carries the same insight in a
    # terminal: "YOUR POLICY 0" beside "YOU SET IT 6" says the tenant's policy
    # documents drive nothing. Always printed UNFILTERED, even when --from is set.
    counts = data.get("category_counts") or {}
    if counts:
        who = " · ".join(f"{_CATEGORY_LABEL[c]} {counts.get(c, 0)}"
                         for c in ("you_set_it", "your_policy", "scanned", "inherited")
                         if c in _CATEGORY_LABEL)
        other = " · ".join(f"{_CATEGORY_LABEL[c]} {counts.get(c, 0)}"
                           for c in ("calculated", "not_set"))
        # Spec H § 3.15 — this rollup counts properties by REGISTRY CLASS, not by who supplied
        # any value. Left in place (it is the filter vocabulary, and `--from` filters by it) but
        # RELABELLED: it said "who supplied it" directly above a WHO SUPPLIED IT column showing
        # different numbers, which is the exact confusion the column fix removes.
        click.echo(f"kind of fact:    {who}")
        click.echo(f"other:           {other}")
    rows = []
    for i in data.get("items", []):
        pop, tot = i.get("rows_populated"), i.get("rows_total")
        rpop, rtot = i.get("resolved_populated"), i.get("resolved_total")
        rows.append({
            "key": i.get("key"),
            # Spec H § 4.12.1a — the tenant-facing NAME. This builder is a WHITELIST, which is
            # why `label` rendered blank after the column was added: a field absent here never
            # reaches the table however well the API serves it.
            "label": i.get("label") or "-",
            # Pre-rendered by the API so the CLI and the page print the SAME words (§ 3.15.3).
            "supplied": " · ".join(
                f"{p.get('count')} {p.get('label')}"
                for p in ((i.get("supplied_by") or {}).get("parts") or [])
            ) or "-",
            "verdict": i.get("verdict"),
            # Two dimensions: the raw sink COLUMN, and the RESOLVED table (governed
            # + graph-inherited entities). A property can be empty in the column yet
            # fully resolved — `VIA` names which one the verdict came from.
            "column_cov": f"{pop}/{tot}" if tot is not None else "-",
            "resolved_cov": f"{rpop}/{rtot}" if rtot else "-",
            "coverage_via": i.get("coverage_via") or "-",
        })
    output({"items": rows, "total": len(rows)}, fmt="text", columns=_COVERAGE_COLS)

    remedies = [(i.get("key"), i.get("remedy"))
                for i in data.get("items", []) if i.get("remedy")]
    if remedies:
        click.echo("\nREMEDIES")
        for key, remedy in remedies:
            click.echo(f"  {key}: {remedy}")


@properties.command(name="resolve")
@click.argument("entity_key", metavar="ENTITY_KEY")
@click.option("--tenant-id", default=None,
              help="Super-admin only: resolve within another tenant.")
@click.pass_context
def properties_resolve(ctx, entity_key, tenant_id):
    """Why does THIS entity have these property values? — the provenance receipt.

    ENTITY_KEY is a graph node key, e.g. `service:prod/api` or
    `image:us-west1-docker.pkg.dev/proj/repo/img`. Shows the resolved values plus,
    for each, which deployment or graph edge supplied it and which conflict rule
    decided it.
    """
    client = _client(ctx)
    try:
        data = client.get(f"{_BASE}/resolve/{entity_key}", params=_tenant_params(tenant_id))
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if fmt != "text":
        output(data, fmt=fmt, raw=ctx.obj.get(CTX_RAW, False) if ctx.obj else False,
               fields=ctx.obj.get(CTX_FIELDS) if ctx.obj else None)
        return

    prov = data.get("provenance") or {}
    if isinstance(prov, str):
        import json as _json
        try:
            prov = _json.loads(prov)
        except ValueError:
            prov = {}

    click.echo(f"{data.get('entity_kind', '?')}  {data.get('entity_key')}")
    click.echo()
    click.echo("RESOLVED VALUES")
    for col in ("asset_team", "asset_owner", "asset_environment",
                "criticality_name", "criticality_level",
                "public_access", "has_customer_data"):
        if col in data:
            click.echo(f"  {col:20s} {data.get(col)}")
    if prov:
        click.echo("\nPROVENANCE (why each value is what it is)")
        for key, meta in prov.items():
            if not isinstance(meta, dict):
                click.echo(f"  {key:20s} {meta}")
                continue
            src = meta.get("source", "?")
            bits = []
            if meta.get("deployment_id"):
                bits.append(f"deployment={meta['deployment_id']}")
            if meta.get("edge"):
                bits.append(f"edge={meta['edge']}")
            if meta.get("inherited_from"):
                bits.append(f"from={meta['inherited_from']}")
            if meta.get("rule"):
                bits.append(f"rule={meta['rule']}")
            click.echo(f"  {key:20s} {src}  " + "  ".join(bits))


@properties.command(name="rebuild")
@click.option("--tenant-id", default=None,
              help="Super-admin only: rebuild another tenant's resolution table.")
@click.pass_context
def properties_rebuild(ctx, tenant_id):
    """Recompute the property resolution table now (idempotent).

    Normally runs automatically after a sync, on a governance edit, and at bundle
    install. Use this to pick up a governance change immediately. Concurrent
    rebuilds are collapsed by a per-tenant advisory lock — losing the race is
    safe and reports `skipped_locked`.
    """
    client = _client(ctx)
    try:
        data = client.post(f"{_BASE}/rebuild", params=_tenant_params(tenant_id), json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if fmt != "text":
        output(data, fmt=fmt, raw=ctx.obj.get(CTX_RAW, False) if ctx.obj else False,
               fields=ctx.obj.get(CTX_FIELDS) if ctx.obj else None)
        return

    if data.get("skipped_locked"):
        click.echo("Rebuild already running for this tenant — skipped (safe: the "
                   "holder reads live state).")
        return
    if data.get("error"):
        click.echo(f"Rebuild failed: {data['error']}", err=True)
        return
    click.echo(
        f"Rebuilt {data.get('rows', 0)} row(s): "
        f"{data.get('services', 0)} service, {data.get('images', 0)} image "
        f"(generation {data.get('generation')})"
    )


register_vm_subgroup(properties)


@properties.command(name="freshness")
@click.option("--tenant-id", default=None,
              help="Super-admin only: read another tenant's resolution freshness.")
@click.pass_context
def properties_freshness(ctx, tenant_id):
    """When was the governance resolution table last rebuilt?

    `entity_properties_resolved` is the bridge that carries governance declared
    on a Deployment (`service:` keys) onto `image:`-keyed vulnerabilities. If it
    is stale, governance filters silently match nothing — so "how many rows" was
    never enough; you also need "as of when".

    Reads the same `resolution_resolved_at` the coverage report now returns.
    """
    client = _client(ctx)
    try:
        data = client.get(f"{_BASE}/coverage", params=_tenant_params(tenant_id))
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    slim = {
        "resolution_rows": data.get("resolution_rows"),
        "resolution_resolved_at": data.get("resolution_resolved_at"),
        "resolution_generation": data.get("resolution_generation"),
        "tenant_id": data.get("tenant_id"),
    }
    if fmt != "text":
        output(slim, fmt=fmt, raw=ctx.obj.get(CTX_RAW, False) if ctx.obj else False,
               fields=ctx.obj.get(CTX_FIELDS) if ctx.obj else None)
        return

    rows = slim["resolution_rows"] or 0
    when = slim["resolution_resolved_at"]
    if not when:
        click.echo("Never resolved — no governance has reached vulnerabilities yet. "
                   "Create a Deployment, or run `torana vm properties rebuild`.")
        return
    click.echo(f"Resolved rows  {rows}")
    click.echo(f"Last resolved  {when}")
