"""Local session cache — stores active session_id per agent_id.

File: ~/.torana/cache/sessions/<agent_id>.json
{
    "session_id": "agent_xxx_yyy",
    "created_at": "2026-06-13T15:11:50Z",
    "agent_id": "xxx"
}
"""

import json
from pathlib import Path


def _sessions_dir() -> Path:
    d = Path.home() / ".torana" / "cache" / "sessions"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _session_file(agent_id: str) -> Path:
    return _sessions_dir() / f"{agent_id}.json"


def get_cached_session_id(agent_id: str) -> str | None:
    """Return the cached session_id for this agent, or None."""
    f = _session_file(agent_id)
    if not f.exists():
        return None
    try:
        data = json.loads(f.read_text())
        return data.get("session_id")
    except Exception:
        return None


def save_session_id(agent_id: str, session_id: str, created_at: str = "") -> None:
    """Persist session_id for this agent."""
    _session_file(agent_id).write_text(
        json.dumps({"agent_id": agent_id, "session_id": session_id, "created_at": created_at}, indent=2)
    )


def clear_session(agent_id: str) -> None:
    """Remove cached session for this agent."""
    f = _session_file(agent_id)
    if f.exists():
        f.unlink()
