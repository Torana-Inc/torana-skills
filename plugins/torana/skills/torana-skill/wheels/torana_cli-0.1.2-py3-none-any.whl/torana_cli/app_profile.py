"""`torana workspace <id> app-profile`: what kind of app this workspace is (APP_PROFILES_SPEC § 3.4.2).

Reads `GET /workspaces/{id}/app-profile`: the bundle's declared AppProfile (kind, words, highlight policy), or none,
which means the vulnerability-management defaults. The profile is read from the CURRENT bundle code, not the installed
version (`source: bundle_code`), the same way AI Home reads it.
"""
from __future__ import annotations

import click

from torana_cli.ai_home import _ctx
from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, handle_api_error, handle_auth_error
from torana_cli.output import output

NO_PROFILE = "This app declares no profile (vulnerability-management defaults)."


def profile_lines(data: dict) -> list[str]:
    """The text view: one `LABEL  value` row per field; the no-profile sentence when the bundle declares none."""
    p = data.get("profile") or None
    rows = []
    if p:
        rows += [("KIND", p.get("kind")), ("LABEL", p.get("label")),
                 ("ITEM NOUN", f"{p.get('item_noun')} / {p.get('item_noun_plural')}"),
                 ("HIGHLIGHT", p.get("highlight"))]
    rows += [("BUNDLE", data.get("bundle_id") or "— (not installed from a bundle)"),
             ("INSTALLED", data.get("installed_version") if data.get("installed_version") is not None else "—"),
             ("SOURCE", data.get("source"))]
    width = max(len(k) for k, _ in rows)
    return ([] if p else [NO_PROFILE]) + [f"{k.ljust(width)}  {v}" for k, v in rows]


def register(workspace_group, client_factory):
    """Attach `app-profile` to the `workspace <id>` group (registered from workspace.py)."""

    @workspace_group.command(name="app-profile")
    @click.pass_context
    def app_profile(ctx):
        """Show what kind of app this workspace is: its bundle's declared profile (kind, the words AI Home uses for
        its items, how it picks the highlighted decision), or that it declares none (vulnerability-management
        defaults). Read from the current bundle code, not the installed version. Read-only.

        \b
        Examples:
          torana workspace <ID> app-profile
          torana workspace <ID> app-profile --format json
        """
        fmt, raw, fields = _ctx(ctx)
        wid = ctx.obj.get("_workspace_id", "") if ctx.obj else ""
        try:
            data = client_factory(ctx).get(f"workspaces/{wid}/app-profile") or {}
        except APIError as e:
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return
        if fmt in ("json", "yaml"):
            output(data, fmt=fmt, raw=raw, fields=fields)
            return
        click.echo("\n".join(profile_lines(data)))
