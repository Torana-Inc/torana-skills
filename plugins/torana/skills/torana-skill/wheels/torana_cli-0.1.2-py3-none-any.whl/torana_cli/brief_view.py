"""`torana alert <id> brief`: fetch, write, check and print an AI item brief.

Spec: pantheon-fe/docs/AI_HOME_V2_BRIEF_SPEC.md § 3.4.6. Staleness is checked exactly as the page checks it: the
item's CURRENT proof (GET datalake/proof/alerts/{id}) against the brief's stored record (POST proof/brief/check).
"""
import time

from torana_cli.client.base import APIError

WAIT_INTERVAL_S = 5
WAIT_MAX_S = 600


def _path(ws: str, aid: str, brief_id: str = "") -> str:
    return f"workspaces/{ws}/ai-home/items/{aid}/brief" + (f"/{brief_id}" if brief_id else "")


def alert_workspace(client, aid: str):
    return (client.get(f"alerts/{aid}") or {}).get("workspace_id")


def latest(client, ws: str, aid: str):
    """{latest_ready, in_flight, latest}, or None when the item has no brief."""
    try:
        return client.get(_path(ws, aid))
    except APIError as e:
        if e.status_code == 404 and e.detail == "no brief for this item":
            return None
        raise


def write(client, ws: str, aid: str) -> dict:
    """POST a new brief. A brief already being written is answered with its id, not an error."""
    try:
        return client.post(_path(ws, aid))
    except APIError as e:
        if e.status_code == 409 and isinstance(e.detail, dict) and e.detail.get("brief_id"):
            return {"brief_id": e.detail["brief_id"], "status": "writing", "already": True}
        raise


def wait(client, ws: str, aid: str, brief_id: str) -> dict:
    deadline = time.monotonic() + WAIT_MAX_S
    while True:
        row = client.get(_path(ws, aid, brief_id))
        if row.get("status") != "writing" or time.monotonic() > deadline:
            return row
        time.sleep(WAIT_INTERVAL_S)


def check(client, ws: str, aid: str, got: dict):
    """The staleness of the brief that will be shown, against the item's proof now. {"unknown": reason} when it
    cannot be checked: never presented as current."""
    row = got.get("latest_ready") or got.get("latest") or {}
    if not row.get("brief") or not row.get("proof_built_at"):
        return None
    try:
        rec = client.get(f"datalake/proof/alerts/{aid}")
        return client.post("datalake/proof/brief/check",
                           json={"brief_id": row["id"], "workspace_id": ws, "alert_id": aid, "record": rec})
    except APIError as e:
        return {"unknown": f"HTTP {e.status_code}: {e.detail if isinstance(e.detail, str) else e}"}


def _when(ts) -> str:
    return str(ts or "")[:16].replace("T", " ") + (" UTC" if ts else "")


def lines(got: dict, check, aid: str) -> list:
    row = got.get("latest_ready") or got.get("latest") or {}
    out = []
    flight = got.get("in_flight")
    if flight:
        out.append(f"Writing a new brief {flight['id']} (heartbeat {flight.get('heartbeat_age_s')} s ago)…")
    if row.get("status") == "writing":
        out.append(f"Writing… check again with: torana alert {aid} brief")
        return out
    if row.get("status") == "failed":
        out.append(f"✕ The last brief failed: {row.get('error')}")
        if not row.get("brief"):
            out.append(f"Try again: torana alert {aid} brief --write --wait")
            return out
    v = row.get("validation") or {}
    built = _when(row.get("proof_built_at"))
    out.append(f"Brief {row.get('id')} · written from the proof built at {built} · {row.get('rounds')} round(s)")
    stale, as_of = {}, {}
    if check is None:
        pass
    elif "unknown" in check:
        out.append(f"? Staleness unknown ({check['unknown']}); do not read it as current.")
    else:
        stale = {(x["section"], x["index"]): x for x in check.get("stale") or []}
        as_of = {(x["section"], x["index"]): x for x in check.get("as_of") or []}
        if stale:
            out.append(f"◇ {len(stale)} sentence(s) rest on claims that changed. "
                       f"Rewrite: torana alert {aid} brief --write --wait")
        else:
            out.append(f"No sentence rests on a claim that changed (checked against the proof built at "
                       f"{_when(check.get('checked_against'))}).")
    failing = {(c["section"], c["index"]): c for c in v.get("checks") or [] if not c.get("pass")}
    claims = row.get("claims") or {}
    for sec in (row.get("brief") or {}).get("sections") or []:
        out.append("")
        out.append(sec.get("title") or sec.get("id"))
        for i, s in enumerate(sec.get("sentences") or []):
            key = (sec.get("id"), i)
            text = s["text"]
            if key in as_of:
                text = f"as of {built}: {text}"
            cites = ", ".join(f"{c} ({(claims.get(c) or {}).get('q') or '?'})" for c in s.get("cites") or [])
            out.append(f"  ✦ {text}")
            out.append(f"      [cites: {cites}]")
            if key in stale:
                x = stale[key]
                out.append(f"      ◇ claims changed since written: {', '.join(x['claims'])}"
                           + ("" if x.get("still_grounded") else
                              f" · no longer grounded: {', '.join(x.get('no_longer_grounded') or [])}"))
            if key in failing:
                bad = failing[key].get("ungrounded") or failing[key].get("unknown_cites") or []
                out.append(f"      ✕ not grounded: {', '.join(bad) or 'no citation'}")
    follow = (row.get("brief") or {}).get("followups") or []
    if follow:
        out.append("")
        out.append("Ask next")
        out += [f"  ? {q}" for q in follow]
    out.append("")
    out.append(f"validated: {v.get('passed')}/{v.get('sentences')} sentences grounded ({v.get('validator')})")
    return out
