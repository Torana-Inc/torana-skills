"""Print widget cards from the server's render envelope. This module builds no sentence:
every word it prints arrives in `card` or `health` (pantheon-viz card_wording.py)."""
import sys

import click

from torana_cli.output import output
from torana_cli.supply_health import glyph_for

SECTION_KEYS = ("about", "health", "freshness", "empty", "data")
FAIL_ON = ("stale", "empty", "error")
BATCH_MAX = 100          # pantheon-viz MAX_BATCH_WIDGETS
_PAD = " " * 14          # two spaces + an 11-wide label + one space


def card_state(w: dict) -> str:
    """ok | empty | error. Falls back to `status` when the server sent no card."""
    state = (w.get("card") or {}).get("state")
    return state or {"success": "ok", "no_data": "empty"}.get(w.get("status"), "error")


def is_stale(w: dict) -> bool:
    return w.get("freshness") == "stale"


def is_not_found(w: dict) -> bool:
    return ((w.get("card") or {}).get("empty") or {}).get("kind") == "not_found"


def wants_health(sections, no_health: bool) -> bool:
    """Whether to ask the server for supply health with this render.

    Health is a second service's answer and costs time (one sweep of a large app can take
    longer than rendering it), so it is skipped when the user says --no-health or asks
    only for parts of the card that do not show it.
    """
    if no_health:
        return False
    return not sections or bool({"health", "empty"} & set(sections))


#: Which envelope fields belong to each --section key in --json output.
_SECTION_FIELDS = {
    "about": ("description", "semantic_description"),
    "health": ("health", "health_unavailable"),
    "freshness": ("freshness", "data_as_of", "freshness_detail", "cached_at", "pushed_as_of"),
    "empty": ("supply_diagnosis", "error_message"),
    "data": ("data",),
}


def section_fields(w: dict, sections) -> dict:
    """One widget's envelope cut down to the --section keys asked for (for --json)."""
    keep = ["widget_id", "widget_name", "widget_type", "status", "card"]
    for key in sections:
        keep.extend(_SECTION_FIELDS[key])
    return {k: w.get(k) for k in keep if k in w}


def render_batch(client, widget_ids, *, refresh=False, dashboard_id=None, include_health=True):
    """POST render/widgets in chunks of BATCH_MAX. Returns (widgets, data_age)."""
    widgets, data_age = [], None
    for i in range(0, len(widget_ids), BATCH_MAX):
        body = {"widget_ids": widget_ids[i:i + BATCH_MAX], "refresh": refresh,
                "include_health": include_health}
        if dashboard_id:
            body["dashboard_id"] = dashboard_id
        resp = client.post("render/widgets", json=body)
        widgets.extend(resp.get("widgets") or [])
        data_age = resp.get("data_age") or data_age
    return widgets, data_age


def _row(label: str, first: str, *more) -> None:
    click.echo(f"  {label:<11} {first}")
    for line in more:
        if line:
            click.echo(f"{_PAD}{line}")


def _print_data(w: dict) -> None:
    data, card = w.get("data"), (w.get("card") or {})
    if not isinstance(data, dict):
        return
    if "columns" in data and "rows" in data:
        cols = data.get("columns") or []
        items = [dict(zip(cols, r)) for r in data.get("rows") or []]
        if items:
            # No "total" key: the formatter's "Use --page N" hint cannot print.
            output({"items": items}, fmt="text", columns=[(c, c, None) for c in cols])
        if card.get("table_caption"):
            click.echo(f"  {card['table_caption']}")
    elif "labels" in data and "datasets" in data:
        datasets = data.get("datasets") or []
        series = [(ds.get("label") or f"series{i}") for i, ds in enumerate(datasets)]
        items = []
        for row_i, lab in enumerate(data.get("labels") or []):
            item = {"label": lab}
            for name, ds in zip(series, datasets):
                vals = ds.get("data") or []
                item[name] = vals[row_i] if row_i < len(vals) else None
            items.append(item)
        if items:
            output({"items": items}, fmt="text",
                   columns=[("label", "label", None)] + [(n, n, None) for n in series])
    elif "value" in data:
        shown = data.get("formatted_value")
        if shown is None:
            shown = data.get("value")
        unit = f" {data['unit']}" if data.get("unit") else ""
        click.echo(f"  {shown}{unit}  {data.get('label') or ''}".rstrip())
        if data.get("trend_direction"):
            pct = "" if data.get("trend_percent") is None else f" {data['trend_percent']}%"
            click.echo(f"  {data['trend_direction']}{pct} {data.get('comparison_label') or ''}".rstrip())


def print_card(w: dict, sections=None, show_semantic=False, health_requested=True) -> None:
    """One card. `sections` is the user's --section list (None = every part, screen order).
    A part the user named is printed in full; an unnamed part is printed only when it has
    something to say (a healthy card prints no Health row)."""
    asked = bool(sections)
    want = set(sections or SECTION_KEYS)
    card = w.get("card") or {}
    state = card_state(w)

    title = w.get("widget_name") or w.get("widget_id")
    click.echo(click.style(f"{title}   [{w.get('widget_type')}]", bold=True))

    if "about" in want:
        desc = card.get("description") or w.get("description")
        if desc:
            click.echo(f"  {desc}")
        if (asked or show_semantic) and w.get("semantic_description"):
            click.echo("  How to read this:")
            for line in str(w["semantic_description"]).splitlines():
                click.echo(f"    {line}")

    if "health" in want and health_requested:
        h = w.get("health")
        if h:
            hs = h.get("health_state") or "unknown"
            if asked or hs != "healthy":
                head = f"{glyph_for(hs)} {h.get('health_label') or hs}. {h.get('why') or ''}".rstrip()
                _row("Health", head, f"Owner: {h['owner']}" if h.get("owner") else None)
        elif w.get("health_unavailable"):
            _row("Health", f"? Not available: {w['health_unavailable']}")

    if "freshness" in want:
        lines = []
        if card.get("stale_line"):
            lines.append(f"⚠ {card['stale_line']}")
        if card.get("what_to_do"):
            lines.append(f"What to do: {card['what_to_do']}")
        if card.get("data_age_line"):
            lines.append(card["data_age_line"])
        if card.get("where_to_fix"):
            lines.append(f"Where: {card['where_to_fix'].get('text')}")
        if asked:
            for t in card.get("freshness_tables") or []:
                lines.append(f"- {t.get('text')}" + (" (bottleneck)" if t.get("is_bottleneck") else ""))
            if card.get("query_ran_line"):
                lines.append(card["query_ran_line"])
        if lines:
            _row("Freshness", *lines)

    if "empty" in want and state != "ok":
        label, cue = ("Failed", "✕") if state == "error" else ("Empty", "○")
        e = card.get("empty")
        if e:
            _row(label, f"{cue} {e.get('title')}. {e.get('message')}", e.get("affects"))
        else:
            # § 3.6 rows 1-2: no card from the server. Print its raw reason, add no wording.
            reason = ((w.get("supply_diagnosis") or {}).get("message")
                      or w.get("error_message") or "the server sent no reason")
            _row(label, f"{cue} {w.get('status')}: {reason}", "card wording unavailable")

    if "data" in want and state == "ok":
        _print_data(w)
        if card.get("supply_note"):
            click.echo(f"  Note: {card['supply_note']}")

    click.echo(f"  cli: {card.get('cli') or 'torana widget %s render' % w.get('widget_id')}")
    click.echo()


def summarize(widgets) -> dict:
    states = [card_state(w) for w in widgets]
    return {
        "total": len(widgets),
        "ok": states.count("ok"), "empty": states.count("empty"), "error": states.count("error"),
        "stale": sum(1 for w in widgets if is_stale(w)),
        "unhealthy": sum(1 for w in widgets
                         if (w.get("health") or {}).get("health_state") not in (None, "healthy")),
    }


def summary_line(widgets) -> str:
    s = summarize(widgets)
    noun = "widget" if s["total"] == 1 else "widgets"
    return (f"{s['total']} {noun}: {s['ok']} ok, {s['empty']} empty, {s['error']} failed"
            f" · {s['stale']} stale")


def exit_code_for(widgets, fail_on=(), single=False):
    """(exit code, what matched). A failed render fails with or without --fail-on."""
    s = summarize(widgets)
    matched = []
    if s["error"]:
        matched.append("error")
    if "empty" in fail_on and s["empty"]:
        matched.append("empty")
    if "stale" in fail_on and s["stale"]:
        matched.append("stale")
    if not matched:
        return 0, matched
    if single and widgets and is_not_found(widgets[0]):
        return 3, matched
    return 1, matched


def build_report(definition: dict, widgets, data_age, fail_on=()) -> dict:
    """The --json report of `dashboard <D> render` (detail shape, § 3.4.4)."""
    _, matched = exit_code_for(widgets, fail_on)
    return {
        "dashboard": {"id": definition.get("id"), "name": definition.get("name"),
                      "description": definition.get("description"),
                      "app_id": definition.get("app_id", definition.get("workspace_id")),
                      "data_age": data_age},
        "widgets": widgets,
        "summary": summarize(widgets),
        "failed_on": matched,
    }


def finish(widgets, fail_on=(), single=False) -> None:
    """Call last, after every card (or the JSON) is printed. Exits non-zero when § 3.4.5 says so."""
    code, matched = exit_code_for(widgets, fail_on, single=single)
    if code:
        flags = "".join(f" --fail-on {m}" for m in matched if m != "error")
        click.echo(f"FAILED: {summary_line(widgets)}{' (' + flags.strip() + ')' if flags else ''}",
                   err=True)
        sys.exit(code)
