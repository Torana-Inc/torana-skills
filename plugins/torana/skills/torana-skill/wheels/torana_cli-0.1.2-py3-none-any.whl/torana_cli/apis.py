"""torana apis — workflow framework API catalogue commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 35),
    ("method", "METHOD", 8),
    ("path", "PATH", 40),
    ("state", "STATE", 12),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group()
def apis():
    """Manage workflow framework API catalogue.

    \b
    Examples:
      torana apis list
      torana apis get <UUID>
      torana apis create --file api.yaml
      torana apis activate <UUID>
      torana apis deprecate <UUID>
    """


@apis.command(name="list")
@click.option("--group-id", default=None, help="Filter by API group UUID.")
@click.option("--search", default=None, help="Search by name or path.")
@click.option("--state", default=None,
              type=click.Choice(["active", "deprecated", "draft"], case_sensitive=False),
              help="Filter by state.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def apis_list(ctx, group_id, search, state, page, page_size):
    """List workflow APIs."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if group_id:
        # ⛔ THE BACKEND PARAM IS `api_group_id`, NOT `group_id`. FastAPI silently ignores an
        # unknown query param, so `--group-id` returned the FULL unfiltered set while looking
        # filtered. Measured 2026-08-15: `--group-id <jira>` returned the same 20 rows as
        # every other group; `?api_group_id=<jira>` returns 25 (total 277 unfiltered).
        # ⚠️ Same silent-drop class as #154 (`providers` ignoring `?search=`) — a 200 that is
        # confidently wrong is worse than an error, because nothing tells the caller.
        # ⭐ `apis browse` in THIS FILE (:289) already sends the correct name; only this
        # command was wrong — the same one-of-N-call-sites pattern as the envelope defect.
        params["api_group_id"] = group_id
    if search:
        params["search"] = search
    if state:
        params["state"] = state

    client = _client(ctx)
    try:
        data = client.get("apis/", params=params)
        # ⛔ SAME ENVELOPE DEFECT #28/CLI-55 FIXED FOR `providers`, LEFT LIVE HERE.
        # The endpoint returns {"apis": [...], "total", "page", "size"} — no "items" key,
        # and `data` is a dict not a list, so the old ternary fell to the else branch and
        # coerced items to []. Measured 2026-08-15: a 200 carrying 20 APIs printed
        # "No results." ⚠️ That is worse than an error — it reads as "this platform has no
        # API catalogue", which is the conclusion it produced, and it hides the api_id that
        # `torana gateway <API_ID> <PATH>` needs, making the whole api-gw proxy path look
        # unreachable from the CLI.
        # ⚠️ Keep the "items"/"total" branch: other endpoints DO return that envelope.
        items = data.get("apis", data.get("items", [])) if isinstance(data, dict) else (
            data if isinstance(data, list) else [])
        total = data.get("total", len(items)) if isinstance(data, dict) else len(items)
        result = {"items": items, "total": total,
                  "page": page, "page_size": effective_page_size}
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@apis.command(name="get")
@click.argument("api_id", metavar="API_ID")
@click.pass_context
def apis_get(ctx, api_id):
    """Get details for a specific API."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"apis/{api_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@apis.command(name="create")
@click.option("--name", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def apis_create(ctx, name, input_file):
    """Create a new workflow API."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name

    if not body.get("name"):
        click.echo("ERROR: --name is required.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post("apis/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created API: {data.get('id', 'unknown')}")


@apis.command(name="update")
@click.argument("api_id", metavar="API_ID")
@click.option("--name", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def apis_update(ctx, api_id, name, input_file):
    """Update a workflow API."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"apis/{api_id}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated API: {api_id}")


@apis.command(name="delete")
@click.argument("api_id", metavar="API_ID")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def apis_delete(ctx, api_id, yes):
    """Delete a workflow API."""
    _confirm(f"Delete API {api_id}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"apis/{api_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted API: {api_id}")


@apis.command(name="activate")
@click.argument("api_id", metavar="API_ID")
@click.pass_context
def apis_activate(ctx, api_id):
    """Activate a workflow API."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"apis/{api_id}/activate/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Activated API: {api_id}")


@apis.command(name="deprecate")
@click.argument("api_id", metavar="API_ID")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def apis_deprecate(ctx, api_id, yes):
    """Deprecate a workflow API."""
    _confirm(f"Deprecate API {api_id}?", yes=yes)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"apis/{api_id}/deprecate/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Deprecated API: {api_id}")


@apis.command(name="browse")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--page", "page", type=int, default=1, help="Page number")
@click.option("--size", "size", type=int, default=20, help="Page size")
@click.option("--provider-id", "provider_id", default=None, help="Filter by provider")
@click.option("--service-type-id", "service_type_id", default=None, help="Filter by service type")
@click.option("--api-group-id", "api_group_id", default=None, help="Filter by API group")
@click.option("--status", "status", default=None, help="Filter by status")
@click.option("--authentication-type", "authentication_type", default=None, help="Filter by auth type")
@click.option("--is-public", "is_public", default=None, help="Filter by public availability")
@click.option("--tags", "tags", default=[], help="Filter by tags (any match)")
@click.option("--capabilities", "capabilities", default=[], help="Filter by capabilities (any match)")
@click.option("--search", "search", default=None, help="Search in name and description")
@click.pass_context
def apis_browse(ctx, page, size, provider_id, service_type_id, api_group_id, status, authentication_type, is_public, tags, capabilities, search, page_size, fetch_all):
    """Browse APIs with full details."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "apis/browse"
    params = {}
    if page is not None:
        params["page"] = page
    if size is not None:
        params["size"] = size
    if provider_id is not None:
        params["provider_id"] = provider_id
    if service_type_id is not None:
        params["service_type_id"] = service_type_id
    if api_group_id is not None:
        params["api_group_id"] = api_group_id
    if status is not None:
        params["status"] = status
    if authentication_type is not None:
        params["authentication_type"] = authentication_type
    if is_public is not None:
        params["is_public"] = is_public
    if tags is not None:
        params["tags"] = tags
    if capabilities is not None:
        params["capabilities"] = capabilities
    if search is not None:
        params["search"] = search

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "page": page_num}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@apis.command(name="semantic")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--q", "q", required=True, help="Natural language query (e.g., 'create issue in GitHub')")
@click.option("--limit", "limit", type=int, default=10, help="Maximum number of results")
@click.option("--threshold", "threshold", type=float, default=0.3, help="Minimum similarity threshold")
@click.option("--provider", "provider", default=None, help="Filter by specific provider")
@click.option("--category", "category", default=None, help="Filter by service category")
@click.option("--include-inactive", "include_inactive", type=bool, default=False, help="Include inactive APIs in results")
@click.pass_context
def apis_semantic(ctx, q, limit, threshold, provider, category, include_inactive, page, page_size, fetch_all):
    """Semantic API search."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "apis/search/semantic"
    params = {}
    if q is not None:
        params["q"] = q
    if limit is not None:
        params["limit"] = limit
    if threshold is not None:
        params["threshold"] = threshold
    if provider is not None:
        params["provider"] = provider
    if category is not None:
        params["category"] = category
    if include_inactive is not None:
        params["include_inactive"] = include_inactive
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@apis.command(name="search")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--q", "q", required=True, help="Search query")
@click.option("--provider-types", "provider_types", default=None, help="Filter by provider types")
@click.option("--categories", "categories", default=None, help="Filter by service type categories")
@click.option("--page", "page", type=int, default=1, help="Page number")
@click.option("--size", "size", type=int, default=20, help="Page size")
@click.pass_context
def apis_search(ctx, q, provider_types, categories, page, size, page_size, fetch_all):
    """Search APIs."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "apis/search"
    params = {}
    if q is not None:
        params["q"] = q
    if provider_types is not None:
        params["provider_types"] = provider_types
    if categories is not None:
        params["categories"] = categories
    if page is not None:
        params["page"] = page
    if size is not None:
        params["size"] = size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "page": page_num}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@apis.command(name="openapi-spec")
@click.argument("API_ID", metavar="API_ID")
@click.pass_context
def apis_openapi_spec(ctx, api_id):
    """Get API OpenAPI specification."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"apis/{api_id}/openapi-spec"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@apis.command(name="health-check")
@click.argument("API_ID", metavar="API_ID")
@click.pass_context
def apis_health_check(ctx, api_id):
    """Perform health check for an API."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"apis/{api_id}/health-check"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@apis.command(name="log-usage")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with request body. Use '-' for stdin.")
@click.argument("API_ID", metavar="API_ID")
@click.option("--operation", "operation", required=True, help="Operation/endpoint used")
@click.option("--method", "method", required=True, help="HTTP method")
@click.option("--status-code", "status_code", default=None, help="Response status code")
@click.option("--response-time-ms", "response_time_ms", default=None, help="Response time in milliseconds")
@click.option("--request-size", "request_size", default=None, help="Request size in bytes")
@click.option("--response-size", "response_size", default=None, help="Response size in bytes")
@click.option("--user-agent", "user_agent", default=None, help="User agent")
@click.option("--ip-address", "ip_address", default=None, help="IP address")
@click.option("--used-by", "used_by", required=True, help="Service/user that used the API")
@click.pass_context
def apis_log_usage(ctx, api_id, operation, method, status_code, response_time_ms, request_size, response_size, user_agent, ip_address, used_by, input_file):
    """Log API usage."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"apis/{api_id}/log-usage"
    if input_file:
        body = _load_input_file(input_file)
    else:
        body = {}
        body["operation"] = operation
        body["method"] = method
        if status_code is not None:
            body["status_code"] = status_code
        if response_time_ms is not None:
            body["response_time_ms"] = response_time_ms
        if request_size is not None:
            body["request_size"] = request_size
        if response_size is not None:
            body["response_size"] = response_size
        if user_agent is not None:
            body["user_agent"] = user_agent
        if ip_address is not None:
            body["ip_address"] = ip_address
        body["used_by"] = used_by

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@apis.command(name="usage-logs")
@click.argument("API_ID", metavar="API_ID")
@click.option("--page", "page", type=int, default=1, help="Page number")
@click.option("--size", "size", type=int, default=50, help="Page size")
@click.option("--used-by", "used_by", default=None, help="Filter by user/service")
@click.option("--operation", "operation", default=None, help="Filter by operation")
@click.pass_context
def apis_usage_logs(ctx, api_id, page, size, used_by, operation):
    """Get API usage logs."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"apis/{api_id}/usage-logs"
    params = {}
    if page is not None:
        params["page"] = page
    if size is not None:
        params["size"] = size
    if used_by is not None:
        params["used_by"] = used_by
    if operation is not None:
        params["operation"] = operation

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@apis.command(name="tags")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def apis_tags(ctx, page, page_size, fetch_all):
    """Get all API tags."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "apis/tags/list"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@apis.command(name="capabilities")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def apis_capabilities(ctx, page, page_size, fetch_all):
    """Get all API capabilities."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "apis/capabilities/list"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)
