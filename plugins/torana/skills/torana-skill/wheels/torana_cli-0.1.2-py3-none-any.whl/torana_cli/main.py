"""
Root Click group for the Torana CLI.

Registers all sub-command groups and handles global flags:
  --format / -o     Output format: text | json | yaml | table
  --json            Shorthand for --format json
  --yaml            Shorthand for --format yaml
  --raw             Bare items array (no pagination envelope) — JSON only
  --profile         Config profile to use
  --log-level       Log verbosity: debug | info | warn | error
"""

import os
import re

import click

from torana_cli import __version__
from torana_cli.config.settings import invalidate_settings
from torana_cli.log.logger import configure_logging


# ── Context key constants (shared between commands) ───────────────────────────
CTX_FORMAT = "format"
CTX_RAW = "raw"
CTX_FIELDS = "fields"
CTX_PROFILE = "profile"
CTX_DRY_RUN = "dry_run"
CTX_ACT_AS_TENANT = "act_as_tenant"
CTX_ACT_AS_REASON = "act_as_reason"
CTX_ACT_AS_ALL_TENANTS = "act_as_all_tenants"


CONTEXT_SETTINGS = dict(help_option_names=["--help", "-h"], max_content_width=120)

# Flags that users commonly place after the subcommand (e.g. `torana rules list --json`).
# Stripping them here lets the root group process them even when typed at the end.
_TRAILING_FLAGS = {
    "--json", "--yaml", "--raw",
    "--format", "-o",
    "--fields",
}


class _ToranaGroup(click.Group):
    """Root Click group that accepts global output flags anywhere on the command line.

    Click normally only parses root-group options before the first subcommand
    word.  Users naturally type `torana sdg dataset get foo --json`, putting
    --json after the leaf command, where Click sees it as an unknown option on
    that leaf and raises an error.

    This subclass rewrites `args` before Click processes them: it scans the
    full argument list, lifts any recognised global output flags out, prepends
    them to `args` so the root group sees them, and leaves the remaining args
    unchanged for subcommand dispatch.
    """

    def make_context(self, info_name, args, **kwargs):
        # Hoist trailing global flags to the front so the root group picks them up.
        front, rest = [], []
        skip_next = False
        for i, arg in enumerate(args):
            if skip_next:
                front.append(arg)   # value that follows --format / --fields / -o
                skip_next = False
                continue
            if arg in _TRAILING_FLAGS:
                front.append(arg)
                # --format, --fields, and -o take a value argument
                if arg in ("--format", "--fields", "-o"):
                    skip_next = True
            else:
                rest.append(arg)
        args = front + rest
        return super().make_context(info_name, args, **kwargs)

    def invoke(self, ctx):
        """A bare group at ANY depth prints its help and exits 0 (platform #752).

        CLI discoverability contract, rule 4: a bare group prints help, exits 0 and makes no
        network call. Click >= 8.2 raises `NoArgsIsHelpError` (exit 2, a usage error) for a
        plain group run with no arguments; Click 8.1 printed help and exited 0. Every group
        is a subgroup of this root, and the error propagates up through its invoke, so this
        ONE catch makes the behaviour independent of the Click version and of which class a
        given group was declared with. Help is printed before any command body runs, so no
        request is made. A bare group inside a bare-invocation error elsewhere is
        unaffected: only the no-args-is-help case is caught.
        """
        no_args_help = getattr(click.exceptions, "NoArgsIsHelpError", None)
        try:
            return super().invoke(ctx)
        except Exception as exc:  # noqa: BLE001 - narrowed immediately below
            if no_args_help is not None and isinstance(exc, no_args_help):
                click.echo(exc.ctx.get_help(), color=exc.ctx.color)
                exc.ctx.exit(0)
            raise


class CollectionGroup(click.Group):
    """A plural `torana <resources>` group that redirects instance verbs to the singular form.

    The CLI splits every resource into a plural collection group (`list`, `create`) and a
    singular instance group (`torana rule <ID> get|execute|…`) — see the hierarchy rule in
    CLAUDE.md. The split is correct, but undiscoverable at the point of failure: typing
    `torana rules execute` produced a bare

        Error: No such command 'execute'.

    which names no alternative, so the user concludes the verb doesn't exist (FT-16). The
    plural group's docstring documents the redirect, but only `--help` shows it.

    This subclass keeps the plural/singular split intact and fixes only the error message:
    when the unknown command is a known instance verb, it names the singular form to use.
    Set `singular=` to the singular command name (e.g. "rule").
    """

    #: Verbs that are instance-scoped by convention and therefore live in the singular group.
    INSTANCE_VERBS = frozenset({
        "get", "update", "delete", "execute", "activate", "deactivate",
        "publish", "archive", "status", "assign", "show", "run", "cancel",
        "enable", "disable", "invoke", "history", "logs",
    })

    def __init__(self, *args, singular=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.singular = singular

    def resolve_command(self, ctx, args):
        try:
            return super().resolve_command(ctx, args)
        except click.UsageError:
            verb = args[0] if args else ""
            singular = self.singular or (self.name or "").rstrip("s")
            if verb in self.INSTANCE_VERBS and singular:
                ctx.fail(
                    f"No such command '{verb}'.\n\n"
                    f"'{verb}' operates on ONE {singular}, so it lives on the singular form:\n"
                    f"    torana {singular} <ID> {verb}\n\n"
                    f"`torana {self.name}` holds collection commands only "
                    f"(see `torana {self.name} --help`)."
                )
            raise


_UUID_RE = re.compile(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")


class InstanceGuard:
    """Mixin for an instance group (`torana alert <ID> <verb>`): a verb typed where the ID goes fails loudly.

    Instance groups take the ID first and the verb second. Two natural slips used to go wrong:

        torana alert get <uuid>     -> "No such command '<uuid>'" (names nothing to try)
        torana workspace home       -> `home` was taken as the workspace ID; help printed, exit 0

    When the first word after the group is one of the group's own commands, it is a verb in the ID slot.
    The group then exits 2 and names the right order. The check is on the group's own command names, not on the
    shape of the ID: some instance groups take names, keys or numbers, not UUIDs, so a UUID-only rule would refuse
    valid input.
    """

    def parse_args(self, ctx, args):
        first = args[0] if args else ""
        if first and not first.startswith("-") and first in self.commands:
            path = ctx.command_path
            idname = next((p.name for p in self.params if isinstance(p, click.Argument)), "id").upper()
            if len(args) > 1 and _UUID_RE.match(args[1]):
                ctx.fail(f"'{first}' is a command, and the ID goes before it.\n\n"
                         f"Did you mean `{path} {args[1]} {first}`?")
            ctx.fail(f"'{first}' is a command name, not a {idname}.\n\n"
                     f"The ID goes first: `{path} <{idname}> {first}`. See `{path} --help`.")
        return super().parse_args(ctx, args)


def _guard_instance_groups(group):
    """Give every instance group (an argument-taking group that can run bare) the InstanceGuard check."""
    for cmd in list(group.commands.values()):
        if not isinstance(cmd, click.Group):
            continue
        takes_id = any(isinstance(p, click.Argument) and p.required for p in cmd.params)
        if takes_id and not isinstance(cmd, InstanceGuard):
            cmd.__class__ = type("Instance" + type(cmd).__name__, (InstanceGuard, type(cmd)), {})
        _guard_instance_groups(cmd)


@click.group(cls=_ToranaGroup, context_settings=CONTEXT_SETTINGS)
@click.version_option(version=__version__, prog_name="torana")
@click.option(
    "--format",
    "-o",
    "fmt",
    default=None,
    type=click.Choice(["text", "json", "yaml", "table"], case_sensitive=False),
    help="Output format (default: text). Overrides config file.",
)
@click.option(
    "--json",
    "use_json",
    is_flag=True,
    default=False,
    help="Shorthand for --format json.",
)
@click.option(
    "--yaml",
    "use_yaml",
    is_flag=True,
    default=False,
    help="Shorthand for --format yaml.",
)
@click.option(
    "--raw",
    is_flag=True,
    default=False,
    help="For list commands: output bare array (no pagination envelope). JSON only.",
)
@click.option(
    "--fields",
    default=None,
    metavar="FIELDS",
    help="Comma-separated fields to include (e.g. id,name,severity).",
)
@click.option(
    "--profile",
    default=None,
    metavar="PROFILE",
    help="Config profile to use (overrides TORANA_PROFILE env var).",
)
@click.option(
    "--log-level",
    default=None,
    type=click.Choice(["debug", "info", "warn", "error"], case_sensitive=False),
    help="Log verbosity for this invocation.",
)
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="Print what would be sent/changed without making any API calls.",
)
@click.option(
    "--act-as-tenant",
    "act_as_tenant",
    default=None,
    metavar="TENANT_ID",
    envvar="TORANA_ACT_AS_TENANT",
    help="SA only: declare that this command CHANGES another tenant's data (needs --act-as-reason). "
         "A super-admin write to another tenant is refused (403 act_as_required) without it, and is "
         "recorded in the security log with it.",
)
@click.option(
    "--act-as-reason",
    "act_as_reason",
    default=None,
    metavar="TEXT",
    envvar="TORANA_ACT_AS_REASON",
    help="Why you are changing another tenant's data (stored in the security log, max 500 chars).",
)
@click.option(
    "--act-as-all-tenants",
    "act_as_all_tenants",
    is_flag=True,
    default=False,
    envvar="TORANA_ACT_AS_ALL_TENANTS",
    help="SA only: declare that this command CHANGES EVERY tenant (needs --act-as-reason; not with "
         "--act-as-tenant). An all-tenants write is refused (403 act_as_all_tenants_required) without it.",
)
@click.pass_context
def cli(ctx, fmt, use_json, use_yaml, raw, fields, profile, log_level, dry_run, act_as_tenant, act_as_reason,
        act_as_all_tenants):
    """
    Torana Security Platform CLI

    Manage detection rules, alerts, workspaces, agents, integrations, and more.

    \b
    Start here (the four customer surfaces):
      Inbox       torana alerts list                       what needs you
                  torana alert <ID> view                  one item, section by section
                  torana alerts cve <CVE> | cwe <CWE>      one CVE or CWE across the app
      Home        torana app <ID> ai-home get              the Home page of an app, card by card
                  torana app <ID> ai-home status           is it current, refreshing or failed
      Chat        torana chats start --app-id <ID> -m "…"  when you want the app's assistant: ask it, wait for the reply
                  torana chat <CHAT_ID> answer --option 1  answer the question it is waiting on
      Dashboards  torana dashboards list --app-id <APP_ID>   the dashboards of an app
                  torana dashboard <ID> render               one dashboard, card by card, as the screen shows it
                  torana app <APP_ID> widgets list           every widget of an app: health, stale, empty
    The operator and admin groups follow in the command list below.

    \b
    Quick start:
      torana auth login --email <your-email> --password '<your-password>'
      torana rules list
      torana workspaces list --format json

    \b
    Discover commands:
      torana --help
      torana rules --help
      torana rules create --help

    \b
    Output formats:
      torana rules list --format table
      torana rules list --json | jq '.items[].name'
      torana rules list --json --raw | jq '.[].name'
    """
    ctx.ensure_object(dict)

    # Profile override triggers settings reload. Export it to TORANA_PROFILE so
    # every downstream resolver (settings + per-profile token cache) that reads
    # the active profile without an explicit arg sees the override consistently.
    if profile:
        os.environ["TORANA_PROFILE"] = profile
        invalidate_settings()

    # Resolve output format
    resolved_fmt = fmt
    if use_json:
        resolved_fmt = "json"
    elif use_yaml:
        resolved_fmt = "yaml"

    if resolved_fmt is None:
        # Fall back to config file default
        from torana_cli.config.settings import get_settings
        settings = get_settings(profile)
        resolved_fmt = settings.format

    ctx.obj[CTX_FORMAT] = resolved_fmt
    ctx.obj[CTX_RAW] = raw
    ctx.obj[CTX_FIELDS] = fields
    ctx.obj[CTX_PROFILE] = profile
    ctx.obj[CTX_DRY_RUN] = dry_run
    # I-95: an all-tenants write declares itself separately; it is never combined with a single tenant.
    has_reason = bool(act_as_reason and act_as_reason.strip())
    if act_as_all_tenants:
        if act_as_tenant:
            raise click.UsageError("--act-as-all-tenants and --act-as-tenant are exclusive: a command changes ONE "
                                   "other tenant or EVERY tenant, not both.")
        if not has_reason:
            raise click.UsageError("--act-as-all-tenants needs --act-as-reason: say why you are changing every "
                                   "tenant (e.g. --act-as-all-tenants --act-as-reason \"backfill INC-7\").")
    # I-65: a super admin's write to another tenant must declare it. Both halves or neither.
    elif bool(act_as_tenant) != has_reason:
        raise click.UsageError("--act-as-tenant and --act-as-reason go together: name the tenant you are "
                               "changing AND why (e.g. --act-as-tenant <id> --act-as-reason \"fix INC-42\").")
    ctx.obj[CTX_ACT_AS_TENANT] = act_as_tenant.strip() if act_as_tenant else None
    ctx.obj[CTX_ACT_AS_REASON] = act_as_reason.strip() if act_as_reason else None
    ctx.obj[CTX_ACT_AS_ALL_TENANTS] = bool(act_as_all_tenants)

    # Configure logging (uses config defaults if not overridden)
    from torana_cli.config.settings import get_settings
    settings = get_settings(profile)
    configure_logging(
        log_level=log_level or settings.log_level,
        log_format=settings.log_format,
        log_file=settings.log_file,
    )


# ── Sub-command registration ───────────────────────────────────────────────────

def _register_commands():
    """Lazily import and attach all command groups."""
    from torana_cli.auth import auth
    from torana_cli.version_cmd import version
    from torana_cli.completion import completion
    from torana_cli.config_cmd import config
    from torana_cli.rules import rules, rule_execution_logs
    from torana_cli.rule import rule
    from torana_cli.alerts import alerts, activities
    from torana_cli.alert import alert
    from torana_cli.remediations import remediations
    from torana_cli.remediation import remediation
    from torana_cli.remediation_plans import remediation_plans
    from torana_cli.remediation_plan import remediation_plan
    from torana_cli.fix_impact import fix_impact
    from torana_cli.pentest import pentest
    from torana_cli.controls import controls
    from torana_cli.control import control
    from torana_cli.workspaces import workspaces
    from torana_cli.workspace import workspace
    from torana_cli.workspace_templates import workspace_templates
    from torana_cli.workspace_template import workspace_template
    from torana_cli.build_v2 import build_v2, register_workspace_build_v2
    register_workspace_build_v2(workspace)  # attach `workspace <id> build-v2 …` (Spec A § 3.4.3)
    # VM semantic parent group. Owned/created by Spec A (Content Library & Install);
    # Specs B (transformers) and C (policy) attach their subgroups via
    # torana_cli.vm.register_vm_subgroup(...) — see torana_cli/vm.py. Registering the
    # capability modules below (once they exist) runs their register_vm_subgroup() as an
    # import side effect; the `vm` group itself is added exactly once here.
    from torana_cli.vm import vm
    # Spec C — attaches `vm policy` onto `vm` via register_vm_subgroup() on import.
    import torana_cli.vm_policy  # noqa: F401  (import side effect)
    # Spec B — attaches `vm transformers` onto `vm` via register_vm_subgroup() on import.
    import torana_cli.vm_transformers  # noqa: F401  (import side effect)
    # Spec G — attaches `vm properties` onto `vm` via register_vm_subgroup() on import.
    import torana_cli.vm_properties  # noqa: F401  (import side effect)
    from torana_cli.agents import agents
    from torana_cli.agent import agent
    from torana_cli.chats import chats
    from torana_cli.chat import chat
    from torana_cli.prompts import prompts
    from torana_cli.prompt import prompt
    from torana_cli.skills import skills
    from torana_cli.agent_tools import agent_tools
    from torana_cli.integrations import integrations, providers, etl, etl_sa
    from torana_cli.integrations_knowledge_consent import knowledge_consent
    from torana_cli.integration import integration
    from torana_cli.webhooks import webhooks
    from torana_cli.deployments import deployments
    from torana_cli.deployment import deployment
    from torana_cli.ingest import ingest
    from torana_cli.entity_graph import entity_graph
    from torana_cli.derived_state import derived_state
    from torana_cli.govern import govern
    from torana_cli.repositories import repositories
    from torana_cli.repository import repository
    from torana_cli.vulnerabilities import vulnerabilities
    from torana_cli.vulnerability import vulnerability
    from torana_cli.advisor import advisor
    from torana_cli.workflows import workflows, detection_workflows
    from torana_cli.workflow import workflow
    from torana_cli.playbooks import playbooks
    from torana_cli.playbook import playbook
    from torana_cli.schedulers import schedulers
    from torana_cli.scheduler import scheduler
    from torana_cli.programs import programs, advisor_admin
    from torana_cli.plans import plans
    from torana_cli.plan import plan
    from torana_cli.templates import templates
    from torana_cli.template import template
    # Transformers live under `torana datalake transformers` / `datalake transformer <ID>`
    # — transformer output tables ARE datalake tables, so they belong in the same
    # namespace as `datalake tables`, `drop-all`, and `clear-all`. Only the
    # non-table-scoped groups stay top-level.
    from torana_cli.transformers import sql_templates, transformer_executions
    from torana_cli.datalake import datalake
    from torana_cli.decorations import decorations
    from torana_cli.pipeline import pipeline
    from torana_cli.admin import admin
    from torana_cli.bootstrap import bootstrap
    from torana_cli.gateway import gateway
    from torana_cli.tenants import tenants
    from torana_cli.users import users
    from torana_cli.roles import roles, permissions
    from torana_cli.namespaces import namespaces
    from torana_cli.tokens import tokens
    from torana_cli.audit_logs import audit_logs
    from torana_cli.context_lake import context_lake
    from torana_cli.atlas import atlas
    from torana_cli.atlas_knowledge import (
        atlas_answer, atlas_ask, atlas_context, atlas_facts, atlas_map, atlas_reachability, atlas_skill,
    )
    from torana_cli.atlas_code import atlas_code
    from torana_cli.atlas_provenance import atlas_provenance
    from torana_cli.atlas_profiles import atlas_kinds, atlas_policy, atlas_profiles
    from torana_cli.atlas_node import node as atlas_node, run as atlas_run
    from torana_cli.atlas_node import exclusion as atlas_exclusion, enrolment as atlas_enrolment
    from torana_cli.suites import suites, suite_execution_logs, active_dashboards
    from torana_cli.suite import suite
    from torana_cli.dashboards import dashboards
    from torana_cli.dashboard import dashboard
    from torana_cli.widgets import widgets
    from torana_cli.widget import widget
    from torana_cli.alert_routes import alert_routes
    from torana_cli.alert_route import alert_route
    from torana_cli.queries import queries
    from torana_cli.query import query
    from torana_cli.apis import apis
    from torana_cli.api_groups import api_groups
    from torana_cli.wf_providers import wf_providers
    from torana_cli.service_types import service_types
    from torana_cli.ui_components import ui_components
    from torana_cli.transformer_tables import transformer_tables
    from torana_cli.service import service
    from torana_cli.sdg import sdg
    from torana_cli.search import search
    from torana_cli.rag import rag
    from torana_cli.events import events

    cli.add_command(auth)
    cli.add_command(version)
    cli.add_command(completion)
    cli.add_command(config)
    cli.add_command(rules)
    cli.add_command(rule)
    cli.add_command(rule_execution_logs)
    cli.add_command(alerts)
    cli.add_command(alert)
    cli.add_command(remediations)
    cli.add_command(remediation)
    cli.add_command(remediation_plans)
    cli.add_command(remediation_plan)
    cli.add_command(fix_impact)
    cli.add_command(pentest)
    cli.add_command(controls)  # T10 — compensating controls (collection)
    cli.add_command(control)   # T10 — one control by id (instance)
    cli.add_command(activities)
    cli.add_command(workspaces)
    cli.add_command(workspace)
    # The product calls a workspace an app. `apps` / `app <APP_ID>` are the names customers use; the
    # `workspace` names above are removed by the app-rename pass (HOME_SURFACE_SPEC § 3.4.9).
    cli.add_command(workspaces, name="apps")
    cli.add_command(workspace, name="app")
    cli.add_command(workspace_templates)
    cli.add_command(workspace_template)
    cli.add_command(build_v2)  # build_v2 cooking subsystem (Spec A)
    cli.add_command(vm)  # VM semantic parent (Spec A owns; B/C attach subgroups) — torana_cli/vm.py
    cli.add_command(agents)
    cli.add_command(agent)
    cli.add_command(chats)
    cli.add_command(chat)
    cli.add_command(prompts)
    cli.add_command(prompt)
    cli.add_command(skills)
    cli.add_command(agent_tools)
    integrations.add_command(knowledge_consent)
    cli.add_command(integrations)
    cli.add_command(integration)
    cli.add_command(webhooks)
    cli.add_command(deployments)
    cli.add_command(deployment)
    cli.add_command(providers)
    cli.add_command(etl)
    cli.add_command(etl_sa)
    cli.add_command(ingest)
    cli.add_command(entity_graph)
    cli.add_command(derived_state)
    cli.add_command(govern)
    cli.add_command(repositories)
    cli.add_command(repository)
    cli.add_command(vulnerabilities)
    cli.add_command(vulnerability)
    cli.add_command(advisor)
    cli.add_command(workflows)
    cli.add_command(workflow)
    cli.add_command(detection_workflows)
    cli.add_command(playbooks)
    cli.add_command(playbook)
    cli.add_command(schedulers)
    cli.add_command(scheduler)
    cli.add_command(programs)
    cli.add_command(advisor_admin)
    cli.add_command(plans)
    cli.add_command(plan)
    cli.add_command(templates)
    cli.add_command(template)
    cli.add_command(sql_templates)
    cli.add_command(transformer_executions)
    cli.add_command(datalake)
    cli.add_command(decorations)
    cli.add_command(pipeline)
    cli.add_command(admin)
    cli.add_command(bootstrap)
    cli.add_command(gateway)
    cli.add_command(tenants)
    cli.add_command(users)
    cli.add_command(roles)
    cli.add_command(permissions)
    cli.add_command(namespaces)
    cli.add_command(tokens)
    cli.add_command(audit_logs)
    cli.add_command(context_lake)
    # Atlas: collection group (atlas.py) + its instance groups (atlas_node.py) nested under it.
    for _atlas_instance in (atlas_node, atlas_run, atlas_exclusion, atlas_enrolment,
                            atlas_profiles, atlas_policy, atlas_kinds,
                            atlas_context, atlas_ask, atlas_answer, atlas_skill, atlas_facts, atlas_map,
                            atlas_reachability, atlas_code, atlas_provenance):
        atlas.add_command(_atlas_instance)
    cli.add_command(atlas)
    cli.add_command(suites)
    cli.add_command(suite)
    cli.add_command(suite_execution_logs)
    cli.add_command(active_dashboards)
    cli.add_command(dashboards)
    cli.add_command(dashboard)
    cli.add_command(widgets)
    cli.add_command(widget)
    cli.add_command(alert_routes)
    cli.add_command(alert_route)
    cli.add_command(queries)
    cli.add_command(query)
    cli.add_command(apis)
    cli.add_command(api_groups)
    cli.add_command(wf_providers)
    cli.add_command(service_types)
    cli.add_command(ui_components)
    cli.add_command(transformer_tables)
    cli.add_command(service)
    cli.add_command(sdg)
    cli.add_command(search)
    cli.add_command(rag)
    cli.add_command(events)


_register_commands()
_guard_instance_groups(cli)


if __name__ == "__main__":
    cli()
