"""torana search — semantic artifact search commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output

_ARTIFACT_COLS = [
    ("id", "ID", 36),
    ("artifact_type", "TYPE", 20),
    ("name", "NAME", 40),
    ("workspace_id", "WORKSPACE_ID", 36),
    ("score", "SCORE", 6),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group()
def search():
    """Semantic search across platform artifacts.

    \b
    Examples:
      torana search artifacts --query "open vulnerabilities" --types rule,widget
      torana search artifacts --query "patch cycle" --workspace-id <UUID> --json --raw
    """


@search.command(name="artifacts")
@click.option("--query", "query", required=True, help="Natural language search query.")
@click.option("--types", "artifact_types", default=None,
              help="Comma-separated artifact types to filter: dashboard,rule,widget,query,transformer,playbook,scheduler,workspace,program.")
@click.option("--workspace-id", "workspace_id", default=None, help="Scope to a specific workspace UUID.")
@click.option("--top-k", "top_k", default=10, type=int, show_default=True, help="Number of results (max 50).")
@click.option("--min-score", "min_score", default=0.7, type=float, show_default=True,
              help="Minimum cosine similarity score (0.0–1.0).")
@click.pass_context
def search_artifacts(ctx, query, artifact_types, workspace_id, top_k, min_score):
    """Semantic search across all platform artifacts for this tenant.

    \b
    Examples:
      torana search artifacts --query "patch management"
      torana search artifacts --query "high severity" --types rule --top-k 5 --json --raw
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = {
        "query": query,
        "top_k": min(top_k, 50),
        "min_score": min_score,
    }
    if artifact_types:
        body["artifact_types"] = [t.strip() for t in artifact_types.split(",") if t.strip()]
    if workspace_id:
        body["workspace_id"] = workspace_id

    client = _client(ctx)
    try:
        data = client.post("artifacts/search", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Normalise to list envelope so --raw works
    items = data.get("results", data if isinstance(data, list) else [])
    result = {"items": items, "total": len(items), "page": 1, "page_size": len(items)}
    output(result, fmt=fmt, raw=raw, fields=fields, columns=_ARTIFACT_COLS)
