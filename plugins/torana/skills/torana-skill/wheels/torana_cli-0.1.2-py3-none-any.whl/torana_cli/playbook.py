"""torana playbook <PLAYBOOK_ID> — per-playbook instance commands."""

import json
import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm
from torana_cli.playbook_actions_view import (
    ACTION_COLUMNS, PREVIEW_COLUMNS, RUN_COLUMNS, action_rows, echo_warnings, handle_playbook_error, run_rows)


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _pbid(ctx) -> str:
    return ctx.obj.get("_playbook_id", "") if ctx.obj else ""


#: Sibling fields `PlaybookExecuteRequest` accepts ALONGSIDE `input_values`
#: (pantheon-workflow-framework/src/pantheon_workflow/schemas/playbook.py).
#:
#: ⛔ THIS LIST IS WHY THE FIX IS NOT `{"input_values": body}`. A naive wrap would bury
#: a caller's `agent_name` / `alert_context` / `async_execution` INSIDE input_values,
#: where the API would silently ignore them — turning a 422 (loud, fixable) into a
#: request that succeeds while dropping the caller's intent. That trade is strictly
#: worse than the bug being fixed.
_EXECUTE_SIBLING_FIELDS = frozenset({
    "input_values", "triggered_by", "agent_name", "agent_id",
    "agent_override", "alert_context", "async_execution",
    "run_key", "dispatch_attempt",                    # OI-188 b
})


def _wrap_input_values(body: dict) -> dict:
    """Accept BOTH the documented shape and the API's wire shape (CLI-46).

    The API requires `{"input_values": {...}}`, but `--help` documents — and every user
    reasonably writes — the bare `{"alert_id": "..."}`. That bare form returned
    `HTTP 422 body → input_values: Field required`, so **a user following the CLI's own
    help text could not execute a playbook at all**, while the working form required
    knowing an internal wrapper name that appears nowhere in the help.

    ⭐ ACCEPT BOTH, rather than rewriting the help to teach the wrapper. The row offers
    either remedy; accepting both is the one that cannot break a caller who already
    learned the wrapped form (scripts in the wild use it — it is the only form that
    has ever worked).

    Rules, in order:
      1. empty body            -> `{"input_values": {}}`, so the required field is always
                                  present and an argument-less execute stops 422-ing.
      2. already has the key   -> passed through UNTOUCHED (idempotent; never double-wrap).
      3. only sibling fields   -> add an empty `input_values`; the caller supplied options
                                  but no parameters, which is legal.
      4. anything else         -> the bare form: user keys go into `input_values`, and any
                                  sibling keys are LIFTED OUT and kept at the top level.

    ⚠️ Rule 4's lift is the load-bearing detail — see `_EXECUTE_SIBLING_FIELDS`.
    """
    if not isinstance(body, dict) or not body:
        return {"input_values": {}}
    if "input_values" in body:
        return body                                   # already wire-shaped — do not touch
    params = {k: v for k, v in body.items() if k not in _EXECUTE_SIBLING_FIELDS}
    wrapped = {k: v for k, v in body.items() if k in _EXECUTE_SIBLING_FIELDS}
    wrapped["input_values"] = params
    return wrapped


# ---------------------------------------------------------------------------
# Root group — takes PLAYBOOK_ID as positional argument
# ---------------------------------------------------------------------------

@click.group(name="playbook", invoke_without_command=True)
@click.argument("playbook_id", metavar="PLAYBOOK_ID")
@click.pass_context
def playbook(ctx, playbook_id):
    """Manage a single playbook by ID.

    \b
    Examples:
      torana playbook <UUID> get
      torana playbook <UUID> execute --input '{...}'
      torana playbook <UUID> preview-actions --alert-file alert.json
      torana playbook <UUID> publish
      torana playbook <UUID> delete --yes
    """
    ctx.ensure_object(dict)
    ctx.obj["_playbook_id"] = playbook_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


# ---------------------------------------------------------------------------
# Instance commands
# ---------------------------------------------------------------------------

@playbook.command(name="get")
@click.pass_context
def playbook_get(ctx):
    """Get details for this playbook, including its execution mode and declared actions.

    `execution_mode` is server-computed: `agent` (free-text instructions, run by an agent), `declarative` (declared
    notify/ticket actions, run by code with NO model) or `hybrid` (both: the actions first, then the agent).

    \b
    Examples:
      torana playbooks list                    # find the id
      torana playbook <PLAYBOOK_ID> get
      torana playbook <PLAYBOOK_ID> executions # its run history
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"playbooks/{_pbid(ctx)}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text" or fields or not isinstance(data, dict):
        output(data, fmt=fmt, fields=fields)
        return
    output({k: v for k, v in data.items() if k != "actions"}, fmt=fmt)
    click.echo(f"\nExecution mode: {data.get('execution_mode', 'agent')}")
    actions = data.get("actions") or []
    if actions:
        click.echo(f"Actions ({len(actions)}):")
        output(action_rows(actions), fmt="text", columns=ACTION_COLUMNS, pagination_hint=False)
    else:
        click.echo("Actions: none declared (the agent runs the instructions)")


@playbook.command(name="update")
@click.option("--name", default=None)
@click.option("--description", default=None)
@click.option("--input-file", "--file", "input_file", default=None, metavar="FILE",
              help="JSON/YAML body; may carry `actions` (declared notify/ticket actions) and `instructions`.")
@click.pass_context
def playbook_update(ctx, name, description, input_file):
    """Update this playbook.

    `actions` omitted = unchanged; `[]` = remove every declared action (the playbook becomes agent mode, which
    needs instructions of 10+ characters). `"instructions": null` with actions = no free text (declarative).
    Template issues the server finds are printed one per line.

    \b
    Examples:
      torana playbook <PLAYBOOK_ID> update --input-file actions.yaml
      torana playbook <PLAYBOOK_ID> update --description "Page on-call on SLA breach"
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if description:
        body["description"] = description

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"playbooks/{_pbid(ctx)}/", json=body)
    except APIError as e:
        handle_playbook_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated playbook: {_pbid(ctx)}")
        if isinstance(data, dict) and data.get("execution_mode"):
            click.echo(f"  Execution mode: {data['execution_mode']}")
    echo_warnings(data)


@playbook.command(name="delete")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def playbook_delete(ctx, yes):
    """Delete this playbook."""
    _confirm(f"Delete playbook {_pbid(ctx)}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"playbooks/{_pbid(ctx)}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted playbook: {_pbid(ctx)}")


@playbook.command(name="execute")
@click.option("--input", "input_data", default=None, metavar="JSON",
              help="JSON input for the playbook.")
@click.option("--input-file", default=None, metavar="FILE",
              help="Read input from file.")
@click.option("--run-key", default=None, metavar="KEY",
              help="Idempotency key: running again with the same key returns the same execution and never resends "
                   "a delivered action.")
@click.option("--alert-context", "alert_context", default=None, metavar="JSON",
              help="The alert's fields for {{alert_data.*}} in the playbook's text, as JSON. Without it every "
                   "{{alert_data.*}} reads \"(not available)\"; --input values are {{input.*}}.")
@click.pass_context
def playbook_execute(ctx, input_data, input_file, run_key, alert_context):
    """Execute this playbook.

    \b
    Examples:
      torana playbook <UUID> execute --input '{"alert_id": "UUID"}'
      torana playbook <UUID> execute --run-key manual-2026-10-19-1

    \b
    --input accepts BOTH shapes (CLI-46):
      bare     '{"alert_id": "UUID"}'                      <- what this help documents
      wrapped  '{"input_values": {"alert_id": "UUID"}}'    <- the API's wire shape
    Bare keys are placed into input_values for you. Execution options
    (agent_name, agent_id, alert_context, async_execution, triggered_by)
    stay at the top level in either shape.

    \b
    ⚠️ INPUT IS NOT THE ALERT. --input values reach the playbook as {{input.<key>}} only. The alert's own
    fields ({{alert_data.<field>}}: name, severity, ...) come from --alert-context (or a top-level
    "alert_context" in the JSON); without it they render as "(not available)". An alert_id in --input does
    not fetch the alert. Example:
      torana playbook <UUID> execute --input '{"alert_id": "UUID"}' \\
          --alert-context '{"alert_id": "UUID", "alert_name": "...", "severity": "critical"}'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    elif input_data:
        try:
            body = json.loads(input_data)
        except json.JSONDecodeError as exc:
            click.echo(f"ERROR: Invalid JSON in --input: {exc}", err=True)
            import sys
            sys.exit(6)

    body = _wrap_input_values(body)
    if run_key:
        body["run_key"] = run_key
    if alert_context:
        try:
            body["alert_context"] = json.loads(alert_context)
        except json.JSONDecodeError as exc:
            click.echo(f"ERROR: Invalid JSON in --alert-context: {exc}", err=True)
            import sys
            sys.exit(6)
    elif not body.get("alert_context") and (body.get("input_values") or {}).get("alert_id"):
        # ⛔ Said, not silent: the run would render every {{alert_data.*}} as "(not available)".
        click.echo("NOTE: --input carries an alert_id but no alert_context, so the playbook's {{alert_data.*}} fields "
                   "will read \"(not available)\" (an alert_id in --input is {{input.alert_id}} only). Pass "
                   "--alert-context '{...}' to give it the alert's fields.", err=True)

    client = _client(ctx)
    try:
        data = client.post(f"playbooks/{_pbid(ctx)}/execute/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Executed playbook: {_pbid(ctx)}")
        if isinstance(data, dict):
            for k, v in data.items():
                if k not in ("id", "action_runs"):
                    click.echo(f"  {k}: {v}")
            if data.get("action_runs"):
                click.echo("Actions:")
                output(run_rows(data["action_runs"]), fmt="text", columns=RUN_COLUMNS, pagination_hint=False)


@playbook.command(name="publish")
@click.pass_context
def playbook_publish(ctx):
    """Publish this playbook."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"playbooks/{_pbid(ctx)}/publish/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Published playbook: {_pbid(ctx)}")


@playbook.command(name="render")
@click.option("--input", "input_data", default=None, metavar="JSON",
              help="JSON context for rendering.")
@click.pass_context
def playbook_render(ctx, input_data):
    """Render this playbook with context data."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_data:
        try:
            body = json.loads(input_data)
        except json.JSONDecodeError as exc:
            click.echo(f"ERROR: Invalid JSON in --input: {exc}", err=True)
            import sys
            sys.exit(6)

    client = _client(ctx)
    try:
        data = client.post(f"playbooks/{_pbid(ctx)}/render/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt if fmt != "text" else "json")


@playbook.command(name="archive")
@click.pass_context
def playbook_archive(ctx):
    """Archive this playbook."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"playbooks/{_pbid(ctx)}/archive"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@playbook.command(name="executions")
@click.option("--status", "status", default=None, help="Filter by status")
@click.option("--limit", "limit", type=int, default=50, help="Max results")
@click.option("--offset", "offset", type=int, default=0, help="Pagination offset")
@click.pass_context
def playbook_executions(ctx, status, limit, offset):
    """List executions for this playbook."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"playbooks/{_pbid(ctx)}/executions"
    params = {}
    if status is not None:
        params["status"] = status
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@playbook.command(name="move")
@click.option("--target-workspace-id", "target_workspace_id", required=True)
@click.pass_context
def playbook_move(ctx, target_workspace_id):
    """Move this playbook to a different workspace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"playbooks/{_pbid(ctx)}/move"
    body = {}
    body["target_workspace_id"] = target_workspace_id

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@playbook.command(name="preview-actions")
@click.option("--alert-file", default=None, metavar="FILE",
              help="JSON/YAML alert context to render against (the keys detection sends: alert_name, severity, …).")
@click.option("--input", "input_data", default=None, metavar="JSON", help="JSON input values for <<input.x>>.")
@click.pass_context
def playbook_preview_actions(ctx, alert_file, input_data):
    """Render this playbook's declared actions and check where each recipient group resolves. Sends nothing.

    Per action and group: the exact text that would be sent, the variables that would print "(not available)",
    whether the text was truncated, and `resolution` — `resolved`, `unresolved_group` (map the group under
    `torana integration <IID> notification-targets create`) or `integration_deleted`.

    \b
    Examples:
      torana playbook <PLAYBOOK_ID> preview-actions
      torana playbook <PLAYBOOK_ID> preview-actions --alert-file alert.json --input '{"team": "platform"}'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    body = {}
    if alert_file:
        body["alert_context"] = _load_input_file(alert_file)
    if input_data:
        try:
            body["input_values"] = json.loads(input_data)
        except json.JSONDecodeError as exc:
            click.echo(f"ERROR: Invalid JSON in --input: {exc}", err=True)
            import sys
            sys.exit(6)

    client = _client(ctx)
    try:
        data = client.post(f"playbooks/{_pbid(ctx)}/preview-actions", json=body)
    except APIError as e:
        handle_playbook_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt)
        return
    click.echo(f"Execution mode: {data.get('execution_mode', '?')}")
    rows = []
    for it in data.get("items") or []:
        rendered = it.get("rendered") or {}
        text = rendered.get("text") or rendered.get("summary") or ""
        rows.append({"action": it.get("action_key", ""), "target": it.get("target_kind", ""),
                     "group": it.get("recipient_group", ""), "resolution": it.get("resolution", ""),
                     "missing_vars": ", ".join(it.get("missing_vars") or []),
                     "truncated": "yes" if it.get("truncated") else "", "text": " ".join(str(text).split())[:80]})
    if rows:
        output(rows, fmt="text", columns=PREVIEW_COLUMNS, pagination_hint=False)
    else:
        click.echo("No declared actions: an agent-mode playbook has nothing to preview.")
    echo_warnings(data)
