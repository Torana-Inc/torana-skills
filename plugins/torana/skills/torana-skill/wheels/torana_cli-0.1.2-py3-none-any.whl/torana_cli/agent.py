"""torana agent <ID> — instance-scoped agent commands."""

import json
import sys

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.a2a_rpc import (
    M_CANCEL,
    M_GET,
    M_LIST,
    M_SEND,
    rpc_call,
    user_message,
)
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _aid(ctx) -> str:
    return ctx.obj.get("_agent_id", "") if ctx.obj else ""


def _sid(ctx) -> str:
    return ctx.obj.get("_session_id", "") if ctx.obj else ""


@click.group(name="agent", invoke_without_command=True)
@click.argument("agent_id", metavar="AGENT_ID")
@click.pass_context
def agent(ctx, agent_id):
    """Manage a single agent by ID.

    \b
    Examples:
      torana agent <UUID> get
      torana agent <UUID> publish
      torana agent <UUID> activate
      torana agent <UUID> health
      torana agent <UUID> session <SID> load

    \b
    When you want to talk to the app's assistant (not the default way to get an answer), use the chat commands:
      torana chats start --app-id <APP_ID> -m "your question"
      torana chat <CHAT_ID> send -m "follow-up"
    """
    ctx.ensure_object(dict)
    ctx.obj["_agent_id"] = agent_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


# ── Nested session sub-group ────────────────────────────────────────────────

@agent.group(name="session", invoke_without_command=True)
@click.argument("session_id", metavar="SESSION_ID")
@click.pass_context
def agent_session(ctx, session_id):
    """Inspect one session of this agent (for agent developers).

    A session is a chat. To send, read, answer, stop or rename a chat use
    `torana chat <CHAT_ID>`: the chat id is this session id. The commands here
    are the lower-level reads and tools: the stored messages, forks and lineage,
    plans, and the checkpoint chain.

    \b
    Examples:
      torana agent <UUID> session <SID> get
      torana agent <UUID> session <SID> load
      torana agent <UUID> session <SID> lineage
    """
    ctx.ensure_object(dict)
    ctx.obj["_session_id"] = session_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


# ── A2A protocol sub-namespace (agent-scoped) ───────────────────────────────
#
# `torana agent <id> a2a <method>` — the A2A 1.0 protocol surface scoped to this
# agent. Verbs are the bare standard protocol method names (send / get-task /
# cancel / tasks / card) so the CLI reads 1:1 with the A2A spec. Living under the
# `a2a` sub-group means `cancel` etc. never collide with the agent's `stop` or
# `session <sid> cancel` — different namespace, no renames. Wire helpers live in
# torana_cli/client/a2a_rpc.py (single source of truth for the a2a-sdk wire rules).
# See docs/AGUI_AGENTS_REFACTOR.md.

def _fmt3(ctx):
    """Return (fmt, raw, fields) from the shared ctx, defaulting to text."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    return fmt, raw, fields


@agent.group(name="a2a")
@click.pass_context
def agent_a2a(ctx):
    """Drive the A2A 1.0 protocol surface for this agent.

    \b
    Bare standard protocol verbs (read 1:1 with the A2A spec):
      torana agent <ID> a2a card
      torana agent <ID> a2a send "Analyze CVE-2024-1234"
      torana agent <ID> a2a get-task <TASK_ID>
      torana agent <ID> a2a cancel <TASK_ID>
      torana agent <ID> a2a tasks --context <SESSION_ID>

    \b
    Notes:
      - These talk the standard A2A protocol; `cancel` is the A2A CancelTask
        (distinct from `agent <ID> stop` and `agent <ID> session <SID> cancel`).
      - Every call carries the A2A-Version: 1.0 header automatically.
    """


@agent_a2a.command(name="card")
@click.pass_context
def agent_a2a_card(ctx):
    """GET the Agent Card (A2A discovery) for this agent."""
    aid = _aid(ctx)
    fmt, raw, fields = _fmt3(ctx)
    client = _client(ctx)
    try:
        # The card is served at the ROOT well-known path (no /api/v1 prefix) — pass
        # a leading-slash absolute path so the client doesn't prepend /api/v1.
        data = client.get("/.well-known/agent-card.json", params={"agent_id": aid})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@agent_a2a.command(name="send")
@click.argument("text", metavar="TEXT")
@click.option("--context", "context_id", default=None,
              help="contextId (== session_id) to continue a conversation.")
@click.option("--task", "task_id", default=None,
              help="taskId to resume a paused (input-required) task.")
@click.option("--async", "return_immediately", is_flag=True, default=False,
              help="return_immediately: return a working handle without blocking.")
@click.pass_context
def agent_a2a_send(ctx, text, context_id, task_id, return_immediately):
    """SendMessage to this agent over A2A — returns the resulting Task.

    Always returns kind:"task" (always-Task policy). A trivial one-shot returns a
    Task already in TASK_STATE_COMPLETED; a paused turn returns input-required.
    """
    aid = _aid(ctx)
    fmt, raw, fields = _fmt3(ctx)
    params = {"message": user_message(text, context_id, task_id)}
    if return_immediately:
        params["configuration"] = {"returnImmediately": True}
    try:
        data = rpc_call(_client(ctx), aid, M_SEND, params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@agent_a2a.command(name="get-task")
@click.argument("task_id", metavar="TASK_ID")
@click.pass_context
def agent_a2a_get_task(ctx, task_id):
    """GetTask — read a Task back by id (state + message + artifacts)."""
    aid = _aid(ctx)
    fmt, raw, fields = _fmt3(ctx)
    try:
        data = rpc_call(_client(ctx), aid, M_GET, {"id": task_id})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@agent_a2a.command(name="cancel")
@click.argument("task_id", metavar="TASK_ID")
@click.pass_context
def agent_a2a_cancel(ctx, task_id):
    """CancelTask — request cancellation of an in-flight A2A task.

    This is the A2A protocol task-cancel. For session-level cancel use
    `agent <ID> session <SID> cancel`; for execution stop use `agent <ID> stop`.
    """
    aid = _aid(ctx)
    fmt, raw, fields = _fmt3(ctx)
    try:
        data = rpc_call(_client(ctx), aid, M_CANCEL, {"id": task_id})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@agent_a2a.command(name="tasks")
@click.option("--context", "context_id", default=None,
              help="contextId (== session_id) to list tasks for.")
@click.pass_context
def agent_a2a_tasks(ctx, context_id):
    """ListTasks — list this agent's A2A tasks (optionally for one conversation)."""
    aid = _aid(ctx)
    fmt, raw, fields = _fmt3(ctx)
    params = {}
    if context_id:
        params["contextId"] = context_id
    try:
        data = rpc_call(_client(ctx), aid, M_LIST, params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


# ── AG-UI / A2UI protocol sub-namespace (agent-scoped) ──────────────────────
#
# `torana agent <id> agui <verb>` — the AG-UI / A2UI surface scoped to this agent,
# symmetric with `agent <id> a2a <method>` (the A2A surface). A2A = talk to the
# agent; AG-UI = the rich-widget rendering contract. The catalog is the manifest
# of widgets the FE renderer supports; agents reference its component names (by
# name) when emitting A2UI updateComponents envelopes, and the backend rejects any
# name not in it. Customer-facing READ lives here; version/drift diagnostics live
# under `torana admin agui catalog`. See docs/AGUI_AGENTS_REFACTOR.md.

@agent.group(name="agui")
@click.pass_context
def agent_agui(ctx):
    """Inspect the AG-UI / A2UI rendering surface for this agent.

    \b
    AG-UI is the rich-widget protocol (distinct from A2A, which talks to the
    agent). The catalog is the contract of which UI widgets the FE renderer
    supports — agents reference its component names when emitting A2UI envelopes.

    \b
    Examples:
      torana agent <ID> agui catalog
      torana agent <ID> agui catalog --json
    """


@agent_agui.command(name="catalog")
@click.pass_context
def agent_agui_catalog(ctx):
    """Show the active A2UI catalog manifest (the widgets the FE renderer supports).

    \b
    The catalog is FE-owned and served by pantheon-agent-builder. Agents reference
    component names from it when emitting A2UI v0.9 updateComponents envelopes.
    For version/drift diagnostics use `torana admin agui catalog`.
    """
    fmt, raw, fields = _fmt3(ctx)
    client = _client(ctx)
    try:
        data = client.get("agui/catalog")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(
        data,
        fmt=fmt,
        raw=raw,
        fields=fields,
        columns=[
            ("version", "CATALOG VERSION", 16),
            ("catalogId", "CATALOG ID", 50),
            ("specVersion", "A2UI SPEC", 12),
        ],
    )


# ── Lifecycle commands (agent-scoped only) ──────────────────────────────────

@agent.command(name="get")
@click.pass_context
def agent_get(ctx):
    """Get details for a specific agent.

    \b
    Examples:
      torana agents list                      # find the id
      torana agent <AGENT_ID> get
      torana agent <AGENT_ID> get --json | jq '{name, state, model}'

    has_drift / drift_summary cover the source files AND the agent's tool rows
    (a row whose include_operations differs from source). Details:
    torana agent <AGENT_ID> drift
    """
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/", params={"show_drift": "true"})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agent.command(name="update")
@click.option("--name", default=None)
@click.option("--description", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def agent_update(ctx, name, description, input_file):
    """Update an agent."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if description:
        body["description"] = description

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"agents/{aid}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated agent: {aid}")


@agent.command(name="delete")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def agent_delete(ctx, yes):
    """Delete an agent."""
    aid = _aid(ctx)
    _confirm(f"Delete agent {aid}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"agents/{aid}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted agent: {aid}")


@agent.command(name="activate")
@click.pass_context
def agent_activate(ctx):
    """Activate an agent (make it available for chat)."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/activate/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Activated agent: {aid}")


@agent.command(name="deactivate")
@click.pass_context
def agent_deactivate(ctx):
    """Deactivate an agent."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/deactivate/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Deactivated agent: {aid}")


@agent.command(name="publish")
@click.pass_context
def agent_publish(ctx):
    """Publish an agent (make it visible to all users in the tenant)."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/publish/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Published agent: {aid}")


@agent.command(name="unpublish")
@click.pass_context
def agent_unpublish(ctx):
    """Unpublish an agent."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/unpublish/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Unpublished agent: {aid}")


@agent.command(name="new-version")
@click.pass_context
def agent_new_version(ctx):
    """Create a new version of the agent."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/new-version/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created new version of agent: {aid}")


@agent.command(name="versions")
@click.pass_context
def agent_versions(ctx):
    """List versions of an agent."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/versions/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agent.command(name="health")
@click.pass_context
def agent_health(ctx):
    """Check agent health status."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/health/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        if isinstance(data, dict):
            status = data.get("status", data.get("health", "unknown"))
            click.echo(f"Agent {aid}: {status}")
            for k, v in data.items():
                if k not in ("status", "health"):
                    click.echo(f"  {k}: {v}")
        else:
            click.echo(str(data))


# ── Chat & invocation commands ──────────────────────────────────────────────


@agent.command(name="invoke")
@click.option("--messages", required=True, help="JSON-formatted message list or file path.")
@click.option("--config", default=None, metavar="FILE", help="Optional agent config file.")
@click.option("--context", default=None, help="Optional context string.")
@click.pass_context
def agent_invoke(ctx, messages, config, context):
    """Invoke agent directly without session."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    # Parse messages (could be JSON string or file)
    import json
    try:
        if messages.startswith('['):
            msg_list = json.loads(messages)
        else:
            from pathlib import Path
            msg_list = json.loads(Path(messages).read_text())
    except (json.JSONDecodeError, FileNotFoundError) as e:
        click.echo(f"ERROR: Failed to parse messages: {e}", err=True)
        import sys
        sys.exit(2)

    body = {"messages": msg_list}
    if config:
        body["config"] = _load_input_file(config)
    if context:
        body["context"] = context

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/invoke/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent.command(name="invoke-stream")
@click.option("--messages", required=True, help="JSON-formatted message list or file path.")
@click.option("--config", default=None, metavar="FILE", help="Optional agent config file.")
@click.option("--context", default=None, help="Optional context string.")
@click.pass_context
def agent_invoke_stream(ctx, messages, config, context):
    """Invoke agent with streaming response."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    # Parse messages (could be JSON string or file)
    import json
    try:
        if messages.startswith('['):
            msg_list = json.loads(messages)
        else:
            from pathlib import Path
            msg_list = json.loads(Path(messages).read_text())
    except (json.JSONDecodeError, FileNotFoundError) as e:
        click.echo(f"ERROR: Failed to parse messages: {e}", err=True)
        import sys
        sys.exit(2)

    body = {"messages": msg_list}
    if config:
        body["config"] = _load_input_file(config)
    if context:
        body["context"] = context

    client = _client(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    try:
        events = []
        for event in client.post_stream(f"agents/{aid}/invoke/stream/", json=body):
            events.append(event)
            if fmt == "json":
                # Stream each event as a JSON line (jq-friendly).
                click.echo(json.dumps(event, default=str))
            else:
                _render_stream_event(event)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "json" and not events:
        click.echo("(no stream events received)")


def _render_stream_event(event) -> None:
    """Human-readable one-liner per SSE event for `invoke-stream`/chat text mode."""
    if not isinstance(event, dict):
        click.echo(str(event))
        return
    etype = event.get("type") or event.get("event") or ""
    content = event.get("content")
    if etype in ("tool_call_start", "tool_call_end", "tool_status"):
        tool = event.get("tool_name") or (content or {}).get("tool_name") if isinstance(content, dict) else event.get("tool_name")
        click.echo(click.style(f"  [tool] {etype}: {tool or ''}", fg="cyan"))
    elif etype in ("agent_message", "formatted_response", "message", "text"):
        # content may be a str, or a dict with a 'content'/'messages' payload
        text = content if isinstance(content, str) else None
        if isinstance(content, dict):
            text = content.get("content") or content.get("text")
        if text:
            click.echo(text)
    elif etype in ("agent_invocation_start",):
        click.echo(click.style(f"  [delegate] {event.get('agent_name','')}", fg="magenta"))
    elif etype in ("end_stream",):
        pass
    else:
        # unknown event — show compactly so nothing is silently dropped
        click.echo(click.style(f"  [{etype or 'event'}] {json.dumps(event, default=str)[:200]}", fg="yellow"))


@agent.command(name="readiness")
@click.pass_context
def agent_readiness(ctx):
    """Check invoke readiness status."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/invoke/status/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


# ── Tools management (agent-scoped) ─────────────────────────────────────────

@agent.command(name="tools")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", "page_size", default=None, type=int)
@click.option("--no-effective", is_flag=True, default=False,
              help="Skip the effective-operations section (configured rows only).")
@click.pass_context
def agent_tools(ctx, page, page_size, no_effective):
    """List tools attached to an agent, and the operations it can actually call.

    The configured rows say what was DECLARED; the effective list says what the
    model receives. They can differ — an include_operations entry used to match by
    prefix, so `get_alert` silently admitted `get_alert_sightings` too. Anything
    effective but not declared is marked UNDECLARED.
    """
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/tools/", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    effective = None
    if not no_effective:
        # The tool list the LLM actually receives, from the BUILT ADK agent — the
        # same code path the chat turn uses, so the two cannot diverge.
        try:
            effective = client.get(f"agents/{aid}/effective-tools")
        except (APIError, AuthError) as e:
            # Never fail the listing over the extra section, but say why it is
            # missing: a silent omission reads as "no effective tools", which is
            # exactly the invisibility this section exists to remove.
            effective = None
            if fmt != "json":
                click.echo(f"(effective operations unavailable: {e})", err=True)

    if fmt == "json":
        if effective is not None:
            payload = {"configured": data, "effective": effective}
            output(payload, fmt=fmt, fields=fields, raw=raw)
        else:
            output(data, fmt=fmt, fields=fields, raw=raw)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)
    if effective is None:
        return

    _print_effective_operations(data, effective)


def _declared_operations(configured) -> set:
    """Every operationId the configured agent_tools rows declare.

    An API row with no include_operations declares the whole API, which we cannot
    enumerate from the row alone; such a row contributes nothing here, so its
    operations are never mislabelled UNDECLARED.
    """
    rows = configured.get("items") if isinstance(configured, dict) else configured
    declared = set()
    for row in (rows or []):
        if not isinstance(row, dict):
            continue
        cfg = row.get("config") or {}
        for op in (cfg.get("include_operations") or []):
            declared.add(op)
    return declared


def _print_effective_operations(configured, effective) -> None:
    """Print what the model receives, marking anything not declared."""
    tools = effective.get("tools") or []
    if not tools:
        return
    declared = _declared_operations(configured)
    # Only an API row with an include list gives us a declared set to compare
    # against; with none, suppress the marker rather than cry wolf.
    comparable = bool(declared)

    total = effective.get("total_count", len(tools))
    by_source = effective.get("counts_by_source") or {}
    click.echo()
    click.echo(f"EFFECTIVE OPERATIONS (what the model receives): {total}")
    if by_source:
        click.echo("  by source: " + ", ".join(
            f"{k}={v}" for k, v in sorted(by_source.items())
        ))

    undeclared = []
    for t in tools:
        name = t.get("name") or "?"
        source = t.get("source") or t.get("tool_type") or ""
        mark = ""
        if comparable and source == "integration" and name not in declared:
            mark = "  ⚠ UNDECLARED"
            undeclared.append(name)
        click.echo(f"  {name:<44}{source:<14}{mark}")

    if undeclared:
        click.echo()
        click.echo(
            f"⚠ {len(undeclared)} operation(s) are effective but NOT declared in "
            "include_operations: " + ", ".join(sorted(undeclared))
        )
        click.echo(
            "  include_operations matches exactly (trailing '*' opts into a family). "
            "Audit with pantheon-agent-builder/scripts/audit_effective_operations.py"
        )
    if effective.get("error"):
        click.echo(f"  (effective list incomplete: {effective['error']})")


@agent.command(name="agent-tools")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", "page_size", default=None, type=int)
@click.pass_context
def agent_agent_tools(ctx, page, page_size):
    """List sub-agent tools."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/agent-tools/", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@agent.command(name="delete-tool")
@click.option("--tool-id", required=True, help="Tool ID to delete.")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def agent_delete_tool(ctx, tool_id, yes):
    """Delete a tool from an agent."""
    aid = _aid(ctx)
    _confirm(f"Delete tool {tool_id} from agent {aid}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"agents/{aid}/tools/{tool_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted tool {tool_id} from agent {aid}.")


@agent.command(name="add-provider-tool")
@click.option("--provider-id", required=True, help="Provider ID to add.")
@click.pass_context
def agent_add_provider_tool(ctx, provider_id):
    """Add a provider tool to an agent."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {"provider_id": provider_id}

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/tools/provider/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Added provider tool {provider_id} to agent {aid}.")


@agent.command(name="add-api-group-tool")
@click.option("--api-group-id", required=True, help="API Group ID to add.")
@click.pass_context
def agent_add_api_group_tool(ctx, api_group_id):
    """Add an API group tool to an agent."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {"api_group_id": api_group_id}

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/tools/api-group/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Added API group tool {api_group_id} to agent {aid}.")


@agent.command(name="add-api-tool")
@click.option("--api-id", required=True, help="API ID to add.")
@click.pass_context
def agent_add_api_tool(ctx, api_id):
    """Add an API tool to an agent."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {"api_id": api_id}

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/tools/api/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Added API tool {api_id} to agent {aid}.")


# ── Maintenance & health (agent-scoped) ─────────────────────────────────────

@agent.command(name="drift")
@click.pass_context
def agent_drift(ctx):
    """Check configuration drift: what reload-from-source would change.

    \b
    Compares the agent JSON / prompt files with the database, AND the agent's
    tool rows (agent_tools, what the ADK build reads) with the JSON's tools:
    a row whose include_operations / exclude_operations / dereference_refs /
    simplify_responses differs from source, or a tool attached but not in
    source (or the reverse), shows under "agent tools".

    \b
    Examples:
      torana agent <AGENT_ID> drift
      torana agent <AGENT_ID> drift --json | jq '.drift.files[] | select(.file_type=="agent_tools")'
      torana agent <AGENT_ID> reload-from-source      # apply it
    """
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/drift/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text" or fields:
        output(data, fmt=fmt, fields=fields)
        return
    _print_drift_text(data)


_DRIFT_FILE_LABELS = {
    "agent_json": "agent JSON",
    "prompt_json": "prompt JSON",
    "prompt_md": "prompt content",
    "embedded_prompt_json": "embedded prompt JSON",
    "embedded_prompt_md": "embedded prompt content",
    "agent_tools": "agent tools (rows the agent runs with)",
}
# A word per change type, never colour alone.
_DRIFT_CHANGE_WORDS = {"added": "ADD", "removed": "REMOVE", "modified": "CHANGE"}


def _print_drift_text(data: dict) -> None:
    drift = (data or {}).get("drift") or {}
    name = data.get("agent_name") or data.get("agent_id")
    state = "DRIFT" if drift.get("has_drift") else "IN SYNC"
    click.echo(f"{name}: {state}")
    click.echo(f"  {drift.get('summary') or ''}")
    for f in drift.get("files") or []:
        label = _DRIFT_FILE_LABELS.get(f.get("file_type"), f.get("file_type"))
        if f.get("prompt_name"):
            label += f" [{f['prompt_name']}]"
        changes = f.get("changes") or []
        if not changes:
            click.echo(f"  ok  {label}: in sync")
            continue
        click.echo(f"  !!  {label}: {len(changes)} change(s)")
        for c in changes:
            word = _DRIFT_CHANGE_WORDS.get(c.get("change_type"), str(c.get("change_type")).upper())
            click.echo(f"      {word:<7}{c.get('field')}  {c.get('description') or ''}")


@agent.command(name="check-stale-tools")
@click.pass_context
def agent_check_stale_tools(ctx):
    """Check for stale tool references."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/stale-tools/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agent.command(name="reconcile")
@click.option("--apply", "apply_changes", is_flag=True, default=False,
              help="Make the changes. Without this flag the reconcile is a dry run "
                   "that only reports what it would add or remove.")
@click.option("--dry-run", is_flag=True, default=False,
              help="Report only, change nothing. This is already the default; the flag "
                   "is kept so existing scripts keep working.")
@click.option("--remove-stale", is_flag=True, default=False,
              help="Also remove tools that reference deleted APIs or agents.")
@click.pass_context
def agent_reconcile(ctx, apply_changes, dry_run, remove_stale):
    """Bring an agent's tools in line with its source config (dry run by default).

    Adds tools the source config declares but the agent lacks, and with
    --remove-stale removes tools whose target no longer exists. Nothing changes
    unless --apply is given.

    \b
    Examples:
      torana agent <AGENT_ID> reconcile                   # preview
      torana agent <AGENT_ID> reconcile --apply           # make the changes
      torana agent <AGENT_ID> reconcile --apply --remove-stale
    """
    if apply_changes and dry_run:
        raise click.UsageError("--apply and --dry-run contradict each other; pass one.")
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    # ⛔ Always send dry_run explicitly. It used to be sent only when --dry-run was
    # given, and the API defaults dry_run=true, so no flag combination could apply.
    params = {"dry_run": not apply_changes}
    if remove_stale:
        params["remove_stale"] = True

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/reconcile/", json={}, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent.command(name="reload-agent")
@click.pass_context
def agent_reload_agent(ctx):
    """Reload agent configuration."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/reload/", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent.command(name="reload-from-source")
@click.pass_context
def agent_reload_from_source(ctx):
    """Reload agent from source file, in place (no new version).

    \b
    Refreshes name, description, model, config, tags, prompt link, INSTRUCTIONS (when the
    JSON carries the key) and source_config, re-syncs the prompt, prunes dropped tools.
    It never ADDS tools or sub-agents: use `reconcile --apply` for those.
    `torana agent <id> drift` shows what a reload would change (incl. agent.instructions).
    """
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/reload-from-source/", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent.command(name="reconciliation-status")
@click.pass_context
def agent_reconciliation_status(ctx):
    """Get reconciliation status."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/reconciliation-status/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ── Compaction & settings (agent-scoped) ────────────────────────────────────

@agent.command(name="compaction-thresholds")
@click.option("--window-days", type=int, default=None)
@click.option("--window-hours", type=int, default=None)
@click.option("--window-minutes", type=int, default=None)
@click.option("--window-seconds", type=int, default=None)
@click.pass_context
def agent_compaction_thresholds(ctx, window_days, window_hours, window_minutes, window_seconds):
    """Get compaction thresholds."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    params = {}
    if window_days is not None:
        params["window_days"] = window_days
    if window_hours is not None:
        params["window_hours"] = window_hours
    if window_minutes is not None:
        params["window_minutes"] = window_minutes
    if window_seconds is not None:
        params["window_seconds"] = window_seconds

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/compaction-thresholds", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


def _merge_thresholds(client, aid, reversible, summary, full):
    """Fill unspecified thresholds from the agent's current effective values (the API
    requires all three, ascending)."""
    current = client.get(f"agents/{aid}/compaction-thresholds")
    return {
        "reversible": reversible if reversible is not None else current["reversible"],
        "summary": summary if summary is not None else current["summary"],
        "full": full if full is not None else current["full"],
    }


@agent.command(name="set-compaction-thresholds")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with {reversible, summary, full}.")
@click.option("--reversible", type=float, default=None, help="Fraction of the model's input window for reversible compaction (strip tool outputs).")
@click.option("--summary", type=float, default=None, help="Fraction for LLM history summarization.")
@click.option("--full", type=float, default=None, help="Fraction for full emergency compaction.")
@click.pass_context
def agent_set_compaction_thresholds(ctx, input_file, reversible, summary, full):
    """Set per-agent token_aware compaction thresholds.

    \b
    Examples:
      torana agent <ID> set-compaction-thresholds --reversible 0.4 --summary 0.6 --full 0.8
      torana agent <ID> set-compaction-thresholds --full 0.85      # others keep current values
    """
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    if not input_file and reversible is None and summary is None and full is None:
        click.echo("ERROR: pass --file or at least one of --reversible/--summary/--full.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        body = _load_input_file(input_file) if input_file else _merge_thresholds(client, aid, reversible, summary, full)
        data = client.put(f"agents/{aid}/compaction-thresholds", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent.command(name="delete-compaction-thresholds")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def agent_delete_compaction_thresholds(ctx, yes):
    """Delete compaction thresholds."""
    aid = _aid(ctx)
    _confirm(f"Delete compaction thresholds for agent {aid}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"agents/{aid}/compaction-thresholds")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted compaction thresholds for agent {aid}.")


@agent.command(name="compaction-settings")
@click.pass_context
def agent_compaction_settings(ctx):
    """Get compaction settings."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/compaction-settings")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent.command(name="set-compaction-settings")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with the full settings body.")
@click.option("--scheme", type=click.Choice(["adk_event_based", "token_aware"]), default=None, help="Compaction scheme. Defaults to the agent's current scheme.")
@click.option("--enable/--disable", "enabled", default=None, help="Compaction on/off for this agent (both schemes).")
@click.option("--interval", type=int, default=None, help="adk_event_based: turns between compactions.")
@click.option("--overlap", type=int, default=None, help="adk_event_based: turns kept across a compaction.")
@click.option("--reversible", type=float, default=None, help="token_aware: reversible threshold (fraction of the input window).")
@click.option("--summary", type=float, default=None, help="token_aware: history-summary threshold.")
@click.option("--full", type=float, default=None, help="token_aware: full-compaction threshold.")
@click.option("--retention", type=int, default=None, help="token_aware: recent raw events kept verbatim.")
@click.pass_context
def agent_set_compaction_settings(ctx, input_file, scheme, enabled, interval, overlap, reversible, summary, full, retention):
    """Set the agent's compaction override. Returns the effective policy.

    \b
    Examples:
      torana agent <ID> set-compaction-settings --scheme token_aware
      torana agent <ID> set-compaction-settings --scheme token_aware --reversible 0.4 --summary 0.6 --full 0.8 --retention 10
      torana agent <ID> set-compaction-settings --scheme adk_event_based --interval 5 --overlap 2
      torana agent <ID> set-compaction-settings --disable
    """
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    flags = (scheme, enabled, interval, overlap, reversible, summary, full, retention)
    if not input_file and all(v is None for v in flags):
        click.echo("ERROR: pass --file or at least one setting flag (see --help).", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        if input_file:
            body = _load_input_file(input_file)
        else:
            # The PUT replaces the whole override, so carry forward everything the flags
            # don't change — otherwise `--full 0.45` would drop an `enabled: true` and
            # silently fall back to an agent-JSON `enabled: false`.
            current = client.get(f"agents/{aid}/compaction-settings")
            system = client.get("agents/compaction/settings")
            body = {"scheme": scheme or current["scheme"]}
            adk = dict(current.get("adk_settings") or {})
            if enabled is not None:
                adk["enabled"] = enabled
            if interval is not None:
                adk["interval"] = interval
            if overlap is not None:
                adk["overlap"] = overlap
            body["adk_settings"] = adk
            if reversible is not None or summary is not None or full is not None:
                body["thresholds"] = _merge_thresholds(client, aid, reversible, summary, full)
            elif current.get("thresholds_source") == "agent":
                body["thresholds"] = current["thresholds"]
            if retention is not None:
                body["event_retention_size"] = retention
            elif current.get("event_retention_size") != system.get("event_retention_size"):
                body["event_retention_size"] = current["event_retention_size"]
        data = client.put(f"agents/{aid}/compaction-settings", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent.command(name="delete-compaction-settings")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def agent_delete_compaction_settings(ctx, yes):
    """Delete compaction settings."""
    aid = _aid(ctx)
    _confirm(f"Delete compaction settings for agent {aid}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"agents/{aid}/compaction-settings")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted compaction settings for agent {aid}.")


# ── Sessions management (agent-scoped, not session-scoped) ───────────────────


# ── Chat sessions (collection group) ────────────────────────────────────────


# ── Plans management (agent-level, not session-scoped) ──────────────────────

@agent.command(name="create-plan")
@click.option("--title", required=True, help="Plan title.")
@click.option("--plan-key-hint", required=True, help="Short hint for the plan key.")
@click.option("--actions", required=True, help="JSON actions list or file path.")
@click.option("--description", default=None)
@click.option("--execution-mode", default="hitl")
@click.option("--workspace-id", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with plan.")
@click.pass_context
def agent_create_plan(ctx, title, plan_key_hint, actions, description, execution_mode, workspace_id, input_file):
    """Create a plan (this will be moved to session-scoped in agent_session)."""
    # NOTE: This is a placeholder. The actual plans should be session-scoped.
    # For now, we keep this for compatibility but it should be under session.
    click.echo("ERROR: Plans should be created under a session.", err=True)
    import sys
    sys.exit(1)


# ── Session-scoped commands (under @agent_session) ──────────────────────────

@agent_session.command(name="get")
@click.pass_context
def agent_session_get(ctx):
    """Get details for a specific session."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/sessions/{sid}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ── Unified message-retrieval surface (TORANA_A2A.md § 3.4.6 / § 3.5.4 / § 3.5.6) ──
#
# Three verbs on the SINGULAR base /agent/<id>/session/<sid> (compose-not-overlay):
#   load           → GET .../                → TenantSessionLoad   (tenant: session+snapshot+render_meta)
#   messages       → GET .../messages        → MessageSnapshot     (public/external contract)
#   messages-admin → GET .../messages/admin  → AdminMessageSnapshot (super_admin, cross-tenant)
# RBAC-transparent: scope/content is decided by the backend from your token.

def _print_message_snapshot(snapshot: dict) -> None:
    """Render a MessageSnapshot as a per-message summary table (text mode)."""
    msgs = snapshot.get("messages", [])
    click.echo(f"{snapshot.get('type', 'MessagesSnapshot')}  "
               f"schemaVersion={snapshot.get('schemaVersion')}  messages={len(msgs)}")
    rows = []
    for m in msgs:
        tcs = m.get("toolCalls") or []
        widgets = ",".join(tc.get("name") or "?" for tc in tcs) if tcs else ""
        content = (m.get("content") or "").replace("\n", " ")
        rows.append({
            "id": m.get("id"),
            "role": m.get("role"),
            "content": content[:60] + ("…" if len(content) > 60 else ""),
            "widgets": widgets[:40],
        })
    output(
        {"items": rows, "total": len(rows)},
        fmt="text",
        columns=[
            ("id", "MSG ID", 16),
            ("role", "ROLE", 10),
            ("content", "CONTENT", 62),
            ("widgets", "WIDGETS", 40),
        ],
    )


@agent_session.command(name="messages")
@click.pass_context
def agent_session_messages(ctx):
    """Get the folded message snapshot for this session (PUBLIC contract).

    \b
    GET /agent/<id>/session/<sid>/messages → MessageSnapshot. The clean,
    externally-consumable payload. Scope is your login: a tenant user reads their
    own session. (For cross-tenant / diagnostics, use `messages-admin`.)
    """
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"agent/{aid}/session/{sid}/messages")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml") or raw:
        output(data, fmt=fmt, raw=raw, fields=fields)
    else:
        _print_message_snapshot(data)


@agent_session.command(name="messages-admin")
@click.pass_context
def agent_session_messages_admin(ctx):
    """Get the message snapshot + diagnostics for this session (SUPER-ADMIN).

    \b
    GET /agent/<id>/session/<sid>/messages/admin → AdminMessageSnapshot. Requires
    audit:read (super_admin); reads ANY session cross-tenant. The payload embeds the
    public MessageSnapshot whole (`.snapshot`) plus diagnostics/message_diagnostics.
    """
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"agent/{aid}/session/{sid}/messages/admin")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml") or raw:
        output(data, fmt=fmt, raw=raw, fields=fields)
    else:
        snap = data.get("snapshot", {})
        _print_message_snapshot(snap)
        diag = data.get("diagnostics") or {}
        mdiag = data.get("message_diagnostics") or {}
        click.echo(f"\ndiagnostics: trace_summary="
                   f"{len(diag.get('trace_summary') or []) if diag else 0} "
                   f"| message_diagnostics={len(mdiag)}")


@agent_session.command(name="load")
@click.pass_context
@click.option("--include", "include", default=None,
              help="Comma-separated kinds: turns,artifacts,thinking,hitl "
                   "(default turns,artifacts,hitl; thinking opt-in).")
def agent_session_load(ctx, include):
    """Get this session's chrome + interleaved conversation timeline (TENANT).

    \b
    GET /agent/<id>/session/<sid> → ConversationLoad. `{session, items[], include}`:
    `session` is the de-bloated chrome (name/state_tag/pending_checkpoint); `items[]`
    is ONE ordered interleaved timeline — kind='turn' (folded message) and
    kind='artifact' (settled A2UI surface) in stream order. `--include` selects which
    kinds. Scope is your login (owner-bound).
    """
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    path = f"agent/{aid}/session/{sid}"
    if include:
        path += f"?include={include}"
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml") or raw:
        output(data, fmt=fmt, raw=raw, fields=fields)
    else:
        sess = data.get("session", {})
        click.echo(f"session: {sess.get('name') or '(unnamed)'}"
                   f"  status={sess.get('status', '?')}"
                   f"  state_tag={(sess.get('state_tag') or '-')[:12]}"
                   f"  pending_checkpoint={sess.get('pending_checkpoint_id') or '-'}")
        click.echo(f"include: {','.join(data.get('include') or [])}")
        items = data.get("items") or []
        click.echo(f"\nitems: {len(items)}")
        for it in items:
            kind = it.get("kind")
            if kind == "turn":
                m = it.get("message", {})
                tc = m.get("toolCalls") or []
                content = (m.get("content") or "").replace("\n", " ")
                click.echo(f"  turn      {m.get('role',''):9} "
                           f"{('[' + str(len(tc)) + ' tools] ') if tc else ''}"
                           f"{content[:70]}")
            elif kind == "artifact":
                s = it.get("surface", {})
                root = (s.get("components") or {}).get("root", {})
                click.echo(f"  artifact  {s.get('surfaceId','')[:24]:24} "
                           f"root={root.get('type','?')}")


@agent_session.command(name="fork")
@click.option("--turn-id", default=None, help="Fork after this turn (inclusive).")
@click.option("--message-index", default=None, type=int, help="Alternative: fork including first N+1 messages.")
@click.option("--name", default=None, help="Optional name for forked session.")
@click.pass_context
def agent_session_fork(ctx, turn_id, message_index, name):
    """Fork a session."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if turn_id is not None:
        body["turn_id"] = turn_id
    if message_index is not None:
        body["message_index"] = message_index
    if name is not None:
        body["name"] = name

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/sessions/{sid}/fork/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent_session.command(name="lineage")
@click.pass_context
def agent_session_lineage(ctx):
    """Get session lineage."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/sessions/{sid}/lineage/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agent_session.command(name="tool-result")
@click.option("--tool-call-id", required=True)
@click.option("--result", required=True, help="Tool result as JSON string or file path.")
@click.option("--approved", is_flag=True, default=False)
@click.option("--response", default=None)
@click.option("--decision", default=None)
@click.pass_context
def agent_session_tool_result(ctx, tool_call_id, result, approved, response, decision):
    """Provide a tool result."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    # Parse result
    import json
    try:
        if result.startswith('{') or result.startswith('['):
            result_data = json.loads(result)
        else:
            from pathlib import Path
            result_data = json.loads(Path(result).read_text())
    except (json.JSONDecodeError, FileNotFoundError):
        result_data = result

    body = {"tool_call_id": tool_call_id, "result": result_data}
    if approved:
        body["approved"] = True
    if response:
        body["response"] = response
    if decision:
        body["decision"] = decision

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/sessions/{sid}/tool-result/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent_session.command(name="hitl-response")
@click.option("--type", "response_type", required=True, help="Response type.")
@click.option("--step-id", default=None)
@click.option("--tool-call-id", default=None)
@click.option("--approved", is_flag=True, default=False)
@click.option("--response", default=None)
@click.option("--decision", default=None)
@click.option("--modified-params", default=None, help="Modified params as JSON.")
@click.option("--comment", default=None)
@click.pass_context
def agent_session_hitl_response(ctx, response_type, step_id, tool_call_id, approved, response, decision, modified_params, comment):
    """Provide a HITL response."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {"type": response_type}
    if step_id:
        body["step_id"] = step_id
    if tool_call_id:
        body["tool_call_id"] = tool_call_id
    if approved:
        body["approved"] = True
    if response:
        body["response"] = response
    if decision:
        body["decision"] = decision
    if modified_params:
        import json
        body["modified_params"] = json.loads(modified_params)
    if comment:
        body["comment"] = comment

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/sessions/{sid}/hitl-response/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent_session.command(name="cancel")
@click.pass_context
def agent_session_cancel(ctx):
    """Cancel a session."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/sessions/{sid}/cancel/", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent_session.command(name="hitl-chain")
@click.option("--checkpoint-id", required=True, help="Checkpoint ID.")
@click.pass_context
def agent_session_hitl_chain(ctx, checkpoint_id):
    """Get HITL checkpoint chain."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/sessions/{sid}/hitl-chain/{checkpoint_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent_session.group(name="plan")
@click.pass_context
def agent_session_plan(ctx):
    """Manage plans for this session."""
    ctx.ensure_object(dict)


@agent_session_plan.command(name="create")
@click.option("--title", required=True, help="Plan title.")
@click.option("--plan-key-hint", required=True, help="Short hint for plan key.")
@click.option("--actions", required=True, help="Actions as JSON string or file path.")
@click.option("--description", default=None)
@click.option("--execution-mode", default="hitl")
@click.option("--workspace-id", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def agent_session_plan_create(ctx, title, plan_key_hint, actions, description, execution_mode, workspace_id, input_file):
    """Create a plan for this session."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    if input_file:
        body = _load_input_file(input_file)
    else:
        # Parse actions
        import json
        try:
            if actions.startswith('['):
                actions_list = json.loads(actions)
            else:
                from pathlib import Path
                actions_list = json.loads(Path(actions).read_text())
        except (json.JSONDecodeError, FileNotFoundError) as e:
            click.echo(f"ERROR: Failed to parse actions: {e}", err=True)
            import sys
            sys.exit(2)

        body = {
            "title": title,
            "plan_key_hint": plan_key_hint,
            "actions": actions_list,
        }
        if description:
            body["description"] = description
        if execution_mode:
            body["execution_mode"] = execution_mode
        if workspace_id:
            body["workspace_id"] = workspace_id

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/sessions/{sid}/plans/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        plan_id = data.get('id', 'unknown')
        click.echo(f"Created plan: {plan_id}")


@agent_session_plan.command(name="list")
@click.option("--status", default=None, help="Filter by plan status.")
@click.pass_context
def agent_session_plan_list(ctx, status):
    """List plans for this session."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if status:
        params["status"] = status

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/sessions/{sid}/plans/", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agent_session_plan.command(name="active")
@click.pass_context
def agent_session_plan_active(ctx):
    """Get active plan for this session."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/sessions/{sid}/plans/active/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent_session_plan.command(name="by-key")
@click.option("--plan-key", required=True, help="Plan key.")
@click.pass_context
def agent_session_plan_by_key(ctx, plan_key):
    """Get plan by key."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/sessions/{sid}/plans/key/{plan_key}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent_session_plan.command(name="get")
@click.option("--plan-id", required=True, help="Plan ID.")
@click.pass_context
def agent_session_plan_get(ctx, plan_id):
    """Get a specific plan."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/sessions/{sid}/plans/{plan_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent_session_plan.command(name="update-actions")
@click.option("--plan-id", required=True, help="Plan ID.")
@click.option("--actions", required=True, help="Actions as JSON string or file path.")
@click.pass_context
def agent_session_plan_update_actions(ctx, plan_id, actions):
    """Update plan actions."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    # Parse actions
    import json
    try:
        if actions.startswith('['):
            actions_list = json.loads(actions)
        else:
            from pathlib import Path
            actions_list = json.loads(Path(actions).read_text())
    except (json.JSONDecodeError, FileNotFoundError) as e:
        click.echo(f"ERROR: Failed to parse actions: {e}", err=True)
        import sys
        sys.exit(2)

    body = {"actions": actions_list}

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/sessions/{sid}/plans/{plan_id}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent_session_plan.command(name="move")
@click.option("--plan-id", required=True, help="Plan ID.")
@click.option("--target-workspace-id", required=True, help="Target workspace ID.")
@click.pass_context
def agent_session_plan_move(ctx, plan_id, target_workspace_id):
    """Move plan to another workspace."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {"target_workspace_id": target_workspace_id}

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/sessions/{sid}/plans/{plan_id}/move/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent_session_plan.command(name="set-status")
@click.option("--plan-id", required=True, help="Plan ID.")
@click.option("--status", required=True, help="New status.")
@click.option("--reason", default=None, help="Reason for status change.")
@click.pass_context
def agent_session_plan_set_status(ctx, plan_id, status, reason):
    """Set plan status."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {"status": status}
    if reason:
        body["reason"] = reason

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/sessions/{sid}/plans/{plan_id}/status/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


# ── Nested work sub-group (async agent work) ────────────────────────────────
#
# `torana agent <ID> work ...` — submit long-running agent work, then poll for
# state + result. The async counterpart to the synchronous invoke: submit returns
# a work_id immediately (no held connection), and the run continues server-side
# through the Gemini stall + minutes-long tool chains without a 504.
# Backend: POST/GET /api/v1/agents/{id}/work (docs/ASYNC_AGENT_WORK_REQUIREMENT.md).

@agent.group(name="work", invoke_without_command=True)
@click.pass_context
def agent_work(ctx):
    """Async agent work — submit long-running runs, poll state + result.

    \b
    Examples:
      torana agent <UUID> work submit -m "Triage alert <ID>"
      torana agent <UUID> work submit -m "..." --wait
      torana agent <UUID> work get <WORK_ID>
      torana agent <UUID> work list --status running
      torana agent <UUID> work cancel <WORK_ID>
    """
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _build_invoke_body(message, input_file, workspace_id, timeout):
    """Assemble an InvokeRequest body from CLI options (shared invoke shape)."""
    if input_file:
        body = _load_input_file(input_file)
    elif message:
        body = {"messages": [{"role": "user", "content": message}]}
    else:
        raise click.UsageError("Provide -m/--message or --input-file.")
    if timeout is not None:
        cfg = dict(body.get("config") or {})
        cfg["timeout_seconds"] = timeout
        body["config"] = cfg
    if workspace_id:
        env = dict(body.get("envelope") or {})
        env["workspace_id"] = workspace_id
        body["envelope"] = env
    return body


@agent_work.command(name="submit")
@click.option("-m", "--message", default=None, help="User message for the agent.")
@click.option("--input-file", default=None,
              help="JSON file with a full InvokeRequest body (messages/config/context/envelope).")
@click.option("--workspace-id", default=None, help="Workspace id (into envelope.workspace_id).")
@click.option("--timeout", type=int, default=None,
              help="Per-run timeout in seconds (config.timeout_seconds).")
@click.option("--wait", is_flag=True, default=False,
              help="Poll until the work reaches a terminal state, then print the result.")
@click.option("--poll-interval", type=float, default=3.0, show_default=True,
              help="Seconds between polls when --wait is set.")
@click.option("--wait-timeout", type=int, default=1800, show_default=True,
              help="Max seconds to wait when --wait is set.")
@click.pass_context
def agent_work_submit(ctx, message, input_file, workspace_id, timeout, wait,
                      poll_interval, wait_timeout):
    """Submit async agent work → returns a work_id immediately (202).

    With --wait, polls until the run finishes and prints the final result.
    """
    aid = _aid(ctx)
    fmt, raw, fields = _fmt3(ctx)
    client = _client(ctx)
    try:
        body = _build_invoke_body(message, input_file, workspace_id, timeout)
    except click.UsageError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(2)
    try:
        submitted = client.post(f"agents/{aid}/work/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if not wait:
        output(submitted, fmt=fmt, raw=raw, fields=fields)
        return

    import time
    work_id = submitted.get("work_id")
    if not work_id:
        output(submitted, fmt=fmt, raw=raw, fields=fields)
        return
    deadline = time.monotonic() + wait_timeout
    terminal = {"succeeded", "failed", "cancelled"}
    last = submitted
    if fmt == "text":
        click.echo(f"Submitted work {work_id} — waiting for completion...", err=True)
    while time.monotonic() < deadline:
        try:
            last = client.get(f"agents/{aid}/work/{work_id}")
        except APIError as e:
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return
        st = (last or {}).get("status")
        if st in terminal:
            break
        if fmt == "text":
            click.echo(f"  … {st}", err=True)
        time.sleep(poll_interval)
    else:
        click.echo(f"Timed out after {wait_timeout}s waiting for work {work_id} "
                   f"(still {(last or {}).get('status')}).", err=True)
        sys.exit(1)
    output(last, fmt=fmt, raw=raw, fields=fields)


@agent_work.command(name="get")
@click.argument("work_id", metavar="WORK_ID")
@click.pass_context
def agent_work_get(ctx, work_id):
    """Get the state + result of a submitted work by id."""
    aid = _aid(ctx)
    fmt, raw, fields = _fmt3(ctx)
    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/work/{work_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@agent_work.command(name="list")
@click.option("--status", default=None,
              help="Filter by status (queued|running|succeeded|failed|cancelled).")
@click.option("--limit", type=int, default=50, show_default=True)
@click.option("--offset", type=int, default=0, show_default=True)
@click.pass_context
def agent_work_list(ctx, status, limit, offset):
    """List this agent's work submissions (newest first)."""
    aid = _aid(ctx)
    fmt, raw, fields = _fmt3(ctx)
    client = _client(ctx)
    params = {"limit": limit, "offset": offset}
    if status:
        params["status"] = status
    try:
        data = client.get(f"agents/{aid}/work", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@agent_work.command(name="cancel")
@click.argument("work_id", metavar="WORK_ID")
@click.pass_context
def agent_work_cancel(ctx, work_id):
    """Request cooperative cancellation of a submitted work."""
    aid = _aid(ctx)
    fmt, raw, fields = _fmt3(ctx)
    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/work/{work_id}/cancel/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)
