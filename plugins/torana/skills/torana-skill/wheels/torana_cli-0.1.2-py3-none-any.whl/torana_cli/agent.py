"""torana agent <ID> — instance-scoped agent commands."""

import json
import sys
from datetime import datetime, timezone

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.a2a_rpc import (
    M_CANCEL,
    M_GET,
    M_LIST,
    M_SEND,
    rpc_call,
    user_message,
)
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm


# ── Constants ────────────────────────────────────────────────────────────────

# Widgets that pause execution and require a human response
HITL_WIDGETS = {"ui_user_choice", "ui_form", "ui_confirmation", "ui_text_input", "ui_date_range"}

# Human-readable labels + icons for known widget types
WIDGET_LABELS = {
    "ui_bar_chart": ("📊", "Bar Chart"),
    "ui_line_chart": ("📈", "Line Chart"),
    "ui_pie_chart": ("🥧", "Pie Chart"),
    "ui_table": ("📋", "Table"),
    "ui_scalar": ("🔢", "Scalar"),
    "ui_gauge": ("🎯", "Gauge"),
    "ui_heatmap": ("🌡", "Heatmap"),
    "ui_treemap": ("🗂", "Treemap"),
    "ui_radar": ("📡", "Radar"),
    "ui_sankey": ("〰", "Sankey"),
    "ui_funnel": ("🔽", "Funnel"),
    "ui_scatter": ("⠿", "Scatter"),
    "ui_timeline": ("📅", "Timeline"),
    "ui_calendar_heatmap": ("📆", "Calendar Heatmap"),
    "ui_waterfall": ("🌊", "Waterfall"),
    "ui_boxplot": ("📦", "Boxplot"),
    "ui_status_card": ("🃏", "Status Card"),
    "ui_markdown_display": ("📝", "Markdown"),
    "ui_code_display": ("💻", "Code"),
    "ui_plan_display": ("📋", "Plan"),
    "ui_plan_tracker": ("✅", "Plan Tracker"),
    "ui_user_choice": ("❓", "Choice"),
    "ui_form": ("📝", "Form"),
    "ui_confirmation": ("✅", "Confirmation"),
    "ui_text_input": ("💬", "Text Input"),
    "ui_date_range": ("📅", "Date Range"),
    "emit_status": ("💬", "Status"),
}


def _widget_label(tool_name: str) -> tuple[str, str]:
    """Return (icon, label) for a widget tool name."""
    return WIDGET_LABELS.get(tool_name, ("🔧", tool_name))


def _widget_title(tool_name: str, args: dict) -> str:
    """Extract a human-readable title from widget args."""
    # Try common title fields in order of preference
    for field in ("title", "question", "header", "label", "prompt", "content"):
        val = args.get(field)
        if val and isinstance(val, str):
            return val[:80] + ("…" if len(val) > 80 else "")
    return ""


# ── Helpers ───────────────────────────────────────────────────────────────────

def _fmt_ts(ts: str | None) -> str:
    """Format ISO timestamp to HH:MM:SS local."""
    if not ts:
        return "—"
    try:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        local = dt.astimezone()
        return local.strftime("%H:%M:%S")
    except Exception:
        return ts[:19]


def _fmt_ts_full(ts: str | None) -> str:
    """Format ISO timestamp to full local datetime."""
    if not ts:
        return "—"
    try:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        local = dt.astimezone()
        return local.strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return ts[:19]


def _elapsed(since_ts: str | None) -> str:
    """Human-readable elapsed time since ISO timestamp."""
    if not since_ts:
        return ""
    try:
        dt = datetime.fromisoformat(since_ts.replace("Z", "+00:00"))
        secs = int((datetime.now(timezone.utc) - dt).total_seconds())
        if secs < 60:
            return f"{secs}s"
        elif secs < 3600:
            return f"{secs // 60}m {secs % 60}s"
        else:
            return f"{secs // 3600}h {(secs % 3600) // 60}m"
    except Exception:
        return ""


def _duration(start: str | None, end: str | None) -> str:
    """Format duration between two ISO timestamps."""
    if not start or not end:
        return ""
    try:
        s = datetime.fromisoformat(start.replace("Z", "+00:00"))
        e = datetime.fromisoformat(end.replace("Z", "+00:00"))
        secs = (e - s).total_seconds()
        if secs < 60:
            return f"{secs:.1f}s"
        else:
            return f"{secs // 60:.0f}m {secs % 60:.0f}s"
    except Exception:
        return ""



def _parse_session_messages(data: dict) -> dict:
    """Parse the audit/sessions/{sid}/messages response into a structured summary."""
    messages = data.get("messages", [])
    trace_summary = data.get("trace_summary", [])
    pending_checkpoint_id = data.get("pending_checkpoint_id")
    session_status = data.get("session_status", "unknown")

    # Build a map from otel_trace_id -> turn for matching ag_ui events to turns
    # trace_summary entries carry trace_id which matches otel_trace_id on messages
    trace_to_turn: dict[str, dict] = {}
    turns = []

    for m in messages:
        mtype = m.get("message_type", "")
        role = m.get("role", "")
        ts = m.get("timestamp") or m.get("created_at", "")
        otel = m.get("otel_trace_id", "")
        msg_turn_id = m.get("turn_id", "")

        if role == "user" and mtype == "text":
            turn = {
                "turn_id": msg_turn_id,
                "otel_trace_id": otel,
                "user": {"text": m.get("content", ""), "sent_at": ts},
                "agent_text": "",
                "widgets": [],          # list of rendered widget dicts
                "hitl_tool_call": None,
                "_tool_call_args": {},  # tcid -> {name, args, ts}
                "_text_messages": {},   # mid -> accumulated text
                "is_hitl_resume": False,
            }
            turns.append(turn)
            if otel:
                trace_to_turn[otel] = turn

    # Synthesize turns for trace_summary entries that have no user message
    # (HITL-resume turns: agent-side turn triggered by HITL response, no user text message)
    user_otels = set(trace_to_turn.keys())
    for tr in trace_summary:
        tid = tr.get("trace_id", "")
        if tid and tid not in user_otels:
            turn = {
                "turn_id": tr.get("turn_id", ""),
                "otel_trace_id": tid,
                "user": None,           # no user message — HITL resume
                "agent_text": "",
                "widgets": [],
                "hitl_tool_call": None,
                "_tool_call_args": {},
                "_text_messages": {},
                "is_hitl_resume": True,
            }
            turns.append(turn)
            trace_to_turn[tid] = turn

    # Sort turns by started_at from trace_summary so HITL-resume turns appear in order
    def _turn_sort_key(t: dict) -> str:
        otel = t.get("otel_trace_id", "")
        matched = next((tr for tr in trace_summary if tr.get("trace_id", "") == otel), None)
        return (matched or {}).get("started_at", "") or t.get("user", {}) and t["user"].get("sent_at", "") or ""

    turns.sort(key=_turn_sort_key)

    # Second pass: attach ag_ui_events to the correct turn via otel_trace_id
    for m in messages:
        mtype = m.get("message_type", "")
        if mtype != "ag_ui_event":
            continue
        otel = m.get("otel_trace_id", "")
        ts = m.get("timestamp") or m.get("created_at", "")
        turn = trace_to_turn.get(otel)
        if turn is None:
            continue

        try:
            evt = json.loads(m.get("content", "{}"))
        except Exception:
            continue
        etype = evt.get("type", "")

        if etype == "ToolCallStart":
            tcid = evt.get("toolCallId", "")
            tcname = evt.get("toolCallName", "")
            turn["_tool_call_args"][tcid] = {"name": tcname, "args": "", "ts": ts}

        elif etype == "ToolCallArgs":
            tcid = evt.get("toolCallId", "")
            if tcid in turn["_tool_call_args"]:
                turn["_tool_call_args"][tcid]["args"] += evt.get("delta", "")

        elif etype == "TextMessageContent":
            mid = evt.get("messageId", "")
            turn["_text_messages"][mid] = (
                turn["_text_messages"].get(mid, "") + evt.get("delta", "")
            )

    # Post-process: collapse text messages, build widget list, detect HITL, attach trace info
    for i, turn in enumerate(turns):
        # Collapse accumulated text per turn
        turn["agent_text"] = " ".join(turn["_text_messages"].values()).strip()
        del turn["_text_messages"]

        # Build ordered widget list + detect HITL tool call
        for tcid, info in turn["_tool_call_args"].items():
            name = info["name"]
            if not name.startswith("ui_") and name not in ("emit_status",):
                continue
            try:
                args = json.loads(info["args"]) if info["args"] else {}
            except Exception:
                args = {}
            widget_entry = {
                "tool_call_id": tcid,
                "widget": name,
                "args": args,
                "ts": info["ts"],
            }
            turn["widgets"].append(widget_entry)
            # First HITL widget found becomes the hitl_tool_call
            if name in HITL_WIDGETS and turn["hitl_tool_call"] is None:
                turn["hitl_tool_call"] = widget_entry
        del turn["_tool_call_args"]

        # Attach trace info by matching otel_trace_id to trace_summary entries
        otel = turn.get("otel_trace_id", "")
        matched_trace = next(
            (tr for tr in trace_summary if tr.get("trace_id", "") == otel), None
        )
        if matched_trace:
            raw_status = matched_trace.get("execution_status", "")
            outcome = matched_trace.get("outcome", "")
            # Backend leaves execution_status=RUNNING / ended_at=None for hitl_pause turns.
            # Treat hitl_pause as a terminal state, not "still running".
            if outcome == "hitl_pause" and raw_status == "RUNNING":
                raw_status = "HITL_PAUSE"
            turn["trace"] = {
                "trace_id": matched_trace.get("trace_id", ""),
                "outcome": outcome,
                "status": raw_status,
                "started_at": matched_trace.get("started_at"),
                "ended_at": matched_trace.get("ended_at"),
                "duration_seconds": matched_trace.get("duration_seconds"),
            }
        else:
            turn["trace"] = None

    return {
        "session_id": data.get("session_id", ""),
        "session_status": session_status,
        "agent_id": data.get("agent_id", ""),
        "agent_name": data.get("agent_name", ""),
        "pending_checkpoint_id": pending_checkpoint_id,
        "turns": turns,
        "raw_trace_summary": trace_summary,
    }


def _wrap_indent(text: str, indent: str = "  ", width: int = 76) -> str:
    """Wrap text at width, preserving newlines, with a hanging indent."""
    import textwrap
    lines = text.splitlines()
    out = []
    for line in lines:
        if len(line) <= width:
            out.append(indent + line)
        else:
            wrapped = textwrap.fill(line, width=width, initial_indent=indent,
                                    subsequent_indent=indent)
            out.append(wrapped)
    return "\n".join(out)


def _print_chat_get_text(parsed: dict, detail: bool, last: int | None) -> None:
    """Render chat get as human-readable text."""
    turns = parsed["turns"]
    if last is not None:
        turns = turns[-last:] if last < len(turns) else turns

    pending_id = parsed["pending_checkpoint_id"]

    if not turns:
        click.echo("No messages yet.")
        return

    W = 72  # separator width

    for i, turn in enumerate(turns):
        user = turn.get("user", {})
        trace = turn.get("trace") or {}
        outcome = trace.get("outcome", "")
        status = trace.get("status", "")
        started = trace.get("started_at")
        ended = trace.get("ended_at")
        duration = trace.get("duration_seconds")
        agent_text = turn.get("agent_text", "")
        widgets = turn.get("widgets", [])
        hitl = turn.get("hitl_tool_call")
        is_hitl_resume = turn.get("is_hitl_resume", False)

        if i > 0:
            click.echo()

        # ── USER block ──────────────────────────────────────────────────────
        user_ts = _fmt_ts(user.get("sent_at") if user else started)
        user_text = (user.get("text", "") if user else "").strip()

        if is_hitl_resume:
            click.echo(f"  YOU  [{_fmt_ts(started)}]  HITL response submitted")
        else:
            click.echo(f"  YOU  [{user_ts}]")
            if user_text:
                click.echo(_wrap_indent(user_text, "    "))

        click.echo()

        # ── AGENT block ─────────────────────────────────────────────────────
        truly_running = (status == "RUNNING") and outcome not in ("hitl_pause", "completed", "error")

        if truly_running and not ended:
            elapsed = _elapsed(started)
            click.echo(f"  AGENT  ⏳ processing...  ({elapsed} elapsed)")
            if detail and trace.get("trace_id"):
                click.echo(f"    Turn: {trace['trace_id']}")

        elif agent_text or widgets:
            dur_str = f"{duration:.1f}s" if duration else _duration(started, ended)
            status_tag = f"✓  {dur_str}" if dur_str else "✓"
            click.echo(f"  AGENT  [{_fmt_ts(ended or started)}]  {status_tag}")

            if agent_text:
                click.echo(_wrap_indent(agent_text, "    "))
                if widgets:
                    click.echo()

            for w in widgets:
                wname = w["widget"]
                if wname == "emit_status":
                    continue
                icon, label = _widget_label(wname)
                args = w.get("args", {})
                title = _widget_title(wname, args)

                # Header line for widget
                title_str = f"  {title}" if title else ""
                click.echo(f"    {icon}  {label}{title_str}")

                # Show widget body content where useful
                if wname == "ui_markdown_display":
                    body = args.get("content", args.get("markdown", ""))
                    if body:
                        # First 8 lines only unless --detail
                        lines = body.strip().splitlines()
                        limit = len(lines) if detail else min(8, len(lines))
                        for ln in lines[:limit]:
                            click.echo(f"       {ln}")
                        if not detail and len(lines) > limit:
                            click.echo(f"       … ({len(lines) - limit} more lines — use --detail)")
                elif wname in ("ui_user_choice", "ui_confirmation"):
                    prompt = args.get("prompt", args.get("message", ""))
                    choices = args.get("choices", args.get("options", []))
                    if prompt:
                        click.echo(f"       {prompt}")
                    if choices:
                        for idx, ch in enumerate(choices, 1):
                            label_text = ch if isinstance(ch, str) else ch.get("label", str(ch))
                            click.echo(f"       {idx}. {label_text}")
                elif wname == "ui_form":
                    prompt = args.get("prompt", args.get("title", ""))
                    if prompt:
                        click.echo(f"       {prompt}")
                    for field in args.get("fields", []):
                        fname = field.get("label", field.get("name", ""))
                        click.echo(f"       • {fname}")

            if detail and trace.get("trace_id"):
                click.echo()
                click.echo(f"    Turn: {trace['trace_id']}")

        elif outcome == "hitl_pause" or status == "HITL_PAUSE" or hitl:
            click.echo(f"  AGENT  [{_fmt_ts(started)}]  ⏸  paused — waiting for your input")

        click.echo()
        click.echo("  " + "─" * W)

    # ── HITL action block ────────────────────────────────────────────────────
    last_turn = turns[-1] if turns else {}
    hitl = last_turn.get("hitl_tool_call")
    last_trace = (last_turn.get("trace") or {})
    last_outcome = last_trace.get("outcome", "")

    if hitl and (pending_id or last_outcome == "hitl_pause"):
        args = hitl.get("args", {})
        prompt = args.get("prompt", "")
        choices = args.get("choices", args.get("options", []))
        widget = hitl.get("widget", "")
        waiting = _elapsed(hitl.get("ts"))
        aid = parsed.get("agent_id", "<AGENT_ID>")
        sid = parsed.get("session_id", "<SESSION_ID>")

        click.echo()
        click.echo("  ┌─ WAITING FOR YOUR INPUT " + "─" * (W - 24) + "┐")
        if prompt:
            click.echo(f"  │  {prompt}")
        if choices:
            for idx, ch in enumerate(choices, 1):
                ch_label = ch if isinstance(ch, str) else ch.get("label", str(ch))
                click.echo(f"  │    {idx}. {ch_label}")
        if waiting:
            click.echo(f"  │  Waiting: {waiting}")
        click.echo(f"  │")
        click.echo(f"  │  Respond:")
        click.echo(f"  │    torana agent {aid} session {sid} chat --respond --text \"<choice>\"")
        click.echo("  └" + "─" * (W - 1) + "┘")


def _build_chat_get_json(parsed: dict, detail: bool, last: int | None) -> dict:
    """Build structured JSON for chat get."""
    turns = parsed["turns"]
    if last is not None:
        turns = turns[-last:] if last < len(turns) else turns

    out_turns = []
    for i, turn in enumerate(turns):
        trace = turn.get("trace") or {}
        status = trace.get("status", "")
        started = trace.get("started_at")
        ended = trace.get("ended_at")
        duration = trace.get("duration_seconds")

        t = {
            "index": i + 1,
            "user": {
                "text": turn["user"].get("text", ""),
                "sent_at": turn["user"].get("sent_at"),
            },
            "agent": {
                "status": "running" if status == "RUNNING" else ("completed" if ended else "paused"),
                "started_at": started,
                "completed_at": ended,
                "duration_seconds": duration,
            },
        }

        if turn.get("agent_text"):
            t["agent"]["text"] = turn["agent_text"]

        # Widgets — always include terse summary; full args only with --detail
        turn_widgets = turn.get("widgets", [])
        if turn_widgets:
            if detail:
                t["agent"]["widgets"] = [
                    {
                        "widget": w["widget"],
                        "title": _widget_title(w["widget"], w.get("args", {})),
                        "args": w.get("args", {}),
                        "ts": w.get("ts"),
                    }
                    for w in turn_widgets
                ]
            else:
                t["agent"]["widgets"] = [
                    {
                        "widget": w["widget"],
                        "title": _widget_title(w["widget"], w.get("args", {})),
                    }
                    for w in turn_widgets
                ]

        if detail:
            t["turn_id"] = trace.get("trace_id", "")
            t["agent"]["outcome"] = trace.get("outcome", "")
            if status == "RUNNING":
                t["agent"]["elapsed_seconds"] = None
                try:
                    s = datetime.fromisoformat(started.replace("Z", "+00:00"))
                    t["agent"]["elapsed_seconds"] = int(
                        (datetime.now(timezone.utc) - s).total_seconds()
                    )
                except Exception:
                    pass

        out_turns.append(t)

    result = {
        "session_id": parsed["session_id"],
        "session_status": parsed["session_status"],
        "agent_id": parsed["agent_id"],
        "agent_name": parsed["agent_name"],
        "turns": out_turns,
    }

    # HITL block
    last_turn = (parsed["turns"][-last:] if last else parsed["turns"])
    if last_turn:
        last_t = last_turn[-1]
        hitl = last_t.get("hitl_tool_call")
        last_outcome = (last_t.get("trace") or {}).get("outcome", "")
        pending_id = parsed["pending_checkpoint_id"]

        if hitl and (pending_id or last_outcome == "hitl_pause"):
            args = hitl.get("args", {})
            hitl_block = {
                "widget": hitl.get("widget"),
                "prompt": args.get("prompt"),
                "options": args.get("choices", args.get("options", [])),
                "checkpoint_id": pending_id,
                "waiting_since": hitl.get("ts"),
            }
            if detail:
                try:
                    s = datetime.fromisoformat(hitl["ts"].replace("Z", "+00:00"))
                    hitl_block["waiting_seconds"] = int(
                        (datetime.now(timezone.utc) - s).total_seconds()
                    )
                except Exception:
                    pass
                hitl_block["tool_call_id"] = hitl.get("tool_call_id")
            result["hitl_pending"] = hitl_block

    return result


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _aid(ctx) -> str:
    return ctx.obj.get("_agent_id", "") if ctx.obj else ""


def _sid(ctx) -> str:
    return ctx.obj.get("_session_id", "") if ctx.obj else ""


@click.group(name="agent", invoke_without_command=True)
@click.argument("agent_id", metavar="AGENT_ID")
@click.pass_context
def agent(ctx, agent_id):
    """Manage a single agent by ID.

    \b
    Examples:
      torana agent <UUID> get
      torana agent <UUID> publish
      torana agent <UUID> activate
      torana agent <UUID> session <SID> chat -m "hello"
      torana agent <UUID> session <SID> chat get
      torana agent <UUID> session <SID> chat get --last 3 --detail
      torana agent <UUID> session <SID> chat --respond --args '{"choice":"B"}'
      torana agent <UUID> session <SID> history
      torana agent <UUID> session <SID> hitl-respond
    """
    ctx.ensure_object(dict)
    ctx.obj["_agent_id"] = agent_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


# ── Nested session sub-group ────────────────────────────────────────────────

@agent.group(name="session", invoke_without_command=True)
@click.argument("session_id", metavar="SESSION_ID")
@click.pass_context
def agent_session(ctx, session_id):
    """Manage a specific session of this agent.

    \b
    Examples:
      torana agent <UUID> session <SID> get
      torana agent <UUID> session <SID> history
      torana agent <UUID> session <SID> hitl-respond
      torana agent <UUID> session <SID> cancel
    """
    ctx.ensure_object(dict)
    ctx.obj["_session_id"] = session_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


# ── A2A protocol sub-namespace (agent-scoped) ───────────────────────────────
#
# `torana agent <id> a2a <method>` — the A2A 1.0 protocol surface scoped to this
# agent. Verbs are the bare standard protocol method names (send / get-task /
# cancel / tasks / card) so the CLI reads 1:1 with the A2A spec. Living under the
# `a2a` sub-group means `cancel` etc. never collide with the agent's `stop` or
# `session <sid> cancel` — different namespace, no renames. Wire helpers live in
# torana_cli/client/a2a_rpc.py (single source of truth for the a2a-sdk wire rules).
# See docs/AGUI_AGENTS_REFACTOR.md.

def _fmt3(ctx):
    """Return (fmt, raw, fields) from the shared ctx, defaulting to text."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    return fmt, raw, fields


@agent.group(name="a2a")
@click.pass_context
def agent_a2a(ctx):
    """Drive the A2A 1.0 protocol surface for this agent.

    \b
    Bare standard protocol verbs (read 1:1 with the A2A spec):
      torana agent <ID> a2a card
      torana agent <ID> a2a send "Analyze CVE-2024-1234"
      torana agent <ID> a2a get-task <TASK_ID>
      torana agent <ID> a2a cancel <TASK_ID>
      torana agent <ID> a2a tasks --context <SESSION_ID>

    \b
    Notes:
      - These talk the standard A2A protocol; `cancel` is the A2A CancelTask
        (distinct from `agent <ID> stop` and `agent <ID> session <SID> cancel`).
      - Every call carries the A2A-Version: 1.0 header automatically.
    """


@agent_a2a.command(name="card")
@click.pass_context
def agent_a2a_card(ctx):
    """GET the Agent Card (A2A discovery) for this agent."""
    aid = _aid(ctx)
    fmt, raw, fields = _fmt3(ctx)
    client = _client(ctx)
    try:
        # The card is served at the ROOT well-known path (no /api/v1 prefix) — pass
        # a leading-slash absolute path so the client doesn't prepend /api/v1.
        data = client.get("/.well-known/agent-card.json", params={"agent_id": aid})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@agent_a2a.command(name="send")
@click.argument("text", metavar="TEXT")
@click.option("--context", "context_id", default=None,
              help="contextId (== session_id) to continue a conversation.")
@click.option("--task", "task_id", default=None,
              help="taskId to resume a paused (input-required) task.")
@click.option("--async", "return_immediately", is_flag=True, default=False,
              help="return_immediately: return a working handle without blocking.")
@click.pass_context
def agent_a2a_send(ctx, text, context_id, task_id, return_immediately):
    """SendMessage to this agent over A2A — returns the resulting Task.

    Always returns kind:"task" (always-Task policy). A trivial one-shot returns a
    Task already in TASK_STATE_COMPLETED; a paused turn returns input-required.
    """
    aid = _aid(ctx)
    fmt, raw, fields = _fmt3(ctx)
    params = {"message": user_message(text, context_id, task_id)}
    if return_immediately:
        params["configuration"] = {"returnImmediately": True}
    try:
        data = rpc_call(_client(ctx), aid, M_SEND, params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@agent_a2a.command(name="get-task")
@click.argument("task_id", metavar="TASK_ID")
@click.pass_context
def agent_a2a_get_task(ctx, task_id):
    """GetTask — read a Task back by id (state + message + artifacts)."""
    aid = _aid(ctx)
    fmt, raw, fields = _fmt3(ctx)
    try:
        data = rpc_call(_client(ctx), aid, M_GET, {"id": task_id})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@agent_a2a.command(name="cancel")
@click.argument("task_id", metavar="TASK_ID")
@click.pass_context
def agent_a2a_cancel(ctx, task_id):
    """CancelTask — request cancellation of an in-flight A2A task.

    This is the A2A protocol task-cancel. For session-level cancel use
    `agent <ID> session <SID> cancel`; for execution stop use `agent <ID> stop`.
    """
    aid = _aid(ctx)
    fmt, raw, fields = _fmt3(ctx)
    try:
        data = rpc_call(_client(ctx), aid, M_CANCEL, {"id": task_id})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@agent_a2a.command(name="tasks")
@click.option("--context", "context_id", default=None,
              help="contextId (== session_id) to list tasks for.")
@click.pass_context
def agent_a2a_tasks(ctx, context_id):
    """ListTasks — list this agent's A2A tasks (optionally for one conversation)."""
    aid = _aid(ctx)
    fmt, raw, fields = _fmt3(ctx)
    params = {}
    if context_id:
        params["contextId"] = context_id
    try:
        data = rpc_call(_client(ctx), aid, M_LIST, params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


# ── AG-UI / A2UI protocol sub-namespace (agent-scoped) ──────────────────────
#
# `torana agent <id> agui <verb>` — the AG-UI / A2UI surface scoped to this agent,
# symmetric with `agent <id> a2a <method>` (the A2A surface). A2A = talk to the
# agent; AG-UI = the rich-widget rendering contract. The catalog is the manifest
# of widgets the FE renderer supports; agents reference its component names (by
# name) when emitting A2UI updateComponents envelopes, and the backend rejects any
# name not in it. Customer-facing READ lives here; version/drift diagnostics live
# under `torana admin agui catalog`. See docs/AGUI_AGENTS_REFACTOR.md.

@agent.group(name="agui")
@click.pass_context
def agent_agui(ctx):
    """Inspect the AG-UI / A2UI rendering surface for this agent.

    \b
    AG-UI is the rich-widget protocol (distinct from A2A, which talks to the
    agent). The catalog is the contract of which UI widgets the FE renderer
    supports — agents reference its component names when emitting A2UI envelopes.

    \b
    Examples:
      torana agent <ID> agui catalog
      torana agent <ID> agui catalog --json
    """


@agent_agui.command(name="catalog")
@click.pass_context
def agent_agui_catalog(ctx):
    """Show the active A2UI catalog manifest (the widgets the FE renderer supports).

    \b
    The catalog is FE-owned and served by pantheon-agent-builder. Agents reference
    component names from it when emitting A2UI v0.9 updateComponents envelopes.
    For version/drift diagnostics use `torana admin agui catalog`.
    """
    fmt, raw, fields = _fmt3(ctx)
    client = _client(ctx)
    try:
        data = client.get("agui/catalog")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(
        data,
        fmt=fmt,
        raw=raw,
        fields=fields,
        columns=[
            ("version", "CATALOG VERSION", 16),
            ("catalogId", "CATALOG ID", 50),
            ("specVersion", "A2UI SPEC", 12),
        ],
    )


# ── Lifecycle commands (agent-scoped only) ──────────────────────────────────

@agent.command(name="get")
@click.pass_context
def agent_get(ctx):
    """Get details for a specific agent.

    \b
    Examples:
      torana agents list                      # find the id
      torana agent <AGENT_ID> get
      torana agent <AGENT_ID> get --json | jq '{name, state, model}'
    """
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agent.command(name="update")
@click.option("--name", default=None)
@click.option("--description", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def agent_update(ctx, name, description, input_file):
    """Update an agent."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if description:
        body["description"] = description

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"agents/{aid}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated agent: {aid}")


@agent.command(name="delete")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def agent_delete(ctx, yes):
    """Delete an agent."""
    aid = _aid(ctx)
    _confirm(f"Delete agent {aid}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"agents/{aid}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted agent: {aid}")


@agent.command(name="activate")
@click.pass_context
def agent_activate(ctx):
    """Activate an agent (make it available for chat)."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/activate/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Activated agent: {aid}")


@agent.command(name="deactivate")
@click.pass_context
def agent_deactivate(ctx):
    """Deactivate an agent."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/deactivate/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Deactivated agent: {aid}")


@agent.command(name="publish")
@click.pass_context
def agent_publish(ctx):
    """Publish an agent (make it visible to all users in the tenant)."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/publish/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Published agent: {aid}")


@agent.command(name="unpublish")
@click.pass_context
def agent_unpublish(ctx):
    """Unpublish an agent."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/unpublish/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Unpublished agent: {aid}")


@agent.command(name="new-version")
@click.pass_context
def agent_new_version(ctx):
    """Create a new version of the agent."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/new-version/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created new version of agent: {aid}")


@agent.command(name="versions")
@click.pass_context
def agent_versions(ctx):
    """List versions of an agent."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/versions/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agent.command(name="health")
@click.pass_context
def agent_health(ctx):
    """Check agent health status."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/health/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        if isinstance(data, dict):
            status = data.get("status", data.get("health", "unknown"))
            click.echo(f"Agent {aid}: {status}")
            for k, v in data.items():
                if k not in ("status", "health"):
                    click.echo(f"  {k}: {v}")
        else:
            click.echo(str(data))


# ── Chat & invocation commands ──────────────────────────────────────────────

@agent_session.group(name="chat", invoke_without_command=True)
@click.option("--message", "-m", default=None, help="Message to send to the agent.")
@click.option("--message-file", default=None, metavar="FILE",
              help="Read message from file (use '-' for stdin).")
@click.option("--respond", is_flag=True, default=False,
              help="Respond to the pending HITL checkpoint.")
@click.option("--rejected", is_flag=True, default=False, help="Reject the HITL checkpoint (default is approved).")
@click.option("--args", "respond_args", default=None,
              help="Modified args as JSON (e.g. '{\"choice\":\"B\"}').")
@click.option("--text", "respond_text", default=None,
              help="Plain text response (shorthand for ui_user_choice — equivalent to --args '{\"choice\":\"...\"}').")
@click.option("--comment", default=None, help="Optional comment for the HITL response.")
@click.pass_context
def agent_chat(ctx, message, message_file, respond, rejected,
               respond_args, respond_text, comment):
    """Send a message to an agent or respond to a HITL checkpoint.

    \b
    Examples:
      # Send a message
      torana agent <ID> session <SID> chat -m "proceed with the KEV watchlist rule"

    \b
      # View conversation history
      torana agent <ID> session <SID> chat get

    \b
      # Respond to a HITL checkpoint (approved by default)
      torana agent <ID> session <SID> chat --respond --text "Option B"
      torana agent <ID> session <SID> chat --respond --rejected
    """
    if ctx.invoked_subcommand is not None:
        return

    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    sid = ctx.obj.get("_session_id", "") if ctx.obj else ""

    # ── HITL respond mode ────────────────────────────────────────────────────
    if respond:

        # Fetch pending_checkpoint_id from the sessions endpoint (audit endpoint doesn't include it)
        checkpoint_id = None
        try:
            sess_list = client.get(f"agents/{aid}/sessions")
            sessions = sess_list if isinstance(sess_list, list) else sess_list.get("sessions", [])
            for s in sessions:
                if s.get("session_id") == sid:
                    checkpoint_id = s.get("pending_checkpoint_id")
                    break
        except APIError as e:
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return

        if checkpoint_id:
            # Use hitl-checkpoint-response
            body: dict = {"checkpoint_id": checkpoint_id, "approved": not rejected}
            # --text is shorthand for response_text (plain text choice)
            # --args is for structured modified_args JSON
            if respond_text:
                body["response_text"] = respond_text
            elif respond_args:
                try:
                    body["modified_args"] = json.loads(respond_args)
                except json.JSONDecodeError as exc:
                    click.echo(f"ERROR: --args must be valid JSON: {exc}", err=True)
                    sys.exit(2)
            if comment:
                body["comment"] = comment
            try:
                data = client.post(f"agents/{aid}/sessions/{sid}/hitl-checkpoint-response/", json=body)
            except APIError as e:
                handle_api_error(e)
                return
            except AuthError as e:
                handle_auth_error(e)
                return
        else:
            # Fall back to generic respond endpoint
            body = {"approved": not rejected}
            if respond_args:
                try:
                    body["modified_args"] = json.loads(respond_args)
                except json.JSONDecodeError as exc:
                    click.echo(f"ERROR: --args must be valid JSON: {exc}", err=True)
                    sys.exit(2)
            if comment:
                body["comment"] = comment
            try:
                data = client.post(f"agents/{aid}/sessions/{sid}/respond/", json=body)
            except APIError as e:
                handle_api_error(e)
                return
            except AuthError as e:
                handle_auth_error(e)
                return

        if fmt != "text":
            output(data, fmt=fmt)
        else:
            decision = "approved" if not rejected else "rejected"
            click.echo(f"HITL response submitted ({decision}). Agent is continuing...")
        return

    # ── Send message mode ────────────────────────────────────────────────────
    if not message and not message_file:
        click.echo(ctx.get_help())
        return

    # Resolve message content
    if message_file:
        if message_file == "-":
            message = click.get_text_stream("stdin").read().strip()
        else:
            from pathlib import Path
            message = Path(message_file).read_text().strip()

    body = {
        "messages": [{"type": "text", "content": message, "metadata": {"input_mode": "text"}}],
        "session_id": sid,
    }

    try:
        data = client.post(f"sessions/{sid}/chat", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        if isinstance(data, dict):
            response_text = (
                data.get("response")
                or data.get("content")
                or data.get("message")
                or data.get("text")
            )
            if response_text:
                click.echo(response_text)
            else:
                click.echo(json.dumps(data, indent=2, default=str))
        else:
            click.echo(str(data))

        click.echo()
        click.echo(f"[session: {sid}]")
        click.echo(f"Run `torana agent {aid} session {sid} chat get` to see status / HITL prompts.")


@agent_chat.command(name="get")
@click.option("--last", default=None, type=int, metavar="N",
              help="Show only the last N turns (default: all).")
@click.option("--detail", is_flag=True, default=False,
              help="Show detailed per-turn info (tokens, model, timing).")
@click.pass_context
def agent_chat_get(ctx, last, detail):
    """Show conversation history with live status and HITL awareness.

    \b
    Examples:
      torana agent <ID> session <SID> chat get
      torana agent <ID> session <SID> chat get --last 3
      torana agent <ID> session <SID> chat get --detail
      torana agent <ID> session <SID> chat get --json
    """
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    sid = ctx.obj.get("_session_id", "") if ctx.obj else ""

    try:
        hist = client.get(f"agents/{aid}/sessions/{sid}/history")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Fetch pending_checkpoint_id from the session GET (not in history response).
    pending_checkpoint_id = None
    try:
        sess_data = client.get(f"agents/{aid}/sessions/{sid}")
        sess = sess_data.get("session", sess_data)
        pending_checkpoint_id = sess.get("pending_checkpoint_id")
        session_status = sess.get("status", "unknown")
    except Exception:
        session_status = "unknown"

    # Convert history grouped format into the flat format _parse_session_messages expects.
    # Use turn_id as the otel_trace_id so the parser groups agent events to the right user turn.
    flat_messages = []
    for turn in hist.get("conversation", []):
        role = turn.get("role", "")
        turn_id = turn.get("turn_id", "")
        for msg in turn.get("messages", []):
            flat_msg = {
                "role": role,
                "message_type": msg.get("type", ""),
                "content": msg.get("content", ""),
                "timestamp": msg.get("timestamp") or turn.get("timestamp", ""),
                "turn_id": turn_id,
                "otel_trace_id": turn_id,
            }
            flat_messages.append(flat_msg)

    raw = {
        "messages": flat_messages,
        "trace_summary": [],
        "pending_checkpoint_id": pending_checkpoint_id,
        "session_status": session_status,
        "agent_id": aid,
        "session_id": sid,
    }

    parsed = _parse_session_messages(raw)

    if fmt == "json":
        result = _build_chat_get_json(parsed, detail=detail, last=last)
        click.echo(json.dumps(result, indent=2, default=str))
    else:
        _print_chat_get_text(parsed, detail=detail, last=last)


@agent.command(name="chat-stream")
@click.option("--session-id", required=True, help="Session ID to use or create.")
@click.option("--messages", required=True, help="JSON-formatted message list or file path.")
@click.option("--context", default=None, help="Optional context string.")
@click.option("--cache-context", default=None, help="Optional cache context string.")
@click.option("--preserve-session-name", is_flag=True, default=False)
@click.pass_context
def agent_chat_stream(ctx, session_id, messages, context, cache_context, preserve_session_name):
    """Send streaming chat messages to an agent."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    # Parse messages (could be JSON string or file)
    import json
    try:
        if messages.startswith('['):
            msg_list = json.loads(messages)
        else:
            from pathlib import Path
            msg_list = json.loads(Path(messages).read_text())
    except (json.JSONDecodeError, FileNotFoundError) as e:
        click.echo(f"ERROR: Failed to parse messages: {e}", err=True)
        import sys
        sys.exit(2)

    body = {"messages": msg_list, "session_id": session_id}
    if context:
        body["context"] = context
    if cache_context:
        body["cache_context"] = cache_context
    if preserve_session_name:
        body["preserve_session_name"] = preserve_session_name

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/chat/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent.command(name="steer")
@click.option("--session-id", required=True, help="Session ID to steer.")
@click.option("--message", "-m", required=True, help="Steering message.")
@click.pass_context
def agent_steer(ctx, session_id, message):
    """Send a steering message to redirect agent execution."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {"session_id": session_id, "message": message}

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/steer/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent.command(name="stop")
@click.option("--session-id", required=True, help="Session ID to stop.")
@click.pass_context
def agent_stop(ctx, session_id):
    """Stop an ongoing agent execution."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {"session_id": session_id}

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/stop/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent.command(name="invoke")
@click.option("--messages", required=True, help="JSON-formatted message list or file path.")
@click.option("--config", default=None, metavar="FILE", help="Optional agent config file.")
@click.option("--context", default=None, help="Optional context string.")
@click.pass_context
def agent_invoke(ctx, messages, config, context):
    """Invoke agent directly without session."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    # Parse messages (could be JSON string or file)
    import json
    try:
        if messages.startswith('['):
            msg_list = json.loads(messages)
        else:
            from pathlib import Path
            msg_list = json.loads(Path(messages).read_text())
    except (json.JSONDecodeError, FileNotFoundError) as e:
        click.echo(f"ERROR: Failed to parse messages: {e}", err=True)
        import sys
        sys.exit(2)

    body = {"messages": msg_list}
    if config:
        body["config"] = _load_input_file(config)
    if context:
        body["context"] = context

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/invoke/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent.command(name="invoke-stream")
@click.option("--messages", required=True, help="JSON-formatted message list or file path.")
@click.option("--config", default=None, metavar="FILE", help="Optional agent config file.")
@click.option("--context", default=None, help="Optional context string.")
@click.pass_context
def agent_invoke_stream(ctx, messages, config, context):
    """Invoke agent with streaming response."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    # Parse messages (could be JSON string or file)
    import json
    try:
        if messages.startswith('['):
            msg_list = json.loads(messages)
        else:
            from pathlib import Path
            msg_list = json.loads(Path(messages).read_text())
    except (json.JSONDecodeError, FileNotFoundError) as e:
        click.echo(f"ERROR: Failed to parse messages: {e}", err=True)
        import sys
        sys.exit(2)

    body = {"messages": msg_list}
    if config:
        body["config"] = _load_input_file(config)
    if context:
        body["context"] = context

    client = _client(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    try:
        events = []
        for event in client.post_stream(f"agents/{aid}/invoke/stream/", json=body):
            events.append(event)
            if fmt == "json":
                # Stream each event as a JSON line (jq-friendly).
                click.echo(json.dumps(event, default=str))
            else:
                _render_stream_event(event)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "json" and not events:
        click.echo("(no stream events received)")


def _render_stream_event(event) -> None:
    """Human-readable one-liner per SSE event for `invoke-stream`/chat text mode."""
    if not isinstance(event, dict):
        click.echo(str(event))
        return
    etype = event.get("type") or event.get("event") or ""
    content = event.get("content")
    if etype in ("tool_call_start", "tool_call_end", "tool_status"):
        tool = event.get("tool_name") or (content or {}).get("tool_name") if isinstance(content, dict) else event.get("tool_name")
        click.echo(click.style(f"  [tool] {etype}: {tool or ''}", fg="cyan"))
    elif etype in ("agent_message", "formatted_response", "message", "text"):
        # content may be a str, or a dict with a 'content'/'messages' payload
        text = content if isinstance(content, str) else None
        if isinstance(content, dict):
            text = content.get("content") or content.get("text")
        if text:
            click.echo(text)
    elif etype in ("agent_invocation_start",):
        click.echo(click.style(f"  [delegate] {event.get('agent_name','')}", fg="magenta"))
    elif etype in ("end_stream",):
        pass
    else:
        # unknown event — show compactly so nothing is silently dropped
        click.echo(click.style(f"  [{etype or 'event'}] {json.dumps(event, default=str)[:200]}", fg="yellow"))


@agent.command(name="readiness")
@click.pass_context
def agent_readiness(ctx):
    """Check invoke readiness status."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/invoke/status/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


# ── Tools management (agent-scoped) ─────────────────────────────────────────

@agent.command(name="tools")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", "page_size", default=None, type=int)
@click.pass_context
def agent_tools(ctx, page, page_size):
    """List tools attached to an agent."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/tools/", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@agent.command(name="agent-tools")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", "page_size", default=None, type=int)
@click.pass_context
def agent_agent_tools(ctx, page, page_size):
    """List sub-agent tools."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/agent-tools/", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@agent.command(name="delete-tool")
@click.option("--tool-id", required=True, help="Tool ID to delete.")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def agent_delete_tool(ctx, tool_id, yes):
    """Delete a tool from an agent."""
    aid = _aid(ctx)
    _confirm(f"Delete tool {tool_id} from agent {aid}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"agents/{aid}/tools/{tool_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted tool {tool_id} from agent {aid}.")


@agent.command(name="add-provider-tool")
@click.option("--provider-id", required=True, help="Provider ID to add.")
@click.pass_context
def agent_add_provider_tool(ctx, provider_id):
    """Add a provider tool to an agent."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {"provider_id": provider_id}

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/tools/provider/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Added provider tool {provider_id} to agent {aid}.")


@agent.command(name="add-api-group-tool")
@click.option("--api-group-id", required=True, help="API Group ID to add.")
@click.pass_context
def agent_add_api_group_tool(ctx, api_group_id):
    """Add an API group tool to an agent."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {"api_group_id": api_group_id}

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/tools/api-group/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Added API group tool {api_group_id} to agent {aid}.")


@agent.command(name="add-api-tool")
@click.option("--api-id", required=True, help="API ID to add.")
@click.pass_context
def agent_add_api_tool(ctx, api_id):
    """Add an API tool to an agent."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {"api_id": api_id}

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/tools/api/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Added API tool {api_id} to agent {aid}.")


# ── Maintenance & health (agent-scoped) ─────────────────────────────────────

@agent.command(name="drift")
@click.pass_context
def agent_drift(ctx):
    """Check configuration drift."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/drift/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agent.command(name="check-stale-tools")
@click.pass_context
def agent_check_stale_tools(ctx):
    """Check for stale tool references."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/stale-tools/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agent.command(name="reconcile")
@click.option("--dry-run", is_flag=True, default=False)
@click.option("--remove-stale", is_flag=True, default=False)
@click.pass_context
def agent_reconcile(ctx, dry_run, remove_stale):
    """Reconcile agent configuration."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    params = {}
    if dry_run:
        params["dry_run"] = True
    if remove_stale:
        params["remove_stale"] = True

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/reconcile/", json={}, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent.command(name="reload-agent")
@click.pass_context
def agent_reload_agent(ctx):
    """Reload agent configuration."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/reload/", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent.command(name="reload-from-source")
@click.pass_context
def agent_reload_from_source(ctx):
    """Reload agent from source file."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/reload-from-source/", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent.command(name="reconciliation-status")
@click.pass_context
def agent_reconciliation_status(ctx):
    """Get reconciliation status."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/reconciliation-status/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ── Compaction & settings (agent-scoped) ────────────────────────────────────

@agent.command(name="compaction-thresholds")
@click.option("--window-days", type=int, default=None)
@click.option("--window-hours", type=int, default=None)
@click.option("--window-minutes", type=int, default=None)
@click.option("--window-seconds", type=int, default=None)
@click.pass_context
def agent_compaction_thresholds(ctx, window_days, window_hours, window_minutes, window_seconds):
    """Get compaction thresholds."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    params = {}
    if window_days is not None:
        params["window_days"] = window_days
    if window_hours is not None:
        params["window_hours"] = window_hours
    if window_minutes is not None:
        params["window_minutes"] = window_minutes
    if window_seconds is not None:
        params["window_seconds"] = window_seconds

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/compaction-thresholds/", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent.command(name="set-compaction-thresholds")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with thresholds.")
@click.pass_context
def agent_set_compaction_thresholds(ctx, input_file):
    """Set compaction thresholds."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    if not input_file:
        click.echo("ERROR: --file is required.", err=True)
        import sys
        sys.exit(2)

    body = _load_input_file(input_file)

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/compaction-thresholds/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent.command(name="delete-compaction-thresholds")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def agent_delete_compaction_thresholds(ctx, yes):
    """Delete compaction thresholds."""
    aid = _aid(ctx)
    _confirm(f"Delete compaction thresholds for agent {aid}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"agents/{aid}/compaction-thresholds/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted compaction thresholds for agent {aid}.")


@agent.command(name="compaction-settings")
@click.pass_context
def agent_compaction_settings(ctx):
    """Get compaction settings."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/compaction-settings/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent.command(name="set-compaction-settings")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with settings.")
@click.pass_context
def agent_set_compaction_settings(ctx, input_file):
    """Set compaction settings."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    if not input_file:
        click.echo("ERROR: --file is required.", err=True)
        import sys
        sys.exit(2)

    body = _load_input_file(input_file)

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/compaction-settings/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent.command(name="delete-compaction-settings")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def agent_delete_compaction_settings(ctx, yes):
    """Delete compaction settings."""
    aid = _aid(ctx)
    _confirm(f"Delete compaction settings for agent {aid}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"agents/{aid}/compaction-settings/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted compaction settings for agent {aid}.")


# ── Sessions management (agent-scoped, not session-scoped) ───────────────────

@agent.command(name="create-session")
@click.option("--metadata", default=None, metavar="JSON", help="Session metadata as JSON string.")
@click.option("--anchor-type", default=None,
              help="Anchor type binding the session to an entity (e.g. build_v2_app, workspace_home, alert).")
@click.option("--anchor-id", default=None,
              help="Anchor id (the entity UUID; for workspace anchors this is the workspace id).")
@click.pass_context
def agent_create_session(ctx, metadata, anchor_type, anchor_id):
    """Create a new session for this agent.

    \b
    Anchored session (binds the chat to a workspace/entity, same as the FE):
      torana agent <ID> create-session --anchor-type build_v2_app --anchor-id <WORKSPACE_ID>
    """
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if metadata:
        import json
        try:
            body["metadata"] = json.loads(metadata)
        except json.JSONDecodeError:
            click.echo("ERROR: metadata must be valid JSON.", err=True)
            import sys
            sys.exit(2)

    if anchor_type or anchor_id:
        if not (anchor_type and anchor_id):
            click.echo("ERROR: --anchor-type and --anchor-id must be provided together.", err=True)
            import sys
            sys.exit(2)
        body["anchor"] = {"type": anchor_type, "id": anchor_id}

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/sessions/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        session_id = data.get('session_id') or data.get('id', 'unknown')
        click.echo(f"Created session: {session_id}")


@agent.command(name="list-sessions")
@click.option("--program-id", default=None)
@click.option("--workspace-id", default=None)
@click.option("--context-type", default=None)
@click.option("--exclude-program-sessions", is_flag=True, default=False)
@click.option("--limit", type=int, default=None)
@click.option("--offset", type=int, default=None)
@click.pass_context
def agent_list_sessions(ctx, program_id, workspace_id, context_type, exclude_program_sessions, limit, offset):
    """List sessions for this agent."""
    aid = _aid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    params = {}
    if program_id:
        params["program_id"] = program_id
    if workspace_id:
        params["workspace_id"] = workspace_id
    if context_type:
        params["context_type"] = context_type
    if exclude_program_sessions:
        params["exclude_program_sessions"] = True
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/sessions/", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


# ── Plans management (agent-level, not session-scoped) ──────────────────────

@agent.command(name="create-plan")
@click.option("--title", required=True, help="Plan title.")
@click.option("--plan-key-hint", required=True, help="Short hint for the plan key.")
@click.option("--actions", required=True, help="JSON actions list or file path.")
@click.option("--description", default=None)
@click.option("--execution-mode", default="hitl")
@click.option("--workspace-id", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with plan.")
@click.pass_context
def agent_create_plan(ctx, title, plan_key_hint, actions, description, execution_mode, workspace_id, input_file):
    """Create a plan (this will be moved to session-scoped in agent_session)."""
    # NOTE: This is a placeholder. The actual plans should be session-scoped.
    # For now, we keep this for compatibility but it should be under session.
    click.echo("ERROR: Plans should be created under a session.", err=True)
    import sys
    sys.exit(1)


# ── Session-scoped commands (under @agent_session) ──────────────────────────

@agent_session.command(name="get")
@click.pass_context
def agent_session_get(ctx):
    """Get details for a specific session."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/sessions/{sid}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ── Unified message-retrieval surface (TORANA_A2A.md § 3.4.6 / § 3.5.4 / § 3.5.6) ──
#
# Three verbs on the SINGULAR base /agent/<id>/session/<sid> (compose-not-overlay):
#   load           → GET .../                → TenantSessionLoad   (tenant: session+snapshot+render_meta)
#   messages       → GET .../messages        → MessageSnapshot     (public/external contract)
#   messages-admin → GET .../messages/admin  → AdminMessageSnapshot (super_admin, cross-tenant)
# RBAC-transparent: scope/content is decided by the backend from your token.

def _print_message_snapshot(snapshot: dict) -> None:
    """Render a MessageSnapshot as a per-message summary table (text mode)."""
    msgs = snapshot.get("messages", [])
    click.echo(f"{snapshot.get('type', 'MessagesSnapshot')}  "
               f"schemaVersion={snapshot.get('schemaVersion')}  messages={len(msgs)}")
    rows = []
    for m in msgs:
        tcs = m.get("toolCalls") or []
        widgets = ",".join(tc.get("name") or "?" for tc in tcs) if tcs else ""
        content = (m.get("content") or "").replace("\n", " ")
        rows.append({
            "id": m.get("id"),
            "role": m.get("role"),
            "content": content[:60] + ("…" if len(content) > 60 else ""),
            "widgets": widgets[:40],
        })
    output(
        {"items": rows, "total": len(rows)},
        fmt="text",
        columns=[
            ("id", "MSG ID", 16),
            ("role", "ROLE", 10),
            ("content", "CONTENT", 62),
            ("widgets", "WIDGETS", 40),
        ],
    )


@agent_session.command(name="messages")
@click.pass_context
def agent_session_messages(ctx):
    """Get the folded message snapshot for this session (PUBLIC contract).

    \b
    GET /agent/<id>/session/<sid>/messages → MessageSnapshot. The clean,
    externally-consumable payload. Scope is your login: a tenant user reads their
    own session. (For cross-tenant / diagnostics, use `messages-admin`.)
    """
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"agent/{aid}/session/{sid}/messages")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml") or raw:
        output(data, fmt=fmt, raw=raw, fields=fields)
    else:
        _print_message_snapshot(data)


@agent_session.command(name="messages-admin")
@click.pass_context
def agent_session_messages_admin(ctx):
    """Get the message snapshot + diagnostics for this session (SUPER-ADMIN).

    \b
    GET /agent/<id>/session/<sid>/messages/admin → AdminMessageSnapshot. Requires
    audit:read (super_admin); reads ANY session cross-tenant. The payload embeds the
    public MessageSnapshot whole (`.snapshot`) plus diagnostics/message_diagnostics.
    """
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"agent/{aid}/session/{sid}/messages/admin")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml") or raw:
        output(data, fmt=fmt, raw=raw, fields=fields)
    else:
        snap = data.get("snapshot", {})
        _print_message_snapshot(snap)
        diag = data.get("diagnostics") or {}
        mdiag = data.get("message_diagnostics") or {}
        click.echo(f"\ndiagnostics: trace_summary="
                   f"{len(diag.get('trace_summary') or []) if diag else 0} "
                   f"| message_diagnostics={len(mdiag)}")


@agent_session.command(name="load")
@click.pass_context
@click.option("--include", "include", default=None,
              help="Comma-separated kinds: turns,artifacts,thinking,hitl "
                   "(default turns,artifacts,hitl; thinking opt-in).")
def agent_session_load(ctx, include):
    """Get this session's chrome + interleaved conversation timeline (TENANT).

    \b
    GET /agent/<id>/session/<sid> → ConversationLoad. `{session, items[], include}`:
    `session` is the de-bloated chrome (name/state_tag/pending_checkpoint); `items[]`
    is ONE ordered interleaved timeline — kind='turn' (folded message) and
    kind='artifact' (settled A2UI surface) in stream order. `--include` selects which
    kinds. Scope is your login (owner-bound).
    """
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    path = f"agent/{aid}/session/{sid}"
    if include:
        path += f"?include={include}"
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml") or raw:
        output(data, fmt=fmt, raw=raw, fields=fields)
    else:
        sess = data.get("session", {})
        click.echo(f"session: {sess.get('name') or '(unnamed)'}"
                   f"  status={sess.get('status', '?')}"
                   f"  state_tag={(sess.get('state_tag') or '-')[:12]}"
                   f"  pending_checkpoint={sess.get('pending_checkpoint_id') or '-'}")
        click.echo(f"include: {','.join(data.get('include') or [])}")
        items = data.get("items") or []
        click.echo(f"\nitems: {len(items)}")
        for it in items:
            kind = it.get("kind")
            if kind == "turn":
                m = it.get("message", {})
                tc = m.get("toolCalls") or []
                content = (m.get("content") or "").replace("\n", " ")
                click.echo(f"  turn      {m.get('role',''):9} "
                           f"{('[' + str(len(tc)) + ' tools] ') if tc else ''}"
                           f"{content[:70]}")
            elif kind == "artifact":
                s = it.get("surface", {})
                root = (s.get("components") or {}).get("root", {})
                click.echo(f"  artifact  {s.get('surfaceId','')[:24]:24} "
                           f"root={root.get('type','?')}")


@agent_session.command(name="update")
@click.option("--name", default=None, help="New session name.")
@click.option("--description", default=None, help="New session description.")
@click.pass_context
def agent_session_update(ctx, name, description):
    """Update a session."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if name is not None:
        body["name"] = name
    if description is not None:
        body["description"] = description

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/sessions/{sid}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent_session.command(name="fork")
@click.option("--turn-id", default=None, help="Fork after this turn (inclusive).")
@click.option("--message-index", default=None, type=int, help="Alternative: fork including first N+1 messages.")
@click.option("--name", default=None, help="Optional name for forked session.")
@click.pass_context
def agent_session_fork(ctx, turn_id, message_index, name):
    """Fork a session."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if turn_id is not None:
        body["turn_id"] = turn_id
    if message_index is not None:
        body["message_index"] = message_index
    if name is not None:
        body["name"] = name

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/sessions/{sid}/fork/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent_session.command(name="lineage")
@click.pass_context
def agent_session_lineage(ctx):
    """Get session lineage."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/sessions/{sid}/lineage/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agent_session.command(name="history")
@click.option("--include-events", is_flag=True, default=False, help="Include event details.")
@click.pass_context
def agent_session_history(ctx, include_events):
    """Get session chat history."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if include_events:
        params["include_events"] = True

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/sessions/{sid}/history/", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agent_session.command(name="stream")
@click.option("--turn-id", required=True, help="Turn ID to stream.")
@click.option("--last-event-id", default=None)
@click.pass_context
def agent_session_stream(ctx, turn_id, last_event_id):
    """Stream session events."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    params = {"turn_id": turn_id}
    if last_event_id:
        params["last_event_id"] = last_event_id

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/sessions/{sid}/stream/", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent_session.command(name="tool-result")
@click.option("--tool-call-id", required=True)
@click.option("--result", required=True, help="Tool result as JSON string or file path.")
@click.option("--approved", is_flag=True, default=False)
@click.option("--response", default=None)
@click.option("--decision", default=None)
@click.pass_context
def agent_session_tool_result(ctx, tool_call_id, result, approved, response, decision):
    """Provide a tool result."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    # Parse result
    import json
    try:
        if result.startswith('{') or result.startswith('['):
            result_data = json.loads(result)
        else:
            from pathlib import Path
            result_data = json.loads(Path(result).read_text())
    except (json.JSONDecodeError, FileNotFoundError):
        result_data = result

    body = {"tool_call_id": tool_call_id, "result": result_data}
    if approved:
        body["approved"] = True
    if response:
        body["response"] = response
    if decision:
        body["decision"] = decision

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/sessions/{sid}/tool-result/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent_session.command(name="hitl-response")
@click.option("--type", "response_type", required=True, help="Response type.")
@click.option("--step-id", default=None)
@click.option("--tool-call-id", default=None)
@click.option("--approved", is_flag=True, default=False)
@click.option("--response", default=None)
@click.option("--decision", default=None)
@click.option("--modified-params", default=None, help="Modified params as JSON.")
@click.option("--comment", default=None)
@click.pass_context
def agent_session_hitl_response(ctx, response_type, step_id, tool_call_id, approved, response, decision, modified_params, comment):
    """Provide a HITL response."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {"type": response_type}
    if step_id:
        body["step_id"] = step_id
    if tool_call_id:
        body["tool_call_id"] = tool_call_id
    if approved:
        body["approved"] = True
    if response:
        body["response"] = response
    if decision:
        body["decision"] = decision
    if modified_params:
        import json
        body["modified_params"] = json.loads(modified_params)
    if comment:
        body["comment"] = comment

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/sessions/{sid}/hitl-response/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent_session.command(name="hitl-checkpoint-response")
@click.option("--checkpoint-id", required=True, help="Checkpoint ID.")
@click.option("--approved", is_flag=True, default=False, help="Approve the checkpoint.")
@click.option("--reason", default=None, help="Reason for decision.")
@click.option("--modified-args", default=None, help="Modified args as JSON.")
@click.option("--comment", default=None)
@click.pass_context
def agent_session_hitl_checkpoint_response(ctx, checkpoint_id, approved, reason, modified_args, comment):
    """Respond to a HITL checkpoint."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {"checkpoint_id": checkpoint_id, "approved": approved}
    if reason:
        body["reason"] = reason
    if modified_args:
        import json
        body["modified_args"] = json.loads(modified_args)
    if comment:
        body["comment"] = comment

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/sessions/{sid}/hitl-checkpoint-response/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent_session.command(name="cancel")
@click.pass_context
def agent_session_cancel(ctx):
    """Cancel a session."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/sessions/{sid}/cancel/", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent_session.command(name="chat-history")
@click.pass_context
def agent_session_chat_history(ctx):
    """Get session chat history."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/sessions/{sid}/chat/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent_session.command(name="hitl-respond")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with response.")
@click.option("--approved", is_flag=True, default=False)
@click.option("--rejected", is_flag=True, default=False)
@click.option("--reason", default=None)
@click.pass_context
def agent_session_hitl_respond(ctx, input_file, approved, rejected, reason):
    """Respond to a HITL prompt."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if approved:
        body["approved"] = True
    if rejected:
        body["approved"] = False
    if reason:
        body["reason"] = reason

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/sessions/{sid}/respond/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent_session.command(name="hitl-chain")
@click.option("--checkpoint-id", required=True, help="Checkpoint ID.")
@click.pass_context
def agent_session_hitl_chain(ctx, checkpoint_id):
    """Get HITL checkpoint chain."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/sessions/{sid}/hitl-chain/{checkpoint_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent_session.group(name="plan")
@click.pass_context
def agent_session_plan(ctx):
    """Manage plans for this session."""
    ctx.ensure_object(dict)


@agent_session_plan.command(name="create")
@click.option("--title", required=True, help="Plan title.")
@click.option("--plan-key-hint", required=True, help="Short hint for plan key.")
@click.option("--actions", required=True, help="Actions as JSON string or file path.")
@click.option("--description", default=None)
@click.option("--execution-mode", default="hitl")
@click.option("--workspace-id", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def agent_session_plan_create(ctx, title, plan_key_hint, actions, description, execution_mode, workspace_id, input_file):
    """Create a plan for this session."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    if input_file:
        body = _load_input_file(input_file)
    else:
        # Parse actions
        import json
        try:
            if actions.startswith('['):
                actions_list = json.loads(actions)
            else:
                from pathlib import Path
                actions_list = json.loads(Path(actions).read_text())
        except (json.JSONDecodeError, FileNotFoundError) as e:
            click.echo(f"ERROR: Failed to parse actions: {e}", err=True)
            import sys
            sys.exit(2)

        body = {
            "title": title,
            "plan_key_hint": plan_key_hint,
            "actions": actions_list,
        }
        if description:
            body["description"] = description
        if execution_mode:
            body["execution_mode"] = execution_mode
        if workspace_id:
            body["workspace_id"] = workspace_id

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/sessions/{sid}/plans/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        plan_id = data.get('id', 'unknown')
        click.echo(f"Created plan: {plan_id}")


@agent_session_plan.command(name="list")
@click.option("--status", default=None, help="Filter by plan status.")
@click.pass_context
def agent_session_plan_list(ctx, status):
    """List plans for this session."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if status:
        params["status"] = status

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/sessions/{sid}/plans/", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agent_session_plan.command(name="active")
@click.pass_context
def agent_session_plan_active(ctx):
    """Get active plan for this session."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/sessions/{sid}/plans/active/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent_session_plan.command(name="by-key")
@click.option("--plan-key", required=True, help="Plan key.")
@click.pass_context
def agent_session_plan_by_key(ctx, plan_key):
    """Get plan by key."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/sessions/{sid}/plans/key/{plan_key}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent_session_plan.command(name="get")
@click.option("--plan-id", required=True, help="Plan ID.")
@click.pass_context
def agent_session_plan_get(ctx, plan_id):
    """Get a specific plan."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/sessions/{sid}/plans/{plan_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent_session_plan.command(name="update-actions")
@click.option("--plan-id", required=True, help="Plan ID.")
@click.option("--actions", required=True, help="Actions as JSON string or file path.")
@click.pass_context
def agent_session_plan_update_actions(ctx, plan_id, actions):
    """Update plan actions."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    # Parse actions
    import json
    try:
        if actions.startswith('['):
            actions_list = json.loads(actions)
        else:
            from pathlib import Path
            actions_list = json.loads(Path(actions).read_text())
    except (json.JSONDecodeError, FileNotFoundError) as e:
        click.echo(f"ERROR: Failed to parse actions: {e}", err=True)
        import sys
        sys.exit(2)

    body = {"actions": actions_list}

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/sessions/{sid}/plans/{plan_id}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent_session_plan.command(name="move")
@click.option("--plan-id", required=True, help="Plan ID.")
@click.option("--target-workspace-id", required=True, help="Target workspace ID.")
@click.pass_context
def agent_session_plan_move(ctx, plan_id, target_workspace_id):
    """Move plan to another workspace."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {"target_workspace_id": target_workspace_id}

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/sessions/{sid}/plans/{plan_id}/move/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@agent_session_plan.command(name="set-status")
@click.option("--plan-id", required=True, help="Plan ID.")
@click.option("--status", required=True, help="New status.")
@click.option("--reason", default=None, help="Reason for status change.")
@click.pass_context
def agent_session_plan_set_status(ctx, plan_id, status, reason):
    """Set plan status."""
    aid = _aid(ctx)
    sid = _sid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {"status": status}
    if reason:
        body["reason"] = reason

    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/sessions/{sid}/plans/{plan_id}/status/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


# ── Nested work sub-group (async agent work) ────────────────────────────────
#
# `torana agent <ID> work ...` — submit long-running agent work, then poll for
# state + result. The async counterpart to the synchronous invoke: submit returns
# a work_id immediately (no held connection), and the run continues server-side
# through the Gemini stall + minutes-long tool chains without a 504.
# Backend: POST/GET /api/v1/agents/{id}/work (docs/ASYNC_AGENT_WORK_REQUIREMENT.md).

@agent.group(name="work", invoke_without_command=True)
@click.pass_context
def agent_work(ctx):
    """Async agent work — submit long-running runs, poll state + result.

    \b
    Examples:
      torana agent <UUID> work submit -m "Triage alert <ID>"
      torana agent <UUID> work submit -m "..." --wait
      torana agent <UUID> work get <WORK_ID>
      torana agent <UUID> work list --status running
      torana agent <UUID> work cancel <WORK_ID>
    """
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _build_invoke_body(message, input_file, workspace_id, timeout):
    """Assemble an InvokeRequest body from CLI options (shared invoke shape)."""
    if input_file:
        body = _load_input_file(input_file)
    elif message:
        body = {"messages": [{"role": "user", "content": message}]}
    else:
        raise click.UsageError("Provide -m/--message or --input-file.")
    if timeout is not None:
        cfg = dict(body.get("config") or {})
        cfg["timeout_seconds"] = timeout
        body["config"] = cfg
    if workspace_id:
        env = dict(body.get("envelope") or {})
        env["workspace_id"] = workspace_id
        body["envelope"] = env
    return body


@agent_work.command(name="submit")
@click.option("-m", "--message", default=None, help="User message for the agent.")
@click.option("--input-file", default=None,
              help="JSON file with a full InvokeRequest body (messages/config/context/envelope).")
@click.option("--workspace-id", default=None, help="Workspace id (into envelope.workspace_id).")
@click.option("--timeout", type=int, default=None,
              help="Per-run timeout in seconds (config.timeout_seconds).")
@click.option("--wait", is_flag=True, default=False,
              help="Poll until the work reaches a terminal state, then print the result.")
@click.option("--poll-interval", type=float, default=3.0, show_default=True,
              help="Seconds between polls when --wait is set.")
@click.option("--wait-timeout", type=int, default=1800, show_default=True,
              help="Max seconds to wait when --wait is set.")
@click.pass_context
def agent_work_submit(ctx, message, input_file, workspace_id, timeout, wait,
                      poll_interval, wait_timeout):
    """Submit async agent work → returns a work_id immediately (202).

    With --wait, polls until the run finishes and prints the final result.
    """
    aid = _aid(ctx)
    fmt, raw, fields = _fmt3(ctx)
    client = _client(ctx)
    try:
        body = _build_invoke_body(message, input_file, workspace_id, timeout)
    except click.UsageError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(2)
    try:
        submitted = client.post(f"agents/{aid}/work/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if not wait:
        output(submitted, fmt=fmt, raw=raw, fields=fields)
        return

    import time
    work_id = submitted.get("work_id")
    if not work_id:
        output(submitted, fmt=fmt, raw=raw, fields=fields)
        return
    deadline = time.monotonic() + wait_timeout
    terminal = {"succeeded", "failed", "cancelled"}
    last = submitted
    if fmt == "text":
        click.echo(f"Submitted work {work_id} — waiting for completion...", err=True)
    while time.monotonic() < deadline:
        try:
            last = client.get(f"agents/{aid}/work/{work_id}")
        except APIError as e:
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return
        st = (last or {}).get("status")
        if st in terminal:
            break
        if fmt == "text":
            click.echo(f"  … {st}", err=True)
        time.sleep(poll_interval)
    else:
        click.echo(f"Timed out after {wait_timeout}s waiting for work {work_id} "
                   f"(still {(last or {}).get('status')}).", err=True)
        sys.exit(1)
    output(last, fmt=fmt, raw=raw, fields=fields)


@agent_work.command(name="get")
@click.argument("work_id", metavar="WORK_ID")
@click.pass_context
def agent_work_get(ctx, work_id):
    """Get the state + result of a submitted work by id."""
    aid = _aid(ctx)
    fmt, raw, fields = _fmt3(ctx)
    client = _client(ctx)
    try:
        data = client.get(f"agents/{aid}/work/{work_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@agent_work.command(name="list")
@click.option("--status", default=None,
              help="Filter by status (queued|running|succeeded|failed|cancelled).")
@click.option("--limit", type=int, default=50, show_default=True)
@click.option("--offset", type=int, default=0, show_default=True)
@click.pass_context
def agent_work_list(ctx, status, limit, offset):
    """List this agent's work submissions (newest first)."""
    aid = _aid(ctx)
    fmt, raw, fields = _fmt3(ctx)
    client = _client(ctx)
    params = {"limit": limit, "offset": offset}
    if status:
        params["status"] = status
    try:
        data = client.get(f"agents/{aid}/work", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@agent_work.command(name="cancel")
@click.argument("work_id", metavar="WORK_ID")
@click.pass_context
def agent_work_cancel(ctx, work_id):
    """Request cooperative cancellation of a submitted work."""
    aid = _aid(ctx)
    fmt, raw, fields = _fmt3(ctx)
    client = _client(ctx)
    try:
        data = client.post(f"agents/{aid}/work/{work_id}/cancel/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)
