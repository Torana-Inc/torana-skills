"""torana viz — visualization service commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE
from torana_cli.output import output


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group()
def viz():
    """Visualization service commands.

    \b
    Examples:
      torana viz graph overview
      torana viz graph search --query "critical assets"
      torana viz rendering dashboard <DASHBOARD_ID>
    """


@viz.group(name="graph")
def viz_graph():
    """Entity relationship graph queries.

    \b
    Examples:
      torana viz graph overview
      torana viz graph search --query "critical assets"
      torana viz graph stats
    """


@viz_graph.command(name="overview")
@click.option("--workspace-id", default=None, help="Filter by workspace UUID.")
@click.pass_context
def graph_overview(ctx, workspace_id):
    """Get graph overview (node counts, relationship stats)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if workspace_id:
        params["workspace_id"] = workspace_id

    client = _client(ctx)
    try:
        data = client.get("/api/graph/overview/", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@viz_graph.command(name="search")
@click.option("--query", required=True, help="Search query.")
@click.option("--entity-type", default=None, help="Filter by entity type.")
@click.option("--workspace-id", default=None, help="Filter by workspace UUID.")
@click.pass_context
def graph_search(ctx, query, entity_type, workspace_id):
    """Search entities in the graph."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {"query": query}
    if entity_type:
        params["entity_type"] = entity_type
    if workspace_id:
        params["workspace_id"] = workspace_id

    client = _client(ctx)
    try:
        data = client.get("/api/graph/search/", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@viz_graph.command(name="stats")
@click.option("--workspace-id", default=None, help="Filter by workspace UUID.")
@click.pass_context
def graph_stats(ctx, workspace_id):
    """Get graph statistics."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    params = {}
    if workspace_id:
        params["workspace_id"] = workspace_id

    client = _client(ctx)
    try:
        data = client.get("/api/graph/stats/", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@viz_graph.command(name="entity-details")
@click.argument("entity_id", metavar="ENTITY_ID")
@click.option("--entity-type", default=None, help="Entity type.")
@click.pass_context
def graph_entity_details(ctx, entity_id, entity_type):
    """Get details for a specific graph entity."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if entity_type:
        params["entity_type"] = entity_type

    client = _client(ctx)
    try:
        data = client.get(f"/api/graph/entity-details/{entity_id}/", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@viz.group(name="rendering")
def viz_rendering():
    """Visualization rendering commands.

    \b
    Examples:
      torana viz rendering dashboard <DASHBOARD_ID>
      torana viz rendering widget <WIDGET_ID>
    """


@viz_rendering.command(name="dashboard")
@click.argument("dashboard_id", metavar="DASHBOARD_ID")
@click.option("--workspace-id", default=None, help="Workspace UUID for context.")
@click.pass_context
def rendering_dashboard(ctx, dashboard_id, workspace_id):
    """Render a dashboard (returns data for all widgets)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    params = {}
    if workspace_id:
        params["workspace_id"] = workspace_id

    client = _client(ctx)
    try:
        data = client.get(f"render/dashboard/{dashboard_id}/", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt if fmt != "text" else "json")


@viz_rendering.command(name="widget")
@click.argument("widget_id", metavar="WIDGET_ID")
@click.option("--workspace-id", default=None, help="Workspace UUID for context.")
@click.pass_context
def rendering_widget(ctx, widget_id, workspace_id):
    """Render a single widget."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    params = {}
    if workspace_id:
        params["workspace_id"] = workspace_id

    client = _client(ctx)
    try:
        data = client.get(f"render/widget/{widget_id}/", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt if fmt != "text" else "json")


@viz.command(name="entity-by-entity-id")
@click.argument("ENTITY_TYPE", metavar="ENTITY_TYPE")
@click.argument("ENTITY_ID", metavar="ENTITY_ID")
@click.option("--hops", "hops", type=int, default=1, help="Number of relationship hops to expand")
@click.option("--relationship-types", "relationship_types", default=None, help="Filter by specific relationship types")
@click.pass_context
def api_entity_by_entity_id(ctx, entity_type, entity_id, hops, relationship_types):
    """Entity-Centered Security Graph."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"api/graph/entity/{entity_type}/{entity_id}"
    params = {}
    if hops is not None:
        params["hops"] = hops
    if relationship_types is not None:
        params["relationship_types"] = relationship_types

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@viz.command(name="details")
@click.argument("ENTITY_TYPE", metavar="ENTITY_TYPE")
@click.argument("ENTITY_ID", metavar="ENTITY_ID")
@click.pass_context
def api_details(ctx, entity_type, entity_id):
    """Entity Detailed Information."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"api/graph/entity/{entity_type}/{entity_id}/details"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@viz.command(name="alert-by-alert-id")
@click.argument("ALERT_ID", metavar="ALERT_ID")
@click.pass_context
def api_alert_by_alert_id(ctx, alert_id):
    """Alert Context Graph."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"api/graph/alert/{alert_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@viz.command(name="entities")
@click.argument("ALERT_ID", metavar="ALERT_ID")
@click.pass_context
def api_entities(ctx, alert_id):
    """Alert Entity Summary."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"api/graph/alert/{alert_id}/entities"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@viz.command(name="widget-by-widget-id")
@click.argument("WIDGET_ID", metavar="WIDGET_ID")
@click.pass_context
def render_widget_by_widget_id(ctx, widget_id):
    """Render Security Widget."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"render/widget/{widget_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@viz.command(name="dashboard-by-dashboard-id")
@click.argument("DASHBOARD_ID", metavar="DASHBOARD_ID")
@click.pass_context
def render_dashboard_by_dashboard_id(ctx, dashboard_id):
    """Render Security Dashboard."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"render/dashboard/{dashboard_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)
