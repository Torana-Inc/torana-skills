"""torana api-groups — workflow framework API group commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 35),
    ("description", "DESCRIPTION", 50),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(name="api-groups")
def api_groups():
    """Manage workflow API groups.

    \b
    Examples:
      torana api-groups list
      torana api-groups get <UUID>
      torana api-groups create --name "Authentication APIs"
      torana api-groups delete <UUID> --yes
    """


@api_groups.command(name="list")
@click.option("--search", default=None, help="Search by name.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def api_groups_list(ctx, search, page, page_size):
    """List API groups."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if search:
        params["search"] = search

    client = _client(ctx)
    try:
        data = client.get("api-groups/", params=params)
        # ⛔ Third instance of the #28/CLI-55 envelope defect — see `apis list`. This
        # endpoint's key is "api_groups" (underscore), NOT the hyphenated route name, so a
        # fix that assumed the key matched the path would still print "No results."
        # Measured 2026-08-15: a 200 carrying 16 groups printed "No results."
        # ⚠️ Keep the "items"/"total" branch: other endpoints DO return that envelope.
        items = data.get("api_groups", data.get("items", [])) if isinstance(data, dict) else (
            data if isinstance(data, list) else [])
        total = data.get("total", len(items)) if isinstance(data, dict) else len(items)
        result = {"items": items, "total": total,
                  "page": page, "page_size": effective_page_size}
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@api_groups.command(name="get")
@click.argument("group_id", metavar="GROUP_ID")
@click.pass_context
def api_groups_get(ctx, group_id):
    """Get details for a specific API group."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"api-groups/{group_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@api_groups.command(name="create")
@click.option("--name", default=None)
@click.option("--description", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def api_groups_create(ctx, name, description, input_file):
    """Create a new API group."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if description:
        body["description"] = description

    if not body.get("name"):
        click.echo("ERROR: --name is required.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post("api-groups/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created API group: {data.get('id', 'unknown')}")


@api_groups.command(name="update")
@click.argument("group_id", metavar="GROUP_ID")
@click.option("--name", default=None)
@click.option("--description", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def api_groups_update(ctx, group_id, name, description, input_file):
    """Update an API group."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if description:
        body["description"] = description

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"api-groups/{group_id}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated API group: {group_id}")


@api_groups.command(name="delete")
@click.argument("group_id", metavar="GROUP_ID")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def api_groups_delete(ctx, group_id, yes):
    """Delete an API group."""
    _confirm(f"Delete API group {group_id}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"api-groups/{group_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted API group: {group_id}")


@api_groups.command(name="with-apis")
@click.argument("API_GROUP_ID", metavar="API_GROUP_ID")
@click.pass_context
def api_groups_with_apis(ctx, api_group_id):
    """Get Api Group With Apis."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"api-groups/{api_group_id}/with-apis"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@api_groups.command(name="apis-count")
@click.argument("API_GROUP_ID", metavar="API_GROUP_ID")
@click.pass_context
def api_groups_apis_count(ctx, api_group_id):
    """Get Api Group Apis Count."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"api-groups/{api_group_id}/apis-count"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)
