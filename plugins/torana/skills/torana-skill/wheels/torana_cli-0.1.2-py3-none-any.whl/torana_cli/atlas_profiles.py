"""torana atlas profiles | policy | kinds — builder profiles, platform policy and the kind registry.

Routes: pantheon-knowledge `src/api/v1/atlas_profiles.py` (`/atlas/profiles*`, `/atlas/policy*`) and
`atlas.py` (`/atlas/kinds*`). Reads follow the caller (a tenant sees its own figures); writes and the
platform-line reads (`compare`, `policy`) are super-admin (`TORANA_PROFILE=SA`) plus atlas:admin.

Spec: pantheon-knowledge/docs/design/BUILDER_PROFILES.md § 3.4.1; PHASE_1_PLAN.md S14·C1.
"""

import json

import click

from torana_cli.atlas import MAX_PAGE_SIZE, _call, _client, _fmt, _params
from torana_cli.confirm import confirm as _confirm
from torana_cli.output import output
from torana_cli.rules import _load_input_file

TIERS = ["hot", "warm", "cold", "*"]
USES = ["build", "answer"]


def _bare_help(ctx):
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _tenant(help_text="Another tenant's view (SA only)."):
    return click.option("--tenant", default=None, help=help_text)


def _done(ctx, data, line):
    """Text: one confirming line; JSON: the server's body (a 204 delete has none)."""
    fmt, _, _ = _fmt(ctx)
    if fmt == "text" or data in (None, {}):
        click.echo(line)
    else:
        output(data, fmt=fmt)


# ---------------------------------------------------------------------------
# torana atlas profiles
# ---------------------------------------------------------------------------

@click.group(name="profiles", invoke_without_command=True)
@click.pass_context
def atlas_profiles(ctx):
    """Builder profiles: the named recipes (model, bounds, prompt) a node build or an answer runs with.

    Reads need atlas:read. create, update, delete, assignments set|delete, compare and the policy group
    are SA only (TORANA_PROFILE=SA). A tenant sees figures for its own runs, never the platform's spec.

    \b
    Examples:
      torana atlas profiles list
      torana atlas profiles show platform-default
      torana atlas profiles assignments list
      torana atlas profiles effective --node code/acme/api
      torana atlas profiles drift --reason profile
      torana atlas profiles spend --json
    """
    _bare_help(ctx)


@atlas_profiles.command(name="list")
@click.option("--use", type=click.Choice(USES), default=None, help="Only profiles for this use.")
@_tenant("Figures for another tenant (SA only).")
@click.option("--page", type=click.IntRange(min=1), default=1, show_default=True)
@click.option("--page-size", type=click.IntRange(1, MAX_PAGE_SIZE), default=50, show_default=True)
@click.pass_context
def atlas_profiles_list(ctx, use, tenant, page, page_size):
    """List profiles with 30-day runs, cost, golden rate and assignment count.

    \b
    Examples:
      torana atlas profiles list
      torana atlas profiles list --use answer --json
    """
    fmt, raw, fields = _fmt(ctx)
    data = _call(_client(ctx).get, "atlas/profiles",
                 params=_params(use=use, tenant=tenant, page=page, page_size=page_size))
    output(data, fmt=fmt, raw=raw, fields=fields, columns=[
        ("name", "NAME", 28), ("use", "USE", 7), ("revision", "REV", 4), ("builtin", "BUILTIN", 7),
        ("assignments", "ASSIGNED", 8), ("runs_30d", "RUNS 30D", 8), ("cost_30d", "COST 30D", 9),
        ("golden_rate_30d", "GOLDEN", 7),
    ])


@atlas_profiles.command(name="show")
@click.argument("name", metavar="NAME")
@_tenant("Figures for another tenant (SA only).")
@click.pass_context
def atlas_profiles_show(ctx, name, tenant):
    """Show one profile: description, spec (SA), revision, figures and where it is assigned.

    \b
    Examples:
      torana atlas profiles show platform-default
      TORANA_PROFILE=SA torana atlas profiles show platform-default --json
    """
    fmt, raw, fields = _fmt(ctx)
    output(_call(_client(ctx).get, f"atlas/profiles/{name}", params=_params(tenant=tenant) or None),
           fmt=fmt, raw=raw, fields=fields)


@atlas_profiles.command(name="create")
@click.option("--name", required=True, help="Profile name (unique).")
@click.option("--description", required=True, help="What the profile is for (1-2000 chars).")
@click.option("--use", type=click.Choice(USES), default="build", show_default=True)
@click.option("--file", "spec_file", required=True, metavar="FILE",
              help="JSON or YAML file holding the spec (model, bounds, prompt …); '-' reads stdin.")
@click.pass_context
def atlas_profiles_create(ctx, name, description, use, spec_file):
    """SA only. Create a profile from a spec file (needs atlas:admin). A new profile runs nowhere until assigned.

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas profiles create --name cheap-warm --description "Sonnet for warm nodes" --file spec.yaml
    """
    fmt, _, _ = _fmt(ctx)
    body = {"name": name, "description": description, "use": use, "spec": _load_input_file(spec_file)}
    output(_call(_client(ctx).post, "atlas/profiles", json=body), fmt=fmt)


@atlas_profiles.command(name="update")
@click.argument("name", metavar="NAME")
@click.option("--revision", type=click.IntRange(min=0), required=True,
              help="The revision you read (`profiles show`); a stale one is refused.")
@click.option("--description", default=None, help="New description.")
@click.option("--file", "spec_file", default=None, metavar="FILE", help="New spec (JSON or YAML; '-' reads stdin).")
@click.pass_context
def atlas_profiles_update(ctx, name, revision, description, spec_file):
    """SA only. Change a profile's description or spec (needs atlas:admin). Creates the next revision.

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas profiles update cheap-warm --revision 1 --file spec.yaml
    """
    fmt, _, _ = _fmt(ctx)
    if description is None and not spec_file:
        raise click.UsageError("send --description and/or --file")
    body = _params(revision=revision, description=description)
    body["revision"] = revision
    if spec_file:
        body["spec"] = _load_input_file(spec_file)
    output(_call(_client(ctx).put, f"atlas/profiles/{name}", json=body), fmt=fmt)


@atlas_profiles.command(name="delete")
@click.argument("name", metavar="NAME")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip the confirmation.")
@click.pass_context
def atlas_profiles_delete(ctx, name, yes):
    """SA only. Delete a profile (needs atlas:admin). Refused while it is assigned.

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas profiles delete cheap-warm --yes
    """
    _confirm(f"Delete profile {name}?", yes=yes)
    data = _call(_client(ctx).delete, f"atlas/profiles/{name}")
    _done(ctx, data, f"deleted profile {name}")


# --- assignments ---------------------------------------------------------------

@atlas_profiles.group(name="assignments", invoke_without_command=True)
@click.pass_context
def atlas_profiles_assignments(ctx):
    """Which profile runs for which (template, tier): platform rows, tenant rows and the resolved grid.

    \b
    Examples:
      torana atlas profiles assignments list
      TORANA_PROFILE=SA torana atlas profiles assignments set --scope platform --template repository --tier warm --profile cheap-warm
    """
    _bare_help(ctx)


@atlas_profiles_assignments.command(name="list")
@click.option("--use", type=click.Choice(USES), default="build", show_default=True)
@_tenant("Another tenant's rows (SA only).")
@click.pass_context
def atlas_profiles_assignments_list(ctx, use, tenant):
    """Show the platform and tenant assignment rows, and the grid (template x tier → profile) they resolve to.

    \b
    Examples:
      torana atlas profiles assignments list
      torana atlas profiles assignments list --use answer --json
    """
    fmt, raw, fields = _fmt(ctx)
    data = _call(_client(ctx).get, "atlas/profiles/assignments", params=_params(use=use, tenant=tenant))
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt, raw=raw, fields=fields)
        return
    row_cols = [("id", "ID", 36), ("template", "TEMPLATE", 14), ("tier", "TIER", 5), ("profile", "PROFILE", 26),
                ("updated_by", "BY", 22)]
    for title, key, cols in (
            ("platform", "platform", row_cols), ("tenant", "tenant", row_cols),
            ("grid (resolved)", "grid", [("template", "TEMPLATE", 14), ("tier", "TIER", 5), ("name", "PROFILE", 26),
                                         ("revision", "REV", 4), ("source", "SOURCE", 10), ("rung", "RUNG", 22)])):
        click.echo(f"\n{title}")
        output({"items": data.get(key) or [], "total": len(data.get(key) or [])}, fmt=fmt, columns=cols,
               pagination_hint=False)


@atlas_profiles_assignments.command(name="set")
@click.option("--profile", required=True, help="The profile to assign.")
@click.option("--scope", type=click.Choice(["platform", "tenant"]), required=True)
@click.option("--tenant", "tenant_id", default=None, help="The (enrolled) tenant, when --scope tenant.")
@click.option("--template", default="*", show_default=True, help="Node template, or * for all.")
@click.option("--tier", type=click.Choice(TIERS), default="*", show_default=True)
@click.option("--use", type=click.Choice(USES), default="build", show_default=True,
              help="An answer assignment is always template * and tier *.")
@click.pass_context
def atlas_profiles_assignments_set(ctx, profile, scope, tenant_id, template, tier, use):
    """SA only. Assign a profile to (template, tier) at platform or tenant scope (needs atlas:admin). Replaces the row there.

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas profiles assignments set --scope platform --template repository --tier warm --profile cheap-warm
      TORANA_PROFILE=SA torana atlas profiles assignments set --scope tenant --tenant <TENANT_ID> --profile platform-default
    """
    fmt, _, _ = _fmt(ctx)
    if scope == "tenant" and not tenant_id:
        raise click.UsageError("--scope tenant needs --tenant")
    body = {"use": use, "scope": scope, "template": template, "tier": tier, "profile": profile}
    if tenant_id:
        body["tenant_id"] = tenant_id
    output(_call(_client(ctx).put, "atlas/profiles/assignments", json=body), fmt=fmt)


@atlas_profiles_assignments.command(name="delete")
@click.argument("assignment_id", metavar="ASSIGNMENT_ID")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip the confirmation.")
@click.pass_context
def atlas_profiles_assignments_delete(ctx, assignment_id, yes):
    """SA only. Delete one assignment row (needs atlas:admin); the next rung of the ladder applies.

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas profiles assignments delete <ASSIGNMENT_ID> --yes
    """
    _confirm(f"Delete assignment {assignment_id}?", yes=yes)
    data = _call(_client(ctx).delete, f"atlas/profiles/assignments/{assignment_id}")
    _done(ctx, data, f"deleted assignment {assignment_id}")


# --- effective / drift / compare / spend ------------------------------------------

@atlas_profiles.command(name="effective")
@click.option("--node", "node_path", default=None, metavar="PATH", help="Resolve for this node (its template and tier).")
@click.option("--template", default=None, help="Or give the template …")
@click.option("--tier", type=click.Choice(["hot", "warm", "cold"]), default=None, help="… and the tier.")
@click.option("--use", type=click.Choice(USES), default="build", show_default=True)
@_tenant("Resolve for another tenant (SA only).")
@click.pass_context
def atlas_profiles_effective(ctx, node_path, template, tier, use, tenant):
    """Which profile a build would run with, and which rung of the ladder chose it.

    \b
    Examples:
      torana atlas profiles effective --node code/acme/api
      torana atlas profiles effective --template repository --tier warm --json
      torana atlas profiles effective --use answer
    """
    fmt, raw, fields = _fmt(ctx)
    data = _call(_client(ctx).get, "atlas/profiles/effective",
                 params=_params(node=node_path, template=template, tier=tier, use=use, tenant=tenant))
    output(data, fmt=fmt, raw=raw, fields=fields)


@atlas_profiles.command(name="drift")
@click.option("--reason", type=click.Choice(["rules", "profile", "tier", "before_profiles"]), default=None,
              help="Only nodes whose last build differs for this reason.")
@_tenant("Another tenant's nodes (SA only).")
@click.option("--page", type=click.IntRange(min=1), default=1, show_default=True)
@click.option("--page-size", type=click.IntRange(1, MAX_PAGE_SIZE), default=50, show_default=True)
@click.pass_context
def atlas_profiles_drift(ctx, reason, tenant, page, page_size):
    """Nodes whose last build used a different profile than the one that would run now (candidates to rebuild).

    \b
    Examples:
      torana atlas profiles drift
      torana atlas profiles drift --reason profile --json
    """
    fmt, raw, fields = _fmt(ctx)
    data = _call(_client(ctx).get, "atlas/profiles/drift",
                 params=_params(reason=reason, tenant=tenant, page=page, page_size=page_size))
    output(data, fmt=fmt, raw=raw, fields=fields)


@atlas_profiles.command(name="compare")
@click.option("--b", "profile_b", required=True, metavar="PROFILE", help="The profile to compare against.")
@click.option("--a", "profile_a", default=None, metavar="PROFILE", help="The baseline (default: what runs now).")
@click.option("--node", "node_path", default=None, metavar="PATH", help="Compare on this node's recorded runs.")
@_tenant("Compare on another tenant (SA only).")
@click.pass_context
def atlas_profiles_compare(ctx, profile_b, profile_a, node_path, tenant):
    """SA only. Compare two profiles' recorded runs: cost, golden rate, failures (needs atlas:admin).

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas profiles compare --b cheap-warm
      TORANA_PROFILE=SA torana atlas profiles compare --a platform-default --b cheap-warm --node code/acme/api
    """
    fmt, raw, fields = _fmt(ctx)
    data = _call(_client(ctx).get, "atlas/profiles/compare",
                 params=_params(b=profile_b, a=profile_a, node=node_path, tenant=tenant))
    output(data, fmt=fmt, raw=raw, fields=fields)


@atlas_profiles.command(name="spend")
@_tenant("Another tenant's spend (SA only).")
@click.option("--since", default=None, help="Window start: an ISO time (default: the server's).")
@click.pass_context
def atlas_profiles_spend(ctx, tenant, since):
    """Spend per profile; trials and the platform line are visible to a super-admin only.

    \b
    Examples:
      torana atlas profiles spend
      TORANA_PROFILE=SA torana atlas profiles spend --tenant <TENANT_ID> --json
    """
    fmt, raw, fields = _fmt(ctx)
    data = _call(_client(ctx).get, "atlas/profiles/spend", params=_params(tenant=tenant, since=since) or None)
    output(data, fmt=fmt, raw=raw, fields=fields)


# --- bulk rebuild and its batches -------------------------------------------------

@atlas_profiles.command(name="rebuild")
@click.option("--tenant", "tenant_id", required=True, help="The (enrolled) tenant whose nodes to rebuild.")
@click.option("--template", default=None, help="Only nodes of this template, e.g. repository.")
@click.option("--tier", type=click.Choice(["hot", "warm", "cold"]), default=None, help="Only nodes of this tier.")
@click.option("--profile", "profile", default=None, metavar="NAME", help="Pin every node to this profile (or use --effective).")
@click.option("--effective", is_flag=True, default=False, help="Rebuild the nodes that drifted from the profile that applies now.")
@click.option("--trial", is_flag=True, default=False, help="Run --profile as a trial (results stay out of the tenant's view).")
@click.option("--include-tier-drift", "include_tier_drift", is_flag=True, default=False,
              help="With --effective: also nodes whose tier changed since their last build.")
@click.option("--apply", "apply_", is_flag=True, default=False,
              help="Execute the rebuild. Without it: only the plan (dry run, writes nothing).")
@click.option("--count", type=click.IntRange(min=1), default=None,
              help="With --apply: the plan's node count (the batch is refused, 409 plan_changed, if it moved).")
@click.option("--max-usd", "max_usd", type=click.FloatRange(min=0, min_open=True), default=None,
              help="With --apply: the cap on the whole batch in USD; at least the plan's min_cap_usd (the larger of expected_usd and "
                   "the biggest per-node cost cap: below it 422 cap_below_node_reservation).")
@click.option("--label", default=None, help="With --apply: a short name for the batch (60 chars).")
@click.pass_context
def atlas_profiles_rebuild(ctx, tenant_id, template, tier, profile, effective, trial, include_tier_drift, apply_,
                           count, max_usd, label):
    """SA only. Bulk-rebuild a tenant's nodes behind a plan (needs atlas:admin). Dry run unless --apply.

    Step 1 (no --apply) prints the plan: nodes, count, ceiling_usd, expected_usd, min_cap_usd, platform budget left, days.
    Step 2 repeats the SAME filters with --apply --count <plan count> --max-usd <cap >= min_cap_usd> (each build reserves its
    profile's whole cost cap against the batch cap, so a smaller cap could never start a build). It pins
    every node in one go and returns the batch id (follow it: `profiles batches get`). Spend counts on the
    platform line, and the batch stops at --max-usd. Repeating step 2 returns the open batch (already_open).

    \b
    Examples:
      TORANA_PROFILE=SA torana --act-as-tenant <TENANT_ID> --act-as-reason "<why>" atlas profiles rebuild --tenant <TENANT_ID> --template repository --effective
      TORANA_PROFILE=SA torana --act-as-tenant <TENANT_ID> --act-as-reason "<why>" atlas profiles rebuild --tenant <TENANT_ID> --template repository --effective --apply --count 12 --max-usd 30 --label drift-fix
    """
    fmt, _, _ = _fmt(ctx)
    if bool(profile) == bool(effective):
        raise click.UsageError("send exactly one of --profile NAME or --effective")
    if trial and not profile:
        raise click.UsageError("--trial runs a named profile: add --profile NAME")
    filters = _params(template=template, tier=tier, profile=profile, effective=effective, trial=trial,
                      include_tier_drift=include_tier_drift)
    if not apply_:
        if count is not None or max_usd is not None or label:
            raise click.UsageError("--count, --max-usd and --label go with --apply")
        body = {"tenant": tenant_id, "templates": [], "rebuild": {**filters, "tenant": tenant_id}}
        output(_call(_client(ctx).post, "atlas/plan", json=body), fmt=fmt)
        return
    if count is None or max_usd is None:
        raise click.UsageError("--apply needs --count and --max-usd from the plan: run without --apply first")
    body = {**filters, "tenant": tenant_id, "count": count, "max_total_usd": max_usd}
    if label:
        body["label"] = label
    data = _call(_client(ctx).post, "atlas/profiles/rebuild", json=body)
    if fmt == "text" and isinstance(data, dict) and data.get("batch_id"):
        click.echo(f"batch {data['batch_id']} {data.get('state')}: {data.get('count')} node(s), "
                   f"{len(data.get('skipped') or [])} skipped (follow it: torana atlas profiles batches get {data['batch_id']})")
        return
    output(data, fmt=fmt)


@atlas_profiles.group(name="batches", invoke_without_command=True)
@click.pass_context
def atlas_profiles_batches(ctx):
    """SA only. Bulk-rebuild batches: state, node count, spend against the cap. `get` follows one; `cancel` stops it.

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas profiles batches list
      TORANA_PROFILE=SA torana atlas profiles batches get <BATCH_ID>
      TORANA_PROFILE=SA torana atlas profiles batches cancel <BATCH_ID> --yes
    """
    _bare_help(ctx)


@atlas_profiles_batches.command(name="list")
@_tenant("Only this tenant's batches.")
@click.pass_context
def atlas_profiles_batches_list(ctx, tenant):
    """SA only. List batches (needs atlas:admin).

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas profiles batches list
      TORANA_PROFILE=SA torana atlas profiles batches list --tenant <TENANT_ID> --json
    """
    fmt, raw, fields = _fmt(ctx)
    data = _call(_client(ctx).get, "atlas/profiles/batches", params=_params(tenant=tenant) or None)
    output(data, fmt=fmt, raw=raw, fields=fields, columns=[
        ("id", "ID", 36), ("state", "STATE", 9), ("label", "LABEL", 16), ("node_count", "NODES", 5),
        ("cap_usd", "CAP USD", 8), ("expected_usd", "EXPECTED", 8), ("spent_usd", "SPENT", 8),
    ])


@atlas_profiles_batches.command(name="get")
@click.argument("batch_id", metavar="BATCH_ID")
@click.pass_context
def atlas_profiles_batches_get(ctx, batch_id):
    """SA only. One batch: state, filters, node counts, spend against the cap (needs atlas:admin).

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas profiles batches get <BATCH_ID>
    """
    fmt, raw, fields = _fmt(ctx)
    output(_call(_client(ctx).get, f"atlas/profiles/batches/{batch_id}"), fmt=fmt, raw=raw, fields=fields)


@atlas_profiles_batches.command(name="cancel")
@click.argument("batch_id", metavar="BATCH_ID")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip the confirmation.")
@click.pass_context
def atlas_profiles_batches_cancel(ctx, batch_id, yes):
    """SA only. Cancel a batch (needs atlas:admin): pins not yet run are cleared; a build in flight finishes.

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas profiles batches cancel <BATCH_ID> --yes
    """
    fmt, _, _ = _fmt(ctx)
    _confirm(f"Cancel batch {batch_id}?", yes=yes)
    output(_call(_client(ctx).post, f"atlas/profiles/batches/{batch_id}/cancel"), fmt=fmt)


# ---------------------------------------------------------------------------
# torana atlas policy
# ---------------------------------------------------------------------------

@click.group(name="policy", invoke_without_command=True)
@click.pass_context
def atlas_policy(ctx):
    """SA only. Atlas policy keys: the platform's limits and switches (budgets, allowed models, bounds …).

    A key resolves tenant row → platform row → code default. `set` writes a row; `reset` deletes it.
    Every command needs a super-admin of the bootstrap tenant (TORANA_PROFILE=SA) plus atlas:admin.

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas policy list
      TORANA_PROFILE=SA torana atlas policy get builder.allowed_models
      TORANA_PROFILE=SA torana atlas policy set selection.source_gone_confirmations --value 3
      TORANA_PROFILE=SA torana atlas policy reset selection.source_gone_confirmations
    """
    _bare_help(ctx)


@atlas_policy.command(name="list")
@_tenant("Resolve for this tenant (default: the platform).")
@click.pass_context
def atlas_policy_list(ctx, tenant):
    """SA only. Every policy key: effective value, where it came from, its default and its revision.

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas policy list
      TORANA_PROFILE=SA torana atlas policy list --tenant <TENANT_ID> --json
    """
    fmt, raw, fields = _fmt(ctx)
    data = _call(_client(ctx).get, "atlas/policy", params=_params(tenant=tenant) or None)
    output(data, fmt=fmt, raw=raw, fields=fields, columns=[
        ("key", "KEY", 40), ("value", "VALUE", 24), ("source", "SOURCE", 8), ("default", "DEFAULT", 16),
        ("revision", "REV", 4),
    ])


@atlas_policy.command(name="get")
@click.argument("key", metavar="KEY")
@_tenant("Resolve for this tenant (default: the platform).")
@click.pass_context
def atlas_policy_get(ctx, key, tenant):
    """SA only. One policy key with every row that sets it (platform, tenant, per template).

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas policy get builder.allowed_models
    """
    fmt, raw, fields = _fmt(ctx)
    data = _call(_client(ctx).get, "atlas/policy", params=_params(tenant=tenant) or None)
    match = next((i for i in (data or {}).get("items", []) if i.get("key") == key), None)
    if match is None:
        click.echo(f"no policy key {key} (list them: torana atlas policy list)", err=True)
        raise SystemExit(3)
    output(match, fmt=fmt, raw=raw, fields=fields)


def _parse_value(text):
    """`--value` is JSON (`3`, `true`, `"x"`, `["a","b"]`, `{"k":1}`); anything that is not JSON is a string."""
    try:
        return json.loads(text)
    except ValueError:
        return text


@atlas_policy.command(name="set")
@click.argument("key", metavar="KEY")
@click.option("--value", required=True, help="The new value as JSON (3, true, '[\"a\",\"b\"]', '{\"k\":1}').")
@click.option("--scope", type=click.Choice(["platform", "tenant"]), default="platform", show_default=True)
@click.option("--tenant", "tenant_id", default=None, help="The tenant, when --scope tenant (only keys that allow a tenant row).")
@click.option("--template", default="*", show_default=True, help="Only for templated keys: the node template.")
@click.option("--revision", type=click.IntRange(min=0), default=None,
              help="The revision you read; a stale one is refused (omit to create the first row).")
@click.pass_context
def atlas_policy_set(ctx, key, value, scope, tenant_id, template, revision):
    """SA only. Set a policy key (needs atlas:admin). Narrowing a value that a live profile uses is refused.

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas policy set selection.source_gone_confirmations --value 3
      TORANA_PROFILE=SA torana atlas policy set builder.allowed_models --value '["claude-sonnet-5-5"]' --revision 2
    """
    fmt, _, _ = _fmt(ctx)
    if scope == "tenant" and not tenant_id:
        raise click.UsageError("--scope tenant needs --tenant")
    body = {"scope": scope, "template": template, "value": _parse_value(value)}
    if tenant_id:
        body["tenant_id"] = tenant_id
    if revision is not None:
        body["revision"] = revision
    output(_call(_client(ctx).put, f"atlas/policy/{key}", json=body), fmt=fmt)


@atlas_policy.command(name="reset")
@click.argument("key", metavar="KEY")
@click.option("--scope", type=click.Choice(["platform", "tenant"]), default="platform", show_default=True)
@click.option("--tenant", "tenant_id", default=None, help="The tenant, when --scope tenant.")
@click.option("--template", default="*", show_default=True)
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip the confirmation.")
@click.pass_context
def atlas_policy_reset(ctx, key, scope, tenant_id, template, yes):
    """SA only. Delete a policy row so the next rung applies (needs atlas:admin).

    \b
    Examples:
      TORANA_PROFILE=SA torana atlas policy reset selection.source_gone_confirmations --yes
    """
    if scope == "tenant" and not tenant_id:
        raise click.UsageError("--scope tenant needs --tenant")
    _confirm(f"Reset policy {key} ({scope})?", yes=yes)
    data = _call(_client(ctx).delete, f"atlas/policy/{key}",
                 params=_params(scope=scope, tenant=tenant_id, template=template))
    _done(ctx, data, f"reset policy {key} ({scope})")


# ---------------------------------------------------------------------------
# torana atlas kinds
# ---------------------------------------------------------------------------

@click.group(name="kinds", invoke_without_command=True)
@click.pass_context
def atlas_kinds(ctx):
    """Kinds: the node templates the registry knows (shape, version, sections, limits, node counts).

    Needs atlas:read. A tenant sees the kinds enabled for it; a super-admin sees all.

    \b
    Examples:
      torana atlas kinds list
      torana atlas kinds show repository
    """
    _bare_help(ctx)


@atlas_kinds.command(name="list")
@_tenant("Enabled-ness for another tenant (SA only).")
@click.option("--page", type=click.IntRange(min=1), default=1, show_default=True)
@click.option("--page-size", type=click.IntRange(1, MAX_PAGE_SIZE), default=50, show_default=True)
@click.pass_context
def atlas_kinds_list(ctx, tenant, page, page_size):
    """List kinds with shape, version, phase, whether enabled, and how many nodes exist.

    \b
    Examples:
      torana atlas kinds list
      torana atlas kinds list --json
    """
    fmt, raw, fields = _fmt(ctx)
    data = _call(_client(ctx).get, "atlas/kinds", params=_params(tenant=tenant, page=page, page_size=page_size))
    output(data, fmt=fmt, raw=raw, fields=fields, columns=[
        ("kind", "KIND", 22), ("shape", "SHAPE", 12), ("version", "VER", 4), ("phase", "PHASE", 6),
        ("enabled", "ENABLED", 7), ("nodes", "NODES", 6),
    ])


@atlas_kinds.command(name="show")
@click.argument("kind", metavar="KIND")
@_tenant("Enabled-ness for another tenant (SA only).")
@click.pass_context
def atlas_kinds_show(ctx, kind, tenant):
    """Show one kind: path rule, sections, card fields, prerequisites and limits.

    \b
    Examples:
      torana atlas kinds show repository
      torana atlas kinds show repository --json
    """
    fmt, raw, fields = _fmt(ctx)
    output(_call(_client(ctx).get, f"atlas/kinds/{kind}", params=_params(tenant=tenant) or None),
           fmt=fmt, raw=raw, fields=fields)
