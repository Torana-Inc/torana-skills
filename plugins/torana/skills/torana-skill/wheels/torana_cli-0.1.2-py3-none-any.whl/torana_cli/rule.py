"""torana rule <RULE_ID> — instance-scoped detection rule commands."""

import sys
import time
import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.rules import _alerting_options, _apply_alerting_fields, _load_input_file
from torana_cli.confirm import confirm as _confirm


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _rid(ctx) -> str:
    return ctx.obj.get("_rule_id", "") if ctx.obj else ""


def _resolve_query_id(client, rule_id: str) -> str:
    """Return the query_id backing a rule.

    A rule's SQL lives on its associated Query, not the rule itself — the rule
    GET returns sql_command=None (only populated under validate_sql). So SQL
    get/update both go through the rule's query_id.
    """
    rule_obj = client.get(f"rules/{rule_id}")
    qid = rule_obj.get("query_id")
    if not qid:
        raise APIError(f"Rule {rule_id} has no associated query_id.", 404, None)
    return qid


# ---------------------------------------------------------------------------
# Root group — takes RULE_ID as positional argument
# ---------------------------------------------------------------------------

@click.group(name="rule", invoke_without_command=True)
@click.argument("rule_id", metavar="RULE_ID")
@click.pass_context
def rule(ctx, rule_id):
    """Manage a single detection rule by ID.

    \b
    Examples:
      torana rule <UUID> get
      torana rule <UUID> execute
      torana rule <UUID> update --severity critical
      torana rule <UUID> delete --yes
      torana rule <UUID> executions
      torana rule <UUID> status <EXECUTION_LOG_ID>
    """
    ctx.ensure_object(dict)
    ctx.obj["_rule_id"] = rule_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


# ---------------------------------------------------------------------------
# Instance commands
# ---------------------------------------------------------------------------

@rule.command(name="get")
@click.pass_context
def rule_get(ctx):
    """Get details for this detection rule.

    \b
    Example:
      torana rule 550e8400-e29b-41d4-a716-446655440000 get
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"rules/{_rid(ctx)}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@rule.command(name="sql")
@click.pass_context
def rule_sql(ctx):
    """Show this rule's SQL.

    The SQL lives on the rule's associated Query (the rule GET returns it as
    null), so this resolves query_id and fetches the query's sql_command.
    Default output is the raw SQL; --json returns the full query object.

    \b
    Example:
      torana rule <UUID> sql
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        qid = _resolve_query_id(client, _rid(ctx))
        data = client.get(f"queries/{qid}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt == "text":
        click.echo(data.get("sql_command") or "(no SQL)")
    else:
        output(data, fmt=fmt)


def _verify_applied(body, data, fields):
    """Exit 1 naming any requested field the server did not apply.

    The rule PUT accepts unknown keys and discards them (FastAPI drops what
    `RuleUpdate` does not declare), so a write that was thrown away still answers 200.
    """
    if not isinstance(data, dict):
        return
    for field in fields:
        if field not in body:
            continue
        requested, applied = body[field], data.get(field)
        if requested != applied:
            click.echo(
                f"ERROR: {field} was NOT applied — the server discarded it.\n"
                f"       requested: {requested}\n"
                f"       still is:  {applied}\n"
                f"       The platform may predate this field. Check\n"
                f"         torana rule {{id}} get --format json",
                err=True)
            sys.exit(1)


@rule.command(name="update")
@click.option("--name", default=None, help="New rule name.")
@click.option("--severity", default=None,
              type=click.Choice(["low", "medium", "high", "critical"], case_sensitive=False))
@click.option("--sql", "sql_command", default=None, help="New SQL detection query.")
@click.option("--description", default=None)
@click.option("--state", default=None,
              type=click.Choice(["active", "inactive", "draft"], case_sensitive=False))
@click.option("--alert-enabled/--no-alert-enabled", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE",
              help="Load updates from JSON/YAML file.")
@click.option("--clear", "clear_fields", multiple=True,
              type=click.Choice(["declared_verdict", "alert_field_map"], case_sensitive=False),
              help="Clear a field (set it to null). Repeatable. ⛔ Needed because a null in "
                   "the body cannot clear a field: the API drops null values, so an explicit "
                   "null is indistinguishable from an omitted key.")
@_alerting_options
@click.pass_context
def rule_update(ctx, name, severity, sql_command, description, state, alert_enabled, input_file,
                clear_fields, emit_mode, declared_verdict, alert_field_map, group_role, group_key_field, group_size_field):
    """Update this detection rule.

    \b
    Examples:
      torana rule <UUID> update --severity critical
      torana rule <UUID> update --file updated-rule.yaml
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)

    if name:
        body["name"] = name
    if severity:
        body["severity"] = severity
    if description:
        body["description"] = description
    if state:
        body["state"] = state
    if alert_enabled is not None:
        body["alert_enabled"] = alert_enabled
    _apply_alerting_fields(body, emit_mode, declared_verdict, alert_field_map,
                           group_role, group_key_field, group_size_field)
    if clear_fields:
        body["clear_fields"] = [c.lower() for c in clear_fields]

    # SQL lives on the rule's Query, not the rule. The rule PUT silently drops
    # sql_command (RuleUpdate has no such field), so route it to the query
    # endpoint, which validates, EXPLAINs, and re-derives source_tables.
    client = _client(ctx)
    if sql_command:
        try:
            qid = _resolve_query_id(client, _rid(ctx))
            client.put(f"queries/{qid}/", json={"sql_command": sql_command})
        except APIError as e:
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return
        if fmt == "text":
            click.echo(f"Updated SQL for rule {_rid(ctx)} (query {qid})")

    if not body:
        if sql_command:
            return  # SQL-only update already handled above.
        click.echo("ERROR: No fields to update. Provide at least one flag or --file.", err=True)
        sys.exit(2)

    try:
        data = client.put(f"rules/{_rid(ctx)}", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # ⛔ The rule PUT ACCEPTS `identity_fields` and discards it server-side (same
    # class as sql_command above, but there is no alternate endpoint to route to —
    # it is immutable after create). Reporting "Updated rule" for a write that was
    # thrown away is worse than an error: `identity_fields` is the field that
    # decides whether a rule produces alerts at all, so an operator believes a
    # yield fix landed and re-measures the same broken yield. Verify and say so.
    requested_identity = body.get("identity_fields")
    if requested_identity is not None:
        applied = data.get("identity_fields") if isinstance(data, dict) else None
        if list(applied or []) != list(requested_identity or []):
            click.echo(
                f"ERROR: identity_fields was NOT applied — the server discarded it.\n"
                f"       requested: {requested_identity}\n"
                f"       still is:  {applied}\n"
                f"       identity_fields is immutable after the rule is created. To change\n"
                f"       the alert identity you must recreate the rule:\n"
                f"         torana rules create --name <n> --severity <s> --workspace-id <w> \\\n"
                f"           --entity-type <t> --identity-fields '<cols>' --sql '<sql>'",
                err=True)
            sys.exit(1)

    # ⛔ Same class as identity_fields above: verify the three WP1 fields actually
    # landed. A rule that reports "Updated" while still emitting a ten-row sample, or
    # while still stamping no verdict, is the failure this whole change exists to fix —
    # and it would be invisible until someone counted alerts a day later.
    _verify_applied(body, data, ("emit_mode", "declared_verdict", "alert_field_map",
                                 "group_role", "group_key_field", "group_size_field"))
    for field in body.get("clear_fields") or []:
        still = data.get(field) if isinstance(data, dict) else None
        if still is not None:
            click.echo(f"ERROR: --clear {field} was NOT applied — it still reads: {still}",
                       err=True)
            sys.exit(1)

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated rule: {_rid(ctx)}")


@rule.command(name="delete")
@click.option("--yes", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def rule_delete(ctx, yes):
    """Delete this detection rule.

    \b
    Example:
      torana rule 550e8400-e29b-41d4-a716-446655440000 delete --yes
    """
    rid = _rid(ctx)
    _confirm(f"Delete rule {rid}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"rules/{rid}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted rule: {rid}")


@rule.command(name="diff")
@click.option("--file", "input_file", required=True, metavar="FILE",
              help="JSON/YAML file with proposed changes. Use '-' for stdin.")
@click.pass_context
def rule_diff(ctx, input_file):
    """Show diff between current rule and proposed changes.

    \b
    Examples:
      torana rule <UUID> diff --file updated-rule.yaml
      cat updated.yaml | torana rule <UUID> diff --file -
    """
    proposed = _load_input_file(input_file)

    client = _client(ctx)
    try:
        current = client.get(f"rules/{_rid(ctx)}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    all_keys = sorted(set(list(current.keys()) + list(proposed.keys())))
    has_diff = False
    for key in all_keys:
        cur_val = current.get(key)
        new_val = proposed.get(key)
        if key not in proposed:
            continue
        if cur_val != new_val:
            has_diff = True
            click.echo(f"  {key}:")
            click.echo(f"    - {cur_val}")
            click.echo(f"    + {new_val}")

    if not has_diff:
        click.echo("No changes detected.")


@rule.command(name="execute")
@click.option("--workspace-id", default=None, help="Workspace UUID (required by some backends).")
@click.option("--no-wait", is_flag=True, default=False,
              help="Return immediately without polling for completion.")
@click.pass_context
def rule_execute(ctx, workspace_id, no_wait):
    """Manually execute this detection rule.

    Execution runs asynchronously; the CLI polls until complete and surfaces
    any error (e.g. invalid SQL column names) before returning.

    \b
    Examples:
      torana rule 550e8400-e29b-41d4-a716-446655440000 execute
      torana rule <UUID> execute --no-wait
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    rid = _rid(ctx)

    body = {}
    if workspace_id:
        body["workspace_id"] = workspace_id

    client = _client(ctx)
    try:
        data = client.post(f"rules/{rid}/execute", json=body if body else None)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    execution_log_id = data.get("execution_log_id") if isinstance(data, dict) else None

    if no_wait or not execution_log_id:
        output(data, fmt=fmt)
        return

    if fmt != "text":
        # JSON/YAML used to dump the bare POST response — {execution_log_id, rule_id,
        # status:QUEUED} — with no match count, so a script could not learn whether the
        # rule fired or how many rows it matched (CLI-27). The text path already polls
        # to terminal state and prints `Results: N`; poll here too and MERGE the
        # terminal fields in, so both surfaces answer the same question.
        merged = dict(data) if isinstance(data, dict) else {"result": data}
        for _ in range(30):
            time.sleep(1)
            try:
                sd = client.get(f"rules/{rid}/executions/{execution_log_id}/status")
            except (APIError, AuthError):
                break
            if not isinstance(sd, dict):
                break
            st = sd.get("status", "RUNNING")
            if st not in ("RUNNING", "running"):
                merged.update({k: v for k, v in sd.items() if v is not None})
                break
        output(merged, fmt=fmt)
        return

    # Note: on the queue path, execution_log_id here is actually a rule_run_jobs
    # (queue-job) id. The status endpoint accepts it and, once terminal, returns
    # the REAL execution-log id — which is what we surface so the user can fetch
    # the log directly via 'rule-execution-logs get'.
    click.echo(f"Execution started: {execution_log_id} (queue job)")
    for _ in range(30):
        time.sleep(1)
        try:
            status_data = client.get(f"rules/{rid}/executions/{execution_log_id}/status")
        except (APIError, AuthError):
            break
        status = status_data.get("status", "RUNNING") if isinstance(status_data, dict) else "RUNNING"
        if status not in ("RUNNING", "running"):
            if status in ("FAILED", "failed", "ERROR", "error"):
                error_msg = status_data.get("error_message", "")
                click.echo("Status:  FAILED")
                if error_msg:
                    click.echo(f"Error:   {error_msg}", err=True)
                sys.exit(1)
            click.echo(f"Status:  {status}")
            # Surface the resolved execution-log id (distinct from the queue-job
            # id) so the user can fetch the log directly.
            resolved_log_id = status_data.get("execution_log_id") if isinstance(status_data, dict) else None
            if resolved_log_id and resolved_log_id != execution_log_id:
                click.echo(f"Log id:  {resolved_log_id}")
                click.echo(f"         (fetch: torana rule-execution-logs get {resolved_log_id})")
            if status_data.get("result_count") is not None:
                click.echo(f"Results: {status_data['result_count']}")
            if status_data.get("alert_id"):
                click.echo(f"Alert:   {status_data['alert_id']}")
            return

    click.echo("Status:  still running (timed out waiting — use 'torana rule <UUID> status' to check)")


@rule.command(name="toggle-alert")
@click.pass_context
def rule_toggle_alert(ctx):
    """Toggle alerting on/off for this rule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.post(f"rules/{_rid(ctx)}/toggle-alert", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@rule.command(name="status")
@click.argument("execution_log_id", metavar="EXECUTION_LOG_ID")
@click.pass_context
def rule_status(ctx, execution_log_id):
    """Poll async execution status for this rule.

    \b
    Example:
      torana rule <UUID> status <EXECUTION_LOG_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"rules/{_rid(ctx)}/executions/{execution_log_id}/status")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@rule.command(name="cancel")
@click.argument("execution_log_id", metavar="EXECUTION_LOG_ID")
@click.pass_context
def rule_cancel(ctx, execution_log_id):
    """Cancel a running execution for this rule.

    \b
    Example:
      torana rule <UUID> cancel <EXECUTION_LOG_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.post(f"rules/{_rid(ctx)}/executions/{execution_log_id}/cancel", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@rule.command(name="stats")
@click.pass_context
def rule_stats(ctx):
    """Get execution statistics for this rule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"rules/{_rid(ctx)}/stats")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@rule.command(name="run-stats")
@click.option("--window", default=None, help="Trailing window (e.g. 7d, 30d).")
@click.pass_context
def rule_run_stats(ctx, window):
    """Get run statistics for this rule.

    \b
    Example:
      torana rule <UUID> run-stats --window 7d
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if window:
        params["window"] = window

    client = _client(ctx)
    try:
        data = client.get(f"rules/{_rid(ctx)}/run-stats", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@rule.command(name="executions")
@click.option("--skip", type=int, default=0)
@click.option("--limit", type=int, default=50)
@click.pass_context
def rule_executions(ctx, skip, limit):
    """Get execution history for this rule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if skip is not None:
        params["skip"] = skip
    if limit is not None:
        params["limit"] = limit

    client = _client(ctx)
    try:
        data = client.get(f"rules/{_rid(ctx)}/executions", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@rule.command(name="logs")
@click.option("--skip", type=int, default=0)
@click.option("--limit", type=int, default=50)
@click.pass_context
def rule_logs(ctx, skip, limit):
    """Get execution logs for this rule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if skip is not None:
        params["skip"] = skip
    if limit is not None:
        params["limit"] = limit

    client = _client(ctx)
    try:
        data = client.get(f"rule-execution-logs/rules/{_rid(ctx)}/logs", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@rule.command(name="tags")
@click.pass_context
def rule_tags(ctx):
    """List tags for this rule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.post(f"rules/{_rid(ctx)}/tags", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@rule.command(name="tags-remove")
@click.argument("tag", metavar="TAG")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def rule_tags_remove(ctx, tag, yes):
    """Remove a tag from this rule.

    \b
    Example:
      torana rule <UUID> tags-remove my-tag --yes
    """
    _confirm("Are you sure?", yes=yes)
    client = _client(ctx)
    try:
        data = client.delete(f"rules/{_rid(ctx)}/tags/{tag}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    output(data, fmt=fmt)


@rule.command(name="move")
@click.option("--target-workspace-id", "target_workspace_id", required=True,
              help="UUID of the destination workspace.")
@click.pass_context
def rule_move(ctx, target_workspace_id):
    """Move this rule to a different workspace.

    \b
    Example:
      torana rule <UUID> move --target-workspace-id <WORKSPACE_UUID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.post(f"rules/{_rid(ctx)}/move", json={"target_workspace_id": target_workspace_id})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@rule.command(name="change-history")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def rule_change_history(ctx, page, page_size):
    """Get the change-history audit trail for this rule.

    \b
    Example:
      torana rule <UUID> change-history
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        data = client.get(f"rules/{_rid(ctx)}/change-history", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)
