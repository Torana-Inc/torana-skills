"""torana programs — program management commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 40),
    ("state", "STATE", 12),
    ("workspace_id", "WORKSPACE", 36),
    ("description", "DESCRIPTION", 40),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group()
def programs():
    """Manage security programs.

    \b
    Examples:
      torana programs list
      torana programs get <UUID>
      torana programs create --file program.yaml
      torana programs execute <UUID> --phase 1
      torana programs status <UUID>
    """


@programs.command(name="list")
@click.option("--workspace-id", default=None, help="Filter by workspace UUID.")
@click.option("--state", default=None, help="Filter by state.")
@click.option("--search", default=None, help="Search by name.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.pass_context
def programs_list(ctx, workspace_id, state, search, page, page_size, fetch_all):
    """List programs.

    \b
    Examples:
      torana programs list
      torana programs list --workspace-id <WID> --state active
      torana programs list --search vulnerability --json | jq '.items[].name'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if workspace_id:
        params["workspace_id"] = workspace_id
    if state:
        params["state"] = state
    if search:
        params["search"] = search

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                p.update({k: v for k, v in params.items() if k not in ("skip", "limit")})
                data = client.get("programs/", params=p)
                items = data.get("items", data if isinstance(data, list) else [])
                all_items.extend(items)
                total = data.get("total", len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items), "page": 1,
                      "page_size": len(all_items)}
        else:
            data = client.get("programs/", params=params)
            result = data if isinstance(data, dict) and "items" in data else {
                "items": data if isinstance(data, list) else [],
                "total": len(data) if isinstance(data, list) else 0,
                "page": page, "page_size": effective_page_size
            }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@programs.command(name="get")
@click.argument("program_id", metavar="PROGRAM_ID")
@click.pass_context
def programs_get(ctx, program_id):
    """Get details for a specific program.

    \b
    Examples:
      torana programs list                     # find the id
      torana programs get <PROGRAM_ID>
      torana programs get <PROGRAM_ID> --json | jq '{name, state, workspace_id}'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"programs/{program_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="create")
@click.option("--name", default=None)
@click.option("--description", default=None)
@click.option("--workspace-id", default=None, help="Workspace UUID.")
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def programs_create(ctx, name, description, workspace_id, input_file):
    """Create a new program.

    \b
    Examples:
      torana programs create --name "Vulnerability Management" --workspace-id <WID>
      torana programs create --file program.yaml

    \b
      Phases are planned and executed separately, in order:
        torana programs plan phase1 <PROGRAM_ID> --agent-id <AGENT_ID>
        torana programs execute phase1 <PROGRAM_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if description:
        body["description"] = description
    if workspace_id:
        body["workspace_id"] = workspace_id

    if not body.get("name"):
        click.echo("ERROR: --name is required (or provide --file with 'name' field).", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post("programs/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created program: {data.get('id', 'unknown')}")
        click.echo(f"  Name: {data.get('name', '')}")


@programs.command(name="update")
@click.argument("program_id", metavar="PROGRAM_ID")
@click.option("--name", default=None)
@click.option("--description", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def programs_update(ctx, program_id, name, description, input_file):
    """Update a program."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if description:
        body["description"] = description

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"programs/{program_id}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated program: {program_id}")


@programs.command(name="delete")
@click.argument("program_id", metavar="PROGRAM_ID")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def programs_delete(ctx, program_id, yes):
    """Delete a program."""
    _confirm(f"Delete program {program_id}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"programs/{program_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted program: {program_id}")


# ─────────────────────────────────────────────────────────────────────────────
# Program phases — `programs plan phaseN` and `programs execute phaseN`.
#
# ⚠️ These were `phase1` and `phase1-1` (etc). The `-1` suffix looked like a
# generator collision but hid a REAL semantic difference: the plain name POSTs to
# /plan/phaseN, the -1 name POSTs to /execute/phaseN. Numbering two different
# operations is exactly how a caller runs the wrong one — so they are now split by
# the verb that distinguishes them (CLI Discoverability Contract, rule 2).
# ─────────────────────────────────────────────────────────────────────────────


@programs.group(name="plan")
def programs_plan_group():
    """Plan a program phase (assigns the planning agent).

    Examples:
      torana programs plan phase1 <PROGRAM_ID> --agent-id <AGENT_ID>
    """


@programs.group(name="execute")
def programs_execute_group():
    """Execute a previously planned program phase.

    Examples:
      torana programs execute phase1 <PROGRAM_ID>
    """


@programs_execute_group.command(name="all")
@click.argument("program_id", metavar="PROGRAM_ID")
@click.option("--phase", default=None, type=int, help="Phase number to execute (1, 2, or 3).")
@click.pass_context
def programs_execute(ctx, program_id, phase):
    """Execute a program (multi-phase: 1→2→3).

    \b
    Example:
      torana programs execute <UUID> --phase 1
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if phase is not None:
        body["phase"] = phase

    client = _client(ctx)
    try:
        data = client.post(f"programs/{program_id}/execute/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Executing program: {program_id}" + (f" (phase {phase})" if phase else ""))
        if isinstance(data, dict):
            for k, v in data.items():
                if k != "id":
                    click.echo(f"  {k}: {v}")


@programs.command(name="status")
@click.argument("program_id", metavar="PROGRAM_ID")
@click.pass_context
def programs_status(ctx, program_id):
    """Get execution status of a program."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(f"programs/{program_id}/status/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        if isinstance(data, dict):
            status = data.get("status", data.get("state", "unknown"))
            click.echo(f"Program {program_id}: {status}")
            for k, v in data.items():
                if k not in ("status", "state", "id"):
                    click.echo(f"  {k}: {v}")
        else:
            click.echo(str(data))


@programs.command(name="available")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def bootstrap_available(ctx, page, page_size, fetch_all):
    """Get Available Program Templates."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "bootstrap/program-templates/available"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@programs.command(name="load")
@click.option("--filenames", "filenames", required=True)
@click.pass_context
def bootstrap_load(ctx, filenames):
    """Load Program Templates."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "bootstrap/program-templates/load"
    body = {}
    body["filenames"] = filenames

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="load-all")
@click.pass_context
def bootstrap_load_all(ctx):
    """Load All Program Templates."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "bootstrap/program-templates/load-all"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="all")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def bootstrap_all(ctx, yes):
    """Delete All Program Templates."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = "bootstrap/program-templates/all"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="delete-selected")
@click.option("--names", "names", required=True)
@click.pass_context
def bootstrap_delete_selected(ctx, names):
    """Delete Selected Program Templates."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "bootstrap/program-templates/delete-selected"
    body = {}
    body["names"] = names

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="available-templates")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def programs_available_templates(ctx, page, page_size, fetch_all):
    """Get Available Workspace Templates."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "bootstrap/workspace-templates/available"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@programs.command(name="load-templates")
@click.option("--filenames", "filenames", required=True)
@click.pass_context
def programs_load_templates(ctx, filenames):
    """Load Workspace Templates."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "bootstrap/workspace-templates/load"
    body = {}
    body["filenames"] = filenames

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="load-all-templates")
@click.pass_context
def programs_load_all_templates(ctx):
    """Load All Workspace Templates."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "bootstrap/workspace-templates/load-all"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="delete-all-templates")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def programs_delete_all_templates(ctx, yes):
    """Delete All Workspace Templates."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = "bootstrap/workspace-templates/all"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="delete-selected-templates")
@click.option("--names", "names", required=True)
@click.pass_context
def programs_delete_selected_templates(ctx, names):
    """Delete Selected Workspace Templates."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "bootstrap/workspace-templates/delete-selected"
    body = {}
    body["names"] = names

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="templates-status")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def programs_templates_status(ctx, page, page_size, fetch_all):
    """Get Workspace Templates Status."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "bootstrap/workspace-templates/status"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@programs.command(name="seed")
@click.pass_context
def bootstrap_seed(ctx):
    """Seed Landing Page Templates."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "bootstrap/landing-page-templates/seed"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="assign-plan")
@click.argument("PROGRAM_ID", metavar="PROGRAM_ID")
@click.option("--plan-id", "plan_id", required=True)
@click.pass_context
def programs_assign_plan(ctx, program_id, plan_id):
    """Assign Plan To Program."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"programs/{program_id}/assign-plan"
    body = {}
    body["plan_id"] = plan_id

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="remove-plan")
@click.argument("PROGRAM_ID", metavar="PROGRAM_ID")
@click.pass_context
def programs_remove_plan(ctx, program_id):
    """Remove Plan From Program."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"programs/{program_id}/remove-plan"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs_plan_group.command(name="all")
@click.argument("PROGRAM_ID", metavar="PROGRAM_ID")
@click.option("--data-planner-agent-id", "data_planner_agent_id", default=None, help="Data Planner agent ID (Phase 1)")
@click.option("--data-planner-agent-name", "data_planner_agent_name", default=None, help="Data Planner agent name (Phase 1)")
@click.option("--detection-planner-agent-id", "detection_planner_agent_id", default=None, help="Detection Planner agent ID (Phase 2)")
@click.option("--detection-planner-agent-name", "detection_planner_agent_name", default=None, help="Detection Planner agent name (Phase 2)")
@click.option("--visibility-planner-agent-id", "visibility_planner_agent_id", default=None, help="Visibility Planner agent ID (Phase 3)")
@click.option("--visibility-planner-agent-name", "visibility_planner_agent_name", default=None, help="Visibility Planner agent name (Phase 3)")
@click.pass_context
def programs_plan(ctx, program_id, data_planner_agent_id, data_planner_agent_name, detection_planner_agent_id, detection_planner_agent_name, visibility_planner_agent_id, visibility_planner_agent_name):
    """Plan program all phases."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"programs/{program_id}/plan"
    params = {}
    if data_planner_agent_id is not None:
        params["data_planner_agent_id"] = data_planner_agent_id
    if data_planner_agent_name is not None:
        params["data_planner_agent_name"] = data_planner_agent_name
    if detection_planner_agent_id is not None:
        params["detection_planner_agent_id"] = detection_planner_agent_id
    if detection_planner_agent_name is not None:
        params["detection_planner_agent_name"] = detection_planner_agent_name
    if visibility_planner_agent_id is not None:
        params["visibility_planner_agent_id"] = visibility_planner_agent_id
    if visibility_planner_agent_name is not None:
        params["visibility_planner_agent_name"] = visibility_planner_agent_name

    client = _client(ctx)
    try:
        data = client.post(path, json={}, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="delete-plan")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("PROGRAM_ID", metavar="PROGRAM_ID")
@click.option("--delete-plan", "delete_plan", type=bool, default=True)
@click.pass_context
def programs_delete_plan(ctx, program_id, delete_plan, yes):
    """Delete Plan And Artifacts."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"programs/{program_id}/plan"
    params = {}
    if delete_plan is not None:
        params["delete_plan"] = delete_plan

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="plan-and-wait")
@click.argument("PROGRAM_ID", metavar="PROGRAM_ID")
@click.option("--data-planner-agent-id", "data_planner_agent_id", default=None, help="Data Planner agent ID (Phase 1)")
@click.option("--data-planner-agent-name", "data_planner_agent_name", default=None, help="Data Planner agent name (Phase 1)")
@click.option("--detection-planner-agent-id", "detection_planner_agent_id", default=None, help="Detection Planner agent ID (Phase 2)")
@click.option("--detection-planner-agent-name", "detection_planner_agent_name", default=None, help="Detection Planner agent name (Phase 2)")
@click.option("--visibility-planner-agent-id", "visibility_planner_agent_id", default=None, help="Visibility Planner agent ID (Phase 3)")
@click.option("--visibility-planner-agent-name", "visibility_planner_agent_name", default=None, help="Visibility Planner agent name (Phase 3)")
@click.pass_context
def programs_plan_and_wait(ctx, program_id, data_planner_agent_id, data_planner_agent_name, detection_planner_agent_id, detection_planner_agent_name, visibility_planner_agent_id, visibility_planner_agent_name):
    """Plan program and wait."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"programs/{program_id}/plan-and-wait"
    params = {}
    if data_planner_agent_id is not None:
        params["data_planner_agent_id"] = data_planner_agent_id
    if data_planner_agent_name is not None:
        params["data_planner_agent_name"] = data_planner_agent_name
    if detection_planner_agent_id is not None:
        params["detection_planner_agent_id"] = detection_planner_agent_id
    if detection_planner_agent_name is not None:
        params["detection_planner_agent_name"] = detection_planner_agent_name
    if visibility_planner_agent_id is not None:
        params["visibility_planner_agent_id"] = visibility_planner_agent_id
    if visibility_planner_agent_name is not None:
        params["visibility_planner_agent_name"] = visibility_planner_agent_name

    client = _client(ctx)
    try:
        data = client.post(path, json={}, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="planning-status")
@click.argument("PROGRAM_ID", metavar="PROGRAM_ID")
@click.pass_context
def programs_planning_status(ctx, program_id):
    """Get program planning status."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"programs/{program_id}/planning-status"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="execution-status")
@click.argument("PROGRAM_ID", metavar="PROGRAM_ID")
@click.pass_context
def programs_execution_status(ctx, program_id):
    """Get Execution Status."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"programs/{program_id}/execution-status"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs_plan_group.command(name="phase1")
@click.argument("PROGRAM_ID", metavar="PROGRAM_ID")
@click.option("--agent-id", "agent_id", required=True, help="Core Planner agent ID")
@click.pass_context
def programs_phase1(ctx, program_id, agent_id):
    """Plan Program Phase1."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"programs/{program_id}/plan/phase1"
    params = {}
    if agent_id is not None:
        params["agent_id"] = agent_id

    client = _client(ctx)
    try:
        data = client.post(path, json={}, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs_execute_group.command(name="phase1")
@click.argument("PROGRAM_ID", metavar="PROGRAM_ID")
@click.pass_context
def programs_phase1_1(ctx, program_id):
    """Execute Program Phase1."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"programs/{program_id}/execute/phase1"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs_plan_group.command(name="phase2")
@click.argument("PROGRAM_ID", metavar="PROGRAM_ID")
@click.option("--agent-id", "agent_id", required=True, help="Visibility Planner agent ID")
@click.pass_context
def programs_phase2(ctx, program_id, agent_id):
    """Plan Program Phase2."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"programs/{program_id}/plan/phase2"
    params = {}
    if agent_id is not None:
        params["agent_id"] = agent_id

    client = _client(ctx)
    try:
        data = client.post(path, json={}, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs_execute_group.command(name="phase2")
@click.argument("PROGRAM_ID", metavar="PROGRAM_ID")
@click.pass_context
def programs_phase2_1(ctx, program_id):
    """Execute Program Phase2."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"programs/{program_id}/execute/phase2"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs_plan_group.command(name="phase3")
@click.argument("PROGRAM_ID", metavar="PROGRAM_ID")
@click.option("--agent-id", "agent_id", required=True, help="Visibility Planner agent ID")
@click.pass_context
def programs_phase3(ctx, program_id, agent_id):
    """Plan Program Phase3."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"programs/{program_id}/plan/phase3"
    params = {}
    if agent_id is not None:
        params["agent_id"] = agent_id

    client = _client(ctx)
    try:
        data = client.post(path, json={}, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs_execute_group.command(name="phase3")
@click.argument("PROGRAM_ID", metavar="PROGRAM_ID")
@click.pass_context
def programs_phase3_1(ctx, program_id):
    """Execute Program Phase3."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"programs/{program_id}/execute/phase3"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="artifacts")
@click.argument("PROGRAM_ID", metavar="PROGRAM_ID")
@click.option("--artifact-type", "artifact_type", default=None, help="Filter by artifact type")
@click.pass_context
def programs_artifacts(ctx, program_id, artifact_type):
    """Get Program Artifacts."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"programs/{program_id}/artifacts"
    params = {}
    if artifact_type is not None:
        params["artifact_type"] = artifact_type

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="delete-artifacts")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("PROGRAM_ID", metavar="PROGRAM_ID")
@click.pass_context
def programs_delete_artifacts(ctx, program_id, yes):
    """Delete Program Artifacts."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"programs/{program_id}/artifacts"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="execution-status-snapshot")
@click.argument("PROGRAM_ID", metavar="PROGRAM_ID")
@click.option("--execution-id", "execution_id", default=None, help="Specific execution ID (defaults to latest)")
@click.pass_context
def programs_execution_status_snapshot(ctx, program_id, execution_id):
    """Get Execution Status Snapshot."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"programs/{program_id}/execution-status-snapshot"
    params = {}
    if execution_id is not None:
        params["execution_id"] = execution_id

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="visualization")
@click.argument("PROGRAM_ID", metavar="PROGRAM_ID")
@click.pass_context
def programs_visualization(ctx, program_id):
    """Get Plan Visualization."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"programs/{program_id}/plan/visualization"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="runtime-stats")
@click.argument("PROGRAM_ID", metavar="PROGRAM_ID")
@click.option("--hours", "hours", type=int, default=24, help="Number of hours to look back for runtime stats")
@click.pass_context
def programs_runtime_stats(ctx, program_id, hours):
    """Get Program Runtime Stats."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"programs/{program_id}/runtime-stats"
    params = {}
    if hours is not None:
        params["hours"] = hours

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="plan-execution-status")
@click.argument("PROGRAM_ID", metavar="PROGRAM_ID")
@click.pass_context
def programs_plan_execution_status(ctx, program_id):
    """Get Plan Execution Status."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"programs/{program_id}/plan-execution-status"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="move")
@click.argument("PROGRAM_ID", metavar="PROGRAM_ID")
@click.option("--workspace-id", "workspace_id", required=True, help="Target workspace ID")
@click.pass_context
def programs_move(ctx, program_id, workspace_id):
    """Move Program."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"programs/{program_id}/move"
    body = {}
    body["workspace_id"] = workspace_id

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="planning-status-stream")
@click.argument("PROGRAM_ID", metavar="PROGRAM_ID")
@click.pass_context
def programs_planning_status_stream(ctx, program_id):
    """Stream Planning Status."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"programs/{program_id}/planning-status-stream"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="execution-status-stream")
@click.argument("PROGRAM_ID", metavar="PROGRAM_ID")
@click.pass_context
def programs_execution_status_stream(ctx, program_id):
    """Stream Execution Status."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"programs/{program_id}/execution-status-stream"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ---------------------------------------------------------------------------
# Workspace intents (program-framework view)
# ---------------------------------------------------------------------------

@programs.command(name="workspace-intents")
@click.argument("workspace_id", metavar="WORKSPACE_ID")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.pass_context
def programs_workspace_intents(ctx, workspace_id, page, page_size, fetch_all):
    """List intents for a workspace (program-framework view).

    \b
    Example:
      torana programs workspace-intents <WORKSPACE_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(f"workspaces/{workspace_id}/intents", params=p)
                items = data.get("items", data if isinstance(data, list) else [])
                all_items.extend(items)
                total = data.get("total", len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(f"workspaces/{workspace_id}/intents", params=params)
            result = data if isinstance(data, dict) and "items" in data else {
                "items": data if isinstance(data, list) else [],
                "total": len(data) if isinstance(data, list) else 0,
            }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields)


@programs.command(name="workspace-intent")
@click.argument("workspace_id", metavar="WORKSPACE_ID")
@click.argument("intent_id", metavar="INTENT_ID")
@click.pass_context
def programs_workspace_intent(ctx, workspace_id, intent_id):
    """Get a single workspace intent (program-framework view).

    \b
    Example:
      torana programs workspace-intent <WORKSPACE_ID> <INTENT_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"workspaces/{workspace_id}/intents/{intent_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="workspace-intent-lineage")
@click.argument("workspace_id", metavar="WORKSPACE_ID")
@click.argument("intent_id", metavar="INTENT_ID")
@click.pass_context
def programs_workspace_intent_lineage(ctx, workspace_id, intent_id):
    """Get the supersession lineage for a workspace intent.

    \b
    Example:
      torana programs workspace-intent-lineage <WORKSPACE_ID> <INTENT_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"workspaces/{workspace_id}/intents/{intent_id}/lineage")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ---------------------------------------------------------------------------
# Workspace coverage (Phase 4b)
# ---------------------------------------------------------------------------

@programs.command(name="workspace-coverage")
@click.argument("workspace_id", metavar="WORKSPACE_ID")
@click.pass_context
def programs_workspace_coverage(ctx, workspace_id):
    """Coverage score and per-framework block for a workspace.

    \b
    Example:
      torana programs workspace-coverage <WORKSPACE_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"workspaces/{workspace_id}/coverage")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="workspace-coverage-history")
@click.argument("workspace_id", metavar="WORKSPACE_ID")
@click.pass_context
def programs_workspace_coverage_history(ctx, workspace_id):
    """Coverage score time series for a workspace.

    \b
    Example:
      torana programs workspace-coverage-history <WORKSPACE_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"workspaces/{workspace_id}/coverage/history")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


# ---------------------------------------------------------------------------
# Built items (I-029)
# ---------------------------------------------------------------------------

@programs.command(name="workspace-built-items")
@click.argument("workspace_id", metavar="WORKSPACE_ID")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.pass_context
def programs_workspace_built_items(ctx, workspace_id, page, page_size, fetch_all):
    """List artifacts created from committed proposals for a workspace.

    \b
    Example:
      torana programs workspace-built-items <WORKSPACE_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(f"workspaces/{workspace_id}/built-items", params=p)
                items = data.get("items", data if isinstance(data, list) else [])
                all_items.extend(items)
                total = data.get("total", len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(f"workspaces/{workspace_id}/built-items", params=params)
            result = data if isinstance(data, dict) and "items" in data else {
                "items": data if isinstance(data, list) else [],
                "total": len(data) if isinstance(data, list) else 0,
            }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields)


# ---------------------------------------------------------------------------
# Build-attention: retired proposals
# ---------------------------------------------------------------------------

@programs.command(name="workspace-retired-proposals")
@click.argument("workspace_id", metavar="WORKSPACE_ID")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.pass_context
def programs_workspace_retired_proposals(ctx, workspace_id, page, page_size, fetch_all):
    """List proposals auto-retired by a refresh sweep (Previously Suggested zone).

    \b
    Example:
      torana programs workspace-retired-proposals <WORKSPACE_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(f"workspaces/{workspace_id}/build-attention/retired", params=p)
                items = data.get("items", data if isinstance(data, list) else [])
                all_items.extend(items)
                total = data.get("total", len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(f"workspaces/{workspace_id}/build-attention/retired", params=params)
            result = data if isinstance(data, dict) and "items" in data else {
                "items": data if isinstance(data, list) else [],
                "total": len(data) if isinstance(data, list) else 0,
            }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields)


@programs.command(name="workspace-restore-proposal")
@click.argument("workspace_id", metavar="WORKSPACE_ID")
@click.argument("proposal_id", metavar="PROPOSAL_ID")
@click.pass_context
def programs_workspace_restore_proposal(ctx, workspace_id, proposal_id):
    """Restore a retired proposal back to draft (Previously Suggested → Needs Attention).

    \b
    Example:
      torana programs workspace-restore-proposal <WORKSPACE_ID> <PROPOSAL_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(
            f"workspaces/{workspace_id}/build-attention/{proposal_id}/restore", json={}
        )
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Restored proposal: {proposal_id}")


@programs.command(name="workspace-attach-session")
@click.argument("workspace_id", metavar="WORKSPACE_ID")
@click.argument("proposal_id", metavar="PROPOSAL_ID")
@click.option("--session-id", "session_id", required=True, help="Chat session ID to attach.")
@click.pass_context
def programs_workspace_attach_session(ctx, workspace_id, proposal_id, session_id):
    """Attach a chat session to a proposal (Build in Chat).

    \b
    Example:
      torana programs workspace-attach-session <WORKSPACE_ID> <PROPOSAL_ID> --session-id <UUID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(
            f"workspaces/{workspace_id}/build-attention/{proposal_id}/attach-session",
            json={"session_id": session_id},
        )
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Attached session {session_id} to proposal {proposal_id}")


# ---------------------------------------------------------------------------
# Advisor: workspace search + artifacts
# ---------------------------------------------------------------------------

@programs.command(name="advisor-rules-search")
@click.argument("workspace_id", metavar="WORKSPACE_ID")
@click.option("--q", "query", required=True, help="Search query.")
@click.pass_context
def programs_advisor_rules_search(ctx, workspace_id, query):
    """Keyword search across workspace rules (Phase 3 §4.1).

    \b
    Example:
      torana programs advisor-rules-search <WORKSPACE_ID> --q "brute force"
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"workspaces/{workspace_id}/advisor/rules/search",
                          params={"q": query})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@programs.command(name="advisor-artifact")
@click.argument("workspace_id", metavar="WORKSPACE_ID")
@click.argument("artifact_id", metavar="ARTIFACT_ID")
@click.pass_context
def programs_advisor_artifact(ctx, workspace_id, artifact_id):
    """Full artifact spec for an artifact in this workspace (Phase 3 §4.2).

    \b
    Example:
      torana programs advisor-artifact <WORKSPACE_ID> <ARTIFACT_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"workspaces/{workspace_id}/advisor/artifacts/{artifact_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ---------------------------------------------------------------------------
# Audit: timeline + SA records
# ---------------------------------------------------------------------------

@programs.command(name="audit-timeline")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.pass_context
def programs_audit_timeline(ctx, page, page_size, fetch_all):
    """Activity timeline list.

    \b
    Example:
      torana programs audit-timeline
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get("audit/timeline", params=p)
                items = data.get("items", data if isinstance(data, list) else [])
                all_items.extend(items)
                total = data.get("total", len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get("audit/timeline", params=params)
            result = data if isinstance(data, dict) and "items" in data else {
                "items": data if isinstance(data, list) else [],
                "total": len(data) if isinstance(data, list) else 0,
            }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields)


@programs.command(name="audit-record")
@click.argument("audit_record_id", metavar="AUDIT_RECORD_ID")
@click.pass_context
def programs_audit_record(ctx, audit_record_id):
    """Full audit record detail for Audit Drawer.

    \b
    Example:
      torana programs audit-record <AUDIT_RECORD_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"audit/timeline/{audit_record_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="audit-record-diff")
@click.argument("audit_record_id", metavar="AUDIT_RECORD_ID")
@click.pass_context
def programs_audit_record_diff(ctx, audit_record_id):
    """Get pre/post diff for a single audit record.

    \b
    Example:
      torana programs audit-record-diff <AUDIT_RECORD_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"audit/timeline/{audit_record_id}/diff")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@programs.command(name="audit-sa-records")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.pass_context
def programs_audit_sa_records(ctx, page, page_size, fetch_all):
    """SA cross-tenant audit log with full filters.

    \b
    Example:
      torana programs audit-sa-records
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get("audit/sa/records", params=p)
                items = data.get("items", data if isinstance(data, list) else [])
                all_items.extend(items)
                total = data.get("total", len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get("audit/sa/records", params=params)
            result = data if isinstance(data, dict) and "items" in data else {
                "items": data if isinstance(data, list) else [],
                "total": len(data) if isinstance(data, list) else 0,
            }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields)


# ---------------------------------------------------------------------------
# Advisor admin (SA-level operations)
# ---------------------------------------------------------------------------

@click.group(name="advisor-admin")
def advisor_admin():
    """Super-admin advisor operations.

    \b
    Examples:
      torana advisor-admin dashboard
      torana advisor-admin flags list
      torana advisor-admin sweeps list
      torana advisor-admin heuristics <TENANT_ID>
    """


@advisor_admin.command(name="dashboard")
@click.option("--workspace-id", "workspace_id", default=None,
              help="Optional workspace drill-down.")
@click.pass_context
def advisor_admin_dashboard(ctx, workspace_id):
    """Advisor dashboard (SA cross-tenant or TA own-tenant)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if workspace_id:
        params["workspace_id"] = workspace_id

    client = _client(ctx)
    try:
        data = client.get("admin/advisor/dashboard", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@advisor_admin.command(name="dispositions")
@click.pass_context
def advisor_admin_dispositions(ctx):
    """List proposal dispositions (SA/TA admin view)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("admin/advisor/dispositions")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@advisor_admin.group(name="flags")
def advisor_admin_flags():
    """Manage advisor feature flags."""


@advisor_admin_flags.command(name="list")
@click.pass_context
def advisor_admin_flags_list(ctx):
    """List current advisor feature flag state across tenants (SA only)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("admin/advisor/flags")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@advisor_admin_flags.command(name="active-slices")
@click.pass_context
def advisor_admin_flags_active_slices(ctx):
    """Return active advisor slice identifiers (SA only)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("admin/advisor/flags/active-slices")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@advisor_admin_flags.command(name="set")
@click.argument("tenant_id", metavar="TENANT_ID")
@click.option("--file", "input_file", required=True, metavar="FILE",
              help="JSON/YAML file with flag name and value.")
@click.pass_context
def advisor_admin_flags_set(ctx, tenant_id, input_file):
    """Flip an advisor feature flag for a tenant (SA only).

    \b
    Example:
      torana advisor-admin flags set <TENANT_ID> --file flag.yaml
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = _load_input_file(input_file)

    client = _client(ctx)
    try:
        data = client.post(f"admin/advisor/flags/tenant/{tenant_id}", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated advisor flag for tenant: {tenant_id}")


@advisor_admin.group(name="heuristics")
def advisor_admin_heuristics():
    """Manage advisor heuristics."""


@advisor_admin_heuristics.command(name="list")
@click.pass_context
def advisor_admin_heuristics_list(ctx):
    """Return the heuristic registry (H1–H17 metadata) (SA only)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("admin/advisor/heuristics")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@advisor_admin_heuristics.command(name="config")
@click.argument("tenant_id", metavar="TENANT_ID")
@click.pass_context
def advisor_admin_heuristics_config(ctx, tenant_id):
    """Return fully-resolved HeuristicConfig for a tenant (SA only)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"admin/advisor/heuristics/{tenant_id}/config")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@advisor_admin_heuristics.command(name="fire-rate")
@click.argument("tenant_id", metavar="TENANT_ID")
@click.pass_context
def advisor_admin_heuristics_fire_rate(ctx, tenant_id):
    """Per-heuristic candidate fire rate across 1d/7d/28d windows (SA only)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"admin/advisor/heuristics/{tenant_id}/fire-rate")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@advisor_admin_heuristics.command(name="overrides")
@click.argument("tenant_id", metavar="TENANT_ID")
@click.pass_context
def advisor_admin_heuristics_overrides(ctx, tenant_id):
    """List raw DB override rows for a tenant (SA only)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"admin/advisor/heuristics/{tenant_id}/overrides")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@advisor_admin_heuristics.command(name="override-set")
@click.argument("tenant_id", metavar="TENANT_ID")
@click.argument("hid", metavar="HID")
@click.option("--file", "input_file", required=True, metavar="FILE",
              help="JSON/YAML file with override body.")
@click.pass_context
def advisor_admin_heuristics_override_set(ctx, tenant_id, hid, input_file):
    """Upsert a heuristic threshold override for a tenant/workspace (SA only).

    \b
    Example:
      torana advisor-admin heuristics override-set <TENANT_ID> <HID> --file override.yaml
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = _load_input_file(input_file)

    client = _client(ctx)
    try:
        data = client.put(f"admin/advisor/heuristics/{tenant_id}/overrides/{hid}", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Upserted heuristic override {hid} for tenant {tenant_id}")


@advisor_admin_heuristics.command(name="override-delete")
@click.argument("tenant_id", metavar="TENANT_ID")
@click.argument("hid", metavar="HID")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def advisor_admin_heuristics_override_delete(ctx, tenant_id, hid, yes):
    """Soft-delete a heuristic override row (SA only)."""
    _confirm(f"Delete heuristic override {hid} for tenant {tenant_id}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"admin/advisor/heuristics/{tenant_id}/overrides/{hid}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted heuristic override {hid} for tenant {tenant_id}")


@advisor_admin.group(name="sweeps")
def advisor_admin_sweeps():
    """Manage advisor sweeps."""


@advisor_admin_sweeps.command(name="list")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.pass_context
def advisor_admin_sweeps_list(ctx, page, page_size, fetch_all):
    """List advisor sweeps with optional filters (SA/TA)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get("admin/advisor/sweeps", params=p)
                items = data.get("items", data if isinstance(data, list) else [])
                all_items.extend(items)
                total = data.get("total", len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get("admin/advisor/sweeps", params=params)
            result = data if isinstance(data, dict) and "items" in data else {
                "items": data if isinstance(data, list) else [],
                "total": len(data) if isinstance(data, list) else 0,
            }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields)


@advisor_admin_sweeps.command(name="diff")
@click.option("--sweep-session-id", "sweep_session_id", required=True)
@click.pass_context
def advisor_admin_sweeps_diff(ctx, sweep_session_id):
    """Diff two advisor sweeps by sweep_session_id (SA only)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("admin/advisor/sweeps/diff",
                          params={"sweep_session_id": sweep_session_id})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@advisor_admin_sweeps.command(name="get")
@click.argument("sweep_id", metavar="SWEEP_ID")
@click.pass_context
def advisor_admin_sweeps_get(ctx, sweep_id):
    """Full sweep reconstruction by sweep_session_id (SA only)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"admin/advisor/sweeps/{sweep_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@advisor_admin_sweeps.command(name="retire")
@click.argument("sweep_id", metavar="SWEEP_ID")
@click.option("--dry-run", "dry_run", is_flag=True, default=False,
              help="Preview which proposals would be retired without persisting.")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def advisor_admin_sweeps_retire(ctx, sweep_id, dry_run, yes):
    """Retire all proposals from a sweep (SA only).

    \b
    Examples:
      torana advisor-admin sweeps retire <SWEEP_ID>
      torana advisor-admin sweeps retire <SWEEP_ID> --dry-run
    """
    if not dry_run and not yes:
        _confirm(f"Retire all proposals from sweep {sweep_id}?", yes=False)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    path = f"admin/advisor/sweeps/{sweep_id}/retire"
    if dry_run:
        path = f"admin/advisor/sweeps/{sweep_id}/retire:dry-run"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        prefix = "[dry-run] Would retire" if dry_run else "Retired"
        click.echo(f"{prefix} proposals from sweep: {sweep_id}")


@advisor_admin_sweeps.command(name="share-link")
@click.argument("sweep_id", metavar="SWEEP_ID")
@click.pass_context
def advisor_admin_sweeps_share_link(ctx, sweep_id):
    """Generate a time-limited HMAC-signed read link for a sweep (SA only)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.post(f"admin/advisor/sweeps/{sweep_id}/share-link", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, fields=fields)
    else:
        url = data.get("url", data.get("link", str(data))) if isinstance(data, dict) else str(data)
        click.echo(f"Share link: {url}")


@advisor_admin.command(name="tenant-summary")
@click.argument("tenant_id", metavar="TENANT_ID")
@click.pass_context
def advisor_admin_tenant_summary(ctx, tenant_id):
    """Tenant-level sweep summary (SA or TA for own tenant)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"admin/advisor/tenants/{tenant_id}/summary")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@advisor_admin.command(name="workspace-snapshot")
@click.argument("workspace_id", metavar="WORKSPACE_ID")
@click.pass_context
def advisor_admin_workspace_snapshot(ctx, workspace_id):
    """Get latest environment snapshot for a workspace (SA/TA)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(
            f"admin/advisor/workspaces/{workspace_id}/environment-snapshot/current"
        )
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@advisor_admin.command(name="workspace-timeline")
@click.argument("workspace_id", metavar="WORKSPACE_ID")
@click.pass_context
def advisor_admin_workspace_timeline(ctx, workspace_id):
    """Workspace advisor sweep timeline (SA/TA)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"admin/advisor/workspaces/{workspace_id}/timeline")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@advisor_admin.command(name="workspace-sweep")
@click.argument("workspace_id", metavar="WORKSPACE_ID")
@click.pass_context
def advisor_admin_workspace_sweep(ctx, workspace_id):
    """Trigger advisor refresh sweep for a workspace (super_admin only)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"admin/workspaces/{workspace_id}/sweep", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Triggered advisor sweep for workspace: {workspace_id}")


@advisor_admin.command(name="workspace-refresh-dry-run")
@click.argument("workspace_id", metavar="WORKSPACE_ID")
@click.pass_context
def advisor_admin_workspace_refresh_dry_run(ctx, workspace_id):
    """Dry-run advisor refresh (Stages 1–4 only, no persistence)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.post(
            f"admin/advisor/workspaces/{workspace_id}/refresh-dry-run", json={}
        )
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@advisor_admin.command(name="circuit-breaker-reset")
@click.pass_context
def advisor_admin_circuit_breaker_reset(ctx):
    """Reset the in-process advisor circuit breaker (SA only — for integration tests)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post("admin/advisor/circuit-breaker/reset", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo("Advisor circuit breaker reset.")


# ─────────────────────────────────────────────────────────────────────────────
# BACK-COMPAT — hidden aliases for the old `phaseN` / `phaseN-1` flat names.
# ⏳ ONE RELEASE ONLY (decision D4). Delete this block next release.
# ─────────────────────────────────────────────────────────────────────────────

def _register_legacy_phase_aliases() -> None:
    import copy
    for _n in (1, 2, 3):
        for _old, _grp in ((f"phase{_n}", programs_plan_group),
                           (f"phase{_n}-1", programs_execute_group)):
            _cmd = _grp.commands.get(f"phase{_n}")
            if _cmd is None:
                continue
            _alias = copy.copy(_cmd)
            _alias.name = _old
            _alias.hidden = True
            programs.add_command(_alias)


_register_legacy_phase_aliases()
