"""torana dashboard <ID> — one dashboard: read it as the screen shows it, change it, delete it.

Reading makes the calls the screen makes: the dashboard's definition
(GET /api/v1/dashboards/{id}), then one batch render of its widgets
(POST /api/v1/render/widgets). The server builds every sentence a card shows; this module
prints them (torana_cli/widget_card.py) and builds none.

Collection commands (list, create) are in dashboards.py.
"""

import sys

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.confirm import confirm as _confirm
from torana_cli.dashboards import with_start_here
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.section_descriptions import with_sections_help
from torana_cli.widget_card import (
    FAIL_ON, SECTION_KEYS, build_report, finish, print_card, render_batch, section_fields,
    summary_line, wants_health,
)


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _did(ctx) -> str:
    return ctx.obj.get("_dashboard_id", "") if ctx.obj else ""


@click.group(name="dashboard", invoke_without_command=True)
@click.argument("dashboard_id", metavar="DASHBOARD_ID")
@click.pass_context
def dashboard(ctx, dashboard_id):
    """One dashboard: read it as the screen shows it, change it, or delete it.

    The id comes from `torana dashboards list --app-id <APP_ID>`.

    {START_HERE}

    \b
    Change it:
      Rename or reconfigure               torana dashboard <ID> update --name "New name"
      Add or take off a widget            torana dashboard <ID> widgets add | remove <WIDGET_ID>
      Move it to another app              torana dashboard <ID> move --target-app-id <APP_ID>
      Delete it                           torana dashboard <ID> delete

    \b
    Examples:
      torana dashboard <ID> render
      torana dashboard <ID> render --fail-on stale --fail-on empty
      torana dashboard <ID> widgets list
    """
    ctx.ensure_object(dict)
    ctx.obj["_dashboard_id"] = dashboard_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


with_start_here(dashboard)


@dashboard.command(name="get")
@click.pass_context
def dashboard_get(ctx):
    """Get a dashboard's definition: its name, description and widgets.

    This is the definition only (what is on the dashboard). To see the data, as the
    screen shows it, use `torana dashboard <ID> render`.

    \b
    Examples:
      torana dashboard <ID> get
      torana dashboard <ID> get --json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get(f"dashboards/{_did(ctx)}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields)


@dashboard.command(name="render")
@click.option("--widget", "only_widgets", multiple=True, metavar="WIDGET_ID",
              help="Only this widget of the dashboard. Repeat for several.")
@click.option("--section", "sections", multiple=True, type=click.Choice(SECTION_KEYS),
              help="Only this part of each card. Repeat for several. Default: every part.")
@click.option("--refresh", is_flag=True, default=False,
              help="Run every query again now (skip the 30-minute result cache).")
@click.option("--no-health", is_flag=True, default=False,
              help="Skip the supply-health check (faster on a large app).")
@click.option("--fail-on", "fail_on", multiple=True, type=click.Choice(FAIL_ON),
              help="Exit 1 when a card is stale, empty or failed. Repeat for several. "
                   "A failed render exits 1 even without this.")
@click.pass_context
def dashboard_render(ctx, only_widgets, sections, refresh, no_health, fail_on):
    """Show a dashboard as the screen does: one card per widget.

    Each card is the widget's title and description, its supply health when something
    is not supplied, a stale line with what to do about it, the reason when it shows
    nothing, and its rows. The sentences are the server's, the same ones the screen
    prints.

    \b
    Use it to read a dashboard, to find out why a card is empty or stale, and in a
    script to check that a dashboard is working:
      exit 0   every card rendered and nothing matched --fail-on
      exit 1   a card failed to render, or a card matched --fail-on
      exit 3   no dashboard has this id

    \b
    --section keys:
      {SECTIONS}

    \b
    Related:
      one widget                  torana widget <WIDGET_ID> render
      every widget of an app      torana app <APP_ID> widgets list
      what is on the dashboard    torana dashboard <ID> widgets list

    \b
    Examples:
      torana dashboard <ID> render
      torana dashboard <ID> render --section empty --section health
      torana dashboard <ID> render --widget <WIDGET_ID> --refresh
      torana dashboard <ID> render --fail-on stale --fail-on empty
      torana dashboard <ID> render --json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    did = _did(ctx)
    client = _client(ctx)
    include_health = wants_health(sections, no_health)

    try:
        definition = client.get(f"dashboards/{did}")
        on_dashboard = [w for w in (definition.get("widgets") or []) if w.get("id")]
        ids = [w["id"] for w in on_dashboard]
        if only_widgets:
            strangers = [w for w in only_widgets if w not in ids]
            if strangers:
                click.echo(f"ERROR: not on this dashboard: {', '.join(strangers)}\n"
                           f"Widgets on '{definition.get('name')}':", err=True)
                for w in on_dashboard:
                    click.echo(f"  {w['id']}  {w.get('name')}", err=True)
                sys.exit(2)
            ids = [i for i in ids if i in only_widgets]
        widgets, data_age = (render_batch(client, ids, refresh=refresh, dashboard_id=did,
                                          include_health=include_health)
                             if ids else ([], None))
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml"):
        report = build_report(definition, widgets, data_age, fail_on)
        if sections:
            report["widgets"] = [section_fields(w, sections) for w in widgets]
        output(report, fmt=fmt)
    else:
        click.echo(click.style(definition.get("name") or did, bold=True))
        if data_age and data_age.get("text"):
            click.echo(f"  {data_age['text']}")
        click.echo()
        if not widgets:
            click.echo("No widgets on this dashboard.")
        for w in widgets:
            print_card(w, sections=sections, health_requested=include_health)
        if widgets:
            click.echo(summary_line(widgets))
    finish(widgets, fail_on)


with_sections_help(dashboard_render, "widget")


@dashboard.command(name="update")
@click.option("--name", default=None, help="New dashboard name.")
@click.option("--file", "input_file", default=None,
              help="JSON/YAML file with the fields to change (name, description, labels).")
@click.pass_context
def dashboard_update(ctx, name, input_file):
    """Update a dashboard's name or configuration.

    Changes the dashboard itself, not its widgets: use `torana dashboard <ID> widgets
    add | remove` for those, and `torana dashboard <ID> move` to put it in another app.

    \b
    Examples:
      torana dashboard <ID> update --name "New Name"
      torana dashboard <ID> update --file dashboard.yaml
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if not body:
        click.echo("Nothing to update: pass --name and/or --file.", err=True)
        raise SystemExit(2)
    client = _client(ctx)
    try:
        data = client.put(f"dashboards/{_did(ctx)}", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated dashboard: {_did(ctx)}")


@dashboard.command(name="delete")
@click.option("--yes", is_flag=True, help="Skip the confirmation prompt.")
@click.pass_context
def dashboard_delete(ctx, yes):
    """Delete a dashboard.

    The dashboard goes; its widgets and their queries stay (they can be on other
    dashboards). To delete a widget as well use `torana widget <WIDGET_ID> delete`.

    \b
    Examples:
      torana dashboard <ID> delete
      torana dashboard <ID> delete --yes
    """
    did = _did(ctx)
    _confirm(f"Delete dashboard {did}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"dashboards/{did}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    click.echo(f"Deleted dashboard {did}")


@dashboard.command(name="move")
@click.option("--target-app-id", "target_app_id", required=True,
              help="The app to move the dashboard to (the id from `torana apps list`).")
@click.pass_context
def dashboard_move(ctx, target_app_id):
    """Move a dashboard to another app.

    The dashboard leaves the app it is in and appears on the target app's Dashboards
    page. Its widgets are not moved with it: move each with `torana widget <WIDGET_ID>
    move --target-app-id <APP_ID>`.

    \b
    Examples:
      torana dashboard <ID> move --target-app-id <APP_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.post(f"dashboards/{_did(ctx)}/move",
                           json={"target_workspace_id": target_app_id})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt != "text":
        output(data, fmt=fmt, fields=fields)
    else:
        click.echo(f"Moved dashboard {_did(ctx)} to app {target_app_id}")


# ── dashboard <id> widgets — membership of the dashboard's widget set ──────────
# Dashboard↔Widget is many-to-many (dashboard_widgets table); these wrap
#   GET    /api/v1/dashboards/{id}            -> widgets[]        (list)
#   POST   /api/v1/dashboards/{id}/widgets    {widget_id}         (add existing)
#   DELETE /api/v1/dashboards/{id}/widgets/{widget_id}           (remove)
@dashboard.group(name="widgets", invoke_without_command=True)
@click.pass_context
def dashboard_widgets(ctx):
    """The widgets on this dashboard: list them, add an existing one, take one off.

    \b
    Examples:
      torana dashboard <ID> widgets list
      torana dashboard <ID> widgets add <WIDGET_ID>
      torana dashboard <ID> widgets remove <WIDGET_ID>
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@dashboard_widgets.command(name="list")
@click.pass_context
def dashboard_widgets_list(ctx):
    """List the widgets on this dashboard.

    Names, types and ids only. For each widget's data and state use
    `torana dashboard <ID> render`.

    \b
    Examples:
      torana dashboard <ID> widgets list
      torana dashboard <ID> widgets list --json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get(f"dashboards/{_did(ctx)}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    widgets = (data or {}).get("widgets", []) if isinstance(data, dict) else []
    output({"items": widgets, "total": len(widgets), "page": 1, "page_size": len(widgets)},
           fmt=fmt, fields=fields,
           columns=[("id", "ID", None), ("name", "NAME", 50),
                    ("widget_type", "TYPE", 8), ("query_id", "QUERY", None)])


@dashboard_widgets.command(name="add")
@click.argument("widget_id", metavar="WIDGET_ID")
@click.pass_context
def dashboard_widgets_add(ctx, widget_id):
    """Add an existing widget to this dashboard.

    The widget must exist already. To make a new one and put it on the dashboard in one
    step use `torana widgets create --dashboard-id <ID> --file w.json`.

    \b
    Examples:
      torana dashboard <ID> widgets add <WIDGET_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.post(f"dashboards/{_did(ctx)}/widgets", json={"widget_id": widget_id})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Added widget {widget_id} to dashboard {_did(ctx)}")


@dashboard_widgets.command(name="remove")
@click.argument("widget_id", metavar="WIDGET_ID")
@click.option("--yes", is_flag=True, help="Skip the confirmation prompt.")
@click.pass_context
def dashboard_widgets_remove(ctx, widget_id, yes):
    """Remove a widget from this dashboard (the widget itself is kept).

    \b
    Examples:
      torana dashboard <ID> widgets remove <WIDGET_ID> --yes
    """
    did = _did(ctx)
    _confirm(f"Remove widget {widget_id} from dashboard {did}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"dashboards/{did}/widgets/{widget_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    click.echo(f"Removed widget {widget_id} from dashboard {did}")
