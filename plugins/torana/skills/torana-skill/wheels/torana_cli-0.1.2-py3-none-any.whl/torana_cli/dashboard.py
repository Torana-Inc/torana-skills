"""torana dashboard <ID> — dashboard instance commands.

Wraps the existing detection-framework endpoints
  GET    /api/v1/dashboards/{id}   (dashboard:read)
  PUT    /api/v1/dashboards/{id}   (dashboard:update, DashboardUpdate body)
  DELETE /api/v1/dashboards/{id}   (dashboard:delete)
Collection ops (list/create) stay in dashboards.py — the plural file already
points here for instance verbs.
"""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _did(ctx) -> str:
    return ctx.obj.get("_dashboard_id", "") if ctx.obj else ""


@click.group(name="dashboard")
@click.argument("dashboard_id", metavar="DASHBOARD_ID")
@click.pass_context
def dashboard(ctx, dashboard_id):
    """Per-dashboard instance commands.

    \b
    Examples:
      torana dashboard <UUID> get
      torana dashboard <UUID> update --name "New Name"
      torana dashboard <UUID> update --file dashboard.yaml
      torana dashboard <UUID> delete
    """
    ctx.ensure_object(dict)
    ctx.obj["_dashboard_id"] = dashboard_id


@dashboard.command(name="get")
@click.pass_context
def dashboard_get(ctx):
    """Get a dashboard by ID (includes its config)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get(f"dashboards/{_did(ctx)}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields)


@dashboard.command(name="update")
@click.option("--name", default=None, help="New dashboard name.")
@click.option("--file", "input_file", default=None,
              help="JSON/YAML file with the DashboardUpdate body (name, config, ...).")
@click.pass_context
def dashboard_update(ctx, name, input_file):
    """Update a dashboard — name and/or its config (via --file)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if not body:
        click.echo("Nothing to update: pass --name and/or --file.", err=True)
        raise SystemExit(2)
    client = _client(ctx)
    try:
        data = client.put(f"dashboards/{_did(ctx)}", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt)


@dashboard.command(name="delete")
@click.option("--yes", is_flag=True, help="Skip the confirmation prompt.")
@click.pass_context
def dashboard_delete(ctx, yes):
    """Delete a dashboard by ID."""
    did = _did(ctx)
    _confirm(f"Delete dashboard {did}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"dashboards/{did}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    click.echo(f"Deleted dashboard {did}")


@dashboard.command(name="render")
@click.option("--workspace-id", default=None, help="Workspace UUID for context.")
@click.pass_context
def dashboard_render(ctx, workspace_id):
    """Render a dashboard's DATA — every widget on it, as the UI draws them.

    \b
    Renders all widgets in one call (GET /api/v1/render/dashboard/<id>). Each
    widget carries its own `status`, so one failing widget does NOT fail the
    dashboard — check every entry, not just the top-level response.

    \b
      torana dashboard <UUID> render
      torana dashboard <UUID> render --json

    \b
    To verify a whole app, render every dashboard in the workspace:
      torana dashboards list --workspace-id <WS>
    For a single widget, or to diagnose an empty one:
      torana widget <UUID> render | why | provenance
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    params = {}
    if workspace_id:
        params["workspace_id"] = workspace_id

    client = _client(ctx)
    try:
        data = client.get(f"render/dashboard/{_did(ctx)}", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt if fmt != "text" else "json")


# ── dashboard <id> widgets — membership of the dashboard's widget set ──────────
# Dashboard↔Widget is many-to-many (dashboard_widgets table); these wrap
#   GET    /api/v1/dashboards/{id}            -> widgets[]        (list)
#   POST   /api/v1/dashboards/{id}/widgets    {widget_id}         (add existing)
#   DELETE /api/v1/dashboards/{id}/widgets/{widget_id}           (remove)
@dashboard.group(name="widgets", invoke_without_command=True)
@click.pass_context
def dashboard_widgets(ctx):
    """Widgets belonging to this dashboard. Use `list`/`add`/`remove`."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@dashboard_widgets.command(name="list")
@click.pass_context
def dashboard_widgets_list(ctx):
    """List the widgets on this dashboard."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get(f"dashboards/{_did(ctx)}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    widgets = (data or {}).get("widgets", []) if isinstance(data, dict) else []
    output({"items": widgets, "total": len(widgets), "page": 1, "page_size": len(widgets)},
           fmt=fmt, fields=fields,
           columns=[("id", "ID", 36), ("name", "NAME", 40),
                    ("widget_type", "TYPE", 14), ("query_id", "QUERY", 36)])


@dashboard_widgets.command(name="add")
@click.argument("widget_id", metavar="WIDGET_ID")
@click.pass_context
def dashboard_widgets_add(ctx, widget_id):
    """Add an existing widget to this dashboard."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.post(f"dashboards/{_did(ctx)}/widgets", json={"widget_id": widget_id})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Added widget {widget_id} to dashboard {_did(ctx)}")


@dashboard_widgets.command(name="remove")
@click.argument("widget_id", metavar="WIDGET_ID")
@click.option("--yes", is_flag=True, help="Skip the confirmation prompt.")
@click.pass_context
def dashboard_widgets_remove(ctx, widget_id, yes):
    """Remove a widget from this dashboard (does not delete the widget itself)."""
    did = _did(ctx)
    _confirm(f"Remove widget {widget_id} from dashboard {did}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"dashboards/{did}/widgets/{widget_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    click.echo(f"Removed widget {widget_id} from dashboard {did}")
