"""torana scheduler <ID> — singular, instance-scoped scheduler commands.

The plural/singular split (pantheon-cli/CLAUDE.md → "CLI Hierarchy"): collection ops live in
`schedulers.py` (`list`, `create`, `tasks`, …); every command that targets ONE scheduler by id
lives here as `torana scheduler <ID> <verb>`. The instance verbs (`get`, `pause`, `resume`,
`execute`, `delete`, `update`) also remain on the plural group for backwards-compatibility, but
`torana scheduler <ID> get` is the discoverable, pattern-consistent form (every other resource
has it). All verbs key on the same `scheduler/tasks/{id}` endpoints the plural group uses.
"""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE
from torana_cli.output import output
from torana_cli.confirm import confirm as _confirm


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    return ToranaClient(base_url=get_settings(profile).base_url)


def _sid(ctx) -> str:
    return ctx.obj.get("_scheduler_id", "") if ctx.obj else ""


@click.group(name="scheduler", invoke_without_command=True)
@click.argument("scheduler_id", metavar="SCHEDULER_ID")
@click.pass_context
def scheduler(ctx, scheduler_id):
    """Instance operations on ONE scheduler, by id.

    \b
    Use the plural `torana schedulers list` to find the id, then act on it here.

    \b
    Examples:
      torana schedulers list                   find the id
      torana scheduler <SCHEDULER_ID> get
      torana scheduler <SCHEDULER_ID> pause
      torana scheduler <SCHEDULER_ID> resume
      torana scheduler <SCHEDULER_ID> execute  run it now, off-schedule
    """
    ctx.ensure_object(dict)
    ctx.obj["_scheduler_id"] = scheduler_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@scheduler.command(name="get")
@click.pass_context
def scheduler_get(ctx):
    """Get this scheduler's details."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get(f"scheduler/tasks/{_sid(ctx)}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields)


@scheduler.command(name="pause")
@click.pass_context
def scheduler_pause(ctx):
    """Pause this scheduler."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.post(f"scheduler/tasks/{_sid(ctx)}/pause")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt)


@scheduler.command(name="resume")
@click.pass_context
def scheduler_resume(ctx):
    """Resume this scheduler."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.post(f"scheduler/tasks/{_sid(ctx)}/resume")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt)


@scheduler.command(name="execute")
@click.pass_context
def scheduler_execute(ctx):
    """Execute this scheduler now."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.post(f"scheduler/tasks/{_sid(ctx)}/execute")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt)


@scheduler.command(name="delete")
@click.option("--yes", is_flag=True, default=False, help="Skip the confirmation prompt.")
@click.pass_context
def scheduler_delete(ctx, yes):
    """Delete this scheduler."""
    scheduler_id = _sid(ctx)
    if not yes and not _confirm(f"Delete scheduler {scheduler_id}?"):
        return
    client = _client(ctx, yes=False)
    try:
        client.delete(f"scheduler/tasks/{scheduler_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    click.echo(f"Deleted scheduler {scheduler_id}")
