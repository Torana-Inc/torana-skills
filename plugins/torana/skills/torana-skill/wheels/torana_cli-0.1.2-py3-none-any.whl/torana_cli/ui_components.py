"""torana ui-components — UI component management commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 35),
    ("component_type", "TYPE", 20),
    ("workspace_id", "WORKSPACE_ID", 36),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(name="ui-components")
def ui_components():
    """Manage UI components.

    \b
    Examples:
      torana ui-components list
      torana ui-components get <UUID>
      torana ui-components create --name "Risk Score Card" --file component.yaml
      torana ui-components delete <UUID> --yes
    """


@ui_components.command(name="list")
@click.option("--workspace-id", default=None, help="Filter by workspace UUID.")
@click.option("--type", "component_type", default=None, help="Filter by component type.")
@click.option("--search", default=None, help="Search by name.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def ui_components_list(ctx, workspace_id, component_type, search, page, page_size):
    """List UI components."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if workspace_id:
        params["workspace_id"] = workspace_id
    if component_type:
        params["component_type"] = component_type
    if search:
        params["search"] = search

    client = _client(ctx)
    try:
        data = client.get("ui-components/", params=params)
        result = data if isinstance(data, dict) and "items" in data else {
            "items": data if isinstance(data, list) else [],
            "total": len(data) if isinstance(data, list) else 0,
            "page": page, "page_size": effective_page_size
        }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@ui_components.command(name="get")
@click.argument("component_id", metavar="COMPONENT_ID")
@click.pass_context
def ui_components_get(ctx, component_id):
    """Get details for a specific UI component."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"ui-components/{component_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@ui_components.command(name="create")
@click.option("--name", default=None)
@click.option("--workspace-id", default=None, help="Workspace UUID.")
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def ui_components_create(ctx, name, workspace_id, input_file):
    """Create a new UI component."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if workspace_id:
        body["workspace_id"] = workspace_id

    if not body.get("name"):
        click.echo("ERROR: --name is required.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post("ui-components/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created UI component: {data.get('id', 'unknown')}")


@ui_components.command(name="update")
@click.argument("component_id", metavar="COMPONENT_ID")
@click.option("--name", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def ui_components_update(ctx, component_id, name, input_file):
    """Update a UI component."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"ui-components/{component_id}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated UI component: {component_id}")


@ui_components.command(name="delete")
@click.argument("component_id", metavar="COMPONENT_ID")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def ui_components_delete(ctx, component_id, yes):
    """Delete a UI component."""
    _confirm(f"Delete UI component {component_id}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"ui-components/{component_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted UI component: {component_id}")


# ──────────────────────────────────────────────────────────────────────────
# Instance reads regrouped from `<noun>-by-<param>` leaves onto verbs
# (CLI Discoverability Contract, rule 2 — see ../CLAUDE.md). The route
# parameter belongs in the positional ARGUMENT, not the command name.
#
# Old flat names remain as HIDDEN aliases for ONE release (D4).
# ──────────────────────────────────────────────────────────────────────────


@ui_components.group(name="by-name")
def ui_components_by_name_grp():
    """Look a UI component up by NAME rather than id.

    Examples:
      torana ui-components by-name get --help
    """


@ui_components.group(name="provider")
def ui_components_provider_grp():
    """UI components belonging to one provider.

    Examples:
      torana ui-components provider get --help
    """


@ui_components.group(name="service")
def ui_components_service_grp():
    """UI component service registration.

    Examples:
      torana ui-components service unregister --help
    """


@ui_components_by_name_grp.command(name="get")
@click.argument("COMPONENT_NAME", metavar="COMPONENT_NAME")
@click.pass_context
def ui_components_by_name_by_component_name(ctx, component_name):
    """Get UI component by name."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"ui-components/by-name/{component_name}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@ui_components_provider_grp.command(name="get")
@click.argument("PROVIDER_ID", metavar="PROVIDER_ID")
@click.option("--page", "page", type=int, default=1, help="Page number")
@click.option("--size", "size", type=int, default=20, help="Page size")
@click.option("--status", "status", default=None, help="Filter by status")
@click.option("--component-type", "component_type", default=None, help="Filter by component type")
@click.pass_context
def ui_components_provider_by_provider_id(ctx, provider_id, page, size, status, component_type):
    """Get UI components for a provider."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"ui-components/provider/{provider_id}"
    params = {}
    if page is not None:
        params["page"] = page
    if size is not None:
        params["size"] = size
    if status is not None:
        params["status"] = status
    if component_type is not None:
        params["component_type"] = component_type

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@ui_components_service_grp.command(name="unregister")
@click.argument("SERVICE_NAME", metavar="SERVICE_NAME")
@click.option("--page", "page", type=int, default=1, help="Page number")
@click.option("--size", "size", type=int, default=20, help="Page size")
@click.option("--status", "status", default=None, help="Filter by status")
@click.option("--component-type", "component_type", default=None, help="Filter by component type")
@click.pass_context
def ui_components_service_by_service_name(ctx, service_name, page, size, status, component_type):
    """Get UI components by service name."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"ui-components/service/{service_name}"
    params = {}
    if page is not None:
        params["page"] = page
    if size is not None:
        params["size"] = size
    if status is not None:
        params["status"] = status
    if component_type is not None:
        params["component_type"] = component_type

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@ui_components.command(name="summary")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def ui_components_summary(ctx, page, page_size, fetch_all):
    """Get UI component statistics."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "ui-components/stats/summary"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@ui_components.command(name="activate")
@click.argument("COMPONENT_ID", metavar="COMPONENT_ID")
@click.pass_context
def ui_components_activate(ctx, component_id):
    """Activate a UI component."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"ui-components/{component_id}/activate"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@ui_components.command(name="deactivate")
@click.argument("COMPONENT_ID", metavar="COMPONENT_ID")
@click.pass_context
def ui_components_deactivate(ctx, component_id):
    """Deactivate a UI component."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"ui-components/{component_id}/deactivate"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ──────────────────────────────────────────────────────────────────────────
# BACK-COMPAT — hidden aliases for the old `<noun>-by-<param>` names.
# ⏳ ONE RELEASE ONLY (decision D4). Delete this block next release.
# ──────────────────────────────────────────────────────────────────────────

_LEGACY_BY_PARAM_UI_COMPONENTS = {
    "by-name-by-component-name": ("by-name", "get"),
    "provider-by-provider-id": ("provider", "get"),
    "service-by-service-name": ("service", "unregister"),
}


def _register_legacy_ui_components_by_param() -> None:
    """Old flat names, hidden so they cannot be discovered anew."""
    import copy
    for _old, (_sub, _verb) in _LEGACY_BY_PARAM_UI_COMPONENTS.items():
        _grp = ui_components.commands.get(_sub)
        if not isinstance(_grp, click.Group):
            continue
        _cmd = _grp.commands.get(_verb)
        if _cmd is None:
            continue
        # ⛔ Never let an alias overwrite a real group of the same name.
        if isinstance(ui_components.commands.get(_old), click.Group):
            continue
        _alias = copy.copy(_cmd)
        _alias.name = _old
        _alias.hidden = True
        ui_components.add_command(_alias)


_register_legacy_ui_components_by_param()
