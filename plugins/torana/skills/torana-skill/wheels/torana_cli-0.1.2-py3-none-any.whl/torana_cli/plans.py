"""torana plans — plan collection management commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW, CollectionGroup
from torana_cli.output import output
from torana_cli.rules import _load_input_file

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 40),
    ("workspace_id", "WORKSPACE", 36),
    ("state", "STATE", 12),
    ("description", "DESCRIPTION", 40),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(cls=CollectionGroup, singular="plan")
def plans():
    """Manage workspace plans (collection operations).

    \b
    Instance commands (get, update, delete, etc.) are under:
      torana plan <UUID> <verb>

    \b
    Examples:
      torana plans list
      torana plans create --name "My Plan" --workspace-id <UUID>
    """


@plans.command(name="list")
@click.option("--workspace-id", default=None, help="Filter by workspace UUID.")
@click.option("--search", default=None, help="Search by name.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def plans_list(ctx, workspace_id, search, page, page_size):
    """List plans."""
    list_plans_core(ctx, workspace_id=workspace_id, search=search, page=page,
                    page_size=page_size)


def list_plans_core(ctx, *, workspace_id=None, search=None, page=1, page_size=None):
    """Shared plans-list routine.

    `torana plans list` and `torana workspace <id> plans list` both call this;
    the workspace form just pre-binds `workspace_id`. Single source of truth.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if workspace_id:
        params["workspace_id"] = workspace_id
    if search:
        params["search"] = search

    client = _client(ctx)
    try:
        data = client.get("plans/", params=params)
        result = data if isinstance(data, dict) and "items" in data else {
            "items": data if isinstance(data, list) else [],
            "total": len(data) if isinstance(data, list) else 0,
            "page": page, "page_size": effective_page_size
        }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@plans.command(name="create")
@click.option("--name", default=None)
@click.option("--description", default=None)
@click.option("--workspace-id", default=None, help="Workspace UUID.")
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def plans_create(ctx, name, description, workspace_id, input_file):
    """Create a new plan."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if description:
        body["description"] = description
    if workspace_id:
        body["workspace_id"] = workspace_id

    if not body.get("name"):
        click.echo("ERROR: --name is required (or provide --file with 'name' field).", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post("plans/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created plan: {data.get('id', 'unknown')}")
        click.echo(f"  Name: {data.get('name', '')}")
