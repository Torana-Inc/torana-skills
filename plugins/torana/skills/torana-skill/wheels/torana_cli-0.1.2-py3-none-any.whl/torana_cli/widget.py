"""torana widget <ID> — one widget: read it as the screen shows it, ask why, change it, delete it.

Reading prints the widget's card from the server's render response. The server builds every
sentence the card shows (pantheon-viz card_wording.py); this module prints them through
torana_cli/widget_card.py and builds none.

Collection commands (list, create) are in widgets.py.
"""

import sys

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import (
    APIError, EXIT_VALIDATION, ToranaClient, handle_api_error, handle_auth_error,
)
from torana_cli.config.settings import get_settings
from torana_cli.dashboards import fetch_dashboards, with_start_here
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm
from torana_cli import chat_core
from torana_cli.chats import read_message, run_turn, wait_options
from torana_cli.section_descriptions import with_sections_help
from torana_cli.supply_health import render_health
from torana_cli.widget_card import (
    FAIL_ON, SECTION_KEYS, finish, print_card, section_fields, wants_health,
)


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(name="widget", invoke_without_command=True)
@click.argument("widget_id", metavar="WIDGET_ID")
@click.pass_context
def widget(ctx, widget_id):
    """One widget: read it as the screen shows it, ask why, change it, or delete it.

    The id comes from `torana dashboard <ID> widgets list` or `torana app <APP_ID> widgets list`.

    {START_HERE}

    \b
    Change it:
      Rename, retype, reconfigure         torana widget <ID> update --file w.json
      Change its SQL                      torana widget <ID> update --sql "SELECT ..."
      Move it to another app              torana widget <ID> move --target-app-id <APP_ID>
      Delete it and its query             torana widget <ID> delete

    \b
    Examples:
      torana widget <ID> render
      torana widget <ID> render --section empty --section health
      torana widget <ID> health
      torana widget <ID> why
    """
    ctx.ensure_object(dict)
    ctx.obj["_widget_id"] = widget_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


with_start_here(widget)


def _wid(ctx) -> str:
    return ctx.obj.get("_widget_id", "") if ctx.obj else ""


@widget.command(name="get")
@click.pass_context
def widget_get(ctx):
    """Get a widget's definition: its name, type, display settings and query id.

    This is the definition only. To see its data, as the screen shows it, use
    `torana widget <ID> render`.

    \b
    Examples:
      torana widget <ID> get
      torana widget <ID> get --fields id,name,query_id
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"widgets/{_wid(ctx)}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@widget.command(name="render")
@click.option("--section", "sections", multiple=True, type=click.Choice(SECTION_KEYS),
              help="Only this part of the card. Repeat for several. Default: every part.")
@click.option("--refresh", is_flag=True, default=False,
              help="Run the query again now (skip the 30-minute result cache).")
@click.option("--no-health", is_flag=True, default=False,
              help="Skip the supply-health check.")
@click.option("--fail-on", "fail_on", multiple=True, type=click.Choice(FAIL_ON),
              help="Exit 1 when the card is stale, empty or failed. Repeat for several. "
                   "A failed render exits 1 even without this.")
@click.pass_context
def widget_render(ctx, sections, refresh, no_health, fail_on):
    """Show one widget as the screen does: its card, with the rows.

    The card is the widget's title and description, how to read it, its supply health
    when something is not supplied, a stale line with what to do about it, the reason
    when it shows nothing, and its rows. The sentences are the server's, the same ones
    the screen prints.

    \b
    Use it to read a widget, and to find out why it is empty or stale:
      torana widget <ID> render --section empty --section health
    says why it shows nothing and who can fix it.

    \b
    Exit codes, for scripts:
      exit 0   the card rendered and nothing matched --fail-on (an empty widget is exit 0)
      exit 1   the render failed, or the card matched --fail-on
      exit 3   no widget has this id

    \b
    --section keys:
      {SECTIONS}

    \b
    Rows: the card shows what the widget's saved query returns. For more rows, or every
    row, page the query itself: torana widget <ID> explore --page 2

    \b
    Examples:
      torana widget <ID> render
      torana widget <ID> render --section empty --section health
      torana widget <ID> render --refresh --fail-on stale
      torana widget <ID> render --json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    include_health = wants_health(sections, no_health)

    client = _client(ctx)
    try:
        resp = client.get(f"render/widget/{_wid(ctx)}",
                          params={"refresh": "true" if refresh else "false",
                                  "include_health": "true" if include_health else "false"})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # json/yaml: the server's render response as it is (card, health, data, timing).
    if fmt in ("json", "yaml"):
        output(section_fields(resp, sections) if sections else resp, fmt=fmt, fields=fields)
    else:
        print_card(resp, sections=sections, show_semantic=True, health_requested=include_health)
    finish([resp], fail_on, single=True)


with_sections_help(widget_render, "widget")


@widget.command(name="health")
@click.option("--all", "show_all", is_flag=True, default=False,
              help="List every field that is not supplied, not just the worst 3.")
@click.pass_context
def widget_health(ctx, show_all):
    """Show whether every field this widget reads is supplied, and who can fix it.

    A widget can return rows and still be missing a field (those cells are empty or
    zero), or return nothing because a field is never supplied on this account. This
    names each such field, why it is missing, and whether closing the gap is yours
    (connect or configure a tool) or ours.

    \b
    The card's Health line (`torana widget <ID> render`) is the one-line form of this.

    \b
    Examples:
      torana widget <ID> health
      torana widget <ID> health --all
      torana widget <ID> health --json
    """
    render_health(ctx, "widget", _wid(ctx), show_all=show_all)


@widget.command(name="verdict")
@click.pass_context
def widget_verdict(ctx):
    """Show the platform's one-word reason for an empty widget (often 'unknown').

    One of: blocked (a tool that could supply this is not connected), empty (everything
    is connected and there is nothing to show), stale (the source's sync is failing),
    live (rows returned), unknown (the platform cannot tell).

    \b
    This often answers `unknown`. To find out why a widget shows nothing and who can
    fix it, use:
      torana widget <ID> render --section empty --section health

    \b
    Examples:
      torana widget <ID> verdict
      torana widget <ID> verdict --json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.get(f"render/widget/{_wid(ctx)}/verdict")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt in ("json", "yaml"):
        output(data, fmt=fmt)
        return

    verdict = (data.get("verdict") or "unknown").upper()
    # Glyph + word, never colour alone.
    cue = {"LIVE": "✓", "EMPTY": "○", "BLOCKED": "✕", "STALE": "⚠", "UNKNOWN": "?"}.get(verdict, "?")
    click.echo(f"\nWidget {data.get('widget_id')}")
    click.echo(f"  [{cue} {verdict}]  {data.get('message') or ''}")
    if data.get("owner"):
        click.echo(f"  owner: {data['owner']}")
    if data.get("missing_integrations"):
        click.echo(f"  connect: {', '.join(data['missing_integrations'])}")
    for k, v in (data.get("evidence") or {}).items():
        click.echo(f"  {k:20} {v}")
    if verdict == "UNKNOWN":
        click.echo(f"  For the reason and who can fix it: "
                   f"torana widget {_wid(ctx)} render --section empty --section health")
    click.echo("")


@widget.command(name="chat")
@click.option("-m", "--message", default=None, help="Your question.")
@click.option("--message-file", default=None, metavar="FILE",
              help="Read the question from a file (`-` = stdin).")
@click.option("--app-id", "app_id", default=None,
              help="The app the widget is read in. Default: the widget's own app.")
@click.option("--agent", "agent_id", default=None,
              help="Ask this agent instead of the platform's Ask AI assistant.")
@click.option("--new", "new_session", is_flag=True, default=False,
              help="Start a fresh chat even if one about this widget already exists.")
@wait_options
@click.pass_context
def widget_chat(ctx, message, message_file, app_id, agent_id, new_session, stream, no_wait, timeout):
    """Ask the app's assistant a question about this widget.

    This is the "ask about this widget" button on a card: it opens a chat with the
    Ask AI assistant that is pinned to the widget, sends your question and waits for
    the reply. The reply is printed on stdout; the chat's id is printed on stderr so
    you can continue it.

    \b
    Continue the same chat:   torana chat <CHAT_ID> send -m "and by team?"
    Read it back:             torana chat <CHAT_ID> history
    Is widget chat on?        torana widget <ID> chat-enabled

    \b
    Exit codes: 0 the assistant replied · 7 it is waiting on a question from you
    (answer with `torana chat <CHAT_ID> answer`) · 8 the turn failed, timed out or was
    cancelled · 9 --no-wait and a turn is already running · 3 no such widget, or the
    Ask AI assistant is not published on this account.

    \b
    Examples:
      torana widget <ID> chat -m "Why did this number go up this week?"
      torana widget <ID> chat -m "Which teams own these?" --stream
      torana widget <ID> chat -m "Summarise this widget" --json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    wid = _wid(ctx)
    text = read_message(message, message_file)
    if not text:
        raise click.UsageError("Give your question with -m or --message-file.")

    client = _client(ctx)
    try:
        current = client.get(f"widgets/{wid}/")
        app_id = app_id or current.get("workspace_id")
        if not app_id:
            click.echo("ERROR: this widget belongs to no app; pass --app-id.", err=True)
            sys.exit(2)
        app = client.get(f"workspaces/{app_id}")
        if not agent_id:
            agent_id = chat_core.resolve_ask_ai_agent(client)["agent_id"]
        # The anchor the screen sends for a widget on a dashboard: "<app id>/<widget id>".
        created = chat_core.create_chat_session(
            client, agent_id=agent_id, app_id=app_id,
            app_name=app.get("name") if isinstance(app, dict) else None,
            anchor={"type": "workspace_widget", "id": f"{app_id}/{wid}"},
            new_session=new_session)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    session_id = created.get("session_id")
    if fmt == "text":
        click.echo(f"[chat {session_id}]", err=True)
    run_turn(ctx, fmt, stream=stream, no_wait=no_wait, call=lambda printer: chat_core.send_and_wait(
        client, session_id=session_id, agent_id=agent_id, message=text,
        wait=not no_wait, timeout=timeout, on_event=printer))


@widget.command(name="chat-enabled")
@click.pass_context
def widget_chat_enabled(ctx):
    """Show whether widget chat is switched on for this account.

    Widget chat is the "ask about this widget" button on a card. It is a setting of
    the whole account, not of one widget: the answer is the same for every widget id.

    \b
    Examples:
      torana widget <ID> chat-enabled
      torana widget <ID> chat-enabled --json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.get("context-lake/widget-chat-enabled")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt in ("json", "yaml"):
        output({"enabled": bool((data or {}).get("enabled"))}, fmt=fmt)
        return
    state = "on" if (data or {}).get("enabled") else "off"
    click.echo(f"Widget chat is {state} for this account.")


def _emit_provenance_tree(resp: dict) -> None:
    """Render the lineage tree as text.

    Deliberately shows ROW ACCOUNTING inline on every hop, not behind a flag: it
    is what turns this from an audit artifact into a debugging tool. A shipped
    bundle once dropped 80,532 of 80,899 rows silently — "rows in -> rows out"
    per hop is the only place in the product that makes that visible.

    Every state marker pairs an ICON with WORDS (never colour alone), so the
    output is readable to a colour-blind reader and in a plain log.
    """
    nodes = (resp or {}).get("nodes") or []
    if not nodes:
        click.echo("No lineage resolved for this widget.")
        return

    # T4 column scoping (§ 3.9.8). When the resolver scoped the tree to the columns
    # THIS widget reads, some base tables are demoted: joined by an upstream transformer
    # for columns the widget never touches. We SHOW them (a verifier needs the full
    # lineage) but clearly separate them below the in-scope tables so "where did
    # severity come from" isn't drowned by enrichment joins the widget didn't read.
    scoped = bool((resp or {}).get("scoped"))
    demoted = [n for n in nodes if scoped and n.get("in_scope") is False]
    primary = [n for n in nodes if not (scoped and n.get("in_scope") is False)]
    if scoped:
        click.echo("i Scoped to the columns this widget reads. Tables joined only for "
                   "other columns are listed separately at the end.\n")

    def _emit_nodes(node_list):
        by_depth = {}
        for n in node_list:
            by_depth.setdefault(n.get("depth", 0), []).append(n)
        for depth in sorted(by_depth):
            for n in by_depth[depth]:
                _emit_one(n)

    def _emit_one(n):
            depth = n.get("depth", 0)
            indent = "  " * depth
            kind = n.get("kind", "unknown")
            rows = n.get("row_count")
            rows_s = f"{rows:,} rows" if isinstance(rows, int) else "rows unknown"
            click.echo(f"{indent}{n['relation']}  [{kind}]  {rows_s}")

            prod = n.get("producer") or {}
            if prod.get("name"):
                click.echo(f"{indent}    produced by transformer '{prod['name']}'"
                           f"  last ran {prod.get('last_success_at') or 'never'}")

            acc = n.get("row_accounting") or {}
            if acc:
                verdict = acc.get("verdict")
                marker = {"row_drop": "!! ROW DROP",
                          "expected_aggregate": "ok  aggregate",
                          "ok": "ok  no loss"}.get(verdict, verdict or "")
                click.echo(f"{indent}    {acc['rows_in']:,} in -> {acc['rows_out']:,} out"
                           f"   [{marker}]")

            for s in (n.get("sources") or []):
                click.echo(f"{indent}    {s.get('source_system') or '(unknown)':<16}"
                           f"{s.get('row_count', 0):>9,}   landed {s.get('last_landed') or '?'}")
                for i in (s.get("integrations") or []):
                    click.echo(f"{indent}        - {i.get('name')}  "
                               f"[{i.get('kind')}]  via {i.get('data_source')}  "
                               f"({i.get('runs')} runs, {i.get('records_out'):,} records)")
                if s.get("attribution_note"):
                    click.echo(f"{indent}        i {s['attribution_note']}")

            if n.get("unresolved_runs"):
                click.echo(f"{indent}    i {n['unresolved_runs']} run(s) could not be "
                           f"attributed to a sink table.")

    # In-scope lineage first (what actually feeds the widget's columns).
    _emit_nodes(primary)

    # Then the demoted tables, clearly fenced off so they don't read as sources.
    if demoted:
        click.echo("\n-- Joined but NOT read by this widget "
                   "(shown for completeness) --")
        for n in demoted:
            reason = n.get("scope_reason") or "not read by this query"
            rows = n.get("row_count")
            rows_s = f"{rows:,} rows" if isinstance(rows, int) else "rows unknown"
            click.echo(f"  {n['relation']}  [{n.get('kind','unknown')}]  {rows_s}")
            click.echo(f"      i {reason}")

    _emit_vocabulary(resp)

    for w in (resp or {}).get("warnings") or []:
        click.echo(f"\n!! {w.get('code')}: {w.get('message')}", err=True)
    if (resp or {}).get("max_depth_reached"):
        click.echo("\ni Lineage was truncated at the maximum depth.", err=True)


def _emit_vocabulary(resp: dict) -> None:
    """The POLICY back-pointer: which decisions shaped these numbers.

    The tree above answers "where did these ROWS come from". This answers "which
    DECISIONS shaped them" — the question a tenant about to change an SLA window is
    actually asking. Both read the same `workspace_vocab_usage` rows as the policy
    page's Impact tab, walked in opposite directions, so they cannot disagree.

    Markers pair an ICON with WORDS, never colour alone (same rule as the tree).
    """
    vocab = (resp or {}).get("vocabulary")
    if not vocab:
        return  # [] = genuinely no policy input; a failed lookup emits a warning instead

    click.echo("\n-- Policy this widget depends on --")
    click.echo("   i Changing one of these changes the numbers above.")
    for v in vocab:
        val = v.get("resolved_value") or {}
        shown = val.get("value") if isinstance(val, dict) else val
        # "default" is load-bearing, not decoration: a tenant reading a number
        # computed from a baseline they never authored should know that.
        origin = "platform default" if v.get("default_in_effect") else "tenant-set"
        click.echo(f"  {v.get('vocab_key')}  = {shown}   [{origin}]")
        consumers = ", ".join(v.get("consumers") or [])
        if v.get("tenant_global"):
            # The widest blast radius in the system — say so in words.
            click.echo(f"      ! applies PLATFORM-WIDE (all apps)  via: {consumers}")
        else:
            click.echo(f"      via: {consumers}")


@widget.command(name="provenance")
@click.option("--sources", is_flag=True, default=False,
              help="Show only the flat per-integration source table (skip the tree).")
@click.pass_context
def widget_provenance(ctx, sources):
    """Show where this widget's data came from: lineage, row counts, sources.

    Walks the widget's lineage from the relation it renders down to the base sink
    tables, and attributes each base table to the integrations that wrote it.

    \b
      torana widget <UUID> provenance             # the lineage tree
      torana widget <UUID> provenance --sources   # just "which integrations fed this"
      torana widget <UUID> provenance --json      # full envelope

    Row accounting ("N in -> M out" per hop) is the highest-value line. A widget
    reading a fraction of its base table is the signature of a silent filter bug
    — the kind that renders a confident, precise, wrong number with no error.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        resp = client.get(f"render/widget/{_wid(ctx)}/provenance")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml"):
        output(resp, fmt=fmt, fields=fields)
        return

    name = (resp or {}).get("widget_name")
    if name:
        click.echo(click.style(f"Where '{name}' gets its data", bold=True))
        click.echo()

    if sources:
        rows = []
        for n in (resp or {}).get("nodes") or []:
            for s in (n.get("sources") or []):
                for i in (s.get("integrations") or []):
                    rows.append({
                        "table": n["relation"],
                        "source": s.get("source_system"),
                        "integration": i.get("name"),
                        "kind": i.get("kind"),
                        "data_source": i.get("data_source"),
                        "runs": i.get("runs"),
                        "records": i.get("records_out"),
                    })
        if not rows:
            click.echo("No integration-attributed sources for this widget.")
            return
        output({"items": rows, "total": len(rows)}, fmt="text", columns=[
            ("table", "TABLE", 26), ("source", "SOURCE", 14),
            ("integration", "INTEGRATION", 34), ("kind", "KIND", 12),
            ("data_source", "DATA SOURCE", 30), ("records", "RECORDS", 10),
        ])
        return

    _emit_provenance_tree(resp)


def _fmt_count(n) -> str:
    return f"{n:,}" if isinstance(n, int) else "?"


def _emit_why_funnel(resp: dict, show_sql: bool = False) -> None:
    """Render the predicate funnel as a text waterfall.

    Shows base → each cumulative predicate → final, marking WHERE the count
    collapses, then the column-health note on that step. Icon+text markers only
    (no colour-only cues — the color-blindness rule). With show_sql, prints each
    step's slice SQL beneath it so the user can copy it into the SQL playground.
    """
    if not (resp or {}).get("decomposable"):
        # Not a funnel-able query (join/subquery FROM, OR-root, or no plan yet).
        for w in (resp or {}).get("warnings") or []:
            click.echo(f"i {w.get('message')}")
        click.echo("\nThis query can't be broken into a predicate funnel. "
                   "Use `provenance` to see where its rows come from, or `explore` "
                   "to run slices of the SQL yourself.")
        return

    relation = resp.get("relation")
    steps = resp.get("steps") or []

    # No predicate to decompose (no WHERE, or a single base step). The number isn't
    # produced by a filter, so a funnel would be noise — say plainly what it reads.
    if len(steps) <= 1:
        base = steps[0].get("count") if steps else None
        n = f"all {base:,} rows of " if isinstance(base, int) else ""
        rel = relation or "its source relation"
        click.echo(f"This widget applies no filters — it reads {n}{rel}.")
        click.echo("The values shown are the numbers inside those rows, not a "
                   "filtered count, so there's nothing to break down here.")
        return

    # Width for right-aligned counts.
    w = max((len(_fmt_count(s.get("count"))) for s in steps), default=6)
    click.echo(f"Rows of {relation} surviving each filter:\n")
    for i, s in enumerate(steps):
        count = s.get("count")
        cs = _fmt_count(count).rjust(w)
        marker = "  <== collapses here" if s.get("collapse") else ""
        if i == 0:
            click.echo(f"  {cs}   {s.get('label')}{marker}")
        else:
            delta = s.get("delta")
            pct = f"  ({delta * 100:+.1f}%)" if isinstance(delta, (int, float)) else ""
            click.echo(f"  {cs}   + {s.get('label')}{pct}{marker}")
        if show_sql and s.get("count_sql"):
            click.echo(f"  {' ' * w}     {s['count_sql']}")
    click.echo(f"  {'-' * w}")
    click.echo(f"  {_fmt_count(resp.get('final_value')).rjust(w)}   = the widget's number")

    for ch in (resp.get("column_health") or []):
        note = ch.get("note")
        if note:
            click.echo(f"\n!! {note}")
        tv = ch.get("top_values") or []
        if tv:
            vals = ", ".join(f"{t.get('value')} ({_fmt_count(t.get('count'))})" for t in tv)
            click.echo(f"   {ch.get('column')} top values: {vals}")

    for warn in (resp or {}).get("warnings") or []:
        click.echo(f"\ni {warn.get('message')}", err=True)


@widget.command(name="why")
@click.option("--sql", "show_sql", is_flag=True, default=False,
              help="Show each step's slice SQL beneath it (copy into the SQL playground).")
@click.pass_context
def widget_why(ctx, show_sql):
    """Why is this number what it is? The filters applied, step by step.

    Provenance tells you WHERE the rows came from; this tells you WHY the number
    is what it is. It re-runs the widget's query in cumulative slices and shows
    where the row set collapses — and, on the collapse step, whether the filtered
    column is even populated (e.g. "asset_environment is NULL for 100% of rows").

    \b
      torana widget <UUID> why           # the funnel waterfall
      torana widget <UUID> why --sql     # + each step's slice SQL
      torana widget <UUID> why --json    # full envelope (count_sql per step)

    The classic catch: a widget shows 0 not because there's no risk, but because
    it filters on a column that's empty. Provenance shows "no rows lost"; this
    shows the filter that produced the 0. Each step's SQL lets you verify the
    count yourself — run it, or open it in the SQL playground.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        resp = client.get(f"render/widget/{_wid(ctx)}/why")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml"):
        output(resp, fmt=fmt, fields=fields)
        return

    name = (resp or {}).get("widget_name")
    if name:
        click.echo(click.style(f"Why '{name}' shows what it shows", bold=True))
        click.echo()
    _emit_why_funnel(resp, show_sql=show_sql)


@widget.command(name="explore")
@click.option("--sql", default=None, metavar="SQL",
              help="SQL to run (defaults to the widget's own query — use --show-sql to see it).")
@click.option("--show-sql", is_flag=True, default=False,
              help="Print the widget's underlying SQL and exit (don't run it).")
@click.option("--page", default=1, type=int, help="Page number (1-based, default 1).")
@click.option("--page-size", default=50, type=int, help="Rows per page (max 1000, default 50).")
@click.pass_context
def widget_explore(ctx, sql, show_sql, page, page_size):
    """Explore a widget's data: page its query's rows, or run a query of your own.

    The widget's real query is the source of truth. With no --sql, this runs the
    widget's own SQL with TRUE database-side pagination and shows the REAL total.
    Pass --sql to run a modified query (SELECT-only), mirroring the UI's Explore drawer.

    \b
      torana widget <UUID> explore --show-sql              # print the widget's SQL
      torana widget <UUID> explore                         # run the widget's SQL (page 1)
      torana widget <UUID> explore --page 2                # next page
      torana widget <UUID> explore --sql "SELECT ... "     # run a modified query
      torana widget <UUID> explore --json                  # full result envelope
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    # Resolve the widget's SQL (needed for --show-sql and as the default query).
    try:
        widget = client.get(f"widgets/{_wid(ctx)}/")
        query = client.get(f"queries/{widget['query_id']}/")
        widget_sql = query.get("sql_command", "")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if show_sql:
        click.echo(widget_sql)
        return

    run_sql = sql or widget_sql
    if not run_sql:
        click.echo("No SQL to run (widget has no query).", err=True)
        return

    try:
        resp = client.post("render/explore",
                           json={"sql": run_sql, "page": page, "page_size": page_size,
                                 "widget_id": _wid(ctx)})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Backend returns rows as arrays (row-ordered by columns); zip into dicts.
    cols = resp.get("columns") or []
    rows = resp.get("rows") or []
    items = [dict(zip(cols, r)) for r in rows]

    if fmt in ("json", "yaml"):
        output({"items": items, "total": resp.get("total", len(items)),
                "page": resp.get("page", 1), "page_size": resp.get("page_size", len(items) or 1),
                "paged": resp.get("paged", True)}, fmt=fmt, fields=fields)
        return

    total = resp.get("total", len(items))
    if resp.get("paged", True):
        frm = (page - 1) * page_size + 1
        to = min(page * page_size, total)
        click.echo(click.style(f"Showing {frm}-{to} of {total} rows.", dim=True))
    else:
        click.echo(click.style(f"Showing first {len(items)} rows (query can't be paged — "
                               f"use SQL Playground).", dim=True))
    output(
        {"items": items, "total": total, "page": resp.get("page", 1),
         "page_size": resp.get("page_size", len(items) or 1)},
        fmt=fmt, fields=fields,
    )


@widget.command(name="decompose")
@click.option("--key", "keys", multiple=True, metavar="COL=VALUE",
              help="A group-by key, e.g. --key severity=Critical — use the name the widget "
                   "DISPLAYS. Repeat for a multi-key widget. Omit ALL keys to get every "
                   "record the widget covers (unreconciled); a partial set is an error.")
@click.option("--show-sql", is_flag=True, default=False,
              help="Print the generated detail SQL and exit (don't run it).")
@click.option("--limit", default=None, type=int,
              help="Rows per page. The server clamps to its own maximum and echoes "
                   "the value it actually used. Omit to use the server default.")
@click.option("--cursor", default=None, metavar="TOKEN",
              help="Resume from a previous run's next_cursor (see -o json).")
@click.option("--all", "fetch_all", is_flag=True, default=False,
              help="Follow cursors to the end. Capped at 100 pages so a mistyped "
                   "key cannot walk a 377k-row table forever.")
@click.option("--total", "with_total", is_flag=True, default=False,
              help="Also compute the exact total row count (an extra COUNT(*) over "
                   "the whole detail set — off by default because it is the "
                   "expensive part on a large drill-down).")
@click.option("--page", default=None, type=int,
              help="DEPRECATED — use --cursor. Offset paging, kept for compatibility.")
@click.option("--page-size", default=None, type=int,
              help="DEPRECATED — use --limit.")
@click.pass_context
def widget_decompose(ctx, keys, show_sql, limit, cursor, fetch_all, with_total,
                     page, page_size):
    """Show the records behind a number: what it was computed from.

    Rewrites the widget's SQL to drop the aggregation, pins the keys you name,
    and pages the individual records. When the widget reads a transformer the
    aggregation lives one level down, so this crosses that hop and tells you
    where it landed (decomposed_via.source_relation).

    \b
    ── TWO QUESTIONS, AND --key CHOOSES ──────────────────────────────────
      --key given  the rows behind ONE cell, reconciled against what that
                   cell displayed (so you get a real check mark).
      no --key     every record the widget covers. There is no single cell
                   to compare against, so metrics are recomputed but NOT
                   compared. A PARTIAL key set is an error, not a shortcut.

    \b
    ── HOW TO NAVIGATE ───────────────────────────────────────────────────
      1. See what a widget shows, and the keys you can pin:
           torana widget <UUID> render
      2. Drill one cell, using the DISPLAYED column name (aliases are
         translated for you):
           torana widget <UUID> decompose --key severity=Critical
      3. Page it. The server ALWAYS paginates — an omitted --limit means the
         server default, never "all rows" (one cell can be 27,000+ records):
           torana widget <UUID> decompose --key severity=Critical -o json
           # take .next_cursor from that, then:
           torana widget <UUID> decompose --key severity=Critical --cursor <TOKEN>
      4. Or walk the whole thing (capped at 100 pages):
           torana widget <UUID> decompose --key severity=Critical --all
      5. Want the exact size first? --total costs an extra COUNT(*):
           torana widget <UUID> decompose --key severity=Critical --total

    \b
    ── READING THE RECONCILIATION ────────────────────────────────────────
      ✓  these records explain the number the widget shows
      ✗  they explain a DIFFERENT number — trust the records; the widget's
         summary table has not caught up
      ·  nothing to compare against (column not drawn on the widget, or you
         drilled the whole widget rather than one cell)

    \b
    ⭐ ROW COUNT AND METRIC VALUE ARE DIFFERENT NUMBERS. A cell reading 218 can
    legitimately have 45,993 rows behind it — 218 distinct CVEs across 45,993
    findings. Rows that look identical usually differ in a column not shown.

    \b
      torana widget <UUID> decompose --key cve_id=CVE-2026-41080
      torana widget <UUID> decompose --key severity=Medium --key package_manager=os
      torana widget <UUID> decompose                       # the WHOLE widget
      torana widget <UUID> decompose --key severity=Medium --show-sql
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    row = {}
    for pair in keys:
        if "=" not in pair:
            click.echo(f"--key must be COL=VALUE, got {pair!r}", err=True)
            return
        col, _, val = pair.partition("=")
        row[col.strip()] = val

    client = _client(ctx)

    # ⭐ Fetch the DISPLAYED row so the reconciliation can return a real verdict.
    # The server compares each recomputed metric against what the cell showed, and
    # with no displayed value it can only print the recomputation with no "✓" —
    # which is exactly the check the user came for. `full_result` carries every
    # column of every rendered row, so the matching row is a local lookup, not a
    # second query. Best-effort: a render failure degrades to no verdict.
    # ⛔ NO --key MEANS THE WHOLE WIDGET, not "the first row". The old lookup ran
    # `all(...)` over an EMPTY row, which is vacuously true, so it matched the
    # first rendered row and silently drilled one slice (1,451 Critical) while the
    # caller asked for everything (31,765). The server now treats an empty row as
    # "the whole population" and enriches a keyed row itself, so this client-side
    # lookup is no longer needed at all.

    # DEPRECATED offset flags map onto the cursor path; warn once so scripts move.
    if page is not None or page_size is not None:
        click.echo(click.style(
            "⚠ --page/--page-size are deprecated; use --limit and --cursor.",
            fg="yellow"), err=True)
        if limit is None:
            limit = page_size

    body = {"row": row}
    if limit is not None:
        body["limit"] = limit
    if cursor:
        body["cursor"] = cursor
    if with_total:
        body["with_total"] = True
    if page is not None and not cursor and not fetch_all:
        body["page"] = page          # explicit legacy request

    def _post(b):
        return client.post(f"render/widget/{_wid(ctx)}/decompose", json=b)

    try:
        resp = _post(body)
        # ⚠️ --all follows cursors SERVER-SIDE-paged, never by asking for one huge
        # page: the cap exists because a mistyped key can select a 377k-row table.
        if fetch_all and resp.get("next_cursor"):
            merged = list(resp.get("rows") or [])
            nxt, pages = resp.get("next_cursor"), 1
            while nxt and pages < 100:
                more = _post({**body, "cursor": nxt})
                merged.extend(more.get("rows") or [])
                nxt = more.get("next_cursor")
                pages += 1
            if nxt:
                click.echo(click.style(
                    "⚠ Stopped after 100 pages; more rows remain. Narrow the key "
                    "or page manually with --cursor.", fg="yellow"), err=True)
            resp = {**resp, "rows": merged, "next_cursor": nxt,
                    "has_more": bool(nxt)}
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    kind = resp.get("kind")
    # ⚠️ Not an error. "This widget does not aggregate" is an ANSWER — the rows it
    # shows are already individual records, so there is nothing to expand.
    if kind in ("not_aggregate", "unsupported"):
        click.echo(resp.get("reason") or f"Cannot decompose this widget ({kind}).")
        return

    if show_sql:
        click.echo(resp.get("sql", ""))
        return

    for w in resp.get("warnings") or []:
        click.echo(click.style(f"⚠ {w}", fg="yellow"), err=True)

    cols = resp.get("columns") or []
    rows = resp.get("rows") or []
    items = [dict(zip(cols, r)) for r in rows]
    total = resp.get("total", len(items))

    if fmt in ("json", "yaml"):
        # ⭐ next_cursor is emitted so the paging is SCRIPTABLE: feed it straight
        # back in as --cursor. Without it, -o json could not walk a large drill.
        output({"kind": kind, "items": items, "total": total,
                "metrics": resp.get("metrics", []),
                "projection": resp.get("projection", []),
                "decomposed_via": resp.get("decomposed_via"),
                "next_cursor": resp.get("next_cursor"),
                "has_more": resp.get("has_more", False),
                "limit": resp.get("limit"),
                "page": resp.get("page", 1),
                "page_size": resp.get("page_size", len(items) or 1)},
               fmt=fmt, fields=fields)
        return

    metrics = resp.get("metrics") or []
    if metrics:
        click.echo(click.style("RECONCILIATION", bold=True))
        for m in metrics:
            # ⛔ A mismatch means the detail rows explain a DIFFERENT number than
            # the widget displayed — the decomposition is wrong and must say so.
            match = m.get("matches")
            mark = "✓" if match else ("✗" if match is False else "·")
            colour = "green" if match else ("red" if match is False else None)
            shown = "" if m.get("displayed") is None else f"  (cell showed {m['displayed']})"
            click.echo(click.style(
                f"  {mark} {m['column']} = {m['expression']} = {m.get('recomputed')}{shown}",
                fg=colour))
        click.echo()

    # ⭐ Say WHERE the rows came from. After crossing a transformer boundary the
    # user is looking at a different relation than the widget names, and without
    # this a mismatch above reads as a bug rather than as drift.
    via = resp.get("decomposed_via") or {}
    if via.get("source_relation"):
        click.echo(click.style(
            f"These rows come from {via['source_relation']}, the relation "
            f"{via.get('relation')} is built from.", dim=True))

    if resp.get("paged", True):
        shown = f"Showing {len(items)} rows"
        if total is not None:
            shown += f" of {total}"
        click.echo(click.style(shown + ".", dim=True))
    else:
        click.echo(click.style(
            f"Showing first {len(items)} rows (not pageable).", dim=True))

    nxt = resp.get("next_cursor")
    if nxt:
        # ⚠️ Only the GROUP-BY keys, not every column of the clicked row. The row
        # is enriched from full_result for reconciliation, so echoing all of it
        # would print a resume command far longer than the cursor it carries.
        gk = set(resp.get("group_keys") or [])
        aliases = ((resp.get("decomposed_via") or {}).get("key_aliases") or {})
        gk |= {a for a, c in aliases.items() if c in gk}
        pairs = [(k, v) for k, v in (row or {}).items() if not gk or k in gk]
        keyflags = " ".join(f"--key {k}={v}" for k, v in pairs)
        click.echo(click.style(
            f"  Next: torana widget {_wid(ctx)} decompose {keyflags} "
            f"--cursor {nxt}", dim=True))

    output({"items": items, "total": total}, fmt=fmt, fields=fields)


def _api_detail(e: APIError) -> str:
    """The server's own words for an error, on one line."""
    detail = getattr(e, "detail", None)
    if isinstance(detail, dict):
        detail = detail.get("detail") or detail
    return " ".join(str(detail or e).split())


def _others_on_query(client, query_id: str, widget_id: str) -> list:
    """The OTHER widgets that use this query (a query can back more than one widget)."""
    users = client.get(f"widgets/by-query/{query_id}")
    users = users.get("items", []) if isinstance(users, dict) else (users or [])
    return [w for w in users if w.get("id") != widget_id]


@widget.command(name="update")
@click.option("--name", default=None, help="New name.")
@click.option("--file", "input_file", default=None, metavar="FILE",
              help="JSON/YAML with the widget fields to change (name, description, "
                   "semantic_description, widget_type, display_config, labels).")
@click.option("--sql", "sql", default=None, metavar="SQL",
              help="New SQL for the widget's query. Updates the query, then the widget.")
@click.option("--sql-file", "sql_file", default=None, metavar="FILE",
              help="Read the new SQL from a file.")
@click.option("--allow-shared", is_flag=True, default=False,
              help="Change the SQL even when other widgets use the same query.")
@click.option("--no-check", is_flag=True, default=False,
              help="Save the SQL without running it first.")
@click.pass_context
def widget_update(ctx, name, input_file, sql, sql_file, allow_shared, no_check):
    """Update a widget, and its query with --sql.

    \b
    --sql changes what the widget computes. The SQL lives on the widget's query. The
    new SQL is run once first (one row); if it does not run, nothing is changed and
    the exit code is 6. Then the query is updated, then the widget. A query used by
    other widgets is left alone unless you pass --allow-shared, because their numbers
    would change too.

    \b
    ⛔ CHANGING `widget_type` ALSO REQUIRES A MATCHING `display_config`. The server
    validates the new type against the display_config it ends up with, and a change
    that sets only `widget_type` keeps the OLD shape, so the call fails with 400
    naming one missing key at a time. Send BOTH together. The shapes, per type:

    \b
      table         {"columns": ["col_a", "col_b"]}
      scalar        {"value_column": "n", "label": "Open criticals"}
      bar | line    {"x_axis": "severity", "y_axis": "count"}
      pie           {"x_axis": "...", "y_axis": "...",
                     "label_field": "severity", "value_field": "count"}

    \b
    ⚠️ The axis values must be COLUMN NAMES the widget's query returns: check with
    `torana widget <ID> explore` before switching type.

    \b
    Examples:
      torana widget <ID> update --name "Open criticals by owner"
      torana widget <ID> update --sql "SELECT owner, count(*) AS n FROM vulnerabilities GROUP BY owner"
      torana widget <ID> update --sql-file q.sql --file w.json
      # w.json, table -> bar in one call:
      # {"widget_type": "bar", "display_config": {"x_axis": "severity", "y_axis": "count"}}
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    wid = _wid(ctx)

    if sql and sql_file:
        click.echo("ERROR: pass --sql or --sql-file, not both.", err=True)
        sys.exit(2)
    if sql_file:
        with open(sql_file) as fh:
            sql = fh.read().strip()

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name

    if not body and not sql:
        click.echo("ERROR: No fields to update.", err=True)
        sys.exit(2)

    client = _client(ctx)
    result = {"widget_id": wid, "query_id": None, "query_updated": False, "widget_updated": False}
    try:
        if sql:
            current = client.get(f"widgets/{wid}/")
            query_id = current.get("query_id")
            result["query_id"] = query_id
            if not query_id:
                click.echo("ERROR: this widget has no query to update.", err=True)
                sys.exit(1)
            others = _others_on_query(client, query_id, wid)
            if others and not allow_shared:
                click.echo(f"ERROR: query {query_id} is also used by {len(others)} other widget(s):",
                           err=True)
                for w in others:
                    click.echo(f"  {w.get('id')}  {w.get('name')}", err=True)
                click.echo("Changing the SQL changes their numbers too. Pass --allow-shared to do it "
                           "anyway.", err=True)
                sys.exit(2)
            if not no_check:
                # The server stores any text as a query's SQL, so a typo would be saved and
                # the widget would fail on its next render. Run it once (one row) first.
                try:
                    client.post("render/explore", json={"sql": sql, "page": 1, "page_size": 1})
                except APIError as e:
                    click.echo("ERROR: the new SQL does not run, so nothing was changed.", err=True)
                    click.echo(f"  {_api_detail(e)}", err=True)
                    click.echo("  (--no-check saves it without running it.)", err=True)
                    sys.exit(EXIT_VALIDATION)
            client.put(f"queries/{query_id}/", json={"sql_command": sql})
            result["query_updated"] = True
        if body:
            try:
                data = client.put(f"widgets/{wid}/", json=body)
            except APIError:
                if result["query_updated"]:
                    click.echo(f"The SQL of query {result['query_id']} WAS changed; the widget "
                               f"was NOT updated:", err=True)
                raise
            result["widget_updated"] = True
            result["widget"] = data
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(result, fmt=fmt)
        return
    if result["query_updated"]:
        click.echo(f"Updated query: {result['query_id']}")
    if result["widget_updated"]:
        click.echo(f"Updated widget: {wid}")


@widget.command(name="delete")
@click.option("--keep-query", is_flag=True, default=False,
              help="Delete only the widget and leave its query.")
@click.option("--yes", is_flag=True, default=False, help="Skip the confirmation prompt.")
@click.pass_context
def widget_delete(ctx, keep_query, yes):
    """Delete a widget and its query.

    Does what the screen's delete button does: takes the widget off every dashboard of
    its app, deletes the widget, and deletes the query behind it. The query is kept
    when another widget still uses it, or when you pass --keep-query; the output says
    which.

    \b
    Examples:
      torana widget <ID> delete
      torana widget <ID> delete --yes
      torana widget <ID> delete --keep-query --yes
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    wid = _wid(ctx)
    client = _client(ctx)
    report = {"widget_id": wid, "query_id": None, "query_deleted": False,
              "query_kept_reason": None, "removed_from_dashboards": []}
    try:
        current = client.get(f"widgets/{wid}/")
        query_id = current.get("query_id")
        report["query_id"] = query_id
        if keep_query:
            report["query_kept_reason"] = "--keep-query"
        elif not query_id:
            report["query_kept_reason"] = "the widget has no query"
        else:
            others = _others_on_query(client, query_id, wid)
            if others:
                report["query_kept_reason"] = f"also used by {len(others)} other widget(s)"

        what = f'Delete widget "{current.get("name")}"'
        what += (f" (its query {query_id} is kept: {report['query_kept_reason']})"
                 if report["query_kept_reason"] else f" and its query {query_id}")
        _confirm(what + "?", yes=yes)

        app_id = current.get("workspace_id")
        if app_id:
            for d in fetch_dashboards(client, app_id):
                if any(w.get("id") == wid for w in d.get("widgets") or []):
                    client.delete(f"dashboards/{d['id']}/widgets/{wid}")
                    report["removed_from_dashboards"].append(d["id"])
        client.delete(f"widgets/{wid}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    query_error = None
    if query_id and not report["query_kept_reason"]:
        try:
            client.delete(f"queries/{query_id}/")
            report["query_deleted"] = True
        except (APIError, AuthError) as e:
            query_error = e
            report["query_kept_reason"] = f"deleting it failed: {e}"

    if fmt != "text":
        output(report, fmt=fmt)
    else:
        click.echo(f"Deleted widget: {wid}")
        if report["query_deleted"]:
            click.echo(f"Deleted query: {query_id}")
        elif query_id:
            click.echo(f"Kept query: {query_id} ({report['query_kept_reason']})")
    if query_error is not None:
        click.echo(f"The widget is gone but its query is not. Remove it with: "
                   f"torana query {query_id} delete", err=True)
        sys.exit(1)


@widget.command(name="move")
@click.option("--target-app-id", "target_app_id", required=True,
              help="The app to move the widget to (the id from `torana apps list`).")
@click.pass_context
def widget_move(ctx, target_app_id):
    """Move a widget to another app.

    The widget leaves the app it is in. It is not put on a dashboard of the target app:
    add it with `torana dashboard <ID> widgets add <WIDGET_ID>`.

    \b
    Examples:
      torana widget <ID> move --target-app-id <APP_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.post(f"widgets/{_wid(ctx)}/move", json={"target_workspace_id": target_app_id})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, fields=fields)
    else:
        click.echo(f"Moved widget {_wid(ctx)} to app {target_app_id}")
