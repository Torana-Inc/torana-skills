"""torana widget — per-widget instance commands."""

import sys

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _human_age(iso: str) -> str:
    """Rough 'Nh/Nd ago' label from an ISO-8601 timestamp; '' if unparseable."""
    from datetime import datetime, timezone
    try:
        dt = datetime.fromisoformat(str(iso).replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
    except (TypeError, ValueError):
        return ""
    secs = (datetime.now(timezone.utc) - dt).total_seconds()
    if secs < 90:
        return "just now"
    if secs < 5400:
        return f"{int(secs // 60)}m ago"
    if secs < 172800:
        return f"{int(secs // 3600)}h ago"
    return f"{int(secs // 86400)}d ago"


def _emit_freshness_line(resp: dict) -> None:
    """Print the data-freshness line for a widget render (Feature A).

    Shows WHEN the data was produced (data_as_of) vs when the query ran (cached_at),
    and — when stale — the bottleneck table's remediation hint ('what to do').
    """
    data_as_of = (resp or {}).get("data_as_of")
    freshness = (resp or {}).get("freshness")
    cached_at = (resp or {}).get("cached_at")
    if not (data_as_of or freshness or cached_at):
        return  # older backend without freshness fields — stay quiet

    if data_as_of:
        label = f"Data as of {data_as_of} ({_human_age(data_as_of)})"
    else:
        label = "Data freshness unknown"
    verdict = (freshness or "").upper()
    if verdict == "STALE":
        label = click.style(f"⚠ {label}  [STALE]", fg="yellow")
    elif verdict == "FRESH":
        label = click.style(label, dim=True)
    else:
        label = click.style(label, dim=True)

    query_part = f"  ·  Query ran {cached_at}" if cached_at else ""
    click.echo(label + click.style(query_part, dim=True))

    # When stale, tell the user what to do — the bottleneck table's remediation hint.
    if verdict == "STALE":
        for t in (resp or {}).get("freshness_detail") or []:
            if t.get("is_bottleneck") and t.get("remediation_hint"):
                click.echo(click.style(f"  → {t['remediation_hint']}", fg="yellow"))
                break


@click.group(name="widget", invoke_without_command=True)
@click.argument("widget_id", metavar="WIDGET_ID")
@click.pass_context
def widget(ctx, widget_id):
    """Per-widget instance commands.

    \b
    Examples:
      torana widget <UUID> get
      torana widget <UUID> update --name "New Name"
      torana widget <UUID> delete --yes
      torana widget <UUID> move --target-workspace-id <UUID>
    """
    ctx.ensure_object(dict)
    ctx.obj["_widget_id"] = widget_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _wid(ctx) -> str:
    return ctx.obj.get("_widget_id", "") if ctx.obj else ""


@widget.command(name="get")
@click.pass_context
def widget_get(ctx):
    """Get details for a specific widget."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"widgets/{_wid(ctx)}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@widget.command(name="render")
@click.option("--refresh", is_flag=True, default=False,
              help="Bypass the render cache (default 30 min TTL) and force a fresh query.")
@click.pass_context
def widget_render(ctx, refresh):
    """Render a widget's DATA — the same rows the UI shows.

    Calls the viz render endpoint (GET /api/v1/render/widget/<id>), which resolves the
    widget's query, executes it, and returns the rendered result. This is exactly what the
    workspace UI calls to draw the widget, so CLI and UI show identical data.

    \b
      torana widget <UUID> render
      torana widget <UUID> render --refresh     # force a fresh query (skip the cache)
      torana widget <UUID> render --json        # full render envelope (status, timing, cache)

    Row count: the render endpoint returns whatever the widget's saved query returns
    (typically capped by a LIMIT in that query) and does NOT paginate — the UI shows the
    same slice. To page through ALL rows, run the widget's SQL directly:
      torana query <QUERY_ID> get --fields sql_command      # get the SQL
      torana datalake query --sql "<sql without LIMIT>"     # then page as you wish
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        resp = client.get(f"render/widget/{_wid(ctx)}",
                          params={"refresh": "true"} if refresh else None)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # json/yaml: hand back the full render envelope verbatim (status, timing, cache, data).
    if fmt in ("json", "yaml"):
        output(resp, fmt=fmt, fields=fields)
        return

    # A render can succeed with data, or fail server-side (bad query, no rows) — surface that.
    status = (resp or {}).get("status")
    if status and status != "success":
        click.echo(f"Render {status}: {resp.get('error_message') or '(no detail)'}", err=True)
        return

    # Semantic context — the "how to read this" body, mirroring the FE's collapsible row.
    # Printed before the data so the reader knows what they are looking at. `description`
    # stays the terse one-liner; `semantic_description` is the rich body (may be multi-line).
    _desc = (resp or {}).get("description")
    _semantic = (resp or {}).get("semantic_description")
    if _desc:
        click.echo(click.style(str(_desc), dim=True))

    # Data freshness (Feature A): tell the reader WHEN the data was produced (data_as_of),
    # not just when the query ran (cached_at) — and, when stale, what to do about it.
    _emit_freshness_line(resp)

    if _semantic:
        click.echo()
        click.echo(click.style("How to read this:", bold=True))
        for _line in str(_semantic).splitlines():
            click.echo(f"  {_line}")
        click.echo()

    data = (resp or {}).get("data")

    # Table widgets: {columns, rows, total_rows} -> render as a real table.
    if isinstance(data, dict) and "columns" in data and "rows" in data:
        cols = data.get("columns") or []
        rows = data.get("rows") or []
        items = [dict(zip(cols, r)) for r in rows]
        output(
            {"items": items, "total": data.get("total_rows", len(items)),
             "page": 1, "page_size": len(items)},
            fmt=fmt, fields=fields,
            columns=[(c, c, 12) for c in cols],
        )
        return

    # Chart widgets (bar / pie / line): {labels, datasets:[{label, data:[...]}]} -> pivot to a
    # readable table with one row per label and one column per series.
    if isinstance(data, dict) and "labels" in data and "datasets" in data:
        labels = data.get("labels") or []
        datasets = data.get("datasets") or []
        series = [(ds.get("label") or f"series{i}") for i, ds in enumerate(datasets)]
        items = []
        for row_i, lab in enumerate(labels):
            item = {"label": lab}
            for ds_i, ds in enumerate(datasets):
                vals = ds.get("data") or []
                item[series[ds_i]] = vals[row_i] if row_i < len(vals) else None
            items.append(item)
        output(
            {"items": items, "total": len(items), "page": 1, "page_size": len(items)},
            fmt=fmt, fields=fields,
            columns=[("label", "label", 14)] + [(s, s, 12) for s in series],
        )
        return

    # Scalar widgets: {value, ...} -> print the value line.
    if isinstance(data, dict) and "value" in data and "labels" not in data:
        output({"items": [data], "total": 1, "page": 1, "page_size": 1}, fmt=fmt, fields=fields)
        return

    # Anything else: print the structured data as-is.
    output(data if data is not None else resp, fmt=fmt, fields=fields)


# `data` is a friendlier alias for `render` — same endpoint, same output.
@widget.command(name="data")
@click.pass_context
def widget_data(ctx):
    """Alias for `render` — show the widget's rendered data (the rows the UI shows)."""
    ctx.invoke(widget_render)


def _emit_provenance_tree(resp: dict) -> None:
    """Render the lineage tree as text.

    Deliberately shows ROW ACCOUNTING inline on every hop, not behind a flag: it
    is what turns this from an audit artifact into a debugging tool. A shipped
    bundle once dropped 80,532 of 80,899 rows silently — "rows in -> rows out"
    per hop is the only place in the product that makes that visible.

    Every state marker pairs an ICON with WORDS (never colour alone), so the
    output is readable to a colour-blind reader and in a plain log.
    """
    nodes = (resp or {}).get("nodes") or []
    if not nodes:
        click.echo("No lineage resolved for this widget.")
        return

    # T4 column scoping (§ 3.9.8). When the resolver scoped the tree to the columns
    # THIS widget reads, some base tables are demoted: joined by an upstream transformer
    # for columns the widget never touches. We SHOW them (a verifier needs the full
    # lineage) but clearly separate them below the in-scope tables so "where did
    # severity come from" isn't drowned by enrichment joins the widget didn't read.
    scoped = bool((resp or {}).get("scoped"))
    demoted = [n for n in nodes if scoped and n.get("in_scope") is False]
    primary = [n for n in nodes if not (scoped and n.get("in_scope") is False)]
    if scoped:
        click.echo("i Scoped to the columns this widget reads. Tables joined only for "
                   "other columns are listed separately at the end.\n")

    def _emit_nodes(node_list):
        by_depth = {}
        for n in node_list:
            by_depth.setdefault(n.get("depth", 0), []).append(n)
        for depth in sorted(by_depth):
            for n in by_depth[depth]:
                _emit_one(n)

    def _emit_one(n):
            depth = n.get("depth", 0)
            indent = "  " * depth
            kind = n.get("kind", "unknown")
            rows = n.get("row_count")
            rows_s = f"{rows:,} rows" if isinstance(rows, int) else "rows unknown"
            click.echo(f"{indent}{n['relation']}  [{kind}]  {rows_s}")

            prod = n.get("producer") or {}
            if prod.get("name"):
                click.echo(f"{indent}    produced by transformer '{prod['name']}'"
                           f"  last ran {prod.get('last_success_at') or 'never'}")

            acc = n.get("row_accounting") or {}
            if acc:
                verdict = acc.get("verdict")
                marker = {"row_drop": "!! ROW DROP",
                          "expected_aggregate": "ok  aggregate",
                          "ok": "ok  no loss"}.get(verdict, verdict or "")
                click.echo(f"{indent}    {acc['rows_in']:,} in -> {acc['rows_out']:,} out"
                           f"   [{marker}]")

            for s in (n.get("sources") or []):
                click.echo(f"{indent}    {s.get('source_system') or '(unknown)':<16}"
                           f"{s.get('row_count', 0):>9,}   landed {s.get('last_landed') or '?'}")
                for i in (s.get("integrations") or []):
                    click.echo(f"{indent}        - {i.get('name')}  "
                               f"[{i.get('kind')}]  via {i.get('data_source')}  "
                               f"({i.get('runs')} runs, {i.get('records_out'):,} records)")
                if s.get("attribution_note"):
                    click.echo(f"{indent}        i {s['attribution_note']}")

            if n.get("unresolved_runs"):
                click.echo(f"{indent}    i {n['unresolved_runs']} run(s) could not be "
                           f"attributed to a sink table.")

    # In-scope lineage first (what actually feeds the widget's columns).
    _emit_nodes(primary)

    # Then the demoted tables, clearly fenced off so they don't read as sources.
    if demoted:
        click.echo("\n-- Joined but NOT read by this widget "
                   "(shown for completeness) --")
        for n in demoted:
            reason = n.get("scope_reason") or "not read by this query"
            rows = n.get("row_count")
            rows_s = f"{rows:,} rows" if isinstance(rows, int) else "rows unknown"
            click.echo(f"  {n['relation']}  [{n.get('kind','unknown')}]  {rows_s}")
            click.echo(f"      i {reason}")

    _emit_vocabulary(resp)

    for w in (resp or {}).get("warnings") or []:
        click.echo(f"\n!! {w.get('code')}: {w.get('message')}", err=True)
    if (resp or {}).get("max_depth_reached"):
        click.echo("\ni Lineage was truncated at the maximum depth.", err=True)


def _emit_vocabulary(resp: dict) -> None:
    """The POLICY back-pointer: which decisions shaped these numbers.

    The tree above answers "where did these ROWS come from". This answers "which
    DECISIONS shaped them" — the question a tenant about to change an SLA window is
    actually asking. Both read the same `workspace_vocab_usage` rows as the policy
    page's Impact tab, walked in opposite directions, so they cannot disagree.

    Markers pair an ICON with WORDS, never colour alone (same rule as the tree).
    """
    vocab = (resp or {}).get("vocabulary")
    if not vocab:
        return  # [] = genuinely no policy input; a failed lookup emits a warning instead

    click.echo("\n-- Policy this widget depends on --")
    click.echo("   i Changing one of these changes the numbers above.")
    for v in vocab:
        val = v.get("resolved_value") or {}
        shown = val.get("value") if isinstance(val, dict) else val
        # "default" is load-bearing, not decoration: a tenant reading a number
        # computed from a baseline they never authored should know that.
        origin = "platform default" if v.get("default_in_effect") else "tenant-set"
        click.echo(f"  {v.get('vocab_key')}  = {shown}   [{origin}]")
        consumers = ", ".join(v.get("consumers") or [])
        if v.get("tenant_global"):
            # The widest blast radius in the system — say so in words.
            click.echo(f"      ! applies PLATFORM-WIDE (all apps)  via: {consumers}")
        else:
            click.echo(f"      via: {consumers}")


@widget.command(name="provenance")
@click.option("--sources", is_flag=True, default=False,
              help="Show only the flat per-integration source table (skip the tree).")
@click.pass_context
def widget_provenance(ctx, sources):
    """Where this widget's data came from — full lineage, row accounting, sources.

    Walks the widget's lineage from the relation it renders down to the base sink
    tables, and attributes each base table to the integrations that wrote it.

    \b
      torana widget <UUID> provenance             # the lineage tree
      torana widget <UUID> provenance --sources   # just "which integrations fed this"
      torana widget <UUID> provenance --json      # full envelope

    Row accounting ("N in -> M out" per hop) is the highest-value line. A widget
    reading a fraction of its base table is the signature of a silent filter bug
    — the kind that renders a confident, precise, wrong number with no error.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        resp = client.get(f"render/widget/{_wid(ctx)}/provenance")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml"):
        output(resp, fmt=fmt, fields=fields)
        return

    name = (resp or {}).get("widget_name")
    if name:
        click.echo(click.style(f"Where '{name}' gets its data", bold=True))
        click.echo()

    if sources:
        rows = []
        for n in (resp or {}).get("nodes") or []:
            for s in (n.get("sources") or []):
                for i in (s.get("integrations") or []):
                    rows.append({
                        "table": n["relation"],
                        "source": s.get("source_system"),
                        "integration": i.get("name"),
                        "kind": i.get("kind"),
                        "data_source": i.get("data_source"),
                        "runs": i.get("runs"),
                        "records": i.get("records_out"),
                    })
        if not rows:
            click.echo("No integration-attributed sources for this widget.")
            return
        output({"items": rows, "total": len(rows)}, fmt="text", columns=[
            ("table", "TABLE", 26), ("source", "SOURCE", 14),
            ("integration", "INTEGRATION", 34), ("kind", "KIND", 12),
            ("data_source", "DATA SOURCE", 30), ("records", "RECORDS", 10),
        ])
        return

    _emit_provenance_tree(resp)


def _fmt_count(n) -> str:
    return f"{n:,}" if isinstance(n, int) else "?"


def _emit_why_funnel(resp: dict, show_sql: bool = False) -> None:
    """Render the predicate funnel as a text waterfall.

    Shows base → each cumulative predicate → final, marking WHERE the count
    collapses, then the column-health note on that step. Icon+text markers only
    (no colour-only cues — the color-blindness rule). With show_sql, prints each
    step's slice SQL beneath it so the user can copy it into the SQL playground.
    """
    if not (resp or {}).get("decomposable"):
        # Not a funnel-able query (join/subquery FROM, OR-root, or no plan yet).
        for w in (resp or {}).get("warnings") or []:
            click.echo(f"i {w.get('message')}")
        click.echo("\nThis query can't be broken into a predicate funnel. "
                   "Use `provenance` to see where its rows come from, or `explore` "
                   "to run slices of the SQL yourself.")
        return

    relation = resp.get("relation")
    steps = resp.get("steps") or []

    # No predicate to decompose (no WHERE, or a single base step). The number isn't
    # produced by a filter, so a funnel would be noise — say plainly what it reads.
    if len(steps) <= 1:
        base = steps[0].get("count") if steps else None
        n = f"all {base:,} rows of " if isinstance(base, int) else ""
        rel = relation or "its source relation"
        click.echo(f"This widget applies no filters — it reads {n}{rel}.")
        click.echo("The values shown are the numbers inside those rows, not a "
                   "filtered count, so there's nothing to break down here.")
        return

    # Width for right-aligned counts.
    w = max((len(_fmt_count(s.get("count"))) for s in steps), default=6)
    click.echo(f"Rows of {relation} surviving each filter:\n")
    for i, s in enumerate(steps):
        count = s.get("count")
        cs = _fmt_count(count).rjust(w)
        marker = "  <== collapses here" if s.get("collapse") else ""
        if i == 0:
            click.echo(f"  {cs}   {s.get('label')}{marker}")
        else:
            delta = s.get("delta")
            pct = f"  ({delta * 100:+.1f}%)" if isinstance(delta, (int, float)) else ""
            click.echo(f"  {cs}   + {s.get('label')}{pct}{marker}")
        if show_sql and s.get("count_sql"):
            click.echo(f"  {' ' * w}     {s['count_sql']}")
    click.echo(f"  {'-' * w}")
    click.echo(f"  {_fmt_count(resp.get('final_value')).rjust(w)}   = the widget's number")

    for ch in (resp.get("column_health") or []):
        note = ch.get("note")
        if note:
            click.echo(f"\n!! {note}")
        tv = ch.get("top_values") or []
        if tv:
            vals = ", ".join(f"{t.get('value')} ({_fmt_count(t.get('count'))})" for t in tv)
            click.echo(f"   {ch.get('column')} top values: {vals}")

    for warn in (resp or {}).get("warnings") or []:
        click.echo(f"\ni {warn.get('message')}", err=True)


@widget.command(name="why")
@click.option("--sql", "show_sql", is_flag=True, default=False,
              help="Show each step's slice SQL beneath it (copy into the SQL playground).")
@click.pass_context
def widget_why(ctx, show_sql):
    """Why is this number what it is? — the predicate funnel.

    Provenance tells you WHERE the rows came from; this tells you WHY the number
    is what it is. It re-runs the widget's query in cumulative slices and shows
    where the row set collapses — and, on the collapse step, whether the filtered
    column is even populated (e.g. "asset_environment is NULL for 100% of rows").

    \b
      torana widget <UUID> why           # the funnel waterfall
      torana widget <UUID> why --sql     # + each step's slice SQL
      torana widget <UUID> why --json    # full envelope (count_sql per step)

    The classic catch: a widget shows 0 not because there's no risk, but because
    it filters on a column that's empty. Provenance shows "no rows lost"; this
    shows the filter that produced the 0. Each step's SQL lets you verify the
    count yourself — run it, or open it in the SQL playground.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        resp = client.get(f"render/widget/{_wid(ctx)}/why")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml"):
        output(resp, fmt=fmt, fields=fields)
        return

    name = (resp or {}).get("widget_name")
    if name:
        click.echo(click.style(f"Why '{name}' shows what it shows", bold=True))
        click.echo()
    _emit_why_funnel(resp, show_sql=show_sql)


@widget.command(name="explore")
@click.option("--sql", default=None, metavar="SQL",
              help="SQL to run (defaults to the widget's own query — use --show-sql to see it).")
@click.option("--show-sql", is_flag=True, default=False,
              help="Print the widget's underlying SQL and exit (don't run it).")
@click.option("--page", default=1, type=int, help="Page number (1-based, default 1).")
@click.option("--page-size", default=50, type=int, help="Rows per page (max 1000, default 50).")
@click.pass_context
def widget_explore(ctx, sql, show_sql, page, page_size):
    """Explore a widget's data — run its underlying SQL (or your own) and page the rows.

    The widget's real query is the source of truth. With no --sql, this runs the
    widget's own SQL with TRUE database-side pagination and shows the REAL total.
    Pass --sql to run a modified query (SELECT-only), mirroring the UI's Explore drawer.

    \b
      torana widget <UUID> explore --show-sql              # print the widget's SQL
      torana widget <UUID> explore                         # run the widget's SQL (page 1)
      torana widget <UUID> explore --page 2                # next page
      torana widget <UUID> explore --sql "SELECT ... "     # run a modified query
      torana widget <UUID> explore --json                  # full result envelope
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    # Resolve the widget's SQL (needed for --show-sql and as the default query).
    try:
        widget = client.get(f"widgets/{_wid(ctx)}/")
        query = client.get(f"queries/{widget['query_id']}/")
        widget_sql = query.get("sql_command", "")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if show_sql:
        click.echo(widget_sql)
        return

    run_sql = sql or widget_sql
    if not run_sql:
        click.echo("No SQL to run (widget has no query).", err=True)
        return

    try:
        resp = client.post("render/explore",
                           json={"sql": run_sql, "page": page, "page_size": page_size})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Backend returns rows as arrays (row-ordered by columns); zip into dicts.
    cols = resp.get("columns") or []
    rows = resp.get("rows") or []
    items = [dict(zip(cols, r)) for r in rows]

    if fmt in ("json", "yaml"):
        output({"items": items, "total": resp.get("total", len(items)),
                "page": resp.get("page", 1), "page_size": resp.get("page_size", len(items) or 1),
                "paged": resp.get("paged", True)}, fmt=fmt, fields=fields)
        return

    total = resp.get("total", len(items))
    if resp.get("paged", True):
        frm = (page - 1) * page_size + 1
        to = min(page * page_size, total)
        click.echo(click.style(f"Showing {frm}-{to} of {total} rows.", dim=True))
    else:
        click.echo(click.style(f"Showing first {len(items)} rows (query can't be paged — "
                               f"use SQL Playground).", dim=True))
    output(
        {"items": items, "total": total, "page": resp.get("page", 1),
         "page_size": resp.get("page_size", len(items) or 1)},
        fmt=fmt, fields=fields,
    )


@widget.command(name="decompose")
@click.option("--key", "keys", multiple=True, metavar="COL=VALUE",
              help="A group-by key, e.g. --key severity=Critical — use the name the widget "
                   "DISPLAYS. Repeat for a multi-key widget. Omit ALL keys to get every "
                   "record the widget covers (unreconciled); a partial set is an error.")
@click.option("--show-sql", is_flag=True, default=False,
              help="Print the generated detail SQL and exit (don't run it).")
@click.option("--limit", default=None, type=int,
              help="Rows per page. The server clamps to its own maximum and echoes "
                   "the value it actually used. Omit to use the server default.")
@click.option("--cursor", default=None, metavar="TOKEN",
              help="Resume from a previous run's next_cursor (see -o json).")
@click.option("--all", "fetch_all", is_flag=True, default=False,
              help="Follow cursors to the end. Capped at 100 pages so a mistyped "
                   "key cannot walk a 377k-row table forever.")
@click.option("--total", "with_total", is_flag=True, default=False,
              help="Also compute the exact total row count (an extra COUNT(*) over "
                   "the whole detail set — off by default because it is the "
                   "expensive part on a large drill-down).")
@click.option("--page", default=None, type=int,
              help="DEPRECATED — use --cursor. Offset paging, kept for compatibility.")
@click.option("--page-size", default=None, type=int,
              help="DEPRECATED — use --limit.")
@click.pass_context
def widget_decompose(ctx, keys, show_sql, limit, cursor, fetch_all, with_total,
                     page, page_size):
    """The records behind a number — what it was computed FROM.

    Rewrites the widget's SQL to drop the aggregation, pins the keys you name,
    and pages the individual records. When the widget reads a transformer the
    aggregation lives one level down, so this crosses that hop and tells you
    where it landed (decomposed_via.source_relation).

    \b
    ── TWO QUESTIONS, AND --key CHOOSES ──────────────────────────────────
      --key given  the rows behind ONE cell, reconciled against what that
                   cell displayed (so you get a real check mark).
      no --key     every record the widget covers. There is no single cell
                   to compare against, so metrics are recomputed but NOT
                   compared. A PARTIAL key set is an error, not a shortcut.

    \b
    ── HOW TO NAVIGATE ───────────────────────────────────────────────────
      1. See what a widget shows, and the keys you can pin:
           torana widget <UUID> render
      2. Drill one cell, using the DISPLAYED column name (aliases are
         translated for you):
           torana widget <UUID> decompose --key severity=Critical
      3. Page it. The server ALWAYS paginates — an omitted --limit means the
         server default, never "all rows" (one cell can be 27,000+ records):
           torana widget <UUID> decompose --key severity=Critical -o json
           # take .next_cursor from that, then:
           torana widget <UUID> decompose --key severity=Critical --cursor <TOKEN>
      4. Or walk the whole thing (capped at 100 pages):
           torana widget <UUID> decompose --key severity=Critical --all
      5. Want the exact size first? --total costs an extra COUNT(*):
           torana widget <UUID> decompose --key severity=Critical --total

    \b
    ── READING THE RECONCILIATION ────────────────────────────────────────
      ✓  these records explain the number the widget shows
      ✗  they explain a DIFFERENT number — trust the records; the widget's
         summary table has not caught up
      ·  nothing to compare against (column not drawn on the widget, or you
         drilled the whole widget rather than one cell)

    \b
    ⭐ ROW COUNT AND METRIC VALUE ARE DIFFERENT NUMBERS. A cell reading 218 can
    legitimately have 45,993 rows behind it — 218 distinct CVEs across 45,993
    findings. Rows that look identical usually differ in a column not shown.

    \b
      torana widget <UUID> decompose --key cve_id=CVE-2026-41080
      torana widget <UUID> decompose --key severity=Medium --key package_manager=os
      torana widget <UUID> decompose                       # the WHOLE widget
      torana widget <UUID> decompose --key severity=Medium --show-sql
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    row = {}
    for pair in keys:
        if "=" not in pair:
            click.echo(f"--key must be COL=VALUE, got {pair!r}", err=True)
            return
        col, _, val = pair.partition("=")
        row[col.strip()] = val

    client = _client(ctx)

    # ⭐ Fetch the DISPLAYED row so the reconciliation can return a real verdict.
    # The server compares each recomputed metric against what the cell showed, and
    # with no displayed value it can only print the recomputation with no "✓" —
    # which is exactly the check the user came for. `full_result` carries every
    # column of every rendered row, so the matching row is a local lookup, not a
    # second query. Best-effort: a render failure degrades to no verdict.
    # ⛔ NO --key MEANS THE WHOLE WIDGET, not "the first row". The old lookup ran
    # `all(...)` over an EMPTY row, which is vacuously true, so it matched the
    # first rendered row and silently drilled one slice (1,451 Critical) while the
    # caller asked for everything (31,765). The server now treats an empty row as
    # "the whole population" and enriches a keyed row itself, so this client-side
    # lookup is no longer needed at all.

    # DEPRECATED offset flags map onto the cursor path; warn once so scripts move.
    if page is not None or page_size is not None:
        click.echo(click.style(
            "⚠ --page/--page-size are deprecated; use --limit and --cursor.",
            fg="yellow"), err=True)
        if limit is None:
            limit = page_size

    body = {"row": row}
    if limit is not None:
        body["limit"] = limit
    if cursor:
        body["cursor"] = cursor
    if with_total:
        body["with_total"] = True
    if page is not None and not cursor and not fetch_all:
        body["page"] = page          # explicit legacy request

    def _post(b):
        return client.post(f"render/widget/{_wid(ctx)}/decompose", json=b)

    try:
        resp = _post(body)
        # ⚠️ --all follows cursors SERVER-SIDE-paged, never by asking for one huge
        # page: the cap exists because a mistyped key can select a 377k-row table.
        if fetch_all and resp.get("next_cursor"):
            merged = list(resp.get("rows") or [])
            nxt, pages = resp.get("next_cursor"), 1
            while nxt and pages < 100:
                more = _post({**body, "cursor": nxt})
                merged.extend(more.get("rows") or [])
                nxt = more.get("next_cursor")
                pages += 1
            if nxt:
                click.echo(click.style(
                    "⚠ Stopped after 100 pages; more rows remain. Narrow the key "
                    "or page manually with --cursor.", fg="yellow"), err=True)
            resp = {**resp, "rows": merged, "next_cursor": nxt,
                    "has_more": bool(nxt)}
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    kind = resp.get("kind")
    # ⚠️ Not an error. "This widget does not aggregate" is an ANSWER — the rows it
    # shows are already individual records, so there is nothing to expand.
    if kind in ("not_aggregate", "unsupported"):
        click.echo(resp.get("reason") or f"Cannot decompose this widget ({kind}).")
        return

    if show_sql:
        click.echo(resp.get("sql", ""))
        return

    for w in resp.get("warnings") or []:
        click.echo(click.style(f"⚠ {w}", fg="yellow"), err=True)

    cols = resp.get("columns") or []
    rows = resp.get("rows") or []
    items = [dict(zip(cols, r)) for r in rows]
    total = resp.get("total", len(items))

    if fmt in ("json", "yaml"):
        # ⭐ next_cursor is emitted so the paging is SCRIPTABLE: feed it straight
        # back in as --cursor. Without it, -o json could not walk a large drill.
        output({"kind": kind, "items": items, "total": total,
                "metrics": resp.get("metrics", []),
                "projection": resp.get("projection", []),
                "decomposed_via": resp.get("decomposed_via"),
                "next_cursor": resp.get("next_cursor"),
                "has_more": resp.get("has_more", False),
                "limit": resp.get("limit"),
                "page": resp.get("page", 1),
                "page_size": resp.get("page_size", len(items) or 1)},
               fmt=fmt, fields=fields)
        return

    metrics = resp.get("metrics") or []
    if metrics:
        click.echo(click.style("RECONCILIATION", bold=True))
        for m in metrics:
            # ⛔ A mismatch means the detail rows explain a DIFFERENT number than
            # the widget displayed — the decomposition is wrong and must say so.
            match = m.get("matches")
            mark = "✓" if match else ("✗" if match is False else "·")
            colour = "green" if match else ("red" if match is False else None)
            shown = "" if m.get("displayed") is None else f"  (cell showed {m['displayed']})"
            click.echo(click.style(
                f"  {mark} {m['column']} = {m['expression']} = {m.get('recomputed')}{shown}",
                fg=colour))
        click.echo()

    # ⭐ Say WHERE the rows came from. After crossing a transformer boundary the
    # user is looking at a different relation than the widget names, and without
    # this a mismatch above reads as a bug rather than as drift.
    via = resp.get("decomposed_via") or {}
    if via.get("source_relation"):
        click.echo(click.style(
            f"These rows come from {via['source_relation']}, the relation "
            f"{via.get('relation')} is built from.", dim=True))

    if resp.get("paged", True):
        shown = f"Showing {len(items)} rows"
        if total is not None:
            shown += f" of {total}"
        click.echo(click.style(shown + ".", dim=True))
    else:
        click.echo(click.style(
            f"Showing first {len(items)} rows (not pageable).", dim=True))

    nxt = resp.get("next_cursor")
    if nxt:
        # ⚠️ Only the GROUP-BY keys, not every column of the clicked row. The row
        # is enriched from full_result for reconciliation, so echoing all of it
        # would print a resume command far longer than the cursor it carries.
        gk = set(resp.get("group_keys") or [])
        aliases = ((resp.get("decomposed_via") or {}).get("key_aliases") or {})
        gk |= {a for a, c in aliases.items() if c in gk}
        pairs = [(k, v) for k, v in (row or {}).items() if not gk or k in gk]
        keyflags = " ".join(f"--key {k}={v}" for k, v in pairs)
        click.echo(click.style(
            f"  Next: torana widget {_wid(ctx)} decompose {keyflags} "
            f"--cursor {nxt}", dim=True))

    output({"items": items, "total": total}, fmt=fmt, fields=fields)


@widget.command(name="update")
@click.option("--name", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def widget_update(ctx, name, input_file):
    """Update a widget.

    \b
    ⛔ CHANGING `widget_type` ALSO REQUIRES A MATCHING `display_config`. The server
    validates the new type against the display_config it ends up with — and a PUT
    that sets only `widget_type` keeps the OLD shape, so the call fails with 400
    naming one missing key at a time:

    \b
      $ echo '{"widget_type": "bar"}' > w.json
      $ torana widget <WID> update --file w.json
      ERROR: API error (HTTP 400)
        bar widget requires 'x_axis' in display_config

    \b
    Send BOTH fields together. The shapes, per type:

    \b
      table         {"columns": ["col_a", "col_b"]}
      scalar        {"value_column": "n", "label": "Open criticals"}
      bar | line    {"x_axis": "severity", "y_axis": "count"}
      pie           {"x_axis": "...", "y_axis": "...",
                     "label_field": "severity", "value_field": "count"}

    \b
      # table → bar, in one call:
      torana widget <WID> update --file w.json
      # w.json:
      # {"widget_type": "bar",
      #  "display_config": {"x_axis": "severity", "y_axis": "count"}}

    \b
    ⚠️ The axis values must be COLUMN NAMES the widget's query actually returns —
    check with `torana widget <WID> explore` before switching type.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"widgets/{_wid(ctx)}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated widget: {_wid(ctx)}")


@widget.command(name="delete")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def widget_delete(ctx, yes):
    """Delete a widget."""
    _confirm(f"Delete widget {_wid(ctx)}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"widgets/{_wid(ctx)}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted widget: {_wid(ctx)}")


@widget.command(name="move")
@click.option("--target-workspace-id", "target_workspace_id", required=True)
@click.pass_context
def widget_move(ctx, target_workspace_id):
    """Move widget to a different workspace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = {"target_workspace_id": target_workspace_id}

    client = _client(ctx)
    try:
        data = client.post(f"widgets/{_wid(ctx)}/move", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)
