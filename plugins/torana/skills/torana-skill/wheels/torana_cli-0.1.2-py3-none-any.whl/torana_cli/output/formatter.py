"""
Output formatter — renders command results in text / json / yaml / table formats.

list commands:   receive a dict {items: [...], total: N, page: N, page_size: N}
get commands:    receive a bare dict
scalar commands: receive a string or simple value
"""

import json
import sys
from typing import Any, Optional

import yaml
from rich.console import Console
from rich.table import Table

#: ⛔ width=None + a HUGE explicit width when stdout is not a tty.
#:
#: A bare Console() takes its width from the tty and — when stdout is NOT a tty
#: (piped into `grep`, captured in CI, read by an agent) — silently falls back to 80
#: columns. That is how `torana entity-graph contract violations | grep gcp` came to
#: print `gcp/artifact_regis…`: the ellipsis was Rich fitting an ~110-char row into an
#: assumed 80-col window that no human ever saw.
#:
#: ⚠️ `soft_wrap=True` alone does NOT fix it — it stops wrapping but the table layout
#: has already allocated column widths against the 80-col budget, so cells get cut
#: with no ellipsis at all, which is WORSE (a clipped value that looks complete).
#: The width must be lifted before layout.
#:
#: A non-tty consumer is a pipe or a file: it has no width limit, so give the layout
#: room it will never exhaust and let each row be as wide as its content.
_console = Console(width=None if sys.stdout.isatty() else 10_000)


class OutputFormatter:
    """Formats and prints a single command result."""

    def __init__(
        self,
        fmt: str = "text",
        raw: bool = False,
        fields: Optional[str] = None,
    ):
        """
        fmt:    text | json | yaml | table
        raw:    if True and format=json, print bare items array (no envelope)
        fields: comma-separated field names to include (e.g. "id,name,severity")

        Non-TTY: if fmt is "text" and stdout is not a terminal, automatically
        uses "json" so piped commands always receive valid JSON.
        """
        self.fmt = fmt
        self.raw = raw
        self.field_list = [f.strip() for f in fields.split(",")] if fields else None

    def print(self, data: Any, columns: Optional[list] = None) -> None:
        """
        Print data in the configured format.

        data:    API response (dict, list, or scalar)
        columns: for text/table format — list of (field, header, width) tuples
                 e.g. [("id", "ID", 36), ("name", "NAME", 30)]
        """
        data = self._apply_fields(data)

        if self.fmt == "json":
            self._print_json(data)
        elif self.fmt == "yaml":
            self._print_yaml(data)
        elif self.fmt == "table":
            self._print_table(data, columns)
        else:
            self._print_text(data, columns)

    def _apply_fields(self, data: Any) -> Any:
        """Filter to requested fields if --fields was specified."""
        if not self.field_list:
            return data

        def _filter(item):
            if isinstance(item, dict):
                return {k: item[k] for k in self.field_list if k in item}
            return item

        if isinstance(data, dict) and "items" in data:
            return {
                **data,
                "items": [_filter(i) for i in data["items"]],
            }
        if isinstance(data, list):
            return [_filter(i) for i in data]
        if isinstance(data, dict):
            return _filter(data)
        return data

    def _print_json(self, data: Any) -> None:
        if self.raw:
            # Extract items array for piping
            if isinstance(data, dict) and "items" in data:
                data = data["items"]
        print(json.dumps(data, indent=2, default=str))

    def _print_yaml(self, data: Any) -> None:
        print(yaml.dump(data, default_flow_style=False, allow_unicode=True), end="")

    def _print_table(self, data: Any, columns: Optional[list] = None) -> None:
        """Print a Rich table with borders."""
        items = _to_items(data)
        if not items:
            _console.print("[dim]No results.[/dim]")
            return

        # ⛔ no_wrap=False + overflow="fold" — NEVER ellipsize a cell.
        #
        # Rich's default is to clip a cell to the terminal width with an ellipsis, and
        # a bare Console() takes its width from the tty. That silently mangled values
        # that are IDENTIFIERS: `gcp/artifact_regis…` cannot be pasted into the
        # follow-up command that takes it verbatim, `UNPROVABLE_STATICA…` is not a
        # value anyone can grep or pass to --outcome, and a truncated edge list
        # (`exposed_via, owns,`) HID `runs_on` entirely — making a debt count read
        # smaller than it was.
        #
        # Folding wraps long values onto continuation lines instead. The row gets
        # taller; no character is ever lost. `_print_columns` (the `text` renderer)
        # already honours a `None` width for exactly this reason — this brings the
        # `table` renderer in line with it.
        table = Table(show_header=True, header_style="bold", box=None,
                      pad_edge=False, collapse_padding=True)

        if columns:
            for _, header, _ in columns:
                table.add_column(header, no_wrap=False, overflow="fold")
            for item in items:
                if isinstance(item, dict):
                    row = [str(item.get(f, "")) for f, _, _ in columns]
                    table.add_row(*row)
        else:
            # Auto-detect columns from first item
            if isinstance(items[0], dict):
                keys = list(items[0].keys())
                for k in keys:
                    # Same no-ellipsis rule as the explicit-columns branch above.
                    table.add_column(k.upper().replace("_", " "),
                                     no_wrap=False, overflow="fold")
                for item in items:
                    table.add_row(*[str(item.get(k, "")) for k in keys])

        _console.print(table, soft_wrap=True)

    def _print_text(self, data: Any, columns: Optional[list] = None) -> None:
        """Column-aligned text output (like kubectl)."""
        items = _to_items(data)

        if not items:
            # An EMPTY COLLECTION is still a non-empty dict ({"items": [],
            # "total": 0}), so the single-resource branch below used to claim it
            # and print the envelope keys — `ITEMS []` / `TOTAL 0` — instead of
            # saying there were no results. Detect the collection envelope by its
            # marker key and report it as empty.
            if isinstance(data, dict) and ("items" in data or "total" in data):
                print("No results.")
                return
            # Single resource (a `get`): render its fields.
            if isinstance(data, dict) and data:
                _print_kv(data)
                return
            print("No results.")
            return

        # List output
        if columns:
            _print_columns(items, columns)
        else:
            # Auto-detect
            if isinstance(items[0], dict):
                keys = list(items[0].keys())
                cols = [(k, k.upper().replace("_", " "), 20) for k in keys]
                _print_columns(items, cols)
            else:
                for item in items:
                    print(item)

        # Pagination hint for list results
        if isinstance(data, dict) and "total" in data:
            # ⛔ `total` may be None, and a bare `data["total"] - n` then raises
            # TypeError AFTER the rows have already printed — the command looks
            # like it worked, exits 1, and any caller testing exit codes marks a
            # WORKING drill-down as dead. A cursor-paginated source (widget
            # decompose) legitimately has no count: it knows there is a next
            # page, not how many rows follow.
            total = data.get("total")
            page = data.get("page", 1)
            page_size = data.get("page_size", 50)
            shown = len(items)
            # Calculate how many items have been shown so far (previous pages + current page)
            items_shown_so_far = (page - 1) * page_size + shown
            # ⚠️ No total → no honest "N remaining" to state. Print nothing
            # rather than guess; the cursor line above already says how to
            # continue.
            remaining = (total - items_shown_so_far) if total is not None else 0
            # Only show pagination hint if there are actually more results
            if remaining > 0:
                print(f"\nShowing {shown} of {total} results. "
                      f"Use --page {page + 1} for next page "
                      f"({remaining} remaining).")


def _to_items(data: Any) -> list:
    """Extract items list from envelope or bare list."""
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        if "items" in data:
            return data["items"]
    return []


def _print_kv(obj: dict) -> None:
    """Print a single object as key: value pairs."""
    max_key = max((len(k) for k in obj), default=10)
    for k, v in obj.items():
        key = k.replace("_", " ").upper().ljust(max_key)
        if isinstance(v, (dict, list)):
            v = json.dumps(v, default=str)
        print(f"{key}  {v}")


def _truncate(value: str, max_width: int) -> str:
    """Truncate a string to max_width, appending … if truncated."""
    if len(value) <= max_width:
        return value
    return value[:max_width - 1] + "…"


def _print_columns(items: list, columns: list) -> None:
    """Print rows in fixed-width columns with a header.

    The width in each column tuple is treated as both the minimum AND maximum
    width — content is truncated with … rather than allowed to blow out the line.

    A width of ``None`` means "never truncate": the column grows to fit the widest
    value in full. Use it for id / correlation columns whose value must never be
    clipped (a truncated id can't be copied back into another command).
    """
    headers = [h for _, h, _ in columns]

    # Grow each column to fit its data — up to its cap, or unbounded when cap is None.
    widths = [len(h) for h in headers]
    for col_idx, (field, _, cap) in enumerate(columns):
        for item in items:
            if isinstance(item, dict):
                val = str(item.get(field, ""))
                grown = max(widths[col_idx], len(val))
                widths[col_idx] = grown if cap is None else min(cap, grown)

    # Print header
    header_line = "  ".join(h.ljust(w) for h, w in zip(headers, widths))
    print(header_line)

    # Print rows
    for item in items:
        if isinstance(item, dict):
            cells = []
            for (field, _, cap), width in zip(columns, widths):
                raw = str(item.get(field, ""))
                # cap is None → never truncate; otherwise clip to the column width.
                val = raw if cap is None else _truncate(raw, width)
                cells.append(val.ljust(width))
            print("  ".join(cells))
        else:
            print(str(item))


def output(
    data: Any,
    fmt: str = "text",
    raw: bool = False,
    fields: Optional[str] = None,
    columns: Optional[list] = None,
) -> None:
    """Convenience function — create formatter and print."""
    OutputFormatter(fmt=fmt, raw=raw, fields=fields).print(data, columns=columns)
