"""torana alerts — alert management commands."""

import json as _json
import sys

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW, CollectionGroup
from torana_cli.output import output
from torana_cli.rules import _load_input_file

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 30),
    ("severity", "SEVERITY", 10),
    # The list is ORDERED by priority (lower is sooner), so the column that decides the
    # order has to be visible — otherwise the order looks arbitrary.
    ("triage_priority", "PRIO", 6),
    ("status", "STATUS", 12),
    ("fired", "FIRED", 16),
    ("assignee", "ASSIGNED TO", 24),
    ("rule_id", "RULE", 36),
    ("triage_verdict", "VERDICT", 15),
    # F-o01-2 — whether the deployment this TRUE POSITIVE relied on is still running.
    # ⛔ The verdict itself is unchanged; this column reports an observation, never a
    # re-decision. "—" covers both "still running" and "no record", which is why the
    # stale case spells itself out rather than relying on the column being non-empty.
    ("runtime", "RUNTIME", 22),
    ("reason_code", "REASON", 24),
    ("decided_by", "DECIDED BY", 14),
    # § 5.26 — what KIND of entry this is, in the rule's own words. Shown rather than
    # only filterable, because `--category posture` returning 139 rows is unreadable if
    # the rows do not say which of them are posture.
    ("category", "CATEGORY", 14),
    # Phase 3 — which Inbox box the item is in, and who closed it. Both come from the
    # API; the CLI never works out a box itself.
    ("box", "BOX", 16),
    ("why_label", "WHY", 22),
    ("closed_by", "CLOSED BY", 24),
]


def _assignee_label(item, name_cache=None):
    """Human label for who an alert is assigned to.

    Resolution order: stored display name → resolved name from name_cache →
    '<type>:<short-id>' fallback (e.g. 'agent:be2f5d91…'). '—' when unassigned.
    `name_cache` maps assigned_to UUID → resolved name (or None if lookup failed).
    """
    name = item.get("assignee_display_name")
    if name:
        return str(name)
    who = item.get("assigned_to")
    if not who:
        return "—"
    if name_cache and name_cache.get(who):
        return name_cache[who]
    kind = item.get("assignee_type") or "?"
    return f"{kind}:{str(who)[:8]}…"


def _decider_label(item, name_cache=None):
    """Who reached this verdict, in one short column.

    The three deciders are deliberately distinguishable: a RULE stamped it from the
    ranking, the triage AGENT judged it, or a PERSON did. Before this the record could
    not tell them apart — the agent's service login made its verdicts read as an
    anonymous user's.
    """
    kind = (item.get("verdict_actor_type") or "").lower()
    who = item.get("verdict_actor_id") or ""
    if not kind:
        return ""
    if kind == "system":
        return "the ranking" if who.startswith("rule:") else "system"
    if kind == "agent":
        name = (name_cache or {}).get(("agent", who))
        return name or "triage agent"
    name = (name_cache or {}).get(("user", who))
    return name or (who[:8] if who else "a person")


def _resolve_assignee_names(client, items):
    """Resolve assignee UUIDs → human names for a page of alerts.

    Dedups by (type, id) so each distinct assignee costs at most one lookup:
    users via GET users/{id} (name|email), agents via GET agents/{id} (name).
    Failures are cached as None so the caller falls back to the UUID label and
    we never retry a bad id. Returns {assigned_to_uuid: name|None}.
    """
    cache = {}
    seen = set()
    for it in items:
        if not isinstance(it, dict):
            continue
        who = it.get("assigned_to")
        kind = (it.get("assignee_type") or "").lower()
        if not who or it.get("assignee_display_name"):
            continue
        key = (kind, who)
        if key in seen:
            continue
        seen.add(key)
        try:
            if kind == "user":
                row = client.get(f"users/{who}")
                cache[who] = row.get("name") or row.get("email")
            elif kind == "agent":
                row = client.get(f"agents/{who}")
                cache[who] = row.get("name")
            else:
                cache[who] = None
        except (APIError, AuthError):
            cache[who] = None  # degrade to UUID label; don't fail the list
    return cache


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)




def _as_json_value(raw, flag, expect):
    """Parse a JSON-typed CLI flag into the structure the API requires.

    These fields are list/object-typed server-side, so forwarding the raw string
    422s with "Input should be a valid list". Accepts JSON; for `list` also
    accepts a comma-separated string of scalars (the natural form for --tags).
    """
    if raw is None:
        return None
    text = str(raw).strip()
    if not text:
        return [] if expect == "list" else {}
    if text.startswith(("[", "{")):
        try:
            parsed = _json.loads(text)
        except ValueError as e:
            click.echo(f"ERROR: {flag} is not valid JSON: {e}", err=True)
            sys.exit(2)
    elif expect == "list":
        # Convenience for scalar lists like --tags a,b,c.
        parsed = [p.strip() for p in text.split(",") if p.strip()]
    else:
        click.echo(f"ERROR: {flag} must be a JSON object, e.g. '{{\"k\": \"v\"}}'.", err=True)
        sys.exit(2)

    if expect == "list" and not isinstance(parsed, list):
        click.echo(f"ERROR: {flag} must be a JSON array.", err=True)
        sys.exit(2)
    if expect == "object" and not isinstance(parsed, dict):
        click.echo(f"ERROR: {flag} must be a JSON object.", err=True)
        sys.exit(2)
    return parsed


@click.group(cls=CollectionGroup, singular="alert")
def alerts():
    """Manage and triage alerts (collection operations).

    \b
    Examples:
      torana alerts list
      torana alerts list --severity critical --state open
      torana alerts create --name "SSH Brute Force" ...

    \b
    Instance operations (get, status, assign, etc.) use the singular form:
      torana alert <UUID> get
      torana alert <UUID> status --status resolved
      torana alert <UUID> assign --assigned-to <user-id>
    """


def list_alerts_core(ctx, *, severity=None, state=None, status_filter=None, rule_id=None,
                     workspace_id=None, assigned_to=None, page=None, page_size=None,
                     limit=None, offset=None, fetch_all=False, resolve_names=True,
                     group_role=None, decided_by=None, finding_severity=None, action=None,
                     category=None, boxes=None, why=None, verdict=None, inbox_rows=False,
                     runtime_stale=False):
    """Shared alert-listing routine.

    Backs both `torana alerts list` (no workspace context) and
    `torana workspace <id> alerts list` (workspace_id pre-bound). Both forms are
    the same operation differing only by whether the workspace filter is set, so
    they MUST go through this one routine — never a parallel list path.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    # Accept both pagination conventions: --page/--page-size (native) and
    # --limit/--offset (alias). resolve_page() collapses them to (page, page_size).
    from torana_cli.pagination import resolve_page
    page, effective_page_size = resolve_page(
        page, page_size, limit, offset, default_page_size=settings.page_size
    )

    # The v2 alerts endpoint takes filters as a JSON `filters` query string
    # ({"field":{"operation":..,"value":..}}), NOT flat params like ?rule_id=X.
    # Flat params are silently ignored (this was the --rule-id bug). Build the
    # JSON filter map here. workspace_id/tenant_id ARE accepted as direct query
    # params by the endpoint, so workspace_id stays flat.
    import json as _json
    filters = {}
    # status (and the --state alias) accept a comma-separated list → in_list.
    status_val = status_filter or state
    if status_val:
        vals = [s.strip() for s in str(status_val).split(",") if s.strip()]
        filters["status"] = ({"operation": "in_list", "value": vals} if len(vals) > 1
                             else {"operation": "equals", "value": vals[0]})
    if severity:
        vals = [s.strip() for s in str(severity).split(",") if s.strip()]
        filters["severity"] = ({"operation": "in_list", "value": vals} if len(vals) > 1
                               else {"operation": "equals", "value": vals[0]})
    # Fix-grain WP4 — one row per ACTION instead of one per finding. ⚠️ This goes through
    # the v2 `filters` map like every other filter here, which is why `group_role` had to
    # join v2's FIELDS: an unknown field there is a 400, not an ignored parameter.
    if group_role:
        filters["group_role"] = {"operation": "equals", "value": group_role}
    # Row 3.26 — the Inbox's own row population (the platform's `top_level`): the CLI can list
    # exactly what the Inbox lists, and `alerts boxes --inbox-rows` counts the same rows.
    if inbox_rows:
        filters["top_level"] = {"operation": "equals", "value": True}
    # WHO decided: 'system' (a rule declared it), 'agent' or 'user'. Comma-separated
    # becomes in_list, matching --status/--severity above.
    if decided_by:
        vals = [s.strip().lower() for s in str(decided_by).split(",") if s.strip()]
        filters["verdict_actor_type"] = (
            {"operation": "in_list", "value": vals} if len(vals) > 1
            else {"operation": "equals", "value": vals[0]})
    # A4 — the FINDING's severity, not the rule's. `--severity` filters the rule's,
    # which is one value per rule, so it cannot narrow a single rule's output at all.
    if finding_severity:
        vals = [s.strip().title() for s in str(finding_severity).split(",") if s.strip()]
        filters["finding_severity"] = (
            {"operation": "in_list", "value": vals} if len(vals) > 1
            else {"operation": "equals", "value": vals[0]})
    # A8 — the KIND of action. `upgrade` / `mitigation` / `finding`, as the rule
    # declared it. Accepts the friendly verbs too, since that is what the UI shows.
    if action:
        _ACTION = {"upgrade": "upgrade", "mitigate": "mitigation",
                   "mitigation": "mitigation", "review": "finding", "finding": "finding"}
        vals = [_ACTION.get(s.strip().lower(), s.strip().lower())
                for s in str(action).split(",") if s.strip()]
        filters["entity_type"] = ({"operation": "in_list", "value": vals} if len(vals) > 1
                                  else {"operation": "equals", "value": vals[0]})
    # § 5.26 — the rule-declared entry kind. No verb map here, deliberately: `--action`
    # needs one because its three values are the platform's guess at one app's
    # vocabulary, and this is whatever the RULE declared, so translating it would put the
    # same words back in the platform.
    if category:
        vals = [s.strip().lower() for s in str(category).split(",") if s.strip()]
        filters["category_key"] = ({"operation": "in_list", "value": vals} if len(vals) > 1
                                   else {"operation": "equals", "value": vals[0]})
    # The box model — why it is closed, and the verdict. Together they list the signal
    # the platform counts: a true positive a person closed as false positive.
    # F-o01-2 — one boolean the API resolves, so the CLI, the inbox and the API ask the
    # SAME question rather than three spellings of it.
    if runtime_stale:
        filters["verdict_runtime_stale"] = {"operation": "equals", "value": True}
    for key, raw_val in (("why", why), ("triage_verdict", verdict)):
        if raw_val:
            vals = [s.strip().lower() for s in str(raw_val).split(",") if s.strip()]
            filters[key] = ({"operation": "in_list", "value": vals} if len(vals) > 1
                            else {"operation": "equals", "value": vals[0]})
    if rule_id:
        filters["rule_id"] = {"operation": "equals", "value": rule_id}
    if assigned_to:
        filters["assigned_to"] = {"operation": "equals", "value": assigned_to}

    params = {"page": page, "page_size": effective_page_size}
    if filters:
        params["filters"] = _json.dumps(filters)
    # Phase 3 — repeatable `box` query parameter; the API filters its stored column.
    if boxes:
        params["box"] = [b.lower() for b in boxes]
    if workspace_id:
        params["workspace_id"] = workspace_id

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"page": page_num, "page_size": effective_page_size}
                p.update({k: v for k, v in params.items() if k not in ("page", "page_size")})
                data = client.get("api/v2/alerts", params=p)
                items = data.get("items", [])
                all_items.extend(items)
                if len(all_items) >= data.get("total", len(all_items)):
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items), "page": 1,
                      "page_size": len(all_items)}
        else:
            result = client.get("api/v2/alerts", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    items = result.get("items", [])

    # Resolve assignee UUIDs → names for the human-readable views only. The
    # extra lookups (deduped, one per distinct assignee) aren't worth it for
    # machine output, which keeps the raw assigned_to/assignee_type fields.
    name_cache = None
    if resolve_names and fmt in ("text", "table") and not raw:
        name_cache = _resolve_assignee_names(client, items)

    # Derive human "fired" and "assignee" columns, injected onto each item so
    # they render in text/table and are selectable via --fields; the raw
    # first_seen_at / assigned_to / assignee_type fields stay intact for JSON.
    from torana_cli.time_util import format_relative
    for item in items:
        if isinstance(item, dict):
            item["fired"] = format_relative(item.get("first_seen_at") or item.get("created_at"))
            item["assignee"] = _assignee_label(item, name_cache)
            # WHO decided this verdict. The raw columns stay intact for JSON; this is the
            # human column, because "true_positive" without a decider is half the record.
            item["decided_by"] = _decider_label(item, name_cache)
            # § 5.26 — the LABEL for the column, the key for `--category`. Falling back
            # to the key keeps a row readable if a rule declared a key and an empty
            # label; falling back to the raw columns keeps JSON output unchanged.
            item["category"] = item.get("category_label") or item.get("category_key")
            # Who closed it, as the API words it ("The agent", "The data", a person).
            item["closed_by"] = item.get("closed_by_display_name") or "—"
            # Why it is closed, as the API words it ("Closed: accepted risk").
            item["why_label"] = item.get("why_label") or "—"
            # F-o01-2 — read the API's DERIVED `verdict_runtime_stale`, never
            # `stale_at` directly: the derived one is already gated on the alert being
            # a true positive, so a stale flag left on a row whose verdict changed
            # cannot show here.
            _stale_since = (item.get("verdict_runtime_stale_at") or "")[:10]
            item["runtime"] = (f"stale since {_stale_since}"
                               if item.get("verdict_runtime_stale") else "—")
            # An unjudged alert is the common case; render it as an em dash like the
            # assignee column rather than a column of the literal word "None".
            for _k in ("triage_verdict", "reason_code", "triage_priority", "category"):
                if item.get(_k) in (None, ""):
                    item[_k] = "—"

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@alerts.command(name="list")
@click.option("--severity", default=None,
              type=click.Choice(["low", "medium", "high", "critical"], case_sensitive=False),
              help="Filter by severity.")
@click.option("--state", default=None, help="Filter by state (e.g. open, closed, in_progress).")
@click.option("--rule-id", default=None, help="Filter by detection rule UUID.")
@click.option("--workspace-id", default=None, help="Filter by workspace UUID.")
@click.option("--assigned-to", default=None,
              help="Filter by assigned user — email address or user UUID. "
                   "An unrecognized value errors (422) rather than returning an empty list.")
@click.option("--status", "status_filter", default=None,
              help="Filter by status. Accepts comma-separated values, e.g. "
                   "'pending_remediation,escalated'. "
                   "Valid: open, triaging, awaiting_input, pending_remediation, "
                   "escalated, resolved, closed.")
@click.option("--page", default=None, type=int, help="Page number (1-indexed).")
@click.option("--page-size", default=None, type=int,
              help="Results per page (max 100). Alias of --limit.")
@click.option("--limit", default=None, type=int,
              help="Max results to return (alias of --page-size).")
@click.option("--offset", default=None, type=int,
              help="Results to skip (alias of (page-1)*page_size).")
@click.option("--roots-only", "roots_only", is_flag=True, default=False,
              help="Only the alerts that stand for an ACTION (one per fix), not the "
                   "findings they clear.")
@click.option("--decided-by", "decided_by", default=None,
              help="Who decided the verdict: system (a rule declared it), agent or "
                   "user. Comma-separated for several.")
@click.option("--finding-severity", "finding_severity", default=None,
              help="Severity of the matched FINDING (critical/high/medium/low). "
                   "Distinct from --severity, which is the RULE's and is one value "
                   "per rule. Comma-separated for several.")
@click.option("--action", "action", default=None,
              help="What KIND of action: upgrade, mitigate or review. Comma-separated "
                   "for several. ('mitigate' means no fix exists.)")
@click.option("--category", "category", default=None,
              help="The rule-declared entry kind, e.g. posture. Comma-separated for "
                   "several. This is the KEY, not the label on the chip: the key is "
                   "stable, the label is prose the rule may reword.")
@click.option("--box", "boxes", multiple=True,
              type=click.Choice(["needs_attention", "closed", "moved"],
                                case_sensitive=False),
              help="Inbox box, repeatable: needs_attention, closed, moved. Omitted "
                   "means All. The box is worked out by the platform, the same answer "
                   "the Inbox shows. moved: the work moved to another entry.")
@click.option("--why", "why", default=None,
              help="Why a closed item is closed: fixed, accepted_risk, wont_fix, "
                   "duplicate, false_positive, benign (a person's reason), closed, or "
                   "moved. Comma-separated for several.")
@click.option("--verdict", "verdict", default=None,
              help="The verdict: true_positive, false_positive, benign, inconclusive. "
                   "Comma-separated for several.")
@click.option("--runtime-stale", "runtime_stale", is_flag=True, default=False,
              help="Only true positives whose relied-on deployment is no longer running "
                   "(verdict unchanged).")
@click.option("--inbox-rows", "inbox_rows", is_flag=True, default=False,
              help="Exactly the rows the Inbox lists: roots, ungrouped items, and members "
                   "no open root stands for. Matches `alerts boxes --inbox-rows`. Not the "
                   "same as --roots-only, which is one row per fix.")
@click.option("--all", "fetch_all", is_flag=True, default=False,
              help="Auto-paginate and return all results.")
@click.pass_context
def alerts_list(ctx, severity, state, status_filter, rule_id, workspace_id, assigned_to,
                page, page_size, limit, offset, roots_only, decided_by, finding_severity,
                action, category, boxes, why, verdict, runtime_stale, inbox_rows, fetch_all):
    """List alerts.

    \b
    Examples:
      torana alerts list --severity critical
      torana alerts list --status pending_remediation,escalated --assigned-to me@acme.com
      torana alerts list --format json | jq '.items[] | select(.severity == "critical")'
      torana alerts list --roots-only        # one row per FIX, not per finding
      torana alerts list --decided-by system # everything the ranking decided
      torana alerts list --decided-by agent,user
      torana alerts list --box closed                  # everything closed
      torana alerts list --box needs_attention --inbox-rows --all
                                                       # exactly the Inbox's rows
      torana alerts list --why false_positive --verdict true_positive
                                                       # true positives closed as FP
    """
    list_alerts_core(ctx, severity=severity, state=state, status_filter=status_filter,
                     rule_id=rule_id, workspace_id=workspace_id, assigned_to=assigned_to,
                     page=page, page_size=page_size, limit=limit, offset=offset,
                     fetch_all=fetch_all, decided_by=decided_by,
                     finding_severity=finding_severity, action=action, category=category,
                     boxes=boxes, why=why, verdict=verdict, inbox_rows=inbox_rows,
                     runtime_stale=runtime_stale,
                     group_role="root" if roots_only else None)


@alerts.command(name="boxes")
@click.option("--workspace-id", default=None, help="Count one workspace's items.")
@click.option("--inbox-rows", "inbox_rows", is_flag=True, default=False,
              help="Count the rows the Inbox lists: roots, ungrouped items, and members no "
                   "open root stands for. Matches `alerts list --inbox-rows`.")
# ⚠️ The old name, kept so existing scripts still count the same rows. On `alerts list`
# --roots-only means one row per FIX, a different population, hence the new name here.
@click.option("--roots-only", "roots_only", is_flag=True, default=False, hidden=True)
@click.pass_context
def alerts_boxes(ctx, workspace_id, inbox_rows, roots_only):
    """How many items are in each Inbox box, and the app's own population.

    The counts come from the platform (GET /api/v2/alerts/facet-counts), the same
    numbers the Inbox shows on its tabs. Moved items are counted in All only.

    \b
    ⛔ TWO DIFFERENT NUMBERS, AND THEY COUNT DIFFERENT THINGS:
      · `All` is the three boxes added up — how many ITEMS the Inbox holds for this scope.
      · the population line is the APP's own, when the app declared one: how many
        FINDINGS the app is about, counted in the datalake. It is not the sum of the
        boxes and must never be added to them.
    The population is counted after each rule run rather than on demand, so it carries
    when it was counted, and says so when a rule has run since.

    \b
    Examples:
      torana alerts boxes
      torana alerts boxes --workspace-id <UUID> --inbox-rows
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    params = {}
    if workspace_id:
        params["workspace_id"] = workspace_id
    if inbox_rows or roots_only:
        params["top_level"] = "true"
    client = _client(ctx)
    try:
        data = client.get("api/v2/alerts/facet-counts", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    boxes = (data or {}).get("boxes") or {}
    signals = (data or {}).get("signals") or {}
    population = (data or {}).get("population") or None
    labels = {"needs_attention": "Needs attention", "closed": "Closed", "moved": "Moved"}
    rows = [{"box": k, "label": labels[k], "count": int(boxes.get(k, 0))}
            for k in ("needs_attention", "closed", "moved")]
    fp_on_tp = int(signals.get("closed_false_positive_while_true_positive", 0))
    if fmt == "text" and not fields:
        for r in rows:
            click.echo(f"{r['label']:<16} {r['count']}")
        click.echo(f"{'All':<16} {sum(r['count'] for r in rows)}")
        if population:
            # ⚠️ Printed on its own line, under the app's OWN word for a row, and never
            # folded into the table above: it counts findings in the datalake, while the
            # table counts items in the Inbox. Two numbers, two populations.
            n = population.get("count")
            label = (population.get("label_singular") if n == 1
                     else population.get("label")) or "items"
            when = str(population.get("counted_at") or "")[:16].replace("T", " ")
            note = f"as of {when}" if when else "time not recorded"
            if population.get("stale"):
                # A rule has run since the count, so the estate may have moved. Said
                # plainly rather than hidden — the number is still the best one we have.
                note += "; a rule has run since, so this may be behind"
            click.echo("")
            click.echo(f"The app counts {n:,} {label} ({note})")
        click.echo("")
        click.echo(f"Closed as false positive while true positive: {fp_on_tp}")
        return
    # ⛔ `len(rows)` WAS 3 — the number of BOXES, printed under a key every other
    # command uses for a number of items. A script reading `total` got 3 beside an `All`
    # of 11. The total is the items the Inbox can LIST, which is what the platform now
    # returns; the moved count stays visible in `items`.
    output({"items": rows, "total": int((data or {}).get("total") or 0),
            "boxes_shown": len(rows), "signals": signals,
            "population": population}, fmt=fmt, fields=fields)


@alerts.command(name="kinds")
@click.option("--workspace-id", default=None, help="Count one workspace's items.")
@click.option("--inbox-rows", "inbox_rows", is_flag=True, default=False,
              help="Count the rows the Inbox lists (same population as `alerts boxes "
                   "--inbox-rows`).")
@click.pass_context
def alerts_kinds(ctx, workspace_id, inbox_rows):
    """What KIND of thing each open item is: its category and where its finding lives.

    The counts come from the platform (GET /api/v2/alerts/facet-counts, `open_by_kind`):
    open means any status other than closed. PLACE is read from the item's key:

    \b
      code        a finding in source code, in a repository
      repository  a package finding in a repository's dependencies
      image       a package finding on a container image
      other       a finding whose key names no recognised place
    An upgrade, mitigation or posture note the app proposes is not a finding and has
    no place; those are counted separately under "Not findings".

    \b
    Examples:
      torana alerts kinds --workspace-id <UUID>
      torana alerts kinds --workspace-id <UUID> --inbox-rows --format json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    params = {}
    if workspace_id:
        params["workspace_id"] = workspace_id
    if inbox_rows:
        params["top_level"] = "true"
    client = _client(ctx)
    try:
        data = client.get("api/v2/alerts/facet-counts", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    summary = (data or {}).get("open_by_kind")
    if summary is None:
        # An older platform without the dimension: say so rather than print zeros.
        click.echo("This platform does not report kinds yet (facet-counts has no "
                   "open_by_kind).", err=True)
        ctx.exit(1)
        return
    if fmt == "text" and not fields:
        click.echo(f"Open items: {summary.get('total', 0)}")
        click.echo("")
        click.echo("By category:")
        for k, n in (summary.get("by_category") or {}).items():
            click.echo(f"  {k:<16} {n}")
        click.echo(f"Open findings by place ({summary.get('findings', 0)} findings):")
        for k, n in (summary.get("by_place") or {}).items():
            click.echo(f"  {k:<16} {n}")
        click.echo("Open findings by category and place:")
        for r in summary.get("by_category_and_place") or []:
            click.echo(f"  {r['category_key'] or '-':<16} {r['place']:<12} {r['count']}")
        nf = summary.get("not_findings") or {}
        if nf.get("total"):
            # Not a place: an upgrade, mitigation or posture note the app proposes.
            parts = ", ".join(f"{k} {n}" for k, n in (nf.get("by_category") or {}).items())
            click.echo(f"Not findings (actions the app proposes, no place): {nf['total']} ({parts})")
        return
    output({"items": summary.get("by_category_and_place") or [],
            "total": int(summary.get("total") or 0),
            "by_category": summary.get("by_category") or {},
            "findings": int(summary.get("findings") or 0),
            "by_place": summary.get("by_place") or {},
            "not_findings": summary.get("not_findings") or {},
            "kinds": (data or {}).get("kinds") or []}, fmt=fmt, fields=fields)


@alerts.command(name="create")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with request body. Use '-' for stdin.")
@click.option("--name", "name", default=None,
              help="Alert title, typically derived from the rule name. Required unless --file supplies it.")
@click.option("--description", "description", default=None, help="Detailed description of the security issue detected")
@click.option("--rule-id", "rule_id", default=None,
              help="ID of the rule that generated this alert. Required unless --file supplies it.")
@click.option("--workspace-id", "workspace_id", default=None,
              help="Workspace UUID the alert belongs to. Required unless --file supplies it — "
                   "the column is NOT NULL, so omitting it fails with a server 500.")
@click.option("--severity", "severity", type=click.Choice(["low", "medium", "high", "critical"], case_sensitive=False), default=None)
@click.option("--status", "status", type=click.Choice(["open", "triaging", "awaiting_input", "pending_remediation", "escalated", "resolved", "closed"], case_sensitive=False), default=None, help="Alert lifecycle status.")
@click.option("--assigned-to", "assigned_to", default=None, help="User or team assigned to investigate this alert")
@click.option("--rule-run-results", "rule_run_results", default=None,
              help="Query results that triggered this alert, as a JSON array "
                   "(e.g. '[{\"cve_id\": \"CVE-2024-1\"}]'). Required unless --file supplies it.")
@click.option("--labels", "labels", default=None,
              help="Key-value pairs for categorizing alerts, as a JSON object.")
@click.option("--tags", "tags", default=None,
              help="Tags for categorizing and routing alerts — JSON array or comma-separated.")
@click.pass_context
def alerts_create(ctx, name, description, rule_id, workspace_id, severity, status, assigned_to, rule_run_results, labels, tags, input_file):
    """Create Alert.

    \b
    Examples:
      torana alerts create --name "SSH brute force" --rule-id <RULE_ID> --severity high
      torana alerts create --file alert.yaml
      torana alerts create --name "Exposed bucket" --severity critical \
          --assigned-to <USER_ID> --status open
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "alerts"
    if input_file:
        body = _load_input_file(input_file)
    else:
        body = {}
        body["name"] = name
        if description is not None:
            body["description"] = description
        body["rule_id"] = rule_id
        if workspace_id is not None:
            body["workspace_id"] = workspace_id
        if severity is not None:
            body["severity"] = severity
        if status is not None:
            body["status"] = status
        if assigned_to is not None:
            body["assigned_to"] = assigned_to
        if rule_run_results is not None:
            # The API requires a LIST; forwarding the raw string 422s with
            # "Input should be a valid list". Parse the JSON the flag documents.
            body["rule_run_results"] = _as_json_value(
                rule_run_results, "--rule-run-results", expect="list")
        if labels is not None:
            body["labels"] = _as_json_value(labels, "--labels", expect="object")
        if tags is not None:
            body["tags"] = _as_json_value(tags, "--tags", expect="list")

    missing = [f for f in ("name", "rule_id", "workspace_id", "rule_run_results")
               if not body.get(f)]
    if missing:
        click.echo(
            "ERROR: missing required field(s): "
            + ", ".join("--" + f.replace("_", "-") for f in missing)
            + "\n       Supply them as flags, or provide all of them in --file.",
            err=True)
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alerts.command(name="filter")
@click.option("--filters", "filters", default=None,
              help='JSON object: field -> value, or field -> {"operation": <op>, '
                   '"value": <v>}. A bare value means equals, a list means in_list. '
                   'e.g. \'{"severity": "critical"}\' or '
                   '\'{"severity": {"operation": "in_list", "value": ["critical", "high"]}}\'')
@click.option("--limit", "limit", type=int, default=100)
@click.option("--offset", "offset", type=int, default=0)
@click.pass_context
def alerts_filter(ctx, filters, limit, offset):
    """Get alerts matching a filter expression.

    ⛔ `--filters` IS JSON AND MUST BE PARSED HERE. It used to be passed through as the
    raw STRING click handed us, so the API saw `"{\\"severity\\": \\"critical\\"}"` where
    it required an object and answered `422 body -> filters: Input should be a valid
    dictionary` — for EVERY invocation, including correct ones. Measured on T1
    2026-10-04: the command had never returned a single alert. Found by running it, not
    by reading it; `tests/test_alerts_filter_json.py` is the regression.

    Examples:
      torana alerts filter --filters '{"severity": "critical"}'
      torana alerts filter --filters '{"status": {"operation": "in_list", "value": ["open", "escalated"]}}'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "alerts/filter"
    body = {}
    if filters is not None:
        if isinstance(filters, str):
            try:
                filters = _json.loads(filters)
            except _json.JSONDecodeError as exc:
                # ⚠️ Fail HERE with the offending text, not at the API. A JSON typo
                # otherwise comes back as a generic 422 about `filters` that says
                # nothing about which character was wrong.
                raise click.BadParameter(
                    f"--filters must be a JSON object: {exc}", param_hint="--filters")
        if not isinstance(filters, dict):
            raise click.BadParameter(
                f"--filters must be a JSON OBJECT, got {type(filters).__name__}",
                param_hint="--filters")
        body["filters"] = filters
    if limit is not None:
        body["limit"] = limit
    if offset is not None:
        body["offset"] = offset

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alerts.command(name="by-rule-by-rule-id")
@click.argument("RULE_ID", metavar="RULE_ID")
@click.pass_context
def alerts_by_rule_by_rule_id(ctx, rule_id):
    """Get Alerts By Rule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"alerts/by-rule/{rule_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alerts.command(name="by-suite-by-suite-id")
@click.argument("SUITE_ID", metavar="SUITE_ID")
@click.pass_context
def alerts_by_suite_by_suite_id(ctx, suite_id):
    """Get Alerts By Suite."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"alerts/by-suite/{suite_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ──────────────────────────────────────────────────────────────────────────
# Instance reads regrouped from `<noun>-by-<param>` leaves onto verbs
# (CLI Discoverability Contract, rule 2 — see ../CLAUDE.md). The route
# parameter belongs in the positional ARGUMENT, not the command name.
#
# Old flat names remain as HIDDEN aliases for ONE release (D4).
# ──────────────────────────────────────────────────────────────────────────


@alerts.group(name="suite-rule")
def alerts_suite_rule_grp():
    """Alerts for one rule within one suite.

    Examples:
      torana alerts suite-rule get --help
    """


@alerts_suite_rule_grp.command(name="get")
@click.argument("SUITE_ID", metavar="SUITE_ID")
@click.argument("RULE_ID", metavar="RULE_ID")
@click.pass_context
def alerts_rule_by_rule_id(ctx, suite_id, rule_id):
    """Get Alerts By Suite And Rule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"alerts/by-suite/{suite_id}/rule/{rule_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alerts.command(name="count")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--suite-id", "suite_id", default=None)
@click.option("--rule-id", "rule_id", default=None)
@click.pass_context
def alerts_count(ctx, suite_id, rule_id, page, page_size, fetch_all):
    """Get Alerts Count."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "alerts/count"
    params = {}
    if suite_id is not None:
        params["suite_id"] = suite_id
    if rule_id is not None:
        params["rule_id"] = rule_id
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@alerts.command(name="triage-agents")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def alerts_triage_agents(ctx, page, page_size, fetch_all):
    """List Triage Agents."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "alerts/triage/agents"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


# ---------------------------------------------------------------------------
# activities — standalone top-level command group
# ---------------------------------------------------------------------------

@click.group()
def activities():
    """Platform activity feed — what happened, across resources.

    \b
    Examples:
      torana activities list
      torana activities list --json --raw | jq '.[0]'
      torana activities list --help          filters (resource, actor, time window)
      torana activities create --alert-id <ALERT_ID> --activity-type note --message "..."
    """


@activities.command(name="list")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--vulnerability-id", "vulnerability_id", default=None,
              help="Only activities about ONE finding — its own timeline, alert or not.")
@click.pass_context
def activities_list(ctx, page, page_size, fetch_all, vulnerability_id):
    """List activities — the platform timeline.

    ⚠️ An activity's subject is an ALERT or a VULNERABILITY (T11 § 3.3.3). Without
    --vulnerability-id this lists both kinds interleaved.

    \b
    Examples:
      torana activities list
      torana activities list --vulnerability-id "gcp_ca_image:...@sha256:...
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "activities"
    effective_page_size = min(page_size or settings.page_size, 100)
    # ⛔ `offset`, NOT `skip` — the endpoint declares `offset` and IGNORES an unknown
    # `skip`, so every page silently returned PAGE ONE. Verified against the running
    # service: `?skip=1` and `?offset=0` returned an identical first row, while
    # `?offset=1` returned the next one. `--all` was affected too: the loop breaks on
    # `len(all_items) >= total`, and a list response makes total == the page size, so
    # it stopped after one page while reporting success.
    params = {"offset": (page - 1) * effective_page_size, "limit": effective_page_size}
    if vulnerability_id:
        params["vulnerability_id"] = vulnerability_id

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "offset": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)



@activities.command(name="create")
@click.option("--alert-id", "alert_id", default=None, help="The alert this activity is about.")
@click.option("--vulnerability-id", "vulnerability_id", default=None,
              help="The datalake vulnerability this activity is about.")
@click.option("--activity-type", "activity_type", required=True,
              help="What happened, e.g. verdict_set, assigned, status_changed.")
@click.option("--message", required=True, help="Human-readable description of what happened.")
@click.option("--actor-type", "actor_type", type=click.Choice(["user", "agent", "system"]),
              default=None, help="Who acted (server default: system).")
@click.option("--extra-data", "extra_data", default=None,
              help='Structured detail as a JSON object, e.g. \'{"prior_verdict": "true_positive"}\'.')
@click.pass_context
def activities_create(ctx, alert_id, vulnerability_id, activity_type, message, actor_type,
                      extra_data):
    """Append one entry to an alert's or a vulnerability's timeline.

    Name at least one subject (--alert-id and/or --vulnerability-id). For a `user`
    activity the actor is YOU, taken from your login; it cannot be set to someone else.

    \b
    Examples:
      torana activities create --alert-id <ALERT_ID> --activity-type note --message "Checked with owner"
      torana activities create --vulnerability-id <VULN_ID> --activity-type verdict_set \\
        --message "False positive: test fixture" --actor-type user \\
        --extra-data '{"prior_verdict": "true_positive"}'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    if not alert_id and not vulnerability_id:
        raise click.UsageError("name a subject: --alert-id, --vulnerability-id, or both")
    body = {"activity_type": activity_type, "message": message}
    if alert_id:
        body["alert_id"] = alert_id
    if vulnerability_id:
        body["vulnerability_id"] = vulnerability_id
    if actor_type:
        body["actor_type"] = actor_type
    if extra_data:
        try:
            parsed = _json.loads(extra_data)
        except ValueError as e:
            raise click.BadParameter(f"not valid JSON: {e}", param_hint="--extra-data")
        if not isinstance(parsed, dict):
            raise click.BadParameter("must be a JSON object", param_hint="--extra-data")
        body["extra_data"] = parsed
    client = _client(ctx)
    try:
        data = client.post("activities", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields)


@alerts.command(name="breakdown")
@click.option("--workspace-id", default=None, help="Limit to one workspace.")
@click.option("--tenant-id", default=None, help="Cross-tenant callers only.")
@click.pass_context
def alerts_breakdown(ctx, workspace_id, tenant_id):
    """Counts over EVERY alert in scope, not just one page.

    \b
    The inbox's tab badges are folded from these rows, so this is the same
    arithmetic the UI shows — use it to check a badge that looks wrong.

    \b
    ⚠️ NOT `alerts count` (a flat total for a suite or rule) and NOT
    `alerts dispositions-summary` (the Advisor's per-rule, 14-day signal).
    This one groups the whole scope by the dimensions a verdict decision
    reads: verdict, status, assignee, and whether a playbook ran.

    \b
    Example:
      torana alerts breakdown --workspace-id <UUID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if workspace_id:
        params["workspace_id"] = workspace_id
    if tenant_id:
        params["tenant_id"] = tenant_id

    client = _client(ctx)
    try:
        data = client.get("api/v2/alerts/facet-counts", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, fields=fields)
        return

    rows = sorted(data.get("groups", []), key=lambda g: -g.get("count", 0))
    # ⛔ TWO POPULATIONS ON ONE SCREEN, SO BOTH ARE LABELLED. `total` is what the Inbox
    # can LIST (Needs attention plus Closed); the rows below are grouped over EVERY item
    # in scope, moved work included, so they sum HIGHER. Printing a bare "TOTAL" above
    # rows that add up to something larger invites the reader to conclude the table is
    # wrong, or the total is.
    _listed = int(data.get("total") or 0)
    _grouped = sum(int(g.get("count") or 0) for g in (data.get("groups") or []))
    click.echo(f"{_listed} listable item(s) in scope — Needs attention plus Closed.")
    if _grouped != _listed:
        click.echo(f"The {_grouped} grouped below include moved work, which the Inbox "
                   f"lists only under All.")
    click.echo("")
    hdr = f"{'VERDICT':<15} {'STATUS':<20} {'ASSIGNEE':<12} {'MINE':<5} {'PLAYBOOK':<9} {'COUNT':>6}"
    click.echo(hdr)
    click.echo("-" * len(hdr))
    for g in rows:
        click.echo(
            f"{str(g.get('triage_verdict') or '-'):<15} "
            f"{str(g.get('status') or '-'):<20} "
            f"{str(g.get('assignee_type') or '-'):<12} "
            f"{('yes' if g.get('assigned_to_me') else '-'):<5} "
            f"{str(g.get('latest_routing_outcome') or '-'):<9} "
            f"{g.get('count', 0):>6}"
        )


@alerts.command(name="dispositions-summary")
@click.option("--workspace-id", default=None, help="Filter by workspace UUID (Signal B).")
@click.pass_context
def alerts_dispositions_summary(ctx, workspace_id):
    """Get alert disposition summary for a workspace.

    \b
    Example:
      torana alerts dispositions-summary --workspace-id <UUID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if workspace_id:
        params["workspace_id"] = workspace_id

    client = _client(ctx)
    try:
        data = client.get("alerts/dispositions/summary", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ──────────────────────────────────────────────────────────────────────────
# BACK-COMPAT — hidden aliases for the old `<noun>-by-<param>` names.
# ⏳ ONE RELEASE ONLY (decision D4). Delete this block next release.
# ──────────────────────────────────────────────────────────────────────────

_LEGACY_BY_PARAM_ALERTS = {
    "rule-by-rule-id": ("suite-rule", "get"),
}


@alerts.command(name="reason-codes")
@click.pass_context
def alerts_reason_codes(ctx):
    """The closed list of grounds a verdict may cite.

    `AGENT MAY CLOSE` marks the only grounds the triage agent may CLOSE a finding on.
    The rest are for confirming, for escalating, or for a person recording an accepted
    risk or a duplicate.

    \b
    Examples:
      torana alerts reason-codes
      torana alert <UUID> verdict --triage-verdict benign --reason-code package_not_shipped
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("alerts/verdict-reason-codes")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    rows = data.get("reason_codes", []) if isinstance(data, dict) else data
    for row in rows:
        if isinstance(row, dict):
            row["verdicts_text"] = ", ".join(row.get("verdicts", []))
            row["may_close"] = "yes" if row.get("agent_may_close") else ""
    cols = [("code", "CODE", 30), ("verdicts_text", "VERDICTS", 34),
            ("may_close", "AGENT MAY CLOSE", 16), ("label", "GROUND", 60)]
    output({"items": rows} if isinstance(data, dict) else rows,
           fmt=fmt, raw=raw, fields=fields, columns=cols)


def _register_legacy_alerts_by_param() -> None:
    """Old flat names, hidden so they cannot be discovered anew."""
    import copy
    for _old, (_sub, _verb) in _LEGACY_BY_PARAM_ALERTS.items():
        _grp = alerts.commands.get(_sub)
        if not isinstance(_grp, click.Group):
            continue
        _cmd = _grp.commands.get(_verb)
        if _cmd is None:
            continue
        # ⛔ Never let an alias overwrite a real group of the same name.
        if isinstance(alerts.commands.get(_old), click.Group):
            continue
        _alias = copy.copy(_cmd)
        _alias.name = _old
        _alias.hidden = True
        alerts.add_command(_alias)


_register_legacy_alerts_by_param()


@alerts.command(name="lifecycle-state")
@click.option("--workspace-id", required=True, help="The workspace whose Inbox to check.")
@click.pass_context
def alerts_lifecycle_state(ctx, workspace_id):
    """Is this Inbox in step with the data behind it?

    \b
    An EMPTY Inbox means one of two opposite things: there is nothing to do, or the last
    check of the data was refused and items that have ended are still listed. This is what
    tells them apart.

    \b
      off      no rule in this workspace has its lifecycle on
      current  every rule checked its data and was believed
      stale    a rule has not been checked recently
      refused  a rule's last check was refused — the reason is shown
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get("alerts/lifecycle-state",
                          params={"workspace_id": workspace_id})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt == "json":
        output(data, fmt=fmt, fields=fields)
        return
    click.echo(f"STATE  {data.get('state')}")
    rows = data.get("rules") or []
    if not rows:
        click.echo("No rule in this workspace has its lifecycle on.")
        return
    output({"items": rows}, fmt=fmt,
           fields=fields or "name,last_run_status,mode,last_observed_at,refusal_reason")


# ── SLA policy (S2-14) ─────────────────────────────────────────────────────────


def _print_sla_policy(ctx, data):
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    if fmt != "text":
        output(data, fmt=fmt, fields=fields)
        return
    defaults = data.get("defaults") or {}
    src = data.get("source")
    click.echo(f"SOURCE  {src}" + ("  (platform defaults; this tenant has not set its own)"
                                   if src == "default" else ""))
    for sev in ("critical", "high", "medium", "low"):
        hours = data.get(f"{sev}_hours")
        shown = f"{hours} h" if hours is not None else "no deadline"
        extra = "" if hours == defaults.get(sev) else f"  (default {defaults.get(sev)} h)"
        click.echo(f"{sev.upper():<9} {shown}{extra}")
    if data.get("updated_at"):
        click.echo(f"UPDATED  {data['updated_at']}")
    overrides = data.get("rule_overrides") or []
    if overrides:
        click.echo(f"\nRULE OVERRIDES ({len(overrides)}): these rules' alerts use their own hours")
        for o in overrides:
            click.echo(f"  {o.get('sla_hours'):>6} h  {o.get('name')}  ({o.get('rule_id')})")
    click.echo(data.get("note") or "")


@alerts.group(name="sla-policy")
@click.pass_context
def alerts_sla_policy(ctx):
    """How long this tenant gives itself to handle an alert, by severity.

    \b
    An alert's deadline (sla_due_at) is set when it is raised: raised + the hours for
    its severity. A rule's own override (torana rule <UUID> update --sla-hours N) wins
    over this table. When an alert's severity rises, the tightest deadline wins.
    Changing the policy affects NEW alerts only.

    \b
    Examples:
      torana alerts sla-policy get
      torana alerts sla-policy set --critical-hours 12 --high-hours 48
      torana alerts sla-policy set --reset
    """
    ctx.ensure_object(dict)


@alerts_sla_policy.command(name="get")
@click.pass_context
def alerts_sla_policy_get(ctx):
    """Show the SLA hours per severity and whether they are this tenant's own.

    \b
    Examples:
      torana alerts sla-policy get
      torana alerts sla-policy get --format json
    """
    client = _client(ctx)
    try:
        data = client.get("alerts/sla-policy")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    _print_sla_policy(ctx, data)


@alerts_sla_policy.command(name="set")
@click.option("--critical-hours", type=click.IntRange(1, 87600), default=None)
@click.option("--high-hours", type=click.IntRange(1, 87600), default=None)
@click.option("--medium-hours", type=click.IntRange(1, 87600), default=None)
@click.option("--low-hours", type=click.IntRange(1, 87600), default=None)
@click.option("--reset", is_flag=True,
              help="Drop this tenant's policy and go back to the platform defaults.")
@click.pass_context
def alerts_sla_policy_set(ctx, critical_hours, high_hours, medium_hours, low_hours, reset):
    """Change the SLA hours for one or more severities (tenant admin).

    \b
    Severities you leave out keep their current hours. Existing alerts keep their
    deadlines; only alerts raised from now on use the new hours.

    \b
    Examples:
      torana alerts sla-policy set --critical-hours 12
      torana alerts sla-policy set --high-hours 48 --medium-hours 120
      torana alerts sla-policy set --reset
    """
    body = {k: v for k, v in (("critical_hours", critical_hours), ("high_hours", high_hours),
                              ("medium_hours", medium_hours), ("low_hours", low_hours))
            if v is not None}
    if reset and body:
        raise click.UsageError("--reset cannot be combined with hour options.")
    if not reset and not body:
        raise click.UsageError("Give at least one --<severity>-hours option, or --reset.")
    if reset:
        body = {"reset": True}
    client = _client(ctx)
    try:
        data = client.put("alerts/sla-policy", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    for k, v in body.items():
        if k != "reset" and data.get(k) != v:
            click.echo(f"ERROR: {k} was NOT applied — requested {v}, still {data.get(k)}",
                       err=True)
            sys.exit(1)
    _print_sla_policy(ctx, data)
