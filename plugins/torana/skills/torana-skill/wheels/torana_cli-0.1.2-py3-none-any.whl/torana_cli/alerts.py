"""torana alerts — alert management commands."""

import functools
import json as _json
import sys

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW, CollectionGroup
from torana_cli.output import output
from torana_cli.severity_words import severity_word
from torana_cli.fix_plan_words import fix_plan_short
from torana_cli.team_words import team_cell
from torana_cli.section_descriptions import all_reasons_option, with_sections_help
from torana_cli.rules import _load_input_file

def entries_option(help_text):
    """`--entries` (the Inbox's own word for what these commands list: entries, which are roots and ungrouped items), with the older
    spelling `--inbox-rows` still accepted but hidden. Both set the function's `inbox_rows`."""
    def deco(f):
        @functools.wraps(f)
        def wrapper(*a, entries=False, inbox_rows_alias=False, **kw):
            kw["inbox_rows"] = bool(entries or inbox_rows_alias)
            return f(*a, **kw)
        wrapper = click.option("--inbox-rows", "inbox_rows_alias", is_flag=True, default=False, hidden=True)(wrapper)
        return click.option("--entries", "entries", is_flag=True, default=False, help=help_text)(wrapper)
    return deco


_LIST_COLS = [
    ("id", "ID", 36),
    # An entry's NAME is the instruction ("Upgrade <package> to <version>"): never cut it.
    # At 30 the version to deploy and long package names were lost (measured: 12 of 62 overdue entries, longest 92).
    ("name", "NAME", 100),
    # The FINDING's severity (what the Inbox shows), not the rule's constant; see `_severity_shown`.
    ("severity_shown", "SEVERITY", 12),
    # The list is ORDERED by priority (lower is sooner), so the column that decides the
    # order has to be visible — otherwise the order looks arbitrary.
    ("triage_priority", "PRIO", 6),
    ("status", "STATUS", 22),
    # The server's SLA state (breached | due soon | on track); "—" when the item has no deadline or is closed.
    ("sla_label", "SLA", 9),
    # Who owns the fix: the distinct teams of the entry's open members (the platform's `owning_teams`).
    ("team_label", "TEAM", 30),
    ("fired", "FIRED", 16),
    # The newest meaningful change (not a rule pass that only re-saw it): what --sort newest|oldest orders by.
    ("last_activity_label", "LAST ACTIVITY", 16),
    ("assignee", "ASSIGNED TO", 24),
    # The rule's NAME (the API's `rule_name`); the raw id shows only with --wide, or in --json.
    ("rule_label", "RULE", 30),
    ("triage_verdict", "VERDICT", 22),
    # T-3 — whether the LAST triage attempt failed. Without it an alert whose triage
    # crashed reads exactly like one never triaged (verdict "—", triage_running False).
    ("triage", "TRIAGE", 18),
    # F-o01-2 — whether the deployment this TRUE POSITIVE relied on is still running.
    # ⛔ The verdict itself is unchanged; this column reports an observation, never a
    # re-decision. "—" covers both "still running" and "no record", which is why the
    # stale case spells itself out rather than relying on the column being non-empty.
    ("runtime", "RUNTIME", 22),
    ("reason_code", "REASON", 24),
    ("decided_by", "DECIDED BY", 14),
    # § 5.26 — what KIND of entry this is, in the rule's own words. Shown rather than
    # only filterable, because `--category posture` returning 139 rows is unreadable if
    # the rows do not say which of them are posture.
    ("category", "CATEGORY", 14),
    # How many findings a root clears (empty for a non-root and for a root that declares no
    # count: never "0").
    ("clears", "CLEARS", 7),
    # Phase 3 — which Inbox box the item is in, and who closed it. Both come from the
    # API; the CLI never works out a box itself.
    ("box", "BOX", 16),
    ("why_label", "WHY", 22),
    ("closed_by", "CLOSED BY", 24),
    # WHEN it closed (the API's `closed_at`), beside who closed it. Without it the only recent date on a closed row is
    # LAST ACTIVITY, which a rescan moves, and a scan time reads as a closure time (CB-59).
    ("closed_on", "CLOSED ON", 10),
]


def _assignee_label(item, name_cache=None):
    """Human label for who an alert is assigned to.

    Resolution order: stored display name → resolved name from name_cache →
    '<type>:<short-id>' fallback (e.g. 'agent:be2f5d91…'). '—' when unassigned.
    `name_cache` maps assigned_to UUID → resolved name (or None if lookup failed).
    """
    name = item.get("assignee_display_name")
    if name:
        return str(name)
    who = item.get("assigned_to")
    if not who:
        return "—"
    if name_cache and name_cache.get(who):
        return name_cache[who]
    kind = item.get("assignee_type") or "?"
    if kind == "team":
        return f"team {who}"                     # I-31: a team name, never an id to shorten
    return f"{kind}:{str(who)[:8]}…"


def _decider_label(item, name_cache=None):
    """Who reached this verdict, in one short column.

    The three deciders are deliberately distinguishable: a RULE stamped it from the
    ranking, the triage AGENT judged it, or a PERSON did. Before this the record could
    not tell them apart — the agent's service login made its verdicts read as an
    anonymous user's.
    """
    # The platform states the source itself (`verdict_source_label`); the derivation below is the fallback for a
    # server that does not.
    if item.get("verdict_source_label"):
        return item["verdict_source_label"]
    kind = (item.get("verdict_actor_type") or "").lower()
    who = item.get("verdict_actor_id") or ""
    if not kind:
        return ""
    if kind == "system":
        return "Ranking rules" if who.startswith("rule:") else "Platform"
    if kind == "agent":
        name = (name_cache or {}).get(("agent", who))
        return name or "Triage agent"
    name = (name_cache or {}).get(("user", who))
    return name or (who[:8] if who else "A person")


def _resolve_assignee_names(client, items):
    """Resolve assignee UUIDs → human names for a page of alerts.

    Dedups by (type, id) so each distinct assignee costs at most one lookup:
    users via GET users/{id} (name|email), agents via GET agents/{id} (name).
    Failures are cached as None so the caller falls back to the UUID label and
    we never retry a bad id. Returns {assigned_to_uuid: name|None}.
    """
    cache = {}
    seen = set()
    for it in items:
        if not isinstance(it, dict):
            continue
        who = it.get("assigned_to")
        kind = (it.get("assignee_type") or "").lower()
        if not who or it.get("assignee_display_name"):
            continue
        key = (kind, who)
        if key in seen:
            continue
        seen.add(key)
        try:
            if kind == "user":
                row = client.get(f"users/{who}")
                cache[who] = row.get("display_name") or row.get("name") or row.get("email")
            elif kind == "agent":
                row = client.get(f"agents/{who}")
                cache[who] = row.get("name")
            else:
                cache[who] = None
        except (APIError, AuthError):
            cache[who] = None  # degrade to UUID label; don't fail the list
    return cache


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)




def _as_json_value(raw, flag, expect):
    """Parse a JSON-typed CLI flag into the structure the API requires.

    These fields are list/object-typed server-side, so forwarding the raw string
    422s with "Input should be a valid list". Accepts JSON; for `list` also
    accepts a comma-separated string of scalars (the natural form for --tags).
    """
    if raw is None:
        return None
    text = str(raw).strip()
    if not text:
        return [] if expect == "list" else {}
    if text.startswith(("[", "{")):
        try:
            parsed = _json.loads(text)
        except ValueError as e:
            click.echo(f"ERROR: {flag} is not valid JSON: {e}", err=True)
            sys.exit(2)
    elif expect == "list":
        # Convenience for scalar lists like --tags a,b,c.
        parsed = [p.strip() for p in text.split(",") if p.strip()]
    else:
        click.echo(f"ERROR: {flag} must be a JSON object, e.g. '{{\"k\": \"v\"}}'.", err=True)
        sys.exit(2)

    if expect == "list" and not isinstance(parsed, list):
        click.echo(f"ERROR: {flag} must be a JSON array.", err=True)
        sys.exit(2)
    if expect == "object" and not isinstance(parsed, dict):
        click.echo(f"ERROR: {flag} must be a JSON object.", err=True)
        sys.exit(2)
    return parsed


@click.group(cls=CollectionGroup, singular="alert")
def alerts():
    """The Inbox: the items that need a decision, and the CVEs and CWEs behind them.

    \b
    Start here:
      Work through the Inbox          torana alerts list --box needs_attention
      How many items in each box      torana alerts boxes
      Read one item, section by section   torana alert <UUID> view
      One CVE or CWE across the app   torana alerts cve <CVE-ID> --workspace-id <WS>
                                      torana alerts cwe <CWE-ID> --workspace-id <WS>
      Is the Inbox current            torana alerts lifecycle-state --workspace-id <WS>

    \b
    Examples:
      torana alerts list --box needs_attention --workspace-id <WS_UUID>
      torana alerts boxes --workspace-id <WS_UUID>
      torana alerts cve CVE-2026-33845 --workspace-id <WS_UUID> --section how-to-fix

    \b
    --section keys, by the name the screen gives the section (a dash means that command has no such section):
      Screen label          torana alert <UUID> view    torana alerts cve   torana alerts cwe
      About                 about                       about               about
      Exposure path         exposure-path               -                   -
      Where it's found      -                           where-found         where-found
      Location              -                           -                   location
      Blast radius          -                           blast-radius        -
      Verdict               verdict                     verdict             verdict
      Where it comes from   provenance                  -                   -
      Code reachability     reachability                -                   -
      How to fix            how-to-fix                  how-to-fix          -
      Fix PR CI             fix-pr-ci                   -                   -
      What this fix clears  clears (an entry)           -                   -
      Affected items        affected (a situation)      -                   -
      Reported by           reported-by                 reported-by         reported-by
      Why it's here         why-here                    -                   -
      History               history                     history             -
      Related               -                           -                   related
    A key the command does not have is refused with exit 2 and the valid list. --section is repeatable.

    Instance operations (read one item, set a verdict, assign, close) use the singular form, `torana alert <UUID> ...`.
    Commands for operators still run but are not listed; see "Operator commands" in
    `skills/torana-skill/references/detection.md`.
    """


def _full_workspace_id(workspace_id):
    """A workspace filter must be the full UUID. A prefix is compared as text and matches no row, so
    the list said "No results" for a workspace that has 151 (harness F2). Refuse it instead."""
    if workspace_id:
        import uuid as _uuid
        try:
            _uuid.UUID(str(workspace_id))
        except ValueError:
            raise click.UsageError(
                f"--workspace-id must be the full workspace id (a UUID), not {workspace_id!r}: a "
                "prefix matches nothing. Find it with `torana workspaces list`.")
    return workspace_id


#: The friendly action verbs → the `category_key` an entry carries for it (the platform's
#: remediation categories, GET /alerts/remediation-vocabulary `categories`).
ACTION_CATEGORY = {
    "upgrade": "upgrade", "roll_back": "roll_back", "mitigate": "mitigation",
    "mitigation": "mitigation", "fix": "fix_code", "fix_code": "fix_code",
    "configure": "configure", "rotate": "rotate_secret", "rotate_secret": "rotate_secret",
    "rebuild": "rebuild_image", "rebuild_image": "rebuild_image",
    "review": "review", "finding": "review",
}


class CommaChoice(click.ParamType):
    """A comma-separated list in which EVERY value must be one of `choices` (case-insensitive; `-` reads as `_`).

    ⛔ A mistyped filter used to print "No results." and exit 0, so a typo read as "you have no findings" (CB-28b). The server now answers
    422 and names the valid values; this refuses the same typo before the call, in the same words, for the sets the platform fixes.
    Returns the normalised comma-joined text, so the code that builds the filter is unchanged."""
    name = "choice list"

    def __init__(self, choices):
        self.choices = list(choices)

    def convert(self, value, param, ctx):
        out = []
        for raw in str(value).split(","):
            raw = raw.strip()
            if not raw:
                continue
            key = raw.lower().replace("-", "_")
            if key not in self.choices:
                self.fail(f"{raw!r} is not one of {', '.join(repr(c) for c in self.choices)}.", param, ctx)
            out.append(key)
        if not out:
            self.fail(f"give at least one of {', '.join(repr(c) for c in self.choices)}.", param, ctx)
        return ",".join(out)


#: The platform's fixed vocabularies for the `alerts list` filters (the server refuses anything else with a 422 that names them; its lists are
#: `ActorType`, `WHY_SQL`, `TriageVerdict`, `sla_state.STATES` and `ACTION_CATEGORY`'s verbs). `--reason` and `--category` are not repeated here:
#: the reasons grow with the lifecycle and the categories are declared by rules, so the server's refusal is their one list.
DECIDED_BY_CHOICES = ("system", "agent", "user")
WHY_CHOICES = ("fixed", "accepted_risk", "wont_fix", "duplicate", "false_positive", "benign", "closed", "moved")
VERDICT_CHOICES = ("true_positive", "false_positive", "benign", "inconclusive")
SLA_STATE_CHOICES = ("on_track", "due_soon", "breached", "none")
ACTION_CHOICES = tuple(sorted(ACTION_CATEGORY))


def _uuid_rule_id(rule_id):
    """`--rule-id` must be a rule's full id. Anything else matches no row, which read as "this rule raised nothing"."""
    if rule_id:
        import uuid as _uuid
        try:
            _uuid.UUID(str(rule_id))
        except ValueError:
            raise click.UsageError(f"--rule-id must be a rule id (a UUID), not {rule_id!r}. Find it with `torana rules list`.")
    return rule_id


def action_category_filter(action: str) -> dict:
    """The v2 filter for `--action` (comma-separated verbs); an unknown verb is passed through as a
    category key, so a kind the platform adds later still works."""
    raw = [v.strip().lower().replace("-", "_") for v in str(action).split(",") if v.strip()]
    vals = [ACTION_CATEGORY.get(v, v) for v in raw]
    return ({"operation": "in_list", "value": vals} if len(vals) > 1
            else {"operation": "equals", "value": vals[0]})


def _triage_label(tf):
    """The TRIAGE column: '—' unless the last triage attempt failed (API `triage_failure`)."""
    if not isinstance(tf, dict) or not tf.get("state"):
        return "—"
    tries = f"{tf.get('attempts')}/{tf.get('max_attempts')}"
    if tf["state"] == "failed":
        return f"FAILED {tries} ({tf.get('error_kind') or '?'})"
    return f"retrying {tries}"


_SORTS = {"newest": [{"field": "last_activity", "direction": "desc"}],
          "oldest": [{"field": "last_activity", "direction": "asc"}],
          "priority": [{"field": "triage_priority", "direction": "asc"}]}


def window_options(fn):
    """--since / --from / --to / --cve / --cwe / --where / --search: the scope options `alerts list` and `alerts boxes` share, so a count and
    its list ask the same question."""
    for opt in reversed([
        click.option("--since", "since", default=None,
                     type=click.Choice(["24h", "2d", "7d", "30d"], case_sensitive=False),
                     help="Only items with activity in the last 24h, 2d, 7d or 30d."),
        click.option("--from", "date_from", default=None, metavar="ISO",
                     help="Only items with last activity at or after this ISO 8601 time, e.g. 2026-10-01T08:00:00Z."),
        click.option("--to", "date_to", default=None, metavar="ISO",
                     help="Only items with last activity at or before this ISO 8601 time."),
        click.option("--cve", "cve", default=None, metavar="CVE-ID",
                     help="Only the entries holding a live finding for this CVE (and ungrouped findings for it)."),
        click.option("--cwe", "cwe", default=None, metavar="CWE-ID",
                     help="Only the entries holding a live finding with this CWE (the finding's own CWE)."),
        click.option("--where", "where", default=None, metavar="TEXT",
                     help="Only items matching this condition over the item's columns (see `torana datalake "
                          "schema-ddl --tables inbox_items`) or, with the `app.` prefix, the app's facts about the "
                          "finding. An item whose app relation lacks a column the condition names cannot match. "
                          "Findings only: add NOT is_platform_entry. Example: \"verdict IS NULL AND app.<fact> = true "
                          "AND raised_at > now() - interval '7 days'\"."),
        click.option("--search", "search", default=None, metavar="TEXT",
                     help="Free-text search, the Inbox's search box: every word must appear in the entry (title, "
                          "matched row, summaries, finding key) OR in a finding grouped inside it. "
                          "'\"quoted phrase\"' is one term; -word excludes. Case-insensitive."),
    ]):
        fn = opt(fn)
    return fn


def box_option(fn):
    """--box, defined ONCE for `alerts list` and `workspace <id> alerts list` so the two cannot drift.

    The API folds the stored `moved` box into `closed` (T1-10: customers see no Moved box). It still
    accepts box=moved from old callers and treats it as closed, so offering it here would only mislead.
    """
    return click.option("--box", "boxes", multiple=True,
                        type=click.Choice(["needs_attention", "closed"], case_sensitive=False),
                        help="Inbox box, repeatable: needs_attention, closed. Omitted means All. The box "
                             "is worked out by the platform, the same answer the Inbox shows. There is no "
                             "moved box: work that moved to another entry is in closed; list it with "
                             "--why moved.")(fn)


def time_options(fn):
    """--sort plus the window options, shared by `alerts list` and `workspace <id> alerts list`."""
    fn = window_options(fn)
    return click.option("--sort", "sort_by", default=None,
                        type=click.Choice(list(_SORTS), case_sensitive=False),
                        help="Order: newest or oldest LAST ACTIVITY (the newest meaningful change: a decision, "
                             "assignment, state change, member joined or left, comment or changed facts; a rule "
                             "pass that only re-saw the item is not one), or priority. Omitted: the Inbox's order.")(fn)


def _time_params(sort_by, since, date_from, date_to, cve=None, cwe=None, where=None, search=None):
    """The API's sort and time-window parameters; refuses the combinations the API would merge silently."""
    import json as _json
    if since and date_from:
        raise click.UsageError("--since and --from both set the start of the window: use one.")
    out = {}
    if sort_by:
        out["sort"] = _json.dumps(_SORTS[sort_by.lower()])
    if since:
        out["activity_within"] = since.lower()
    if date_from:
        out["activity_from"] = date_from
    if date_to:
        out["activity_to"] = date_to
    if cve:
        out["cve"] = cve.strip().upper()
    if cwe:
        out["cwe"] = cwe.strip().upper()
    if where:
        out["where"] = where
    if search and search.strip():
        out["q"] = search.strip()
    return out


def _matched_label(m):
    """One line saying where a row matched the search: '13 of 222 findings: CVE-… on <host>', 'title', or
    'package_name: <name>'. Empty when the list was not searched."""
    if not isinstance(m, dict) or not m.get("where"):
        return ""
    where, snip = m["where"], (m.get("snippet") or "").replace("\n", " ")
    if where == "findings":
        return f"{m.get('findings_matched')} of {m.get('findings_total')} findings: {snip}"
    if where == "title":
        return "title"
    return f"{m.get('field') or where}: {snip}"


def _refuse_unfiltered(result, where, search):
    """The server echoes the filters it applied (`applied_filters`). An older server ignores `where` / `search`, and
    its list would read as filtered when it is not: so when a filter was asked for and the echo is missing or
    differs, print nothing and exit 1."""
    if not (where or search):
        return
    echo = (result or {}).get("applied_filters") if isinstance(result, dict) else None
    if isinstance(echo, dict) and echo.get("where") == (where or None) and echo.get("q") == ((search or "").strip() or None):
        return
    click.echo("This server does not support --where/--search; the list was not filtered.", err=True)
    sys.exit(1)


overdue_option = click.option(
    "--overdue", "overdue", is_flag=True, default=False,
    help="Only items whose SLA deadline has passed (SLA = breached): open items with a deadline in the past. The platform decides this, "
         "so no date is compared here. Closed items and items with no deadline are never overdue.")

team_option = click.option(
    "--team", "team", default=None,
    help="Only items a team owns: an entry with an open member owned by this team (the owner column its rule declares), case-insensitive. "
         "Comma-separated for several. `none` keeps items with a member that has no team recorded.")

sla_state_option = click.option(
    "--sla-state", "sla_state", default=None, type=CommaChoice(SLA_STATE_CHOICES),
    help="Only items in this deadline state: on_track, due_soon, breached or none (no deadline, or closed). Comma-separated for several. "
         "The platform decides the state, so no date is compared here; --overdue is the shortcut for breached.")

#: The list column and the header word for each server-decided `sla_state` (the CLI never compares dates itself).
SLA_WORDS = {"breached": "breached", "due_soon": "due soon", "on_track": "on track"}


def list_alerts_core(ctx, *, severity=None, state=None, status_filter=None, rule_id=None,
                     workspace_id=None, assigned_to=None, page=None, page_size=None,
                     limit=None, offset=None, fetch_all=False, resolve_names=True,
                     group_role=None, decided_by=None, finding_severity=None, action=None,
                     category=None, boxes=None, why=None, verdict=None, inbox_rows=False,
                     include_members=False, reason=None,
                     runtime_stale=False, triage_failure=None, wide=False, facts_changed=False, overdue=False, sla_state=None, team=None,
                     sort_by=None, since=None, date_from=None, date_to=None, cve=None, cwe=None,
                     where=None, search=None, tenant_id=None):
    """Shared alert-listing routine.

    Backs both `torana alerts list` (no workspace context) and
    `torana workspace <id> alerts list` (workspace_id pre-bound). Both forms are
    the same operation differing only by whether the workspace filter is set, so
    they MUST go through this one routine — never a parallel list path.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    # Accept both pagination conventions: --page/--page-size (native) and
    # --limit/--offset (alias). resolve_page() collapses them to (page, page_size).
    from torana_cli.pagination import resolve_page
    page, effective_page_size = resolve_page(
        page, page_size, limit, offset, default_page_size=settings.page_size
    )

    # The v2 alerts endpoint takes filters as a JSON `filters` query string
    # ({"field":{"operation":..,"value":..}}), NOT flat params like ?rule_id=X.
    # Flat params are silently ignored (this was the --rule-id bug). Build the
    # JSON filter map here. workspace_id/tenant_id ARE accepted as direct query
    # params by the endpoint, so workspace_id stays flat.
    import json as _json
    filters = {}
    # status (and the --state alias) accept a comma-separated list → in_list.
    status_val = status_filter or state
    if status_val:
        vals = [s.strip() for s in str(status_val).split(",") if s.strip()]
        filters["status"] = ({"operation": "in_list", "value": vals} if len(vals) > 1
                             else {"operation": "equals", "value": vals[0]})
    if severity:
        vals = [s.strip().lower() for s in str(severity).split(",") if s.strip()]
        if vals == ["none"]:
            # no severity is not a word the field holds: it is the field being null (the v2 filter's `is_null`)
            filters["level"] = {"operation": "is_null"}
        else:
            vals = ["no_priority" if v in ("no-priority", "no priority") else v for v in vals]
            filters["level"] = ({"operation": "in_list", "value": vals} if len(vals) > 1
                                   else {"operation": "equals", "value": vals[0]})
    # Fix-grain WP4 — one row per ACTION instead of one per finding. ⚠️ This goes through
    # the v2 `filters` map like every other filter here, which is why `group_role` had to
    # join v2's FIELDS: an unknown field there is a 400, not an ignored parameter.
    if group_role:
        filters["group_role"] = {"operation": "equals", "value": group_role}
    # `--entries` sends nothing: the list is entries only by default, which is exactly what
    # the Inbox lists, so there is no `top_level` filter to send (the platform is removing it).
    # WHO decided: 'system' (a rule declared it), 'agent' or 'user'. Comma-separated
    # becomes in_list, matching --status/--severity above.
    if decided_by:
        vals = [s.strip().lower() for s in str(decided_by).split(",") if s.strip()]
        filters["verdict_actor_type"] = (
            {"operation": "in_list", "value": vals} if len(vals) > 1
            else {"operation": "equals", "value": vals[0]})
    # A4 — the scanner's own word (capitalised, with Unknown). `--severity` filters the item's ONE severity (lower case).
    if finding_severity:
        vals = [s.strip().title() for s in str(finding_severity).split(",") if s.strip()]
        filters["finding_severity"] = (
            {"operation": "in_list", "value": vals} if len(vals) > 1
            else {"operation": "equals", "value": vals[0]})
    # A8 — the KIND of action, as the entry's `category_key`: that is where a platform entry holds
    # its action (its entity_type is the generic `inbox_entry`), and a rule-owned root carries the
    # same key beside its entity_type, so ONE filter on the key finds both.
    if action:
        if category:
            raise click.UsageError("--action and --category both filter the entry kind: "
                                   "use one (--action takes the friendly verbs).")
        filters["category_key"] = action_category_filter(action)
    # § 5.26 — the rule-declared entry kind. No verb map here, deliberately: `--action`
    # needs one because its three values are the platform's guess at one app's
    # vocabulary, and this is whatever the RULE declared, so translating it would put the
    # same words back in the platform.
    if category:
        vals = [s.strip().lower() for s in str(category).split(",") if s.strip()]
        filters["category_key"] = ({"operation": "in_list", "value": vals} if len(vals) > 1
                                   else {"operation": "equals", "value": vals[0]})
    # The box model — why it is closed, and the verdict. Together they list the signal
    # the platform counts: a true positive a person closed as false positive.
    # F-o01-2 — one boolean the API resolves, so the CLI, the inbox and the API ask the
    # SAME question rather than three spellings of it.
    if runtime_stale:
        filters["verdict_runtime_stale"] = {"operation": "equals", "value": True}
    if overdue:
        filters["sla_breached"] = {"operation": "equals", "value": True}
    # The deadline state, decided by the platform (`--overdue` is the shortcut for `breached`).
    if sla_state:
        if overdue and sla_state != "breached":
            raise click.UsageError("--overdue means --sla-state breached; give one of them, or --sla-state breached with it.")
        vals = [v for v in sla_state.split(",") if v]
        filters["sla_state"] = ({"operation": "in_list", "value": vals} if len(vals) > 1
                                else {"operation": "equals", "value": vals[0]})
    # Who owns the fix: the platform decides it from the entry's open members (the CLI sends the names, `none` for members without a team).
    if team:
        vals = [v.strip() for v in str(team).split(",") if v.strip()]
        filters["owning_team"] = ({"operation": "in_list", "value": vals} if len(vals) > 1
                                  else {"operation": "equals", "value": vals[0]})
    # A fact the verdict relied on changed and the item is not re-triaged yet (the platform sends the same boolean).
    if facts_changed:
        filters["facts_changed"] = {"operation": "equals", "value": True}
    # T-3 — the last triage attempt failed: `failed` (dead-lettered), `retrying`, or `any`.
    if triage_failure:
        vals = [s.strip().lower() for s in str(triage_failure).split(",") if s.strip()]
        if "any" in vals:
            filters["triage_failure"] = {"operation": "is_not_null", "value": None}
        else:
            filters["triage_failure"] = ({"operation": "in_list", "value": vals} if len(vals) > 1
                                         else {"operation": "equals", "value": vals[0]})
    for key, raw_val in (("why", why), ("triage_verdict", verdict),
                         ("resolution_reason", reason)):
        if raw_val:
            vals = [s.strip().lower() for s in str(raw_val).split(",") if s.strip()]
            filters[key] = ({"operation": "in_list", "value": vals} if len(vals) > 1
                            else {"operation": "equals", "value": vals[0]})
    if rule_id:
        filters["rule_id"] = {"operation": "equals", "value": _uuid_rule_id(rule_id)}
    if assigned_to:
        filters["assigned_to"] = {"operation": "equals", "value": assigned_to}

    params = {"page": page, "page_size": effective_page_size}
    if filters:
        params["filters"] = _json.dumps(filters)
    # Phase 3 — repeatable `box` query parameter; the API filters its stored column.
    if boxes:
        params["box"] = [b.lower() for b in boxes]
    if workspace_id:
        params["workspace_id"] = _full_workspace_id(workspace_id)
    if include_members:
        params["include_members"] = "true"
    if tenant_id:                                   # OI-133: SA only; the API refuses anyone else and audits the read
        params["tenant_id"] = tenant_id
    params.update(_time_params(sort_by, since, date_from, date_to, cve, cwe, where, search))

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            left_out = {}
            while True:
                p = {"page": page_num, "page_size": effective_page_size}
                p.update({k: v for k, v in params.items() if k not in ("page", "page_size")})
                data = client.get("api/v2/alerts", params=p)
                items = data.get("items", [])
                all_items.extend(items)
                if page_num == 1:           # what the list leaves out is the same on every page: say it once, from the first
                    left_out = {k: data[k] for k in ("members_not_included", "members_hint", "applied_filters") if k in data}
                    _refuse_unfiltered(data, where, search)
                if not items or len(all_items) >= data.get("total", len(all_items)):
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items), "page": 1,
                      "page_size": len(all_items), **left_out}
        else:
            result = client.get("api/v2/alerts", params=params)
            _refuse_unfiltered(result, where, search)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    items = result.get("items", [])

    # Resolve assignee UUIDs → names for the human-readable views only. The
    # extra lookups (deduped, one per distinct assignee) aren't worth it for
    # machine output, which keeps the raw assigned_to/assignee_type fields.
    name_cache = None
    if resolve_names and fmt in ("text", "table") and not raw:
        name_cache = _resolve_assignee_names(client, items)

    # Derive human "fired" and "assignee" columns, injected onto each item so
    # they render in text/table and are selectable via --fields; the raw
    # first_seen_at / assigned_to / assignee_type fields stay intact for JSON.
    from torana_cli.time_util import format_relative
    # CB-45: the "—" placeholder is for the text and table views. JSON (and --raw) carry null, never a dash, so a
    # script can tell "nothing" from a value.
    _dash = "—" if fmt in ("text", "table") and not raw else None
    for item in items:
        if isinstance(item, dict):
            item["rule_label"] = item.get("rule_name") or item.get("rule_id") or _dash
            item["fired"] = format_relative(item.get("first_seen_at") or item.get("created_at"))
            item["assignee"] = _assignee_label(item, name_cache)
            # WHO decided this verdict. The raw columns stay intact for JSON; this is the
            # human column, because "true_positive" without a decider is half the record.
            item["decided_by"] = _decider_label(item, name_cache)
            # § 5.26 — the LABEL for the column, the key for `--category`. Falling back
            # to the key keeps a row readable if a rule declared a key and an empty
            # label; falling back to the raw columns keeps JSON output unchanged.
            item["category"] = item.get("category_label") or item.get("category_key")
            # How many findings a root clears, from the platform's one number. EMPTY when the
            # rule declares no count (never "0": that would say the fix clears nothing).
            _fc = item.get("findings_cleared")
            item["clears"] = "" if _fc is None else str(_fc)
            item["severity_shown"] = (item.get("level_label") or (item.get("finding_severity_label") if _dash else None)
                                  or _severity_shown(item, _dash))
            item["sla_label"] = SLA_WORDS.get(item.get("sla_state") or "", _dash)
            item["team_label"] = team_cell(item, _dash)
            # Who closed it, as the API words it ("The agent", "The data", a person).
            item["closed_by"] = item.get("closed_by_display_name") or _dash
            item["closed_on"] = (item.get("closed_at") or "")[:10] or _dash
            # Why it is closed, as the API words it ("Closed: accepted risk").
            item["why_label"] = item.get("why_label") or _dash
            # F-o01-2 — read the API's DERIVED `verdict_runtime_stale`, never
            # `stale_at` directly: the derived one is already gated on the alert being
            # a true positive, so a stale flag left on a row whose verdict changed
            # cannot show here.
            _stale_since = (item.get("verdict_runtime_stale_at") or "")[:10]
            item["runtime"] = (f"stale since {_stale_since}"
                               if item.get("verdict_runtime_stale") else _dash)
            item["triage"] = _triage_label(item.get("triage_failure"))
            # An unjudged alert is the common case; render it as an em dash like the
            # assignee column rather than a column of the literal word "None".
            for _k in ("triage_verdict", "reason_code", "triage_priority", "category"):
                if _dash and item.get(_k) in (None, ""):
                    item[_k] = _dash
            if _dash:
                # The words come from ONE place, the platform (its labels use the screen's words). When it sends them,
                # print them; JSON keeps the raw codes and carries the labels as sent. Without them: the output above.
                # `verdict_label` is the screen's chip text: on a platform entry "True positive" or "True positive 120/131"
                # (null when undecided). Older servers send only `entry_verdict`: humanise that.
                _v = item.get("verdict_label")
                if _v:
                    item["triage_verdict"] = _v
                elif item.get("entry_verdict") and item.get("triage_verdict") in (None, "", _dash):
                    _ev = str(item["entry_verdict"])
                    item["triage_verdict"] = "Mixed" if _ev == "mixed" else _ev.replace("_", " ").capitalize()
                if item.get("status_label"):
                    item["status"] = item["status_label"]
            # Where the row matched --search (the API's `search_match`), the Inbox's "matched in …" line.
            item["matched"] = _matched_label(item.get("search_match"))
            # B11 — the fix plan's state and PR, short (the full line is in `alert <id> get`). Text only: JSON keeps
            # `fix_plan` exactly as the API sent it.
            if _dash:
                item["fix_label"] = fix_plan_short(item.get("fix_plan"), item.get("fix_status")) or _dash

    cols = list(_LIST_COLS)
    # OI-133: a super admin's list can hold several tenants' rows (no --tenant = every tenant). Name the tenant on
    # every row whenever any row is not the caller's own, so mixed rows are never read as one tenant's.
    if _rows_span_other_tenants(items, ctx):
        cols.insert(0, ("tenant_id", "TENANT", 36))
    if search and search.strip():
        cols.insert(2, ("matched", "MATCHED", 60))
    # B11 — a FIX column only when some row on the page has a fix plan, so a page without one reads as before.
    if any(isinstance(i, dict) and i.get("fix_plan") for i in items):
        at = next(i for i, c in enumerate(cols) if c[0] == "clears") + 1
        cols.insert(at, ("fix_label", "FIX", 32))
    if wide:
        at = next(i for i, c in enumerate(cols) if c[0] == "rule_label") + 1
        cols.insert(at, ("rule_id", "RULE ID", 36))
        # Who set the PRIO number, in the platform's own words (the API's `priority_source_label`): the ranking, the triage agent, a person or a
        # code measurement. Blank when the item has no priority.
        at = next(i for i, c in enumerate(cols) if c[0] == "triage_priority") + 1
        cols.insert(at, ("priority_source_label", "PRIORITY SET BY", 28))
    output(result, fmt=fmt, raw=raw, fields=fields, columns=cols, pagination_hint=False)
    if fmt in ("text", "table") and not raw:
        click.echo(_total_line(result, shown=len(items), include_members=include_members))


def _own_tenant_id(ctx):
    """The caller's tenant, from the access token's claims (unverified: display only). None when unknown."""
    import base64
    import json as _json
    from torana_cli.client.auth import get_access_token
    try:
        tok = get_access_token(profile=ctx.obj.get(CTX_PROFILE) if ctx.obj else None)
        part = tok.split(".")[1]
        part += "=" * (-len(part) % 4)
        return _json.loads(base64.urlsafe_b64decode(part)).get("tenant_id")
    except Exception:
        return None


def _rows_span_other_tenants(items, ctx) -> bool:
    tenants = {i.get("tenant_id") for i in items if isinstance(i, dict) and i.get("tenant_id")}
    if not tenants:
        return False
    if len(tenants) > 1:
        return True
    own = _own_tenant_id(ctx)
    return own is None or tenants != {str(own)}


def _total_line(result, *, shown, include_members=False):
    """The count under the table, from the platform's own numbers (CB-23, CB-27a): a reader never counts rows, and never mistakes the entries for
    every finding. `total` counts ENTRIES (and ungrouped items); the grouped findings the list leaves out come from `members_not_included`."""
    total = result.get("total")
    total = shown if not isinstance(total, int) or total < 0 else total
    noun = "item" if total == 1 else "items"
    line = f"{total} {noun}" if shown >= total else f"{total} {noun} ({shown} shown; --page/--limit or --all for the rest)"
    left = result.get("members_not_included") or 0
    if left and not include_members:
        line += (f", and {left} more {'finding' if left == 1 else 'findings'} grouped under entries; "
                 f"add --include-members to list them")
    return "\n" + line


@alerts.command(name="list")
@click.option("--severity", default=None,
              type=click.Choice(["low", "medium", "high", "critical", "info", "no_priority", "none"], case_sensitive=False),
              help="Filter by the level the SEVERITY column shows: the app's class (critical|high|medium|low) for an item a ranked app "
                   "governs, `no_priority` for one the app has not ranked yet, else the item's ONE severity (the finding's own, or the rule's "
                   "declared one for the rule's own condition). `none` keeps the items that have no level (an unrated finding the app does "
                   "not rank, or a rule that declares none). For the scanner's own word, with Unknown, use --finding-severity.")
@click.option("--state", default=None, help="Filter by state (e.g. open, closed, in_progress).")
@click.option("--rule-id", default=None, help="Filter by detection rule UUID.")
@click.option("--workspace-id", default=None, help="Filter by workspace UUID.")
@click.option("--assigned-to", default=None,
              help="Filter by assigned user — email address or user UUID — or team:<name> for the items an "
                   "owning team holds. An unrecognized user errors (422) rather than returning an empty list.")
@click.option("--status", "status_filter", default=None,
              help="Filter by status. Accepts comma-separated values, e.g. "
                   "'pending_remediation,escalated'. "
                   "Valid: open, triaging, awaiting_input, pending_remediation, "
                   "escalated, resolved, closed.")
@click.option("--page", default=None, type=int, help="Page number (1-indexed).")
@click.option("--page-size", default=None, type=int,
              help="Results per page (max 100). Alias of --limit.")
@click.option("--limit", default=None, type=int,
              help="Max results to return (alias of --page-size).")
@click.option("--offset", default=None, type=int,
              help="Results to skip (alias of (page-1)*page_size).")
@click.option("--roots-only", "roots_only", is_flag=True, default=False,
              help="Only the alerts that stand for an ACTION (one per fix), not the "
                   "findings they clear.")
@click.option("--decided-by", "decided_by", default=None, type=CommaChoice(DECIDED_BY_CHOICES),
              help="Who decided the verdict: system (a rule declared it), agent or "
                   "user. Comma-separated for several.")
@click.option("--finding-severity", "finding_severity", default=None,
              help="Severity of the matched FINDING (critical/high/medium/low). "
                   "Distinct from --severity, which is the RULE's and is one value "
                   "per rule. Comma-separated for several.")
@click.option("--action", "action", default=None, type=CommaChoice(ACTION_CHOICES),
              help="What KIND of action: upgrade, roll_back, mitigate, fix, configure, rotate, "
                   "rebuild or review (the platform's list: `torana alerts remediation-vocabulary`). "
                   "Comma-separated for several. ('mitigate' means no fix exists.)")
@click.option("--category", "category", default=None,
              help="The rule-declared entry kind, e.g. posture. Comma-separated for "
                   "several. This is the KEY, not the label on the chip: the key is "
                   "stable, the label is prose the rule may reword.")
@box_option
@click.option("--why", "why", default=None, type=CommaChoice(WHY_CHOICES),
              help="Why a closed item is closed: fixed, accepted_risk, wont_fix, "
                   "duplicate, false_positive, benign (a person's reason), closed, or "
                   "moved. Comma-separated for several.")
@click.option("--verdict", "verdict", default=None, type=CommaChoice(VERDICT_CHOICES),
              help="The verdict: true_positive, false_positive, benign, inconclusive. "
                   "Comma-separated for several.")
@click.option("--reason", "reason", default=None,
              help="The exact closing reason: a person's (fixed, accepted_risk, wont_fix, "
                   "duplicate, false_positive, benign) or the platform's (closed_at_source, "
                   "dismissed_at_source, no_longer_reported, no_longer_deployed, below_policy, "
                   "rerouted, ...). Comma-separated for several.")
@entries_option("The list shows ENTRIES (roots and ungrouped items) by default, exactly what the Inbox lists; this says so "
                "explicitly. Not the same as --roots-only, which is one row per fix.")
@click.option("--include-members", "include_members", is_flag=True, default=False,
              help="Also list the members that belong inside an entry (diagnostics). A member "
                   "is normally seen only through `torana alert <entry-id> members`.")
@click.option("--runtime-stale", "runtime_stale", is_flag=True, default=False,
              help="Only true positives whose relied-on deployment is no longer running "
                   "(verdict unchanged).")
@overdue_option
@sla_state_option
@team_option
@click.option("--facts-changed", "facts_changed", is_flag=True, default=False,
              help="Only items where a fact the verdict relied on has changed and the item is waiting to be "
                   "re-triaged (or a person has to decide, when a person chose its owner).")
@click.option("--triage-failure", "triage_failure", default=None,
              help="Only alerts whose LAST triage attempt failed: failed (dead-lettered, "
                   "will not retry on its own), retrying, or any. Comma-separated for "
                   "several.")
@click.option("--wide", "wide", is_flag=True, default=False,
              help="Also show the rule's id next to its name (--format json always carries both).")
@click.option("--all", "fetch_all", is_flag=True, default=False,
              help="Auto-paginate: fetch every PAGE of the list. It covers the ENTRIES (and ungrouped items) the filters match, which is what "
                   "the Inbox lists; the findings grouped inside entries are not part of it (add --include-members). The footer and "
                   "`members_not_included` in --format json say how many were left out.")
@time_options
@click.option("--tenant", "tenant_id", default=None, metavar="TENANT_ID",
              help="Super admin only: list THIS tenant's items. Without it a super admin sees every tenant's items, with a "
                   "TENANT column. Every cross-tenant list is recorded in the security audit log (`torana audit-logs`).")
@click.pass_context
def alerts_list(ctx, severity, state, status_filter, rule_id, workspace_id, assigned_to,
                page, page_size, limit, offset, roots_only, decided_by, finding_severity,
                action, category, boxes, why, verdict, reason, runtime_stale, overdue, sla_state, team, facts_changed, inbox_rows,
                include_members, triage_failure, wide, fetch_all, sort_by, since, date_from, date_to, cve, cwe, where, search,
                tenant_id):
    """List the Inbox's items (alerts), a page or all of them.

    Use this to see what needs attention: one row per item, in the order the Inbox shows them. To read one item
    use `torana alert <UUID> view`; to count items per box use `torana alerts boxes`; to see one CVE or CWE across
    the app use `torana alerts cve` / `alerts cwe`. Each filter narrows the list; `--format json` gives the full
    rows. An empty list can mean nothing needs doing or that the data check was refused: see `alerts lifecycle-state`.

    \b
    Examples:
      torana alerts list --severity critical
      torana alerts list --status pending_remediation,escalated --assigned-to me@acme.com
      torana alerts list --assigned-to team:backend-dev   # what an owning team holds (nobody notified)
      torana alerts list --format json | jq '.items[] | select(.severity == "critical")'
      torana alerts list --roots-only        # one row per FIX, not per finding
      torana alerts list --decided-by system # everything the ranking decided
      torana alerts list --decided-by agent,user
      torana alerts list --box closed                  # everything closed
      torana alerts list --box needs_attention --entries --all
                                                       # exactly the Inbox's rows (the entries; add --include-members for the
                                                       # findings grouped inside them: the footer says how many are left out)
      torana alerts list --sla-state due_soon,breached # what is close to, or past, its deadline
      torana alerts list --why false_positive --verdict true_positive
                                                       # true positives closed as FP
      torana alerts list --box closed --reason closed_at_source
                                                       # closed because the source fixed it
      torana alerts list --workspace-id <UUID> --triage-failure failed
                                                       # triage dead-lettered: needs a person
      torana alerts list --sort newest --since 2d      # what changed in the last two days, newest first
      torana alerts list --from 2026-10-01T00:00:00Z --to 2026-10-03T00:00:00Z --sort oldest
      torana alerts list --cve CVE-2026-33845          # the entries holding a live finding for that CVE
      TORANA_PROFILE=SA torana alerts list --tenant <TENANT_UUID> --box needs_attention
                                                       # one tenant's items, as a super admin (audited)
      torana alerts list --cwe CWE-89 --box needs_attention
      torana alerts list --workspace-id <UUID> --search pantheon-rag --box needs_attention
                                                       # entries whose title OR grouped findings mention it
      torana alerts list --search '"no fix available" -gnutls28' --all
                                                       # a phrase, minus a word
    """
    list_alerts_core(ctx, severity=severity, state=state, status_filter=status_filter,
                     rule_id=rule_id, workspace_id=workspace_id, assigned_to=assigned_to,
                     page=page, page_size=page_size, limit=limit, offset=offset,
                     fetch_all=fetch_all, decided_by=decided_by,
                     finding_severity=finding_severity, action=action, category=category,
                     boxes=boxes, why=why, verdict=verdict, inbox_rows=inbox_rows,
                     include_members=include_members, reason=reason,
                     runtime_stale=runtime_stale, overdue=overdue, sla_state=sla_state, team=team, facts_changed=facts_changed, triage_failure=triage_failure, wide=wide,
                     sort_by=sort_by, since=since, date_from=date_from, date_to=date_to, cve=cve, cwe=cwe, where=where, search=search,
                     group_role="root" if roots_only else None, tenant_id=tenant_id)


@alerts.command(name="labels")
@click.pass_context
def alerts_labels(ctx):
    """The words the Inbox uses for verdicts, statuses, severities and closed reasons — the same on the screen, the API and the CLI.

    Read-only. The platform holds one set of words; the screen, the API's `*_label` fields and this CLI all print them.
    Text shows one small table per map (the code the API stores, then the word). `--format json` is the raw export.

    \b
    Examples:
      torana alerts labels
      torana alerts labels --format json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get("api/v2/alerts/labels")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt != "text" or fields or not isinstance(data, dict):
        output(data, fmt=fmt, fields=fields)
        return
    for name, value in data.items():
        title = name.replace("_", " ")
        if isinstance(value, dict):
            click.echo(f"\n{title.upper()}")
            width = max([len(str(k)) for k in value] + [4])
            click.echo(f"  {'CODE':<{width}}  WORD")
            for code, word in value.items():
                click.echo(f"  {str(code):<{width}}  {word}")
        else:
            click.echo(f"\n{title}: {value}")


@alerts.command(name="boxes")
@click.option("--workspace-id", default=None, help="Count one workspace's items.")
@entries_option("The counts are over ENTRIES (roots and ungrouped items) by default, the rows `alerts list` shows; this says so "
                "explicitly.")
@click.option("--include-members", "include_members", is_flag=True, default=False,
              help="Count members too (diagnostics).")
# ⚠️ The old name, kept so existing scripts still count the same rows. On `alerts list`
# --roots-only means one row per FIX, a different population, hence the new name here.
@click.option("--roots-only", "roots_only", is_flag=True, default=False, hidden=True)
@window_options
@click.pass_context
def alerts_boxes(ctx, workspace_id, inbox_rows, include_members, roots_only, since, date_from, date_to, cve, cwe, where, search):
    """How many items are in each Inbox box (Needs attention, Closed, All), and the app's own population.

    Use this for the size of the work before listing it (`alerts list`); to read one item use `alert <UUID> view`.

    \b
    Examples:
      torana alerts boxes --workspace-id <WS_UUID>
      torana alerts boxes --workspace-id <WS_UUID> --format json

    The counts come from the platform (GET /api/v2/alerts/facet-counts), the same
    numbers the Inbox shows on its tabs. Work that moved to another entry is counted in Closed.

    \b
    ⛔ TWO DIFFERENT NUMBERS, AND THEY COUNT DIFFERENT THINGS:
      · `All` is the three boxes added up — how many ITEMS the Inbox holds for this scope.
      · the population line is the APP's own, when the app declared one: how many
        FINDINGS the app is about, counted in the datalake. It is not the sum of the
        boxes and must never be added to them.
    The population is counted after each rule run rather than on demand, so it carries
    when it was counted, and says so when a rule has run since.

    \b
    Examples:
      torana alerts boxes
      torana alerts boxes --workspace-id <UUID> --entries
      torana alerts boxes --cve CVE-2026-33845          # the counts for one CVE, the same entries `alerts list --cve` shows
      torana alerts boxes --since 2d                    # the counts for what changed in the last two days
      torana alerts boxes --workspace-id <UUID> --search litellm   # the tab counts for a search
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    params = {}
    if workspace_id:
        params["workspace_id"] = _full_workspace_id(workspace_id)
    if include_members:
        params["include_members"] = "true"
    params.update(_time_params(None, since, date_from, date_to, cve, cwe, where, search))
    client = _client(ctx)
    try:
        data = client.get("api/v2/alerts/facet-counts", params=params)
        _refuse_unfiltered(data, where, search)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    boxes = (data or {}).get("boxes") or {}
    signals = (data or {}).get("signals") or {}
    population = (data or {}).get("population") or None
    labels = {"needs_attention": "Needs attention", "closed": "Closed"}
    rows = [{"box": k, "label": labels[k], "count": int(boxes.get(k, 0))}
            for k in ("needs_attention", "closed")]
    fp_on_tp = int(signals.get("closed_false_positive_while_true_positive", 0))
    if fmt == "text" and not fields:
        for r in rows:
            click.echo(f"{r['label']:<18} {r['count']}")
        click.echo(f"{'Total (both boxes)':<18} {sum(r['count'] for r in rows)}")
        if population:
            # ⚠️ Printed on its own line, under the app's OWN word for a row, and never
            # folded into the table above: it counts findings in the datalake, while the
            # table counts items in the Inbox. Two numbers, two populations.
            n = population.get("count")
            label = (population.get("label_singular") if n == 1
                     else population.get("label")) or "items"
            when = str(population.get("counted_at") or "")[:16].replace("T", " ")
            note = f"as of {when}" if when else "time not recorded"
            if population.get("stale"):
                # A rule has run since the count, so the estate may have moved. Said
                # plainly rather than hidden — the number is still the best one we have.
                note += "; a rule has run since, so this may be behind"
            click.echo("")
            click.echo(f"The app counts {n:,} {label} ({note})")
        click.echo("")
        click.echo(f"Closed as false positive while true positive: {fp_on_tp}")
        # T-3 — open items whose last triage attempt failed. `failed` will not retry on
        # its own and needs a person; `retrying` is the platform still at it.
        click.echo(f"Triage failed (will not retry): {int(signals.get('triage_failed', 0))}"
                   f"   ·   retrying: {int(signals.get('triage_retrying', 0))}")
        return
    # ⛔ `len(rows)` WAS 3 — the number of BOXES, printed under a key every other
    # command uses for a number of items. A script reading `total` got 3 beside an `All`
    # of 11. The total is the items the Inbox can LIST, which is what the platform now
    # returns; the moved count stays visible in `items`.
    output({"items": rows, "total": int((data or {}).get("total") or 0),
            "boxes_shown": len(rows), "signals": signals,
            "population": population}, fmt=fmt, fields=fields)


@alerts.command(name="reconcile-owners")
@click.option("--tenant", "tenant_id", default=None,
              help="Operator (super admin profile) only: repair this tenant instead of your own.")
@click.option("--workspace-id", default=None, help="Repair one workspace's items only.")
@click.option("--apply", "apply_changes", is_flag=True, default=False,
              help="Make the changes. Without it this is a DRY RUN that only counts.")
@click.pass_context
def alerts_reconcile_owners(ctx, tenant_id, workspace_id, apply_changes):
    """Repair who owns items, through the platform: a dry run unless --apply.

    Confirmed items (and open status summaries) that nobody useful holds go to the tenant
    admin. Items that are not confirmed but hold an assignee that is not a person (free
    text such as "classie", an address from another tenant) go back to the triage agent
    when they are undecided and routed to triage, otherwise they are unassigned. Each
    change writes an activity saying why. A person's own assignment is never replaced.

    \b
    Examples:
      torana alerts reconcile-owners
      torana alerts reconcile-owners --workspace-id <UUID> --apply
      TORANA_PROFILE=SA torana --act-as-tenant <tenant UUID> --act-as-reason "<why>" alerts reconcile-owners --tenant <tenant UUID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    body = {"dry_run": not apply_changes}
    if tenant_id:
        body["tenant_id"] = tenant_id
    if workspace_id:
        body["workspace_id"] = _full_workspace_id(workspace_id)
    client = _client(ctx)
    try:
        data = client.post("api/v1/alerts/reconcile-owners", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields)


def _severity_shown(item, dash="—"):
    """The level the Inbox shows for an item: the app's class when it ranks it (`level_label`), else the FINDING's severity. The alert's own `severity` is the declaring rule's constant ("medium"
    on every item of a rule), so for a finding or an entry that states no severity the column says so rather than showing the rule's."""
    # The platform's own answer wins: the item's ONE severity in words (the finding's, or for a rule's own condition the rule's declared one),
    # or why there is none ("Not recorded" / "Not declared").
    sent = str(item.get("level_label") or item.get("entry_severity_label") or "").strip()
    if sent:
        return sent
    finding = str(item.get("finding_severity") or "").strip()
    if finding:
        return severity_word(finding)
    key = str(item.get("finding_key") or "")
    if key.startswith(("finding:", "entry:")):
        return dash
    return severity_word(item.get("severity")) or dash


def reconcile_sla_body(tenant_id, workspace_id, apply_changes) -> dict:
    """The request body of `alerts reconcile-sla` (a dry run unless applied)."""
    body = {"dry_run": not apply_changes}
    if tenant_id:
        body["tenant_id"] = tenant_id
    if workspace_id:
        body["workspace_id"] = _full_workspace_id(workspace_id)
    return body


@alerts.command(name="reconcile-sla")
@click.option("--tenant", "tenant_id", default=None,
              help="Operator (super admin profile) only: repair this tenant instead of your own.")
@click.option("--workspace-id", default=None, help="Repair one workspace's items only.")
@click.option("--apply", "apply_changes", is_flag=True, default=False,
              help="Make the changes. Without it this is a DRY RUN that only counts.")
@click.pass_context
def alerts_reconcile_sla(ctx, tenant_id, workspace_id, apply_changes):
    """Bring every open item's SLA deadline to what the rules now say: a dry run unless --apply.

    A deadline is corrected when a signal for its item is processed or an entry's member
    changes, and an unchanged row sends no signal, so items that predate a rule change would
    never heal. This pass heals them. An item has ONE severity: its finding's for an item
    about a finding, its rule's declared severity for an item about the rule's own condition
    (a situation entry's members). An open item with no deadline gets its raised time plus
    the hours for that severity (it may already be past: it is overdue). An item with no
    severity (an unrated finding, or a rule that declares none) has no deadline, and one it
    already holds is cleared. A stored deadline is never moved here: it tightens when a
    signal brings a higher rating, and a reopened or already-corrected deadline is left
    alone. Each open entry then takes the earliest deadline of its open members. A second run
    changes nothing. The output counts each kind (born with a deadline, unrated and cleared)
    and samples up to 20 changes.

    \b
    Examples:
      torana alerts reconcile-sla
      torana alerts reconcile-sla --workspace-id <UUID> --apply
      TORANA_PROFILE=SA torana --act-as-tenant <tenant UUID> --act-as-reason "<why>" alerts reconcile-sla --tenant <tenant UUID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    body = reconcile_sla_body(tenant_id, workspace_id, apply_changes)
    client = _client(ctx)
    try:
        data = client.post("api/v1/alerts/reconcile-sla", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields)


@alerts.command(name="correct", hidden=True)
@click.argument("correction", metavar="CORRECTION")
@click.option("--tenant", "tenant_id", default=None,
              help="Operator (super admin profile) only: correct this tenant instead of your own.")
@click.option("--workspace-id", default=None, help="Correct one workspace's items only.")
@click.option("--apply", "apply_changes", is_flag=True, default=False,
              help="Make the changes. Without it this is a DRY RUN that only counts and samples.")
@click.pass_context
def alerts_inbox_correct(ctx, correction, tenant_id, workspace_id, apply_changes):
    """Run one named correction of Inbox items the platform recorded wrongly: a dry run unless --apply.

    An operator command, hidden from the listing. Each correction selects one exact shape and nothing else, goes through the platform's
    own code (never a direct database edit), writes an activity line per item saying what was corrected and why, and a second run
    changes nothing. The output counts what was selected and samples up to 20 items.

    \b
    Corrections:
      decommissioned-benign   closed as benign only because the workload was decommissioned: now "no longer deployed",
                              with the earlier verdict back when one is recorded
      no-longer-reported-but-not-deployed
                              closed as "no longer reported" while the posture data still has the finding and says its
                              workload is not running: now "no longer deployed". Posture that is unavailable or says
                              "running" leaves the item alone (the output counts each kind).
      declared-fix            an item whose fix the triage agent chose, where the rule that raised it now declares a fix:
                              the declared fix replaces it and the item joins its entry. A closed item gets its fix fields
                              corrected only and stays closed; the verdict is never changed.
      reword-fixed-in-running-image
                              an item closed because "the running image already carries the fix", with only that generic
                              sentence: reworded with the posture data's own closing words (both versions and the next step).
                              Text only: nothing reopens and no verdict changes. Items the posture data has nothing to say
                              about are left as they were (the output counts them).
      leave-wrong-entry       an open finding whose fix the triage agent chose and the installed version has since reached: it
                              leaves the entry that holds that fix, and the old fix stays only in its history. Its verdict is
                              unchanged. A person's fix or pin is never touched (the output counts those separately).
      reword-entry-closure    an entry closed as "Condition cleared" that says nothing more: reworded once, from its findings'
                              own closing reasons. Text only: nothing reopens. An entry with a finding that has no usable
                              text is left as it was (the output counts them).
      refresh-entry-target    an open upgrade entry that names a target version none of its findings carries: it is refreshed
                              so its target and title follow the app's version. The findings are not touched.

    \b
    Examples:
      torana alerts correct decommissioned-benign
      torana alerts correct decommissioned-benign --apply
      torana alerts correct no-longer-reported-but-not-deployed
      torana alerts correct declared-fix
      torana alerts correct reword-fixed-in-running-image
      torana alerts correct leave-wrong-entry
      torana alerts correct reword-entry-closure
      torana alerts correct refresh-entry-target
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    body = {"correction": correction, "dry_run": not apply_changes}
    if tenant_id:
        body["tenant_id"] = tenant_id
    if workspace_id:
        body["workspace_id"] = _full_workspace_id(workspace_id)
    client = _client(ctx)
    try:
        data = client.post("api/v1/alerts/inbox-correct", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields)


@alerts.command(name="regroup")
@click.option("--tenant", "tenant_id", default=None,
              help="Operator (super admin profile) only: regroup this tenant instead of your own.")
@click.option("--workspace-id", default=None, help="Only this workspace's members.")
@click.option("--rule-id", default=None, help="Only the members this rule raised.")
@click.option("--limit", default=500, show_default=True,
              help="Members examined per server call. The command pages through ALL members "
                   "itself (keyset cursor); a smaller page keeps each call inside the request "
                   "timeout when --apply is moving members.")
@click.option("--apply", "apply_changes", is_flag=True, default=False,
              help="Make the changes. Without it this is a DRY RUN that only reports.")
@click.pass_context
def alerts_regroup(ctx, tenant_id, workspace_id, rule_id, limit, apply_changes):
    """Regroup members after a grouping-policy change: a dry run unless --apply.

    Recomputes each platform-managed member's entry key under today's policy (the remediation
    registry's key for a remediation member, the rule's current declared title for a situation
    member) and moves the members whose key differs. Each move writes an activity on both
    sides, recomputes both entries, and closes an entry left with no open member. A person's
    move or split is never undone.

    \b
    Examples:
      torana alerts regroup
      torana alerts regroup --rule-id <UUID> --apply
      TORANA_PROFILE=SA torana --act-as-tenant <tenant UUID> --act-as-reason "<why>" alerts regroup --tenant <tenant UUID> --apply
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    body = {"dry_run": not apply_changes, "limit": limit}
    if tenant_id:
        body["tenant_id"] = tenant_id
    if workspace_id:
        body["workspace_id"] = _full_workspace_id(workspace_id)
    if rule_id:
        body["rule_id"] = rule_id
    client = _client(ctx)
    # ⛔ ONE CALL EXAMINES ONLY `limit` MEMBERS, so this pages by cursor until the server says
    # nothing remains. A single call used to look at the same first page every time, so members
    # beyond it were never reached (review M2).
    totals = {"dry_run": not apply_changes, "checked": 0, "to_move": 0, "moved": 0, "failed": 0,
              "pinned_kept": 0, "in_foreign_entry": 0, "entries_to_create": 0, "to_categorise": 0, "categorised": 0,
              "remaining": False, "pages": 0, "sample": []}
    try:
        while True:
            data = client.post("api/v1/alerts/regroup", json=body)
            totals["pages"] += 1
            for k in ("checked", "to_move", "moved", "failed", "pinned_kept", "in_foreign_entry", "entries_to_create",
                      "to_categorise", "categorised"):
                totals[k] += int(data.get(k) or 0)
            if not totals["sample"]:
                totals["sample"] = data.get("sample") or []
            totals["remaining"] = bool(data.get("remaining"))
            cursor = data.get("next_after_id")
            if cursor:
                totals["last_after_id"] = cursor
            if not (data.get("remaining") and cursor) or cursor == body.get("after_id"):
                break
            body["after_id"] = cursor
    except APIError as e:
        # A failure mid-run leaves earlier pages applied: say how far it got and where to resume.
        click.echo(f"regroup stopped after {totals['pages']} page(s): checked {totals['checked']}, "
                   f"moved {totals['moved']}, failed {totals['failed']}. Resume with the cursor "
                   f"{body.get('after_id') or '(none: the first page failed)'}.", err=True)
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if totals["pages"] > 1 and not apply_changes:
        # Each page counts the new entries ITS moves would create; a key seen on several pages is
        # counted once per page, so over several pages this is an upper bound.
        totals["entries_to_create_is_upper_bound"] = True
    output(totals, fmt=fmt, fields=fields)


@alerts.command(name="kinds")
@click.option("--workspace-id", default=None, help="Count one workspace's items.")
@entries_option("Count the rows the Inbox lists (same population as `alerts boxes --entries`).")
@click.pass_context
def alerts_kinds(ctx, workspace_id, inbox_rows):
    """What KIND of thing each open item is: its category and where its finding lives.

    The counts come from the platform (GET /api/v2/alerts/facet-counts, `open_by_kind`):
    open means any status other than closed. PLACE is read from the item's key:

    \b
      code        a finding in source code, in a repository
      repository  a package finding in a repository's dependencies
      image       a package finding on a container image
      other       a finding whose key names no recognised place
    An upgrade, mitigation or posture note the app proposes is not a finding and has
    no place; those are counted separately under "Not findings".

    \b
    Examples:
      torana alerts kinds --workspace-id <UUID>
      torana alerts kinds --workspace-id <UUID> --entries --format json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    params = {}
    if workspace_id:
        params["workspace_id"] = workspace_id
    if inbox_rows:
        params["top_level"] = "true"
    client = _client(ctx)
    try:
        data = client.get("api/v2/alerts/facet-counts", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    summary = (data or {}).get("open_by_kind")
    if summary is None:
        # An older platform without the dimension: say so rather than print zeros.
        click.echo("This platform does not report kinds yet (facet-counts has no "
                   "open_by_kind).", err=True)
        ctx.exit(1)
        return
    if fmt == "text" and not fields:
        click.echo(f"Open items: {summary.get('total', 0)}")
        click.echo("")
        click.echo("By category:")
        for k, n in (summary.get("by_category") or {}).items():
            click.echo(f"  {k:<16} {n}")
        click.echo(f"Open findings by place ({summary.get('findings', 0)} findings):")
        for k, n in (summary.get("by_place") or {}).items():
            click.echo(f"  {k:<16} {n}")
        click.echo("Open findings by category and place:")
        for r in summary.get("by_category_and_place") or []:
            click.echo(f"  {r['category_key'] or '-':<16} {r['place']:<12} {r['count']}")
        nf = summary.get("not_findings") or {}
        if nf.get("total"):
            # Not a place: an upgrade, mitigation or posture note the app proposes.
            parts = ", ".join(f"{k} {n}" for k, n in (nf.get("by_category") or {}).items())
            click.echo(f"Not findings (actions the app proposes, no place): {nf['total']} ({parts})")
        return
    output({"items": summary.get("by_category_and_place") or [],
            "total": int(summary.get("total") or 0),
            "by_category": summary.get("by_category") or {},
            "findings": int(summary.get("findings") or 0),
            "by_place": summary.get("by_place") or {},
            "not_findings": summary.get("not_findings") or {},
            "kinds": (data or {}).get("kinds") or []}, fmt=fmt, fields=fields)


@alerts.command(name="create")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with request body. Use '-' for stdin.")
@click.option("--name", "name", default=None,
              help="Alert title, typically derived from the rule name. Required unless --file supplies it.")
@click.option("--description", "description", default=None, help="Detailed description of the security issue detected")
@click.option("--rule-id", "rule_id", default=None,
              help="ID of the rule that generated this alert. Required unless --file supplies it.")
@click.option("--workspace-id", "workspace_id", default=None,
              help="Workspace UUID the alert belongs to. Required unless --file supplies it — "
                   "the column is NOT NULL, so omitting it fails with a server 500.")
@click.option("--severity", "severity", type=click.Choice(["low", "medium", "high", "critical"], case_sensitive=False), default=None)
@click.option("--status", "status", type=click.Choice(["open", "triaging", "awaiting_input", "pending_remediation", "escalated", "resolved", "closed"], case_sensitive=False), default=None, help="Alert lifecycle status.")
@click.option("--assigned-to", "assigned_to", default=None, help="User or team assigned to investigate this alert")
@click.option("--rule-run-results", "rule_run_results", default=None,
              help="Query results that triggered this alert, as a JSON array "
                   "(e.g. '[{\"cve_id\": \"CVE-2024-1\"}]'). Required unless --file supplies it.")
@click.option("--labels", "labels", default=None,
              help="Key-value pairs for categorizing alerts, as a JSON object.")
@click.option("--tags", "tags", default=None,
              help="Tags for categorizing and routing alerts — JSON array or comma-separated.")
@click.pass_context
def alerts_create(ctx, name, description, rule_id, workspace_id, severity, status, assigned_to, rule_run_results, labels, tags, input_file):
    """Create Alert.

    \b
    Examples:
      torana alerts create --name "SSH brute force" --rule-id <RULE_ID> --severity high
      torana alerts create --file alert.yaml
      torana alerts create --name "Exposed bucket" --severity critical \
          --assigned-to <USER_ID> --status open
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "alerts"
    if input_file:
        body = _load_input_file(input_file)
    else:
        body = {}
        body["name"] = name
        if description is not None:
            body["description"] = description
        body["rule_id"] = rule_id
        if workspace_id is not None:
            body["workspace_id"] = workspace_id
        if severity is not None:
            body["severity"] = severity
        if status is not None:
            body["status"] = status
        if assigned_to is not None:
            body["assigned_to"] = assigned_to
        if rule_run_results is not None:
            # The API requires a LIST; forwarding the raw string 422s with
            # "Input should be a valid list". Parse the JSON the flag documents.
            body["rule_run_results"] = _as_json_value(
                rule_run_results, "--rule-run-results", expect="list")
        if labels is not None:
            body["labels"] = _as_json_value(labels, "--labels", expect="object")
        if tags is not None:
            body["tags"] = _as_json_value(tags, "--tags", expect="list")

    missing = [f for f in ("name", "rule_id", "workspace_id", "rule_run_results")
               if not body.get(f)]
    if missing:
        click.echo(
            "ERROR: missing required field(s): "
            + ", ".join("--" + f.replace("_", "-") for f in missing)
            + "\n       Supply them as flags, or provide all of them in --file.",
            err=True)
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alerts.command(name="filter")
@click.option("--filters", "filters", default=None,
              help='JSON object: field -> value, or field -> {"operation": <op>, '
                   '"value": <v>}. A bare value means equals, a list means in_list. '
                   'e.g. \'{"severity": "critical"}\' or '
                   '\'{"severity": {"operation": "in_list", "value": ["critical", "high"]}}\'')
@click.option("--limit", "limit", type=int, default=100)
@click.option("--offset", "offset", type=int, default=0)
@click.pass_context
def alerts_filter(ctx, filters, limit, offset):
    """List the items that match field conditions you write as JSON, such as severity critical and status open.

    Use this when `alerts list` has no flag for the condition you need. Each field takes a bare value (equals), a list (any of),
    or {"operation": ..., "value": ...}. Paged with --limit and --offset.

    \b
    Output:
      The matching items.

    \b
    Related:
      torana alerts list    the Inbox by box, severity, app and more, with flags
      torana alerts kinds   what kind of thing each open item is

    ⛔ `--filters` IS JSON AND MUST BE PARSED HERE. It used to be passed through as the
    raw STRING click handed us, so the API saw `"{\\"severity\\": \\"critical\\"}"` where
    it required an object and answered `422 body -> filters: Input should be a valid
    dictionary` — for EVERY invocation, including correct ones. Measured on T1
    2026-10-04: the command had never returned a single alert. Found by running it, not
    by reading it; `tests/test_alerts_filter_json.py` is the regression.

    Examples:
      torana alerts filter --filters '{"severity": "critical"}'
      torana alerts filter --filters '{"status": {"operation": "in_list", "value": ["open", "escalated"]}}'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "alerts/filter"
    body = {}
    if filters is not None:
        if isinstance(filters, str):
            try:
                filters = _json.loads(filters)
            except _json.JSONDecodeError as exc:
                # ⚠️ Fail HERE with the offending text, not at the API. A JSON typo
                # otherwise comes back as a generic 422 about `filters` that says
                # nothing about which character was wrong.
                raise click.BadParameter(
                    f"--filters must be a JSON object: {exc}", param_hint="--filters")
        if not isinstance(filters, dict):
            raise click.BadParameter(
                f"--filters must be a JSON OBJECT, got {type(filters).__name__}",
                param_hint="--filters")
        body["filters"] = filters
    if limit is not None:
        body["limit"] = limit
    if offset is not None:
        body["offset"] = offset

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alerts.command(name="by-rule-by-rule-id")
@click.argument("RULE_ID", metavar="RULE_ID")
@click.pass_context
def alerts_by_rule_by_rule_id(ctx, rule_id):
    """Get Alerts By Rule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"alerts/by-rule/{rule_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alerts.command(name="by-suite-by-suite-id")
@click.argument("SUITE_ID", metavar="SUITE_ID")
@click.pass_context
def alerts_by_suite_by_suite_id(ctx, suite_id):
    """Get Alerts By Suite."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"alerts/by-suite/{suite_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ──────────────────────────────────────────────────────────────────────────
# Instance reads regrouped from `<noun>-by-<param>` leaves onto verbs
# (CLI Discoverability Contract, rule 2 — see ../CLAUDE.md). The route
# parameter belongs in the positional ARGUMENT, not the command name.
#
# Old flat names remain as HIDDEN aliases for ONE release (D4).
# ──────────────────────────────────────────────────────────────────────────


# ── Analyst drill-down: a CVE or CWE across the app's ranked findings ───────────────────────────────────────

@alerts.group(name="drill-down")
def alerts_drill_down():
    """What the platform holds about a CVE or a CWE across this app's ranked findings.

    A SUMMARY of the LIVE findings (open, not in a terminal state): counts, intel, breakdowns, what to look at, the ten
    most exposed instances and a weekly timeline. Blast radius and the upgrade delta are separate calls.

    \b
    Examples:
      torana alerts drill-down cve CVE-2026-33845 --workspace-id <WS_UUID>
      torana alerts drill-down cwe CWE-89 --workspace-id <WS_UUID>
      torana alerts drill-down cve CVE-2026-59822 --workspace-id <WS_UUID> --blast-radius \\
          --ecosystem pypi --package litellm --version 1.82.6
      torana alerts drill-down cve CVE-2026-59822 --workspace-id <WS_UUID> --upgrade-delta \\
          --ecosystem pypi --package litellm --installed 1.82.6 --target 1.84.0
    """


def _dd_get(ctx, path, params):
    client = _client(ctx)
    try:
        return client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
    except AuthError as e:
        handle_auth_error(e)
    return None


def _dd_section(title):
    click.echo("")
    click.echo(f"{title}")
    click.echo("-" * len(title))


def _dd_cell(value):
    """A table cell. ⛔ A missing value is "not available", never a dash or "none": it means the platform did not supply
    it, not that there is nothing. A boolean is yes or no."""
    if value is None:
        return "not available"
    if isinstance(value, bool):
        return "yes" if value else "no"
    return str(value)


def _dd_n(value):
    """A number in a sentence: a missing one is "not available" (never 0)."""
    return "not available" if value is None else str(value)


def _dd_table(rows, cols):
    """A small left-aligned table: cols = [(key, header)]."""
    if not rows:
        click.echo("  (none)")
        return
    cells = [[_dd_cell(r.get(k)) for k, _ in cols] for r in rows]
    widths = [max(len(h), *(len(c[i]) for c in cells)) for i, (_, h) in enumerate(cols)]
    widths = [min(w, 60) for w in widths]
    click.echo("  " + "  ".join(h.ljust(widths[i]) for i, (_, h) in enumerate(cols)))
    for c in cells:
        click.echo("  " + "  ".join(c[i][:widths[i]].ljust(widths[i]) for i in range(len(cols))))


def _dd_short(place):
    """An image place `image:<registry>/<path>/<name>@sha256:<digest>` as `<name>@<digest prefix>`: the registry prefix is
    the same on every row and pushes the part that tells them apart off the table."""
    p = str(place or "")
    if p.startswith("image:") and "@" in p:
        name, _, digest = p.rpartition("@")
        return name.rsplit("/", 1)[-1] + "@" + digest.replace("sha256:", "")[:12]
    return p


def _dd_breakdown(title, bd, extra=()):
    rows = (bd or {}).get("rows") or []
    if not rows:
        return
    _dd_section(title)
    if title == "By place":
        rows = [{**r, "label": _dd_short(r.get("label"))} for r in rows]
    _dd_table(rows, [("label", "NAME"), ("live", "LIVE"), ("running", "RUNNING"), ("internet_facing", "INTERNET")] + list(extra))
    if (bd or {}).get("more"):
        click.echo(f"  … and {bd['more']} more")


def _dd_instances(rows):
    def decided(r):
        if r.get("inbox_known") is False:
            return None                                                   # the Inbox could not be read: not known
        if not r.get("alert_id"):
            return "not in the Inbox"
        if not r.get("verdict"):
            return "no verdict yet"
        return f"{r['verdict']} ({r['verdict_source_label']})" if r.get("verdict_source_label") else r["verdict"]
    _dd_table([{**r, "place_key": _dd_short(r.get("place_key")), "decided": decided(r)}
               for r in rows or []],
              [("place_key", "PLACE"), ("package", "PACKAGE"), ("installed_version", "VERSION"), ("running", "RUNNING"),
               ("internet_facing_services", "INET"), ("owner", "OWNER"), ("severity", "SEV"), ("decided", "DECIDED"),
               ("link_alert_id", "OPEN IN INBOX")])


def _dd_as_of(d):
    """The platform's own one-sentence freshness note (the last successful build of the relation, "newer source data not
    yet included" when it is behind). An older platform sends only a row-change time as `as_of`, which understates
    freshness, so it is never shown: no note reads "not available"."""
    return d.get("as_of_note") or "data as of: not available (the platform did not report a build time)"


def _dd_print_cve(d):
    c = d.get("counts") or {}
    h = d.get("history") or {}
    click.echo(f"{d.get('cve_id')}: {_dd_n(c.get('live'))} live findings in {_dd_n(c.get('places'))} places · "
               f"{_dd_n(c.get('running'))} running · {_dd_n(c.get('internet_facing'))} internet-facing · "
               f"{_dd_n(c.get('in_inbox'))} in the Inbox · {_dd_n(c.get('decided'))} decided · {_dd_n(c.get('open'))} open")
    if c.get("exposure_unknown"):
        click.echo(f"  {c['exposure_unknown']} of these: running state not known (not counted as running or as not running)")
    click.echo(f"  not live: {_dd_n(h.get('no_longer_deployed'))} no longer deployed, {_dd_n(h.get('fixed_at_source'))} fixed at "
               f"source, {_dd_n(h.get('other'))} other · {_dd_as_of(d)}")
    if d.get("inbox_available") is False:
        click.echo(f"  Inbox: {d.get('inbox_unavailable_reason')}")
    if c.get("decision_sample_truncated"):
        click.echo("  (in the Inbox / decided / open count only the most exposed findings)")
    f = d.get("funnel") or {}
    click.echo(f"  funnel: live {_dd_n(f.get('live'))} → in the Inbox {_dd_n(f.get('in_inbox'))} → decided "
               f"{_dd_n(f.get('decided'))} → closed {_dd_n(f.get('closed'))}")
    intel = d.get("intel") or {}
    if intel.get("known"):
        _dd_section("Intel")
        kev = intel.get("kev_listed")
        click.echo(f"  CVSS {_dd_n(intel.get('cvss3_base_score'))} · EPSS {_dd_n(intel.get('epss_score'))} · "
                   f"KEV {'not available' if kev is None else 'listed' if kev else 'not listed'} · "
                   f"CWE {intel.get('cwe_ids') or intel.get('cwe_id') or 'not available'} · "
                   f"published {str(intel['published_date'])[:10] if intel.get('published_date') else 'not available'}")
    elif intel:
        click.echo("  intel: not in the threat-intel table" + (f" ({intel['unavailable']})" if intel.get("unavailable") else ""))
    bds = d.get("breakdowns") or {}
    _dd_breakdown("By place", bds.get("place"))
    _dd_breakdown("By owner", bds.get("owner"))
    _dd_breakdown("By scanner", bds.get("scanner"), [("disagree", "DISAGREE")])
    _dd_breakdown("By package", bds.get("package"))
    if "decider" in bds and bds["decider"] is None:
        click.echo("\nBy decider\n  not available")
    else:
        _dd_breakdown("By decider", bds.get("decider"))
    if d.get("look_here") is None and "look_here" in d:
        _dd_section("Look here")
        click.echo(f"  not available: {d.get('look_here_unavailable_reason') or 'the Inbox could not be read'}")
    elif d.get("look_here"):
        _dd_section("Look here")
        for item in d["look_here"]:
            click.echo(f"  {item['kind']}: {item['count']}")
            _dd_instances(item.get("instances"))
    _dd_section("Most exposed")
    _dd_instances(d.get("most_exposed"))
    if d.get("timeline"):
        _dd_section("Timeline (per week)")
        _dd_table(d["timeline"], [("week", "WEEK"), ("first_seen", "FIRST SEEN"), ("closed", "CLOSED"), ("reopened", "REOPENED")])


def _dd_print_cwe(d):
    code, pk = d.get("code") or {}, d.get("packages") or {}
    c = code.get("counts") or {}
    click.echo(f"{d.get('cwe_id')} — code findings: {_dd_n(c.get('live'))} live · {_dd_n(c.get('running'))} running · "
               f"{_dd_n(c.get('internet_facing'))} internet-facing · {_dd_n(c.get('in_inbox'))} in the Inbox · "
               f"{_dd_n(c.get('decided_by_triage_agent'))} decided by the triage agent · {_dd_as_of(d)}")
    if d.get("inbox_available") is False:
        click.echo(f"  Inbox: {d.get('inbox_unavailable_reason')}")
    if code.get("hotspots"):
        _dd_section("Hotspots (repository, file)")
        _dd_table(code["hotspots"], [("repository", "REPOSITORY"), ("file", "FILE"), ("live", "LIVE"), ("open", "OPEN"),
                                     ("running", "RUNNING"), ("internet_facing", "INTERNET")])
    if code.get("by_rule"):
        _dd_section("By scanner rule (verdicts are what the triage agent decided)")
        _dd_table([{**r, "verdicts": (None if r.get("verdicts") is None else
                                      ", ".join(f"{k} {v}" for k, v in r["verdicts"].items() if v) or "none decided")}
                   for r in code["by_rule"]], [("rule_id", "RULE"), ("findings", "FINDINGS"), ("verdicts", "AGENT VERDICTS")])
    if code.get("earlier_decisions"):
        _dd_section("The triage agent's earlier decisions")
        _dd_table(code["earlier_decisions"], [("name", "ITEM"), ("verdict", "VERDICT"), ("when", "WHEN"),
                                              ("link_alert_id", "OPEN IN INBOX")])
    _dd_section(f"Package CVEs with this weakness: {_dd_n(pk.get('live'))} live findings in {_dd_n(pk.get('cves_total'))} CVEs")
    _dd_table(pk.get("cves") or [], [("cve_id", "CVE"), ("live", "LIVE"), ("running", "RUNNING"), ("internet_facing", "INTERNET")])
    if pk.get("more"):
        click.echo(f"  … and {pk['more']} more")


_DD_COUNT_WORDS = {
    "service": ("service", "services"),
    "image": ("running image", "running images"),
    "images_with_package": ("image digest carries it", "image digests carry it"),
    "cloud": ("cloud resource", "cloud resources"),
    "host": ("host", "hosts"),
    "datastore": ("datastore", "datastores"),
}


def _dd_count_label(key, n):
    """"12 services", "1 cloud resource": the count with its noun in the right number; an unknown key is the key,
    pluralised ("2 queues")."""
    one, many = _DD_COUNT_WORDS.get(key) or (str(key).replace("_", " "), str(key).replace("_", " ") + "s")
    return f"{n} {one if n == 1 else many}"


def _dd_print_blast(d):
    if not d.get("available"):
        click.echo(f"Blast radius not available: {d.get('reason')}")
        return
    ac = d.get("affected_counts") or {}
    # The headline is the services whose RUNNING image carries this version. A service reached only through a repository
    # that declares the package is shown apart and never counted as running exposure.
    if "running_with_version" in d:
        click.echo(f"{d['running_with_version']} service(s) run an image that carries this version"
                   + (f"; {d['repository_only']} more reached only through a repository that declares it" if d.get("repository_only") else ""))
    # Only what is certain about the VERSION is counted. The cloud, host and datastore counts include nodes reached through
    # repository-only paths, so they are not printed.
    # A measured zero is stated: "0 running images carry it" is a fact, not an omission.
    facts = []
    if ac.get("image") is not None:
        facts.append(f"{ac['image']} running image{' carries' if ac['image'] == 1 else 's carry'} it")
    if ac.get("images_with_package") is not None:
        n = ac["images_with_package"]
        facts.append(f"{n} image digest{' carries' if n == 1 else 's carry'} it")
    if facts or d.get("truncated"):
        click.echo("Images: " + "; ".join(facts)
                   + (" (INCOMPLETE: the walk was cut short, so these are lower bounds)" if d.get("truncated") else ""))
    _dd_section("Services reached")
    words = {"running_image": "runs this version", "repository_only": "repository only (not running this version)",
             "not_determined": "how it was reached is not known"}
    rows = [{"service": s, "how": ""} if isinstance(s, str) else
            {"service": s.get("service"), "how": words.get(s.get("reached_via"), s.get("reached_via"))}
            for s in d.get("services") or []]
    _dd_table([{"service": r["service"], "how": r["how"] or ""} for r in rows], [("service", "SERVICE"), ("how", "REACHED")])
    for n in d.get("notes") or []:
        click.echo(f"Note: {n}")
    _dd_section("Owners")
    click.echo(d.get("owners_note") or "")
    _dd_table([{"owner": o} for o in d.get("owners") or []], [("owner", "OWNER")])


def _dd_print_delta(d):
    if not d.get("available"):
        click.echo(f"Upgrade delta not available: {d.get('reason')}")
        return
    click.echo(f"Moving {d.get('package')} {d.get('base_version')} → {d.get('target_version')}: "
               f"{len(d.get('fixed') or [])} fixed · {len(d.get('introduced') or [])} introduced · "
               f"{len(d.get('unchanged') or [])} unchanged" + (" · none known introduced (not a guarantee)" if d.get("none_known") else ""))
    if d.get("not_checked"):
        click.echo("Checked: " + ", ".join(x.replace("_", " ") for x in d.get("checks") or [])
                   + ". Not checked: " + ", ".join(x.replace("_", " ") for x in d["not_checked"]) + ".")
    for key in ("fixed", "introduced", "unchanged"):
        if d.get(key):
            _dd_section(key.capitalize())
            _dd_table(d[key], [("id", "ADVISORY"), ("severity", "SEVERITY"), ("cvss", "CVSS"), ("kev", "KEV")])


def _dd_emit(ctx, data, printer):
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    if fmt in ("text", "table") and not raw and not fields and isinstance(data, dict):
        printer(data)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@alerts_drill_down.command(name="cve", hidden=True)
@click.argument("CVE_ID", metavar="CVE")
@click.option("--workspace-id", "workspace_id", required=True, help="The app (workspace) UUID the findings are read in.")
@click.option("--blast-radius", "blast_radius", is_flag=True, default=False,
              help="Instead of the summary: the services and owners one package version reaches "
                   "(needs --ecosystem --package --version; pypi, golang, npm, maven).")
@click.option("--upgrade-delta", "upgrade_delta", is_flag=True, default=False,
              help="Instead of the summary: what moving a package fixes and introduces "
                   "(needs --ecosystem --package --installed --target; pypi, golang, npm, maven).")
@click.option("--ecosystem", default=None, help="pypi, golang, npm or maven.")
@click.option("--package", default=None, help="The package name (module path for golang).")
@click.option("--version", default=None, help="The package version (with --blast-radius).")
@click.option("--installed", default=None, help="The installed version (with --upgrade-delta).")
@click.option("--target", default=None, help="The version to move to (with --upgrade-delta).")
@click.pass_context
def alerts_drill_down_cve(ctx, cve_id, workspace_id, blast_radius, upgrade_delta, ecosystem, package, version, installed,
                          target):
    """One CVE across the app's live ranked findings.

    \b
    Examples:
      torana alerts drill-down cve CVE-2026-33845 --workspace-id <WS_UUID>
      torana alerts drill-down cve CVE-2026-59822 --workspace-id <WS_UUID> --blast-radius --ecosystem pypi --package litellm --version 1.82.6
    """
    if blast_radius and upgrade_delta:
        raise click.UsageError("Use --blast-radius or --upgrade-delta, not both.")
    base = f"alerts/drill-down/cve/{cve_id}"
    ws = _full_workspace_id(workspace_id)
    if blast_radius:
        if not (ecosystem and package and version):
            raise click.UsageError("--blast-radius needs --ecosystem, --package and --version.")
        data = _dd_get(ctx, base + "/blast-radius", {"workspace_id": ws, "ecosystem": ecosystem, "package": package,
                                                      "version": version})
        printer = _dd_print_blast
    elif upgrade_delta:
        if not (ecosystem and package and installed and target):
            raise click.UsageError("--upgrade-delta needs --ecosystem, --package, --installed and --target.")
        data = _dd_get(ctx, base + "/upgrade-delta", {"workspace_id": ws, "ecosystem": ecosystem, "package": package,
                                                       "installed": installed, "target": target})
        printer = _dd_print_delta
    else:
        data = _dd_get(ctx, base, {"workspace_id": ws})
        printer = _dd_print_cve
    if data is not None:
        _dd_emit(ctx, data, printer)


@alerts_drill_down.command(name="cwe", hidden=True)
@click.argument("CWE_ID", metavar="CWE")
@click.option("--workspace-id", "workspace_id", required=True, help="The app (workspace) UUID the findings are read in.")
@click.pass_context
def alerts_drill_down_cwe(ctx, cwe_id, workspace_id):
    """One CWE (weakness class): its code findings (hotspots, rules, the agent's decisions) and the package CVEs.

    \b
    Example:
      torana alerts drill-down cwe CWE-89 --workspace-id <WS_UUID>
    """
    data = _dd_get(ctx, f"alerts/drill-down/cwe/{cwe_id}", {"workspace_id": _full_workspace_id(workspace_id)})
    if data is not None:
        _dd_emit(ctx, data, _dd_print_cwe)


# ── `alerts cve` / `alerts cwe`: a CVE or CWE across the app, one section at a time (INBOX_SECTIONS_SPEC § 3.4.3.2) ─────

#: The sections the platform serves for each panel, by CLI key (the API key with `_` written `-`), in screen order.
CVE_SECTION_KEYS = ("about", "where-found", "blast-radius", "verdict", "how-to-fix", "reported-by", "history")
CWE_SECTION_KEYS = ("about", "where-found", "location", "verdict", "reported-by", "related")

_SECTION_TITLES = {"about": "About", "where_found": "Where it's found", "location": "Location",
                   "blast_radius": "Blast radius", "verdict": "Verdict", "how_to_fix": "How to fix", "reported_by": "Reported by",
                   "history": "History", "related": "Related"}


def _panel_cell(cell) -> str:
    """One table cell: text, an action target (`inbox`/`open` = an alert id, `drill` = a CVE id), or an external link."""
    if isinstance(cell, dict):
        return " ".join(str(x) for x in (cell.get("url"), cell.get("note")) if x)
    return "not available" if cell is None else str(cell)


def _print_panel_table(table: dict) -> None:
    cols = table.get("columns") or []
    if table.get("title"):
        click.echo(f"  {table['title']}")
    rows = [[_panel_cell(r.get(c["field"])) for c in cols] for r in table.get("rows") or []]
    widths = [max([len(str(c.get("header", "")))] + [len(r[i]) for r in rows]) for i, c in enumerate(cols)]
    click.echo("  " + "  ".join(str(c.get("header", "")).ljust(widths[i]) for i, c in enumerate(cols)).rstrip())
    for r in rows:
        click.echo("  " + "  ".join(v.ljust(widths[i]) for i, v in enumerate(r)).rstrip())


def _print_panel_section(key: str, body: dict) -> None:
    """One panel section as the drawer shows it: `title`, its `description`, its `lines` (the item view's line shape), then its `tables`."""
    from torana_cli.alert import _print_description, _print_notes, _print_view_line
    click.echo("")
    click.echo((body.get("title") or _SECTION_TITLES.get(key, key)).upper())
    _print_description(body)
    if body.get("empty") or body.get("unavailable"):
        click.echo(f"  {body.get('empty') or body.get('unavailable')}")
        return
    for row in body.get("lines") or []:
        _print_view_line(row)
    for table in body.get("tables") or []:
        _print_panel_table(table)
    _print_notes(body)


def _print_what_to_do(w) -> None:
    """The drawer's top line: what to do about this CVE ("12 open findings to fix:" and the Inbox entries), printed before any card."""
    from torana_cli.alert import _print_view_line
    if not isinstance(w, dict):
        return
    if w.get("unavailable"):
        click.echo(f"  {w['unavailable']}")
        return
    _print_view_line({"label": "", "value": w.get("value") or "", "links": w.get("links") or []})


def _panel_read(ctx, kind, ident, workspace_id, sections_wanted, ecosystem, package, version, installed, target, check_upgrade,
                all_reasons=False):
    ctx.meta["torana_all_reasons"] = all_reasons
    keys = [_api_panel_key(k) for k in sections_wanted]
    ws = _full_workspace_id(workspace_id)
    base = f"alerts/drill-down/{kind}/{ident}"
    if ("blast_radius" in keys) and not (ecosystem and package and version):
        keys_for_server = keys
        blast = None
    else:
        keys_for_server = [k for k in keys if k != "blast_radius"]
        blast = ("blast_radius" in keys)
    if check_upgrade and not (ecosystem and package and installed and target):
        raise click.UsageError("--check-upgrade needs --ecosystem, --package, --installed and --target.")
    params = {"workspace_id": ws}
    if keys_for_server:
        params["section"] = keys_for_server
    data = None
    if not (blast and not keys_for_server):
        data = _dd_get(ctx, base, params)
        if data is None:
            return
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    extra = {}
    if blast:
        extra["blast_radius"] = _dd_get(ctx, base + "/blast-radius", {"workspace_id": ws, "ecosystem": ecosystem, "package": package,
                                                                      "version": list(version)})
    if check_upgrade:
        extra["upgrade_delta"] = _dd_get(ctx, base + "/upgrade-delta", {"workspace_id": ws, "ecosystem": ecosystem, "package": package,
                                                                        "installed": installed, "target": target})
    if fmt not in ("text", "table") or fields:
        out = dict(data or {})
        out.update(extra)
        output(out, fmt=fmt, fields=fields)
        return
    click.echo("")
    click.echo(f"{ident}")
    _print_what_to_do((data or {}).get("what_to_do"))
    sections = (data or {}).get("sections") or {}
    for key in (keys or list(sections)):
        if key in sections:
            _print_panel_section(key, sections[key])
    if extra.get("blast_radius"):
        _print_blast_answer(extra["blast_radius"])
    if extra.get("upgrade_delta"):
        _dd_print_delta(extra["upgrade_delta"])
    click.echo("")


def _print_blast_answer(d) -> None:
    """A blast-radius answer: one version prints as before; several print the union, then each version's own reach."""
    if isinstance(d, dict) and isinstance(d.get("versions"), list):
        click.echo(f"  All {len(d['versions'])} versions together")
        _dd_print_blast(d.get("union") or {})
        for v in d["versions"]:
            click.echo(f"  Version {v.get('version')}")
            _dd_print_blast(v)
    else:
        _dd_print_blast(d)


def _api_panel_key(key: str) -> str:
    return key.strip().lower().replace("-", "_")


@alerts.command(name="cve")
@click.argument("CVE_ID", metavar="CVE")
@click.option("--workspace-id", "workspace_id", required=True, help="The app (workspace) UUID the findings are read in.")
@click.option("--section", "sections_wanted", multiple=True, type=click.Choice(CVE_SECTION_KEYS, case_sensitive=False),
              help="Show only this section (repeatable). Without it, every section.")
@click.option("--ecosystem", default=None, help="pypi, golang, npm or maven (for blast-radius and --check-upgrade).")
@click.option("--package", default=None, help="The package name (module path for golang).")
@click.option("--version", "version", multiple=True,
              help="The package version (with --section blast-radius). Repeat it to check every installed version: "
                   "the answer is the union of services plus each version's own.")
@click.option("--check-upgrade", "check_upgrade", is_flag=True, default=False,
              help="With how-to-fix: what moving the package fixes and introduces (needs --ecosystem --package --installed --target).")
@click.option("--installed", default=None, help="The installed version (with --check-upgrade).")
@click.option("--target", default=None, help="The version to move to (with --check-upgrade).")
@all_reasons_option
@click.pass_context
def alerts_cve(ctx, cve_id, workspace_id, sections_wanted, ecosystem, package, version, check_upgrade, installed, target, all_reasons):
    """One CVE across the app's live findings, whole or one section at a time.

    Use this to see how a CVE stands in this app: how severe it is, where it is found, what to do about it,
    who decided what and how the numbers moved. The first line says what to do (for example "12 open findings to fix:" with the
    Inbox entry that holds them). To read one item use `torana alert <id> view`; to work
    through the Inbox use `torana alerts list`. It reads the LIVE findings (open, not in a terminal state).

    \b
    --section keys, with what each card shows (the platform sends the same text as `description` on every section):
      {SECTIONS}

    \b
    blast-radius needs --ecosystem --package --version; how-to-fix can check a move with --check-upgrade.

    `Not available` means the platform did not supply the value; it is never a zero.

    \b
    Examples:
      torana alerts cve CVE-2026-33845 --workspace-id <WS_UUID>
      torana alerts cve CVE-2026-33845 --workspace-id <WS_UUID> --section how-to-fix
      torana alerts cve CVE-2026-33845 --workspace-id <WS_UUID> --section verdict --section reported-by --format json
      torana alerts cve CVE-2026-33845 --workspace-id <WS_UUID> --section verdict --all-reasons
      torana alerts cve CVE-2026-59822 --workspace-id <WS_UUID> --section blast-radius --ecosystem pypi --package litellm --version 1.82.6

    Related: `alerts cwe`, `alert <id> view`, `alerts list --cve`.
    """
    _panel_read(ctx, "cve", cve_id, workspace_id, sections_wanted, ecosystem, package, version, installed, target, check_upgrade,
                all_reasons)


@alerts.command(name="cwe")
@click.argument("CWE_ID", metavar="CWE")
@click.option("--workspace-id", "workspace_id", required=True, help="The app (workspace) UUID the findings are read in.")
@click.option("--section", "sections_wanted", multiple=True, type=click.Choice(CWE_SECTION_KEYS, case_sensitive=False),
              help="Show only this section (repeatable). Without it, every section.")
@all_reasons_option
@click.pass_context
def alerts_cwe(ctx, cwe_id, workspace_id, sections_wanted, all_reasons):
    """One CWE (weakness class) across the app: its code findings and the package CVEs, whole or one section at a time.

    Use this to see where a class of weakness shows up in this app's code and packages. To read one item use
    `torana alert <id> view`; to see one CVE use `torana alerts cve`.

    \b
    --section keys, with what each card shows (the platform sends the same text as `description` on every section):
      {SECTIONS}

    \b
    Examples:
      torana alerts cwe CWE-89 --workspace-id <WS_UUID>
      torana alerts cwe CWE-89 --workspace-id <WS_UUID> --section location
      torana alerts cwe CWE-89 --workspace-id <WS_UUID> --section verdict --format json

    Related: `alerts cve`, `alert <id> view`.
    """
    _panel_read(ctx, "cwe", cwe_id, workspace_id, sections_wanted, None, None, None, None, None, False, all_reasons)


with_sections_help(alerts_cve, "cve")
with_sections_help(alerts_cwe, "cwe")


@alerts.group(name="suite-rule")
def alerts_suite_rule_grp():
    """Alerts for one rule within one suite.

    Examples:
      torana alerts suite-rule get --help
    """


@alerts_suite_rule_grp.command(name="get")
@click.argument("SUITE_ID", metavar="SUITE_ID")
@click.argument("RULE_ID", metavar="RULE_ID")
@click.pass_context
def alerts_rule_by_rule_id(ctx, suite_id, rule_id):
    """The items one detection rule raised inside one suite.

    Use this when you start from a suite and a rule (an operator view) and want the items they produced. To browse the Inbox
    by box, severity or app, use `alerts list`.

    \b
    Output:
      The items raised by that rule in that suite.

    \b
    Related:
      torana alerts list             the Inbox, by box and filters
      torana alerts count --rule-id  how many a rule raised

    \b
    Examples:
      torana alerts suite-rule get <SUITE_ID> <RULE_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"alerts/by-suite/{suite_id}/rule/{rule_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alerts.command(name="count")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--suite-id", "suite_id", default=None)
@click.option("--rule-id", "rule_id", default=None)
@click.pass_context
def alerts_count(ctx, suite_id, rule_id, page, page_size, fetch_all):
    """How many items exist in total, or how many one suite or one rule raised.

    Use this for a single number. For the count in each Inbox box use `alerts boxes`; for counts by severity, status or app
    use `alerts breakdown`.

    \b
    Output:
      The count (all items, or those of --suite-id / --rule-id).

    \b
    Related:
      torana alerts boxes       the count in each Inbox box
      torana alerts breakdown   counts by severity, status, app

    \b
    Examples:
      torana alerts count
      torana alerts count --rule-id <RULE_ID>
      torana alerts count --suite-id <SUITE_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "alerts/count"
    params = {}
    if suite_id is not None:
        params["suite_id"] = suite_id
    if rule_id is not None:
        params["rule_id"] = rule_id
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@alerts.command(name="triage-agents")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def alerts_triage_agents(ctx, page, page_size, fetch_all):
    """List Triage Agents."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "alerts/triage/agents"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


# ---------------------------------------------------------------------------
# activities — standalone top-level command group
# ---------------------------------------------------------------------------

@click.group()
def activities():
    """Platform activity feed — what happened, across resources.

    \b
    Examples:
      torana activities list
      torana activities list --json --raw | jq '.[0]'
      torana activities list --type verdict_set --actor agent --since 7d --all
      torana activities list --help          filters: --type, --actor, --alert-type, --vulnerability-id, --since/--from/--to
      torana activities create --alert-id <ALERT_ID> --activity-type note --message "..."
    """


@activities.command(name="list")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--vulnerability-id", "vulnerability_id", default=None,
              help="Only activities about ONE finding — its own timeline, alert or not.")
@click.option("--type", "activity_type", default=None, metavar="TYPE[,TYPE]",
              help="Only these activity types, comma-separated (e.g. verdict_set,agent_response,escalated).")
@click.option("--actor", "actor_type", default=None,
              type=click.Choice(["user", "agent", "system"], case_sensitive=False),
              help="Only activities done by this kind of actor: a person (user), the triage agent (agent) or the platform (system).")
@click.option("--alert-type", "alert_type", default=None,
              type=click.Choice(["vulnerability", "cloud", "identity", "compliance", "custom"], case_sensitive=False),
              help="Only activities on alerts of this type. Activities about a finding with no alert have no alert type, so this leaves them out.")
@click.option("--since", "since", default=None,
              type=click.Choice(["24h", "2d", "7d", "30d"], case_sensitive=False),
              help="Only activities in the last 24h, 2d, 7d or 30d.")
@click.option("--from", "date_from", default=None, metavar="ISO",
              help="Only activities at or after this ISO 8601 time, e.g. 2026-10-01T08:00:00Z.")
@click.option("--to", "date_to", default=None, metavar="ISO",
              help="Only activities at or before this ISO 8601 time.")
@click.pass_context
def activities_list(ctx, page, page_size, fetch_all, vulnerability_id, activity_type, actor_type, alert_type,
                    since, date_from, date_to):
    """List activities — the platform timeline, newest first.

    ⚠️ An activity's subject is an ALERT or a VULNERABILITY (T11 § 3.3.3). Without
    --vulnerability-id this lists both kinds interleaved.

    ⚠️ One page by default. The API does not report a total, so a full page means there may be more: add --all (or --page).
    Count by asking for --all with the filters you want; do not read a count off one page.

    \b
    Examples:
      torana activities list --type verdict_set --since 7d --all
      torana activities list --actor agent --from 2026-10-01T00:00:00Z --to 2026-10-08T00:00:00Z
      torana activities list --vulnerability-id <VULNERABILITY_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "activities"
    effective_page_size = min(page_size or settings.page_size, 100)
    # ⛔ `offset`, NOT `skip` — the endpoint declares `offset` and IGNORES an unknown
    # `skip`, so every page silently returned PAGE ONE. Verified against the running
    # service: `?skip=1` and `?offset=0` returned an identical first row, while
    # `?offset=1` returned the next one. `--all` was affected too: the loop breaks on
    # `len(all_items) >= total`, and a list response makes total == the page size, so
    # it stopped after one page while reporting success.
    params = {"offset": (page - 1) * effective_page_size, "limit": effective_page_size}
    if vulnerability_id:
        params["vulnerability_id"] = vulnerability_id
    if activity_type:
        params["activity_type"] = ",".join(t.strip() for t in activity_type.split(",") if t.strip())
    if actor_type:
        params["actor_type"] = actor_type.lower()
    if alert_type:
        params["alert_type"] = alert_type.lower()
    params.update(_activity_window(since, date_from, date_to))

    client = _client(ctx)
    try:
        if fetch_all:
            # The endpoint returns a bare LIST with no total, so "I have them all" means a page that came back
            # SHORT. Stopping on `len(all) >= total` read the first page's own size as the total and returned one page.
            all_items = []
            page_num = 1
            while True:
                p = {**params, "offset": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                if isinstance(data, dict) and isinstance(data.get("total"), int):
                    if len(all_items) >= data["total"]:
                        break
                elif len(items) < effective_page_size:
                    break
                if not items:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
            shown_all = True
        else:
            data = client.get(path, params=params)
            shown_all = False
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)
    if fmt in ("text", "table") and not raw:
        n = len(data.get("items", data)) if isinstance(data, dict) else len(data)
        if shown_all:
            click.echo(f"\n{n} {'activity' if n == 1 else 'activities'}")
        elif n >= effective_page_size:
            click.echo(f"\n{n} shown; there may be more (the API reports no total). Add --all for every one, or --page for the next.")


_SINCE_DELTAS = {"24h": 1, "2d": 2, "7d": 7, "30d": 30}


def _activity_window(since, date_from, date_to):
    """`start_time` / `end_time` for the activities endpoint. --since is a convenience for a start time worked out from now."""
    if since and date_from:
        raise click.UsageError("--since and --from both set the start of the window: use one.")
    out = {}
    if since:
        import datetime as _dt
        start = _dt.datetime.now(_dt.timezone.utc) - _dt.timedelta(days=_SINCE_DELTAS[since.lower()])
        out["start_time"] = start.strftime("%Y-%m-%dT%H:%M:%SZ")
    if date_from:
        out["start_time"] = date_from
    if date_to:
        out["end_time"] = date_to
    return out



@activities.command(name="create")
@click.option("--alert-id", "alert_id", default=None, help="The alert this activity is about.")
@click.option("--vulnerability-id", "vulnerability_id", default=None,
              help="The datalake vulnerability this activity is about.")
@click.option("--activity-type", "activity_type", required=True,
              help="What happened, e.g. verdict_set, assigned, status_changed.")
@click.option("--message", required=True, help="Human-readable description of what happened.")
@click.option("--actor-type", "actor_type", type=click.Choice(["user", "agent", "system"]),
              default=None, help="Who acted (server default: system).")
@click.option("--extra-data", "extra_data", default=None,
              help='Structured detail as a JSON object, e.g. \'{"prior_verdict": "true_positive"}\'.')
@click.pass_context
def activities_create(ctx, alert_id, vulnerability_id, activity_type, message, actor_type,
                      extra_data):
    """Append one entry to an alert's or a vulnerability's timeline.

    Name at least one subject (--alert-id and/or --vulnerability-id). For a `user`
    activity the actor is YOU, taken from your login; it cannot be set to someone else.

    \b
    Examples:
      torana activities create --alert-id <ALERT_ID> --activity-type note --message "Checked with owner"
      torana activities create --vulnerability-id <VULN_ID> --activity-type verdict_set \\
        --message "False positive: test fixture" --actor-type user \\
        --extra-data '{"prior_verdict": "true_positive"}'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    if not alert_id and not vulnerability_id:
        raise click.UsageError("name a subject: --alert-id, --vulnerability-id, or both")
    body = {"activity_type": activity_type, "message": message}
    if alert_id:
        body["alert_id"] = alert_id
    if vulnerability_id:
        body["vulnerability_id"] = vulnerability_id
    if actor_type:
        body["actor_type"] = actor_type
    if extra_data:
        try:
            parsed = _json.loads(extra_data)
        except ValueError as e:
            raise click.BadParameter(f"not valid JSON: {e}", param_hint="--extra-data")
        if not isinstance(parsed, dict):
            raise click.BadParameter("must be a JSON object", param_hint="--extra-data")
        body["extra_data"] = parsed
    client = _client(ctx)
    try:
        data = client.post("activities", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields)


@alerts.command(name="breakdown")
@click.option("--workspace-id", default=None, help="Limit to one workspace.")
@click.option("--tenant-id", default=None, help="Cross-tenant callers only.")
@click.pass_context
def alerts_breakdown(ctx, workspace_id, tenant_id):
    """Counts over EVERY alert in scope, not just one page.

    \b
    The inbox's tab badges are folded from these rows, so this is the same
    arithmetic the UI shows — use it to check a badge that looks wrong.

    \b
    ⚠️ NOT `alerts count` (a flat total for a suite or rule) and NOT
    `alerts dispositions-summary` (the Advisor's per-rule, 14-day signal).
    This one groups the whole scope by the dimensions a verdict decision
    reads: verdict, status, assignee, and whether a playbook ran.

    \b
    Example:
      torana alerts breakdown --workspace-id <UUID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if workspace_id:
        params["workspace_id"] = _full_workspace_id(workspace_id)
    if tenant_id:
        params["tenant_id"] = tenant_id

    client = _client(ctx)
    try:
        data = client.get("api/v2/alerts/facet-counts", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, fields=fields)
        return

    rows = sorted(data.get("groups", []), key=lambda g: -g.get("count", 0))
    # ⛔ TWO POPULATIONS ON ONE SCREEN, SO BOTH ARE LABELLED. `total` is what the Inbox
    # can LIST (Needs attention plus Closed); the rows below are grouped over EVERY item
    # in scope, moved work included, so they sum HIGHER. Printing a bare "TOTAL" above
    # rows that add up to something larger invites the reader to conclude the table is
    # wrong, or the total is.
    _listed = int(data.get("total") or 0)
    _grouped = sum(int(g.get("count") or 0) for g in (data.get("groups") or []))
    click.echo(f"{_listed} listable item(s) in scope — Needs attention plus Closed.")
    if _grouped != _listed:
        click.echo(f"The {_grouped} grouped below include moved work, which the Inbox "
                   f"lists only under All.")
    click.echo("")
    hdr = f"{'VERDICT':<15} {'STATUS':<20} {'ASSIGNEE':<12} {'MINE':<5} {'PLAYBOOK':<9} {'COUNT':>6}"
    click.echo(hdr)
    click.echo("-" * len(hdr))
    for g in rows:
        click.echo(
            f"{str(g.get('triage_verdict') or '-'):<15} "
            f"{str(g.get('status') or '-'):<20} "
            f"{str(g.get('assignee_type') or '-'):<12} "
            f"{('yes' if g.get('assigned_to_me') else '-'):<5} "
            f"{str(g.get('latest_routing_outcome') or '-'):<9} "
            f"{g.get('count', 0):>6}"
        )


@alerts.command(name="dispositions-summary")
@click.option("--workspace-id", default=None, help="Filter by workspace UUID (Signal B).")
@click.pass_context
def alerts_dispositions_summary(ctx, workspace_id):
    """How the items of an app were decided: the counts per disposition (true positive, false positive, not decided and so on).

    Use this for a summary of verdicts across an app. For the list of items, use `alerts list`; for one item's verdict use
    `alert <UUID> view --section verdict`. Without --workspace-id it covers every app you can see. Get the app UUID from
    `torana workspaces list`.

    \b
    Output:
      One count per disposition.

    \b
    Related:
      torana alerts breakdown   counts by severity, status, app
      torana alerts boxes       counts per Inbox box

    \b
    Examples:
      torana alerts dispositions-summary --workspace-id <UUID>
      torana alerts dispositions-summary
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if workspace_id:
        params["workspace_id"] = _full_workspace_id(workspace_id)

    client = _client(ctx)
    try:
        data = client.get("alerts/dispositions/summary", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ──────────────────────────────────────────────────────────────────────────
# BACK-COMPAT — hidden aliases for the old `<noun>-by-<param>` names.
# ⏳ ONE RELEASE ONLY (decision D4). Delete this block next release.
# ──────────────────────────────────────────────────────────────────────────

_LEGACY_BY_PARAM_ALERTS = {
    "rule-by-rule-id": ("suite-rule", "get"),
}


@alerts.command(name="remediation-vocabulary")
@click.pass_context
def alerts_remediation_vocabulary(ctx):
    """The remediation actions, target types and which combinations are valid.

    A remediation is an ACTION on a TARGET TYPE. `valid_targets` lists, per action, the
    target types it takes; `accept` and `none` are recorded actions that take no target and close nothing;
    `versioned_actions` are the ones that may carry a target version. The category each
    action puts an open item in is under `categories`.

    \b
    Examples:
      torana alerts remediation-vocabulary
      torana alert <UUID> verdict --triage-verdict true_positive \\
        --remediation-action upgrade --remediation-target-type package \\
        --remediation-target-version 4.17.21
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get("alerts/remediation-vocabulary")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields)


@alerts.command(name="reason-codes")
@click.pass_context
def alerts_reason_codes(ctx):
    """The closed list of grounds a verdict may cite.

    `AGENT MAY CLOSE` marks the only grounds the triage agent may CLOSE a finding on.
    The rest are for confirming, for escalating, or for a person recording an accepted
    risk or a duplicate.

    \b
    Examples:
      torana alerts reason-codes
      torana alert <UUID> verdict --triage-verdict benign --reason-code package_not_shipped
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("alerts/verdict-reason-codes")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    rows = data.get("reason_codes", []) if isinstance(data, dict) else data
    for row in rows:
        if isinstance(row, dict):
            row["verdicts_text"] = ", ".join(row.get("verdicts", []))
            row["may_close"] = "yes" if row.get("agent_may_close") else ""
    cols = [("code", "CODE", 30), ("verdicts_text", "VERDICTS", 34),
            ("may_close", "AGENT MAY CLOSE", 16), ("label", "GROUND", 60)]
    output({"items": rows} if isinstance(data, dict) else rows,
           fmt=fmt, raw=raw, fields=fields, columns=cols)


def _register_legacy_alerts_by_param() -> None:
    """Old flat names, hidden so they cannot be discovered anew."""
    import copy
    for _old, (_sub, _verb) in _LEGACY_BY_PARAM_ALERTS.items():
        _grp = alerts.commands.get(_sub)
        if not isinstance(_grp, click.Group):
            continue
        _cmd = _grp.commands.get(_verb)
        if _cmd is None:
            continue
        # ⛔ Never let an alias overwrite a real group of the same name.
        if isinstance(alerts.commands.get(_old), click.Group):
            continue
        _alias = copy.copy(_cmd)
        _alias.name = _old
        _alias.hidden = True
        alerts.add_command(_alias)


_register_legacy_alerts_by_param()


#: Operator commands: they stay callable (behaviour unchanged) but leave the default listing, so a customer's Claude meets the Inbox
#: commands first. Listed under "Operator commands" in `skills/torana-skill/references/detection.md`. (INBOX_SECTIONS_SPEC § 3.4.3.4)
OPERATOR_ALERTS_COMMANDS = ("reconcile-owners", "reconcile-sla", "regroup", "create", "triage-agents",
                            "by-rule-by-rule-id", "by-suite-by-suite-id", "suite-rule")


def _hide_operator_commands() -> None:
    for _name in OPERATOR_ALERTS_COMMANDS:
        _cmd = alerts.commands.get(_name)
        if _cmd is not None:
            _cmd.hidden = True


@alerts.command(name="lifecycle-state")
@click.option("--workspace-id", required=True, help="The workspace whose Inbox to check.")
@click.pass_context
def alerts_lifecycle_state(ctx, workspace_id):
    """Is this Inbox in step with the data behind it?

    Use this when the Inbox looks empty or out of date; for the items themselves use `alerts list`.

    \b
    Examples:
      torana alerts lifecycle-state --workspace-id <WS_UUID>
      torana alerts lifecycle-state --workspace-id <WS_UUID> --format json

    \b
    An EMPTY Inbox means one of two opposite things: there is nothing to do, or the last
    check of the data was refused and items that have ended are still listed. This is what
    tells them apart.

    \b
      off      no rule in this workspace has its lifecycle on
      current  every rule checked its data and was believed
      stale    a rule has not been checked recently
      refused  a rule's last check was refused — the reason is shown
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get("alerts/lifecycle-state",
                          params={"workspace_id": workspace_id})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt == "json":
        output(data, fmt=fmt, fields=fields)
        return
    click.echo(f"STATE  {data.get('state')}")
    rows = data.get("rules") or []
    if not rows:
        click.echo("No rule in this workspace has its lifecycle on.")
        return
    output({"items": rows}, fmt=fmt,
           fields=fields or "name,last_run_status,mode,last_observed_at,refusal_reason")


# ── SLA policy (S2-14) ─────────────────────────────────────────────────────────


def _print_sla_policy(ctx, data):
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    if fmt != "text":
        output(data, fmt=fmt, fields=fields)
        return
    defaults = data.get("defaults") or {}
    src = data.get("source")
    click.echo(f"SOURCE  {src}" + ("  (platform defaults; this tenant has not set its own)"
                                   if src == "default" else ""))
    for sev in ("critical", "high", "medium", "low"):
        hours = data.get(f"{sev}_hours")
        shown = f"{hours} h" if hours is not None else "no deadline"
        extra = "" if hours == defaults.get(sev) else f"  (default {defaults.get(sev)} h)"
        click.echo(f"{sev.upper():<9} {shown}{extra}")
    if data.get("updated_at"):
        click.echo(f"UPDATED  {data['updated_at']}")
    overrides = data.get("rule_overrides") or []
    if overrides:
        click.echo(f"\nRULE OVERRIDES ({len(overrides)}): these rules' alerts use their own hours")
        for o in overrides:
            click.echo(f"  {o.get('sla_hours'):>6} h  {o.get('name')}  ({o.get('rule_id')})")
    click.echo(data.get("note") or "")


@alerts.group(name="sla-policy")
@click.pass_context
def alerts_sla_policy(ctx):
    """How long this tenant gives itself to handle an alert, by severity.

    \b
    An alert's deadline (sla_due_at) is set when it is raised: raised + the hours for
    its severity. A rule's own override (torana rule <UUID> update --sla-hours N) wins
    over this table. When an alert's severity rises, the tightest deadline wins.
    Changing the policy affects NEW alerts only.

    \b
    This table does NOT set the deadlines of a vulnerability app that ranks its findings
    (Exposure Posture & Remediation): there the deadline class comes from the app's
    priority, and its windows (in days) from the app's policy value sla_window_by_severity.
    `torana alert <UUID> view` says which ("High deadline: 30 days, from the app's priority 12").

    \b
    Examples:
      torana alerts sla-policy get
      torana alerts sla-policy set --critical-hours 12 --high-hours 48
      torana alerts sla-policy set --reset
    """
    ctx.ensure_object(dict)


@alerts_sla_policy.command(name="get")
@click.pass_context
def alerts_sla_policy_get(ctx):
    """Show the SLA hours per severity and whether they are this tenant's own.

    \b
    Examples:
      torana alerts sla-policy get
      torana alerts sla-policy get --format json
    """
    client = _client(ctx)
    try:
        data = client.get("alerts/sla-policy")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    _print_sla_policy(ctx, data)


@alerts_sla_policy.command(name="set")
@click.option("--critical-hours", type=click.IntRange(1, 87600), default=None)
@click.option("--high-hours", type=click.IntRange(1, 87600), default=None)
@click.option("--medium-hours", type=click.IntRange(1, 87600), default=None)
@click.option("--low-hours", type=click.IntRange(1, 87600), default=None)
@click.option("--reset", is_flag=True,
              help="Drop this tenant's policy and go back to the platform defaults.")
@click.pass_context
def alerts_sla_policy_set(ctx, critical_hours, high_hours, medium_hours, low_hours, reset):
    """Change the SLA hours for one or more severities (tenant admin).

    \b
    Severities you leave out keep their current hours. Existing alerts keep their
    deadlines; only alerts raised from now on use the new hours.

    \b
    Examples:
      torana alerts sla-policy set --critical-hours 12
      torana alerts sla-policy set --high-hours 48 --medium-hours 120
      torana alerts sla-policy set --reset
    """
    body = {k: v for k, v in (("critical_hours", critical_hours), ("high_hours", high_hours),
                              ("medium_hours", medium_hours), ("low_hours", low_hours))
            if v is not None}
    if reset and body:
        raise click.UsageError("--reset cannot be combined with hour options.")
    if not reset and not body:
        raise click.UsageError("Give at least one --<severity>-hours option, or --reset.")
    if reset:
        body = {"reset": True}
    client = _client(ctx)
    try:
        data = client.put("alerts/sla-policy", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    for k, v in body.items():
        if k != "reset" and data.get(k) != v:
            click.echo(f"ERROR: {k} was NOT applied — requested {v}, still {data.get(k)}",
                       err=True)
            sys.exit(1)
    _print_sla_policy(ctx, data)


@alerts.command(name="reachability-queue")
@click.option("--repository", "repository", required=True, metavar="REPO_KEY",
              help="⛔ REQUIRED. The repo:<host>/<org>/<repo> key of the checkout you are "
                   "asking from. It is the SCOPE, not a filter: every row returned is a "
                   "finding bound to this repository by its own key, so an answer measured "
                   "here cannot move an item in another repository.")
@click.option("--commit", "commit", default=None, metavar="SHA",
              help="⭐ The commit you hold. Items already measured at it are omitted, so the "
                   "answer becomes 'what do I still owe' rather than 'what could be "
                   "measured'. Same (alert, commit) key the write path dedups on.")
@click.option("--limit", "limit", default=100, type=click.IntRange(1, 100),
              help="Cap per list, not per response (default 100).")
@click.option("--include-measured", is_flag=True, default=False,
              help="Also list items already measured at --commit (a fix planner needs every open member).")
@click.option("--pkg-offset", default=0, type=click.IntRange(min=0),
              help="Skip this many package rows (page with the response's next_pkg_offset).")
@click.option("--code-offset", default=0, type=click.IntRange(min=0),
              help="Skip this many code findings (page with the response's next_code_offset).")
@click.option("--as-findings", is_flag=True, default=False,
              help="Page the package list to the end and print ONLY a JSON array of {ecosystem, package, "
                   "installed, fixed, alert_id}, one per member: remediation_plan.py's --findings input.")
@click.pass_context
def alerts_reachability_queue(ctx, repository, commit, limit, include_measured, pkg_offset, code_offset,
                              as_findings):
    """Which open items in one repository still need a code-reachability answer.

    Two lists, answered by two different analyses: `packages` asks "does this repository
    import the package at all" (an import scan over the tree) and `code_findings` asks "is
    this function reachable from an entry point" (a call graph over one file).

    A `packages` row is one (ecosystem, package, version) with every member `alert_ids` it
    answers for — the question has one answer however many CVEs are open against it.

    ⛔ An Inbox ENTRY ("Upgrade litellm to 1.88.6") is deliberately not listed. It groups every
    place the package appears — on the demo tenant, 226 members across 12 repositories — so no
    single checkout can answer it. Entries still move: the ranking derives an entry's position
    from its members, so lowering the members lowers the entry.

    Pair it with `torana alert <id> reachability` to write each answer back.

    \b
    Examples:
      torana alerts reachability-queue --repository repo:github.com/acme/api --commit $(git rev-parse HEAD)
      torana alerts reachability-queue --repository repo:github.com/acme/api --commit $(git rev-parse HEAD) --format json
      torana alerts reachability-queue --repository repo:github.com/acme/api --include-measured --as-findings > findings.json
    """  # noqa: E501 — Click renders a \b block verbatim, so an example must not be wrapped
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {"limit": limit, "repository": repository, "pkg_offset": pkg_offset, "code_offset": code_offset}
    if commit:
        params["commit"] = commit
    if include_measured:
        params["include_measured"] = "true"

    client = _client(ctx)
    try:
        if as_findings:
            click.echo(_json.dumps(queue_findings(client, params)))
            return
        data = client.get("alerts/reachability-queue", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


def queue_findings(client, params: dict) -> list:
    """Every package member of the queue, paged by `next_pkg_offset` to the end, as remediation_plan.py's
    findings: one `{ecosystem, package, installed, fixed, alert_id}` per member, `fixed` = the member's own
    target version (null when no fix is published). FIX_PR_SPEC.md § 3.4.6."""
    out, seen, params, warned = [], set(), {**params}, False
    while True:
        data = client.get("alerts/reachability-queue", params=params) or {}
        for p in data.get("packages") or []:
            members = p.get("members")
            if members is None:
                if not warned:
                    click.echo("WARNING: the server's queue carries no `members` (it predates FIX_PR_SPEC § 3.4.6): "
                               "every finding is emitted with fixed=null, so the planner sees no fix version. "
                               "Upgrade the platform before planning.", err=True)
                    warned = True
                members = [{"alert_id": a, "target_version": ""} for a in p.get("alert_ids") or []]
            for m in members:
                if m["alert_id"] in seen:
                    continue
                seen.add(m["alert_id"])
                out.append({"ecosystem": p.get("ecosystem"), "package": p.get("package_name"),
                            "installed": p.get("installed_version"), "fixed": m.get("target_version") or None,
                            "alert_id": m["alert_id"]})
        nxt = data.get("next_pkg_offset")
        if nxt is None or nxt <= params.get("pkg_offset", 0):
            return out
        params["pkg_offset"] = nxt


_hide_operator_commands()

# `alerts drill-down` keeps working with byte-identical output; `alerts cve` / `alerts cwe` replace it in the listing.
alerts_drill_down.hidden = True


def _hidden_alias(group, command, old_name):
    """Register `command` under its older spelling too, hidden from `--help`, so existing scripts keep working."""
    import copy
    alias = copy.copy(command)
    alias.name, alias.hidden = old_name, True
    group.add_command(alias, name=old_name)


_hidden_alias(alerts, alerts_inbox_correct, "inbox-correct")    # `alerts inbox-correct` is now `alerts correct`
