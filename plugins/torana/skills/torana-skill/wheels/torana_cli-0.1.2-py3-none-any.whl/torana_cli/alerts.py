"""torana alerts — alert management commands."""

import json as _json
import sys

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW, CollectionGroup
from torana_cli.output import output
from torana_cli.rules import _load_input_file

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 30),
    ("severity", "SEVERITY", 10),
    ("status", "STATUS", 12),
    ("fired", "FIRED", 16),
    ("assignee", "ASSIGNED TO", 24),
    ("rule_id", "RULE", 36),
]


def _assignee_label(item, name_cache=None):
    """Human label for who an alert is assigned to.

    Resolution order: stored display name → resolved name from name_cache →
    '<type>:<short-id>' fallback (e.g. 'agent:be2f5d91…'). '—' when unassigned.
    `name_cache` maps assigned_to UUID → resolved name (or None if lookup failed).
    """
    name = item.get("assignee_display_name")
    if name:
        return str(name)
    who = item.get("assigned_to")
    if not who:
        return "—"
    if name_cache and name_cache.get(who):
        return name_cache[who]
    kind = item.get("assignee_type") or "?"
    return f"{kind}:{str(who)[:8]}…"


def _resolve_assignee_names(client, items):
    """Resolve assignee UUIDs → human names for a page of alerts.

    Dedups by (type, id) so each distinct assignee costs at most one lookup:
    users via GET users/{id} (name|email), agents via GET agents/{id} (name).
    Failures are cached as None so the caller falls back to the UUID label and
    we never retry a bad id. Returns {assigned_to_uuid: name|None}.
    """
    cache = {}
    seen = set()
    for it in items:
        if not isinstance(it, dict):
            continue
        who = it.get("assigned_to")
        kind = (it.get("assignee_type") or "").lower()
        if not who or it.get("assignee_display_name"):
            continue
        key = (kind, who)
        if key in seen:
            continue
        seen.add(key)
        try:
            if kind == "user":
                row = client.get(f"users/{who}")
                cache[who] = row.get("name") or row.get("email")
            elif kind == "agent":
                row = client.get(f"agents/{who}")
                cache[who] = row.get("name")
            else:
                cache[who] = None
        except (APIError, AuthError):
            cache[who] = None  # degrade to UUID label; don't fail the list
    return cache


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)




def _as_json_value(raw, flag, expect):
    """Parse a JSON-typed CLI flag into the structure the API requires.

    These fields are list/object-typed server-side, so forwarding the raw string
    422s with "Input should be a valid list". Accepts JSON; for `list` also
    accepts a comma-separated string of scalars (the natural form for --tags).
    """
    if raw is None:
        return None
    text = str(raw).strip()
    if not text:
        return [] if expect == "list" else {}
    if text.startswith(("[", "{")):
        try:
            parsed = _json.loads(text)
        except ValueError as e:
            click.echo(f"ERROR: {flag} is not valid JSON: {e}", err=True)
            sys.exit(2)
    elif expect == "list":
        # Convenience for scalar lists like --tags a,b,c.
        parsed = [p.strip() for p in text.split(",") if p.strip()]
    else:
        click.echo(f"ERROR: {flag} must be a JSON object, e.g. '{{\"k\": \"v\"}}'.", err=True)
        sys.exit(2)

    if expect == "list" and not isinstance(parsed, list):
        click.echo(f"ERROR: {flag} must be a JSON array.", err=True)
        sys.exit(2)
    if expect == "object" and not isinstance(parsed, dict):
        click.echo(f"ERROR: {flag} must be a JSON object.", err=True)
        sys.exit(2)
    return parsed


@click.group(cls=CollectionGroup, singular="alert")
def alerts():
    """Manage and triage alerts (collection operations).

    \b
    Examples:
      torana alerts list
      torana alerts list --severity critical --state open
      torana alerts create --name "SSH Brute Force" ...

    \b
    Instance operations (get, status, assign, etc.) use the singular form:
      torana alert <UUID> get
      torana alert <UUID> status --status resolved
      torana alert <UUID> assign --assigned-to <user-id>
    """


def list_alerts_core(ctx, *, severity=None, state=None, status_filter=None, rule_id=None,
                     workspace_id=None, assigned_to=None, page=None, page_size=None,
                     limit=None, offset=None, fetch_all=False, resolve_names=True):
    """Shared alert-listing routine.

    Backs both `torana alerts list` (no workspace context) and
    `torana workspace <id> alerts list` (workspace_id pre-bound). Both forms are
    the same operation differing only by whether the workspace filter is set, so
    they MUST go through this one routine — never a parallel list path.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    # Accept both pagination conventions: --page/--page-size (native) and
    # --limit/--offset (alias). resolve_page() collapses them to (page, page_size).
    from torana_cli.pagination import resolve_page
    page, effective_page_size = resolve_page(
        page, page_size, limit, offset, default_page_size=settings.page_size
    )

    # The v2 alerts endpoint takes filters as a JSON `filters` query string
    # ({"field":{"operation":..,"value":..}}), NOT flat params like ?rule_id=X.
    # Flat params are silently ignored (this was the --rule-id bug). Build the
    # JSON filter map here. workspace_id/tenant_id ARE accepted as direct query
    # params by the endpoint, so workspace_id stays flat.
    import json as _json
    filters = {}
    # status (and the --state alias) accept a comma-separated list → in_list.
    status_val = status_filter or state
    if status_val:
        vals = [s.strip() for s in str(status_val).split(",") if s.strip()]
        filters["status"] = ({"operation": "in_list", "value": vals} if len(vals) > 1
                             else {"operation": "equals", "value": vals[0]})
    if severity:
        vals = [s.strip() for s in str(severity).split(",") if s.strip()]
        filters["severity"] = ({"operation": "in_list", "value": vals} if len(vals) > 1
                               else {"operation": "equals", "value": vals[0]})
    if rule_id:
        filters["rule_id"] = {"operation": "equals", "value": rule_id}
    if assigned_to:
        filters["assigned_to"] = {"operation": "equals", "value": assigned_to}

    params = {"page": page, "page_size": effective_page_size}
    if filters:
        params["filters"] = _json.dumps(filters)
    if workspace_id:
        params["workspace_id"] = workspace_id

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"page": page_num, "page_size": effective_page_size}
                p.update({k: v for k, v in params.items() if k not in ("page", "page_size")})
                data = client.get("api/v2/alerts", params=p)
                items = data.get("items", [])
                all_items.extend(items)
                if len(all_items) >= data.get("total", len(all_items)):
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items), "page": 1,
                      "page_size": len(all_items)}
        else:
            result = client.get("api/v2/alerts", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    items = result.get("items", [])

    # Resolve assignee UUIDs → names for the human-readable views only. The
    # extra lookups (deduped, one per distinct assignee) aren't worth it for
    # machine output, which keeps the raw assigned_to/assignee_type fields.
    name_cache = None
    if resolve_names and fmt in ("text", "table") and not raw:
        name_cache = _resolve_assignee_names(client, items)

    # Derive human "fired" and "assignee" columns, injected onto each item so
    # they render in text/table and are selectable via --fields; the raw
    # first_seen_at / assigned_to / assignee_type fields stay intact for JSON.
    from torana_cli.time_util import format_relative
    for item in items:
        if isinstance(item, dict):
            item["fired"] = format_relative(item.get("first_seen_at") or item.get("created_at"))
            item["assignee"] = _assignee_label(item, name_cache)

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@alerts.command(name="list")
@click.option("--severity", default=None,
              type=click.Choice(["low", "medium", "high", "critical"], case_sensitive=False),
              help="Filter by severity.")
@click.option("--state", default=None, help="Filter by state (e.g. open, closed, in_progress).")
@click.option("--rule-id", default=None, help="Filter by detection rule UUID.")
@click.option("--workspace-id", default=None, help="Filter by workspace UUID.")
@click.option("--assigned-to", default=None,
              help="Filter by assigned user — email address or user UUID. "
                   "An unrecognized value errors (422) rather than returning an empty list.")
@click.option("--status", "status_filter", default=None,
              help="Filter by status. Accepts comma-separated values, e.g. "
                   "'pending_remediation,escalated'. "
                   "Valid: open, triaging, awaiting_input, pending_remediation, "
                   "escalated, resolved, closed.")
@click.option("--page", default=None, type=int, help="Page number (1-indexed).")
@click.option("--page-size", default=None, type=int,
              help="Results per page (max 100). Alias of --limit.")
@click.option("--limit", default=None, type=int,
              help="Max results to return (alias of --page-size).")
@click.option("--offset", default=None, type=int,
              help="Results to skip (alias of (page-1)*page_size).")
@click.option("--all", "fetch_all", is_flag=True, default=False,
              help="Auto-paginate and return all results.")
@click.pass_context
def alerts_list(ctx, severity, state, status_filter, rule_id, workspace_id, assigned_to,
                page, page_size, limit, offset, fetch_all):
    """List alerts.

    \b
    Examples:
      torana alerts list --severity critical
      torana alerts list --status pending_remediation,escalated --assigned-to me@acme.com
      torana alerts list --format json | jq '.items[] | select(.severity == "critical")'
    """
    list_alerts_core(ctx, severity=severity, state=state, status_filter=status_filter,
                     rule_id=rule_id, workspace_id=workspace_id, assigned_to=assigned_to,
                     page=page, page_size=page_size, limit=limit, offset=offset,
                     fetch_all=fetch_all)


@alerts.command(name="create")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with request body. Use '-' for stdin.")
@click.option("--name", "name", default=None,
              help="Alert title, typically derived from the rule name. Required unless --file supplies it.")
@click.option("--description", "description", default=None, help="Detailed description of the security issue detected")
@click.option("--rule-id", "rule_id", default=None,
              help="ID of the rule that generated this alert. Required unless --file supplies it.")
@click.option("--workspace-id", "workspace_id", default=None,
              help="Workspace UUID the alert belongs to. Required unless --file supplies it — "
                   "the column is NOT NULL, so omitting it fails with a server 500.")
@click.option("--severity", "severity", type=click.Choice(["low", "medium", "high", "critical"], case_sensitive=False), default=None)
@click.option("--status", "status", type=click.Choice(["open", "triaging", "awaiting_input", "pending_remediation", "escalated", "resolved", "closed"], case_sensitive=False), default=None, help="Alert lifecycle status.")
@click.option("--assigned-to", "assigned_to", default=None, help="User or team assigned to investigate this alert")
@click.option("--rule-run-results", "rule_run_results", default=None,
              help="Query results that triggered this alert, as a JSON array "
                   "(e.g. '[{\"cve_id\": \"CVE-2024-1\"}]'). Required unless --file supplies it.")
@click.option("--labels", "labels", default=None,
              help="Key-value pairs for categorizing alerts, as a JSON object.")
@click.option("--tags", "tags", default=None,
              help="Tags for categorizing and routing alerts — JSON array or comma-separated.")
@click.pass_context
def alerts_create(ctx, name, description, rule_id, workspace_id, severity, status, assigned_to, rule_run_results, labels, tags, input_file):
    """Create Alert.

    \b
    Examples:
      torana alerts create --name "SSH brute force" --rule-id <RULE_ID> --severity high
      torana alerts create --file alert.yaml
      torana alerts create --name "Exposed bucket" --severity critical \
          --assigned-to <USER_ID> --status open
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "alerts"
    if input_file:
        body = _load_input_file(input_file)
    else:
        body = {}
        body["name"] = name
        if description is not None:
            body["description"] = description
        body["rule_id"] = rule_id
        if workspace_id is not None:
            body["workspace_id"] = workspace_id
        if severity is not None:
            body["severity"] = severity
        if status is not None:
            body["status"] = status
        if assigned_to is not None:
            body["assigned_to"] = assigned_to
        if rule_run_results is not None:
            # The API requires a LIST; forwarding the raw string 422s with
            # "Input should be a valid list". Parse the JSON the flag documents.
            body["rule_run_results"] = _as_json_value(
                rule_run_results, "--rule-run-results", expect="list")
        if labels is not None:
            body["labels"] = _as_json_value(labels, "--labels", expect="object")
        if tags is not None:
            body["tags"] = _as_json_value(tags, "--tags", expect="list")

    missing = [f for f in ("name", "rule_id", "workspace_id", "rule_run_results")
               if not body.get(f)]
    if missing:
        click.echo(
            "ERROR: missing required field(s): "
            + ", ".join("--" + f.replace("_", "-") for f in missing)
            + "\n       Supply them as flags, or provide all of them in --file.",
            err=True)
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alerts.command(name="filter")
@click.option("--filters", "filters", default={})
@click.option("--limit", "limit", type=int, default=100)
@click.option("--offset", "offset", type=int, default=0)
@click.pass_context
def alerts_filter(ctx, filters, limit, offset):
    """Get Alerts Filtered."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "alerts/filter"
    body = {}
    if filters is not None:
        body["filters"] = filters
    if limit is not None:
        body["limit"] = limit
    if offset is not None:
        body["offset"] = offset

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alerts.command(name="by-rule-by-rule-id")
@click.argument("RULE_ID", metavar="RULE_ID")
@click.pass_context
def alerts_by_rule_by_rule_id(ctx, rule_id):
    """Get Alerts By Rule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"alerts/by-rule/{rule_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alerts.command(name="by-suite-by-suite-id")
@click.argument("SUITE_ID", metavar="SUITE_ID")
@click.pass_context
def alerts_by_suite_by_suite_id(ctx, suite_id):
    """Get Alerts By Suite."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"alerts/by-suite/{suite_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ──────────────────────────────────────────────────────────────────────────
# Instance reads regrouped from `<noun>-by-<param>` leaves onto verbs
# (CLI Discoverability Contract, rule 2 — see ../CLAUDE.md). The route
# parameter belongs in the positional ARGUMENT, not the command name.
#
# Old flat names remain as HIDDEN aliases for ONE release (D4).
# ──────────────────────────────────────────────────────────────────────────


@alerts.group(name="suite-rule")
def alerts_suite_rule_grp():
    """Alerts for one rule within one suite.

    Examples:
      torana alerts suite-rule get --help
    """


@alerts_suite_rule_grp.command(name="get")
@click.argument("SUITE_ID", metavar="SUITE_ID")
@click.argument("RULE_ID", metavar="RULE_ID")
@click.pass_context
def alerts_rule_by_rule_id(ctx, suite_id, rule_id):
    """Get Alerts By Suite And Rule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"alerts/by-suite/{suite_id}/rule/{rule_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alerts.command(name="count")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--suite-id", "suite_id", default=None)
@click.option("--rule-id", "rule_id", default=None)
@click.pass_context
def alerts_count(ctx, suite_id, rule_id, page, page_size, fetch_all):
    """Get Alerts Count."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "alerts/count"
    params = {}
    if suite_id is not None:
        params["suite_id"] = suite_id
    if rule_id is not None:
        params["rule_id"] = rule_id
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@alerts.command(name="triage-agents")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def alerts_triage_agents(ctx, page, page_size, fetch_all):
    """List Triage Agents."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "alerts/triage/agents"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


# ---------------------------------------------------------------------------
# activities — standalone top-level command group
# ---------------------------------------------------------------------------

@click.group()
def activities():
    """Platform activity feed — what happened, across resources.

    \b
    Examples:
      torana activities list
      torana activities list --json --raw | jq '.[0]'
      torana activities list --help          filters (resource, actor, time window)
    """


@activities.command(name="list")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--vulnerability-id", "vulnerability_id", default=None,
              help="Only activities about ONE finding — its own timeline, alert or not.")
@click.pass_context
def activities_list(ctx, page, page_size, fetch_all, vulnerability_id):
    """List activities — the platform timeline.

    ⚠️ An activity's subject is an ALERT or a VULNERABILITY (T11 § 3.3.3). Without
    --vulnerability-id this lists both kinds interleaved.

    \b
    Examples:
      torana activities list
      torana activities list --vulnerability-id "gcp_ca_image:...@sha256:...
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "activities"
    effective_page_size = min(page_size or settings.page_size, 100)
    # ⛔ `offset`, NOT `skip` — the endpoint declares `offset` and IGNORES an unknown
    # `skip`, so every page silently returned PAGE ONE. Verified against the running
    # service: `?skip=1` and `?offset=0` returned an identical first row, while
    # `?offset=1` returned the next one. `--all` was affected too: the loop breaks on
    # `len(all_items) >= total`, and a list response makes total == the page size, so
    # it stopped after one page while reporting success.
    params = {"offset": (page - 1) * effective_page_size, "limit": effective_page_size}
    if vulnerability_id:
        params["vulnerability_id"] = vulnerability_id

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "offset": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@alerts.command(name="dispositions-summary")
@click.option("--workspace-id", default=None, help="Filter by workspace UUID (Signal B).")
@click.pass_context
def alerts_dispositions_summary(ctx, workspace_id):
    """Get alert disposition summary for a workspace.

    \b
    Example:
      torana alerts dispositions-summary --workspace-id <UUID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if workspace_id:
        params["workspace_id"] = workspace_id

    client = _client(ctx)
    try:
        data = client.get("alerts/dispositions/summary", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ──────────────────────────────────────────────────────────────────────────
# BACK-COMPAT — hidden aliases for the old `<noun>-by-<param>` names.
# ⏳ ONE RELEASE ONLY (decision D4). Delete this block next release.
# ──────────────────────────────────────────────────────────────────────────

_LEGACY_BY_PARAM_ALERTS = {
    "rule-by-rule-id": ("suite-rule", "get"),
}


def _register_legacy_alerts_by_param() -> None:
    """Old flat names, hidden so they cannot be discovered anew."""
    import copy
    for _old, (_sub, _verb) in _LEGACY_BY_PARAM_ALERTS.items():
        _grp = alerts.commands.get(_sub)
        if not isinstance(_grp, click.Group):
            continue
        _cmd = _grp.commands.get(_verb)
        if _cmd is None:
            continue
        # ⛔ Never let an alias overwrite a real group of the same name.
        if isinstance(alerts.commands.get(_old), click.Group):
            continue
        _alias = copy.copy(_cmd)
        _alias.name = _old
        _alias.hidden = True
        alerts.add_command(_alias)


_register_legacy_alerts_by_param()
