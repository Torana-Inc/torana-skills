"""torana alerts — alert management commands."""

import json as _json
import sys

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW, CollectionGroup
from torana_cli.output import output
from torana_cli.rules import _load_input_file

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 30),
    ("severity", "SEVERITY", 10),
    # The list is ORDERED by priority (lower is sooner), so the column that decides the
    # order has to be visible — otherwise the order looks arbitrary.
    ("triage_priority", "PRIO", 6),
    ("status", "STATUS", 12),
    ("fired", "FIRED", 16),
    # The newest meaningful change (not a rule pass that only re-saw it): what --sort newest|oldest orders by.
    ("last_activity_label", "LAST ACTIVITY", 16),
    ("assignee", "ASSIGNED TO", 24),
    # The rule's NAME (the API's `rule_name`); the raw id shows only with --wide, or in --json.
    ("rule_label", "RULE", 30),
    ("triage_verdict", "VERDICT", 15),
    # T-3 — whether the LAST triage attempt failed. Without it an alert whose triage
    # crashed reads exactly like one never triaged (verdict "—", triage_running False).
    ("triage", "TRIAGE", 18),
    # F-o01-2 — whether the deployment this TRUE POSITIVE relied on is still running.
    # ⛔ The verdict itself is unchanged; this column reports an observation, never a
    # re-decision. "—" covers both "still running" and "no record", which is why the
    # stale case spells itself out rather than relying on the column being non-empty.
    ("runtime", "RUNTIME", 22),
    ("reason_code", "REASON", 24),
    ("decided_by", "DECIDED BY", 14),
    # § 5.26 — what KIND of entry this is, in the rule's own words. Shown rather than
    # only filterable, because `--category posture` returning 139 rows is unreadable if
    # the rows do not say which of them are posture.
    ("category", "CATEGORY", 14),
    # How many findings a root clears (empty for a non-root and for a root that declares no
    # count: never "0").
    ("clears", "CLEARS", 7),
    # Phase 3 — which Inbox box the item is in, and who closed it. Both come from the
    # API; the CLI never works out a box itself.
    ("box", "BOX", 16),
    ("why_label", "WHY", 22),
    ("closed_by", "CLOSED BY", 24),
]


def _assignee_label(item, name_cache=None):
    """Human label for who an alert is assigned to.

    Resolution order: stored display name → resolved name from name_cache →
    '<type>:<short-id>' fallback (e.g. 'agent:be2f5d91…'). '—' when unassigned.
    `name_cache` maps assigned_to UUID → resolved name (or None if lookup failed).
    """
    name = item.get("assignee_display_name")
    if name:
        return str(name)
    who = item.get("assigned_to")
    if not who:
        return "—"
    if name_cache and name_cache.get(who):
        return name_cache[who]
    kind = item.get("assignee_type") or "?"
    return f"{kind}:{str(who)[:8]}…"


def _decider_label(item, name_cache=None):
    """Who reached this verdict, in one short column.

    The three deciders are deliberately distinguishable: a RULE stamped it from the
    ranking, the triage AGENT judged it, or a PERSON did. Before this the record could
    not tell them apart — the agent's service login made its verdicts read as an
    anonymous user's.
    """
    # The platform states the source itself (`verdict_source_label`); the derivation below is the fallback for a
    # server that does not.
    if item.get("verdict_source_label"):
        return item["verdict_source_label"]
    kind = (item.get("verdict_actor_type") or "").lower()
    who = item.get("verdict_actor_id") or ""
    if not kind:
        return ""
    if kind == "system":
        return "the ranking" if who.startswith("rule:") else "system"
    if kind == "agent":
        name = (name_cache or {}).get(("agent", who))
        return name or "triage agent"
    name = (name_cache or {}).get(("user", who))
    return name or (who[:8] if who else "a person")


def _resolve_assignee_names(client, items):
    """Resolve assignee UUIDs → human names for a page of alerts.

    Dedups by (type, id) so each distinct assignee costs at most one lookup:
    users via GET users/{id} (name|email), agents via GET agents/{id} (name).
    Failures are cached as None so the caller falls back to the UUID label and
    we never retry a bad id. Returns {assigned_to_uuid: name|None}.
    """
    cache = {}
    seen = set()
    for it in items:
        if not isinstance(it, dict):
            continue
        who = it.get("assigned_to")
        kind = (it.get("assignee_type") or "").lower()
        if not who or it.get("assignee_display_name"):
            continue
        key = (kind, who)
        if key in seen:
            continue
        seen.add(key)
        try:
            if kind == "user":
                row = client.get(f"users/{who}")
                cache[who] = row.get("name") or row.get("email")
            elif kind == "agent":
                row = client.get(f"agents/{who}")
                cache[who] = row.get("name")
            else:
                cache[who] = None
        except (APIError, AuthError):
            cache[who] = None  # degrade to UUID label; don't fail the list
    return cache


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)




def _as_json_value(raw, flag, expect):
    """Parse a JSON-typed CLI flag into the structure the API requires.

    These fields are list/object-typed server-side, so forwarding the raw string
    422s with "Input should be a valid list". Accepts JSON; for `list` also
    accepts a comma-separated string of scalars (the natural form for --tags).
    """
    if raw is None:
        return None
    text = str(raw).strip()
    if not text:
        return [] if expect == "list" else {}
    if text.startswith(("[", "{")):
        try:
            parsed = _json.loads(text)
        except ValueError as e:
            click.echo(f"ERROR: {flag} is not valid JSON: {e}", err=True)
            sys.exit(2)
    elif expect == "list":
        # Convenience for scalar lists like --tags a,b,c.
        parsed = [p.strip() for p in text.split(",") if p.strip()]
    else:
        click.echo(f"ERROR: {flag} must be a JSON object, e.g. '{{\"k\": \"v\"}}'.", err=True)
        sys.exit(2)

    if expect == "list" and not isinstance(parsed, list):
        click.echo(f"ERROR: {flag} must be a JSON array.", err=True)
        sys.exit(2)
    if expect == "object" and not isinstance(parsed, dict):
        click.echo(f"ERROR: {flag} must be a JSON object.", err=True)
        sys.exit(2)
    return parsed


@click.group(cls=CollectionGroup, singular="alert")
def alerts():
    """Manage and triage alerts (collection operations).

    \b
    Examples:
      torana alerts list
      torana alerts list --severity critical --state open
      torana alerts create --name "SSH Brute Force" ...

    \b
    Instance operations (get, status, assign, etc.) use the singular form:
      torana alert <UUID> get
      torana alert <UUID> status --status resolved
      torana alert <UUID> assign --assigned-to <user-id>
    """


def _full_workspace_id(workspace_id):
    """A workspace filter must be the full UUID. A prefix is compared as text and matches no row, so
    the list said "No results" for a workspace that has 151 (harness F2). Refuse it instead."""
    if workspace_id:
        import uuid as _uuid
        try:
            _uuid.UUID(str(workspace_id))
        except ValueError:
            raise click.UsageError(
                f"--workspace-id must be the full workspace id (a UUID), not {workspace_id!r}: a "
                "prefix matches nothing. Find it with `torana workspaces list`.")
    return workspace_id


#: The friendly action verbs → the `category_key` an entry carries for it (the platform's
#: remediation categories, GET /alerts/remediation-vocabulary `categories`).
ACTION_CATEGORY = {
    "upgrade": "upgrade", "roll_back": "roll_back", "mitigate": "mitigation",
    "mitigation": "mitigation", "fix": "fix_code", "fix_code": "fix_code",
    "configure": "configure", "rotate": "rotate_secret", "rotate_secret": "rotate_secret",
    "rebuild": "rebuild_image", "rebuild_image": "rebuild_image",
    "review": "review", "finding": "review",
}


def action_category_filter(action: str) -> dict:
    """The v2 filter for `--action` (comma-separated verbs); an unknown verb is passed through as a
    category key, so a kind the platform adds later still works."""
    raw = [v.strip().lower().replace("-", "_") for v in str(action).split(",") if v.strip()]
    vals = [ACTION_CATEGORY.get(v, v) for v in raw]
    return ({"operation": "in_list", "value": vals} if len(vals) > 1
            else {"operation": "equals", "value": vals[0]})


def _triage_label(tf):
    """The TRIAGE column: '—' unless the last triage attempt failed (API `triage_failure`)."""
    if not isinstance(tf, dict) or not tf.get("state"):
        return "—"
    tries = f"{tf.get('attempts')}/{tf.get('max_attempts')}"
    if tf["state"] == "failed":
        return f"FAILED {tries} ({tf.get('error_kind') or '?'})"
    return f"retrying {tries}"


_SORTS = {"newest": [{"field": "last_activity", "direction": "desc"}],
          "oldest": [{"field": "last_activity", "direction": "asc"}],
          "priority": [{"field": "triage_priority", "direction": "asc"}]}


def window_options(fn):
    """--since / --from / --to / --cve / --cwe: the scope options `alerts list` and `alerts boxes` share, so a count and
    its list ask the same question."""
    for opt in reversed([
        click.option("--since", "since", default=None,
                     type=click.Choice(["24h", "2d", "7d", "30d"], case_sensitive=False),
                     help="Only items with activity in the last 24h, 2d, 7d or 30d."),
        click.option("--from", "date_from", default=None, metavar="ISO",
                     help="Only items with last activity at or after this ISO 8601 time, e.g. 2026-10-01T08:00:00Z."),
        click.option("--to", "date_to", default=None, metavar="ISO",
                     help="Only items with last activity at or before this ISO 8601 time."),
        click.option("--cve", "cve", default=None, metavar="CVE-ID",
                     help="Only the entries holding a live finding for this CVE (and ungrouped findings for it)."),
        click.option("--cwe", "cwe", default=None, metavar="CWE-ID",
                     help="Only the entries holding a live finding with this CWE (the finding's own CWE)."),
    ]):
        fn = opt(fn)
    return fn


def time_options(fn):
    """--sort plus the window options, shared by `alerts list` and `workspace <id> alerts list`."""
    fn = window_options(fn)
    return click.option("--sort", "sort_by", default=None,
                        type=click.Choice(list(_SORTS), case_sensitive=False),
                        help="Order: newest or oldest LAST ACTIVITY (the newest meaningful change: a decision, "
                             "assignment, state change, member joined or left, comment or changed facts; a rule "
                             "pass that only re-saw the item is not one), or priority. Omitted: the Inbox's order.")(fn)


def _time_params(sort_by, since, date_from, date_to, cve=None, cwe=None):
    """The API's sort and time-window parameters; refuses the combinations the API would merge silently."""
    import json as _json
    if since and date_from:
        raise click.UsageError("--since and --from both set the start of the window: use one.")
    out = {}
    if sort_by:
        out["sort"] = _json.dumps(_SORTS[sort_by.lower()])
    if since:
        out["activity_within"] = since.lower()
    if date_from:
        out["activity_from"] = date_from
    if date_to:
        out["activity_to"] = date_to
    if cve:
        out["cve"] = cve.strip().upper()
    if cwe:
        out["cwe"] = cwe.strip().upper()
    return out


def list_alerts_core(ctx, *, severity=None, state=None, status_filter=None, rule_id=None,
                     workspace_id=None, assigned_to=None, page=None, page_size=None,
                     limit=None, offset=None, fetch_all=False, resolve_names=True,
                     group_role=None, decided_by=None, finding_severity=None, action=None,
                     category=None, boxes=None, why=None, verdict=None, inbox_rows=False,
                     include_members=False, reason=None,
                     runtime_stale=False, triage_failure=None, wide=False,
                     sort_by=None, since=None, date_from=None, date_to=None, cve=None, cwe=None):
    """Shared alert-listing routine.

    Backs both `torana alerts list` (no workspace context) and
    `torana workspace <id> alerts list` (workspace_id pre-bound). Both forms are
    the same operation differing only by whether the workspace filter is set, so
    they MUST go through this one routine — never a parallel list path.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    # Accept both pagination conventions: --page/--page-size (native) and
    # --limit/--offset (alias). resolve_page() collapses them to (page, page_size).
    from torana_cli.pagination import resolve_page
    page, effective_page_size = resolve_page(
        page, page_size, limit, offset, default_page_size=settings.page_size
    )

    # The v2 alerts endpoint takes filters as a JSON `filters` query string
    # ({"field":{"operation":..,"value":..}}), NOT flat params like ?rule_id=X.
    # Flat params are silently ignored (this was the --rule-id bug). Build the
    # JSON filter map here. workspace_id/tenant_id ARE accepted as direct query
    # params by the endpoint, so workspace_id stays flat.
    import json as _json
    filters = {}
    # status (and the --state alias) accept a comma-separated list → in_list.
    status_val = status_filter or state
    if status_val:
        vals = [s.strip() for s in str(status_val).split(",") if s.strip()]
        filters["status"] = ({"operation": "in_list", "value": vals} if len(vals) > 1
                             else {"operation": "equals", "value": vals[0]})
    if severity:
        vals = [s.strip() for s in str(severity).split(",") if s.strip()]
        filters["severity"] = ({"operation": "in_list", "value": vals} if len(vals) > 1
                               else {"operation": "equals", "value": vals[0]})
    # Fix-grain WP4 — one row per ACTION instead of one per finding. ⚠️ This goes through
    # the v2 `filters` map like every other filter here, which is why `group_role` had to
    # join v2's FIELDS: an unknown field there is a 400, not an ignored parameter.
    if group_role:
        filters["group_role"] = {"operation": "equals", "value": group_role}
    # `--inbox-rows` sends nothing: the list is entries only by default, which is exactly what
    # the Inbox lists, so there is no `top_level` filter to send (the platform is removing it).
    # WHO decided: 'system' (a rule declared it), 'agent' or 'user'. Comma-separated
    # becomes in_list, matching --status/--severity above.
    if decided_by:
        vals = [s.strip().lower() for s in str(decided_by).split(",") if s.strip()]
        filters["verdict_actor_type"] = (
            {"operation": "in_list", "value": vals} if len(vals) > 1
            else {"operation": "equals", "value": vals[0]})
    # A4 — the FINDING's severity, not the rule's. `--severity` filters the rule's,
    # which is one value per rule, so it cannot narrow a single rule's output at all.
    if finding_severity:
        vals = [s.strip().title() for s in str(finding_severity).split(",") if s.strip()]
        filters["finding_severity"] = (
            {"operation": "in_list", "value": vals} if len(vals) > 1
            else {"operation": "equals", "value": vals[0]})
    # A8 — the KIND of action, as the entry's `category_key`: that is where a platform entry holds
    # its action (its entity_type is the generic `inbox_entry`), and a rule-owned root carries the
    # same key beside its entity_type, so ONE filter on the key finds both.
    if action:
        if category:
            raise click.UsageError("--action and --category both filter the entry kind: "
                                   "use one (--action takes the friendly verbs).")
        filters["category_key"] = action_category_filter(action)
    # § 5.26 — the rule-declared entry kind. No verb map here, deliberately: `--action`
    # needs one because its three values are the platform's guess at one app's
    # vocabulary, and this is whatever the RULE declared, so translating it would put the
    # same words back in the platform.
    if category:
        vals = [s.strip().lower() for s in str(category).split(",") if s.strip()]
        filters["category_key"] = ({"operation": "in_list", "value": vals} if len(vals) > 1
                                   else {"operation": "equals", "value": vals[0]})
    # The box model — why it is closed, and the verdict. Together they list the signal
    # the platform counts: a true positive a person closed as false positive.
    # F-o01-2 — one boolean the API resolves, so the CLI, the inbox and the API ask the
    # SAME question rather than three spellings of it.
    if runtime_stale:
        filters["verdict_runtime_stale"] = {"operation": "equals", "value": True}
    # T-3 — the last triage attempt failed: `failed` (dead-lettered), `retrying`, or `any`.
    if triage_failure:
        vals = [s.strip().lower() for s in str(triage_failure).split(",") if s.strip()]
        if "any" in vals:
            filters["triage_failure"] = {"operation": "is_not_null", "value": None}
        else:
            filters["triage_failure"] = ({"operation": "in_list", "value": vals} if len(vals) > 1
                                         else {"operation": "equals", "value": vals[0]})
    for key, raw_val in (("why", why), ("triage_verdict", verdict),
                         ("resolution_reason", reason)):
        if raw_val:
            vals = [s.strip().lower() for s in str(raw_val).split(",") if s.strip()]
            filters[key] = ({"operation": "in_list", "value": vals} if len(vals) > 1
                            else {"operation": "equals", "value": vals[0]})
    if rule_id:
        filters["rule_id"] = {"operation": "equals", "value": rule_id}
    if assigned_to:
        filters["assigned_to"] = {"operation": "equals", "value": assigned_to}

    params = {"page": page, "page_size": effective_page_size}
    if filters:
        params["filters"] = _json.dumps(filters)
    # Phase 3 — repeatable `box` query parameter; the API filters its stored column.
    if boxes:
        params["box"] = [b.lower() for b in boxes]
    if workspace_id:
        params["workspace_id"] = _full_workspace_id(workspace_id)
    if include_members:
        params["include_members"] = "true"
    params.update(_time_params(sort_by, since, date_from, date_to, cve, cwe))

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"page": page_num, "page_size": effective_page_size}
                p.update({k: v for k, v in params.items() if k not in ("page", "page_size")})
                data = client.get("api/v2/alerts", params=p)
                items = data.get("items", [])
                all_items.extend(items)
                if len(all_items) >= data.get("total", len(all_items)):
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items), "page": 1,
                      "page_size": len(all_items)}
        else:
            result = client.get("api/v2/alerts", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    items = result.get("items", [])

    # Resolve assignee UUIDs → names for the human-readable views only. The
    # extra lookups (deduped, one per distinct assignee) aren't worth it for
    # machine output, which keeps the raw assigned_to/assignee_type fields.
    name_cache = None
    if resolve_names and fmt in ("text", "table") and not raw:
        name_cache = _resolve_assignee_names(client, items)

    # Derive human "fired" and "assignee" columns, injected onto each item so
    # they render in text/table and are selectable via --fields; the raw
    # first_seen_at / assigned_to / assignee_type fields stay intact for JSON.
    from torana_cli.time_util import format_relative
    for item in items:
        if isinstance(item, dict):
            item["rule_label"] = item.get("rule_name") or item.get("rule_id") or "—"
            item["fired"] = format_relative(item.get("first_seen_at") or item.get("created_at"))
            item["assignee"] = _assignee_label(item, name_cache)
            # WHO decided this verdict. The raw columns stay intact for JSON; this is the
            # human column, because "true_positive" without a decider is half the record.
            item["decided_by"] = _decider_label(item, name_cache)
            # § 5.26 — the LABEL for the column, the key for `--category`. Falling back
            # to the key keeps a row readable if a rule declared a key and an empty
            # label; falling back to the raw columns keeps JSON output unchanged.
            item["category"] = item.get("category_label") or item.get("category_key")
            # How many findings a root clears, from the platform's one number. EMPTY when the
            # rule declares no count (never "0": that would say the fix clears nothing).
            _fc = item.get("findings_cleared")
            item["clears"] = "" if _fc is None else str(_fc)
            # Who closed it, as the API words it ("The agent", "The data", a person).
            item["closed_by"] = item.get("closed_by_display_name") or "—"
            # Why it is closed, as the API words it ("Closed: accepted risk").
            item["why_label"] = item.get("why_label") or "—"
            # F-o01-2 — read the API's DERIVED `verdict_runtime_stale`, never
            # `stale_at` directly: the derived one is already gated on the alert being
            # a true positive, so a stale flag left on a row whose verdict changed
            # cannot show here.
            _stale_since = (item.get("verdict_runtime_stale_at") or "")[:10]
            item["runtime"] = (f"stale since {_stale_since}"
                               if item.get("verdict_runtime_stale") else "—")
            item["triage"] = _triage_label(item.get("triage_failure"))
            # An unjudged alert is the common case; render it as an em dash like the
            # assignee column rather than a column of the literal word "None".
            for _k in ("triage_verdict", "reason_code", "triage_priority", "category"):
                if item.get(_k) in (None, ""):
                    item[_k] = "—"

    cols = list(_LIST_COLS)
    if wide:
        at = next(i for i, c in enumerate(cols) if c[0] == "rule_label") + 1
        cols.insert(at, ("rule_id", "RULE ID", 36))
    output(result, fmt=fmt, raw=raw, fields=fields, columns=cols)


@alerts.command(name="list")
@click.option("--severity", default=None,
              type=click.Choice(["low", "medium", "high", "critical"], case_sensitive=False),
              help="Filter by severity.")
@click.option("--state", default=None, help="Filter by state (e.g. open, closed, in_progress).")
@click.option("--rule-id", default=None, help="Filter by detection rule UUID.")
@click.option("--workspace-id", default=None, help="Filter by workspace UUID.")
@click.option("--assigned-to", default=None,
              help="Filter by assigned user — email address or user UUID. "
                   "An unrecognized value errors (422) rather than returning an empty list.")
@click.option("--status", "status_filter", default=None,
              help="Filter by status. Accepts comma-separated values, e.g. "
                   "'pending_remediation,escalated'. "
                   "Valid: open, triaging, awaiting_input, pending_remediation, "
                   "escalated, resolved, closed.")
@click.option("--page", default=None, type=int, help="Page number (1-indexed).")
@click.option("--page-size", default=None, type=int,
              help="Results per page (max 100). Alias of --limit.")
@click.option("--limit", default=None, type=int,
              help="Max results to return (alias of --page-size).")
@click.option("--offset", default=None, type=int,
              help="Results to skip (alias of (page-1)*page_size).")
@click.option("--roots-only", "roots_only", is_flag=True, default=False,
              help="Only the alerts that stand for an ACTION (one per fix), not the "
                   "findings they clear.")
@click.option("--decided-by", "decided_by", default=None,
              help="Who decided the verdict: system (a rule declared it), agent or "
                   "user. Comma-separated for several.")
@click.option("--finding-severity", "finding_severity", default=None,
              help="Severity of the matched FINDING (critical/high/medium/low). "
                   "Distinct from --severity, which is the RULE's and is one value "
                   "per rule. Comma-separated for several.")
@click.option("--action", "action", default=None,
              help="What KIND of action: upgrade, roll_back, mitigate, fix, configure, rotate, "
                   "rebuild or review (the platform's list: `torana alerts remediation-vocabulary`). "
                   "Comma-separated for several. ('mitigate' means no fix exists.)")
@click.option("--category", "category", default=None,
              help="The rule-declared entry kind, e.g. posture. Comma-separated for "
                   "several. This is the KEY, not the label on the chip: the key is "
                   "stable, the label is prose the rule may reword.")
@click.option("--box", "boxes", multiple=True,
              type=click.Choice(["needs_attention", "closed"],
                                case_sensitive=False),
              help="Inbox box, repeatable: needs_attention, closed. Omitted "
                   "means All. The box is worked out by the platform, the same answer "
                   "the Inbox shows. Work that moved to another entry is in closed (why: moved).")
@click.option("--why", "why", default=None,
              help="Why a closed item is closed: fixed, accepted_risk, wont_fix, "
                   "duplicate, false_positive, benign (a person's reason), closed, or "
                   "moved. Comma-separated for several.")
@click.option("--verdict", "verdict", default=None,
              help="The verdict: true_positive, false_positive, benign, inconclusive. "
                   "Comma-separated for several.")
@click.option("--reason", "reason", default=None,
              help="The exact closing reason: a person's (fixed, accepted_risk, wont_fix, "
                   "duplicate, false_positive, benign) or the platform's (closed_at_source, "
                   "dismissed_at_source, no_longer_reported, no_longer_deployed, below_policy, "
                   "rerouted, ...). Comma-separated for several.")
@click.option("--inbox-rows", "inbox_rows", is_flag=True, default=False,
              help="No longer needed: the list shows ENTRIES (roots and ungrouped items) by "
                   "default, exactly what the Inbox lists. Kept so existing scripts still work. "
                   "Not the same as --roots-only, which is one row per fix.")
@click.option("--include-members", "include_members", is_flag=True, default=False,
              help="Also list the members that belong inside an entry (diagnostics). A member "
                   "is normally seen only through `torana alert <entry-id> members`.")
@click.option("--runtime-stale", "runtime_stale", is_flag=True, default=False,
              help="Only true positives whose relied-on deployment is no longer running "
                   "(verdict unchanged).")
@click.option("--triage-failure", "triage_failure", default=None,
              help="Only alerts whose LAST triage attempt failed: failed (dead-lettered, "
                   "will not retry on its own), retrying, or any. Comma-separated for "
                   "several.")
@click.option("--wide", "wide", is_flag=True, default=False,
              help="Also show the rule's id next to its name (--format json always carries both).")
@click.option("--all", "fetch_all", is_flag=True, default=False,
              help="Auto-paginate and return all results.")
@time_options
@click.pass_context
def alerts_list(ctx, severity, state, status_filter, rule_id, workspace_id, assigned_to,
                page, page_size, limit, offset, roots_only, decided_by, finding_severity,
                action, category, boxes, why, verdict, reason, runtime_stale, inbox_rows,
                include_members, triage_failure, wide, fetch_all, sort_by, since, date_from, date_to, cve, cwe):
    """List alerts.

    \b
    Examples:
      torana alerts list --severity critical
      torana alerts list --status pending_remediation,escalated --assigned-to me@acme.com
      torana alerts list --format json | jq '.items[] | select(.severity == "critical")'
      torana alerts list --roots-only        # one row per FIX, not per finding
      torana alerts list --decided-by system # everything the ranking decided
      torana alerts list --decided-by agent,user
      torana alerts list --box closed                  # everything closed
      torana alerts list --box needs_attention --inbox-rows --all
                                                       # exactly the Inbox's rows
      torana alerts list --why false_positive --verdict true_positive
                                                       # true positives closed as FP
      torana alerts list --box closed --reason closed_at_source
                                                       # closed because the source fixed it
      torana alerts list --workspace-id <UUID> --triage-failure failed
                                                       # triage dead-lettered: needs a person
      torana alerts list --sort newest --since 2d      # what changed in the last two days, newest first
      torana alerts list --from 2026-10-01T00:00:00Z --to 2026-10-03T00:00:00Z --sort oldest
      torana alerts list --cve CVE-2026-33845          # the entries holding a live finding for that CVE
      torana alerts list --cwe CWE-89 --box needs_attention
    """
    list_alerts_core(ctx, severity=severity, state=state, status_filter=status_filter,
                     rule_id=rule_id, workspace_id=workspace_id, assigned_to=assigned_to,
                     page=page, page_size=page_size, limit=limit, offset=offset,
                     fetch_all=fetch_all, decided_by=decided_by,
                     finding_severity=finding_severity, action=action, category=category,
                     boxes=boxes, why=why, verdict=verdict, inbox_rows=inbox_rows,
                     include_members=include_members, reason=reason,
                     runtime_stale=runtime_stale, triage_failure=triage_failure, wide=wide,
                     sort_by=sort_by, since=since, date_from=date_from, date_to=date_to, cve=cve, cwe=cwe,
                     group_role="root" if roots_only else None)


@alerts.command(name="boxes")
@click.option("--workspace-id", default=None, help="Count one workspace's items.")
@click.option("--inbox-rows", "inbox_rows", is_flag=True, default=False,
              help="No longer needed: the counts are over ENTRIES (roots and ungrouped items) "
                   "by default, the rows `alerts list` shows. Kept for existing scripts.")
@click.option("--include-members", "include_members", is_flag=True, default=False,
              help="Count members too (diagnostics).")
# ⚠️ The old name, kept so existing scripts still count the same rows. On `alerts list`
# --roots-only means one row per FIX, a different population, hence the new name here.
@click.option("--roots-only", "roots_only", is_flag=True, default=False, hidden=True)
@window_options
@click.pass_context
def alerts_boxes(ctx, workspace_id, inbox_rows, include_members, roots_only, since, date_from, date_to, cve, cwe):
    """How many items are in each Inbox box, and the app's own population.

    The counts come from the platform (GET /api/v2/alerts/facet-counts), the same
    numbers the Inbox shows on its tabs. Work that moved to another entry is counted in Closed.

    \b
    ⛔ TWO DIFFERENT NUMBERS, AND THEY COUNT DIFFERENT THINGS:
      · `All` is the three boxes added up — how many ITEMS the Inbox holds for this scope.
      · the population line is the APP's own, when the app declared one: how many
        FINDINGS the app is about, counted in the datalake. It is not the sum of the
        boxes and must never be added to them.
    The population is counted after each rule run rather than on demand, so it carries
    when it was counted, and says so when a rule has run since.

    \b
    Examples:
      torana alerts boxes
      torana alerts boxes --workspace-id <UUID> --inbox-rows
      torana alerts boxes --cve CVE-2026-33845          # the counts for one CVE, the same entries `alerts list --cve` shows
      torana alerts boxes --since 2d                    # the counts for what changed in the last two days
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    params = {}
    if workspace_id:
        params["workspace_id"] = _full_workspace_id(workspace_id)
    if include_members:
        params["include_members"] = "true"
    params.update(_time_params(None, since, date_from, date_to, cve, cwe))
    client = _client(ctx)
    try:
        data = client.get("api/v2/alerts/facet-counts", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    boxes = (data or {}).get("boxes") or {}
    signals = (data or {}).get("signals") or {}
    population = (data or {}).get("population") or None
    labels = {"needs_attention": "Needs attention", "closed": "Closed"}
    rows = [{"box": k, "label": labels[k], "count": int(boxes.get(k, 0))}
            for k in ("needs_attention", "closed")]
    fp_on_tp = int(signals.get("closed_false_positive_while_true_positive", 0))
    if fmt == "text" and not fields:
        for r in rows:
            click.echo(f"{r['label']:<16} {r['count']}")
        click.echo(f"{'All':<16} {sum(r['count'] for r in rows)}")
        if population:
            # ⚠️ Printed on its own line, under the app's OWN word for a row, and never
            # folded into the table above: it counts findings in the datalake, while the
            # table counts items in the Inbox. Two numbers, two populations.
            n = population.get("count")
            label = (population.get("label_singular") if n == 1
                     else population.get("label")) or "items"
            when = str(population.get("counted_at") or "")[:16].replace("T", " ")
            note = f"as of {when}" if when else "time not recorded"
            if population.get("stale"):
                # A rule has run since the count, so the estate may have moved. Said
                # plainly rather than hidden — the number is still the best one we have.
                note += "; a rule has run since, so this may be behind"
            click.echo("")
            click.echo(f"The app counts {n:,} {label} ({note})")
        click.echo("")
        click.echo(f"Closed as false positive while true positive: {fp_on_tp}")
        # T-3 — open items whose last triage attempt failed. `failed` will not retry on
        # its own and needs a person; `retrying` is the platform still at it.
        click.echo(f"Triage failed (will not retry): {int(signals.get('triage_failed', 0))}"
                   f"   ·   retrying: {int(signals.get('triage_retrying', 0))}")
        return
    # ⛔ `len(rows)` WAS 3 — the number of BOXES, printed under a key every other
    # command uses for a number of items. A script reading `total` got 3 beside an `All`
    # of 11. The total is the items the Inbox can LIST, which is what the platform now
    # returns; the moved count stays visible in `items`.
    output({"items": rows, "total": int((data or {}).get("total") or 0),
            "boxes_shown": len(rows), "signals": signals,
            "population": population}, fmt=fmt, fields=fields)


@alerts.command(name="reconcile-owners")
@click.option("--tenant", "tenant_id", default=None,
              help="Operator (super admin profile) only: repair this tenant instead of your own.")
@click.option("--workspace-id", default=None, help="Repair one workspace's items only.")
@click.option("--apply", "apply_changes", is_flag=True, default=False,
              help="Make the changes. Without it this is a DRY RUN that only counts.")
@click.pass_context
def alerts_reconcile_owners(ctx, tenant_id, workspace_id, apply_changes):
    """Repair who owns items, through the platform: a dry run unless --apply.

    Confirmed items (and open status summaries) that nobody useful holds go to the tenant
    admin. Items that are not confirmed but hold an assignee that is not a person (free
    text such as "classie", an address from another tenant) go back to the triage agent
    when they are undecided and routed to triage, otherwise they are unassigned. Each
    change writes an activity saying why. A person's own assignment is never replaced.

    \b
    Examples:
      torana alerts reconcile-owners
      torana alerts reconcile-owners --workspace-id <UUID> --apply
      TORANA_PROFILE=SA torana alerts reconcile-owners --tenant <tenant UUID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    body = {"dry_run": not apply_changes}
    if tenant_id:
        body["tenant_id"] = tenant_id
    if workspace_id:
        body["workspace_id"] = _full_workspace_id(workspace_id)
    client = _client(ctx)
    try:
        data = client.post("api/v1/alerts/reconcile-owners", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields)


def reconcile_sla_body(tenant_id, workspace_id, apply_changes) -> dict:
    """The request body of `alerts reconcile-sla` (a dry run unless applied)."""
    body = {"dry_run": not apply_changes}
    if tenant_id:
        body["tenant_id"] = tenant_id
    if workspace_id:
        body["workspace_id"] = _full_workspace_id(workspace_id)
    return body


@alerts.command(name="reconcile-sla")
@click.option("--tenant", "tenant_id", default=None,
              help="Operator (super admin profile) only: repair this tenant instead of your own.")
@click.option("--workspace-id", default=None, help="Repair one workspace's items only.")
@click.option("--apply", "apply_changes", is_flag=True, default=False,
              help="Make the changes. Without it this is a DRY RUN that only counts.")
@click.pass_context
def alerts_reconcile_sla(ctx, tenant_id, workspace_id, apply_changes):
    """Bring every open item's SLA deadline to what the rules now say: a dry run unless --apply.

    A deadline is corrected when a signal for its item is processed or an entry's member
    changes, and an unchanged row sends no signal, so items that predate a rule change would
    never heal. This pass heals them. An open item with no deadline gets its raised time plus
    the hours for the worse of its rule's and its finding's severity (it may already be past:
    it is overdue). An item still on its original deadline for the rule's severity, whose
    finding is worse, is shortened. A reopened or already-corrected deadline is left alone.
    Each open entry then takes the earliest deadline of its open members. A second run
    changes nothing. The output counts each kind and samples up to 20 changes.

    \b
    Examples:
      torana alerts reconcile-sla
      torana alerts reconcile-sla --workspace-id <UUID> --apply
      TORANA_PROFILE=SA torana alerts reconcile-sla --tenant <tenant UUID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    body = reconcile_sla_body(tenant_id, workspace_id, apply_changes)
    client = _client(ctx)
    try:
        data = client.post("api/v1/alerts/reconcile-sla", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields)


@alerts.command(name="regroup")
@click.option("--tenant", "tenant_id", default=None,
              help="Operator (super admin profile) only: regroup this tenant instead of your own.")
@click.option("--workspace-id", default=None, help="Only this workspace's members.")
@click.option("--rule-id", default=None, help="Only the members this rule raised.")
@click.option("--limit", default=500, show_default=True,
              help="Members examined per server call. The command pages through ALL members "
                   "itself (keyset cursor); a smaller page keeps each call inside the request "
                   "timeout when --apply is moving members.")
@click.option("--apply", "apply_changes", is_flag=True, default=False,
              help="Make the changes. Without it this is a DRY RUN that only reports.")
@click.pass_context
def alerts_regroup(ctx, tenant_id, workspace_id, rule_id, limit, apply_changes):
    """Regroup members after a grouping-policy change: a dry run unless --apply.

    Recomputes each platform-managed member's entry key under today's policy (the remediation
    registry's key for a remediation member, the rule's current declared title for a situation
    member) and moves the members whose key differs. Each move writes an activity on both
    sides, recomputes both entries, and closes an entry left with no open member. A person's
    move or split is never undone.

    \b
    Examples:
      torana alerts regroup
      torana alerts regroup --rule-id <UUID> --apply
      TORANA_PROFILE=SA torana alerts regroup --tenant <tenant UUID> --apply
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    body = {"dry_run": not apply_changes, "limit": limit}
    if tenant_id:
        body["tenant_id"] = tenant_id
    if workspace_id:
        body["workspace_id"] = _full_workspace_id(workspace_id)
    if rule_id:
        body["rule_id"] = rule_id
    client = _client(ctx)
    # ⛔ ONE CALL EXAMINES ONLY `limit` MEMBERS, so this pages by cursor until the server says
    # nothing remains. A single call used to look at the same first page every time, so members
    # beyond it were never reached (review M2).
    totals = {"dry_run": not apply_changes, "checked": 0, "to_move": 0, "moved": 0, "failed": 0,
              "pinned_kept": 0, "in_foreign_entry": 0, "entries_to_create": 0, "to_categorise": 0, "categorised": 0,
              "remaining": False, "pages": 0, "sample": []}
    try:
        while True:
            data = client.post("api/v1/alerts/regroup", json=body)
            totals["pages"] += 1
            for k in ("checked", "to_move", "moved", "failed", "pinned_kept", "in_foreign_entry", "entries_to_create",
                      "to_categorise", "categorised"):
                totals[k] += int(data.get(k) or 0)
            if not totals["sample"]:
                totals["sample"] = data.get("sample") or []
            totals["remaining"] = bool(data.get("remaining"))
            cursor = data.get("next_after_id")
            if cursor:
                totals["last_after_id"] = cursor
            if not (data.get("remaining") and cursor) or cursor == body.get("after_id"):
                break
            body["after_id"] = cursor
    except APIError as e:
        # A failure mid-run leaves earlier pages applied: say how far it got and where to resume.
        click.echo(f"regroup stopped after {totals['pages']} page(s): checked {totals['checked']}, "
                   f"moved {totals['moved']}, failed {totals['failed']}. Resume with the cursor "
                   f"{body.get('after_id') or '(none: the first page failed)'}.", err=True)
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if totals["pages"] > 1 and not apply_changes:
        # Each page counts the new entries ITS moves would create; a key seen on several pages is
        # counted once per page, so over several pages this is an upper bound.
        totals["entries_to_create_is_upper_bound"] = True
    output(totals, fmt=fmt, fields=fields)


@alerts.command(name="kinds")
@click.option("--workspace-id", default=None, help="Count one workspace's items.")
@click.option("--inbox-rows", "inbox_rows", is_flag=True, default=False,
              help="Count the rows the Inbox lists (same population as `alerts boxes "
                   "--inbox-rows`).")
@click.pass_context
def alerts_kinds(ctx, workspace_id, inbox_rows):
    """What KIND of thing each open item is: its category and where its finding lives.

    The counts come from the platform (GET /api/v2/alerts/facet-counts, `open_by_kind`):
    open means any status other than closed. PLACE is read from the item's key:

    \b
      code        a finding in source code, in a repository
      repository  a package finding in a repository's dependencies
      image       a package finding on a container image
      other       a finding whose key names no recognised place
    An upgrade, mitigation or posture note the app proposes is not a finding and has
    no place; those are counted separately under "Not findings".

    \b
    Examples:
      torana alerts kinds --workspace-id <UUID>
      torana alerts kinds --workspace-id <UUID> --inbox-rows --format json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    params = {}
    if workspace_id:
        params["workspace_id"] = workspace_id
    if inbox_rows:
        params["top_level"] = "true"
    client = _client(ctx)
    try:
        data = client.get("api/v2/alerts/facet-counts", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    summary = (data or {}).get("open_by_kind")
    if summary is None:
        # An older platform without the dimension: say so rather than print zeros.
        click.echo("This platform does not report kinds yet (facet-counts has no "
                   "open_by_kind).", err=True)
        ctx.exit(1)
        return
    if fmt == "text" and not fields:
        click.echo(f"Open items: {summary.get('total', 0)}")
        click.echo("")
        click.echo("By category:")
        for k, n in (summary.get("by_category") or {}).items():
            click.echo(f"  {k:<16} {n}")
        click.echo(f"Open findings by place ({summary.get('findings', 0)} findings):")
        for k, n in (summary.get("by_place") or {}).items():
            click.echo(f"  {k:<16} {n}")
        click.echo("Open findings by category and place:")
        for r in summary.get("by_category_and_place") or []:
            click.echo(f"  {r['category_key'] or '-':<16} {r['place']:<12} {r['count']}")
        nf = summary.get("not_findings") or {}
        if nf.get("total"):
            # Not a place: an upgrade, mitigation or posture note the app proposes.
            parts = ", ".join(f"{k} {n}" for k, n in (nf.get("by_category") or {}).items())
            click.echo(f"Not findings (actions the app proposes, no place): {nf['total']} ({parts})")
        return
    output({"items": summary.get("by_category_and_place") or [],
            "total": int(summary.get("total") or 0),
            "by_category": summary.get("by_category") or {},
            "findings": int(summary.get("findings") or 0),
            "by_place": summary.get("by_place") or {},
            "not_findings": summary.get("not_findings") or {},
            "kinds": (data or {}).get("kinds") or []}, fmt=fmt, fields=fields)


@alerts.command(name="create")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with request body. Use '-' for stdin.")
@click.option("--name", "name", default=None,
              help="Alert title, typically derived from the rule name. Required unless --file supplies it.")
@click.option("--description", "description", default=None, help="Detailed description of the security issue detected")
@click.option("--rule-id", "rule_id", default=None,
              help="ID of the rule that generated this alert. Required unless --file supplies it.")
@click.option("--workspace-id", "workspace_id", default=None,
              help="Workspace UUID the alert belongs to. Required unless --file supplies it — "
                   "the column is NOT NULL, so omitting it fails with a server 500.")
@click.option("--severity", "severity", type=click.Choice(["low", "medium", "high", "critical"], case_sensitive=False), default=None)
@click.option("--status", "status", type=click.Choice(["open", "triaging", "awaiting_input", "pending_remediation", "escalated", "resolved", "closed"], case_sensitive=False), default=None, help="Alert lifecycle status.")
@click.option("--assigned-to", "assigned_to", default=None, help="User or team assigned to investigate this alert")
@click.option("--rule-run-results", "rule_run_results", default=None,
              help="Query results that triggered this alert, as a JSON array "
                   "(e.g. '[{\"cve_id\": \"CVE-2024-1\"}]'). Required unless --file supplies it.")
@click.option("--labels", "labels", default=None,
              help="Key-value pairs for categorizing alerts, as a JSON object.")
@click.option("--tags", "tags", default=None,
              help="Tags for categorizing and routing alerts — JSON array or comma-separated.")
@click.pass_context
def alerts_create(ctx, name, description, rule_id, workspace_id, severity, status, assigned_to, rule_run_results, labels, tags, input_file):
    """Create Alert.

    \b
    Examples:
      torana alerts create --name "SSH brute force" --rule-id <RULE_ID> --severity high
      torana alerts create --file alert.yaml
      torana alerts create --name "Exposed bucket" --severity critical \
          --assigned-to <USER_ID> --status open
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "alerts"
    if input_file:
        body = _load_input_file(input_file)
    else:
        body = {}
        body["name"] = name
        if description is not None:
            body["description"] = description
        body["rule_id"] = rule_id
        if workspace_id is not None:
            body["workspace_id"] = workspace_id
        if severity is not None:
            body["severity"] = severity
        if status is not None:
            body["status"] = status
        if assigned_to is not None:
            body["assigned_to"] = assigned_to
        if rule_run_results is not None:
            # The API requires a LIST; forwarding the raw string 422s with
            # "Input should be a valid list". Parse the JSON the flag documents.
            body["rule_run_results"] = _as_json_value(
                rule_run_results, "--rule-run-results", expect="list")
        if labels is not None:
            body["labels"] = _as_json_value(labels, "--labels", expect="object")
        if tags is not None:
            body["tags"] = _as_json_value(tags, "--tags", expect="list")

    missing = [f for f in ("name", "rule_id", "workspace_id", "rule_run_results")
               if not body.get(f)]
    if missing:
        click.echo(
            "ERROR: missing required field(s): "
            + ", ".join("--" + f.replace("_", "-") for f in missing)
            + "\n       Supply them as flags, or provide all of them in --file.",
            err=True)
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alerts.command(name="filter")
@click.option("--filters", "filters", default=None,
              help='JSON object: field -> value, or field -> {"operation": <op>, '
                   '"value": <v>}. A bare value means equals, a list means in_list. '
                   'e.g. \'{"severity": "critical"}\' or '
                   '\'{"severity": {"operation": "in_list", "value": ["critical", "high"]}}\'')
@click.option("--limit", "limit", type=int, default=100)
@click.option("--offset", "offset", type=int, default=0)
@click.pass_context
def alerts_filter(ctx, filters, limit, offset):
    """Get alerts matching a filter expression.

    ⛔ `--filters` IS JSON AND MUST BE PARSED HERE. It used to be passed through as the
    raw STRING click handed us, so the API saw `"{\\"severity\\": \\"critical\\"}"` where
    it required an object and answered `422 body -> filters: Input should be a valid
    dictionary` — for EVERY invocation, including correct ones. Measured on T1
    2026-10-04: the command had never returned a single alert. Found by running it, not
    by reading it; `tests/test_alerts_filter_json.py` is the regression.

    Examples:
      torana alerts filter --filters '{"severity": "critical"}'
      torana alerts filter --filters '{"status": {"operation": "in_list", "value": ["open", "escalated"]}}'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "alerts/filter"
    body = {}
    if filters is not None:
        if isinstance(filters, str):
            try:
                filters = _json.loads(filters)
            except _json.JSONDecodeError as exc:
                # ⚠️ Fail HERE with the offending text, not at the API. A JSON typo
                # otherwise comes back as a generic 422 about `filters` that says
                # nothing about which character was wrong.
                raise click.BadParameter(
                    f"--filters must be a JSON object: {exc}", param_hint="--filters")
        if not isinstance(filters, dict):
            raise click.BadParameter(
                f"--filters must be a JSON OBJECT, got {type(filters).__name__}",
                param_hint="--filters")
        body["filters"] = filters
    if limit is not None:
        body["limit"] = limit
    if offset is not None:
        body["offset"] = offset

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alerts.command(name="by-rule-by-rule-id")
@click.argument("RULE_ID", metavar="RULE_ID")
@click.pass_context
def alerts_by_rule_by_rule_id(ctx, rule_id):
    """Get Alerts By Rule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"alerts/by-rule/{rule_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alerts.command(name="by-suite-by-suite-id")
@click.argument("SUITE_ID", metavar="SUITE_ID")
@click.pass_context
def alerts_by_suite_by_suite_id(ctx, suite_id):
    """Get Alerts By Suite."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"alerts/by-suite/{suite_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ──────────────────────────────────────────────────────────────────────────
# Instance reads regrouped from `<noun>-by-<param>` leaves onto verbs
# (CLI Discoverability Contract, rule 2 — see ../CLAUDE.md). The route
# parameter belongs in the positional ARGUMENT, not the command name.
#
# Old flat names remain as HIDDEN aliases for ONE release (D4).
# ──────────────────────────────────────────────────────────────────────────


# ── Analyst drill-down: a CVE or CWE across the app's ranked findings ───────────────────────────────────────

@alerts.group(name="drill-down")
def alerts_drill_down():
    """What the platform holds about a CVE or a CWE across this app's ranked findings.

    A SUMMARY of the LIVE findings (open, not in a terminal state): counts, intel, breakdowns, what to look at, the ten
    most exposed instances and a weekly timeline. Blast radius and the upgrade delta are separate calls.

    \b
    Examples:
      torana alerts drill-down cve CVE-2026-33845 --workspace-id <WS_UUID>
      torana alerts drill-down cwe CWE-89 --workspace-id <WS_UUID>
      torana alerts drill-down cve CVE-2026-59822 --workspace-id <WS_UUID> --blast-radius \\
          --ecosystem pypi --package litellm --version 1.82.6
      torana alerts drill-down cve CVE-2026-59822 --workspace-id <WS_UUID> --upgrade-delta \\
          --ecosystem pypi --package litellm --installed 1.82.6 --target 1.84.0
    """


def _dd_get(ctx, path, params):
    client = _client(ctx)
    try:
        return client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
    except AuthError as e:
        handle_auth_error(e)
    return None


def _dd_section(title):
    click.echo("")
    click.echo(f"{title}")
    click.echo("-" * len(title))


def _dd_cell(value):
    """A table cell. ⛔ A missing value is "not available", never a dash or "none": it means the platform did not supply
    it, not that there is nothing. A boolean is yes or no."""
    if value is None:
        return "not available"
    if isinstance(value, bool):
        return "yes" if value else "no"
    return str(value)


def _dd_n(value):
    """A number in a sentence: a missing one is "not available" (never 0)."""
    return "not available" if value is None else str(value)


def _dd_table(rows, cols):
    """A small left-aligned table: cols = [(key, header)]."""
    if not rows:
        click.echo("  (none)")
        return
    cells = [[_dd_cell(r.get(k)) for k, _ in cols] for r in rows]
    widths = [max(len(h), *(len(c[i]) for c in cells)) for i, (_, h) in enumerate(cols)]
    widths = [min(w, 60) for w in widths]
    click.echo("  " + "  ".join(h.ljust(widths[i]) for i, (_, h) in enumerate(cols)))
    for c in cells:
        click.echo("  " + "  ".join(c[i][:widths[i]].ljust(widths[i]) for i in range(len(cols))))


def _dd_short(place):
    """An image place `image:<registry>/<path>/<name>@sha256:<digest>` as `<name>@<digest prefix>`: the registry prefix is
    the same on every row and pushes the part that tells them apart off the table."""
    p = str(place or "")
    if p.startswith("image:") and "@" in p:
        name, _, digest = p.rpartition("@")
        return name.rsplit("/", 1)[-1] + "@" + digest.replace("sha256:", "")[:12]
    return p


def _dd_breakdown(title, bd, extra=()):
    rows = (bd or {}).get("rows") or []
    if not rows:
        return
    _dd_section(title)
    if title == "By place":
        rows = [{**r, "label": _dd_short(r.get("label"))} for r in rows]
    _dd_table(rows, [("label", "NAME"), ("live", "LIVE"), ("running", "RUNNING"), ("internet_facing", "INTERNET")] + list(extra))
    if (bd or {}).get("more"):
        click.echo(f"  … and {bd['more']} more")


def _dd_instances(rows):
    def decided(r):
        if r.get("inbox_known") is False:
            return None                                                   # the Inbox could not be read: not known
        if not r.get("alert_id"):
            return "not in the Inbox"
        if not r.get("verdict"):
            return "no verdict yet"
        return f"{r['verdict']} ({r['verdict_source_label']})" if r.get("verdict_source_label") else r["verdict"]
    _dd_table([{**r, "place_key": _dd_short(r.get("place_key")), "decided": decided(r)}
               for r in rows or []],
              [("place_key", "PLACE"), ("package", "PACKAGE"), ("installed_version", "VERSION"), ("running", "RUNNING"),
               ("internet_facing_services", "INET"), ("owner", "OWNER"), ("severity", "SEV"), ("decided", "DECIDED"),
               ("link_alert_id", "OPEN IN INBOX")])


def _dd_as_of(d):
    """The platform's own one-sentence freshness note (the last successful build of the relation, "newer source data not
    yet included" when it is behind). An older platform sends only a row-change time as `as_of`, which understates
    freshness, so it is never shown: no note reads "not available"."""
    return d.get("as_of_note") or "data as of: not available (the platform did not report a build time)"


def _dd_print_cve(d):
    c = d.get("counts") or {}
    h = d.get("history") or {}
    click.echo(f"{d.get('cve_id')}: {_dd_n(c.get('live'))} live findings in {_dd_n(c.get('places'))} places · "
               f"{_dd_n(c.get('running'))} running · {_dd_n(c.get('internet_facing'))} internet-facing · "
               f"{_dd_n(c.get('in_inbox'))} in the Inbox · {_dd_n(c.get('decided'))} decided · {_dd_n(c.get('open'))} open")
    if c.get("exposure_unknown"):
        click.echo(f"  {c['exposure_unknown']} of these: running state not known (not counted as running or as not running)")
    click.echo(f"  not live: {_dd_n(h.get('no_longer_deployed'))} no longer deployed, {_dd_n(h.get('fixed_at_source'))} fixed at "
               f"source, {_dd_n(h.get('other'))} other · {_dd_as_of(d)}")
    if d.get("inbox_available") is False:
        click.echo(f"  Inbox: {d.get('inbox_unavailable_reason')}")
    if c.get("decision_sample_truncated"):
        click.echo("  (in the Inbox / decided / open count only the most exposed findings)")
    f = d.get("funnel") or {}
    click.echo(f"  funnel: live {_dd_n(f.get('live'))} → in the Inbox {_dd_n(f.get('in_inbox'))} → decided "
               f"{_dd_n(f.get('decided'))} → closed {_dd_n(f.get('closed'))}")
    intel = d.get("intel") or {}
    if intel.get("known"):
        _dd_section("Intel")
        kev = intel.get("kev_listed")
        click.echo(f"  CVSS {_dd_n(intel.get('cvss3_base_score'))} · EPSS {_dd_n(intel.get('epss_score'))} · "
                   f"KEV {'not available' if kev is None else 'listed' if kev else 'not listed'} · "
                   f"CWE {intel.get('cwe_ids') or intel.get('cwe_id') or 'not available'} · "
                   f"published {str(intel['published_date'])[:10] if intel.get('published_date') else 'not available'}")
    elif intel:
        click.echo("  intel: not in the threat-intel table" + (f" ({intel['unavailable']})" if intel.get("unavailable") else ""))
    bds = d.get("breakdowns") or {}
    _dd_breakdown("By place", bds.get("place"))
    _dd_breakdown("By owner", bds.get("owner"))
    _dd_breakdown("By scanner", bds.get("scanner"), [("disagree", "DISAGREE")])
    _dd_breakdown("By package", bds.get("package"))
    if "decider" in bds and bds["decider"] is None:
        click.echo("\nBy decider\n  not available")
    else:
        _dd_breakdown("By decider", bds.get("decider"))
    if d.get("look_here") is None and "look_here" in d:
        _dd_section("Look here")
        click.echo(f"  not available: {d.get('look_here_unavailable_reason') or 'the Inbox could not be read'}")
    elif d.get("look_here"):
        _dd_section("Look here")
        for item in d["look_here"]:
            click.echo(f"  {item['kind']}: {item['count']}")
            _dd_instances(item.get("instances"))
    _dd_section("Most exposed")
    _dd_instances(d.get("most_exposed"))
    if d.get("timeline"):
        _dd_section("Timeline (per week)")
        _dd_table(d["timeline"], [("week", "WEEK"), ("first_seen", "FIRST SEEN"), ("closed", "CLOSED"), ("reopened", "REOPENED")])


def _dd_print_cwe(d):
    code, pk = d.get("code") or {}, d.get("packages") or {}
    c = code.get("counts") or {}
    click.echo(f"{d.get('cwe_id')} — code findings: {_dd_n(c.get('live'))} live · {_dd_n(c.get('running'))} running · "
               f"{_dd_n(c.get('internet_facing'))} internet-facing · {_dd_n(c.get('in_inbox'))} in the Inbox · "
               f"{_dd_n(c.get('decided_by_triage_agent'))} decided by the triage agent · {_dd_as_of(d)}")
    if d.get("inbox_available") is False:
        click.echo(f"  Inbox: {d.get('inbox_unavailable_reason')}")
    if code.get("hotspots"):
        _dd_section("Hotspots (repository, file)")
        _dd_table(code["hotspots"], [("repository", "REPOSITORY"), ("file", "FILE"), ("live", "LIVE"), ("open", "OPEN"),
                                     ("running", "RUNNING"), ("internet_facing", "INTERNET")])
    if code.get("by_rule"):
        _dd_section("By scanner rule (verdicts are what the triage agent decided)")
        _dd_table([{**r, "verdicts": (None if r.get("verdicts") is None else
                                      ", ".join(f"{k} {v}" for k, v in r["verdicts"].items() if v) or "none decided")}
                   for r in code["by_rule"]], [("rule_id", "RULE"), ("findings", "FINDINGS"), ("verdicts", "AGENT VERDICTS")])
    if code.get("earlier_decisions"):
        _dd_section("The triage agent's earlier decisions")
        _dd_table(code["earlier_decisions"], [("name", "ITEM"), ("verdict", "VERDICT"), ("when", "WHEN"),
                                              ("link_alert_id", "OPEN IN INBOX")])
    _dd_section(f"Package CVEs with this weakness: {_dd_n(pk.get('live'))} live findings in {_dd_n(pk.get('cves_total'))} CVEs")
    _dd_table(pk.get("cves") or [], [("cve_id", "CVE"), ("live", "LIVE"), ("running", "RUNNING"), ("internet_facing", "INTERNET")])
    if pk.get("more"):
        click.echo(f"  … and {pk['more']} more")


_DD_COUNT_WORDS = {
    "service": ("service", "services"),
    "image": ("running image", "running images"),
    "images_with_package": ("image digest carries it", "image digests carry it"),
    "cloud": ("cloud resource", "cloud resources"),
    "host": ("host", "hosts"),
    "datastore": ("datastore", "datastores"),
}


def _dd_count_label(key, n):
    """"12 services", "1 cloud resource": the count with its noun in the right number; an unknown key is the key,
    pluralised ("2 queues")."""
    one, many = _DD_COUNT_WORDS.get(key) or (str(key).replace("_", " "), str(key).replace("_", " ") + "s")
    return f"{n} {one if n == 1 else many}"


def _dd_print_blast(d):
    if not d.get("available"):
        click.echo(f"Blast radius not available: {d.get('reason')}")
        return
    ac = d.get("affected_counts") or {}
    # The headline is the services whose RUNNING image carries this version. A service reached only through a repository
    # that declares the package is shown apart and never counted as running exposure.
    if "running_with_version" in d:
        click.echo(f"{d['running_with_version']} service(s) run an image that carries this version"
                   + (f"; {d['repository_only']} more reached only through a repository that declares it" if d.get("repository_only") else ""))
    # Only what is certain about the VERSION is counted. The cloud, host and datastore counts include nodes reached through
    # repository-only paths, so they are not printed.
    # A measured zero is stated: "0 running images carry it" is a fact, not an omission.
    facts = []
    if ac.get("image") is not None:
        facts.append(f"{ac['image']} running image{' carries' if ac['image'] == 1 else 's carry'} it")
    if ac.get("images_with_package") is not None:
        n = ac["images_with_package"]
        facts.append(f"{n} image digest{' carries' if n == 1 else 's carry'} it")
    if facts or d.get("truncated"):
        click.echo("Images: " + "; ".join(facts)
                   + (" (INCOMPLETE: the walk was cut short, so these are lower bounds)" if d.get("truncated") else ""))
    _dd_section("Services reached")
    words = {"running_image": "runs this version", "repository_only": "repository only (not running this version)",
             "not_determined": "how it was reached is not known"}
    rows = [{"service": s, "how": ""} if isinstance(s, str) else
            {"service": s.get("service"), "how": words.get(s.get("reached_via"), s.get("reached_via"))}
            for s in d.get("services") or []]
    _dd_table([{"service": r["service"], "how": r["how"] or ""} for r in rows], [("service", "SERVICE"), ("how", "REACHED")])
    for n in d.get("notes") or []:
        click.echo(f"Note: {n}")
    _dd_section("Owners")
    click.echo(d.get("owners_note") or "")
    _dd_table([{"owner": o} for o in d.get("owners") or []], [("owner", "OWNER")])


def _dd_print_delta(d):
    if not d.get("available"):
        click.echo(f"Upgrade delta not available: {d.get('reason')}")
        return
    click.echo(f"Moving {d.get('package')} {d.get('base_version')} → {d.get('target_version')}: "
               f"{len(d.get('fixed') or [])} fixed · {len(d.get('introduced') or [])} introduced · "
               f"{len(d.get('unchanged') or [])} unchanged" + (" · none known introduced (not a guarantee)" if d.get("none_known") else ""))
    if d.get("not_checked"):
        click.echo("Checked: " + ", ".join(x.replace("_", " ") for x in d.get("checks") or [])
                   + ". Not checked: " + ", ".join(x.replace("_", " ") for x in d["not_checked"]) + ".")
    for key in ("fixed", "introduced", "unchanged"):
        if d.get(key):
            _dd_section(key.capitalize())
            _dd_table(d[key], [("id", "ADVISORY"), ("severity", "SEVERITY"), ("cvss", "CVSS"), ("kev", "KEV")])


def _dd_emit(ctx, data, printer):
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    if fmt in ("text", "table") and not raw and not fields and isinstance(data, dict):
        printer(data)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@alerts_drill_down.command(name="cve")
@click.argument("CVE_ID", metavar="CVE")
@click.option("--workspace-id", "workspace_id", required=True, help="The app (workspace) UUID the findings are read in.")
@click.option("--blast-radius", "blast_radius", is_flag=True, default=False,
              help="Instead of the summary: the services and owners one package version reaches "
                   "(needs --ecosystem --package --version; pypi, golang, npm, maven).")
@click.option("--upgrade-delta", "upgrade_delta", is_flag=True, default=False,
              help="Instead of the summary: what moving a package fixes and introduces "
                   "(needs --ecosystem --package --installed --target; pypi, golang, npm, maven).")
@click.option("--ecosystem", default=None, help="pypi, golang, npm or maven.")
@click.option("--package", default=None, help="The package name (module path for golang).")
@click.option("--version", default=None, help="The package version (with --blast-radius).")
@click.option("--installed", default=None, help="The installed version (with --upgrade-delta).")
@click.option("--target", default=None, help="The version to move to (with --upgrade-delta).")
@click.pass_context
def alerts_drill_down_cve(ctx, cve_id, workspace_id, blast_radius, upgrade_delta, ecosystem, package, version, installed,
                          target):
    """One CVE across the app's live ranked findings.

    \b
    Examples:
      torana alerts drill-down cve CVE-2026-33845 --workspace-id <WS_UUID>
      torana alerts drill-down cve CVE-2026-59822 --workspace-id <WS_UUID> --blast-radius --ecosystem pypi --package litellm --version 1.82.6
    """
    if blast_radius and upgrade_delta:
        raise click.UsageError("Use --blast-radius or --upgrade-delta, not both.")
    base = f"alerts/drill-down/cve/{cve_id}"
    ws = _full_workspace_id(workspace_id)
    if blast_radius:
        if not (ecosystem and package and version):
            raise click.UsageError("--blast-radius needs --ecosystem, --package and --version.")
        data = _dd_get(ctx, base + "/blast-radius", {"workspace_id": ws, "ecosystem": ecosystem, "package": package,
                                                      "version": version})
        printer = _dd_print_blast
    elif upgrade_delta:
        if not (ecosystem and package and installed and target):
            raise click.UsageError("--upgrade-delta needs --ecosystem, --package, --installed and --target.")
        data = _dd_get(ctx, base + "/upgrade-delta", {"workspace_id": ws, "ecosystem": ecosystem, "package": package,
                                                       "installed": installed, "target": target})
        printer = _dd_print_delta
    else:
        data = _dd_get(ctx, base, {"workspace_id": ws})
        printer = _dd_print_cve
    if data is not None:
        _dd_emit(ctx, data, printer)


@alerts_drill_down.command(name="cwe")
@click.argument("CWE_ID", metavar="CWE")
@click.option("--workspace-id", "workspace_id", required=True, help="The app (workspace) UUID the findings are read in.")
@click.pass_context
def alerts_drill_down_cwe(ctx, cwe_id, workspace_id):
    """One CWE (weakness class): its code findings (hotspots, rules, the agent's decisions) and the package CVEs.

    \b
    Example:
      torana alerts drill-down cwe CWE-89 --workspace-id <WS_UUID>
    """
    data = _dd_get(ctx, f"alerts/drill-down/cwe/{cwe_id}", {"workspace_id": _full_workspace_id(workspace_id)})
    if data is not None:
        _dd_emit(ctx, data, _dd_print_cwe)


@alerts.group(name="suite-rule")
def alerts_suite_rule_grp():
    """Alerts for one rule within one suite.

    Examples:
      torana alerts suite-rule get --help
    """


@alerts_suite_rule_grp.command(name="get")
@click.argument("SUITE_ID", metavar="SUITE_ID")
@click.argument("RULE_ID", metavar="RULE_ID")
@click.pass_context
def alerts_rule_by_rule_id(ctx, suite_id, rule_id):
    """Get Alerts By Suite And Rule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"alerts/by-suite/{suite_id}/rule/{rule_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alerts.command(name="count")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--suite-id", "suite_id", default=None)
@click.option("--rule-id", "rule_id", default=None)
@click.pass_context
def alerts_count(ctx, suite_id, rule_id, page, page_size, fetch_all):
    """Get Alerts Count."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "alerts/count"
    params = {}
    if suite_id is not None:
        params["suite_id"] = suite_id
    if rule_id is not None:
        params["rule_id"] = rule_id
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@alerts.command(name="triage-agents")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def alerts_triage_agents(ctx, page, page_size, fetch_all):
    """List Triage Agents."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "alerts/triage/agents"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


# ---------------------------------------------------------------------------
# activities — standalone top-level command group
# ---------------------------------------------------------------------------

@click.group()
def activities():
    """Platform activity feed — what happened, across resources.

    \b
    Examples:
      torana activities list
      torana activities list --json --raw | jq '.[0]'
      torana activities list --help          filters (resource, actor, time window)
      torana activities create --alert-id <ALERT_ID> --activity-type note --message "..."
    """


@activities.command(name="list")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--vulnerability-id", "vulnerability_id", default=None,
              help="Only activities about ONE finding — its own timeline, alert or not.")
@click.pass_context
def activities_list(ctx, page, page_size, fetch_all, vulnerability_id):
    """List activities — the platform timeline.

    ⚠️ An activity's subject is an ALERT or a VULNERABILITY (T11 § 3.3.3). Without
    --vulnerability-id this lists both kinds interleaved.

    \b
    Examples:
      torana activities list
      torana activities list --vulnerability-id "gcp_ca_image:...@sha256:...
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "activities"
    effective_page_size = min(page_size or settings.page_size, 100)
    # ⛔ `offset`, NOT `skip` — the endpoint declares `offset` and IGNORES an unknown
    # `skip`, so every page silently returned PAGE ONE. Verified against the running
    # service: `?skip=1` and `?offset=0` returned an identical first row, while
    # `?offset=1` returned the next one. `--all` was affected too: the loop breaks on
    # `len(all_items) >= total`, and a list response makes total == the page size, so
    # it stopped after one page while reporting success.
    params = {"offset": (page - 1) * effective_page_size, "limit": effective_page_size}
    if vulnerability_id:
        params["vulnerability_id"] = vulnerability_id

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "offset": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)



@activities.command(name="create")
@click.option("--alert-id", "alert_id", default=None, help="The alert this activity is about.")
@click.option("--vulnerability-id", "vulnerability_id", default=None,
              help="The datalake vulnerability this activity is about.")
@click.option("--activity-type", "activity_type", required=True,
              help="What happened, e.g. verdict_set, assigned, status_changed.")
@click.option("--message", required=True, help="Human-readable description of what happened.")
@click.option("--actor-type", "actor_type", type=click.Choice(["user", "agent", "system"]),
              default=None, help="Who acted (server default: system).")
@click.option("--extra-data", "extra_data", default=None,
              help='Structured detail as a JSON object, e.g. \'{"prior_verdict": "true_positive"}\'.')
@click.pass_context
def activities_create(ctx, alert_id, vulnerability_id, activity_type, message, actor_type,
                      extra_data):
    """Append one entry to an alert's or a vulnerability's timeline.

    Name at least one subject (--alert-id and/or --vulnerability-id). For a `user`
    activity the actor is YOU, taken from your login; it cannot be set to someone else.

    \b
    Examples:
      torana activities create --alert-id <ALERT_ID> --activity-type note --message "Checked with owner"
      torana activities create --vulnerability-id <VULN_ID> --activity-type verdict_set \\
        --message "False positive: test fixture" --actor-type user \\
        --extra-data '{"prior_verdict": "true_positive"}'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    if not alert_id and not vulnerability_id:
        raise click.UsageError("name a subject: --alert-id, --vulnerability-id, or both")
    body = {"activity_type": activity_type, "message": message}
    if alert_id:
        body["alert_id"] = alert_id
    if vulnerability_id:
        body["vulnerability_id"] = vulnerability_id
    if actor_type:
        body["actor_type"] = actor_type
    if extra_data:
        try:
            parsed = _json.loads(extra_data)
        except ValueError as e:
            raise click.BadParameter(f"not valid JSON: {e}", param_hint="--extra-data")
        if not isinstance(parsed, dict):
            raise click.BadParameter("must be a JSON object", param_hint="--extra-data")
        body["extra_data"] = parsed
    client = _client(ctx)
    try:
        data = client.post("activities", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields)


@alerts.command(name="breakdown")
@click.option("--workspace-id", default=None, help="Limit to one workspace.")
@click.option("--tenant-id", default=None, help="Cross-tenant callers only.")
@click.pass_context
def alerts_breakdown(ctx, workspace_id, tenant_id):
    """Counts over EVERY alert in scope, not just one page.

    \b
    The inbox's tab badges are folded from these rows, so this is the same
    arithmetic the UI shows — use it to check a badge that looks wrong.

    \b
    ⚠️ NOT `alerts count` (a flat total for a suite or rule) and NOT
    `alerts dispositions-summary` (the Advisor's per-rule, 14-day signal).
    This one groups the whole scope by the dimensions a verdict decision
    reads: verdict, status, assignee, and whether a playbook ran.

    \b
    Example:
      torana alerts breakdown --workspace-id <UUID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if workspace_id:
        params["workspace_id"] = _full_workspace_id(workspace_id)
    if tenant_id:
        params["tenant_id"] = tenant_id

    client = _client(ctx)
    try:
        data = client.get("api/v2/alerts/facet-counts", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, fields=fields)
        return

    rows = sorted(data.get("groups", []), key=lambda g: -g.get("count", 0))
    # ⛔ TWO POPULATIONS ON ONE SCREEN, SO BOTH ARE LABELLED. `total` is what the Inbox
    # can LIST (Needs attention plus Closed); the rows below are grouped over EVERY item
    # in scope, moved work included, so they sum HIGHER. Printing a bare "TOTAL" above
    # rows that add up to something larger invites the reader to conclude the table is
    # wrong, or the total is.
    _listed = int(data.get("total") or 0)
    _grouped = sum(int(g.get("count") or 0) for g in (data.get("groups") or []))
    click.echo(f"{_listed} listable item(s) in scope — Needs attention plus Closed.")
    if _grouped != _listed:
        click.echo(f"The {_grouped} grouped below include moved work, which the Inbox "
                   f"lists only under All.")
    click.echo("")
    hdr = f"{'VERDICT':<15} {'STATUS':<20} {'ASSIGNEE':<12} {'MINE':<5} {'PLAYBOOK':<9} {'COUNT':>6}"
    click.echo(hdr)
    click.echo("-" * len(hdr))
    for g in rows:
        click.echo(
            f"{str(g.get('triage_verdict') or '-'):<15} "
            f"{str(g.get('status') or '-'):<20} "
            f"{str(g.get('assignee_type') or '-'):<12} "
            f"{('yes' if g.get('assigned_to_me') else '-'):<5} "
            f"{str(g.get('latest_routing_outcome') or '-'):<9} "
            f"{g.get('count', 0):>6}"
        )


@alerts.command(name="dispositions-summary")
@click.option("--workspace-id", default=None, help="Filter by workspace UUID (Signal B).")
@click.pass_context
def alerts_dispositions_summary(ctx, workspace_id):
    """Get alert disposition summary for a workspace.

    \b
    Example:
      torana alerts dispositions-summary --workspace-id <UUID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if workspace_id:
        params["workspace_id"] = _full_workspace_id(workspace_id)

    client = _client(ctx)
    try:
        data = client.get("alerts/dispositions/summary", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ──────────────────────────────────────────────────────────────────────────
# BACK-COMPAT — hidden aliases for the old `<noun>-by-<param>` names.
# ⏳ ONE RELEASE ONLY (decision D4). Delete this block next release.
# ──────────────────────────────────────────────────────────────────────────

_LEGACY_BY_PARAM_ALERTS = {
    "rule-by-rule-id": ("suite-rule", "get"),
}


@alerts.command(name="remediation-vocabulary")
@click.pass_context
def alerts_remediation_vocabulary(ctx):
    """The remediation actions, target types and which combinations are valid.

    A remediation is an ACTION on a TARGET TYPE. `valid_targets` lists, per action, the
    target types it takes; `accept` and `none` are recorded actions that take no target and close nothing;
    `versioned_actions` are the ones that may carry a target version. The category each
    action puts an open item in is under `categories`.

    \b
    Examples:
      torana alerts remediation-vocabulary
      torana alert <UUID> verdict --triage-verdict true_positive \\
        --remediation-action upgrade --remediation-target-type package \\
        --remediation-target-version 4.17.21
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get("alerts/remediation-vocabulary")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields)


@alerts.command(name="reason-codes")
@click.pass_context
def alerts_reason_codes(ctx):
    """The closed list of grounds a verdict may cite.

    `AGENT MAY CLOSE` marks the only grounds the triage agent may CLOSE a finding on.
    The rest are for confirming, for escalating, or for a person recording an accepted
    risk or a duplicate.

    \b
    Examples:
      torana alerts reason-codes
      torana alert <UUID> verdict --triage-verdict benign --reason-code package_not_shipped
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("alerts/verdict-reason-codes")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    rows = data.get("reason_codes", []) if isinstance(data, dict) else data
    for row in rows:
        if isinstance(row, dict):
            row["verdicts_text"] = ", ".join(row.get("verdicts", []))
            row["may_close"] = "yes" if row.get("agent_may_close") else ""
    cols = [("code", "CODE", 30), ("verdicts_text", "VERDICTS", 34),
            ("may_close", "AGENT MAY CLOSE", 16), ("label", "GROUND", 60)]
    output({"items": rows} if isinstance(data, dict) else rows,
           fmt=fmt, raw=raw, fields=fields, columns=cols)


def _register_legacy_alerts_by_param() -> None:
    """Old flat names, hidden so they cannot be discovered anew."""
    import copy
    for _old, (_sub, _verb) in _LEGACY_BY_PARAM_ALERTS.items():
        _grp = alerts.commands.get(_sub)
        if not isinstance(_grp, click.Group):
            continue
        _cmd = _grp.commands.get(_verb)
        if _cmd is None:
            continue
        # ⛔ Never let an alias overwrite a real group of the same name.
        if isinstance(alerts.commands.get(_old), click.Group):
            continue
        _alias = copy.copy(_cmd)
        _alias.name = _old
        _alias.hidden = True
        alerts.add_command(_alias)


_register_legacy_alerts_by_param()


@alerts.command(name="lifecycle-state")
@click.option("--workspace-id", required=True, help="The workspace whose Inbox to check.")
@click.pass_context
def alerts_lifecycle_state(ctx, workspace_id):
    """Is this Inbox in step with the data behind it?

    \b
    An EMPTY Inbox means one of two opposite things: there is nothing to do, or the last
    check of the data was refused and items that have ended are still listed. This is what
    tells them apart.

    \b
      off      no rule in this workspace has its lifecycle on
      current  every rule checked its data and was believed
      stale    a rule has not been checked recently
      refused  a rule's last check was refused — the reason is shown
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get("alerts/lifecycle-state",
                          params={"workspace_id": workspace_id})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt == "json":
        output(data, fmt=fmt, fields=fields)
        return
    click.echo(f"STATE  {data.get('state')}")
    rows = data.get("rules") or []
    if not rows:
        click.echo("No rule in this workspace has its lifecycle on.")
        return
    output({"items": rows}, fmt=fmt,
           fields=fields or "name,last_run_status,mode,last_observed_at,refusal_reason")


# ── SLA policy (S2-14) ─────────────────────────────────────────────────────────


def _print_sla_policy(ctx, data):
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    if fmt != "text":
        output(data, fmt=fmt, fields=fields)
        return
    defaults = data.get("defaults") or {}
    src = data.get("source")
    click.echo(f"SOURCE  {src}" + ("  (platform defaults; this tenant has not set its own)"
                                   if src == "default" else ""))
    for sev in ("critical", "high", "medium", "low"):
        hours = data.get(f"{sev}_hours")
        shown = f"{hours} h" if hours is not None else "no deadline"
        extra = "" if hours == defaults.get(sev) else f"  (default {defaults.get(sev)} h)"
        click.echo(f"{sev.upper():<9} {shown}{extra}")
    if data.get("updated_at"):
        click.echo(f"UPDATED  {data['updated_at']}")
    overrides = data.get("rule_overrides") or []
    if overrides:
        click.echo(f"\nRULE OVERRIDES ({len(overrides)}): these rules' alerts use their own hours")
        for o in overrides:
            click.echo(f"  {o.get('sla_hours'):>6} h  {o.get('name')}  ({o.get('rule_id')})")
    click.echo(data.get("note") or "")


@alerts.group(name="sla-policy")
@click.pass_context
def alerts_sla_policy(ctx):
    """How long this tenant gives itself to handle an alert, by severity.

    \b
    An alert's deadline (sla_due_at) is set when it is raised: raised + the hours for
    its severity. A rule's own override (torana rule <UUID> update --sla-hours N) wins
    over this table. When an alert's severity rises, the tightest deadline wins.
    Changing the policy affects NEW alerts only.

    \b
    Examples:
      torana alerts sla-policy get
      torana alerts sla-policy set --critical-hours 12 --high-hours 48
      torana alerts sla-policy set --reset
    """
    ctx.ensure_object(dict)


@alerts_sla_policy.command(name="get")
@click.pass_context
def alerts_sla_policy_get(ctx):
    """Show the SLA hours per severity and whether they are this tenant's own.

    \b
    Examples:
      torana alerts sla-policy get
      torana alerts sla-policy get --format json
    """
    client = _client(ctx)
    try:
        data = client.get("alerts/sla-policy")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    _print_sla_policy(ctx, data)


@alerts_sla_policy.command(name="set")
@click.option("--critical-hours", type=click.IntRange(1, 87600), default=None)
@click.option("--high-hours", type=click.IntRange(1, 87600), default=None)
@click.option("--medium-hours", type=click.IntRange(1, 87600), default=None)
@click.option("--low-hours", type=click.IntRange(1, 87600), default=None)
@click.option("--reset", is_flag=True,
              help="Drop this tenant's policy and go back to the platform defaults.")
@click.pass_context
def alerts_sla_policy_set(ctx, critical_hours, high_hours, medium_hours, low_hours, reset):
    """Change the SLA hours for one or more severities (tenant admin).

    \b
    Severities you leave out keep their current hours. Existing alerts keep their
    deadlines; only alerts raised from now on use the new hours.

    \b
    Examples:
      torana alerts sla-policy set --critical-hours 12
      torana alerts sla-policy set --high-hours 48 --medium-hours 120
      torana alerts sla-policy set --reset
    """
    body = {k: v for k, v in (("critical_hours", critical_hours), ("high_hours", high_hours),
                              ("medium_hours", medium_hours), ("low_hours", low_hours))
            if v is not None}
    if reset and body:
        raise click.UsageError("--reset cannot be combined with hour options.")
    if not reset and not body:
        raise click.UsageError("Give at least one --<severity>-hours option, or --reset.")
    if reset:
        body = {"reset": True}
    client = _client(ctx)
    try:
        data = client.put("alerts/sla-policy", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    for k, v in body.items():
        if k != "reset" and data.get(k) != v:
            click.echo(f"ERROR: {k} was NOT applied — requested {v}, still {data.get(k)}",
                       err=True)
            sys.exit(1)
    _print_sla_policy(ctx, data)
