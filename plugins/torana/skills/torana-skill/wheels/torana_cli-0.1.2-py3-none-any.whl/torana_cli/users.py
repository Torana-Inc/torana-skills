"""torana users — user management commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm

_LIST_COLS = [
    ("id", "ID", 36),
    ("email", "EMAIL", 40),
    ("name", "NAME", 30),
    ("role", "ROLE", 15),
    ("is_active", "ACTIVE", 6),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group()
def users():
    """Manage users.

    \b
    Examples:
      torana users list
      torana users get <UUID>
      torana users create --email user@acme.com --name "Alice"
      torana users delete <UUID> --yes
    """


@users.command(name="list")
@click.option("--search", default=None, help="Search by email or name.")
@click.option("--role", default=None, help="Filter by role.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.pass_context
def users_list(ctx, search, role, page, page_size, fetch_all):
    """List users.

    \b
    Examples:
      torana users list
      torana users list --search @acme.com --role admin
      torana users list --json | jq '.items[] | {email, is_enabled}'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if search:
        params["search"] = search
    if role:
        params["role"] = role

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                p.update({k: v for k, v in params.items() if k not in ("skip", "limit")})
                data = client.get("users/", params=p)
                items = data.get("items", data if isinstance(data, list) else [])
                all_items.extend(items)
                total = data.get("total", len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items), "page": 1,
                      "page_size": len(all_items)}
        else:
            data = client.get("users/", params=params)
            result = data if isinstance(data, dict) and "items" in data else {
                "items": data if isinstance(data, list) else [],
                "total": len(data) if isinstance(data, list) else 0,
                "page": page, "page_size": effective_page_size
            }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@users.command(name="get")
@click.argument("user_id", metavar="USER_ID")
@click.pass_context
def users_get(ctx, user_id):
    """Get details for a specific user.

    \b
    Examples:
      torana users list                        # find the id
      torana users get <USER_ID>
      torana roles user-permissions <USER_ID>  # what they can actually do
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"users/{user_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@users.command(name="create")
@click.option("--email", default=None, help="User email address.")
@click.option("--name", default=None, help="Display name.")
@click.option("--role", default=None, help="Role name.")
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def users_create(ctx, email, name, role, input_file):
    """Create a new user.

    \b
    Examples:
      torana users create --email analyst@acme.com --name "A Analyst" --role analyst
      torana users create --file user.yaml
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if email:
        body["email"] = email
    if name:
        body["name"] = name
    if role:
        body["role"] = role

    if not body.get("email"):
        click.echo("ERROR: --email is required.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post("users/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created user: {data.get('id', 'unknown')}")
        click.echo(f"  Email: {data.get('email', '')}")


@users.command(name="update")
@click.argument("user_id", metavar="USER_ID")
@click.option("--name", default=None)
@click.option("--role", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def users_update(ctx, user_id, name, role, input_file):
    """Update a user."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if role:
        body["role"] = role

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"users/{user_id}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated user: {user_id}")


@users.command(name="delete")
@click.argument("user_id", metavar="USER_ID")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def users_delete(ctx, user_id, yes):
    """Delete a user."""
    _confirm(f"Delete user {user_id}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"users/{user_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted user: {user_id}")


@users.command(name="me")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def users_me(ctx, page, page_size, fetch_all):
    """Get Current User Profile."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "users/me"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@users.command(name="update-me")
@click.option("--name", "name", default=None)
@click.option("--first-name", "first_name", default=None)
@click.option("--last-name", "last_name", default=None)
@click.option("--username", "username", default=None)
@click.option("--display-name", "display_name", default=None)
@click.option("--department", "department", default=None)
@click.option("--job-title", "job_title", default=None)
@click.option("--employee-id", "employee_id", default=None)
@click.option("--manager-id", "manager_id", default=None)
@click.option("--phone-number", "phone_number", default=None)
@click.option("--mobile-number", "mobile_number", default=None)
@click.option("--office-location", "office_location", default=None)
@click.option("--timezone", "timezone", default=None)
@click.option("--language", "language", default=None)
@click.option("--locale", "locale", default=None)
@click.option("--cost-center", "cost_center", default=None)
@click.option("--business-unit", "business_unit", default=None)
@click.option("--region", "region", default=None)
@click.option("--country", "country", default=None)
@click.option("--is-active", "is_active", default=None)
@click.option("--is-verified", "is_verified", default=None)
@click.option("--is-mfa-enabled", "is_mfa_enabled", default=None)
@click.option("--roles", "roles", default=None)
@click.option("--preferences", "preferences", default=None)
@click.option("--custom-attributes", "custom_attributes", default=None)
@click.option("--business-context", "business_context", default=None)
@click.pass_context
def users_update_me(ctx, name, first_name, last_name, username, display_name, department, job_title, employee_id, manager_id, phone_number, mobile_number, office_location, timezone, language, locale, cost_center, business_unit, region, country, is_active, is_verified, is_mfa_enabled, roles, preferences, custom_attributes, business_context):
    """Update Current User Profile."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "users/me"
    body = {}
    if name is not None:
        body["name"] = name
    if first_name is not None:
        body["first_name"] = first_name
    if last_name is not None:
        body["last_name"] = last_name
    if username is not None:
        body["username"] = username
    if display_name is not None:
        body["display_name"] = display_name
    if department is not None:
        body["department"] = department
    if job_title is not None:
        body["job_title"] = job_title
    if employee_id is not None:
        body["employee_id"] = employee_id
    if manager_id is not None:
        body["manager_id"] = manager_id
    if phone_number is not None:
        body["phone_number"] = phone_number
    if mobile_number is not None:
        body["mobile_number"] = mobile_number
    if office_location is not None:
        body["office_location"] = office_location
    if timezone is not None:
        body["timezone"] = timezone
    if language is not None:
        body["language"] = language
    if locale is not None:
        body["locale"] = locale
    if cost_center is not None:
        body["cost_center"] = cost_center
    if business_unit is not None:
        body["business_unit"] = business_unit
    if region is not None:
        body["region"] = region
    if country is not None:
        body["country"] = country
    if is_active is not None:
        body["is_active"] = is_active
    if is_verified is not None:
        body["is_verified"] = is_verified
    if is_mfa_enabled is not None:
        body["is_mfa_enabled"] = is_mfa_enabled
    if roles is not None:
        body["roles"] = roles
    if preferences is not None:
        body["preferences"] = preferences
    if custom_attributes is not None:
        body["custom_attributes"] = custom_attributes
    if business_context is not None:
        body["business_context"] = business_context

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@users.command(name="reset-password")
@click.argument("USER_ID", metavar="USER_ID")
@click.option("--current-password", "current_password", default=None)
@click.option("--new-password", "new_password", required=True)
@click.pass_context
def users_reset_password(ctx, user_id, current_password, new_password):
    """Reset User Password."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"users/{user_id}/reset-password"
    body = {}
    if current_password is not None:
        body["current_password"] = current_password
    body["new_password"] = new_password

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@users.command(name="toggle-enabled")
@click.argument("USER_ID", metavar="USER_ID")
@click.pass_context
def users_toggle_enabled(ctx, user_id):
    """Toggle User Enabled."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"users/{user_id}/toggle-enabled"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)
