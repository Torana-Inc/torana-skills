"""torana session — per-session instance commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.confirm import confirm as _confirm


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(name="session", invoke_without_command=True)
@click.argument("session_id", metavar="SESSION_ID")
@click.pass_context
def session(ctx, session_id):
    """Per-session instance commands.

    \b
    Examples:
      torana session <UUID> get
      torana session <UUID> chat --message "Follow-up"
      torana session <UUID> history
      torana session <UUID> cancel
    """
    ctx.ensure_object(dict)
    ctx.obj["_session_id"] = session_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _sid(ctx) -> str:
    return ctx.obj.get("_session_id", "") if ctx.obj else ""


@session.command(name="get")
@click.pass_context
def session_get(ctx):
    """Get details for a specific session."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"sessions/{_sid(ctx)}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@session.command(name="delete")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def session_delete(ctx, yes):
    """Delete a session."""
    _confirm(f"Delete session {_sid(ctx)}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"sessions/{_sid(ctx)}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted session: {_sid(ctx)}")


@session.command(name="chat")
@click.option("--message", "-m", required=True, help="Message to send.")
@click.pass_context
def session_chat(ctx, message):
    """Send a message in an existing session.

    \b
    Example:
      torana session <UUID> chat --message "Follow-up question"
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"sessions/{_sid(ctx)}/chat/", json={"message": message})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        if isinstance(data, dict):
            response_text = (
                data.get("response") or data.get("content")
                or data.get("message") or data.get("text")
            )
            if response_text:
                click.echo(response_text)
            else:
                import json
                click.echo(json.dumps(data, indent=2, default=str))
        else:
            click.echo(str(data))


@session.command(name="cancel")
@click.pass_context
def session_cancel(ctx):
    """Cancel a running session."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"sessions/{_sid(ctx)}/cancel/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Cancelled session: {_sid(ctx)}")


@session.command(name="history")
@click.pass_context
def session_history(ctx):
    """Get message history for a session."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    client = _client(ctx)
    try:
        data = client.get(f"sessions/{_sid(ctx)}/history/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw)
