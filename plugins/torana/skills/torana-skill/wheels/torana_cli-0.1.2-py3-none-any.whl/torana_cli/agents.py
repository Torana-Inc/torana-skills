"""torana agents — agent management commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW, CollectionGroup
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 30),
    ("state", "STATE", 10),
    ("version", "VERSION", 8),
    ("drift", "STATUS", 12),
    ("description", "DESCRIPTION", 40),
]


def _drift_label(item):
    """Map the API's has_drift bool to the DRIFT / UP-TO-DATE column value.

    Grep-friendly: `torana agents list | grep DRIFT` returns only drifted rows
    (UP-TO-DATE does not contain the token "DRIFT").
    """
    return "DRIFT" if item.get("has_drift") else "UP-TO-DATE"


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _extract_items(data):
    """Normalise the agents list envelope to (items, total).

    The /api/v1/agents endpoint returns {agents, total, limit, offset}
    instead of the standard {items, total, page, page_size} shape.
    """
    if isinstance(data, dict):
        items = data.get("items") or data.get("agents") or []
        total = data.get("total", len(items))
        return items, total
    if isinstance(data, list):
        return data, len(data)
    return [], 0


@click.group(cls=CollectionGroup, singular="agent")
def agents():
    """Manage AI agents (collection operations).

    \b
    Examples:
      torana agents list
      torana agents create --file agent.yaml
      torana agents health-summary

    \b
    Instance operations (get, publish, activate, chat, etc.) use the singular form:
      torana agent <UUID> get
      torana agent <UUID> publish
      torana agent <UUID> activate
      torana agent <UUID> session <SID> chat -m "hello"
      torana agent <UUID> session <SID> history
    """


# ── A2A discovery / registry (collection-scoped) ────────────────────────────
#
# `torana agents a2a cards` — the A2A DISCOVERY surface. A2A standardises the
# Agent Card but leaves the registry ("enumerate available cards") to the
# implementer. This is the collection-level counterpart to the per-agent
# `torana agent <id> a2a card`: it lists every Agent Card the caller may see, so
# an A2A client can bootstrap (list cards → pick one → talk to its interface URL)
# WITHOUT already knowing an agent UUID. Backend: GET /api/v1/a2a/cards.
# See docs/AGUI_AGENTS_REFACTOR.md.

def _card_row(card: dict) -> dict:
    """Flatten one Agent Card into a discovery table row."""
    ifaces = card.get("supportedInterfaces") or card.get("supported_interfaces") or []
    url = ifaces[0].get("url") if ifaces else ""
    proto = ifaces[0].get("protocolVersion") or ifaces[0].get("protocol_version") if ifaces else ""
    # The agent UUID is the tail of the interface URL (/api/v1/a2a/<uuid>).
    agent_id = url.rstrip("/").rsplit("/", 1)[-1] if url else ""
    skills = card.get("skills") or []
    return {
        "agent_id": agent_id,
        "name": card.get("name", ""),
        "protocol": str(proto or ""),
        "skills": len(skills),
        "url": url,
    }


@agents.group(name="a2a")
def agents_a2a():
    """A2A discovery for the agents you can reach (collection-scoped).

    \b
    Examples:
      torana agents a2a cards
      torana agents a2a cards --json
    """


@agents_a2a.command(name="cards")
@click.pass_context
def agents_a2a_cards(ctx):
    """List the A2A Agent Cards visible to you (the discovery registry).

    \b
    A2A's per-agent card paths need an agent UUID you may not know yet. This is
    the registry: it returns one card per published + active agent you can see,
    each with the interface URL to call. Use it to bootstrap:
      1. torana agents a2a cards            ← find an agent + its UUID
      2. torana agent <UUID> a2a card       ← the full card for one agent
      3. torana agent <UUID> a2a send "..." ← talk to it
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("a2a/cards")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # json/yaml/raw print the full card payload; text renders a discovery table.
    if fmt in ("json", "yaml") or raw:
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    cards = data.get("cards", []) if isinstance(data, dict) else (data or [])
    rows = [_card_row(c) for c in cards]
    click.echo(f"{data.get('count', len(rows)) if isinstance(data, dict) else len(rows)} A2A card(s):")
    output(
        {"items": rows, "total": len(rows)},
        fmt="text",
        fields=fields,
        columns=[
            ("agent_id", "AGENT ID", 36),
            ("name", "NAME", 32),
            ("protocol", "PROTO", 6),
            ("skills", "SKILLS", 7),
            ("url", "A2A URL", 50),
        ],
    )


@agents.command(name="list")
@click.option("--state", default=None, help="Filter by state (active, inactive, draft).")
@click.option("--search", default=None, help="Search by name.")
@click.option("--show-drift", is_flag=True, default=False,
              help="Show ONLY agents that have drifted from their source config.")
@click.option("--show-test/--no-show-test", "show_test", default=True, show_default=True,
              help="Include test agents (tagged test-agent:true). On by default so the "
                   "listing shows ALL agents; pass --no-show-test to hide them.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.pass_context
def agents_list(ctx, state, search, show_drift, show_test, page, page_size, fetch_all):
    """List agents.

    The DRIFT column is always shown (DRIFT / UP-TO-DATE), so you can do:
      torana agents list | grep DRIFT      # only drifted agents

    Use --show-drift to filter the listing to drifted agents only.

    Test agents (tagged test-agent:true) are shown by default. Pass
    --no-show-test to exclude them.

    \b
    Examples:
      torana agents list
      torana agents list --state active --search vuln
      torana agents list --show-drift          # which agents differ from their source config
      torana agents list --json | jq '.items[] | select(.state == "draft") | .name'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if state:
        params["state"] = state
    if search:
        params["search"] = search
    # Drift status is always requested so the DRIFT column is always populated.
    params["show_drift"] = "true"
    # Include test agents by default so `torana agents list` shows ALL agents.
    if show_test:
        params["show_test"] = "true"

    # --show-drift is a client-side filter, so it must scan the whole result set,
    # not just one page — force pagination through everything when filtering.
    fetch_all = fetch_all or show_drift

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                p.update({k: v for k, v in params.items() if k not in ("skip", "limit")})
                data = client.get("agents/", params=p)
                items, total = _extract_items(data)
                all_items.extend(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            items = all_items
            result_page, result_page_size = 1, len(all_items)
        else:
            data = client.get("agents/", params=params)
            items, _total = _extract_items(data)
            result_page, result_page_size = page, effective_page_size
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Derive the grep-friendly DRIFT / UP-TO-DATE column value on every row.
    for item in items:
        if isinstance(item, dict):
            item["drift"] = _drift_label(item)

    # --show-drift narrows the listing to drifted agents only (client-side).
    if show_drift:
        items = [i for i in items if isinstance(i, dict) and i.get("has_drift")]

    result = {"items": items, "total": len(items), "page": result_page,
              "page_size": result_page_size}
    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@agents.command(name="create")
@click.option("--name", default=None)
@click.option("--description", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def agents_create(ctx, name, description, input_file):
    """Create a new agent.

    \b
    Example:
      torana agents create --file agent.yaml
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if description:
        body["description"] = description

    if not body.get("name"):
        click.echo("ERROR: --name is required (or provide --file with 'name' field).", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post("agents/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created agent: {data.get('id', 'unknown')}")
        click.echo(f"  Name: {data.get('name', '')}")


@agents.command(name="cache")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def agents_cache(ctx, page, page_size, fetch_all):
    """Get Agent Cache Status."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "agents/cache"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@agents.command(name="clear-cache")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def agents_clear_cache(ctx, yes):
    """Clear Agent Cache."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = "agents/cache"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agents.command(name="skills")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def agents_skills(ctx, page, page_size, fetch_all):
    """List Skills."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "agents/skills"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@agents.command(name="settings")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def agents_settings(ctx, page, page_size, fetch_all):
    """Get Skill Settings."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "agents/skills/settings"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


# ──────────────────────────────────────────────────────────────────────────
# Instance reads regrouped from `<noun>-by-<param>` leaves onto verbs
# (CLI Discoverability Contract, rule 2 — see ../CLAUDE.md). The route
# parameter belongs in the positional ARGUMENT, not in the command name.
#
# Old flat names remain as HIDDEN aliases for ONE release (D4).
# ──────────────────────────────────────────────────────────────────────────


@agents.group(name="source-config")
def agents_source_config_grp():
    """Agent/prompt source config as it exists on disk.

    Examples:
      torana agents source-config agent --help
    """


@agents.group(name="skill")
def agents_skill_grp():
    """One agent skill, by name.

    Examples:
      torana agents skill get --help
    """


@agents.group(name="cache-entry")
def agents_cache_entry_grp():
    """One provider (Gemini) cache entry, by name.

    Examples:
      torana agents cache-entry get --help
    """


@agents_skill_grp.command(name="get")
@click.argument("SKILL_NAME", metavar="SKILL_NAME")
@click.pass_context
def agents_skills_by_skill_name(ctx, skill_name):
    """Get Skill Detail."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"agents/skills/{skill_name}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agents.command(name="update-skill-setting")
@click.argument("SKILL_NAME", metavar="SKILL_NAME")
@click.option("--enabled", "enabled", type=bool, required=True)
@click.pass_context
def agents_update_skill_setting(ctx, skill_name, enabled):
    """Update Skill Setting."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"agents/skills/{skill_name}/settings"
    body = {}
    body["enabled"] = enabled

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agents.command(name="reload")
@click.pass_context
def agents_reload(ctx):
    """Reload Skills Endpoint."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "agents/skills/reload"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agents.command(name="tenant-plans")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--page", "page", type=int, default=1)
@click.option("--size", "size", type=int, default=25)
@click.option("--status", "status", default=None)
@click.option("--agent-id", "agent_id", default=None)
@click.option("--search", "search", default=None, help="Search title/plan_key")
@click.option("--sort-by", "sort_by", default="updated_at")
@click.option("--sort-order", "sort_order", default="desc")
@click.pass_context
def agents_tenant_plans(ctx, page, size, status, agent_id, search, sort_by, sort_order, page_size, fetch_all):
    """Browse Tenant Plans."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "agents/plans"
    params = {}
    if page is not None:
        params["page"] = page
    if size is not None:
        params["size"] = size
    if status is not None:
        params["status"] = status
    if agent_id is not None:
        params["agent_id"] = agent_id
    if search is not None:
        params["search"] = search
    if sort_by is not None:
        params["sort_by"] = sort_by
    if sort_order is not None:
        params["sort_order"] = sort_order

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "page": page_num}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@agents.group(name="admin")
def agents_admin():
    """Cross-tenant agent administration (super admin only)."""


@agents_admin.command(name="plans")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--page", "page", type=int, default=1)
@click.option("--size", "size", type=int, default=25)
@click.option("--status", "status", default=None)
@click.option("--agent-id", "agent_id", default=None)
@click.option("--session-id", "session_id", default=None)
@click.option("--workspace-id", "workspace_id", default=None)
@click.option("--tenant-id", "tenant_id", default=None)
@click.option("--search", "search", default=None, help="Search title/plan_key")
@click.option("--sort-by", "sort_by", default="created_at")
@click.option("--sort-order", "sort_order", default="desc")
@click.pass_context
def agents_admin_plans(ctx, page, size, status, agent_id, session_id, workspace_id, tenant_id, search, sort_by, sort_order, page_size, fetch_all):
    """Admin Browse Plans."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "agents/admin/plans"
    params = {}
    if page is not None:
        params["page"] = page
    if size is not None:
        params["size"] = size
    if status is not None:
        params["status"] = status
    if agent_id is not None:
        params["agent_id"] = agent_id
    if session_id is not None:
        params["session_id"] = session_id
    if workspace_id is not None:
        params["workspace_id"] = workspace_id
    if tenant_id is not None:
        params["tenant_id"] = tenant_id
    if search is not None:
        params["search"] = search
    if sort_by is not None:
        params["sort_by"] = sort_by
    if sort_order is not None:
        params["sort_order"] = sort_order

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "page": page_num}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@agents.command(name="transition-plan-status")
@click.argument("PLAN_ID", metavar="PLAN_ID")
@click.option("--status", "status", required=True, help="Target status")
@click.option("--reason", "reason", default=None, help="Reason for the transition")
@click.pass_context
def agents_transition_plan_status(ctx, plan_id, status, reason):
    """Admin Transition Plan Status."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"agents/admin/plans/{plan_id}/status"
    body = {}
    body["status"] = status
    if reason is not None:
        body["reason"] = reason

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agents.command(name="models")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def agents_models(ctx, page, page_size, fetch_all):
    """Get Available Models."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "agents/models"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@agents.command(name="health-summary")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--health-status", "health_status", default=None)
@click.option("--agent-type", "agent_type", default=None)
@click.option("--sort-by", "sort_by", default=None)
@click.option("--show-test", "show_test", type=bool, default=False, help="Include test agents (tagged with test-agent:true)")
@click.option("--show-drift", "show_drift", type=bool, default=False, help="Include drift detection (DB vs file) for each agent")
@click.option("--show-retries", "show_retries", is_flag=True, default=False, help="Include LLM retry telemetry (MALFORMED / empty-STOP) per agent")
@click.option("--retry-window-days", "retry_window_days", default=7, show_default=True, type=int, help="Lookback window (days) for --show-retries")
@click.pass_context
def agents_health_summary(ctx, health_status, agent_type, sort_by, show_test, show_drift, show_retries, retry_window_days, page, page_size, fetch_all):
    """Get Health Summary."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "agents/health-summary"
    params = {}
    if health_status is not None:
        params["health_status"] = health_status
    if agent_type is not None:
        params["agent_type"] = agent_type
    if sort_by is not None:
        params["sort_by"] = sort_by
    if show_test is not None:
        params["show_test"] = show_test
    if show_drift is not None:
        params["show_drift"] = show_drift
    if show_retries:
        params["show_retries"] = True
        params["retry_window_days"] = retry_window_days
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@agents.command(name="agents-with-drift")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--state", "state", default=None, help="Filter by agent state")
@click.option("--agent-type", "agent_type", default=None, help="Filter by agent type")
@click.option("--limit", "limit", type=int, default=100, help="Maximum number of agents to check")
@click.pass_context
def agents_agents_with_drift(ctx, state, agent_type, limit, page, page_size, fetch_all):
    """List Agents With Drift."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "agents/drift"
    params = {}
    if state is not None:
        params["state"] = state
    if agent_type is not None:
        params["agent_type"] = agent_type
    if limit is not None:
        params["limit"] = limit
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@agents.command(name="stale-tools")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def agents_stale_tools(ctx, page, page_size, fetch_all):
    """Check All Stale Tools."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "agents/stale-tools"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@agents.command(name="reconcile-all")
@click.option("--dry-run", "dry_run", type=bool, default=True)
@click.option("--remove-stale", "remove_stale", type=bool, default=False)
@click.pass_context
def agents_reconcile_all(ctx, dry_run, remove_stale):
    """Reconcile All Agents."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "agents/reconcile"
    params = {}
    if dry_run is not None:
        params["dry_run"] = dry_run
    if remove_stale is not None:
        params["remove_stale"] = remove_stale

    client = _client(ctx)
    try:
        data = client.post(path, json={}, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agents.command(name="thresholds")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def agents_thresholds(ctx, page, page_size, fetch_all):
    """Get System Compaction Thresholds."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "agents/compaction/thresholds"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@agents.command(name="compaction-settings")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def agents_compaction_settings(ctx, page, page_size, fetch_all):
    """Get System Compaction Settings."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "agents/compaction/settings"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@agents.command(name="provider-cache")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def agents_provider_cache(ctx, page, page_size, fetch_all):
    """List Gemini Cache Entries."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "agents/provider-cache/list"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Text format: the API entries carry a nested `usage` object (audit-join:
    # creating/using sessions + savings) + derived age/ttl that a flat column
    # dump can't show. Render a purpose-built summary so the default view
    # surfaces the tracking metrics without forcing --json. json/yaml/raw pass
    # through untouched (full nested payload).
    if fmt == "text":
        _render_provider_cache_text(data)
        return
    output(data, fmt=fmt, fields=fields, raw=raw)


def _fmt_secs(s):
    """Human-readable duration from seconds (e.g. 1493 -> '24m 53s')."""
    if s is None:
        return "-"
    s = int(s)
    if s < 0:
        return "expired"
    m, sec = divmod(s, 60)
    h, m = divmod(m, 60)
    if h:
        return f"{h}h {m}m"
    if m:
        return f"{m}m {sec}s"
    return f"{sec}s"


def _render_provider_cache_text(data):
    """Readable text rendering of enriched provider-cache entries."""
    entries = data.get("entries", data.get("items", [])) if isinstance(data, dict) else data
    if not entries:
        click.echo("No provider cache entries.")
        return
    click.echo(f"\nProvider cache entries: {len(entries)}\n")
    for e in entries:
        u = e.get("usage") or {}
        name = (e.get("name") or "").replace("cachedContents/", "")
        model = u.get("model_name") or (e.get("model") or "").replace("models/", "") or "?"
        click.echo(f"● {name}")
        click.echo(f"    model={model}   age={_fmt_secs(e.get('age_seconds'))}   "
                   f"ttl={_fmt_secs(e.get('ttl_remaining_seconds'))}"
                   f"{'  (EXPIRED)' if e.get('is_expired') else ''}")
        click.echo(f"    sessions={u.get('total_sessions', 0)}  turns={u.get('total_turns', 0)}  "
                   f"cache_read_tokens={u.get('total_cache_read_tokens', 0):,}")
        creator = u.get("creating_session_id")
        if creator:
            click.echo(f"    created_by: {creator}")
        for s in (u.get("sessions") or []):
            tag = "creator" if s.get("is_creator") else "user"
            # tenant is the REAL value from the audit log (not the truncated fragment in
            # the Gemini display_name). It answers "whose session read this cache?", which
            # is the question that matters once one cache serves many sessions.
            _tenant = s.get("tenant_id")
            click.echo(f"      - [{tag}] {s.get('session_id')}  "
                       f"agent={s.get('agent_name') or '?'}  turns={s.get('turns', 0)}  "
                       f"read={s.get('cache_read_tokens', 0):,}"
                       + (f"  tenant={_tenant}" if _tenant else ""))
        click.echo("")


@agents_cache_entry_grp.command(name="get")
@click.argument("CACHE_NAME", metavar="CACHE_NAME")
@click.pass_context
def agents_list_by_cache_name(ctx, cache_name):
    """Get Gemini Cache Entry."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"agents/provider-cache/list/{cache_name}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agents.command(name="delete-provider-cache")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.option("--cache-names", "cache_names", required=True, help="List of cache names to delete")
@click.pass_context
def agents_delete_provider_cache(ctx, cache_names, yes):
    """Delete Gemini Cache Entries."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = "agents/provider-cache/"
    body = {}
    body["cache_names"] = cache_names

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agents.command(name="all")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def agents_all(ctx, yes):
    """Delete All Gemini Cache Entries."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = "agents/provider-cache/all"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agents_source_config_grp.command(name="agent")
@click.argument("AGENT_NAME", metavar="AGENT_NAME")
@click.pass_context
def source_config_agents_by_agent_name(ctx, agent_name):
    """Get Agent Source Config."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"source-config/agents/{agent_name}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agents_source_config_grp.command(name="prompt")
@click.argument("PROMPT_NAME", metavar="PROMPT_NAME")
@click.pass_context
def source_config_prompts_by_prompt_name(ctx, prompt_name):
    """Get Prompt Source Config."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"source-config/prompts/{prompt_name}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agents.command(name="code-executions-list")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def agents_code_executions_list(ctx, page, page_size):
    """List code executions."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        data = client.get("code-executions", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@agents.command(name="code-executions-get")
@click.argument("EXECUTION_ID", metavar="EXECUTION_ID")
@click.pass_context
def agents_code_executions_get(ctx, execution_id):
    """Get a specific code execution by ID."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"code-executions/{execution_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ---------------------------------------------------------------------------
# HITL: respond + checkpoint chain
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Workspace intents
# ---------------------------------------------------------------------------

@agents.command(name="workspace-intents")
@click.argument("workspace_id", metavar="WORKSPACE_ID")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.pass_context
def agents_workspace_intents(ctx, workspace_id, page, page_size, fetch_all):
    """List intents for a workspace (agent-builder view).

    \b
    Example:
      torana agents workspace-intents <WORKSPACE_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(f"workspaces/{workspace_id}/intents", params=p)
                items = data.get("items", data if isinstance(data, list) else [])
                all_items.extend(items)
                total = data.get("total", len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(f"workspaces/{workspace_id}/intents", params=params)
            result = data if isinstance(data, dict) and "items" in data else {
                "items": data if isinstance(data, list) else [],
                "total": len(data) if isinstance(data, list) else 0,
            }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields)


@agents.command(name="workspace-intent")
@click.argument("workspace_id", metavar="WORKSPACE_ID")
@click.argument("intent_id", metavar="INTENT_ID")
@click.pass_context
def agents_workspace_intent(ctx, workspace_id, intent_id):
    """Get a single workspace intent (agent-builder view).

    \b
    Example:
      torana agents workspace-intent <WORKSPACE_ID> <INTENT_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"workspaces/{workspace_id}/intents/{intent_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agents.command(name="workspace-intent-lineage")
@click.argument("workspace_id", metavar="WORKSPACE_ID")
@click.argument("intent_id", metavar="INTENT_ID")
@click.pass_context
def agents_workspace_intent_lineage(ctx, workspace_id, intent_id):
    """Get the supersession lineage for a workspace intent (agent-builder view).

    \b
    Example:
      torana agents workspace-intent-lineage <WORKSPACE_ID> <INTENT_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"workspaces/{workspace_id}/intents/{intent_id}/lineage")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ---------------------------------------------------------------------------
# Audit: session intents
# ---------------------------------------------------------------------------

@agents.command(name="session-intents")
@click.argument("session_id", metavar="SESSION_ID")
@click.pass_context
def agents_session_intents(ctx, session_id):
    """Get intents generated by an audit session.

    \b
    Example:
      torana agents session-intents <SESSION_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"audit/sessions/{session_id}/intents")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@agents.command(name="rendered-prompt")
@click.argument("AGENT_ID", metavar="AGENT_ID")
@click.pass_context
def agents_rendered_prompt(ctx, agent_id):
    """Show the fully rendered system prompt as the LLM would receive it.

    Unlike 'torana prompts get', which returns the static template stored in the
    database, this command applies all runtime substitutions — including the
    datalake terse schema for sql-generation agents.

    The backend uses the exact same apply_schema_injection() + fetch_schema_text()
    functions that the before_model_callback uses, so the output is guaranteed
    identical to what the LLM sees on turn 1.

    \b
    Example:
      torana agents rendered-prompt <AGENT_ID>
      torana agents rendered-prompt <AGENT_ID> --format json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"agents/{agent_id}/rendered-prompt")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt == "text":
        # For text mode, print the rendered prompt directly — it's the main payload.
        rendered = data.get("rendered_prompt", "") if isinstance(data, dict) else str(data)
        schema_injected = data.get("schema_injected", False) if isinstance(data, dict) else False
        schema_bytes = data.get("schema_bytes", 0) if isinstance(data, dict) else 0
        agent_name = data.get("agent_name", "") if isinstance(data, dict) else ""

        click.echo(f"Agent: {agent_name}  (id: {agent_id})")
        if schema_injected:
            click.echo(f"Schema injected: yes ({schema_bytes} bytes)")
        else:
            click.echo("Schema injected: no")
        click.echo("---")
        click.echo(rendered)
    else:
        output(data, fmt=fmt, fields=fields)


_STALL_COLS = [
    ("created_at", "TIME", 26),
    # TENANT is shown because this view spans ALL tenants — without it a super-admin sees a
    # guard trip but cannot tell whose turn tripped it.
    ("tenant_id", "TENANT", 14),
    ("kind", "KIND", 12),
    ("action", "ACTION", 12),
    ("reason", "REASON", 34),
    ("agent_name", "AGENT", 22),
    ("tool_name", "TOOL", 16),
    ("measured_summary", "MEASURED", 30),
]


@agents.command(name="stall-events")
@click.option("--session", "session_id", help="Filter by chat session id")
@click.option("--turn", "turn_id", help="Filter by turn id")
@click.option("--agent-name", help="Filter by agent name")
@click.option("--kind", help="Filter by kind (output_cap|query_lint|context_ceiling|turn_cap|guard_reset|source_cap|tool_guard)")
@click.option("--tenant", "tenant_id", help="Narrow to ONE tenant id. Omit to see ALL tenants "
                                            "(this is a super-admin-only view).")
@click.option("--limit", default=50, show_default=True, help="Max results")
@click.pass_context
def agents_stall_events(ctx, session_id, turn_id, agent_name, kind, tenant_id, limit):
    """List LLM stall-guard interventions (output caps, query lints, context aborts).

    Each row is one guard firing — what the system trimmed/refused/aborted, on which
    turn, by which agent, with the measured numbers. This is the DB-backed CLI view
    of the same data shown in the SA chat "Guard Interventions" panel.

    Spans ALL tenants by default — guard trips happen in tenant sessions, and this is a
    super-admin-only view. Use --tenant to narrow to one.

    Examples:
      torana agents stall-events
      torana agents stall-events --session <id>
      torana agents stall-events --kind tool_guard --limit 100
      torana agents stall-events --tenant <tenant-id>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {"limit": min(limit, 100)}
    if session_id:
        params["session_id"] = session_id
    if turn_id:
        params["turn_id"] = turn_id
    if agent_name:
        params["agent_name"] = agent_name
    if kind:
        params["kind"] = kind
    if tenant_id:
        params["tenant_id"] = tenant_id

    client = _client(ctx)
    try:
        data = client.get("audit/stall-events", params=params)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    items = data.get("items", []) if isinstance(data, dict) else data
    total = data.get("total_count", len(items)) if isinstance(data, dict) else len(items)
    # flatten `measured` into a readable summary column for text output
    for it in items:
        m = it.get("measured") or {}
        it["measured_summary"] = ", ".join(f"{k}={v}" for k, v in m.items()) if m else ""
    result = {"items": items, "total_count": total}
    output(result, fmt=fmt, raw=raw, fields=fields, columns=_STALL_COLS)


# ── Per-turn execution observability (Agent Execution Observability — Track A) ──
#
# `torana agents turns <session>`      — one line per turn (the SA glance)
# `torana agents turn <session> <tid>` — the full boundary timeline for one turn
#
# Under the existing `agents` semantic group (feedback_cli_semantic_grouping). SA
# sees cross-tenant; tenant-admin sees own (backend enforces). Backend:
# GET /api/v1/audit/turns/{session_id}[/{turn_id}].

def _turn_summary_line(seq: int, rec: dict) -> str:
    """One readable line per turn (spec § 3.5):
    `turn 3 | L2 Security_Data_Resolver | 7 llm, 4 tool | ⚠ recall×4 | uncertain(vulnerabilities 0.73) | 41s`
    """
    record = rec.get("record") or {}
    summary = record.get("summary") or {}
    layers = summary.get("layers_touched") or []
    agents_touched = summary.get("agents_touched") or []
    llm = summary.get("llm_calls", 0)
    tools = summary.get("tool_calls", 0)
    warnings = summary.get("warnings") or []
    grounding = summary.get("grounding") or {}
    elapsed_ms = rec.get("elapsed_ms") or 0

    layer_lbl = "/".join(layers) if layers else "-"
    agent_lbl = ", ".join(agents_touched) if agents_touched else "-"
    parts = [
        f"turn {seq}",
        f"{layer_lbl} {agent_lbl}",
        f"{llm} llm, {tools} tool",
    ]
    # Repeated-tool ⚠ — pull the recall×N shape out of tools_by_name.
    tbn = summary.get("tools_by_name") or {}
    repeats = [f"{n}×{c}" for n, c in sorted(tbn.items()) if c >= 3]
    if repeats:
        parts.append("⚠ " + ", ".join(repeats))
    elif warnings:
        parts.append("⚠ " + warnings[0])
    if grounding.get("outcome"):
        tables = ", ".join(grounding.get("resolved_tables") or []) or "-"
        parts.append(f"{grounding['outcome']}({tables})")
    parts.append(f"{round(elapsed_ms / 1000)}s")
    return " | ".join(parts)


@agents.command(name="turns")
@click.argument("session_id", metavar="SESSION_ID")
@click.option("--limit", default=100, show_default=True, help="Max turns (<=100)")
@click.option("--offset", default=0, show_default=True, help="Turns to skip")
@click.pass_context
def agents_turns(ctx, session_id, limit, offset):
    """List per-turn ExecutionRecords for a session (most recent first).

    Each line is a one-glance summary — layers/agents touched, llm+tool counts, the
    repeated-tool ⚠ (e.g. `recall×4`), grounding outcome, and duration — so a silent
    failure is visible without decoding a single Jaeger span.

    \b
    Examples:
      torana agents turns <session_id>
      torana agents turns <session_id> --json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(
            f"audit/turns/{session_id}",
            params={"limit": min(limit, 100), "offset": offset},
        )
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    turns = data.get("turns", []) if isinstance(data, dict) else (data or [])

    if fmt == "text":
        if not turns:
            click.echo("No execution records for this session.")
            return
        # Most recent first from the API; number oldest→newest for readability.
        total = len(turns)
        for idx, rec in enumerate(turns):
            seq = total - idx
            click.echo(_turn_summary_line(seq, rec))
        return

    # json/yaml/raw — passthrough the § 3.3.2 shape.
    output({"items": turns, "total_count": len(turns)}, fmt=fmt, raw=raw, fields=fields)


@agents.command(name="turn")
@click.argument("session_id", metavar="SESSION_ID")
@click.argument("turn_id", metavar="TURN_ID")
@click.pass_context
def agents_turn(ctx, session_id, turn_id):
    """Show the full boundary timeline for one turn (readable).

    Renders every callback boundary (before_model / after_model / before_tool /
    after_tool / ground_need / l0_primitive) across every layer, plus the summary
    banner (warnings first).

    \b
    Examples:
      torana agents turn <session_id> <turn_id>
      torana agents turn <session_id> <turn_id> --json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"audit/turns/{session_id}/{turn_id}")
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    record = (data or {}).get("record") or {}
    summary = record.get("summary") or {}
    boundaries = record.get("boundaries") or []

    # Header
    elapsed_ms = data.get("elapsed_ms") or 0
    click.echo(f"Turn {turn_id}")
    click.echo(f"  session   : {data.get('session_id')}")
    click.echo(f"  agent_id  : {data.get('agent_id')}")
    click.echo(f"  trace_id  : {data.get('trace_id')}")
    click.echo(f"  elapsed   : {round(elapsed_ms / 1000)}s")
    click.echo(
        f"  totals    : {summary.get('llm_calls', 0)} llm, "
        f"{summary.get('tool_calls', 0)} tool, "
        f"layers {', '.join(summary.get('layers_touched') or []) or '-'}"
    )

    warnings = summary.get("warnings") or []
    if warnings:
        click.echo("  ⚠ warnings:")
        for w in warnings:
            click.echo(f"      - {w}")

    # L1 grounding decisions — the high-value view. One block per grounded need
    # (before_agent boundary), showing outcome + resolved tables + candidate scores,
    # and — when expansion ran — the anchor + per-neighbor kept/dropped/reason.
    _render_grounding(boundaries)

    click.echo("  boundaries:")
    for b in boundaries:
        seq = b.get("seq")
        kind = b.get("kind", "-")
        layer = b.get("layer", "-")
        agent = b.get("agent", "-")
        payload = b.get("payload") or {}
        flags = b.get("flags") or []
        payload_str = ", ".join(f"{k}={v}" for k, v in payload.items())
        flag_str = (" [" + ", ".join(str(f) for f in flags) + "]") if flags else ""
        click.echo(f"    {seq:>3} {layer:<3} {kind:<14} {agent:<26} {payload_str}{flag_str}")


# Non-color cue for the four grounding outcomes (user is red/green colorblind:
# every outcome carries a distinct glyph + word, never color alone).
_GROUNDING_OUTCOME_CUES = {
    "resolvable": ("✓", "GROUNDED"),
    "resolvable_via_expansion": ("⤢", "GROUNDED via EXPANSION"),
    "gap": ("∅", "GAP — no data"),
    "low_confidence_ungrounded": ("≈", "STEPPED ASIDE — low confidence"),
}


def _render_grounding(boundaries):
    """Print one grounding block per before_agent boundary that carries a grounding
    payload. Faithful to the frozen shape (GROUNDING_PANEL_RENDER_HANDOFF.md): outcome,
    resolved tables, candidate scores, and the full expansion neighbor table."""
    grounded = [
        b for b in boundaries
        if b.get("kind") == "before_agent"
        and isinstance((b.get("payload") or {}).get("grounding"), dict)
    ]
    if not grounded:
        return

    click.echo("  grounding:")
    for b in grounded:
        g = (b.get("payload") or {})["grounding"]
        outcome = g.get("outcome") or "unknown"
        glyph, label = _GROUNDING_OUTCOME_CUES.get(outcome, ("?", outcome.upper()))
        tables = ", ".join(g.get("resolved_tables") or []) or "-"
        click.echo(f"    {glyph} {label}   tables: {tables}")

        # Candidate scores — the retrieval signal behind every decision.
        cands = g.get("candidates") or []
        if cands:
            cand_str = ", ".join(
                f"{c.get('name')}={c.get('score')}" for c in cands[:8]
            )
            click.echo(f"        candidates: {cand_str}")

        # Stepped-aside: surface the low-confidence signal + gap reason (tuning signal).
        if outcome == "low_confidence_ungrounded" or g.get("low_confidence"):
            reason = g.get("gap_reason") or "low_confidence"
            click.echo(f"        low-confidence: {reason} (resolver fell back to discovery)")

        # Expansion ran — the high-value view: per-neighbor kept/dropped + reason.
        exp = g.get("expansion")
        if isinstance(exp, dict):
            anchor = exp.get("anchor") or "-"
            kept = ", ".join(exp.get("kept") or []) or "-"
            click.echo(f"        expansion: anchor={anchor}, pulled=[{kept}]")
            neighbors = exp.get("neighbors_considered") or []
            if neighbors:
                click.echo(f"        {'NEIGHBOR':<22} {'RELEVANCE':<10} {'DECISION':<8} WHY")
                for n in neighbors:
                    decision = "keep" if n.get("kept") else "drop"
                    click.echo(
                        f"        {str(n.get('name', '-')):<22} "
                        f"{str(n.get('relevance', '-')):<10} "
                        f"{decision:<8} {n.get('reason', '')}"
                    )


# ─────────────────────────────────────────────────────────────────────────────
# BACK-COMPAT — hidden alias for the old flat `admin-plans` name.
# ⏳ ONE RELEASE ONLY (decision D4). Delete next release.
# ─────────────────────────────────────────────────────────────────────────────

def _register_legacy_agents_aliases() -> None:
    import copy
    _cmd = agents_admin.commands.get("plans")
    if _cmd is not None:
        _alias = copy.copy(_cmd)
        _alias.name = "admin-plans"
        _alias.hidden = True
        agents.add_command(_alias)


_register_legacy_agents_aliases()


# ──────────────────────────────────────────────────────────────────────────
# BACK-COMPAT — hidden aliases for the old `<noun>-by-<param>` names.
# ⏳ ONE RELEASE ONLY (decision D4). Delete this block next release.
# ──────────────────────────────────────────────────────────────────────────

_LEGACY_BY_PARAM_AGENTS = {
    "agents-by-agent-name": ("source-config", "agent"),
    "list-by-cache-name": ("cache-entry", "get"),
    "prompts-by-prompt-name": ("source-config", "prompt"),
    "skills-by-skill-name": ("skill", "get"),
}


def _register_legacy_agents_by_param() -> None:
    """Old flat names, hidden so they cannot be discovered anew."""
    import copy
    for _old, (_sub, _verb) in _LEGACY_BY_PARAM_AGENTS.items():
        _grp = agents.commands.get(_sub)
        if not isinstance(_grp, click.Group):
            continue
        _cmd = _grp.commands.get(_verb)
        if _cmd is None:
            continue
        # ⛔ Never let an alias overwrite a real group of the same name.
        if isinstance(agents.commands.get(_old), click.Group):
            continue
        _alias = copy.copy(_cmd)
        _alias.name = _old
        _alias.hidden = True
        agents.add_command(_alias)


_register_legacy_agents_by_param()
