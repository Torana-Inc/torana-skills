"""torana remediation-plans — the remediation-plan record (collection operations).

A remediation plan is ONE edit to ONE lock in ONE repository (FIX_PR_SPEC.md § 3.3.1): every class-2 and class-3
finding that one recompile fixes, across every subject repository that reported it. A runner proposes it from its
computed artifacts (`propose`); a person decides it (`torana remediation-plan <id> approve|override|refuse`); the
platform opens the PR (`torana remediation-plan <id> open-pr`). Instance operations live in `remediation_plan.py`.
"""

import json
import os
import sys
from typing import Optional

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import (
    EXIT_AUTH, EXIT_NOT_FOUND, EXIT_PERMISSION, EXIT_USAGE, EXIT_VALIDATION, APIError, ToranaClient, handle_api_error, handle_auth_error,
)
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW, CollectionGroup
from torana_cli.output import output
from torana_cli import fresh_token
from torana_cli import remediation_proposal as rprop

EXIT_RETRY_EXHAUSTED = 3

_PLAN_COLS = [
    ("id", "ID", 36),
    ("state", "STATE", 15),
    ("target_repository", "TARGET", 40),
    ("resolve_file", "LOCK", 32),
    ("pr_state", "PR", 13),
    ("blocked_by_text", "BLOCKED BY", 0),
]
_REFUSAL_COLS = [
    ("id", "ID", 36),
    ("kind", "KIND", 8),
    ("reason_code", "REASON", 18),
    ("package", "PACKAGE", 24),
    ("refused_by", "BY", 20),
    ("description", "NOTE", 0),
]
_MINT_COLS = [
    ("id", "ID", 36),
    ("target_repository", "TARGET", 40),
    ("actor", "ACTOR", 24),
    ("outcome", "OUTCOME", 8),
    ("expires_at", "EXPIRES", 20),
    ("revoked_at", "REVOKED", 0),
]


def _client(ctx) -> ToranaClient:
    """With `TORANA_TOKEN_CMD` set, every write first takes a fresh token from it (`fresh_token.py`)."""
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    return fresh_token.client_for(get_settings(profile).base_url, ToranaClient)


#: The extras worth a line under the server's sentence, in this order (DF's plan-route error set).
_ERROR_EXTRAS = ("needs_ack", "pr_url", "blocking_plan_id", "plan_id", "paths", "packages", "holder",
                 "expires_at")


def plan_api_error(e: APIError) -> None:
    """A plan-route error `{error, message, …}` at ANY status: the server's sentence first, with
    `(code, HTTP n)`, then the extras a person acts on (needs_ack, pr_url, blocking_plan_id, paths, …); exit
    with the CLI's code for the status. Anything else falls through to the shared handler."""
    d = e.detail
    if not (isinstance(d, dict) and d.get("error") and d.get("message")):
        handle_api_error(e)
        return
    click.echo(f"\nERROR: {d['message']} ({d['error']}, HTTP {e.status_code})", err=True)
    for k in _ERROR_EXTRAS:
        if d.get(k) not in (None, "", []):
            v = d[k]
            click.echo(f"  {k}: {', '.join(map(str, v)) if isinstance(v, list) else v}", err=True)
    sys.exit(e.exit_code)


def _call(fn, *args, **kwargs):
    """One request; auth and API errors print and exit with the CLI's codes."""
    try:
        return fn(*args, **kwargs)
    except AuthError as e:
        handle_auth_error(e)
    except APIError as e:
        plan_api_error(e)


def error_code(e: APIError) -> str:
    """The plan routes' error code: `detail.error` (FIX_PR_SPEC.md, DF's convention)."""
    return (e.detail or {}).get("error", "") if isinstance(e.detail, dict) else ""


def with_blocked_by_text(plan: dict) -> dict:
    """The `BLOCKED BY` column: one `<plan id or "not yet planned">: <reason>` per entry (§ 3.10.14)."""
    items = plan.get("blocked_by") or []
    return {**plan, "blocked_by_text": "; ".join(f"{b.get('plan_id') or 'not yet planned'}: {b.get('reason', '')}"
                                                 for b in items)}


@click.group(name="remediation-plans", cls=CollectionGroup, singular="remediation-plan")
@click.pass_context
def remediation_plans(ctx):
    """Remediation plans: one lock edit per repository, proposed by a runner, decided by a person.

    \b
    Instance operations (get, approve, override, refuse, reconsider, target-token, open-pr) are under
    `torana remediation-plan <ID>`.

    \b
    Examples:
      torana remediation-plans list --entry-alert-id <ALERT_UUID>
      torana remediation-plans propose --plan plan.json --findings findings.json --probe probe.json
      torana remediation-plans refusals --target-repository repo:github.com/acme/deploy
      torana remediation-plans settings get
    """
    ctx.ensure_object(dict)


# ── list ───────────────────────────────────────────────────────────────────────────

@remediation_plans.command(name="list")
@click.option("--alert-id", default=None, help="Plans with this alert as a member.")
@click.option("--entry-alert-id", default=None,
              help="Plans with a member that is this Inbox entry or has it as its parent (what the Inbox shows).")
@click.option("--subject-repository", default=None, metavar="REPO_KEY",
              help="Plans with a member from this repository. ⛔ Required for a CI token (its own repository).")
@click.option("--target-repository", default=None, metavar="REPO_KEY",
              help="Plans that edit this repository. A CI token may pass its OWN repository here to find approved "
                   "fixes that edit it — including ones another repository's scan raised — because it is the "
                   "runner that holds the write credential. That listing returns approved plans only.")
@click.option("--state", default=None,
              type=click.Choice(["proposed", "approved", "overridden", "removal_chosen", "refused", "superseded",
                                 "completed"]))
@click.option("--limit", default=50, type=click.IntRange(1, 100), show_default=True)
@click.option("--offset", default=0, type=click.IntRange(min=0), show_default=True)
@click.pass_context
def remediation_plans_list(ctx, alert_id, entry_alert_id, subject_repository, target_repository, state, limit,
                           offset):
    """List remediation plans.

    \b
    Examples:
      torana remediation-plans list --entry-alert-id <ALERT_UUID>
      torana remediation-plans list --target-repository repo:github.com/acme/deploy --state proposed
      torana remediation-plans list --subject-repository repo:github.com/acme/api --format json
    """
    params = {"limit": limit, "offset": offset}
    for k, v in dict(alert_id=alert_id, entry_alert_id=entry_alert_id, subject_repository=subject_repository,
                     target_repository=target_repository, state=state).items():
        if v:
            params[k] = v
    data = _call(_client(ctx).get, "remediation-plans", params=params) or {}
    data = {**data, "items": [with_blocked_by_text(p) for p in data.get("items") or []]}
    output(data, fmt=ctx.obj.get(CTX_FORMAT, "text"), raw=ctx.obj.get(CTX_RAW, False),
           fields=ctx.obj.get(CTX_FIELDS), columns=_PLAN_COLS)


# ── propose ────────────────────────────────────────────────────────────────────────

def _load(path: str, what: str):
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError) as exc:
        click.echo(f"ERROR: cannot read {what} {path}: {exc}", err=True)
        sys.exit(EXIT_USAGE)


def _reread(client: ToranaClient, proposal: dict, e: APIError) -> dict:
    """`group_conflict` / `stale_merge`: re-read the plan the server named (or the one being refreshed) before the
    one re-post (§ 3.4.7). A refresh whose plan is no longer the `proposed` plan on this lock is re-posted as a
    plain proposal (it joins or merges into whatever is open there now, rules 3-4) instead of repeating a refresh
    that cannot succeed; a refresh still aimed at the open plan is re-posted against its current state."""
    pid = (e.detail or {}).get("plan_id") or proposal.get("refresh_plan_id")
    if not pid:
        return proposal
    try:
        current = client.get(f"remediation-plans/{pid}") or {}
    except APIError:
        current = {}
    lock_key = f"{proposal['target_repository']}|{proposal['resolve_repository']}|{proposal['resolve_file']}"
    if proposal.get("refresh_plan_id") and (current.get("state") != "proposed"
                                            or current.get("lock_key") != lock_key):
        return {**proposal, "refresh_plan_id": None}
    return proposal


def _post_proposal(client: ToranaClient, proposal: dict) -> dict:
    """POST one proposal, with the § 3.4.7 retries: `refused_change` drops the named packages and re-posts once;
    `refused_plan` is skipped (exit 0: a person refused that edit); `group_conflict` / `stale_merge` re-read the
    plan and re-post once."""
    retried = False
    while True:
        try:
            data = client.post("remediation-plans", json=proposal)
            return {"status": "ok", "plan": data}
        except APIError as e:
            code = error_code(e)
            if e.status_code == 409 and code == "refused_plan":
                return {"status": "skipped_refused_plan", "plan_id": e.detail.get("plan_id"),
                        "message": e.detail.get("message")}
            if retried or e.status_code != 409 or code not in ("refused_change", "group_conflict", "stale_merge"):
                return {"status": "error", "http": e.status_code, "error": code or str(e),
                        "message": e.detail.get("message") if isinstance(e.detail, dict) else str(e.detail or e)}
            retried = True
            if code == "refused_change":
                proposal = rprop.drop_packages(proposal, list(e.detail.get("packages") or []))
                if not proposal["packages"]:
                    return {"status": "skipped_refused_change", "message": e.detail.get("message")}
            else:
                proposal = _reread(client, proposal, e)


@remediation_plans.command(name="propose")
@click.option("--plan", "plan_path", required=True, metavar="PLAN.json", help="remediation_plan.py --json output.")
@click.option("--findings", "findings_path", required=True, metavar="FINDINGS.json",
              help="The findings the plan was made from (`alerts reachability-queue --as-findings`).")
@click.option("--probe", "probe_path", required=True, metavar="PROBE.json",
              help="remediation_apply.py --apply --json output for that plan.")
@click.option("--refresh-plan-id", default=None, help="This probe re-proves that plan (its lock's proposal refreshes it).")
@click.option("--repo-key", default=None, metavar="REPO_KEY",
              help="Key of the plan's --repo tree (default: from its git origin remote).")
@click.option("--with-key", "with_keys", multiple=True, metavar="LABEL=KEY",
              help="Key of another scope tree, by its planner label (repeatable).")
@click.pass_context
def remediation_plans_propose(ctx, plan_path, findings_path, probe_path, refresh_plan_id, repo_key, with_keys):
    """Propose plans from a runner's plan, findings and probe: one POST per lock × repository.

    \b
    Every planner label is rewritten to a repository key and every path made repo-relative before anything is
    sent. A group whose probe did not reach gates_passed or needs_human is not proposed (listed as skipped).
    Exit 0 when every proposal was accepted or skipped as already refused; 3 when a conflict retry also failed.

    \b
    Examples:
      torana remediation-plans propose --plan plan.json --findings findings.json --probe probe.json
      torana remediation-plans propose --plan plan.json --findings findings.json --probe probe.json \\
          --repo-key repo:github.com/acme/api --with-key deploy/base-image=repo:github.com/acme/deploy
    """
    plan = _load(plan_path, "--plan")
    findings = _load(findings_path, "--findings")
    probe = _load(probe_path, "--probe")
    labels = {}
    for item in with_keys:
        label, sep, key = item.partition("=")
        if not sep or not key.startswith("repo:"):
            click.echo(f"ERROR: --with-key wants LABEL=repo:<host>/<org>/<repo>, got {item!r}", err=True)
            sys.exit(EXIT_USAGE)
        labels[label] = key
    client = _client(ctx)
    refresh = None
    if refresh_plan_id:
        current = _call(client.get, f"remediation-plans/{refresh_plan_id}") or {}
        refresh = (refresh_plan_id, current.get("lock_key"))
    try:
        keys = rprop.scope_keys(plan, repo_key, labels)
        proposals, skipped = rprop.build_proposals(plan, findings if isinstance(findings, list) else [], probe,
                                                   keys, refresh)
    except (rprop.ProposalError, KeyError) as exc:
        click.echo(f"ERROR: {exc}", err=True)
        sys.exit(EXIT_USAGE)

    results = []
    for p in proposals:
        try:
            r = _post_proposal(client, p)
        except AuthError as e:
            handle_auth_error(e)
            return
        lock_key = f"{p['target_repository']}|{p['resolve_repository']}|{p['resolve_file']}"
        plan_out = r.pop("plan", None) or {}
        results.append({"lock_key": lock_key, **r, "plan_id": r.get("plan_id") or plan_out.get("id"),
                        "state": plan_out.get("state"), "deferred_members": plan_out.get("deferred_members") or []})
    for s in skipped:
        results.append({"lock_key": None, "status": "not_proposed", **s})
    data = {"items": results, "total": len(results)}
    fmt = ctx.obj.get(CTX_FORMAT, "text")
    output(data, fmt=fmt, raw=ctx.obj.get(CTX_RAW, False), fields=ctx.obj.get(CTX_FIELDS),
           columns=[("status", "STATUS", 22), ("plan_id", "PLAN", 36), ("lock_key", "LOCK", 0)])
    errors = [r for r in results if r["status"] == "error"]
    if errors:
        for r in errors:
            click.echo(f"ERROR: {r['lock_key']}: {r.get('message') or r.get('error')} ({r.get('error')}, "
                       f"HTTP {r.get('http')})", err=True)
        sys.exit(propose_exit_code(errors))


def propose_exit_code(errors: list) -> int:
    """The most specific failure wins: 403 → 4, 401 → 5, 422 → 6, 404 → 3; only when every failure is a conflict
    that survived its retry is it 3 (retry later); otherwise 1."""
    codes = {APIError("", r.get("http") or 0).exit_code for r in errors}
    for c in (EXIT_PERMISSION, EXIT_AUTH, EXIT_VALIDATION, EXIT_NOT_FOUND):
        if c in codes:
            return c
    if all(r.get("error") in ("group_conflict", "stale_merge", "refused_change") for r in errors):
        return EXIT_RETRY_EXHAUSTED
    return 1


# ── refusals ───────────────────────────────────────────────────────────────────────

@remediation_plans.command(name="refusals")
@click.option("--target-repository", required=True, metavar="REPO_KEY")
@click.option("--limit", default=50, type=click.IntRange(1, 100), show_default=True)
@click.option("--offset", default=0, type=click.IntRange(min=0), show_default=True)
@click.pass_context
def remediation_plans_refusals(ctx, target_repository, limit, offset):
    """List the live refusals that block re-proposing an edit (a refused plan, a dropped package).

    \b
    Not for a CI token: refusals are a person's decisions.

    \b
    Examples:
      torana remediation-plans refusals --target-repository repo:github.com/acme/deploy
    """
    data = _call(_client(ctx).get, "remediation-plans/refusals",
                 params={"target_repository": target_repository, "limit": limit, "offset": offset})
    output(data, fmt=ctx.obj.get(CTX_FORMAT, "text"), raw=ctx.obj.get(CTX_RAW, False),
           fields=ctx.obj.get(CTX_FIELDS), columns=_REFUSAL_COLS)


# ── the tenant's settings ─────────────────────────────────────────────────────────

@remediation_plans.group(name="settings")
@click.pass_context
def remediation_plans_settings(ctx):
    """The tenant's remediation-plan settings (require_plan_approval).

    \b
    Off (the default): the PR is the only gate. A plan a person could approve is approved by the
    system, and the owning team reviews the PR. On: a person approves each plan in Torana first.

    \b
    Examples:
      torana remediation-plans settings get
      torana remediation-plans settings set --require-plan-approval
    """
    ctx.ensure_object(dict)


@remediation_plans_settings.command(name="get")
@click.pass_context
def remediation_plans_settings_get(ctx):
    """Show whether this tenant requires a person to approve each plan. Anyone who reads plans; never a CI token.

    \b
    Examples:
      torana remediation-plans settings get
      torana remediation-plans settings get --format json
    """
    data = _call(_client(ctx).get, "remediation-plans/settings")
    output(data, fmt=ctx.obj.get(CTX_FORMAT, "text"), fields=ctx.obj.get(CTX_FIELDS))


@remediation_plans_settings.command(name="set")
@click.option("--require-plan-approval/--no-require-plan-approval", "require", default=None,
              help="On: a person approves each plan before its PR. Off: the system approves; the PR is the gate.")
@click.pass_context
def remediation_plans_settings_set(ctx, require):
    """Turn plan approval on or off for this tenant. Needs `rule:update` (tenant admin); never a CI token.

    \b
    Turning it on never un-approves a plan. Turning it off approves nothing now: a proposed plan is
    approved by the system the next time it is proposed or refreshed.

    \b
    Examples:
      torana remediation-plans settings set --require-plan-approval
      torana remediation-plans settings set --no-require-plan-approval
    """
    if require is None:
        raise click.UsageError("Pass --require-plan-approval or --no-require-plan-approval.")
    data = _call(_client(ctx).put, "remediation-plans/settings", json={"require_plan_approval": require})
    output(data, fmt=ctx.obj.get(CTX_FORMAT, "text"), fields=ctx.obj.get(CTX_FIELDS))


# ── leases ─────────────────────────────────────────────────────────────────────────

@remediation_plans.group(name="lease")
@click.pass_context
def remediation_plans_lease(ctx):
    """One runner at a time per target repository (a lease with a TTL).

    \b
    Examples:
      torana remediation-plans lease acquire --plan-id <PLAN_UUID> --holder-run "$GITHUB_RUN_ID:$GITHUB_RUN_ATTEMPT"
      torana remediation-plans lease release <LEASE_UUID> --holder-run "$GITHUB_RUN_ID:$GITHUB_RUN_ATTEMPT"
    """
    ctx.ensure_object(dict)


@remediation_plans_lease.command(name="acquire")
@click.option("--plan-id", required=True)
@click.option("--holder-run", required=True, help="This run's id (`<run id>:<attempt>` or `local:<host>:<pid>`).")
@click.option("--ttl", type=click.IntRange(60, 3600), default=None, help="Seconds (server default when omitted).")
@click.pass_context
def remediation_plans_lease_acquire(ctx, plan_id, holder_run, ttl):
    """Take the lease on a plan's target repository. Exit 4 when another run holds it (`lease_held`).

    \b
    The holder's repository is set by the server from your token; it is never sent.

    \b
    Examples:
      torana remediation-plans lease acquire --plan-id <PLAN_UUID> --holder-run local:$(hostname):$$
    """
    body = {"plan_id": plan_id, "holder_run": holder_run, **({"ttl_seconds": ttl} if ttl else {})}
    try:
        data = _client(ctx).post("remediation-plans/leases", json=body)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        if e.status_code == 409 and error_code(e) == "lease_held":
            d = e.detail
            click.echo(f"lease held by {d.get('holder')} until {d.get('expires_at')}: {d.get('message', '')}",
                       err=True)
            sys.exit(EXIT_PERMISSION)
        plan_api_error(e)
        return
    output(data, fmt=ctx.obj.get(CTX_FORMAT, "text"), fields=ctx.obj.get(CTX_FIELDS))


@remediation_plans_lease.command(name="release")
@click.argument("lease_id")
@click.option("--holder-run", required=True, help="The run id the lease was acquired with.")
@click.pass_context
def remediation_plans_lease_release(ctx, lease_id, holder_run):
    """Release a lease this run holds (404 when it is not this run's, or already gone).

    \b
    Examples:
      torana remediation-plans lease release <LEASE_UUID> --holder-run local:$(hostname):$$
    """
    _call(_client(ctx).delete, f"remediation-plans/leases/{lease_id}", params={"holder_run": holder_run})
    click.echo(f"released {lease_id}", err=True)


# ── read tokens for a propose run (§ 3.4.11) ───────────────────────────────────────

def read_revoke_token() -> str:
    """The token to revoke: `TORANA_TARGET_TOKEN`, else stdin. ⛔ Never argv (it would land in shell history and
    in the process table)."""
    token = os.environ.get("TORANA_TARGET_TOKEN", "").strip()
    if not token and not sys.stdin.isatty():
        token = sys.stdin.read().strip()
    if not token:
        click.echo("ERROR: --revoke reads the token from stdin or TORANA_TARGET_TOKEN, never from argv",
                   err=True)
        sys.exit(EXIT_USAGE)
    return token


def revoke_on_github(token: str) -> Optional[str]:
    """GitHub's self-revoke: `DELETE /installation/token` with the token itself (204; 401 = already revoked or
    expired, nothing left to revoke). None when done, else a short error (no token, no response body)."""
    import httpx
    try:
        r = httpx.delete("https://api.github.com/installation/token", timeout=30,
                         headers={"Authorization": f"token {token}", "Accept": "application/vnd.github+json",
                                  "X-GitHub-Api-Version": "2022-11-28"})
    except httpx.HTTPError as exc:
        return f"cannot reach GitHub ({type(exc).__name__})"
    if r.status_code not in (204, 401):
        return f"GitHub answered HTTP {r.status_code}"
    return None


def refuse_token_on_argv(ctx, param, value):
    if value:
        click.echo("ERROR: a token is never passed on argv: pipe it on stdin or set TORANA_TARGET_TOKEN", err=True)
        sys.exit(EXIT_USAGE)
    return value


def mint_or_revoke(client: ToranaClient, mint_path: str, revoked_path_of, body: dict, revoke: bool,
                   mint_id: str) -> None:
    """Mint: print `{token, expires_at, repository, mint_id}` as JSON on stdout, nothing else. Revoke: GitHub
    first, then record `{"outcome": "revoked"}`, or `{"outcome": "revoke_failed", "error"}` and exit 1."""
    if revoke:
        if not mint_id:
            click.echo("ERROR: --revoke needs --mint-id", err=True)
            sys.exit(EXIT_USAGE)
        error = revoke_on_github(read_revoke_token())
        if error:
            # Best effort: the mint row says the revoke FAILED (the token may live until GitHub's hour), never
            # "revoked". A failure to record that is reported too; the exit is 1 either way.
            try:
                client.post(revoked_path_of(mint_id), json={"outcome": "revoke_failed", "error": error[:500]})
                recorded = "recorded as revoke_failed"
            except (APIError, AuthError) as exc:
                recorded = f"and recording it failed too ({type(exc).__name__})"
            except SystemExit:
                recorded = "and recording it failed too (no token)"
            click.echo(f"ERROR: revoke failed: {error}; {recorded}. GitHub expires the token within the hour.",
                       err=True)
            sys.exit(1)
        _call(client.post, revoked_path_of(mint_id), json={"outcome": "revoked"})
        click.echo(f"revoked {mint_id}", err=True)
        return
    data = _call(client.post, mint_path, json=body) or {}
    click.echo(json.dumps({k: data.get(k) for k in ("token", "expires_at", "repository", "mint_id")}))


@remediation_plans.command(name="target-token")
@click.option("--subject", required=True, metavar="REPO_KEY", help="Your own repository (a CI token's must match).")
@click.option("--target", required=True, metavar="REPO_KEY", help="A repository declared related to the subject.")
@click.option("--holder-run", required=True, help="This run's id.")
@click.option("--revoke", is_flag=True, help="Revoke a token minted by this command (token on stdin).")
@click.option("--mint-id", default=None, help="The mint to record as revoked (with --revoke).")
@click.option("--token", hidden=True, expose_value=False, callback=refuse_token_on_argv, is_eager=True)
@click.pass_context
def remediation_plans_target_token(ctx, subject, target, holder_run, revoke, mint_id):
    """A read-only, one-repository token for a propose run's checkout of a DECLARED related repository.

    \b
    Only for a target a tenant admin declared (`torana integration <IID> related-repos add`): 403 `not_related`
    otherwise. Prints JSON on stdout only; mask it in CI and revoke it after the checkout. For an approved plan,
    use `torana remediation-plan <ID> target-token` (no declaration needed).

    \b
    Examples:
      torana remediation-plans target-token --subject repo:github.com/acme/api \\
          --target repo:github.com/acme/deploy --holder-run "$GITHUB_RUN_ID:$GITHUB_RUN_ATTEMPT"
      echo "$TOKEN" | torana remediation-plans target-token --subject repo:github.com/acme/api \\
          --target repo:github.com/acme/deploy --holder-run "$RUN" --revoke --mint-id <MINT_UUID>
    """
    mint_or_revoke(_client(ctx), "remediation-plans/target-token",
                   lambda m: f"remediation-plans/target-tokens/{m}/revoked",
                   {"subject_repository": subject, "target_repository": target, "holder_run": holder_run},
                   revoke, mint_id)


@remediation_plans.group(name="target-tokens")
@click.pass_context
def remediation_plans_target_tokens(ctx):
    """The record of read tokens minted for propose runs (never a token).

    \b
    Examples:
      torana remediation-plans target-tokens list --subject repo:github.com/acme/api
    """
    ctx.ensure_object(dict)


@remediation_plans_target_tokens.command(name="list")
@click.option("--subject", required=True, metavar="REPO_KEY")
@click.option("--limit", default=50, type=click.IntRange(1, 100), show_default=True)
@click.option("--offset", default=0, type=click.IntRange(min=0), show_default=True)
@click.pass_context
def remediation_plans_target_tokens_list(ctx, subject, limit, offset):
    """List propose-run read-token mints of one subject repository: actor, target, expiry, revoked.

    \b
    Examples:
      torana remediation-plans target-tokens list --subject repo:github.com/acme/api --format json
    """
    data = _call(_client(ctx).get, "remediation-plans/target-tokens",
                 params={"subject_repository": subject, "limit": limit, "offset": offset})
    output(data, fmt=ctx.obj.get(CTX_FORMAT, "text"), raw=ctx.obj.get(CTX_RAW, False),
           fields=ctx.obj.get(CTX_FIELDS), columns=_MINT_COLS)
