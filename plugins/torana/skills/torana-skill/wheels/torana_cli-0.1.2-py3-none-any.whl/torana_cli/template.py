"""torana template — per-template instance commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(name="template", invoke_without_command=True)
@click.argument("template_id", metavar="TEMPLATE_ID")
@click.pass_context
def template(ctx, template_id):
    """Per-template instance commands.

    \b
    Examples:
      torana template <UUID> get
      torana template <UUID> update --name "New Name"
      torana template <UUID> delete --yes
      torana template <UUID> preview --user-values '{}'
      torana template <UUID> use --program-name "My Program" --owner admin@example.com --user-values '{}'
    """
    ctx.ensure_object(dict)
    ctx.obj["_template_id"] = template_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _tid(ctx) -> str:
    return ctx.obj.get("_template_id", "") if ctx.obj else ""


@template.command(name="get")
@click.pass_context
def template_get(ctx):
    """Get details for a specific template."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"templates/{_tid(ctx)}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@template.command(name="update")
@click.option("--name", default=None)
@click.option("--category", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def template_update(ctx, name, category, input_file):
    """Update a template."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if category:
        body["category"] = category

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"templates/{_tid(ctx)}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated template: {_tid(ctx)}")


@template.command(name="delete")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def template_delete(ctx, yes):
    """Delete a template."""
    _confirm(f"Delete template {_tid(ctx)}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"templates/{_tid(ctx)}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted template: {_tid(ctx)}")


@template.command(name="preview")
@click.option("--user-values", "user_values", required=True, help="User-provided values to preview in template.")
@click.pass_context
def template_preview(ctx, user_values):
    """Preview template with user-provided values."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = {"user_values": user_values}
    client = _client(ctx)
    try:
        data = client.post(f"templates/{_tid(ctx)}/preview", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@template.command(name="use")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with request body.")
@click.option("--created-by", "created_by", required=True, help="User creating the program.")
@click.option("--program-name", "program_name", required=True, help="Name for the new program.")
@click.option("--program-description", "program_description", default=None)
@click.option("--owner", "owner", required=True, help="Program owner email or identifier.")
@click.option("--user-values", "user_values", required=True, help="User-provided values for variable fields.")
@click.option("--tags", "tags", default=None)
@click.option("--priority", "priority", type=int, default=3)
@click.pass_context
def template_use(ctx, created_by, program_name, program_description, owner, user_values,
                 tags, priority, input_file):
    """Instantiate this template as a new program."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if created_by is not None:
        params["created_by"] = created_by

    if input_file:
        body = _load_input_file(input_file)
    else:
        body = {"program_name": program_name, "owner": owner, "user_values": user_values}
        if program_description is not None:
            body["program_description"] = program_description
        if tags is not None:
            body["tags"] = tags
        if priority is not None:
            body["priority"] = priority

    client = _client(ctx)
    try:
        data = client.post(f"templates/{_tid(ctx)}/use", json=body, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)
