"""One item of an app's Home: `torana app <APP_ID> ai-home item <ALERT_ID> …`.

Spec: docs/specs/HOME_SURFACE_SPEC.md § 3.4.6. Registered from ai_home.py on the `ai-home` group.

⭐ EVERY VERB CALLS CODE THAT EXISTS; none re-derives. What the page says about the item comes from the page's
`sections`; the live proof and its graph from the proof route `alert <ID> proof` reads (proof_view); the brief from
brief_view, as `alert <ID> brief` does. `check` compares the two: what the page stored against the proof now.
⛔ The brief is TWO commands, `brief get` and `brief write`: the agent command policy decides per command, never
per option, so a write behind an option of a read command would be runnable by an agent.
"""
import click

from torana_cli import home_sections as hs
from torana_cli.ai_home import _ctx
from torana_cli.ai_home_get import fetch_page, home_cmd
from torana_cli.client.auth import AuthError
from torana_cli.client.base import EXIT_NOT_FOUND, APIError, handle_api_error, handle_auth_error
from torana_cli.output import output

NOT_ON_PAGE = "This item is not on the current Home page."
ITEM_SECTIONS = ("ledger", "graph", "cites", "rows")


def stored_claims(page: dict, alert_id: str):
    """The item's claims as the page's proof stored them: {claim id: text}; None when the page did not prove it."""
    it = next((x for x in (page.get("proof") or {}).get("items") or [] if x.get("alert_id") == alert_id), None)
    return None if it is None else {c.get("id"): c.get("text") for c in it.get("claims") or []}


def compare_claims(stored: dict, live: dict) -> list:
    """Per claim id, in the page's order then the new ones: same · changed · gone (no longer claimed) · new."""
    out = []
    for cid, text in stored.items():
        if cid not in live:
            out.append({"id": cid, "state": "gone", "stored": text, "live": None})
        else:
            out.append({"id": cid, "state": "same" if live[cid] == text else "changed", "stored": text,
                        "live": live[cid]})
    out += [{"id": cid, "state": "new", "stored": None, "live": text} for cid, text in live.items() if cid not in stored]
    return out


def group_cites(lines: list) -> list:
    """Every proven fact the item's lines cite, once each, in page order."""
    seen, out = set(), []
    for ln in lines:
        for c in ln.get("cites") or []:
            if c.get("id") not in seen:
                seen.add(c.get("id"))
                out.append(c)
    return out


def register(ai_home, client_factory):
    """Attach the `item <ALERT_ID>` group to the `ai-home` group."""

    def _wid(ctx) -> str:
        return ctx.obj.get("_workspace_id", "") if ctx.obj else ""

    def _aid(ctx) -> str:
        return ctx.obj.get("_home_item_id", "") if ctx.obj else ""

    def _fail(e):
        handle_auth_error(e) if isinstance(e, AuthError) else handle_api_error(e)

    def _page(ctx, client):
        """The current page, or exit 3 with the plain sentence when the app has none."""
        try:
            return fetch_page(client, _wid(ctx))
        except APIError as e:
            if e.status_code == 404:
                click.echo("No Home page has been prepared for this app yet.", err=True)
                ctx.exit(EXIT_NOT_FOUND)
            raise

    def _group(ctx, page):
        found = hs.item_group(page.get("sections"), _aid(ctx))
        if found is None:
            click.echo(NOT_ON_PAGE, err=True)
            click.echo(f"  The items on it:  {home_cmd(_wid(ctx))} get --section needs-you", err=True)
            ctx.exit(EXIT_NOT_FOUND)
        return found

    @ai_home.group(name="item", invoke_without_command=True)
    @click.argument("alert_id", metavar="ALERT_ID")
    @click.pass_context
    def item(ctx, alert_id):
        """One item of the Home page: why it is there, its proof, the facts the page cited, and its AI brief.

        ALERT_ID is the id on a Needs-you line (the "→" commands under each line carry it).

        \b
        Examples:
          torana app <APP_ID> ai-home item <ALERT_ID> get
          torana app <APP_ID> ai-home item <ALERT_ID> get --section cites
          torana app <APP_ID> ai-home item <ALERT_ID> check
          torana app <APP_ID> ai-home item <ALERT_ID> brief get
        """
        ctx.ensure_object(dict)
        ctx.obj["_home_item_id"] = alert_id
        if ctx.invoked_subcommand is None:
            click.echo(ctx.get_help())

    @item.command(name="get")
    @click.option("--section", "section", type=click.Choice(ITEM_SECTIONS), default=None,
                  help="ledger: the live proof, claim by claim · graph: its exposure path · cites: the facts the "
                       "page cited for it, as stored · rows: the alerts in the same decision.")
    @click.pass_context
    def item_get(ctx, section):
        """Show one Home item: what the page says about it, or with --section its proof.

        With no --section it prints the item's card as the page shows it. `ledger` and `graph` are the proof as
        it is NOW; `cites` is what the page stored when it was prepared (compare the two with `item check`).

        \b
        Related: `ai-home item <ALERT_ID> check`, `ai-home item <ALERT_ID> brief get`, `alert <ALERT_ID> proof --claim`.

        \b
        Examples:
          torana app <APP_ID> ai-home item <ALERT_ID> get
          torana app <APP_ID> ai-home item <ALERT_ID> get --section ledger
          torana app <APP_ID> ai-home item <ALERT_ID> get --section cites --json
          torana app <APP_ID> ai-home item <ALERT_ID> get --section rows
        """
        from torana_cli import proof_view
        fmt, raw, fields = _ctx(ctx)
        wid, aid = _wid(ctx), _aid(ctx)
        client = client_factory(ctx)
        try:
            if section in ("ledger", "graph"):
                rec = client.get(f"datalake/proof/alerts/{aid}")
                if fmt in ("json", "yaml"):
                    output(rec if section == "ledger" else {"alert_id": aid, "graph": (rec.get("item") or {}).get("graph")},
                           fmt=fmt, raw=raw, fields=fields)
                elif section == "ledger":
                    proof_view.echo(proof_view.record_lines(rec))
                else:
                    proof_view.echo(proof_view.graph_lines(rec.get("item") or {}))
                return
            page = _page(ctx, client)
            block, lines = _group(ctx, page)
        except (APIError, AuthError) as e:
            return _fail(e)

        base = {"app_id": wid, "alert_id": aid, "run_id": page.get("run_id")}
        if section == "cites":
            cites = group_cites(lines)
            if fmt in ("json", "yaml"):
                output({**base, "cites": cites}, fmt=fmt, raw=raw, fields=fields)
                return
            click.echo(f"The page cited {len(cites)} proven fact{'' if len(cites) == 1 else 's'} for this item "
                       f"(as stored when it was prepared, run {page.get('run_id')}):")
            for c in cites:
                click.echo(f"  ◆ {c.get('id')} · {c.get('kind')} · {c.get('text') or hs.CITE_MISSING}")
            if not cites:
                click.echo("  None: this item's lines cite no proven fact.")
            return
        if section == "rows":
            members = [ln for ln in lines if ln.get("kind") == "member"]
            if fmt in ("json", "yaml"):
                output({**base, "rows": [ln.get("parts") for ln in members]}, fmt=fmt, raw=raw, fields=fields)
                return
            if not members:
                click.echo("This item is one alert; no other alert shares its decision.")
                click.echo(f"  A grouped check's own rows:  torana alert {aid} members")
                return
            click.echo(f"{len(members)} alert{'' if len(members) == 1 else 's'} in this decision:")
            for ln in members:
                click.echo("\n".join(hs.line_lines(ln, base=2)) + f"   ({(ln.get('parts') or {}).get('alert_id')})")
            return
        if fmt in ("json", "yaml"):
            output({**base, "section": block.get("key"), "lines": lines}, fmt=fmt, raw=raw, fields=fields)
            return
        for ln in lines:
            click.echo("\n".join(hs.line_lines(ln, cites=True, base=0)))

    @item.command(name="check")
    @click.pass_context
    def item_check(ctx):
        """Compare this item's live proof with what the Home page stored when it was prepared.

        Use it when the page is not fresh and you need to know whether a cited fact still holds. Each claim is
        `same`, `changed` (both texts are printed), `gone` or `new`. It writes nothing and exits 0 either way;
        a claim that only aged ("37 hours ago") reads `changed`.

        \b
        Related: `ai-home item <ALERT_ID> get --section ledger`, `ai-home refresh --wait`.

        \b
        Examples:
          torana app <APP_ID> ai-home item <ALERT_ID> check
          torana app <APP_ID> ai-home item <ALERT_ID> check --json
        """
        from torana_cli import proof_view
        fmt, raw, fields = _ctx(ctx)
        wid, aid = _wid(ctx), _aid(ctx)
        client = client_factory(ctx)
        try:
            page = _page(ctx, client)
            stored = stored_claims(page, aid)
            if stored is None:
                click.echo(NOT_ON_PAGE, err=True)
                ctx.exit(EXIT_NOT_FOUND)
            rec = client.get(f"datalake/proof/alerts/{aid}")
        except (APIError, AuthError) as e:
            return _fail(e)
        live = {c.get("id"): proof_view.plain(c.get("spans")) for c in (rec.get("item") or {}).get("claims") or []}
        claims = compare_claims(stored, live)
        moved = [c for c in claims if c["state"] != "same"]
        if fmt in ("json", "yaml"):
            output({"app_id": wid, "alert_id": aid, "run_id": page.get("run_id"), "changed": len(moved),
                    "claims": claims}, fmt=fmt, raw=raw, fields=fields)
            return
        click.echo(f"{len(claims) - len(moved)} of {len(claims)} claims are the same as on the page "
                   f"(run {page.get('run_id')}); {len(moved)} differ.")
        for c in moved:
            click.echo(f"  {c['state']:8s}{c['id']}")
            if c["stored"] is not None:
                click.echo(f"      page: {c['stored']}")
            if c["live"] is not None:
                click.echo(f"      now:  {c['live']}")
        if moved:
            click.echo(f"  Prepare a new page:  {home_cmd(wid)} refresh --wait")

    @item.group(name="brief", invoke_without_command=True)
    @click.pass_context
    def brief(ctx):
        """The item's AI brief: proven claims in prose, each sentence with the claims it cites.

        \b
        Examples:
          torana app <APP_ID> ai-home item <ALERT_ID> brief get
          torana app <APP_ID> ai-home item <ALERT_ID> brief write --wait
        """
        ctx.ensure_object(dict)
        if ctx.invoked_subcommand is None:
            click.echo(ctx.get_help())

    def _show(ctx, client, latest):
        from torana_cli import brief_view
        fmt, raw, fields = _ctx(ctx)
        wid, aid = _wid(ctx), _aid(ctx)
        staleness = brief_view.check(client, wid, aid, latest)
        if fmt in ("json", "yaml"):
            output({**latest, "staleness": staleness}, fmt=fmt, raw=raw, fields=fields)
        else:
            click.echo("\n".join(brief_view.lines(latest, staleness, aid)))

    @brief.command(name="get")
    @click.pass_context
    def brief_get(ctx):
        """Show the latest AI brief for this item, checked against its proof as it is now.

        A sentence whose claims changed since it was written is marked "◇ claims changed since written". Exit 3
        when the item has no brief yet.

        \b
        Examples:
          torana app <APP_ID> ai-home item <ALERT_ID> brief get
          torana app <APP_ID> ai-home item <ALERT_ID> brief get --json
        """
        from torana_cli import brief_view
        client = client_factory(ctx)
        try:
            latest = brief_view.latest(client, _wid(ctx), _aid(ctx))
            if latest is None:
                click.echo("No brief yet for this item.", err=True)
                click.echo(f"  Write one:  {home_cmd(_wid(ctx))} item {_aid(ctx)} brief write --wait", err=True)
                ctx.exit(EXIT_NOT_FOUND)
            _show(ctx, client, latest)
        except (APIError, AuthError) as e:
            return _fail(e)

    @brief.command(name="write")
    @click.option("--wait", is_flag=True, default=False,
                  help="Stay until the brief is ready or failed (checks every 5 seconds, up to 10 minutes), then print it.")
    @click.pass_context
    def brief_write(ctx, wait):
        """Write a new AI brief for this item: one AI call over its proven claims, about a minute.

        Every number, id and name in a sentence must appear in a claim it cites; code checks that. An item with no
        proof model, and a grouped check, have no brief: the platform says so.

        \b
        Examples:
          torana app <APP_ID> ai-home item <ALERT_ID> brief write --wait
          torana app <APP_ID> ai-home item <ALERT_ID> brief write
        """
        from torana_cli import brief_view
        wid, aid = _wid(ctx), _aid(ctx)
        client = client_factory(ctx)
        try:
            started = brief_view.write(client, wid, aid)
            if not wait:
                fmt, raw, fields = _ctx(ctx)
                if fmt in ("json", "yaml"):
                    output({"app_id": wid, "alert_id": aid, **started}, fmt=fmt, raw=raw, fields=fields)
                    return
                click.echo(f"Writing brief {started['brief_id']}.")
                click.echo(f"  Show it:  {home_cmd(wid)} item {aid} brief get")
                return
            row = brief_view.wait(client, wid, aid, started["brief_id"])
            _show(ctx, client, {"latest_ready": row if row.get("status") == "ready" else None, "in_flight": None,
                                "latest": row})
        except (APIError, AuthError) as e:
            return _fail(e)
