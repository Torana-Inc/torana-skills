"""OAuth 2.0 browser-based login flow for the Torana CLI.

Implements Authorization Code + PKCE (RFC 7636) with a local callback server.
Supports both interactive browser flow and headless (manual URL) flow.
"""

import base64
import hashlib
import http.server
import json
import pathlib
import secrets
import threading
import webbrowser
from typing import Optional
from urllib.parse import urlencode, urlparse, parse_qs

import click
import httpx

from torana_cli.client.auth import (
    AuthError,
    _save_cached_token,
    get_token_info,
)

# ---------------------------------------------------------------------------
# OAuth client — pre-registered on Torana Auth server
# ---------------------------------------------------------------------------

OAUTH_CLIENT_ID = "torana-cli"

# Default scopes requested by the CLI.
# Using granular scopes (instead of "*") so the consent screen shows
# the grouped permission view with individual checkboxes — matching
# the Claude Desktop consent experience.
OAUTH_DEFAULT_SCOPES = [
    # Detection
    "detection:rules:read",
    "detection:rules:write",
    "detection:rules:execute",
    "detection:rules:*",
    "detection:dashboards:read",
    "detection:dashboards:write",
    "detection:dashboards:*",
    "detection:*",
    # Agents
    "agents:read",
    "agents:write",
    "agents:execute",
    "agents:*",
    # Prompts
    "prompts:read",
    "prompts:write",
    "prompts:*",
    # Workflows
    "workflows:read",
    "workflows:write",
    "workflows:execute",
    "workflows:*",
    # Visualizations
    "visualizations:read",
    "visualizations:write",
    "visualizations:*",
    # Widgets
    "widgets:read",
    "widgets:write",
    "widgets:*",
    # Integrations
    "integrations:read",
    "integrations:write",
    "integrations:*",
    # Transformers
    "transformers:read",
    "transformers:write",
    "transformers:execute",
    "transformers:*",
    # Datalake
    "datalake:read",
    "datalake:write",
    "datalake:*",
    # Documents
    "documents:read",
    "documents:write",
    "documents:*",
    # Policy (vm policy: read/bind/ratify/adjudicate/extract)
    "policy:read",
    "policy:write",
    "policy:*",
    # Audit (context-lake summary, audit logs)
    "audit:read",
    "audit:write",
    "audit:*",
    # Entity graph (entity-graph reconcile needs graph:write)
    "graph:read",
    "graph:write",
    "graph:*",
    # Admin
    "tenant:manage",
    "users:manage",
]


# ---------------------------------------------------------------------------
# PKCE (RFC 7636)
# ---------------------------------------------------------------------------

def generate_pkce() -> tuple:
    """Generate PKCE code_verifier and code_challenge (S256).

    Returns:
        (code_verifier, code_challenge) — both URL-safe strings.

    The verifier is 86 characters (from 64 random bytes base64url-encoded),
    well within the RFC 7636 requirement of 43–128 characters.
    """
    code_verifier = secrets.token_urlsafe(64)

    # S256: BASE64URL(SHA256(code_verifier))
    digest = hashlib.sha256(code_verifier.encode("ascii")).digest()
    code_challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")

    return code_verifier, code_challenge


# ---------------------------------------------------------------------------
# Local HTTP callback server
# ---------------------------------------------------------------------------

class OAuthCallbackHandler(http.server.BaseHTTPRequestHandler):
    """Handles a single OAuth redirect callback from the browser.

    After receiving the GET /callback request, extracts the authorization code
    and state, returns a success page to the browser, and shuts the server down.
    """

    # Class-level storage for the single callback result
    auth_code: Optional[str] = None
    state: Optional[str] = None
    error: Optional[str] = None
    error_description: Optional[str] = None

    @classmethod
    def reset(cls):
        """Reset class-level state between login attempts."""
        cls.auth_code = None
        cls.state = None
        cls.error = None
        cls.error_description = None

    def do_GET(self):
        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)

        if parsed.path != "/callback":
            self.send_error(404)
            return

        # Extract results from query parameters
        OAuthCallbackHandler.auth_code = params.get("code", [None])[0]
        OAuthCallbackHandler.state = params.get("state", [None])[0]
        OAuthCallbackHandler.error = params.get("error", [None])[0]
        OAuthCallbackHandler.error_description = params.get(
            "error_description", [None]
        )[0]

        # Send a friendly success page to the browser
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()

        if OAuthCallbackHandler.error:
            body = (
                "<html><body style='font-family:sans-serif;text-align:center;padding:60px'>"
                "<h1>Authentication Failed</h1>"
                f"<p>{OAuthCallbackHandler.error}: "
                f"{OAuthCallbackHandler.error_description or 'Unknown error'}</p>"
                "<p>Return to the terminal to try again.</p>"
                "</body></html>"
            )
        else:
            body = (
                "<html><body style='font-family:sans-serif;text-align:center;padding:60px'>"
                "<h1>Authentication Successful</h1>"
                "<p>You can close this tab and return to the terminal.</p>"
                "</body></html>"
            )

        self.wfile.write(body.encode("utf-8"))

        # Signal server to shut down (in a thread to avoid deadlock)
        threading.Thread(target=self.server.shutdown, daemon=True).start()

    def log_message(self, format, *args):
        """Suppress default stderr logging from BaseHTTPRequestHandler."""
        pass


def start_callback_server() -> tuple:
    """Start the callback server on a random available port.

    Binds to 127.0.0.1 (loopback only) so only local connections are accepted.

    Returns:
        (server, port) — the HTTPServer instance and the port it bound to.
    """
    OAuthCallbackHandler.reset()
    server = http.server.HTTPServer(("127.0.0.1", 0), OAuthCallbackHandler)
    port = server.server_address[1]
    return server, port


# ---------------------------------------------------------------------------
# Token exchange
# ---------------------------------------------------------------------------

def exchange_code_for_tokens(
    base_url: str,
    code: str,
    redirect_uri: str,
    code_verifier: str,
    debug: bool = False,
) -> dict:
    """Exchange an authorization code for access + refresh tokens.

    Calls POST /oauth/token with grant_type=authorization_code.
    Uses application/x-www-form-urlencoded as per the OAuth 2.0 spec.

    Returns:
        Token data dict with keys: access_token, refresh_token, token_type,
        base_url, email, auth_method.

    Raises:
        AuthError on failure.
    """
    url = f"{base_url.rstrip('/')}/oauth/token"
    if debug:
        click.echo(f"[DEBUG] POST {url}", err=True)
        click.echo(f"[DEBUG] code:         {code[:12]}...", err=True)
        click.echo(f"[DEBUG] redirect_uri: {redirect_uri}", err=True)
        click.echo(f"[DEBUG] verifier:     {code_verifier[:12]}...", err=True)
    try:
        resp = httpx.post(
            url,
            data={
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": redirect_uri,
                "client_id": OAUTH_CLIENT_ID,
                "code_verifier": code_verifier,
            },
            headers={"ngrok-skip-browser-warning": "1"},
            timeout=15,
        )
        resp.raise_for_status()
    except httpx.HTTPStatusError as e:
        if debug:
            click.echo(f"[DEBUG] response status:  {e.response.status_code}", err=True)
            click.echo("[DEBUG] response headers:", err=True)
            for k, v in e.response.headers.items():
                click.echo(f"[DEBUG]   {k}: {v}", err=True)
            click.echo(f"[DEBUG] response body:    {e.response.text[:500]}", err=True)
        detail = ""
        try:
            body = e.response.json()
            detail = body.get("detail") or body.get("error_description") or body.get("error") or str(body)
        except Exception:
            detail = e.response.text[:200]
        raise AuthError(
            f"Token exchange failed: HTTP {e.response.status_code} — {detail}"
        ) from e
    except httpx.RequestError as e:
        raise AuthError(f"Cannot reach {url}: {e}") from e

    data = resp.json()
    access_token = data.get("access_token")
    if not access_token:
        raise AuthError("No access_token in token exchange response")

    claims = get_token_info(access_token)
    email = claims.get("email", "")

    from torana_cli.config.settings import resolve_profile_name
    token_data = {
        "access_token": access_token,
        "refresh_token": data.get("refresh_token"),
        "token_type": data.get("token_type", "bearer"),
        "base_url": base_url,
        "email": email,
        "auth_method": "oauth",
        "profile": resolve_profile_name(),
    }
    # No explicit profile arg: resolves to the active/overridden profile
    # (TORANA_PROFILE is set from --profile in main.py).
    _save_cached_token(token_data)
    return token_data


# ---------------------------------------------------------------------------
# Browser login flow (interactive)
# ---------------------------------------------------------------------------

def browser_login(base_url: str, no_browser: bool = False) -> dict:
    """Execute the full OAuth browser login flow.

    1. Generate PKCE verifier/challenge
    2. Start local callback server on a random port
    3. Build authorize URL and open it in the browser
    4. Wait for the browser redirect to localhost
    5. Validate state, extract authorization code
    6. Exchange code for tokens

    Args:
        base_url: Torana server URL (e.g. https://app.toranasecurity.ai)
        no_browser: If True, print URL instead of opening browser (but still
                    use the local callback server).

    Returns:
        Token data dict (same shape as password login).

    Raises:
        AuthError on failure or cancellation.
    """
    # 1. Generate PKCE
    code_verifier, code_challenge = generate_pkce()

    # 2. Generate state for CSRF protection
    state = secrets.token_urlsafe(32)

    # 3. Start local callback server
    server, port = start_callback_server()
    redirect_uri = f"http://localhost:{port}/callback"

    # 4. Build authorize URL
    params = {
        "response_type": "code",
        "client_id": OAUTH_CLIENT_ID,
        "redirect_uri": redirect_uri,
        "scope": " ".join(OAUTH_DEFAULT_SCOPES),
        "state": state,
        "code_challenge": code_challenge,
        "code_challenge_method": "S256",
    }
    authorize_url = f"{base_url.rstrip('/')}/oauth/authorize?{urlencode(params)}"

    # 5. Open browser or print URL
    if no_browser:
        click.echo("\nOpen this URL in a browser:\n")
        click.echo(f"  {authorize_url}\n")
    else:
        click.echo("Opening browser for authentication...")
        if not webbrowser.open(authorize_url):
            click.echo("Could not open browser. Open this URL manually:\n")
            click.echo(f"  {authorize_url}\n")

    # 6. Wait for callback (blocks until the handler calls server.shutdown())
    click.echo("Waiting for authentication... (press Ctrl+C to cancel)")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.server_close()
        raise AuthError("Authentication cancelled by user")
    finally:
        server.server_close()

    # 7. Validate callback response
    if OAuthCallbackHandler.error:
        desc = OAuthCallbackHandler.error_description or OAuthCallbackHandler.error
        raise AuthError(f"OAuth error: {desc}")

    auth_code = OAuthCallbackHandler.auth_code
    returned_state = OAuthCallbackHandler.state

    if not auth_code:
        raise AuthError("No authorization code received")

    if returned_state != state:
        raise AuthError("State mismatch \u2014 possible CSRF attack. Aborting.")

    # 8. Exchange code for tokens
    token_data = exchange_code_for_tokens(
        base_url=base_url,
        code=auth_code,
        redirect_uri=redirect_uri,
        code_verifier=code_verifier,
    )

    return token_data


# ---------------------------------------------------------------------------
# Headless login flow (no local browser available)
# ---------------------------------------------------------------------------

_HEADLESS_STATE_FILE = pathlib.Path.home() / ".torana" / "cache" / ".oauth_pending.json"


_HEADLESS_STATE_FILE = pathlib.Path.home() / ".torana" / "cache" / ".oauth_pending.json"


def headless_login(
    base_url: str,
    auth_code: Optional[str] = None,
    interactive: bool = False,
    debug: bool = False,
) -> Optional[dict]:
    """OAuth login for headless environments (no local browser).

    Three modes controlled by the caller:

    interactive=True (--no-browser, original behavior):
        Prints the URL, then blocks on stdin prompting the user to paste
        the authorization code. Single command, works in any real terminal.

    interactive=False, auth_code=None (--no-browser --print-url, Step 1):
        Prints the URL and saves PKCE state to disk. Exits immediately
        without blocking stdin. Safe for bash_tool / CI / non-interactive shells.

    interactive=False, auth_code=<code> (--no-browser --print-url --code, Step 2):
        Loads saved PKCE state, exchanges the code for tokens, deletes state file.
        Exits immediately without blocking stdin.

    Args:
        base_url: Torana server URL.
        auth_code: Authorization code for non-interactive Step 2. None otherwise.
        interactive: If True, prompt for code on stdin after printing URL.

    Returns:
        Token data dict, or None if Step 1 of non-interactive flow.

    Raises:
        AuthError on failure.
    """
    if interactive:
        # --- Original blocking flow ---
        code_verifier, code_challenge = generate_pkce()
        state = secrets.token_urlsafe(32)
        redirect_uri = f"{base_url.rstrip('/')}/oauth/callback/display"

        params = {
            "response_type": "code",
            "client_id": OAUTH_CLIENT_ID,
            "redirect_uri": redirect_uri,
            "scope": " ".join(OAUTH_DEFAULT_SCOPES),
            "state": state,
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
        }
        authorize_url = f"{base_url.rstrip('/')}/oauth/authorize?{urlencode(params)}"

        click.echo("\nOpen this URL in a browser on any machine:\n")
        click.echo(f"  {authorize_url}\n")

        auth_code = click.prompt("Enter the authorization code").strip()
        if not auth_code:
            raise AuthError("No authorization code provided")

        return exchange_code_for_tokens(
            base_url=base_url,
            code=auth_code,
            redirect_uri=redirect_uri,
            code_verifier=code_verifier,
            debug=debug,
        )

    elif auth_code is None:
        # --- Non-interactive Step 1: print URL and save state ---
        code_verifier, code_challenge = generate_pkce()
        state = secrets.token_urlsafe(32)
        # Embed code_verifier as `cv` query param in redirect_uri so the display
        # page can do the token exchange server-side (sandbox egress is blocked).
        redirect_uri = f"{base_url.rstrip('/')}/oauth/callback/display?cv={code_verifier}"

        params = {
            "response_type": "code",
            "client_id": OAUTH_CLIENT_ID,
            "redirect_uri": redirect_uri,
            "scope": " ".join(OAUTH_DEFAULT_SCOPES),
            "state": state,
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
        }
        authorize_url = f"{base_url.rstrip('/')}/oauth/authorize?{urlencode(params)}"

        _HEADLESS_STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
        _HEADLESS_STATE_FILE.write_text(json.dumps({
            "code_verifier": code_verifier,
            "redirect_uri": redirect_uri,
            "base_url": base_url,
        }))

        if debug:
            click.echo(f"[DEBUG] state file written: {_HEADLESS_STATE_FILE}", err=True)
            click.echo(f"[DEBUG] base_url:     {base_url}", err=True)
            click.echo(f"[DEBUG] redirect_uri: {redirect_uri}", err=True)
            click.echo(f"[DEBUG] verifier:     {code_verifier[:12]}...", err=True)

        click.echo("\nOpen this URL in a browser on any machine:\n")
        click.echo(f"  {authorize_url}\n")
        click.echo("After authorizing, the page will show your authorization code.")
        click.echo("Copy it and run:")
        click.echo("  torana auth login --web --no-browser --code <paste-code-here>\n")
        return None

    else:
        # --- Non-interactive Step 2: exchange code using saved state ---
        if not _HEADLESS_STATE_FILE.exists():
            raise AuthError(
                "No pending OAuth session found. "
                "Run 'torana auth login --web --no-browser --print-url' first to get the URL."
            )
        try:
            saved = json.loads(_HEADLESS_STATE_FILE.read_text())
        except Exception as e:
            raise AuthError(f"Could not read pending OAuth state: {e}") from e

        code_verifier = saved.get("code_verifier")
        redirect_uri = saved.get("redirect_uri")
        saved_base_url = saved.get("base_url", base_url)

        if not code_verifier or not redirect_uri:
            raise AuthError("Pending OAuth state is corrupt. Re-run the login command.")

        if debug:
            click.echo(f"[DEBUG] state file:   {_HEADLESS_STATE_FILE}", err=True)
            click.echo(f"[DEBUG] base_url:     {saved_base_url}", err=True)
            click.echo(f"[DEBUG] redirect_uri: {redirect_uri}", err=True)
            click.echo(f"[DEBUG] code:         {auth_code.strip()[:12]}...", err=True)
            click.echo(f"[DEBUG] verifier:     {code_verifier[:12]}...", err=True)

        token_data = exchange_code_for_tokens(
            base_url=saved_base_url,
            code=auth_code.strip(),
            redirect_uri=redirect_uri,
            code_verifier=code_verifier,
            debug=debug,
        )
        # Only delete state file on success — preserve it so a retry with a new
        # code doesn't require re-running --print-url
        _HEADLESS_STATE_FILE.unlink(missing_ok=True)
        return token_data
