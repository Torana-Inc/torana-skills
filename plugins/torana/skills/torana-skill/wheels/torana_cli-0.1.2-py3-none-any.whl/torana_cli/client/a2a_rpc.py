"""A2A JSON-RPC wire helpers — shared by the protocol verbs in agent.py and any
A2A-driving commands in admin.py.

Single source of truth for the a2a-sdk 1.1.0 wire requirements so the CLI never
drifts between callers:

  - a2a-sdk 1.1.0 dispatches on gRPC-style method names (SendMessage / GetTask /
    CancelTask / ListTasks / SubscribeToTask), NOT message/send.
  - Every JSON-RPC call MUST carry the `A2A-Version: 1.0` request header.
  - The Agent Card is served at the ROOT well-known path (no /api/v1 prefix) —
    callers pass a leading-slash absolute path so ToranaClient does not prepend it.

See pantheon-agent-builder docs/TORANA_A2A_SPIKE_NOTE.md for the wire spike.
"""
import uuid

# a2a-sdk 1.1.0 wire requirements.
A2A_VERSION_HEADER = {"A2A-Version": "1.0"}

# gRPC-style method names dispatched by the A2A adapter.
M_SEND = "SendMessage"
M_GET = "GetTask"
M_CANCEL = "CancelTask"
M_LIST = "ListTasks"


def jsonrpc(method: str, params: dict, rpc_id: int = 1) -> dict:
    """Build a JSON-RPC 2.0 envelope for an A2A method call."""
    return {"jsonrpc": "2.0", "id": rpc_id, "method": method, "params": params}


def user_message(text: str, context_id: str = None, task_id: str = None) -> dict:
    """Build an A2A user Message part list (ROLE_USER + a single text part)."""
    msg = {
        "messageId": str(uuid.uuid4()),
        "role": "ROLE_USER",
        "parts": [{"text": text}],
    }
    if context_id:
        msg["contextId"] = context_id
    if task_id:
        msg["taskId"] = task_id
    return msg


def rpc_call(client, agent_id: str, method: str, params: dict) -> dict:
    """POST a JSON-RPC call to /api/v1/a2a/{agent_id} with the A2A-Version header.

    `client` is a ToranaClient instance; its post() supports extra_headers.
    """
    return client.post(
        f"a2a/{agent_id}",
        json=jsonrpc(method, params),
        extra_headers=A2A_VERSION_HEADER,
    )
