"""C-04: what an API error means to the person reading it, by status group. No model call.

The reference is nginx's request id, returned on every response as `X-Torana-Reference`; quoting it lets Torana
support find the request's trace. Spec: pantheon-deploy docs/em/C04_ERROR_REFERENCE_ID.md § 3.4.2.
"""
import re
from typing import Optional

REFERENCE_HEADER = "X-Torana-Reference"
REFERENCE_RE = re.compile(r"^[0-9a-f]{32}$")

#: The status groups. pantheon-fe `shared/error-words.ts` has the same keys and mapping; a test in each repo pins
#: this literal, so a change to one shows up in the other's review.
GROUPS = ("network", "invalid", "signin", "access", "missing", "conflict", "too_large", "slow_down",
          "ours", "unavailable", "other")

#: 5xx error codes whose `message` a service writes FOR USERS: shown. Any other 5xx text is never shown (D3): 112
#: sites put raw exception text in a 5xx detail. Empty in S1, because no 5xx site sends a structured,
#: internals-free message yet. EM row C-04b converts those sites and adds their codes here.
USER_FACING_5XX: frozenset = frozenset()


def group_of(status: int) -> str:
    if status == 0:
        return "network"
    if status in (400, 422):
        return "invalid"
    if status == 401:
        return "signin"
    if status == 403:
        return "access"
    if status in (404, 410):
        return "missing"
    if status == 409:
        return "conflict"
    if status in (413, 414, 431):
        return "too_large"
    if status == 429:
        return "slow_down"
    if status in (502, 503, 504):
        return "unavailable"
    if status >= 500:
        return "ours"
    return "other"


#: What to do, in CLI terms. No "signin" row: the 401 message already says `torana auth login`.
TODO = {
    "network": "Check the network and the address in `torana config list`, then try again.",
    "invalid": "Fix the value named above and run the command again.",
    "access": "Ask an admin of your tenant for the permission.",
    "missing": "Check the id; it may have been deleted, or you may not be able to see it.",
    "conflict": "Read its current state, then try again.",
    "too_large": "Send less (a shorter value or fewer items).",
    "slow_down": "Wait a minute, then try again.",
    "ours": "Try again. If it keeps failing, send Torana support the reference.",
    "unavailable": "Try again in a few minutes. If it continues, send Torana support the reference.",
    "other": "If this is unexpected, send Torana support the reference.",
}

#: What happened, for a 5xx (whose own text is never shown). A 4xx says what happened in the server's sentence.
HAPPENED_5XX = {
    "ours": "Something failed on Torana's side.",
    "unavailable": "A Torana service did not answer.",
}


def reference_from(headers) -> Optional[str]:
    """The nginx reference on a response, or None (absent, all zero, or not one 32-hex value)."""
    try:
        value = (headers.get(REFERENCE_HEADER) or "").strip().lower()
    except Exception:
        return None
    return value if REFERENCE_RE.match(value) and int(value, 16) else None


def user_facing_5xx(detail) -> Optional[str]:
    """A 5xx message a service wrote for users (its code is in USER_FACING_5XX), else None."""
    if (isinstance(detail, dict) and detail.get("error") in USER_FACING_5XX
            and isinstance(detail.get("message"), str)):
        return detail["message"]
    return None
