"""HTTP client layer for Torana CLI."""
