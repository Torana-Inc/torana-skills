"""Base HTTP client — all requests route through {base_url}/api/v1/{path} via nginx."""

import os
import sys
from typing import Any, Optional

import httpx

from torana_cli.client.auth import AuthError, get_access_token
from torana_cli.config.settings import get_settings
from torana_cli.log.logger import get_logger

logger = get_logger(__name__)

#: ⚠️ THESE ARE CLIENT DEADLINES, NOT SERVER LIMITS. A GET that exceeds `_READ_TIMEOUT`
#: is abandoned by the CLI while the server keeps working — the caller sees "read
#: operation timed out" and concludes the endpoint failed, when it may well be about to
#: succeed. Measured 2026-09-07: `ai-home facts` on a 50-widget Classie workspace takes
#: 24-27s (50 widgets / 4 concurrent x ~1.4s render, plus the supply graph), so it sits
#: just under a 30s deadline and tips over it as soon as a widget or two is added.
#:
#: ⛔ RAISING THIS IS NOT A FIX FOR A SLOW ENDPOINT — it only stops the CLI lying about
#: what happened. The render fan-out is the real cost and is tracked separately.
#:
#: Override per invocation when a deployment is genuinely slower:
#:     TORANA_READ_TIMEOUT=120 torana workspace <id> ai-home facts
_READ_TIMEOUT = float(os.getenv("TORANA_READ_TIMEOUT", "90"))
_WRITE_TIMEOUT = float(os.getenv("TORANA_WRITE_TIMEOUT", "120"))

# Exit codes matching the CLI spec
EXIT_GENERAL = 1
EXIT_USAGE = 2
EXIT_NOT_FOUND = 3
EXIT_PERMISSION = 4
EXIT_AUTH = 5
EXIT_VALIDATION = 6


class APIError(Exception):
    """Raised on non-2xx API responses."""

    def __init__(self, message: str, status_code: int, detail: Any = None):
        super().__init__(message)
        self.status_code = status_code
        self.detail = detail

    @property
    def exit_code(self) -> int:
        if self.status_code == 401:
            return EXIT_AUTH
        if self.status_code == 403:
            return EXIT_PERMISSION
        if self.status_code == 404:
            return EXIT_NOT_FOUND
        if self.status_code == 422:
            return EXIT_VALIDATION
        return EXIT_GENERAL


def _current_command_path() -> str:
    """The CLI leaf currently executing, e.g. "datalake query". Empty when unknown.

    ⭐ WHY THIS EXISTS. A host that brokers this CLI's egress (pantheon-agent-builder's
    sandbox broker) has to authorize each call. Reconstructing the command from the URL is a
    heuristic and it is wrong in BOTH directions — measured 2026-08-29 on real traffic, it
    refused 5 of 7 legitimate reads and, worse, ADMITTED `GET /api/v1/query` by matching an
    unrelated leaf. The CLI already knows the answer exactly at this moment, so it states it
    rather than letting the broker guess: `datalake query` calls `/query`, which no path
    parser recovers.

    ⛔ THIS IS A CLAIM, NOT A CREDENTIAL. Anything can send this header. The broker treats it
    as one of two independent facts and corroborates it against the request itself; see
    pantheon-agent-builder/docs/streams/STREAM_F_broker_authz.md § 3.2.

    ⚠️ Never raises and never blocks a call: a laptop user is unaffected, and a missing
    header simply means the broker has nothing to corroborate (it then refuses, which is the
    correct direction).
    """
    try:
        import click
        ctx = click.get_current_context(silent=True)
        if ctx is None:
            return ""
        parts = []
        while ctx is not None:
            if ctx.info_name:
                parts.append(ctx.info_name)
            ctx = ctx.parent
        parts.reverse()
        # Drop the root program name ("torana" / "cli"), keeping the leaf path.
        return " ".join(parts[1:]) if len(parts) > 1 else ""
    except Exception:
        return ""


class ToranaClient:
    """
    HTTP client for Torana REST APIs.

    All requests go to {base_url}/api/v1/{path} via nginx gateway.
    Auth is handled automatically via get_access_token().
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        access_token: Optional[str] = None,
        profile: Optional[str] = None,
    ):
        settings = get_settings(profile)
        self._base_url = (base_url or settings.base_url).rstrip("/")
        self._access_token = access_token
        self._profile = profile

    def _get_token(self) -> str:
        if self._access_token:
            return self._access_token
        return get_access_token(self._base_url, self._profile)

    def _build_url(self, path: str) -> str:
        """Prepend /api/v1/ if the path doesn't already have a full prefix.

        Paths starting with '/' are treated as absolute and used as-is
        (no /api/v1/ prepend). This is needed for services whose nginx
        location blocks don't include the /api/v1/ prefix.

        Trailing slashes are stripped to avoid 307 redirects from nginx
        that would drop the Authorization header on the redirect.
        """
        if path.startswith("/"):
            return f"{self._base_url}{path.rstrip('/')}"
        path = path.strip("/")
        if not path.startswith("api/"):
            path = f"api/v1/{path}"
        return f"{self._base_url}/{path}"

    def _headers(self) -> dict:
        token = self._get_token()
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        cmd = _current_command_path()
        if cmd:
            headers["X-Torana-Command"] = cmd
        return headers

    def get(self, path: str, params: Optional[dict] = None,
            timeout: Optional[float] = None) -> Any:
        """GET `path`.

        `timeout` overrides the default read deadline for the few endpoints that are
        legitimately slow — `post()` already had this; GET did not, so a slow read had
        no escape hatch short of an env var.
        """
        url = self._build_url(path)
        logger.debug(f"GET {url} params={params}")
        try:
            with httpx.Client(timeout=timeout or _READ_TIMEOUT,
                              follow_redirects=True) as client:
                resp = client.get(url, headers=self._headers(), params=params)
        except httpx.RequestError as e:
            raise APIError(f"Cannot reach {url}: {e}", status_code=0) from e
        self._handle_response(resp)
        return resp.json()

    def get_bytes(self, path: str, params: Optional[dict] = None,
                  timeout: Optional[float] = None) -> tuple:
        """GET `path` and return `(content, filename)` for a FILE download.

        ⛔ A separate method, not a flag on `get()`. `get()` ends in
        `resp.json()`, so pointing it at an .xlsx raises a JSON decode error on
        a perfectly good response — the failure reads as a broken endpoint
        rather than the wrong reader.

        `filename` comes from Content-Disposition when the server sets one, so
        the server names the file (it knows the scope and timestamp); None when
        it does not, and the caller falls back to its own name.
        """
        url = self._build_url(path)
        logger.debug(f"GET(bytes) {url} params={params}")
        try:
            with httpx.Client(timeout=timeout or _READ_TIMEOUT,
                              follow_redirects=True) as client:
                resp = client.get(url, headers=self._headers(), params=params)
        except httpx.RequestError as e:
            raise APIError(f"Cannot reach {url}: {e}", status_code=0) from e
        self._handle_response(resp)

        filename = None
        disposition = resp.headers.get("content-disposition", "")
        if "filename=" in disposition:
            filename = disposition.split("filename=", 1)[1].strip().strip('"')
        return resp.content, filename

    def post(
        self,
        path: str,
        json: Optional[dict] = None,
        params: Optional[dict] = None,
        extra_headers: Optional[dict] = None,
        timeout: Optional[float] = None,
    ) -> Any:
        """POST to `path`.

        `timeout` overrides the default write deadline for the few endpoints that
        are legitimately long-running (e.g. build-v2 deploy, which materializes
        every transformer inline). Pass a larger value rather than raising
        `_WRITE_TIMEOUT` globally — a long default would mask genuinely hung
        requests on every other endpoint.
        """
        url = self._build_url(path)
        logger.debug(f"POST {url}")
        headers = self._headers()
        if extra_headers:
            headers = {**headers, **extra_headers}
        try:
            with httpx.Client(timeout=timeout or _WRITE_TIMEOUT, follow_redirects=True) as client:
                resp = client.post(url, headers=headers, json=json, params=params)
        except httpx.RequestError as e:
            raise APIError(f"Cannot reach {url}: {e}", status_code=0) from e
        self._handle_response(resp)
        try:
            return resp.json()
        except Exception:
            return {}

    def post_stream(
        self,
        path: str,
        json: Optional[dict] = None,
        params: Optional[dict] = None,
    ):
        """POST to a text/event-stream endpoint, yielding parsed SSE events.

        Yields each `data:` payload as a parsed object (dict/list) when it is JSON, else the raw
        string. Use for endpoints that stream Server-Sent Events (e.g. agent invoke/stream, chat).
        Raises APIError on a non-2xx status before the stream begins.
        """
        import json as _json
        url = self._build_url(path)
        logger.debug(f"POST(stream) {url}")
        headers = {**self._headers(), "Accept": "text/event-stream"}
        try:
            with httpx.Client(timeout=None, follow_redirects=True) as client:
                with client.stream("POST", url, headers=headers, json=json, params=params) as resp:
                    if resp.status_code >= 400:
                        # Read the (buffered) error body so _handle_response can classify it.
                        resp.read()
                        self._handle_response(resp)
                        return
                    for line in resp.iter_lines():
                        if not line or not line.startswith("data:"):
                            continue
                        payload = line[len("data:"):].strip()
                        if not payload or payload == "[DONE]":
                            continue
                        try:
                            yield _json.loads(payload)
                        except Exception:
                            yield payload
        except httpx.RequestError as e:
            raise APIError(f"Cannot reach {url}: {e}", status_code=0) from e

    def put(self, path: str, json: Optional[dict] = None, params: Optional[dict] = None) -> Any:
        url = self._build_url(path)
        logger.debug(f"PUT {url}")
        try:
            with httpx.Client(timeout=_WRITE_TIMEOUT, follow_redirects=True) as client:
                resp = client.put(url, headers=self._headers(), json=json, params=params)
        except httpx.RequestError as e:
            raise APIError(f"Cannot reach {url}: {e}", status_code=0) from e
        self._handle_response(resp)
        try:
            return resp.json()
        except Exception:
            return {}

    def patch(self, path: str, json: Optional[dict] = None, params: Optional[dict] = None) -> Any:
        url = self._build_url(path)
        logger.debug(f"PATCH {url}")
        try:
            with httpx.Client(timeout=_WRITE_TIMEOUT, follow_redirects=True) as client:
                resp = client.patch(url, headers=self._headers(), json=json, params=params)
        except httpx.RequestError as e:
            raise APIError(f"Cannot reach {url}: {e}", status_code=0) from e
        self._handle_response(resp)
        try:
            return resp.json()
        except Exception:
            return {}

    def delete(self, path: str, params: Optional[dict] = None) -> Optional[Any]:
        url = self._build_url(path)
        logger.debug(f"DELETE {url}")
        try:
            with httpx.Client(timeout=_READ_TIMEOUT, follow_redirects=True) as client:
                resp = client.delete(url, headers=self._headers(), params=params)
        except httpx.RequestError as e:
            raise APIError(f"Cannot reach {url}: {e}", status_code=0) from e
        self._handle_response(resp)
        if resp.status_code == 204 or not resp.content:
            return None
        try:
            return resp.json()
        except Exception:
            return None

    def _handle_response(self, resp: httpx.Response) -> None:
        """Raise APIError for non-2xx responses with structured detail."""
        logger.info(
            f"{resp.request.method} {resp.request.url} → {resp.status_code} "
            f"({resp.elapsed.total_seconds() * 1000:.0f}ms)"
        )
        if resp.is_success:
            return

        detail = None
        try:
            body = resp.json()
            detail = body.get("detail") or body
        except Exception:
            pass

        status = resp.status_code
        if status == 401:
            msg = "Authentication required — run 'torana auth login'"
        elif status == 403:
            msg = "Permission denied (HTTP 403)"
        elif status == 404:
            msg = "Resource not found (HTTP 404)"
        elif status == 422:
            msg = "Validation error (HTTP 422)"
        else:
            msg = f"API error (HTTP {status})"

        err = APIError(msg, status_code=status, detail=detail)
        # CLI-51 — a 404 has TWO indistinguishable causes: the capability was never
        # built, or the DEPLOYMENT serving this path is behind the source that has it.
        # Nothing reported which, so a checkout 31 commits behind produced three wrong
        # findings (CLI-42, CLI-43, one test-plan blocker) filed against routes that
        # worked upstream. Carry the path so the error handler can say "attribute this
        # before filing it" and name the command that settles the question.
        if status == 404:
            try:
                err.request_path = resp.request.url.path
            except Exception:
                err.request_path = None
        raise err


def handle_api_error(e: APIError) -> None:
    """Print a formatted error message to stderr and exit with the appropriate code."""
    import click

    click.echo(f"\nERROR: {e}", err=True)

    if e.detail:
        if isinstance(e.detail, list):
            for item in e.detail:
                if isinstance(item, dict):
                    loc = " → ".join(str(x) for x in item.get("loc", []))
                    msg = item.get("msg", "")
                    click.echo(f"  {loc}: {msg}", err=True)
                else:
                    click.echo(f"  {item}", err=True)
        elif isinstance(e.detail, dict):
            for k, v in e.detail.items():
                click.echo(f"  {k}: {v}", err=True)
        else:
            click.echo(f"  {e.detail}", err=True)

    # CLI-51 — make a 404 ATTRIBUTABLE instead of merely reported.
    #
    # ⛔ The failure this prevents is not a crash, it is a WRONG FILING. A 404 from a
    # stale deployment and a 404 from a capability that was never built are
    # byte-identical, and three issues were filed against the first believing it was the
    # second. So the hint does not guess — it names the ONE command that distinguishes
    # them, because the deployment's own build is the missing evidence.
    if e.status_code == 404:
        path = getattr(e, "request_path", None)
        click.echo("", err=True)
        if path:
            click.echo(f"  path: {path}", err=True)
        click.echo("  A 404 means EITHER this capability does not exist, OR the deployed",
                   err=True)
        click.echo("  service is behind the source that has it. These are indistinguishable",
                   err=True)
        click.echo("  from here — confirm which before filing a gap:", err=True)
        click.echo("      torana admin services list   # per-service build commit", err=True)

    sys.exit(e.exit_code)


def handle_auth_error(e: AuthError) -> None:
    """Print auth error and exit with code 5."""
    import click

    click.echo(f"\nERROR: {e}", err=True)
    sys.exit(EXIT_AUTH)
