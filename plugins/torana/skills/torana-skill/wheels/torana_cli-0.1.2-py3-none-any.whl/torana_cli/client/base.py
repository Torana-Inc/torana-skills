"""Base HTTP client — all requests route through {base_url}/api/v1/{path} via nginx."""

import hashlib
import os
import secrets
import sys
from typing import Any, Optional

import httpx

from torana_cli import __version__
from torana_cli.client.auth import AuthError, get_access_token
from torana_cli.config.settings import get_settings
from torana_cli.log.logger import get_logger

logger = get_logger(__name__)

#: ⚠️ THESE ARE CLIENT DEADLINES, NOT SERVER LIMITS. A GET that exceeds `_READ_TIMEOUT`
#: is abandoned by the CLI while the server keeps working — the caller sees "read
#: operation timed out" and concludes the endpoint failed, when it may well be about to
#: succeed. Measured 2026-09-07: `ai-home facts` on a 50-widget Classie workspace takes
#: 24-27s (50 widgets / 4 concurrent x ~1.4s render, plus the supply graph), so it sits
#: just under a 30s deadline and tips over it as soon as a widget or two is added.
#:
#: ⛔ RAISING THIS IS NOT A FIX FOR A SLOW ENDPOINT — it only stops the CLI lying about
#: what happened. The render fan-out is the real cost and is tracked separately.
#:
#: Override per invocation when a deployment is genuinely slower:
#:     TORANA_READ_TIMEOUT=120 torana workspace <id> ai-home facts
_READ_TIMEOUT = float(os.getenv("TORANA_READ_TIMEOUT", "90"))
_WRITE_TIMEOUT = float(os.getenv("TORANA_WRITE_TIMEOUT", "120"))

# Exit codes matching the CLI spec
EXIT_GENERAL = 1
EXIT_USAGE = 2
EXIT_NOT_FOUND = 3
EXIT_PERMISSION = 4
EXIT_AUTH = 5
EXIT_VALIDATION = 6


class APIError(Exception):
    """Raised on non-2xx API responses."""

    def __init__(self, message: str, status_code: int, detail: Any = None):
        super().__init__(message)
        self.status_code = status_code
        self.detail = detail

    @property
    def exit_code(self) -> int:
        if self.status_code == 401:
            return EXIT_AUTH
        if self.status_code == 403:
            return EXIT_PERMISSION
        if self.status_code == 404:
            return EXIT_NOT_FOUND
        if self.status_code == 422:
            return EXIT_VALIDATION
        return EXIT_GENERAL


def _current_command_path() -> str:
    """The CLI leaf currently executing, e.g. "datalake query". Empty when unknown.

    ⭐ WHY THIS EXISTS. A host that brokers this CLI's egress (pantheon-agent-builder's
    sandbox broker) has to authorize each call. Reconstructing the command from the URL is a
    heuristic and it is wrong in BOTH directions — measured 2026-08-29 on real traffic, it
    refused 5 of 7 legitimate reads and, worse, ADMITTED `GET /api/v1/query` by matching an
    unrelated leaf. The CLI already knows the answer exactly at this moment, so it states it
    rather than letting the broker guess: `datalake query` calls `/query`, which no path
    parser recovers.

    ⛔ THIS IS A CLAIM, NOT A CREDENTIAL. Anything can send this header. The broker treats it
    as one of two independent facts and corroborates it against the request itself; see
    pantheon-agent-builder/docs/streams/STREAM_F_broker_authz.md § 3.2.

    ⚠️ Never raises and never blocks a call: a laptop user is unaffected, and a missing
    header simply means the broker has nothing to corroborate (it then refuses, which is the
    correct direction).
    """
    try:
        import click
        ctx = click.get_current_context(silent=True)
        if ctx is None:
            return ""
        parts = []
        while ctx is not None:
            if ctx.info_name:
                parts.append(ctx.info_name)
            ctx = ctx.parent
        parts.reverse()
        # Drop the root program name ("torana" / "cli"), keeping the leaf path.
        return " ".join(parts[1:]) if len(parts) > 1 else ""
    except Exception:
        return ""


def _dry_run_active() -> bool:
    """True when the root `torana --dry-run` flag is set for the running command."""
    try:
        import click
        ctx = click.get_current_context(silent=True)
        root = ctx.find_root() if ctx is not None else None
        return bool(root is not None and isinstance(root.obj, dict) and root.obj.get("dry_run"))
    except Exception:
        return False


def _declares_dry_run(json: Any, params: Optional[dict]) -> bool:
    """A request that is itself a server-side preview (`dry_run` in its body or query)."""
    for bag in (json, params):
        if isinstance(bag, dict) and str(bag.get("dry_run", "")).lower() in ("true", "1"):
            return True
    return False


def _dry_run_guard(method: str, url: str, json: Any = None, params: Optional[dict] = None) -> None:
    """Stop before the first WRITE under `torana --dry-run`.

    ⛔ The flag promises "without making any API calls", but only three commands read it:
    every other command, generated ones included, sent its write anyway (a `--dry-run
    tenants reset` reached the server, 2026-09-30). Enforcing it here covers every
    command at once. Reads still run, so previews keep working, and a write that is
    itself a server-side preview (`dry_run: true`) is let through.
    """
    if not _dry_run_active() or _declares_dry_run(json, params):
        return
    import json as _json
    sys.stderr.write(f"[dry-run] would send: {method} {url}\n")
    if params:
        sys.stderr.write(f"[dry-run]   params: {_json.dumps(params, default=str)}\n")
    if json is not None:
        sys.stderr.write(f"[dry-run]   body:   {_json.dumps(json, default=str)[:2000]}\n")
    sys.stderr.write("[dry-run] stopped before the first write; nothing was changed.\n")
    sys.exit(0)


#: F1/F2 (2026-10-01 log triage): who started a call. The platform demotes a failure an LLM
#: caused (a guessed table name) and keeps a code-originated one loud; see
#: pantheon-shared `pantheon_shared/http/origin.py` for the closed value set.
ORIGIN_HEADER = "x-pantheon-origin"
#: CLI trace ids are recognisable on sight in any log line or Jaeger search:
#:   c11a + origin digit (0 human, c Claude Code) + 11-hex session + 16 random hex = 32 hex,
#: still a valid OTel trace id. One id per CLI process, so one invocation = one trace.
_TRACE_PREFIX = "c11a"


def _under_claude_code() -> bool:
    return bool(os.getenv("CLAUDECODE"))


def _call_origin() -> str:
    return "cli-llm" if _under_claude_code() else "cli"


def _session_part() -> str:
    """11 hex grouping every call of one session. A hash, so no raw session id is sent."""
    key = (os.getenv("TORANA_SESSION_ID")
           or (os.getenv("CLAUDE_CODE_SESSION_ID") if _under_claude_code() else None)
           or os.getenv("TERM_SESSION_ID")
           or f"ppid:{os.getppid()}")
    return hashlib.sha256(key.encode()).hexdigest()[:11]


def _new_trace_id() -> str:
    digit = "c" if _under_claude_code() else "0"
    return f"{_TRACE_PREFIX}{digit}{_session_part()}{secrets.token_hex(8)}"


_PROCESS_TRACE_ID: Optional[str] = None


def _cli_trace_id() -> str:
    global _PROCESS_TRACE_ID
    if _PROCESS_TRACE_ID is None:
        _PROCESS_TRACE_ID = _new_trace_id()
    return _PROCESS_TRACE_ID


def _inherited_trace_headers() -> Optional[dict]:
    """F9b: run in-process inside a Pantheon service (pantheon-admin's cli_runner), continue the
    caller's trace instead of minting a new one. None on a human's terminal (no current span).

    The origin is the caller's inbound one when it has one (an agent tool driving the CLI stays
    `llm-tool`), else the CLI's own.
    """
    try:
        from opentelemetry import trace
        if not trace.get_current_span().get_span_context().is_valid:
            return None
        from pantheon_shared.tracing import outgoing_trace_headers
    except Exception:
        return None
    h = outgoing_trace_headers()
    out = {k: h[k] for k in ("traceparent", "X-Trace-ID", "X-Span-ID", "X-Session-ID", "X-Turn-ID")
           if k in h}
    origin = _call_origin()
    try:
        from pantheon_shared.http.origin import WIRE_ORIGINS, current_origin
        if current_origin() in WIRE_ORIGINS:
            origin = current_origin()
    except Exception:
        pass
    out[ORIGIN_HEADER] = origin
    return out


def _trace_headers() -> dict:
    """W3C traceparent + business X-Trace-ID (the F4 pair), and the call origin."""
    inherited = _inherited_trace_headers()
    if inherited:
        return inherited
    trace_id = _cli_trace_id()
    return {
        "traceparent": f"00-{trace_id}-{secrets.token_hex(8)}-01",
        "X-Trace-ID": trace_id,
        ORIGIN_HEADER: _call_origin(),
    }


class ToranaClient:
    """
    HTTP client for Torana REST APIs.

    All requests go to {base_url}/api/v1/{path} via nginx gateway.
    Auth is handled automatically via get_access_token().
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        access_token: Optional[str] = None,
        profile: Optional[str] = None,
    ):
        settings = get_settings(profile)
        self._base_url = (base_url or settings.base_url).rstrip("/")
        self._access_token = access_token
        self._profile = profile

    def _get_token(self) -> str:
        if self._access_token:
            return self._access_token
        return get_access_token(self._base_url, self._profile)

    def _build_url(self, path: str) -> str:
        """Prepend /api/v1/ if the path doesn't already have a full prefix.

        Paths starting with '/' are treated as absolute and used as-is
        (no /api/v1/ prepend). This is needed for services whose nginx
        location blocks don't include the /api/v1/ prefix.

        Trailing slashes are stripped to avoid 307 redirects from nginx
        that would drop the Authorization header on the redirect.
        """
        if path.startswith("/"):
            return f"{self._base_url}{path.rstrip('/')}"
        path = path.strip("/")
        if not path.startswith("api/"):
            path = f"api/v1/{path}"
        return f"{self._base_url}/{path}"

    def _headers(self) -> dict:
        token = self._get_token()
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            # G-API-1: httpx's default User-Agent ("python-httpx/<version>") gives nginx
            # no way to tell CLI traffic from a script or curl. `log_format main` reads
            # this to label requests `client=cli` for the API-errors dashboard.
            "User-Agent": f"torana-cli/{__version__}",
        }
        headers.update(_trace_headers())
        cmd = _current_command_path()
        if cmd:
            headers["X-Torana-Command"] = cmd
        return headers

    def get(self, path: str, params: Optional[dict] = None,
            timeout: Optional[float] = None) -> Any:
        """GET `path`.

        `timeout` overrides the default read deadline for the few endpoints that are
        legitimately slow — `post()` already had this; GET did not, so a slow read had
        no escape hatch short of an env var.
        """
        url = self._build_url(path)
        logger.debug(f"GET {url} params={params}")
        try:
            with httpx.Client(timeout=timeout or _READ_TIMEOUT,
                              follow_redirects=True) as client:
                resp = client.get(url, headers=self._headers(), params=params)
        except httpx.RequestError as e:
            raise APIError(f"Cannot reach {url}: {e}", status_code=0) from e
        self._handle_response(resp)
        return resp.json()

    def get_with_headers(self, path: str, params: Optional[dict] = None,
                         timeout: Optional[float] = None):
        """GET `path` → `(json, headers)`, for endpoints that return their row count in
        a header (e.g. `X-Total-Count`) because the body is a bare array."""
        url = self._build_url(path)
        logger.debug(f"GET {url} params={params}")
        try:
            with httpx.Client(timeout=timeout or _READ_TIMEOUT,
                              follow_redirects=True) as client:
                resp = client.get(url, headers=self._headers(), params=params)
        except httpx.RequestError as e:
            raise APIError(f"Cannot reach {url}: {e}", status_code=0) from e
        self._handle_response(resp)
        return resp.json(), resp.headers

    def get_bytes(self, path: str, params: Optional[dict] = None,
                  timeout: Optional[float] = None) -> tuple:
        """GET `path` and return `(content, filename)` for a FILE download.

        ⛔ A separate method, not a flag on `get()`. `get()` ends in
        `resp.json()`, so pointing it at an .xlsx raises a JSON decode error on
        a perfectly good response — the failure reads as a broken endpoint
        rather than the wrong reader.

        `filename` comes from Content-Disposition when the server sets one, so
        the server names the file (it knows the scope and timestamp); None when
        it does not, and the caller falls back to its own name.
        """
        url = self._build_url(path)
        logger.debug(f"GET(bytes) {url} params={params}")
        try:
            with httpx.Client(timeout=timeout or _READ_TIMEOUT,
                              follow_redirects=True) as client:
                resp = client.get(url, headers=self._headers(), params=params)
        except httpx.RequestError as e:
            raise APIError(f"Cannot reach {url}: {e}", status_code=0) from e
        self._handle_response(resp)

        filename = None
        disposition = resp.headers.get("content-disposition", "")
        if "filename=" in disposition:
            filename = disposition.split("filename=", 1)[1].strip().strip('"')
        return resp.content, filename

    def post(
        self,
        path: str,
        json: Optional[dict] = None,
        params: Optional[dict] = None,
        extra_headers: Optional[dict] = None,
        timeout: Optional[float] = None,
    ) -> Any:
        """POST to `path`.

        `timeout` overrides the default write deadline for the few endpoints that
        are legitimately long-running (e.g. build-v2 deploy, which materializes
        every transformer inline). Pass a larger value rather than raising
        `_WRITE_TIMEOUT` globally — a long default would mask genuinely hung
        requests on every other endpoint.
        """
        url = self._build_url(path)
        _dry_run_guard("POST", url, json, params)
        logger.debug(f"POST {url}")
        headers = self._headers()
        if extra_headers:
            headers = {**headers, **extra_headers}
        try:
            with httpx.Client(timeout=timeout or _WRITE_TIMEOUT, follow_redirects=True) as client:
                resp = client.post(url, headers=headers, json=json, params=params)
        except httpx.RequestError as e:
            raise APIError(f"Cannot reach {url}: {e}", status_code=0) from e
        self._handle_response(resp)
        try:
            return resp.json()
        except Exception:
            return {}

    def post_stream(
        self,
        path: str,
        json: Optional[dict] = None,
        params: Optional[dict] = None,
    ):
        """POST to a text/event-stream endpoint, yielding parsed SSE events.

        Yields each `data:` payload as a parsed object (dict/list) when it is JSON, else the raw
        string. Use for endpoints that stream Server-Sent Events (e.g. agent invoke/stream, chat).
        Raises APIError on a non-2xx status before the stream begins.
        """
        import json as _json
        url = self._build_url(path)
        _dry_run_guard("POST", url, json, params)
        logger.debug(f"POST(stream) {url}")
        headers = {**self._headers(), "Accept": "text/event-stream"}
        try:
            with httpx.Client(timeout=None, follow_redirects=True) as client:
                with client.stream("POST", url, headers=headers, json=json, params=params) as resp:
                    if resp.status_code >= 400:
                        # Read the (buffered) error body so _handle_response can classify it.
                        resp.read()
                        self._handle_response(resp)
                        return
                    for line in resp.iter_lines():
                        if not line or not line.startswith("data:"):
                            continue
                        payload = line[len("data:"):].strip()
                        if not payload or payload == "[DONE]":
                            continue
                        try:
                            yield _json.loads(payload)
                        except Exception:
                            yield payload
        except httpx.RequestError as e:
            raise APIError(f"Cannot reach {url}: {e}", status_code=0) from e

    def put(self, path: str, json: Optional[dict] = None, params: Optional[dict] = None) -> Any:
        url = self._build_url(path)
        _dry_run_guard("PUT", url, json, params)
        logger.debug(f"PUT {url}")
        try:
            with httpx.Client(timeout=_WRITE_TIMEOUT, follow_redirects=True) as client:
                resp = client.put(url, headers=self._headers(), json=json, params=params)
        except httpx.RequestError as e:
            raise APIError(f"Cannot reach {url}: {e}", status_code=0) from e
        self._handle_response(resp)
        try:
            return resp.json()
        except Exception:
            return {}

    def patch(self, path: str, json: Optional[dict] = None, params: Optional[dict] = None) -> Any:
        url = self._build_url(path)
        _dry_run_guard("PATCH", url, json, params)
        logger.debug(f"PATCH {url}")
        try:
            with httpx.Client(timeout=_WRITE_TIMEOUT, follow_redirects=True) as client:
                resp = client.patch(url, headers=self._headers(), json=json, params=params)
        except httpx.RequestError as e:
            raise APIError(f"Cannot reach {url}: {e}", status_code=0) from e
        self._handle_response(resp)
        try:
            return resp.json()
        except Exception:
            return {}

    def delete(self, path: str, params: Optional[dict] = None) -> Optional[Any]:
        url = self._build_url(path)
        _dry_run_guard("DELETE", url, None, params)
        logger.debug(f"DELETE {url}")
        try:
            with httpx.Client(timeout=_READ_TIMEOUT, follow_redirects=True) as client:
                resp = client.delete(url, headers=self._headers(), params=params)
        except httpx.RequestError as e:
            raise APIError(f"Cannot reach {url}: {e}", status_code=0) from e
        self._handle_response(resp)
        if resp.status_code == 204 or not resp.content:
            return None
        try:
            return resp.json()
        except Exception:
            return None

    def _handle_response(self, resp: httpx.Response) -> None:
        """Raise APIError for non-2xx responses with structured detail."""
        logger.info(
            f"{resp.request.method} {resp.request.url} → {resp.status_code} "
            f"({resp.elapsed.total_seconds() * 1000:.0f}ms)"
        )
        if resp.is_success:
            return

        detail = None
        try:
            body = resp.json()
            detail = body.get("detail") or body
        except Exception:
            pass

        status = resp.status_code
        if status == 401:
            msg = "Authentication required — run 'torana auth login'"
        elif status == 403:
            msg = "Permission denied (HTTP 403)"
        elif status == 404:
            msg = "Resource not found (HTTP 404)"
        elif status == 422:
            msg = "Validation error (HTTP 422)"
        else:
            msg = f"API error (HTTP {status})"

        err = APIError(msg, status_code=status, detail=detail)
        # CLI-51 — a 404 has TWO indistinguishable causes: the capability was never
        # built, or the DEPLOYMENT serving this path is behind the source that has it.
        # Nothing reported which, so a checkout 31 commits behind produced three wrong
        # findings (CLI-42, CLI-43, one test-plan blocker) filed against routes that
        # worked upstream. Carry the path so the error handler can say "attribute this
        # before filing it" and name the command that settles the question.
        if status == 404:
            try:
                err.request_path = resp.request.url.path
            except Exception:
                err.request_path = None
        raise err


def handle_api_error(e: APIError) -> None:
    """Print a formatted error message to stderr and exit with the appropriate code."""
    import click

    # A 409 whose body is `{"detail": {"error": <code>, "message": <sentence>}}` (e.g.
    # `repair_running`, `build_lock_queue_full`, `build_lock_held`) is a "busy, try later"
    # answer, not a failure of the request itself. Lead with the server's sentence on ONE
    # line so it is the first thing read; any other keys (e.g. `holder`) follow indented.
    # Exit code is unchanged (1).
    if (e.status_code == 409 and isinstance(e.detail, dict)
            and e.detail.get("message")):
        code = e.detail.get("error")
        click.echo(f"\nERROR: {e.detail['message']}" + (f" ({code}, HTTP 409)" if code
                                                          else " (HTTP 409)"), err=True)
        for k, v in e.detail.items():
            if k not in ("error", "message"):
                click.echo(f"  {k}: {v}", err=True)
        sys.exit(e.exit_code)

    click.echo(f"\nERROR: {e}", err=True)

    if e.detail:
        if isinstance(e.detail, list):
            for item in e.detail:
                if isinstance(item, dict):
                    loc = " → ".join(str(x) for x in item.get("loc", []))
                    msg = item.get("msg", "")
                    click.echo(f"  {loc}: {msg}", err=True)
                else:
                    click.echo(f"  {item}", err=True)
        elif isinstance(e.detail, dict):
            for k, v in e.detail.items():
                click.echo(f"  {k}: {v}", err=True)
        else:
            click.echo(f"  {e.detail}", err=True)

    # CLI-51 — make a 404 ATTRIBUTABLE instead of merely reported.
    #
    # ⛔ The failure this prevents is not a crash, it is a WRONG FILING. A 404 from a
    # stale deployment and a 404 from a capability that was never built are
    # byte-identical, and three issues were filed against the first believing it was the
    # second. So the hint does not guess — it names the ONE command that distinguishes
    # them, because the deployment's own build is the missing evidence.
    if e.status_code == 404:
        path = getattr(e, "request_path", None)
        click.echo("", err=True)
        if path:
            click.echo(f"  path: {path}", err=True)
        click.echo("  A 404 means EITHER this capability does not exist, OR the deployed",
                   err=True)
        click.echo("  service is behind the source that has it. These are indistinguishable",
                   err=True)
        click.echo("  from here — confirm which before filing a gap:", err=True)
        click.echo("      torana admin services list   # per-service build commit", err=True)

    sys.exit(e.exit_code)


def handle_auth_error(e: AuthError) -> None:
    """Print auth error and exit with code 5."""
    import click

    click.echo(f"\nERROR: {e}", err=True)
    sys.exit(EXIT_AUTH)
