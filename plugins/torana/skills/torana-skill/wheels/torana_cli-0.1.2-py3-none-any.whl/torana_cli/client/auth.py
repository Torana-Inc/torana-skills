"""Token management, auto-refresh, and credential storage for the Torana CLI."""

import json
import os
import sys
import time
from contextvars import ContextVar
from pathlib import Path
from typing import Optional

import httpx
import jwt

from torana_cli.config.settings import get_settings, resolve_profile_name

# Paths
CACHE_DIR = Path.home() / ".torana" / "cache"
# Legacy single-profile cache file. Auto-migrated to the per-profile file on
# first read so existing sessions survive the upgrade.
LEGACY_TOKEN_FILE = CACHE_DIR / "token.json"
CREDENTIALS_FILE = Path.home() / ".torana" / "credentials.yaml"


class AuthError(Exception):
    """Raised when authentication fails."""

    pass


# ── Injected token (in-process embedding) ──────────────────────────────────────
#
# Set by a HOST PROCESS that embeds the CLI (e.g. pantheon-admin invoking
# `torana_cli.main:cli` through click.testing.CliRunner) to supply the bearer
# token for ONE invocation, instead of the on-disk token-<profile>.json cache a
# laptop user relies on.
#
# ⛔ A ContextVar, deliberately NOT an environment variable. `os.environ` is
# process-global, and an embedding host is multi-worker and serves concurrent
# tenants — an env var would race across in-flight requests and could leak
# tenant A's token into tenant B's call. A ContextVar is scoped to the calling
# task/thread, so concurrent invocations cannot see each other's token.
#
# A laptop user who never calls set_injected_token() sees no behaviour change
# whatsoever: the default is None and every existing resolution step is
# untouched.
_injected_token: ContextVar[Optional[str]] = ContextVar(
    "torana_cli_injected_token", default=None
)


def set_injected_token(token: Optional[str]):
    """Inject a bearer token for the current context. Returns the reset Token.

    Callers MUST reset it when the invocation finishes:

        tok = set_injected_token(jwt)
        try:
            CliRunner().invoke(cli, argv)
        finally:
            reset_injected_token(tok)
    """
    return _injected_token.set(token)


def reset_injected_token(token) -> None:
    """Restore the previous injected-token value (pair with set_injected_token)."""
    _injected_token.reset(token)


def get_injected_token() -> Optional[str]:
    """Return the token injected for this context, if any."""
    return _injected_token.get()


def _token_file(profile: Optional[str] = None) -> Path:
    """Path to the token cache file for a given profile.

    Each profile keeps its own cached session (token-<profile>.json) so that
    switching the active profile never invalidates another profile's login.
    """
    name = resolve_profile_name(profile)
    return CACHE_DIR / f"token-{name}.json"


def _load_cached_token(profile: Optional[str] = None) -> Optional[dict]:
    """Load token from this profile's cache file. Returns None if missing.

    On first run after upgrading, if the per-profile file doesn't exist but the
    legacy token.json does, migrate it into the active profile's file so the
    existing session is preserved (one-time, best-effort).
    """
    token_file = _token_file(profile)
    if not token_file.exists() and LEGACY_TOKEN_FILE.exists():
        try:
            legacy = json.loads(LEGACY_TOKEN_FILE.read_text())
            CACHE_DIR.mkdir(parents=True, exist_ok=True)
            token_file.write_text(json.dumps(legacy, indent=2))
            token_file.chmod(0o600)
            LEGACY_TOKEN_FILE.unlink()
        except Exception:
            pass
    if not token_file.exists():
        return None
    try:
        return json.loads(token_file.read_text())
    except Exception:
        return None


def _save_cached_token(token_data: dict, profile: Optional[str] = None) -> None:
    """Save token data to this profile's cache file with restricted permissions."""
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    token_file = _token_file(profile)
    token_file.write_text(json.dumps(token_data, indent=2))
    token_file.chmod(0o600)


def _clear_cached_token(profile: Optional[str] = None) -> None:
    """Remove this profile's cached token file."""
    token_file = _token_file(profile)
    if token_file.exists():
        token_file.unlink()


def _is_token_expired(access_token: str, buffer_seconds: int = 60) -> bool:
    """Return True if the JWT has expired (or will expire within buffer_seconds)."""
    try:
        claims = jwt.decode(access_token, options={"verify_signature": False})
        exp = claims.get("exp")
        if exp is None:
            return False  # No expiry claim — treat as valid
        return time.time() >= (exp - buffer_seconds)
    except Exception:
        return True  # Can't parse — treat as expired


def login(base_url: str, email: str, password: str, profile: Optional[str] = None,
          persist: bool = True) -> dict:
    """
    Authenticate with the Torana platform and return the token response.
    Also saves the token to the cache for the given (or active) profile.

    `persist=False` returns the token WITHOUT writing it to any profile's cache.
    Used for env-var (`TORANA_EMAIL`/`TORANA_PASSWORD`) auth, which is a per-command
    override: writing it to the profile would silently repoint that profile at the
    env identity for every later command, long after the env vars are gone (CLI-21).

    Returns dict with keys: access_token, refresh_token, token_type, expires_in
    Raises AuthError on failure.
    """
    url = f"{base_url.rstrip('/')}/api/v1/auth/login"
    try:
        resp = httpx.post(
            url,
            json={"email": email, "password": password, "rememberMe": False},
            headers={"Content-Type": "application/json"},
            timeout=15,
        )
        resp.raise_for_status()
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            raise AuthError("Invalid credentials. Check your email and password.") from e
        raise AuthError(f"Login failed: HTTP {e.response.status_code}") from e
    except httpx.RequestError as e:
        raise AuthError(f"Cannot reach {url}: {e}") from e

    data = resp.json()
    access_token = data.get("access_token")
    if not access_token:
        raise AuthError("No access_token in response")

    token_data = {
        "access_token": access_token,
        "refresh_token": data.get("refresh_token"),
        "token_type": data.get("token_type", "bearer"),
        "base_url": base_url,
        "email": email,
        "auth_method": "password",
        "profile": resolve_profile_name(profile),
    }
    if persist:
        _save_cached_token(token_data, profile)
    return token_data


def logout(profile: Optional[str] = None) -> None:
    """Clear the cached token for the given (or active) profile."""
    _clear_cached_token(profile)


def refresh_token(base_url: str, refresh_tok: str, profile: Optional[str] = None) -> dict:
    """
    Attempt to refresh an access token using the refresh token.
    Returns new token data and saves to cache for the given (or active) profile.
    Raises AuthError on failure.
    """
    url = f"{base_url.rstrip('/')}/api/v1/auth/refresh"
    try:
        resp = httpx.post(
            url,
            json={"refresh_token": refresh_tok},
            headers={"Content-Type": "application/json"},
            timeout=15,
        )
        resp.raise_for_status()
    except httpx.HTTPStatusError as e:
        raise AuthError(f"Token refresh failed: HTTP {e.response.status_code}") from e
    except httpx.RequestError as e:
        raise AuthError(f"Cannot reach {url}: {e}") from e

    data = resp.json()
    access_token = data.get("access_token")
    if not access_token:
        raise AuthError("No access_token in refresh response")

    cached = _load_cached_token(profile) or {}
    token_data = {
        "access_token": access_token,
        "refresh_token": data.get("refresh_token", refresh_tok),
        "token_type": data.get("token_type", "bearer"),
        "base_url": base_url,
        "email": cached.get("email", ""),
        "auth_method": cached.get("auth_method", "password"),
        "profile": resolve_profile_name(profile),
    }
    _save_cached_token(token_data, profile)
    return token_data


def get_access_token(base_url: Optional[str] = None, profile: Optional[str] = None) -> str:
    """
    Resolve a valid access token for the given (or active) profile, using:
    0. Token injected into this context by an embedding host (see set_injected_token)
    1. TORANA_TOKEN env var
    2. TORANA_EMAIL + TORANA_PASSWORD env vars (auto-login)
    3. Cached token for this profile (auto-refresh if expired)
    4. Config profile email + credentials.yaml

    Raises AuthError if no valid token can be obtained.
    """
    settings = get_settings(profile)
    effective_base_url = base_url or settings.base_url

    # 0. Token injected for THIS context by an embedding host. Checked before
    #    TORANA_TOKEN so that a host serving concurrent tenants is never
    #    overridden by a process-global env var one of its own operators set.
    injected = _injected_token.get()
    if injected:
        return injected

    # 1. Explicit token env var
    env_token = os.environ.get("TORANA_TOKEN")
    if env_token:
        return env_token

    # 2. Email + password env vars
    env_email = os.environ.get("TORANA_EMAIL")
    env_password = os.environ.get("TORANA_PASSWORD")
    if env_email and env_password:
        # Env credentials outrank the profile. That is intended for CI, but left
        # silent it means `TORANA_PROFILE=T1 torana …` can run as an entirely
        # different user in a different TENANT with no signal — the cross-tenant
        # write risk behind CLI-21. Two guards:
        #   (a) warn whenever env creds override a profile that has a different
        #       cached identity, so the swap is visible; and
        #   (b) do NOT persist the env identity into the profile's token cache —
        #       otherwise one contaminated command silently repoints the profile
        #       for every LATER command, long after the env vars are gone.
        cached_identity = (_load_cached_token(profile) or {}).get("email")
        if cached_identity and cached_identity.strip().lower() != env_email.strip().lower():
            print(
                f"WARNING: TORANA_EMAIL={env_email} overrides profile "
                f"'{profile or settings.active_profile}' (cached identity: {cached_identity}). "
                f"Running as {env_email}. Unset TORANA_EMAIL/TORANA_PASSWORD to use the profile.",
                file=sys.stderr,
            )
        # profile=None → login() does not write this identity into the profile cache.
        token_data = login(effective_base_url, env_email, env_password, profile=None,
                           persist=False)
        return token_data["access_token"]

    # 3. Cached token (per-profile)
    cached = _load_cached_token(profile)
    if cached:
        access_token = cached.get("access_token")
        if access_token and not _is_token_expired(access_token):
            return access_token

        # Try refresh
        refresh_tok = cached.get("refresh_token")
        if refresh_tok:
            try:
                new_data = refresh_token(effective_base_url, refresh_tok, profile)
                return new_data["access_token"]
            except AuthError:
                pass  # Fall through to credential-based re-auth

        # Re-authenticate — behavior depends on original auth method
        auth_method = cached.get("auth_method", "password")

        if auth_method == "password":
            # Try saved credentials from credentials.yaml
            email = cached.get("email")
            creds = _load_credentials()
            password = creds.get(email) if email else None
            if email and password:
                try:
                    token_data = login(effective_base_url, email, password, profile)
                    return token_data["access_token"]
                except AuthError:
                    pass

        if auth_method == "oauth":
            raise AuthError(
                "Session expired. Run 'torana auth login --web' to re-authenticate."
            )

    raise AuthError(
        "Not authenticated. Run 'torana auth login --email <email> --password <password>' "
        "or 'torana auth login --web' for browser-based login."
    )


def _load_credentials() -> dict:
    """
    Load email→password mapping from ~/.torana/credentials.yaml.
    Returns empty dict if file doesn't exist.
    """
    if not CREDENTIALS_FILE.exists():
        return {}
    try:
        import yaml

        data = yaml.safe_load(CREDENTIALS_FILE.read_text()) or {}
        return data.get("credentials", {})
    except Exception:
        return {}


def save_credential(email: str, password: str) -> None:
    """Save email/password to credentials.yaml with restricted permissions."""
    import yaml

    creds_dir = CREDENTIALS_FILE.parent
    creds_dir.mkdir(parents=True, exist_ok=True)

    existing = {}
    if CREDENTIALS_FILE.exists():
        try:
            existing = yaml.safe_load(CREDENTIALS_FILE.read_text()) or {}
        except Exception:
            existing = {}

    if "credentials" not in existing:
        existing["credentials"] = {}
    existing["credentials"][email] = password

    CREDENTIALS_FILE.write_text(yaml.dump(existing, default_flow_style=False))
    CREDENTIALS_FILE.chmod(0o600)


def get_token_info(access_token: str) -> dict:
    """Decode JWT claims without signature verification. Returns dict of claims."""
    try:
        return jwt.decode(access_token, options={"verify_signature": False})
    except Exception:
        return {}
