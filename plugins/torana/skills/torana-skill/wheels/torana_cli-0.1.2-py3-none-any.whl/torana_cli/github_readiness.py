"""GitHub readiness, the laptop half (B22): can THIS machine push the fix branch the platform will then verify?

The platform half (is the App installed, granted, covering the repository) comes from the API
(`GET /remediation-plans/{id}/github-readiness`) and its `words` are printed verbatim. These checks need the
developer's own `gh` login, so only the CLI can ask them. Same shape as the server's checks:
`{check, ok, reason_code, words, who_fixes}`, `ok` true / false / null (null = could not be asked, never "missing").

⛔ Run BEFORE the lane commits anything: a developer must never push a branch the platform then refuses to record.
"""
import json
import re
import shutil
import subprocess
from typing import Any, Dict, List, Optional

#: code → (words, who_fixes). `{owner}`, `{repository}` and `{login}` are filled when known.
LOCAL_REASONS = {
    "gh_not_installed": (
        "The GitHub CLI (gh) is not installed on this machine, so Torana cannot check that you can push. "
        "Install it from https://cli.github.com.", "developer"),
    "gh_not_authenticated": (
        "The GitHub CLI is not logged in on this machine. Run `gh auth login`.", "developer"),
    "sso_authorization_required": (
        "Your GitHub login is not authorized for {owner}'s SAML single sign-on. Run `gh auth refresh -h github.com` "
        "and authorize {owner} when GitHub asks.", "developer"),
    "no_push_permission": (
        "Your GitHub account {login} cannot push to {repository}. A repository admin must give you write access.",
        "repo_admin"),
    "github_unavailable": (
        "GitHub could not be asked whether you can push to {repository}; nothing is known to be missing. "
        "Try again in a minute.", "developer"),
}

_REPO_KEY = re.compile(r"^(?:repo:)?(?:github\.com)/([^/\s]+)/([^/\s]+)$")
_SSO = re.compile(r"saml|single sign-on|sso", re.I)


def _check(check: str, ok: Optional[bool], code: Optional[str] = None, **ctx: Any) -> Dict[str, Any]:
    out: Dict[str, Any] = {"check": check, "ok": ok, "reason_code": None, "words": None, "who_fixes": None}
    if code:
        words, who = LOCAL_REASONS[code]
        out.update(reason_code=code, words=words.format(**{"owner": "the organization",
                                                            "repository": "the repository",
                                                            "login": "you", **ctx}), who_fixes=who)
    return out


def _gh(args: List[str], cwd: Optional[str]) -> subprocess.CompletedProcess:
    return subprocess.run(["gh", *args], capture_output=True, text=True, cwd=cwd, timeout=30)


def local_checks(target_repository: str, cwd: Optional[str] = None) -> List[Dict[str, Any]]:
    """`gh_cli` then `push_rights` for a github.com target. Never raises."""
    m = _REPO_KEY.match((target_repository or "").strip())
    if not m:
        return []          # the server's `forge` check already names a non-github.com target
    owner, repo = m.group(1), m.group(2)
    ctx = {"owner": owner, "repository": f"{owner}/{repo}"}

    if not shutil.which("gh"):
        return [_check("gh_cli", False, "gh_not_installed", **ctx), _check("push_rights", None)]
    try:
        if _gh(["auth", "status", "-h", "github.com"], cwd).returncode != 0:
            return [_check("gh_cli", False, "gh_not_authenticated", **ctx), _check("push_rights", None)]
        login = (_gh(["api", "user", "--jq", ".login"], cwd).stdout or "").strip()
        p = _gh(["api", f"repos/{owner}/{repo}", "--jq", ".permissions.push"], cwd)
    except (OSError, subprocess.SubprocessError):
        return [_check("gh_cli", None, "github_unavailable", **ctx), _check("push_rights", None)]
    ctx["login"] = login or "you"
    gh_ok = _check("gh_cli", True)
    if p.returncode == 0:
        if (p.stdout or "").strip() == "true":
            return [gh_ok, _check("push_rights", True)]
        return [gh_ok, _check("push_rights", False, "no_push_permission", **ctx)]
    err = f"{p.stderr or ''} {p.stdout or ''}"
    if "403" in err and _SSO.search(err):
        return [gh_ok, _check("push_rights", False, "sso_authorization_required", **ctx)]
    if "404" in err or "403" in err:
        # GitHub answers 404 for a private repository you cannot see: to you it does not exist.
        return [gh_ok, _check("push_rights", False, "no_push_permission", **ctx)]
    return [gh_ok, _check("push_rights", None, "github_unavailable", **ctx)]


def overall(checks: List[Dict[str, Any]]) -> Optional[bool]:
    """True only when every check is true; False when any is false; else None (unknown)."""
    oks = [c.get("ok") for c in checks]
    if all(o is True for o in oks):
        return True
    return False if any(o is False for o in oks) else None


def render(result: Dict[str, Any]) -> str:
    """Text view. ⛔ Icon AND word on every line: state is never carried by colour alone."""
    mark = {True: "✔ ready  ", False: "✖ MISSING", None: "? unknown"}
    verdict = {True: "READY", False: "NOT READY", None: "UNKNOWN (could not check everything)"}
    out = [f"GitHub readiness for {result.get('target_repository')}: {verdict[result.get('ready')]}"]
    if app_line(result.get("app")):
        out.append(f"  {app_line(result.get('app'))}")
    for c in result.get("checks") or []:
        line = f"  {mark[c.get('ok')]}  {c['check']}"
        if c.get("words"):
            line += f"\n      {c['words']}\n      Who fixes it: {c.get('who_fixes')}"
        if c.get("admin_detail"):
            line += f"\n      {admin_line(c)}"
        out.append(line)
    return "\n".join(out)


def app_line(app: Optional[Dict[str, Any]]) -> str:
    """I-23: which GitHub App Torana expects here, from the server's `app` block ('' when it sent none)."""
    if not app or not (app.get("slug") or app.get("app_id")):
        return ""
    name = app.get("name") or app.get("slug")
    bits = [f"slug {app['slug']}" if app.get("slug") and app.get("name") else "",
            f"id {app['app_id']}" if app.get("app_id") else ""]
    detail = ", ".join(b for b in bits if b)
    return f"Torana expects the GitHub App {name}" + (f" ({detail})" if detail else "") + \
        (f": {app['html_url']}" if app.get("html_url") else "")


def admin_line(item: Dict[str, Any]) -> str:
    """I-21: the setting names, printed apart from the sentence and labelled for whom they are."""
    return f"For your Torana administrator: {item['admin_detail']}" if item.get("admin_detail") else ""


def overview_has_problems(data: Dict[str, Any]) -> bool:
    """I-30: true when the plain overview lists any problem (exit 6), top level or on an installation."""
    return bool(data.get("problems")) or any(i.get("problems") for i in data.get("installations") or [])


def installation_state(i: Dict[str, Any]) -> str:
    """The installation's first word. ⛔ Never a bare "✔ ready" while a repository Torana knows is uncovered or was
    not checked (I-24): uncovered repositories are problems; unknown or unchecked ones say how many."""
    if i.get("problems"):
        return "✖ PROBLEMS"
    cov = i.get("repository_coverage") or []
    covered = sum(1 for c in cov if c.get("covered") is True)
    unknown = sum(1 for c in cov if c.get("covered") is None) + int(i.get("coverage_not_checked") or 0)
    if unknown:
        return f"? ready for {covered} known repositories; {unknown} could not be checked"
    if cov:
        return f"✔ ready for all {covered} known repositories"
    return "✔ ready"


def render_overview(data: Dict[str, Any]) -> str:
    """Text view of the plain overview (`integrations github-app readiness`). ⛔ Icon AND word on every line."""
    out: List[str] = []
    if app_line(data.get("app")):
        out.append(app_line(data.get("app")))
    for p in data.get("problems") or []:
        out.append(f"✖ {p['words']}  (who fixes it: {p['who_fixes']})")
        if p.get("repositories"):
            # I-91: the repositories this one cause blocks, under it, never as separate "not covered" rows.
            out.append(f"    Known repositories there: {', '.join(p['repositories'])}")
        if p.get("admin_detail"):
            out.append(f"    {admin_line(p)}")
    for i in data.get("installations") or []:
        out.append(f"{installation_state(i)}  {i.get('account_login')}  repositories: {i.get('repository_selection')}"
                   + (f"  missing permissions: {', '.join(i['missing_permissions'])}"
                      if i.get("missing_permissions") else ""))
        if i.get("repositories") is not None:
            more = " (first 100)" if i.get("repositories_truncated") else ""
            out.append(f"    covers{more}: {', '.join(i['repositories']) or 'no repositories'}")
        for c in i.get("repository_coverage") or []:
            mark = {True: "✔ covered    ", False: "✖ NOT COVERED", None: "? unknown    "}[c.get("covered")]
            out.append(f"    {mark}  {c['repository']}  (known from: {', '.join(c.get('sources') or [])})")
        if i.get("coverage_not_checked"):
            out.append(f"    ? {i['coverage_not_checked']} more known repositories not checked (limit reached)")
        for p in i.get("problems") or []:
            out.append(f"    {p['words']}\n    Who fixes it: {p['who_fixes']}")
            if p.get("admin_detail"):
                out.append(f"    {admin_line(p)}")
    # ⛔ I-91: `repositories_without_installation` is NOT printed as rows: the owner's one problem above already names
    # them. A server older than batch 5 sends no `repositories` on the problem, so fall back to the old rows then.
    if not any(p.get("repositories") is not None for p in data.get("problems") or []):
        for k in data.get("repositories_without_installation") or []:
            out.append(f"✖ NOT COVERED  {k['repository']}  (no installation on its owner; known from: "
                       f"{', '.join(k.get('sources') or [])})")
    if data.get("app_configured") and data.get("plan_repositories_checked") is False:
        out.append("? Remediation-plan repositories not checked (the plan service did not answer); only declared "
                   "related repositories were checked.")
    if not data.get("installations") and not data.get("problems"):
        out.append("No GitHub App installations for this tenant.")
    return "\n".join(out)


def to_json(result: Dict[str, Any]) -> str:
    return json.dumps(result, indent=2)
