"""torana rag — RAG collection and semantic search commands."""

import os
import sys

import click
import httpx

from torana_cli.client.auth import AuthError, get_access_token
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.confirm import confirm as _confirm
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output

_COLLECTION_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 40),
    ("document_count", "DOCS", 6),
    ("created_at", "CREATED", 20),
]

_RESULT_COLS = [
    ("chunk_id", "CHUNK_ID", 36),
    ("score", "SCORE", 6),
    ("document_id", "DOCUMENT_ID", 36),
    ("text", "TEXT", 80),
]

_DOCUMENT_COLS = [
    ("id", "ID", 36),
    ("title", "TITLE", 40),
    ("document_type", "TYPE", 12),
    ("status", "STATUS", 10),
    ("total_chunks", "CHUNKS", 6),
    ("created_at", "CREATED", 20),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group()
def rag():
    """RAG collections and semantic search.

    \b
    Examples:
      torana rag collections list
      torana rag search --collection organization_policies --query "SLA requirements"
      torana rag search --collection vulnerability_management_kb --query "CVE patch cycle" --top-k 5
    """


@rag.group(name="collections")
def rag_collections():
    """Manage and list RAG collections."""


@rag_collections.command(name="list")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def rag_collections_list(ctx, page, page_size):
    """List RAG collections available to this tenant.

    \b
    Example:
      torana rag collections list --json --raw
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        data = client.get("collections/", params=params)
        result = data if isinstance(data, dict) and "items" in data else {
            "items": data if isinstance(data, list) else [],
            "total": len(data) if isinstance(data, list) else 0,
            "page": page, "page_size": effective_page_size,
        }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_COLLECTION_COLS)


@rag_collections.command(name="create")
@click.option("--name", required=True, help="Collection name (e.g. organization_policies).")
@click.option("--description", default=None, help="What this collection contains.")
@click.option("--purpose", default=None, help="Why this collection exists.")
@click.option("--document-type", "document_types", multiple=True,
              help="Expected document type (repeatable, e.g. --document-type policy).")
@click.option("--tag", "tags", multiple=True, help="Tag (repeatable).")
@click.option("--compliance-framework", "compliance_frameworks", multiple=True,
              help="Related compliance framework (repeatable, e.g. SOC2).")
@click.option("--vector-size", default=768, type=int, show_default=True,
              help="Embedding dimension. 768 matches the platform default (gemini-embedding-001).")
@click.option("--distance-metric", default="Cosine", show_default=True,
              type=click.Choice(["Cosine", "Dot", "Euclid"]),
              help="Similarity distance metric.")
@click.option("--workspace-id", "workspace_id", default=None,
              help="Optional workspace UUID — omit for a global/shared collection.")
@click.pass_context
def rag_collections_create(ctx, name, description, purpose, document_types, tags,
                           compliance_frameworks, vector_size, distance_metric, workspace_id):
    """Create a RAG collection.

    Creates both the Postgres metadata row and the Qdrant vector collection.
    Idempotent — re-running with an existing name returns the existing collection.
    A collection must exist before documents can be uploaded into it.

    \b
    Example:
      torana rag collections create \\
        --name organization_policies \\
        --description "Org-specific VM policies, SLA targets, risk acceptance" \\
        --purpose policy_configuration \\
        --document-type policy --document-type compliance \\
        --compliance-framework SOC2 --compliance-framework ISO27001
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {
        "name": name,
        "vector_size": vector_size,
        "distance_metric": distance_metric,
    }
    if description:
        body["description"] = description
    if purpose:
        body["purpose"] = purpose
    if document_types:
        body["document_types"] = list(document_types)
    if tags:
        body["tags"] = list(tags)
    if compliance_frameworks:
        body["compliance_frameworks"] = list(compliance_frameworks)
    if workspace_id:
        body["workspace_id"] = workspace_id

    client = _client(ctx)
    try:
        data = client.post("collections", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt == "json":
        import json
        click.echo(json.dumps(data, indent=2, default=str))
    else:
        click.echo(f"Created collection: {data.get('name', name)}")
        click.echo(f"  ID:       {data.get('id', '?')}")
        click.echo(f"  Vectors:  {data.get('vector_size', vector_size)}-dim {data.get('distance_metric', distance_metric)}")


#: Extensions pantheon-rag will parse. Mirrors RAG_ALLOWED_FILE_EXTENSIONS
#: (pantheon-rag/src/config/settings.py) — kept here so a bulk upload fails fast on the
#: client instead of round-tripping a file the server will reject.
_UPLOADABLE_EXTS = (".pdf", ".docx", ".md", ".txt", ".html")

#: Server cap (RAG_MAX_FILE_SIZE_MB, default 50). Checked client-side for the same reason.
_MAX_FILE_MB = 50


def _derive_title(path: str) -> str:
    """Human title from a filename, for bulk uploads where --title cannot apply per file.

    `01_Information-Security-Policy.pdf` -> `Information Security Policy`

    ⚠️ The title is what a reconciliation ledger joins on against an external system's
    policy name, so this rule is load-bearing, not cosmetic. Verify it against a real
    export before relying on the join.

    ⚠️ KNOWN LIMIT — the ALL_CAPS branch is best-effort only. Preserving short tokens
    rescues real acronyms (VM, CISO, SAAS) but over-preserves short ordinary words
    ("ZERO DAY Response Policy"). No length rule separates the two without a dictionary,
    and it is not worth one: the branch fires ONLY on an entirely-uppercase filename,
    which is a dev-fixture convention. A real GRC export ships mixed-case human-readable
    names ("Code of Conduct.pdf"), where `.isupper()` is False and the name passes through
    untouched. Preview with --dry-run; to override, rename the file or upload it singly
    with --title.
    """
    import re
    stem = os.path.splitext(os.path.basename(path))[0]
    stem = re.sub(r"^\d+[-_.\s]*", "", stem)          # drop an ordering prefix
    stem = re.sub(r"[-_]+", " ", stem)
    stem = re.sub(r"\s+", " ", stem).strip()
    if stem.isupper():
        # ALL_CAPS_FILENAME -> Title Case, but PRESERVE short all-caps tokens, which are
        # overwhelmingly acronyms in this domain. Blind .title() produced "Vm Operations
        # Policy" and "Ciso Reporting Policy" on the real corpus — wrong, and the title is
        # a join key, so a mangled acronym is a failed match rather than a cosmetic nit.
        # Length-based rather than a hardcoded acronym list, which would silently drift.
        stem = " ".join(
            tok if len(tok) <= 5 else tok.title()
            for tok in stem.split(" ")
        )
    return stem or os.path.basename(path)


def _collect_uploadables(root: str, recursive: bool, exclude=()) -> list:
    """Every parseable file under a directory, sorted for deterministic ordering.

    `exclude` is a tuple of fnmatch globs tested against the BASENAME — a corpus export
    routinely carries scaffolding (README, index files) that must not be indexed as policy.
    """
    import fnmatch

    def _excluded(name: str) -> bool:
        return any(fnmatch.fnmatch(name, pat) for pat in exclude)

    found = []
    if recursive:
        for dirpath, _dirnames, filenames in os.walk(root):
            for fn in filenames:
                if fn.lower().endswith(_UPLOADABLE_EXTS) and not fn.startswith(".") \
                        and not _excluded(fn):
                    found.append(os.path.join(dirpath, fn))
    else:
        for fn in os.listdir(root):
            full = os.path.join(root, fn)
            if os.path.isfile(full) and fn.lower().endswith(_UPLOADABLE_EXTS) \
                    and not fn.startswith(".") and not _excluded(fn):
                found.append(full)
    return sorted(found)


def _extract_zip(zip_path: str, dest: str) -> None:
    """Expand a zip into `dest`, refusing any member that escapes it.

    ⛔ Zip-slip guard is not optional: a crafted archive with `../` members would
    otherwise write anywhere the CLI user can write. Every member's RESOLVED path must
    stay under `dest`.
    """
    import zipfile
    dest_real = os.path.realpath(dest)
    with zipfile.ZipFile(zip_path) as zf:
        for member in zf.infolist():
            if member.is_dir():
                continue
            target = os.path.realpath(os.path.join(dest, member.filename))
            if not (target == dest_real or target.startswith(dest_real + os.sep)):
                raise click.ClickException(
                    f"Refusing to extract {member.filename!r}: it escapes the extraction "
                    f"directory (zip-slip)."
                )
            os.makedirs(os.path.dirname(target), exist_ok=True)
            with zf.open(member) as src, open(target, "wb") as out:
                out.write(src.read())


def _fingerprint(path: str) -> str:
    """First 12 hex chars of the file's sha256 — the content half of `Document.version`.

    ⚠️ Pattern borrowed VERBATIM from pantheon-cli/skills/torana-vm/SPEC.md:500, which
    established it because `Document` has NO `content_hash` column: the fingerprint rides
    in the EXISTING `version` field as "<semver>+<sha256[:12]>". Do not invent a second
    scheme — two fingerprint formats in one column is worse than none.
    """
    import hashlib
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()[:12]


def _stamp_version(version, fingerprint: str) -> str:
    """Compose the value written to `Document.version`."""
    return f"{version}+{fingerprint}" if version else fingerprint


def _read_fingerprint(version) -> str:
    """Recover the fingerprint from a stored `version`; '' when there isn't one.

    ⚠️ The shape check is load-bearing. A legacy document carrying `version="1.0"` has no
    fingerprint, but a naive rsplit returns "1.0" — which then compares unequal to every
    real fingerprint and silently classifies the document as CHANGED. Returning '' instead
    lets the caller say "no fingerprint recorded" rather than assert a change it cannot know
    about.
    """
    import re
    if not version:
        return ""
    tail = str(version).rsplit("+", 1)[-1]
    return tail if re.fullmatch(r"[0-9a-f]{12}", tail) else ""


def resolve_collection_id(client, collection_name: str):
    """Collection UUID for a NAME, or None when it does not exist.

    Public because `policy extract --collection` needs the same lookup: one
    implementation of name -> id, so the two commands cannot disagree about which
    collection a name refers to.
    """
    cols = client.get("collections/", params={"skip": 0, "limit": 100})
    items = cols.get("items", cols) if isinstance(cols, dict) else cols
    return next((c.get("id") for c in (items or [])
                 if c.get("name") == collection_name), None)


def list_documents_in_collection(client, collection_id: str, document_type=None) -> list:
    """Every document in a collection, newest first, paginated to exhaustion.

    ⚠️ Pages to the END rather than taking the first 100. A silently truncated list
    would make a bulk extract skip documents while reporting success — the exact
    partial-apply lie `bulk.py` exists to prevent.
    """
    out, page = [], 1
    while True:
        filters = {"collection_id": {"operation": "equals", "value": collection_id}}
        if document_type:
            filters["document_type"] = {"operation": "equals", "value": document_type}
        data = client.post("documents/search", json={
            "page": page, "page_size": 100, "filters": filters,
            "sort": [{"field": "created_at", "direction": "desc"}],
        })
        docs = data.get("items", []) if isinstance(data, dict) else (data or [])
        out.extend(d for d in docs if isinstance(d, dict))
        if len(docs) < 100:
            return out
        page += 1


def _existing_docs(ctx, collection_name: str) -> dict:
    """{title: {"id":…, "version":…}} for documents already in `collection_name`.

    Two calls, not one per file: resolve the collection name -> id, then page the
    document list. Returns {} on ANY failure (collection absent, RAG unreachable) so a
    lookup problem degrades to "upload everything" rather than blocking the upload.
    """
    client = _client(ctx)
    try:
        cid = resolve_collection_id(client, collection_name)
        if not cid:
            return {}
        out = {}
        for d in list_documents_in_collection(client, cid):
            t = d.get("title")
            # Newest-first ordering means the FIRST row for a title is the current one;
            # setdefault keeps it and ignores older duplicates.
            if t:
                out.setdefault(t, {"id": d.get("id"), "version": d.get("version")})
        return out
    except Exception:
        # Deliberately broad: a lookup failure must DEGRADE to "upload everything",
        # never block the upload. The cost of a missed skip is a duplicate; the cost of
        # a hard failure here is an unusable command whenever RAG is briefly unreachable.
        return {}


def _upload_one(url, token, abs_path, title, form_base):
    """POST one file. Returns (ok: bool, payload_or_error)."""
    filename = os.path.basename(abs_path)
    form_data = dict(form_base)
    form_data["title"] = title

    # Let the server decide the content type from the filename — pantheon-rag dispatches
    # its parser on the EXTENSION (document_parser.py), and hardcoding a type here would
    # mislabel every PDF in a mixed folder.
    import mimetypes
    ctype = mimetypes.guess_type(filename)[0] or "application/octet-stream"

    try:
        with open(abs_path, "rb") as f:
            with httpx.Client(timeout=120, follow_redirects=True) as client:
                resp = client.post(
                    url,
                    headers={"Authorization": f"Bearer {token}"},
                    data=form_data,
                    files={"file": (filename, f, ctype)},
                )
    except httpx.RequestError as e:
        return False, f"cannot reach {url}: {e}"

    if resp.status_code not in (200, 201):
        try:
            detail = resp.json().get("detail", resp.text)
        except Exception:
            detail = resp.text
        return False, f"HTTP {resp.status_code}: {detail}"
    return True, resp.json()


@rag.command(name="upload")
@click.argument("path", type=click.Path(exists=True, dir_okay=True, readable=True))
@click.option("--title", default=None,
              help="Display title. Single file only — for a directory or zip the title is "
                   "derived from each filename.")
@click.option("--collection", "collection_name", required=True,
              help="Target collection name (e.g. organization_policies).")
@click.option("--organization-id", "organization_id", default=None,
              help="Tenant UUID. Defaults to the authenticated user's tenant. Super admins may pass a different tenant UUID.")
@click.option("--workspace-id", "workspace_id", default=None,
              help="Optional workspace UUID to attach the document(s) to.")
@click.option("--document-type", "document_type", default=None,
              help="Document type tag (e.g. policy, compliance, standards).")
@click.option("--version", "version", default=None, help="Document version string (e.g. 1.0).")
@click.option("--recursive/--no-recursive", default=True, show_default=True,
              help="Walk sub-directories when PATH is a directory.")
@click.option("--exclude", "exclude", multiple=True, metavar="GLOB",
              help="Skip files whose name matches GLOB (repeatable), e.g. --exclude 'README*'. "
                   "Directory/zip uploads only.")
@click.option("--skip-unchanged/--no-skip-unchanged", default=True, show_default=True,
              help="Skip a file whose content fingerprint already matches a document of the "
                   "same title in the collection. Makes re-running a corpus upload safe.")
@click.option("--replace", is_flag=True,
              help="When a file CHANGED, delete the existing document before uploading. "
                   "Without this the old document is left in place and reported.")
@click.option("--dry-run", is_flag=True,
              help="List what would be uploaded and exit. Nothing is sent.")
@click.pass_context
def rag_upload(ctx, path, title, collection_name, organization_id, workspace_id,
               document_type, version, recursive, exclude, skip_unchanged, replace,
               dry_run):
    """Upload a file, a DIRECTORY, or a ZIP to a RAG collection and ingest it.

    Each document is chunked, embedded, and stored in the target collection so agents can
    retrieve relevant passages via semantic search.

    Directory and zip uploads exist so a policy corpus exported from a GRC tool (e.g. a
    Vanta "policy packet") can be onboarded in one command instead of one command per file.
    Only parseable extensions are uploaded (.pdf .docx .md .txt .html); anything else is
    skipped and reported.

    \b
    Examples:
      # single file (unchanged)
      torana rag upload policy.md \\
        --title "VM Triage Policy" \\
        --collection organization_policies \\
        --document-type policy

    \b
      # a whole exported policy corpus
      torana rag upload ./vanta-policy-packet/ \\
        --collection organization_policies \\
        --document-type policy --exclude 'README*'

    \b
      # straight from the downloaded zip, preview first
      torana rag upload policy-packet.zip \\
        --collection organization_policies \\
        --document-type policy --dry-run
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    import tempfile
    tmpdir = None
    try:
        # ── Resolve PATH to a concrete file list ────────────────────────────
        if os.path.isdir(path):
            files = _collect_uploadables(path, recursive, exclude)
            bulk = True
        elif path.lower().endswith(".zip"):
            tmpdir = tempfile.mkdtemp(prefix="torana-rag-upload-")
            _extract_zip(path, tmpdir)
            files = _collect_uploadables(tmpdir, True, exclude)
            bulk = True
        else:
            files = [path]
            bulk = False

        if bulk and title:
            raise click.ClickException(
                "--title applies to a single file only. For a directory or zip the title "
                "is derived from each filename; re-run without --title."
            )
        if not files:
            raise click.ClickException(
                f"No uploadable files under {path!r}. "
                f"Accepted extensions: {', '.join(_UPLOADABLE_EXTS)}"
            )

        # ── Client-side size gate: fail fast rather than round-trip a reject ─
        planned, oversized = [], []
        for f in files:
            mb = os.path.getsize(f) / (1024 * 1024)
            (oversized if mb > _MAX_FILE_MB else planned).append((f, mb))

        for f, mb in oversized:
            click.echo(f"SKIP  {os.path.basename(f)} — {mb:.1f} MB exceeds the "
                       f"{_MAX_FILE_MB} MB server limit", err=True)

        # ── Classify: new / unchanged / changed ─────────────────────────────
        # The fingerprint is what makes re-running a corpus upload safe. Without it a
        # quarterly re-export creates a SECOND full set of documents — there is no upsert
        # on title and no content_hash column server-side.
        existing = _existing_docs(ctx, collection_name) if skip_unchanged else {}

        actions = []          # (path, mb, title, fingerprint, action, existing_id)
        for f, mb in planned:
            doc_title = title or _derive_title(f)
            fp = _fingerprint(f)
            prior = existing.get(doc_title)
            prior_fp = _read_fingerprint(prior.get("version")) if prior else ""
            if prior is None:
                action, prior_id = "new", None
            elif not prior_fp:
                # Uploaded before fingerprinting existed — we cannot tell whether it
                # changed. Say so rather than guessing; the operator decides.
                action, prior_id = "unfingerprinted", prior.get("id")
            elif prior_fp == fp:
                action, prior_id = "unchanged", prior.get("id")
            else:
                action, prior_id = "changed", prior.get("id")
            actions.append((f, mb, doc_title, fp, action, prior_id))

        if dry_run:
            click.echo(f"Plan for collection '{collection_name}':")
            for f, mb, doc_title, fp, action, prior_id in actions:
                if action == "unchanged":
                    verb = "SKIP (unchanged)"
                elif action == "changed":
                    verb = "REPLACE" if replace else "UPLOAD (old kept)"
                elif action == "unfingerprinted":
                    verb = "REPLACE (no fp)" if replace else "UPLOAD (no fp)"
                else:
                    verb = "UPLOAD"
                click.echo(f"  {os.path.basename(f):<50} {mb:6.2f} MB  "
                           f"{verb:<18} -> {doc_title}")
            n_up = sum(1 for a in actions if a[4] != "unchanged")
            n_skip = sum(1 for a in actions if a[4] == "unchanged")
            click.echo(f"\n{n_up} to upload, {n_skip} unchanged"
                       + (f", {len(oversized)} oversized" if oversized else ""))
            return

        if not planned:
            raise click.ClickException("Every candidate file was skipped; nothing to upload.")

        try:
            token = get_access_token(settings.base_url)
        except AuthError as e:
            handle_auth_error(e)
            return

        url = f"{settings.base_url.rstrip('/')}/api/v1/documents/upload"
        form_base = {"collection_name": collection_name}
        if organization_id:
            form_base["organization_id"] = organization_id
        if workspace_id:
            form_base["workspace_id"] = workspace_id
        if document_type:
            form_base["document_type"] = document_type

        # ── Upload, continuing past a failure so one bad file cannot strand a corpus ──
        results, failures, skipped, replaced = [], 0, 0, 0
        for f, _mb, doc_title, fp, action, prior_id in actions:
            if action == "unchanged":
                skipped += 1
                results.append({"file": os.path.basename(f), "title": doc_title,
                                "id": prior_id, "status": "unchanged"})
                if fmt != "json":
                    click.echo(f"SKIP  {doc_title}  (unchanged, id={prior_id})")
                continue

            # A CHANGED file with --replace: remove the superseded document first, so the
            # collection ends with exactly one copy. Deliberately opt-in — deleting a
            # tenant's document must never be a side effect of an upload.
            if action in ("changed", "unfingerprinted") and replace and prior_id:
                try:
                    _client(ctx).delete(f"documents/{prior_id}")
                    replaced += 1
                except (APIError, AuthError) as e:
                    failures += 1
                    click.echo(f"FAIL  {doc_title} — could not delete superseded "
                               f"document {prior_id}: {e}", err=True)
                    continue

            abs_path = os.path.abspath(f)
            form = dict(form_base)
            form["version"] = _stamp_version(version, fp)
            ok, payload = _upload_one(url, token, abs_path, doc_title, form)
            if ok:
                results.append({
                    "file": os.path.basename(abs_path),
                    "title": doc_title,
                    "id": payload.get("id", "?"),
                    "status": payload.get("status", "?"),
                    "action": action,
                })
                if fmt != "json":
                    note = ""
                    if action == "changed" and not replace:
                        note = (f"  ⚠️ changed — previous document {prior_id} still exists; "
                                f"re-run with --replace to supersede it")
                    elif action == "unfingerprinted" and not replace:
                        note = (f"  ⚠️ previous document {prior_id} has no fingerprint "
                                f"(pre-dates this feature) — cannot tell if it changed; "
                                f"re-run with --replace to supersede it")
                    click.echo(f"OK    {doc_title}  (id={payload.get('id', '?')}, "
                               f"status={payload.get('status', '?')}){note}")
            else:
                failures += 1
                results.append({
                    "file": os.path.basename(abs_path),
                    "title": doc_title,
                    "id": None,
                    "status": "failed",
                    "error": payload,
                })
                click.echo(f"FAIL  {doc_title} — {payload}", err=True)

        uploaded = len(results) - failures - skipped
        if fmt == "json":
            import json
            click.echo(json.dumps(
                {"collection": collection_name, "uploaded": uploaded,
                 "unchanged": skipped, "replaced": replaced, "failed": failures,
                 "results": results},
                indent=2, default=str))
        elif bulk:
            click.echo(f"\n{uploaded} uploaded, {skipped} unchanged, {replaced} replaced, "
                       f"{failures} failed, {len(oversized)} oversized "
                       f"-> collection '{collection_name}'")

        if failures:
            sys.exit(1)
    finally:
        if tmpdir:
            import shutil
            shutil.rmtree(tmpdir, ignore_errors=True)


@rag.command(name="search")
@click.option("--collection", "collection_name", required=True,
              help="Collection name (e.g. organization_policies, vulnerability_management_kb).")
@click.option("--query", "query", required=True, help="Natural language search query.")
@click.option("--top-k", "top_k", default=10, type=int, show_default=True, help="Number of results.")
@click.pass_context
def rag_search(ctx, collection_name, query, top_k):
    """Semantic search over a single RAG collection.

    Returns verbatim chunks ranked by similarity score.

    \b
    Examples:
      torana rag search --collection organization_policies --query "password requirements" --json --raw
      torana rag search --collection vulnerability_management_kb --query "CVSS scoring" --top-k 5
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = {
        "query": query,
        "collection_name": collection_name,
        "top_k": top_k,
    }

    client = _client(ctx)
    try:
        data = client.post("search", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Normalise to list envelope
    items = data.get("results", data.get("chunks", data if isinstance(data, list) else []))
    result = {"items": items, "total": len(items), "page": 1, "page_size": len(items)}
    output(result, fmt=fmt, raw=raw, fields=fields, columns=_RESULT_COLS)


@rag.group(name="collection", invoke_without_command=True)
@click.argument("collection_id", metavar="COLLECTION_ID")
@click.pass_context
def rag_collection(ctx, collection_id):
    """Operate on a single RAG collection by ID.

    Pass the collection UUID from `torana rag collections list`.

    \b
    Examples:
      torana rag collection 770e8400-e29b-41d4-a716-446655440003 get
      torana rag collection 770e8400-e29b-41d4-a716-446655440003 documents
    """
    ctx.ensure_object(dict)
    ctx.obj["_collection_id"] = collection_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _cid(ctx) -> str:
    return ctx.obj.get("_collection_id", "") if ctx.obj else ""


@rag_collection.command(name="get")
@click.pass_context
def rag_collection_get(ctx):
    """Show details for a single collection.

    \b
    Example:
      torana rag collection 770e8400-e29b-41d4-a716-446655440003 get --json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    collection_id = _cid(ctx)

    client = _client(ctx)
    try:
        data = client.get(f"collections/{collection_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@rag_collection.command(name="documents")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--status", "status_filter", default=None,
              help="Filter by ingestion status (e.g. indexed, pending, failed).")
@click.option("--document-type", "document_type", default=None,
              help="Filter by document type (e.g. policy, compliance).")
@click.pass_context
def rag_collection_documents(ctx, page, page_size, status_filter, document_type):
    """List documents in this collection.

    \b
    Examples:
      torana rag collection 770e8400-e29b-41d4-a716-446655440003 documents
      torana rag collection 770e8400-... documents --status indexed --json --raw
      torana rag collection 770e8400-... documents --document-type policy
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    collection_id = _cid(ctx)

    effective_page_size = min(page_size or settings.page_size, 100)

    filters = {"collection_id": {"operation": "equals", "value": collection_id}}
    if status_filter:
        filters["status"] = {"operation": "equals", "value": status_filter}
    if document_type:
        filters["document_type"] = {"operation": "equals", "value": document_type}

    body = {
        "page": page,
        "page_size": effective_page_size,
        "filters": filters,
        "sort": [{"field": "created_at", "direction": "desc"}],
    }

    client = _client(ctx)
    try:
        data = client.post("documents/search", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    result = data if isinstance(data, dict) and "items" in data else {
        "items": data if isinstance(data, list) else [],
        "total": len(data) if isinstance(data, list) else 0,
        "page": page, "page_size": effective_page_size,
    }
    output(result, fmt=fmt, raw=raw, fields=fields, columns=_DOCUMENT_COLS)


# ---------------------------------------------------------------------------
# GAP-3 — document management. Every command below backs onto an EXISTING
# pantheon-rag route; nothing here is new server capability.
#
# Why it matters beyond convenience: a bulk corpus upload that cannot be
# inspected, corrected or undone from the same surface is a one-way door. The
# reconciliation ledger (Vanta design § 4.4) has to ACT on a drifted document,
# not merely report it.
# ---------------------------------------------------------------------------

@rag.command(name="documents")
@click.option("--collection-id", "collection_id", default=None,
              help="Restrict to one collection (UUID).")
@click.option("--workspace-id", "workspace_id", default=None,
              help="Restrict to documents attached to this workspace (UUID).")
@click.option("--document-type", "document_type", default=None,
              help="Filter by document type, e.g. policy.")
@click.option("--status", "status_filter", default=None,
              help="Filter by ingestion status: pending, processing, indexed, failed.")
@click.option("--title-contains", "title_contains", default=None,
              help="Case-insensitive substring match on the title.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def rag_documents(ctx, collection_id, workspace_id, document_type, status_filter,
                  title_contains, page, page_size):
    """List documents across collections, with filters.

    Complements `rag collection <id> documents`, which can only ever answer for ONE
    collection — this answers "what policy documents does this tenant hold at all?",
    which is the question a corpus reconciliation asks.

    \b
    Examples:
      torana rag documents --document-type policy
      torana rag documents --workspace-id 9f1c... --status failed
      torana rag documents --title-contains "Access Control" --json --raw
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)

    filters = {}
    if collection_id:
        filters["collection_id"] = {"operation": "equals", "value": collection_id}
    if workspace_id:
        filters["workspace_id"] = {"operation": "equals", "value": workspace_id}
    if document_type:
        filters["document_type"] = {"operation": "equals", "value": document_type}
    if status_filter:
        filters["status"] = {"operation": "equals", "value": status_filter}
    if title_contains:
        filters["title"] = {"operation": "contains_ignore_case", "value": title_contains}

    body = {
        "page": page,
        "page_size": effective_page_size,
        "filters": filters,
        "sort": [{"field": "created_at", "direction": "desc"}],
    }

    client = _client(ctx)
    try:
        data = client.post("documents/search", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    result = data if isinstance(data, dict) and "items" in data else {
        "items": data if isinstance(data, list) else [],
        "total": len(data) if isinstance(data, list) else 0,
        "page": page, "page_size": effective_page_size,
    }
    output(result, fmt=fmt, raw=raw, fields=fields, columns=_DOCUMENT_COLS)


@rag.group(name="document", invoke_without_command=True)
@click.argument("document_id", metavar="DOCUMENT_ID")
@click.pass_context
def rag_document(ctx, document_id):
    """Operate on a single RAG document by ID.

    Pass the document UUID from `torana rag documents` or `rag upload`.

    \b
    Examples:
      torana rag document 3fa85f64-5717-4562-b3fc-2c963f66afa6 get
      torana rag document 3fa85f64-5717-4562-b3fc-2c963f66afa6 status
      torana rag document 3fa85f64-5717-4562-b3fc-2c963f66afa6 delete --yes
    """
    ctx.ensure_object(dict)
    ctx.obj["_document_id"] = document_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _did(ctx) -> str:
    return ctx.obj.get("_document_id", "") if ctx.obj else ""


@rag_document.command(name="get")
@click.pass_context
def rag_document_get(ctx):
    """Show a document's metadata (title, type, version, chunks, status)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    try:
        data = _client(ctx).get(f"documents/{_did(ctx)}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@rag_document.command(name="status")
@click.pass_context
def rag_document_status(ctx):
    """Show ingestion status — use after an upload to see when chunking finished."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    try:
        data = _client(ctx).get(f"documents/{_did(ctx)}/status")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@rag_document.command(name="update")
@click.option("--title", default=None, help="New display title.")
@click.option("--document-type", "document_type", default=None, help="New document type.")
@click.option("--compliance-framework", "compliance_framework", default=None,
              help="New compliance framework tag (e.g. SOC2, ISO27001).")
@click.option("--version", "version", default=None, help="New version string.")
@click.option("--active/--inactive", "is_active", default=None,
              help="Mark the document active or inactive.")
@click.pass_context
def rag_document_update(ctx, title, document_type, compliance_framework, version, is_active):
    """Update document METADATA (not content — re-upload or reingest for that).

    ⚠️ Editing `--version` by hand will break bulk-upload change detection, which stores
    a content fingerprint there (`<semver>+<sha256[:12]>`). Prefer re-uploading the file.

    \b
    Example:
      torana rag document 3fa85f64-... update --title "Access Control Policy" \\
        --compliance-framework SOC2
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    payload = {}
    if title is not None:
        payload["title"] = title
    if document_type is not None:
        payload["document_type"] = document_type
    if compliance_framework is not None:
        payload["compliance_framework"] = compliance_framework
    if version is not None:
        payload["version"] = version
    if is_active is not None:
        payload["is_active"] = is_active

    if not payload:
        raise click.ClickException(
            "Nothing to update. Pass at least one of --title, --document-type, "
            "--compliance-framework, --version, --active/--inactive."
        )

    try:
        data = _client(ctx).patch(f"documents/{_did(ctx)}", json=payload)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@rag_document.command(name="reingest")
@click.pass_context
def rag_document_reingest(ctx):
    """Re-chunk and re-embed the stored file, keeping the SAME document id.

    Use when ingestion failed or chunking settings changed. It does NOT pick up a new
    file — the stored upload is reprocessed. To change content, upload again.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    try:
        data = _client(ctx).post(f"documents/{_did(ctx)}/reingest", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@rag_document.command(name="delete")
@click.option("--yes", "-y", is_flag=True, help="Skip the confirmation prompt.")
@click.pass_context
def rag_document_delete(ctx, yes):
    """Delete a document and its embedded chunks.

    ⛔ Destructive and not undoable — the vectors go with it. Confirmation is required;
    in a non-interactive context pass --yes explicitly rather than having the prompt
    silently auto-answer.
    """
    document_id = _did(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    # Name the document in the prompt — a bare UUID gives the operator nothing to
    # recognise, which is how the wrong one gets deleted.
    label = document_id
    try:
        meta = _client(ctx).get(f"documents/{document_id}")
        if isinstance(meta, dict) and meta.get("title"):
            label = f"{meta['title']!r} ({document_id})"
    except Exception:
        pass

    _confirm(f"Delete document {label} and all its embedded chunks?", yes=yes)

    try:
        _client(ctx).delete(f"documents/{document_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt == "json":
        import json
        click.echo(json.dumps({"id": document_id, "deleted": True}, indent=2))
    else:
        click.echo(f"Deleted document {label}")
