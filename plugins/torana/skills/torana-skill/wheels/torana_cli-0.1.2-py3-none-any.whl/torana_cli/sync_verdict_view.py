"""Print an integration's sync `verdict` (I-11, I-47): WHY its health is what it is.

⛔ The server writes the words (pantheon-integration etl/sync_verdict.py and
extractors/github_permissions.py); this module PRINTS them, verbatim. It never composes,
shortens or re-derives a sentence, so the CLI, the FE and the API say the same thing.

Not colour-coded: a state a reader must not miss cannot depend on colour.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional


def verdict_lines(verdict: Optional[Dict[str, Any]], indent: str = "  ") -> List[str]:
    """`reason` / `Fix:` / `Who fixes it:` lines for one verdict, or [] when there is none."""
    if not verdict:
        return []
    out: List[str] = []
    if verdict.get("reason"):
        out.append(f"{indent}{verdict['reason']}")
    if verdict.get("fix"):
        out.append(f"{indent}Fix: {verdict['fix']}")
    if verdict.get("fix_owner"):
        out.append(f"{indent}Who fixes it: {verdict['fix_owner']}")
    missing = verdict.get("missing_permissions") or []
    if missing:
        out.append(f"{indent}Missing permissions: {', '.join(missing)}")
    return out


def integration_verdict_lines(item: Dict[str, Any], *, title: Optional[str] = None) -> List[str]:
    """The block for one integration payload: per data source, worst first.

    Falls back to the rollup `verdict` when no per-source list is present.
    """
    sources = item.get("sources") or []
    rollup = item.get("verdict")
    if not sources and not rollup:
        return []
    out: List[str] = [title] if title else []
    if sources:
        for s in sources:
            out.append(f"  ! {s.get('data_source')} ({s.get('status')})")
            out.extend(verdict_lines(s.get("verdict"), indent="      "))
    else:
        out.extend(verdict_lines(rollup, indent="  "))
    return out
