"""torana remediation <REMEDIATION_ID> — instance-scoped PR-lifecycle commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE
from torana_cli.output import output

# Lifecycle states the server accepts (mirrors RemediationState).
_STATES = [
    "opened", "checks_running", "checks_passed", "checks_failed",
    "review_pending", "approved", "merged", "deploying", "deployed_prod",
    "verified", "regressed", "abandoned",
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _rid(ctx) -> str:
    return ctx.obj.get("_remediation_id", "") if ctx.obj else ""


@click.group(name="remediation", invoke_without_command=True)
@click.argument("remediation_id", metavar="REMEDIATION_ID")
@click.pass_context
def remediation(ctx, remediation_id):
    """Manage a single PR-lifecycle remediation by ID.

    \b
    Examples:
      torana remediation <UUID> get
      torana remediation <UUID> link-pr --pr-url https://github.com/o/r/pull/1
      torana remediation <UUID> set-state --state merged
    """
    ctx.ensure_object(dict)
    ctx.obj["_remediation_id"] = remediation_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@remediation.command(name="get")
@click.pass_context
def remediation_get(ctx):
    """Get a remediation by ID."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get(f"remediations/{_rid(ctx)}")
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(data, fmt=fmt, fields=fields)


@remediation.command(name="link-pr")
@click.option("--pr-url", default=None, help="Pull request URL.")
@click.option("--pr-number", type=int, default=None, help="Pull request number.")
@click.option("--repo", default=None, help="Canonical asset key, e.g. github.com/org/repo.")
@click.option("--branch", default=None, help="PR head branch.")
@click.option("--base-branch", default=None, help="PR base branch.")
@click.option("--head-sha", default=None, help="PR head commit sha.")
@click.pass_context
def remediation_link_pr(ctx, pr_url, pr_number, repo, branch, base_branch, head_sha):
    """Attach / update PR identity on a remediation."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    body = {}
    for key, value in dict(
        pr_url=pr_url, pr_number=pr_number, repo=repo, branch=branch,
        base_branch=base_branch, head_sha=head_sha,
    ).items():
        if value is not None:
            body[key] = value
    client = _client(ctx)
    try:
        data = client.put(f"remediations/{_rid(ctx)}/pr", json=body)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(data, fmt=fmt)


@remediation.command(name="set-state")
@click.option("--state", required=True, type=click.Choice(_STATES),
              help="New lifecycle state (drives the alert's status).")
@click.option("--message", default=None, help="Note recorded on the alert activity.")
@click.option("--checks-status", default=None, type=click.Choice(["pending", "passed", "failed"]))
@click.option("--review-status", default=None,
              type=click.Choice(["pending", "approved", "changes_requested"]))
@click.option("--merged-sha", default=None, help="Merge commit sha (with --state merged).")
@click.option("--deploy-env", default=None, help="Deploy environment (with --state deployed_prod).")
@click.pass_context
def remediation_set_state(ctx, state, message, checks_status, review_status, merged_sha, deploy_env):
    """Advance the PR-lifecycle state; the server maps it onto the alert's status."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    body = {"state": state}
    for key, value in dict(
        message=message, checks_status=checks_status, review_status=review_status,
        merged_sha=merged_sha, deploy_env=deploy_env,
    ).items():
        if value is not None:
            body[key] = value
    client = _client(ctx)
    try:
        data = client.put(f"remediations/{_rid(ctx)}/state", json=body)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(data, fmt=fmt)


@remediation.command(name="impact")
@click.option("--compute", is_flag=True, default=False,
              help="Compute + store the Fix-Impact report (POST). Default fetches the stored one (GET).")
@click.option("--changed-pkgs", default=None,
              help="Comma-separated pkg: keys changed by the fix (with --compute).")
@click.option("--base-sha", default=None, help="Base commit sha (with --compute).")
@click.option("--head-sha", default=None, help="Head commit sha (with --compute).")
@click.option("--direction", default="both", type=click.Choice(["forward", "reverse", "both"]),
              help="Blast-radius traversal direction (with --compute).")
@click.option("--stage", default="triage", type=click.Choice(["triage", "pr"]),
              help="When the report was computed (with --compute).")
@click.option("--test-status", default=None,
              type=click.Choice(["covered", "generated", "uncovered", "no-suite"]),
              help="Test coverage verdict for the fix (T7, with --compute).")
@click.option("--test-evidence-file", default=None,
              help="Path to a JSON file with the differential test evidence (T7, with --compute).")
@click.option("--scan-delta-file", "scan_delta_file", default=None,
              help="Path to a JSON file with the scan delta — the vulnerabilities the fix "
                   "ADDS / REMOVES / leaves UNCHANGED (with --compute). The overall verdict "
                   "is derived from this input, so without it the report is `inconclusive`. "
                   "`torana scan` produces this file.")
@click.pass_context
def remediation_impact(ctx, compute, changed_pkgs, base_sha, head_sha, direction, stage,
                       test_status, test_evidence_file, scan_delta_file):
    """Fetch (default) or --compute the Fix-Impact blast-radius report for this remediation."""
    import json as _json
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        if compute:
            body = {"direction": direction, "stage": stage}
            if changed_pkgs:
                body["changed_pkgs"] = [p.strip() for p in changed_pkgs.split(",") if p.strip()]
            if base_sha:
                body["base_sha"] = base_sha
            if head_sha:
                body["head_sha"] = head_sha
            if test_status:
                body["test_status"] = test_status
            if test_evidence_file:
                try:
                    with open(test_evidence_file) as _tf:
                        body["test_evidence"] = _json.load(_tf)
                except (OSError, ValueError) as _e:
                    click.echo(f"ERROR: could not read --test-evidence-file: {_e}", err=True)
                    return
            if scan_delta_file:
                try:
                    with open(scan_delta_file) as _sf:
                        body["scan_delta"] = _json.load(_sf)
                except (OSError, ValueError) as _e:
                    click.echo(f"ERROR: could not read --scan-delta-file: {_e}", err=True)
                    return
            data = client.post(f"remediations/{_rid(ctx)}/impact", json=body)
        else:
            data = client.get(f"remediations/{_rid(ctx)}/impact")
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(data, fmt=fmt, fields=fields)
