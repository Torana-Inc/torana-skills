"""torana remediation <REMEDIATION_ID> — instance-scoped PR-lifecycle commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE
from torana_cli.output import output

# Lifecycle states the server accepts (mirrors RemediationState).
_STATES = [
    "opened", "checks_running", "checks_passed", "checks_failed",
    "review_pending", "approved", "merged", "deploying", "deployed_prod",
    "verified", "regressed", "abandoned",
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _rid(ctx) -> str:
    return ctx.obj.get("_remediation_id", "") if ctx.obj else ""


@click.group(name="remediation", invoke_without_command=True)
@click.argument("remediation_id", metavar="REMEDIATION_ID")
@click.pass_context
def remediation(ctx, remediation_id):
    """Manage a single PR-lifecycle remediation by ID.

    \b
    Examples:
      torana remediation <UUID> get
      torana remediation <UUID> ci get
      torana remediation <UUID> refresh
      torana remediation <UUID> link-pr --pr-url https://github.com/o/r/pull/1
      torana remediation <UUID> set-state --state merged
      torana remediation <UUID> set-state --state merged --merged-at 2026-10-22T02:10:06Z
    """
    ctx.ensure_object(dict)
    ctx.obj["_remediation_id"] = remediation_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@remediation.command(name="get")
@click.pass_context
def remediation_get(ctx):
    """Get a remediation by ID."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get(f"remediations/{_rid(ctx)}")
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(data, fmt=fmt, fields=fields)


@remediation.command(name="link-pr")
@click.option("--pr-url", default=None, help="Pull request URL.")
@click.option("--pr-number", type=int, default=None, help="Pull request number.")
@click.option("--repo", default=None, help="Canonical asset key, e.g. github.com/org/repo.")
@click.option("--branch", default=None, help="PR head branch.")
@click.option("--base-branch", default=None, help="PR base branch.")
@click.option("--head-sha", default=None, help="PR head commit sha.")
@click.pass_context
def remediation_link_pr(ctx, pr_url, pr_number, repo, branch, base_branch, head_sha):
    """Attach / update PR identity on a remediation."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    body = {}
    for key, value in dict(
        pr_url=pr_url, pr_number=pr_number, repo=repo, branch=branch,
        base_branch=base_branch, head_sha=head_sha,
    ).items():
        if value is not None:
            body[key] = value
    client = _client(ctx)
    try:
        data = client.put(f"remediations/{_rid(ctx)}/pr", json=body)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(data, fmt=fmt)


@remediation.command(name="set-state")
@click.option("--state", required=True, type=click.Choice(_STATES),
              help="New lifecycle state (drives the alert's status).")
@click.option("--message", default=None, help="Note recorded on the alert activity.")
@click.option("--checks-status", default=None, type=click.Choice(["pending", "passed", "failed"]))
@click.option("--review-status", default=None,
              type=click.Choice(["pending", "approved", "changes_requested"]))
@click.option("--merged-sha", default=None, help="Merge commit sha (with --state merged).")
@click.option("--merged-at", default=None, metavar="ISO8601",
              help="When the PROVIDER merged the PR, e.g. 2026-10-22T02:10:06Z (with --state "
                   "merged). Omit it and the server stamps the time it processed this call, "
                   "which is only an approximation. Pass it to correct a row whose merge time "
                   "is wrong: a settled row cannot be refreshed from GitHub, so this is the "
                   "only way to repair one.")
@click.option("--deploy-env", default=None, help="Deploy environment (with --state deployed_prod).")
@click.pass_context
def remediation_set_state(ctx, state, message, checks_status, review_status, merged_sha,
                          merged_at, deploy_env):
    """Advance the PR-lifecycle state; the server maps it onto the alert's status."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    body = {"state": state}
    for key, value in dict(
        message=message, checks_status=checks_status, review_status=review_status,
        merged_sha=merged_sha, merged_at=merged_at, deploy_env=deploy_env,
    ).items():
        if value is not None:
            body[key] = value
    client = _client(ctx)
    try:
        data = client.put(f"remediations/{_rid(ctx)}/state", json=body)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(data, fmt=fmt)


@remediation.command(name="impact")
@click.option("--compute", is_flag=True, default=False,
              help="Compute + store the Fix-Impact report (POST). Default fetches the stored one (GET).")
@click.option("--changed-pkgs", default=None,
              help="Comma-separated pkg: keys changed by the fix (with --compute).")
@click.option("--base-sha", default=None, help="Base commit sha (with --compute).")
@click.option("--head-sha", default=None, help="Head commit sha (with --compute).")
@click.option("--direction", default="both", type=click.Choice(["forward", "reverse", "both"]),
              help="Blast-radius traversal direction (with --compute).")
@click.option("--stage", default="triage", type=click.Choice(["triage", "pr"]),
              help="When the report was computed (with --compute).")
@click.option("--test-status", default=None,
              type=click.Choice(["covered", "generated", "uncovered", "no-suite"]),
              help="Test coverage verdict for the fix (T7, with --compute).")
@click.option("--test-evidence-file", default=None,
              help="Path to a JSON file with the differential test evidence (T7, with --compute).")
@click.option("--scan-delta-file", "scan_delta_file", default=None,
              help="Path to a JSON file with the scan delta — the vulnerabilities the fix "
                   "ADDS / REMOVES / leaves UNCHANGED (with --compute). The overall verdict "
                   "is derived from this input, so without it the report is `inconclusive`. "
                   "The torana-scan skill's upgrade delta produces this file (there is no "
                   "`torana scan` command).")
@click.pass_context
def remediation_impact(ctx, compute, changed_pkgs, base_sha, head_sha, direction, stage,
                       test_status, test_evidence_file, scan_delta_file):
    """Fetch (default) or --compute the Fix-Impact blast-radius report for this remediation."""
    import json as _json
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        if compute:
            body = {"direction": direction, "stage": stage}
            if changed_pkgs:
                body["changed_pkgs"] = [p.strip() for p in changed_pkgs.split(",") if p.strip()]
            if base_sha:
                body["base_sha"] = base_sha
            if head_sha:
                body["head_sha"] = head_sha
            if test_status:
                body["test_status"] = test_status
            if test_evidence_file:
                try:
                    with open(test_evidence_file) as _tf:
                        body["test_evidence"] = _json.load(_tf)
                except (OSError, ValueError) as _e:
                    click.echo(f"ERROR: could not read --test-evidence-file: {_e}", err=True)
                    return
            if scan_delta_file:
                try:
                    with open(scan_delta_file) as _sf:
                        body["scan_delta"] = _json.load(_sf)
                except (OSError, ValueError) as _e:
                    click.echo(f"ERROR: could not read --scan-delta-file: {_e}", err=True)
                    return
            data = client.post(f"remediations/{_rid(ctx)}/impact", json=body)
        else:
            data = client.get(f"remediations/{_rid(ctx)}/impact")
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(data, fmt=fmt, fields=fields)


@remediation.group(name="ci", invoke_without_command=True)
@click.pass_context
def remediation_ci(ctx):
    """The CI of this fix PR's current commit, as Torana last read it (EM D-05A).

    \b
    Examples:
      torana remediation <UUID> ci get
      torana remediation <UUID> ci get --format json
      torana remediation <UUID> ci ready
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@remediation_ci.command(name="get")
@click.pass_context
def remediation_ci_get(ctx):
    """Print the fix PR's stored CI read: the answer, then each failed or pending check.

    Read-only (needs alert:read): it never asks GitHub. `torana remediation <ID> refresh` asks (alert:update).
    The answer is the platform's words; failed checks show the step and the first error when GitHub gave them.
    On a plan's PR every member resolves to the same read.

    \b
    Examples:
      torana remediation 3394465e-2477-4bdf-8a42-20a18a83432e ci get
      torana remediation 3394465e-2477-4bdf-8a42-20a18a83432e ci get --format json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get(f"remediations/{_rid(ctx)}/ci")
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    if fmt == "text" and not fields:
        from torana_cli.fix_pr_ci_view import print_fix_pr_ci
        print_fix_pr_ci(data)
        return
    output(data, fmt=fmt, fields=fields)


@remediation_ci.command(name="ready")
@click.option("--retry", is_flag=True, help="Re-read CI now and re-decide (the same as `refresh`; needs alert:update).")
@click.pass_context
def remediation_ci_ready(ctx, retry):
    """Whether Torana marks this fix PR ready for review, and why not yet (EM D-23).

    Every fix PR opens as a DRAFT. Torana's GitHub App marks it ready when CI passed on the commit Torana verified
    AND the plan's review approved it. Otherwise it stays a draft, and Torana's check run on the PR says why. Prints
    the decision (`READY …`), one line per blocker and the flip's state. There is no "flip now" command: the flip is
    automatic. When the App may not flip in this repository, mark it ready yourself with `gh pr ready <n>`.

    \b
    Examples:
      torana remediation 3394465e-2477-4bdf-8a42-20a18a83432e ci ready
      torana remediation 3394465e-2477-4bdf-8a42-20a18a83432e ci ready --retry
      torana remediation 3394465e-2477-4bdf-8a42-20a18a83432e ci ready --format json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        if retry:
            data = (client.post(f"remediations/{_rid(ctx)}/refresh", json={}) or {}).get("ci") or {}
        else:
            data = client.get(f"remediations/{_rid(ctx)}/ci") or {}
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    ready = data.get("ready") if isinstance(data, dict) else None
    if fmt == "text" and not fields:
        from torana_cli.fix_pr_ci_view import ready_lines
        lines = ready_lines(ready)
        if not lines:
            click.echo("READY  not decided yet: Torana has not read this PR's CI since the ready rule shipped. "
                       "Run with --retry.")
            return
        for line in lines:
            click.echo(line)
        return
    output(ready or {}, fmt=fmt, fields=fields)


@remediation.command(name="refresh")
@click.pass_context
def remediation_refresh(ctx):
    """Ask GitHub what this PR's state and CI really are, and apply the answer.

    Torana learns a PR's fate from one webhook delivery, and GitHub Apps do not auto-redeliver a
    failed one. When a delivery is lost the row keeps whatever state it last had -- and every
    surface reports that as current. This asks.

    \b
    It only ever moves the row to a state GitHub STATED. A read that failed, timed out or found
    nothing records the reason and leaves the row alone: an unreadable PR is not a closed PR.
    `reconciled: false` means GitHub could not be asked; `changed: false` means it was asked and
    the row was already right.

    \b
    When the PR is still open it also reads its CI in the same call (`ci`): the text output prints
    `ci.answer.words` first, then the failing checks. Needs alert:update; a read-only user uses
    `torana remediation <ID> ci get`.

    \b
    Examples:
      torana remediation 3394465e-2477-4bdf-8a42-20a18a83432e refresh
      torana remediation 3394465e-2477-4bdf-8a42-20a18a83432e refresh --format json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.post(f"remediations/{_rid(ctx)}/refresh", json={})
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    if fmt == "text" and not fields and isinstance(data, dict) and data.get("ci"):
        from torana_cli.fix_pr_ci_view import print_fix_pr_ci
        print_fix_pr_ci(data["ci"])
        click.echo(f"PR state: {data.get('reason')}")
        return
    output(data, fmt=fmt, fields=fields)

