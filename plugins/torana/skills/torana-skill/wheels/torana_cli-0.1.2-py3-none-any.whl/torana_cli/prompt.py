"""torana prompt <ID> — agent prompt INSTANCE commands.

Instance operations that target a single prompt by ID. The prompt ID binds to
the ``prompt`` group; verbs follow it (``torana prompt <ID> get``). Collection
operations (list/create/...) live in the plural ``prompts`` group in
torana_cli/prompts.py.
"""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _pid(ctx) -> str:
    return ctx.obj.get("_prompt_id", "") if ctx.obj else ""


@click.group(name="prompt", invoke_without_command=True)
@click.argument("prompt_id", metavar="PROMPT_ID")
@click.pass_context
def prompt(ctx, prompt_id):
    """Operate on a single prompt by ID.

    \b
    Examples:
      torana prompt <UUID> get
      torana prompt <UUID> update --file prompt.yaml
      torana prompt <UUID> reload-from-source
      torana prompt <UUID> clone --new-name "Copy"
      torana prompt <UUID> delete --yes
    """
    ctx.ensure_object(dict)
    ctx.obj["_prompt_id"] = prompt_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@prompt.command(name="get")
@click.pass_context
def prompt_get(ctx):
    """Get a specific prompt."""
    prompt_id = _pid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"prompts/{prompt_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@prompt.command(name="update")
@click.option("--name", default=None)
@click.option("--content", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def prompt_update(ctx, name, content, input_file):
    """Update a prompt."""
    prompt_id = _pid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if content:
        body["content"] = content

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"prompts/{prompt_id}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated prompt: {prompt_id}")


@prompt.command(name="delete")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def prompt_delete(ctx, yes):
    """Delete a prompt."""
    prompt_id = _pid(ctx)
    _confirm(f"Delete prompt {prompt_id}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"prompts/{prompt_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted prompt: {prompt_id}")


@prompt.command(name="clone")
@click.option("--new-name", "new_name", required=True, help="Name for the cloned prompt")
@click.option("--new-description", "new_description", default=None, help="Description for the cloned prompt")
@click.pass_context
def prompt_clone(ctx, new_name, new_description):
    """Clone this prompt."""
    prompt_id = _pid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"prompts/{prompt_id}/clone"
    body = {"new_name": new_name}
    if new_description is not None:
        body["new_description"] = new_description

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@prompt.command(name="usage")
@click.option("--increment-usage", "increment_usage", type=bool, default=True)
@click.option("--update-last-used", "update_last_used", type=bool, default=True)
@click.pass_context
def prompt_usage(ctx, increment_usage, update_last_used):
    """Update this prompt's usage counters."""
    prompt_id = _pid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"prompts/{prompt_id}/usage"
    body = {}
    if increment_usage is not None:
        body["increment_usage"] = increment_usage
    if update_last_used is not None:
        body["update_last_used"] = update_last_used

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@prompt.command(name="associate-agent")
@click.argument("AGENT_ID", metavar="AGENT_ID")
@click.option("--usage-type", "usage_type", default=None, help="How the prompt is used in the agent")
@click.pass_context
def prompt_associate_agent(ctx, agent_id, usage_type):
    """Associate this prompt with an agent."""
    prompt_id = _pid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"prompts/{prompt_id}/associate-agent/{agent_id}"
    params = {}
    if usage_type is not None:
        params["usage_type"] = usage_type

    client = _client(ctx)
    try:
        data = client.post(path, json={}, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@prompt.command(name="reload-from-source")
@click.pass_context
def prompt_reload_from_source(ctx):
    """Reload this prompt from its source file."""
    prompt_id = _pid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"prompts/{prompt_id}/reload-from-source"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@prompt.command(name="agents")
@click.pass_context
def prompt_agents(ctx):
    """List agents that refer to this prompt."""
    prompt_id = _pid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"prompts/{prompt_id}/agents"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@prompt.command(name="drift")
@click.pass_context
def prompt_drift(ctx):
    """Show this prompt's drift vs its source file."""
    prompt_id = _pid(ctx)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"prompts/{prompt_id}/drift"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)
