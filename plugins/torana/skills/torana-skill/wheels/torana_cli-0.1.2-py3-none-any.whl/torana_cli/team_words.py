"""The owning teams of an Inbox item in words, from the platform's `owning_teams` and `members_without_team` (the CLI counts nothing itself).

A member with no team is said as "no team recorded", never left out and never given a team.
"""
from __future__ import annotations

NO_TEAM = "no team recorded"


def _parts(item, with_counts: bool):
    teams = item.get("owning_teams")
    if not isinstance(teams, list):
        return None
    out = []
    for t in teams:
        if not isinstance(t, dict) or not t.get("team"):
            continue
        n = t.get("members")
        out.append(f"{t['team']} ({n})" if with_counts and n is not None and (len(teams) > 1 or item.get("members_without_team")) else str(t["team"]))
    none = item.get("members_without_team") or 0
    if none:
        out.append(f"{NO_TEAM} ({none})" if with_counts and out else NO_TEAM)
    return out


def team_words(item) -> str:
    """"Team: backend-dev (12), genai-team (3), no team recorded (2)" for the item view; empty when the platform did not send the field."""
    parts = _parts(item or {}, True)
    if parts is None:
        return ""
    return "Team: " + (", ".join(parts) if parts else NO_TEAM)


def team_cell(item, empty="—") -> str:
    """The list column: the team names, "no team recorded" for members without one, `empty` when the platform sent nothing."""
    parts = _parts(item or {}, False)
    return ", ".join(parts) if parts else (empty if parts is None else NO_TEAM)
