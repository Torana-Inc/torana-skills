"""torana workspace-template <ID> — workspace template instance commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FORMAT, CTX_PROFILE
from torana_cli.output import output


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(name="workspace-template", invoke_without_command=True)
@click.argument("template_id", metavar="TEMPLATE_ID")
@click.pass_context
def workspace_template(ctx, template_id):
    """Operate on a single workspace template.

    \b
    Examples:
      torana workspace-template <TEMPLATE_ID> get
    """
    ctx.ensure_object(dict)
    ctx.obj["_template_id"] = template_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _tid(ctx) -> str:
    return ctx.obj.get("_template_id", "") if ctx.obj else ""


@workspace_template.command(name="get")
@click.pass_context
def workspace_template_get(ctx):
    """Get a workspace template by ID.

    \b
    Examples:
      torana workspace-template <TEMPLATE_ID> get
      torana workspace-template <TEMPLATE_ID> get --json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(f"workspace-templates/{_tid(ctx)}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)
