"""torana completion — shell completion script generation.

Click provides built-in shell completion for bash, zsh, and fish via
environment variables. This command generates the activation snippet
the user needs to add to their shell profile.

Usage:
    # One-time setup
    torana completion bash >> ~/.bashrc
    torana completion zsh  >> ~/.zshrc
    torana completion fish > ~/.config/fish/completions/torana.fish

    # Or evaluate directly
    eval "$(torana completion bash)"
    eval "$(torana completion zsh)"
"""

import click


_BASH_SCRIPT = """\
# Torana CLI bash completion
# Add this to ~/.bashrc or ~/.bash_profile:
#   eval "$(torana completion bash)"
_TORANA_COMPLETE=bash_source torana
"""

_ZSH_SCRIPT = """\
# Torana CLI zsh completion
# Add this to ~/.zshrc:
#   eval "$(torana completion zsh)"
_TORANA_COMPLETE=zsh_source torana
"""

_FISH_SCRIPT = """\
# Torana CLI fish completion
# Save to ~/.config/fish/completions/torana.fish:
#   torana completion fish > ~/.config/fish/completions/torana.fish
_TORANA_COMPLETE=fish_source torana
"""

_SETUP_INSTRUCTIONS = {
    "bash": """\
# Add the following line to ~/.bashrc or ~/.bash_profile:
eval "$(torana completion bash)"

# Or add the script directly:
torana completion bash >> ~/.bashrc
source ~/.bashrc
""",
    "zsh": """\
# Add the following line to ~/.zshrc:
eval "$(torana completion zsh)"

# Or add the script directly:
torana completion zsh >> ~/.zshrc
source ~/.zshrc
""",
    "fish": """\
# Save the completion script to fish completions directory:
torana completion fish > ~/.config/fish/completions/torana.fish
""",
}


@click.command(name="completion")
@click.argument(
    "shell",
    metavar="SHELL",
    type=click.Choice(["bash", "zsh", "fish"], case_sensitive=False),
)
@click.option(
    "--instructions",
    is_flag=True,
    default=False,
    help="Print setup instructions instead of the completion script.",
)
def completion(shell, instructions):
    """Generate shell completion script for bash, zsh, or fish.

    Outputs the completion activation script to stdout. Pipe it to your
    shell profile or evaluate it directly.

    \b
    Quick setup:
      eval "$(torana completion bash)"    # bash
      eval "$(torana completion zsh)"     # zsh
      torana completion fish > ~/.config/fish/completions/torana.fish

    \b
    Persistent setup (add to shell profile):
      torana completion bash >> ~/.bashrc
      torana completion zsh  >> ~/.zshrc
      torana completion fish > ~/.config/fish/completions/torana.fish

    \b
    View setup instructions:
      torana completion bash --instructions
    """
    shell = shell.lower()

    if instructions:
        click.echo(_SETUP_INSTRUCTIONS[shell], nl=False)
        return

    # Emit the Click _COMPLETE env-var invocation that generates the actual
    # completion script when the user evaluates it in their shell.
    if shell == "bash":
        click.echo(_BASH_SCRIPT, nl=False)
    elif shell == "zsh":
        click.echo(_ZSH_SCRIPT, nl=False)
    elif shell == "fish":
        click.echo(_FISH_SCRIPT, nl=False)
