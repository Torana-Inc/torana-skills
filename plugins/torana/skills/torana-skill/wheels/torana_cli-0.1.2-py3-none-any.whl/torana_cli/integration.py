"""torana integration — per-integration instance commands."""

import sys

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.webhooks import list_webhook_deliveries_core
from torana_cli.confirm import confirm as _confirm


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(name="integration", invoke_without_command=True)
@click.argument("integration_id", metavar="INTEGRATION_ID")
@click.pass_context
def integration(ctx, integration_id):
    """Per-integration instance commands.

    \b
    Examples:
      torana integration <UUID> get
      torana integration <UUID> activate
      torana integration <UUID> health
      torana integration <UUID> enable <DATA_SOURCE_NAME>
    """
    ctx.ensure_object(dict)
    ctx.obj["_integration_id"] = integration_id
    # Bare `torana integration <id>` → show help (don't error on missing command).
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _iid(ctx) -> str:
    return ctx.obj.get("_integration_id", "") if ctx.obj else ""


def selection_lines(data, integration_id: str) -> list:
    """Lines about the data-source SELECTION, and separately about what the scheduler holds.

    ``data_source_selection`` (from the platform) says which syncable sources the selection
    leaves out. That is ALL it says: it never implies anything is scheduled. A scheduling
    claim comes only from the scheduler's own fields (``schedules[].scheduled``,
    ``unscheduled_data_sources``); an older platform that sends no selection is reported as
    not available, never as "none".
    """
    sel = (data or {}).get("data_source_selection")
    if not isinstance(sel, dict):
        return ["", "Data sources left out of the selection: not available (the platform did not report it)"]
    left_out = sel.get("not_selected") or []
    if not left_out:
        lines = ["", "Data sources left out of the selection: none"]
    else:
        who = sel.get("narrowed_last_updated_by") or "unknown"
        when = sel.get("narrowed_last_updated_at") or "unknown"
        lines = [
            "",
            f"⚠ Left out of this integration's stored selection (not synced): {', '.join(left_out)}",
            f"  Row last updated by {who} at {when}.",
            f"  To sync every source, now and future: torana integration {integration_id} patch "
            f"--enabled-data-sources <all syncable names>  (a full list is stored as 'all').",
        ]
    # Selected but the scheduler holds no job: said only when the scheduler itself says so.
    unscheduled = sorted({str(r.get("data_source")) for r in ((data or {}).get("schedules") or [])
                          if isinstance(r, dict) and r.get("scheduled") is False
                          and r.get("data_source") not in left_out})
    if unscheduled:
        lines.append(f"⚠ {len(unscheduled)} data source(s) selected but the scheduler holds no job for them: "
                     f"{', '.join(unscheduled)}.")
        lines.append("  If the selection changed recently, restarting integration reloads the scheduler's jobs.")
    return lines


@integration.command(name="get")
@click.pass_context
def integration_get(ctx):
    """Get a specific integration.

    \b
    Examples:
      torana integrations list                 # find the id
      torana integration <INTEGRATION_ID> get
      torana integration <INTEGRATION_ID> get --json | jq '{name, state, provider}'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"/api/v1/integrations/{_iid(ctx)}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)
    if fmt == "text" and not fields:
        for line in selection_lines(data, _iid(ctx)):
            click.echo(line)
    # SAST § 3.4.7: whether triage may read code around flagged lines. GitHub only (the platform sends null otherwise).
    state = (data or {}).get("code_context_enabled")
    if fmt == "text" and not fields and state is not None:
        click.echo(f"\nCode reading by triage: {'on' if state else 'off'}  "
                   f"(change with: torana integration {_iid(ctx)} patch --code-context on|off)")


@integration.command(name="scope")
@click.pass_context
def integration_scope(ctx):
    """What this integration is SCOPED to read — and what that leaves dormant.

    For GCP: every project read, the organization, the billing project, and any data
    source that collects NOTHING under the current config.

    \b
    Why this exists: a GCP integration with no Organization ID silently collects nothing
    from Cloud Asset Inventory and Security Command Center — both are org-scoped — while
    the sync still reports success. This is where that becomes visible.

    \b
    Examples:
      torana integration <INTEGRATION_ID> scope
      torana integration <INTEGRATION_ID> scope --json | jq '.dormant_data_sources'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.get(f"/api/v1/integrations/{_iid(ctx)}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    scope = (data or {}).get("scope")
    if fmt == "json":
        output(scope, fmt=fmt)
        return
    # ⛔ "No project list" is not "no projects". Every provider's payload carries a `scope`
    # (GitHub's holds only `applicable_fields`); only a project-scoped provider carries
    # `project_ids`. Reading a missing key as zero printed "misconfigured; at least one is
    # required" for every healthy GitHub integration.
    if not scope or "project_ids" not in scope:
        click.echo(f"No per-project read scope for provider {(data or {}).get('provider') or '?'} "
                   f"— its sources are chosen by the integration's selection alone.")
        for line in selection_lines(data, _iid(ctx)):
            click.echo(line)
        return

    projects = scope.get("project_ids") or []
    # ⛔ R8 PARITY with the Settings tab (§ 3.9d/§ 3.9e): per-project data-source
    # SELECTION. Without it the CLI shows which projects are read but not WHAT is read
    # from each, so an operator cannot see that a project was deliberately narrowed —
    # which then looks identical to a project that silently collected nothing.
    per_project = scope.get("scope_data_sources") or {}
    syncable = scope.get("syncable_data_sources") or []
    click.echo(f"PROJECTS ({len(projects)})")
    for pid in projects:
        billing = "  <- billing" if pid == scope.get("quota_project_id") else ""
        click.echo(f"  {pid}{billing}")
        # ⚠️ ABSENT and EMPTY are DIFFERENT configs and must read differently:
        #   absent -> "all N"        (the default; nothing was narrowed)
        #   []     -> "NOTHING"      (a deliberate choice to park this project)
        # Collapsing them would report a parked project as fully collecting.
        if pid not in per_project:
            click.echo(f"      data sources: all{f' ({len(syncable)})' if syncable else ''}"
                       f"  (no per-project selection set)")
        else:
            sel = per_project.get(pid) or []
            if not sel:
                click.echo("      data sources: NONE — nothing is collected from this project")
            else:
                click.echo(f"      data sources: {len(sel)} selected — {', '.join(sorted(sel))}")
    if not projects:
        click.echo("  (none — the integration is misconfigured; at least one is required)")
    click.echo(f"ORG              {scope.get('org_id') or '(not set)'}")
    click.echo(f"BILLING PROJECT  {scope.get('quota_project_id') or '(not set)'}")

    dormant = scope.get("dormant_data_sources") or []
    if dormant:
        # NOT colour-coded: a state a reader must not miss cannot depend on colour.
        click.echo(f"\nDORMANT DATA SOURCES ({len(dormant)}) — these collect NOTHING:")
        for d in dormant:
            click.echo(f"  ! {d.get('name')}: {d.get('reason')}")
    else:
        click.echo("\nDORMANT DATA SOURCES  none — every source can collect")


@integration.command(name="gcp-projects")
@click.option("--add", "add_ids", multiple=True, metavar="PROJECT_ID",
              help="Append project id(s) to the integration's read scope. Repeatable.")
@click.pass_context
def integration_gcp_projects(ctx, add_ids):
    """Discover GCP projects this integration's credential can see (GCP only).

    Read-only by default. `--add` appends to `project_ids`.

    \b
    ⚠️ Adding a project does NOT backfill its history: ETL cursors are keyed per
    (integration, data_source) with no project dimension, so the next incremental sync
    asks the new project only for changes since a watermark it never contributed to.
    Run a full resync after adding one.

    \b
    Examples:
      torana integration <INTEGRATION_ID> gcp-projects
      torana integration <INTEGRATION_ID> gcp-projects --add prod-app --add shared-registry
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    iid = _iid(ctx)

    try:
        found = client.get(f"/api/v1/integrations/{iid}/gcp/projects")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if not add_ids:
        if fmt == "json":
            output(found, fmt=fmt)
            return
        if not (found or {}).get("credential_can_list"):
            click.echo("This credential cannot list projects "
                       "(needs resourcemanager.projects.list). Enter project ids manually.")
            return
        rows = (found or {}).get("projects") or []
        click.echo(f"PROJECTS VISIBLE TO THIS CREDENTIAL ({len(rows)})")
        for r in rows:
            mark = "*" if r.get("in_scope") else " "
            click.echo(f" {mark} {r.get('project_id'):32} {r.get('name') or ''}")
        if (found or {}).get("truncated"):
            click.echo("\n(list truncated — type an id directly if yours is not shown)")
        click.echo("\n* = already in this integration's read scope")
        return

    # --add: READ-MODIFY-WRITE. Re-read immediately before the write so a concurrent
    # edit is visible in the result rather than silently lost.
    try:
        current = client.get(f"/api/v1/integrations/{iid}/")
        cfg = dict((current or {}).get("config") or {})
        existing = list(cfg.get("project_ids") or
                        ([cfg["project_id"]] if cfg.get("project_id") else []))
        merged = list(existing)
        for pid in add_ids:
            if pid not in merged:
                merged.append(pid)
        cfg["project_ids"] = merged
        # ⛔ The update endpoint REPLACES config wholesale (no merge), so the WHOLE
        # config object goes back — sending only project_ids would wipe the rest.
        client.put(f"/api/v1/integrations/{iid}/", json={"config": cfg})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"READ SCOPE NOW ({len(merged)} project(s)):")
    for pid in merged:
        click.echo(f"  {pid}")
    click.echo("\n! New projects need a FULL RESYNC to backfill their history "
               "(cursors carry no project dimension). Existing data is unaffected.")


@integration.command(name="update")
@click.option("--name", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def integration_update(ctx, name, input_file):
    """Update an integration."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"/api/v1/integrations/{_iid(ctx)}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated integration: {_iid(ctx)}")


@integration.command(name="delete")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def integration_delete(ctx, yes):
    """Delete an integration and everything it brought in.

    \b
    ASYNCHRONOUS. The integration disappears from every list immediately, but its
    datalake rows, graph nodes and edges are removed by a background job that takes
    roughly 20-40s. Follow it with:
      torana integration <UUID> cleanup-status
    """
    _confirm(f"Delete integration {_iid(ctx)} AND all the data it contributed?", yes=yes)
    client = _client(ctx)
    try:
        data = client.delete(f"/api/v1/integrations/{_iid(ctx)}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    if fmt != "text":
        output(data, fmt=fmt)
        return

    click.echo(f"Deleted integration: {_iid(ctx)}")
    state = (data or {}).get("purge_state") if isinstance(data, dict) else None
    if state:
        click.echo(f"  Data cleanup queued (state: {state}) — runs in the background.")
        click.echo(f"  Check it: torana integration {_iid(ctx)} cleanup-status")


# ── deletion cleanup (INTEGRATION_DELETE_CLEANUP_TODO.md § 3.5) ───────────────

def _render_cleanup(row: dict) -> None:
    """One integration's cleanup state, as a short block."""
    state = row.get("purge_state") or "unknown"
    click.echo("")
    click.echo(f"  {row.get('name') or '(unnamed)'}  [{row.get('integration_id')}]")
    click.echo(f"    state        {state}")
    if row.get("purge_attempts"):
        click.echo(f"    attempts     {row['purge_attempts']} of {row.get('max_attempts', '?')}")
    if row.get("purge_completed_at"):
        click.echo(f"    completed    {row['purge_completed_at']}")
    if row.get("purge_last_error"):
        click.echo(f"    last error   {row['purge_last_error']}")
    # State is the ONLY cue here — never a colour alone (some readers cannot rely on it).
    if state == "failed":
        click.echo("    ⚠ Cleanup FAILED. The data is still present and the tombstone is kept.")
        click.echo(f"    Retry: torana integration {row.get('integration_id')} cleanup")
    elif state in ("pending", "purging"):
        click.echo("    Cleanup is queued/running; the record disappears once its data is gone.")
    click.echo("")


@integration.command(name="cleanup-status")
@click.pass_context
def integration_cleanup_status(ctx):
    """Show the data-cleanup state of a deleted integration.

    \b
    A 404 here is the SUCCESS case for a deleted integration: the record is removed
    only after its data has actually gone.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.get(f"/api/v1/integrations/{_iid(ctx)}/cleanup-status")
    except APIError as e:
        if getattr(e, "status_code", None) == 404:
            click.echo(f"No cleanup pending for {_iid(ctx)}.")
            click.echo("  If you deleted it, this means cleanup COMPLETED and its data is gone.")
            return
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
        return
    _render_cleanup(data or {})


@integration.command(name="cleanup")
@click.option("--wait", is_flag=True, default=False,
              help="Poll until the cleanup finishes. NOTE: cleanup is queued per TENANT, "
                   "so this can also wait behind unrelated work for the same tenant.")
@click.option("--timeout", default=300, show_default=True, type=int,
              help="With --wait: stop watching after this many seconds. The cleanup is "
                   "NOT cancelled — only the waiting stops.")
@click.option("--poll-interval", default=5.0, show_default=True, type=float,
              help="Seconds between polls when --wait is set.")
@click.pass_context
def integration_cleanup(ctx, wait, timeout, poll_interval):
    """Queue (or re-queue) removal of a deleted integration's data.

    \b
    Safe to re-run. Use it to retry a cleanup that failed, or to clean up an
    integration that was deleted before this feature existed (its data is still
    there, and nothing else will ever remove it).
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.post(f"/api/v1/integrations/{_iid(ctx)}/cleanup")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
        return

    click.echo((data or {}).get("message") or "Cleanup queued.")

    if not wait:
        return

    # ⛔ POLL THE ROW'S OWN purge_state, NEVER the tenant's drain state. The dirty flag
    # is per TENANT: if that tenant is ALREADY draining when this lands, the newly
    # queued row is not part of that claim and is only picked up on the NEXT cycle —
    # so watching the drain state would look like a hang right after a successful
    # trigger.
    import time as _time
    deadline = _time.monotonic() + max(1, int(timeout))
    click.echo("Waiting for cleanup to finish…", err=True)
    while _time.monotonic() < deadline:
        _time.sleep(max(1.0, float(poll_interval)))
        try:
            row = client.get(f"/api/v1/integrations/{_iid(ctx)}/cleanup-status")
        except APIError as e:
            if getattr(e, "status_code", None) == 404:
                # The record is gone — which is exactly what success looks like.
                click.echo("Cleanup complete: the integration's data has been removed.")
                return
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return
        state = (row or {}).get("purge_state")
        if state == "failed":
            _render_cleanup(row or {})
            raise SystemExit(1)
        click.echo(f"  … {state}", err=True)

    click.echo(f"Still running after {timeout}s — the CLI stopped watching; the cleanup "
               f"has NOT been cancelled.", err=True)
    click.echo(f"  Check later: torana integration {_iid(ctx)} cleanup-status", err=True)
    raise SystemExit(2)


@integration.command(name="test-auth")
@click.pass_context
def integration_test_auth(ctx):
    """Re-test authentication NOW and refresh the stored auth_success flag.

    \b
    Use this after an EXTERNAL access problem is fixed — a cloud IAM grant lands, a
    token is re-issued, a firewall opens. Nothing re-evaluates `auth_success` on its
    own: there is no background job, and the ETL sync never touches the field. So a
    fixed integration keeps reporting `AUTH SUCCESS False` until you run this.

    \b
    Changes ONLY auth_success (+ connection status/timestamp). It never touches the
    config, the status, or is_active — so it is safe to run at any time. Unlike
    `activate`, it reports a FAILING verdict instead of refusing with a 400.

    \b
    Examples:
      torana integration <UUID> test-auth
      torana integration <UUID> test-auth --json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"/api/v1/integrations/{_iid(ctx)}/test-auth/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
        return

    ok = bool(data.get("auth_success"))
    # Status is spelled out in WORDS as well as marked, never colour alone.
    click.echo(f"Authentication: {'PASS' if ok else 'FAIL'}  [{'OK' if ok else 'X'}]")
    if data.get("message"):
        click.echo(f"  {data['message']}")
    click.echo(f"  auth_success is now: {ok}")
    if not ok:
        click.echo("")
        click.echo("  The stored flag has been refreshed to reflect this failure.")
        click.echo("  Fix the underlying access, then run this command again.")
        raise SystemExit(1)


@integration.command(name="activate")
@click.pass_context
def integration_activate(ctx):
    """Activate an integration."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"/api/v1/integrations/{_iid(ctx)}/activate/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Activated integration: {_iid(ctx)}")


@integration.command(name="install-webhook")
@click.pass_context
def integration_install_webhook(ctx):
    """Install the Torana GitLab MR-remediation webhook on this integration's group.

    Creates a group webhook on GitLab server-side (using the integration's PAT) so
    merge-request lifecycle events drive the alert's remediation status. Requires the
    PAT to have api scope + Owner/Maintainer on the group. GitLab integrations only.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"/api/v1/integrations/gitlab/webhook/install?integration_id={_iid(ctx)}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        wid = data.get("webhook_id") if isinstance(data, dict) else None
        suffix = f" (hook id {wid})" if wid else ""
        click.echo(f"Installed Torana GitLab webhook on integration {_iid(ctx)}{suffix}")


@integration.group(name="webhook-deliveries", invoke_without_command=True)
@click.pass_context
def integration_webhook_deliveries(ctx):
    """Inbound webhook deliveries for this integration. Use `list` to list them."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@integration_webhook_deliveries.command(name="list")
@click.option("--outcome", default=None,
              help="Filter by outcome (created|set_state|no_match|ignored|unmapped|rejected|error).")
@click.option("--since-hours", type=int, default=None, help="Only deliveries in the last N hours.")
@click.option("--page", type=int, default=1)
@click.option("--page-size", type=int, default=50)
@click.pass_context
def integration_webhook_deliveries_list(ctx, outcome, since_hours, page, page_size):
    """List inbound webhook deliveries for this integration."""
    list_webhook_deliveries_core(ctx, integration_id=_iid(ctx), outcome=outcome,
                                 since_hours=since_hours, page=page, page_size=page_size)


@integration.command(name="uninstall-webhook")
@click.pass_context
def integration_uninstall_webhook(ctx):
    """Remove the Torana GitLab webhook from this integration's group."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.delete(f"/api/v1/integrations/gitlab/webhook/uninstall?integration_id={_iid(ctx)}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Removed Torana GitLab webhook from integration {_iid(ctx)}")


@integration.command(name="deactivate")
@click.pass_context
def integration_deactivate(ctx):
    """Deactivate an integration."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"/api/v1/integrations/{_iid(ctx)}/deactivate/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Deactivated integration: {_iid(ctx)}")


@integration.command(name="patch")
@click.option("--file", "input_file", default=None, metavar="FILE",
              help="JSON/YAML file with patch body.")
@click.option("--paused", default=None, type=bool, help="Pause or resume ETL scheduling.")
@click.option("--enabled-data-sources", "enabled_data_sources", multiple=True,
              metavar="NAME[,NAME...]",
              help="Replace the data-source selection (comma-separated and/or repeated). "
                   "A non-empty subset of the provider's syncable sources; the scheduler "
                   "drops deselected sources and run-now refuses them (409).")
@click.option("--code-context", "code_context", default=None, type=click.Choice(["on", "off"], case_sensitive=False),
              help="GitHub integrations: whether the triage agent may read the code around a finding's flagged lines "
                   "(the function and its same-file callers, at the scanned commit; nothing is kept). On by default; "
                   "off stops all reads through this integration. Changes this one setting and nothing else.")
@click.pass_context
def integration_patch(ctx, input_file, paused, enabled_data_sources, code_context):
    """Update integration sync controls (pause/resume, data sources, code reading).

    \b
    Example:
      torana integration <UUID> patch --paused true
      torana integration <UUID> patch --enabled-data-sources repositories,users
      torana integration <UUID> patch --code-context off     # triage no longer reads code through this integration
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if paused is not None:
        # ⛔ The API field is `status` (active|paused). This used to send `paused`,
        # which the endpoint ignores, so every `--paused` call failed with HTTP 400
        # "No updatable fields provided".
        body["status"] = "paused" if paused else "active"
    if enabled_data_sources:
        from torana_cli.integrations import _split_sources
        body["enabled_data_sources"] = _split_sources(enabled_data_sources)
    if code_context:
        body["code_context_enabled"] = code_context.lower() == "on"

    if not body:
        click.echo("ERROR: Provide --file or at least one option to patch.", err=True)
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.patch(f"/api/v1/integrations/{_iid(ctx)}", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Patched integration: {_iid(ctx)}")
        if isinstance((data or {}).get("code_context_enabled"), bool):
            click.echo(f"Code reading by triage: {'on' if data['code_context_enabled'] else 'off'}")


def _sa_scheduling(ctx, action: str) -> None:
    """POST admin/etl/ops/<id>/<action> (pause|resume) and report the new state."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.post(f"admin/etl/ops/{_iid(ctx)}/{action}", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt != "text":
        output(data, fmt=fmt)
    else:
        paused = data.get("paused") if isinstance(data, dict) else None
        state = "paused (is_enabled=false)" if paused else "scheduled (is_enabled=true)"
        click.echo(f"Integration {_iid(ctx)}: ETL scheduling {state}")


@integration.command(name="resume")
@click.pass_context
def integration_resume(ctx):
    """SA only: turn ETL scheduling back ON for this integration (is_enabled=true).

    The scheduler leader reloads its jobs straight away, so the integration's data
    sources are scheduled again with no service restart.

    ⚠️ Not the same switch as `patch --paused`, which sets the tenant-facing `status`
    (active|paused). An integration stored with is_enabled=false reads NOT SCHEDULED and
    is invisible to tenant reachability whatever its status says. This command fixes
    that state.

    \b
    Examples:
      TORANA_PROFILE=SA torana integration <UUID> resume
    """
    _sa_scheduling(ctx, "resume")


@integration.command(name="pause")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def integration_pause(ctx, yes):
    """SA only: turn ETL scheduling OFF for this integration (is_enabled=false).

    The scheduler leader drops the integration's jobs straight away. Undo with `resume`.
    Asks first; --yes skips the prompt.

    \b
    Examples:
      TORANA_PROFILE=SA torana integration <UUID> pause
      TORANA_PROFILE=SA torana integration <UUID> pause --yes
    """
    _confirm(f"Stop ETL scheduling for integration {_iid(ctx)}?", yes=yes)
    _sa_scheduling(ctx, "pause")


@integration.command(name="health")
@click.pass_context
def integration_health(ctx):
    """Check integration health."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(f"/api/v1/integrations/{_iid(ctx)}/health/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        if isinstance(data, dict):
            status = data.get("status", data.get("health", "unknown"))
            click.echo(f"Integration {_iid(ctx)}: {status}")
            for k, v in data.items():
                if k not in ("status", "health"):
                    click.echo(f"  {k}: {v}")
        else:
            click.echo(str(data))


_NOT_REMOVED = ("\n! Future syncs skip it. Rows ALREADY COLLECTED are NOT removed — "
                "they stay attributed to this integration and stop being refreshed.")


def _toggle_selection(ctx, data_source_name: str, *, enable: bool) -> None:
    """Add or remove one source from the integration's data-source SELECTION (T-38).

    ⭐ THE SELECTION IS WHAT THE PLATFORM HONOURS, for every provider: the scheduler drops
    a deselected source, run-now refuses it (409), the runner skips it, and the health
    rollups (integration HEALTH, sync-overview, AI Home's health tile) stop counting it.

    ⛔ This used to write the per-project `scope_data_sources` instead. That refused
    outright on every non-GCP provider ("no configured scope units"), and on GCP it was a
    silent no-op for the org-scoped sources (`cloud_assets`, `scc_findings`), whose
    extractors never read the per-project list — measured on Classie 2026-10-08: the
    command printed DISABLED and the sources stayed scheduled and failing.
    """
    client = _client(ctx)
    iid = _iid(ctx)
    verb = "enable" if enable else "disable"
    try:
        data = client.post(f"/api/v1/integrations/{iid}/data-sources/{data_source_name}/{verb}")
        current = client.get(f"/api/v1/integrations/{iid}/") if enable else None
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    selected = (data or {}).get("enabled_data_sources") or []
    click.echo(f"{verb.upper()}D: {data_source_name}")
    click.echo(f"  selection: {len(selected)} source(s) selected"
               f"{'' if data_source_name in selected else '  (not collected)'}")
    if not enable:
        click.echo(_NOT_REMOVED)
        return

    # ⚠️ The selection is not the only narrowing on GCP. A project whose per-project list
    # leaves this source out still will not collect it. Say so; never widen a project's
    # list silently — it may have been narrowed (or parked) on purpose.
    scope = (current or {}).get("scope") or {}
    per_project = scope.get("scope_data_sources") or {}
    still_out = sorted(u for u in (scope.get("project_ids") or [])
                       if u in per_project and data_source_name not in (per_project.get(u) or []))
    if still_out:
        click.echo(f"\n⚠ Still excluded per project: {', '.join(still_out)}. To collect it there too:")
        for u in still_out:
            click.echo(f"    torana integration {iid} enable {data_source_name} --project {u}")
    click.echo("\n! A newly enabled source needs a sync to backfill: "
               f"torana integration {iid} sync run --source {data_source_name}")


def _apply_source_selection(ctx, data_source_name: str, *, enable: bool, projects) -> None:
    """Add or remove one data source from the NAMED GCP projects' per-project selection.

    ⛔ READ-MODIFY-WRITE, re-reading immediately before the write so a concurrent
    edit is visible in the result rather than silently lost — same shape as
    `scope --add`.

    ⚠️ ABSENT MEANS ALL. A scope unit with no entry syncs every syncable source,
    so the first `disable` must MATERIALISE the current full set minus one rather
    than write a one-element list. Writing `{"p": ["x"]}` when the user disabled
    a different source would silently switch off everything else.

    ⚠️ AN EMPTY LIST IS A REAL, DIFFERENT STATE — "sync nothing from this unit" —
    and is never collapsed to absent. `{"p": []}` and `{}` are different configs.

    ⚠️ ONLY PROJECT-SCOPED SOURCES READ THIS LIST. The org-scoped ones (`cloud_assets`,
    `scc_findings`) ignore it, so narrowing them here changes nothing — deselect them
    with plain `disable` instead.
    """
    client = _client(ctx)
    iid = _iid(ctx)
    try:
        current = client.get(f"/api/v1/integrations/{iid}/")
        cfg = dict((current or {}).get("config") or {})

        # `scope` is a computed field ON the integration payload, not a separate
        # endpoint — one fetch, so the config and the scope cannot disagree.
        scope = (current or {}).get("scope") or {}
        syncable = sorted(scope.get("syncable_data_sources") or [])
        units = list(scope.get("project_ids") or [])

        if not units:
            click.echo(
                "ERROR: --project applies only to a project-scoped (GCP) integration, and this "
                "one has no projects.\n"
                f"  • Without --project:  torana integration {iid} "
                f"{'enable' if enable else 'disable'} {data_source_name}", err=True)
            sys.exit(2)
        unknown = [p for p in projects if p not in units]
        if unknown:
            click.echo(f"ERROR: not in this integration's scope: {', '.join(unknown)}\n"
                       f"  • Projects:  {', '.join(units)}", err=True)
            sys.exit(2)

        if syncable and data_source_name not in syncable:
            click.echo(
                f"ERROR: {data_source_name!r} is not syncable for this provider — "
                "naming it here would not enable it.\n"
                f"  • Syncable:  {', '.join(syncable)}", err=True)
            sys.exit(2)

        sel = dict(cfg.get("scope_data_sources") or {})
        for unit in projects:
            # Absent => all syncable. Materialise before removing, never after.
            chosen = list(sel[unit]) if unit in sel else list(syncable)
            if enable:
                if data_source_name not in chosen:
                    chosen.append(data_source_name)
            else:
                chosen = [d for d in chosen if d != data_source_name]
            sel[unit] = sorted(chosen)

        cfg["scope_data_sources"] = sel
        # ⛔ The update endpoint REPLACES config wholesale (no merge), so the WHOLE
        # config object goes back — sending only this key would wipe the rest.
        client.put(f"/api/v1/integrations/{iid}/", json={"config": cfg})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    verb = "ENABLED" if enable else "DISABLED"
    click.echo(f"{verb}: {data_source_name} (per project)")
    for unit in sorted(projects):
        n = len(sel[unit])
        mark = "" if data_source_name in sel[unit] else "  (not collected)"
        click.echo(f"  {unit}: {n} source(s) selected{mark}")
    if enable:
        click.echo("\n! A newly enabled source needs a sync to backfill: "
                   f"torana integration {iid} sync run --source {data_source_name}")
    else:
        click.echo(_NOT_REMOVED)


_PROJECT_OPT = click.option(
    "--project", "projects", multiple=True, metavar="PROJECT_ID",
    help="GCP only: change this project's per-project source list instead of the "
         "integration's selection. Repeatable. Has no effect on org-scoped sources "
         "(cloud_assets, scc_findings).")


@integration.command(name="enable")
@click.argument("data_source_name", metavar="DATA_SOURCE_NAME")
@_PROJECT_OPT
@click.pass_context
def integration_enable(ctx, data_source_name, projects):
    """Add a data source back to this integration's selection.

    Any provider. The scheduler registers it again on its next reload. Rejected when the
    source has no backend mapping for this provider (the error lists the valid names).

    \b
    ⚠️ On GCP a project's own source list can still leave it out; the command names any
    such project and the `--project` command that adds it there too.

    \b
    Examples:
      torana integration <UUID> enable teams
      torana integration <UUID> enable gke_clusters --project my-project
      torana integration <UUID> schedule         # the source shows as scheduled again
    """
    if projects:
        _apply_source_selection(ctx, data_source_name, enable=True, projects=projects)
    else:
        _toggle_selection(ctx, data_source_name, enable=True)


@integration.command(name="disable")
@click.argument("data_source_name", metavar="DATA_SOURCE_NAME")
@_PROJECT_OPT
@click.pass_context
def integration_disable(ctx, data_source_name, projects):
    """Stop collecting a data source, without deleting what it already wrote.

    Any provider. Removes it from the integration's selection: the scheduler drops it,
    run-now refuses it, and it stops counting against integration health and AI Home's
    "How this app is running" tile. Disabling the last selected source is refused (pause
    the integration instead).

    \b
    With --project (GCP only) it narrows just those projects' source lists and leaves
    the selection alone. Org-scoped sources ignore that list, so use plain `disable`
    for them.

    \b
    ⛔ DOES NOT REMOVE EXISTING ROWS. Rows already collected stay attributed to
    this integration and simply stop being refreshed, so their `last_seen`
    freezes while the rest of the estate moves on. A stale row that still LOOKS
    current is worse than a missing one — check what it holds before disabling:

      torana integrations data <UUID>

    \b
    Examples:
      torana integration <UUID> disable teams
      torana integration <UUID> disable cloud_sql_instances --project my-project
      torana integration <UUID> schedule         # the source shows as "not selected"
    """
    if projects:
        _apply_source_selection(ctx, data_source_name, enable=False, projects=projects)
    else:
        _toggle_selection(ctx, data_source_name, enable=False)


def _scope_unit_verdict(run, unit, n_units):
    """(status, records_out) for ONE project row split out of a run row.

    ⛔ A unit's `status == "ok"` means the project was READ, not that its rows LANDED.
    The ledger is written at extraction time; the upsert failing afterwards is invisible
    to it. Mapping "ok" to `success` and the unit's EXTRACTED count to LOADED is how a run
    the server stored as `partial`, out=0, dlq=68 was displayed as `success`, loaded=68
    (P1_CA_VULNERABILITIES_SILENTLY_DROPPED, Classie 2026-09-18). A read project therefore
    inherits the RUN's verdict; the only verdict it may shed is the one other projects
    caused (`partial_project_scope`), and only when nothing was dead-lettered.
    """
    if unit.get("status") != "ok":
        return unit.get("status"), unit.get("records")
    status = run.get("status")
    dlq = run.get("dlq_count") or 0
    if status == "partial" and run.get("stop_reason") == "partial_project_scope" and not dlq:
        status = "success"
    if n_units == 1:
        return status, run.get("records_out")
    # ⚠️ Several projects share one run's dead letters, which are not attributed per
    # project — the unit count is only its LOADED count when nothing was dropped.
    return status, (unit.get("records") if not dlq else None)


def _expand_scope_rows(items):
    """Split each run row into ONE ROW PER SCOPE UNIT. Returns (rows, scoped?).

    ⭐ The CLI mirror of the FE's § 3.9g decision: a row that spans N projects has to
    squash per-project outcomes into one cell while RECORDS shows a total belonging to
    neither project. Splitting makes every column true of exactly one project.

    ⚠️ A run with NO scope detail yields exactly one row (project "—") so single-container
    providers, and runs predating the ledger, never vanish from the listing.
    """
    rows, scoped = [], False
    for r in items:
        units = ((r.get("scope_outcomes") or {}).get("units")) or []
        if not units:
            rows.append({**r, "project": "\u2014", "reason": r.get("stop_reason")})
            continue
        scoped = True
        for u in units:
            _ok = u.get("status") == "ok"
            _status, _out = _scope_unit_verdict(r, u, len(units))
            rows.append({
                **r,
                "project": u.get("key"),
                # ⛔ EVERY count must belong to THIS project. `records_in` was left as the
                # run total, so a SKIPPED project displayed "EXTRACTED 73" for records it
                # never read — a more convincing lie than the summary cell this replaced.
                # The ledger records what each unit produced; a non-ok unit produced none.
                "status": _status,
                "records_in": u.get("records") if not _ok else r.get("records_in"),
                "records_out": _out,
                # ⚠️ `stop_reason` is a RUN-level verdict ("partial_project_scope") and
                # explains nothing about a project that succeeded — showing it per row
                # made every healthy project look implicated. Only a unit's OWN reason.
                "reason": u.get("reason") or "",
            })
    return rows, scoped


@integration.command(name="runs")
@click.option("--limit", default=20, show_default=True, help="Number of runs to return.")
@click.option("--offset", default=0, show_default=True, help="Offset for pagination.")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Fetch all runs.")
@click.pass_context
def integration_runs(ctx, limit, offset, fetch_all):
    """List ETL run history for this integration.

    \b
    Example:
      torana integration <UUID> runs
      torana integration <UUID> runs --limit 50
      torana integration <UUID> runs --all
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            cur_offset = 0
            while True:
                data = client.get("etl/admin/runs", params={
                    "integration_id": _iid(ctx), "limit": 100, "offset": cur_offset
                })
                items = data.get("items", data if isinstance(data, list) else [])
                all_items.extend(items)
                if len(items) < 100:
                    break
                cur_offset += 100
            result = {"items": all_items, "total": len(all_items), "page": 1, "page_size": len(all_items)}
        else:
            data = client.get("etl/admin/runs", params={
                "integration_id": _iid(ctx), "limit": limit, "offset": offset
            })
            items = data.get("items", data if isinstance(data, list) else [])
            result = {"items": items, "total": len(items), "page": 1, "page_size": limit}
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # ⛔ R8 PARITY with the Run History tab (§ 3.9g): ONE ROW PER (run x project) for a
    # scoped integration. Without this the CLI shows `partial` and no way to learn WHICH
    # project — the exact dead end the FE now avoids, reintroduced on another surface.
    result["items"], _scoped = _expand_scope_rows(result.get("items") or [])
    result["total"] = len(result["items"])

    _cols = [
        ("run_id", "RUN ID", 36),
        ("data_source", "DATA SOURCE", 20),
    ]
    # Appears only for a scoped integration, so single-container output is unchanged.
    if _scoped:
        _cols.append(("project", "PROJECT", 24))
    _cols += [
        ("status", "STATUS", 12),
        ("records_in", "EXTRACTED", 10),
        ("records_out", "LOADED", 8),
        ("dlq_count", "DLQ", 6),
    ]
    if _scoped:
        _cols.append(("reason", "REASON", 40))
    _cols += [
        ("records_per_sec", "REC/S", 7),
        ("elapsed_s", "ELAPSED(s)", 10),
        ("last_heartbeat_at", "HEARTBEAT", 24),
        ("started_at", "STARTED", 24),
        ("trace_id", "TRACE ID", 32),
    ]
    output(result, fmt=fmt, raw=raw, fields=fields, columns=_cols)


@integration.command(name="run-events")
@click.argument("run_id", metavar="RUN_ID")
@click.option("--event-type", "event_type", default=None, help="Filter to one event type (e.g. drift_detected, dlq_spike, error).")
@click.option("--limit", default=200, show_default=True)
@click.pass_context
def integration_run_events(ctx, run_id, event_type, limit):
    """Show event history for a specific run.

    \b
    Example:
      torana integration <UUID> run-events <RUN_ID>
      torana integration <UUID> run-events <RUN_ID> --event-type drift_detected
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {"limit": limit}
    if event_type:
        params["event_type"] = event_type

    client = _client(ctx)
    try:
        data = client.get(f"etl/admin/runs/{run_id}/events", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    items = data.get("items", [])
    result = {"items": items, "total": len(items), "page": 1, "page_size": limit}
    output(result, fmt=fmt, raw=raw, fields=fields, columns=[
        ("id", "ID", 8),
        ("event_type", "TYPE", 18),
        ("batch_num", "BATCH", 6),
        ("records_extracted", "EXTRACTED", 10),
        ("dlq_count", "DLQ", 6),
        ("drift_count", "DRIFT", 6),
        ("batch_elapsed_ms", "MS", 8),
        ("ts", "TIMESTAMP", 26),
    ])


@integration.command(name="generate-embedding")
@click.pass_context
def integration_generate_embedding(ctx):
    """Generate integration embedding."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"/api/v1/integrations/{_iid(ctx)}/generate-embedding"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@integration.command(name="etl-health")
@click.option("--tenant-id", "tenant_id", default=None, help="Tenant ID (SA only — defaults to own tenant).")
@click.option("--days", default=7, show_default=True, help="Window in days for aggregation.")
@click.pass_context
def integration_etl_health(ctx, tenant_id, days):
    """Show ETL health summary for this integration.

    Reports success rate, average duration, DLQ rate, last failure,
    and any currently active run — aggregated over the last N days.

    \b
    Example:
      torana integration <UUID> etl-health
      torana integration <UUID> etl-health --days 30
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None

    from torana_cli.config.settings import get_settings
    settings = get_settings(profile)

    # Resolve tenant_id from token if not supplied
    if not tenant_id:
        try:
            from torana_cli.client.auth import get_access_token
            import base64, json as _json
            tok = get_access_token(settings.base_url)
            payload = tok.split(".")[1]
            payload += "=" * (-len(payload) % 4)
            claims = _json.loads(base64.urlsafe_b64decode(payload))
            tenant_id = claims.get("tenant_id") or claims.get("tenant")
        except Exception:
            pass

    if not tenant_id:
        click.echo("ERROR: could not resolve tenant_id — pass --tenant-id explicitly.", err=True)
        return

    client = _client(ctx)
    try:
        data = client.get(
            f"admin/etl/integrations/{_iid(ctx)}/health",
            params={"tenant_id": tenant_id, "window_days": days},
        )
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, fields=fields)
        return

    # Human-readable text output
    sr = data.get("success_rate_pct")
    click.echo(f"Integration:     {_iid(ctx)}")
    click.echo(f"Window:          last {data.get('window_days')} days")
    click.echo(f"Total runs:      {data.get('total_runs')}")
    click.echo(f"Success rate:    {sr}%" if sr is not None else "Success rate:    —")
    click.echo(f"  Successful:    {data.get('successful_runs')}")
    # ⛔ `partial` MUST be shown, or the breakdown does not add up to Total runs and the
    # missing runs are invisible. MEASURED before this: 93 successful + 41 failed against
    # 148 total — the 14 partial runs (a project skipped, data still collected) appeared
    # in NO bucket. Reported separately from Failed because the two need different
    # responses: fix one project's IAM binding vs. investigate a broken sync.
    _degraded = data.get('degraded_runs')
    if _degraded:
        click.echo(f"  Partial:       {_degraded}   (some scope units not read)")
    click.echo(f"  Failed:        {data.get('failed_runs')}")
    click.echo(f"  Cancelled:     {data.get('cancelled_runs')}")
    avg_e = data.get("avg_elapsed_s")
    click.echo(f"Avg duration:    {avg_e}s" if avg_e else "Avg duration:    —")
    avg_dlq = data.get("avg_dlq_rate_pct")
    click.echo(f"Avg DLQ rate:    {avg_dlq}%" if avg_dlq else "Avg DLQ rate:    0%")
    ls = data.get("last_success_at")
    click.echo(f"Last success:    {ls[:19].replace('T',' ') if ls else '—'}")
    lf = data.get("last_failure_at")
    lf_class = data.get("last_failure_error_class") or ""
    if lf:
        click.echo(f"Last failure:    {lf[:19].replace('T',' ')}  ({lf_class})")
    else:
        click.echo("Last failure:    —")

    active = data.get("active_run")
    if active:
        click.echo(f"\nActive run:      {active['run_id']}")
        click.echo(f"  Data source:   {active['data_source']}")
        click.echo(f"  Batches done:  {active['batches_done']}")
        click.echo(f"  Extracted:     {active['records_extracted']}")
        rps = active.get("records_per_sec")
        click.echo(f"  Rate:          {rps}/s" if rps else "  Rate:          —")
        hb = active.get("last_heartbeat_at")
        click.echo(f"  Last heartbeat:{hb[:19].replace('T',' ') if hb else '—'}")
    else:
        click.echo("\nActive run:      none")


# ── Sync (trigger + history) ─────────────────────────────────────────────────
# The `sync` group is the discoverable home for everything the UI's "Run Sync"
# dialog does, plus the sync-history views. One verb per UI action:
#
#   torana integration <IID> sync run [--source X ...]   # the "Sync selected" button
#   torana integration <IID> sync list-sources           # the picker (syncable sources)
#   torana integration <IID> sync list                   # sync history (latest first)
#   torana integration <IID> sync latest                 # most-recent sync's per-source status
#   torana integration <IID> sync batch <BATCH_ID> get   # one past sync, per-source status
#   torana integration <IID> sync batch <BATCH_ID> sources list
#   torana integration <IID> sync batch <BATCH_ID> source <NAME> get
#
# A "sync" is one sync_batch_id spanning one-or-more data-source runs — the exact
# unit the UI shows. `run` posts to the same trigger-batch endpoint the UI uses;
# the history views read batch-history. Tenant derives from login; --tenant-id is
# a pure SA filter (omit → own tenant, or ALL tenants for SA).

def _bid(ctx) -> str:
    return ctx.obj.get("_batch_id", "") if ctx.obj else ""


def _sname(ctx) -> str:
    return ctx.obj.get("_source_name", "") if ctx.obj else ""


def _fetch_batches(ctx, tenant_id=None, limit=100):
    """GET batch-history for this integration. Returns the parsed dict or exits."""
    params = {"limit": limit}
    if tenant_id:
        params["tenant_id"] = tenant_id  # pure filter — omit for own-tenant / SA all-tenants
    client = _client(ctx)
    try:
        return client.get(f"admin/etl/integrations/{_iid(ctx)}/batch-history", params=params)
    except APIError as e:
        handle_api_error(e)
        sys.exit(1)
    except AuthError as e:
        handle_auth_error(e)
        sys.exit(5)


def _find_batch(data, batch_id):
    b = next((x for x in (data.get("items") or [])
              if str(x.get("sync_batch_id") or "") == batch_id), None)
    if b is None:
        click.echo(f"Sync not found: {batch_id}", err=True)
        sys.exit(3)
    return b


@integration.group(name="sync", invoke_without_command=True)
@click.pass_context
def integration_sync(ctx):
    """Sync data sources & view sync history — the CLI 'Run Sync'.

    \b
    Verbs:
      run            Start a sync (all syncable sources by default, or a subset)
      list-sources   Show which data sources can be synced (the picker)
      list           Sync history (latest first)
      latest         Most-recent sync's per-source status
      cursors        Current incremental watermark per data source
      batch <ID>     Drill into one past sync (get | sources | source)

    \b
    Examples:
      torana integration <UUID> sync run
      torana integration <UUID> sync run --source scc_findings --source iam_members
      torana integration <UUID> sync list-sources
      torana integration <UUID> sync list
      torana integration <UUID> sync batch <BATCH_ID> get
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@integration_sync.command(name="run")
@click.option("--source", "data_sources", multiple=True,
              help="Sync only this data source (repeatable). Omit = ALL syncable sources.")
@click.option("--tenant-id", "tenant_id", default=None,
              help="Target tenant (SA only). Omit: your own tenant.")
@click.option("--mode", default="normal", type=click.Choice(["normal", "backfill"]),
              show_default=True,
              help="backfill re-pulls from --from-timestamp instead of the stored cursor.")
@click.option("--from-timestamp", "from_timestamp", default=None,
              help="Cursor override for --mode backfill (ISO-8601, e.g. 2026-01-01T00:00:00Z). "
                   "Required by backfill: without it the stored cursor is used and the run "
                   "re-imports nothing.")
@click.pass_context
def integration_sync_run(ctx, data_sources, tenant_id, mode, from_timestamp):
    """Start a sync across one-or-more data sources (default ALL syncable).

    \b
    This is the CLI equivalent of the UI "Run Sync" dialog's "Sync selected" button.
    With no --source flags it syncs every syncable source (matching the dialog's
    all-selected default). Every spawned run shares one sync id — it shows up as the
    newest entry in `sync list`. Tenant derives from your login; SA can target another
    with --tenant-id. Use `sync list-sources` to see what's syncable.

    \b
    Examples:
      torana integration <UUID> sync run                                  # all sources
      torana integration <UUID> sync run --source scc_findings            # one source
      torana integration <UUID> sync run --source scc_findings --source iam_members
      torana integration <UUID> sync run --mode backfill --from-timestamp 2026-01-01T00:00:00Z

    \b
    ⛔ --mode backfill REQUIRES --from-timestamp. It means "re-pull from THIS point",
    not "forget everything": the server sets the cursor override only when a
    timestamp is supplied, so `--mode backfill` alone silently falls back to the
    stored cursor and an incremental source reports success having imported
    nothing. To make sources re-pull from scratch — the thing you want after
    clearing the datalake — reset the cursors instead:

    \b
      torana integrations cursor reset --all-integrations
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    # Fail loudly rather than accept a flag that cannot do what it says.
    if mode == "backfill" and not from_timestamp:
        raise click.UsageError(
            "--mode backfill requires --from-timestamp.\n\n"
            "  Without it the server keeps using the STORED cursor, so the run reports\n"
            "  success while importing nothing (the ETL log calls this 'converged steady\n"
            "  state, NOT a regression').\n\n"
            "  To re-pull a source from the beginning (e.g. after clearing the datalake),\n"
            "  reset the cursor instead:\n"
            "      torana integrations cursor reset --all-integrations"
        )
    if from_timestamp and mode != "backfill":
        raise click.UsageError(
            "--from-timestamp only applies to --mode backfill (it is ignored otherwise)."
        )

    body = {"integration_id": _iid(ctx), "mode": mode}
    if from_timestamp:
        body["from_timestamp"] = from_timestamp
    if data_sources:
        body["data_sources"] = list(data_sources)
    # SA cross-tenant path needs tenant_id; own-tenant path derives it server-side.
    if tenant_id:
        body["tenant_id"] = tenant_id
        endpoint = "admin/etl/ops/trigger-batch"
    else:
        endpoint = "etl/admin/ops/trigger-batch"
    client = _client(ctx)
    try:
        data = client.post(endpoint, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    elif isinstance(data, dict):
        click.echo(f"Sync started: {data.get('sync_batch_id', 'unknown')}")
        click.echo(f"  syncing {data.get('triggered_count', 0)} data source(s)")
    else:
        click.echo(str(data))


@integration_sync.command(name="list-sources")
@click.option("--all", "show_all", is_flag=True, default=False,
              help="Include non-syncable sources too (default: syncable only).")
@click.pass_context
def integration_sync_list_sources(ctx, show_all):
    """List this integration's data sources — the "Run Sync" picker.

    \b
    Shows which sources CAN be synced (syncable = a backend mapping exists). By
    default only syncable sources are listed — those are the ones the UI dialog
    offers. Pass --all to see every declared source with its syncable flag/reason.
    Feed a name into `sync run --source <NAME>`.

    \b
    Examples:
      torana integration <UUID> sync list-sources
      torana integration <UUID> sync list-sources --all --json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    # Resolve the integration's provider, then read that provider's data-source
    # metadata — the same source the UI picker uses (available_data_sources).
    try:
        integ = client.get(f"/api/v1/integrations/{_iid(ctx)}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    provider_name = integ.get("provider") or integ.get("provider_name")
    if not provider_name:
        click.echo("ERROR: could not determine this integration's provider.", err=True)
        sys.exit(1)

    try:
        provider = client.get(f"/api/v1/integrations/providers/{provider_name}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    sources = provider.get("available_data_sources") or []
    if not show_all:
        sources = [s for s in sources if s.get("syncable") is not False]

    rows = [{
        "name": s.get("name"),
        "syncable": s.get("syncable"),
        "supports_incremental": s.get("supports_incremental"),
        "sink_table": s.get("sink_table"),
        "description": s.get("description"),
        "syncable_reason": s.get("syncable_reason"),
    } for s in sources]

    result = {"items": rows, "total": len(rows), "page": 1, "page_size": len(rows)}
    output(result, fmt=fmt, raw=raw, fields=fields, columns=[
        ("name", "DATA SOURCE", 32),
        ("syncable", "SYNCABLE", 9),
        ("supports_incremental", "INCR", 6),
        ("sink_table", "SINK TABLE", 24),
        ("description", "DESCRIPTION", 50),
    ])


@integration_sync.command(name="list")
@click.option("--tenant-id", "tenant_id", default=None,
              help="Filter to one tenant (SA only). Omit: your tenant, or ALL tenants for SA.")
@click.option("--limit", default=30, show_default=True,
              help="Max number of syncs to return (server caps at 100).")
@click.pass_context
def integration_sync_list(ctx, tenant_id, limit):
    """List past syncs (latest first) — the run-history master view.

    \b
    Examples:
      torana integration <UUID> sync list
      torana integration <UUID> sync list --tenant-id <TID>   # SA: one tenant
      torana integration <UUID> sync list --limit 50 --json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    data = _fetch_batches(ctx, tenant_id=tenant_id, limit=limit)
    output(data, fmt=fmt, raw=raw, fields=fields, columns=[
        ("sync_batch_id", "SYNC ID", 36),
        ("tenant_name", "TENANT", 18),
        ("overall_status", "STATUS", 10),
        ("data_source_count", "SOURCES", 8),
        ("started_at", "STARTED", 24),
        ("finished_at", "FINISHED", 24),
        ("trigger", "TRIGGER", 10),
    ])


@integration_sync.command(name="latest")
@click.option("--tenant-id", "tenant_id", default=None,
              help="Filter to one tenant (SA only).")
@click.pass_context
def integration_sync_latest(ctx, tenant_id):
    """Show the MOST RECENT sync's per-data-source status (the view the UI opens on).

    \b
    Examples:
      torana integration <UUID> sync latest
      torana integration <UUID> sync latest --json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    data = _fetch_batches(ctx, tenant_id=tenant_id, limit=1)
    items = data.get("items") or []
    if not items:
        click.echo("No syncs recorded yet.")
        return
    batch = items[0]  # already latest-first
    if fmt != "text":
        output(batch, fmt=fmt, fields=fields)
        return
    click.echo(f"Sync {batch.get('sync_batch_id')} · overall "
               f"{batch.get('overall_status')} · {batch.get('data_source_count')} sources"
               + (f" · tenant {batch['tenant_name']}" if batch.get("tenant_name") else ""))
    _print_sources(batch)
    # Close the loop: having shown the LAST sync, say when the NEXT one is due,
    # so "do I need to run one by hand?" is answered without a second command.
    _echo_next_sync(ctx)


def _fmt_relative(value):
    """'in 2h 5m' / 'due now' for a future ISO timestamp; None if unparseable."""
    from datetime import datetime, timezone
    try:
        ts = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=timezone.utc)
    secs = (ts - datetime.now(timezone.utc)).total_seconds()
    if secs <= 0:
        return "due now"
    if secs < 3600:
        return f"in {int(secs // 60)}m"
    if secs < 86400:
        return f"in {int(secs // 3600)}h {int((secs % 3600) // 60)}m"
    return f"in {int(secs // 86400)}d"


def _echo_next_sync(ctx):
    """Print the 'Next sync' line. Best-effort — never raises.

    ⛔ A null next_sync_at is NOT unknown; it means nothing is scheduled, and
    that is the case the operator most needs told, because it is the one where a
    hand-run is the ONLY way the data ever refreshes.
    """
    try:
        data = _client(ctx).get(f"/api/v1/integrations/{_iid(ctx)}/") or {}
        nxt = data.get("next_sync_at")
        if not nxt:
            click.echo("\nNext sync:       not scheduled — this integration only "
                       "refreshes when you run it by hand")
            return
        rel = _fmt_relative(nxt)
        line = f"\nNext sync:       {str(nxt)[:19].replace('T', ' ')} UTC"
        if rel:
            line += f"  ({rel})"
        if data.get("sync_cadence"):
            line += f"  · {data['sync_cadence']}"
        click.echo(line)
        if data.get("scheduled_data_sources"):
            click.echo(f"                 {data['scheduled_data_sources']} data source(s) "
                       f"on a schedule")
        # ⛔ T-28: the time above is when the cron says it is DUE. Whether the scheduler
        # actually holds a job is the leader's answer, and it can disagree.
        unsched = data.get("unscheduled_data_sources")
        if data.get("scheduler_truthful") is False:
            click.echo("                 ⚠️  scheduler job list unreadable — the time above "
                       "is unverified")
        elif unsched:
            click.echo(f"                 ⚠️  {unsched} data source(s) NOT SCHEDULED — no "
                       f"job on the scheduler; see `integration {_iid(ctx)} schedule`")
    except Exception:
        # Freshness metadata must never break the command it decorates.
        return


@integration_sync.command(name="next")
@click.pass_context
def integration_sync_next(ctx):
    """When is the NEXT automatic sync due?

    Answers "do I need to run a sync by hand right now?".

    \b
    Examples:
      torana integration <UUID> sync next
      torana integration <UUID> sync next --json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    try:
        data = _client(ctx).get(f"/api/v1/integrations/{_iid(ctx)}/") or {}
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    payload = {
        "integration_id": _iid(ctx),
        "provider": data.get("provider"),
        "last_sync_time": data.get("last_sync_time"),
        "last_sync_status": data.get("last_sync_status"),
        "next_sync_at": data.get("next_sync_at"),
        "sync_cadence": data.get("sync_cadence"),
        "sync_schedule": data.get("sync_schedule"),
        "scheduled_data_sources": data.get("scheduled_data_sources"),
        # Leader truth (T-28): how many of those have NO job on the scheduler.
        "unscheduled_data_sources": data.get("unscheduled_data_sources"),
        "scheduler_truthful": data.get("scheduler_truthful"),
    }
    if fmt != "text":
        output(payload, fmt=fmt, fields=fields)
        return

    ls = payload["last_sync_time"]
    click.echo(f"Last sync:       "
               f"{str(ls)[:19].replace('T', ' ') + ' UTC' if ls else 'never'}"
               + (f"  ({payload['last_sync_status']})"
                  if payload.get("last_sync_status") else ""))
    _echo_next_sync(ctx)


@integration_sync.group(name="batch", invoke_without_command=True)
@click.argument("batch_id", metavar="BATCH_ID")
@click.option("--tenant-id", "tenant_id", default=None,
              help="Filter to one tenant (SA only).")
@click.pass_context
def integration_sync_batch(ctx, batch_id, tenant_id):
    """One past sync, by id. Sub-commands: get | sources | source."""
    ctx.ensure_object(dict)
    ctx.obj["_batch_id"] = batch_id
    ctx.obj["_batch_tenant_id"] = tenant_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _batch_tenant(ctx):
    return ctx.obj.get("_batch_tenant_id") if ctx.obj else None


@integration_sync_batch.command(name="get")
@click.pass_context
def integration_sync_batch_get(ctx):
    """Get the sync's metadata + per-data-source status (the "this run" view)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    data = _fetch_batches(ctx, tenant_id=_batch_tenant(ctx))
    batch = _find_batch(data, _bid(ctx))
    if fmt != "text":
        output(batch, fmt=fmt, fields=fields)
        return
    click.echo(f"Sync {batch.get('sync_batch_id')} · overall "
               f"{batch.get('overall_status')} · {batch.get('data_source_count')} sources"
               + (f" · tenant {batch['tenant_name']}" if batch.get("tenant_name") else ""))
    _print_sources(batch)


def _print_sources(batch):
    """Render one row per data source — or per (data source x PROJECT) when scoped.

    ⛔ R8 PARITY. The API serves `status_reason` and `scope_outcomes`, and the FE renders
    both; without them here the CLI answers a strictly weaker question than the UI for the
    same run. A multi-project sync showed `partial` with no way to learn WHICH project —
    the exact dead end the whole per-project effort exists to remove.

    ⭐ ONE ROW PER PROJECT, matching the FE (§ 3.9g): a single row spanning N projects has
    to squash per-project outcomes into one cell while RECORDS shows a total belonging to
    neither. Splitting the row makes every column true of exactly one project.
    """
    rows = []
    scoped = False
    for name, v in sorted((batch.get("per_data_source") or {}).items()):
        units = ((v.get("scope_outcomes") or {}).get("units")) or []
        base = {
            "data_source": name,
            "status": v.get("status"),
            "records_out": v.get("records_out"),
            "dlq_count": v.get("dlq_count"),
            # WHY, not just WHAT — the same classification the API and FE show.
            "reason": v.get("status_reason") or v.get("error_class"),
            "trace_id": v.get("trace_id"),
        }
        if not units:
            rows.append({**base, "project": "—"})
            continue
        scoped = True
        for u in units:
            _status, _out = _scope_unit_verdict({**v, **base}, u, len(units))
            rows.append({
                **base,
                "project": u.get("key"),
                # This PROJECT's status and records — never the cross-project total,
                # and never a verdict the run did not reach (see _scope_unit_verdict).
                "status": _status,
                "records_out": _out,
                "reason": u.get("reason") or base["reason"],
            })

    columns = [("data_source", "DATA SOURCE", 30)]
    # ⚠️ The Project column appears ONLY for a scoped integration, so every
    # single-container provider's output is byte-identical to before.
    if scoped:
        columns.append(("project", "PROJECT", 24))
    columns += [
        ("status", "STATUS", 10),
        ("records_out", "RECORDS", 9),
        ("dlq_count", "DLQ", 5),
        ("reason", "REASON", 40),
        ("trace_id", "TRACE ID", 32),
    ]
    output({"items": rows, "total": len(rows), "page": 1, "page_size": len(rows)},
           fmt="text", columns=columns)


@integration_sync_batch.group(name="sources", invoke_without_command=True)
@click.pass_context
def integration_sync_batch_sources(ctx):
    """Data sources in this sync. Use `list` to list them."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@integration_sync_batch_sources.command(name="list")
@click.pass_context
def integration_sync_batch_sources_list(ctx):
    """List each data source's status for this sync — the "Data Sources — this run" view."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    data = _fetch_batches(ctx, tenant_id=_batch_tenant(ctx))
    batch = _find_batch(data, _bid(ctx))
    rows = []
    for name, v in sorted((batch.get("per_data_source") or {}).items()):
        rows.append({"data_source": name, "status": v.get("status"),
                     "records_out": v.get("records_out"), "dlq_count": v.get("dlq_count"),
                     "error_class": v.get("error_class"), "trace_id": v.get("trace_id"),
                     "run_id": v.get("run_id")})
    output({"items": rows, "total": len(rows), "page": 1, "page_size": len(rows)},
           fmt=fmt, raw=raw, fields=fields, columns=[
        ("data_source", "DATA SOURCE", 30),
        ("status", "STATUS", 10),
        ("records_out", "RECORDS", 9),
        ("dlq_count", "DLQ", 5),
        ("error_class", "ERROR", 14),
        ("trace_id", "TRACE ID", 32),
    ])


@integration_sync_batch.group(name="source", invoke_without_command=True)
@click.argument("data_source", metavar="DATA_SOURCE")
@click.pass_context
def integration_sync_batch_source(ctx, data_source):
    """One data source in this sync, by name. Sub-command: get."""
    ctx.ensure_object(dict)
    ctx.obj["_source_name"] = data_source
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@integration_sync_batch_source.command(name="get")
@click.pass_context
def integration_sync_batch_source_get(ctx):
    """Full error/diagnostics for this source — the exact error + drill-down links.

    \b
    The CLI equivalent of expanding a data source on the sync-detail page: error
    class + message + step, stop reason, and the trace_id / run_id / logs deep-links.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    data = _fetch_batches(ctx, tenant_id=_batch_tenant(ctx))
    batch = _find_batch(data, _bid(ctx))
    name = _sname(ctx)
    src = (batch.get("per_data_source") or {}).get(name)
    if src is None:
        click.echo(f"Data source '{name}' not in sync {_bid(ctx)}", err=True)
        sys.exit(3)

    if fmt != "text":
        output({"data_source": name, **src}, fmt=fmt, fields=fields)
        return

    st = (src.get("status") or "").upper()
    click.echo(f"{name}  [{st}]  {src.get('records_out', 0)} rec · "
               f"{src.get('dlq_count', 0)} dlq")
    if src.get("error_class") or src.get("error_message"):
        step = f" at step {src['error_step_id']}" if src.get("error_step_id") else ""
        click.echo(f"  ERROR  {src.get('error_class') or ''}{step}")
        if src.get("error_message"):
            click.echo(f"    {src['error_message']}")
    if src.get("stop_reason"):
        click.echo(f"  STOP REASON  {src['stop_reason']}")
    if src.get("run_id"):
        click.echo(f"  run_id   {src['run_id']}")
    if src.get("trace_id"):
        click.echo(f"  trace_id {src['trace_id']}")
    if src.get("logs_url"):
        click.echo(f"  logs     {src['logs_url']}")


# ---------------------------------------------------------------------------
# Cursors — where the next sync resumes from
# ---------------------------------------------------------------------------
#
# The ETL cursor store is INDEPENDENT of the datalake, so clearing lake rows does
# NOT restore a full pull: each incremental source keeps asking its provider for
# "changes since <cursor>" and re-imports almost nothing. Resetting the cursor is
# what makes the next run a genuine first run.
#
# Distinct from `backfill`, which overrides the cursor for ONE run and requires a
# timestamp — meaningless for the opaque `cursor_token`/`link_header` strategies.
# Reset DELETES the stored value, which works for every strategy.

def reset_cursors_core(ctx, *, integration_id=None, data_source=None,
                       all_integrations=False):
    """Shared reset routine for the singular and plural command forms.

    One routine so `torana integration <ID> cursor reset` and
    `torana integrations cursor reset --all-integrations` cannot drift in
    scope semantics or output shape.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    params = {}
    if integration_id:
        params["integration_id"] = integration_id
    if data_source:
        params["data_source"] = data_source
    if all_integrations:
        params["all_integrations"] = "true"

    client = _client(ctx)
    try:
        data = client.delete("etl/cursors", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml"):
        output(data, fmt=fmt)
        return

    cleared = data.get("cleared", []) or []
    if not cleared:
        click.echo("No cursors to reset — these sources have no committed cursor.")
        return
    click.echo(f"Reset {len(cleared)} cursor(s):")
    for c in cleared:
        click.echo(f"  {c.get('data_source'):24} was: {c.get('value')}")
    if data.get("next_steps"):
        click.echo()
        click.echo(data["next_steps"])


@integration.command(name="schedule")
@click.pass_context
def integration_schedule(ctx):
    """When each data source on this integration is due to sync.

    Read-only. The cadence is declared per DATA SOURCE in its mapping, so one
    integration routinely holds several: GitHub syncs repositories every 4 hours,
    most sources every 6, and team membership every 12.

    \b
    The single cadence on `integration get` and the list page is the cadence of
    whichever source fires SOONEST -- it is not the integration's. This command is
    the per-source truth.

    \b
    Sourced from the ENABLED MAPPINGS, which is what the scheduler runs -- so a
    source that syncs cannot be missing from this list. Joining the cursor and run
    endpoints instead would reintroduce that gap: they enumerate the provider
    class and the run table, which have drifted (kubernetes: 8 / 7 / 8).

    \b
    Example:
      torana integration <UUID> schedule
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get(f"integrations/{_iid(ctx)}/data-sources") or {}
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    rows = data.get("items") or []
    if not rows:
        # Not an error: an integration with no enabled mapping for its provider is
        # genuinely unscheduled, and a hand-run is then the ONLY way it refreshes.
        click.echo("No data source on this integration is scheduled. "
                   "It refreshes only when you run it by hand.")
        return

    sched = data.get("scheduler") or {}
    for r in rows:
        # ⛔ T-28: NEXT RUN used to be computed from the cron, so a source the scheduler
        # had never registered still showed a time. `scheduled` is the LEADER's answer:
        #   True  -> the leader's own next fire time
        #   False -> NOT SCHEDULED: no job exists, so no cron run will ever happen
        #   None  -> the leader's list could not be read; the cron time is only "due"
        # 'on-push' sources carry no fire time. Say so rather than printing a blank
        # cell, which reads as missing data instead of "waits for an upload".
        # T-38: deselected by the customer — unscheduled ON PURPOSE, never a fault.
        if r.get("selected") is False:
            r["next_run"] = "not selected"
        elif not r.get("next_sync_at"):
            r["next_run"] = "on push"
        elif r.get("scheduled") is False:
            r["next_run"] = "NOT SCHEDULED"
        elif r.get("scheduled") is True:
            r["next_run"] = _fmt_ts(r.get("scheduler_next_run_at") or r["next_sync_at"])
        else:
            r["next_run"] = f"due {_fmt_ts(r['next_sync_at'])} ?"

        # ⚠️ Absent means NEVER RUN, not "unknown".
        r["last_run"] = (_fmt_ts(r["last_run_at"]) if r.get("last_run_at")
                         else "never run")
        r["outcome"] = r.get("last_run_status") or "—"

        # ⚠️ 0 is a VALUE, not a blank: a source returning zero rows on every run
        # while reporting success is exactly what this column exists to reveal.
        r["records"] = "—" if r.get("records_in") is None else str(r["records_in"])

        # ⛔ full_refresh BEFORE cursor_set. A `cursor: {type: none}` source STILL
        # stores a value — the commit path stamps now() when the extractor yields no
        # cursor, so that absence can mean "never completed a run". That stamp is a
        # RUN MARKER, not a resume point, and printing it made six of eight
        # identically-configured kubernetes sources look incremental.
        if r.get("full_refresh"):
            r["cursor_value"] = "full refresh — pulls everything"
        elif r.get("cursor_set") and r.get("cursor_value") is not None:
            r["cursor_value"] = _fmt_cursor(r["cursor_value"])
        else:
            r["cursor_value"] = "not set — pulls from the beginning"

    output(rows, fmt=fmt, raw=raw, fields=fields, columns=[
        ("data_source", "DATA SOURCE", 26),
        ("cadence", "CADENCE", 15),
        ("last_run", "LAST RUN", 21),
        ("outcome", "OUTCOME", 9),
        ("records", "RECORDS", 8),
        ("cursor_value", "CURSOR", 32),
        ("next_run", "NEXT RUN", 21),
    ])
    if fmt == "text":
        click.echo(f"\n{len(rows)} data source(s). Times are UTC.")
        if not sched.get("truthful"):
            click.echo("⚠️  Could not read the scheduler's registered jobs "
                       f"({sched.get('reason') or 'unknown reason'}). NEXT RUN marked "
                       "'?' is when the source is DUE by its cron, not a confirmed job.")
        elif any(r.get("scheduled") is False and r.get("selected") is not False
                 for r in rows):
            click.echo("⚠️  NOT SCHEDULED: the scheduler holds no job for these sources, "
                       "so they will not sync on their own. Check the integration is "
                       "active, enabled and credentialed; otherwise report it.")


def _fmt_ts(value) -> str:
    """'2026-09-24 20:00:00 UTC' from an ISO timestamp; the input unchanged if it
    is not one. Cursor values are opaque and are often NOT timestamps."""
    text = str(value)
    if len(text) >= 19 and text[4] == "-" and text[7] == "-" and text[10] in "T ":
        return text[:19].replace("T", " ") + " UTC"
    return text


def _fmt_cursor(value) -> str:
    """Render a cursor value, which is not always a string.

    An org-scoped source stores `{"__per_project__": {"<project>": "<watermark>"}}`;
    printing the dict directly is unreadable in a fixed-width column.
    """
    if isinstance(value, dict):
        per_project = value.get("__per_project__")
        if isinstance(per_project, dict):
            return "; ".join(f"{k}={_fmt_ts(v)}" for k, v in per_project.items())
        return str(value)
    return _fmt_ts(value)


@integration.group(name="cursor", invoke_without_command=True)
@click.pass_context
def integration_cursor(ctx):
    """ETL cursors for this integration — where the next sync resumes from.

    \b
    Examples:
      torana integration <UUID> cursor list
      torana integration <UUID> cursor reset --data-source users
      torana integration <UUID> cursor reset --all
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@integration_cursor.command(name="list")
@click.pass_context
def integration_cursor_list(ctx):
    """Show each data source's cursor and when it was last committed."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get("etl/cursors", params={"integration_id": _iid(ctx)})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    # Every DECLARED source is listed, including ones with no cursor — an
    # unset cursor is a real state ("never synced"), and omitting those rows
    # made a reset tenant look identical to a broken query.
    output(data, fmt=fmt, raw=raw, fields=fields, columns=[
        ("data_source", "DATA SOURCE", 24),
        ("status", "CURSOR", 44),
        ("updated_at", "COMMITTED", 30),
    ])


@integration_cursor.command(name="reset")
@click.option("--data-source", "data_source", default=None,
              help="Reset just this data source. Omit with --all to reset every source.")
@click.option("--all", "all_sources", is_flag=True,
              help="Reset every data source on this integration.")
@click.option("--yes", is_flag=True, help="Skip the confirmation prompt.")
@click.pass_context
def integration_cursor_reset(ctx, data_source, all_sources, yes):
    """Clear cursors so the next sync starts from the beginning.

    Does NOT delete data and does NOT trigger a sync — it only changes WHERE the
    next run resumes from. Use after clearing datalake rows, or when a source has
    drifted and needs a clean full pull.
    """
    if not data_source and not all_sources:
        click.echo("Specify --data-source <NAME>, or --all for every source on "
                   "this integration.", err=True)
        sys.exit(2)
    if data_source and all_sources:
        click.echo("--data-source and --all are mutually exclusive.", err=True)
        sys.exit(2)
    if not yes:
        scope = f"data source '{data_source}'" if data_source else "ALL data sources"
        _confirm(f"Reset the cursor for {scope} on integration {_iid(ctx)}? "
                      f"The next sync re-pulls from the beginning.", yes=False)
    reset_cursors_core(ctx, integration_id=_iid(ctx), data_source=data_source)


# ---------------------------------------------------------------------------
# Recipient groups (OI-188 b): playbook group -> Slack channel id / Jira project
# ---------------------------------------------------------------------------

_TARGET_COLUMNS = [("id", "ID", 36), ("group_key", "GROUP", 24), ("provider", "PROVIDER", 8),
                   ("workspace_id", "WORKSPACE", 36), ("slack_channel_id", "SLACK CHANNEL", 13),
                   ("jira_project_key", "JIRA PROJECT", 12), ("jira_issue_type", "ISSUE TYPE", 10),
                   ("description", "DESCRIPTION", 40)]


def _targets_path(ctx, target_id: str = "") -> str:
    base = f"/api/v1/integrations/{_iid(ctx)}/notification-targets"
    return f"{base}/{target_id}" if target_id else base


def _target_call(ctx, method: str, path: str, body=None):
    client = _client(ctx)
    try:
        return getattr(client, method)(path, **({"json": body} if body is not None else {}))
    except APIError as e:
        handle_api_error(e)
    except AuthError as e:
        handle_auth_error(e)
    return None


@integration.group(name="notification-targets", invoke_without_command=True)
@click.pass_context
def integration_notification_targets(ctx):
    """Recipient groups of this Slack or Jira integration.

    A declared playbook action names a recipient GROUP (`platform-oncall`), never a channel. Each group maps here
    to one Slack channel ID (C…/G…) or one Jira project + issue type. A workspace-scoped mapping wins over a
    tenant-wide one. Pausing the integration's sync does NOT silence notifications.

    \b
    Examples:
      torana integration <IID> notification-targets list
      torana integration <IID> notification-targets create --group-key platform-oncall \\
          --slack-channel-id C0123ABCD --description "Platform on-call channel"
      torana integration <IID> notification-targets test <TARGET_ID>
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@integration_notification_targets.command(name="list")
@click.pass_context
def integration_notification_targets_list(ctx):
    """List this integration's recipient groups.

    \b
    Examples:
      torana integration <IID> notification-targets list
      torana integration <IID> notification-targets list --json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    data = _target_call(ctx, "get", _targets_path(ctx))
    items = (data or {}).get("items") or [] if isinstance(data, dict) else (data or [])
    if fmt == "text":
        if not items:
            click.echo("No recipient groups on this integration. Add one with `notification-targets create`.")
            return
        output(items, fmt="text", columns=_TARGET_COLUMNS, pagination_hint=False)
        return
    output(items if raw else {"items": items, "total": len(items), "page": 1, "page_size": len(items)},
           fmt=fmt, raw=raw)


@integration_notification_targets.command(name="create")
@click.option("--group-key", required=True, help="Lower-case group name a playbook uses, e.g. platform-oncall.")
@click.option("--description", required=True, help="What this group is, for people and agents.")
@click.option("--slack-channel-id", default=None, help="Slack: the channel ID (C…/G…), never its name.")
@click.option("--jira-project-key", default=None, help="Jira: the project key, e.g. SEC.")
@click.option("--jira-issue-type", default=None, help="Jira: issue type name (default Task).")
@click.option("--workspace-id", default=None, help="Scope the mapping to one workspace (default: tenant-wide).")
@click.pass_context
def integration_notification_targets_create(ctx, group_key, description, slack_channel_id, jira_project_key,
                                            jira_issue_type, workspace_id):
    """Map a recipient group to a Slack channel or a Jira project. Needs integrations:update.

    The provider comes from the integration. A Slack bot also needs the `chat:write` scope to post.

    \b
    Examples:
      torana integration <SLACK_IID> notification-targets create --group-key platform-oncall \\
          --slack-channel-id C0123ABCD --description "Platform on-call channel"
      torana integration <JIRA_IID> notification-targets create --group-key sec-tickets \\
          --jira-project-key SEC --jira-issue-type Bug --description "Security backlog"
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    body = {k: v for k, v in {"group_key": group_key, "description": description,
                              "slack_channel_id": slack_channel_id, "jira_project_key": jira_project_key,
                              "jira_issue_type": jira_issue_type, "workspace_id": workspace_id}.items()
            if v is not None}
    data = _target_call(ctx, "post", _targets_path(ctx), body)
    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created recipient group {group_key}: {(data or {}).get('id', '?')} "
                   f"({(data or {}).get('provider', '?')})")


@integration_notification_targets.command(name="update")
@click.argument("TARGET_ID", metavar="TARGET_ID")
@click.option("--description", default=None)
@click.option("--slack-channel-id", default=None)
@click.option("--jira-project-key", default=None)
@click.option("--jira-issue-type", default=None)
@click.pass_context
def integration_notification_targets_update(ctx, target_id, description, slack_channel_id, jira_project_key,
                                            jira_issue_type):
    """Change a recipient group's channel, project, issue type or description. Needs integrations:update.

    \b
    Examples:
      torana integration <IID> notification-targets update <TARGET_ID> --slack-channel-id C0NEWCHAN1
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    body = {k: v for k, v in {"description": description, "slack_channel_id": slack_channel_id,
                              "jira_project_key": jira_project_key, "jira_issue_type": jira_issue_type}.items()
            if v is not None}
    if not body:
        click.echo("ERROR: nothing to update (give at least one option).", err=True)
        sys.exit(2)
    data = _target_call(ctx, "put", _targets_path(ctx, target_id), body)
    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated recipient group {target_id}")


@integration_notification_targets.command(name="delete")
@click.argument("TARGET_ID", metavar="TARGET_ID")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def integration_notification_targets_delete(ctx, target_id, yes):
    """Remove a recipient group (soft delete). Playbooks naming it then fail with unresolved_group.

    \b
    Examples:
      torana integration <IID> notification-targets delete <TARGET_ID> --yes
    """
    _confirm(f"Delete recipient group {target_id}?", yes=yes)
    _target_call(ctx, "delete", _targets_path(ctx, target_id))
    click.echo(f"Deleted recipient group {target_id}")


@integration_notification_targets.command(name="test")
@click.argument("TARGET_ID", metavar="TARGET_ID")
@click.pass_context
def integration_notification_targets_test(ctx, target_id):
    """Slack: post "Torana test message for group <key>" to the channel. Jira: check the project and issue type
    (creates nothing). Prints the outcome, e.g. credential_scope_missing naming the scope the bot lacks.

    \b
    Examples:
      torana integration <IID> notification-targets test <TARGET_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    data = _target_call(ctx, "post", _targets_path(ctx, target_id) + "/test", {})
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt)
        return
    if data.get("ok"):
        click.echo(f"✓ ok: {data.get('status', '')} {data.get('external_ref') or ''}".rstrip())
        return
    d = data.get("detail") or {}
    click.echo(f"✗ failed: {d.get('error', '?')} — {d.get('message', '')}", err=True)
    sys.exit(1)


# ── related repositories (FIX_PR_SPEC.md § 3.4.11) ──────────────────────────────────

_RELATED_COLUMNS = [
    ("id", "ID", 36),
    ("subject_repository", "SUBJECT", 40),
    ("target_repository", "TARGET", 40),
    ("description", "WHY", 0),
]


def _related_path(ctx, related_id: str = "") -> str:
    base = f"integrations/{ctx.obj['_integration_id']}/related-repositories"
    return f"{base}/{related_id}" if related_id else base


def _related_call(ctx, method: str, path: str, **kwargs):
    client = _client(ctx)
    try:
        return getattr(client, method)(path, **kwargs)
    except AuthError as e:
        handle_auth_error(e)
    except APIError as e:
        handle_api_error(e)


@integration.group(name="related-repos", invoke_without_command=True)
@click.pass_context
def integration_related_repos(ctx):
    """Repositories declared RELATED to a subject repository, through this GitHub integration's App.

    A propose run for the subject may then get a short-lived, read-only, one-repository token to check out the
    target (`torana remediation-plans target-token`), e.g. pantheon-auth → pantheon-deploy, whose base-image lock
    builds it. Adding and removing need `remediation_plan:create` (tenant admin) and are refused to a CI token, so
    a job can never widen its own reach. Every mint reads the declaration fresh: a removal applies to the next
    mint.

    \b
    Examples:
      torana integration <IID> related-repos list
      torana integration <IID> related-repos add --subject repo:github.com/acme/api \\
          --target repo:github.com/acme/deploy --description "deploy's base-image lock builds api's image"
      torana integration <IID> related-repos remove <RELATED_ID>
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@integration_related_repos.command(name="list")
@click.option("--limit", default=50, type=click.IntRange(1, 100), show_default=True)
@click.option("--offset", default=0, type=click.IntRange(min=0), show_default=True)
@click.pass_context
def integration_related_repos_list(ctx, limit, offset):
    """List the related-repository declarations on this integration.

    \b
    Examples:
      torana integration <IID> related-repos list
      torana integration <IID> related-repos list --format json
    """
    data = _related_call(ctx, "get", _related_path(ctx), params={"limit": limit, "offset": offset})
    output(data, fmt=ctx.obj.get(CTX_FORMAT, "text"), raw=ctx.obj.get(CTX_RAW, False),
           fields=ctx.obj.get(CTX_FIELDS), columns=_RELATED_COLUMNS)


@integration_related_repos.command(name="add")
@click.option("--subject", required=True, metavar="REPO_KEY", help="repo:github.com/<org>/<repo> that proposes.")
@click.option("--target", required=True, metavar="REPO_KEY", help="repo:github.com/<org>/<repo> it may read.")
@click.option("--description", required=True, help="Why they are related (required, non-empty).")
@click.pass_context
def integration_related_repos_add(ctx, subject, target, description):
    """Declare a target repository related to a subject. 409 `already_related` when it is declared already.

    \b
    Examples:
      torana integration <IID> related-repos add --subject repo:github.com/acme/api \\
          --target repo:github.com/acme/deploy --description "deploy's base-image lock builds api's image"
    """
    if not description.strip():
        click.echo("ERROR: --description must say why they are related", err=True)
        sys.exit(2)
    data = _related_call(ctx, "post", _related_path(ctx), json={
        "subject_repository": subject, "target_repository": target, "description": description})
    output(data, fmt=ctx.obj.get(CTX_FORMAT, "text"), fields=ctx.obj.get(CTX_FIELDS))


@integration_related_repos.command(name="remove")
@click.argument("RELATED_ID", metavar="RELATED_ID")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def integration_related_repos_remove(ctx, related_id, yes):
    """Remove a declaration (soft delete). The next mint for that pair is refused (`not_related`).

    \b
    Examples:
      torana integration <IID> related-repos remove <RELATED_ID> --yes
    """
    _confirm(f"Remove related-repository declaration {related_id}?", yes=yes)
    _related_call(ctx, "delete", _related_path(ctx, related_id))
    click.echo(f"Removed related-repository declaration {related_id}")
