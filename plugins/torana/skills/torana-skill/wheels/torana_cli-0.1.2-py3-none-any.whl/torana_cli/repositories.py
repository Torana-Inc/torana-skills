"""torana repositories — query datalake repository (asset-inventory) records.

All reads use the datalake's /tables/repositories/data endpoint — the same sink
table `ingest assets` writes and `govern repo` annotates.

Instance commands (get) are under: torana repository <KEY> <verb>

Why this exists (CLI-17): the `repositories` sink table had NO CLI read at all,
while the API and FE both surfaced the row — a surface-parity violation. Worse,
the `torana-asset-inventory` skill's idempotency guard shells
`torana repositories list --raw | grep <repo>`; against a nonexistent command that
grep silently fails, the guard reads "not found", and a duplicate repository asset
is created on every run.
"""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output


_REPO_COLS = [
    ("torana_repository_id", "KEY", 44),
    ("name", "NAME", 28),
    ("provider", "PROVIDER", 10),
    ("visibility", "VISIBILITY", 10),
    ("criticality_name", "CRITICALITY", 12),
    ("asset_owner_email", "OWNER", 28),
    ("environment", "ENV", 10),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _normalize_list_response(data: dict) -> dict:
    """Normalize the datalake /tables/{name}/data response to {items, total}."""
    if isinstance(data, dict):
        if "data" in data:
            return {"items": data["data"], "total": data.get("count", len(data["data"]))}
        if "items" in data:
            return data
    return {"items": data if isinstance(data, list) else [], "total": 0}


def _sql_quote(value: str) -> str:
    """Single-quote a SQL literal, escaping embedded quotes."""
    return "'" + str(value).replace("'", "''") + "'"


def _count_repositories(client, filters: dict):
    """Accurate total via COUNT(*). Returns int or None when unavailable.

    The datalake list endpoint returns only the page count, so without this a
    caller can't tell "20 shown" from "20 total" without paging everything.
    """
    where = ""
    if filters:
        clauses = [f"{k} = {_sql_quote(v)}" for k, v in filters.items() if v is not None]
        if clauses:
            where = " WHERE " + " AND ".join(clauses)
    sql = "SELECT count(*) AS n FROM repositories" + where
    try:
        data = client.post("/query", json={"query": sql})
    except (APIError, AuthError):
        return None
    rows = data.get("results") if isinstance(data, dict) else None
    if rows and isinstance(rows, list) and isinstance(rows[0], dict):
        first = rows[0]
        return first.get("n", next(iter(first.values()), None))
    return None


def resolve_repository_key(client, repo: str) -> str:
    """Resolve a user-supplied repo reference to its canonical torana_repository_id.

    Accepts the full source-neutral key (`repo:github.com/org/name`), an
    `org/name` pair, or a bare repo name. Mirrors the resolution already used by
    `vulnerabilities list --repo` so the two surfaces agree on what a repo
    reference means.

    Exits 3 when nothing matches and 6 when the reference is ambiguous — an
    ambiguous match must never silently pick one row.
    """
    if repo.startswith("repo:"):
        return repo

    like = _sql_quote(f"%{repo}%")
    sql = (
        "SELECT torana_repository_id, name, full_name FROM repositories "
        f"WHERE torana_repository_id LIKE {like} OR name = {_sql_quote(repo)} "
        f"OR full_name = {_sql_quote(repo)}"
    )
    try:
        data = client.post("/query", json={"query": sql})
    except (APIError, AuthError):
        data = None

    rows = (data or {}).get("results") if isinstance(data, dict) else None
    rows = rows or []
    if not rows:
        click.echo(f"ERROR: no repository matches {repo!r}.", err=True)
        raise SystemExit(3)

    if len(rows) > 1:
        exact = [
            r for r in rows
            if r.get("name") == repo
            or r.get("full_name") == repo
            or str(r.get("torana_repository_id", "")).endswith("/" + repo)
        ]
        if len(exact) == 1:
            rows = exact
        else:
            candidates = "\n  ".join(str(r.get("torana_repository_id")) for r in rows[:10])
            click.echo(
                f"ERROR: {repo!r} is ambiguous; matches:\n  {candidates}\n"
                "Pass the full repo: key to disambiguate.",
                err=True,
            )
            raise SystemExit(6)

    return str(rows[0]["torana_repository_id"])


def list_repositories_core(ctx, *, repo=None, owner=None, provider=None,
                           limit=None, offset=None, page=None, page_size=None):
    """Shared list routine. One implementation so any future workspace-scoped
    repository list can never drift from the top-level one."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    from torana_cli.pagination import resolve_limit_offset
    limit, offset = resolve_limit_offset(page, page_size, limit, offset, default_limit=50)

    client = _client(ctx)

    params = {"limit": limit, "offset": offset}
    eq_filters = {}
    if repo:
        # Exact-key filter. Resolve a partial reference first so `--repo <name>`
        # behaves the same here as it does on `vulnerabilities list --repo`.
        repo_key = repo if repo.startswith("repo:") else resolve_repository_key(client, repo)
        params["torana_repository_id"] = repo_key
        eq_filters["torana_repository_id"] = repo_key
    if owner:
        params["asset_owner_email"] = owner
        eq_filters["asset_owner_email"] = owner
    if provider:
        params["provider"] = provider
        eq_filters["provider"] = provider

    try:
        data = client.get("/tables/repositories/data", params=params)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    normalized = _normalize_list_response(data)
    total = _count_repositories(client, eq_filters)
    if total is not None:
        normalized["total"] = total
        normalized["page_count"] = len(normalized.get("items", []))
    output(normalized, fmt=fmt, raw=raw, fields=fields, columns=_REPO_COLS)


@click.group()
def repositories():
    """Query repository records in the datalake (collection operations).

    \b
    Instance commands (get) are under:
      torana repository <KEY> <verb>

    \b
    Examples:
      torana repositories list
      torana repositories list --repo github.com/acme/api
      torana repositories list --owner sec@acme.com --format json
    """


@repositories.command(name="list")
@click.option("--repo", default=None,
              help="Filter to one repository (full repo: key, org/name, or bare name).")
@click.option("--owner", default=None, help="Filter by asset owner email.")
@click.option("--provider", default=None, help="Filter by provider (github, gitlab, ...).")
@click.option("--limit", type=int, default=None, help="Max rows to return (default 50).")
@click.option("--offset", type=int, default=None, help="Rows to skip.")
@click.option("--page", type=int, default=None, help="Page number (alias for offset).")
@click.option("--page-size", type=int, default=None, help="Page size (alias for limit).")
@click.pass_context
def repositories_list(ctx, repo, owner, provider, limit, offset, page, page_size):
    """List repository asset records from the datalake.

    \b
    Examples:
      torana repositories list
      torana repositories list --repo github.com/acme/api
      torana repositories list --provider github --limit 20
    """
    list_repositories_core(ctx, repo=repo, owner=owner, provider=provider,
                           limit=limit, offset=offset, page=page, page_size=page_size)
