"""torana repositories — query datalake repository (asset-inventory) records.

All reads use the datalake's /tables/repositories/data endpoint — the same sink
table `ingest assets` writes and `govern repo` annotates.

Instance commands (get) are under: torana repository <KEY> <verb>

Why this exists (CLI-17): the `repositories` sink table had NO CLI read at all,
while the API and FE both surfaced the row — a surface-parity violation. Worse,
the `torana-asset-inventory` skill's idempotency guard shells
`torana repositories list --raw | grep <repo>`; against a nonexistent command that
grep silently fails, the guard reads "not found", and a duplicate repository asset
is created on every run.
"""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output


_REPO_COLS = [
    ("torana_repository_id", "KEY", 44),
    ("name", "NAME", 28),
    ("provider", "PROVIDER", 10),
    ("visibility", "VISIBILITY", 10),
    ("criticality_name", "CRITICALITY", 12),
    ("asset_owner_email", "OWNER", 28),
    ("environment", "ENV", 10),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _normalize_list_response(data: dict) -> dict:
    """Normalize the datalake /tables/{name}/data response to {items, total}."""
    if isinstance(data, dict):
        if "data" in data:
            return {"items": data["data"], "total": data.get("count", len(data["data"]))}
        if "items" in data:
            return data
    return {"items": data if isinstance(data, list) else [], "total": 0}


def _sql_quote(value: str) -> str:
    """Single-quote a SQL literal, escaping embedded quotes."""
    return "'" + str(value).replace("'", "''") + "'"


def _count_repositories(client, filters: dict):
    """Accurate total via COUNT(*). Returns int or None when unavailable.

    The datalake list endpoint returns only the page count, so without this a
    caller can't tell "20 shown" from "20 total" without paging everything.
    """
    where = ""
    if filters:
        clauses = [f"{k} = {_sql_quote(v)}" for k, v in filters.items() if v is not None]
        if clauses:
            where = " WHERE " + " AND ".join(clauses)
    sql = "SELECT count(*) AS n FROM repositories" + where
    try:
        data = client.post("/query", json={"query": sql})
    except (APIError, AuthError):
        return None
    rows = data.get("results") if isinstance(data, dict) else None
    if rows and isinstance(rows, list) and isinstance(rows[0], dict):
        first = rows[0]
        return first.get("n", next(iter(first.values()), None))
    return None


def resolve_repository_key(client, repo: str) -> str:
    """Resolve a user-supplied repo reference to its canonical torana_repository_id.

    Accepts the full source-neutral key (`repo:github.com/org/name`), an
    `org/name` pair, or a bare repo name. Mirrors the resolution already used by
    `vulnerabilities list --repo` so the two surfaces agree on what a repo
    reference means.

    Exits 3 when nothing matches and 6 when the reference is ambiguous — an
    ambiguous match must never silently pick one row.
    """
    if repo.startswith("repo:"):
        return repo

    like = _sql_quote(f"%{repo}%")
    sql = (
        "SELECT torana_repository_id, name, full_name FROM repositories "
        f"WHERE torana_repository_id LIKE {like} OR name = {_sql_quote(repo)} "
        f"OR full_name = {_sql_quote(repo)}"
    )
    try:
        data = client.post("/query", json={"query": sql})
    except (APIError, AuthError):
        data = None

    rows = (data or {}).get("results") if isinstance(data, dict) else None
    rows = rows or []
    if not rows:
        click.echo(f"ERROR: no repository matches {repo!r}.", err=True)
        raise SystemExit(3)

    if len(rows) > 1:
        exact = [
            r for r in rows
            if r.get("name") == repo
            or r.get("full_name") == repo
            or str(r.get("torana_repository_id", "")).endswith("/" + repo)
        ]
        if len(exact) == 1:
            rows = exact
        else:
            candidates = "\n  ".join(str(r.get("torana_repository_id")) for r in rows[:10])
            click.echo(
                f"ERROR: {repo!r} is ambiguous; matches:\n  {candidates}\n"
                "Pass the full repo: key to disambiguate.",
                err=True,
            )
            raise SystemExit(6)

    return str(rows[0]["torana_repository_id"])


def list_repositories_core(ctx, *, repo=None, owner=None, provider=None,
                           limit=None, offset=None, page=None, page_size=None):
    """Shared list routine. One implementation so any future workspace-scoped
    repository list can never drift from the top-level one."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    from torana_cli.pagination import resolve_limit_offset
    limit, offset = resolve_limit_offset(page, page_size, limit, offset, default_limit=50)

    client = _client(ctx)

    params = {"limit": limit, "offset": offset}
    eq_filters = {}
    if repo:
        # Exact-key filter. Resolve a partial reference first so `--repo <name>`
        # behaves the same here as it does on `vulnerabilities list --repo`.
        repo_key = repo if repo.startswith("repo:") else resolve_repository_key(client, repo)
        params["torana_repository_id"] = repo_key
        eq_filters["torana_repository_id"] = repo_key
    if owner:
        params["asset_owner_email"] = owner
        eq_filters["asset_owner_email"] = owner
    if provider:
        params["provider"] = provider
        eq_filters["provider"] = provider

    try:
        data = client.get("/tables/repositories/data", params=params)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    normalized = _normalize_list_response(data)
    total = _count_repositories(client, eq_filters)
    if total is not None:
        normalized["total"] = total
        normalized["page_count"] = len(normalized.get("items", []))
    output(normalized, fmt=fmt, raw=raw, fields=fields, columns=_REPO_COLS)


@click.group()
def repositories():
    """Query repository records in the datalake (collection operations).

    \b
    Instance commands (get) are under:
      torana repository <KEY> <verb>

    \b
    Examples:
      torana repositories list
      torana repositories list --repo github.com/acme/api
      torana repositories list --owner sec@acme.com --format json
    """


@repositories.command(name="scan-freshness")
@click.option("--stale-after-hours", type=int, default=None,
              help="How long a repository may go unreported before it reads stale "
                   "(default 48h — a daily schedule must survive missing ONE night).")
@click.option("--repo", "repository_id", default=None,
              help="Just one repository (full repo: key).")
@click.option("--state", type=click.Choice(["healthy", "stale", "never_scanned"]),
              default=None, help="Show only repositories in this state.")
@click.pass_context
def repositories_scan_freshness(ctx, stale_after_hours, repository_id, state):
    """Which repositories are still reporting scans — and which stopped.

    \b
    ⛔ WHY THIS EXISTS. GitHub stops running scheduled workflows in a repository with
    no activity for 60 days, and it does so SILENTLY. So a repo can quietly stop being
    scanned while every finding count still reads zero — and a stale zero looks exactly
    like a clean repository.

    \b
    States, which are deliberately three and not two:
      healthy        reported within the window
      stale          reported before, has stopped — find out why
      never_scanned  never reported at all — probably has no workflow

    \b
    Examples:
      torana repositories scan-freshness
      torana repositories scan-freshness --state stale
      torana repositories scan-freshness --stale-after-hours 24 --format json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text")
    raw = ctx.obj.get(CTX_RAW, False)
    fields = ctx.obj.get(CTX_FIELDS)

    params = {}
    if stale_after_hours:
        params["stale_after_hours"] = stale_after_hours
    if repository_id:
        params["repository_id"] = repository_id

    client = _client(ctx)
    try:
        data = client.get("ci/scan-enrolment", params=params or None)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    rows = data.get("repositories") or []
    if state:
        rows = [r for r in rows if r.get("state") == state]

    if fmt == "json":
        output({**data, "repositories": rows}, fmt=fmt, raw=raw, fields=fields)
        return

    counts = data.get("counts") or {}
    click.echo(f"window: {data.get('stale_after_hours')}h   "
               f"healthy={counts.get('healthy', 0)}  "
               f"stale={counts.get('stale', 0)}  "
               f"never_scanned={counts.get('never_scanned', 0)}")
    # ⚠️ `columns` is a list of (field, HEADER, width) triples, not field names —
    # `_print_columns` unpacks three values. A list of strings raises
    # "too many values to unpack" only once there is a ROW to print, so an empty
    # result set hides it (MEASURED on demo 2026-10-02: the API call succeeded and
    # the counts printed, then the table crashed).
    # ⚠️ width None = never truncate: a repository id that cannot be copied back
    # into `--repo` is useless.
    output(rows, fmt=fmt, raw=raw, fields=fields,
           columns=[("state", "STATE", 14),
                    ("repository_name", "REPOSITORY", 36),
                    ("last_scan_date", "LAST FULL SCAN", 26),
                    ("torana_repository_id", "TORANA ID", None)])


@repositories.command(name="pr-findings")
@click.option("--repo", "repository_id", required=True,
              help="Repository key (repo:github.com/org/name).")
@click.option("--pr", "pr_number", type=int, required=True, help="Pull request number.")
@click.option("--new-only", is_flag=True, default=False,
              help="Only what this PR INTRODUCED — the set the gate judges.")
@click.pass_context
def repositories_pr_findings(ctx, repository_id, pr_number, new_only):
    """Findings a pull request's branch currently shows, and the gate's verdict.

    \b
    ⛔ THESE ARE NOT INVENTORY. They describe a branch, which is a proposal — nothing
    that counts findings, ranks exposure or reports posture reads them. They are
    promoted by RE-SCANNING THE MERGED TREE when the PR merges, and deleted when it
    closes.

    \b
    Two columns carry the gate's decision:
      delta_class   new | unchanged  — only `new` is judged
      gate_verdict  blocking | warning

    \b
    ⚠️ A `blocking` row does not mean the merge was blocked. Enforcement needs
    `build_block_requires_security_review` ratified; until then the check concludes
    success and the verdicts show what ratifying it would start blocking.

    \b
    Examples:
      torana repositories pr-findings --repo repo:github.com/acme/api --pr 412
      torana repositories pr-findings --repo repo:github.com/acme/api --pr 412 --new-only
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text")
    raw = ctx.obj.get(CTX_RAW, False)
    fields = ctx.obj.get(CTX_FIELDS)

    params = {"repository_id": repository_id, "pr_number": pr_number}
    if new_only:
        params["delta_class"] = "new"

    client = _client(ctx)
    try:
        data = client.get("ci/pull-request-findings", params=params)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    rows = data.get("findings") or []
    if fmt == "json":
        output(data, fmt=fmt, raw=raw, fields=fields)
        return
    click.echo(f"{repository_id}#{pr_number}   total={data.get('count', 0)}  "
               f"new={data.get('new_count', 0)}  "
               f"blocking={data.get('blocking_count', 0)}   (branch state, not inventory)")
    # (field, HEADER, width) triples — see the note in scan-freshness.
    # ⚠️ torana_vulnerability_id is width None: it is the argument to `pr-triage
    # --finding`, so truncating it would make the next command impossible to run.
    output(rows, fmt=fmt, raw=raw, fields=fields,
           columns=[("delta_class", "DELTA", 10),
                    ("gate_verdict", "VERDICT", 9),
                    ("severity", "SEVERITY", 10),
                    ("scan_type", "TYPE", 8),
                    ("file_path", "FILE", 44),
                    ("line", "LINE", 6),
                    ("rule_id", "RULE", 30),
                    ("torana_vulnerability_id", "TORANA ID", None)])


@repositories.command(name="list")
@click.option("--repo", default=None,
              help="Filter to one repository (full repo: key, org/name, or bare name).")
@click.option("--owner", default=None, help="Filter by asset owner email.")
@click.option("--provider", default=None, help="Filter by provider (github, gitlab, ...).")
@click.option("--limit", type=int, default=None, help="Max rows to return (default 50).")
@click.option("--offset", type=int, default=None, help="Rows to skip.")
@click.option("--page", type=int, default=None, help="Page number (alias for offset).")
@click.option("--page-size", type=int, default=None, help="Page size (alias for limit).")
@click.pass_context
def repositories_list(ctx, repo, owner, provider, limit, offset, page, page_size):
    """List repository asset records from the datalake.

    \b
    Examples:
      torana repositories list
      torana repositories list --repo github.com/acme/api
      torana repositories list --provider github --limit 20
    """
    list_repositories_core(ctx, repo=repo, owner=owner, provider=provider,
                           limit=limit, offset=offset, page=page, page_size=page_size)
