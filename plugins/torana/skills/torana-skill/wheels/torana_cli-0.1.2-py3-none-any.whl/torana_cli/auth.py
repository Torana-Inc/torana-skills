"""torana auth — authentication commands."""

import sys

import click

from torana_cli.client.auth import (
    AuthError,
    get_access_token,
    get_token_info,
    login as do_login,
    logout as do_logout,
    save_credential,
    _load_cached_token,
    _load_credentials,
    _save_cached_token,
)
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_PROFILE, CTX_RAW, CTX_FORMAT, CTX_FIELDS
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.output import output
from torana_cli.rules import _load_input_file


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group()
def auth():
    """Authenticate and manage sessions.

    \b
    Examples:
      torana auth login --email <your-email> --password '<your-password>'
      torana auth status
      torana auth token
      torana auth logout
    """


@auth.command()
@click.option("--email", default=None, help="Account email address (required for password login).")
@click.option(
    "--password",
    default=None,
    help="Account password. Use --password-stdin to read from stdin.",
)
@click.option(
    "--password-stdin",
    is_flag=True,
    default=False,
    help="Read password from stdin (safer in CI/CD).",
)
@click.option(
    "--save-credentials/--no-save-credentials",
    default=True,
    help="Save email/password to ~/.torana/credentials.yaml for auto-refresh.",
)
@click.option(
    "--web",
    is_flag=True,
    default=False,
    help="Authenticate via browser (OAuth 2.0 with PKCE).",
)
@click.option(
    "--no-browser",
    is_flag=True,
    default=False,
    help="With --web: print URL instead of opening browser; prompts for code interactively.",
)
@click.option(
    "--print-url",
    is_flag=True,
    default=False,
    help="With --web --no-browser: non-interactive two-step flow. Step 1 prints URL and exits; "
         "Step 2 uses --code to exchange the token.",
)
@click.option(
    "--code",
    default=None,
    help="With --web --no-browser --print-url: the authorization code from the browser (Step 2).",
)
@click.option(
    "--debug",
    is_flag=True,
    default=False,
    help="Print debug info during OAuth exchange (base_url, redirect_uri, POST URL, etc.).",
)
@click.pass_context
def login(ctx, email, password, password_stdin, save_credentials, web, no_browser, print_url, code, debug):
    """Log in and cache a JWT token.

    \b
    Password login:
      torana auth login --email <your-email> --password '<your-password>'
      echo '<your-password>' | torana auth login --email <your-email> --password-stdin

    \b
    Headless OAuth (interactive — prompts for code in terminal):
      torana auth login --web --no-browser

    \b
    Headless OAuth (non-interactive two-step — for bash_tool / CI / non-interactive shells):
      torana auth login --web --no-browser --print-url   # Step 1: prints URL and exits
      torana auth login --web --no-browser --code <code> # Step 2: exchanges token

    \b
    Interactive browser login (opens browser automatically):
      torana auth login --web
    """
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    if web:
        # --- OAuth browser login ---
        from torana_cli.client.oauth import browser_login, headless_login

        try:
            if no_browser and (print_url or code):
                # Two-step non-blocking flow:
                #   --print-url        → Step 1 (print URL, save state, exit)
                #   --code <code>      → Step 2 (exchange code, exit)
                token_data = headless_login(settings.base_url, auth_code=code, debug=debug)
                if token_data is None:
                    # Step 1 complete — URL printed, exits without blocking
                    return
            elif no_browser:
                # Original interactive flow — blocks on stdin for code
                token_data = headless_login(settings.base_url, auth_code=None, interactive=True, debug=debug)
            else:
                token_data = browser_login(settings.base_url, no_browser=False)
        except AuthError as e:
            click.echo(f"\nERROR: {e}", err=True)
            sys.exit(5)

        claims = get_token_info(token_data["access_token"])
        email_display = token_data.get("email") or claims.get("email", "unknown")
        tenant_id = claims.get("tenant_id", "unknown")
        exp = claims.get("exp")

        click.echo(f"\nLogged in as {email_display} (via OAuth)")
        click.echo(f"Tenant: {tenant_id}")
        if exp:
            import datetime
            expires = datetime.datetime.fromtimestamp(exp).strftime("%Y-%m-%d %H:%M:%S")
            click.echo(f"Token expires: {expires}")
        click.echo("Token cached at ~/.torana/cache/token.json")
        return

    # --- Password login (existing flow) ---
    if not email:
        click.echo(
            "ERROR: --email is required for password login. "
            "Use --web for browser-based OAuth login.",
            err=True,
        )
        sys.exit(2)

    if password_stdin:
        password = click.get_text_stream("stdin").readline().strip()
        if not password:
            click.echo("ERROR: No password provided via stdin.", err=True)
            sys.exit(2)
    elif not password:
        click.echo("ERROR: Provide --password or use --password-stdin.", err=True)
        sys.exit(2)

    try:
        token_data = do_login(settings.base_url, email, password, profile)
    except AuthError as e:
        click.echo(f"\nERROR: {e}", err=True)
        sys.exit(5)

    if save_credentials:
        save_credential(email, password)

    claims = get_token_info(token_data["access_token"])
    tenant_id = claims.get("tenant_id", "unknown")
    exp = claims.get("exp")

    click.echo(f"Logged in as {email}")
    click.echo(f"Tenant: {tenant_id}")
    click.echo(f"Profile: {token_data.get('profile')}")
    if exp:
        import datetime
        expires = datetime.datetime.fromtimestamp(exp).strftime("%Y-%m-%d %H:%M:%S")
        click.echo(f"Token expires: {expires}")
    click.echo(f"Token cached for profile '{token_data.get('profile')}'.")


@auth.command()
@click.option("--server", is_flag=True, default=False,
              help="Also revoke the token server-side (denylist it), not just locally.")
@click.pass_context
def logout(ctx, server):
    """Log out and remove the cached token for the active profile.

    By default this is LOCAL ONLY: it clears the cached token but the token
    itself stays valid at the edge until it expires naturally. Pass --server to
    also revoke it, which denylists the jti so it is rejected immediately.

    \b
    Example:
      torana auth logout
      torana auth logout --server
      torana --profile production auth logout
    """
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    if server:
        # Revoke BEFORE clearing the local cache — the call needs the token.
        try:
            _client(ctx).post("auth/logout", json={})
            click.echo("Token revoked server-side.")
        except Exception as exc:
            # Never block the local logout on a failed revoke; the user asked to
            # be logged out and must end up logged out either way.
            click.echo(f"Warning: server-side revoke failed ({exc}). "
                       f"Clearing the local cache anyway; the token remains valid "
                       f"until it expires.", err=True)

    do_logout(profile)
    click.echo(f"Logged out of profile '{settings.active_profile}'. Token cache cleared.")


@auth.command(name="set-token")
@click.argument("access_token")
@click.option(
    "--refresh-token",
    default=None,
    help="Optional refresh token.",
)
@click.pass_context
def set_token(ctx, access_token, refresh_token):
    """Save a pre-obtained access token to the local cache.

    Use this when the CLI cannot exchange the OAuth code directly
    (e.g. inside the Claude Desktop sandbox). Copy the access token
    shown on the browser page after OAuth consent and paste it here.

    \b
    Example:
      torana auth set-token eyJhbGci...
      torana auth set-token eyJhbGci... --refresh-token eyJhbGci...
    """
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    try:
        claims = get_token_info(access_token)
    except Exception as e:
        click.echo(f"ERROR: Could not decode token — is it a valid JWT? ({e})", err=True)
        sys.exit(2)

    email = claims.get("email", "")
    tenant_id = claims.get("tenant_id", "unknown")
    exp = claims.get("exp")

    token_data = {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "base_url": settings.base_url,
        "email": email,
        "auth_method": "oauth",
        "profile": settings.active_profile,
    }
    _save_cached_token(token_data, profile)

    click.echo("Token saved.")
    click.echo(f"Email:  {email}")
    click.echo(f"Tenant: {tenant_id}")
    if exp:
        import datetime
        expires = datetime.datetime.fromtimestamp(exp).strftime("%Y-%m-%d %H:%M:%S")
        click.echo(f"Expires: {expires}")
    click.echo("Token cached at ~/.torana/cache/token.json")


@auth.command()
@click.pass_context
def status(ctx):
    """Show current authentication status.

    \b
    Example:
      torana auth status
    """
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    cached = _load_cached_token()
    if not cached:
        click.echo("Status: NOT authenticated")
        click.echo("Run 'torana auth login' to authenticate.")
        sys.exit(5)

    access_token = cached.get("access_token", "")
    from torana_cli.client.auth import _is_token_expired
    expired = _is_token_expired(access_token)

    # An expired ACCESS token does NOT mean you are logged out. Before every API call,
    # get_access_token() transparently recovers an expired access token via, in order:
    #   1. the cached refresh_token, then
    #   2. saved credentials (credentials.yaml) for a password-auth profile.
    # If EITHER path is available, the session is healthy and the next command will just work —
    # reporting "EXPIRED / re-authenticate / exit 5" here is a false alarm (it is exactly what made
    # a slow-but-healthy bootstrap look broken). Only when the access token is expired AND neither
    # recovery path exists is re-authentication actually required.
    if expired:
        has_refresh = bool(cached.get("refresh_token"))
        auth_method = cached.get("auth_method", "password")
        email = cached.get("email")
        has_saved_creds = bool(
            auth_method == "password" and email and _load_credentials().get(email)
        )
        recoverable = has_refresh or has_saved_creds

        if not recoverable:
            # Genuinely stuck — no refresh token and no saved credentials to renew with.
            click.echo("Status: token EXPIRED")
            click.echo("Run 'torana auth login' to re-authenticate.")
            sys.exit(5)

        # Healthy: the access token is stale but will auto-refresh on the next call. Say so
        # calmly and exit 0 — do NOT tell the user to re-authenticate.
        how = "refresh token" if has_refresh else "saved credentials"
        claims = get_token_info(access_token) or {}
        email_disp = cached.get("email", claims.get("email", "unknown"))
        tenant_id = claims.get("tenant_id", "unknown")
        click.echo("Status: authenticated (access token stale — will auto-refresh on next call)")
        click.echo(f"Email:  {email_disp}")
        click.echo(f"Tenant: {tenant_id}")
        click.echo(f"Method: {auth_method}")
        click.echo(f"Profile: {settings.active_profile}")
        click.echo(f"Renews via: {how}")
        click.echo(f"Target:  {settings.base_url}")
        return

    claims = get_token_info(access_token)
    email = cached.get("email", claims.get("email", "unknown"))
    tenant_id = claims.get("tenant_id", "unknown")
    auth_method = cached.get("auth_method", "password")
    exp = claims.get("exp")

    click.echo("Status: authenticated")
    click.echo(f"Email:  {email}")
    click.echo(f"Tenant: {tenant_id}")
    click.echo(f"Method: {auth_method}")
    click.echo(f"Profile: {settings.active_profile}")
    if exp:
        import datetime
        remaining = max(0, int(exp - __import__("time").time()))
        expires = datetime.datetime.fromtimestamp(exp).strftime("%Y-%m-%d %H:%M:%S")
        click.echo(f"Expires: {expires} ({remaining}s remaining)")
    click.echo(f"Target:  {settings.base_url}")


@auth.command(name="token")
@click.pass_context
def get_token(ctx):
    """Print the current access token (for use in scripts).

    \b
    Example:
      export TOKEN=$(torana auth token)
      curl -H "Authorization: Bearer $TOKEN" http://localhost/api/v1/rules/
    """
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    try:
        token = get_access_token(settings.base_url)
    except AuthError as e:
        click.echo(f"\nERROR: {e}", err=True)
        sys.exit(5)

    # Print bare token (for shell capture)
    click.echo(token, nl=False)


@auth.command()
@click.pass_context
def refresh(ctx):
    """Force a token refresh.

    \b
    Example:
      torana auth refresh
    """
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    cached = _load_cached_token()
    if not cached:
        click.echo("ERROR: Not authenticated. Run 'torana auth login'.", err=True)
        sys.exit(5)

    refresh_tok = cached.get("refresh_token")
    if not refresh_tok:
        click.echo("ERROR: No refresh token in cache. Run 'torana auth login'.", err=True)
        sys.exit(5)

    from torana_cli.client.auth import refresh_token
    try:
        new_data = refresh_token(settings.base_url, refresh_tok, profile)
    except AuthError as e:
        click.echo(f"\nERROR: Token refresh failed: {e}", err=True)
        sys.exit(5)

    claims = get_token_info(new_data["access_token"])
    exp = claims.get("exp")
    if exp:
        import datetime
        expires = datetime.datetime.fromtimestamp(exp).strftime("%Y-%m-%d %H:%M:%S")
        click.echo(f"Token refreshed. New expiry: {expires}")
    else:
        click.echo("Token refreshed.")


@auth.command()
@click.pass_context
def diagnose(ctx):
    """Diagnose the current session: token lifetimes, clock skew, edge gate.

    The CLI surface for session diagnostics (the FE has the equivalent SA panel).
    Answers "is my session healthy, and if not, why" without needing to decode a
    JWT by hand.

    \b
    Exit codes:
      0  healthy
      1  degraded (something is wrong but a session exists)
      5  no session

    \b
    Example:
      TORANA_PROFILE=T1 torana auth diagnose
    """
    import base64
    import json as _json
    import time

    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    cached = _load_cached_token()
    if not cached:
        click.echo("No session. Run 'torana auth login'.")
        sys.exit(5)

    def _claims(tok):
        """Decode a JWT payload. Never raises — returns {} on anything malformed."""
        try:
            part = tok.split(".")[1]
            part += "=" * (-len(part) % 4)
            return _json.loads(base64.urlsafe_b64decode(part))
        except Exception:
            return {}

    def _describe(tok, label):
        c = _claims(tok)
        if not c:
            click.echo(f"  {label:<9} (unparseable)")
            return None
        now = time.time()
        exp, iat = c.get("exp"), c.get("iat")
        left = int(exp - now) if exp else None
        life = round((exp - iat) / 60, 1) if (exp and iat) else None
        state = "EXPIRED" if (left is not None and left <= 0) else "ok"
        click.echo(
            f"  {label:<9} {state:<8} expires_in={left}s  lifetime={life}min  "
            f"type={c.get('token_type', '(absent)')}  epoch={c.get('token_epoch')}"
        )
        return c

    degraded = False

    click.echo(f"Profile   {settings.active_profile}  ->  {settings.base_url}")
    click.echo("Token")
    a = _describe(cached.get("access_token", ""), "access")
    r = _describe(cached.get("refresh_token", ""), "refresh")

    if not r:
        click.echo("  WARNING: no refresh token — this session cannot renew itself.")
        degraded = True

    # token_type is only present on tokens minted after the Release A deploy.
    # Its ABSENCE is informational, not a fault.
    if a and a.get("token_type") is None:
        click.echo("  note: token predates the token_type claim (minted before Release A).")

    # Live checks against the server.
    click.echo("Server")
    try:
        me = _client(ctx).get("users/me")
        click.echo(f"  identity  {me.get('email', '(unknown)')}  tenant={me.get('tenant_id', '?')}")
    except Exception as exc:
        # Clean one-line failure, never a traceback — per the CLI error convention.
        click.echo(f"  identity  FAILED: {type(exc).__name__}: {exc}")
        degraded = True

    try:
        _client(ctx).get("health")
        click.echo("  reachable yes")
    except Exception:
        # /health is not routed on every deployment; a failure here is not
        # itself evidence of a problem, so it does not set `degraded`.
        click.echo("  reachable (health endpoint not available on this target)")

    click.echo(f"Verdict   {'DEGRADED' if degraded else 'healthy'}")
    sys.exit(1 if degraded else 0)


@auth.command(name="oauth-authorization-server")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def well_known_oauth_authorization_server(ctx, page, page_size, fetch_all):
    """Oauth Discovery."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "/.well-known/oauth-authorization-server"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@auth.command(name="sse")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def well_known_sse(ctx, page, page_size, fetch_all):
    """Oauth Resource Metadata."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "/.well-known/oauth-protected-resource/sse"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@auth.command(name="login-api")
@click.option("--email", "email", required=True)
@click.option("--password", "password", required=True)
@click.pass_context
def auth_login(ctx, email, password):
    """Login."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "auth/login"
    body = {}
    body["email"] = email
    body["password"] = password

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@auth.command(name="refresh-token")
@click.option("--refresh-token", "refresh_token", required=True)
@click.pass_context
def auth_refresh(ctx, refresh_token):
    """Refresh Token (raw API call — use 'auth refresh' for auto-refresh from cache)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "auth/refresh"
    body = {}
    body["refresh_token"] = refresh_token

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@auth.command(name="forgot-password")
@click.pass_context
def auth_forgot_password(ctx):
    """Forgot Password."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "auth/forgot-password"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@auth.command(name="reset-password")
@click.pass_context
def auth_reset_password(ctx):
    """Reset Password."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "auth/reset-password"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@auth.command(name="me")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def auth_me(ctx, page, page_size, fetch_all):
    """Get Current User Info."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "auth/me"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Surface which server this identity was resolved against, so it's obvious
    # at a glance whether you're talking to local / demo / prod.
    if isinstance(data, dict) and "items" not in data:
        data["base_url"] = settings.base_url
        data["profile"] = settings.active_profile

    output(data, fmt=fmt, fields=fields, raw=raw)


@auth.command(name="logout-api")
@click.pass_context
def auth_logout(ctx):
    """Logout (raw API call — use 'auth logout' to also clear local token cache)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "auth/logout"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@auth.command(name="change-password")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with request body. Use '-' for stdin.")
@click.option("--current-password", "current_password", required=True)
@click.option("--new-password", "new_password", required=True)
@click.option("--confirm-password", "confirm_password", required=True)
@click.pass_context
def auth_change_password(ctx, current_password, new_password, confirm_password, input_file):
    """Change Password."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "auth/change-password"
    if input_file:
        body = _load_input_file(input_file)
    else:
        body = {}
        body["current_password"] = current_password
        body["new_password"] = new_password
        body["confirm_password"] = confirm_password

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@auth.command(name="authorize")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--response-type", "response_type", required=True)
@click.option("--client-id", "client_id", required=True)
@click.option("--redirect-uri", "redirect_uri", required=True)
@click.option("--scope", "scope", default=None)
@click.option("--state", "state", default=None)
@click.option("--code-challenge", "code_challenge", default=None)
@click.option("--code-challenge-method", "code_challenge_method", default="S256")
@click.pass_context
def oauth_authorize(ctx, response_type, client_id, redirect_uri, scope, state, code_challenge, code_challenge_method, page, page_size, fetch_all):
    """Oauth Authorize."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "/oauth/authorize"
    params = {}
    if response_type is not None:
        params["response_type"] = response_type
    if client_id is not None:
        params["client_id"] = client_id
    if redirect_uri is not None:
        params["redirect_uri"] = redirect_uri
    if scope is not None:
        params["scope"] = scope
    if state is not None:
        params["state"] = state
    if code_challenge is not None:
        params["code_challenge"] = code_challenge
    if code_challenge_method is not None:
        params["code_challenge_method"] = code_challenge_method
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@auth.command(name="oauth-authorize")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--response-type", "response_type", required=True)
@click.option("--client-id", "client_id", required=True)
@click.option("--redirect-uri", "redirect_uri", required=True)
@click.option("--scope", "scope", default=None)
@click.option("--state", "state", default=None)
@click.option("--code-challenge", "code_challenge", default=None)
@click.option("--code-challenge-method", "code_challenge_method", default="S256")
@click.pass_context
def oauth_login(ctx, response_type, client_id, redirect_uri, scope, state, code_challenge, code_challenge_method, page, page_size, fetch_all):
    """Oauth Login Page."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "/oauth/login"
    params = {}
    if response_type is not None:
        params["response_type"] = response_type
    if client_id is not None:
        params["client_id"] = client_id
    if redirect_uri is not None:
        params["redirect_uri"] = redirect_uri
    if scope is not None:
        params["scope"] = scope
    if state is not None:
        params["state"] = state
    if code_challenge is not None:
        params["code_challenge"] = code_challenge
    if code_challenge_method is not None:
        params["code_challenge_method"] = code_challenge_method
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@auth.command(name="login-submit")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with request body. Use '-' for stdin.")
@click.option("--email", "email", required=True)
@click.option("--password", "password", required=True)
@click.option("--response-type", "response_type", required=True)
@click.option("--client-id", "client_id", required=True)
@click.option("--redirect-uri", "redirect_uri", required=True)
@click.option("--scope", "scope", default=None)
@click.option("--state", "state", default=None)
@click.option("--code-challenge", "code_challenge", default=None)
@click.option("--code-challenge-method", "code_challenge_method", default="S256")
@click.pass_context
def oauth_login_submit(ctx, email, password, response_type, client_id, redirect_uri, scope, state, code_challenge, code_challenge_method, input_file):
    """Oauth Login Submit."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "/oauth/login-submit"
    if input_file:
        body = _load_input_file(input_file)
    else:
        body = {}
        body["email"] = email
        body["password"] = password
        body["response_type"] = response_type
        body["client_id"] = client_id
        body["redirect_uri"] = redirect_uri
        if scope is not None:
            body["scope"] = scope
        if state is not None:
            body["state"] = state
        if code_challenge is not None:
            body["code_challenge"] = code_challenge
        if code_challenge_method is not None:
            body["code_challenge_method"] = code_challenge_method

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ──────────────────────────────────────────────────────────────────────────
# Instance reads regrouped from `<noun>-by-<param>` leaves onto verbs
# (CLI Discoverability Contract, rule 2 — see ../CLAUDE.md). The route
# parameter belongs in the positional ARGUMENT, not the command name.
#
# Old flat names remain as HIDDEN aliases for ONE release (D4).
# ──────────────────────────────────────────────────────────────────────────


@auth.group(name="client")
def auth_client_grp():
    """One OAuth client, by id.

    Examples:
      torana auth client get --help
    """


@auth_client_grp.command(name="get")
@click.argument("CLIENT_ID", metavar="CLIENT_ID")
@click.pass_context
def oauth_clients_by_client_id(ctx, client_id):
    """Get Oauth Client."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"/oauth/clients/{client_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@auth.command(name="consent")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--response-type", "response_type", required=True)
@click.option("--client-id", "client_id", required=True)
@click.option("--redirect-uri", "redirect_uri", required=True)
@click.option("--scope", "scope", default=None)
@click.option("--state", "state", default=None)
@click.option("--code-challenge", "code_challenge", default=None)
@click.option("--code-challenge-method", "code_challenge_method", default="S256")
@click.pass_context
def oauth_consent(ctx, response_type, client_id, redirect_uri, scope, state, code_challenge, code_challenge_method, page, page_size, fetch_all):
    """Show Consent Screen."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "/oauth/consent"
    params = {}
    if response_type is not None:
        params["response_type"] = response_type
    if client_id is not None:
        params["client_id"] = client_id
    if redirect_uri is not None:
        params["redirect_uri"] = redirect_uri
    if scope is not None:
        params["scope"] = scope
    if state is not None:
        params["state"] = state
    if code_challenge is not None:
        params["code_challenge"] = code_challenge
    if code_challenge_method is not None:
        params["code_challenge_method"] = code_challenge_method
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@auth.command(name="consent-submit")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with request body. Use '-' for stdin.")
@click.option("--action", "action", required=True)
@click.option("--scopes", "scopes", default=[])
@click.option("--response-type", "response_type", required=True)
@click.option("--client-id", "client_id", required=True)
@click.option("--redirect-uri", "redirect_uri", required=True)
@click.option("--state", "state", default=None)
@click.option("--code-challenge", "code_challenge", default=None)
@click.option("--code-challenge-method", "code_challenge_method", default="S256")
@click.option("--user-id", "user_id", required=True)
@click.pass_context
def oauth_consent_submit(ctx, action, scopes, response_type, client_id, redirect_uri, state, code_challenge, code_challenge_method, user_id, input_file):
    """Handle Consent Submission."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "/oauth/consent-submit"
    if input_file:
        body = _load_input_file(input_file)
    else:
        body = {}
        body["action"] = action
        if scopes is not None:
            body["scopes"] = scopes
        body["response_type"] = response_type
        body["client_id"] = client_id
        body["redirect_uri"] = redirect_uri
        if state is not None:
            body["state"] = state
        if code_challenge is not None:
            body["code_challenge"] = code_challenge
        if code_challenge_method is not None:
            body["code_challenge_method"] = code_challenge_method
        body["user_id"] = user_id

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ──────────────────────────────────────────────────────────────────────────
# BACK-COMPAT — hidden aliases for the old `<noun>-by-<param>` names.
# ⏳ ONE RELEASE ONLY (decision D4). Delete this block next release.
# ──────────────────────────────────────────────────────────────────────────

_LEGACY_BY_PARAM_AUTH = {
    "clients-by-client-id": ("client", "get"),
}


def _register_legacy_auth_by_param() -> None:
    """Old flat names, hidden so they cannot be discovered anew."""
    import copy
    for _old, (_sub, _verb) in _LEGACY_BY_PARAM_AUTH.items():
        _grp = auth.commands.get(_sub)
        if not isinstance(_grp, click.Group):
            continue
        _cmd = _grp.commands.get(_verb)
        if _cmd is None:
            continue
        # ⛔ Never let an alias overwrite a real group of the same name.
        if isinstance(auth.commands.get(_old), click.Group):
            continue
        _alias = copy.copy(_cmd)
        _alias.name = _old
        _alias.hidden = True
        auth.add_command(_alias)


_register_legacy_auth_by_param()
