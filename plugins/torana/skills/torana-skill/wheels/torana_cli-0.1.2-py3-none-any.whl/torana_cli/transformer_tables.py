"""torana transformer-tables — data transformer output table commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm

_LIST_COLS = [
    ("name", "TABLE", 40),
    ("transformer_id", "TRANSFORMER_ID", 36),
    ("row_count", "ROWS", 10),
    ("last_updated", "LAST UPDATED", 20),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(name="transformer-tables")
def transformer_tables():
    """Manage transformer output tables.

    \b
    Examples:
      torana transformer-tables list
      torana transformer-tables get <TABLE_NAME>
      torana transformer-tables clear <TABLE_NAME>
      torana transformer-tables drop <TABLE_NAME> --yes
    """


@transformer_tables.command(name="list")
@click.option("--transformer-id", default=None, help="Filter by transformer UUID.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def transformer_tables_list(ctx, transformer_id, page, page_size):
    """List transformer output tables."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if transformer_id:
        params["transformer_id"] = transformer_id

    client = _client(ctx)
    try:
        # No trailing slash — the route is registered at "" and a trailing slash 404s.
        data = client.get("transformer-tables", params=params)
        if isinstance(data, dict) and "items" in data:
            result = data
        else:
            # The endpoint returns {"tables": [<name>, ...], "count": N}.
            if isinstance(data, dict):
                rows = data.get("tables") or []
            elif isinstance(data, list):
                rows = data
            else:
                rows = []
            items = [r if isinstance(r, dict) else {"name": r} for r in rows]
            result = {
                "items": items,
                "total": data.get("count", len(items)) if isinstance(data, dict) else len(items),
                "page": page, "page_size": effective_page_size
            }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@transformer_tables.command(name="get")
@click.argument("table_name", metavar="TABLE_NAME")
@click.pass_context
def transformer_tables_get(ctx, table_name):
    """Get details and schema for a transformer table."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"transformer-tables/{table_name}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@transformer_tables.command(name="create")
@click.option("--name", required=True, help="Table name.")
@click.option("--transformer-id", default=None, help="Associated transformer UUID.")
@click.option("--file", "input_file", default=None, metavar="FILE",
              help="YAML/JSON with table schema definition.")
@click.pass_context
def transformer_tables_create(ctx, name, transformer_id, input_file):
    """Create a transformer output table."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {"name": name}
    if input_file:
        file_body = _load_input_file(input_file)
        body.update(file_body)
    if transformer_id:
        body["transformer_id"] = transformer_id

    client = _client(ctx)
    try:
        data = client.post("transformer-tables/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created table: {name}")


@transformer_tables.command(name="delete")
@click.argument("table_name", metavar="TABLE_NAME")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def transformer_tables_delete(ctx, table_name, yes):
    """Delete a transformer output table (drops the table record)."""
    _confirm(f"Delete transformer table '{table_name}'?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"transformer-tables/{table_name}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted table: {table_name}")


@transformer_tables.command(name="clear")
@click.argument("table_name", metavar="TABLE_NAME")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def transformer_tables_clear(ctx, table_name, yes):
    """Clear all rows from a transformer table (truncate)."""
    _confirm(f"Clear all data from table '{table_name}'?", yes=yes)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"transformer-tables/{table_name}/clear/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Cleared table: {table_name}")


def _fetch_transformer_table_names(client, workspace_id=None):
    """Every transformer output-table name, paginated to exhaustion."""
    names, page, page_size = [], 1, 100
    while True:
        params = {"skip": (page - 1) * page_size, "limit": page_size}
        if workspace_id:
            params["workspace_id"] = workspace_id
        data = client.get("transformer-tables", params=params)
        if isinstance(data, dict) and "items" in data:
            rows = data.get("items") or []
        elif isinstance(data, dict):
            rows = data.get("tables") or []
        else:
            rows = data if isinstance(data, list) else []
        if not rows:
            break
        for r in rows:
            name = r.get("name") or r.get("table_name") if isinstance(r, dict) else r
            if name:
                names.append(name)
        if len(rows) < page_size:
            break
        page += 1
    # De-dupe, preserving discovery order.
    seen, ordered = set(), []
    for n in names:
        if n not in seen:
            seen.add(n)
            ordered.append(n)
    return ordered


@transformer_tables.command(name="clear-all")
@click.option("--workspace-id", default=None, help="Only clear tables in this workspace.")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def transformer_tables_clear_all(ctx, workspace_id, yes):
    """Clear all rows from EVERY transformer output table (structure is kept).

    The transformer-layer counterpart to `torana datalake clear-all`, which only
    clears the sink tables. Transformers are upsert-based, so re-running them
    against empty sinks does NOT remove existing output rows — clearing the
    outputs first is what makes a rebuild actually rebuild.

    \b
    Examples:
      torana transformer-tables clear-all --yes
      torana transformer-tables clear-all --workspace-id <UUID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        names = _fetch_transformer_table_names(client, workspace_id)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if not names:
        click.echo("No transformer output tables found. Nothing to clear.")
        return

    if not yes:
        click.echo(f"This will delete ALL rows from {len(names)} transformer table(s):")
        for name in names:
            click.echo(f"  {name}")
        _confirm("Proceed with clearing all transformer tables?", yes=False)
    cleared, failed = [], []
    for name in names:
        try:
            client.post(f"transformer-tables/{name}/clear/")
            cleared.append(name)
            if fmt == "text":
                click.echo(f"  \u2713 {name}")
        except (APIError, AuthError) as e:
            failed.append({"table": name, "error": str(e)})
            if fmt == "text":
                click.echo(f"  \u2717 {name}: {e}", err=True)

    if fmt != "text":
        output({"cleared": cleared, "failed": failed,
                "total": len(names), "cleared_count": len(cleared),
                "failed_count": len(failed)}, fmt=fmt)
    else:
        click.echo(f"Cleared {len(cleared)}/{len(names)} transformer table(s).")

    if failed:
        import sys
        sys.exit(1)


@transformer_tables.command(name="drop")
@click.argument("table_name", metavar="TABLE_NAME")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def transformer_tables_drop(ctx, table_name, yes):
    """Drop a transformer table from the database."""
    _confirm(f"Permanently drop table '{table_name}' from the database?", yes=yes)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        # Route is DELETE /transformer-tables/{name}/drop (no trailing slash).
        data = client.delete(f"transformer-tables/{table_name}/drop")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Dropped table: {table_name}")


@transformer_tables.command(name="summary")
@click.argument("TABLE_NAME", metavar="TABLE_NAME")
@click.pass_context
def transformer_tables_summary(ctx, table_name):
    """Get table summary."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"transformer-tables/{table_name}/summary"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@transformer_tables.command(name="data")
@click.argument("TABLE_NAME", metavar="TABLE_NAME")
@click.option("--limit", "limit", type=int, default=100)
@click.pass_context
def transformer_tables_data(ctx, table_name, limit):
    """Get table data."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"transformer-tables/{table_name}/data"
    params = {}
    if limit is not None:
        params["limit"] = limit

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)
