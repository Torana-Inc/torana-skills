"""torana tokens — the platform's sign-in tokens: list, inspect, revoke, clean up."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.confirm import confirm as _confirm

# The API's token records are the platform's own sign-in tokens (ACCESS / REFRESH): they have a type, an owner, a lifetime and a
# revocation, and no name, prefix or scopes.
_LIST_COLS = [
    ("id", "ID", 36),
    ("token_type", "TYPE", 8),
    ("created_at", "CREATED", 20),
    ("expires_at", "EXPIRES", 20),
    ("revoked_at", "REVOKED", 20),
    ("revocation_reason", "REASON", 18),
    ("usage_count", "USED", 5),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group()
def tokens():
    """Inspect and revoke the platform's sign-in tokens (access and refresh).

    These are the tokens people and the CLI hold after signing in, each with a type, an owner, a lifetime and a revocation. They have no
    name or scopes, and there is no command to create one: signing in issues them.

    \b
    Examples:
      torana tokens list --type REFRESH --active
      torana tokens get <TOKEN_ID>
      torana tokens statistics
      torana tokens revoke-token <TOKEN_ID>
      torana tokens revoke-admin <USER_ID> --reason "incident response"
      torana tokens cleanup-expired
    """


@tokens.command(name="list")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int, help="Results per page (max 100).")
@click.option("--type", "token_type", default=None, type=click.Choice(["ACCESS", "REFRESH"], case_sensitive=False),
              help="Only this token type.")
@click.option("--user-id", default=None, help="Only this user's tokens.")
@click.option("--active/--inactive", "is_active", default=None, help="Only active (not revoked, not expired) or only inactive tokens.")
@click.pass_context
def tokens_list(ctx, page, page_size, token_type, user_id, is_active):
    """List the platform's sign-in tokens (access and refresh), newest first.

    \b
    Examples:
      torana tokens list
      torana tokens list --type REFRESH --active
      torana tokens list --json | jq '.items[] | {id, token_type, expires_at}'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"page": page, "page_size": effective_page_size}
    if token_type:
        params["token_type"] = token_type.upper()
    if user_id:
        params["user_id"] = user_id
    if is_active is not None:
        params["is_active"] = str(is_active).lower()

    client = _client(ctx)
    try:
        data = client.get("tokens/", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    page_info = data.get("pagination", {}) if isinstance(data, dict) else {}
    items = data.get("items", []) if isinstance(data, dict) else (data if isinstance(data, list) else [])
    result = {"items": items, "total": page_info.get("total_count", len(items)),
              "page": page_info.get("page", page), "page_size": page_info.get("page_size", effective_page_size)}
    if fmt != "text" and page_info:
        result["pagination"] = page_info
    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@tokens.command(name="get")
@click.argument("token_id", metavar="TOKEN_ID")
@click.pass_context
def tokens_get(ctx, token_id):
    """Get details for a specific token.

    \b
    Examples:
      torana tokens list                       # find the id
      torana tokens get <TOKEN_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"tokens/{token_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@tokens.command(name="statistics")
@click.option("--tenant-id", "tenant_id", default=None, help="Filter by tenant ID")
@click.option("--hours", "hours", type=int, default=24, help="Look back this many hours (1-168).")
@click.pass_context
def tokens_statistics(ctx, tenant_id, hours):
    """Token counts: total, active, expired, revoked, expiring in 24 hours, recent activity and the split by type.

    The result is one summary, not a list, so there is no paging.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    params = {"hours": hours}
    if tenant_id is not None:
        params["tenant_id"] = tenant_id

    client = _client(ctx)
    try:
        data = client.get("tokens/statistics", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@tokens.command(name="revoke-admin")
@click.argument("USER_ID", metavar="USER_ID")
@click.option("--reason", "reason", default=None, help="Reason for revocation")
@click.option("--token-type", "token_type", default=None, help="Token type to revoke")
@click.pass_context
def tokens_revoke_admin(ctx, user_id, reason, token_type):
    """Revoke User Tokens."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"tokens/users/{user_id}/revoke"
    body = {}
    if reason is not None:
        body["reason"] = reason
    if token_type is not None:
        body["token_type"] = token_type

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@tokens.command(name="cleanup-expired")
@click.pass_context
def tokens_cleanup_expired(ctx):
    """Cleanup Expired Tokens."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "tokens/cleanup-expired"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@tokens.command(name="revoke-token")
@click.argument("TOKEN_ID", metavar="TOKEN_ID")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def tokens_revoke_token(ctx, token_id, yes):
    """Revoke a specific token by ID (POST endpoint)."""
    _confirm(f"Revoke token {token_id}?", yes=yes)
    client = _client(ctx)
    try:
        client.post(f"tokens/{token_id}/revoke")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Revoked token: {token_id}")
