"""torana tokens — API token management commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.confirm import confirm as _confirm

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 30),
    ("token_prefix", "PREFIX", 12),
    ("scopes", "SCOPES", 30),
    ("expires_at", "EXPIRES", 20),
    ("is_active", "ACTIVE", 6),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group()
def tokens():
    """Manage API tokens.

    \b
    Examples:
      torana tokens list
      torana tokens get <UUID>
      torana tokens create --name ci-pipeline --scopes read
      torana tokens revoke <UUID>
      torana tokens cleanup
    """


@tokens.command(name="list")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def tokens_list(ctx, page, page_size):
    """List API tokens.

    \b
    Examples:
      torana tokens list
      torana tokens list --json | jq '.items[] | {name, expires_at}'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        data = client.get("tokens/", params=params)
        result = data if isinstance(data, dict) and "items" in data else {
            "items": data if isinstance(data, list) else [],
            "total": len(data) if isinstance(data, list) else 0,
            "page": page, "page_size": effective_page_size
        }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@tokens.command(name="get")
@click.argument("token_id", metavar="TOKEN_ID")
@click.pass_context
def tokens_get(ctx, token_id):
    """Get details for a specific token.

    \b
    Examples:
      torana tokens list                       # find the id
      torana tokens get <TOKEN_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"tokens/{token_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@tokens.command(name="create")
@click.option("--name", required=True, help="Token name.")
@click.option("--scopes", default=None, help="Comma-separated scopes (e.g. read,write).")
@click.option("--expires-in", default=None, type=int,
              help="Expiry in days (omit for no expiry).")
@click.pass_context
def tokens_create(ctx, name, scopes, expires_in):
    """Create a new API token.

    \b
    Examples:
      torana tokens create --name ci-pipeline --expires-in 90d
      torana tokens create --name readonly --scopes "rules:read,alerts:read"

    \b
      ⛔ The token value is shown ONCE, at creation. It cannot be retrieved later —
      capture it now or create a new one.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {"name": name}
    if scopes:
        body["scopes"] = [s.strip() for s in scopes.split(",")]
    if expires_in is not None:
        body["expires_in_days"] = expires_in

    client = _client(ctx)
    try:
        data = client.post("tokens/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created token: {data.get('id', 'unknown')}")
        if data.get("token"):
            click.echo(f"  Token: {data['token']}")
            click.echo("  (Save this value — it will not be shown again.)")


@tokens.command(name="revoke")
@click.argument("token_id", metavar="TOKEN_ID")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def tokens_revoke(ctx, token_id, yes):
    """Revoke an API token."""
    _confirm(f"Revoke token {token_id}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"tokens/{token_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Revoked token: {token_id}")


@tokens.command(name="cleanup")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def tokens_cleanup(ctx, yes):
    """Remove all expired tokens."""
    _confirm("Remove all expired tokens?", yes=yes)
    client = _client(ctx)
    try:
        data = client.post("tokens/cleanup/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if isinstance(data, dict):
        removed = data.get("removed", data.get("count", "?"))
        click.echo(f"Removed {removed} expired token(s).")
    else:
        click.echo("Cleanup complete.")


@tokens.command(name="statistics")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--tenant-id", "tenant_id", default=None, help="Filter by tenant ID")
@click.option("--hours", "hours", type=int, default=24, help="Look back this many hours (max 168 = 7 days)")
@click.pass_context
def tokens_statistics(ctx, tenant_id, hours, page, page_size, fetch_all):
    """Get Token Statistics."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "tokens/statistics"
    params = {}
    if tenant_id is not None:
        params["tenant_id"] = tenant_id
    if hours is not None:
        params["hours"] = hours
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@tokens.command(name="revoke-admin")
@click.argument("USER_ID", metavar="USER_ID")
@click.option("--reason", "reason", default=None, help="Reason for revocation")
@click.option("--token-type", "token_type", default=None, help="Token type to revoke")
@click.pass_context
def tokens_revoke_admin(ctx, user_id, reason, token_type):
    """Revoke User Tokens."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"tokens/users/{user_id}/revoke"
    body = {}
    if reason is not None:
        body["reason"] = reason
    if token_type is not None:
        body["token_type"] = token_type

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@tokens.command(name="cleanup-expired")
@click.pass_context
def tokens_cleanup_expired(ctx):
    """Cleanup Expired Tokens."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "tokens/cleanup-expired"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@tokens.command(name="revoke-token")
@click.argument("TOKEN_ID", metavar="TOKEN_ID")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def tokens_revoke_token(ctx, token_id, yes):
    """Revoke a specific token by ID (POST endpoint)."""
    _confirm(f"Revoke token {token_id}?", yes=yes)
    client = _client(ctx)
    try:
        client.post(f"tokens/{token_id}/revoke")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Revoked token: {token_id}")
