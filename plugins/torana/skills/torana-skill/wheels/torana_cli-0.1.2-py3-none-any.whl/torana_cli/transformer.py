"""torana datalake transformer — per-transformer instance commands."""

import re
import sys

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm

# Imported lazily inside functions to avoid a circular import:
# datalake.py imports this module to attach the group.


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _tid(ctx) -> str:
    return ctx.obj.get("_transformer_id", "") if ctx.obj else ""


_UUID_RE = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I
)


def _resolve_transformer_id(ctx, ident):
    """Accept either a transformer UUID or a destination-table / transformer NAME.

    Table names are what users see in the datalake and in `transformers list`,
    so requiring a UUID would mean a lookup round-trip for every command. A
    UUID-shaped argument is used as-is (no API call); anything else is resolved
    by scanning definitions for a matching destination_table, then name.

    Exits 3 (not found) if nothing matches, and 6 if the name is ambiguous —
    several definitions can share a destination_table, and silently picking one
    would make the command's target depend on list order.
    """
    if _UUID_RE.match(ident or ""):
        return ident

    # Lazy import — datalake.py imports this module, so a top-level import
    # would be circular.
    from torana_cli.datalake import _fetch_all_transformers

    client = _client(ctx)
    try:
        items = _fetch_all_transformers(client)
    except APIError as e:
        handle_api_error(e)
        return None
    except AuthError as e:
        handle_auth_error(e)
        return None

    needle = (ident or "").lower()
    matches = [t for t in items if (t.get("destination_table") or "").lower() == needle]
    if not matches:
        matches = [t for t in items if (t.get("name") or "").lower() == needle]

    if not matches:
        click.echo(f"ERROR: no transformer found for '{ident}'. "
                   f"Try `torana datalake transformers list`.", err=True)
        sys.exit(3)
    if len(matches) > 1:
        click.echo(
            f"ERROR: '{ident}' matches {len(matches)} transformers — pass a UUID instead:",
            err=True)
        for m in matches:
            click.echo(f"  {m.get('id')}  {m.get('name')}", err=True)
        sys.exit(6)
    return matches[0].get("id")


@click.group(name="transformer", invoke_without_command=True)
@click.argument("transformer_id", metavar="TRANSFORMER")
@click.pass_context
def transformer(ctx, transformer_id):
    """Per-transformer instance commands.

    TRANSFORMER accepts a UUID, a destination-table name, or a transformer name.

    \b
    Examples:
      torana datalake transformer mttr_by_severity get
      torana datalake transformer mttr_by_severity materialize
      torana datalake transformer <UUID> executions
    """
    ctx.ensure_object(dict)
    # Resolve lazily: `--help` and a bare invocation must not hit the API.
    if ctx.invoked_subcommand is None:
        ctx.obj["_transformer_id"] = transformer_id
        click.echo(ctx.get_help())
        return
    resolved = _resolve_transformer_id(ctx, transformer_id)
    if resolved is None:
        ctx.exit(1)
    ctx.obj["_transformer_id"] = resolved


@transformer.command(name="get")
@click.pass_context
def transformer_get(ctx):
    """Get details for a specific transformer."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"transformers/{_tid(ctx)}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@transformer.command(name="update")
@click.option("--name", default=None)
@click.option("--schedule", default=None)
@click.option("--sql", "custom_sql", default=None,
              help="New SQL body. Regenerates and compile-validates the dbt model; "
                   "a SQL error is rejected (422) and the transformer left unchanged.")
@click.option("--description", default=None, help="Update the description.")
@click.option("--why", "changed_because", default=None,
              help="Why the SQL changed (e.g. 'epss_score went EMPTY -> RANGE(1000)'). "
                   "Recorded on the version this update supersedes.")
@click.option("--trigger", "version_trigger", default=None,
              type=click.Choice(["created", "sync", "integration_change", "intent_edit"]),
              help="What caused the change. Defaults to intent_edit.")
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def transformer_update(ctx, name, schedule, custom_sql, description,
                       changed_because, version_trigger, input_file):
    """Update a transformer.

    \b
    Examples:
      torana datalake transformer <ID> update --sql "SELECT 1 AS n"
      torana datalake transformer <ID> update --file body.json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if schedule:
        body["schedule"] = schedule
    if custom_sql:
        body["custom_sql"] = custom_sql
    if description:
        body["description"] = description
    # S8 row 20v — the audit answer travels with the change that caused it. Asking
    # for it later never works: by then nobody remembers which column moved.
    if changed_because:
        body["version_changed_because"] = changed_because
    if version_trigger:
        body["version_trigger"] = version_trigger

    # Build definitions use `sql`; storage and create-and-execute use `custom_sql`.
    # A --file body may legitimately carry either, so normalize here rather than
    # forwarding a field the server would ignore (the silent drop behind CLI-6).
    if "sql" in body and "custom_sql" not in body:
        body["custom_sql"] = body.pop("sql")

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"transformers/{_tid(ctx)}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated transformer: {_tid(ctx)}")


@transformer.command(name="delete")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def transformer_delete(ctx, yes):
    """Delete a transformer."""
    _confirm(f"Delete transformer {_tid(ctx)}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"transformers/{_tid(ctx)}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted transformer: {_tid(ctx)}")


@transformer.command(name="execute")
@click.pass_context
def transformer_execute(ctx):
    """Execute a transformer immediately."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"transformers/{_tid(ctx)}/execute/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Executed transformer: {_tid(ctx)}")
        if isinstance(data, dict):
            for k, v in data.items():
                if k not in ("id",):
                    click.echo(f"  {k}: {v}")


@transformer.command(name="execute-and-wait")
@click.option("--timeout", default=None, type=int, help="Max seconds to wait for completion.")
@click.pass_context
def transformer_execute_and_wait(ctx, timeout):
    """Execute a transformer and wait for it to finish.

    \b
    Example:
      torana datalake transformer <UUID> execute-and-wait --timeout 120
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if timeout is not None:
        params["timeout"] = timeout

    client = _client(ctx)
    try:
        data = client.post(f"transformers/{_tid(ctx)}/execute-and-wait", json={}, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, fields=fields)
    else:
        click.echo(f"Transformer {_tid(ctx)} execution complete.")
        if isinstance(data, dict):
            for k, v in data.items():
                if k not in ("id",):
                    click.echo(f"  {k}: {v}")


@transformer.command(name="move")
@click.option("--target-workspace-id", "target_workspace_id", required=True)
@click.pass_context
def transformer_move(ctx, target_workspace_id):
    """Move transformer to a different workspace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"transformers/{_tid(ctx)}/move"
    body = {}
    body["target_workspace_id"] = target_workspace_id

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


_EXECUTION_COLS = [
    ("started_at", "STARTED", 26),
    ("status", "STATUS", 8),
    ("duration", "DURATION", 9),
    ("rows_affected", "ROWS", 8),
    ("error", "ERROR", 60),
]


@transformer.command(name="executions")
@click.option("--limit", "limit", type=int, default=50)
@click.option("--offset", "offset", type=int, default=0)
@click.option("--verbose", is_flag=True,
              help="Print the full dbt log for each run instead of the one-line cause.")
@click.pass_context
def transformer_executions(ctx, limit, offset, verbose):
    """Run history for this transformer — when it ran, and why it failed.

    One row per execution. The ERROR column carries the concrete database cause
    (e.g. 'column "is_sla_breached" does not exist'), extracted from the dbt log
    — the log itself is ~40 lines of ANSI-coloured output per run, so dumping it
    inline buries the one line that says what broke. Use --verbose for the full
    log, or --format json for the unabridged records.

    \b
    Example:
      torana datalake transformer mttr_by_severity executions
      torana datalake transformer mttr_by_severity executions --verbose
    """
    from torana_cli.datalake import _first_error_line, strip_ansi

    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = f"transformers/{_tid(ctx)}/executions"
    params = {}
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if isinstance(data, dict):
        items = data.get("executions", data.get("items", []))
        total = data.get("total", len(items))
    else:
        items = data if isinstance(data, list) else []
        total = len(items)

    # --format json keeps the FULL records (dbt_output included) — a machine
    # consumer asked for everything, and truncating it there would be lossy.
    if fmt != "text":
        output({"items": items, "total": total}, fmt=fmt, raw=raw, fields=fields)
        return

    for it in items:
        if not isinstance(it, dict):
            continue
        ms = it.get("execution_time_ms")
        it["duration"] = f"{ms / 1000:.1f}s" if isinstance(ms, (int, float)) else "—"
        it["error"] = _first_error_line(it.get("error_message")) or "—"
        if it.get("rows_affected") is None:
            it["rows_affected"] = "—"

    output({"items": items, "total": total}, fmt="text", raw=raw, fields=fields,
           columns=_EXECUTION_COLS)

    if verbose:
        for it in items:
            if not isinstance(it, dict) or not it.get("error_message"):
                continue
            click.echo(f"\n--- {it.get('started_at')}  ({it.get('status')}) ---")
            click.echo(strip_ansi(it["error_message"]))


# ──────────────────────────────────────────────────────────────────────────
# Instance reads regrouped from `<noun>-by-<param>` leaves onto verbs
# (CLI Discoverability Contract, rule 2 — see ../CLAUDE.md). The route
# parameter belongs in the positional ARGUMENT, not the command name.
#
# Old flat names remain as HIDDEN aliases for ONE release (D4).
# ──────────────────────────────────────────────────────────────────────────


@transformer.group(name="execution")
def transformer_execution_grp():
    """One transformer execution, by id.

    Examples:
      torana datalake transformer <ID> execution get --help
    """


@transformer_execution_grp.command(name="get")
@click.argument("execution_id", metavar="EXECUTION_ID")
@click.pass_context
def transformer_executions_by_execution_id(ctx, execution_id):
    """Get Execution."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"transformers/{_tid(ctx)}/executions/{execution_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@transformer.command(name="materialize")
@click.option("--timeout", default=300, show_default=True, type=int,
              help="Max seconds to wait for completion.")
@click.pass_context
def transformer_materialize(ctx, timeout):
    """Build this transformer's output table (execute and wait).

    Alias for `execute-and-wait` named for what it does to the datalake: the
    destination table goes from unmaterialized to materialized. Exits non-zero
    if the run fails, so scripts can detect it.

    \b
    Example:
      torana datalake transformer mttr_by_severity materialize
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        # The server reads `timeout_seconds` from the BODY (ExecuteAndWaitRequest);
        # sending `timeout` as a query param was silently ignored, so --timeout
        # never took effect and the server's 120s default always applied.
        data = client.post(f"transformers/{_tid(ctx)}/execute-and-wait",
                           json={"timeout_seconds": timeout})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    status = data.get("status") if isinstance(data, dict) else None
    if fmt != "text":
        output(data, fmt=fmt, fields=fields)
    elif status == "success":
        rows = data.get("rows_affected")
        suffix = f", rows_affected={rows}" if rows is not None else ""
        click.echo(f"Materialized. status=success{suffix}")
    else:
        from torana_cli.datalake import _first_error_line
        click.echo(f"FAILED. status={status}", err=True)
        detail = _first_error_line(data.get("error_message") if isinstance(data, dict) else None)
        if detail:
            click.echo(f"  {detail}", err=True)

    if status != "success":
        ctx.exit(1)


def _format_definition_line(payload) -> str:
    """The one-line definition-provenance summary for `status`.

    ⛔ THREE OUTCOMES, NEVER TWO. `unknown` is not `current`: a row with no recorded
    provenance pre-dates the tracking columns (or is not a platform relation at all), and
    printing it as up to date would assert a guarantee nobody checked — the exact blind
    spot the columns were added to close.
    """
    state = payload.get("definition_drift_state") or "unknown"
    own = payload.get("definition_version")
    own_label = f"v{own}" if own is not None else "unrecorded"

    if state == "outdated":
        latest = payload.get("definition_latest_version")
        latest_label = f"v{latest}" if latest is not None else "a newer version"
        # The version pair carries the meaning on its own, so this line still reads
        # correctly stripped of any styling.
        return f"{own_label}  ⚠ OUTDATED — platform has {latest_label}"
    if state == "current":
        return f"{own_label}  (current)"
    return f"{own_label}  (unknown — pre-dates drift tracking)"


@transformer.command(name="status")
@click.option("--history", default=3, show_default=True, type=int,
              help="How many recent executions to show.")
@click.pass_context
def transformer_status(ctx, history):
    """Show this transformer's health: materialized? last run? last error?

    One view answering the three questions you ask after a failed build:
    does the output table exist, did the last run succeed, and if not why.

    \b
    Example:
      torana datalake transformer mttr_by_severity status
    """
    from torana_cli.datalake import (_fetch_transformer_table_names, _first_error_line,
                                     resolve_materialization_state, strip_ansi)

    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    tid = _tid(ctx)

    client = _client(ctx)
    try:
        defn = client.get(f"transformers/{tid}")
        runs = client.get(f"transformers/{tid}/executions",
                          params={"limit": max(history, 1)})
        built = set(_fetch_transformer_table_names(client))
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if isinstance(runs, dict):
        execs = runs.get("executions", runs.get("items", []))
    else:
        execs = runs if isinstance(runs, list) else []

    dest = defn.get("destination_table")
    is_built = bool(dest and dest in built)
    last = execs[0] if execs else None
    last_error = _first_error_line(last.get("error_message")) if last else None

    payload = {
        "id": defn.get("id"),
        "name": defn.get("name"),
        "destination_table": dest,
        # SAME vocabulary as `transformers list` — one token set across the whole
        # datalake surface, so what you grep in a listing you can grep here.
        "state": resolve_materialization_state(
            is_built=is_built,
            last_status=(last or {}).get("status"),
            has_runs=bool(execs),
        ),
        "is_active": defn.get("is_active"),
        # DEFINITION PROVENANCE — which platform definition generation this relation was
        # built from, and whether the platform has moved since.
        #
        # ⛔ NOT DERIVABLE FROM `state` OR `last_status`. A drifted relation is
        # materialized, its last run succeeded, and it is serving SQL the platform has
        # superseded — so every other field on this screen reports it healthy. This is the
        # only line that can say otherwise.
        #
        # ⚠️ `definition_drift_state` is computed server-side (it needs the ACTIVE
        # definition's hash, which this response does not carry). Absent → "unknown",
        # never "current": an older server that does not send it must not read as up to
        # date. Three states, not two.
        "definition_version": defn.get("definition_version"),
        "definition_drift_state": defn.get("definition_drift_state") or "unknown",
        "definition_latest_version": defn.get("definition_latest_version"),
        "schedule": defn.get("schedule"),
        "workspace_id": defn.get("workspace_id"),
        "source_tables": defn.get("source_tables") or [],
        "last_status": (last or {}).get("status"),
        "last_started_at": (last or {}).get("started_at"),
        "last_rows_affected": (last or {}).get("rows_affected"),
        "last_error": last_error,
        # CLI-39: the FULL failure reason and the dbt output, straight from the
        # transformer record. `last_error` above is only the first line of the newest
        # execution — enough to know something broke, never enough to know WHY. In a
        # #91 cascade the model that actually failed is a DIFFERENT transformer, and
        # its name appears only in the dbt output, so without this the operator had to
        # read the service log (impossible for a customer).
        "failure_reason": defn.get("last_error"),
        "dbt_output": defn.get("last_dbt_output"),
        # Set when THIS transformer was removed from the tenant dbt graph by cascade
        # recovery — distinguishes "your SQL is broken" from "you were collateral damage".
        "quarantined_at": defn.get("quarantined_at"),
        "quarantine_reason": defn.get("quarantine_reason"),
        "recent_executions": [
            {"status": e.get("status"), "started_at": e.get("started_at"),
             "rows_affected": e.get("rows_affected"),
             "execution_time_ms": e.get("execution_time_ms"),
             "error": _first_error_line(e.get("error_message"))}
            for e in execs
        ],
    }

    if fmt != "text":
        output(payload, fmt=fmt, fields=fields)
        return

    click.echo(f"{payload['name']}  ({payload['id']})")
    click.echo(f"  destination table : {dest or '—'}")
    click.echo(f"  state             : {payload['state']}")
    # Sits beside `state` because it answers the same question — is this relation correct
    # right now — where `active`/`schedule`/`reads from` below are configuration.
    click.echo(f"  definition        : {_format_definition_line(payload)}")
    click.echo(f"  active            : {payload['is_active']}")
    click.echo(f"  schedule          : {payload['schedule'] or '— (manual)'}")
    srcs = payload["source_tables"]
    click.echo(f"  reads from        : {', '.join(srcs) if srcs else '—'}")

    # Quarantine is reported BEFORE run history: a quarantined transformer has been
    # removed from the tenant's dbt graph, so its "last run" is stale and misleading
    # on its own. Lead with the fact that it is not currently in the graph.
    if payload.get("quarantined_at"):
        click.echo(f"\n  ⚠ QUARANTINED     : {payload['quarantined_at']}")
        click.echo("    This transformer was removed from the tenant's dbt graph because")
        click.echo("    its SQL failed to parse, which was breaking every OTHER transformer")
        click.echo("    in the tenant. It is restored automatically once an update passes")
        click.echo("    validation — no manual action needed.")
        if payload.get("quarantine_reason"):
            click.echo("    reason:")
            for line in str(payload["quarantine_reason"]).strip().splitlines()[:6]:
                click.echo(f"      {strip_ansi(line)}")

    # ⛔ REPORTED BEFORE RUN HISTORY, for the same reason quarantine is: the run history
    # below is actively misleading here. A drifted relation's last run SUCCEEDED — against
    # SQL the platform has since superseded — so "last run: success" reads as health while
    # the relation serves stale output. Measured 2026-09-23 on the `prioritize_*` set: 6
    # relations a full bundle version behind, every one green. Lead with the drift.
    if payload.get("definition_drift_state") == "outdated":
        latest = payload.get("definition_latest_version")
        latest_label = f"v{latest}" if latest is not None else "a newer version"
        own = payload.get("definition_version")
        own_label = f"v{own}" if own is not None else "an unrecorded version"
        click.echo(f"\n  ⚠ OUTDATED DEFINITION : built from {own_label}, "
                   f"platform ships {latest_label}")
        click.echo("    The platform definition changed after this relation was built. Any")
        click.echo("    run below succeeded against the OLD SQL, so a green status here does")
        click.echo("    NOT mean the output matches what the platform now defines.")
        click.echo("    It is rebuilt from the current definition on the next repair.")

    if not last:
        click.echo("\n  No execution history — this transformer has never run.")
        return

    click.echo(f"\n  last run          : {payload['last_status']} "
               f"at {payload['last_started_at']}")
    if payload["last_rows_affected"] is not None:
        click.echo(f"  rows affected     : {payload['last_rows_affected']}")
    if last_error:
        click.echo(f"  last error        : {last_error}")

    # The full reason + dbt output (CLI-39). Printed only when the last run failed, so
    # a healthy transformer stays terse. `failure_reason` may span lines; the dbt HEAD
    # is what names the offending model in a cascade.
    reason = payload.get("failure_reason")
    if reason and str(reason).strip() != str(last_error or "").strip():
        click.echo("\n  failure reason:")
        for line in str(reason).strip().splitlines()[:12]:
            click.echo(f"    {strip_ansi(line)}")
    dbt_out = payload.get("dbt_output")
    if dbt_out and payload["last_status"] != "success":
        click.echo("\n  dbt output (head — names the model that actually failed):")
        for line in str(dbt_out).strip().splitlines()[:15]:
            click.echo(f"    {strip_ansi(line)}")

    if len(execs) > 1:
        click.echo(f"\n  recent runs ({len(execs)}):")
        for e in execs:
            mark = "OK  " if e.get("status") == "success" else "FAIL"
            ms = e.get("execution_time_ms")
            suffix = f"  ({ms}ms)" if ms is not None else ""
            click.echo(f"    {mark}  {e.get('started_at')}{suffix}")
            err = _first_error_line(e.get("error_message"))
            if err:
                click.echo(f"          {err}")


# ── S8 row 20v — version history ────────────────────────────────────────────────
# ⛔ "A version nobody can read is not an audit trail." This is the CLI leg of
# three-surface parity with GET /transformers/{id}/versions[...] and the FE tab.

@transformer.command(name="versions")
@click.option("--limit", default=100, show_default=True, help="Max versions to return.")
@click.option("--offset", default=0, show_default=True)
@click.pass_context
def transformer_versions(ctx, limit, offset):
    """List this transformer's SQL history, newest first.

    Answers "the dashboard was right last week — what was it then?".
    No rows means the SQL has not changed since versioning landed.

    \b
    Examples:
      torana datalake transformer vulnerabilities_by_team versions
      torana datalake transformer <UUID> versions --format json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"transformers/{_tid(ctx)}/versions")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, fields=fields)
        return

    items = data.get("items", []) if isinstance(data, dict) else (data or [])
    if not items:
        click.echo("No versions recorded — this transformer's SQL has not changed "
                   "since versioning landed.")
        return
    click.echo(f"{data.get('total', len(items))} version(s), newest first:")
    for v in items:
        click.echo(
            f"  v{v.get('version_number')}  {v.get('created_at')}  "
            f"[{v.get('trigger')}]"
            + (f"  {v.get('generation_status')}" if v.get('generation_status') else "")
        )
        if v.get("changed_because"):
            click.echo(f"        why: {v['changed_because']}")


@transformer.command(name="version")
@click.argument("version_number", type=int)
@click.option("--sql-only", is_flag=True, default=False,
              help="Print just the SQL body (pipe-friendly).")
@click.pass_context
def transformer_version_show(ctx, version_number, sql_only):
    """Show one version — its SQL body and why it was superseded.

    \b
    Examples:
      torana datalake transformer <ID> version 3
      torana datalake transformer <ID> version 3 --sql-only > v3.sql
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(f"transformers/{_tid(ctx)}/versions/{version_number}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if sql_only:
        click.echo(data.get("sql") or "")
        return
    if fmt != "text":
        output(data, fmt=fmt)
        return

    click.echo(f"Version:          v{data.get('version_number')}")
    click.echo(f"Created:          {data.get('created_at')}")
    click.echo(f"Trigger:          {data.get('trigger')}")
    if data.get("changed_because"):
        click.echo(f"Changed because:  {data['changed_because']}")
    if data.get("generation_status"):
        click.echo(f"Generation:       {data['generation_status']}")
    if data.get("intent_hash"):
        click.echo(f"Intent hash:      {data['intent_hash']}")
    click.echo("\nSQL:")
    click.echo(data.get("sql") or "(empty)")


@transformer.command(name="version-diff")
@click.argument("from_version", type=int)
@click.argument("to_version", type=int)
@click.pass_context
def transformer_version_diff(ctx, from_version, to_version):
    """Diff two versions. Use 0 to mean the CURRENT live SQL.

    \b
    Examples:
      torana datalake transformer <ID> version-diff 2 3
      torana datalake transformer <ID> version-diff 3 0   # v3 vs current
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(
            f"transformers/{_tid(ctx)}/versions/{from_version}/diff/{to_version}"
        )
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
        return

    if data.get("identical"):
        click.echo(f"{data.get('from_label')} and {data.get('to_label')} are identical.")
        return
    click.echo(data.get("diff") or "(no diff)")


# ──────────────────────────────────────────────────────────────────────────
# BACK-COMPAT — hidden aliases for the old `<noun>-by-<param>` names.
# ⏳ ONE RELEASE ONLY (decision D4). Delete this block next release.
# ──────────────────────────────────────────────────────────────────────────

_LEGACY_BY_PARAM_TRANSFORMER = {
    "executions-by-execution-id": ("execution", "get"),
}


def _register_legacy_transformer_by_param() -> None:
    """Old flat names, hidden so they cannot be discovered anew."""
    import copy
    for _old, (_sub, _verb) in _LEGACY_BY_PARAM_TRANSFORMER.items():
        _grp = transformer.commands.get(_sub)
        if not isinstance(_grp, click.Group):
            continue
        _cmd = _grp.commands.get(_verb)
        if _cmd is None:
            continue
        # ⛔ Never let an alias overwrite a real group of the same name.
        if isinstance(transformer.commands.get(_old), click.Group):
            continue
        _alias = copy.copy(_cmd)
        _alias.name = _old
        _alias.hidden = True
        transformer.add_command(_alias)


_register_legacy_transformer_by_param()
