"""torana datalake transformer — per-transformer instance commands."""

import re
import sys

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm

# Imported lazily inside functions to avoid a circular import:
# datalake.py imports this module to attach the group.


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _tid(ctx) -> str:
    return ctx.obj.get("_transformer_id", "") if ctx.obj else ""


_UUID_RE = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I
)


def _resolve_transformer_id(ctx, ident):
    """Accept either a transformer UUID or a destination-table / transformer NAME.

    Table names are what users see in the datalake and in `transformers list`,
    so requiring a UUID would mean a lookup round-trip for every command. A
    UUID-shaped argument is used as-is (no API call); anything else is resolved
    by scanning definitions for a matching destination_table, then name.

    Exits 3 (not found) if nothing matches, and 6 if the name is ambiguous —
    several definitions can share a destination_table, and silently picking one
    would make the command's target depend on list order.
    """
    if _UUID_RE.match(ident or ""):
        return ident

    # Lazy import — datalake.py imports this module, so a top-level import
    # would be circular.
    from torana_cli.datalake import _fetch_all_transformers

    client = _client(ctx)
    try:
        items = _fetch_all_transformers(client)
    except APIError as e:
        handle_api_error(e)
        return None
    except AuthError as e:
        handle_auth_error(e)
        return None

    needle = (ident or "").lower()
    matches = [t for t in items if (t.get("destination_table") or "").lower() == needle]
    if not matches:
        matches = [t for t in items if (t.get("name") or "").lower() == needle]

    if not matches:
        click.echo(f"ERROR: no transformer found for '{ident}'. "
                   f"Try `torana datalake transformers list`.", err=True)
        sys.exit(3)
    if len(matches) > 1:
        click.echo(
            f"ERROR: '{ident}' matches {len(matches)} transformers — pass a UUID instead:",
            err=True)
        for m in matches:
            click.echo(f"  {m.get('id')}  {m.get('name')}", err=True)
        sys.exit(6)
    return matches[0].get("id")


@click.group(name="transformer", invoke_without_command=True)
@click.argument("transformer_id", metavar="TRANSFORMER")
@click.pass_context
def transformer(ctx, transformer_id):
    """Per-transformer instance commands.

    TRANSFORMER accepts a UUID, a destination-table name, or a transformer name.

    \b
    Examples:
      torana datalake transformer mttr_by_severity get
      torana datalake transformer mttr_by_severity materialize
      torana datalake transformer <UUID> executions
    """
    ctx.ensure_object(dict)
    # Resolve lazily: `--help` and a bare invocation must not hit the API.
    if ctx.invoked_subcommand is None:
        ctx.obj["_transformer_id"] = transformer_id
        click.echo(ctx.get_help())
        return
    resolved = _resolve_transformer_id(ctx, transformer_id)
    if resolved is None:
        ctx.exit(1)
    ctx.obj["_transformer_id"] = resolved


@transformer.command(name="get")
@click.pass_context
def transformer_get(ctx):
    """Get details for a specific transformer."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"transformers/{_tid(ctx)}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@transformer.command(name="update")
@click.option("--name", default=None)
@click.option("--schedule", default=None)
@click.option("--sql", "custom_sql", default=None,
              help="New SQL body. Regenerates and compile-validates the dbt model; "
                   "a SQL error is rejected (422) and the transformer left unchanged.")
@click.option("--description", default=None, help="Update the description.")
@click.option("--why", "changed_because", default=None,
              help="Why the SQL changed (e.g. 'epss_score went EMPTY -> RANGE(1000)'). "
                   "Recorded on the version this update supersedes.")
@click.option("--trigger", "version_trigger", default=None,
              type=click.Choice(["created", "sync", "integration_change", "intent_edit"]),
              help="What caused the change. Defaults to intent_edit.")
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.option("--time-grain", "time_grain", default=None, metavar="GRAIN",
              help="Clock grain override: 15m | 1h | 1d | <seconds> | clear. Below the "
                   "platform floor (15m) is refused — only a view is exact at that resolution.")
@click.pass_context
def transformer_update(ctx, name, schedule, custom_sql, description,
                       changed_because, version_trigger, input_file, time_grain):
    """Update a transformer.

    \b
    Examples:
      torana datalake transformer <ID> update --sql "SELECT 1 AS n"
      torana datalake transformer <ID> update --file body.json
      torana datalake transformer prioritized_vulnerabilities update --time-grain 1d
      torana datalake transformer prioritized_vulnerabilities update --time-grain clear
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if schedule:
        body["schedule"] = schedule
    if custom_sql:
        body["custom_sql"] = custom_sql
    if description:
        body["description"] = description
    # S8 row 20v — the audit answer travels with the change that caused it. Asking
    # for it later never works: by then nobody remembers which column moved.
    if changed_because:
        body["version_changed_because"] = changed_because
    if version_trigger:
        body["version_trigger"] = version_trigger
    if time_grain is not None:
        try:
            body["time_grain_override_seconds"] = parse_time_grain(time_grain)
        except ValueError as e:
            click.echo(f"ERROR: {e}", err=True)
            sys.exit(2)

    # Build definitions use `sql`; storage and create-and-execute use `custom_sql`.
    # A --file body may legitimately carry either, so normalize here rather than
    # forwarding a field the server would ignore (the silent drop behind CLI-6).
    if "sql" in body and "custom_sql" not in body:
        body["custom_sql"] = body.pop("sql")

    if not body and time_grain is None:
        click.echo("ERROR: No fields to update.", err=True)
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"transformers/{_tid(ctx)}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated transformer: {_tid(ctx)}")


@transformer.command(name="delete")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def transformer_delete(ctx, yes):
    """Delete a transformer."""
    _confirm(f"Delete transformer {_tid(ctx)}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"transformers/{_tid(ctx)}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted transformer: {_tid(ctx)}")


@transformer.command(name="execute")
@click.pass_context
def transformer_execute(ctx):
    """Execute a transformer immediately."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"transformers/{_tid(ctx)}/execute/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Executed transformer: {_tid(ctx)}")
        if isinstance(data, dict):
            for k, v in data.items():
                if k not in ("id",):
                    click.echo(f"  {k}: {v}")


@transformer.command(name="execute-and-wait")
@click.option("--timeout", default=None, type=int, help="Max seconds to wait for completion.")
@click.pass_context
def transformer_execute_and_wait(ctx, timeout):
    """Execute a transformer and wait for it to finish.

    \b
    Example:
      torana datalake transformer <UUID> execute-and-wait --timeout 120
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if timeout is not None:
        params["timeout"] = timeout

    client = _client(ctx)
    try:
        data = client.post(f"transformers/{_tid(ctx)}/execute-and-wait", json={}, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, fields=fields)
    else:
        click.echo(f"Transformer {_tid(ctx)} execution complete.")
        if isinstance(data, dict):
            for k, v in data.items():
                if k not in ("id",):
                    click.echo(f"  {k}: {v}")


@transformer.command(name="move")
@click.option("--target-workspace-id", "target_workspace_id", required=True)
@click.pass_context
def transformer_move(ctx, target_workspace_id):
    """Move transformer to a different workspace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"transformers/{_tid(ctx)}/move"
    body = {}
    body["target_workspace_id"] = target_workspace_id

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


_EXECUTION_COLS = [
    ("started_at", "STARTED", 26),
    ("status", "STATUS", 9),
    ("duration", "DURATION", 9),
    ("lock_wait", "LOCK WAIT", 9),
    ("rows_affected", "ROWS", 8),
    ("batch", "BATCH", 24),
    ("error", "ERROR", 60),
]


def _exec_batch(execution) -> dict:
    """`dbt_output.batch` of one execution row, or {} (legacy/serial rows have none).

    ⛔ A contract with pantheon-data-transformers (DT_BATCHED_DBT_SPEC § 3.3.1): keys
    batch_id, build_id, trace_id, wave, waves, group, mode, fallback_reason, notes, spawns.
    """
    out = (execution or {}).get("dbt_output") if isinstance(execution, dict) else None
    b = out.get("batch") if isinstance(out, dict) else None
    return b if isinstance(b, dict) else {}


def _relation_locks(execution) -> dict:
    """How this run waited for its relation build locks: `{wait_ms, busy}` from
    `dbt_output.relation_locks` (single execute) or `dbt_output.batch` (a batched build's
    item). {} on rows written before relation locks existed."""
    out = (execution or {}).get("dbt_output") if isinstance(execution, dict) else None
    if not isinstance(out, dict):
        return {}
    rl = out.get("relation_locks")
    if isinstance(rl, dict):
        return {"wait_ms": rl.get("wait_ms"), "busy": rl.get("busy") or {}}
    b = _exec_batch(execution)
    if b.get("lock_wait_ms") is not None or b.get("lock_busy_by"):
        return {"wait_ms": b.get("lock_wait_ms"),
                "busy": {"(this relation)": b["lock_busy_by"]} if b.get("lock_busy_by") else {}}
    return {}


def _lock_wait_label(execution) -> str:
    ms = _relation_locks(execution).get("wait_ms")
    if ms is None:
        return "—"
    return "<1s" if ms < 1000 else f"{ms / 1000:.0f}s"


def _batch_label(execution) -> str:
    """`3f9a1c2b w2/5 incr`, `3f9a1c2b dependent` for dependents, or `-` with no batch.
    The id is the BUILD id (`torana datalake transformers build <id> show`)."""
    b = _exec_batch(execution)
    if not b.get("batch_id"):
        return "-"
    # § 3.12.2: the id `builds list` prints and `build <id> show` takes; batch_id on
    # rows written before the build record existed.
    bid = str(b.get("build_id") or b["batch_id"])[:8]
    group = b.get("group") or "?"
    if group.startswith("dependent") or b.get("wave") is None:
        return f"{bid} {group}"
    return f"{bid} w{b.get('wave')}/{b.get('waves', '?')} {group}"


@transformer.command(name="executions")
@click.option("--limit", "limit", type=int, default=50)
@click.option("--offset", "offset", type=int, default=0)
@click.option("--verbose", is_flag=True,
              help="Print the full dbt log for each run instead of the one-line cause, "
                   "and each batched run's mode, notes, spawns and exception.")
@click.pass_context
def transformer_executions(ctx, limit, offset, verbose):
    """Run history for this transformer — when it ran, and why it failed.

    One row per execution. The ERROR column carries the concrete database cause
    (e.g. 'column "is_sla_breached" does not exist'), extracted from the dbt log
    — the log itself is ~40 lines of ANSI-coloured output per run, so dumping it
    inline buries the one line that says what broke. Use --verbose for the full
    log, or --format json for the unabridged records.

    \b
    Example:
      torana datalake transformer mttr_by_severity executions
      torana datalake transformer mttr_by_severity executions --verbose
    """
    from torana_cli.datalake import _first_error_line, strip_ansi

    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = f"transformers/{_tid(ctx)}/executions"
    params = {}
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if isinstance(data, dict):
        items = data.get("executions", data.get("items", []))
        total = data.get("total", len(items))
    else:
        items = data if isinstance(data, list) else []
        total = len(items)

    # --format json keeps the FULL records (dbt_output included) — a machine
    # consumer asked for everything, and truncating it there would be lossy.
    if fmt != "text":
        output({"items": items, "total": total}, fmt=fmt, raw=raw, fields=fields)
        return

    for it in items:
        if not isinstance(it, dict):
            continue
        ms = it.get("execution_time_ms")
        it["duration"] = f"{ms / 1000:.1f}s" if isinstance(ms, (int, float)) else "—"
        it["error"] = _first_error_line(it.get("error_message")) or "—"
        if it.get("rows_affected") is None:
            it["rows_affected"] = "—"
        it["batch"] = _batch_label(it)
        it["lock_wait"] = _lock_wait_label(it)

    output({"items": items, "total": total}, fmt="text", raw=raw, fields=fields,
           columns=_EXECUTION_COLS)

    if verbose:
        for it in items:
            if not isinstance(it, dict):
                continue
            b = _exec_batch(it)
            rl = _relation_locks(it)
            if not it.get("error_message") and not b and not rl:
                continue
            click.echo(f"\n--- {it.get('started_at')}  ({it.get('status')}) ---")
            if b:
                mode = b.get("mode") or "?"
                if b.get("fallback_reason"):
                    mode += f" ({b['fallback_reason']})"
                click.echo(f"batch {b.get('batch_id')}  mode {mode}  "
                           f"spawns {b.get('spawns', '—')}  build {b.get('build_id') or '—'}")
                click.echo(f"notes: {', '.join(map(str, b.get('notes') or [])) or '—'}")
            if rl:
                # Relation build locks: how long this run waited for another builder of
                # the same relation, and (status lock_busy) who held it the whole wait.
                busy = rl.get("busy") or {}
                click.echo(f"relation locks: waited {_lock_wait_label(it)}"
                           + ("  · busy: " + ", ".join(f"{r} (held by {h})"
                                                       for r, h in sorted(busy.items()))
                              if busy else ""))
            exc = (it.get("dbt_output") or {}).get("exception")
            if it.get("status") != "success" and exc and exc != it.get("error_message"):
                click.echo(f"exception: {strip_ansi(str(exc))}")
            if it.get("error_message"):
                click.echo(strip_ansi(it["error_message"]))


# ──────────────────────────────────────────────────────────────────────────
# Instance reads regrouped from `<noun>-by-<param>` leaves onto verbs
# (CLI Discoverability Contract, rule 2 — see ../CLAUDE.md). The route
# parameter belongs in the positional ARGUMENT, not the command name.
#
# Old flat names remain as HIDDEN aliases for ONE release (D4).
# ──────────────────────────────────────────────────────────────────────────


@transformer.group(name="execution")
def transformer_execution_grp():
    """One transformer execution, by id.

    Examples:
      torana datalake transformer <ID> execution get --help
    """


@transformer_execution_grp.command(name="get")
@click.argument("execution_id", metavar="EXECUTION_ID")
@click.pass_context
def transformer_executions_by_execution_id(ctx, execution_id):
    """Get Execution."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"transformers/{_tid(ctx)}/executions/{execution_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@transformer.command(name="materialize")
@click.option("--timeout", default=300, show_default=True, type=int,
              help="Max seconds to wait for completion.")
@click.pass_context
def transformer_materialize(ctx, timeout):
    """Build this transformer's output table (execute and wait).

    Alias for `execute-and-wait` named for what it does to the datalake: the
    destination table goes from unmaterialized to materialized. Exits non-zero
    if the run fails, so scripts can detect it.

    \b
    Example:
      torana datalake transformer mttr_by_severity materialize
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        # The server reads `timeout_seconds` from the BODY (ExecuteAndWaitRequest);
        # sending `timeout` as a query param was silently ignored, so --timeout
        # never took effect and the server's 120s default always applied.
        data = client.post(f"transformers/{_tid(ctx)}/execute-and-wait",
                           json={"timeout_seconds": timeout})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    status = data.get("status") if isinstance(data, dict) else None
    if fmt != "text":
        output(data, fmt=fmt, fields=fields)
    elif status == "success":
        rows = data.get("rows_affected")
        suffix = f", rows_affected={rows}" if rows is not None else ""
        click.echo(f"Materialized. status=success{suffix}")
    else:
        from torana_cli.datalake import _first_error_line
        click.echo(f"FAILED. status={status}", err=True)
        detail = _first_error_line(data.get("error_message") if isinstance(data, dict) else None)
        if detail:
            click.echo(f"  {detail}", err=True)

    if status != "success":
        ctx.exit(1)


def _sweep_line(data) -> str:
    """One line for a SweepReleaseResponse (DT_BATCHED_DBT_SPEC § 3.12.7). Glyph + word."""
    st = data.get("status")
    live, would = data.get("live", 0), data.get("would_tombstone", 0)
    if st == "swept":
        return f"✓ swept: {data.get('tombstoned', 0)} of {live} live rows tombstoned"
    if st == "blocked":
        return (f"– blocked: would tombstone {would} of {live} "
                f"(re-run with --allow-mass-tombstone if the change is real)")
    if st == "failed":
        why = data.get("error") or data.get("message")
        return "✗ failed" + (f": {why}" if why else "")
    return f"? {st}"


@transformer.command(name="sweep")
@click.option("--allow-mass-tombstone", is_flag=True, default=False,
              help="Turn the mass-tombstone guard off for this one sweep. Without it the "
                   "guarded sweep runs, and reports `blocked` with its counts.")
@click.option("--yes", is_flag=True, default=False,
              help="Skip the confirmation that --allow-mass-tombstone asks for.")
@click.pass_context
def transformer_sweep(ctx, allow_mass_tombstone, yes):
    """Run this bootstrap relation's soft-delete sweep once; release a blocked one.

    A build's sweep soft-deletes (tombstones) rows whose key no longer appears in
    the source. It is BLOCKED, and the audit shows SWEEP_BLOCKED, when it would
    remove more than half of at least 20 live rows, or when the source returned
    nothing while live rows exist. Check the counts; if the change is real, release
    it with --allow-mass-tombstone. Runs under the platform build lock (409 while
    it is busy). Exit 0 only when the sweep ran (`swept`).

    \b
    Examples:
      torana datalake transformer prioritized_vulnerabilities sweep
      torana datalake transformer prioritized_vulnerabilities sweep --allow-mass-tombstone
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    if allow_mass_tombstone:
        _confirm(f"Release the sweep guard for transformer {_tid(ctx)}? The rows it counts "
                 f"as gone from the source will be soft-deleted.", yes=yes)

    client = _client(ctx)
    try:
        data = client.post(f"transformers/{_tid(ctx)}/sweep",
                           json={"allow_mass_tombstone": allow_mass_tombstone})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    data = data if isinstance(data, dict) else {}
    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(_sweep_line(data))
    if data.get("status") != "swept":
        ctx.exit(1)


def _format_definition_line(payload) -> str:
    """The one-line definition-provenance summary for `status`.

    ⛔ THREE OUTCOMES, NEVER TWO. `unknown` is not `current`: a row with no recorded
    provenance pre-dates the tracking columns (or is not a platform relation at all), and
    printing it as up to date would assert a guarantee nobody checked — the exact blind
    spot the columns were added to close.
    """
    state = payload.get("definition_drift_state") or "unknown"
    own = payload.get("definition_version")
    own_label = f"v{own}" if own is not None else "unrecorded"

    if state == "outdated":
        latest = payload.get("definition_latest_version")
        latest_label = f"v{latest}" if latest is not None else "a newer version"
        # The version pair carries the meaning on its own, so this line still reads
        # correctly stripped of any styling.
        return f"{own_label}  ⚠ OUTDATED — platform has {latest_label}"
    if state == "current":
        return f"{own_label}  (current)"
    return f"{own_label}  (unknown — pre-dates drift tracking)"


def parse_time_grain(value: str):
    """`15m` | `1h` | `1d` | `<seconds>` | `clear` → seconds (None clears). The FLOOR is the
    server's to enforce (422); only the syntax is checked here."""
    v = str(value).strip().lower()
    if v in ("clear", "none", "off"):
        return None
    units = {"s": 1, "m": 60, "h": 3600, "d": 86400}
    if v[-1:] in units and v[:-1].isdigit():
        return int(v[:-1]) * units[v[-1]]
    if v.isdigit():
        return int(v)
    raise ValueError(f"--time-grain {value!r}: use 15m, 1h, 1d, a number of seconds, or clear")


@transformer.command(name="refresh-plan")
@click.pass_context
def transformer_refresh_plan(ctx):
    """When and why this transformer rebuilds: its triggers, schedule and reasoning.

    Rendered verbatim from the platform's refresh plan (the same object the API and the
    Data Transformers page show). `--format json` prints the raw plan.

    \b
    Examples:
      torana datalake transformer prioritized_vulnerabilities refresh-plan
      torana datalake transformer prioritized_vulnerabilities refresh-plan --format json
    """
    from torana_cli.refresh_plan_render import render_plan
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        plan = client.get(f"transformers/{_tid(ctx)}/refresh-plan")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt != "text":
        output(plan, fmt=fmt)
        return
    for line in render_plan(plan):
        click.echo(line)


@transformer.command(name="status")
@click.option("--history", default=3, show_default=True, type=int,
              help="How many recent executions to show.")
@click.pass_context
def transformer_status(ctx, history):
    """Show this transformer's health: materialized? last run? last error?

    One view answering the three questions you ask after a failed build:
    does the output table exist, did the last run succeed, and if not why.

    \b
    Example:
      torana datalake transformer mttr_by_severity status
    """
    from torana_cli.datalake import (RUN_NOTES, _fetch_output_relation_types,
                                     _first_error_line, is_build_execution,
                                     resolve_materialization_state, run_mark, strip_ansi)

    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    tid = _tid(ctx)

    client = _client(ctx)
    try:
        defn = client.get(f"transformers/{tid}", params={"include_refresh": "true"})
        runs = client.get(f"transformers/{tid}/executions",
                          params={"limit": max(history, 1)})
        built = _fetch_output_relation_types(client)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if isinstance(runs, dict):
        execs = runs.get("executions", runs.get("items", []))
    else:
        execs = runs if isinstance(runs, list) else []

    dest = defn.get("destination_table")
    is_built = bool(dest and dest in built)
    # ⛔ The last BUILD, not the newest execution row: a drain writes a row for every
    # `already_current` skip and every deferral, and none of them ran (NOT_A_BUILD).
    builds = [e for e in execs if is_build_execution(e)]
    last = builds[0] if builds else None
    last_error = _first_error_line(last.get("error_message")) if last else None

    payload = {
        "id": defn.get("id"),
        "name": defn.get("name"),
        "destination_table": dest,
        # `table` | `view` — what the output physically is; None when it does not exist.
        "type": built.get(dest) if dest else None,
        # SAME vocabulary as `transformers list` — one token set across the whole
        # datalake surface, so what you grep in a listing you can grep here.
        "state": resolve_materialization_state(
            is_built=is_built,
            last_status=(last or {}).get("status"),
            has_runs=bool(execs),
            kind=built.get(dest) if dest else None,
        ),
        "is_active": defn.get("is_active"),
        # DEFINITION PROVENANCE — which platform definition generation this relation was
        # built from, and whether the platform has moved since.
        #
        # ⛔ NOT DERIVABLE FROM `state` OR `last_status`. A drifted relation is
        # materialized, its last run succeeded, and it is serving SQL the platform has
        # superseded — so every other field on this screen reports it healthy. This is the
        # only line that can say otherwise.
        #
        # ⚠️ `definition_drift_state` is computed server-side (it needs the ACTIVE
        # definition's hash, which this response does not carry). Absent → "unknown",
        # never "current": an older server that does not send it must not read as up to
        # date. Three states, not two.
        "definition_version": defn.get("definition_version"),
        "definition_drift_state": defn.get("definition_drift_state") or "unknown",
        "definition_latest_version": defn.get("definition_latest_version"),
        "schedule": defn.get("schedule"),
        "workspace_id": defn.get("workspace_id"),
        "source_tables": defn.get("source_tables") or [],
        "last_status": (last or {}).get("status"),
        # § 3.11.6: the ROW's last_status (not the latest execution's). `owed_full_refresh`
        # / `owed_rebuild` / `lock_contention` mean a rebuild is owed on the next build;
        # health reads `stale`.
        "row_last_status": defn.get("last_status"),
        "last_started_at": (last or {}).get("started_at"),
        "last_rows_affected": (last or {}).get("rows_affected"),
        "last_error": last_error,
        # CLI-39: the FULL failure reason and the dbt output, straight from the
        # transformer record. `last_error` above is only the first line of the newest
        # execution — enough to know something broke, never enough to know WHY. In a
        # #91 cascade the model that actually failed is a DIFFERENT transformer, and
        # its name appears only in the dbt output, so without this the operator had to
        # read the service log (impossible for a customer).
        "failure_reason": defn.get("last_error"),
        "dbt_output": defn.get("last_dbt_output"),
        # Set when THIS transformer was removed from the tenant dbt graph by cascade
        # recovery — distinguishes "your SQL is broken" from "you were collateral damage".
        "quarantined_at": defn.get("quarantined_at"),
        "quarantine_reason": defn.get("quarantine_reason"),
        # The refresh plan's compact form (§ 3.4.1), rendered verbatim — never recomputed.
        "refresh": defn.get("refresh"),
        "recent_executions": [
            {"status": e.get("status"), "started_at": e.get("started_at"),
             "rows_affected": e.get("rows_affected"),
             "execution_time_ms": e.get("execution_time_ms"),
             "batch": _batch_label(e),
             "error": _first_error_line(e.get("error_message"))}
            for e in execs
        ],
    }

    if fmt != "text":
        output(payload, fmt=fmt, fields=fields)
        return

    click.echo(f"{payload['name']}  ({payload['id']})")
    click.echo(f"  destination table : {dest or '—'}")
    click.echo(f"  state             : {payload['state']}")
    click.echo(f"  type              : {payload['type'] or '—'}")
    # Sits beside `state` because it answers the same question — is this relation correct
    # right now — where `active`/`schedule`/`reads from` below are configuration.
    click.echo(f"  definition        : {_format_definition_line(payload)}")
    from torana_cli.datalake import OWED_GLYPH, owed_label
    owed = owed_label(payload.get("row_last_status"))
    if owed:
        why = {"owed_full_refresh": "repair rewrote its SQL; the next build rebuilds it from scratch",
               "lock_contention": ("its last build was cancelled waiting for a table lock (a "
                                   "reader held it); the previous rows stand and the next "
                                   "build retries it"),
               }.get(payload["row_last_status"],
                     "a build stopped before reaching it; the next build rebuilds it")
        click.echo(f"  owed              : {OWED_GLYPH} {owed} — {why}")
    click.echo(f"  active            : {payload['is_active']}")
    click.echo(f"  schedule          : {payload['schedule'] or '— (manual)'}")
    srcs = payload["source_tables"]
    click.echo(f"  reads from        : {', '.join(srcs) if srcs else '—'}")
    ref = payload.get("refresh") or {}
    if ref:
        from torana_cli.refresh_plan_render import verdict_label
        click.echo(f"  refresh           : {ref.get('summary') or '—'}")
        nxt = ref.get("next_at") or ref.get("next_on") or "—"
        click.echo(f"  next              : {nxt}  ({ref.get('next_trigger') or '—'})  "
                   f"{verdict_label(ref.get('verdict'))}")

    # Quarantine is reported BEFORE run history: a quarantined transformer has been
    # removed from the tenant's dbt graph, so its "last run" is stale and misleading
    # on its own. Lead with the fact that it is not currently in the graph.
    if payload.get("quarantined_at"):
        click.echo(f"\n  ⚠ QUARANTINED     : {payload['quarantined_at']}")
        click.echo("    This transformer was removed from the tenant's dbt graph because")
        click.echo("    its SQL failed to parse, which was breaking every OTHER transformer")
        click.echo("    in the tenant. It is restored automatically once an update passes")
        click.echo("    validation — no manual action needed.")
        if payload.get("quarantine_reason"):
            click.echo("    reason:")
            for line in str(payload["quarantine_reason"]).strip().splitlines()[:6]:
                click.echo(f"      {strip_ansi(line)}")

    # ⛔ REPORTED BEFORE RUN HISTORY, for the same reason quarantine is: the run history
    # below is actively misleading here. A drifted relation's last run SUCCEEDED — against
    # SQL the platform has since superseded — so "last run: success" reads as health while
    # the relation serves stale output. Measured 2026-09-23 on the `prioritize_*` set: 6
    # relations a full bundle version behind, every one green. Lead with the drift.
    if payload.get("definition_drift_state") == "outdated":
        latest = payload.get("definition_latest_version")
        latest_label = f"v{latest}" if latest is not None else "a newer version"
        own = payload.get("definition_version")
        own_label = f"v{own}" if own is not None else "an unrecorded version"
        click.echo(f"\n  ⚠ OUTDATED DEFINITION : built from {own_label}, "
                   f"platform ships {latest_label}")
        click.echo("    The platform definition changed after this relation was built. Any")
        click.echo("    run below succeeded against the OLD SQL, so a green status here does")
        click.echo("    NOT mean the output matches what the platform now defines.")
        click.echo("    It is rebuilt from the current definition on the next repair.")

    if not last and not execs:
        click.echo("\n  No execution history — this transformer has never run.")
        return
    if last:
        click.echo(f"\n  last run          : {payload['last_status']} "
                   f"at {payload['last_started_at']}")
    else:
        # Every run in the window was a skip/deferral. The ROW still knows its last real
        # build — `last_*` columns move only on a build.
        click.echo(f"\n  last run          : {defn.get('last_status') or '—'} at "
                   f"{defn.get('last_run_at') or '—'}  (older than the "
                   f"{len(execs)} run(s) below, which were all skips)")
    if payload["last_rows_affected"] is not None:
        click.echo(f"  rows affected     : {payload['last_rows_affected']}")
    if last_error:
        click.echo(f"  last error        : {last_error}")

    # The full reason + dbt output (CLI-39). Printed only when the last run failed, so
    # a healthy transformer stays terse. `failure_reason` may span lines; the dbt HEAD
    # is what names the offending model in a cascade.
    reason = payload.get("failure_reason")
    if reason and str(reason).strip() != str(last_error or "").strip():
        click.echo("\n  failure reason:")
        for line in str(reason).strip().splitlines()[:12]:
            click.echo(f"    {strip_ansi(line)}")
    dbt_out = payload.get("dbt_output")
    if dbt_out and payload["last_status"] != "success":
        click.echo("\n  dbt output (head — names the model that actually failed):")
        for line in str(dbt_out).strip().splitlines()[:15]:
            click.echo(f"    {strip_ansi(line)}")

    if len(execs) > 1:
        click.echo(f"\n  recent runs ({len(execs)}):")
        for e in execs:
            st = str(e.get("status") or "").lower()
            ms = e.get("execution_time_ms")
            suffix = f"  ({ms}ms)" if ms is not None else ""
            click.echo(f"    {run_mark(st)}  {e.get('started_at')}  "
                       f"batch {_batch_label(e):24}{suffix}")
            note = RUN_NOTES.get(st)
            err = _first_error_line(e.get("error_message"))
            if note:
                click.echo(f"          {note}")
            elif err:
                click.echo(f"          {err}")


# ── Who reads this transformer ──────────────────────────────────────────────────
# DT_MATERIALIZATION_POLICY_SPEC § 3.4.1 / § 3.2.4: the CLI leg of the FE's USED BY drawer,
# both over GET /transformers/{id}/consumers (apps, rules, widgets, KPIs, attention cards and
# downstream transformers), so the two cannot disagree. Layout only: the tier and its reason
# are the server's.

#: How an app holds the relation, from its build_v2_artifacts type.
USED_BY_HOW = {"transformer": "owns a copy",
               "transformer_ref": "references the platform definition"}
#: Glyph + word per consumer kind (never colour alone).
USED_BY_KIND = {"app": "▣ app", "rule": "⚑ rule", "widget": "▦ widget", "kpi": "# KPI",
                "attention_card": "! attention card", "transformer": "⇢ transformer"}
TIER_WORD = {"consumed": "● consumed", "offered": "○ offered", "dormant": "☾ dormant"}


def used_by_rows(data):
    """`/consumers` → one row per consumer, for text and JSON alike. Pure (unit-tested)."""
    rows = []
    for c in (data or {}).get("consumers") or []:
        kind = c.get("kind") or ""
        detail = c.get("detail") or ""
        rows.append({"kind": kind, "name": c.get("name") or c.get("id"), "id": c.get("id"),
                     "where": (USED_BY_HOW.get(detail, detail) if kind == "app" else detail)})
    return rows


@transformer.command(name="used-by")
@click.pass_context
def transformer_used_by(ctx):
    """List everything that reads this transformer, and the refresh tier that follows.

    Apps (and whether each owns a copy or references the platform definition), detection
    rules, dashboard widgets, KPIs, attention cards, and other transformers. A PARTIAL
    answer means one source could not be read: the list may be short, and the platform
    never stops rebuilding a relation on a partial answer. Chat-time agent SQL and
    external readers are never visible.

    \b
    Examples:
      torana datalake transformer prioritized_vulnerabilities used-by
      torana datalake transformer <UUID> used-by --format json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get(f"transformers/{_tid(ctx)}/consumers")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    items = used_by_rows(data)
    if fmt != "text":
        output({"items": items, "total": len(items), "counts": data.get("counts") or {},
                "tier": data.get("tier"), "why": data.get("why"),
                "partial": bool(data.get("partial")), "errors": data.get("errors") or [],
                "not_visible": data.get("not_visible") or []}, fmt=fmt, fields=fields)
        return
    tier = data.get("tier")
    click.echo(f"{data.get('name')}  —  {TIER_WORD.get(tier, tier)}: {data.get('why') or ''}")
    if data.get("partial"):
        click.echo("⚠ PARTIAL — " + "; ".join(data.get("errors") or ["a source was not read"])
                   + " (the list may be short; nothing is demoted on it)")
    if not items:
        click.echo("  No declared reader.")
    for i in items:
        click.echo(f"  {USED_BY_KIND.get(i['kind'], i['kind']):<18} {str(i['name'])[:44]:<44} "
                   f"{i['where']}")
    nv = data.get("not_visible") or []
    if nv:
        click.echo("  Not visible to the platform: " + ", ".join(nv))


# ── S8 row 20v — version history ────────────────────────────────────────────────
# ⛔ "A version nobody can read is not an audit trail." This is the CLI leg of
# three-surface parity with GET /transformers/{id}/versions[...] and the FE tab.

@transformer.command(name="versions")
@click.option("--limit", default=100, show_default=True, help="Max versions to return.")
@click.option("--offset", default=0, show_default=True)
@click.pass_context
def transformer_versions(ctx, limit, offset):
    """List this transformer's SQL history, newest first.

    Answers "the dashboard was right last week — what was it then?".
    No rows means the SQL has not changed since versioning landed.

    \b
    Examples:
      torana datalake transformer vulnerabilities_by_team versions
      torana datalake transformer <UUID> versions --format json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"transformers/{_tid(ctx)}/versions")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, fields=fields)
        return

    items = data.get("items", []) if isinstance(data, dict) else (data or [])
    if not items:
        click.echo("No versions recorded — this transformer's SQL has not changed "
                   "since versioning landed.")
        return
    click.echo(f"{data.get('total', len(items))} version(s), newest first:")
    for v in items:
        click.echo(
            f"  v{v.get('version_number')}  {v.get('created_at')}  "
            f"[{v.get('trigger')}]"
            + (f"  {v.get('generation_status')}" if v.get('generation_status') else "")
        )
        if v.get("changed_because"):
            click.echo(f"        why: {v['changed_because']}")


@transformer.command(name="version")
@click.argument("version_number", type=int)
@click.option("--sql-only", is_flag=True, default=False,
              help="Print just the SQL body (pipe-friendly).")
@click.pass_context
def transformer_version_show(ctx, version_number, sql_only):
    """Show one version — its SQL body and why it was superseded.

    \b
    Examples:
      torana datalake transformer <ID> version 3
      torana datalake transformer <ID> version 3 --sql-only > v3.sql
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(f"transformers/{_tid(ctx)}/versions/{version_number}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if sql_only:
        click.echo(data.get("sql") or "")
        return
    if fmt != "text":
        output(data, fmt=fmt)
        return

    click.echo(f"Version:          v{data.get('version_number')}")
    click.echo(f"Created:          {data.get('created_at')}")
    click.echo(f"Trigger:          {data.get('trigger')}")
    if data.get("changed_because"):
        click.echo(f"Changed because:  {data['changed_because']}")
    if data.get("generation_status"):
        click.echo(f"Generation:       {data['generation_status']}")
    if data.get("intent_hash"):
        click.echo(f"Intent hash:      {data['intent_hash']}")
    click.echo("\nSQL:")
    click.echo(data.get("sql") or "(empty)")


@transformer.command(name="version-diff")
@click.argument("from_version", type=int)
@click.argument("to_version", type=int)
@click.pass_context
def transformer_version_diff(ctx, from_version, to_version):
    """Diff two versions. Use 0 to mean the CURRENT live SQL.

    \b
    Examples:
      torana datalake transformer <ID> version-diff 2 3
      torana datalake transformer <ID> version-diff 3 0   # v3 vs current
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(
            f"transformers/{_tid(ctx)}/versions/{from_version}/diff/{to_version}"
        )
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
        return

    if data.get("identical"):
        click.echo(f"{data.get('from_label')} and {data.get('to_label')} are identical.")
        return
    click.echo(data.get("diff") or "(no diff)")


# ──────────────────────────────────────────────────────────────────────────
# BACK-COMPAT — hidden aliases for the old `<noun>-by-<param>` names.
# ⏳ ONE RELEASE ONLY (decision D4). Delete this block next release.
# ──────────────────────────────────────────────────────────────────────────

_LEGACY_BY_PARAM_TRANSFORMER = {
    "executions-by-execution-id": ("execution", "get"),
}


def _register_legacy_transformer_by_param() -> None:
    """Old flat names, hidden so they cannot be discovered anew."""
    import copy
    for _old, (_sub, _verb) in _LEGACY_BY_PARAM_TRANSFORMER.items():
        _grp = transformer.commands.get(_sub)
        if not isinstance(_grp, click.Group):
            continue
        _cmd = _grp.commands.get(_verb)
        if _cmd is None:
            continue
        # ⛔ Never let an alias overwrite a real group of the same name.
        if isinstance(transformer.commands.get(_old), click.Group):
            continue
        _alias = copy.copy(_cmd)
        _alias.name = _old
        _alias.hidden = True
        transformer.add_command(_alias)


_register_legacy_transformer_by_param()
