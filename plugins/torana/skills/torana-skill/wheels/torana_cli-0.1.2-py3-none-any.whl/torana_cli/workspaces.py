"""torana workspaces — workspace collection commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_DRY_RUN, CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW, CollectionGroup
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 30),
    ("type", "TYPE", 32),
    ("state", "STATE", 10),
    ("is_default", "DEFAULT", 7),
    ("build_v2_enabled", "BUILD-V2", 9),
    ("description", "DESCRIPTION", 40),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(cls=CollectionGroup, singular="workspace")
def workspaces():
    """Manage workspaces.

    \b
    Examples:
      torana workspaces list
      torana workspaces create --name "My Workspace"
      torana workspaces summary
    """


@workspaces.command(name="list")
@click.option("--tenant-id", "tenant_id", default=None,
              help="List another tenant's workspaces (super-admin). Without it the "
                   "listing is scoped to the authenticated tenant.")
@click.option("--state", default=None,
              type=click.Choice(["active", "inactive", "archived"], case_sensitive=False),
              help="Filter by state.")
@click.option("--search", default=None, help="Search by name.")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False,
              help="Auto-paginate and return all results.")
@click.pass_context
def workspaces_list(ctx, tenant_id, state, search, page, page_size, fetch_all):
    """List workspaces.

    \b
    Examples:
      torana workspaces list
      torana workspaces list --format table
      torana workspaces list --json | jq '.items[] | {id, name}'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)

    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if tenant_id:
        params["tenant_id"] = tenant_id
    if state:
        params["state"] = state
    if search:
        params["search"] = search

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                p.update({k: v for k, v in params.items() if k not in ("skip", "limit")})
                data = client.get("workspaces", params=p)
                items = data.get("items", data if isinstance(data, list) else [])
                all_items.extend(items)
                total = data.get("total", len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items), "page": 1,
                      "page_size": len(all_items)}
        else:
            data = client.get("workspaces", params=params)
            if isinstance(data, list):
                result = {"items": data, "total": len(data), "page": page,
                          "page_size": effective_page_size}
            else:
                result = data
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@workspaces.command(name="create")
@click.option("--name", default=None)
@click.option("--description", default=None)
@click.option("--icon", default=None, help="Icon identifier (e.g. fa-shield).")
@click.option("--type", "workspace_type", default=None,
              help="Workspace type. Run 'torana workspace-templates categories' to list "
                   "available types. Ignored if --template-id is given (the template's "
                   "category wins).")
@click.option("--app-template", "app_template", default=None, metavar="APP_TEMPLATE_ID",
              help="Start from a bundled STARTER APP for this type (materializes its "
                   "artifacts at creation). Discover ids with "
                   "'torana workspaces app-templates list --type <t>'. Omit (or 'blank') "
                   "= blank app (today's behavior).")
@click.option("--bundle", "bundle_id", default=None, metavar="BUNDLE_ID",
              help="Install an APP BUNDLE (Spec E chained-proposal use-case app) at creation — "
                   "serial-replays its links into N real proposals + N versions. Discover ids "
                   "with 'torana build bundles list'. Mutually exclusive with --app-template.")
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.option("--if-not-exists", is_flag=True, default=False,
              help="Return existing workspace if one with the same name already exists.")
@click.pass_context
def workspaces_create(ctx, name, description, icon, workspace_type, app_template, bundle_id,
                      input_file, if_not_exists):
    """Create a new workspace.

    \b
    Examples:
      torana workspaces create --name "My Workspace" --description "..." --icon fa-shield
      torana workspaces create --name "My Workspace" --type vulnerability_management
      torana workspaces create --name "VM App" --type vulnerability_management_v2 --app-template cspm
      torana workspaces create --name "CISO" --type vulnerability_management_v2 --bundle ciso_posture
      torana workspaces create --name "My Workspace" --if-not-exists
      torana --dry-run workspaces create --name "My Workspace"
    """
    import sys
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    dry_run = ctx.obj.get(CTX_DRY_RUN, False) if ctx.obj else False

    if app_template and bundle_id:
        click.echo("ERROR: --app-template and --bundle are mutually exclusive.", err=True)
        sys.exit(2)

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if description:
        body["description"] = description
    if icon:
        body["icon"] = icon
    if workspace_type:
        body["type"] = workspace_type
    # Spec A app-template selection: namespaced into the shared template_id field.
    if app_template and app_template != "blank":
        body["template_id"] = f"app:{app_template}"
    # Spec E bundle selection: namespaced `bundle:<id>` into the same template_id field.
    if bundle_id and bundle_id != "blank":
        body["template_id"] = f"bundle:{bundle_id}"

    if not body.get("name"):
        click.echo("ERROR: --name is required (or provide --file with 'name' field).", err=True)
        sys.exit(2)

    if dry_run:
        click.echo("[dry-run] Would POST to workspaces/:")
        import json
        click.echo(json.dumps(body, indent=2, default=str))
        return

    client = _client(ctx)

    # App-template gap preview (§ 3.4.1): show what vocabulary resolves for this tenant —
    # and any fail-fast gap — BEFORE creating (parity with the FE Starter-App preview).
    if app_template and app_template != "blank":
        try:
            prev = client.get(f"vm/app-templates/{app_template}")
        except APIError as e:
            if getattr(e, "status_code", None) == 404:
                click.echo(f"ERROR: app template '{app_template}' not found. "
                           f"List with: torana workspaces app-templates list --type <t>", err=True)
                sys.exit(3)
            handle_api_error(e)
            return
        p = (prev or {}).get("preview", {})
        click.echo(f"App template: {prev.get('name')} ({prev.get('artifact_count')} artifacts)")
        if not p.get("resolvable", True):
            click.echo(f"  ⚠ Cannot create for this tenant — {p.get('gap')}", err=True)
            click.echo("  Fix the vocabulary gap (Spec C policy) and retry.", err=True)
            sys.exit(6)
        resolved = p.get("resolved") or {}
        if resolved:
            click.echo("  Vocabulary that will be applied:")
            for k, v in resolved.items():
                shown = v.get("expanded") or v.get("value")
                click.echo(f"    {k} = {shown}")
        if not _confirm("  Create this workspace and materialize the app?", yes=False, abort=False):
            return

    # ⛔ BUNDLE PRE-INSTALL CHECK — shown BEFORE the workspace is created, which is the
    # only moment the operator can still act on it (connect the integration first, or
    # pick a different app). Parity with the app-template preview above, and with the
    # FE's BundleSchemaCheck panel.
    #
    # ⚠️ WARN, NEVER BLOCK. An empty column is a STATE, not a defect — the tenant may
    # connect a scanner next week and the same bundle is then exactly right. A refusal
    # here would block a correct install. `refused` (a removed column or an
    # incompatible type) is a different axis and DOES stop the install, server-side.
    if bundle_id and bundle_id != "blank":
        try:
            chk = client.get(f"workspaces/build-v2/bundles/{bundle_id}/schema-check")
        except (APIError, AuthError):
            chk = None          # best-effort: never block a create on the preview
        empties = (chk or {}).get("empty_predicate_columns") or []
        if empties:
            click.echo("")
            click.echo("  ⚠ Some of this app filters on data your account does not have yet:")
            for e in empties:
                used = ", ".join(e.get("used_by") or []) or "-"
                click.echo(f"    • {e.get('table')}.{e.get('column')} — holds no values here")
                click.echo(f"      affects: {used}")
            click.echo("    These parts will be empty until an integration writes those "
                       "columns.")
            click.echo("    Everything else installs and works normally.")
            if not _confirm("  Continue?", yes=False, abort=False):
                return

    if if_not_exists:
        try:
            existing = client.get("workspaces", params={"search": body["name"], "limit": 10})
            items = existing.get("items", existing if isinstance(existing, list) else [])
            for item in items:
                if item.get("name") == body["name"]:
                    click.echo(
                        "Warning: Workspace already exists with this name — returning existing.",
                        err=True,
                    )
                    output(item, fmt=fmt)
                    return
        except (APIError, AuthError):
            pass

    try:
        data = client.post("workspaces", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created workspace: {data.get('id', 'unknown')}")
        click.echo(f"  Name: {data.get('name', '')}")


@workspaces.command(name="summary")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False,
              help="Auto-paginate and return all results.")
@click.pass_context
def workspaces_summary(ctx, page, page_size, fetch_all):
    """Get workspace statistics (all workspaces).

    \b
    Example:
      torana workspaces summary --json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "workspaces/stats/summary"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size,
                     "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@workspaces.command(name="schema-check")
@click.argument("workspace_id")
@click.pass_context
def workspaces_schema_check(ctx, workspace_id):
    """⭐ Is the app I INSTALLED here still current against MY schema?

    \b
    ⚠️ A DIFFERENT question from `torana build bundles schema-check`, and the difference
    is why this exists:
      • `build bundles schema-check <id>`  — would this DEFINITION install cleanly?
      • `workspaces schema-check <ws>`     — does the app ALREADY INSTALLED here still work?

    \b
    ⛔ They diverge the moment either side moves. A bundle is authored once and installs
    into many workspaces across tenants that migrate independently, and the definition
    keeps being revised after an install. "The current definition is fine" is NOT
    evidence that a workspace installed six weeks ago still works.

    \b
    This resolves the bundle the workspace was actually BUILT FROM (source_bundle_id +
    source_bundle_version) and checks THAT version — never the latest.

    \b
    Exit code 1 when the installed app is refused, 0 when it is current.
    ⛔ A workspace not built from a bundle exits 2 — nothing to check is NOT a pass.

    \b
    Example:
      torana workspaces schema-check 0f3c…-…
    """
    import sys

    fmt = ctx.obj.get(CTX_FORMAT) if ctx.obj else None
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    client = _client(ctx)
    try:
        data = client.get(f"workspaces/{workspace_id}/schema-check")
    except APIError as e:
        # ⚠️ handle_api_error owns the exit code (the shared convention across this CLI),
        # so a 409 "not built from a bundle" surfaces as a non-zero exit with the reason
        # printed. That is the property that matters: it must never look like a pass.
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml"):
        output(data, fmt=fmt, fields=fields, raw=raw)
    else:
        # ⭐ Name the bundle+version resolved. Without it the reader cannot tell whether
        # a clean verdict refers to what they actually installed.
        click.echo(f"workspace       : {data.get('workspace_id')}")
        click.echo(f"installed bundle: {data.get('source_bundle_id')} "
                   f"v{data.get('source_bundle_version')}")
        click.echo("")
        click.echo(data.get("summary") or "(no summary)")
        broken = [v for v in (data.get("verdicts") or []) if not v.get("ok")]
        if broken:
            click.echo("")
            for v in broken:
                click.echo(f"  artifact: {v.get('artifact_key')} (link {v.get('link_id')})")
                if v.get("unverifiable"):
                    click.echo(f"    COULD NOT VERIFY: {v['unverifiable']}")
                for b in (v.get("breaks") or []):
                    click.echo(f"    {b.get('message')}")
        else:
            click.echo(f"\n{data.get('artifacts_checked', 0)} artifact(s) checked, "
                       f"none broken.")

    if data.get("refused"):
        sys.exit(1)


# ── Background jobs (SA) ──────────────────────────────────────────────────────
# Surface parity for the two workspace sweep schedulers. They run unattended
# across every tenant, so without a CLI/FE view their only evidence was a
# container log line.

@workspaces.command(name="background-jobs")
@click.pass_context
def workspaces_background_jobs(ctx):
    """Show the workspace sweep schedulers and their last run (super_admin).

    Two DISTINCT schedulers:
      - Advisor sweep      LLM analysis that rebuilds recommendations.
      - Landing-page sweep KPI queries + attention cards (plain SQL, no LLM).

    \b
    Example:
      TORANA_PROFILE=SA torana workspaces background-jobs
      TORANA_PROFILE=SA torana workspaces background-jobs --json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    client = _client(ctx)
    try:
        data = client.get("admin/workspaces/background-jobs")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Flatten to one row per job so the default table view is readable; --json
    # still returns the full envelope including scheduler_running.
    if fmt == "text" and not raw and isinstance(data, dict):
        rows = []
        for j in data.get("jobs", []):
            rows.append({
                "name": j.get("name"),
                "enabled": j.get("enabled"),
                "schedule": j.get("schedule"),
                "last_run_at": j.get("last_run_at") or "never",
                "env_var": j.get("env_var"),
            })
        output({"items": rows, "total": len(rows)}, fmt=fmt, fields=fields, raw=raw)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


# ── App-template catalog (Spec A § 3.4.1) ─────────────────────────────────────
# The discover half of the CLI's discover→create flow: browse bundled starter apps
# for a workspace type, then name one in `workspaces create --app-template <id>`.
# (Creating a workspace FROM a template is `create`, not a verb here.)

@workspaces.group(name="app-templates", invoke_without_command=True)
@click.pass_context
def app_templates(ctx):
    """Bundled starter apps for a workspace type. Use `list` / `show`."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@app_templates.command(name="list")
@click.option("--type", "workspace_type", default=None,
              help="Filter to app templates for this workspace type "
                   "(e.g. vulnerability_management_v2).")
@click.pass_context
def app_templates_list(ctx, workspace_type):
    """List bundled app templates (optionally for one workspace type)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    params = {}
    if workspace_type:
        params["workspace_type"] = workspace_type
    try:
        data = client.get("vm/app-templates", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields, raw=raw, columns=[
        ("id", "ID", 20), ("name", "NAME", 30), ("workspace_type", "TYPE", 28),
        ("artifact_count", "ARTIFACTS", 10),
    ])


@app_templates.command(name="show")
@click.argument("template_id")
@click.pass_context
def app_templates_show(ctx, template_id):
    """Show one app template + a grounded vocabulary preview for this tenant."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.get(f"vm/app-templates/{template_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt)
