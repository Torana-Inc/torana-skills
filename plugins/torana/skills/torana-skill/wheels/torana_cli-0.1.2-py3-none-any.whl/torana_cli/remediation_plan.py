"""torana remediation-plan <PLAN_ID> — one remediation plan: read it, decide it, mint its read token, open its PR.

FIX_PR_SPEC.md § 3.4.3 / § 3.4.7. A decision sends the fingerprint the person saw (`get` prints it), and the
server compares it in the same UPDATE that changes the state: a plan that moved while you read it answers 409
`plan_changed`, and nothing is decided on a plan nobody saw.
"""

import base64
import json
import os
import sys

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import EXIT_PERMISSION, EXIT_USAGE, EXIT_VALIDATION, APIError, handle_auth_error
from torana_cli.main import CTX_FIELDS, CTX_FORMAT
from torana_cli.output import output
from torana_cli import remediation_proposal as rprop
from torana_cli.remediation_plans import (
    _call, _client, mint_or_revoke, plan_api_error, refuse_token_on_argv, with_blocked_by_text,
)

_OPEN_PR_TIMEOUT = 280.0      # below nginx's 300 s for this route (§ 3.4.3), so the client reads the server's own
#                              answer (504 pr_pending, 502) instead of a dropped connection; integration's is 240 s

_CLASS_WORDS = {2: "Lock only", 3: "Manifest edit", 4: "Code change needed"}

#: Why a `proposed` plan cannot be approved, in the server's codes (DF `not_approvable_reasons`).
#: ⛔ The CLI prints the SERVER's reason, never its own guess: the old line listed four possible
#: causes and left the reader to work out which, and two of the causes it listed (a class-4 package,
#: another repository's open code change) are not visible in the plan at all.
_BLOCK_WORDS = {
    "needs_human": "an edit needs a person (use `override --set`)",
    "bump_to_null": "a package has no target version",
    "blocked_on": "a package is declared elsewhere; that declaration changes first",
    "probe_stale": "the last probe does not cover this plan",
    # ⚠️ Reached only when NO usable codemod was reported (phase 5): with one, the server drops this
    # reason and the plan is approvable. The words say which, so a reader is not told their rewrite
    # does not exist while the "Code change" block above prints it.
    "class_4_needs_code_change": ("this upgrade needs a CODE change and no usable codemod was "
                                  "reported (see the Code change line)"),
    "member_out_of_scope": "a place that must change with this fix is in a repository this plan does not cover",
    # ⛔ NOT A FAILURE — A DIFFERENT LANE (B3, `class_4_laptop_lane_only`). The platform never carries
    # source bytes, so a plan that rewrites source cannot have its PR opened by the App; it is opened
    # from the checkout that produced the rewrite. The words give the command rather than the rule,
    # because a reader who hits this needs the next step, not the reason.
    "class_4_laptop_lane_only": ("this plan changes source files, so its PR is opened from the checkout that "
                                 "made the change, not by the platform: `remediation_apply.py --plan-id <id> "
                                 "--repo <checkout> --apply --commit --push-pr`"),
}

#: ⚠️ FALLBACK ONLY, for an `api_diff` stored before the library wrote `blind_to_words` / `method_words`
#: (torana-reachability 1.13.0, api_diff_check: the same strings). A current answer's words are printed verbatim.
_BLIND_TO_WORDS = {
    "returned_object": "methods on returned objects",
    "star_import": "import *",
    "dynamic_name": "names built at runtime (getattr, patch strings)",
    "wrapper_package": "use through a wrapper package",
    "class_body_import": "imports inside a class body",
}
_METHOD_WHY_WORDS = {"parser_missing": "no parser", "npm": "npm: the call graph reads Python only",
                     "truncated": "the call graph was truncated"}


def _block_words(reason: str) -> str:
    if reason.startswith("class_4_plan_open:"):
        pkg = reason.split(":", 1)[1]
        return (f"a code change is open for {pkg}: another repository uses a symbol this upgrade "
                f"changes; refuse or supersede that plan first")
    return _BLOCK_WORDS.get(reason, reason)


def _api_diff_line(x: dict) -> str:
    """What the upgrade changes in the package's API, for ONE package.

    ⛔ PRINTED FOR EVERY ROW THAT ASKS THE API QUESTION (`asks_api_question`), ANSWER OR NOT. A line only when there is an answer would
    make "nobody checked" and "nothing changed" look identical in a terminal, which is the one
    confusion the API diff exists to remove."""
    d = x.get("api_diff") or {"state": "not_requested"}
    state = d.get("state")
    if state != "ready":
        # ⛔ WORDS, NOT ONLY A CODE. `reason` is the gate's machine code, `why` the library's sentence for a
        # reader; printing `reason or why` showed the code and dropped the sentence whenever both existed.
        code = str(d.get("reason") or "").strip()
        sentence = str(d.get("why") or "").strip()
        line = f"    API diff: {state}" + (f" ({code})" if code else "") \
            + " — this does NOT mean the API is unchanged"
        return line + (f"\n      {sentence}" if sentence else "")
    touched = d.get("touched") or []
    noop = d.get("annotation_only") or []
    # ⛔ "none used here" IS A CLAIM ABOUT THIS REPOSITORY'S CODE, so it may only be made when the search found
    # nothing at all. Since the planner weighs declarations (`signature_delta`), a ready row can carry symbols
    # this code really does call whose signature move cannot break the call; calling that "none used here"
    # states an absence as a fact. Same correction as the PR body and the FE.
    if touched:
        used = f"{len(touched)} used here"
    elif noop:
        used = f"none that can change a call site; {len(noop)} used here, annotation only"
    else:
        used = "none used here"
    line = (f"    API diff: {d.get('removed', 0)} removed, {d.get('renamed', 0)} renamed, "
            f"{d.get('signature_changed', 0)} changed; {used}")
    if d.get("complete") is False:
        line += "  [INCOMPLETE extraction: these counts are a floor]"
    line += _method_line(d)
    for h in touched[:5]:
        line += f"\n      {h.get('symbol')} at {h.get('file')}:{h.get('line')}"
        if h.get("sig_detail"):
            line += f"\n        {h.get('sig_class')}: {h.get('sig_detail')}"
    for h in (d.get("deprecated") or [])[:5]:
        line += f"\n      deprecated, still served: {h.get('symbol')} at {h.get('file')}:{h.get('line')}"
    # ⚠️ PRINTED, NOT HIDDEN. A NARROWED annotation runs fine and still fails a type checker, so a reader
    # deciding this plan is owed the list rather than a count they cannot act on.
    for h in noop[:5]:
        line += (f"\n      no call-site change: {h.get('symbol')} at {h.get('file')}:{h.get('line')}"
                 + (f" — {h.get('sig_detail')}" if h.get("sig_detail") else ""))
    if noop:
        line += ("\n      (a narrowed annotation still fails a type checker; the build and test gates are"
                 " where that shows)")
    return line


def _method_line(d: dict) -> str:
    """How the check looked (FIX_KNOWLEDGE_CONVERGENCE § 3.6.9): the call graph and what it cannot see, or the name
    search it fell back to. Nothing for an answer older than the call-graph check (no `method`)."""
    method = d.get("method")
    if d.get("method_words"):                            # ⭐ the library's words, verbatim (one computation)
        blind = d.get("blind_to_words") or []
        return f"\n      method: {d['method_words']}" + (f" — blind to: {', '.join(blind)}" if blind else "")
    if method == "callgraph":
        blind = [_BLIND_TO_WORDS.get(b, b) for b in d.get("blind_to") or []]
        return "\n      method: call graph" + (f" — blind to: {', '.join(blind)}" if blind else "")
    if method == "word":
        why = _METHOD_WHY_WORDS.get(d.get("method_why") or "", d.get("method_why") or "")
        return "\n      method: name search" + (f" ({why})" if why else "") + " — it over-reports"
    return ""


def asks_api_question(p: dict) -> bool:
    """A class-3 bump, or a class-2 move that crosses a major version (`api_question`, § 3.6.7 (b)); never a
    removal. The same test DF, the PR body and the FE use."""
    cls = int(p.get("class") or 0)
    return not p.get("removal") and (cls == 3 or (cls == 2 and bool(p.get("api_question"))))


#: Which lane opened the PR (`plan.pr_opened_by`), in words. The FE prints the same three
#: (`remediation-plan-view.ts` `openedByWords`); an unknown lane is de-underscored, never bare.
_OPENED_BY_WORDS = {
    "target_ci": "opened by this repository's own CI",
    "platform": "opened by the platform",
    "developer": "opened by a developer",
}


def _opened_by_words(code: str) -> str:
    """⛔ The fallback KEEPS the "opened by" prefix, so a lane this build does not know still reads as a
    sentence and matches the FE's `openedByWords` exactly. Dropping it gave "(some new lane)" here and
    "opened by some new lane" there — the same datum worded two ways on two surfaces."""
    return _OPENED_BY_WORDS.get(code) or f"opened by {str(code).replace('_', ' ')}"


_PR_STATE_WORDS = {
    "none": "no PR yet", "opening": "Opening PR…", "opening_stale": "Opening stalled — the next run retries",
    "open": "PR open", "merged": "Merged", "closed": "Closed without merge",
}


def _refused_pushes(p: dict) -> list:
    """The `pr_refused` history entries, while the plan still has no PR.

    ⛔ `PR: no PR yet` IS TRUE AND HIDES THE ANSWER. Verification refuses a pushed branch by
    releasing the claim and LEAVING THE PLAN APPROVED, so `pr_state` goes back to `none` — the same
    words a plan that was never pushed prints. An operator asking "my CI pushed a PR and nothing
    happened" reads `no PR yet` and learns nothing (observed 2026-10-21: PR #327 refused twice, both
    invisible here). The reason is already on the plan's history; this only finds it.
    """
    if (p.get("pr_state") or "none") != "none" or p.get("pr_number"):
        return []
    return [h for h in p.get("history") or [] if h.get("action") == "pr_refused"]


def _pid(ctx) -> str:
    return ctx.obj.get("_plan_id", "") if ctx.obj else ""


def _fmt(ctx) -> str:
    return ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"


@click.group(name="remediation-plan", invoke_without_command=True)
@click.argument("plan_id", metavar="PLAN_ID")
@click.pass_context
def remediation_plan(ctx, plan_id):
    """One remediation plan by ID: get, decide (approve / override / refuse / reconsider),
    target-token, the push lane (pr-text, reserve-pr, then verify-branch BEFORE you open the PR
    and record-pr after; release-pr
    on failure), open-pr (the platform pushes it).

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> get
      torana remediation-plan <PLAN_UUID> approve --fingerprint sha256:<hex> --accept-downgrade
      torana remediation-plan <PLAN_UUID> refuse --note "pinned on purpose until the SDK migration"
    """
    ctx.ensure_object(dict)
    ctx.obj["_plan_id"] = plan_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


# ── get ────────────────────────────────────────────────────────────────────────────

def _package_line(p: dict) -> str:
    cls = "Remove dependency" if p.get("removal") else _CLASS_WORDS.get(int(p.get("class") or 0), "?")
    line = f"  {p['package']} {p.get('installed') or '?'} → {p.get('target') or 'removed'}  [{cls}]"
    if p.get("partial"):
        n = p.get("open_alert_ids")
        n = n if isinstance(n, int) else len(n or [])
        line += f"  partial: {n} flaw(s) stay open ({p.get('requested_target')} does not resolve)"
    if p.get("blocked_on"):
        line += f"  blocked on: {p['blocked_on']}"
    if asks_api_question(p):
        line += "\n" + _api_diff_line(p)
    for ms in _move_scopes(p):
        for r in ms.get("review") or []:
            line += f"\n    ⚠ review: {r.get('words') or r.get('file')}"
        for st in ms.get("stale") or []:
            if st.get("file"):
                line += f"\n    ⚠ the Atlas named {st.get('file')}:{st.get('line')}, but {st.get('why')}"
            else:   # a repository the planner could not check at all (F65): there is no file to name
                line += f"\n    ⚠ not checked: {st.get('why')}"
        if ms.get("source") == "none" and ms.get("why"):
            line += f"\n    other repositories not checked: {ms['why']}"
    return line


def _move_scopes(p: dict) -> list:
    """Every subject's `move_scope` on a package: DF stores `move_scope_by_subject` (one per proposing repository,
    FIX_KNOWLEDGE_CONVERGENCE § 3.4.6) and every reader takes the union; a bare `move_scope` is a single proposal."""
    by = p.get("move_scope_by_subject")
    if isinstance(by, dict) and by:
        return [by[k] for k in sorted(by) if isinstance(by[k], dict)]
    return [p["move_scope"]] if isinstance(p.get("move_scope"), dict) else []


#: One short phrase per gate 4/5 status, for the text view. ⛔ `error` and `failed` must not read alike:
#: `failed` means the suite ran and the project is broken, `error` that it could not run at all, so the fix
#: is UNJUDGED. A reader who conflates them abandons a good fix.
_GATE_WORDS = {"passed": "passed", "failed": "FAILED", "error": "could not run (unjudged)",
               "pre_existing": "already failing before the fix", "not_detected": "no suite found",
               "unsupported": "suite not supported", "not_run": "not run"}

#: The coverage verdict's own vocabulary. ⚠️ A SEPARATE TABLE because it answers a different question and `no-suite` must
#: never be read as a pass: the three words are "the suite ran those lines", "it did not", "we did not measure".
_COVERAGE_WORDS = {"covered": "the suite ran the rewritten lines",
                   "uncovered": "the suite NEVER ran some rewritten lines",
                   "no-suite": "not measured"}


#: One phrase per `codemod.state` (phase-5 spec § 3.6.1). ⛔ `not_run` and `complete` must never read
#: alike: "nobody looked" is not "looked, nothing to do".
_CODEMOD_WORDS = {
    "complete": "every call site migrated",
    "partial": "SOME call sites migrated, the rest listed below",
    "refused": "REFUSED — nothing was proposed",
    "unavailable": "could not run here",
    "not_run": "not attempted",
}

#: Gate B's levels, in the order a reader should take them: files, syntax, then the one that decides.
_GATE_B_ORDER = (("l0_files", "files"), ("l1_syntax", "syntax"), ("l2_closed_loop", "closed loop"),
                 ("l3", "build/tests/coverage"))


def _codemod_lines(p: dict) -> list:
    """The "Code change" block: what the codemod rewrote, and what checked it (§ 3.6.6).

    ⛔ ABSENT IS STATED ONLY WHEN IT MATTERS. A class-2/3 plan has no code to change, so printing
    "codemod: not reported" on every lock bump would be noise; a CLASS-4 plan with no block is a
    different thing entirely — a plan nobody tried to migrate — and says so.
    """
    cm = p.get("codemod")
    class4 = bool(p.get("class4_package")) or any(int(x.get("class") or 0) == 4
                                                  for x in p.get("effective_packages") or [])
    if not isinstance(cm, dict):
        return ["Code change (codemod): not reported by a runner"] if class4 else []
    state = str(cm.get("state") or "")
    word = _CODEMOD_WORDS.get(state, state or "not reported")
    words = str(cm.get("words") or "").strip()
    out = [f"Code change (codemod): {word}" + (f" — {words}" if words else "")]
    if cm.get("decline"):
        out.append(f"  declined: {cm['decline']}")
    for st in cm.get("sites") or []:
        where = f"{st.get('file')}:{st.get('line')}"
        why = str(st.get("why") or "").strip()
        sub = str(st.get("sub") or "")
        op = f"{sub} {st.get('op')}" if st.get("op") else sub
        rename = (f" {st.get('old')} → {st.get('new')}" if st.get("old") and st.get("new") else "")
        out.append(f"  {where}  {st.get('status')}  ({op}{rename})" + (f" — {why}" if why else ""))
    for f in cm.get("files") or []:
        lines = ", ".join(str(n) for n in f.get("lines") or [])
        tag = " MODEL-AUTHORED" if f.get("model_authored") else ""
        out.append(f"  {f.get('file')}: line(s) {lines}{tag}")
    # ⛔ EVERY LEVEL NAMED, including one that did not run. An omitted level reads as one that
    # passed, and `l2_closed_loop` is the level a class-4 approval actually rests on.
    gb = cm.get("gate_b") or {}
    checks = []
    for key, label in _GATE_B_ORDER:
        v = gb.get(key)
        if v is None:
            checks.append(f"{label} not reported")
            continue
        if key == "l3":
            checks.append(f"{label} {v.get('status') or 'not_run'}")
            continue
        ok = v.get("ok")
        checks.append(f"{label} " + ("ok" if ok is True else "FAILED" if ok is False else "did not run"))
    out.append("  checked: " + " · ".join(checks))
    l2 = gb.get("l2_closed_loop") or {}
    if l2.get("basis") == "convention":
        out.append("  ⚠ the closed loop placed the calls by CONVENTION, not measurement: only the "
                   "import lines were really verified")
    return out


def render_codemod_diff(p: dict) -> str:
    """Each rewritten file's recorded diff, or one line saying why there is none (`get --diff`).

    ⛔ THE RECORDED BYTES, NOT A FRESH DIFF. The applier computed this against the copy it rewrote and
    the plan stores it beside the two sha256s the push lane verifies; re-deriving it here from a
    checkout would show a DIFFERENT diff the moment the working tree moved, and a reader comparing the
    two would have no way to tell which one the approval covers.

    ⚠️ `diff_omitted` is a real state, not an error: the applier bounds what it records per file, so a
    large rewrite is summarised by its line numbers and hashes and read in the PR instead.
    """
    cm = p.get("codemod")
    if not isinstance(cm, dict):
        return "No code change recorded for this plan."
    files = [f for f in (cm.get("files") or []) if isinstance(f, dict)]
    if not files:
        return "No file was rewritten, so there is no diff."
    out = []
    for f in files:
        head = f"── {f.get('file')}  line(s) {', '.join(str(n) for n in f.get('lines') or [])}"
        if f.get("model_authored"):
            head += "  [MODEL-AUTHORED]"
        out.append(head)
        diff = str(f.get("diff") or "")
        if diff:
            out.append(diff.rstrip("\n"))
        elif f.get("diff_omitted"):
            out.append("  (the applier did not record a diff for this file — it is bounded; read it in the PR)")
        else:
            out.append("  (no diff recorded)")
        out.append("")
    return "\n".join(out).rstrip("\n")


def _gate_lines(p: dict) -> list:
    """The runner's reported gates 4 and 5, or one honest line saying nothing was reported.

    ⛔ NULL IS "NOT REPORTED", NEVER "PASSED" and never "there is no suite" (phase-4 spec § 3.3.1). A gate
    that ran and found no suite says so in its OWN status, which is a different claim from the plan never
    having heard from a runner.

    ⚠️ ATTRIBUTED. The platform cannot re-run a customer's suite on the customer's compute (spec P4 / F7),
    so the line says who reported it rather than presenting it as a Torana finding.
    """
    g = p.get("gates")
    if not g:
        return ["Gates 4-5 (build, tests, coverage of the rewritten lines): not reported by a runner"]
    parts = []
    for key, label in (("gate_4_build", "build"), ("gate_5_tests", "tests")):
        st = str((g.get(key) or {}).get("status") or "not_run")
        parts.append(f"{label} {_GATE_WORDS.get(st, st)}")
    lines = ["Gates 4-5 (reported by the runner, not verified by Torana): " + " · ".join(parts)]
    # ⛔ A plan from before the coverage verdict existed has no `gate_5_coverage` key, and that is "not reported", not
    # "nothing was rewritten": only a runner that actually looked may claim either.
    cov = g.get("gate_5_coverage")
    st = str((cov or {}).get("status") or "")
    word = _COVERAGE_WORDS.get(st, "not reported") if cov else "not reported"
    why = str((cov or {}).get("why") or "").strip()
    lines.append(f"Gate 5 coverage (the rewritten lines): {word}" + (f" — {why}" if why else ""))
    return lines


#: The two history entries the platform writes when the plan's PR is decided on GitHub (DF
#: `complete_by_system` / `refuse_by_system`), and what happened in words.
_PR_DECIDED = {"complete": "Merged", "refuse": "Closed without merge"}
_PR_DECIDED_REASONS = {"PR merged", "PR closed without merge"}


def _pr_decided_line(p: dict) -> str:
    """Who merged or closed the plan's PR (B17), from the LAST such history entry; "" when it is undecided.

    ⛔ ONLY THE WEBHOOK NAMES A PERSON. `github_login` is GitHub's own statement of who merged or closed it, and
    DF writes it on the webhook lane only. A `reconcile` is Torana going to ASK GitHub (F40: whoever triggered it
    did not merge it), so it never prints a name; nor does an entry that recorded none, which says so rather than
    leaving the reader to assume the system did it.
    """
    entries = [h for h in p.get("history") or []
               if h.get("action") in _PR_DECIDED and h.get("reason") in _PR_DECIDED_REASONS]
    if not entries:
        return ""
    h = entries[-1]
    what, at, lane, login = _PR_DECIDED[h["action"]], h.get("at"), h.get("lane"), h.get("github_login")
    verb = "merged" if h["action"] == "complete" else "closed"
    if login and lane == "webhook":
        return f"{what} by GitHub user @{login} (reported by the GitHub webhook) at {at}"
    if lane == "reconcile":
        return f"{what}: Torana found this by checking GitHub at {at}; who {verb} it was not recorded"
    if lane == "manual":
        return f"{what}: set by hand in Torana by {h.get('actor')} at {at}; who {verb} it on GitHub was not recorded"
    return f"{what} at {at}; who {verb} it was not recorded"


def render_plan(p: dict) -> str:
    """The text view: what a person needs to decide, downgrades first (FD: a downgrade is never missed)."""
    out = [f"Plan {p.get('id')}  [{p.get('state')}]  {p.get('description', '')}",
           f"Target: {p.get('target_repository')}  lock: {p.get('resolve_file')} ({p.get('lock_format')})"
           + ("  dev only" if p.get("dev_only") else ""),
           f"Fingerprint (send it to approve/override): {p.get('effective_fingerprint')}"]
    if p.get("pr_draft_reasons"):
        out.append("⚠ PR OPENS AS A DRAFT (the PR body warns the reviewer): " + ", ".join(p["pr_draft_reasons"]))
    if p.get("downgrades"):
        out.append("⚠ DOWNGRADES (acknowledge with --accept-downgrade):")
        out += [f"  {d['package']} {d.get('from')} → {d.get('to')}" for d in p["downgrades"]]
    out.append("Packages:")
    out += [_package_line(x) for x in p.get("effective_packages") or p.get("packages") or []]
    edits = p.get("effective_edits") or p.get("edits") or []
    if edits:
        out.append("Edits:")
        for e in edits:
            out.append(f"  {e['file']}:{e['line']} {e['action']} `{e.get('from')}`"
                       + (f" → `{e['to']}`" if e.get("to") else "")
                       + (f"  needs a person: {e['needs_human']}" if e.get("needs_human") else ""))
    if p.get("co_movers"):
        out.append("Also moves: " + ", ".join(f"{c['package']} {c.get('from')} → {c.get('to')}"
                                              for c in p["co_movers"]))
    members = p.get("members")
    out.append(f"Fixes {len(members) if isinstance(members, list) else members or 0} alert(s)")
    if p.get("probe_stale"):
        out.append("Needs a fresh check: the last probe does not cover this plan (approve is refused until then)")
    if p.get("needs_ack") and p.get("state") == "proposed":
        out.append("Acknowledge before approving: " + ", ".join(p["needs_ack"]))
    if not p.get("approvable", True) and p.get("state") == "proposed":
        reasons = p.get("not_approvable_reasons") or []
        out.append("Not approvable as proposed: "
                   + ("; ".join(_block_words(r) for r in reasons) if reasons
                      else "a needs_human edit, a bump without a target, blocked_on, or stale"))
        # ⛔ The server's sentences (`out_of_scope_words`, § 3.4.6), verbatim: which place, and how to cover it.
        out += [f"  {w}" for w in p.get("out_of_scope_words") or []]
    for b in p.get("blocked_by") or []:
        out.append(f"Waiting on {b.get('plan_id') or 'a lock not yet planned'} ({b.get('lock_key')}): "
                   f"{b.get('reason')}")
    out.append(f"PR: {_PR_STATE_WORDS.get(p.get('pr_state') or 'none', p.get('pr_state'))}"
               + (f"  {p['pr_url']}" if p.get("pr_url") else "")
               # ⛔ SAID, NOT IMPLIED. Under option A the target repository's own CI pushes the branch with its
               # own workflow token, so a reader looking at a PR the platform proposed is owed the fact that
               # their CI is what opened it. Absent on a plan that never recorded a lane: not a claim either way.
               + (f"  ({_opened_by_words(p['pr_opened_by'])})" if p.get("pr_opened_by") else ""))
    decided = _pr_decided_line(p)
    if decided:
        out.append(decided)
    out.extend(_codemod_lines(p))
    out.extend(_gate_lines(p))
    # ⛔ THREE STATES, AND `None` IS "NOT DETERMINED", NEVER "NOT PROTECTED". The detailed protection settings need
    # admin rights the GitHub App deliberately does not request, so the platform can fail to find out; printing that
    # silence as "unprotected" would state a fact about the customer's repository nobody checked. Only once there is
    # a PR to talk about.
    if p.get("pr_url"):
        out.append("Base branch: " + {True: "protected",
                                      False: "NOT protected",
                                      }.get(p.get("base_branch_protected"), "protection not determined"))
    # ⭐ A PR SET WAS INVISIBLE HERE. One lock can be served by declarations in several repositories, so a plan
    # is often one of N — the API has said so in `pr_set` all along and this view never printed it, which made a
    # three-repository change look like a standalone one.
    pr_set = p.get("pr_set") or []
    if pr_set:
        out.append(f"PR set: this plan and {len(pr_set)} other(s) serve the same lock "
                   f"(the order they merge in does not matter)")
        out += [f"  {x.get('target_repository')}  [{x.get('state')}]"
                + (f"  {x['pr_url']}" if x.get("pr_url") else "") for x in pr_set]
    # ⛔ PRINTED VERBATIM. The server owns these words (it is the side that knows the set's states), and the
    # thing it says — do not rebuild while the set is part-landed — is measured, not advisory.
    window = p.get("pr_set_window")
    if isinstance(window, dict) and window.get("words"):
        out.append(window["words"])
    refused = _refused_pushes(p)
    if refused:
        last = refused[-1]
        out.append(f"{len(refused)} pushed PR(s) refused by the platform, last at {last.get('at')}"
                   + (f": {last.get('reason')}" if last.get("reason") else ""))
    lease = p.get("lease")
    if lease:
        out.append(f"Being applied by {lease.get('holder_subject')} ({lease.get('holder_run')}) until "
                   f"{lease.get('expires_at')}")
    for m in p.get("token_mints") or []:
        out.append(f"Read access to {m.get('target_repository')} issued to {m.get('actor')} until "
                   f"{m.get('expires_at')}" + (f", revoked {m['revoked_at']}" if m.get("revoked_at") else "")
                   + (f" ({m.get('outcome')})" if m.get("outcome") != "minted" else ""))
    if p.get("decided_by") == "system":
        # The tenant's require_plan_approval is off: the PR is the only gate (`remediation-plans settings`).
        out.append(f"Approved by the system at {p.get('decided_at')}: no person approved it in Torana; "
                   "the PR review is the gate"
                   + (f" ({p['decision_note']})" if p.get("decision_note") else ""))
    elif p.get("decided_by"):
        out.append(f"Last decision: {p.get('decided_by')} at {p.get('decided_at')}"
                   + (f": {p['decision_note']}" if p.get("decision_note") else ""))
    return "\n".join(out)


@remediation_plan.command(name="get")
@click.option("--diff", "show_diff", is_flag=True,
              help="Also print the codemod's diff for each rewritten file (class 4).")
@click.pass_context
def remediation_plan_get(ctx, show_diff):
    """Get a plan: packages, edits, downgrades, fingerprint, blocked_by, PR state, lease and read-token history.

    \b
    A plan approved by the system (the tenant's require_plan_approval is off) says so, and
    `pr_draft_reasons` (downgrade, partial) says why its PR opens as a draft.

    \b
    ⚠️ `--diff` prints the bounded diff the applier recorded for each file it rewrote — the SAME bytes
    the plan's fingerprint approves and the push lane verifies by hash. It is omitted by default
    because a plan's diff is the long part of the output and most reads do not need it.

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> get
      torana remediation-plan <PLAN_UUID> get --diff
      torana remediation-plan <PLAN_UUID> get --format json
    """
    data = _call(_client(ctx).get, f"remediation-plans/{_pid(ctx)}") or {}
    if _fmt(ctx) == "text" and not ctx.obj.get(CTX_FIELDS):
        click.echo(render_plan(data))
        if show_diff:
            click.echo(render_codemod_diff(data))
        return
    output(with_blocked_by_text(data), fmt=_fmt(ctx), fields=ctx.obj.get(CTX_FIELDS))


# ── decisions ──────────────────────────────────────────────────────────────────────

def _decide(ctx, verb: str, body: dict) -> None:
    try:
        data = _client(ctx).post(f"remediation-plans/{_pid(ctx)}/{verb}", json=body)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        if e.status_code == 409 and isinstance(e.detail, dict) and e.detail.get("error") == "plan_changed":
            click.echo("the plan changed while you were reading it: run `get` again and decide on what it says now",
                       err=True)
        plan_api_error(e)
        return
    if _fmt(ctx) == "text" and isinstance(data, dict) and data.get("id"):
        click.echo(render_plan(data))
        return
    output(data, fmt=_fmt(ctx), fields=ctx.obj.get(CTX_FIELDS))


@remediation_plan.command(name="approve")
@click.option("--fingerprint", required=True, help="The effective fingerprint `get` printed.")
@click.option("--accept-downgrade", is_flag=True, help="Acknowledge that a package moves backwards.")
@click.option("--accept-partial", is_flag=True, help="Acknowledge that some flaws stay open.")
@click.option("--accept-unknown-api-diff", is_flag=True,
              help="Acknowledge that NOBODY has checked what the upgrade changes in the package API.")
@click.option("--accept-deprecated-names", is_flag=True,
              help="Acknowledge that this code uses names the upgrade deprecates (they still work, for now).")
@click.option("--accept-unverified-scope", is_flag=True,
              help="Acknowledge that other repositories were not checked for pins that must move with this fix.")
@click.option("--accept-build-patch", is_flag=True,
              help="Acknowledge that you checked the build step patching this package still applies to the new "
                   "version.")
@click.option("--accept-partial-codemod", is_flag=True,
              help="Acknowledge that some uses of the old name were NOT migrated and are left for you. The PR "
                   "still opens as a DRAFT.")
@click.option("--accept-model-drafted", is_flag=True,
              help="Acknowledge that a model wrote part of the code change. The PR still opens as a DRAFT.")
@click.option("--note", default=None)
@click.pass_context
def remediation_plan_approve(ctx, fingerprint, accept_downgrade, accept_partial,
                             accept_unknown_api_diff, accept_deprecated_names, accept_unverified_scope,
                             accept_build_patch, accept_partial_codemod, accept_model_drafted, note):
    """Approve a proposed plan as `get` showed it. Needs `alert:update`; never a CI token.

    \b
    `get` prints what must be acknowledged under "Acknowledge before approving"; each has a flag.
    ⚠️ `--accept-unknown-api-diff` is not a formality: it says nobody checked what the upgrade
    changes in the package's public API, which is the normal state for every plan made before the
    API-diff feature and for any package the platform could not fetch.
    ⚠️ `--accept-unverified-scope` says other repositories were NOT checked for pins that must move with
    this fix (no Atlas answer, or the checkout no longer matches it): a fix can look done and still ship the
    old version. `--accept-build-patch` says a build step that patches the package still applies.

    \b
    ⛔ `--accept-partial-codemod` and `--accept-model-drafted` DO NOT UN-DRAFT THE PR. Every other
    acknowledgement here lets a PR open ready for review; these two do not, because what they
    acknowledge is that part of the change still needs a human — uses of the old name left in the
    code, or a hunk a model wrote. Your acknowledgement records that you know; the draft makes sure
    somebody reads it.

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> approve --fingerprint sha256:<hex>
      torana remediation-plan <PLAN_UUID> approve --fingerprint sha256:<hex> --accept-downgrade --accept-partial
      torana remediation-plan <PLAN_UUID> approve --fingerprint sha256:<hex> --accept-unknown-api-diff
      torana remediation-plan <PLAN_UUID> approve --fingerprint sha256:<hex> --accept-unverified-scope
      torana remediation-plan <PLAN_UUID> approve --fingerprint sha256:<hex> --accept-build-patch
      torana remediation-plan <PLAN_UUID> approve --fingerprint sha256:<hex> --accept-partial-codemod
      torana remediation-plan <PLAN_UUID> approve --fingerprint sha256:<hex> --accept-model-drafted
    """
    ack = [a for a, on in (("downgrade", accept_downgrade), ("partial", accept_partial),
                           ("api_diff_unknown", accept_unknown_api_diff),
                           ("deprecated_names_used", accept_deprecated_names),
                           ("lever_scope_unverified", accept_unverified_scope),
                           ("build_patch_review", accept_build_patch),
                           ("codemod_partial", accept_partial_codemod),
                           ("model_drafted", accept_model_drafted)) if on]
    _decide(ctx, "approve", {"fingerprint": fingerprint, **({"acknowledge": ack} if ack else {}),
                             **({"note": note} if note else {})})


def _pairs(values, sep: str, what: str):
    out = []
    for v in values:
        left, s, right = v.partition(sep)
        if not s or not left or not right:
            click.echo(f"ERROR: {what} wants {'PKG=VER' if sep == '=' else 'FILE:LINE=SPEC'}, got {v!r}", err=True)
            sys.exit(EXIT_USAGE)
        out.append((left, right))
    return out


@remediation_plan.command(name="override")
@click.option("--fingerprint", required=True, help="The effective fingerprint `get` printed.")
@click.option("--target", "targets", multiple=True, metavar="PKG=VER", help="Choose another target (repeatable).")
@click.option("--edit", "edits", multiple=True, metavar="FILE:LINE=SPEC",
              help="Write this declaration instead (repeatable; covers a needs_human edit).")
@click.option("--remove", is_flag=True, help="Choose the removal (when the plan offers one).")
@click.option("--drop", "drops", multiple=True, metavar="PKG",
              help="Take a package out of the plan; it is not proposed again at that target (repeatable).")
@click.option("--note", default=None)
@click.pass_context
def remediation_plan_override(ctx, fingerprint, targets, edits, remove, drops, note):
    """Change what a proposed plan does: another target, another declaration, the removal, or drop a package.

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> override --fingerprint sha256:<hex> --target pyjwt=2.15.1
      torana remediation-plan <PLAN_UUID> override --fingerprint sha256:<hex> --edit pyproject.toml:14='>=46.0.8'
      torana remediation-plan <PLAN_UUID> override --fingerprint sha256:<hex> --drop litellm --note "SDK pin"
    """
    body = {"fingerprint": fingerprint}
    if targets:
        body["packages"] = [{"package": p, "target": v} for p, v in _pairs(targets, "=", "--target")]
    if edits:
        rows = []
        for where, spec in _pairs(edits, "=", "--edit"):
            f, s, line = where.rpartition(":")
            if not s or not line.isdigit():
                click.echo(f"ERROR: --edit wants FILE:LINE=SPEC, got {where}={spec!r}", err=True)
                sys.exit(EXIT_USAGE)
            rows.append({"file": f, "line": int(line), "to": spec})
        body["edits"] = rows
    if remove:
        body["remove"] = True
    if drops:
        body["drop"] = list(drops)
    if note:
        body["note"] = note
    if len(body) == 1 or (note and len(body) == 2):
        click.echo("ERROR: say what to change: --target, --edit, --remove or --drop", err=True)
        sys.exit(EXIT_USAGE)
    _decide(ctx, "override", body)


@remediation_plan.command(name="refuse")
@click.option("--note", required=True, help="Why (required; shown to whoever proposes it next).")
@click.pass_context
def remediation_plan_refuse(ctx, note):
    """Refuse a plan, or withdraw an approval that has no PR yet. The same edit is not proposed again.

    \b
    A plan with an open PR answers 409 `pr_exists`: close the PR to refuse it.

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> refuse --note "pinned on purpose until the SDK migration"
    """
    if not note.strip():
        click.echo("ERROR: --note must say why", err=True)
        sys.exit(EXIT_USAGE)
    _decide(ctx, "refuse", {"note": note})


@remediation_plan.command(name="reconsider")
@click.option("--reason", required=True, help="Why the refusal no longer holds (required).")
@click.pass_context
def remediation_plan_reconsider(ctx, reason):
    """Return a refused plan to proposed. It needs a fresh check (a probe) before anyone can approve it.

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> reconsider --reason "the SDK migration landed"
    """
    if not reason.strip():
        click.echo("ERROR: --reason must say why", err=True)
        sys.exit(EXIT_USAGE)
    _decide(ctx, "reconsider", {"reason": reason})


# ── read token for an approved cross-repository plan (§ 3.4.10) ───────────────────

@remediation_plan.command(name="target-token")
@click.option("--holder-run", required=True, help="This run's id.")
@click.option("--revoke", is_flag=True, help="Revoke a token minted by this command (token on stdin).")
@click.option("--mint-id", default=None, help="The mint to record as revoked (with --revoke).")
@click.option("--token", hidden=True, expose_value=False, callback=refuse_token_on_argv, is_eager=True)
@click.pass_context
def remediation_plan_target_token(ctx, holder_run, revoke, mint_id):
    """A read-only, one-repository token to check out an approved plan's target repository.

    \b
    Prints `{token, expires_at, repository, mint_id}` as JSON on stdout and nothing else. GitHub keeps it for an
    hour; revoke it as soon as the checkout is done (`--revoke`, token on stdin or TORANA_TARGET_TOKEN, never
    argv). A same-repository plan answers 409 `token_not_needed`.

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> target-token --holder-run "$GITHUB_RUN_ID:$GITHUB_RUN_ATTEMPT"
      echo "$TOKEN" | torana remediation-plan <PLAN_UUID> target-token --holder-run "$RUN" --revoke --mint-id <M>
    """
    pid = _pid(ctx)
    mint_or_revoke(_client(ctx), f"remediation-plans/{pid}/target-token",
                   lambda m: f"remediation-plans/{pid}/target-token/{m}/revoked",
                   {"holder_run": holder_run}, revoke, mint_id)


# ── open-pr ────────────────────────────────────────────────────────────────────────

def _link_on_path(root: str, rel: str):
    """The first component of `rel` under `root` that is a symlink (or a `..`), as a relative path; else None.
    Never follows a link. The rule of remediation_apply.link_on_path (a skill script the CLI cannot import)."""
    cur, seen = root, []
    for part in rel.replace("\\", "/").split("/"):
        if part in ("", "."):
            continue
        seen.append(part)
        if part == "..":
            return "/".join(seen)
        cur = os.path.join(cur, part)
        if os.path.islink(cur):
            return "/".join(seen)
    return None


def _gates_for_wire(report: dict) -> dict:
    """The runner's gates 4 (build), 5 (tests) and 6 (coverage of the rewritten lines), verbatim, for the wire.

    ⛔ RETURNS {} WHEN NOTHING WAS REPORTED, and the caller then sends no `gates` key at all. A report
    predating gates 4–5, or a run that did not ask for them, leaves the plan's `gates` column NULL —
    which every surface renders as "not reported". Sending `{}` or a fabricated "passed" would be the
    one failure this whole chain exists to avoid: an omitted check reading as a passed one.
    """
    return {k: report[k] for k in ("gate_4_build", "gate_5_tests", "gate_5_coverage")
            if isinstance(report.get(k), dict)}


def build_open_pr_body(plan: dict, diff_text: str, root: str, report: dict, base_sha: str,
                       base_branch: str) -> dict:
    """The § 3.4.3 open-pr body: every file the diff touches in the target repository, read whole from `root`,
    and the probe summary the server fingerprints. Size limits are checked here too, so a too-large PR fails
    before it is sent."""
    target = plan["target_repository"]
    paths = rprop.diff_paths(diff_text, target)
    if not paths:
        raise rprop.ProposalError(f"the diff touches no file in {target}")
    if len(paths) > rprop.MAX_FILES:
        raise rprop.ProposalError(f"{len(paths)} files: at most {rprop.MAX_FILES} (too_large)")
    files, total = [], 0
    for rel in paths:
        link = _link_on_path(root, rel)
        if link:
            # ⛔ The diff names a path; reading it through a link would send the link TARGET's bytes, possibly a file
            # from outside the repository, to the platform. remediation_apply.py refuses the same (link_on_path).
            raise rprop.ProposalError(f"{rel}: {link} is a symlink under --root {root}; never read through a link")
        full = os.path.join(root, rel)
        try:
            with open(full, "rb") as fh:
                raw = fh.read()
        except OSError as exc:
            raise rprop.ProposalError(f"cannot read {rel} under --root {root}: {exc}")
        if len(raw) > rprop.MAX_FILE_BYTES:
            raise rprop.ProposalError(f"{rel} is {len(raw)} bytes: at most {rprop.MAX_FILE_BYTES} (too_large)")
        total += len(raw)
        files.append({"path": rel, "content_b64": base64.b64encode(raw).decode("ascii")})
    if total > rprop.MAX_TOTAL_BYTES:
        raise rprop.ProposalError(f"{total} bytes in all: at most {rprop.MAX_TOTAL_BYTES} (too_large)")
    classes = {p["package"]: int(p.get("class") or plan.get("remediation_class") or 2)
               for p in plan.get("effective_packages") or plan.get("packages") or []}
    summary = rprop.probe_summary(report, classes, repo=target,
                                  lock_names={f"{target}/{lk}" for lk in plan.get("locks") or []})
    body = {"base_branch": base_branch, "base_sha": base_sha, "probe": summary, "files": files,
            "evidence_markdown": rprop.evidence_markdown(report)}
    # ⭐ Gates 4–5 travel on THIS lane too. The platform-push lane is parked, not deleted (§ 3.10.10 keeps
    # it behind config), and DF's `OpenPrBody.gates` has always accepted them: without this, a plan opened
    # through the platform would silently report "not reported" for gates the runner really ran.
    gates = _gates_for_wire(report)
    if gates:
        body["gates"] = gates
    return body


@remediation_plan.command(name="open-pr")
@click.option("--diff", "diff_path", required=True, metavar="CHANGES.diff",
              help="remediation_apply.py's changes.diff (paths come from its headers).")
@click.option("--root", "root", required=True, metavar="COPY_DIR",
              help="The applied copy of the target repository (full file contents come from here).")
@click.option("--probe", "probe_path", required=True, metavar="PROBE.json", help="The apply report of that run.")
@click.option("--base-sha", required=True, help="The target repository HEAD the copy was made from.")
@click.option("--base-branch", default="main", show_default=True)
@click.pass_context
def remediation_plan_open_pr(ctx, diff_path, root, probe_path, base_sha, base_branch):
    """Send an approved plan's applied files to the platform, which opens (or reuses) the PR.

    \b
    No GitHub credential on this machine: the platform checks the plan, the paths and the content, and opens the
    PR as its GitHub App. Retrying is safe (an existing PR is reused). 409 `plan_stale` / 422
    `content_outside_lane` mean re-probe; 409 `base_moved` means re-run on the new HEAD; 504 `pr_pending` means
    the next run records it.

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> open-pr --diff work/group-0/changes.diff \\
          --root work/group-0/repo:github.com/acme/deploy --probe probe.json --base-sha $(git -C deploy rev-parse HEAD)
    """
    client = _client(ctx)
    plan = _call(client.get, f"remediation-plans/{_pid(ctx)}") or {}
    try:
        with open(diff_path, encoding="utf-8") as fh:
            diff_text = fh.read()
        with open(probe_path, encoding="utf-8") as fh:
            reports = rprop.probe_groups(json.load(fh))
    except (OSError, ValueError) as exc:
        click.echo(f"ERROR: {exc}", err=True)
        sys.exit(EXIT_USAGE)
    if len(reports) != 1:
        click.echo(f"ERROR: --probe must hold exactly one group report (it holds {len(reports)})", err=True)
        sys.exit(EXIT_USAGE)
    try:
        body = build_open_pr_body(plan, diff_text, root, next(iter(reports.values())), base_sha, base_branch)
    except rprop.ProposalError as exc:
        click.echo(f"ERROR: {exc}", err=True)
        sys.exit(EXIT_VALIDATION)
    data = _call(client.post, f"remediation-plans/{_pid(ctx)}/open-pr", json=body, timeout=_OPEN_PR_TIMEOUT)
    output(data, fmt=_fmt(ctx), fields=ctx.obj.get(CTX_FIELDS))


# ── record-pr ──────────────────────────────────────────────────────────────────────

def build_record_pr_body(plan: dict, report: dict, base_sha: str, base_branch: str,
                         pr_number: "int | None") -> dict:
    """The § 3.4.4 record-pr body: the probe summary the server fingerprints, and the PR number.

    ⛔ NO FILE CONTENT, and that is the point of the lane rather than an omission. The runner has
    already pushed; the platform reads the pushed branch itself and checks every changed line
    against the approved plan. Sending our own copy of the files would ask the platform to verify
    our account of what we pushed instead of what we actually pushed.
    """
    target = plan["target_repository"]
    classes = {p["package"]: int(p.get("class") or plan.get("remediation_class") or 2)
               for p in plan.get("effective_packages") or plan.get("packages") or []}
    summary = rprop.probe_summary(report, classes, repo=target,
                                  lock_names={f"{target}/{lk}" for lk in plan.get("locks") or []})
    body = {"base_branch": base_branch, "base_sha": base_sha, "probe": summary}
    # ⭐ The runner's gates 4 (build) and 5 (tests), so the plan can say what ran and the PR body can
    # attribute it (phase-4 spec § 3.3.1 / § 3.4.6). Same helper as the open-pr lane, so the two lanes
    # cannot drift into reporting different things.
    gates = _gates_for_wire(report)
    if gates:
        body["gates"] = gates
    if pr_number is not None:
        body["pr_number"] = int(pr_number)
    return body


@remediation_plan.command(name="verify-branch")
@click.option("--probe", "probe_path", required=True, metavar="PROBE.json", help="The apply report of that run.")
@click.option("--base-sha", required=True, help="The target repository HEAD the copy was made from.")
@click.option("--base-branch", default="main", show_default=True)
@click.option("--claim-id", default=None,
              help="The reservation `reserve-pr` returned before the push. Passing it refreshes that same "
                   "reservation rather than taking a second one.")
@click.pass_context
def remediation_plan_verify_branch(ctx, probe_path, base_sha, base_branch, claim_id):
    """Check the PUSHED BRANCH against the approved plan, BEFORE you open the PR.

    \b
    Run this between `git push` and `gh pr create`. The platform reads the pushed branch with a
    read-only token — comparing it against the recorded base commit, so the file list is GitHub's
    account of what you pushed and never yours — and checks every changed line against the approved
    plan. It advances nothing: no PR number, no state change. `record-pr` still records the PR after
    you open it.

    \b
    ⛔ WHY IT EXISTS. The same check used to run only at `record-pr`, the LAST step. A refusal
    therefore left a real open pull request on the repository that the platform had declined to
    record — 3 of the first 8 fix PRs ended that way, each one the applier producing a diff the
    guard then refused. Verifying first means a refusal costs a pushed branch: no reviewers
    notified, no CI started, no PR for anyone to clean up.

    \b
    422 `content_outside_lane` means the branch carries more than the plan approved (the claim is
    released and the reason is written onto the plan). 409 `plan_stale` means re-probe. 504
    `verify_pending` keeps your claim — retry, or open the PR and let `record-pr` decide.

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> verify-branch --probe probe.json \\
          --base-sha $(git -C deploy rev-parse origin/main) --claim-id <CLAIM_UUID>
    """
    client = _client(ctx)
    # Explicitly BEFORE any PR exists, and it stores nothing: no `pr_number`, no `gates` (LANE_FIELDS).
    body = _push_lane_body(client, ctx, probe_path, base_sha, base_branch, None, lane="verify-branch")
    if claim_id:
        body["claim_id"] = claim_id
    data = _call(client.post, f"remediation-plans/{_pid(ctx)}/verify-branch", json=body,
                 timeout=_OPEN_PR_TIMEOUT)
    output(data, fmt=_fmt(ctx), fields=ctx.obj.get(CTX_FIELDS))


@remediation_plan.command(name="record-pr")
@click.option("--probe", "probe_path", required=True, metavar="PROBE.json", help="The apply report of that run.")
@click.option("--base-sha", required=True, help="The target repository HEAD the copy was made from.")
@click.option("--base-branch", default="main", show_default=True)
@click.option("--pr-number", type=int, default=None,
              help="The PR this run opened. Omit and the platform finds the open PR on the plan's branch.")
@click.option("--claim-id", default=None,
              help="The reservation `reserve-pr` returned before the push (409 claim_lost once it expired and "
                   "another run took the slot). Omit and the slot is claimed now.")
@click.pass_context
def remediation_plan_record_pr(ctx, probe_path, base_sha, base_branch, pr_number, claim_id):
    """Report a PR THIS runner pushed and opened, so the platform verifies and records it.

    \b
    Use this when the repository's own CI holds the write credential (the default lane): you push
    `torana/alert-<ALERT_ID>` and open the PR with the workflow token, then call this. The platform
    re-reads the pushed branch with a read-only token and checks every changed line against the
    approved plan — so a PR that touches anything outside the plan is REFUSED and not recorded,
    with the reason written onto the plan.

    \b
    Only the repository the fix EDITS can call this: it is the one that holds the credential. A
    cross-repository fix (auth's finding, deploy's lock) is therefore recorded by deploy's own run.
    422 `content_outside_lane` means the branch carries more than the plan approved; 409
    `plan_stale` means re-probe; 403 `target_mismatch` means this is not the target's runner.
    A developer's laptop may call it too (recorded as opened by `developer`).

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> record-pr --probe probe.json \\
          --base-sha $(git -C deploy rev-parse HEAD) --pr-number 412
      torana remediation-plan <PLAN_UUID> record-pr --probe probe.json --base-sha <SHA> \\
          --pr-number 412 --claim-id <CLAIM_UUID>
    """
    client = _client(ctx)
    body = _push_lane_body(client, ctx, probe_path, base_sha, base_branch, pr_number)
    if claim_id:
        body["claim_id"] = claim_id
    data = _call(client.post, f"remediation-plans/{_pid(ctx)}/record-pr", json=body, timeout=_OPEN_PR_TIMEOUT)
    output(data, fmt=_fmt(ctx), fields=ctx.obj.get(CTX_FIELDS))


def _one_report(probe_path: str) -> dict:
    """The single group report in `--probe` (apply's `--json` output or `probe-report.json`); exit 2 otherwise."""
    try:
        with open(probe_path, encoding="utf-8") as fh:
            reports = rprop.probe_groups(json.load(fh))
    except (OSError, ValueError) as exc:
        click.echo(f"ERROR: {exc}", err=True)
        sys.exit(EXIT_USAGE)
    if len(reports) != 1:
        click.echo(f"ERROR: --probe must hold exactly one group report (it holds {len(reports)})", err=True)
        sys.exit(EXIT_USAGE)
    return next(iter(reports.values()))


#: The fields each push-lane call may send — exactly DF's body models (pantheon-detection-framework
#: `src/pantheon/api/routes/remediation_plans.py`: ReservePrBody, VerifyBranchBody, RecordPrBody), which are all
#: `extra="forbid"`. ⛔ WHY A LIST AND NOT "THE RECORD BODY MINUS pr_number": when gates 4–5 were added to the
#: record body, reserve-pr and verify-branch inherited `gates` and DF refused both with 422 "Extra inputs are not
#: permitted" — so with `--gates-45` the laptop lane could never reserve a PR (first live run, 2026-10-29). The
#: guard test `test_push_lane_bodies_match_df.py` compares these to DF's models.
LANE_FIELDS = {
    "reserve-pr": frozenset({"base_branch", "base_sha", "probe"}),
    "verify-branch": frozenset({"base_branch", "base_sha", "probe", "claim_id"}),
    "record-pr": frozenset({"base_branch", "base_sha", "probe", "pr_number", "claim_id", "gates"}),
}


def lane_body(lane: str, body: dict) -> dict:
    """`body` cut to what `lane`'s DF model accepts (`LANE_FIELDS`)."""
    keep = LANE_FIELDS[lane]
    return {k: v for k, v in body.items() if k in keep}


def _push_lane_body(client, ctx, probe_path: str, base_sha: str, base_branch: str, pr_number,
                    lane: str = "record-pr") -> dict:
    """A push-lane call's body: the probe summary the server fingerprints (no file content), cut to `lane`."""
    plan = _call(client.get, f"remediation-plans/{_pid(ctx)}") or {}
    try:
        return lane_body(lane, build_record_pr_body(plan, _one_report(probe_path), base_sha, base_branch, pr_number))
    except rprop.ProposalError as exc:
        click.echo(f"ERROR: {exc}", err=True)
        sys.exit(EXIT_VALIDATION)


# ── the push lane: pr-text, reserve-pr, release-pr ─────────────────────────────────

#: The server's "wait, someone else holds it" answers: exit 4, like a held lease.
_BUSY = ("waiting_on_open_pr", "pr_in_progress")


@remediation_plan.command(name="pr-text")
@click.option("--probe", "probe_path", default=None, metavar="PROBE.json",
              help="This run's apply report: its gates 1–3 go into the body as evidence. Omit for a preview.")
@click.pass_context
def remediation_plan_pr_text(ctx, probe_path):
    """The PR's title, body, branch and draft flag, written by the platform from the stored plan.

    \b
    Every lane opens the same PR: the body is built by the same code as the platform's own
    open-pr, ends with the `Torana-Alert-Id` / `Torana-Plan-Id` trailers, and starts with a
    warning per draft reason (downgrade, partial). `commit_message` is the subject line plus
    those trailers. JSON: {plan_id, state, title, body, branch, draft, draft_reasons, trailers,
    commit_message}. Anyone who reads plans, or the TARGET repository's CI token.

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> pr-text
      torana remediation-plan <PLAN_UUID> pr-text --probe work/probe-report.json --format json
    """
    client = _client(ctx)
    if probe_path:
        evidence = rprop.evidence_markdown(_one_report(probe_path))
        data = _call(client.post, f"remediation-plans/{_pid(ctx)}/pr-text", json={"evidence_markdown": evidence})
    else:
        data = _call(client.get, f"remediation-plans/{_pid(ctx)}/pr-text")
    data = data or {}
    if _fmt(ctx) == "text" and not ctx.obj.get(CTX_FIELDS):
        draft = ("DRAFT (" + ", ".join(data.get("draft_reasons") or []) + ")") if data.get("draft") else "ready"
        click.echo(f"Title:  {data.get('title')}\nBranch: {data.get('branch')}\nPR:     {draft}\n")
        click.echo(data.get("body") or "")
        return
    output(data, fmt=_fmt(ctx), fields=ctx.obj.get(CTX_FIELDS))


@remediation_plan.command(name="reserve-pr")
@click.option("--probe", "probe_path", required=True, metavar="PROBE.json", help="The apply report of this run.")
@click.option("--base-sha", required=True, help="The target repository commit the fix branch is built on.")
@click.option("--base-branch", default="main", show_default=True)
@click.pass_context
def remediation_plan_reserve_pr(ctx, probe_path, base_sha, base_branch):
    """Reserve this plan's PR slot BEFORE you push, so no second PR on the same files is opened.

    \b
    Prints {plan_id, claim_id, branch, claimed_at, expires_at}. Pass `claim_id` to `record-pr
    --claim-id` after the push (within 15 minutes), or hand it back with `release-pr` if the push
    or the PR create fails. Exit 4: wait — another plan's PR on these files is open or opening
    (`waiting_on_open_pr`, with its PR), or another run holds this plan's slot (`pr_in_progress`).
    409 `plan_stale`: probe again. Needs `remediation_plan:create`, or the TARGET's CI token.

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> reserve-pr --probe work/probe-report.json \\
          --base-sha $(git -C deploy rev-parse origin/main) --format json
    """
    client = _client(ctx)
    body = _push_lane_body(client, ctx, probe_path, base_sha, base_branch, None, lane="reserve-pr")
    try:
        data = client.post(f"remediation-plans/{_pid(ctx)}/reserve-pr", json=body)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        d = e.detail if isinstance(e.detail, dict) else {}
        if e.status_code == 409 and d.get("error") in _BUSY:
            click.echo(f"busy: {d.get('message', '')} ({d['error']})", err=True)
            for k in ("blocking_plan_id", "pr_url"):
                if d.get(k):
                    click.echo(f"  {k}: {d[k]}", err=True)
            sys.exit(EXIT_PERMISSION)
        plan_api_error(e)
        return
    output(data, fmt=_fmt(ctx), fields=ctx.obj.get(CTX_FIELDS))


@remediation_plan.command(name="release-pr")
@click.option("--claim-id", required=True, help="The claim `reserve-pr` returned.")
@click.option("--reason", default=None, help="Why (written into the plan's history), e.g. the push's error.")
@click.pass_context
def remediation_plan_release_pr(ctx, claim_id, reason):
    """Hand a reservation back when the push or the PR create failed. Idempotent: `released: false`
    when this claim is no longer held.

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> release-pr --claim-id <CLAIM_UUID> --reason "git push: permission denied"
    """
    data = _call(_client(ctx).post, f"remediation-plans/{_pid(ctx)}/reserve-pr/{claim_id}/released",
                 json={"reason": reason[:500]} if reason else {})
    output(data, fmt=_fmt(ctx), fields=ctx.obj.get(CTX_FIELDS))


# ── github-readiness (B22) ─────────────────────────────────────────────────────────

@remediation_plan.command(name="github-readiness")
@click.option("--repo", "repo_path", default=None, metavar="PATH",
              help="Your local checkout of the target: also check that YOUR gh login can push to it.")
@click.pass_context
def remediation_plan_github_readiness(ctx, repo_path):
    """Check every GitHub prerequisite for this plan's fix PR BEFORE you commit: the Torana App installed,
    granted and covering the target repository (server), and with --repo, that your own `gh` login can push
    to it (this machine). Each missing one is named in plain words with who can fix it.

    \b
    Exit 0 = ready; 6 = something is missing or could not be checked.

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> github-readiness
      torana remediation-plan <PLAN_UUID> github-readiness --repo ~/src/pantheon-deploy --format json
    """
    from torana_cli import github_readiness as ghr
    data = _call(_client(ctx).get, f"remediation-plans/{_pid(ctx)}/github-readiness") or {}
    checks = list(data.get("checks") or [])
    if repo_path:
        checks += ghr.local_checks(data.get("target_repository") or "", cwd=os.path.expanduser(repo_path))
    result = {**data, "checks": checks, "ready": ghr.overall(checks)}
    if _fmt(ctx) == "text" and not ctx.obj.get(CTX_FIELDS):
        click.echo(ghr.render(result))
    else:
        output(result, fmt=_fmt(ctx), fields=ctx.obj.get(CTX_FIELDS))
    if result["ready"] is not True:
        sys.exit(EXIT_VALIDATION)
