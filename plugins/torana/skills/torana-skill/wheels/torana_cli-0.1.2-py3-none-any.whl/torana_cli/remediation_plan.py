"""torana remediation-plan <PLAN_ID> — one remediation plan: read it, decide it, mint its read token, open its PR.

FIX_PR_SPEC.md § 3.4.3 / § 3.4.7. A decision sends the fingerprint the person saw (`get` prints it), and the
server compares it in the same UPDATE that changes the state: a plan that moved while you read it answers 409
`plan_changed`, and nothing is decided on a plan nobody saw.
"""

import base64
import json
import os
import sys

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import EXIT_PERMISSION, EXIT_USAGE, EXIT_VALIDATION, APIError, handle_auth_error
from torana_cli.main import CTX_FIELDS, CTX_FORMAT
from torana_cli.output import output
from torana_cli import remediation_proposal as rprop
from torana_cli.remediation_plans import (
    _call, _client, mint_or_revoke, plan_api_error, refuse_token_on_argv, with_blocked_by_text,
)

_OPEN_PR_TIMEOUT = 280.0      # below nginx's 300 s for this route (§ 3.4.3), so the client reads the server's own
#                              answer (504 pr_pending, 502) instead of a dropped connection; integration's is 240 s

_CLASS_WORDS = {2: "Lock only", 3: "Manifest edit"}
_PR_STATE_WORDS = {
    "none": "no PR yet", "opening": "Opening PR…", "opening_stale": "Opening stalled — the next run retries",
    "open": "PR open", "merged": "Merged", "closed": "Closed without merge",
}


def _refused_pushes(p: dict) -> list:
    """The `pr_refused` history entries, while the plan still has no PR.

    ⛔ `PR: no PR yet` IS TRUE AND HIDES THE ANSWER. Verification refuses a pushed branch by
    releasing the claim and LEAVING THE PLAN APPROVED, so `pr_state` goes back to `none` — the same
    words a plan that was never pushed prints. An operator asking "my CI pushed a PR and nothing
    happened" reads `no PR yet` and learns nothing (observed 2026-10-21: PR #327 refused twice, both
    invisible here). The reason is already on the plan's history; this only finds it.
    """
    if (p.get("pr_state") or "none") != "none" or p.get("pr_number"):
        return []
    return [h for h in p.get("history") or [] if h.get("action") == "pr_refused"]


def _pid(ctx) -> str:
    return ctx.obj.get("_plan_id", "") if ctx.obj else ""


def _fmt(ctx) -> str:
    return ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"


@click.group(name="remediation-plan", invoke_without_command=True)
@click.argument("plan_id", metavar="PLAN_ID")
@click.pass_context
def remediation_plan(ctx, plan_id):
    """One remediation plan by ID: get, decide (approve / override / refuse / reconsider),
    target-token, the push lane (pr-text, reserve-pr, then verify-branch BEFORE you open the PR
    and record-pr after; release-pr
    on failure), open-pr (the platform pushes it).

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> get
      torana remediation-plan <PLAN_UUID> approve --fingerprint sha256:<hex> --accept-downgrade
      torana remediation-plan <PLAN_UUID> refuse --note "pinned on purpose until the SDK migration"
    """
    ctx.ensure_object(dict)
    ctx.obj["_plan_id"] = plan_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


# ── get ────────────────────────────────────────────────────────────────────────────

def _package_line(p: dict) -> str:
    cls = "Remove dependency" if p.get("removal") else _CLASS_WORDS.get(int(p.get("class") or 0), "?")
    line = f"  {p['package']} {p.get('installed') or '?'} → {p.get('target') or 'removed'}  [{cls}]"
    if p.get("partial"):
        n = p.get("open_alert_ids")
        n = n if isinstance(n, int) else len(n or [])
        line += f"  partial: {n} flaw(s) stay open ({p.get('requested_target')} does not resolve)"
    if p.get("blocked_on"):
        line += f"  blocked on: {p['blocked_on']}"
    return line


def render_plan(p: dict) -> str:
    """The text view: what a person needs to decide, downgrades first (FD: a downgrade is never missed)."""
    out = [f"Plan {p.get('id')}  [{p.get('state')}]  {p.get('description', '')}",
           f"Target: {p.get('target_repository')}  lock: {p.get('resolve_file')} ({p.get('lock_format')})"
           + ("  dev only" if p.get("dev_only") else ""),
           f"Fingerprint (send it to approve/override): {p.get('effective_fingerprint')}"]
    if p.get("pr_draft_reasons"):
        out.append("⚠ PR OPENS AS A DRAFT (the PR body warns the reviewer): " + ", ".join(p["pr_draft_reasons"]))
    if p.get("downgrades"):
        out.append("⚠ DOWNGRADES (acknowledge with --accept-downgrade):")
        out += [f"  {d['package']} {d.get('from')} → {d.get('to')}" for d in p["downgrades"]]
    out.append("Packages:")
    out += [_package_line(x) for x in p.get("effective_packages") or p.get("packages") or []]
    edits = p.get("effective_edits") or p.get("edits") or []
    if edits:
        out.append("Edits:")
        for e in edits:
            out.append(f"  {e['file']}:{e['line']} {e['action']} `{e.get('from')}`"
                       + (f" → `{e['to']}`" if e.get("to") else "")
                       + (f"  needs a person: {e['needs_human']}" if e.get("needs_human") else ""))
    if p.get("co_movers"):
        out.append("Also moves: " + ", ".join(f"{c['package']} {c.get('from')} → {c.get('to')}"
                                              for c in p["co_movers"]))
    members = p.get("members")
    out.append(f"Fixes {len(members) if isinstance(members, list) else members or 0} alert(s)")
    if p.get("probe_stale"):
        out.append("Needs a fresh check: the last probe does not cover this plan (approve is refused until then)")
    if p.get("needs_ack") and p.get("state") == "proposed":
        out.append("Acknowledge before approving: " + ", ".join(p["needs_ack"]))
    if not p.get("approvable", True) and p.get("state") == "proposed":
        out.append("Not approvable as proposed (a needs_human edit, a bump without a target, blocked_on, or stale)")
    for b in p.get("blocked_by") or []:
        out.append(f"Waiting on {b.get('plan_id') or 'a lock not yet planned'} ({b.get('lock_key')}): "
                   f"{b.get('reason')}")
    out.append(f"PR: {_PR_STATE_WORDS.get(p.get('pr_state') or 'none', p.get('pr_state'))}"
               + (f"  {p['pr_url']}" if p.get("pr_url") else ""))
    refused = _refused_pushes(p)
    if refused:
        last = refused[-1]
        out.append(f"{len(refused)} pushed PR(s) refused by the platform, last at {last.get('at')}"
                   + (f": {last.get('reason')}" if last.get("reason") else ""))
    lease = p.get("lease")
    if lease:
        out.append(f"Being applied by {lease.get('holder_subject')} ({lease.get('holder_run')}) until "
                   f"{lease.get('expires_at')}")
    for m in p.get("token_mints") or []:
        out.append(f"Read access to {m.get('target_repository')} issued to {m.get('actor')} until "
                   f"{m.get('expires_at')}" + (f", revoked {m['revoked_at']}" if m.get("revoked_at") else "")
                   + (f" ({m.get('outcome')})" if m.get("outcome") != "minted" else ""))
    if p.get("decided_by") == "system":
        # The tenant's require_plan_approval is off: the PR is the only gate (`remediation-plans settings`).
        out.append(f"Approved by the system at {p.get('decided_at')}: no person approved it in Torana; "
                   "the PR review is the gate"
                   + (f" ({p['decision_note']})" if p.get("decision_note") else ""))
    elif p.get("decided_by"):
        out.append(f"Last decision: {p.get('decided_by')} at {p.get('decided_at')}"
                   + (f": {p['decision_note']}" if p.get("decision_note") else ""))
    return "\n".join(out)


@remediation_plan.command(name="get")
@click.pass_context
def remediation_plan_get(ctx):
    """Get a plan: packages, edits, downgrades, fingerprint, blocked_by, PR state, lease and read-token history.

    \b
    A plan approved by the system (the tenant's require_plan_approval is off) says so, and
    `pr_draft_reasons` (downgrade, partial) says why its PR opens as a draft.

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> get
      torana remediation-plan <PLAN_UUID> get --format json
    """
    data = _call(_client(ctx).get, f"remediation-plans/{_pid(ctx)}") or {}
    if _fmt(ctx) == "text" and not ctx.obj.get(CTX_FIELDS):
        click.echo(render_plan(data))
        return
    output(with_blocked_by_text(data), fmt=_fmt(ctx), fields=ctx.obj.get(CTX_FIELDS))


# ── decisions ──────────────────────────────────────────────────────────────────────

def _decide(ctx, verb: str, body: dict) -> None:
    try:
        data = _client(ctx).post(f"remediation-plans/{_pid(ctx)}/{verb}", json=body)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        if e.status_code == 409 and isinstance(e.detail, dict) and e.detail.get("error") == "plan_changed":
            click.echo("the plan changed while you were reading it: run `get` again and decide on what it says now",
                       err=True)
        plan_api_error(e)
        return
    if _fmt(ctx) == "text" and isinstance(data, dict) and data.get("id"):
        click.echo(render_plan(data))
        return
    output(data, fmt=_fmt(ctx), fields=ctx.obj.get(CTX_FIELDS))


@remediation_plan.command(name="approve")
@click.option("--fingerprint", required=True, help="The effective fingerprint `get` printed.")
@click.option("--accept-downgrade", is_flag=True, help="Acknowledge that a package moves backwards.")
@click.option("--accept-partial", is_flag=True, help="Acknowledge that some flaws stay open.")
@click.option("--note", default=None)
@click.pass_context
def remediation_plan_approve(ctx, fingerprint, accept_downgrade, accept_partial, note):
    """Approve a proposed plan as `get` showed it. Needs `alert:update`; never a CI token.

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> approve --fingerprint sha256:<hex>
      torana remediation-plan <PLAN_UUID> approve --fingerprint sha256:<hex> --accept-downgrade --accept-partial
    """
    ack = [a for a, on in (("downgrade", accept_downgrade), ("partial", accept_partial)) if on]
    _decide(ctx, "approve", {"fingerprint": fingerprint, **({"acknowledge": ack} if ack else {}),
                             **({"note": note} if note else {})})


def _pairs(values, sep: str, what: str):
    out = []
    for v in values:
        left, s, right = v.partition(sep)
        if not s or not left or not right:
            click.echo(f"ERROR: {what} wants {'PKG=VER' if sep == '=' else 'FILE:LINE=SPEC'}, got {v!r}", err=True)
            sys.exit(EXIT_USAGE)
        out.append((left, right))
    return out


@remediation_plan.command(name="override")
@click.option("--fingerprint", required=True, help="The effective fingerprint `get` printed.")
@click.option("--target", "targets", multiple=True, metavar="PKG=VER", help="Choose another target (repeatable).")
@click.option("--edit", "edits", multiple=True, metavar="FILE:LINE=SPEC",
              help="Write this declaration instead (repeatable; covers a needs_human edit).")
@click.option("--remove", is_flag=True, help="Choose the removal (when the plan offers one).")
@click.option("--drop", "drops", multiple=True, metavar="PKG",
              help="Take a package out of the plan; it is not proposed again at that target (repeatable).")
@click.option("--note", default=None)
@click.pass_context
def remediation_plan_override(ctx, fingerprint, targets, edits, remove, drops, note):
    """Change what a proposed plan does: another target, another declaration, the removal, or drop a package.

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> override --fingerprint sha256:<hex> --target pyjwt=2.15.1
      torana remediation-plan <PLAN_UUID> override --fingerprint sha256:<hex> --edit pyproject.toml:14='>=46.0.8'
      torana remediation-plan <PLAN_UUID> override --fingerprint sha256:<hex> --drop litellm --note "SDK pin"
    """
    body = {"fingerprint": fingerprint}
    if targets:
        body["packages"] = [{"package": p, "target": v} for p, v in _pairs(targets, "=", "--target")]
    if edits:
        rows = []
        for where, spec in _pairs(edits, "=", "--edit"):
            f, s, line = where.rpartition(":")
            if not s or not line.isdigit():
                click.echo(f"ERROR: --edit wants FILE:LINE=SPEC, got {where}={spec!r}", err=True)
                sys.exit(EXIT_USAGE)
            rows.append({"file": f, "line": int(line), "to": spec})
        body["edits"] = rows
    if remove:
        body["remove"] = True
    if drops:
        body["drop"] = list(drops)
    if note:
        body["note"] = note
    if len(body) == 1 or (note and len(body) == 2):
        click.echo("ERROR: say what to change: --target, --edit, --remove or --drop", err=True)
        sys.exit(EXIT_USAGE)
    _decide(ctx, "override", body)


@remediation_plan.command(name="refuse")
@click.option("--note", required=True, help="Why (required; shown to whoever proposes it next).")
@click.pass_context
def remediation_plan_refuse(ctx, note):
    """Refuse a plan, or withdraw an approval that has no PR yet. The same edit is not proposed again.

    \b
    A plan with an open PR answers 409 `pr_exists`: close the PR to refuse it.

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> refuse --note "pinned on purpose until the SDK migration"
    """
    if not note.strip():
        click.echo("ERROR: --note must say why", err=True)
        sys.exit(EXIT_USAGE)
    _decide(ctx, "refuse", {"note": note})


@remediation_plan.command(name="reconsider")
@click.option("--reason", required=True, help="Why the refusal no longer holds (required).")
@click.pass_context
def remediation_plan_reconsider(ctx, reason):
    """Return a refused plan to proposed. It needs a fresh check (a probe) before anyone can approve it.

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> reconsider --reason "the SDK migration landed"
    """
    if not reason.strip():
        click.echo("ERROR: --reason must say why", err=True)
        sys.exit(EXIT_USAGE)
    _decide(ctx, "reconsider", {"reason": reason})


# ── read token for an approved cross-repository plan (§ 3.4.10) ───────────────────

@remediation_plan.command(name="target-token")
@click.option("--holder-run", required=True, help="This run's id.")
@click.option("--revoke", is_flag=True, help="Revoke a token minted by this command (token on stdin).")
@click.option("--mint-id", default=None, help="The mint to record as revoked (with --revoke).")
@click.option("--token", hidden=True, expose_value=False, callback=refuse_token_on_argv, is_eager=True)
@click.pass_context
def remediation_plan_target_token(ctx, holder_run, revoke, mint_id):
    """A read-only, one-repository token to check out an approved plan's target repository.

    \b
    Prints `{token, expires_at, repository, mint_id}` as JSON on stdout and nothing else. GitHub keeps it for an
    hour; revoke it as soon as the checkout is done (`--revoke`, token on stdin or TORANA_TARGET_TOKEN, never
    argv). A same-repository plan answers 409 `token_not_needed`.

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> target-token --holder-run "$GITHUB_RUN_ID:$GITHUB_RUN_ATTEMPT"
      echo "$TOKEN" | torana remediation-plan <PLAN_UUID> target-token --holder-run "$RUN" --revoke --mint-id <M>
    """
    pid = _pid(ctx)
    mint_or_revoke(_client(ctx), f"remediation-plans/{pid}/target-token",
                   lambda m: f"remediation-plans/{pid}/target-token/{m}/revoked",
                   {"holder_run": holder_run}, revoke, mint_id)


# ── open-pr ────────────────────────────────────────────────────────────────────────

def _link_on_path(root: str, rel: str):
    """The first component of `rel` under `root` that is a symlink (or a `..`), as a relative path; else None.
    Never follows a link. The rule of remediation_apply.link_on_path (a skill script the CLI cannot import)."""
    cur, seen = root, []
    for part in rel.replace("\\", "/").split("/"):
        if part in ("", "."):
            continue
        seen.append(part)
        if part == "..":
            return "/".join(seen)
        cur = os.path.join(cur, part)
        if os.path.islink(cur):
            return "/".join(seen)
    return None


def build_open_pr_body(plan: dict, diff_text: str, root: str, report: dict, base_sha: str,
                       base_branch: str) -> dict:
    """The § 3.4.3 open-pr body: every file the diff touches in the target repository, read whole from `root`,
    and the probe summary the server fingerprints. Size limits are checked here too, so a too-large PR fails
    before it is sent."""
    target = plan["target_repository"]
    paths = rprop.diff_paths(diff_text, target)
    if not paths:
        raise rprop.ProposalError(f"the diff touches no file in {target}")
    if len(paths) > rprop.MAX_FILES:
        raise rprop.ProposalError(f"{len(paths)} files: at most {rprop.MAX_FILES} (too_large)")
    files, total = [], 0
    for rel in paths:
        link = _link_on_path(root, rel)
        if link:
            # ⛔ The diff names a path; reading it through a link would send the link TARGET's bytes, possibly a file
            # from outside the repository, to the platform. remediation_apply.py refuses the same (link_on_path).
            raise rprop.ProposalError(f"{rel}: {link} is a symlink under --root {root}; never read through a link")
        full = os.path.join(root, rel)
        try:
            with open(full, "rb") as fh:
                raw = fh.read()
        except OSError as exc:
            raise rprop.ProposalError(f"cannot read {rel} under --root {root}: {exc}")
        if len(raw) > rprop.MAX_FILE_BYTES:
            raise rprop.ProposalError(f"{rel} is {len(raw)} bytes: at most {rprop.MAX_FILE_BYTES} (too_large)")
        total += len(raw)
        files.append({"path": rel, "content_b64": base64.b64encode(raw).decode("ascii")})
    if total > rprop.MAX_TOTAL_BYTES:
        raise rprop.ProposalError(f"{total} bytes in all: at most {rprop.MAX_TOTAL_BYTES} (too_large)")
    classes = {p["package"]: int(p.get("class") or plan.get("remediation_class") or 2)
               for p in plan.get("effective_packages") or plan.get("packages") or []}
    summary = rprop.probe_summary(report, classes, repo=target,
                                  lock_names={f"{target}/{lk}" for lk in plan.get("locks") or []})
    return {"base_branch": base_branch, "base_sha": base_sha, "probe": summary, "files": files,
            "evidence_markdown": rprop.evidence_markdown(report)}


@remediation_plan.command(name="open-pr")
@click.option("--diff", "diff_path", required=True, metavar="CHANGES.diff",
              help="remediation_apply.py's changes.diff (paths come from its headers).")
@click.option("--root", "root", required=True, metavar="COPY_DIR",
              help="The applied copy of the target repository (full file contents come from here).")
@click.option("--probe", "probe_path", required=True, metavar="PROBE.json", help="The apply report of that run.")
@click.option("--base-sha", required=True, help="The target repository HEAD the copy was made from.")
@click.option("--base-branch", default="main", show_default=True)
@click.pass_context
def remediation_plan_open_pr(ctx, diff_path, root, probe_path, base_sha, base_branch):
    """Send an approved plan's applied files to the platform, which opens (or reuses) the PR.

    \b
    No GitHub credential on this machine: the platform checks the plan, the paths and the content, and opens the
    PR as its GitHub App. Retrying is safe (an existing PR is reused). 409 `plan_stale` / 422
    `content_outside_lane` mean re-probe; 409 `base_moved` means re-run on the new HEAD; 504 `pr_pending` means
    the next run records it.

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> open-pr --diff work/group-0/changes.diff \\
          --root work/group-0/repo:github.com/acme/deploy --probe probe.json --base-sha $(git -C deploy rev-parse HEAD)
    """
    client = _client(ctx)
    plan = _call(client.get, f"remediation-plans/{_pid(ctx)}") or {}
    try:
        with open(diff_path, encoding="utf-8") as fh:
            diff_text = fh.read()
        with open(probe_path, encoding="utf-8") as fh:
            reports = rprop.probe_groups(json.load(fh))
    except (OSError, ValueError) as exc:
        click.echo(f"ERROR: {exc}", err=True)
        sys.exit(EXIT_USAGE)
    if len(reports) != 1:
        click.echo(f"ERROR: --probe must hold exactly one group report (it holds {len(reports)})", err=True)
        sys.exit(EXIT_USAGE)
    try:
        body = build_open_pr_body(plan, diff_text, root, next(iter(reports.values())), base_sha, base_branch)
    except rprop.ProposalError as exc:
        click.echo(f"ERROR: {exc}", err=True)
        sys.exit(EXIT_VALIDATION)
    data = _call(client.post, f"remediation-plans/{_pid(ctx)}/open-pr", json=body, timeout=_OPEN_PR_TIMEOUT)
    output(data, fmt=_fmt(ctx), fields=ctx.obj.get(CTX_FIELDS))


# ── record-pr ──────────────────────────────────────────────────────────────────────

def build_record_pr_body(plan: dict, report: dict, base_sha: str, base_branch: str,
                         pr_number: "int | None") -> dict:
    """The § 3.4.4 record-pr body: the probe summary the server fingerprints, and the PR number.

    ⛔ NO FILE CONTENT, and that is the point of the lane rather than an omission. The runner has
    already pushed; the platform reads the pushed branch itself and checks every changed line
    against the approved plan. Sending our own copy of the files would ask the platform to verify
    our account of what we pushed instead of what we actually pushed.
    """
    target = plan["target_repository"]
    classes = {p["package"]: int(p.get("class") or plan.get("remediation_class") or 2)
               for p in plan.get("effective_packages") or plan.get("packages") or []}
    summary = rprop.probe_summary(report, classes, repo=target,
                                  lock_names={f"{target}/{lk}" for lk in plan.get("locks") or []})
    body = {"base_branch": base_branch, "base_sha": base_sha, "probe": summary}
    if pr_number is not None:
        body["pr_number"] = int(pr_number)
    return body


@remediation_plan.command(name="verify-branch")
@click.option("--probe", "probe_path", required=True, metavar="PROBE.json", help="The apply report of that run.")
@click.option("--base-sha", required=True, help="The target repository HEAD the copy was made from.")
@click.option("--base-branch", default="main", show_default=True)
@click.option("--claim-id", default=None,
              help="The reservation `reserve-pr` returned before the push. Passing it refreshes that same "
                   "reservation rather than taking a second one.")
@click.pass_context
def remediation_plan_verify_branch(ctx, probe_path, base_sha, base_branch, claim_id):
    """Check the PUSHED BRANCH against the approved plan, BEFORE you open the PR.

    \b
    Run this between `git push` and `gh pr create`. The platform reads the pushed branch with a
    read-only token — comparing it against the recorded base commit, so the file list is GitHub's
    account of what you pushed and never yours — and checks every changed line against the approved
    plan. It advances nothing: no PR number, no state change. `record-pr` still records the PR after
    you open it.

    \b
    ⛔ WHY IT EXISTS. The same check used to run only at `record-pr`, the LAST step. A refusal
    therefore left a real open pull request on the repository that the platform had declined to
    record — 3 of the first 8 fix PRs ended that way, each one the applier producing a diff the
    guard then refused. Verifying first means a refusal costs a pushed branch: no reviewers
    notified, no CI started, no PR for anyone to clean up.

    \b
    422 `content_outside_lane` means the branch carries more than the plan approved (the claim is
    released and the reason is written onto the plan). 409 `plan_stale` means re-probe. 504
    `verify_pending` keeps your claim — retry, or open the PR and let `record-pr` decide.

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> verify-branch --probe probe.json \\
          --base-sha $(git -C deploy rev-parse origin/main) --claim-id <CLAIM_UUID>
    """
    client = _client(ctx)
    body = _push_lane_body(client, ctx, probe_path, base_sha, base_branch, None)
    body.pop("pr_number", None)                      # this call is explicitly BEFORE any PR exists
    if claim_id:
        body["claim_id"] = claim_id
    data = _call(client.post, f"remediation-plans/{_pid(ctx)}/verify-branch", json=body,
                 timeout=_OPEN_PR_TIMEOUT)
    output(data, fmt=_fmt(ctx), fields=ctx.obj.get(CTX_FIELDS))


@remediation_plan.command(name="record-pr")
@click.option("--probe", "probe_path", required=True, metavar="PROBE.json", help="The apply report of that run.")
@click.option("--base-sha", required=True, help="The target repository HEAD the copy was made from.")
@click.option("--base-branch", default="main", show_default=True)
@click.option("--pr-number", type=int, default=None,
              help="The PR this run opened. Omit and the platform finds the open PR on the plan's branch.")
@click.option("--claim-id", default=None,
              help="The reservation `reserve-pr` returned before the push (409 claim_lost once it expired and "
                   "another run took the slot). Omit and the slot is claimed now.")
@click.pass_context
def remediation_plan_record_pr(ctx, probe_path, base_sha, base_branch, pr_number, claim_id):
    """Report a PR THIS runner pushed and opened, so the platform verifies and records it.

    \b
    Use this when the repository's own CI holds the write credential (the default lane): you push
    `torana/alert-<ALERT_ID>` and open the PR with the workflow token, then call this. The platform
    re-reads the pushed branch with a read-only token and checks every changed line against the
    approved plan — so a PR that touches anything outside the plan is REFUSED and not recorded,
    with the reason written onto the plan.

    \b
    Only the repository the fix EDITS can call this: it is the one that holds the credential. A
    cross-repository fix (auth's finding, deploy's lock) is therefore recorded by deploy's own run.
    422 `content_outside_lane` means the branch carries more than the plan approved; 409
    `plan_stale` means re-probe; 403 `target_mismatch` means this is not the target's runner.
    A developer's laptop may call it too (recorded as opened by `developer`).

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> record-pr --probe probe.json \\
          --base-sha $(git -C deploy rev-parse HEAD) --pr-number 412
      torana remediation-plan <PLAN_UUID> record-pr --probe probe.json --base-sha <SHA> \\
          --pr-number 412 --claim-id <CLAIM_UUID>
    """
    client = _client(ctx)
    body = _push_lane_body(client, ctx, probe_path, base_sha, base_branch, pr_number)
    if claim_id:
        body["claim_id"] = claim_id
    data = _call(client.post, f"remediation-plans/{_pid(ctx)}/record-pr", json=body, timeout=_OPEN_PR_TIMEOUT)
    output(data, fmt=_fmt(ctx), fields=ctx.obj.get(CTX_FIELDS))


def _one_report(probe_path: str) -> dict:
    """The single group report in `--probe` (apply's `--json` output or `probe-report.json`); exit 2 otherwise."""
    try:
        with open(probe_path, encoding="utf-8") as fh:
            reports = rprop.probe_groups(json.load(fh))
    except (OSError, ValueError) as exc:
        click.echo(f"ERROR: {exc}", err=True)
        sys.exit(EXIT_USAGE)
    if len(reports) != 1:
        click.echo(f"ERROR: --probe must hold exactly one group report (it holds {len(reports)})", err=True)
        sys.exit(EXIT_USAGE)
    return next(iter(reports.values()))


def _push_lane_body(client, ctx, probe_path: str, base_sha: str, base_branch: str, pr_number) -> dict:
    """reserve-pr's and record-pr's body: the probe summary the server fingerprints (no file content)."""
    plan = _call(client.get, f"remediation-plans/{_pid(ctx)}") or {}
    try:
        return build_record_pr_body(plan, _one_report(probe_path), base_sha, base_branch, pr_number)
    except rprop.ProposalError as exc:
        click.echo(f"ERROR: {exc}", err=True)
        sys.exit(EXIT_VALIDATION)


# ── the push lane: pr-text, reserve-pr, release-pr ─────────────────────────────────

#: The server's "wait, someone else holds it" answers: exit 4, like a held lease.
_BUSY = ("waiting_on_open_pr", "pr_in_progress")


@remediation_plan.command(name="pr-text")
@click.option("--probe", "probe_path", default=None, metavar="PROBE.json",
              help="This run's apply report: its gates 1–3 go into the body as evidence. Omit for a preview.")
@click.pass_context
def remediation_plan_pr_text(ctx, probe_path):
    """The PR's title, body, branch and draft flag, written by the platform from the stored plan.

    \b
    Every lane opens the same PR: the body is built by the same code as the platform's own
    open-pr, ends with the `Torana-Alert-Id` / `Torana-Plan-Id` trailers, and starts with a
    warning per draft reason (downgrade, partial). `commit_message` is the subject line plus
    those trailers. JSON: {plan_id, state, title, body, branch, draft, draft_reasons, trailers,
    commit_message}. Anyone who reads plans, or the TARGET repository's CI token.

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> pr-text
      torana remediation-plan <PLAN_UUID> pr-text --probe work/probe-report.json --format json
    """
    client = _client(ctx)
    if probe_path:
        evidence = rprop.evidence_markdown(_one_report(probe_path))
        data = _call(client.post, f"remediation-plans/{_pid(ctx)}/pr-text", json={"evidence_markdown": evidence})
    else:
        data = _call(client.get, f"remediation-plans/{_pid(ctx)}/pr-text")
    data = data or {}
    if _fmt(ctx) == "text" and not ctx.obj.get(CTX_FIELDS):
        draft = ("DRAFT (" + ", ".join(data.get("draft_reasons") or []) + ")") if data.get("draft") else "ready"
        click.echo(f"Title:  {data.get('title')}\nBranch: {data.get('branch')}\nPR:     {draft}\n")
        click.echo(data.get("body") or "")
        return
    output(data, fmt=_fmt(ctx), fields=ctx.obj.get(CTX_FIELDS))


@remediation_plan.command(name="reserve-pr")
@click.option("--probe", "probe_path", required=True, metavar="PROBE.json", help="The apply report of this run.")
@click.option("--base-sha", required=True, help="The target repository commit the fix branch is built on.")
@click.option("--base-branch", default="main", show_default=True)
@click.pass_context
def remediation_plan_reserve_pr(ctx, probe_path, base_sha, base_branch):
    """Reserve this plan's PR slot BEFORE you push, so no second PR on the same files is opened.

    \b
    Prints {plan_id, claim_id, branch, claimed_at, expires_at}. Pass `claim_id` to `record-pr
    --claim-id` after the push (within 15 minutes), or hand it back with `release-pr` if the push
    or the PR create fails. Exit 4: wait — another plan's PR on these files is open or opening
    (`waiting_on_open_pr`, with its PR), or another run holds this plan's slot (`pr_in_progress`).
    409 `plan_stale`: probe again. Needs `remediation_plan:create`, or the TARGET's CI token.

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> reserve-pr --probe work/probe-report.json \\
          --base-sha $(git -C deploy rev-parse origin/main) --format json
    """
    client = _client(ctx)
    body = _push_lane_body(client, ctx, probe_path, base_sha, base_branch, None)
    try:
        data = client.post(f"remediation-plans/{_pid(ctx)}/reserve-pr", json=body)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        d = e.detail if isinstance(e.detail, dict) else {}
        if e.status_code == 409 and d.get("error") in _BUSY:
            click.echo(f"busy: {d.get('message', '')} ({d['error']})", err=True)
            for k in ("blocking_plan_id", "pr_url"):
                if d.get(k):
                    click.echo(f"  {k}: {d[k]}", err=True)
            sys.exit(EXIT_PERMISSION)
        plan_api_error(e)
        return
    output(data, fmt=_fmt(ctx), fields=ctx.obj.get(CTX_FIELDS))


@remediation_plan.command(name="release-pr")
@click.option("--claim-id", required=True, help="The claim `reserve-pr` returned.")
@click.option("--reason", default=None, help="Why (written into the plan's history), e.g. the push's error.")
@click.pass_context
def remediation_plan_release_pr(ctx, claim_id, reason):
    """Hand a reservation back when the push or the PR create failed. Idempotent: `released: false`
    when this claim is no longer held.

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> release-pr --claim-id <CLAIM_UUID> --reason "git push: permission denied"
    """
    data = _call(_client(ctx).post, f"remediation-plans/{_pid(ctx)}/reserve-pr/{claim_id}/released",
                 json={"reason": reason[:500]} if reason else {})
    output(data, fmt=_fmt(ctx), fields=ctx.obj.get(CTX_FIELDS))


# ── github-readiness (B22) ─────────────────────────────────────────────────────────

@remediation_plan.command(name="github-readiness")
@click.option("--repo", "repo_path", default=None, metavar="PATH",
              help="Your local checkout of the target: also check that YOUR gh login can push to it.")
@click.pass_context
def remediation_plan_github_readiness(ctx, repo_path):
    """Check every GitHub prerequisite for this plan's fix PR BEFORE you commit: the Torana App installed,
    granted and covering the target repository (server), and with --repo, that your own `gh` login can push
    to it (this machine). Each missing one is named in plain words with who can fix it.

    \b
    Exit 0 = ready; 6 = something is missing or could not be checked.

    \b
    Examples:
      torana remediation-plan <PLAN_UUID> github-readiness
      torana remediation-plan <PLAN_UUID> github-readiness --repo ~/src/pantheon-deploy --format json
    """
    from torana_cli import github_readiness as ghr
    data = _call(_client(ctx).get, f"remediation-plans/{_pid(ctx)}/github-readiness") or {}
    checks = list(data.get("checks") or [])
    if repo_path:
        checks += ghr.local_checks(data.get("target_repository") or "", cwd=os.path.expanduser(repo_path))
    result = {**data, "checks": checks, "ready": ghr.overall(checks)}
    if _fmt(ctx) == "text" and not ctx.obj.get(CTX_FIELDS):
        click.echo(ghr.render(result))
    else:
        output(result, fmt=_fmt(ctx), fields=ctx.obj.get(CTX_FIELDS))
    if result["ready"] is not True:
        sys.exit(EXIT_VALIDATION)
