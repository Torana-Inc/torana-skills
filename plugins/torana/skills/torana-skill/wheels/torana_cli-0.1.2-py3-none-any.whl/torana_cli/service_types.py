"""torana service-types — workflow framework service type commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 35),
    ("category", "CATEGORY", 20),
    ("description", "DESCRIPTION", 50),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(name="service-types")
def service_types():
    """Manage workflow service types.

    \b
    Examples:
      torana service-types list
      torana service-types get <UUID>
      torana service-types create --name "SIEM Connector" --file type.yaml
      torana service-types delete <UUID> --yes
    """


@service_types.command(name="list")
@click.option("--search", default=None, help="Search by name or category.")
@click.option("--category", default=None, help="Filter by category.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def service_types_list(ctx, search, category, page, page_size):
    """List service types."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if search:
        params["search"] = search
    if category:
        params["category"] = category

    client = _client(ctx)
    try:
        data = client.get("service-types/", params=params)
        result = data if isinstance(data, dict) and "items" in data else {
            "items": data if isinstance(data, list) else [],
            "total": len(data) if isinstance(data, list) else 0,
            "page": page, "page_size": effective_page_size
        }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@service_types.command(name="get")
@click.argument("type_id", metavar="TYPE_ID")
@click.pass_context
def service_types_get(ctx, type_id):
    """Get details for a specific service type."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"service-types/{type_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@service_types.command(name="create")
@click.option("--name", default=None)
@click.option("--category", default=None, help="Service category.")
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def service_types_create(ctx, name, category, input_file):
    """Create a new service type."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if category:
        body["category"] = category

    if not body.get("name"):
        click.echo("ERROR: --name is required.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post("service-types/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created service type: {data.get('id', 'unknown')}")


@service_types.command(name="update")
@click.argument("type_id", metavar="TYPE_ID")
@click.option("--name", default=None)
@click.option("--category", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def service_types_update(ctx, type_id, name, category, input_file):
    """Update a service type."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if category:
        body["category"] = category

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"service-types/{type_id}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated service type: {type_id}")


@service_types.command(name="delete")
@click.argument("type_id", metavar="TYPE_ID")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def service_types_delete(ctx, type_id, yes):
    """Delete a service type."""
    _confirm(f"Delete service type {type_id}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"service-types/{type_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted service type: {type_id}")


@service_types.command(name="providers")
@click.argument("SERVICE_TYPE_ID", metavar="SERVICE_TYPE_ID")
@click.option("--page", "page", type=int, default=1, help="Page number")
@click.option("--size", "size", type=int, default=20, help="Page size")
@click.option("--status", "status", default=None, help="Filter by provider status")
@click.pass_context
def service_types_providers(ctx, service_type_id, page, size, status):
    """Get providers for a service type."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"service-types/{service_type_id}/providers"
    params = {}
    if page is not None:
        params["page"] = page
    if size is not None:
        params["size"] = size
    if status is not None:
        params["status"] = status

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@service_types.command(name="categories")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def service_types_categories(ctx, page, page_size, fetch_all):
    """Get all service type categories."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "service-types/categories/list"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@service_types.command(name="activate")
@click.argument("SERVICE_TYPE_ID", metavar="SERVICE_TYPE_ID")
@click.pass_context
def service_types_activate(ctx, service_type_id):
    """Activate a service type."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"service-types/{service_type_id}/activate"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@service_types.command(name="deactivate")
@click.argument("SERVICE_TYPE_ID", metavar="SERVICE_TYPE_ID")
@click.pass_context
def service_types_deactivate(ctx, service_type_id):
    """Deactivate a service type."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"service-types/{service_type_id}/deactivate"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)
