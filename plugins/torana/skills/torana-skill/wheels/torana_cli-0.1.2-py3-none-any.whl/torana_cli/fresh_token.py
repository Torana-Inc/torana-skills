"""`TORANA_TOKEN_CMD`: a FRESH bearer token immediately before each write (FIX_PR_SPEC.md § 3.4.9).

A CI token lives 900 s, and a remediation run writes AFTER a resolve that can take longer, so a token taken at the
start of the job is expired by the write. When `TORANA_TOKEN_CMD` is set, the remediation-plan commands run it
(shlex-split, no shell, 30 s timeout; stdout, stripped, is the token) right before EACH write call, and use that
token for the write. A non-zero exit or an empty stdout fails loudly (exit 5) BEFORE the write is sent. A read
reuses the last token fetched (fetching one if none was yet). Unset: the CLI's usual token resolution, unchanged.

⛔ The token is never printed or logged; a failing command's own stderr is not echoed either, since a token
helper may print secrets there.
"""

import os
import shlex
import subprocess
import sys
from typing import Optional

import click

from torana_cli.client.base import EXIT_AUTH, ToranaClient

ENV = "TORANA_TOKEN_CMD"
_TIMEOUT = 30


def token_from_command(cmd: str) -> str:
    """Run the token command once; the token, or exit 5 with a message that never contains it."""
    try:
        p = subprocess.run(shlex.split(cmd), capture_output=True, text=True, timeout=_TIMEOUT)
    except (OSError, ValueError, subprocess.TimeoutExpired) as exc:
        click.echo(f"ERROR: {ENV} could not run ({type(exc).__name__}); nothing was written", err=True)
        sys.exit(EXIT_AUTH)
    token = (p.stdout or "").strip()
    if p.returncode != 0 or not token:
        click.echo(f"ERROR: {ENV} exited {p.returncode}"
                   + (" with an empty token" if p.returncode == 0 else "") + "; nothing was written", err=True)
        sys.exit(EXIT_AUTH)
    return token


class FreshTokenClient(ToranaClient):
    """A ToranaClient that takes a new token from `TORANA_TOKEN_CMD` before every POST / PUT / PATCH / DELETE."""

    def __init__(self, cmd: str, **kwargs):
        super().__init__(**kwargs)
        self._cmd = cmd

    def _refresh(self) -> None:
        self._access_token = token_from_command(self._cmd)

    def _get_token(self) -> str:
        if not self._access_token:
            self._refresh()
        return self._access_token

    def post(self, *args, **kwargs):
        self._refresh()
        return super().post(*args, **kwargs)

    def put(self, *args, **kwargs):
        self._refresh()
        return super().put(*args, **kwargs)

    def patch(self, *args, **kwargs):
        self._refresh()
        return super().patch(*args, **kwargs)

    def delete(self, *args, **kwargs):
        self._refresh()
        return super().delete(*args, **kwargs)


def client_for(base_url: str, plain_factory=ToranaClient) -> ToranaClient:
    cmd: Optional[str] = os.environ.get(ENV, "").strip() or None
    return FreshTokenClient(cmd, base_url=base_url) if cmd else plain_factory(base_url=base_url)
