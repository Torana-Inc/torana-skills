"""⛔ ONE health renderer, shared by every resource group.

⚠️ `torana widgets health`, `torana transformers health` and `torana rules
health` all land here. A per-group copy would drift, and the whole point of a
health signal is that every surface — API, CLI and FE — gives the same answer
for the same artifact.

⛔ IT COMPUTES NOTHING. `health_state` / `health_label` / `owner_split` arrive
resolved from `/datalake/supply/artifact/{kind}/{id}`. Mapping verdicts to a
state here would be a second copy of SUPPLY_GRAPH_SPEC § 3.4.1.
"""
from __future__ import annotations

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import (
    APIError, ToranaClient, handle_api_error, handle_auth_error,
)
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FORMAT, CTX_PROFILE
from torana_cli.output import output

#: ⛔ A WORD AND A GLYPH, never colour alone — this has to read the same in a
#: pipe, a CI log and a terminal that strips styling, and it decides whether
#: somebody opens a ticket. Mirrors the FE chip exactly.
#:
#: ⚠️ THE STATE SET IS THE SERVER'S, NOT OURS. Every key here is a
#: `health_state` emitted by `_artifact_health()` in
#: `pantheon-datalake/torana_datalake/api/routes/supply.py`, whose
#: `health_label` dict is the authoritative enumeration. Adding a state there
#: and not here is exactly the drift that shipped `degraded` with no glyph:
#: row 17 added the fifth state, this map was never updated, and it fell
#: through a `.get(state, "?")` default straight into `unknown`'s glyph.
#:
#: ⛔ SO THERE IS NO DEFAULT ANY MORE — see `_glyph_for()`. A state we do not
#: know is rendered as a LOUD, visibly-wrong marker, never silently folded
#: into an existing one. Two states that mean opposite things
#: (`degraded` = "returns rows, some fields empty"; `unknown` = "we could not
#: trace it") must never print the same character: one is a data-quality
#: answer, the other is our own gap, and they send a reader to different
#: places.
#:
#: ⚠️ Distinct SHAPES, not shades — the primary reader of this output is
#: red/green colourblind, so a state separated only by colour is, for them,
#: not separated at all.
_GLYPH = {
    "healthy": "✓",
    "degraded": "◐",
    "blocked_ours": "✕",
    "blocked_yours": "▲",
    "unknown": "?",
}

#: ⛔ The marker for a state the server emits and this map has not been taught.
#: Deliberately not "?" — "?" IS `unknown`'s glyph, and reusing it is precisely
#: how the `degraded` bug hid for a whole row. This one is meant to look broken.
_UNMAPPED_GLYPH = "⁉"


def _glyph_for(state: str) -> str:
    """Glyph for a server `health_state` — loud, never silently defaulted.

    ⛔ An unmapped state returns `⁉` and NOT `?`. Silently defaulting is what
    let `degraded` render as `unknown` — a wrong answer that looked like a
    right one. `_UNMAPPED_GLYPH` is visibly not a real state, so the next state
    added server-side surfaces as a rendering bug the moment anyone runs the
    command, instead of quietly impersonating `unknown`.

    ⚠️ It does NOT raise. This is a read-only diagnostic command; refusing to
    print an artifact's health because we lack one glyph would withhold the
    other four correct lines, and a health command that fails closed on a
    cosmetic gap is worse than one that flags it.
    """
    return _GLYPH.get(state, _UNMAPPED_GLYPH)


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    return ToranaClient(base_url=get_settings(profile).base_url)


def render_health(ctx, kind: str, artifact_id: str, show_all: bool = False) -> None:
    """Fetch and print one artifact's supply health.

    ⚠️ `show_all` lists EVERY blocking column instead of the § 3.4.2 cap of 3.
    The cap keeps an inline explanation readable; a user who asked for `--all`
    wants the answer, and "…and 10 more" is a dead end in a terminal they can
    scroll.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.get(f"datalake/supply/artifact/{kind}/{artifact_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
        return

    state = data.get("health_state") or "unknown"
    click.echo(f"\n  {data.get('artifact_name')}  [{data.get('artifact_label')}]")
    click.echo(f"  {_glyph_for(state)} {data.get('health_label') or state.upper()}")
    click.echo(f"  {data.get('why', '')}")
    click.echo(f"  Owner: {data.get('owner', '—')}")

    # ⛔ § 3.2 — split by who can close the gap. Measured on T1: 53% of blocking
    # columns are OURS, so an undifferentiated "your setup is broken" is wrong
    # more often than right.
    split = data.get("owner_split") or {}
    if split.get("blocking_total"):
        click.echo(f"    of {split['blocking_total']} blocking column(s): "
                   f"{split.get('torana', 0)} ours (we do not collect it yet), "
                   f"{split.get('customer', 0)} your setup")
    click.echo()

    rows = (data.get("blocking_all") if show_all else data.get("blocking")) or []
    if rows:
        # ⛔ § 6.2 rule 2 — the label states its OWN population, and the
        # population differs by answer: on `undetermined` these are columns we
        # could not TRACE, and `blocking_count` is 0.
        if data.get("answerable") == "undetermined":
            click.echo(f"  Could not trace ({len(rows)} of "
                       f"{data.get('column_count')} fields it reads):")
        else:
            click.echo(f"  Not supplied ({data.get('blocking_count')} of "
                       f"{data.get('column_count')} fields it reads):")
        for b in rows:
            click.echo(f"    {b['table']}.{b['column']:<28} {b['verdict']}")
        if not show_all and data.get("answerable") != "undetermined":
            more = (data.get("blocking_count") or 0) - len(rows)
            if more > 0:
                click.echo(f"    ...and {more} more   (use --all to list them)")
        click.echo()

    # ⛔ S2 § 3a — supplied, populated, and still unusable for THIS query.
    dead = (data.get("sql_limits") or {}).get("dead_constant_predicates") or []
    if dead:
        click.echo("  Filters on a field that never varies:")
        for c in dead:
            click.echo(f"    {c['table']}.{c['column']:<28} {c['note']}")
        click.echo()

    limits = data.get("sql_limits") or {}
    if limits.get("caveat"):
        click.echo(f"  ⚠️  {limits['caveat']}")
        click.echo(f"     ({limits.get('unqualified_columns_skipped')} "
                   f"column name(s) not checked)\n")


def glyph_for(state: str) -> str:
    """Public alias of `_glyph_for` for callers rendering a health COLUMN.

    ⚠️ Exported so a table never re-derives the glyph set. Two copies of this
    map is exactly the drift documented on `_GLYPH` — one of them gets a new
    server state and the other silently prints the wrong shape.
    """
    return _glyph_for(state)


def workspace_health_map(client, workspace_id: str, kinds=None) -> dict:
    """`{artifact_id: artifact_health}` for every artifact in a workspace.

    ⛔ ONE fetch per workspace, NOT one per row — the same rule the FE's
    `SupplyHealthService` enforces, and for the same measured reason: fetching
    artifacts individually at concurrency 6-10 drove `pantheon-data-transformers`
    into 120s timeouts and an unhealthy container. A 22-widget app would be 22
    calls; a big one far more.

    ⚠️ ALWAYS PASS `kinds` WHEN YOU ONLY NEED ONE. The server diagnoses each
    artifact with its own east-west detail fetch, sequentially, so the response
    time is LINEAR in the artifact count (measured on VM3, 2026-08-16: 45
    artifacts 9.7s / 22 widgets 4.7s / 6 rules 2.0s — ~215ms each). Asking for
    all three kinds to render a widget column makes the caller wait on the
    transformers and rules it will then discard.

    ⚠️ Unavailable → an EMPTY map, never an exception. A health column that
    cannot load must render NO verdict (which is honest) rather than fail the
    whole listing or, worse, imply "healthy" by omission. Callers render an
    absent id as `unknown`.
    """
    params = {"kind": list(kinds)} if kinds else None
    try:
        data = client.get(f"datalake/supply/workspace/{workspace_id}", params=params)
    except (APIError, AuthError):
        return {}
    out = {}
    for a in (data or {}).get("artifacts") or []:
        if a.get("artifact_id"):
            out[a["artifact_id"]] = a
    return out


def multi_workspace_health_map(client, workspace_ids, kinds=None) -> dict:
    """`{artifact_id: artifact_health}` across SEVERAL workspaces, merged.

    ⛔ ONE call PER WORKSPACE, never one per row — `workspace_health_map`'s rule,
    which this only widens. A listing that spans N workspaces costs N calls, not
    len(rows) calls.

    ⚠️ WHY THIS EXISTS AT ALL: a widget listing is workspace-scoped, so one call
    answers it. A TRANSFORMER listing is not — `torana datalake transformers
    list` is tenant-wide and its rows span several workspaces (measured on T1,
    2026-09-22: 43 rows over 5 distinct ids). Asking only the page's own
    workspace would leave most rows blank, which reads as "no opinion" rather
    than "not asked". There is no tenant-wide supply endpoint to ask instead —
    `/datalake/supply/workspace/{id}` is the only artifact sweep the server
    offers — so the fan-out belongs here, once, rather than in each caller.

    ⚠️ A NON-UUID id IS NOT A BUG. Transformers carry sentinel workspace ids
    (`bootstrap`, and `vm-catalog` for catalog-materialized relations). The
    server does not require a UUID, and for `kind=transformer` the sentinel
    resolves normally (measured: `bootstrap` returns 33 transformers). Do NOT
    filter ids through a UUID check — that would silently blank the MAJORITY of
    a tenant's rows.

    ⚠️ Unavailable → that workspace contributes NOTHING and the others still
    render. One unreachable workspace must never blank a whole listing, and an
    absent id is rendered `unknown` by the caller, never "healthy".
    """
    out = {}
    seen = set()
    for wid in workspace_ids:
        if not wid or wid in seen:
            continue
        seen.add(wid)
        # ⛔ PER-WORKSPACE try, NOT one around the loop. `workspace_health_map`
        # swallows APIError/AuthError but NOT an unexpected failure, and a
        # single raising workspace must not abort the sweep — that would blank
        # every workspace ORDERED AFTER the bad one, so the set of rows showing
        # a verdict would depend on listing order. Caught in testing: one
        # failing workspace silently cost a third of the rows their health.
        try:
            out.update(workspace_health_map(client, str(wid), kinds=kinds))
        except Exception:  # noqa: BLE001 — one bad workspace, not a dead column
            continue
    return out


def health_command(kind: str):
    """Build a `health <ID>` command for a resource group.

    ⚠️ One factory, so `widgets health`, `transformers health` and `rules
    health` cannot drift in flags, output or wording.
    """
    @click.command(name="health")
    @click.argument("artifact_id")
    @click.option("--all", "show_all", is_flag=True, default=False,
                  help="List EVERY blocking column, not just the worst 3.")
    @click.pass_context
    def _cmd(ctx, artifact_id, show_all):
        """Can this ever return anything — and if not, who fixes it?"""
        render_health(ctx, kind, artifact_id, show_all=show_all)

    return _cmd
