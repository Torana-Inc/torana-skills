"""torana plan — per-plan instance commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(name="plan", invoke_without_command=True)
@click.argument("plan_id", metavar="PLAN_ID")
@click.pass_context
def plan(ctx, plan_id):
    """Per-plan instance commands.

    \b
    Examples:
      torana plan <UUID> get
      torana plan <UUID> update --name "New Name"
      torana plan <UUID> delete --yes
      torana plan <UUID> transformers
      torana plan <UUID> rules
    """
    ctx.ensure_object(dict)
    ctx.obj["_plan_id"] = plan_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _pid(ctx) -> str:
    return ctx.obj.get("_plan_id", "") if ctx.obj else ""


@plan.command(name="get")
@click.pass_context
def plan_get(ctx):
    """Get details for a specific plan.

    \b
    Examples:
      torana plans list                        # find the id
      torana plan <PLAN_ID> get
      torana plan <PLAN_ID> rule list          # the plan's artifacts live in sub-groups
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"plans/{_pid(ctx)}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan.command(name="update")
@click.option("--name", default=None)
@click.option("--description", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def plan_update(ctx, name, description, input_file):
    """Update a plan."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if description:
        body["description"] = description

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"plans/{_pid(ctx)}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated plan: {_pid(ctx)}")


@plan.command(name="delete")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def plan_delete(ctx, yes):
    """Delete a plan."""
    _confirm(f"Delete plan {_pid(ctx)}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"plans/{_pid(ctx)}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted plan: {_pid(ctx)}")


@plan.command(name="move")
@click.option("--workspace-id", "workspace_id", required=True, help="Target workspace ID")
@click.pass_context
def plan_move(ctx, workspace_id):
    """Move Plan."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/move"
    body = {}
    body["workspace_id"] = workspace_id

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ──────────────────────────────────────────────────────────────────────────
# Plan artifacts — `plan <ID> <artifact> <verb>`.
#
# Regrouped from 40 flat verb-object leaves (`add-rule`, `rules`,
# `rules-by-name`, `update-rule`, `delete-rule` …) into 8 noun-verb
# sub-groups — CLI Discoverability Contract, rule 2 (see ../CLAUDE.md).
#
# ⚠️ `<artifact>s-by-name` was the by-<param> class this rename targets: the
# name stated the ROUTE SHAPE, not what the command does. The identifier now
# lives where it belongs — in the positional argument — and the leaf ends in
# a verb (`get`).
#
# Old flat names remain registered as HIDDEN aliases for ONE release (D4);
# delete `_LEGACY_PLAN_ARTIFACTS` and its registrar next release.
# ──────────────────────────────────────────────────────────────────────────


@plan.group(name="rule")
def plan_rule_grp():
    """Rule artifacts on this plan.

    Examples:
      torana plan <PLAN_ID> rule list
      torana plan <PLAN_ID> rule get <NAME>
    """


@plan.group(name="dashboard")
def plan_dashboard_grp():
    """Dashboard artifacts on this plan.

    Examples:
      torana plan <PLAN_ID> dashboard list
      torana plan <PLAN_ID> dashboard get <NAME>
    """


@plan.group(name="playbook")
def plan_playbook_grp():
    """Playbook artifacts on this plan.

    Examples:
      torana plan <PLAN_ID> playbook list
      torana plan <PLAN_ID> playbook get <NAME>
    """


@plan.group(name="schedule")
def plan_schedule_grp():
    """Schedule artifacts on this plan.

    Examples:
      torana plan <PLAN_ID> schedule list
      torana plan <PLAN_ID> schedule get <NAME>
    """


@plan.group(name="suite")
def plan_suite_grp():
    """Suite artifacts on this plan.

    Examples:
      torana plan <PLAN_ID> suite list
      torana plan <PLAN_ID> suite get <NAME>
    """


@plan.group(name="transformer")
def plan_transformer_grp():
    """Transformer artifacts on this plan.

    Examples:
      torana plan <PLAN_ID> transformer list
      torana plan <PLAN_ID> transformer get <NAME>
    """


@plan.group(name="alert-routing")
def plan_alert_routing_grp():
    """Alert routing artifacts on this plan.

    Examples:
      torana plan <PLAN_ID> alert-routing list
      torana plan <PLAN_ID> alert-routing get <NAME>
    """


@plan.group(name="widget")
def plan_widget_grp():
    """Widget artifacts on this plan.

    Examples:
      torana plan <PLAN_ID> widget list
      torana plan <PLAN_ID> widget get <NAME>
    """


@plan_transformer_grp.command(name="list")
@click.pass_context
def plan_transformers(ctx):
    """List Transformers."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/transformers"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_transformer_grp.command(name="add")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with request body. Use '-' for stdin.")
@click.option("--name", "name", required=True, help="Unique transformer name")
@click.option("--description", "description", default=None, help="Purpose and what this transformer calculates")
@click.option("--custom-sql", "custom_sql", required=True, help="Custom SQL query for the transformation")
@click.option("--destination-table", "destination_table", required=True, help="Target table/view name")
@click.option("--source-tables", "source_tables", default=None, help="List of source tables referenced")
@click.option("--materialized", "materialized", type=bool, default=True, help="Whether to materialize results")
@click.option("--parameters", "parameters", default=None, help="Template parameters if using template")
@click.option("--backend", "backend", default="auto", help="Backend type: snowflake, duckdb, or auto")
@click.option("--unique-key", "unique_key", default=None, help="Natural row key (comma-separated columns) for incremental materialization of a row-projection. When set, the output merges on this key with maintained created_at/updated_at so detection rules can watermark it. Omit for aggregates — the backend auto-infers an unambiguous id column when possible.")
@click.option("--created-by", "created_by", default="program_framework", help="Creator identifier")
@click.pass_context
def plan_add_transformer(ctx, name, description, custom_sql, destination_table, source_tables, materialized, parameters, backend, unique_key, created_by, input_file):
    """Add Transformer."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/transformers"
    if input_file:
        body = _load_input_file(input_file)
    else:
        body = {}
        body["name"] = name
        if description is not None:
            body["description"] = description
        body["custom_sql"] = custom_sql
        body["destination_table"] = destination_table
        if source_tables is not None:
            body["source_tables"] = source_tables
        if materialized is not None:
            body["materialized"] = materialized
        if parameters is not None:
            body["parameters"] = parameters
        if backend is not None:
            body["backend"] = backend
        if unique_key is not None:
            body["unique_key"] = [c.strip() for c in unique_key.split(",") if c.strip()]
        if created_by is not None:
            body["created_by"] = created_by

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_transformer_grp.command(name="get")
@click.argument("NAME", metavar="NAME")
@click.pass_context
def plan_transformers_by_name(ctx, name):
    """Get Transformer."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/transformers/{name}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_transformer_grp.command(name="update")
@click.argument("NAME", metavar="NAME")
@click.option("--description", "description", default=None, help="Purpose and what this transformer calculates")
@click.option("--custom-sql", "custom_sql", required=True, help="Custom SQL query for the transformation")
@click.option("--destination-table", "destination_table", required=True, help="Target table/view name")
@click.option("--source-tables", "source_tables", default=None, help="List of source tables referenced")
@click.option("--materialized", "materialized", type=bool, default=True, help="Whether to materialize results")
@click.option("--parameters", "parameters", default=None, help="Template parameters if using template")
@click.option("--backend", "backend", default="auto", help="Backend type: snowflake, duckdb, or auto")
@click.option("--unique-key", "unique_key", default=None, help="Natural row key (comma-separated columns) for incremental materialization of a row-projection. When set, the output merges on this key with maintained created_at/updated_at so detection rules can watermark it. Omit for aggregates — the backend auto-infers an unambiguous id column when possible.")
@click.option("--created-by", "created_by", default="program_framework", help="Creator identifier")
@click.pass_context
def plan_update_transformer(ctx, name, description, custom_sql, destination_table, source_tables, materialized, parameters, backend, unique_key, created_by):
    """Update Transformer."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/transformers/{name}"
    body = {}
    if description is not None:
        body["description"] = description
    body["custom_sql"] = custom_sql
    body["destination_table"] = destination_table
    if source_tables is not None:
        body["source_tables"] = source_tables
    if materialized is not None:
        body["materialized"] = materialized
    if parameters is not None:
        body["parameters"] = parameters
    if backend is not None:
        body["backend"] = backend
    if unique_key is not None:
        body["unique_key"] = [c.strip() for c in unique_key.split(",") if c.strip()]
    if created_by is not None:
        body["created_by"] = created_by

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_transformer_grp.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("NAME", metavar="NAME")
@click.pass_context
def plan_delete_transformer(ctx, name, yes):
    """Delete Transformer."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"plans/{_pid(ctx)}/transformers/{name}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_rule_grp.command(name="list")
@click.pass_context
def plan_rules(ctx):
    """List Rules."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/rules"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_rule_grp.command(name="add")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with request body. Use '-' for stdin.")
@click.option("--name", "name", required=True, help="Unique rule name")
@click.option("--description", "description", default=None, help="What this rule detects")
@click.option("--query-name", "query_name", required=True, help="Name for the associated query")
@click.option("--query-description", "query_description", default=None, help="Description of what the query does")
@click.option("--sql-command", "sql_command", required=True, help="SQL query that returns findings")
@click.option("--severity", "severity", default=None, help="Severity level for findings")
@click.option("--alert-enabled", "alert_enabled", type=bool, default=True, help="Whether alerts are enabled for this rule")
@click.option("--labels", "labels", default=None, help="Labels for categorization and metadata")
@click.option("--query-labels", "query_labels", default=None, help="Labels for the associated query")
@click.pass_context
def plan_add_rule(ctx, name, description, query_name, query_description, sql_command, severity, alert_enabled, labels, query_labels, input_file):
    """Add Rule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/rules"
    if input_file:
        body = _load_input_file(input_file)
    else:
        body = {}
        body["name"] = name
        if description is not None:
            body["description"] = description
        body["query_name"] = query_name
        if query_description is not None:
            body["query_description"] = query_description
        body["sql_command"] = sql_command
        if severity is not None:
            body["severity"] = severity
        if alert_enabled is not None:
            body["alert_enabled"] = alert_enabled
        if labels is not None:
            body["labels"] = labels
        if query_labels is not None:
            body["query_labels"] = query_labels

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_rule_grp.command(name="get")
@click.argument("NAME", metavar="NAME")
@click.pass_context
def plan_rules_by_name(ctx, name):
    """Get Rule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/rules/{name}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_rule_grp.command(name="update")
@click.argument("NAME", metavar="NAME")
@click.option("--description", "description", default=None, help="What this rule detects")
@click.option("--query-name", "query_name", required=True, help="Name for the associated query")
@click.option("--query-description", "query_description", default=None, help="Description of what the query does")
@click.option("--sql-command", "sql_command", required=True, help="SQL query that returns findings")
@click.option("--severity", "severity", default=None, help="Severity level for findings")
@click.option("--alert-enabled", "alert_enabled", type=bool, default=True, help="Whether alerts are enabled for this rule")
@click.option("--labels", "labels", default=None, help="Labels for categorization and metadata")
@click.option("--query-labels", "query_labels", default=None, help="Labels for the associated query")
@click.pass_context
def plan_update_rule(ctx, name, description, query_name, query_description, sql_command, severity, alert_enabled, labels, query_labels):
    """Update Rule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/rules/{name}"
    body = {}
    if description is not None:
        body["description"] = description
    body["query_name"] = query_name
    if query_description is not None:
        body["query_description"] = query_description
    body["sql_command"] = sql_command
    if severity is not None:
        body["severity"] = severity
    if alert_enabled is not None:
        body["alert_enabled"] = alert_enabled
    if labels is not None:
        body["labels"] = labels
    if query_labels is not None:
        body["query_labels"] = query_labels

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_rule_grp.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("NAME", metavar="NAME")
@click.pass_context
def plan_delete_rule(ctx, name, yes):
    """Delete Rule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"plans/{_pid(ctx)}/rules/{name}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_suite_grp.command(name="list")
@click.pass_context
def plan_suites(ctx):
    """List Suites."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/suites"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_suite_grp.command(name="add")
@click.option("--name", "name", required=True, help="Unique suite name")
@click.option("--description", "description", default=None, help="Purpose of this suite")
@click.option("--labels", "labels", default=None, help="Labels for categorization and metadata")
@click.pass_context
def plan_add_suite(ctx, name, description, labels):
    """Add Suite."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/suites"
    body = {}
    body["name"] = name
    if description is not None:
        body["description"] = description
    if labels is not None:
        body["labels"] = labels

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_suite_grp.command(name="get")
@click.argument("NAME", metavar="NAME")
@click.pass_context
def plan_suites_by_name(ctx, name):
    """Get Suite."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/suites/{name}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_suite_grp.command(name="update")
@click.argument("NAME", metavar="NAME")
@click.option("--description", "description", default=None, help="Purpose of this suite")
@click.option("--labels", "labels", default=None, help="Labels for categorization and metadata")
@click.pass_context
def plan_update_suite(ctx, name, description, labels):
    """Update Suite."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/suites/{name}"
    body = {}
    if description is not None:
        body["description"] = description
    if labels is not None:
        body["labels"] = labels

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_suite_grp.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("NAME", metavar="NAME")
@click.pass_context
def plan_delete_suite(ctx, name, yes):
    """Delete Suite."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"plans/{_pid(ctx)}/suites/{name}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_playbook_grp.command(name="list")
@click.pass_context
def plan_playbooks(ctx):
    """List Playbooks."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/playbooks"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_playbook_grp.command(name="add")
@click.option("--name", "name", required=True, help="Unique playbook name")
@click.option("--description", "description", default=None, help="What this playbook does")
@click.option("--instructions", "instructions", required=True, help="Natural language instructions for the AI agent")
@click.option("--input-parameters", "input_parameters", default=None, help="Input parameters")
@click.option("--agent-name", "agent_name", default=None, help="Specific agent to use (optional)")
@click.option("--agent-id", "agent_id", default=None, help="Specific agent ID to use (optional)")
@click.option("--tags", "tags", default=None, help="Tags for categorization")
@click.option("--status", "status", default="active", help="Playbook status (active/draft/archived)")
@click.pass_context
def plan_add_playbook(ctx, name, description, instructions, input_parameters, agent_name, agent_id, tags, status):
    """Add Playbook."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/playbooks"
    body = {}
    body["name"] = name
    if description is not None:
        body["description"] = description
    body["instructions"] = instructions
    if input_parameters is not None:
        body["input_parameters"] = input_parameters
    if agent_name is not None:
        body["agent_name"] = agent_name
    if agent_id is not None:
        body["agent_id"] = agent_id
    if tags is not None:
        body["tags"] = tags
    if status is not None:
        body["status"] = status

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_playbook_grp.command(name="get")
@click.argument("NAME", metavar="NAME")
@click.pass_context
def plan_playbooks_by_name(ctx, name):
    """Get Playbook."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/playbooks/{name}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_playbook_grp.command(name="update")
@click.argument("NAME", metavar="NAME")
@click.option("--description", "description", default=None, help="What this playbook does")
@click.option("--instructions", "instructions", required=True, help="Natural language instructions for the AI agent")
@click.option("--input-parameters", "input_parameters", default=None, help="Input parameters")
@click.option("--agent-name", "agent_name", default=None, help="Specific agent to use (optional)")
@click.option("--agent-id", "agent_id", default=None, help="Specific agent ID to use (optional)")
@click.option("--tags", "tags", default=None, help="Tags for categorization")
@click.option("--status", "status", default="active", help="Playbook status (active/draft/archived)")
@click.pass_context
def plan_update_playbook(ctx, name, description, instructions, input_parameters, agent_name, agent_id, tags, status):
    """Update Playbook."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/playbooks/{name}"
    body = {}
    if description is not None:
        body["description"] = description
    body["instructions"] = instructions
    if input_parameters is not None:
        body["input_parameters"] = input_parameters
    if agent_name is not None:
        body["agent_name"] = agent_name
    if agent_id is not None:
        body["agent_id"] = agent_id
    if tags is not None:
        body["tags"] = tags
    if status is not None:
        body["status"] = status

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_playbook_grp.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("NAME", metavar="NAME")
@click.pass_context
def plan_delete_playbook(ctx, name, yes):
    """Delete Playbook."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"plans/{_pid(ctx)}/playbooks/{name}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_alert_routing_grp.command(name="list")
@click.pass_context
def plan_alert_routing(ctx):
    """List Alert Routing."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/alert-routing"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_alert_routing_grp.command(name="add")
@click.option("--name", "name", required=True, help="Routing rule name")
@click.option("--description", "description", default=None, help="What this routing rule does")
@click.option("--enabled", "enabled", type=bool, default=True, help="Whether routing is enabled")
@click.option("--priority", "priority", type=int, default=100, help="Routing priority (lower = higher priority)")
@click.option("--stop-on-match", "stop_on_match", type=bool, default=False, help="Whether to stop processing other rules")
@click.option("--severity-levels", "severity_levels", default=None, help="Severity levels to match")
@click.option("--required-tags", "required_tags", default=None, help="Required tags on alert")
@click.option("--source-rule-ids", "source_rule_ids", default=None, help="Source rule IDs (supports templates)")
@click.option("--source-suite-ids", "source_suite_ids", default=None, help="Source suite IDs")
@click.option("--matching-operator", "matching_operator", default="any", help="Match operator: any or all")
@click.option("--destination-type", "destination_type", default="playbook", help="Destination type: user, agent, or playbook")
@click.option("--destination-config", "destination_config", required=True, help="Destination configuration (playbook_id, input_mapping, etc)")
@click.option("--max-executions-per-hour", "max_executions_per_hour", default=None, help="Rate limit")
@click.pass_context
def plan_add_alert_routing(ctx, name, description, enabled, priority, stop_on_match, severity_levels, required_tags, source_rule_ids, source_suite_ids, matching_operator, destination_type, destination_config, max_executions_per_hour):
    """Add Alert Routing Rule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/alert-routing"
    body = {}
    body["name"] = name
    if description is not None:
        body["description"] = description
    if enabled is not None:
        body["enabled"] = enabled
    if priority is not None:
        body["priority"] = priority
    if stop_on_match is not None:
        body["stop_on_match"] = stop_on_match
    if severity_levels is not None:
        body["severity_levels"] = severity_levels
    if required_tags is not None:
        body["required_tags"] = required_tags
    if source_rule_ids is not None:
        body["source_rule_ids"] = source_rule_ids
    if source_suite_ids is not None:
        body["source_suite_ids"] = source_suite_ids
    if matching_operator is not None:
        body["matching_operator"] = matching_operator
    if destination_type is not None:
        body["destination_type"] = destination_type
    body["destination_config"] = destination_config
    if max_executions_per_hour is not None:
        body["max_executions_per_hour"] = max_executions_per_hour

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_alert_routing_grp.command(name="get")
@click.argument("NAME", metavar="NAME")
@click.pass_context
def plan_alert_routing_by_name(ctx, name):
    """Get Alert Routing Rule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/alert-routing/{name}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_alert_routing_grp.command(name="update")
@click.argument("NAME", metavar="NAME")
@click.option("--description", "description", default=None, help="What this routing rule does")
@click.option("--enabled", "enabled", type=bool, default=True, help="Whether routing is enabled")
@click.option("--priority", "priority", type=int, default=100, help="Routing priority (lower = higher priority)")
@click.option("--stop-on-match", "stop_on_match", type=bool, default=False, help="Whether to stop processing other rules")
@click.option("--severity-levels", "severity_levels", default=None, help="Severity levels to match")
@click.option("--required-tags", "required_tags", default=None, help="Required tags on alert")
@click.option("--source-rule-ids", "source_rule_ids", default=None, help="Source rule IDs (supports templates)")
@click.option("--source-suite-ids", "source_suite_ids", default=None, help="Source suite IDs")
@click.option("--matching-operator", "matching_operator", default="any", help="Match operator: any or all")
@click.option("--destination-type", "destination_type", default="playbook", help="Destination type: user, agent, or playbook")
@click.option("--destination-config", "destination_config", required=True, help="Destination configuration (playbook_id, input_mapping, etc)")
@click.option("--max-executions-per-hour", "max_executions_per_hour", default=None, help="Rate limit")
@click.pass_context
def plan_update_alert_routing(ctx, name, description, enabled, priority, stop_on_match, severity_levels, required_tags, source_rule_ids, source_suite_ids, matching_operator, destination_type, destination_config, max_executions_per_hour):
    """Update Alert Routing Rule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/alert-routing/{name}"
    body = {}
    if description is not None:
        body["description"] = description
    if enabled is not None:
        body["enabled"] = enabled
    if priority is not None:
        body["priority"] = priority
    if stop_on_match is not None:
        body["stop_on_match"] = stop_on_match
    if severity_levels is not None:
        body["severity_levels"] = severity_levels
    if required_tags is not None:
        body["required_tags"] = required_tags
    if source_rule_ids is not None:
        body["source_rule_ids"] = source_rule_ids
    if source_suite_ids is not None:
        body["source_suite_ids"] = source_suite_ids
    if matching_operator is not None:
        body["matching_operator"] = matching_operator
    if destination_type is not None:
        body["destination_type"] = destination_type
    body["destination_config"] = destination_config
    if max_executions_per_hour is not None:
        body["max_executions_per_hour"] = max_executions_per_hour

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_alert_routing_grp.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("NAME", metavar="NAME")
@click.pass_context
def plan_delete_alert_routing(ctx, name, yes):
    """Delete Alert Routing Rule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"plans/{_pid(ctx)}/alert-routing/{name}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_schedule_grp.command(name="list")
@click.pass_context
def plan_schedules(ctx):
    """List Schedules."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/schedules"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_schedule_grp.command(name="add")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with request body. Use '-' for stdin.")
@click.option("--name", "name", required=True, help="Unique schedule name")
@click.option("--description", "description", default=None, help="What this schedule controls")
@click.option("--task-type", "task_type", type=click.Choice(["playbook", "suite", "rule", "transformer"], case_sensitive=False), required=True, help="Type of task to schedule")
@click.option("--schedule-type", "schedule_type", default="cron", help="Schedule type (typically 'cron')")
@click.option("--schedule-expression", "schedule_expression", required=True, help="Cron expression")
@click.option("--timezone", "timezone", default="UTC", help="Timezone for schedule")
@click.option("--is-enabled", "is_enabled", type=bool, default=True, help="Whether schedule is enabled")
@click.option("--playbook-id", "playbook_id", default=None, help="Playbook ID if task_type=playbook")
@click.option("--suite-id", "suite_id", default=None, help="Suite ID if task_type=suite")
@click.option("--rule-id", "rule_id", default=None, help="Rule ID if task_type=rule")
@click.option("--transformer-id", "transformer_id", default=None, help="Transformer ID if task_type=transformer")
@click.option("--start-date", "start_date", default=None, help="Schedule start date")
@click.option("--end-date", "end_date", default=None, help="Schedule end date")
@click.option("--max-executions", "max_executions", default=None, help="Maximum number of executions")
@click.option("--parameters", "parameters", default=None, help="Schedule parameters")
@click.option("--on-failure", "on_failure", default=None, help="Behavior on failure")
@click.option("--notify-on-failure", "notify_on_failure", type=bool, default=False, help="Send notifications on failure")
@click.pass_context
def plan_add_schedule(ctx, name, description, task_type, schedule_type, schedule_expression, timezone, is_enabled, playbook_id, suite_id, rule_id, transformer_id, start_date, end_date, max_executions, parameters, on_failure, notify_on_failure, input_file):
    """Add Schedule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/schedules"
    if input_file:
        body = _load_input_file(input_file)
    else:
        body = {}
        body["name"] = name
        if description is not None:
            body["description"] = description
        body["task_type"] = task_type
        if schedule_type is not None:
            body["schedule_type"] = schedule_type
        body["schedule_expression"] = schedule_expression
        if timezone is not None:
            body["timezone"] = timezone
        if is_enabled is not None:
            body["is_enabled"] = is_enabled
        if playbook_id is not None:
            body["playbook_id"] = playbook_id
        if suite_id is not None:
            body["suite_id"] = suite_id
        if rule_id is not None:
            body["rule_id"] = rule_id
        if transformer_id is not None:
            body["transformer_id"] = transformer_id
        if start_date is not None:
            body["start_date"] = start_date
        if end_date is not None:
            body["end_date"] = end_date
        if max_executions is not None:
            body["max_executions"] = max_executions
        if parameters is not None:
            body["parameters"] = parameters
        if on_failure is not None:
            body["on_failure"] = on_failure
        if notify_on_failure is not None:
            body["notify_on_failure"] = notify_on_failure

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_schedule_grp.command(name="get")
@click.argument("NAME", metavar="NAME")
@click.pass_context
def plan_schedules_by_name(ctx, name):
    """Get Schedule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/schedules/{name}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_schedule_grp.command(name="update")
@click.argument("NAME", metavar="NAME")
@click.option("--description", "description", default=None, help="What this schedule controls")
@click.option("--task-type", "task_type", type=click.Choice(["playbook", "suite", "rule", "transformer"], case_sensitive=False), required=True, help="Type of task to schedule")
@click.option("--schedule-type", "schedule_type", default="cron", help="Schedule type (typically 'cron')")
@click.option("--schedule-expression", "schedule_expression", required=True, help="Cron expression")
@click.option("--timezone", "timezone", default="UTC", help="Timezone for schedule")
@click.option("--is-enabled", "is_enabled", type=bool, default=True, help="Whether schedule is enabled")
@click.option("--playbook-id", "playbook_id", default=None, help="Playbook ID if task_type=playbook")
@click.option("--suite-id", "suite_id", default=None, help="Suite ID if task_type=suite")
@click.option("--rule-id", "rule_id", default=None, help="Rule ID if task_type=rule")
@click.option("--transformer-id", "transformer_id", default=None, help="Transformer ID if task_type=transformer")
@click.option("--start-date", "start_date", default=None, help="Schedule start date")
@click.option("--end-date", "end_date", default=None, help="Schedule end date")
@click.option("--max-executions", "max_executions", default=None, help="Maximum number of executions")
@click.option("--parameters", "parameters", default=None, help="Schedule parameters")
@click.option("--on-failure", "on_failure", default=None, help="Behavior on failure")
@click.option("--notify-on-failure", "notify_on_failure", type=bool, default=False, help="Send notifications on failure")
@click.pass_context
def plan_update_schedule(ctx, name, description, task_type, schedule_type, schedule_expression, timezone, is_enabled, playbook_id, suite_id, rule_id, transformer_id, start_date, end_date, max_executions, parameters, on_failure, notify_on_failure):
    """Update Schedule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/schedules/{name}"
    body = {}
    if description is not None:
        body["description"] = description
    body["task_type"] = task_type
    if schedule_type is not None:
        body["schedule_type"] = schedule_type
    body["schedule_expression"] = schedule_expression
    if timezone is not None:
        body["timezone"] = timezone
    if is_enabled is not None:
        body["is_enabled"] = is_enabled
    if playbook_id is not None:
        body["playbook_id"] = playbook_id
    if suite_id is not None:
        body["suite_id"] = suite_id
    if rule_id is not None:
        body["rule_id"] = rule_id
    if transformer_id is not None:
        body["transformer_id"] = transformer_id
    if start_date is not None:
        body["start_date"] = start_date
    if end_date is not None:
        body["end_date"] = end_date
    if max_executions is not None:
        body["max_executions"] = max_executions
    if parameters is not None:
        body["parameters"] = parameters
    if on_failure is not None:
        body["on_failure"] = on_failure
    if notify_on_failure is not None:
        body["notify_on_failure"] = notify_on_failure

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_schedule_grp.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("NAME", metavar="NAME")
@click.pass_context
def plan_delete_schedule(ctx, name, yes):
    """Delete Schedule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"plans/{_pid(ctx)}/schedules/{name}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_dashboard_grp.command(name="list")
@click.pass_context
def plan_dashboards(ctx):
    """List Dashboards."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/dashboards"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_dashboard_grp.command(name="add")
@click.option("--name", "name", required=True, help="Unique dashboard name")
@click.option("--description", "description", default=None, help="Purpose of this dashboard")
@click.option("--labels", "labels", default=None, help="Labels for categorization and metadata")
@click.option("--widgets", "widgets", default=None, help="Dashboard widgets")
@click.pass_context
def plan_add_dashboard(ctx, name, description, labels, widgets):
    """Add Dashboard."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/dashboards"
    body = {}
    body["name"] = name
    if description is not None:
        body["description"] = description
    if labels is not None:
        body["labels"] = labels
    if widgets is not None:
        body["widgets"] = widgets

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_dashboard_grp.command(name="get")
@click.argument("NAME", metavar="NAME")
@click.pass_context
def plan_dashboards_by_name(ctx, name):
    """Get Dashboard."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/dashboards/{name}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_dashboard_grp.command(name="update")
@click.argument("NAME", metavar="NAME")
@click.option("--description", "description", default=None, help="Purpose of this dashboard")
@click.option("--labels", "labels", default=None, help="Labels for categorization and metadata")
@click.option("--widgets", "widgets", default=None, help="Dashboard widgets")
@click.pass_context
def plan_update_dashboard(ctx, name, description, labels, widgets):
    """Update Dashboard."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/dashboards/{name}"
    body = {}
    if description is not None:
        body["description"] = description
    if labels is not None:
        body["labels"] = labels
    if widgets is not None:
        body["widgets"] = widgets

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_dashboard_grp.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("NAME", metavar="NAME")
@click.pass_context
def plan_delete_dashboard(ctx, name, yes):
    """Delete Dashboard."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"plans/{_pid(ctx)}/dashboards/{name}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_widget_grp.command(name="list")
@click.argument("DASHBOARD_NAME", metavar="DASHBOARD_NAME")
@click.pass_context
def plan_widgets(ctx, dashboard_name):
    """List Dashboard Widgets."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/dashboards/{dashboard_name}/widgets"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_widget_grp.command(name="add")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with request body. Use '-' for stdin.")
@click.argument("DASHBOARD_NAME", metavar="DASHBOARD_NAME")
@click.option("--id", "id", required=True, help="Unique widget ID")
@click.option("--title", "title", required=True, help="Widget title")
@click.option("--type", "type", type=click.Choice(["metric_card", "chart", "table", "gauge", "pie", "bar", "line", "area", "scalar"], case_sensitive=False), required=True, help="Widget visualization type")
@click.option("--data-source", "data_source", required=True, help="Data source configuration for a widget.")
@click.option("--display-config", "display_config", default=None, help="Display configuration for widget rendering")
@click.option("--size", "size", type=click.Choice(["small", "medium", "large", "full"], case_sensitive=False), default="medium", help="Widget size")
@click.option("--position", "position", default=None, help="Grid position {row, col}")
@click.pass_context
def plan_add_widget(ctx, dashboard_name, id, title, type, data_source, display_config, size, position, input_file):
    """Add Dashboard Widget."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/dashboards/{dashboard_name}/widgets"
    if input_file:
        body = _load_input_file(input_file)
    else:
        body = {}
        body["id"] = id
        body["title"] = title
        body["type"] = type
        body["data_source"] = data_source
        if display_config is not None:
            body["display_config"] = display_config
        if size is not None:
            body["size"] = size
        if position is not None:
            body["position"] = position

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_widget_grp.command(name="get")
@click.argument("DASHBOARD_NAME", metavar="DASHBOARD_NAME")
@click.argument("WIDGET_ID", metavar="WIDGET_ID")
@click.pass_context
def plan_widgets_by_widget_id(ctx, dashboard_name, widget_id):
    """Get Dashboard Widget."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/dashboards/{dashboard_name}/widgets/{widget_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_widget_grp.command(name="update")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with request body. Use '-' for stdin.")
@click.argument("DASHBOARD_NAME", metavar="DASHBOARD_NAME")
@click.argument("WIDGET_ID", metavar="WIDGET_ID")
@click.option("--id", "id", required=True, help="Unique widget ID")
@click.option("--title", "title", required=True, help="Widget title")
@click.option("--type", "type", type=click.Choice(["metric_card", "chart", "table", "gauge", "pie", "bar", "line", "area", "scalar"], case_sensitive=False), required=True, help="Widget visualization type")
@click.option("--data-source", "data_source", required=True, help="Data source configuration for a widget.")
@click.option("--display-config", "display_config", default=None, help="Display configuration for widget rendering")
@click.option("--size", "size", type=click.Choice(["small", "medium", "large", "full"], case_sensitive=False), default="medium", help="Widget size")
@click.option("--position", "position", default=None, help="Grid position {row, col}")
@click.pass_context
def plan_update_widget(ctx, dashboard_name, widget_id, id, title, type, data_source, display_config, size, position, input_file):
    """Update Dashboard Widget."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"plans/{_pid(ctx)}/dashboards/{dashboard_name}/widgets/{widget_id}"
    if input_file:
        body = _load_input_file(input_file)
    else:
        body = {}
        body["id"] = id
        body["title"] = title
        body["type"] = type
        body["data_source"] = data_source
        if display_config is not None:
            body["display_config"] = display_config
        if size is not None:
            body["size"] = size
        if position is not None:
            body["position"] = position

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@plan_widget_grp.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("DASHBOARD_NAME", metavar="DASHBOARD_NAME")
@click.argument("WIDGET_ID", metavar="WIDGET_ID")
@click.pass_context
def plan_delete_widget(ctx, dashboard_name, widget_id, yes):
    """Delete Dashboard Widget."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"plans/{_pid(ctx)}/dashboards/{dashboard_name}/widgets/{widget_id}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ──────────────────────────────────────────────────────────────────────────
# BACK-COMPAT — hidden aliases for the old flat artifact command names.
# ⏳ ONE RELEASE ONLY (decision D4). Delete this block next release.
# ──────────────────────────────────────────────────────────────────────────

_LEGACY_PLAN_ARTIFACTS = {
    "add-alert-routing": ("alert-routing", "add"),
    "add-dashboard": ("dashboard", "add"),
    "add-playbook": ("playbook", "add"),
    "add-rule": ("rule", "add"),
    "add-schedule": ("schedule", "add"),
    "add-suite": ("suite", "add"),
    "add-transformer": ("transformer", "add"),
    "add-widget": ("widget", "add"),
    "alert-routing": ("alert-routing", "list"),
    "alert-routing-by-name": ("alert-routing", "get"),
    "dashboards": ("dashboard", "list"),
    "dashboards-by-name": ("dashboard", "get"),
    "delete-alert-routing": ("alert-routing", "delete"),
    "delete-dashboard": ("dashboard", "delete"),
    "delete-playbook": ("playbook", "delete"),
    "delete-rule": ("rule", "delete"),
    "delete-schedule": ("schedule", "delete"),
    "delete-suite": ("suite", "delete"),
    "delete-transformer": ("transformer", "delete"),
    "delete-widget": ("widget", "delete"),
    "playbooks": ("playbook", "list"),
    "playbooks-by-name": ("playbook", "get"),
    "rules": ("rule", "list"),
    "rules-by-name": ("rule", "get"),
    "schedules": ("schedule", "list"),
    "schedules-by-name": ("schedule", "get"),
    "suites": ("suite", "list"),
    "suites-by-name": ("suite", "get"),
    "transformers": ("transformer", "list"),
    "transformers-by-name": ("transformer", "get"),
    "update-alert-routing": ("alert-routing", "update"),
    "update-dashboard": ("dashboard", "update"),
    "update-playbook": ("playbook", "update"),
    "update-rule": ("rule", "update"),
    "update-schedule": ("schedule", "update"),
    "update-suite": ("suite", "update"),
    "update-transformer": ("transformer", "update"),
    "update-widget": ("widget", "update"),
    "widgets": ("widget", "list"),
    "widgets-by-widget-id": ("widget", "get"),
}


def _register_legacy_plan_aliases() -> None:
    """Old flat names, hidden so they cannot be discovered anew."""
    import copy
    for _old, (_group, _verb) in _LEGACY_PLAN_ARTIFACTS.items():
        _grp = plan.commands.get(_group)
        if not isinstance(_grp, click.Group):
            continue
        _cmd = _grp.commands.get(_verb)
        if _cmd is None:
            continue
        # ⛔ Never let an alias overwrite a real group that now owns this name
        # — that would hide every verb underneath it.
        if isinstance(plan.commands.get(_old), click.Group):
            continue
        _alias = copy.copy(_cmd)
        _alias.name = _old
        _alias.hidden = True
        plan.add_command(_alias)


_register_legacy_plan_aliases()
