"""The one line an Inbox item shows for its fix plan (the API's `fix_plan`, B11).

`fix_plan` is `{id, target_repository, resolve_file, state, pr_state, pr_number, pr_url, decided_by,
blocked_reason, merged_at}` or null. `fix_status` (I-90) is set once the plan's PR merged and the item is still open:
`{state, badge, title, lines, ...}` — whether a scan has looked since the merge, in the platform's words. ⛔ The words come from the platform's fields; the CLI never works out a plan's state
itself. `blocked_reason` is already in words ("needs an engineering decision: requirements.in:23 …"): print it.
"""
from typing import Any, Dict, Optional

#: `pr_state` (`none | opening | opening_stale | open | merged | closed`) in words. `none` says nothing.
_PR_WORDS = {"opening": "PR opening", "opening_stale": "PR opening (stalled)"}


def repo_name(key: Optional[str]) -> str:
    """`repo:github.com/acme/pantheon-deploy` → `pantheon-deploy`."""
    return str(key or "").rstrip("/").rsplit("/", 1)[-1]


def state_words(fp: Dict[str, Any], decider: Optional[str] = None) -> str:
    """`approved by system`, `approved by <name>`, or the state itself (`proposed`, `refused`, …)."""
    state = str(fp.get("state") or "").replace("_", " ")
    who = fp.get("decided_by")
    if state == "approved" and who:
        return "approved by system" if who == "system" else f"approved by {decider or who}"
    return state


#: Plan states that go ahead to a PR (the FE's GO_STATES, services/remediation-plans.service.ts).
GO_STATES = ("approved", "overridden", "removal_chosen")


def pr_words(fp: Dict[str, Any]) -> str:
    """`PR #7 open` / `PR #7 merged` / `PR #7 closed without merge` / `PR opening` / `PR pending` (a plan that goes ahead
    and has no PR yet, as the Inbox says it, EM A-03); empty for a plan that does not go ahead and has none."""
    ps = fp.get("pr_state") or "none"
    if ps in ("open", "merged", "closed"):
        pr = f"PR #{fp['pr_number']}" if fp.get("pr_number") is not None else "PR"
        return f"{pr} closed without merge" if ps == "closed" else f"{pr} {ps}"
    if ps == "none" and fp.get("state") in GO_STATES:
        return "PR pending"
    return _PR_WORDS.get(ps, "")


def fix_plan_line(fp: Optional[Dict[str, Any]], decider: Optional[str] = None) -> Optional[str]:
    """`Fix: pantheon-deploy · base-image/requirements.lock · approved by system · PR #7 open`; None without a plan.

    `decider` is the person's name for a `decided_by` that is not `system` (the caller resolves it)."""
    if not isinstance(fp, dict):
        return None
    parts = [repo_name(fp.get("target_repository")), fp.get("resolve_file") or "",
             state_words(fp, decider), pr_words(fp), fp.get("blocked_reason") or ""]
    return "Fix: " + " · ".join(p for p in parts if p)


def fix_plan_short(fp: Optional[Dict[str, Any]], fs: Optional[Dict[str, Any]] = None) -> Optional[str]:
    """The list's FIX column: the state and the PR, or the state and `blocked` (the full reason is in `get`).
    A merged fix with a `fix_status` prints the API's `fix_status.badge` as sent ("PR #8 merged · waiting for scan")."""
    if not isinstance(fp, dict):
        return None
    if isinstance(fs, dict) and fs.get("badge"):
        badge = str(fs["badge"])
        # An older platform sent only the tail ("waiting for scan"): the one place the CLI adds words of its own.
        return badge if "merged" in badge else f"merged · {badge}"
    state = "approved" if fp.get("state") == "approved" else state_words(fp)
    tail = pr_words(fp) or ("blocked" if fp.get("blocked_reason") else "")
    return " · ".join(p for p in (state, tail) if p)
