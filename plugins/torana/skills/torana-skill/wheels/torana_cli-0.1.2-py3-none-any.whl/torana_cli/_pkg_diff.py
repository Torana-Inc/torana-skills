"""Derive changed ``pkg:`` keys from a local git diff (GAP-A2).

`torana fix-impact analyze --base-sha X --head-sha Y` used to accept the two SHAs and do
NOTHING with them (they never reached the compute). This module closes that gap: given a local
git checkout, it diffs the dependency manifests between the two commits and returns the changed
package coordinates as source-neutral ``pkg:<type>/<name>@<version>`` keys — the same keys the
entity graph uses — so a PR/branch feeds fix-impact directly instead of the caller hand-listing
packages.

Deliberately CLI/checkout-side (not the API): deriving from a diff needs the repo, which the
developer/skill has locally and the stateless API does not. Server-side auto-compute on
remediation creation (via the GitHub compare API) remains a documented follow-up; the API still
carries base_sha/head_sha for it.

Supported manifests (pinned/resolved versions only — the reliable signal):
  requirements*.txt  → pypi     go.mod            → golang
  poetry.lock        → pypi     package-lock.json → npm
Anything else changed in the diff is reported as skipped, never silently dropped.
"""
from __future__ import annotations

import json
import re
import subprocess
from typing import Any, Callable, Dict, List, Tuple


def _git(repo_path: str, args: List[str]) -> "str | None":
    """Run `git -C <repo_path> <args>`; return stdout, or None on any failure."""
    try:
        r = subprocess.run(
            ["git", "-C", repo_path, *args],
            capture_output=True, text=True, timeout=30,
        )
        return r.stdout if r.returncode == 0 else None
    except Exception:
        return None


def _git_show(repo_path: str, ref: str, path: str) -> str:
    """Content of `path` at `ref` — empty string if it did not exist there (added file)."""
    return _git(repo_path, ["show", f"{ref}:{path}"]) or ""


def _norm_pypi(name: str) -> str:
    """PyPI/purl name normalization: lowercase, underscores→hyphens (so `Foo_Bar`==`foo-bar`)."""
    return name.strip().lower().replace("_", "-")


# ── per-manifest parsers → {package_name: resolved_version} ──────────────────────────────────

def _parse_requirements(text: str) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or line.startswith("-"):
            continue                                   # skip blanks, comments, -r/-e/--flags
        line = line.split(" #", 1)[0].strip()          # strip inline comment
        # only exact pins are a reliable coordinate: name[extras]==version
        m = re.match(r"^([A-Za-z0-9._-]+)\s*(?:\[[^\]]*\])?\s*==\s*([A-Za-z0-9._+!-]+)", line)
        if m:
            out[_norm_pypi(m.group(1))] = m.group(2)
    return out


def _parse_gomod(text: str) -> Dict[str, str]:
    out: Dict[str, str] = {}
    in_block = False
    for raw in text.splitlines():
        s = raw.strip()
        if not s or s.startswith("//"):
            continue
        if s.startswith("require ("):
            in_block = True
            continue
        if in_block and s == ")":
            in_block = False
            continue
        if s.startswith("require ") and not s.startswith("require ("):
            s = s[len("require "):].strip()
        elif not in_block:
            continue
        s = s.split("//", 1)[0].strip()                # drop `// indirect` etc.
        parts = s.split()
        if len(parts) >= 2 and parts[1].startswith("v"):
            out[parts[0]] = parts[1].lstrip("v")
    return out


def _parse_package_lock(text: str) -> Dict[str, str]:
    out: Dict[str, str] = {}
    try:
        d = json.loads(text)
    except Exception:
        return out
    pkgs = d.get("packages")
    if isinstance(pkgs, dict):                          # lockfile v2/v3
        for k, v in pkgs.items():
            if not k or not isinstance(v, dict):
                continue
            if "node_modules/" in k:
                name = k.split("node_modules/")[-1]     # keeps @scope/name
                ver = v.get("version")
                if name and ver:
                    out[name] = ver
    else:                                               # lockfile v1
        def _walk(deps: dict) -> None:
            for name, meta in (deps or {}).items():
                if isinstance(meta, dict):
                    if meta.get("version"):
                        out[name] = meta["version"]
                    _walk(meta.get("dependencies"))
        _walk(d.get("dependencies") or {})
    return out


def _parse_poetry_lock(text: str) -> Dict[str, str]:
    out: Dict[str, str] = {}
    try:
        import tomllib  # py3.11+
        d = tomllib.loads(text)
        for p in d.get("package", []) or []:
            n, v = p.get("name"), p.get("version")
            if n and v:
                out[_norm_pypi(n)] = v
    except Exception:
        pass
    return out


# (filename predicate, parser, purl type)
_FILE_PARSERS: List[Tuple[Callable[[str], bool], Callable[[str], Dict[str, str]], str]] = [
    (lambda f: f.rsplit("/", 1)[-1] == "go.mod", _parse_gomod, "golang"),
    (lambda f: f.rsplit("/", 1)[-1] == "package-lock.json", _parse_package_lock, "npm"),
    (lambda f: f.rsplit("/", 1)[-1] == "poetry.lock", _parse_poetry_lock, "pypi"),
    (lambda f: "requirements" in f.rsplit("/", 1)[-1] and f.endswith(".txt"),
     _parse_requirements, "pypi"),
]


def derive_changed_pkgs(repo_path: str, base: str, head: str) -> Dict[str, Any]:
    """Dependency changes between two SHAs, split BY ROLE:
    ``{"base": [...], "head": [...], "names": [...], "notes": [...]}``.

    A package is "changed" if its resolved version differs base→head OR it is newly added.
    Removed packages are excluded — a fix's blast radius is what the new/changed code ships.

    WHY the base/head split (the GAP-A2 correctness fix): the blast radius MUST be keyed on the
    **base** version — the version currently DEPLOYED, i.e. the thing this change disturbs. The
    head version is by definition NOT deployed yet, so seeding the graph with it matches ZERO
    images and reports "affects nothing" for every version bump — the most common fix there is.
    So:
      base  → the blast-radius key (what you're disturbing)   ← seed the graph with THIS
      head  → the target version (metadata; e.g. check it for its own CVEs, verify after deploy)
      names → "<eco>/<name>", for name-level widening ("who else is on this library") and for
              range-pinned manifests that resolve no exact version.
    A newly-added package has NO base version, so it contributes head+name but no base key — which
    is semantically right: adding a dependency disturbs nothing already running.
    """
    out: Dict[str, Any] = {"base": [], "head": [], "names": [], "notes": []}
    listing = _git(repo_path, ["diff", "--name-only", base, head])
    if listing is None:
        out["notes"] = [f"git diff failed in {repo_path!r} (base={base!r} head={head!r}) — "
                        f"is it a git checkout with both commits present?"]
        return out
    files = [f for f in listing.splitlines() if f.strip()]
    if not files:
        out["notes"] = [f"no files changed between {base} and {head}"]
        return out

    base_keys: set = set()
    head_keys: set = set()
    names: set = set()
    notes: List[str] = []
    matched = False
    for f in files:
        for pred, parser, eco in _FILE_PARSERS:
            if pred(f):
                matched = True
                before = parser(_git_show(repo_path, base, f))
                after = parser(_git_show(repo_path, head, f))
                changed = {n: v for n, v in after.items() if before.get(n) != v}
                for name, ver in changed.items():
                    head_keys.add(f"pkg:{eco}/{name}@{ver}")
                    names.add(f"{eco}/{name}")
                    prev = before.get(name)
                    if prev:                      # absent ⇒ newly added ⇒ no base key
                        base_keys.add(f"pkg:{eco}/{name}@{prev}")
                added = sum(1 for n in changed if not before.get(n))
                notes.append(f"{f}: {eco} — {len(changed)} changed/added "
                             f"({len(changed) - added} bumped, {added} newly added)")
                break
    if not matched:
        notes.append("no recognised dependency manifests changed "
                     "(requirements*.txt / go.mod / poetry.lock / package-lock.json)")
    out["base"], out["head"] = sorted(base_keys), sorted(head_keys)
    out["names"], out["notes"] = sorted(names), notes
    return out
