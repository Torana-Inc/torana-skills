"""torana prompts — agent prompt library management commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.rules import _load_input_file

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 30),
    ("agent_id", "AGENT", 36),
    ("description", "DESCRIPTION", 40),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(name="prompts")
def agent_prompts():
    """Manage agent prompt library.

    \b
    Examples:
      torana prompts list --agent-id <UUID>
      torana prompts get <UUID>
      torana prompts create --file prompt.yaml
      torana prompts delete <UUID> --yes
    """


@agent_prompts.command(name="list")
@click.option("--agent-id", default=None, help="Filter by agent UUID.")
@click.option("--search", default=None, help="Search by name.")
@click.option("--show-drift", is_flag=True, default=False, help="Include drift status vs source files.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def prompts_list(ctx, agent_id, search, show_drift, page, page_size):
    """List prompts."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if agent_id:
        params["agent_id"] = agent_id
    if search:
        params["search"] = search
    if show_drift:
        params["show_drift"] = "true"

    client = _client(ctx)
    try:
        data = client.get("prompts/", params=params)
        if isinstance(data, dict) and "items" in data:
            result = data
        elif isinstance(data, dict) and "prompts" in data:
            # Agent-builder returns {"prompts": [...], "total": N} — normalize to items envelope
            result = {
                "items": data["prompts"],
                "total": data.get("total", len(data["prompts"])),
                "page": page, "page_size": effective_page_size
            }
        else:
            result = {
                "items": data if isinstance(data, list) else [],
                "total": len(data) if isinstance(data, list) else 0,
                "page": page, "page_size": effective_page_size
            }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    cols = _LIST_COLS + [("has_drift", "DRIFT", 8), ("drift_summary", "DRIFT STATUS", 50)] if show_drift else _LIST_COLS
    output(result, fmt=fmt, raw=raw, fields=fields, columns=cols)


@agent_prompts.command(name="get")
@click.argument("prompt_id", metavar="PROMPT_ID")
@click.pass_context
def prompts_get(ctx, prompt_id):
    """Get a specific prompt."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"prompts/{prompt_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agent_prompts.command(name="create")
@click.option("--name", default=None)
@click.option("--content", default=None, help="Prompt content text.")
@click.option("--agent-id", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def prompts_create(ctx, name, content, agent_id, input_file):
    """Create a new prompt."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if content:
        body["content"] = content
    if agent_id:
        body["agent_id"] = agent_id

    if not body.get("name"):
        click.echo("ERROR: --name is required.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post("prompts/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created prompt: {data.get('id', 'unknown')}")


@agent_prompts.command(name="update")
@click.argument("prompt_id", metavar="PROMPT_ID")
@click.option("--name", default=None)
@click.option("--content", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def prompts_update(ctx, prompt_id, name, content, input_file):
    """Update a prompt."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if content:
        body["content"] = content

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"prompts/{prompt_id}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated prompt: {prompt_id}")


@agent_prompts.command(name="delete")
@click.argument("prompt_id", metavar="PROMPT_ID")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def prompts_delete(ctx, prompt_id, yes):
    """Delete a prompt."""
    if not yes:
        click.confirm(f"Delete prompt {prompt_id}?", abort=True)

    client = _client(ctx)
    try:
        client.delete(f"prompts/{prompt_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted prompt: {prompt_id}")


@agent_prompts.command(name="categories")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def prompts_categories(ctx, page, page_size, fetch_all):
    """Get Categories."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "prompts/categories"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@agent_prompts.command(name="popular")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--limit", "limit", type=int, default=10, help="Number of prompts to return")
@click.pass_context
def prompts_popular(ctx, limit, page, page_size, fetch_all):
    """Get Popular Prompts."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "prompts/popular"
    params = {}
    if limit is not None:
        params["limit"] = limit
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@agent_prompts.command(name="recent")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--limit", "limit", type=int, default=10, help="Number of prompts to return")
@click.pass_context
def prompts_recent(ctx, limit, page, page_size, fetch_all):
    """Get Recent Prompts."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "prompts/recent"
    params = {}
    if limit is not None:
        params["limit"] = limit
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@agent_prompts.command(name="by-name-by-name")
@click.argument("NAME", metavar="NAME")
@click.pass_context
def prompts_by_name_by_name(ctx, name):
    """Get Prompt By Name."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"prompts/by-name/{name}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agent_prompts.command(name="clone")
@click.argument("PROMPT_ID", metavar="PROMPT_ID")
@click.option("--new-name", "new_name", required=True, help="Name for the cloned prompt")
@click.option("--new-description", "new_description", default=None, help="Description for the cloned prompt")
@click.pass_context
def prompts_clone(ctx, prompt_id, new_name, new_description):
    """Clone Prompt."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"prompts/{prompt_id}/clone"
    body = {}
    body["new_name"] = new_name
    if new_description is not None:
        body["new_description"] = new_description

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agent_prompts.command(name="usage")
@click.argument("PROMPT_ID", metavar="PROMPT_ID")
@click.option("--increment-usage", "increment_usage", type=bool, default=True)
@click.option("--update-last-used", "update_last_used", type=bool, default=True)
@click.pass_context
def prompts_usage(ctx, prompt_id, increment_usage, update_last_used):
    """Update Prompt Usage."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"prompts/{prompt_id}/usage"
    body = {}
    if increment_usage is not None:
        body["increment_usage"] = increment_usage
    if update_last_used is not None:
        body["update_last_used"] = update_last_used

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agent_prompts.command(name="associate-agent-by-agent-id")
@click.argument("PROMPT_ID", metavar="PROMPT_ID")
@click.argument("AGENT_ID", metavar="AGENT_ID")
@click.option("--usage-type", "usage_type", default=None, help="How the prompt is used in the agent")
@click.pass_context
def prompts_associate_agent_by_agent_id(ctx, prompt_id, agent_id, usage_type):
    """Associate Prompt With Agent."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"prompts/{prompt_id}/associate-agent/{agent_id}"
    params = {}
    if usage_type is not None:
        params["usage_type"] = usage_type

    client = _client(ctx)
    try:
        data = client.post(path, json={}, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agent_prompts.command(name="validate")
@click.pass_context
def prompts_validate(ctx):
    """Validate Prompt."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "prompts/validate"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agent_prompts.command(name="reload-from-source")
@click.argument("PROMPT_ID", metavar="PROMPT_ID")
@click.pass_context
def prompts_reload_from_source(ctx, prompt_id):
    """Reload Prompt From Source."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"prompts/{prompt_id}/reload-from-source"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agent_prompts.command(name="agents")
@click.argument("PROMPT_ID", metavar="PROMPT_ID")
@click.pass_context
def prompts_agents(ctx, prompt_id):
    """Get Referring Agents."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"prompts/{prompt_id}/agents"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agent_prompts.command(name="drift")
@click.argument("PROMPT_ID", metavar="PROMPT_ID")
@click.pass_context
def prompts_drift(ctx, prompt_id):
    """Get Prompt Drift."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"prompts/{prompt_id}/drift"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)
