"""torana bootstrap — agent, prompt and RAG collection bootstrap commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.confirm import confirm as _confirm


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


# Bootstrap list endpoints return a non-standard envelope, e.g.
# {"agents": [...], "total_count": N} rather than {"items": [...], "total": N}.
# Normalize to the standard envelope so the text/table formatter renders a clean
# table instead of dumping the raw list as JSON via the key/value fallback.
def _normalize_envelope(data, items_key):
    if not isinstance(data, dict):
        return data
    items = data.get(items_key)
    if items is None:
        return data
    return {"items": items, "total": data.get("total_count", len(items))}


# Columns for text/table rendering of bootstrap agent/prompt list entries.
_AGENT_LIST_COLUMNS = [
    ("name", "NAME", 30),
    ("agent_type", "TYPE", 10),
    ("bundles", "BUNDLES", 16),
    ("is_loaded", "LOADED", 8),
    ("filename", "FILENAME", 30),
]
_PROMPT_LIST_COLUMNS = [
    ("name", "NAME", 30),
    ("bundles", "BUNDLES", 16),
    ("is_loaded", "LOADED", 8),
    ("filename", "FILENAME", 30),
]


def _join_bundles(data):
    """Render each item's `bundles` list as `a,b` for text output."""
    items = data.get("items", []) if isinstance(data, dict) else data
    for item in items or []:
        if isinstance(item, dict) and isinstance(item.get("bundles"), list):
            item["bundles"] = ",".join(item["bundles"])
    return data


# One filename per call. `--filenames` used to be a single string split on commas,
# and a REPEATED flag silently kept only the LAST value: `load --filenames a.json
# --filenames b.json` loaded b.json alone and reported success. Loading one file
# per call makes each result (created / failed + reason) unambiguous, so both
# repeats and comma lists are refused. `--filenames` stays as an alias.
def _single_filename(ctx, param, values):
    values = [v for v in (values or ()) if v is not None]
    if not values:
        raise click.MissingParameter(ctx=ctx, param=param)
    if len(values) > 1:
        raise click.BadParameter(
            f"takes exactly ONE filename, got {len(values)}: {', '.join(values)}. "
            "Run the command once per file.", ctx=ctx, param=param)
    value = values[0].strip()
    if "," in value:
        raise click.BadParameter(
            f"takes exactly ONE filename, got a comma list: {value}. "
            "Run the command once per file.", ctx=ctx, param=param)
    if not value:
        raise click.BadParameter("filename is empty.", ctx=ctx, param=param)
    return value


def _filename_option(what):
    return click.option(
        "--filename", "--filenames", "filename", multiple=True, callback=_single_filename,
        metavar="FILE", help=f"{what} bootstrap filename, e.g. my_agent.json. Exactly one per call.")


@click.group()
def bootstrap():
    """Bootstrap agents, prompts, and playground data.

    \b
    Examples:
      torana bootstrap agents list
      torana bootstrap agents load-all
      torana bootstrap agents delete-all --yes
      torana bootstrap prompts list
      torana bootstrap prompts load-all
      torana bootstrap collections list
      torana bootstrap playground usecases
      torana bootstrap status
    """


# ---------------------------------------------------------------------------
# torana bootstrap agents
# ---------------------------------------------------------------------------

@bootstrap.group(name="agents")
def bootstrap_agents():
    """Bootstrap agent management.

    \b
    Examples:
      torana bootstrap agents list
      torana bootstrap agents load --filename agent.json
      torana bootstrap agents load-all
      torana bootstrap agents validate --filename agent.json
      torana bootstrap agents delete --names my-agent
      torana bootstrap agents delete-all --yes
      torana bootstrap agents status
    """


@bootstrap_agents.command(name="list")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def bootstrap_agents_list(ctx, page, page_size, fetch_all):
    """List available bootstrap agents."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "bootstrap/agents/available"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = _normalize_envelope(client.get(path, params=p), "agents")
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
            data = _normalize_envelope(data, "agents")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt == "text":
        data = _join_bundles(data)
    output(data, fmt=fmt, fields=fields, raw=raw, columns=_AGENT_LIST_COLUMNS)


@bootstrap_agents.command(name="load")
@_filename_option("Agent")
@click.option("--resolve-dependencies", "resolve_dependencies", type=bool, default=True)
@click.option("--validate-first", "validate_first", type=bool, default=False)
@click.pass_context
def bootstrap_agents_load(ctx, filename, resolve_dependencies, validate_first):
    """Load ONE agent from its bootstrap file.

    \b
    Examples:
      torana bootstrap agents load --filename trace_explainer.json
      torana bootstrap agents load --filename trace_explainer.json --validate-first true
    One file per call: repeat the command for each agent.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = {"filenames": [filename]}
    if resolve_dependencies is not None:
        body["resolve_dependencies"] = resolve_dependencies
    if validate_first is not None:
        body["validate_first"] = validate_first

    client = _client(ctx)
    try:
        data = client.post("bootstrap/agents/load", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@bootstrap_agents.command(name="validate")
@_filename_option("Agent")
@click.option("--resolve-dependencies", "resolve_dependencies", type=bool, default=True)
@click.option("--validate-first", "validate_first", type=bool, default=False)
@click.pass_context
def bootstrap_agents_validate(ctx, filename, resolve_dependencies, validate_first):
    """Validate ONE agent file without loading it.

    \b
    Examples:
      torana bootstrap agents validate --filename trace_explainer.json
    One file per call: repeat the command for each agent.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = {"filenames": [filename]}
    if resolve_dependencies is not None:
        body["resolve_dependencies"] = resolve_dependencies
    if validate_first is not None:
        body["validate_first"] = validate_first

    client = _client(ctx)
    try:
        data = client.post("bootstrap/agents/validate", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@bootstrap_agents.command(name="load-all")
@click.pass_context
def bootstrap_agents_load_all(ctx):
    """Load all available agents, and reset existing ones to their files' lifecycle state.

    An existing agent is returned to the state its file declares (auto_publish /
    auto_activate → published and active; otherwise draft); each restore is listed
    under `updated` with `state_restored`. Exits 1 when any agent is in `failed`,
    including a lifecycle state that could not be restored.

    \b
    Examples:
      torana bootstrap agents load-all
      torana bootstrap agents load-all -o json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.post("bootstrap/agents/load-all", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)
    if isinstance(data, dict) and data.get("failed"):
        ctx.exit(1)


@bootstrap_agents.command(name="delete-all")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def bootstrap_agents_delete_all(ctx, yes):
    """Delete every bootstrap agent nothing uses (chats, audit, forks, parents).

    Removes only rows the bootstrap loader provably created that nothing
    references; every other row comes back under `kept` with the reason.
    """
    _confirm("Are you sure?", yes=yes)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.delete("bootstrap/agents/all")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@bootstrap_agents.command(name="delete")
@click.option("--names", "names", required=True, help="Comma-separated agent names to delete.")
@click.pass_context
def bootstrap_agents_delete(ctx, names):
    """Delete the named bootstrap agents, if nothing uses them.

    Removes only rows the bootstrap loader provably created that nothing
    references; every other row comes back under `kept` with the reason.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.post("bootstrap/agents/delete-selected", json={"names": [n.strip() for n in names.split(",")]})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@bootstrap_agents.command(name="status")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def bootstrap_agents_status(ctx, page, page_size, fetch_all):
    """Get bootstrap agent status."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "bootstrap/agents/status"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


# ---------------------------------------------------------------------------
# torana bootstrap prompts
# ---------------------------------------------------------------------------

@bootstrap.group(name="prompts")
def bootstrap_prompts():
    """Bootstrap prompt management.

    \b
    Examples:
      torana bootstrap prompts list
      torana bootstrap prompts load --filename prompt.json
      torana bootstrap prompts load-all
      torana bootstrap prompts delete --names my-prompt
      torana bootstrap prompts delete-all --yes
      torana bootstrap prompts status
    """


@bootstrap_prompts.command(name="list")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def bootstrap_prompts_list(ctx, page, page_size, fetch_all):
    """List available bootstrap prompts."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "bootstrap/prompts/available"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = _normalize_envelope(client.get(path, params=p), "prompts")
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
            data = _normalize_envelope(data, "prompts")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt == "text":
        data = _join_bundles(data)
    output(data, fmt=fmt, fields=fields, raw=raw, columns=_PROMPT_LIST_COLUMNS)


@bootstrap_prompts.command(name="load")
@_filename_option("Prompt")
@click.pass_context
def bootstrap_prompts_load(ctx, filename):
    """Load ONE prompt from its bootstrap file.

    \b
    Examples:
      torana bootstrap prompts load --filename agui_test_baseline.json
    One file per call: repeat the command for each prompt.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.post("bootstrap/prompts/load", json={"filenames": [filename]})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@bootstrap_prompts.command(name="load-all")
@click.pass_context
def bootstrap_prompts_load_all(ctx):
    """Load all available prompts."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.post("bootstrap/prompts/load-all", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@bootstrap_prompts.command(name="delete-all")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def bootstrap_prompts_delete_all(ctx, yes):
    """Delete every bootstrap prompt no agent uses.

    Removes only rows the bootstrap loader provably created that nothing
    references; every other row comes back under `kept` with the reason.
    """
    _confirm("Are you sure?", yes=yes)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.delete("bootstrap/prompts/all")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@bootstrap_prompts.command(name="delete")
@click.option("--names", "names", required=True, help="Comma-separated prompt names to delete.")
@click.pass_context
def bootstrap_prompts_delete(ctx, names):
    """Delete the named bootstrap prompts, if no agent uses them.

    Removes only rows the bootstrap loader provably created that nothing
    references; every other row comes back under `kept` with the reason.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.post("bootstrap/prompts/delete-selected", json={"names": [n.strip() for n in names.split(",")]})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@bootstrap_prompts.command(name="status")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def bootstrap_prompts_status(ctx, page, page_size, fetch_all):
    """Get bootstrap prompt status."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "bootstrap/prompts/status"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


# ---------------------------------------------------------------------------
# torana bootstrap playground
# ---------------------------------------------------------------------------

@bootstrap.group(name="playground")
def bootstrap_playground():
    """Bootstrap playground data.

    \b
    Examples:
      torana bootstrap playground usecases
      torana bootstrap playground usecases my-usecase
      torana bootstrap playground schemas
      torana bootstrap playground preview my-usecase
      torana bootstrap playground status
      torana bootstrap playground load-mock-data --yes
    """


@bootstrap_playground.command(name="usecases")
@click.argument("usecase_name", metavar="USECASE_NAME", required=False)
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def bootstrap_playground_usecases(ctx, usecase_name, page, page_size, fetch_all):
    """List playground usecases, or get details for a specific one."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    client = _client(ctx)
    try:
        if usecase_name:
            data = client.get(f"bootstrap/playground/usecases/{usecase_name}")
        else:
            path = "bootstrap/playground/usecases"
            effective_page_size = min(page_size or settings.page_size, 100)
            params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
            if fetch_all:
                all_items = []
                page_num = 1
                while True:
                    p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                    data = _normalize_envelope(client.get(path, params=p), "usecases")
                    items = data.get('items', data) if isinstance(data, dict) else data
                    all_items.extend(items)
                    total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                    if len(all_items) >= total:
                        break
                    page_num += 1
                data = {"items": all_items, "total": len(all_items)}
            else:
                data = _normalize_envelope(client.get(path, params=params), "usecases")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@bootstrap_playground.command(name="schemas")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def bootstrap_playground_schemas(ctx, page, page_size, fetch_all):
    """List playground schemas."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "bootstrap/playground/schemas"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = _normalize_envelope(client.get(path, params=p), "schemas")
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = _normalize_envelope(client.get(path, params=params), "schemas")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@bootstrap_playground.command(name="preview")
@click.argument("usecase_name", metavar="USECASE_NAME")
@click.pass_context
def bootstrap_playground_preview(ctx, usecase_name):
    """Preview mock data for a usecase."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"bootstrap/mock-data/preview/{usecase_name}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@bootstrap_playground.command(name="status")
@click.pass_context
def bootstrap_playground_status(ctx):
    """Get playground bootstrap status."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("bootstrap/playground/status")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@bootstrap_playground.command(name="load-mock-data")
@click.option("--yes", is_flag=True, default=False, help="Skip confirmation.")
@click.pass_context
def bootstrap_playground_load_mock_data(ctx, yes):
    """Load mock data for playground/demo purposes."""
    _confirm("Load mock data? This may overwrite existing data.", yes=yes)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.post("bootstrap/mock-data/load", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ---------------------------------------------------------------------------
# torana bootstrap status  (global)
# ---------------------------------------------------------------------------

@bootstrap.command(name="status")
@click.pass_context
def bootstrap_status(ctx):
    """Get global bootstrap status."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("bootstrap/status")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ---------------------------------------------------------------------------
# torana bootstrap collections  (pantheon-rag; SA of the bootstrap tenant only)
# ---------------------------------------------------------------------------

_COLLECTION_LIST_COLUMNS = [
    ("name", "NAME", 30),
    ("is_loaded", "LOADED", 8),
    ("total_documents", "DOCS", 6),
    ("status", "STATUS", 10),
    ("id", "ID", 38),
]


def _collections_call(ctx, method, path, *, columns=None, normalize=None, **kwargs):
    """Run one bootstrap-collections request and print the result."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = getattr(client, method)(f"bootstrap/collections/{path}", **kwargs)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if normalize:
        data = _normalize_envelope(data, normalize)
    if columns:
        output(data, fmt=fmt, fields=fields, columns=columns)
    else:
        output(data, fmt=fmt, fields=fields)


def _tenant_params(tenant_id):
    return {"tenant_id": tenant_id} if tenant_id else None


_TENANT_OPTION = click.option(
    "--tenant-id", "tenant_id", default=None,
    help="Target tenant (default: the bootstrap tenant).",
)


@bootstrap.group(name="collections")
def bootstrap_collections():
    """Bootstrap RAG knowledge-base collections (super admins of the bootstrap tenant only).

    \b
    Examples:
      torana bootstrap collections list
      torana bootstrap collections status
      torana bootstrap collections ingest --names vulnerability_management_kb
      torana bootstrap collections ingestion-info
      torana bootstrap collections delete --ids <collection-id>
      torana bootstrap collections delete-all --yes
    """


@bootstrap_collections.command(name="list")
@_TENANT_OPTION
@click.pass_context
def bootstrap_collections_list(ctx, tenant_id):
    """List configured and loaded bootstrap collections.

    \b
    Examples:
      torana bootstrap collections list
      torana bootstrap collections list --tenant-id <tenant-id>
    """
    _collections_call(ctx, "get", "available", params=_tenant_params(tenant_id),
                      columns=_COLLECTION_LIST_COLUMNS, normalize="collections")


@bootstrap_collections.command(name="status")
@_TENANT_OPTION
@click.pass_context
def bootstrap_collections_status(ctx, tenant_id):
    """Show collection counts (total, active, archived, with documents, empty).

    \b
    Examples:
      torana bootstrap collections status
    """
    _collections_call(ctx, "get", "status", params=_tenant_params(tenant_id))


@bootstrap_collections.command(name="ingestion-info")
@click.pass_context
def bootstrap_collections_ingestion_info(ctx):
    """Show the ingestion source and the configured bootstrap collections.

    \b
    Examples:
      torana bootstrap collections ingestion-info
    """
    _collections_call(ctx, "get", "ingestion-info")


@bootstrap_collections.command(name="ingest")
@click.option("--names", "names", default=None,
              help="Comma-separated collection names to load (default: all configured).")
@_TENANT_OPTION
@click.pass_context
def bootstrap_collections_ingest(ctx, names, tenant_id):
    """Create the bootstrap collections and ingest their documents (can take minutes).

    \b
    Examples:
      torana bootstrap collections ingest
      torana bootstrap collections ingest --names vulnerability_management_kb
    """
    body = {}
    if names:
        body["collection_ids"] = [f"script-{n.strip()}" for n in names.split(",") if n.strip()]
    if tenant_id:
        body["tenant_id"] = tenant_id
    _collections_call(ctx, "post", "ingest", json=body)


@bootstrap_collections.command(name="delete")
@click.option("--ids", "ids", required=True, help="Comma-separated collection ids to delete.")
@_TENANT_OPTION
@click.pass_context
def bootstrap_collections_delete(ctx, ids, tenant_id):
    """Delete the given collections, if each is an UNUSED bootstrap collection.

    Deletes only collections proven to be bootstrap whose every document came
    from the bootstrap source directory; every other one comes back under
    `kept` with the reason.

    \b
    Examples:
      torana bootstrap collections delete --ids <collection-id>
    """
    body = {"collection_ids": [i.strip() for i in ids.split(",") if i.strip()]}
    if tenant_id:
        body["tenant_id"] = tenant_id
    _collections_call(ctx, "post", "delete-selected", json=body)


@bootstrap_collections.command(name="delete-all")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@_TENANT_OPTION
@click.pass_context
def bootstrap_collections_delete_all(ctx, yes, tenant_id):
    """Delete every UNUSED bootstrap collection of the target tenant.

    Deletes only collections proven to be bootstrap whose every document came
    from the bootstrap source directory; every other one (a tenant upload, an
    empty or a non-bootstrap collection) comes back under `kept` with the reason.

    \b
    Examples:
      torana bootstrap collections delete-all --yes
    """
    _confirm("Are you sure?", yes=yes)
    _collections_call(ctx, "delete", "all", params=_tenant_params(tenant_id))
