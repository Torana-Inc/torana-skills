"""torana bootstrap — agent and prompt bootstrap commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.confirm import confirm as _confirm


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


# Bootstrap list endpoints return a non-standard envelope, e.g.
# {"agents": [...], "total_count": N} rather than {"items": [...], "total": N}.
# Normalize to the standard envelope so the text/table formatter renders a clean
# table instead of dumping the raw list as JSON via the key/value fallback.
def _normalize_envelope(data, items_key):
    if not isinstance(data, dict):
        return data
    items = data.get(items_key)
    if items is None:
        return data
    return {"items": items, "total": data.get("total_count", len(items))}


# Columns for text/table rendering of bootstrap agent/prompt list entries.
_AGENT_LIST_COLUMNS = [
    ("name", "NAME", 30),
    ("agent_type", "TYPE", 10),
    ("is_loaded", "LOADED", 8),
    ("filename", "FILENAME", 30),
]
_PROMPT_LIST_COLUMNS = [
    ("name", "NAME", 30),
    ("is_loaded", "LOADED", 8),
    ("filename", "FILENAME", 30),
]


@click.group()
def bootstrap():
    """Bootstrap agents, prompts, and playground data.

    \b
    Examples:
      torana bootstrap agents list
      torana bootstrap agents load-all
      torana bootstrap agents delete-all --yes
      torana bootstrap prompts list
      torana bootstrap prompts load-all
      torana bootstrap playground usecases
      torana bootstrap status
    """


# ---------------------------------------------------------------------------
# torana bootstrap agents
# ---------------------------------------------------------------------------

@bootstrap.group(name="agents")
def bootstrap_agents():
    """Bootstrap agent management.

    \b
    Examples:
      torana bootstrap agents list
      torana bootstrap agents load --filenames agent.yaml
      torana bootstrap agents load-all
      torana bootstrap agents validate --filenames agent.yaml
      torana bootstrap agents delete --names my-agent
      torana bootstrap agents delete-all --yes
      torana bootstrap agents status
    """


@bootstrap_agents.command(name="list")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def bootstrap_agents_list(ctx, page, page_size, fetch_all):
    """List available bootstrap agents."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "bootstrap/agents/available"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = _normalize_envelope(client.get(path, params=p), "agents")
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
            data = _normalize_envelope(data, "agents")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw, columns=_AGENT_LIST_COLUMNS)


@bootstrap_agents.command(name="load")
@click.option("--filenames", "filenames", required=True, help="Agent filename(s) to load.")
@click.option("--resolve-dependencies", "resolve_dependencies", type=bool, default=True)
@click.option("--validate-first", "validate_first", type=bool, default=False)
@click.pass_context
def bootstrap_agents_load(ctx, filenames, resolve_dependencies, validate_first):
    """Load agents from file(s)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = {"filenames": [f.strip() for f in filenames.split(",")]}
    if resolve_dependencies is not None:
        body["resolve_dependencies"] = resolve_dependencies
    if validate_first is not None:
        body["validate_first"] = validate_first

    client = _client(ctx)
    try:
        data = client.post("bootstrap/agents/load", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@bootstrap_agents.command(name="validate")
@click.option("--filenames", "filenames", required=True, help="Agent filename(s) to validate.")
@click.option("--resolve-dependencies", "resolve_dependencies", type=bool, default=True)
@click.option("--validate-first", "validate_first", type=bool, default=False)
@click.pass_context
def bootstrap_agents_validate(ctx, filenames, resolve_dependencies, validate_first):
    """Validate agents from file(s) without loading."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = {"filenames": [f.strip() for f in filenames.split(",")]}
    if resolve_dependencies is not None:
        body["resolve_dependencies"] = resolve_dependencies
    if validate_first is not None:
        body["validate_first"] = validate_first

    client = _client(ctx)
    try:
        data = client.post("bootstrap/agents/validate", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@bootstrap_agents.command(name="load-all")
@click.pass_context
def bootstrap_agents_load_all(ctx):
    """Load all available agents."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.post("bootstrap/agents/load-all", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@bootstrap_agents.command(name="delete-all")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def bootstrap_agents_delete_all(ctx, yes):
    """Delete all bootstrap agents."""
    _confirm("Are you sure?", yes=yes)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.delete("bootstrap/agents/all")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@bootstrap_agents.command(name="delete")
@click.option("--names", "names", required=True, help="Comma-separated agent names to delete.")
@click.pass_context
def bootstrap_agents_delete(ctx, names):
    """Delete selected agents by name."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.post("bootstrap/agents/delete-selected", json={"names": [n.strip() for n in names.split(",")]})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@bootstrap_agents.command(name="status")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def bootstrap_agents_status(ctx, page, page_size, fetch_all):
    """Get bootstrap agent status."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "bootstrap/agents/status"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


# ---------------------------------------------------------------------------
# torana bootstrap prompts
# ---------------------------------------------------------------------------

@bootstrap.group(name="prompts")
def bootstrap_prompts():
    """Bootstrap prompt management.

    \b
    Examples:
      torana bootstrap prompts list
      torana bootstrap prompts load --filenames prompt.yaml
      torana bootstrap prompts load-all
      torana bootstrap prompts delete --names my-prompt
      torana bootstrap prompts delete-all --yes
      torana bootstrap prompts status
    """


@bootstrap_prompts.command(name="list")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def bootstrap_prompts_list(ctx, page, page_size, fetch_all):
    """List available bootstrap prompts."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "bootstrap/prompts/available"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = _normalize_envelope(client.get(path, params=p), "prompts")
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
            data = _normalize_envelope(data, "prompts")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw, columns=_PROMPT_LIST_COLUMNS)


@bootstrap_prompts.command(name="load")
@click.option("--filenames", "filenames", required=True, help="Prompt filename(s) to load.")
@click.pass_context
def bootstrap_prompts_load(ctx, filenames):
    """Load prompts from file(s)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.post("bootstrap/prompts/load", json={"filenames": [f.strip() for f in filenames.split(",")]})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@bootstrap_prompts.command(name="load-all")
@click.pass_context
def bootstrap_prompts_load_all(ctx):
    """Load all available prompts."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.post("bootstrap/prompts/load-all", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@bootstrap_prompts.command(name="delete-all")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def bootstrap_prompts_delete_all(ctx, yes):
    """Delete all bootstrap prompts."""
    _confirm("Are you sure?", yes=yes)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.delete("bootstrap/prompts/all")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@bootstrap_prompts.command(name="delete")
@click.option("--names", "names", required=True, help="Comma-separated prompt names to delete.")
@click.pass_context
def bootstrap_prompts_delete(ctx, names):
    """Delete selected prompts by name."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.post("bootstrap/prompts/delete-selected", json={"names": [n.strip() for n in names.split(",")]})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@bootstrap_prompts.command(name="status")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def bootstrap_prompts_status(ctx, page, page_size, fetch_all):
    """Get bootstrap prompt status."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "bootstrap/prompts/status"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


# ---------------------------------------------------------------------------
# torana bootstrap playground
# ---------------------------------------------------------------------------

@bootstrap.group(name="playground")
def bootstrap_playground():
    """Bootstrap playground data.

    \b
    Examples:
      torana bootstrap playground usecases
      torana bootstrap playground usecases my-usecase
      torana bootstrap playground schemas
      torana bootstrap playground preview my-usecase
      torana bootstrap playground status
      torana bootstrap playground load-mock-data --yes
    """


@bootstrap_playground.command(name="usecases")
@click.argument("usecase_name", metavar="USECASE_NAME", required=False)
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def bootstrap_playground_usecases(ctx, usecase_name, page, page_size, fetch_all):
    """List playground usecases, or get details for a specific one."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    client = _client(ctx)
    try:
        if usecase_name:
            data = client.get(f"bootstrap/playground/usecases/{usecase_name}")
        else:
            path = "bootstrap/playground/usecases"
            effective_page_size = min(page_size or settings.page_size, 100)
            params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
            if fetch_all:
                all_items = []
                page_num = 1
                while True:
                    p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                    data = _normalize_envelope(client.get(path, params=p), "usecases")
                    items = data.get('items', data) if isinstance(data, dict) else data
                    all_items.extend(items)
                    total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                    if len(all_items) >= total:
                        break
                    page_num += 1
                data = {"items": all_items, "total": len(all_items)}
            else:
                data = _normalize_envelope(client.get(path, params=params), "usecases")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@bootstrap_playground.command(name="schemas")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def bootstrap_playground_schemas(ctx, page, page_size, fetch_all):
    """List playground schemas."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "bootstrap/playground/schemas"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = _normalize_envelope(client.get(path, params=p), "schemas")
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = _normalize_envelope(client.get(path, params=params), "schemas")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@bootstrap_playground.command(name="preview")
@click.argument("usecase_name", metavar="USECASE_NAME")
@click.pass_context
def bootstrap_playground_preview(ctx, usecase_name):
    """Preview mock data for a usecase."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"bootstrap/mock-data/preview/{usecase_name}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@bootstrap_playground.command(name="status")
@click.pass_context
def bootstrap_playground_status(ctx):
    """Get playground bootstrap status."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("bootstrap/playground/status")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@bootstrap_playground.command(name="load-mock-data")
@click.option("--yes", is_flag=True, default=False, help="Skip confirmation.")
@click.pass_context
def bootstrap_playground_load_mock_data(ctx, yes):
    """Load mock data for playground/demo purposes."""
    _confirm("Load mock data? This may overwrite existing data.", yes=yes)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.post("bootstrap/mock-data/load", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ---------------------------------------------------------------------------
# torana bootstrap status  (global)
# ---------------------------------------------------------------------------

@bootstrap.command(name="status")
@click.pass_context
def bootstrap_status(ctx):
    """Get global bootstrap status."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("bootstrap/status")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)
