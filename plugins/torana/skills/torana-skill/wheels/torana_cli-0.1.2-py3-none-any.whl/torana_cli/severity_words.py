"""A severity in words. The platform sends `finding_severity_label` and `rule_severity_label`; this is the same rule, for a server that does not yet."""
from __future__ import annotations

_WORDS = {"critical": "Critical", "high": "High", "medium": "Medium", "low": "Low", "info": "Info"}


def severity_word(value):
    """Title case ("critical", "HIGH" -> "Critical", "High"); None when nothing is stated."""
    text = str(value or "").strip()
    return (_WORDS.get(text.lower()) or text[:1].upper() + text[1:]) if text and text != "\u2014" else None


NOT_DECLARED = "Not declared"


def rule_severity_label(rule):
    """A rule's declared severity in words, "Not declared" when it declares none. The platform sends `severity_label`;
    this is the same rule, for a server that does not yet."""
    if not isinstance(rule, dict):
        return NOT_DECLARED
    return rule.get("severity_label") or severity_word(rule.get("severity")) or NOT_DECLARED
