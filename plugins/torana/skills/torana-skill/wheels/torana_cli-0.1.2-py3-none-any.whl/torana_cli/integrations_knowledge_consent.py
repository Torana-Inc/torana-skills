"""torana integrations knowledge-consent — the tenant's consent for Atlas to read a source.

Routes: pantheon-integration `torana_mesh/api/routes/knowledge_consent.py` under `/integrations/…`.
Consent is the TENANT's own decision: get|sources|history|grant|revoke need atlas:consent held by name and a
caller who belongs to the tenant, so a super-admin gets 403 `tenant_owned` (exit 4). `migrate-phase0` is the
one SA job (dry-run unless --apply). A write is append-only: grant and revoke each add a row; history lists them.

Spec: pantheon-knowledge/docs/design/SELECTION_ON_SYNC.md § 3.18.8; PHASE_1_PLAN.md S03 / S14·C1.
"""

import click

from torana_cli.atlas import _call, _client, _fmt
from torana_cli.output import output

SCOPES = ["read_contents", "model_processing"]
MAX_HISTORY = 100


def _bare_help(ctx):
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


scope_option = click.option("--scope", type=click.Choice(SCOPES), required=True,
                            help="read_contents: fetch content beyond the synced metadata (a code host: clone). "
                                 "model_processing: an AI model may read this source to write knowledge.")
text_version_option = click.option(
    "--text-version", "text_version", required=True, metavar="VERSION",
    help="The consent-text version the person saw and accepted (recorded with the row).")


def _consent_path(source_id: str, pushed: bool) -> str:
    return (f"integrations/pushed-data/{source_id}/knowledge-consent" if pushed
            else f"integrations/{source_id}/knowledge-consent")


def _history(ctx, path, scope, limit, offset):
    fmt, raw, fields = _fmt(ctx)
    params = {k: v for k, v in {"scope": scope, "limit": limit, "offset": offset}.items() if v is not None}
    output(_call(_client(ctx).get, f"{path}/history", params=params), fmt=fmt, raw=raw, fields=fields,
           columns=[("scope", "SCOPE", 17), ("granted", "GRANTED", 7), ("actor", "BY", 30),
                    ("consent_text_version", "TEXT", 5), ("created_at", "AT", 26)])


def _write(ctx, path, scope, granted, text_version):
    fmt, _, _ = _fmt(ctx)
    body = {"scope": scope, "granted": granted, "consent_text_version": text_version}
    output(_call(_client(ctx).put, path, json=body), fmt=fmt)


def _history_options(f):
    f = click.option("--offset", type=click.IntRange(min=0), default=0, show_default=True)(f)
    f = click.option("--limit", type=click.IntRange(1, MAX_HISTORY), default=MAX_HISTORY, show_default=True)(f)
    return click.option("--scope", type=click.Choice(SCOPES), default=None, help="Only this scope.")(f)


@click.group(name="knowledge-consent", invoke_without_command=True)
@click.pass_context
def knowledge_consent(ctx):
    """Knowledge consent: may Atlas read this source, and may a model process it? Granted per source and scope.

    The tenant decides: grant, revoke, get, sources and history need atlas:consent and a caller of the tenant
    (a super-admin is refused, exit 4 `tenant_owned`). Nothing from a source is written to a knowledge node
    without its consent. A pushed-data type (SARIF, SBOM …) is a source too: `knowledge-consent pushed …`.

    \b
    Examples:
      torana integrations knowledge-consent sources
      torana integrations knowledge-consent get <INTEGRATION_ID>
      torana integrations knowledge-consent grant <INTEGRATION_ID> --scope model_processing --text-version 1
      torana integrations knowledge-consent revoke <INTEGRATION_ID> --scope model_processing --text-version 1
      torana integrations knowledge-consent history <INTEGRATION_ID> --scope read_contents
      torana integrations knowledge-consent pushed get sarif
    """
    _bare_help(ctx)


@knowledge_consent.command(name="sources")
@click.pass_context
def knowledge_consent_sources(ctx):
    """Every source's consent: each integration and each pushed-data type, with the scopes it offers.

    \b
    Examples:
      torana integrations knowledge-consent sources
      torana integrations knowledge-consent sources --json
    """
    fmt, raw, fields = _fmt(ctx)
    output(_call(_client(ctx).get, "integrations/knowledge-consent/sources"), fmt=fmt, raw=raw, fields=fields)


@knowledge_consent.command(name="get")
@click.argument("integration_id", metavar="INTEGRATION_ID")
@click.pass_context
def knowledge_consent_get(ctx, integration_id):
    """One integration's consent: the scopes it offers and whether each is granted.

    \b
    Examples:
      torana integrations knowledge-consent get <INTEGRATION_ID>
    """
    fmt, raw, fields = _fmt(ctx)
    output(_call(_client(ctx).get, _consent_path(integration_id, False)), fmt=fmt, raw=raw, fields=fields)


@knowledge_consent.command(name="grant")
@click.argument("integration_id", metavar="INTEGRATION_ID")
@scope_option
@text_version_option
@click.pass_context
def knowledge_consent_grant(ctx, integration_id, scope, text_version):
    """Grant one scope on an integration (tenant only; appends a row and a timeline event).

    \b
    Examples:
      torana integrations knowledge-consent grant <INTEGRATION_ID> --scope model_processing --text-version 1
    """
    _write(ctx, _consent_path(integration_id, False), scope, True, text_version)


@knowledge_consent.command(name="revoke")
@click.argument("integration_id", metavar="INTEGRATION_ID")
@scope_option
@text_version_option
@click.pass_context
def knowledge_consent_revoke(ctx, integration_id, scope, text_version):
    """Revoke one scope on an integration (tenant only). Knowledge built from the source is hidden on the next read.

    \b
    Examples:
      torana integrations knowledge-consent revoke <INTEGRATION_ID> --scope model_processing --text-version 1
    """
    _write(ctx, _consent_path(integration_id, False), scope, False, text_version)


@knowledge_consent.command(name="history")
@click.argument("integration_id", metavar="INTEGRATION_ID")
@_history_options
@click.pass_context
def knowledge_consent_history(ctx, integration_id, scope, limit, offset):
    """Who changed an integration's consent, and when (newest first).

    \b
    Examples:
      torana integrations knowledge-consent history <INTEGRATION_ID>
      torana integrations knowledge-consent history <INTEGRATION_ID> --scope read_contents --json
    """
    _history(ctx, _consent_path(integration_id, False), scope, limit, offset)


@knowledge_consent.group(name="pushed", invoke_without_command=True)
@click.pass_context
def knowledge_consent_pushed(ctx):
    """Consent for a pushed-data TYPE (data the tenant sends in, not an integration). Off by default.

    \b
    Examples:
      torana integrations knowledge-consent pushed get sarif
      torana integrations knowledge-consent pushed grant sarif --scope model_processing --text-version 1
    """
    _bare_help(ctx)


@knowledge_consent_pushed.command(name="get")
@click.argument("type_id", metavar="TYPE")
@click.pass_context
def knowledge_consent_pushed_get(ctx, type_id):
    """One pushed-data type's consent, and what granting it unlocks (`knowledge-consent sources` lists the types).

    \b
    Examples:
      torana integrations knowledge-consent pushed get sarif
    """
    fmt, raw, fields = _fmt(ctx)
    output(_call(_client(ctx).get, _consent_path(type_id, True)), fmt=fmt, raw=raw, fields=fields)


@knowledge_consent_pushed.command(name="grant")
@click.argument("type_id", metavar="TYPE")
@scope_option
@text_version_option
@click.pass_context
def knowledge_consent_pushed_grant(ctx, type_id, scope, text_version):
    """Grant one scope on a pushed-data type (tenant only).

    \b
    Examples:
      torana integrations knowledge-consent pushed grant sarif --scope model_processing --text-version 1
    """
    _write(ctx, _consent_path(type_id, True), scope, True, text_version)


@knowledge_consent_pushed.command(name="revoke")
@click.argument("type_id", metavar="TYPE")
@scope_option
@text_version_option
@click.pass_context
def knowledge_consent_pushed_revoke(ctx, type_id, scope, text_version):
    """Revoke one scope on a pushed-data type (tenant only).

    \b
    Examples:
      torana integrations knowledge-consent pushed revoke sarif --scope model_processing --text-version 1
    """
    _write(ctx, _consent_path(type_id, True), scope, False, text_version)


@knowledge_consent_pushed.command(name="history")
@click.argument("type_id", metavar="TYPE")
@_history_options
@click.pass_context
def knowledge_consent_pushed_history(ctx, type_id, scope, limit, offset):
    """Who changed a pushed-data type's consent, and when (newest first).

    \b
    Examples:
      torana integrations knowledge-consent pushed history sarif
    """
    _history(ctx, _consent_path(type_id, True), scope, limit, offset)


@knowledge_consent.command(name="migrate-phase0")
@click.option("--tenant", "tenant_id", required=True, help="The tenant whose code-host integrations to migrate.")
@click.option("--push-type", "push_types", multiple=True, metavar="TYPE",
              help="Also grant model_processing for this pushed-data type (repeatable; none by default).")
@click.option("--apply", "apply_", is_flag=True, default=False, help="Write the rows. Without it: a dry run.")
@click.pass_context
def knowledge_consent_migrate_phase0(ctx, tenant_id, push_types, apply_):
    """SA only. Write Phase 0's consent for a tenant's code host (read_contents + model_processing). Dry run by default.

    Actor `migration:phase0-internal-tenant`, text version 0. Idempotent: a scope already granted is skipped.
    Needs the super_admin role (TORANA_PROFILE=SA). Read the plan it prints, then rerun with --apply.

    \b
    Examples:
      TORANA_PROFILE=SA torana integrations knowledge-consent migrate-phase0 --tenant <TENANT_ID>
      TORANA_PROFILE=SA torana integrations knowledge-consent migrate-phase0 --tenant <TENANT_ID> --push-type sarif --apply
    """
    fmt, _, _ = _fmt(ctx)
    body = {"tenant_id": tenant_id, "push_types": list(push_types), "apply": apply_}
    output(_call(_client(ctx).post, "integrations/knowledge-consent/phase0-migration", json=body), fmt=fmt)
