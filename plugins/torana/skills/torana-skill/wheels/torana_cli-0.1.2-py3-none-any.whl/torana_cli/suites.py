"""torana suites — detection suite commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW, CollectionGroup
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 35),
    ("state", "STATE", 12),
    ("workspace_id", "WORKSPACE_ID", 36),
    ("rule_count", "RULES", 6),
    ("created_by", "CREATED_BY", 36),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(cls=CollectionGroup, singular="suite")
def suites():
    """Manage detection suites (collection operations).

    \b
    Examples:
      torana suites list
      torana suites create --name "Network Monitoring" --workspace-id <UUID>

    \b
    Instance operations (get, activate, execute, etc.) use the singular form:
      torana suite <UUID> get
      torana suite <UUID> activate
      torana suite <UUID> execute
      torana suite <UUID> delete --yes
    """


@suites.command(name="list")
@click.option("--workspace-id", default=None, help="Filter by workspace UUID.")
@click.option("--search", default=None, help="Search by name.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def suites_list(ctx, workspace_id, search, page, page_size):
    """List detection suites."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if workspace_id:
        params["workspace_id"] = workspace_id
    if search:
        params["search"] = search

    client = _client(ctx)
    try:
        data = client.get("suites/", params=params)
        result = data if isinstance(data, dict) and "items" in data else {
            "items": data if isinstance(data, list) else [],
            "total": len(data) if isinstance(data, list) else 0,
            "page": page, "page_size": effective_page_size
        }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@suites.command(name="create")
@click.option("--name", default=None)
@click.option("--workspace-id", default=None, help="Workspace UUID.")
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def suites_create(ctx, name, workspace_id, input_file):
    """Create a new detection suite."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if workspace_id:
        body["workspace_id"] = workspace_id

    if not body.get("name"):
        click.echo("ERROR: --name is required.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post("suites/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created suite: {data.get('id', 'unknown')}")


@suites.command(name="recent")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--limit", "limit", type=int, default=50)
@click.pass_context
def suites_recent(ctx, limit, page, page_size, fetch_all):
    """Get recent suite executions."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "suites/executions/recent"
    params = {}
    if limit is not None:
        params["limit"] = limit
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@suites.command(name="active")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def suites_active(ctx, page, page_size, fetch_all):
    """Get Active Suites."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "suites/active"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


# ---------------------------------------------------------------------------
# suite-execution-logs commands
# ---------------------------------------------------------------------------

@click.group(name="suite-execution-logs")
def suite_execution_logs():
    """Suite execution logs — per-rule status for one suite run.

    \b
    When a suite reports a partial failure, this is where you find WHICH member
    rule failed. The suite-level status only tells you that something did.

    \b
    Examples:
      torana suite-execution-logs list --suite-id <SUITE_ID>
      torana suite-execution-logs get <EXECUTION_ID>
      torana suite-execution-logs get <EXECUTION_ID> --json | jq '.rules[] | select(.status != "success")'
    """


@suite_execution_logs.command(name="list")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--suite-id", "suite_id", default=None)
@click.option("--failed-only", "failed_only", type=bool, default=False)
@click.pass_context
def suite_execution_logs_list(ctx, suite_id, failed_only, page, page_size, fetch_all):
    """List suite execution logs."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "suite-execution-logs/"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if suite_id is not None:
        params["suite_id"] = suite_id
    if failed_only is not None:
        params["failed_only"] = failed_only

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@suite_execution_logs.command(name="get")
@click.argument("LOG_ID", metavar="LOG_ID")
@click.pass_context
def suite_execution_logs_get(ctx, log_id):
    """Get a suite execution log."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"suite-execution-logs/{log_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@suite_execution_logs.command(name="delete")
@click.argument("LOG_ID", metavar="LOG_ID")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def suite_execution_logs_delete(ctx, log_id, yes):
    """Delete a suite execution log."""
    _confirm(f"Delete suite execution log {log_id}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"suite-execution-logs/{log_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted suite execution log: {log_id}")


# ---------------------------------------------------------------------------
# active-dashboards commands
# ---------------------------------------------------------------------------

@click.group(name="active-dashboards")
def active_dashboards():
    """Manage active dashboards (detection monitoring).

    \b
    ⚠️ list / create / delete only — there is no `get`. To read one, list and
    filter.

    \b
    Examples:
      torana active-dashboards list
      torana active-dashboards list --json | jq '.items[] | {id, name}'
      torana active-dashboards create --help
      torana active-dashboards delete <DASHBOARD_ID> --yes
    """


@active_dashboards.command(name="list")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def active_dashboards_list(ctx, page, page_size, fetch_all):
    """List active dashboards."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "active-dashboards/"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@active_dashboards.command(name="create")
@click.option("--input", "input_file", default=None, help="JSON/YAML file with body fields.")
@click.option("--workspace-id", "workspace_id", default=None)
@click.option("--dashboard-id", "dashboard_id", default=None)
@click.pass_context
def active_dashboards_create(ctx, input_file, workspace_id, dashboard_id):
    """Create an active dashboard."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = _load_input_file(input_file) if input_file else {}
    if workspace_id is not None:
        body["workspace_id"] = workspace_id
    if dashboard_id is not None:
        body["dashboard_id"] = dashboard_id

    client = _client(ctx)
    try:
        data = client.post("active-dashboards/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@active_dashboards.command(name="delete")
@click.argument("DASHBOARD_ID", metavar="DASHBOARD_ID")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def active_dashboards_delete(ctx, dashboard_id, yes):
    """Delete an active dashboard."""
    _confirm(f"Delete active dashboard {dashboard_id}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"active-dashboards/{dashboard_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted active dashboard: {dashboard_id}")
