"""torana derived-state — is what I'm looking at current?

Subcommands
-----------
  status                           Freshness of the three derived layers.
  freshness                        Per transformer: built after its inputs changed?
  refresh                          Force a refresh (operator escape hatch).

Torana has three DERIVED layers that must be recomputed, IN ORDER, after data
lands: entity-graph reconcile -> property resolution -> transformer
materialization. They now refresh themselves when an ETL run or a deployment
write marks the tenant dirty. These commands answer the question no surface
could answer before — *is this current?* — and give operators a way to force a
refresh without waiting for the debounce window.

Spec: pantheon-integration/docs/DERIVED_STATE_CONVERGENCE.md § 3.4.4
Grouped under a single semantic parent per the CLI grouping convention.
"""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import (
    APIError,
    ToranaClient,
    handle_api_error,
    handle_auth_error,
)
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output

_BASE = "derived-state"


def _ctx(ctx):
    o = ctx.obj or {}
    return (o.get(CTX_FORMAT, "text"), o.get(CTX_RAW, False), o.get(CTX_FIELDS))


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    return ToranaClient(base_url=get_settings(profile).base_url)


def _tenant_params(tenant_id):
    return {"tenant_id": tenant_id} if tenant_id else None


@click.group(name="derived-state")
def derived_state():
    """Freshness of derived data (graph, governance properties, transformers).

    \b
    Derived data is REBUILT from source, not written directly. When a widget shows
    a stale number, ask here BEFORE re-running the pipeline that produced it — the
    answer is usually "the refresh has not run yet", not "the query is wrong".

    \b
    Examples:
      torana derived-state status                  is it current, and when did it last refresh?
      torana derived-state status --json
      torana derived-state freshness               was each transformer built after its data changed?
      torana derived-state refresh                 operator escape hatch — force it
    """


@derived_state.command(name="status")
@click.option("--tenant-id", default=None,
              help="SUPER ADMIN ONLY — read another tenant's derived state.")
@click.pass_context
def derived_state_status(ctx, tenant_id):
    """Show whether derived data is current, and when it last refreshed.

    \b
    Reads three layers independently:
      graph        — last successful entity-graph reconcile
      properties   — last governance resolution (entity_properties_resolved)
      transformers — last successful materialization

    `transformers` can read `unknown` when the transformers service is
    unreachable; the other two layers still report.
    """
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.get(f"{_BASE}/status", params=_tenant_params(tenant_id))
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    if raw or fmt != "text":
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    # Text mode: a flat, human-readable freshness summary rather than the raw
    # nested payload — the point of this command is a one-glance answer.
    state = data.get("state") or "idle"
    dirty = data.get("is_dirty")
    click.echo(f"Tenant        {data.get('tenant_id')}")
    click.echo(f"State         {'updating' if state == 'draining' else 'idle'}"
               + ("  (refresh queued)" if dirty and state != "draining" else ""))
    click.echo(f"Last refresh  {data.get('last_drained_at') or 'never'}")
    layers = data.get("layers") or {}
    click.echo("")
    click.echo("LAYER         LAST UPDATED                       DETAIL")
    g = layers.get("graph") or {}
    p = layers.get("properties") or {}
    t = layers.get("transformers") or {}
    click.echo(f"graph         {str(g.get('last_reconciled_at') or 'never'):34} -")
    click.echo(f"properties    {str(p.get('last_resolved_at') or 'never'):34} "
               f"{p.get('rows')} row(s)")
    click.echo(f"transformers  {str(t.get('last_materialized_at') or 'never'):34} "
               f"{t.get('status')}")

    for ns in (data.get("namespaces") or []):
        _echo_drain_results(ns)
        if ns.get("last_drain_status") in ("failed", "partial"):
            click.echo("")
            click.echo(f"⚠ last refresh was {ns['last_drain_status']} "
                       f"(namespace {ns.get('namespace_id') or 'default'}) — "
                       f"run `torana derived-state status --format json` for per-step detail.")


# DT_BATCHED_DBT_SPEC § 3.12.4 (G12): the per-relation results the drain stores. Glyph +
# word, never colour alone.
_DRAIN_GLYPH = {"success": "✓", "already_current": "✓", "failed": "✗",
                "dt_unavailable_gave_up": "✗", "unverified": "⚠", "sweep_blocked": "⚠"}


def _drain_glyph(status) -> str:
    s = str(status or "?")
    if s.startswith("deferred"):
        return "–"
    return _DRAIN_GLYPH.get(s, "⚠")


def _echo_drain_results(ns) -> None:
    """One table per namespace: RELATION · RESULT, grouped by result, problems first."""
    t = ((ns.get("last_drain_detail") or {}).get("transformers") or {})
    results = t.get("results") or {}
    if not results:
        return
    click.echo("")
    click.echo(f"Last drain — transformers (namespace {ns.get('namespace_id') or 'default'}, "
               f"{t.get('status')}, {len(results)} relation(s))")
    # DT_BATCHED_DBT_SPEC § 3.4.2: ONE execute-batch call, or the per-relation loop when
    # data-transformers has no such route — a permanent `serial_fallback` is a misconfig.
    path = t.get("build_path")
    if path:
        warn = "⚠ " if path == "serial_fallback" else ""
        click.echo(f"  build path: {warn}{path}"
                   + (f" · build {str(t['build_id'])[:8]}" if t.get("build_id") else ""))
    by = {}
    for model, st in results.items():
        st = st.get("status") if isinstance(st, dict) else st
        by.setdefault(str(st), []).append(model)
    order = sorted(by, key=lambda s: (_drain_glyph(s) == "✓", s))
    click.echo(f"  {'RESULT':30} {'COUNT':>5}  RELATIONS")
    for st in order:
        models = sorted(by[st])
        shown = ", ".join(models[:6]) + (f" … +{len(models) - 6}" if len(models) > 6 else "")
        click.echo(f"  {_drain_glyph(st) + ' ' + st:30} {len(models):>5}  {shown}")


#: Glyph + word per freshness verdict, worst first — never colour alone.
_FRESH_GLYPH = {"emptied": "✗",
                "behind": "✗", "clock_overdue": "✗", "failed": "✗", "never_built": "–",
                "untracked": "?", "unknown": "?", "dormant": "–", "current": "✓", "live": "✓",
                "rebuild_queued": "⟳", "rebuilding": "⟳"}
#: ⚠️ A SECOND COPY of data-transformers' `refresh_policy.api.PROBLEM_VERDICTS`, kept here
#: because `--problems` filters the fetched pages client-side and no endpoint publishes the
#: list. The two have already drifted: `untracked` is a problem here and not there. Adding a
#: verdict on the server therefore does NOT reach this filter — `emptied` (#642) had to be
#: added by hand. The drift is filed; the fix is for DT to expose the list.
_PROBLEM_VERDICTS = ("emptied", "behind", "clock_overdue", "failed", "never_built",
                     "untracked", "unknown")


def _short_ts(value) -> str:
    """`2026-09-27 12:02:31` from an ISO string; '—' when absent."""
    return str(value)[:19].replace("T", " ") if value else "—"


@derived_state.command(name="freshness")
@click.option("--tenant-id", default=None,
              help="SUPER ADMIN ONLY — read another tenant's freshness.")
@click.option("--problems", is_flag=True, default=False,
              help="Show only emptied / behind / failed / never_built / untracked "
                   "transformers.")
@click.pass_context
def derived_state_freshness(ctx, tenant_id, problems):
    """Was each transformer built AFTER its inputs last changed?

    \b
    One verdict per transformer, worst first:
      ✗ emptied         it holds no row, while its newest successful build wrote some:
                        its rows were removed out of band, not by a build. The next
                        maintenance pass rebuilds it with a full refresh
      ✗ behind          an input changed after its last successful build STARTED, and
                        no refresh is pending and no build is queued or running
      ✗ failed          its last build failed; it holds the previous data
      – never_built     no successful build on record
      ? untracked       reads no table and its policy check failed
      ⟳ rebuild_queued  an input changed and a refresh is pending or a build holds it
                        (the WHY gives the input, its change time and the expected build
                        time), or an upstream transformer is queued / rebuilding
                        ("after X rebuilds")
      ⟳ rebuilding      a live build that includes it holds the build lock
      ✓ current         built after every known input change
      ✓ live            a view — it runs its query on every read, nothing to build

    \b
    Also prints when each input table last CHANGED and which writer changed it (etl,
    reconcile, properties, threat_intel).

    Source: data-transformers' refresh plans (`datalake transformers refresh-plans`), the
    same verdicts the Data Transformers page shows.

    \b
    Examples:
      torana derived-state freshness
      torana derived-state freshness --problems
      torana derived-state freshness --format json
    """
    from torana_cli.refresh_plan_render import freshness_report
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    # DT_MATERIALIZATION_POLICY_SPEC Phase 4: read data-transformers directly, every page.
    pages = []
    try:
        offset = 0
        while True:
            params = {"limit": 100, "offset": offset, **(_tenant_params(tenant_id) or {})}
            body = client.get("transformers/refresh-plans", params=params)
            pages.append(body)
            got = len(body.get("plans") or [])
            offset += got
            if not got or offset >= int(body.get("total") or 0):
                break
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    data = freshness_report(pages)

    rows = data.get("transformers") or []
    if problems:
        rows = [r for r in rows if r.get("verdict") in _PROBLEM_VERDICTS]
        data = {**data, "transformers": rows}

    if raw or fmt != "text":
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    click.echo(f"Tenant            {data.get('tenant_id')}")
    click.echo(f"Last data change  {_short_ts(data.get('last_data_change_at'))} UTC")
    if data.get("refresh_pending"):
        since = _short_ts(data.get("pending_since"))
        click.echo(f"⟳ drain pending since {since} UTC — the relations it rebuilds read "
                   f"⟳ rebuild_queued, then ⟳ rebuilding.")
    from torana_cli.refresh_plan_render import summary_line
    click.echo("Summary           " + summary_line(data.get("summary") or {}))

    tables = data.get("tables") or {}
    if tables:
        click.echo("")
        click.echo(f"{'INPUT TABLE':28} {'LAST CHANGE (UTC)':20} SOURCE")
        for name, t in sorted(tables.items(), key=lambda kv: kv[1].get("last_changed_at") or "",
                              reverse=True):
            click.echo(f"{name:28} {_short_ts(t.get('last_changed_at')):20} "
                       f"{t.get('source') or '—'}")

    click.echo("")
    if not rows:
        click.echo("No transformers match." if problems else "No transformers.")
    else:
        click.echo(f"{'VERDICT':16} {'TRANSFORMER':34} {'BUILT (UTC)':20} "
                   f"{'INPUT CHANGED (UTC)':20} CHANGED INPUT")
        for r in rows:
            v = r.get("verdict") or "?"
            built = _short_ts(r.get("built_at")) if v != "live" else "— (view)"
            changed = r.get("changed_input") or "—"
            if r.get("via"):
                changed += f" (after {r['via']} rebuilds)"
            if r.get("rebuild_due_at"):
                changed += f" · due ~{_short_ts(r['rebuild_due_at'])[11:]}"
            if r.get("reads_no_data") and v == "current":
                changed = "reads no data — nothing to rebuild"
            click.echo(f"{_FRESH_GLYPH.get(v, '?') + ' ' + v:16} {str(r.get('name')):34} "
                       f"{built:20} {_short_ts(r.get('input_changed_at')):20} {changed}")
    errors = {k: v["error"] for k, v in (data.get("sources") or {}).items()
              if isinstance(v, dict) and v.get("error")}
    if errors:
        click.echo("")
        for k, e in errors.items():
            click.echo(f"⚠ {k} unavailable: {e} — verdicts may be incomplete")


@derived_state.command(name="refresh")
@click.option("--tenant-id", default=None,
              help="SUPER ADMIN ONLY — refresh another tenant's derived state.")
@click.pass_context
def derived_state_refresh(ctx, tenant_id):
    """Force a derived-state refresh (operator escape hatch).

    Queues the work rather than running it inline — the chain takes ~20s+, so
    this returns immediately and a background worker converges all three layers.
    Normally unnecessary: an ETL run or a deployment write already triggers this
    automatically.
    """
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.post(f"{_BASE}/refresh", params=_tenant_params(tenant_id), json={})
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    if raw or fmt != "text":
        output(data, fmt=fmt, raw=raw, fields=fields)
        return
    click.echo(data.get("detail") or ("Queued." if data.get("marked") else "Not queued."))
