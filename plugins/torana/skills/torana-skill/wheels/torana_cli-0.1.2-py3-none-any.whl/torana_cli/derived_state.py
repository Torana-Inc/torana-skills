"""torana derived-state — is what I'm looking at current?

Subcommands
-----------
  status                           Freshness of the three derived layers.
  refresh                          Force a refresh (operator escape hatch).

Torana has three DERIVED layers that must be recomputed, IN ORDER, after data
lands: entity-graph reconcile -> property resolution -> transformer
materialization. They now refresh themselves when an ETL run or a deployment
write marks the tenant dirty. These commands answer the question no surface
could answer before — *is this current?* — and give operators a way to force a
refresh without waiting for the debounce window.

Spec: pantheon-integration/docs/DERIVED_STATE_CONVERGENCE.md § 3.4.4
Grouped under a single semantic parent per the CLI grouping convention.
"""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import (
    APIError,
    ToranaClient,
    handle_api_error,
    handle_auth_error,
)
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output

_BASE = "derived-state"


def _ctx(ctx):
    o = ctx.obj or {}
    return (o.get(CTX_FORMAT, "text"), o.get(CTX_RAW, False), o.get(CTX_FIELDS))


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    return ToranaClient(base_url=get_settings(profile).base_url)


def _tenant_params(tenant_id):
    return {"tenant_id": tenant_id} if tenant_id else None


@click.group(name="derived-state")
def derived_state():
    """Freshness of derived data (graph, governance properties, transformers).

    \b
    Derived data is REBUILT from source, not written directly. When a widget shows
    a stale number, ask here BEFORE re-running the pipeline that produced it — the
    answer is usually "the refresh has not run yet", not "the query is wrong".

    \b
    Examples:
      torana derived-state status                  is it current, and when did it last refresh?
      torana derived-state status --json
      torana derived-state refresh                 operator escape hatch — force it
    """


@derived_state.command(name="status")
@click.option("--tenant-id", default=None,
              help="SUPER ADMIN ONLY — read another tenant's derived state.")
@click.pass_context
def derived_state_status(ctx, tenant_id):
    """Show whether derived data is current, and when it last refreshed.

    \b
    Reads three layers independently:
      graph        — last successful entity-graph reconcile
      properties   — last governance resolution (entity_properties_resolved)
      transformers — last successful materialization

    `transformers` can read `unknown` when the transformers service is
    unreachable; the other two layers still report.
    """
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.get(f"{_BASE}/status", params=_tenant_params(tenant_id))
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    if raw or fmt != "text":
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    # Text mode: a flat, human-readable freshness summary rather than the raw
    # nested payload — the point of this command is a one-glance answer.
    state = data.get("state") or "idle"
    dirty = data.get("is_dirty")
    click.echo(f"Tenant        {data.get('tenant_id')}")
    click.echo(f"State         {'updating' if state == 'draining' else 'idle'}"
               + ("  (refresh queued)" if dirty and state != "draining" else ""))
    click.echo(f"Last refresh  {data.get('last_drained_at') or 'never'}")
    layers = data.get("layers") or {}
    click.echo("")
    click.echo("LAYER         LAST UPDATED                       DETAIL")
    g = layers.get("graph") or {}
    p = layers.get("properties") or {}
    t = layers.get("transformers") or {}
    click.echo(f"graph         {str(g.get('last_reconciled_at') or 'never'):34} -")
    click.echo(f"properties    {str(p.get('last_resolved_at') or 'never'):34} "
               f"{p.get('rows')} row(s)")
    click.echo(f"transformers  {str(t.get('last_materialized_at') or 'never'):34} "
               f"{t.get('status')}")

    for ns in (data.get("namespaces") or []):
        if ns.get("last_drain_status") in ("failed", "partial"):
            click.echo("")
            click.echo(f"⚠ last refresh was {ns['last_drain_status']} "
                       f"(namespace {ns.get('namespace_id') or 'default'}) — "
                       f"run `torana derived-state status --format json` for per-step detail.")


@derived_state.command(name="refresh")
@click.option("--tenant-id", default=None,
              help="SUPER ADMIN ONLY — refresh another tenant's derived state.")
@click.pass_context
def derived_state_refresh(ctx, tenant_id):
    """Force a derived-state refresh (operator escape hatch).

    Queues the work rather than running it inline — the chain takes ~20s+, so
    this returns immediately and a background worker converges all three layers.
    Normally unnecessary: an ETL run or a deployment write already triggers this
    automatically.
    """
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.post(f"{_BASE}/refresh", params=_tenant_params(tenant_id), json={})
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    if raw or fmt != "text":
        output(data, fmt=fmt, raw=raw, fields=fields)
        return
    click.echo(data.get("detail") or ("Queued." if data.get("marked") else "Not queued."))
