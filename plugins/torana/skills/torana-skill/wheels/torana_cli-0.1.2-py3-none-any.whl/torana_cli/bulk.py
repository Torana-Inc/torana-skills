"""Shared bulk-operation helper for collection groups.

There are NO bulk endpoints server-side — every enable/disable/publish verb is
per-instance. So a bulk verb is a client-side loop over the existing per-instance
call. That is fine, but it has to be done honestly:

  * **Partial failure must be visible.** A loop that stops on the first error leaves
    the caller with a half-applied change and no idea which half. A loop that
    swallows errors reports success for items that failed. Both are the silent-lie
    pattern this whole tracker is about. `run_bulk` applies to every item, collects
    per-item outcomes, prints a summary, and exits non-zero when anything failed.
  * **Nothing is silently capped.** The caller passes the ids it resolved; if a
    selection was truncated upstream, that is the caller's job to say so.

This exists so the five resources CLI-4 covers (playbooks, schedulers, rules,
alerts, alert-routes) share ONE implementation and cannot drift.
"""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError


def run_bulk(ctx, ids, action, *, label, dry_run=False):
    """Apply `action(id) -> None` to every id, reporting per-item outcomes.

    `action` should raise APIError/AuthError on failure; anything else propagates.
    Returns (succeeded, failed) counts. Exits non-zero if any item failed, so the
    command is scriptable.
    """
    ids = [i for i in (ids or []) if i]
    if not ids:
        click.echo("No matching items — nothing to do.")
        return 0, 0

    if dry_run:
        click.echo(f"DRY RUN — would {label} {len(ids)} item(s):")
        for i in ids:
            click.echo(f"  {i}")
        return len(ids), 0

    ok, failures = [], []
    for item_id in ids:
        try:
            action(item_id)
            ok.append(item_id)
            click.echo(f"  ✓ {item_id}")
        except (APIError, AuthError) as exc:
            failures.append((item_id, str(exc)))
            click.echo(f"  ✗ {item_id}: {exc}", err=True)

    click.echo(f"\n{label}: {len(ok)} succeeded, {len(failures)} failed "
               f"(of {len(ids)}).")
    if failures:
        # Non-zero exit so a script can't mistake a partial apply for success.
        ctx.exit(1)
    return len(ok), len(failures)


def resolve_ids(client, path, *, id_field="id", params=None, predicate=None):
    """Fetch a collection and return the ids to operate on.

    `predicate(item) -> bool` filters client-side when the API has no matching
    server-side filter. Returns [] rather than raising when the shape is unexpected,
    so the caller's "nothing to do" path handles it.
    """
    data = client.get(path, params=params or {})
    if isinstance(data, dict):
        items = data.get("items", [])
    elif isinstance(data, list):
        items = data
    else:
        items = []
    if predicate is not None:
        items = [i for i in items if predicate(i)]
    return [str(i.get(id_field)) for i in items if isinstance(i, dict) and i.get(id_field)]
