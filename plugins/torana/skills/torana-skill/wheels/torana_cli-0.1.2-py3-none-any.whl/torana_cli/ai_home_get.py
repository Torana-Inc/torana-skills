"""An app's Home on the CLI: the page, its state, a refresh, earlier pages and the window's events.

Spec: docs/specs/HOME_SURFACE_SPEC.md § 3.4.2 to § 3.4.6. Registered from ai_home.py on the `ai-home` group.

⭐ `get` prints the server's `sections` (torana_cli/home_sections.py); it builds no card's words.
⭐ `status` reads the RAW run list: page age, run states, schedule and switches are one report, not a collection.
"""
import time
from datetime import datetime, timezone

import click

from torana_cli import home_sections as hs
from torana_cli.ai_home import _age, _ctx, list_runs_core, run_detail_core
from torana_cli.client.auth import AuthError
from torana_cli.client.base import EXIT_NOT_FOUND, EXIT_RUN_FAILED, APIError, handle_api_error, handle_auth_error, echo_reference
from torana_cli.output import output
from torana_cli.section_descriptions import with_sections_help

WAIT_POLL_S = 5
#: Covers both passes of a proven run: proving, the narrate queue and narration (up to 3 LLM rounds).
WAIT_DEFAULT_S = 20 * 60
TERMINAL = ("success", "partial", "data_only", "failed", "timeout")
FAILED = ("failed", "timeout")
#: Retention keeps this many proven pages per app (program-framework AI_HOME_PROVEN_RUNS_KEEP default).
KEPT_RUNS = 24
OLDER_SERVER = "This server does not send finished sections yet; showing the previous layout."
EARLIER_PAGE_QUESTIONS = "What matters shows the current answers, not those of an earlier page."


def home_cmd(app_id: str) -> str:
    return f"torana app {app_id} ai-home"


def _dt(v):
    if not v:
        return None
    try:
        d = datetime.fromisoformat(str(v).replace("Z", "+00:00"))
    except ValueError:
        return None
    return d if d.tzinfo else d.replace(tzinfo=timezone.utc)


def _detail(e: APIError) -> dict:
    return e.detail if isinstance(e.detail, dict) else {}


def never_run_lines(detail: dict, app_id: str) -> list:
    """No page yet is a STATE: say it, and say truthfully whether one is coming (`first_page_scheduled`)."""
    out = ["No Home page has been prepared for this app yet."]
    fly = detail.get("in_flight") or {}
    bad = detail.get("last_failure") or {}
    if fly:                              # a page is on its way: say where it is, in the server's words, never "never prepared"
        out = [f"No Home page is ready yet: one is being prepared ({fly.get('stage_label') or fly.get('stage') or 'running'}), run {fly.get('run_id')}.",
               f"  Follow it:  {home_cmd(app_id)} status"]
        return out
    if bad:
        out.append(f"  The last attempt failed: {bad.get('error') or 'no reason recorded'} (run {bad.get('run_id')}).")
    coming = detail.get("first_page_scheduled")
    if coming is True:
        out.append(f"  The platform prepares the first one within the hour. Follow it:  {home_cmd(app_id)} status")
    elif coming is False:
        out.append(f"  Prepare it now:  {home_cmd(app_id)} refresh --wait")
    else:                               # an older server does not say
        out.append(f"  Follow it:  {home_cmd(app_id)} status")
    return out


def fetch_page(client, app_id: str, run_id: str | None = None) -> dict:
    params = {"kind": "proven", **({"run_id": run_id} if run_id else {})}
    return client.get(f"workspaces/{app_id}/ai-home", params=params) or {}


def report_of(page: dict, app_id: str) -> dict:
    """The JSON report of `get`: the page's identity, window, switches and cards. A report, not a collection."""
    return {"run_id": page.get("run_id"), "app_id": app_id, "status": page.get("status"),
            "trigger": page.get("trigger"), "generated_at": page.get("generated_at"),
            "window": {"label": page.get("window_label"), "since_at": page.get("since_at"),
                       "now_at": page.get("now_at")},
            # The app's declared kind (APP_PROFILES_SPEC), when it has one: printed on the stamp line.
            "app_label": (((page.get("proof") or {}).get("home") or {}).get("profile") or {}).get("label"),
            "features": page.get("features"), "sections_version": page.get("sections_version"),
            # Which Inbox items the page describes changed after it was prepared (checked when served); the marked
            # lines are in `sections` (kind `changed`). None from an older server.
            "changes": page.get("changes"),
            # The app profile's choices: sections this app does not draw (still in `sections`, still printed by
            # `--section <key>`) and the headings it gives (already applied to each section's title).
            "hidden_sections": page.get("hidden_sections") or [], "section_titles": page.get("section_titles") or {},
            "sections": page.get("sections")}


def run_state(data: dict) -> dict:
    """The state of an app's Home from the raw run list (spec § 3.4.3). First match wins: refreshing (a run is in
    progress, even after a failure) · never_prepared · last_refresh_failed · current."""
    items = data.get("items") or []
    shown = data.get("shown_page") or None
    flying = next((r for r in items if r.get("status") == "in_progress"), None)
    finished = [r for r in items if r.get("status") != "in_progress"]
    shown_started = next((_dt(r.get("started_at")) for r in items if r.get("is_shown")), None)
    failed = next((r for r in finished if r.get("status") in FAILED), None)
    if failed and shown_started and (_dt(failed.get("started_at")) or shown_started) <= shown_started:
        failed = None                       # older than the page readers are shown: not news
    if flying:
        state = "refreshing"
    elif not shown:
        state = "never_prepared"
    elif finished and finished[0].get("status") in FAILED and not finished[0].get("is_shown"):
        state = "last_refresh_failed"
    else:
        state = "current"
    sched = data.get("schedule") or {}
    out = {"page": ({"run_id": shown.get("run_id"), "generated_at": shown.get("generated_at"),
                     "age_seconds": shown.get("age_seconds")} if shown else None),
           "state": state,
           "in_flight": ({"run_id": flying.get("run_id"), "stage": flying.get("stage"), "stage_label": flying.get("stage_label"),
                          "phase": flying.get("phase"),
                          "started_at": flying.get("started_at")} if flying else None),
           "last_failure": ({"run_id": failed.get("run_id"), "error": failed.get("error"),
                             "completed_at": failed.get("completed_at")} if failed else None),
           "schedule": {k: sched.get(k) for k in ("enabled", "refresh_minutes", "next_due_at")}}
    if "features" in data:                  # an older server sends none: say nothing about switches
        out["features"] = data["features"]
    return out


def status_lines(st: dict, app_id: str, never_run: dict | None = None) -> list:
    """`status` in words: the state first, then the schedule, then every switch that is off."""
    page, fly, bad = st.get("page") or {}, st.get("in_flight") or {}, st.get("last_failure") or {}
    old = f"the page from {_age(page.get('age_seconds'))} ago" if page else "no page yet"
    state = st["state"]
    if state == "current":
        out = [f"Current: prepared {_age(page.get('age_seconds'))} ago (run {page.get('run_id')})."]
    elif state == "refreshing":
        out = [f"Refreshing ({fly.get('stage_label') or fly.get('stage') or 'running'}): run {fly.get('run_id')}; showing {old}."]
    elif state == "last_refresh_failed":
        out = [f"The last refresh failed ({bad.get('error') or 'no reason recorded'}); showing {old}.",
               f"  Try:  {home_cmd(app_id)} refresh --wait"]
    else:
        out = never_run_lines(never_run or {}, app_id)
    if bad and state != "last_refresh_failed":
        out.append(f"  The refresh before it failed: {bad.get('error') or 'no reason recorded'} (run {bad.get('run_id')}).")
    sched = st.get("schedule") or {}
    if sched.get("enabled") and sched.get("next_due_at"):
        out.append(f"  Next scheduled refresh: {str(sched['next_due_at'])[:16].replace('T', ' ')} UTC "
                   f"(every {sched.get('refresh_minutes')} min).")
    for name, sw in (st.get("features") or {}).items():
        if isinstance(sw, dict) and sw.get("enabled") is False and sw.get("reason"):
            out.append(f"  ○ {sw['reason']}")
    return out


def wait_for_run(client, app_id: str, run_id: str, *, timeout_s: int, poll_s: int = WAIT_POLL_S) -> dict:
    """Poll GET workspaces/{id}/ai-home/runs/{run_id} until its status is terminal or `timeout_s` passes, printing
    each stage change on stderr. Returns {run_id, status, error, timed_out}.
    ⛔ A 401 or a 404 on the run is raised at once (the old loop swallowed both and span for 20 minutes); any
    other API error is retried, and raised after three in a row."""
    deadline = time.monotonic() + timeout_s
    seen, errors, last = None, 0, {}
    while True:
        try:
            last = client.get(f"workspaces/{app_id}/ai-home/runs/{run_id}") or {}
            errors = 0
        except APIError as e:
            errors += 1
            if e.status_code in (401, 403, 404) or errors >= 3:
                raise
        stage = last.get("stage")
        if stage and stage != seen and stage != "done":
            click.echo(f"  … {last.get('stage_label') or stage}", err=True)
            seen = stage
        if last.get("status") in TERMINAL:
            return {"run_id": run_id, "status": last["status"], "error": last.get("error"), "timed_out": False}
        if time.monotonic() >= deadline:
            return {"run_id": run_id, "status": last.get("status") or "in_progress", "error": None, "timed_out": True}
        time.sleep(poll_s)


def register(ai_home, client_factory, list_timeline_core):
    """Attach get, status, refresh, runs and events to the `ai-home` group."""

    def _wid(ctx) -> str:
        return ctx.obj.get("_workspace_id", "") if ctx.obj else ""

    def _fail(e):
        handle_auth_error(e) if isinstance(e, AuthError) else handle_api_error(e)

    # ── get ──────────────────────────────────────────────────────────────────────────────────────────────────────
    @ai_home.command(name="get")
    @click.option("--section", "keys", multiple=True, type=click.Choice(hs.HOME_SECTION_KEYS),
                  help="Print only this card. Repeat for several. Keys are listed above.")
    @click.option("--run", "run_id", default=None, metavar="RUN_ID",
                  help="Show an earlier page instead of the latest (ids from `ai-home runs list`).")
    @click.option("--cites", is_flag=True, default=False,
                  help="Under each line that cites proven facts, print each fact's id and text as the page stored it.")
    @click.pass_context
    def ai_home_get(ctx, keys, run_id, cites):
        """Show an app's Home as the screen shows it: what needs you, what the app handled, and how it is running.

        Every card's words are written by the platform and are the same on the screen. Use this to read the
        page; use --section to read one card. With no --section it prints every card the screen draws.

        \b
        Cards (--section):
              {SECTIONS}

        \b
        Marks: ✦ written by AI · ◆ proven fact · ▲ needs attention · ◐ watch · ✓ fine · ○ switched off or never ran.
        "—" means not known, never zero. "N+" means at least N.
        Under a line, "→" is the command that opens it.

        \b
        Related: `ai-home status` (is the page current), `ai-home refresh` (prepare a new one),
        `ai-home item <ALERT_ID> get` (one item's proof).

        \b
        Examples:
          torana app <APP_ID> ai-home get
          torana app <APP_ID> ai-home get --section needs-you
          torana app <APP_ID> ai-home get --section needs-you --cites
          torana app <APP_ID> ai-home get --section handled --section rules --json
          torana app <APP_ID> ai-home get --run <RUN_ID>
        """
        fmt, raw, fields = _ctx(ctx)
        wid = _wid(ctx)
        client = client_factory(ctx)
        try:
            page = fetch_page(client, wid, run_id)
        except APIError as e:
            if e.status_code == 404 and run_id:
                click.echo(f"That page is no longer kept (only the last {KEPT_RUNS} are).", err=True)
                echo_reference(e)
                ctx.exit(EXIT_NOT_FOUND)
            if e.status_code == 404 and _detail(e).get("error") == "never_run":
                if fmt in ("json", "yaml"):
                    output({"app_id": wid, "state": _detail(e).get("state") or "never_prepared",
                            "first_page_scheduled": _detail(e).get("first_page_scheduled"),
                            "in_flight": _detail(e).get("in_flight"), "last_failure": _detail(e).get("last_failure"),
                            "features": _detail(e).get("features"), "sections": None}, fmt=fmt, raw=raw, fields=fields)
                else:
                    click.echo("\n".join(never_run_lines(_detail(e), wid)))
                return
            return _fail(e)
        except AuthError as e:
            return _fail(e)

        if page.get("sections") is None:       # an older server: the previous layout, and say so
            click.echo(OLDER_SERVER, err=True)
            from torana_cli import ai_home_v2
            view = ai_home_v2.v2_view(page, wid)
            if fmt in ("json", "yaml"):
                output(view, fmt=fmt, raw=raw, fields=fields)
            else:
                ai_home_v2.render(view, page, wid)
            return

        report = report_of(page, wid)
        wanted = list(dict.fromkeys(keys))
        hidden = [] if wanted else list(report["hidden_sections"])     # naming a section always prints it
        blocks = ([hs.block_of(report["sections"], k) or {"key": hs.api_key(k), "missing": True} for k in wanted]
                  if wanted else [b for b in report["sections"] if b.get("drawn", True) and b.get("key") not in hidden])
        # "What matters to you" is read from its own route; when the feature is off, its reason is the card.
        questions = None
        matters = next((b for b in blocks if b.get("key") == "what_matters" and not b.get("missing")), None)
        switch = (report.get("features") or {}).get("what_matters") or {}
        if matters is not None and switch.get("enabled", True):
            try:
                questions = client.get(f"workspaces/{wid}/ai-home/questions")
            except (APIError, AuthError) as e:
                return _fail(e)

        if fmt in ("json", "yaml"):
            out_blocks = [b for b in blocks if not b.get("missing")]
            if questions is not None:
                out_blocks = [{**b, "questions": questions} if b.get("key") == "what_matters" else b for b in out_blocks]
            output({**report, "sections": out_blocks}, fmt=fmt, raw=raw, fields=fields)
            return

        click.echo("")
        click.echo(hs.stamp_line(report))
        stale = hs.changes_line(report)
        if stale:
            click.echo(stale)
        for b in blocks:
            if b.get("missing"):
                click.echo("\n".join(hs.missing_block_lines(hs.cli_key(b["key"]))))
            elif b.get("key") == "what_matters":
                click.echo("\n".join(hs.block_lines(b)))
                if questions is None:
                    click.echo(f"  ○ {switch.get('reason') or 'What matters to you is turned off in this environment.'}")
                    continue
                if run_id:
                    click.echo(f"  {EARLIER_PAGE_QUESTIONS}")
                from torana_cli.ai_home_questions import _print_list
                _print_list(questions)
            else:
                click.echo("\n".join(hs.block_lines(b, cites=cites)))
        line = hs.hidden_line(report, hidden)
        if line:
            click.echo(f"\n{line}")
        click.echo("")

    with_sections_help(ai_home_get, "home")

    # ── status ───────────────────────────────────────────────────────────────────────────────────────────────────
    @ai_home.command(name="status")
    @click.pass_context
    def ai_home_status(ctx):
        """Show whether this app's Home is current, being prepared again, or whether the last attempt failed.

        Use it before trusting the page's age, and after `ai-home refresh`. It prints the state in words, the
        next scheduled preparation, and every Home feature that is switched off in this environment.

        \b
        state is one of: current · refreshing · last_refresh_failed · never_prepared.
        A state is not an error: every state exits 0.

        \b
        Related: `ai-home refresh --wait`, `ai-home runs list`, `ai-home get`.

        \b
        Examples:
          torana app <APP_ID> ai-home status
          torana app <APP_ID> ai-home status --json
        """
        fmt, raw, fields = _ctx(ctx)
        wid = _wid(ctx)
        client = client_factory(ctx)
        never = None
        try:
            # ⛔ The RAW response: `shown_page`, `schedule` and `features` are this report; a collection wrapper drops them.
            st = run_state(client.get(f"workspaces/{wid}/ai-home/runs", params={"kind": "proven", "limit": 20}) or {})
            if st["state"] == "never_prepared":      # the page's own 404 says whether a first page is coming
                try:
                    fetch_page(client, wid)
                except APIError as e:
                    if e.status_code != 404:
                        raise
                    never = _detail(e)
        except (APIError, AuthError) as e:
            return _fail(e)
        if fmt in ("json", "yaml"):
            extra = {"first_page_scheduled": never.get("first_page_scheduled")} if never is not None else {}
            output({"app_id": wid, **st, **extra}, fmt=fmt, raw=raw, fields=fields)
            return
        click.echo("\n".join(status_lines(st, wid, never)))

    # ── refresh ──────────────────────────────────────────────────────────────────────────────────────────────────
    @ai_home.command(name="refresh")
    @click.option("--wait", is_flag=True, default=False,
                  help="Stay until the new page is ready or the attempt has ended (checks every 5 seconds).")
    @click.option("--timeout", "timeout_s", type=click.IntRange(5, 7200), default=WAIT_DEFAULT_S, show_default=True,
                  metavar="SECONDS", help="With --wait: give up waiting after this long. The work carries on.")
    @click.pass_context
    def ai_home_refresh(ctx, wait, timeout_s):
        """Prepare a new Home page for this app now (the screen's Regenerate button).

        The platform proves the app's items again from current data, then writes the page up. It takes a few
        minutes. Without --wait this returns at once; follow it with `ai-home status`.

        \b
        Exit codes with --wait:
          0   the new page is ready (success, partial or data_only)
          8   the attempt failed or timed out, or --timeout passed first; the previous page is still shown
          3   the run could not be found · 5 not logged in

        \b
        Related: `ai-home status`, `ai-home runs get <RUN_ID>` (why an attempt failed).

        \b
        Examples:
          torana app <APP_ID> ai-home refresh
          torana app <APP_ID> ai-home refresh --wait
          torana app <APP_ID> ai-home refresh --wait --timeout 600 --json
        """
        fmt, raw, fields = _ctx(ctx)
        wid = _wid(ctx)
        client = client_factory(ctx)
        result, attached = None, False
        try:
            try:
                started = client.post(f"workspaces/{wid}/ai-home/run?kind=proven", {}) or {}
                run_id = started.get("run_id")
            except APIError as e:
                if e.status_code != 409:
                    raise
                # One is already being prepared: that is the one to follow.
                attached = True
                data = client.get(f"workspaces/{wid}/ai-home/runs", params={"kind": "proven", "limit": 20}) or {}
                flying = next((r for r in data.get("items") or [] if r.get("status") == "in_progress"), None)
                run_id = (flying or {}).get("run_id")
                if not run_id:                  # it ended between the two calls: report the newest attempt
                    newest = next(iter(data.get("items") or []), {})
                    result = {"run_id": newest.get("run_id"), "status": newest.get("status"),
                              "error": newest.get("error"), "timed_out": False}
            if result is None and not wait:
                result = {"run_id": run_id, "status": "in_progress", "error": None, "timed_out": False}
                if fmt in ("json", "yaml"):
                    output({"app_id": wid, **result, "already_running": attached}, fmt=fmt, raw=raw, fields=fields)
                    return
                click.echo(("A refresh is already running" if attached else "Refresh started") + f" (run {run_id}).")
                click.echo(f"  Follow it:  {home_cmd(wid)} status")
                return
            if result is None:
                result = wait_for_run(client, wid, run_id, timeout_s=timeout_s)
        except (APIError, AuthError) as e:
            return _fail(e)

        ok = result["status"] in TERMINAL and result["status"] not in FAILED and not result["timed_out"]
        if fmt in ("json", "yaml"):
            output({"app_id": wid, **result, "already_running": attached}, fmt=fmt, raw=raw, fields=fields)
        elif ok:
            click.echo(f"Home page prepared (run {result['run_id']}, {result['status']}).")
        elif result["timed_out"]:
            click.echo(f"Still preparing after {timeout_s // 60 or 1} minute(s) (run {result['run_id']}); it carries on. "
                       f"Follow it:  {home_cmd(wid)} status", err=True)
        else:
            click.echo(f"The refresh failed: {result.get('error') or result['status']}. "
                       "The previous page is still shown.", err=True)
            click.echo(f"  Why:  {home_cmd(wid)} runs get {result['run_id']}", err=True)
        if not ok:
            ctx.exit(EXIT_RUN_FAILED)

    # ── runs ─────────────────────────────────────────────────────────────────────────────────────────────────────
    @ai_home.group(name="runs", invoke_without_command=True)
    @click.pass_context
    def runs(ctx):
        """Earlier Home pages of this app: every attempt to prepare one, newest first.

        \b
        Examples:
          torana app <APP_ID> ai-home runs list
          torana app <APP_ID> ai-home runs get <RUN_ID>
        """
        ctx.ensure_object(dict)
        if ctx.invoked_subcommand is None:
            click.echo(ctx.get_help())

    @runs.command(name="list")
    @click.option("--limit", default=20, show_default=True, type=click.IntRange(1, 100))
    @click.pass_context
    def runs_list(ctx, limit):
        """List this app's Home pages and the attempts to prepare them, newest first.

        Each row says how the attempt ended, who started it (scheduled or manual), why it failed if it did, and
        which one is the page readers are shown ("◀ shown"). Open an earlier page with
        `ai-home get --run <RUN_ID>`.

        \b
        Examples:
          torana app <APP_ID> ai-home runs list
          torana app <APP_ID> ai-home runs list --limit 50 --json
        """
        list_runs_core(ctx, client_factory, _wid(ctx), limit=limit, kind="proven")

    @runs.command(name="get")
    @click.argument("run_id", metavar="RUN_ID")
    @click.pass_context
    def runs_get(ctx, run_id):
        """Show one attempt in detail: how it ended, why it failed, and which page is shown instead.

        \b
        Examples:
          torana app <APP_ID> ai-home runs get <RUN_ID>
          torana app <APP_ID> ai-home runs get <RUN_ID> --json
        """
        run_detail_core(ctx, client_factory, _wid(ctx), run_id)

    # ── events ───────────────────────────────────────────────────────────────────────────────────────────────────
    @ai_home.command(name="events")
    @click.option("--window", default=None, type=click.Choice(["1h", "6h", "24h", "7d"]),
                  help="Look back this far instead of the page's own window.")
    @click.option("--since", default=None, metavar="TIME", help="Start here (an ISO time) instead of the page's window.")
    @click.option("--limit", default=100, show_default=True, type=click.IntRange(1, 500),
                  help="At most this many rows; the list is paged for you.")
    @click.pass_context
    def ai_home_events(ctx, window, since, limit):
        """List the activity events behind the Home page's "events in the window" figure.

        These are the app's own activity: data syncs, rule runs, agent work. They are not findings the app dealt
        with (that is `ai-home get --section handled`). With no option the window is the page's own, so the rows
        are the ones the page counted; the footer says the page's figure. A row is a group of repeated events
        (× is how many, and it keeps counting after the page was prepared).

        \b
        Related: `ai-home get --section summary` (the figure), `ai-home get --section handled`.

        \b
        Examples:
          torana app <APP_ID> ai-home events
          torana app <APP_ID> ai-home events --window 24h
          torana app <APP_ID> ai-home events --since 2026-10-12T00:00:00Z --json
        """
        fmt, raw, fields = _ctx(ctx)
        wid = _wid(ctx)
        client = client_factory(ctx)
        page, until = {}, None
        try:
            if not window and not since:
                try:
                    page = fetch_page(client, wid)
                    since, until = page.get("since_at"), _dt(page.get("now_at"))
                except APIError as e:
                    if e.status_code != 404:
                        raise
                    window = "24h"              # no page yet: the last day
            rows, cursor, pages = [], None, 0
            while len(rows) < limit and pages < 10:
                data = list_timeline_core(client, workspace_id=wid, since=since, window=window,
                                          limit=min(100, limit - len(rows)), cursor=cursor)
                pages += 1
                rows += (data or {}).get("items") or []
                cursor = (data or {}).get("next_cursor")
                if not cursor:
                    break
        except (APIError, AuthError) as e:
            return _fail(e)
        listed = len(rows)
        if until:
            # The route has no upper bound: cut at the page's own clock here. ⛔ By `first_at`, not `created_at`: a
            # row is a roll-up, `created_at` is its NEWEST member, and a roll-up that began inside the window keeps
            # growing after the page is prepared (the narrator that writes the page runs after the count). Cutting
            # by `created_at` dropped that row and listed 34 where the page counted 35 (measured 2026-10-12).
            rows = [r for r in rows if (_dt(r.get("first_at") or r.get("created_at")) or until) <= until]
        since_f = (page.get("facts") or {}).get("since") or {}
        counted = since_f.get("handled_count")
        counted_s = None if not isinstance(counted, int) else f"{counted}+" if since_f.get("handled_truncated") else str(counted)
        wrapped = {"items": rows, "total": len(rows), "page": 1, "page_size": len(rows),
                   "window": {"since_at": since, "until_at": page.get("now_at"), "preset": window},
                   "page_counted": counted_s, "after_the_page": listed - len(rows), "more": bool(cursor)}
        if fmt in ("json", "yaml"):
            output(wrapped, fmt=fmt, raw=raw, fields=fields)
            return
        output(wrapped, fmt=fmt, raw=raw, fields=fields, columns=[
            ("line_type", "TYPE", 8), ("producer", "PRODUCER", 14), ("title", "TITLE", 60),
            ("rolled_up_count", "×", 3), ("created_at", "WHEN", 20)])
        if counted_s is not None:
            same = "" if counted_s == str(len(rows)) else f" (listed here: {len(rows)})"
            click.echo(f"The page counted {counted_s} events in this window{same}.")
        if listed - len(rows):
            click.echo(f"{listed - len(rows)} more arrived after the page was prepared; see them with --window.")
        if cursor:
            click.echo(f"There are more than {limit}; raise --limit.")
