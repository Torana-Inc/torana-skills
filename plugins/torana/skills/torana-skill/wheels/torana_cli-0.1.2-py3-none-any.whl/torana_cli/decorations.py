"""torana decorations — inspect and trigger the decoration layer.

A DECORATION is an asserted fact joined onto sink rows at read time (KEV/EPSS
threat intel, SLA windows) rather than written by the ingest mapping. That split
is deliberate — see `pantheon-integration/torana_mesh/mappings/CLAUDE.md`
("Writers write only what they OBSERVED") — but it means an operator asking
"why is this vulnerability not enriched?" has to reason about a pipeline with
three separable failure points: the PRODUCER (are facts being made?), the APPLY
step (did they reach rows?), and the TRIGGER (did anything run?).

Before this group existed there was no CLI surface for any of it: diagnosing the
enrichment gap meant probing raw tables by guessing their names, and the only way
to force a refresh was curl against a service port. That is CLI-42 (no write
verb) and CLI-43 (no read verb).

⚠ LEADER-ONLY SCHEDULER. `producer-scheduler` is answered by whichever worker
handles the request, but the job is registered only on the LEADER. A non-leader
truthfully reports `next_run_time: null`, which reads as "never scheduled" and is
the wrong conclusion. Every renderer here surfaces `answered_by_leader` alongside
it so the distinction is visible rather than inferred.
"""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.confirm import confirm as _confirm


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    return ToranaClient(base_url=get_settings(profile).base_url)


def _fmt(ctx):
    """The (format, raw, fields) triple every command reads the same way."""
    if not ctx.obj:
        return "text", False, None
    return (
        ctx.obj.get(CTX_FORMAT, "text"),
        ctx.obj.get(CTX_RAW, False),
        ctx.obj.get(CTX_FIELDS),
    )


def _fmt_count(value):
    """Thousands-separated, and a DASH for null — never a bare 0.

    `rows_updated` is NULL while a job is pending and 0 when an apply genuinely
    touched nothing. Rendering both as "0" merges "has not run" with "ran, found
    nothing to change", which are the two answers a reader is trying to tell
    apart.
    """
    if value is None:
        return "—"
    try:
        return f"{int(value):,}"
    except (TypeError, ValueError):
        return str(value)


def _short_ts(value):
    """`2026-09-18T17:40:11.123456+00:00` -> `2026-09-18 17:40:11`."""
    if not value:
        return "—"
    return str(value).replace("T", " ")[:19]


def _job_row(job: dict) -> dict:
    """One queue row, flattened for the text table.

    Attempts collapse to `1/5` rather than two columns: the number only means
    anything against its ceiling, and two adjacent integer columns invited
    reading `3` and `5` as unrelated counters.
    """
    return {
        **job,
        "attempts": f"{job.get('attempt', 0)}/{job.get('max_attempts', 0)}",
        "rows_updated": _fmt_count(job.get("rows_updated")),
        "finished_at": _short_ts(job.get("finished_at")),
    }


@click.group(name="decorations", invoke_without_command=True)
@click.pass_context
def decorations(ctx):
    """Decoration layer — read-time enrichment of sink rows (threat intel, SLA).

    A decoration is an ASSERTED fact (KEV/EPSS, SLA windows) joined onto rows at
    read time, not written by ingest. Use these verbs to answer "are facts being
    produced, did they reach the rows, and did anything actually run?".

    \b
    Examples:
      torana decorations list                  # what decorations exist
      torana decorations status                # per-decoration freshness + coverage
      torana decorations jobs                  # apply-job queue, incl. failures
      torana decorations history               # past refreshes + rows updated
      torana decorations scheduler             # the apply-side schedule
      torana decorations producer-scheduler    # the producer cron (leader-only!)
      torana decorations reapply cve_intel     # TENANT: re-apply facts to my rows
      torana decorations refresh cve_intel     # ADMIN: force a producer run now
      torana decorations retry <job_key>       # retry one failed apply job
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@decorations.command(name="list")
@click.pass_context
def decorations_list(ctx):
    """List the registered decorations and what each one decorates."""
    fmt, raw, fields = _fmt(ctx)
    client = _client(ctx)
    try:
        data = client.get("decorations")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Normalize the resource-named key to the {items,total} collection contract
    # in the COMMAND CORE, never at the render site — one place owns the shape.
    if isinstance(data, dict) and "decorations" in data:
        items = data.get("decorations") or []
        data = {
            "items": items,
            "total": data.get("total", len(items)),
            "page": 1,
            "page_size": len(items),
            # A distinct facet, not the list — kept as a sidecar.
            "column_precedence": data.get("column_precedence"),
        }

    output(
        data, fmt=fmt, raw=raw, fields=fields,
        columns=[
            ("name", "NAME", 18),
            ("decorates", "DECORATES", 18),
            ("subject_column", "SUBJECT COLUMN", 20),
            ("scope", "SCOPE", 10),
        ],
    )


@decorations.command(name="status")
@click.option("--decoration", "decoration", default=None,
              help="Only this decoration (e.g. cve_intel).")
@click.pass_context
def decorations_status(ctx, decoration):
    """Per-decoration freshness: is the source newer than what was applied?

    The load-bearing comparison is `source_version` vs `applied_version`. When
    they differ, facts exist that have NOT reached the rows — the exact state
    behind "the cache is full but every row is empty" (functionality #94/#68).
    """
    fmt, raw, fields = _fmt(ctx)
    client = _client(ctx)
    params = {"decoration": decoration} if decoration else None
    try:
        data = client.get("decorations/status", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    rows = (data or {}).get("decorations") or []
    if not rows:
        click.echo("No decorations reported.")
        return

    for d in rows:
        click.echo(f"\n{d.get('decoration')}")
        for ns in d.get("namespaces") or []:
            src, applied = ns.get("source_version"), ns.get("applied_version")
            # Surfaced as an explicit line rather than left for the reader to
            # diff two long ISO timestamps by eye.
            drift = "" if src == applied else "   ⚠ SOURCE NEWER THAN APPLIED"
            stale = ns.get("staleness_seconds")
            click.echo(f"  namespace        : {ns.get('namespace_id') or '(global)'}")
            click.echo(f"  status           : {ns.get('status')}{drift}")
            click.echo(f"  source_version   : {src}")
            click.echo(f"  applied_version  : {applied}")
            # ⭐ The one line a TENANT actually asks for: "when was my data last
            # refreshed?". `last_success_at` is stamped AFTER the apply committed,
            # so it answers that and not "when did the producer start".
            click.echo(f"  last_completed   : {_short_ts(ns.get('last_success_at'))}")
            if ns.get("last_attempt_at") and ns.get("last_attempt_at") != ns.get("last_success_at"):
                click.echo(f"  last_attempt     : {_short_ts(ns.get('last_attempt_at'))}")
            if stale is not None:
                click.echo(f"  staleness        : {round(float(stale) / 3600, 1)}h")
            if ns.get("pending_apply"):
                click.echo(f"  pending_apply    : {ns.get('pending_apply')}")
            if ns.get("error"):
                click.echo(f"  error            : {ns.get('error')}")


@decorations.command(name="jobs")
@click.option("--state", default=None,
              help="Filter by job state (e.g. pending, running, failed, succeeded).")
@click.option("--decoration", default=None, help="Filter by decoration name.")
@click.option("--limit", default=50, show_default=True, help="Max rows.")
@click.pass_context
def decorations_jobs(ctx, state, decoration, limit):
    """Apply-job queue — which decoration applies ran, and which failed."""
    fmt, raw, fields = _fmt(ctx)
    client = _client(ctx)
    params = {"limit": limit}
    if state:
        params["state"] = state
    if decoration:
        params["decoration"] = decoration
    try:
        data = client.get("decorations/jobs", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # json/yaml get the untouched envelope, so the derived text columns below can
    # never hide a field the API returned.
    if fmt in ("json", "yaml") or raw:
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    if isinstance(data, dict) and "jobs" in data:
        items = data.get("jobs") or []
        data = {
            "items": [_job_row(j) for j in items],
            "total": data.get("total", len(items)),
            "page": 1,
            "page_size": data.get("limit", len(items)),
        }

    output(
        data, fmt=fmt, raw=raw, fields=fields,
        columns=[
            ("job_key", "JOB KEY", 26),
            ("decoration", "DECORATION", 12),
            ("state", "STATE", 10),
            ("attempts", "ATT", 5),
            ("rows_updated", "ROWS UPDATED", 13),
            ("finished_at", "FINISHED", 20),
        ],
    )

    # ⛔ This table is a QUEUE, not a log. One row per (decoration, target),
    # upserted in place, so `rows_updated` is always the LAST run's figure and
    # there is no second row to compare it against. Saying so here stops the
    # single row reading as "the layer has only ever run once".
    if fmt == "text":
        click.echo("\nOne row per apply target, upserted in place — this is the "
                   "queue, not a history log.")
        click.echo("Run history:  torana decorations history")


@decorations.command(name="history")
@click.option("--decoration", default=None,
              help="Only this decoration (matched on the event title/detail).")
@click.option("--window", type=click.Choice(["1h", "6h", "24h", "7d"]),
              default="7d", show_default=True, help="How far back to read.")
@click.option("--since", default=None, help="Window start (ISO). Overrides --window.")
@click.option("--limit", default=50, show_default=True, type=int, help="Max rows.")
@click.pass_context
def decorations_history(ctx, decoration, window, since, limit):
    """Past refreshes and how many rows each one updated.

    ⛔ READ FROM THE EVENT FEED, NOT FROM `decorations jobs`. `decoration_apply_jobs`
    is a work QUEUE — one row per (decoration, target), upserted in place — so it
    holds the LAST run and nothing before it. The durable per-tenant record of what
    ran is the platform event timeline, which keeps one row per completed apply with
    `rows_updated_count` in its detail.

    ⚠ ONLY RUNS THAT CHANGED SOMETHING APPEAR. Emission is suppressed when an apply
    updated zero rows, deliberately: a daily "0 findings updated" line would bury
    the days that mattered. So a gap here means "nothing changed", not "nothing ran"
    — use `decorations status` for the last-attempt timestamp either way.
    """
    fmt, raw, fields = _fmt(ctx)
    client = _client(ctx)

    # `producer` is the registry name in pantheon-shared/events/registry.py; the
    # event keys it emits are prefixed `decoration:`.
    params = {"producer": "decoration", "limit": min(limit, 100)}
    if since:
        params["since"] = since
    elif window:
        params["window"] = window

    try:
        data = client.get("events", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml") or raw:
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    items = (data or {}).get("items") or []

    def _count(node):
        v = ((node.get("detail") or {}).get("rows_updated_count"))
        return v if isinstance(v, (int, float)) else None

    def _row(node):
        det = node.get("detail") or {}
        return {
            "when": _short_ts(node.get("created_at")),
            "decoration": det.get("decoration") or "—",
            "rows_updated": _fmt_count(_count(node)),
            "namespace": (det.get("namespace_id") or "")[:8] or "(global)",
            "title": node.get("title") or "",
            "_sort": str(node.get("created_at") or ""),
        }

    # ⛔ ONE ROW PER REFRESH — the feed's roll-up is UNDONE here, deliberately.
    #
    # The feed groups on (producer, event_key), and EVERY decoration event shares
    # `event_key = decoration:<name>`, so an entire decoration's history collapsed onto
    # ONE line. Two separate lies came out of that, both measured on ACME:
    #   * it SUMS numeric `*_count` detail fields onto the head but keeps ONE member's
    #     title — printing "45,232" beside the sentence "15,092 findings updated";
    #   * the ×N was not a count of refreshes at all. Policy's "×2" was ONE apply
    #     (14,289 rows) plus ONE status-recovery event with no row count.
    #
    # `members` ARE the raw events, so flattening restores the truth rather than
    # re-deriving it. ⚠️ The head's OWN figure must be recovered by SUBTRACTION, because
    # the API mutated head.detail into the group sum — exact only while the member list
    # is complete. The cap (TIMELINE_ROLLUP_MEMBER_CAP, 20) truncates the LIST without
    # touching rolled_up_count, so when the two disagree we print a dash rather than a
    # confidently wrong number.
    rows = []
    for it in items:
        members = it.get("members") or []
        rows.extend(_row(m) for m in members)

        head = _row(it)
        total = _count(it)
        if members:
            complete = (it.get("rolled_up_count") or 1) == len(members) + 1
            if complete and total is not None:
                head["rows_updated"] = _fmt_count(
                    total - sum(_count(m) or 0 for m in members))
            else:
                head["rows_updated"] = "—"
        rows.append(head)

    if decoration:
        rows = [r for r in rows if r["decoration"] == decoration]
    # Un-collapsing interleaves the groups, so re-sort or the rows come out grouped
    # rather than chronological.
    rows.sort(key=lambda r: r["_sort"], reverse=True)
    for r in rows:
        r.pop("_sort", None)

    if not rows:
        click.echo(f"No decoration refreshes recorded in the last {since or window}.")
        click.echo("A gap means nothing CHANGED — zero-row applies are not emitted.")
        click.echo("Last attempt either way:  torana decorations status")
        return

    output(
        {"items": rows, "total": len(rows)},
        fmt=fmt, raw=raw, fields=fields,
        columns=[
            ("when", "WHEN", 20),
            ("decoration", "DECORATION", 12),
            ("rows_updated", "ROWS UPDATED", 13),
            ("namespace", "NS", 10),
            ("title", "WHAT HAPPENED", 46),
        ],
    )


def _render_scheduler(payload, label):
    """Shared renderer for the two scheduler views.

    Both carry the leader-only trap, so both explain it the same way. Duplicating
    the wording would let the two explanations drift.
    """
    click.echo(f"{label}")
    click.echo(f"  id               : {payload.get('id')}")
    click.echo(f"  schedule         : {payload.get('schedule') or '— (not scheduled)'}")
    click.echo(f"  enabled          : {payload.get('enabled')}")
    click.echo(f"  registered       : {payload.get('registered')}")
    click.echo(f"  next_run_time    : {payload.get('next_run_time') or '(none)'}")
    if payload.get("env_var"):
        click.echo(f"  kill-switch env  : {payload.get('env_var')}")

    leader_only = payload.get("leader_only")
    answered_by_leader = payload.get("answered_by_leader")
    if leader_only:
        click.echo(f"  leader_only      : {leader_only}")
        click.echo(f"  answered_by_leader: {answered_by_leader}")
        if answered_by_leader is False and not payload.get("next_run_time"):
            # Without this the operator reads `next_run_time: null` as "the job is
            # not scheduled" and goes looking for a scheduling bug that is not there.
            click.echo(
                "\n  NOTE: this worker is NOT the scheduler leader, so a null "
                "next_run_time\n"
                "        is EXPECTED and does not mean the job is unscheduled. Only "
                "the leader\n"
                "        registers it. Re-run until a leader answers, or check the "
                "leader's logs."
            )


@decorations.command(name="scheduler")
@click.pass_context
def decorations_scheduler(ctx):
    """Every decoration-layer scheduled job, across both services.

    Unlike `producer-scheduler` (one job, integration-side), this returns the
    WHOLE set — the datalake apply tick and the integration producers — each with
    its own service, kill-switch env var and next run.
    """
    fmt, raw, fields = _fmt(ctx)
    client = _client(ctx)
    try:
        data = client.get("decorations/scheduler")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    payload = data or {}
    click.echo(f"scheduler_running : {payload.get('scheduler_running')}")
    jobs = payload.get("jobs") or []
    if not jobs:
        click.echo("\nNo scheduled decoration jobs reported.")
        return
    for job in jobs:
        click.echo(f"\n{job.get('name') or job.get('id')}  [{job.get('service')}]")
        click.echo(f"  id               : {job.get('id')}")
        click.echo(f"  schedule         : {job.get('schedule') or '— (not scheduled)'}")
        click.echo(f"  enabled          : {job.get('enabled')}")
        click.echo(f"  registered       : {job.get('registered')}")
        click.echo(f"  next_run_time    : {job.get('next_run_time') or '(none)'}")
        if job.get("env_var"):
            click.echo(f"  kill-switch env  : {job.get('env_var')}")
        # Same leader-only caveat as producer-scheduler: a null next_run_time on a
        # leader-only job read from a non-leader is EXPECTED, not a missing schedule.
        if job.get("leader_only"):
            click.echo(f"  leader_only      : {job.get('leader_only')}")
            click.echo(f"  answered_by_leader: {job.get('answered_by_leader')}")
            if job.get("answered_by_leader") is False and not job.get("next_run_time"):
                click.echo(
                    "  NOTE: answered by a NON-leader — a null next_run_time here is "
                    "expected,\n        not evidence the job is unscheduled."
                )


@decorations.command(name="producer-scheduler")
@click.pass_context
def decorations_producer_scheduler(ctx):
    """The PRODUCER cron (integration) — is fact production scheduled?

    Distinct from `scheduler`: this is the job that MAKES facts; that one APPLIES
    them. A break in either produces the same visible symptom (empty rows), which
    is why they are separate verbs.
    """
    fmt, raw, fields = _fmt(ctx)
    client = _client(ctx)
    try:
        data = client.get("decorations/producer-scheduler")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, raw=raw, fields=fields)
        return
    _render_scheduler(data or {}, "PRODUCER scheduler (integration)")


@decorations.command(name="refresh")
@click.argument("name", metavar="DECORATION")
@click.option("--yes", is_flag=True, help="Skip the confirmation prompt.")
@click.pass_context
def decorations_refresh(ctx, name, yes):
    """Force a producer run for DECORATION now (async, returns 202).

    This is the operator-reachable path that did not exist: when the scheduled
    producer has not run, nothing else makes threat intel reach already-ingested
    rows (functionality #94/#68).

    \b
    ⛔ A `global`-SCOPE DECORATION (cve_intel) IS PLATFORM ADMIN ONLY — 403 for a
    tenant admin, deliberately. It RE-READS THE WORLD: ~353k CVEs, a rewrite of the
    SHARED fact table, and an apply enqueued for EVERY tenant on the platform. One
    tenant pressing it rewrites every other tenant's rows, and it is the most
    memory-hungry job on the fleet (already SIGKILLed at 2.19 GiB peak).
    \b
    ⭐ If you are a TENANT and your new scan rows have no EPSS/KEV yet, you want
    `torana decorations reapply <name>` instead — it pushes the facts that ALREADY
    exist onto YOUR rows, reads no feed, and touches no other tenant.
    \b
    `tenant`-scope decorations (policy, governance_*) stay available to a tenant
    admin: they only ever read that tenant's own data.

    \b
    Examples:
      torana decorations refresh cve_intel      # platform admin (TORANA_PROFILE=SA/DSA)
      torana decorations refresh policy         # tenant-scope, tenant admin is fine
    """
    fmt, raw, fields = _fmt(ctx)
    # A refresh can re-read a 350k-row feed and rewrite fact tables, so it is
    # confirmed by default — cheap to re-run, but not something to fire blind.
    _confirm(f"Trigger a producer refresh for decoration '{name}'?", yes=yes)
    client = _client(ctx)
    try:
        data = client.post(f"decorations/{name}/refresh", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    click.echo(f"Refresh accepted for '{name}' (runs in the background).")
    for k, v in (data or {}).items():
        click.echo(f"  {k}: {v}")
    click.echo("\nFollow it with:  torana decorations jobs --decoration " + name)


@decorations.command(name="reapply")
@click.argument("name", metavar="DECORATION")
@click.option("--yes", is_flag=True, help="Skip the confirmation prompt.")
@click.pass_context
def decorations_reapply(ctx, name, yes):
    """Push the EXISTING facts onto YOUR OWN rows (async, 202). Tenant-safe.

    ⭐ THE TENANT HALF OF A REFRESH. `refresh` re-reads the world; this re-applies
    what has already been produced. Concretely it enqueues ONE apply job for your
    own (decoration, tenant, namespace) — the same unit of work the 06:30 cron
    enqueues — and reads no NVD, no EPSS, no CISA feed, and writes nothing global.
    No other tenant is affected.

    \b
    WHEN YOU WANT IT: you pushed a scan at 14:00. Those new vulnerability rows were
    not in the estate at 06:30, and there is no sink-write trigger — so they carry
    no EPSS score and no KEV flag until tomorrow's apply. This fills them in now.

    \b
    ⚠️ IT CANNOT INVENT FACTS. If the producer has never run for this decoration
    there is nothing to apply, and you get a 409 naming the daily schedule rather
    than a job that would write NULLs over your rows.

    \b
    ⚠️ Spamming it is harmless: jobs collapse on (decoration, tenant, namespace), so
    N calls fold into ONE pending job rather than queuing N full-table updates.

    \b
    Example:
      torana decorations reapply cve_intel
    """
    fmt, raw, fields = _fmt(ctx)
    # Confirmed, but with a MUCH milder warning than `refresh` — this rewrites only
    # the caller's own rows and reads no feed. Prompting identically for both would
    # flatten a real difference in blast radius.
    _confirm(
        f"Re-apply existing '{name}' facts to your own rows? "
        f"(no feed is read, no other tenant is affected)",
        yes=yes,
    )
    client = _client(ctx)
    try:
        data = client.post(f"decorations/{name}/reapply", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    payload = data or {}
    # ⚠️ `enqueued: false` is a SUCCESS — a job was already pending and this folded
    # into it. Printing the raw boolean alone would read as a failure.
    if payload.get("enqueued") is False:
        click.echo(f"A re-apply was ALREADY pending for '{name}' — this request folded "
                   f"into it (no second job queued).")
    else:
        click.echo(f"Re-apply queued for '{name}' (your namespace only).")
    for k in ("tenant_id", "namespace_id", "source_version"):
        if payload.get(k):
            click.echo(f"  {k}: {payload[k]}")
    click.echo("\nFollow it with:  torana decorations jobs --decoration " + name)


@decorations.command(name="retry")
@click.argument("job_key", metavar="JOB_KEY")
@click.pass_context
def decorations_retry(ctx, job_key):
    """Retry one failed apply job by its JOB_KEY (from `decorations jobs`)."""
    fmt, raw, fields = _fmt(ctx)
    client = _client(ctx)
    try:
        data = client.post(f"decorations/jobs/{job_key}/retry", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, raw=raw, fields=fields)
        return
    click.echo(f"Retry queued for job '{job_key}'.")
    for k, v in (data or {}).items():
        click.echo(f"  {k}: {v}")
