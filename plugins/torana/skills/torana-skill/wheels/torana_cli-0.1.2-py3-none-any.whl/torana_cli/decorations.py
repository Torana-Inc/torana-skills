"""torana decorations — inspect and trigger the decoration layer.

A DECORATION is an asserted fact joined onto sink rows at read time (KEV/EPSS
threat intel, SLA windows) rather than written by the ingest mapping. That split
is deliberate — see `pantheon-integration/torana_mesh/mappings/CLAUDE.md`
("Writers write only what they OBSERVED") — but it means an operator asking
"why is this vulnerability not enriched?" has to reason about a pipeline with
three separable failure points: the PRODUCER (are facts being made?), the APPLY
step (did they reach rows?), and the TRIGGER (did anything run?).

Before this group existed there was no CLI surface for any of it: diagnosing the
enrichment gap meant probing raw tables by guessing their names, and the only way
to force a refresh was curl against a service port. That is CLI-42 (no write
verb) and CLI-43 (no read verb).

⚠ LEADER-ONLY SCHEDULER. `producer-scheduler` is answered by whichever worker
handles the request, but the job is registered only on the LEADER. A non-leader
truthfully reports `next_run_time: null`, which reads as "never scheduled" and is
the wrong conclusion. Every renderer here surfaces `answered_by_leader` alongside
it so the distinction is visible rather than inferred.
"""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.confirm import confirm as _confirm


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    return ToranaClient(base_url=get_settings(profile).base_url)


def _fmt(ctx):
    """The (format, raw, fields) triple every command reads the same way."""
    if not ctx.obj:
        return "text", False, None
    return (
        ctx.obj.get(CTX_FORMAT, "text"),
        ctx.obj.get(CTX_RAW, False),
        ctx.obj.get(CTX_FIELDS),
    )


@click.group(name="decorations", invoke_without_command=True)
@click.pass_context
def decorations(ctx):
    """Decoration layer — read-time enrichment of sink rows (threat intel, SLA).

    A decoration is an ASSERTED fact (KEV/EPSS, SLA windows) joined onto rows at
    read time, not written by ingest. Use these verbs to answer "are facts being
    produced, did they reach the rows, and did anything actually run?".

    \b
    Examples:
      torana decorations list                  # what decorations exist
      torana decorations status                # per-decoration freshness + coverage
      torana decorations jobs                  # apply-job queue, incl. failures
      torana decorations scheduler             # the apply-side schedule
      torana decorations producer-scheduler    # the producer cron (leader-only!)
      torana decorations refresh cve_intel     # force a producer run now
      torana decorations retry <job_key>       # retry one failed apply job
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@decorations.command(name="list")
@click.pass_context
def decorations_list(ctx):
    """List the registered decorations and what each one decorates."""
    fmt, raw, fields = _fmt(ctx)
    client = _client(ctx)
    try:
        data = client.get("decorations")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Normalize the resource-named key to the {items,total} collection contract
    # in the COMMAND CORE, never at the render site — one place owns the shape.
    if isinstance(data, dict) and "decorations" in data:
        items = data.get("decorations") or []
        data = {
            "items": items,
            "total": data.get("total", len(items)),
            "page": 1,
            "page_size": len(items),
            # A distinct facet, not the list — kept as a sidecar.
            "column_precedence": data.get("column_precedence"),
        }

    output(
        data, fmt=fmt, raw=raw, fields=fields,
        columns=[
            ("name", "NAME", 18),
            ("decorates", "DECORATES", 18),
            ("subject_column", "SUBJECT COLUMN", 20),
            ("scope", "SCOPE", 10),
        ],
    )


@decorations.command(name="status")
@click.option("--decoration", "decoration", default=None,
              help="Only this decoration (e.g. cve_intel).")
@click.pass_context
def decorations_status(ctx, decoration):
    """Per-decoration freshness: is the source newer than what was applied?

    The load-bearing comparison is `source_version` vs `applied_version`. When
    they differ, facts exist that have NOT reached the rows — the exact state
    behind "the cache is full but every row is empty" (functionality #94/#68).
    """
    fmt, raw, fields = _fmt(ctx)
    client = _client(ctx)
    params = {"decoration": decoration} if decoration else None
    try:
        data = client.get("decorations/status", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    rows = (data or {}).get("decorations") or []
    if not rows:
        click.echo("No decorations reported.")
        return

    for d in rows:
        click.echo(f"\n{d.get('decoration')}")
        for ns in d.get("namespaces") or []:
            src, applied = ns.get("source_version"), ns.get("applied_version")
            # Surfaced as an explicit line rather than left for the reader to
            # diff two long ISO timestamps by eye.
            drift = "" if src == applied else "   ⚠ SOURCE NEWER THAN APPLIED"
            stale = ns.get("staleness_seconds")
            click.echo(f"  namespace        : {ns.get('namespace_id') or '(global)'}")
            click.echo(f"  status           : {ns.get('status')}{drift}")
            click.echo(f"  source_version   : {src}")
            click.echo(f"  applied_version  : {applied}")
            if stale is not None:
                click.echo(f"  staleness        : {round(float(stale) / 3600, 1)}h")
            if ns.get("pending_apply"):
                click.echo(f"  pending_apply    : {ns.get('pending_apply')}")
            if ns.get("error"):
                click.echo(f"  error            : {ns.get('error')}")


@decorations.command(name="jobs")
@click.option("--state", default=None,
              help="Filter by job state (e.g. pending, running, failed, succeeded).")
@click.option("--decoration", default=None, help="Filter by decoration name.")
@click.option("--limit", default=50, show_default=True, help="Max rows.")
@click.pass_context
def decorations_jobs(ctx, state, decoration, limit):
    """Apply-job queue — which decoration applies ran, and which failed."""
    fmt, raw, fields = _fmt(ctx)
    client = _client(ctx)
    params = {"limit": limit}
    if state:
        params["state"] = state
    if decoration:
        params["decoration"] = decoration
    try:
        data = client.get("decorations/jobs", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if isinstance(data, dict) and "jobs" in data:
        items = data.get("jobs") or []
        data = {
            "items": items,
            "total": data.get("total", len(items)),
            "page": 1,
            "page_size": data.get("limit", len(items)),
        }

    output(
        data, fmt=fmt, raw=raw, fields=fields,
        columns=[
            ("job_key", "JOB KEY", 30),
            ("decoration", "DECORATION", 14),
            ("state", "STATE", 10),
            ("attempt", "ATT", 4),
            ("max_attempts", "MAX", 4),
            ("generation", "GENERATION", 22),
        ],
    )


def _render_scheduler(payload, label):
    """Shared renderer for the two scheduler views.

    Both carry the leader-only trap, so both explain it the same way. Duplicating
    the wording would let the two explanations drift.
    """
    click.echo(f"{label}")
    click.echo(f"  id               : {payload.get('id')}")
    click.echo(f"  schedule         : {payload.get('schedule') or '— (not scheduled)'}")
    click.echo(f"  enabled          : {payload.get('enabled')}")
    click.echo(f"  registered       : {payload.get('registered')}")
    click.echo(f"  next_run_time    : {payload.get('next_run_time') or '(none)'}")
    if payload.get("env_var"):
        click.echo(f"  kill-switch env  : {payload.get('env_var')}")

    leader_only = payload.get("leader_only")
    answered_by_leader = payload.get("answered_by_leader")
    if leader_only:
        click.echo(f"  leader_only      : {leader_only}")
        click.echo(f"  answered_by_leader: {answered_by_leader}")
        if answered_by_leader is False and not payload.get("next_run_time"):
            # Without this the operator reads `next_run_time: null` as "the job is
            # not scheduled" and goes looking for a scheduling bug that is not there.
            click.echo(
                "\n  NOTE: this worker is NOT the scheduler leader, so a null "
                "next_run_time\n"
                "        is EXPECTED and does not mean the job is unscheduled. Only "
                "the leader\n"
                "        registers it. Re-run until a leader answers, or check the "
                "leader's logs."
            )


@decorations.command(name="scheduler")
@click.pass_context
def decorations_scheduler(ctx):
    """Every decoration-layer scheduled job, across both services.

    Unlike `producer-scheduler` (one job, integration-side), this returns the
    WHOLE set — the datalake apply tick and the integration producers — each with
    its own service, kill-switch env var and next run.
    """
    fmt, raw, fields = _fmt(ctx)
    client = _client(ctx)
    try:
        data = client.get("decorations/scheduler")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    payload = data or {}
    click.echo(f"scheduler_running : {payload.get('scheduler_running')}")
    jobs = payload.get("jobs") or []
    if not jobs:
        click.echo("\nNo scheduled decoration jobs reported.")
        return
    for job in jobs:
        click.echo(f"\n{job.get('name') or job.get('id')}  [{job.get('service')}]")
        click.echo(f"  id               : {job.get('id')}")
        click.echo(f"  schedule         : {job.get('schedule') or '— (not scheduled)'}")
        click.echo(f"  enabled          : {job.get('enabled')}")
        click.echo(f"  registered       : {job.get('registered')}")
        click.echo(f"  next_run_time    : {job.get('next_run_time') or '(none)'}")
        if job.get("env_var"):
            click.echo(f"  kill-switch env  : {job.get('env_var')}")
        # Same leader-only caveat as producer-scheduler: a null next_run_time on a
        # leader-only job read from a non-leader is EXPECTED, not a missing schedule.
        if job.get("leader_only"):
            click.echo(f"  leader_only      : {job.get('leader_only')}")
            click.echo(f"  answered_by_leader: {job.get('answered_by_leader')}")
            if job.get("answered_by_leader") is False and not job.get("next_run_time"):
                click.echo(
                    "  NOTE: answered by a NON-leader — a null next_run_time here is "
                    "expected,\n        not evidence the job is unscheduled."
                )


@decorations.command(name="producer-scheduler")
@click.pass_context
def decorations_producer_scheduler(ctx):
    """The PRODUCER cron (integration) — is fact production scheduled?

    Distinct from `scheduler`: this is the job that MAKES facts; that one APPLIES
    them. A break in either produces the same visible symptom (empty rows), which
    is why they are separate verbs.
    """
    fmt, raw, fields = _fmt(ctx)
    client = _client(ctx)
    try:
        data = client.get("decorations/producer-scheduler")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, raw=raw, fields=fields)
        return
    _render_scheduler(data or {}, "PRODUCER scheduler (integration)")


@decorations.command(name="refresh")
@click.argument("name", metavar="DECORATION")
@click.option("--yes", is_flag=True, help="Skip the confirmation prompt.")
@click.pass_context
def decorations_refresh(ctx, name, yes):
    """Force a producer run for DECORATION now (async, returns 202).

    This is the operator-reachable path that did not exist: when the scheduled
    producer has not run, nothing else makes threat intel reach already-ingested
    rows (functionality #94/#68).

    \b
    Example:
      torana decorations refresh cve_intel
    """
    fmt, raw, fields = _fmt(ctx)
    # A refresh can re-read a 350k-row feed and rewrite fact tables, so it is
    # confirmed by default — cheap to re-run, but not something to fire blind.
    _confirm(f"Trigger a producer refresh for decoration '{name}'?", yes=yes)
    client = _client(ctx)
    try:
        data = client.post(f"decorations/{name}/refresh", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    click.echo(f"Refresh accepted for '{name}' (runs in the background).")
    for k, v in (data or {}).items():
        click.echo(f"  {k}: {v}")
    click.echo("\nFollow it with:  torana decorations jobs --decoration " + name)


@decorations.command(name="retry")
@click.argument("job_key", metavar="JOB_KEY")
@click.pass_context
def decorations_retry(ctx, job_key):
    """Retry one failed apply job by its JOB_KEY (from `decorations jobs`)."""
    fmt, raw, fields = _fmt(ctx)
    client = _client(ctx)
    try:
        data = client.post(f"decorations/jobs/{job_key}/retry", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, raw=raw, fields=fields)
        return
    click.echo(f"Retry queued for job '{job_key}'.")
    for k, v in (data or {}).items():
        click.echo(f"  {k}: {v}")
