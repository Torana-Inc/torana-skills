"""Everything that must move together to fix a package: the lines the CLI prints for a stored set.

FIX_KNOWLEDGE_CONVERGENCE.md § 3.4 (W1). The set is computed once, by the shared library, inside the Atlas; DF stores
it on the alert. Every sentence here (`words`, `why`, `not_listed`, `label`) is the LIBRARY's / server's, printed
verbatim. This module only lays the lines out; it derives no state and writes no sentence of its own beyond the
fixed section names.

Used by `torana atlas provenance` (after the "Where the shipped version is set" line) and
`torana alert <id> fix-scope`.
"""

from typing import Any, Dict, List, Optional

DEFAULT_LABEL = "Everything that must move together"


def _place(p: Dict[str, Any]) -> str:
    where = str(p.get("file") or "")
    if p.get("line"):
        where += f":{p['line']}"
    tree = p.get("name") or p.get("tree") or str(p.get("repository") or "").removeprefix("repo:")
    return f"{tree} {where}".strip()


def _gaps(items: List[Dict[str, Any]]) -> List[str]:
    out = []
    for g in items or []:
        who = g.get("tree") or str(g.get("repository") or "").removeprefix("repo:") or "?"
        out.append(f"  ○ not checked: {who} — {g.get('why', '')}")
    return out


def move_set_lines(move_together: Optional[Dict[str, Any]], pins: Optional[Dict[str, Any]] = None) -> List[str]:
    """The set's lines, or [] when the answer carries neither.

    With a set (`move_together`, the answer had a fixed version): the server's label, one line per member and per
    review item (their `words`), what could not be decided or checked, then `not_listed`. With pins only (the
    answer had a range, no target): one line per pin and its role, no edits."""
    if move_together:
        ms = move_together
        lines = [f"{ms.get('label') or DEFAULT_LABEL}:"]
        for m in ms.get("members") or []:
            lines.append(f"  • {m.get('words') or _place(m)}")
            if m.get("needs_human"):
                lines.append(f"      ⚠ {m['needs_human']}")
        for r in ms.get("review") or []:
            lines.append(f"  ⚠ review: {r.get('words') or _place(r)}")
        for u in ms.get("undecidable") or []:
            lines.append(f"  ? {u.get('words') or (_place(u) + ' — ' + str(u.get('why', '')))}")
        lines += _gaps(ms.get("not_checked"))
        if ms.get("not_listed"):
            lines.append(f"  ⓘ {ms['not_listed']}")
        return lines
    if pins:
        lines = [f"Where {pins.get('package', 'the package')} is pinned (no fixed version, so no edits):"]
        for p in pins.get("pins") or []:
            spec = p.get("spec") or p.get("version") or ""
            lines.append(f"  • [{p.get('role')}] {_place(p)}" + (f" `{spec}`" if spec else ""))
        lines += _gaps(pins.get("not_checked"))
        return lines
    return []
