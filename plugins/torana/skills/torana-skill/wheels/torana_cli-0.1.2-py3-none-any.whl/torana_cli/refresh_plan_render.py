"""Render a transformer RefreshPlan (DT_MATERIALIZATION_POLICY_SPEC § 3.4.2).

⛔ RENDER, NEVER COMPUTE. The plan's `summary`, `explanation` and `schedule[].why` are printed
VERBATIM (U-13): the plan is the only producer of refresh explanations, so the CLI, the FE and
the API can never tell three different stories. This module only lays out structured fields.

Every verdict and mode is a GLYPH plus a WORD, never colour alone.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Optional

VERDICT_GLYPH = {"current": "✓", "live": "◇", "untracked": "·", "behind": "✗",
                 "clock_overdue": "✗", "failed": "✗", "never_built": "○", "dormant": "–",
                 "unknown": "?", "rebuild_queued": "⟳", "rebuilding": "⟳",
                 # #642. Without an entry the fallback is "?", which in this vocabulary means
                 # UNKNOWN — and an emptied relation is the opposite of unknown: the platform
                 # knows exactly what is wrong with it.
                 "emptied": "✗"}
#: § 3.2.5: counted even at 0 in every summary line, so "0 rebuilding" is an answer, not an
#: absence — and "current" is never the only word on a page while a rebuild is on its way.
ALWAYS_COUNTED = ("current", "rebuild_queued", "rebuilding")
MODE_GLYPH = {"event+clock": "⚡⏱", "event": "⚡", "clock": "⏱", "live": "◇", "manual": "✎",
              "dormant": "–"}


def verdict_label(v: Optional[str]) -> str:
    v = v or "unknown"
    return f"{VERDICT_GLYPH.get(v, '?')} {v.replace('_', ' ')}"


def summary_line(summary: Dict[str, int]) -> str:
    """`15 current · 3 rebuild queued · 0 rebuilding · 1 ✗ clock overdue` from the API's
    `summary` counts. Lays out only: every number is the server's."""
    summary = summary or {}
    parts = [f"{VERDICT_GLYPH.get(v, '?')} {int(summary.get(v) or 0)} {v.replace('_', ' ')}"
             for v in ALWAYS_COUNTED]
    parts += [f"{VERDICT_GLYPH.get(v, '?')} {n} {v.replace('_', ' ')}"
              for v, n in summary.items() if v not in ALWAYS_COUNTED and n]
    return " · ".join(parts)


def mode_label(m: Optional[str]) -> str:
    m = m or "—"
    return f"{MODE_GLYPH.get(m, '')} {m}".strip()


def _hm(iso: Optional[str], *, with_date: bool = False) -> str:
    if not iso:
        return "—"
    s = str(iso).replace("T", " ")
    if with_date:
        return s[:16] + " UTC" if "+" in s or s.endswith("Z") or len(s) >= 16 else s
    return s[11:16] + " UTC" if len(s) >= 16 else s


def _kind_phrase(kind: Optional[str]) -> str:
    return {"incremental": "incremental table", "table": "table", "view": "view",
            "phantom": "absent relation"}.get(kind or "", kind or "relation")


def render_plan(plan: Dict[str, Any]) -> List[str]:
    """The text layout of `torana datalake transformer <n> refresh-plan`."""
    st = plan.get("state") or {}
    out: List[str] = []
    head = (f"{plan.get('name')} — {_kind_phrase(plan.get('relation_kind'))} · "
            f"{mode_label(plan.get('mode'))} · {verdict_label(st.get('verdict'))}")
    out.append(head)
    if plan.get("declared_kind") and plan.get("declared_kind") != plan.get("relation_kind"):
        out.append(f"declared {plan.get('declared_kind')}")
    if st.get("verdict") in ("rebuild_queued", "rebuilding"):
        # The plan's own why says what moved; these are its structured facts.
        bits = [str(st.get("why") or "")]
        if st.get("build_id"):
            bits.append(f"build {str(st['build_id'])[:8]}")
        out.append("⟳ " + " · ".join(b for b in bits if b))
    out.append(str(plan.get("summary") or ""))
    out.append("")
    for line in plan.get("explanation") or []:
        out.append(f"  {line}")
    for a in plan.get("advice") or []:
        out.append(f"  advice: {a}")

    out.append("")
    out.append("TRIGGERS")
    trig = plan.get("triggers") or []
    if not trig:
        out.append("  (none — only a forced build rebuilds it)")
    for t in trig:
        k = t.get("kind")
        if k == "data":
            parts = [f"{i.get('name')} ({i.get('signal')} {_hm(i.get('last_changed_at'), with_date=True)})"
                     for i in t.get("inputs") or []]
            out.append(f"  {'data':9} " + (" · ".join(parts) or "—"))
        elif k == "clock":
            out.append(f"  {'clock':9} next {_hm(t.get('next_due_at'), with_date=True)} — "
                       f"{t.get('why')}")
        elif k == "upstream":
            out.append(f"  {'upstream':9} {', '.join(t.get('upstreams') or [])} — {t.get('why')}")
        else:
            out.append(f"  {str(k):9} {t.get('why')}")

    out.append("")
    out.append("SCHEDULE")
    for e in plan.get("schedule") or []:
        when = _hm(e.get("at"), with_date=True) if e.get("at") else (e.get("on") or "—")
        out.append(f"  {when:22} {str(e.get('trigger')):9} {e.get('why')}")

    views = plan.get("views_reading") or []
    if views:
        out.append("")
        out.append(f"VIEWS THAT READ THIS TABLE  {', '.join(views)}")

    el = plan.get("eligibility") or {}
    out.append("")
    enforced = "" if el.get("enforced") else " (shown, not yet enforced)"
    out.append(f"ELIGIBILITY  {el.get('tier')}{enforced} — {el.get('why')}"
               + ("  [consumer list partial]" if el.get("partial") else ""))

    rec = plan.get("recent") or []
    if rec:
        out.append("")
        out.append("RECENT REBUILDS")
        for r in rec:
            # BUILD = the first 8 of build_id, as `builds list` prints it; open it with
            # `torana datalake transformers build <id> show`. `—` = not part of a batch build.
            out.append(f"  {_hm(r.get('started_at'), with_date=True):22} "
                       f"{str(r.get('caller') or '—'):8} {str(r.get('status') or '—'):8} "
                       f"{str(r.get('build_id') or '—')[:8]:8} "
                       f"{', '.join(r.get('reasons') or []) or '—'}")
    pol = plan.get("policy") or {}
    if not pol.get("signals_available", True):
        out.append("")
        out.append(f"⚠ change signals unavailable: {pol.get('signals_error') or 'unknown'}")
    return out


def plans_rows(plans: Iterable[Dict[str, Any]]) -> List[Dict[str, str]]:
    """One row per plan for `refresh-plans`: NAME · MODE · NEXT · VERDICT · WHY."""
    rows = []
    for p in plans:
        st = p.get("state") or {}
        nxt = next((e for e in p.get("schedule") or [] if e.get("at")), None)
        nxt_s = _hm(nxt.get("at"), with_date=True) if nxt else (
            "on change" if any(e.get("on") for e in p.get("schedule") or []) else "—")
        rows.append({"name": p.get("name") or "", "mode": mode_label(p.get("mode")),
                     "next": nxt_s, "verdict": verdict_label(st.get("verdict")),
                     "why": str(st.get("why") or "")})
    return rows


def _grain_words(seconds) -> str:
    if not seconds:
        return "—"
    s = int(seconds)
    for unit, n in (("d", 86400), ("h", 3600), ("m", 60)):
        if s % n == 0:
            return f"{s // n}{unit}"
    return f"{s}s"


def profile_lines(defn) -> list:
    """The time profile a definition read carries (`with_profile=true`, § 3.2.2): the
    profile of ONE tenant's instance row, never of the template. Lays out fields only."""
    state = defn.get("time_profile_state")
    tenant = str(defn.get("time_profile_tenant_id") or "")[:8]
    if state is None:
        return []
    if state != "instantiated":
        return [f"  time      : not instantiated in tenant {tenant}"]
    tp = defn.get("time_profile") or {}
    if not tp:
        return [f"  time      : not profiled yet (tenant {tenant}; the boot backfill writes it)"]
    if not tp.get("dependent"):
        return [f"  time      : not time-dependent (tenant {tenant})"]
    head = (f"  time      : ⏱ time-dependent, grain {_grain_words(tp.get('grain_seconds'))} "
            f"({tp.get('grain_source') or '—'}"
            + (f", {tp['boundary']}" if tp.get("boundary") else "")
            + (", clamped to the floor" if tp.get("clamped") else "")
            + f") — tenant {tenant}")
    lines = [head]
    for x in (tp.get("expressions") or [])[:5]:
        lines.append(f"              {x}")
    if tp.get("parse_error"):
        lines.append(f"              parse error: {tp['parse_error']}")
    return lines


#: Worst first, matching the server's POLICY_SEVERITY. `emptied` (#642) ranks ahead of
#: `behind`: a relation serving zero rows while claiming to be built is more misleading than
#: one serving real, older rows. ⛔ Without an entry it took the .get default (3) and sorted
#: mid-table among the unknowns.
_FRESH_ORDER = {"emptied": -1,
                "behind": 0, "clock_overdue": 0, "failed": 1, "never_built": 2, "unknown": 3,
                "untracked": 4, "dormant": 5, "rebuild_queued": 6, "rebuilding": 6,
                "current": 7, "live": 8}


def freshness_report(pages: List[Dict[str, Any]]) -> Dict[str, Any]:
    """`derived-state freshness` from data-transformers' `refresh-plans` pages (Phase 4
    re-point). The verdict fields are copied from each plan's `state`; the header facts come
    from the response's `signals` block. Lays out only — no verdict is computed here."""
    first = pages[0] if pages else {}
    sig = first.get("signals") or {}
    rows = []
    for body in pages:
        for p in body.get("plans") or []:
            st = p.get("state") or {}
            rows.append({"id": p.get("transformer_id"), "name": p.get("name"),
                         "verdict": st.get("verdict"), "why": st.get("why"),
                         "built_at": st.get("built_at"),
                         "input_changed_at": st.get("input_changed_at"),
                         "changed_input": st.get("changed_input"),
                         "lag_seconds": st.get("lag_seconds"),
                         "via": st.get("via"),
                         "rebuild_due_at": st.get("rebuild_due_at"),
                         "reads_no_data": bool(st.get("reads_no_data"))})
    rows.sort(key=lambda r: (_FRESH_ORDER.get(r["verdict"] or "", 3), r["name"] or ""))
    return {"tenant_id": first.get("tenant_id"),
            "refresh_pending": bool(sig.get("refresh_pending")),
            "pending_since": sig.get("pending_since"),
            "last_marked_at": sig.get("last_marked_at"),
            "last_data_change_at": sig.get("last_data_change_at"),
            "summary": first.get("summary") or {},
            "tables": sig.get("tables") or {},
            "transformers": rows,
            "sources": ({"signals": {"error": sig.get("error")}}
                        if sig and not sig.get("available") else {}),
            "verdict_source": "data-transformers"}
