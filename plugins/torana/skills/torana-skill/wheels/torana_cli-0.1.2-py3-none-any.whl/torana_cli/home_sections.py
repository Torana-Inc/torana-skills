"""An app's Home as the server sends it: the card keys, and the text render of `sections`.

Spec: docs/specs/HOME_SURFACE_SPEC.md § 3.2, § 3.3.1, § 3.4.2.

⭐ NOTHING HERE DECIDES WHAT A CARD SAYS. Every card arrives as a block of finished lines
(pantheon_shared.proof.home_sections, `sections` on GET …/ai-home?kind=proven). The screen lays out each
line's `parts`; this prints each line's `text`. A line's `marker` is its meaning, and the glyph below is
only how a terminal shows it: shape carries the kind, never colour alone.
"""
import click

from torana_cli.section_descriptions import SECTION_DESCRIPTIONS

#: The ten cards, in page order, with what each shows (the `--section` keys; the API says `_` for `-`).
HOME_SECTIONS = SECTION_DESCRIPTIONS["home"]
HOME_SECTION_KEYS = tuple(HOME_SECTIONS)
#: A card's heading when the app's template does not list the card (`get --section KEY` on such an app).
FALLBACK_TITLES = {"act-first": "Act on these first", "summary": "Summary", "what-matters": "What matters to you",
                   "trust": "Trust", "health": "How this app is running", "needs-you": "Needs you",
                   "handled": "Handled for you", "rules": "Rules and alerts", "dashboards": "How things are going",
                   "blind": "What this page cannot see"}
#: marker → glyph: ✦ model-written, ◆ proven, ▲ needs attention, ◐ watch, ✓ fine, ○ switched off or never ran.
GLYPH = {"ai": "✦", "proven": "◆", "warn": "▲", "watch": "◐", "ok": "✓", "off": "○"}
#: A cited id the page's stored proof does not hold (the screen's words, v2-cites-drawer).
CITE_MISSING = "Not in this run's proof."
NOT_ON_THIS_HOME = "This app's Home does not have this card."
#: Line kinds whose commands are left out of the text (one per alert in a card: they are in the JSON).
_QUIET_COMMANDS = ("member",)


def api_key(cli_key: str) -> str:
    return cli_key.replace("-", "_")


def cli_key(key: str) -> str:
    return key.replace("_", "-")


def bold_marked(text) -> str:
    """The server marks the words to catch with `**…**`: print them bold."""
    parts = str(text or "").split("**")
    return "".join(click.style(p, bold=True) if i % 2 else p for i, p in enumerate(parts))


def block_of(sections, key: str):
    """The block for one CLI key, or None when this app's template does not list the card."""
    return next((b for b in sections or [] if b.get("key") == api_key(key)), None)


def cite_lines(cites, pad: str, show: bool) -> list:
    """Under a line: the count of proven facts it cites, or with `show` each one's id and stored text."""
    if not cites:
        return []
    n = len(cites)
    out = [f"{pad}◆ cites {n} proven fact{'' if n == 1 else 's'}"]
    if show:
        out += [f"{pad}  {c.get('id')}: {c.get('text') or CITE_MISSING}" for c in cites]
    return out


def line_lines(ln: dict, *, cites: bool = False, base: int = 2) -> list:
    """One line as printed: its glyph and text at its indent, then its cites and the commands that open it."""
    pad = " " * (base + 2 * int(ln.get("indent") or 0))
    glyph = GLYPH.get(ln.get("marker"))
    out = [f"{pad}{glyph + ' ' if glyph else ''}{bold_marked(ln.get('text'))}"]
    out += cite_lines(ln.get("cites"), pad + "    ", cites)
    if ln.get("kind") not in _QUIET_COMMANDS:
        out += [f"{pad}    → {c}" for c in ln.get("commands") or []]
    return out


def block_lines(block: dict, *, cites: bool = False) -> list:
    """One card: its heading, what it shows, its notes, then its lines, or the sentence that says why it has none."""
    key = cli_key(block.get("key") or "")
    out = ["", f"{block.get('title') or FALLBACK_TITLES.get(key, key)}   [{key}]"]
    if block.get("description"):
        out.append(f"  {block['description']}")
    out += [f"  {n}" for n in block.get("notes") or []]
    for ln in block.get("lines") or []:
        out += line_lines(ln, cites=cites)
    if not block.get("lines"):
        why = block.get("unavailable") or block.get("empty")
        if why:
            out.append(f"  {'▲ ' if block.get('unavailable') else ''}{why}")
    return out


def hidden_line(report: dict, hidden: list):
    """The one line that stands for the sections this app's profile does not draw, or None. Their titles are the
    app's own; each is still printed by `get --section <key>`."""
    if not hidden:
        return None
    titles = {b.get("key"): b.get("title") for b in report.get("sections") or []}
    names = [str(titles.get(k) or FALLBACK_TITLES.get(cli_key(k), k)) for k in hidden]
    return f"Hidden by this app: {', '.join(names)}.  (`get --section <name>` prints one)"


def missing_block_lines(key: str) -> list:
    return ["", f"{FALLBACK_TITLES.get(key, key)}   [{key}]", f"  {NOT_ON_THIS_HOME}"]


def stamp_line(report: dict) -> str:
    """The line above the page: its window, when it was prepared, and which run it is."""
    from torana_cli.ai_home import _ago
    window = (report.get("window") or {}).get("label") or "Home"
    gen = f" · prepared {_ago(report['generated_at'])}" if report.get("generated_at") else ""
    how = " · scheduled" if report.get("trigger") == "scheduled" else ""
    app = f" · {report['app_label']}" if report.get("app_label") else ""
    return f"{window}{gen}{how}{app}   (run {report.get('run_id')})"


def changes_line(report: dict):
    """Under the stamp: the server's sentence when items the page describes changed after it was prepared (or
    could not be checked). The marked lines themselves are in the needs-you card. None when nothing to say."""
    ch = report.get("changes") or {}
    note = ch.get("note")
    if not note:
        return None
    return f"{note}   → torana app {report.get('app_id')} ai-home get --section needs-you"


def item_group(sections, alert_id: str):
    """(block, lines) for the Needs-you card one alert belongs to: its card line, or its own row, down to the next
    card. None when the alert is not on the page. The alert may be a card's lead, its brief target, or a member."""
    block = block_of(sections, "needs-you")
    lines = (block or {}).get("lines") or []
    hit = next((i for i, ln in enumerate(lines) if _names(ln, alert_id)), None)
    if hit is None:
        return None
    start = hit
    while start > 0 and int(lines[start].get("indent") or 0) > 0:
        start -= 1
    end = start + 1
    while end < len(lines) and int(lines[end].get("indent") or 0) > 0:
        end += 1
    return block, lines[start:end]


def _names(ln: dict, alert_id: str) -> bool:
    p = ln.get("parts") or {}
    return alert_id in (p.get("alert_id"), p.get("lead"), p.get("brief")) and ln.get("kind") in ("card", "row", "member")
