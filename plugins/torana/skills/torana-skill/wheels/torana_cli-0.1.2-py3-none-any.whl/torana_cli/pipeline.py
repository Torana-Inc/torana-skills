"""torana pipeline — detection pipeline diagnostics (SA only).

Read-only views over the detection-framework durable queues
(rule_run_jobs, detection_signals, alert_events, action_jobs, agent_invocation_queue):
whole-pipeline status, per-queue overview / per-tenant depth, the worker fleet
roster, and an end-to-end correlation-id trace.

Backed by GET /api/v1/pipeline/* (permission rule-run-queue:read). These are
collection/diagnostic reads, so they live in one flat group rather than a
plural/singular split.
"""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output

# Valid queue keys for the per-queue endpoints (mirrors PIPELINE_QUEUES in the
# detection-framework service). Surfaced in --help and validated client-side so
# a typo gets a clear message instead of a raw 404.
_QUEUE_KEYS = ["rule_run", "signals", "alert_events", "action_jobs", "agent_invocation"]

# Drill-down (`pipeline queue`) maps the pipeline key → the underlying queue table, read
# via the admin table-data API (cursor-paginated). Mirrors the FE queue-entries page so
# the CLI drill-down is on par. Only agent_invocation_queue carries `last_error_kind`, so
# the recoverable/permanent buckets apply only there.
_DETECTION_SERVICE = "pantheon-detection-framework"
_KEY_TO_TABLE = {
    "rule_run": "rule_run_jobs",
    "signals": "detection_signals",
    "alert_events": "alert_events",
    "action_jobs": "action_jobs",
    "agent_invocation": "agent_invocation_queue",
}
_RECOVERABLE_QUEUE = "agent_invocation"

# Per-queue identity for the `queues` catalog (key → table, subsystem, one-line role).
# Subsystem labels mirror the FE rules-and-alerts queue-entries page. Pure static
# metadata — `pipeline queues` needs no API call, it's a discoverability aid so users
# don't have to memorise the five keys / their tables / which buckets apply.
_QUEUE_CATALOG = {
    "rule_run":         {"table": "rule_run_jobs",          "subsystem": "Subsystem 1", "role": "Rule execution jobs"},
    "signals":          {"table": "detection_signals",      "subsystem": "Subsystem 2", "role": "Correlation signals"},
    "alert_events":     {"table": "alert_events",            "subsystem": "Subsystem 2", "role": "Alert routing events"},
    "action_jobs":      {"table": "action_jobs",             "subsystem": "Subsystem 2", "role": "Action dispatch jobs"},
    "agent_invocation": {"table": "agent_invocation_queue",  "subsystem": "Subsystem 3", "role": "Agent invocation queue"},
}

_QUEUE_CATALOG_COLS = [
    ("key", "KEY", 16),
    ("subsystem", "SUBSYSTEM", 12),
    ("table", "TABLE", 24),
    ("role", "ROLE", 24),
    ("buckets", "BUCKETS", 60),
]

# bucket → filter[field][op]=value predicates (reproduce the home-page derived states).
# 'retrying' approximates as queued+attempts>0 (next_visible_at>now isn't expressible via
# the generic filter API) — same approximation the FE uses.
_BUCKETS = {
    "all":              [],
    "ready":            [("status", "eq", "queued"), ("attempts", "eq", "0")],
    "retrying":         [("status", "eq", "queued"), ("attempts", "gt", "0")],
    "running":          [("status", "eq", "running")],
    "dead":             [("status", "eq", "dead")],
    "dead-recoverable": [("status", "eq", "dead"), ("last_error_kind", "in", "transient,rate_limit")],
    "dead-permanent":   [("status", "eq", "dead"), ("last_error_kind", "not_in", "transient,rate_limit")],
    "succeeded":        [("status", "eq", "succeeded")],
}
# Buckets valid per queue (recoverable/permanent only where last_error_kind exists).
_BUCKETS_RECOVERABLE = ["all", "ready", "retrying", "running", "dead-recoverable", "dead-permanent", "succeeded"]
_BUCKETS_PLAIN = ["all", "ready", "retrying", "running", "dead", "succeeded"]

# Columns surfaced first in the row table (the meaningful substrate fields).
_ITEM_COLS = [
    ("id", "ID", 38),
    ("status", "STATUS", 10),
    ("last_error_kind", "ERR_KIND", 10),
    ("attempts", "ATT", 4),
    ("enqueued_at", "ENQUEUED", 26),
    ("finished_at", "FINISHED", 26),
    ("alert_id", "ALERT_ID", 38),
]

_QUEUE_COLS = [
    ("subsystem", "SUBSYSTEM", 18),
    ("key", "KEY", 14),
    ("depth", "IN_FLIGHT", 10),
    ("queued", "QUEUED", 8),
    ("retrying", "RETRYING", 9),      # mid-backoff, riding out a dependency outage
    ("running", "RUNNING", 8),
    ("dead_recoverable", "DEAD·REC", 9),   # re-runnable via `pipeline requeue`
    ("dead_permanent", "DEAD·PERM", 10),   # broken — investigate
    ("throughput_per_min", "THRU/MIN", 9),
    ("oldest_queued_age_seconds", "OLDEST_S", 10),
]

_WORKER_COLS = [
    ("worker_id", "WORKER", 28),
    ("subsystem", "SUBSYSTEM", 18),
    ("host", "HOST", 18),
    ("pid", "PID", 8),
    ("jobs_in_flight", "IN_FLIGHT", 10),
    ("last_seen_age_seconds", "LAST_SEEN_S", 12),
    ("stale", "STALE", 6),
]

_TENANT_COLS = [
    ("tenant_id", "TENANT_ID", 36),
    ("queued", "QUEUED", 8),
    ("running", "RUNNING", 8),
    ("claimed", "CLAIMED", 8),
    ("dead", "DEAD", 6),
]

# Queues whose dead jobs carry a recoverable/permanent classification (requeue target).
_REQUEUE_HINT = (
    "QUEUE_KEY one of: rule_run | signals | alert_events | action_jobs | agent_invocation"
)


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _fmt(ctx):
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    return fmt, raw, fields


def _validate_queue(queue_key):
    if queue_key not in _QUEUE_KEYS:
        click.echo(
            f"ERROR: unknown queue '{queue_key}'. Valid: {', '.join(_QUEUE_KEYS)}.",
            err=True,
        )
        raise SystemExit(6)


@click.group()
def pipeline():
    """Detection pipeline diagnostics (SA only).

    \b
    Examples:
      torana pipeline status
      torana pipeline status --window-seconds 600
      torana pipeline queues list                            # list the detection queues
      torana pipeline queue rule_run entries list --bucket dead  # drill into one queue's rows
      torana pipeline queue rule_run entry <ENTRY_ID> get    # one job (entry <id> get)
      torana pipeline overview rule_run
      torana pipeline by-tenant agent_invocation
      torana pipeline workers
      torana pipeline trace <CORRELATION_ID>
    """


@pipeline.command(name="status")
@click.option("--window-seconds", "window_seconds", type=click.IntRange(30, 3600),
              default=None,
              help="Throughput window in seconds (rate = items finished in this "
                   "window). Range 30-3600. Server default is 300 when omitted.")
@click.option("--tenant-id", "tenant_id", default=None,
              help="Scope every queue's metrics to one tenant (UUID). "
                   "Omit for the global aggregate across all tenants.")
@click.pass_context
def pipeline_status(ctx, window_seconds, tenant_id):
    """Whole-pipeline status across every detection queue.

    \b
    Each queue's depth-by-status + oldest-queued age + recent throughput, in
    pipeline order, plus rolled-up totals (in_flight depth, dead, 'moving' flag).
    The time window and tenant scope are optional:

    \b
      torana pipeline status                            # global, server default (300s)
      torana pipeline status --window-seconds 600
      torana pipeline status --tenant-id <TENANT_UUID>  # scope to one tenant
    """
    fmt, raw, fields = _fmt(ctx)
    params = {}
    if window_seconds is not None:
        params["window_seconds"] = window_seconds
    if tenant_id:
        params["tenant_id"] = tenant_id

    client = _client(ctx)
    try:
        data = client.get("pipeline/status", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml") or raw:
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    queues = data.get("queues", []) if isinstance(data, dict) else []
    totals = data.get("totals", {}) if isinstance(data, dict) else {}
    win = data.get("window_seconds", window_seconds or 300) if isinstance(data, dict) else window_seconds
    moving = totals.get("moving")
    moving_str = (
        click.style("MOVING ✓", fg="green") if moving
        else click.style("STALLED ✗", fg="red") if moving is not None
        else "n/a"
    )
    retrying = totals.get("retrying", 0)
    dead_rec = totals.get("dead_recoverable", 0)
    dead_perm = totals.get("dead_permanent", 0)
    retry_str = (click.style(f"retrying={retrying}", fg="yellow") if retrying
                 else f"retrying={retrying}")
    dead_str = f"dead={totals.get('dead', 'n/a')}"
    if dead_rec:
        dead_str += click.style(f" (recoverable={dead_rec}", fg="yellow") + \
            f" permanent={dead_perm})"
    elif dead_perm:
        dead_str += f" (permanent={dead_perm})"
    click.echo(
        f"pipeline status  (window={win}s)  "
        f"in_flight={totals.get('in_flight_depth', 'n/a')}  "
        f"{retry_str}  {dead_str}  {moving_str}"
    )
    if dead_rec:
        click.echo(click.style(
            f"  ↻ {dead_rec} recoverable dead job(s) — revive with: "
            f"torana pipeline requeue <queue> --recoverable-only", fg="cyan"))
    output({"items": queues, "total": len(queues)}, fmt="table",
           fields=fields, columns=_QUEUE_COLS)


@pipeline.command(name="overview")
@click.argument("queue_key", metavar="QUEUE_KEY")
@click.option("--window-seconds", "window_seconds", type=click.IntRange(30, 3600),
              default=None, help="Throughput window in seconds (30-3600, default 300).")
@click.option("--tenant-id", "tenant_id", default=None,
              help="Scope this queue's metrics to one tenant (UUID). "
                   "Omit for the global aggregate across all tenants.")
@click.pass_context
def pipeline_overview(ctx, queue_key, window_seconds, tenant_id):
    """One queue's overview by pipeline key.

    \b
    QUEUE_KEY one of: rule_run | signals | alert_events | action_jobs | agent_invocation
    """
    _validate_queue(queue_key)
    fmt, raw, fields = _fmt(ctx)
    params = {}
    if window_seconds is not None:
        params["window_seconds"] = window_seconds
    if tenant_id:
        params["tenant_id"] = tenant_id

    client = _client(ctx)
    try:
        data = client.get(f"pipeline/{queue_key}/overview", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@pipeline.command(name="by-tenant")
@click.argument("queue_key", metavar="QUEUE_KEY")
@click.option("--limit", type=click.IntRange(1, 100), default=50, show_default=True,
              help="Max tenants to return.")
@click.pass_context
def pipeline_by_tenant(ctx, queue_key, limit):
    """Per-tenant depth for one queue — who is consuming it.

    \b
    QUEUE_KEY one of: rule_run | signals | alert_events | action_jobs | agent_invocation
    """
    _validate_queue(queue_key)
    fmt, raw, fields = _fmt(ctx)

    client = _client(ctx)
    try:
        data = client.get(f"pipeline/{queue_key}/by-tenant", params={"limit": limit})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml") or raw:
        output(data, fmt=fmt, raw=raw, fields=fields)
        return
    tenants = data.get("tenants", []) if isinstance(data, dict) else []
    output({"items": tenants, "total": len(tenants)}, fmt="table",
           fields=fields, columns=_TENANT_COLS)


@pipeline.command(name="workers")
@click.option("--stale-seconds", "stale_seconds", type=click.IntRange(30, 600),
              default=90, show_default=True,
              help="last_seen older than this flags a worker stale.")
@click.pass_context
def pipeline_workers(ctx, stale_seconds):
    """The multi-worker fleet roster — which workers are alive, by subsystem,
    with stale (dead/wedged) ones flagged."""
    fmt, raw, fields = _fmt(ctx)

    client = _client(ctx)
    try:
        data = client.get("pipeline/workers", params={"stale_seconds": stale_seconds})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml") or raw:
        output(data, fmt=fmt, raw=raw, fields=fields)
        return
    workers = data.get("workers", []) if isinstance(data, dict) else []
    output({"items": workers, "total": len(workers)}, fmt="table",
           fields=fields, columns=_WORKER_COLS)


@pipeline.command(name="trace")
@click.argument("correlation_id", metavar="CORRELATION_ID")
@click.pass_context
def pipeline_trace(ctx, correlation_id):
    """End-to-end trace — walk the full rule_run -> signal -> finding -> action ->
    triage chain for one correlation_id, with timing + which worker ran each stage."""
    fmt, raw, fields = _fmt(ctx)

    client = _client(ctx)
    try:
        data = client.get(f"pipeline/trace/{correlation_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@pipeline.command(name="invocation-monitor")
@click.pass_context
def pipeline_invocation_monitor(ctx):
    """Phase-2 monitor view — in-flight (dispatched, caller-polled) playbook invocations:
    how many are running on a workflow-framework handle, the oldest one's age, how many
    are over deadline (about to be cancelled), plus recent playbook succeeded/dead rates
    and triage in-flight."""
    fmt, raw, fields = _fmt(ctx)

    client = _client(ctx)
    try:
        data = client.get("pipeline/invocation-monitor")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@pipeline.command(name="requeue")
@click.argument("queue_key", metavar="QUEUE_KEY")
@click.option("--recoverable-only/--all", "recoverable_only", default=True,
              show_default=True,
              help="Requeue only RECOVERABLE dead jobs (dependency-outage / retries-exhausted). "
                   "--all force-requeues every dead job (explicit override).")
@click.option("--tenant-id", "tenant_id", default=None,
              help="Scope the requeue to one tenant; omit for all tenants.")
@click.option("--limit", type=click.IntRange(1, 5000), default=1000, show_default=True,
              help="Max rows to requeue in one call (re-run to drain more).")
@click.option("--dry-run", is_flag=True, default=False,
              help="Show the eligible count WITHOUT requeuing anything.")
@click.pass_context
def pipeline_requeue(ctx, queue_key, recoverable_only, tenant_id, limit, dry_run):
    """Revive dead-letter jobs back into the queue (flips dead -> queued).

    Recoverable dead jobs are ones that dead-lettered because a dependency was down
    (transient / rate-limit) or retries exhausted — re-runnable once the dependency is
    back. Permanent / cancelled dead jobs are left alone unless --all is given.

    \b
    QUEUE_KEY one of: rule_run | signals | alert_events | action_jobs | agent_invocation

    \b
    Examples:
      torana pipeline requeue agent_invocation --dry-run          # preview eligible count
      torana pipeline requeue agent_invocation                    # requeue recoverable
      torana pipeline requeue agent_invocation --tenant-id <UUID> # scope to one tenant
      torana pipeline requeue agent_invocation --all              # force-requeue ALL dead
    """
    _validate_queue(queue_key)
    fmt, raw, fields = _fmt(ctx)

    body = {
        "recoverable_only": recoverable_only,
        "limit": limit,
        "dry_run": dry_run,
    }
    if tenant_id:
        body["tenant_id"] = tenant_id

    client = _client(ctx)
    try:
        data = client.post(f"pipeline/{queue_key}/requeue", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml") or raw:
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    eligible = data.get("eligible", 0)
    requeued = data.get("requeued", 0)
    if dry_run:
        click.echo(click.style(
            f"dry-run: {eligible} dead job(s) in '{queue_key}' eligible for requeue "
            f"({'recoverable-only' if recoverable_only else 'ALL'}). "
            f"Re-run without --dry-run to requeue.", fg="cyan"))
    else:
        click.echo(click.style(
            f"requeued {requeued} of {eligible} eligible dead job(s) in '{queue_key}' "
            f"→ queued (will be reprocessed).", fg="green"))
        if requeued < eligible:
            click.echo(f"  {eligible - requeued} remain — re-run to drain more "
                       f"(--limit was {limit}).")


def _valid_buckets(queue_key):
    return _BUCKETS_RECOVERABLE if queue_key == _RECOVERABLE_QUEUE else _BUCKETS_PLAIN


def _normalize_bucket(queue_key, bucket):
    """Coerce a requested bucket to one valid for the queue — dead-recoverable/permanent
    on a queue without last_error_kind collapses to 'dead' (matches the FE)."""
    valid = _valid_buckets(queue_key)
    if bucket in valid:
        return bucket
    if bucket in ("dead-recoverable", "dead-permanent"):
        return "dead" if "dead" in valid else "all"
    return "all"


# ──────────────────────────────────────────────────────────────────────────────
# Queue catalog + drill-down, modelled as a coherent hierarchy:
#
#   torana pipeline queues list                          # the queue catalog
#   torana pipeline queue <KEY> entries list [--bucket]  # entries in that queue
#   torana pipeline queue <KEY> entry get <ID>           # one entry in full
#
# A queue CONTAINS entries — `queue <KEY>` is a singular group, with `entries`
# (collection) and `entry <ID>` (instance) nested inside it. Every leaf has an
# explicit verb; nothing lists implicitly. Mirrors the CLI plural/singular split.
# ──────────────────────────────────────────────────────────────────────────────

def _qkey(ctx) -> str:
    return ctx.obj.get("_queue_key", "") if ctx.obj else ""


def _eid(ctx) -> str:
    return ctx.obj.get("_entry_id", "") if ctx.obj else ""


@pipeline.group(name="queues")
def pipeline_queues():
    """The detection pipeline queue catalog.

    \b
    Example:
      torana pipeline queues list
    """


@pipeline_queues.command(name="list")
@click.pass_context
def pipeline_queues_list(ctx):
    """List the detection pipeline queues — the catalog of queue keys you can drill into.

    \b
    Pure metadata (no API call): each queue's pipeline key, subsystem, underlying
    table, role, and which lifecycle buckets apply. Use the KEY with
    `queue <KEY> entries list` to list that queue's entries.
    """
    fmt, raw, fields = _fmt(ctx)
    rows = [
        {
            "key": key,
            "subsystem": meta["subsystem"],
            "table": meta["table"],
            "role": meta["role"],
            "buckets": " ".join(_valid_buckets(key)),
        }
        for key, meta in _QUEUE_CATALOG.items()
    ]
    if fmt in ("json", "yaml") or raw:
        output({"items": rows, "total": len(rows)}, fmt=fmt, raw=raw, fields=fields)
        return
    output({"items": rows, "total": len(rows)}, fmt="table",
           fields=fields, columns=_QUEUE_CATALOG_COLS)
    click.echo(click.style(
        "\ndrill in: torana pipeline queue <KEY> entries list [--bucket <BUCKET>]", fg="cyan"))


@pipeline.group(name="queue", invoke_without_command=True)
@click.argument("queue_key", metavar="QUEUE_KEY")
@click.pass_context
def pipeline_queue(ctx, queue_key):
    """One detection queue, by pipeline key — its entries live underneath.

    \b
    QUEUE_KEY one of: rule_run | signals | alert_events | action_jobs | agent_invocation
    (see `torana pipeline queues list` for the catalog).

    \b
    Examples:
      torana pipeline queue agent_invocation entries list --bucket retrying
      torana pipeline queue rule_run entry get <ENTRY_ID>
    """
    _validate_queue(queue_key)
    ctx.ensure_object(dict)
    ctx.obj["_queue_key"] = queue_key
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@pipeline_queue.group(name="entries")
def pipeline_queue_entries():
    """Entries (rows) in this queue."""


@pipeline_queue_entries.command(name="list")
@click.option("--bucket", "bucket", default="all", show_default=True,
              help="Lifecycle bucket: all | ready | retrying | running | dead | "
                   "dead-recoverable | dead-permanent | succeeded "
                   "(recoverable/permanent only for agent_invocation).")
@click.option("--tenant-id", "tenant_id", default=None, help="Scope to one tenant.")
@click.option("--limit", type=click.IntRange(1, 1000), default=25, show_default=True,
              help="Max rows per page.")
@click.option("--cursor", "cursor", default=None, help="Cursor for the next page (from a prior call).")
@click.pass_context
def pipeline_queue_entries_list(ctx, bucket, tenant_id, limit, cursor):
    """List this queue's ENTRIES (rows), cursor-paginated — the CLI drill-down,
    on par with the FE rules-and-alerts queue-entries page.

    \b
    Examples:
      torana pipeline queue agent_invocation entries list --bucket retrying
      torana pipeline queue agent_invocation entries list --bucket dead-recoverable --tenant-id <UUID>
      torana pipeline queue rule_run entries list --bucket dead --limit 50
      torana pipeline queue agent_invocation entries list --cursor <NEXT_CURSOR>   # next page
    """
    queue_key = _qkey(ctx)
    fmt, raw, fields = _fmt(ctx)
    table = _KEY_TO_TABLE[queue_key]
    bucket = _normalize_bucket(queue_key, bucket)

    params = {"limit": limit, "order_by": "enqueued_at:desc"}
    if cursor:
        params["cursor"] = cursor
    # is_deleted=false + the bucket predicates + optional tenant scope.
    preds = [("is_deleted", "eq", "false"), *(_BUCKETS.get(bucket) or [])]
    if tenant_id:
        preds.append(("tenant_id", "eq", tenant_id))
    for field, op, value in preds:
        params[f"filter[{field}][{op}]"] = value

    client = _client(ctx)
    try:
        data = client.get(f"services/{_DETECTION_SERVICE}/tables/{table}/data", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    rows = data.get("data", []) if isinstance(data, dict) else []
    pagination = data.get("pagination", {}) if isinstance(data, dict) else {}
    if fmt in ("json", "yaml") or raw:
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    click.echo(f"{table}  bucket={bucket}"
               + (f"  tenant={tenant_id}" if tenant_id else "")
               + f"  ({len(rows)} rows)")
    output({"items": rows, "total": len(rows)}, fmt="table", fields=fields, columns=_ITEM_COLS)
    nxt = pagination.get("next_cursor")
    if nxt:
        click.echo(click.style(
            f"\nmore rows — next page: torana pipeline queue {queue_key} entries list "
            f"--bucket {bucket} --cursor {nxt}", fg="cyan"))


@pipeline_queue.group(name="entry", invoke_without_command=True)
@click.argument("entry_id", metavar="ENTRY_ID")
@click.pass_context
def pipeline_queue_entry(ctx, entry_id):
    """A single ENTRY (job) in this queue, by id.

    \b
    Examples:
      torana pipeline queue rule_run entry <ENTRY_ID> get
      torana pipeline queue agent_invocation entry <ENTRY_ID> provenance
    """
    ctx.ensure_object(dict)
    ctx.obj["_entry_id"] = entry_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _fetch_entry_row(client, table, entry_id):
    """Fetch one queue row by id via the admin table-data API, or None."""
    data = client.get(
        f"services/{_DETECTION_SERVICE}/tables/{table}/data",
        params={"limit": 1, "filter[id][eq]": entry_id},
    )
    rows = data.get("data", []) if isinstance(data, dict) else []
    return rows[0] if rows else None


@pipeline_queue_entry.command(name="get")
@click.pass_context
def pipeline_queue_entry_get(ctx):
    """Show this ENTRY in full (the single-job detail) — what the FE drawer shows."""
    queue_key = _qkey(ctx)
    entry_id = _eid(ctx)
    fmt, raw, fields = _fmt(ctx)
    table = _KEY_TO_TABLE[queue_key]

    client = _client(ctx)
    try:
        row = _fetch_entry_row(client, table, entry_id)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if not row:
        click.echo(f"No entry '{entry_id}' in {table}.", err=True)
        raise SystemExit(3)

    if fmt in ("json", "yaml") or raw:
        output(row, fmt=fmt, raw=raw, fields=fields)
        return

    # Recoverability verdict (mirrors the FE detail header).
    verdict = "n/a"
    if row.get("status") == "dead":
        kind = row.get("last_error_kind")
        att, mx = row.get("attempts"), row.get("max_attempts")
        if kind in ("transient", "rate_limit") or (att is not None and mx is not None and att >= mx):
            verdict = "recoverable — re-runnable"
        else:
            verdict = "permanent — broken"
    click.echo(f"{table}  {row.get('id')}")
    click.echo(f"  status={row.get('status')}  recoverability={verdict}")
    click.echo("")
    for k in sorted(row.keys()):
        click.echo(f"  {k:24} {row[k]}")


def _fmt_ts(v):
    """Trim an ISO timestamp to seconds for compact display, or '—'."""
    if not v:
        return "—"
    s = str(v)
    return s[:19].replace("T", " ") if len(s) >= 19 else s


def _actor_label(rule_run):
    """Who/what triggered this run, from trigger_context. user → name (email);
    scheduler/api/suite → their identifying id; missing → 'unknown'."""
    tctx = (rule_run or {}).get("trigger_context") or {}
    if not isinstance(tctx, dict) or not tctx:
        return "unknown"
    kind = tctx.get("actor_type")
    if kind == "user":
        name = tctx.get("actor_name")
        email = tctx.get("email")
        if name and email:
            return f"{name} ({email})"
        return name or email or tctx.get("user_id") or "user"
    if kind == "suite":
        who = tctx.get("triggered_by_user_id")
        sid = (tctx.get("suite_run_id") or "")[:8]
        return f"suite {sid}…" + (f" (by {who})" if who else "")
    if kind == "scheduler":
        return f"scheduler {tctx.get('schedule_id', '')}".strip()
    if kind == "api":
        return f"api {tctx.get('client_id', '')}".strip()
    return kind or "unknown"


@pipeline_queue_entry.command(name="provenance")
@click.pass_context
def pipeline_queue_entry_provenance(ctx):
    """Show how this ENTRY came to exist — the full provenance + audit chain.

    \b
    Walks bottom→top: the originating RULE and how it was triggered (manual /
    scheduled / suite), the rule run, the alert (finding), and every pipeline
    stage it passed through — each with status + timing. Pivots through the
    entry's alert_id (a hard FK), so it works even when the queue row itself
    carries no correlation_id.

    \b
    Example:
      torana pipeline queue agent_invocation entry <ENTRY_ID> provenance
    """
    queue_key = _qkey(ctx)
    entry_id = _eid(ctx)
    fmt, raw, fields = _fmt(ctx)
    table = _KEY_TO_TABLE[queue_key]

    client = _client(ctx)
    try:
        row = _fetch_entry_row(client, table, entry_id)
        if not row:
            click.echo(f"No entry '{entry_id}' in {table}.", err=True)
            raise SystemExit(3)
        alert_id = row.get("alert_id")
        if not alert_id:
            click.echo(f"Entry '{entry_id}' has no alert_id — cannot trace provenance "
                       f"(only alert-bearing queues like agent_invocation have it).", err=True)
            raise SystemExit(6)
        trace = client.get(f"pipeline/trace/by-alert/{alert_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml") or raw:
        output(trace, fmt=fmt, raw=raw, fields=fields)
        return

    _render_provenance(trace, anchor=f"entry {entry_id} in {table}", footer_id=entry_id,
                        footer_label="THIS ENTRY (the agent invocation you're looking at)")


def provenance_by_alert_core(ctx, alert_id):
    """Fetch + render the pipeline provenance/trace for an alert_id.

    Shared by `torana pipeline trace by-alert` and the alert-scoped
    `torana workspace <id> alert <ALERT_ID> provenance` / `torana alert <ID>
    provenance` — same endpoint, same renderer; only the anchor framing differs.
    """
    fmt, raw, fields = _fmt(ctx)
    client = _client(ctx)
    try:
        trace = client.get(f"pipeline/trace/by-alert/{alert_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml") or raw:
        output(trace, fmt=fmt, raw=raw, fields=fields)
        return

    _render_provenance(trace, anchor=f"alert {alert_id}", footer_id=alert_id,
                        footer_label="THIS ALERT (the finding you're looking at)")


def _render_provenance(trace, *, anchor, footer_id, footer_label):
    """Human-readable bottom→top provenance + audit chain.

    `anchor` is the parenthetical shown in the header (what you pivoted from).
    `footer_id`/`footer_label` describe the leaf row the user is looking at.
    """
    prov = trace.get("provenance") or {}
    rule = prov.get("rule") or {}
    rule_run = prov.get("rule_run") or {}
    alert = trace.get("alert") or {}
    stages = trace.get("stages") or []

    click.echo(click.style("PROVENANCE", bold=True) + f"  ({anchor})")
    click.echo("")

    # 1. Origin — the rule + how it was triggered.
    if rule:
        click.echo(click.style("① RULE", fg="cyan", bold=True)
                   + f"  {rule.get('name', '?')}"
                   + (f"  [{rule.get('severity')}]" if rule.get("severity") else ""))
        click.echo(f"     id={rule.get('id')}")
    else:
        click.echo(click.style("① RULE", fg="cyan", bold=True) + "  (not resolved)")

    if rule_run:
        trig = rule_run.get("trigger") or "?"
        click.echo(f"     triggered: {click.style(trig, fg='yellow', bold=True)}  "
                   f"by {click.style(_actor_label(rule_run), fg='cyan')}  "
                   f"at {_fmt_ts(rule_run.get('enqueued_at'))}")
        click.echo(f"     rule_run {rule_run.get('id', '?')[:8]}…  "
                   f"status={rule_run.get('status')}  "
                   f"ran={_fmt_ts(rule_run.get('enqueued_at'))} → "
                   f"{_fmt_ts(rule_run.get('finished_at'))}")
    else:
        click.echo("     triggered: (no rule run found for this correlation_id)")
    click.echo(click.style("        │", fg="white"))

    # 2. The alert (finding) it produced.
    if alert:
        click.echo(click.style("② ALERT", fg="cyan", bold=True)
                   + f"  {alert.get('finding_key', alert.get('id', '?'))}")
        click.echo(f"     id={alert.get('id', footer_id)}  status={alert.get('status')}  "
                   f"created={_fmt_ts(alert.get('created_at'))}")
    cid = trace.get("correlation_id")
    click.echo(f"     correlation_id={cid or '(none — historical row)'}")
    click.echo(click.style("        │", fg="white"))

    # 3. Pipeline stages (the audit trail) — each stage's rows with status + timing.
    click.echo(click.style("③ PIPELINE STAGES", fg="cyan", bold=True)
               + "  (audit — what each stage did)")
    if not stages:
        click.echo("     (no stages — correlation_id not on the queue rows)")
    for st in stages:
        rows = st.get("rows") or []
        click.echo(f"     {click.style(st.get('stage', '?'), bold=True)}  "
                   f"({st.get('table')}, {len(rows)} row(s))")
        for r in rows:
            worker = r.get("claimed_by") or "—"
            click.echo(f"        {r.get('status', '?'):10} "
                       f"at={_fmt_ts(r.get('at'))}  "
                       f"done={_fmt_ts(r.get('finished_at'))}  "
                       f"worker={worker}  {str(r.get('id', ''))[:8]}…")
    click.echo(click.style("        │", fg="white"))
    click.echo(click.style("④ ", fg="cyan", bold=True)
               + click.style(footer_label, fg="cyan", bold=True)
               + f"  {str(footer_id)[:8]}…")
