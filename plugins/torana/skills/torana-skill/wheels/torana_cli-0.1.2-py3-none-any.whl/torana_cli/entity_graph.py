"""torana entity-graph — read the CAASM asset graph (AG0 § 3.4.3).

Subcommands
-----------
  edges list                       List edges (filterable, paginated).
  neighbors <key>                  Forward/reverse adjacency of one node.
  reachable <from_key>             Bounded lineage/reachability from a node.
  reconcile                        Run A6 reconciliation (O1 § 3.5) for this tenant.
  packages list                    List SBOM packages (filterable, paginated).

Wraps the read endpoints in pantheon-integration (§ 3.4.2). Grouped under a
single semantic parent per the CLI grouping convention — no new top-level groups.
"""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import (
    APIError,
    ToranaClient,
    handle_api_error,
    handle_auth_error,
)
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output


def _tenant_option(fn):
    """Shared --tenant-id flag for the cross-tenant READ commands (SA only).

    Declared once so the flag name and help text can't drift between commands.
    Omitted -> your own tenant (the default for every caller); a non-SA passing
    another tenant's id gets a 403 from the server, never silently their own data.
    """
    return click.option(
        "--tenant-id", "tenant_id", default=None,
        help="SUPER ADMIN ONLY — read another tenant's graph.",
    )(fn)


# ⛔ from_key/to_key are NEVER truncated: a polymorphic entity key IS an id — it gets
# pasted straight into `neighbors <key>` / `govern show <key>`, and a real one runs
# well past 36 chars (`image:us-west1-docker.pkg.dev/<proj>/<repo>@sha256:<64 hex>` is
# ~130). Clipping produced a key that looks complete, copies clean, and matches nothing.
_EDGE_COLS = [
    ("from_key", "FROM", None),
    ("edge_type", "TYPE", 14),
    ("to_key", "TO", None),
    ("confidence", "CONF", 14),
    ("source_system", "SOURCE", 18),
    ("created_via", "VIA", 16),
]
_PKG_COLS = [
    ("purl", "PURL", 40),
    ("package_manager", "MANAGER", 12),
    ("version", "VERSION", 14),
]
_NODE_COLS = [
    # ⛔ never truncate — same reason as _EDGE_COLS: this key is copied into the next
    # command, and an image: key exceeds 60 chars routinely.
    ("key", "KEY", None),
    # STATE, not RESOLVED: a boolean cannot separate "an onboarded integration should have
    # produced this row and didn't" (referenced — chase it) from "nothing onboarded covers this
    # authority" (unclaimed — expected). RESOLVED is kept as a narrower second column so
    # existing scripts reading it still work.
    ("state", "STATE", 12),
    ("home_table", "HOME_TABLE", 14),
    ("resolved", "RESOLVED", 10),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    return ToranaClient(base_url=get_settings(profile).base_url)


def _ctx(ctx):
    return (
        ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text",
        ctx.obj.get(CTX_RAW, False) if ctx.obj else False,
        ctx.obj.get(CTX_FIELDS) if ctx.obj else None,
    )


# ─── parent group ─────────────────────────────────────────────────────────────

@click.group(name="entity-graph")
def entity_graph():
    """Read the CAASM asset graph (edges, adjacency, lineage, packages).

    The graph is DIRECTED. Edges point a natural way — image ──contains──▶ pkg,
    image ──deployed_as──▶ service, service ──exposed_via──▶ cloud LB. So:
      forward = follow arrows (downstream)   reverse = walk AGAINST arrows (upstream)

    \b
    Node keys look like:
      pkg:pypi/litellm@1.74.15.post2                 an SBOM package (a leaf)
      image:us-west1-docker.pkg.dev/.../svc@sha256:… a built container image
      service:prod/pantheon-agent-builder            a running service (env in the key)
      cloud:gcp/resource/136.66.136.36               a public cloud endpoint
      repo:github.com/acme/billing-api               a source repo

    \b
    NOTE: graph data is per-TENANT. If a query is empty, you may be on the wrong
    tenant — use TORANA_PROFILE=T1 (or --tenant-id <id> as super admin).

    \b
    Examples:
      # one-hop adjacency of a node, both directions
      torana entity-graph neighbors service:prod/billing --direction both
      # who ships a package? (walk UP from the leaf)
      torana entity-graph reachable pkg:pypi/litellm@1.74.15.post2 --direction reverse
      # full lineage: a package → its images → running services → internet exposure
      torana entity-graph reachable pkg:pypi/litellm@1.74.15.post2 \\
        --via contains:reverse,deployed_as:forward,exposed_via:forward --max-depth 6
      # the tenant's only internet-facing edges
      torana entity-graph edges list --type exposed_via
      torana entity-graph packages list --purl-prefix pkg:pypi/litellm
    """


# ─── security graph (the OTHER graph — entity/alert relationships) ────────────
# NOTE: this is a DIFFERENT graph from the CAASM asset graph above. It is built
# from the datalake entity tables (assets, identities, vulnerabilities, findings,
# datastores, repositories, artifacts) and wraps /api/graph/* . Kept under this
# same semantic parent so there is ONE graph entry point in the CLI, but the
# subcommands are namespaced `security-*` so the two are never confused.

@entity_graph.group(name="security", invoke_without_command=True)
@click.pass_context
def security(ctx):
    """The entity/alert security graph (datalake entities, not the CAASM asset graph).

    \b
    Built from the datalake entity tables and their relationships — the graph
    the alert-context and entity-detail views draw. Distinct from the asset
    graph: different nodes, different keys (UUIDs, not `pkg:`/`service:` keys).

    \b
    Examples:
      torana entity-graph security stats
      torana entity-graph security search --query "prod-server"
      torana entity-graph security entity assets <ASSET_ID> --hops 2
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@security.command(name="overview")
@click.option("--workspace-id", default=None, help="Filter by workspace UUID.")
@click.pass_context
def security_overview(ctx, workspace_id):
    """Graph overview — node counts and relationship stats.

    \b
      torana entity-graph security overview
    """
    fmt, _, fields = _ctx(ctx)
    params = {}
    if workspace_id:
        params["workspace_id"] = workspace_id
    client = _client(ctx)
    try:
        data = client.get("/api/graph/overview/", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields)


@security.command(name="stats")
@click.option("--workspace-id", default=None, help="Filter by workspace UUID.")
@click.pass_context
def security_stats(ctx, workspace_id):
    """Entity counts per type, and the total.

    \b
      torana entity-graph security stats
    """
    fmt, _, _ = _ctx(ctx)
    params = {}
    if workspace_id:
        params["workspace_id"] = workspace_id
    client = _client(ctx)
    try:
        data = client.get("/api/graph/stats/", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt)


@security.command(name="search")
@click.option("--query", required=True, help="Search query.")
@click.option("--entity-type", default=None, help="Filter by entity type.")
@click.option("--workspace-id", default=None, help="Filter by workspace UUID.")
@click.pass_context
def security_search(ctx, query, entity_type, workspace_id):
    """Full-text search across entity names and properties.

    \b
      torana entity-graph security search --query "prod-server"
      torana entity-graph security search --query acme --entity-type repositories
    """
    fmt, _, fields = _ctx(ctx)
    params = {"query": query}
    if entity_type:
        params["entity_type"] = entity_type
    if workspace_id:
        params["workspace_id"] = workspace_id
    client = _client(ctx)
    try:
        data = client.get("/api/graph/search/", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields)


@security.command(name="entity")
@click.argument("entity_type", metavar="ENTITY_TYPE")
@click.argument("entity_id", metavar="ENTITY_ID")
@click.option("--hops", type=int, default=1, help="Relationship hops to expand (1-3).")
@click.option("--relationship-types", default=None, help="Filter by relationship types.")
@click.pass_context
def security_entity(ctx, entity_type, entity_id, hops, relationship_types):
    """Entity-centered graph — one entity expanded outward N hops.

    \b
    ENTITY_TYPE is one of: assets, identities, vulnerabilities, findings,
    datastores, repositories, artifacts.

    \b
      torana entity-graph security entity assets <ASSET_ID>
      torana entity-graph security entity assets <ASSET_ID> --hops 2   # blast radius
    """
    fmt, _, fields = _ctx(ctx)
    params = {}
    if hops is not None:
        params["hops"] = hops
    if relationship_types is not None:
        params["relationship_types"] = relationship_types
    client = _client(ctx)
    try:
        data = client.get(f"api/graph/entity/{entity_type}/{entity_id}", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields)


@security.command(name="entity-details")
@click.argument("entity_type", metavar="ENTITY_TYPE")
@click.argument("entity_id", metavar="ENTITY_ID")
@click.pass_context
def security_entity_details(ctx, entity_type, entity_id):
    """Detailed information for one graph entity.

    \b
      torana entity-graph security entity-details assets <ASSET_ID>
    """
    fmt, _, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.get(f"api/graph/entity/{entity_type}/{entity_id}/details")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields)


# ─── edges (collection group) ─────────────────────────────────────────────────

@entity_graph.group(name="edges", invoke_without_command=True)
@click.pass_context
def edges(ctx):
    """Asset-graph edges. Use `list` to list them."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@edges.command(name="list")
@click.option("--from-key", default=None, help="Filter by source node key.")
@click.option("--to-key", default=None, help="Filter by target node key.")
@click.option("--type", "edge_type", default=None, help="Filter by edge_type.")
@click.option("--confidence", default=None, help="Filter by confidence.")
@click.option("--source", "source_system", default=None, help="Filter by source_system (e.g. torana-entity-graph).")
@click.option("--created-via", "created_via", default=None,
              help="Filter by producer kind: manifest_parse | etl_derivation | sdg_replay.")
@click.option("--as-of", "as_of", default=None,
              help="Temporal overlay: only edges PRESENT at this instant "
                   "(first_seen <= as_of <= last_seen). ISO 8601, e.g. 2026-04-01T00:00:00Z.")
@click.option("--seen-from", "seen_from", default=None,
              help="Temporal overlay: only edges FIRST OBSERVED on/after this timestamp. ISO 8601.")
@click.option("--seen-to", "seen_to", default=None,
              help="Temporal overlay: only edges FIRST OBSERVED on/before this timestamp. "
                   "Pair with --seen-from for a window. ISO 8601.")
@click.option("--include-deleted", is_flag=True, default=False, help="Include tombstoned edges.")
@click.option("--limit", default=100, type=int, help="Max rows per page (<=100).")
@click.option("--offset", default=0, type=int, help="Pagination offset.")
@click.option("--all", "fetch_all", is_flag=True, default=False,
              help="Auto-paginate and return EVERY matching edge (ignores --offset).")
@_tenant_option
@click.pass_context
def edges_list(ctx, from_key, to_key, edge_type, confidence, source_system, created_via,
               as_of, seen_from, seen_to, include_deleted, limit, offset, fetch_all, tenant_id):
    """List entity-graph edges (filterable, paginated).

    \b
    The server caps a page at 100 rows. Without --all you get ONE page — on a real graph
    that is a tiny fraction of the edges, while `total` reports the full count (measured:
    100 returned of 141,893). Use --all when you are counting, aggregating, or asserting
    coverage; a partial page silently reads as the whole graph.

    \b
    Examples:
      torana entity-graph edges list --type deployed_as
      torana entity-graph edges list --all --format json
      torana entity-graph edges list --type owns --all --fields from_key,to_key
    """
    fmt, raw, fields = _ctx(ctx)
    params = {"limit": limit, "offset": offset}
    if from_key:
        params["from_key"] = from_key
    if to_key:
        params["to_key"] = to_key
    if edge_type:
        params["edge_type"] = edge_type
    if confidence:
        params["confidence"] = confidence
    if source_system:
        params["source_system"] = source_system
    if created_via:
        params["created_via"] = created_via
    if as_of:
        params["as_of"] = as_of
    if seen_from:
        params["seen_from"] = seen_from
    if seen_to:
        params["seen_to"] = seen_to
    if include_deleted:
        params["include_deleted"] = "true"
    if tenant_id:
        params["tenant_id"] = tenant_id

    client = _client(ctx)
    try:
        if fetch_all:
            # Walk every page. The server caps a page at 100, so a single call on a real
            # graph returns a fraction of the edges while `total` reports the full count —
            # silent truncation that reads as complete coverage to anyone counting or
            # asserting on the result.
            items, page_offset, total = [], 0, 0
            while True:
                params["offset"] = page_offset
                page = client.get("entity-graph/edges", params=params)
                batch = page.get("edges", []) or []
                total = page.get("count", total)
                items.extend(batch)
                if len(batch) < limit or len(items) >= (total or 0):
                    break
                page_offset += limit
            data = {"items": items, "total": total or len(items),
                    "page": 1, "page_size": len(items)}
        else:
            data = client.get("entity-graph/edges", params=params)
            # Normalize {edges:[...]} -> {items:[...]} for the formatter.
            data = {"items": data.get("edges", []), "total": data.get("count", 0),
                    "page": 1, "page_size": limit}
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields, columns=_EDGE_COLS)


# ─── neighbors ────────────────────────────────────────────────────────────────

@entity_graph.command(name="neighbors")
@click.argument("key")
@click.option("--type", "edge_type", default=None, help="Restrict to one edge_type.")
@click.option("--direction", default="both",
              type=click.Choice(["forward", "reverse", "both"]),
              help="Adjacency direction.")
@click.option("--include-deleted", is_flag=True, default=False)
@_tenant_option
@click.pass_context
def neighbors(ctx, key, edge_type, direction, include_deleted, tenant_id):
    """Forward/reverse adjacency of one node KEY.

    ONE hop only (for multi-hop lineage use `reachable`). forward = edges
    pointing OUT of KEY; reverse = edges pointing AT KEY; both = either side.

    \b
    Examples:
      # everything one hop from a service (its image, exposure, owner, …)
      torana entity-graph neighbors service:prod/pantheon-agent-builder --direction both
      # which images CONTAIN this package (reverse of the contains edge)
      torana entity-graph neighbors pkg:pypi/litellm@1.74.15.post2 \\
        --type contains --direction reverse
      # is this service internet-facing? (does an exposed_via edge leave it?)
      torana entity-graph neighbors service:prod/pantheon-nginx \\
        --type exposed_via --direction forward
    """
    fmt, raw, fields = _ctx(ctx)
    params = {"key": key, "direction": direction}
    if edge_type:
        params["edge_type"] = edge_type
    if include_deleted:
        params["include_deleted"] = "true"
    if tenant_id:
        params["tenant_id"] = tenant_id

    client = _client(ctx)
    try:
        data = client.get("entity-graph/neighbors", params=params)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


# ─── reachable ────────────────────────────────────────────────────────────────

@entity_graph.command(name="reachable")
@click.argument("from_key")
@click.option("--via", default=None,
              help="Comma-separated edge types to follow (e.g. builds,packaged_in). An entry may "
                   "carry a per-edge direction as edge:forward|edge:reverse "
                   "(e.g. contains:reverse,deployed_as:forward,exposed_via:forward) — a MIXED walk "
                   "that lets a package reach its running services (reverse contains → forward "
                   "deployed_as), which a single --direction cannot.")
@click.option("--max-depth", default=8, type=int, help="Depth cap (1..16).")
@click.option("--direction", default="forward",
              type=click.Choice(["forward", "reverse", "both"]),
              help="Traversal direction (upstream=reverse, downstream=forward).")
@click.option("--include-deleted", is_flag=True, default=False)
@_tenant_option
@click.pass_context
def reachable(ctx, from_key, via, max_depth, direction, include_deleted, tenant_id):
    """Bounded reachability/lineage from FROM_KEY (multi-hop, depth-capped).

    \b
    Direction options:
      --direction forward   follow arrows downstream (default)
      --direction reverse   walk upstream — "what leads to me?"
      --via edge:dir,…      MIXED walk: per-edge direction. The ONLY way to cross
                            edges that point opposite ways in one path (e.g.
                            reverse `contains` up to the image, then forward
                            `deployed_as` down to the service). A single
                            --direction cannot make that turn.

    A package is a LEAF: forward from it returns nothing; reverse (or a mixed
    walk) is where its lineage lives.

    \b
    Examples:
      # BACKWARD: which images ship this package? (leaf → up)
      torana entity-graph reachable pkg:pypi/litellm@1.74.15.post2 \\
        --direction reverse --max-depth 3
      # FORWARD from a repo: what it builds → is packaged in → deploys as
      torana entity-graph reachable repo:github.com/acme/billing-api \\
        --via builds,packaged_in,deployed_as --direction forward
      # MIXED: package → images → running services → internet exposure
      #   (reverse `contains`, then forward `deployed_as` + `exposed_via`)
      torana entity-graph reachable pkg:pypi/litellm@1.74.15.post2 \\
        --via contains:reverse,deployed_as:forward,exposed_via:forward --max-depth 6
    """
    fmt, raw, fields = _ctx(ctx)
    params = {"from_key": from_key, "max_depth": max_depth, "direction": direction}
    if via:
        params["via"] = via
    if include_deleted:
        params["include_deleted"] = "true"
    if tenant_id:
        params["tenant_id"] = tenant_id

    client = _client(ctx)
    try:
        data = client.get("entity-graph/reachable", params=params)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


# ─── overlay (Layers & Overlays § 3.4.1 / § 3.4.5) ──────────────────────────────

@entity_graph.command(name="overlay")
@click.option("--overlays", default=None,
              help="Comma-separated subset of "
                   "vulnerability,exposure,criticality,data_sensitivity,findings,ownership. "
                   "Default: all.")
@click.option("--node-kind", default="service",
              type=click.Choice(["service", "image", "all"]),
              help="Which nodes to roll up (default service).")
@click.option("--scope-env", default=None, help="Filter to one environment.")
@click.option("--scope-source", default=None, help="Filter to one source_system.")
@click.option("--scope-cluster", default=None, help="Filter to one container_cluster_id.")
@click.option("--include-deleted", is_flag=True, default=False)
@click.option("--limit", default=100, type=int, help="Max nodes per page (<=100).")
@click.option("--offset", default=0, type=int, help="Pagination offset.")
@_tenant_option
@click.pass_context
def overlay(ctx, overlays, node_kind, scope_env, scope_source, scope_cluster,
            include_deleted, limit, offset, tenant_id):
    """Per-node risk overlay rollup for a scoped set of service/image nodes.

    \b
    Examples:
      torana entity-graph overlay --overlays vulnerability,exposure --scope-env prod
      torana entity-graph overlay --node-kind all --scope-source gke
    """
    fmt, raw, fields = _ctx(ctx)
    params = {"node_kind": node_kind, "limit": limit, "offset": offset}
    if overlays:
        params["overlays"] = overlays
    if scope_env:
        params["scope_env"] = scope_env
    if scope_source:
        params["scope_source"] = scope_source
    if scope_cluster:
        params["scope_cluster"] = scope_cluster
    if include_deleted:
        params["include_deleted"] = "true"
    if tenant_id:
        params["tenant_id"] = tenant_id

    client = _client(ctx)
    try:
        data = client.get("entity-graph/overlay", params=params)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    # Nested per-node payload — normalize the node list for the formatter while
    # preserving coverage/scope in the envelope. `count` is the FULL scoped total
    # (no `total` key from the API — matches the edges convention).
    data = {"items": data.get("nodes", []), "total": data.get("count", 0),
            "page": 1, "page_size": limit,
            "coverage": data.get("coverage"), "scope": data.get("scope")}
    output(data, fmt=fmt, raw=raw, fields=fields)


# ─── scopes (Layers & Overlays § 3.4.2 / § 3.4.5) ───────────────────────────────

@entity_graph.command(name="scopes")
@_tenant_option
@click.pass_context
def scopes(ctx, tenant_id):
    """Dynamic scope-filter values present in this tenant's graph.

    Environments, source systems, clusters, edge types, confidences — the values
    the overlay `--scope-*` flags accept (data-driven; only present values are listed).
    """
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.get("entity-graph/scopes",
                          params={"tenant_id": tenant_id} if tenant_id else {})
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


# ─── reconcile (A6 — O1 light-up § 3.5) ─────────────────────────────────────────

@entity_graph.command(name="reconcile")
@click.option("--max-depth", default=None, type=click.IntRange(1, 16),
              help="Reachability depth cap for the image→service→cloud walk (1..16). "
                   "Omit to use the server default (ASSET_GRAPH_RECONCILE_MAX_DEPTH).")
@click.pass_context
def reconcile(ctx, max_depth):
    """Run A6 reconciliation for the current tenant.

    Derives the cross-resource OBSERVED edges (service ──exposed_via──▶ public
    cloud LB) and writes shadow / drift / reachable findings. Synchronous and
    idempotent. Returns a summary of what the sweep produced. This is the
    on-demand trigger for the same work the scheduled A6 sweep performs.
    """
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        # Omit when unset: sending a hardcoded client-side 8 meant an operator who
        # set ASSET_GRAPH_RECONCILE_MAX_DEPTH=12 silently got 8 from the CLI while
        # the scheduled sweep used 12.
        _params = {"max_depth": max_depth} if max_depth is not None else None
        data = client.post("entity-graph/reconcile", params=_params)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@entity_graph.command(name="reconcile-config")
@click.option("--enable", "action", flag_value="enable", default=None,
              help="Turn the reconciler ON for this tenant.")
@click.option("--disable", "action", flag_value="disable", default=None,
              help="Turn it OFF. The graph then stops converging — say why with --reason.")
@click.option("--reason", default=None,
              help="Why it was switched off. Stored and shown in `reconcile-config`.")
@_tenant_option
@click.pass_context
def reconcile_config(ctx, action, reason, tenant_id):
    """Show, or set, whether the reconciler may run for this tenant.

    With no flag this SHOWS the current state. `--enable` / `--disable` set it.

    \b
    TWO switches are reported, because either can stop a sweep:
      platform_disabled  process-wide env kill switch (operator-only, not settable here)
      enabled            this tenant's toggle

    ⛔ Disabling is NOT a pause button. While it is off the graph does not converge —
    duplicate identities are not collapsed, vulnerability pointers are not re-pointed,
    stale edges are not retired — and none of that errors. Every derived number simply
    goes quietly stale, which is why --reason is stored.
    """
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    params = {"tenant_id": tenant_id} if tenant_id else None
    try:
        if action is None:
            data = client.get("entity-graph/reconcile-config", params=params)
        else:
            if action == "disable" and not reason:
                click.echo("Refusing to disable without --reason: a disabled reconciler "
                           "is silent, and the next person to notice needs to know why.",
                           err=True)
                return
            data = client.put("entity-graph/reconcile-config",
                              json={"enabled": action == "enable", "reason": reason},
                              params=params)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@entity_graph.command(name="reconcile-history")
@click.option("--trigger", default=None,
              type=click.Choice(["manual", "scheduled", "post_sync"]),
              help="Filter by how the sweep was triggered.")
@click.option("--status", default=None,
              type=click.Choice(["running", "success", "failed", "abandoned"]),
              help="Filter by outcome status.")
@click.option("--limit", default=100, type=int, help="Max rows (<=100).")
@click.option("--offset", default=0, type=int, help="Pagination offset.")
@_tenant_option
@click.pass_context
def reconcile_history(ctx, trigger, status, limit, offset, tenant_id):
    """List past A6 reconciliation sweeps for the current tenant (newest first).

    Each row is one reconcile run — its trigger (manual|scheduled|post_sync), status, the
    shadow/drift/reachable finding counts + edges it produced, and duration. This is
    the per-run history the on-demand `reconcile` command never persisted before.
    Use `--format json` for the full row incl. actor + trace_id.
    """
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    params = {"limit": limit, "offset": offset}
    if trigger:
        params["trigger"] = trigger
    if status:
        params["status"] = status
    # Only sent when set — an empty tenant_id would make every ordinary tenant call a
    # cross-tenant read and 403 on a command that should just work.
    if tenant_id:
        params["tenant_id"] = tenant_id
    try:
        data = client.get("entity-graph/reconcile-runs", params=params)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    # Normalize {runs,count} → the paginated envelope output() expects.
    data = {"items": data.get("runs", []), "total": data.get("count", 0),
            "page": 1, "page_size": limit}
    # ⚠️ COLLAPSED and VULNS are the two counters that record a sweep DELETING rows, and
    # neither was on any surface until migration 025 — a pass could soft-delete tens of
    # thousands of rows and the run row would look identical to a no-op one. They earn a
    # column here over the tidier-looking alternatives for that reason alone.
    # The rest (repointed_pointers, artifacts_retired, findings_resolved,
    # candidates_promoted) are on `reconcile-run <id>`; ten columns is already the
    # width budget for this table.
    output(data, fmt=fmt, raw=raw, fields=fields, columns=[
        ("started_at", "WHEN", 22), ("trigger", "TRIGGER", 10), ("status", "STATUS", 8),
        ("health_verdict", "HEALTH", 9), ("shadow_count", "SHADOW", 7),
        ("drift_count", "DRIFT", 6), ("reachable_count", "REACH", 6),
        ("confirmed_edges", "EDGES", 6), ("retired_edges", "RETIRED", 8),
        ("duplicates_collapsed", "COLLAPSED", 10), ("vulns_retired", "VULNS", 7),
        ("duration_ms", "MS", 8),
    ])


@entity_graph.command(name="reconcile-run")
@click.argument("run_id", metavar="RUN_ID")
@click.option("--findings-limit", default=100, type=int, help="Max findings to show (<=100).")
@click.pass_context
def reconcile_run(ctx, run_id, findings_limit):
    """Show ONE reconciliation run + the findings it produced.

    Findings are matched by time-window + reconciler source_system (the findings table
    is a datalake table, so the association is by the run's [started_at, finished_at]
    window rather than a foreign key). Best viewed with `--format json`.
    """
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.get(f"entity-graph/reconcile-runs/{run_id}",
                          params={"findings_limit": findings_limit})
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


def _render_manifest(path, flavor, values):
    """Render a repo's deployment manifests with the NATIVE tool → plain k8s YAML.

    The client renders (it has the repo + tools + creds); the server interprets
    (Deployment_Object_and_Runtime_Provenance.md § 2.6). Returns (rendered, error).
    """
    import glob
    import os
    import shutil
    import subprocess

    cwd = None
    if flavor == "kustomize":
        if shutil.which("kustomize"):
            cmd = ["kustomize", "build", path]
        elif shutil.which("kubectl"):
            cmd = ["kubectl", "kustomize", path]
        else:
            return None, "neither `kustomize` nor `kubectl` found on PATH — cannot render kustomize"
    elif flavor == "helm":
        if not shutil.which("helm"):
            return None, "`helm` not found on PATH — cannot render a Helm chart"
        cmd = ["helm", "template", path]
        for v in values:
            cmd += ["-f", v]
    elif flavor == "compose":
        # `docker compose config` resolves ${VAR} from .env + merges → the plain compose.
        # Run in the compose file's dir so its .env resolves.
        cwd = os.path.dirname(os.path.abspath(path)) or "."
        base = os.path.basename(path)
        if shutil.which("docker"):
            cmd = ["docker", "compose", "-f", base, "config"]
        elif shutil.which("docker-compose"):
            cmd = ["docker-compose", "-f", base, "config"]
        else:
            return None, "`docker` (compose) not found on PATH — cannot render compose"
    else:  # k8s-raw — no rendering, read the plain YAML file(s)
        try:
            if os.path.isdir(path):
                docs = [open(f, encoding="utf-8").read()
                        for f in sorted(glob.glob(os.path.join(path, "*.y*ml")))]
                return ("\n---\n".join(docs), None) if docs else (None, "no *.yaml in dir")
            return open(path, encoding="utf-8").read(), None
        except Exception as exc:
            return None, str(exc)

    try:
        res = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=180)
    except Exception as exc:
        return None, f"{cmd[0]} failed to run: {exc}"
    if res.returncode != 0:
        return None, (res.stderr or res.stdout or "render failed").strip()[:600]
    return res.stdout, None


@entity_graph.command(name="parse-manifests")
@click.option("--path", required=True, type=click.Path(exists=True),
              help="Manifest to render: a kustomize overlay dir, a helm chart, or a raw-k8s file/dir.")
@click.option("--flavor", type=click.Choice(["kustomize", "helm", "k8s-raw", "compose"]),
              default="kustomize", help="Renderer to use (default kustomize).")
@click.option("--deployment", "deployment_id", default=None,
              help="A `manifest` Deployment id — the governance + env source of record (§ 2.6).")
@click.option("--env", "env_label", default=None,
              help="Env label → service:<env>/<name>. Required unless --deployment supplies it.")
@click.option("--values", multiple=True, help="helm only: values file(s) passed as -f (repeatable).")
@click.option("--criticality", default=None, help="Inline governance (when no --deployment).")
@click.option("--owner", default=None, help="Inline governance (when no --deployment).")
@click.option("--has-customer-data", "has_customer_data", is_flag=True, default=False,
              help="Inline governance (when no --deployment).")
@click.pass_context
def parse_manifests(ctx, path, flavor, deployment_id, env_label, values,
                    criticality, owner, has_customer_data):
    """Render a repo's deployment manifests and push the DECLARED asset graph.

    Runs the NATIVE renderer (`kustomize build` / `helm template` / raw read) locally,
    then POSTs the plain rendered k8s YAML to /ingest/manifests. The server interprets
    it into `service:` nodes + digest-keyed `deployed_as` edges + exposure — keyed
    identically to the live-cluster path so declared ⋈ observed converge. This is the
    code-side / shift-left / no-cluster-access producer (§ 2.6). Governance comes from
    the referenced `manifest` Deployment (--deployment), else from the inline flags.
    """
    import sys
    fmt, raw, fields = _ctx(ctx)

    if not env_label and not deployment_id:
        click.echo("ERROR: provide --env <label> or --deployment <id>", err=True)
        sys.exit(2)

    rendered, err = _render_manifest(path, flavor, values)
    if rendered is None:
        click.echo(f"ERROR: render failed ({flavor}): {err}", err=True)
        sys.exit(1)

    body = {
        "schema_version": "manifest_ingest.v1",
        "source": "torana-entity-graph",
        "env_label": env_label or "prod",
        "flavor": flavor,
        "manifest_ref": str(path),
        "rendered": rendered,
    }
    if deployment_id:
        body["deployment_id"] = deployment_id
    else:
        if criticality:
            body["criticality"] = criticality
        if owner:
            body["owner"] = owner
        if has_customer_data:
            body["has_customer_data"] = True

    client = _client(ctx)
    try:
        receipt = client.post("ingest/manifests", json=body)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(receipt, fmt=fmt, raw=raw, fields=fields)


# ─── packages (collection group) ──────────────────────────────────────────────

@entity_graph.group(name="packages", invoke_without_command=True)
@click.pass_context
def packages(ctx):
    """SBOM packages. Use `list` to list them."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@packages.command(name="list")
@click.option("--manager", "package_manager", default=None, help="Filter by package_manager.")
@click.option("--purl-prefix", default=None, help="Filter by purl prefix (left-anchored).")
@click.option("--include-deleted", is_flag=True, default=False)
@click.option("--limit", default=100, type=int, help="Max rows (<=100).")
@click.option("--offset", default=0, type=int, help="Pagination offset.")
@click.pass_context
def packages_list(ctx, package_manager, purl_prefix, include_deleted, limit, offset):
    """List SBOM packages (filterable, paginated)."""
    fmt, raw, fields = _ctx(ctx)
    params = {"limit": limit, "offset": offset}
    if package_manager:
        params["package_manager"] = package_manager
    if purl_prefix:
        params["purl_prefix"] = purl_prefix
    if include_deleted:
        params["include_deleted"] = "true"

    client = _client(ctx)
    try:
        data = client.get("packages", params=params)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    data = {"items": data.get("packages", []), "total": data.get("count", 0),
            "page": 1, "page_size": limit}
    output(data, fmt=fmt, raw=raw, fields=fields, columns=_PKG_COLS)


# ─── nodes (Explore-mode starting-node picker) ────────────────────────────────

@entity_graph.group(name="nodes", invoke_without_command=True)
@click.pass_context
def nodes(ctx):
    """Entity-graph nodes. Use `list` to list them."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@nodes.command(name="list")
@click.option("--kind", default=None,
              help="Node kind (key prefix): service | image | pkg | repo | cloud | team | "
                   "host | datastore | gav. OPTIONAL — omit to list every kind (needed for "
                   "a --home-table-only question, since `assets` is home to service:, "
                   "cloud: AND host:).")
@click.option("--q", "q", default=None, help="Case-insensitive substring filter on the node key.")
@click.option("--include-deleted", is_flag=True, default=False)
@click.option("--limit", default=100, type=int, help="Max rows (<=100).")
@click.option("--offset", default=0, type=int, help="Pagination offset.")
@click.option("--state", "state", multiple=True,
              type=click.Choice(["resolved", "referenced", "unclaimed", "unknown"]),
              help="Filter by resolution state; repeatable. Omit for all. "
                   "(`unknown` returns nothing here — this listing only ever yields keys "
                   "that ARE graph nodes; it is accepted so the vocabulary matches the API "
                   "and `nodes resolve`, where the state does occur.)")
@click.option("--home-table", "home_table", default=None,
              type=click.Choice(["assets", "repositories", "artifacts", "datastores",
                                 "packages", "identities"]),
              help="Filter to nodes whose inventory row lives in this table. Implies "
                   "resolved — an unresolved node has no row and so no home table.")
@_tenant_option
@click.pass_context
def nodes_list(ctx, kind, q, include_deleted, limit, offset, state, home_table, tenant_id):
    """List entity-graph nodes of one KIND (deduped, filterable, paginated).

    The starting-node listing behind the Explore-mode picker — "give me all
    nodes of kind service|image|pkg|repo|cloud|team|datastore|route". Distinct across
    edge endpoints (+ SBOM packages for kind=pkg).

    `datastore` is a valid kind (databases/caches/queues an `accesses` edge points
    at). It returns 0 rows until a producer emits `accesses` edges.

    `route` is an HTTP route — one Ingress host+path pair, keyed
    route:<namespace>/<ingress>/<path-slug> and homed in `assets` as
    asset_type='http_route' (F2). It answers "which workload serves
    demo.example.com/search?" via its `routes_to` edge.

    \b
    STATE — the graph has no node table, so a node is any string appearing as an edge
    endpoint. It may or may not have an inventory row behind it:
      resolved    the node has an inventory row (HOME_TABLE says which)
      referenced  edge endpoint only, BUT an onboarded integration could have produced
                  the row — a real ingestion gap worth chasing
      unclaimed   edge endpoint only and nothing onboarded covers its authority —
                  expected, e.g. a gitlab.com repo learned from an image's OCI label
                  with no GitLab integration, or a docker.io base image we don't sync

    \b
    Examples:
      torana entity-graph nodes list --kind service
      torana entity-graph nodes list --kind pkg --q litellm
      torana entity-graph nodes list --kind image --limit 50 --offset 50
      torana entity-graph nodes list --kind datastore
      # only the actionable gaps:
      torana entity-graph nodes list --kind image --state referenced
      # only nodes backed by a row in `assets`:
      torana entity-graph nodes list --kind service --home-table assets
    """
    fmt, raw, fields = _ctx(ctx)
    params = {"kind": kind, "limit": limit, "offset": offset}
    if q:
        params["q"] = q
    if include_deleted:
        params["include_deleted"] = "true"
    if state:
        params["state"] = list(state)
    if home_table:
        params["home_table"] = home_table
    if tenant_id:
        params["tenant_id"] = tenant_id

    client = _client(ctx)
    try:
        data = client.get("entity-graph/nodes", params=params)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    data = {"items": data.get("nodes", []), "total": data.get("count", 0),
            "page": 1, "page_size": limit}
    output(data, fmt=fmt, raw=raw, fields=fields, columns=_NODE_COLS)


#: Server cap — `resolve_entity_graph_nodes` rejects >1000 keys with a 422. Mirrored
#: here so an over-long batch fails locally with a clear message instead of burning a
#: round trip on a server-side 422.
_RESOLVE_KEY_CAP = 1000


@nodes.command(name="resolve")
@click.argument("keys", nargs=-1)
@click.option("--file", "keys_file", type=click.Path(exists=True, dir_okay=False),
              default=None,
              help="Read node keys from a file, one per line (blank lines and "
                   "`#` comments ignored). Combine with positional KEYS if you like.")
@_tenant_option
@click.pass_context
def nodes_resolve(ctx, keys, keys_file, tenant_id):
    """Bulk-resolve arbitrary node KEYS to their inventory-backing state.

    ⭐ The CLI face of `POST /entity-graph/nodes/resolve`, which existed on the API
    with no CLI command at all (three-surface parity, R8).

    Different question from `nodes list`: `list` enumerates the nodes the graph
    ALREADY has of one kind, so it can only tell you about keys that appear as an
    edge endpoint. `resolve` answers "for THIS set of keys — wherever I got them —
    which have an inventory row behind them?", including keys that are in no edge at
    all. That is the only way to ask about a node the graph has never seen.

    \b
    STATE (identical vocabulary to `nodes list`):
      resolved    the key has an inventory row (HOME TABLE says which)
      referenced  no row, but an onboarded integration could have produced one —
                  a real ingestion gap worth chasing
      unclaimed   no row and nothing onboarded claims its authority — expected
      unknown     the key maps to no inventory table at all, so coverage cannot be
                  assessed. NOT a gap and NOT a verdict — the absence of one. You see
                  this when you resolve something that is not a graph node key (a UI
                  card id, a typo, a synthetic prefix like `vuln::CVE-…`)

    \b
    Examples:
      torana entity-graph nodes resolve repo:github.com/torana-inc/pantheon-sdg
      torana entity-graph nodes resolve service:production/netd service:production/kube-proxy
      torana entity-graph nodes resolve --file /tmp/keys.txt
    """
    fmt, raw, fields = _ctx(ctx)

    all_keys = [k for k in keys if k]
    if keys_file:
        with open(keys_file, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if line and not line.startswith("#"):
                    all_keys.append(line)
    # Dedupe, preserving the order the caller gave — the server does the same, and a
    # stable order keeps output diffable.
    all_keys = list(dict.fromkeys(all_keys))

    if not all_keys:
        raise click.UsageError("Provide at least one node key, or --file with keys in it.")
    if len(all_keys) > _RESOLVE_KEY_CAP:
        raise click.UsageError(
            f"Too many keys ({len(all_keys)}); the cap is {_RESOLVE_KEY_CAP} per call — "
            "split the request."
        )

    params = {}
    if tenant_id:
        params["tenant_id"] = tenant_id

    client = _client(ctx)
    try:
        data = client.post("entity-graph/nodes/resolve",
                           json={"keys": all_keys},
                           params=params or None)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    rows = (data or {}).get("nodes", [])
    output({"items": rows, "total": len(rows), "page": 1, "page_size": len(rows) or 1},
           fmt=fmt, raw=raw, fields=fields, columns=_NODE_COLS)


# ─── health (ingestion freshness per producer) ──────────────────────────────

#: ⛔ The GRAPH-INGESTION verdict vocabulary — NOT the supply-health one.
#: Server-side source of truth: `_VERDICT_ORDER` in
#: `pantheon-integration/torana_mesh/services/graph_health_verdict.py`.
#: ⚠️ Deliberately separate from `supply_health._GLYPH` (S16 § 2.3): the two
#: subsystems answer different questions and their state sets are not the same
#: — `broken` is only here; `blocked_ours` / `blocked_yours` are only there.
#: ⛔ Defined ONCE because it was written out twice in this file and a second
#: copy is how a map goes stale (exactly what row 29 was).
_GRAPH_VERDICT_GLYPHS = {
    "healthy": "✓",
    "degraded": "▲",
    "broken": "✗",
    "unknown": "?",
}

_HEALTH_COLS = [
    ("source", "SOURCE", 24),
    ("received_at", "LAST_INGEST", 28),
    ("edges", "EDGES", 8),
    ("status", "STATUS", 10),
]


_ALL_TENANT_HEALTH_COLS = [
    ("verdict", "VERDICT", 10),
    ("tenant_name", "TENANT", 28),
    ("failed", "FAILED", 8),
    ("producers", "PRODUCERS", 10),
    ("last_ingest", "LAST_INGEST", 28),
    ("tenant_id", "TENANT_ID", 38),
]


@entity_graph.command(name="health")
@click.option("--deep", is_flag=True, default=False,
              help="Also show the data-quality verdict + per-invariant results (Phase E).")
@click.option("--tenant-id", "tenant_id", default=None,
              help="SUPER ADMIN ONLY — read another tenant's graph health.")
@click.option("--all-tenants", is_flag=True, default=False,
              help="SUPER ADMIN ONLY — one verdict row per tenant (cross-tenant roll-up).")
@click.option("--fail-under", "fail_under", type=float, default=None, metavar="PCT",
              help="Exit 1 when overall inventory-in-graph coverage is below PCT "
                   "(0-100). OPT-IN: without it this command always exits 0, even "
                   "while printing ✗. Use in a CI gate or pre-deploy check.")
@click.pass_context
def health(ctx, deep, tenant_id, all_tenants, fail_under):
    """Ingestion health per edge producer (last ingest receipt).

    Mirrors the FE 'Ingestion Health' surface (CLI-parity rule). Server-computed via
    GET /entity-graph/health so the CLI, FE, and API share one source. With --deep,
    additionally evaluates the data-quality Expectation Registry and prints the
    healthy/degraded/broken verdict + each invariant's pass/fail (Phase E).

    Super admins can inspect ANY tenant with --tenant-id, or see every tenant at
    once with --all-tenants (the cross-tenant roll-up behind the SA Health screen).
    Both are 403 for non-SA callers.

    \b
    ⛔ EXIT CODE — read this before wiring it into a gate.
    Bare `health` exits 0 UNCONDITIONALLY, including when it prints
    `✗ assets 44/1224 (3.6%)`. A gate built on the bare command reports GREEN on
    an estate where 96% of assets are invisible to exposure — the precise
    falsification-blindness the graph-coverage work exists to remove, reproduced
    in the instrument that measures it (#143).
    ⚠️ The default stays 0 DELIBERATELY: flipping it is a breaking change for
    every existing caller. Opt in with --fail-under instead.

    \b
    Examples:
      torana entity-graph health
      torana entity-graph health --deep
      # CI gate — non-zero when coverage regresses below 50%:
      torana entity-graph health --fail-under 50
    """
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)

    if fail_under is not None and not (0.0 <= fail_under <= 100.0):
        click.echo("--fail-under takes a percentage between 0 and 100.", err=True)
        raise SystemExit(2)

    if fail_under is not None and all_tenants:
        # The all-tenants roll-up carries no inventory_coverage block, so there is
        # nothing to threshold. Refuse rather than silently exiting 0 — a gate that
        # cannot evaluate must not report success.
        click.echo("--fail-under is not supported with --all-tenants: the "
                   "cross-tenant roll-up carries no inventory-coverage figure.",
                   err=True)
        raise SystemExit(2)

    if all_tenants and tenant_id:
        click.echo("Use either --all-tenants or --tenant-id, not both.", err=True)
        return

    # SA cross-tenant roll-up — one row per tenant, worst verdict first.
    if all_tenants:
        try:
            data = client.get("entity-graph/health/all-tenants")
        except AuthError as e:
            handle_auth_error(e)
            return
        except APIError as e:
            handle_api_error(e)
            return
        # ⚠️ A DIFFERENT VOCABULARY FROM `supply_health._GLYPH` — checked, not
        # assumed (S16 § 2.3). These verdicts are graph-INGESTION health, derived
        # by `pantheon-integration/torana_mesh/services/graph_health_verdict.py`
        # (`_VERDICT_ORDER`); supply's states are column-SUPPLY health, derived by
        # `pantheon-datalake/.../routes/supply.py`. Different services, different
        # closed sets: `broken` exists only here, `blocked_ours`/`blocked_yours`
        # only there. ⛔ So do NOT unify the two maps — `▲` meaning `degraded`
        # here and `blocked_yours` there is not drift, it is two vocabularies.
        # ⚠️ What IS shared is the RULE (a word plus a distinct non-colour shape),
        # and within THIS vocabulary the four glyphs must stay distinct.
        glyphs = _GRAPH_VERDICT_GLYPHS
        rows = [{
            # Non-color glyph alongside the word (color-blindness rule).
            "verdict": f"{glyphs.get(t.get('verdict'), '?')} {str(t.get('verdict', '')).upper()}",
            "tenant_name": t.get("tenant_name"),
            "failed": f"{t.get('expectations_failed', 0)}/{t.get('expectations_total', 0)}",
            "producers": len(t.get("producers") or []),
            "last_ingest": t.get("last_ingest") or "—",
            "tenant_id": t.get("tenant_id"),
        } for t in data.get("tenants", [])]
        output({"items": rows, "total": len(rows), "page": 1, "page_size": len(rows) or 1},
               fmt=fmt, raw=raw, fields=fields, columns=_ALL_TENANT_HEALTH_COLS)
        return

    params = {}
    if deep:
        params["deep"] = "true"
    if tenant_id:
        params["tenant_id"] = tenant_id
    try:
        data = client.get("entity-graph/health", params=params)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    producers = data.get("producers", [])
    rows = [{
        "source": p.get("source"),
        "received_at": p.get("last_ingest"),
        "edges": p.get("edges"),
        "status": p.get("status") or "ok",
    } for p in producers]

    # Inventory coverage — how much loaded inventory the graph can actually see.
    #
    # Nodes are derived from entity_edges endpoints, so an inventory row with no edge
    # is not a node and is invisible to neighbors/reachable/exposure. Without this
    # block that gap was silent: the producers table above can look perfectly healthy
    # while most of the estate is not in the graph at all.
    cov = data.get("inventory_coverage") or {}
    # Captured for the --fail-under gate below. Held OUTSIDE the `if` so a response
    # carrying no coverage block is distinguishable from one reporting 0% — the
    # former cannot be thresholded and must not silently pass (see _apply_gate).
    gate_pct = cov.get("coverage_pct") if cov else None
    gate_measurable = bool(cov.get("tables"))
    if cov.get("tables"):
        pct = cov.get("coverage_pct")
        # Glyph, not colour, carries the state (color-blindness rule): ✓ / ▲ / ✗.
        glyph = "?" if pct is None else ("✓" if pct >= 90 else ("▲" if pct >= 50 else "✗"))
        shown = "n/a" if pct is None else f"{pct}%"
        click.echo(
            f"\nInventory in graph: {glyph} {shown}"
            f"  ({cov.get('in_graph', 0)}/{cov.get('rows_total', 0)} rows"
            f"; {cov.get('not_in_graph', 0)} not in graph)"
        )
        if cov.get("illegal_key"):
            click.echo(
                f"  ✗ {cov['illegal_key']} row(s) carry a key that is not a legal "
                f"polymorphic prefix — these can NEVER join the graph; fix the source "
                f"mapping's key derivation."
            )
        for t in cov["tables"]:
            if t.get("error"):
                click.echo(f"    {t.get('table')}: ? unavailable ({t['error'][:60]})")
                continue
            tp = t.get("coverage_pct")
            tg = "?" if tp is None else ("✓" if tp >= 90 else ("▲" if tp >= 50 else "✗"))
            extra = f", {t['illegal_key']} illegal-key" if t.get("illegal_key") else ""
            click.echo(
                f"    {tg} {t.get('table'):14} {t.get('in_graph', 0)}/{t.get('rows', 0)}"
                f"  ({'n/a' if tp is None else str(tp) + '%'}{extra})"
                + (f"  [only {t['node_eligible_filter']}]"
                   if t.get("node_eligible_filter") else "")
            )
        click.echo("")

    # ── node_coverage — the INVERSE question ────────────────────────────────────────
    # `Inventory in graph` above walks ROWS and asks "does an edge reference this?".
    # This walks NODES and asks "is there a row behind this?". Neither implies the other,
    # and only the `referenced` bucket is actionable: an onboarded integration should have
    # produced that row and didn't. `unclaimed` is expected and needs no action, so it is
    # reported separately rather than folded into one "unresolved" number.
    ncov = data.get("node_coverage") or {}
    if ncov.get("kinds"):
        pct = ncov.get("backed_pct")
        glyph = "?" if pct is None else ("✓" if pct >= 90 else ("▲" if pct >= 50 else "✗"))
        shown = "n/a" if pct is None else f"{pct}%"
        click.echo(
            f"Graph nodes backed by inventory: {glyph} {shown}"
            f"  ({ncov.get('resolved', 0)}/{ncov.get('nodes', 0)} nodes"
            f"; {ncov.get('referenced', 0)} referenced (gap), "
            f"{ncov.get('unclaimed', 0)} unclaimed (expected))"
        )
        for k in ncov["kinds"]:
            kp = k.get("backed_pct")
            kg = "?" if kp is None else ("✓" if kp >= 90 else ("▲" if kp >= 50 else "✗"))
            bits = []
            if k.get("referenced"):
                bits.append(f"{k['referenced']} referenced")
            if k.get("unclaimed"):
                bits.append(f"{k['unclaimed']} unclaimed")
            suffix = ("  (" + ", ".join(bits) + ")") if bits else ""
            click.echo(
                f"    {kg} {k.get('kind'):10} {k.get('resolved', 0)}/{k.get('nodes', 0)}"
                f"  ({'n/a' if kp is None else str(kp) + '%'}){suffix}"
            )
        if ncov.get("referenced"):
            click.echo(
                f"  ▲ {ncov['referenced']} node(s) are `referenced`: an onboarded integration "
                f"could have produced the inventory row but didn't — see "
                f"`torana entity-graph nodes list --kind <kind> --state referenced`."
            )
        click.echo("")

    def _apply_gate():
        """Exit non-zero when --fail-under is supplied and coverage is below it.

        ⛔ An UNMEASURABLE estate fails the gate too. If the response carries no
        inventory_coverage block, or a null coverage_pct, the gate cannot evaluate —
        and a gate that cannot evaluate must never report success. That is the whole
        defect this flag exists to fix (#143): silence read as health.
        """
        if fail_under is None:
            return
        if not gate_measurable or gate_pct is None:
            click.echo(
                "\n✗ FAIL: inventory coverage is not measurable in this response, so "
                "--fail-under cannot be evaluated. Refusing to report success.",
                err=True)
            raise SystemExit(1)
        if float(gate_pct) < fail_under:
            click.echo(
                f"\n✗ FAIL: inventory-in-graph coverage {gate_pct}% is below the "
                f"--fail-under threshold of {fail_under}%. Rows outside the graph are "
                f"not reported as unconnected — they are ABSENT, and exposure answers "
                f"'not exposed' about every one of them.",
                err=True)
            raise SystemExit(1)
        click.echo(f"\n✓ PASS: inventory-in-graph coverage {gate_pct}% "
                   f"meets the --fail-under threshold of {fail_under}%.")

    if deep and data.get("verdict"):
        v = data["verdict"]
        # Verdict line with a non-color glyph (color-blindness rule): ✓ healthy, ▲ degraded, ✗ broken.
        # ⚠️ Second render of the SAME vocabulary — shares the one map above so
        # the two lines can never disagree about what a verdict looks like.
        glyph = _GRAPH_VERDICT_GLYPHS.get(v.get("verdict"), "?")
        click.echo(f"\nData-health verdict: {glyph} {str(v.get('verdict', '')).upper()}"
                   f"  ({v.get('expectations_failed', 0)} invariant(s) failed)")
        if v.get("reasons"):
            click.echo("  reasons: " + ", ".join(v["reasons"]))
        inv_rows = [{
            "key": e.get("key"),
            "passed": "✓" if e.get("passed") else "✗",
            "value": e.get("value"),
            "check": f"{e.get('operator')} {e.get('threshold')}",
            "severity": e.get("severity"),
        } for e in sorted(v.get("expectations", []), key=lambda x: (x.get("passed", True)))]
        click.echo("")
        output({"items": inv_rows, "total": len(inv_rows), "page": 1, "page_size": len(inv_rows) or 1},
                fmt=fmt, raw=raw, fields=fields, columns=[
                    ("key", "INVARIANT", 24), ("passed", "OK", 3), ("value", "VALUE", 12),
                    ("check", "CHECK", 14), ("severity", "SEV", 8)])
        _apply_gate()
        return

    output({"items": rows, "total": len(rows), "page": 1, "page_size": len(rows) or 1},
           fmt=fmt, raw=raw, fields=fields, columns=_HEALTH_COLS)
    _apply_gate()


# ─── candidates (AG3a edge-derivation diagnostic ledger) ────────────────────

_CANDIDATE_COLS = [
    ("edge_type", "TYPE", 14),
    ("reason", "REASON", 24),
    ("missing_side", "MISSING", 8),
    ("candidate_value", "VALUE", 40),
    ("occurrence_count", "N", 5),
    ("status", "STATUS", 10),
]


@entity_graph.group(name="candidates", invoke_without_command=True)
@click.pass_context
def candidates(ctx):
    """Asset-edge derivation candidates. Use `list` to list them."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@candidates.command(name="list")
@click.option("--status", "status_", default=None, help="open | promoted | dismissed | needs_job.")
@click.option("--reason", default=None, help="Filter by reason.")
@click.option("--type", "edge_type", default=None, help="Filter by edge_type.")
@click.option("--ingest-receipt", "ingest_receipt_id", default=None, help="Filter by ingest pass.")
@click.option("--include-deleted", is_flag=True, default=False)
@click.option("--limit", default=100, type=int, help="Max rows (<=100).")
@click.option("--offset", default=0, type=int, help="Pagination offset.")
@click.pass_context
def candidates_list(ctx, status_, reason, edge_type, ingest_receipt_id,
                    include_deleted, limit, offset):
    """Asset-edge derivation candidates — edges that could NOT be keyed (§ 4.9.2).

    The diagnostic ledger: every derivation attempt that failed to compute one
    endpoint's key, with the reason and the raw value that wouldn't normalize. The
    after-every-ingest "why didn't my edge appear?" surface.
    """
    fmt, raw, fields = _ctx(ctx)
    params = {"limit": limit, "offset": offset}
    if status_:
        params["status"] = status_
    if reason:
        params["reason"] = reason
    if edge_type:
        params["edge_type"] = edge_type
    if ingest_receipt_id:
        params["ingest_receipt_id"] = ingest_receipt_id
    if include_deleted:
        params["include_deleted"] = "true"

    client = _client(ctx)
    try:
        data = client.get("entity-graph/candidates", params=params)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    data = {"items": data.get("candidates", []), "total": data.get("count", 0),
            "page": 1, "page_size": limit}
    output(data, fmt=fmt, raw=raw, fields=fields, columns=_CANDIDATE_COLS)


# ─── metrics (AG3a derivation metrics — per-pass rollups) ───────────────────

_METRIC_COLS = [
    ("created_at", "WHEN", 26),
    ("edge_type", "TYPE", 14),
    ("source_system", "SOURCE", 14),
    ("edges_derived", "DERIVED", 8),
    ("candidates_written", "FAILED", 7),
    ("duration_ms", "MS", 7),
]


@entity_graph.group(name="metrics", invoke_without_command=True)
@click.pass_context
def metrics(ctx):
    """Asset-graph derivation metrics. Use `list` to list them."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@metrics.command(name="list")
@click.option("--since", default=None,
              help="Window, e.g. '1 hour', '24 hours', '7 days'.")
@click.option("--type", "edge_type", default=None, help="Filter by edge_type.")
@click.option("--source", "source_system", default=None, help="Filter by source_system.")
@click.option("--limit", default=100, type=int, help="Max rows (<=100).")
@click.option("--offset", default=0, type=int, help="Pagination offset.")
@click.pass_context
def metrics_list(ctx, since, edge_type, source_system, limit, offset):
    """Asset-graph derivation metrics — per-pass rollups (§ 4.9.7).

    Counters (edges derived / failed), confidence histogram, and timing per ingest
    pass per edge_type. Use --since to window: `--since '1 hour'`.
    """
    fmt, raw, fields = _ctx(ctx)
    params = {"limit": limit, "offset": offset}
    if since:
        params["since"] = since
    if edge_type:
        params["edge_type"] = edge_type
    if source_system:
        params["source_system"] = source_system

    client = _client(ctx)
    try:
        data = client.get("entity-graph/metrics", params=params)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    data = {"items": data.get("metrics", []), "total": data.get("count", 0),
            "page": 1, "page_size": limit}
    output(data, fmt=fmt, raw=raw, fields=fields, columns=_METRIC_COLS)


# ── expectations (Phase E — data-quality invariant registry) ─────────────────

_EXPECTATION_COLS = [
    ("key", "KEY", 22),
    ("title", "TITLE", 40),
    ("operator", "OP", 5),
    ("threshold", "THRESHOLD", 12),
    ("severity", "SEV", 8),
    ("enabled", "ENABLED", 8),
    ("is_seed", "SEED", 6),
]


@entity_graph.group(name="expectations", invoke_without_command=True)
@click.pass_context
def expectations(ctx):
    """Data-quality invariants (the Expectation Registry). Use `list` to list them.

    \b
    Each invariant is a scalar query compared to a threshold; a trip becomes a
    data_quality finding and drives the graph-health verdict (Phase E).
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@expectations.command(name="list")
@click.option("--limit", default=100, type=int, help="Max rows (<=100).")
@click.option("--offset", default=0, type=int, help="Pagination offset.")
@click.pass_context
def expectations_list(ctx, limit, offset):
    """List this tenant's data-quality invariants."""
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.get("entity-graph/expectations", params={"limit": limit, "offset": offset})
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    data = {"items": data.get("expectations", []), "total": data.get("count", 0),
            "page": 1, "page_size": limit}
    output(data, fmt=fmt, raw=raw, fields=fields, columns=_EXPECTATION_COLS)


@expectations.command(name="create")
@click.option("--key", required=True, help="Stable slug, e.g. no_dual_key.")
@click.option("--title", required=True, help="Human one-liner.")
@click.option("--query", required=True, help="A single SELECT returning one numeric column AS value.")
@click.option("--operator", required=True,
              type=click.Choice(["eq", "ne", "lt", "lte", "gt", "gte"]),
              help="Comparison: value <op> threshold.")
@click.option("--threshold", required=True, type=float, help="The RHS compared against the query value.")
@click.option("--severity", default="high",
              type=click.Choice(["critical", "high", "medium", "low"]),
              help="Finding severity when tripped.")
@click.option("--description", default="", help="Semantic description of the invariant.")
@click.option("--disabled", is_flag=True, default=False, help="Create disabled (not evaluated).")
@click.pass_context
def expectations_create(ctx, key, title, query, operator, threshold, severity, description, disabled):
    """Create a data-quality invariant."""
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    body = {"key": key, "title": title, "query": query, "operator": operator,
            "threshold": threshold, "severity": severity, "description": description,
            "enabled": not disabled}
    try:
        data = client.post("entity-graph/expectations", json=body)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@expectations.command(name="delete")
@click.argument("key")
@click.pass_context
def expectations_delete(ctx, key):
    """Soft-delete a data-quality invariant by KEY."""
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.delete(f"entity-graph/expectations/{key}")
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@expectations.command(name="run")
@click.pass_context
def expectations_run(ctx):
    """Evaluate all enabled invariants now and print the results + trips."""
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.post("entity-graph/expectations/run")
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    results = data.get("results", [])
    rows = [{
        "key": r.get("key"),
        "passed": "✓" if r.get("passed") else "✗",
        "value": r.get("value"),
        "check": f"{r.get('operator')} {r.get('threshold')}",
        "severity": r.get("severity"),
    } for r in sorted(results, key=lambda x: x.get("passed", True))]
    output({"items": rows, "total": len(rows), "page": 1, "page_size": len(rows) or 1},
           fmt=fmt, raw=raw, fields=fields, columns=[
               ("key", "INVARIANT", 24), ("passed", "OK", 3), ("value", "VALUE", 12),
               ("check", "CHECK", 14), ("severity", "SEV", 8)])


@expectations.command(name="seed")
@click.pass_context
def expectations_seed(ctx):
    """(Re)seed the platform-canonical data-quality invariants for this tenant."""
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.post("entity-graph/expectations/seed")
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@entity_graph.command(name="freshness")
@_tenant_option
@click.pass_context
def reconcile_freshness(ctx, tenant_id):
    """Is the graph current, or has data landed since the last reconcile?

    The API and the UI have both had this signal for a while; the CLI did not,
    so a scripted caller could reconcile but never ask whether it needed to.

    `is_stale` true means rows were ingested AFTER the last successful sweep —
    the graph has not yet converged on them.

    Convergence is SCHEDULED, not automatic-on-sync: there is no post-sync
    reconcile hook, so a fresh sync stays stale until the next cron tick (shown
    as "Next reconcile"). Run `torana entity-graph reconcile` to converge now.
    """
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.get("entity-graph/reconcile-freshness",
                          params={"tenant_id": tenant_id} if tenant_id else None)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    if raw or fmt != "table":
        output(data, fmt=fmt, raw=raw, fields=fields)
        return
    stale = data.get("is_stale")
    ever = data.get("ever_reconciled")
    click.echo(f"Last reconciled  {data.get('last_reconciled_at') or 'never'}")
    click.echo(f"Last ingested    {data.get('last_ingested_at') or 'never'}")
    # ⚠️ Both watermarks are printed SEPARATELY on purpose (#159). `last_ingested_at`
    # used to be the EDGE watermark alone while being named as though it covered
    # everything, so a sync that landed inventory and derived no edge moved nothing and
    # the graph was declared `current` over rows it had never reconciled. Showing the
    # two halves makes that blind spot visible instead of implicit.
    click.echo(f"  ├─ edges       {data.get('last_edge_ingested_at') or 'never'}")
    click.echo(f"  └─ inventory   {data.get('last_inventory_ingested_at') or 'never'}")
    reason = data.get("stale_reason")
    if not ever:
        click.echo("Status           never reconciled")
    elif stale and reason == "inventory-newer-than-reconcile":
        # Glyph + word, never colour alone.
        click.echo("Status           ✗ STALE — INVENTORY landed since the last reconcile "
                   "while no new edge did.")
        click.echo("                 Rows arrived and connected to NOTHING. They are not "
                   "reported as unconnected — they are")
        click.echo("                 ABSENT from the graph, and exposure answers 'not "
                   "exposed' about every one of them.")
        click.echo("                 See: torana entity-graph orphans")
    elif stale:
        click.echo("Status           ✗ STALE — data landed since the last reconcile")
    else:
        click.echo("Status           ✓ current")
    if reason:
        click.echo(f"Reason           {reason}")
    # ⛔ `is_stale: true` without this is a dead end — it says the graph has not caught
    # up but not whether waiting fixes it. When the sweep is DISABLED the honest answer
    # is that nothing will fire, never a fabricated time.
    if data.get("reconcile_scheduled") is False:
        click.echo("Next reconcile   ✗ NONE — the scheduled sweep is DISABLED "
                   "(ASSET_GRAPH_RECONCILE_DISABLED).")
        click.echo("                 Only `torana entity-graph reconcile` will converge "
                   "the graph.")
    elif data.get("next_reconcile_at"):
        sched = data.get("reconcile_schedule")
        click.echo(f"Next reconcile   {data['next_reconcile_at']}"
                   + (f"   (cron: {sched})" if sched else ""))


# ─── orphans (rows NO edge names — the inverse of health coverage) ───────────

#: ⛔ NEVER truncate a key column — same rule as _EDGE_COLS/_NODE_COLS (width None).
#: Both of these get pasted straight into `neighbors <key>` / `govern show <key>`,
#: and a clipped key looks complete, copies clean, and matches nothing.
_ORPHAN_COLS = [
    ("torana_entity_id", "KEY", None),
    ("connected_twin", "CONNECTED_TWIN", None),
    ("asset_name", "ASSET_NAME", 28),
    ("source_system", "SOURCE", 12),
    ("asset_owner", "OWNER", 14),
]

#: `dangling-pointer` rows are a DIFFERENT shape — they are vulnerabilities keyed by the
#: pointer that dangles, not orphaned asset rows — so they get their own columns. Same
#: no-truncation rule on the key (width None): it gets pasted straight into a query.
_DANGLING_COLS = [
    ("dangling_key", "DANGLING_KEY", None),
    ("pointer", "POINTER_COLUMN", 36),
    ("reason", "REASON", 11),
    ("rows", "ROWS", 6),
]


@entity_graph.command(name="kind-vocabulary")
@_tenant_option
@click.pass_context
def kind_vocabulary(ctx, tenant_id):
    """Which asset kinds the platform RECOGNISES — and which nothing claims.

    ⛔ THE COMPANION TO `orphans --category unclassified`. That counts ROWS nobody has
    judged; this names the KINDS behind them and the producer each arrives from — which
    is what you act on. An unclassified kind is fixed by declaring it in the mapping that
    EMITS it (its `metadata.node_roles` block), never by editing the classifier: a kind
    list in shared code answers correctly for one integration and mis-files every other.

    Examples:
      torana entity-graph kind-vocabulary
      torana entity-graph kind-vocabulary --format json
    """
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    params = {"tenant_id": tenant_id} if tenant_id else {}
    try:
        data = client.get("entity-graph/kind-vocabulary", params=params)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    # Matches `orphans`: the human renderer serves BOTH the default `text` and `table`;
    # only json/yaml/raw fall through to the generic serialiser.
    if raw or fmt not in ("table", "text"):
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    if not data.get("available", True):
        click.echo(f"kind-vocabulary unavailable: {data.get('reason')}")
        return

    counts = data.get("counts") or {}
    click.echo(f"\nDeclared: {counts.get('declared_kinds', 0)} kind(s) across "
               f"{counts.get('declared_roles', 0)} role(s)")
    for role, entries in (data.get("roles") or {}).items():
        producers = sorted({e.get("producer") for e in entries if e.get("producer")})
        click.echo(f"\n  {role}  ({len(entries)} kinds · {', '.join(producers) or '—'})")
        click.echo("    " + ", ".join(e.get("kind", "") for e in entries))

    unc = data.get("unclassified") or []
    click.echo(f"\nUNCLAIMED BY ANY MAPPING — {counts.get('unclassified_kinds', 0)} kind(s), "
               f"{counts.get('unclassified_rows', 0)} row(s) in this estate:")
    if not unc:
        click.echo("    (none — every kind present is declared)")
    else:
        for u in unc[:40]:
            click.echo(f"    {str(u.get('kind'))[:38]:<38} {u.get('rows'):>6}  "
                       f"{u.get('source_system')}")
        if len(unc) > 40:
            click.echo(f"    … {len(unc) - 40} more (use --format json)")
    click.echo("\n  Fix one by adding it to `node_roles` in the mapping that emits it.")


@entity_graph.command(name="orphans")
@click.option("--category", "category", default=None,
              type=click.Choice(["twin", "service-subject", "exposure", "controller-owned",
                                 "relationship", "unconnected", "not-a-graph-entity",
                                 "unclassified", "dangling-pointer"]),
              help="Enumerate ONE category. Omit for counts by category. "
                   "⚠️ `unkeyable` was REPLACED by `unclassified` (kind-vocabulary): NO "
                   "mapping claims the kind, so it is untriaged — OUR coverage gap, not "
                   "the estate's ambiguity. Use `entity-graph kind-vocabulary` to see "
                   "which kinds those are and which integration to fix. "
                   "⚠️ `no-env` was REMOVED (#158) — it encoded a retracted inference.")
@click.option("--table", "as_table", is_flag=True, default=False,
              help="Force the table renderer for the listing.")
@click.option("--limit", default=100, type=int, help="Max rows (<=100).")
@click.option("--offset", default=0, type=int, help="Pagination offset.")
@_tenant_option
@click.pass_context
def orphans(ctx, category, as_table, limit, offset, tenant_id):
    """Inventory rows that loaded correctly and connect to NOTHING.

    `entity-graph health` COUNTS these; nothing enumerated them. The graph has no
    node table, so a row no edge names is not REPORTED as unconnected — it is
    ABSENT, and exposure (computed FROM the graph) answers "not exposed" about it
    having never seen it.

    \b
    CATEGORY — whose problem each row is:
      twin       a DIFFERENT key for same asset_name AND KIND is connected  (#135)
      no-env     has asset_owner, asset_environment NULL -> no service key (#134)
      relationship the row IS an edge (a binding) -- never a node, correctly unconnected
      unconnected  a real node with NOTHING attached -- an unused role / unbound principal
      unclassified NO mapping claims the kind -- untriaged; OUR coverage gap

    \b
    ⚠️ `twin` IS EVIDENCE, NOT A COMPLETE COLLISION DETECTOR. It fires only when
    ONE HALF of a split is connected. A `prod`/`production` mistake that leaves
    BOTH halves orphaned lands in `no-env`, not `twin`. Never read "no twins" as
    "no splits".

    \b
    dangling-pointer is the SAME question from the OTHER SIDE OF THE JOIN (#108):
    a sink-table identity pointer naming a row that does not exist live, so the
    join parses, EXPLAINs, runs and returns NOTHING — forever, and silently,
    because both sides look reachable. Two sub-reasons, two owners:
      retired     a row exists but is soft-deleted -> a CONVERGENCE bug
      never-seen  no row in any state -> a COVERAGE gap (nothing wrote it)
    ⚠️ Its rows are NOT in the headline total, which stays the assets-side count.

    \b
    Examples:
      torana entity-graph orphans
      torana entity-graph orphans --category twin --limit 10
      torana entity-graph orphans --category no-env --format json
      torana entity-graph orphans --category dangling-pointer
    """
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    params = {"limit": limit, "offset": offset}
    if category:
        params["category"] = category
    if tenant_id:
        params["tenant_id"] = tenant_id
    try:
        data = client.get("entity-graph/orphans", params=params)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    if not data.get("available", True):
        click.echo(f"orphans unavailable: {data.get('reason')}")
        return

    # A listing was asked for → render the rows (json/table as requested).
    if category:
        payload = {"items": data.get("items", []), "total": data.get("total", 0),
                   "page": 1, "page_size": limit}
        # `text` is the CLI's DEFAULT format (not `table`) — both mean "render it for
        # a human here". Testing only `!= "table"` sent the default straight to
        # output(), which found no top-level rows and printed "No results." over a
        # perfectly good payload.
        if raw or (fmt not in ("table", "text") and not as_table):
            output(payload, fmt=fmt, raw=raw, fields=fields)
            return
        output(payload, fmt="table", raw=raw, fields=fields,
               columns=(_DANGLING_COLS if category == "dangling-pointer"
                        else _ORPHAN_COLS))
        return

    # No category → the counts roll-up.
    if raw or fmt not in ("table", "text"):
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    total = data.get("total", 0)
    click.echo(f"\nRows in inventory that NO edge names: {total}\n")
    # ⚠️ `dangling-pointer` is printed BELOW the total, not inside it: its rows are
    # vulnerabilities, not orphaned assets, and folding them into one number would
    # silently redefine what this figure has always meant.
    for row in data.get("by_category", []):
        if str(row.get("category")) == "dangling-pointer":
            continue
        click.echo(f"    {str(row.get('category')):10} {str(row.get('rows')):>6}"
                   f"   {row.get('meaning')}")
    click.echo()
    for row in data.get("by_category", []):
        if str(row.get("category")) == "dangling-pointer":
            continue
        click.echo(f"    {str(row.get('category')):10} owner: {row.get('owner')}")

    coverage = data.get("home_table_coverage") or []
    if coverage:
        click.echo("\n  COVERAGE — the SAME question asked of every home table, not just `assets`:")
        for h in coverage:
            rows, gap = int(h.get("rows") or 0), int(h.get("no_node") or 0)
            pct = f"{(gap / rows * 100):.0f}%" if rows else "—"
            flag = "  <-- nothing reports these" if gap and h.get("home_table") != "assets" else ""
            click.echo(f"    {str(h.get('home_table')):14} {rows:>6} rows"
                       f" {gap:>6} with no node  {pct:>4}{flag}")
        click.echo("    A row no edge names is ABSENT from the graph, not reported as")
        click.echo("    unconnected — so every graph-derived answer silently excludes it.")
        click.echo("    ⚠️ Only `assets` is broken down by category above; the others are")
        click.echo("    counted, because the category tests read assets-only columns.")

    pointers = data.get("dangling_pointers") or []
    if pointers:
        click.echo("\n  DANGLING POINTERS — the same question, the other side of the join"
                   " (#108):")
        for p in pointers:
            click.echo(f"    {str(p.get('pointer')):38} {str(p.get('reason')):11}"
                       f" {str(p.get('rows')):>6} rows"
                       f"  ({p.get('distinct_keys')} distinct keys)")
        click.echo("    A pointer naming a row that does not exist live -> the join")
        click.echo("    parses, runs, and returns nothing FOREVER. 'retired' = a")
        click.echo("    convergence bug; 'never-seen' = a coverage gap.")

    click.echo("\n  `twin` is EVIDENCE, not a complete collision detector: it fires only")
    click.echo("  when one half of a split is connected. A split leaving BOTH halves")
    click.echo("  orphaned is invisible here. Never read 'no twins' as 'no splits'.")
    click.echo("\n  Enumerate one: torana entity-graph orphans --category <name>\n")


# ⛔ THE PRODUCER IS ALWAYS THE FIRST FIX. This removes debris a producer bug
# already wrote; it does not make the producer correct. Re-running a broken
# producer re-creates the rows, so the order is: fix the key derivation, verify a
# clean run, THEN prune the old rows.
#
# ⚠️ Why a targeted prune is needed at all — the debris is INVISIBLE to every
# existing check. A key like `service:environment.production/keycloak` (an enum
# stringified as "Environment.PRODUCTION" instead of its .value) starts with a
# LEGAL `service:` prefix, so `illegal_key` never fires; and the same buggy run
# wrote edges, so the node is an endpoint and `not_in_graph` does not fire either.
# `torana entity-graph health` reported `service 42/42 (100.0%)` over an estate
# silently split into two halves that could never join.
@nodes.command(name="prune")
@click.option("--key-pattern", required=True,
              help="SQL LIKE pattern the node key must match, e.g. 'service:environment.%'. "
                   "Must be anchored (no leading %), contain a ':' and >= 8 literal chars.")
@click.option("--yes", is_flag=True, default=False,
              help="Actually soft-delete. WITHOUT this the command only previews.")
@click.pass_context
def nodes_prune(ctx, key_pattern, yes):
    """Soft-delete nodes whose key matches a pattern, plus their edges.

    PREVIEWS BY DEFAULT — prints what would be removed and changes nothing until
    you pass --yes. That default is deliberate: a typo in --key-pattern should
    cost a re-read, not an incident.

    Soft delete only (is_deleted = TRUE): every read path filters on it, so the
    rows leave every answer while staying auditable and recoverable.

    \b
    Examples:
      torana entity-graph nodes prune --key-pattern 'service:environment.%'
      torana entity-graph nodes prune --key-pattern 'service:environment.%' --yes
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.delete(
            "entity-graph/nodes",
            params={"key_pattern": key_pattern, "dry_run": (not yes)},
        )
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


# ─────────────────────────────────────────────────────────────────────────────
# The relationship contract — what a row of a given kind OWES the graph
# ─────────────────────────────────────────────────────────────────────────────
#
# ⭐ NEEDS NO TENANT. Unlike every other command in this group, the contract check
# is a static join over files on disk — the answer is identical for every customer,
# because the defect is in the BUILD, not in anyone's data. A tenant is for
# VALIDATING a finding, never for computing it.

# ─────────────────────────────────────────────────────────────────────────────
# `contract` — a GROUP, so the debt has addressable rows
# ─────────────────────────────────────────────────────────────────────────────
#
# ⭐ WHY A GROUP AND NOT A FLAG. `--violations` answered "how much debt is there?"
# and stopped. But a breach is only actionable once you can ask "what does THIS one
# need?", and a flag has nowhere to hang that follow-up. Subcommands give the debt
# STABLE, ADDRESSABLE ROWS:
#
#     contract                      the reference table — what each kind of row owes
#     contract violations           every mapping's standing, each with an ID
#     contract violation <id> details   the gap analysis for one breach
#
# ⚠️ The ID is positional within the CURRENT filtered listing, deliberately: it is a
# cursor for a conversation ("show me #7"), never a durable identifier. Mappings are
# keyed by PATH, and `details` accepts either — so a script pins the path and a human
# types the number.

_CONTRACT_COLS = [
    ("category", "CATEGORY", 20),
    ("table", "TABLE", 16),
    ("owes", "OWES", 40),
    ("subject", "SUBJECT", 12),
]

# ⛔ EVERY COLUMN IS None (never truncate) — DELIBERATE, do not add caps back.
#
# `path` IS the id: `contract violation <path> details` takes it verbatim, so a
# clipped `gcp/artifact_regis…` cannot be copied back into the follow-up command —
# exactly the failure `_print_columns`' own docstring warns about. `outcome` clipped
# `UNPROVABLE_STATICALLY` to `UNPROVABLE_STATICA…`, which is not a value anyone can
# grep or filter on (`--outcome UNPROVABLE_STATICALLY`). And `owed` is the payload of
# the whole command — the edge list truncated to `exposed_via, owns,` silently HIDES
# `runs_on`, the single most-owed edge on the platform, making the debt read smaller
# than it is.
#
# These rows are short and bounded (102 mappings, longest path ~40 chars), so growing
# to fit costs nothing. A reader who wants fixed width has --format json.
_VIOLATION_COLS = [
    ("path", "MAPPING", None),
    ("table", "TABLE", None),
    ("outcome", "OUTCOME", None),
    ("owed", "OWED", None),
]


def _fetch_contract(ctx):
    """The contract itself (SA-only). Returns the parsed payload or exits."""
    client = _client(ctx)
    try:
        return client.get("entity-graph/relationship-contract")
    except AuthError as e:
        handle_auth_error(e)
        raise SystemExit(1)
    except APIError as e:
        handle_api_error(e)
        raise SystemExit(1)


def _fetch_violations(ctx, outcome=None, table=None, landing=False, tenant_id=None):
    """Every mapping's standing, with a stable positional ID assigned in listing
    order so `violation <id> details` and `violations` always agree."""
    client = _client(ctx)
    params = {}
    if outcome:
        params["outcome"] = outcome
    if table:
        params["table"] = table
    if landing:
        params["landing"] = "true"
        if tenant_id:
            params["tenant_id"] = tenant_id
    try:
        data = client.get("entity-graph/relationship-contract/violations",
                          params=params or None)
    except AuthError as e:
        handle_auth_error(e)
        raise SystemExit(1)
    except APIError as e:
        handle_api_error(e)
        raise SystemExit(1)
    # ⛔ NO POSITIONAL IDs. An earlier version numbered the rows, and the number was
    # never safe to use: it is a POSITION, so it shifts the moment a mapping is added,
    # fixed or reclassified — and this contract moved 21 -> 4 -> 27 in a single
    # session. Worse, filtering renumbered it, so `--outcome BREACHED` showed id 14
    # for one mapping while `violation 14 details` resolved a different one. Pinning
    # it against the unfiltered set fixed the inconsistency but not the decay.
    #
    # ⭐ The mapping PATH is already a deterministic, stable, meaningful key — it is
    # what the audit keys on, what the ratchet baseline records, and what a commit
    # message can quote a year from now. Use it and nothing else.
    return data


@entity_graph.group(name="contract", invoke_without_command=True)
@click.option("--violations", "violations_flag", is_flag=True, default=False,
              help="DEPRECATED — use `contract violations`. Kept so existing "
                   "scripts and CI jobs do not break.")
@click.option("--outcome", default=None, help="Filter to one outcome.")
@click.option("--table", "table", default=None, help="Filter to one destination table.")
@click.pass_context
def contract(ctx, violations_flag, outcome, table):
    """The relationship contract: which edges each (category, table) pair OWES.

    Four layers already describe CAPABILITY — the datalake schema (which columns
    exist), the category model (what a tool must produce), the entity graph (which
    columns each edge needs) and reachability (who can write a column). NONE of them
    describes OBLIGATION, which is why rows land correctly and connect to nothing.

    ⛔ The failure is silent by construction: the graph has no node table, so a row
    with no edge is not REPORTED as unconnected — it is ABSENT. Exposure is computed
    FROM the graph, so the platform answers "not exposed" with total confidence about
    assets it has never seen.

    Examples:
      torana entity-graph contract show                  read the contract
      torana entity-graph contract show --table assets   one destination table
      torana entity-graph contract violations            the outstanding debt
      torana entity-graph contract violation <path> details   one breach's gap analysis

    \b
    Super admin only — this is platform curation, not tenant data.
    """
    if ctx.invoked_subcommand is not None:
        return

    # ⚠️ Back-compat: `--violations` was the original surface and is wired into CI.
    # Route it to the subcommand rather than duplicating the body, so the two can
    # never drift in what they report or in their exit code.
    if violations_flag:
        ctx.invoke(contract_violations, outcome=outcome, table=table)
        return

    # ⛔ Bare `contract` prints HELP and exits 0 — it must NOT make a network call.
    # It used to read the contract, so an unauthenticated bare invocation failed with
    # "Not authenticated" instead of telling the reader what the group can do. That is
    # the one thing a bare group may never do (see ../CLAUDE.md § "CLI discoverability
    # contract", rule 4). The read moved to the explicit `show` verb below.
    click.echo(ctx.get_help())


@contract.command(name="show")
@click.option("--outcome", default=None, help="Filter to one outcome.")
@click.option("--table", "table", default=None, help="Filter to one destination table.")
@click.pass_context
def contract_show(ctx, outcome, table):
    """Read the relationship contract — which edges each (category, table) pair OWES.

    Examples:
      torana entity-graph contract show
      torana entity-graph contract show --table assets
      torana entity-graph contract show --json | jq '.[] | select(.owes | length == 0)'
    """
    fmt, raw, fields = _ctx(ctx)
    data = _fetch_contract(ctx)
    entries = data.get("entries") or []
    if table:
        entries = [e for e in entries if e.get("table") == table]

    if raw or fields or fmt not in ("text", "table"):
        output(entries, fmt=fmt, raw=raw, fields=fields)
        return

    rows = [{**e, "owes": ", ".join(e.get("owes") or []) or "— (owes nothing)"}
            for e in entries]
    output(rows, fmt="table", columns=_CONTRACT_COLS)
    click.echo(f"\n{len(rows)} classified (category, table) pair(s).")
    click.echo("An entry owing nothing is a REVIEWED DECISION; a pair with no entry "
               "at all is UNCLASSIFIED. They are different answers.")


@contract.command(name="violations")
@click.option("--outcome", default=None,
              help="Filter to one outcome (BREACHED, UNPROVABLE_STATICALLY, "
                   "NOT_OWED, NOT_A_SUBJECT, HONOURED, EXEMPT, UNCLASSIFIED).")
@click.option("--table", "table", default=None, help="Filter to one destination table.")
@click.pass_context
def contract_violations(ctx, outcome, table):
    """Every shipped mapping's standing against the contract, with an ID per row.

    ⛔ EXITS NON-ZERO when any listed mapping is BREACHED, so it is usable in CI.

    Outcomes are deliberately NOT collapsed to pass/fail:

      BREACHED               owes edges, derives none. The debt.
      UNPROVABLE_STATICALLY  derives, but a required column isn't visible in the
                             YAML — it may come from the extractor. A RUNTIME
                             question, not a violation.
      NOT_A_SUBJECT          the contract declares an obligation, but no owed edge
                             binds to this row shape. NOT a reviewed decision.
      NOT_OWED               reviewed and decided it owes nothing.
      UNCLASSIFIED           no contract entry — nobody decided. Not a pass.
      HONOURED               owes, derives, produces every required column.

    Use `contract violation <id> details` to see what one breach actually needs.
    """
    fmt, raw, fields = _ctx(ctx)
    data = _fetch_violations(ctx, outcome, table)
    mappings = data.get("mappings") or []
    summary = data.get("summary") or {}
    by_outcome = summary.get("by_outcome") or {}

    if raw or fields or fmt not in ("text", "table"):
        output(data, fmt=fmt, raw=raw, fields=fields)
    else:
        rows = [{**m, "owed": ", ".join(m.get("owed") or [])} for m in mappings]
        output(rows, fmt="table", columns=_VIOLATION_COLS)
        click.echo("")
        for k in ("BREACHED", "UNPROVABLE_STATICALLY", "NOT_A_SUBJECT",
                  "UNCLASSIFIED", "NOT_OWED", "HONOURED", "EXEMPT"):
            if by_outcome.get(k):
                click.echo(f"  {k:24} {by_outcome[k]}")
        click.echo(f"\n  {'TOTAL MAPPINGS':24} {summary.get('total_mappings', len(mappings))}")
        breached_here = [m for m in mappings if m.get("outcome") == "BREACHED"]
        if breached_here:
            click.echo(f"\n  Inspect one:  torana entity-graph contract violation "
                       f"{breached_here[0]['path']} details")

    # ⛔ EXIT NON-ZERO ON A BREACH so this is usable as a CI ratchet. Only BREACHED
    # fails: UNPROVABLE_STATICALLY is a runtime question the post-sync check owns,
    # and failing on it would flag the platform's own working reference producers.
    #
    # ⚠️ The exit status reflects WHAT WAS ASKED FOR, not the standing baseline. The
    # `summary` block is deliberately unfiltered (it IS the baseline), so reading the
    # breach count from it made `--outcome HONOURED` exit 1 while printing only
    # healthy rows. A command that fails while showing nothing wrong teaches people
    # to ignore its exit code — the one thing a CI gate cannot survive.
    breached = sum(1 for m in mappings if m.get("outcome") == "BREACHED")
    if breached:
        click.echo(f"\n⛔ {breached} mapping(s) BREACHED the relationship contract.",
                   err=True)
        ctx.exit(1)


# ⚠️ `violation <id> details` reads as group→arg→subcommand, but Click resolves the
# token after a GROUP as a subcommand NAME — so `violation gcp/compute_instances.yaml`
# was parsed as a command lookup and failed. Modelled instead as ONE command taking
# both tokens, which keeps the surface the user asked for while parsing correctly.
@contract.command(name="violation")
@click.option("--tenant-id", "tenant_id", default=None,
              help="With --landing: WHICH tenant's rows to measure. ⛔ Effectively "
                   "required — this command is SA-only and the SA tenant holds no "
                   "inventory, so without it you measure an empty table.")
@click.option("--landing", is_flag=True, default=False,
              help="Also measure how many rows in the destination table DO populate "
                   "each missing column. ⭐ Turns 'not in payload' into a work item: "
                   "if siblings have it, the column is demonstrably fillable. Needs "
                   "tenant data, so it is opt-in.")
@click.argument("ident")
@click.argument("verb", required=False, default="details",
                type=click.Choice(["details"], case_sensitive=False))
@click.pass_context
def contract_violation_details(ctx, tenant_id, landing, ident, verb):
    """Why THIS mapping breaches, and what each owed edge still needs.

    IDENT is the mapping PATH, e.g. `gcp/compute_instances.yaml`. ⭐ Deterministic
    by design: a path survives the listing being re-sorted, filtered, or the debt
    count changing, so it is safe to quote in a ticket or a commit. A unique suffix
    (`compute_instances.yaml`) also resolves.

    ⭐ Per owed edge it reports the required columns and which are missing, so the
    verdict names the OWNER of the fix rather than just the symptom:

      missing, but produced elsewhere in this mapping  -> a mapping fix
      missing from the payload entirely                -> ETL work
      the COLUMN DOES NOT EXIST on the table           -> a schema decision

    ⚠️ Static analysis: it proves a derivation CAN run, never that it PRODUCED
    anything. A mapping whose column arrives from the extractor looks missing here —
    which is exactly why UNPROVABLE_STATICALLY is its own outcome.
    """
    fmt, raw, fields = _ctx(ctx)
    data = _fetch_violations(ctx, landing=landing, tenant_id=tenant_id)
    mappings = data.get("mappings") or []

    match = next((m for m in mappings if m.get("path") == ident), None)
    if match is None:
        # A suffix match is the common typo (`compute_instances.yaml` for
        # `gcp/compute_instances.yaml`), and it is unambiguous whenever it hits once.
        near = [m for m in mappings
                if str(m.get("path", "")).endswith(ident)
                or ident in str(m.get("path", ""))]
        if len(near) == 1:
            match = near[0]
        else:
            click.echo(f"No mapping at path {ident!r}.", err=True)
            if near:
                click.echo("Did you mean one of:", err=True)
                for m in near[:8]:
                    click.echo(f"  {m['path']}", err=True)
            else:
                click.echo("List them with: torana entity-graph contract violations",
                           err=True)
            ctx.exit(2)

    if raw or fields or fmt not in ("text", "table"):
        output(match, fmt=fmt, raw=raw, fields=fields)
        return

    click.echo(f"MAPPING    {match.get('path')}")
    click.echo(f"TABLE      {match.get('table')}")
    click.echo(f"CATEGORIES {', '.join(match.get('categories') or []) or '—'}")
    click.echo(f"OUTCOME    {match.get('outcome')}")
    click.echo(f"DERIVES    {'yes' if match.get('derives_step') else 'NO — no derive_entity_edges step'}")

    owed = match.get("owed") or []
    click.echo(f"\nOWES       {', '.join(owed) or '— nothing'}")
    if match.get("breach_reasons"):
        click.echo(f"WHY        {', '.join(match['breach_reasons'])}")
    if match.get("missing_columns"):
        # ⭐ Per column: WHY it is missing, and therefore WHO fixes it. A flat list
        # gave `host_id` (no mapping can ever satisfy it) the same weight as
        # `service_name` (two lines of YAML), leaving the reader to redo the
        # classification by hand.
        verdicts = match.get("column_verdicts") or {}
        landing = match.get("column_landing") or {}
        explain = {
            "RECOVERABLE": "the payload already carries it → MAPPING fix",
            "NOT_IN_PAYLOAD": "the source never sends it → ETL work",
            "COLUMN_ABSENT": "⛔ not a column on this table → SCHEMA decision",
            "STAGING": "staging field (leading _), not a real column",
        }
        click.echo("\nMISSING COLUMNS (gate the owed edges):")
        for c in match["missing_columns"]:
            v = verdicts.get(c, "")
            line = f"  {c:22} {v:16} {explain.get(v, '')}"
            land = landing.get(c)
            if land and land.get("rows"):
                # ⭐ The falsifier: if sibling rows populate it, "the provider does
                # not supply this" is not available as an excuse.
                src = land.get("source") or "this source"
                if land["landed"]:
                    line += (f"\n  {'':22} ⭐ {land['landed']}/{land['rows']} "
                             f"{src} rows DO populate it — demonstrably fillable")
                else:
                    # ⚠️ 0/N is the OPPOSITE evidence and must not read as a nudge:
                    # no row from this source has ever carried it.
                    line += (f"\n  {'':22} ⚠️ 0/{land['rows']} {src} rows populate it "
                             f"— no precedent from this source")
            click.echo(line)
    if match.get("unsatisfiable_edges"):
        click.echo(f"\nEDGES THAT CANNOT DERIVE: "
                   f"{', '.join(match['unsatisfiable_edges'])}")
    if match.get("exempt_reason"):
        click.echo(f"\nEXEMPT     {match['exempt_reason']}")

    click.echo("\n⚠️ A missing column is not always a mapping fix. If the column does "
               "not exist on the table\n   it is a SCHEMA decision; if the source never "
               "sends it, it is ETL work. Adding a\n   derive step to silence the breach "
               "mints nothing and only hides it.")
