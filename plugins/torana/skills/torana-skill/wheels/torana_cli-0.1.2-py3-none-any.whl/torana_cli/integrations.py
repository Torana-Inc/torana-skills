"""torana integrations — integration collection management commands."""

import sys

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 30),
    ("provider", "PROVIDER", 20),
    ("status", "STATE", 12),
    # ⛔ NOT the same question as STATE. STATE is the lifecycle (active/paused);
    # HEALTH is whether the last sync actually collected everything. An
    # integration whose credential works but which is DENIED on some scope unit
    # (a GCP project, an AWS account) is `active` AND degraded — and until this
    # column existed the CLI, like the FE, showed only `active`, so a GCP
    # integration with 7 of 18 data sources collecting nothing looked healthy.
    ("health", "HEALTH", 10),
    # #162 — WHO OWNS THIS ROW. Deployment-owned integrations used to be omitted from
    # this list entirely, so a connected integration was indistinguishable from an
    # absent one on the canonical "what is connected?" surface. They are now listed,
    # and this column names the owner so a caller knows where to go to manage it.
    # ⛔ Never label these "internal" — a tenant reads that as Torana's rather than
    # theirs, which is false: it is THEIR integration, owned by their deployment.
    ("managed_by", "MANAGED BY", 24),
    ("last_sync_time", "LAST SYNC", 19),
    # When auto-sync will next run. Rendered RELATIVE ("in 2h") because the
    # question this column answers is "should I sync by hand right now?", and a
    # relative answer settles that without the reader doing clock arithmetic.
    ("next_sync_at", "NEXT SYNC", 14),
    ("semantic_description", "DESCRIPTION", 40),
]


def _fmt_ts(value):
    """Render an ISO timestamp as 'YYYY-MM-DD HH:MM:SS' for table output.

    The full ISO form ('2026-07-18T10:51:16.153331+00:00') overflows the column
    and gets ellipsized, which hides the very field the column exists to show.
    Anything unparseable is returned unchanged rather than dropped.
    """
    if not isinstance(value, str):
        return value
    return value.replace("T", " ")[:19]


def _fmt_next_sync(value):
    """Render next_sync_at as a relative 'in 2h' / 'due now'.

    ⛔ `None` is NOT unknown — it is a definite "nothing is scheduled", so it
    renders as 'not scheduled' rather than a blank cell. A blank reads as
    missing data and hides the actionable case: an integration that will never
    auto-sync and must be run by hand.
    """
    if not value:
        return "not scheduled"
    from datetime import datetime, timezone
    try:
        ts = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return str(value)
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=timezone.utc)
    secs = (ts - datetime.now(timezone.utc)).total_seconds()
    if secs <= 0:
        return "due now"
    if secs < 3600:
        return f"in {int(secs // 60)}m"
    if secs < 86400:
        return f"in {int(secs // 3600)}h {int((secs % 3600) // 60)}m"
    return f"in {int(secs // 86400)}d"


# ⛔ THESE MUST MATCH THE PAYLOAD'S ACTUAL KEYS (#28, third defect).
# The provider payload has NO `id` and NO `category`; it carries:
#   name · display_name · integration_type · description · supported_data_sources
#   icon · auth_fields · config_fields · available_data_sources · max_integrations
# The previous set named `id` and `category`, so half of every row rendered BLANK.
# ⚠️ That is the same class of failure as the unwrap bug it sat behind: the command
# returns 200 and prints a table, and the table is empty where it matters — so the
# output looks like a working command reporting sparse data, not a broken mapping.
_PROVIDER_COLS = [
    ("name", "NAME", 24),
    ("display_name", "DISPLAY NAME", 24),
    ("integration_type", "TYPE", 20),
    ("description", "DESCRIPTION", 44),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group()
def integrations():
    """Manage integrations (collection operations).

    \b
    Instance commands (get, update, delete, activate, etc.) are under:
      torana integration <UUID> <verb>

    \b
    Examples:
      torana integrations list
      torana integrations create --file github-integration.yaml
      torana integrations providers
    """


@integrations.command(name="list")
@click.option("--provider", default=None, help="Filter by provider name.")
@click.option("--state", default=None, help="Filter by state (active, inactive, error).")
@click.option("--search", default=None, help="Search by name.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.option("--exclude-managed", is_flag=True, default=False,
              help="Exclude integrations owned by a deployment. They are INCLUDED by "
                   "default and carry a MANAGED BY column naming the owner.")
@click.pass_context
def integrations_list(ctx, provider, state, search, page, page_size, fetch_all,
                      exclude_managed):
    """List integrations.

    Deployment-owned integrations are listed by DEFAULT, with a MANAGED BY column
    naming the owning deployment. ⛔ There is deliberately no `--include-managed`:
    an opt-IN default recreates the bug this fixed — the caller who does not know
    those rows exist is exactly the caller who cannot know to ask for them. Three
    sessions concluded "kubernetes is connected on NO tenant" from this command
    while the integration was connected the whole time (#162).

    Use `--exclude-managed` for the old, self-managed-only view.

    \b
    Examples:
      torana integrations list
      torana integrations list --provider github --state active
      torana integrations list --exclude-managed   # hide deployment-owned integrations
      torana integrations list --json | jq '.items[] | select(.state != "active") | .name'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    # Set into `params` (not only on the single-page call) because the --all loop
    # rebuilds skip/limit per page and copies every OTHER key from here — a flag added
    # at the single-page call site alone would be silently dropped by --all.
    if exclude_managed:
        params["exclude_managed"] = "true"
    if provider:
        params["provider"] = provider
    if state:
        params["state"] = state
    if search:
        params["search"] = search

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                p.update({k: v for k, v in params.items() if k not in ("skip", "limit")})
                data = client.get("/api/v1/integrations", params=p)
                items = data.get("integrations", data.get("items", data if isinstance(data, list) else []))
                all_items.extend(items)
                total = data.get("count", data.get("total", len(items))) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items), "page": 1,
                      "page_size": len(all_items)}
        else:
            data = client.get("/api/v1/integrations", params=params)
            if isinstance(data, dict) and "items" in data:
                result = data
            elif isinstance(data, dict) and "integrations" in data:
                result = {"items": data["integrations"],
                          "total": data.get("count", len(data["integrations"])),
                          "page": page, "page_size": effective_page_size}
            elif isinstance(data, list):
                result = {"items": data, "total": len(data),
                          "page": page, "page_size": effective_page_size}
            else:
                result = {"items": [], "total": 0,
                          "page": page, "page_size": effective_page_size}
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Render LAST SYNC as "YYYY-MM-DD HH:MM:SS" (19 chars) so it fits the column
    # untruncated. Table view only — json/yaml keep the full ISO value.
    if fmt in ("text", "table"):
        for _row in result.get("items", []):
            if not isinstance(_row, dict):
                continue
            if _row.get("last_sync_time"):
                _row["last_sync_time"] = _fmt_ts(_row["last_sync_time"])
            # Relative next-sync. Table/text only — --json keeps the real ISO
            # timestamp (and a real null) so scripts can compute against it.
            _row["next_sync_at"] = _fmt_next_sync(_row.get("next_sync_at"))
            # A self-managed integration has NO owner — render that as blank, not
            # the literal "None". "None" reads as a value and invites the question
            # "managed by None?", which is the opposite of the clarity this column
            # was added for. Text/table only; --json keeps the real null so
            # scripts can test `managed_by is None`.
            if _row.get("managed_by") in (None, ""):
                _row["managed_by"] = ""
            # HEALTH — derived for the table only; --json keeps the raw
            # `last_sync_status` so scripts test the real value rather than a
            # label. Blank (not "ok") when healthy: a column that says something
            # on every row stops being scannable, and the eye should land only on
            # the rows that need an action.
            _sync_status = str(_row.get("last_sync_status") or "").lower()
            if _row.get("auth_success") is False:
                _row["health"] = "auth-fail"
            elif _sync_status == "partial":
                _row["health"] = "degraded"
            elif _sync_status == "failed":
                _row["health"] = "failed"
            else:
                _row["health"] = ""

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@integrations.command(name="create")
@click.option("--name", default=None)
@click.option("--provider", default=None, help="Provider name (e.g. github, jira).")
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def integrations_create(ctx, name, provider, input_file):
    """Create a new integration.

    \b
    Example:
      torana integrations create --file github-integration.yaml
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if provider:
        body["provider"] = provider

    if not body.get("name"):
        click.echo("ERROR: --name is required (or provide --file with 'name' field).", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        # ⛔ NO TRAILING SLASH (#28). The integration service sets
        # FastAPI(redirect_slashes=False), so "/api/v1/integrations/" is not a route at
        # all and 404s -- it is NOT 307-redirected to the no-slash form. Measured:
        # POST /api/v1/integrations -> 422 (routed, body validated);
        # POST /api/v1/integrations/ -> 404 (unrouted). Every other call in this file
        # already uses the no-slash form.
        data = client.post("/api/v1/integrations", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created integration: {data.get('id', 'unknown')}")
        click.echo(f"  Name: {data.get('name', '')}")


@integrations.command(name="providers")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def integrations_providers(ctx, page, page_size, fetch_all):
    """List integration providers."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "/api/v1/integrations/providers"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Normalise the non-standard envelope key so the formatter can extract the list
    if isinstance(data, dict) and "providers" in data and "items" not in data:
        data = {"items": data["providers"], "total": len(data["providers"])}

    columns = [
        ("name", "NAME", 30),
        ("display_name", "DISPLAY NAME", 30),
        ("integration_type", "TYPE", 24),
        ("description", "DESCRIPTION", 50),
        ("max_integrations", "MAX", 5),
    ]
    output(data, fmt=fmt, fields=fields, raw=raw, columns=columns)


# ──────────────────────────────────────────────────────────────────────────
# Instance reads regrouped from `<noun>-by-<param>` leaves onto verbs
# (CLI Discoverability Contract, rule 2 — see ../CLAUDE.md). The route
# parameter belongs in the positional ARGUMENT, not the command name.
#
# Old flat names remain as HIDDEN aliases for ONE release (D4).
# ──────────────────────────────────────────────────────────────────────────


@integrations.group(name="provider")
def integrations_provider_grp():
    """One integration provider, or providers of one type.

    Examples:
      torana integrations provider get --help
    """


@integrations_provider_grp.command(name="get")
@click.argument("PROVIDER_NAME", metavar="PROVIDER_NAME")
@click.pass_context
def integrations_providers_by_provider_name(ctx, provider_name):
    """Get specific integration provider."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"/api/v1/integrations/providers/{provider_name}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@integrations.command(name="types")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def integrations_types(ctx, page, page_size, fetch_all):
    """List integration types."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "/api/v1/integrations/types"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@integrations_provider_grp.command(name="list")
@click.argument("INTEGRATION_TYPE", metavar="INTEGRATION_TYPE")
@click.pass_context
def integrations_providers_by_type(ctx, integration_type):
    """List providers by type."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"/api/v1/integrations/types/{integration_type}/providers"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@integrations.command(name="semantic")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--q", "q", required=True, help="Natural language query (e.g., 'communication service')")
@click.option("--limit", "limit", type=int, default=10, help="Maximum number of results")
@click.option("--threshold", "threshold", type=float, default=0.3, help="Minimum similarity threshold")
@click.option("--category", "category", default=None, help="Filter by integration category")
@click.option("--include-inactive", "include_inactive", type=bool, default=False, help="Include inactive integrations")
@click.pass_context
def integrations_semantic(ctx, q, limit, threshold, category, include_inactive, page, page_size, fetch_all):
    """Semantic integration search."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "/api/v1/integrations/search/semantic"
    params = {}
    if q is not None:
        params["q"] = q
    if limit is not None:
        params["limit"] = limit
    if threshold is not None:
        params["threshold"] = threshold
    if category is not None:
        params["category"] = category
    if include_inactive is not None:
        params["include_inactive"] = include_inactive
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@integrations.command(name="bulk-generate-embeddings")
@click.option("--force-regenerate", "force_regenerate", type=bool, default=False, help="Force regeneration of existing embeddings")
@click.pass_context
def integrations_bulk_generate_embeddings(ctx, force_regenerate):
    """Bulk generate embeddings."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "/api/v1/integrations/bulk-generate-embeddings"
    params = {}
    if force_regenerate is not None:
        params["force_regenerate"] = force_regenerate

    client = _client(ctx)
    try:
        data = client.post(path, json={}, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ---------------------------------------------------------------------------
# providers sub-group
# ---------------------------------------------------------------------------

@click.group()
def providers():
    """List integration providers.

    \b
    Examples:
      torana providers list
      torana providers list --search github
    """


@providers.command(name="list")
@click.option("--search", default=None, help="Search providers by name or category.")
@click.option("--category", default=None, help="Filter by category.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def providers_list(ctx, search, category, page, page_size):
    """List available integration providers."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if search:
        params["search"] = search
    if category:
        params["category"] = category

    client = _client(ctx)
    try:
        # ⛔ NO TRAILING SLASH (#28) -- see the note at `integrations create`.
        data = client.get("/api/v1/integrations/providers", params=params)
        # ⛔ TWO defects produced one symptom here (#28 § 2.4), and fixing only the slash
        # leaves this command still printing "No results." on a 200 with 25 providers.
        # The endpoint returns {"providers": [...], "count": 25} -- there is no "items"
        # key and `data` is a dict, not a list, so the old ternary fell to the else
        # branch and coerced items to []. Mirrors the envelope handling that
        # `integrations list` above already does for its {"integrations", "count"} shape.
        # ⚠️ Keep the "items"/"total" branch: other endpoints DO return that envelope.
        items = data.get("providers", data.get("items", [])) if isinstance(data, dict) else (
            data if isinstance(data, list) else [])
        total = data.get("count", data.get("total", len(items))) if isinstance(data, dict) else len(items)
        result = {"items": items, "total": total,
                  "page": page, "page_size": effective_page_size}
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_PROVIDER_COLS)


@providers.command(name="search")
@click.argument("query", metavar="QUERY")
@click.pass_context
def providers_search(ctx, query):
    """Search for integration providers.

    \b
    Example:
      torana providers search github
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        # ⛔ NO TRAILING SLASH (#28), and the SAME envelope fix as `providers list` --
        # this site feeds the identical unwrap and returns the identical
        # {"providers": [...], "count": N} shape. Verified against the live endpoint
        # rather than assumed, because it passes different params (§ 2.4).
        data = client.get("/api/v1/integrations/providers", params={"search": query, "limit": 100})
        items = data.get("providers", data.get("items", [])) if isinstance(data, dict) else (
            data if isinstance(data, list) else [])
        total = data.get("count", data.get("total", len(items))) if isinstance(data, dict) else len(items)
        result = {"items": items, "total": total}
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, fields=fields, columns=_PROVIDER_COLS)


# ---------------------------------------------------------------------------
# ETL — mapping configs, runs, operators, preview
# ---------------------------------------------------------------------------

@click.group()
def etl():
    """Manage ETL pipelines and mapping configurations.

    \b
    Examples:
      torana etl mappings list
      torana etl mappings get <UUID>
      torana etl runs list
      torana etl runs trigger --integration-id <UUID>
      torana etl operators
    """


def _fmt_elapsed(seconds):
    """Compact duration for the live-status table: 45s, 4m, 1h 12m.

    Server-computed seconds, so no clock agreement with this machine is needed.
    """
    if seconds is None:
        return "-"
    try:
        seconds = float(seconds)
    except (TypeError, ValueError):
        return "-"
    if seconds < 0:
        return "-"
    if seconds < 60:
        return f"{int(seconds)}s"
    mins = int(seconds // 60)
    if mins < 60:
        return f"{mins}m"
    return f"{mins // 60}h {mins % 60}m"


@etl.command(name="live-status")
@click.option("--tenant-id", default=None,
              help="SA-only cross-tenant read. Omitted => the caller's own tenant.")
@click.option("--syncing-only", is_flag=True, default=False,
              help="Show only integrations that are syncing (or stalled) right now.")
@click.pass_context
def etl_live_status(ctx, tenant_id, syncing_only):
    """What is syncing RIGHT NOW, how far along, and for how long.

    \b
    The same cheap poll the Integrations page uses to come alive — two indexed
    reads over etl_sync_run_details, no joins. Use it to answer "is anything
    running?" without tailing logs.

    \b
      SYNCING   a run is in flight
      STALLED   a run is recorded running but its heartbeat has gone quiet for
                >5 min — the process most likely died. It is NOT progressing;
                the startup reaper marks such rows abandoned, and re-running the
                sync is safe (it resumes from the committed cursor).
      idle      nothing running; LAST shows how the previous run ended

    \b
    PROGRESS is X/Y over the current sync BATCH — the runs one Sync action
    created — not the integration's configured data-source list. Syncing 3 of 17
    configured sources reads 2/3, not 2/17.

    \b
    Examples:
      torana etl live-status
      torana etl live-status --syncing-only
      torana etl live-status --json | jq '.items[] | select(.is_syncing)'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    path = "admin/etl/integrations/live-status"
    if tenant_id:
        path += f"?tenant_id={tenant_id}"
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml"):
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    rows = data.get("items", []) if isinstance(data, dict) else []
    items = []
    for r in rows:
        syncing, stalled = r.get("is_syncing"), r.get("is_stalled")
        if syncing_only and not (syncing or stalled):
            continue
        total = r.get("total_sources") or 0
        items.append({
            "integration_id": r.get("integration_id"),
            # ⛔ STALLED is its own state, never folded into SYNCING: one is
            # progressing and the other has stopped, and they need different
            # responses from the reader.
            "state": "STALLED" if stalled else ("SYNCING" if syncing else "idle"),
            # "-" rather than "0/0": a batch size we do not know is not zero.
            "progress": f"{r.get('done_sources', 0)}/{total}" if total else "-",
            "elapsed": _fmt_elapsed(r.get("elapsed_s")),
            "sources": ", ".join(r.get("active_data_sources") or []) or "-",
            "records": r.get("records_in") or 0,
            "last": r.get("last_status") or "-",
        })

    # Running first, then stalled, then idle — the rows worth acting on at the top.
    _order = {"SYNCING": 0, "STALLED": 1, "idle": 2}
    items.sort(key=lambda x: (_order.get(x["state"], 9), x["integration_id"]))

    syncing_count = data.get("syncing_count", 0) if isinstance(data, dict) else 0
    print(f"SYNCING NOW  {syncing_count}")
    print()

    output(
        {"items": items, "total": len(items)},
        fmt=fmt, raw=raw, fields=fields,
        columns=[
            ("integration_id", "INTEGRATION", 38),
            ("state", "STATE", 9),
            ("progress", "PROGRESS", 9),
            ("elapsed", "ELAPSED", 9),
            ("records", "RECORDS", 8),
            ("sources", "RUNNING NOW", 30),
            ("last", "LAST", 10),
        ],
    )


@etl.command(name="table-sync-status")
@click.pass_context
def etl_table_sync_status(ctx):
    """Latest sync status + last-synced time for every datalake sink table.

    \b
    The state of the MOST RECENT run of each pipeline writing a table, rolled up
    worst-wins — so a table fed by four integrations where one is failing reads
    `failed`, not `success`. Same run rows as `torana etl runs list`, keyed by
    destination table instead of by run.

    \b
      success       every writer's newest run succeeded
      partial       a writer completed but dropped records to the DLQ
      failed        a writer's newest run failed or was incomplete
      syncing       a writer is running right now
      never_synced  no pipeline has ever written this table
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("etl/table-sync-status")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml"):
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    tables = data.get("tables", {}) if isinstance(data, dict) else {}
    items = [
        {
            "table": name,
            "status": st.get("status"),
            "last_synced": st.get("last_synced") or "-",
            # "1/17" reads as "one of seventeen writers is failing" — the number
            # that decides whether `failed` means a whole dead pipeline or one
            # bad source among many.
            "failing": f"{st.get('failing_writers', 0)}/{st.get('writers', 0)}",
        }
        for name, st in tables.items()
    ]
    # Newest sync first; tables never synced sink to the bottom.
    items.sort(key=lambda r: (r["last_synced"] or ""), reverse=True)

    unresolved = data.get("unresolved_runs", 0) if isinstance(data, dict) else 0
    if unresolved:
        # Reported, never silently dropped: runs whose destination table could
        # not be resolved are missing from every row above.
        print(f"UNRESOLVED RUNS  {unresolved} (no destination table could be resolved)")
        print()

    output(
        {"items": items, "total": len(items)},
        fmt=fmt, raw=raw, fields=fields,
        columns=[
            ("table", "TABLE", 24),
            ("status", "STATUS", 14),
            ("failing", "FAILING", 9),
            ("last_synced", "LAST SYNCED", 32),
        ],
    )


@etl.group(name="mappings")
def etl_mappings():
    """Manage ETL mapping configurations."""


@etl_mappings.command(name="list")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.pass_context
def etl_mappings_list(ctx, page, page_size, fetch_all):
    """List ETL mapping configs."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get("etl/mappings", params=p)
                items = data.get("items", data if isinstance(data, list) else [])
                all_items.extend(items)
                total = data.get("total", len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items), "page": 1, "page_size": len(all_items)}
        else:
            data = client.get("etl/mappings", params=params)
            result = data if isinstance(data, dict) and "items" in data else {
                "items": data if isinstance(data, list) else [],
                "total": len(data) if isinstance(data, list) else 0,
                "page": page, "page_size": effective_page_size,
            }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields,
           columns=[("id", "ID", 36), ("name", "NAME", 30), ("status", "STATUS", 12)])


@etl_mappings.command(name="get")
@click.argument("config_id", metavar="CONFIG_ID")
@click.pass_context
def etl_mappings_get(ctx, config_id):
    """Get an ETL mapping config by ID."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"etl/mappings/{config_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@etl_mappings.command(name="create")
@click.option("--file", "input_file", required=True, metavar="FILE",
              help="JSON/YAML file with mapping config body.")
@click.pass_context
def etl_mappings_create(ctx, input_file):
    """Create an ETL mapping config."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = _load_input_file(input_file)

    client = _client(ctx)
    try:
        data = client.post("etl/mappings", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created ETL mapping: {data.get('id', 'unknown')}")


@etl_mappings.command(name="update")
@click.argument("config_id", metavar="CONFIG_ID")
@click.option("--file", "input_file", required=True, metavar="FILE",
              help="JSON/YAML file with mapping config body.")
@click.pass_context
def etl_mappings_update(ctx, config_id, input_file):
    """Update (bump version of) an ETL mapping config."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = _load_input_file(input_file)

    client = _client(ctx)
    try:
        data = client.put(f"etl/mappings/{config_id}", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated ETL mapping: {config_id}")


@etl_mappings.command(name="delete")
@click.argument("config_id", metavar="CONFIG_ID")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def etl_mappings_delete(ctx, config_id, yes):
    """Soft-delete an ETL mapping config."""
    _confirm(f"Delete ETL mapping {config_id}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"etl/mappings/{config_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted ETL mapping: {config_id}")


@etl_mappings.command(name="resolved")
@click.argument("config_id", metavar="CONFIG_ID")
@click.pass_context
def etl_mappings_resolved(ctx, config_id):
    """Get the resolved (compiled) form of an ETL mapping config."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"etl/mappings/{config_id}/resolved")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@etl_mappings.command(name="fetch-sample")
@click.argument("config_id", metavar="CONFIG_ID")
@click.option("--limit", "limit", default=None, type=click.IntRange(1, 200),
              help="Max records to pull (server default applies when omitted).")
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def etl_mappings_fetch_sample(ctx, config_id, limit, input_file):
    """Fetch a data sample for an ETL mapping config.

    Calls the integration's extractor LIVE and caches the raw records (no pipeline
    operators applied) for the mapping playground and `torana etl mapping-report`.
    Cached samples expire after 7 days and each fetch REPLACES the previous batch.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = _load_input_file(input_file) if input_file else {}
    # ⚠️ `limit` is a QUERY parameter on this endpoint, not a body field — passing it
    # in the body is silently ignored and you get the server default instead.
    path = f"etl/mappings/{config_id}/fetch-sample"
    if limit is not None:
        path = f"{path}?limit={limit}"

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@etl_mappings.command(name="samples")
@click.argument("config_id", metavar="CONFIG_ID")
@click.pass_context
def etl_mappings_samples(ctx, config_id):
    """List cached samples for an ETL mapping config."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"etl/mappings/{config_id}/samples")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


# ETL runs

@etl.group(name="runs")
def etl_runs():
    """Manage ETL pipeline runs."""


@etl_runs.command(name="list")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.pass_context
def etl_runs_list(ctx, page, page_size, fetch_all):
    """List ETL pipeline runs for this tenant."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    # Use etl/admin/runs (the etl_sync_run_details serializer) rather than the legacy /etl/runs
    # (sync_logs) — it carries the full audit fields: stop_reason, records_in, sync_session_id,
    # resume_depth. Tenant-scoped + integrations:read gated, so a tenant sees only their own runs.
    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get("etl/admin/runs", params=p)
                items = data.get("items", data if isinstance(data, list) else [])
                all_items.extend(items)
                total = data.get("total", len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items), "page": 1, "page_size": len(all_items)}
        else:
            data = client.get("etl/admin/runs", params=params)
            result = data if isinstance(data, dict) and "items" in data else {
                "items": data if isinstance(data, list) else [],
                "total": len(data) if isinstance(data, list) else 0,
                "page": page, "page_size": effective_page_size,
            }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # A 'partial' run means records were DROPPED, but the run row alone never says why —
    # that cost a psql fallback. Resolve the top DLQ error for the runs that dropped
    # something and show it inline, so `partial` explains itself in one command.
    _annotate_runs_with_dlq(client, result)

    # Column caps are min AND max width (content truncates with … past the cap). Size the
    # identifying/audit fields to their full natural length so they are NEVER truncated:
    # run_id (36 = full UUID), data_source (30 = 'container_analysis_occurrences'), started_at
    # (26 = full ISO-8601). RECORDS wide enough for 6-figure counts.
    output(result, fmt=fmt, raw=raw, fields=fields,
           columns=[("run_id", "RUN ID", 36), ("status", "STATUS", 11),
                    ("stop_reason", "STOP REASON", 26), ("data_source", "SOURCE", 30),
                    ("records_in", "RECORDS", 8), ("dlq_count", "DLQ", 6),
                    ("top_error", "TOP DLQ ERROR", 60),
                    ("resume_depth", "RSM", 4), ("started_at", "STARTED", 29)])

    if any((r.get("dlq_count") or 0) for r in result.get("items", [])):
        click.echo("\nRuns with DLQ > 0 dropped records. Full error + the dropped record:"
                   "\n  torana etl dlq list --run-id <RUN ID> --group-by-error")


def _annotate_runs_with_dlq(client, result, max_lookups=10):
    """Fill `top_error` on each run row that has dlq_count > 0.

    One summary call per affected run (the summary is grouped server-side, so a run
    with 80k drops costs one small request). Capped at `max_lookups` runs so a long
    listing can't fan out into a slow burst; rows beyond the cap simply show no
    top_error rather than a wrong one.

    Purely additive decoration — ANY failure here leaves the row untouched. A DLQ
    lookup problem must never take down `runs list`, which has to keep working when
    the ETL subsystem is the thing that's broken.
    """
    items = result.get("items", []) if isinstance(result, dict) else []
    looked_up = 0
    for row in items:
        if not isinstance(row, dict):
            continue
        row.setdefault("top_error", "")
        if not (row.get("dlq_count") or 0):
            continue
        if looked_up >= max_lookups:
            continue
        run_id = row.get("run_id")
        if not run_id:
            continue
        looked_up += 1
        try:
            data = client.get("etl/admin/dlq/summary",
                              params={"run_id": run_id, "limit": 1})
            groups = data.get("items", []) if isinstance(data, dict) else []
            if groups:
                top = groups[0]
                msg = f"{top.get('error_class') or ''}: {top.get('error_message') or ''}"
                row["top_error"] = msg.strip(": ")
        except Exception:
            # Decoration only — leave top_error blank and keep listing runs.
            continue


@etl_runs.command(name="trigger")
@click.option("--integration-id", "integration_id", required=True, help="Integration to run.")
@click.option("--data-source", "data_source", required=True,
              help="Data source to sync (e.g. container_analysis_occurrences, users). Required by the API.")
@click.option("--file", "input_file", default=None, metavar="FILE",
              help="Optional JSON/YAML body (backfill params etc.).")
@click.pass_context
def etl_runs_trigger(ctx, integration_id, data_source, input_file):
    """Trigger an ad-hoc or backfill ETL pipeline run.

    \b
    Example:
      torana etl runs trigger --integration-id <UUID> --data-source container_analysis_occurrences
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = _load_input_file(input_file) if input_file else {}
    body["integration_id"] = integration_id
    body["data_source"] = data_source

    client = _client(ctx)
    try:
        data = client.post("etl/runs", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Triggered ETL run: {data.get('run_id', 'unknown')}")


@etl_runs.command(name="get")
@click.argument("run_id", metavar="RUN_ID")
@click.pass_context
def etl_runs_get(ctx, run_id):
    """Get detail for a single ETL run."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"etl/runs/{run_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


def _print_sync_session(data, fmt, fields, raw):
    """Render a sync-session rollup (human summary + per-run chain). Shared by the singular
    `etl run <id> session` command."""
    if fmt != "text":
        output(data, fmt=fmt, fields=fields, raw=raw)
        return
    click.echo(f"Sync session {data.get('sync_session_id')}")
    click.echo(f"  source        : {data.get('source')} / {data.get('data_source')}")
    click.echo(f"  runs          : {data.get('run_count')}  "
               f"(pauses={data.get('pause_count')}, resumes={data.get('resume_count')})")
    click.echo(f"  started       : {data.get('started_at')}")
    click.echo(f"  finished      : {data.get('finished_at')}")
    click.echo(f"  total wall    : {data.get('total_wall_clock_s')}s  "
               f"(active {data.get('total_active_elapsed_s')}s)")
    click.echo(f"  records in    : {data.get('total_records_in')}  "
               f"(out {data.get('total_records_out')}, dlq {data.get('total_dlq')})")
    click.echo(f"  final outcome : {data.get('final_status')} ({data.get('final_stop_reason')})")
    click.echo("  chain:")
    output({"items": data.get("runs", []), "total": data.get("run_count", 0),
            "page": 1, "page_size": data.get("run_count", 0)},
           fmt="text", raw=False, fields=None,
           columns=[("resume_depth", "#", 3), ("run_id", "RUN ID", 36),
                    ("status", "STATUS", 11), ("stop_reason", "STOP REASON", 26),
                    ("records_in", "RECORDS", 8), ("started_at", "STARTED", 29)])


# ─── singular: torana etl run <RUN_ID> <verb> (instance ops) ───────────────────

@etl.group(name="run", invoke_without_command=True)
@click.argument("run_id", metavar="RUN_ID")
@click.pass_context
def etl_run(ctx, run_id):
    """Operate on a single ETL run by id (get, session).

    \b
    Examples:
      torana etl run <RUN_ID> get
      torana etl run <RUN_ID> session   # roll up the whole sync session this run belongs to
    """
    ctx.ensure_object(dict)
    ctx.obj["_run_id"] = run_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _run_id(ctx) -> str:
    return ctx.obj.get("_run_id", "") if ctx.obj else ""


@etl_run.command(name="get")
@click.pass_context
def etl_run_get(ctx):
    """Get detail for this ETL run."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get(f"etl/runs/{_run_id(ctx)}")
    except APIError as e:
        handle_api_error(e); return
    except AuthError as e:
        handle_auth_error(e); return
    output(data, fmt=fmt, fields=fields)


@etl_run.command(name="session")
@click.pass_context
def etl_run_session(ctx):
    """Roll up the whole SYNC SESSION this run belongs to — one auditable sync.

    A big sync often drains across MANY runs (each = one execution window that yields when it
    elapses, then auto-resumes from the committed cursor). This reconstructs the whole chain:
    when it started, how many times it paused + why, when it finished, total duration, and total
    records — the "how long did my sync actually take" answer, entirely from the DB. You pass a
    RUN ID (any run in the chain, e.g. from `torana etl runs list`); the session is derived.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    rid = _run_id(ctx)
    client = _client(ctx)
    # 1. Resolve this run's sync_session_id from its detail.
    try:
        run = client.get(f"etl/admin/runs/{rid}")
    except APIError as e:
        handle_api_error(e); return
    except AuthError as e:
        handle_auth_error(e); return
    session_id = run.get("sync_session_id") or rid   # first run's session == its own id
    # 2. Roll up the session.
    try:
        data = client.get(f"etl/admin/sync-sessions/{session_id}")
    except APIError as e:
        handle_api_error(e); return
    except AuthError as e:
        handle_auth_error(e); return
    _print_sync_session(data, fmt, fields, raw)


@etl_runs.command(name="stats")
@click.pass_context
def etl_runs_stats(ctx):
    """Get aggregate ETL run stats for this tenant."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("etl/runs/stats")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@etl_runs.command(name="dlq")
@click.argument("run_id", metavar="RUN_ID")
@click.pass_context
def etl_runs_dlq(ctx, run_id):
    """List DLQ (dead-letter queue) entries for an ETL run."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"etl/runs/{run_id}/dlq")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@etl_runs.command(name="dlq-replay")
@click.argument("run_id", metavar="RUN_ID")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def etl_runs_dlq_replay(ctx, run_id, yes):
    """Replay DLQ entries for a finished ETL run."""
    _confirm(f"Replay DLQ for run {run_id}?", yes=yes)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"etl/dlq/{run_id}/replay", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Replayed DLQ for run: {run_id}")


# ETL operators + preview

@etl.command(name="operators")
@click.pass_context
def etl_operators(ctx):
    """List available ETL pipeline operators."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("etl/operators")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields,
           columns=[("name", "NAME", 30), ("type", "TYPE", 20), ("description", "DESCRIPTION", 50)])


@etl.command(name="preview-step")
@click.option("--file", "input_file", required=True, metavar="FILE",
              help="JSON/YAML file describing the step to preview.")
@click.pass_context
def etl_preview_step(ctx, input_file):
    """Preview the output of a single ETL pipeline step."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = _load_input_file(input_file)

    client = _client(ctx)
    try:
        data = client.post("etl/preview-step", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@etl.command(name="preview-pipeline")
@click.option("--file", "input_file", required=True, metavar="FILE",
              help="JSON/YAML file describing the pipeline to preview.")
@click.pass_context
def etl_preview_pipeline(ctx, input_file):
    """Preview the output of a full ETL pipeline."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = _load_input_file(input_file)

    client = _client(ctx)
    try:
        data = client.post("etl/preview-pipeline", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt)


@etl.command(name="data-sources")
@click.argument("integration_id", metavar="INTEGRATION_ID")
@click.pass_context
def etl_data_sources(ctx, integration_id):
    """List enabled data sources for an integration (ETL view)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"etl/integrations/{integration_id}/data-sources")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@etl.command(name="mapping-report")
@click.option("--source", "source", default=None, help="Filter to one provider, e.g. 'github'.")
@click.option("--data-source", "data_source", default=None, help="Filter to one data source.")
@click.option("--replay-limit", "replay_limit", default=8, show_default=True, type=int,
              help="Records to replay per mapping. More records expose fallback "
                   "branches ('a or b') that one record hides.")
@click.option("--all-mappings", "all_mappings", is_flag=True, default=False,
              help="Include mappings whose data source is not enabled for this tenant.")
@click.pass_context
def etl_mapping_report(ctx, source, data_source, replay_limit, all_mappings):
    """What actually fills each datalake column — proved against live rows.

    Replays CACHED extractor samples through the real mapping operators, attributes
    every column to the step that wrote it, and diffs the result against the row the
    datalake holds.

    \b
    ⚠️ POPULATE SAMPLES FIRST — this never calls a source API:
        torana etl mappings fetch-sample <CONFIG_ID>
    A mapping with no cached sample is reported as declared-not-proven, never
    silently skipped. Samples expire after 7 days.

    \b
    Verdicts (per column):
      PROVEN        replayed value == stored value
      DIFFERS       both present and different — see differs_reason, which names the
                    cause (timestamp coercion, preserve-on-upsert, source drift, ...)
      ONLY-LANDED   populated, but NO mapping step writes it (decoration/agent/platform)
      ONLY-REPLAY   the mapping produced it and it never landed
      UNVERIFIED    no sample to replay, or a side-effecting step

    \b
    Examples:
      torana etl mapping-report --data-source dependabot_alerts
      torana etl mapping-report --json | jq '.mappings[].dropped_at_validate'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = {"replay_limit": replay_limit, "enabled_only": not all_mappings}
    if source:
        body["source"] = source
    if data_source:
        body["data_source"] = data_source

    client = _client(ctx)
    try:
        data = client.post("etl/mapping-report", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    # Text rendering: a per-mapping summary plus the findings a reader ACTS on.
    # ⛔ Not the 650-row column dump — that is what --json is for. A wall of rows
    # in a terminal buries the three lines that matter.
    click.echo(f"Tenant {data.get('tenant_id')}   {data.get('generated_at')}")
    click.echo(f"{data.get('mappings_reported')} mapping(s), "
               f"{data.get('mappings_with_samples')} with samples · "
               f"{data.get('columns_total')} columns, {data.get('columns_proven')} PROVEN")
    click.echo("")
    click.echo(f"  {'source/data_source':40s} {'replayed':>8} {'matched':>8}  evidence")
    click.echo("  " + "-" * 100)
    for m in data.get("mappings", []):
        name = f"{m['source']}/{m['data_source']}"
        click.echo(f"  {name:40s} {m['samples_replayed']:>8} {m['landed_rows_matched']:>8}  {m['evidence']}")

    dropped = [(m["data_source"], m["dropped_at_validate"])
               for m in data.get("mappings", []) if m.get("dropped_at_validate")]
    if dropped:
        click.echo("")
        click.echo("  Written by a mapping but NOT a column — discarded at validate:")
        for ds, cols in dropped:
            click.echo(f"    {ds:34s} {', '.join(cols)}")

    no_sample = [f"{m['source']}/{m['data_source']}"
                 for m in data.get("mappings", []) if not m["samples_replayed"]]
    if no_sample:
        click.echo("")
        click.echo(f"  {len(no_sample)} mapping(s) DECLARED but not proven (no cached sample):")
        click.echo(f"    {', '.join(no_sample)}")
        click.echo("    Populate with: torana etl mappings fetch-sample <CONFIG_ID>")

    if data.get("note"):
        click.echo("")
        click.echo(f"  {data['note']}")


# ---------------------------------------------------------------------------
# Tenant-scoped ETL admin (under /api/v1/etl/admin/*)
# ---------------------------------------------------------------------------

@etl.group(name="admin")
def etl_admin():
    """ETL admin operations (tenant-scoped).

    \b
    Examples:
      torana etl admin dlq
      torana etl admin drift
      torana etl admin runs list
      torana etl admin sync-overview
    """


@etl_admin.command(name="dlq")
@click.pass_context
def etl_admin_dlq(ctx):
    """DLQ console for this tenant."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("etl/admin/dlq")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@etl_admin.command(name="dlq-mark-replayed")
@click.argument("entry_id", metavar="ENTRY_ID")
@click.pass_context
def etl_admin_dlq_mark_replayed(ctx, entry_id):
    """Mark a DLQ entry as replayed (tenant)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.patch(f"etl/admin/dlq/{entry_id}", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Marked DLQ entry as replayed: {entry_id}")


@etl_admin.command(name="drift")
@click.pass_context
def etl_admin_drift(ctx):
    """Drift log for this tenant."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("etl/admin/drift")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@etl_admin.command(name="sync-overview")
@click.pass_context
def etl_admin_sync_overview(ctx):
    """Sync overview for this tenant (one row per integration)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("etl/admin/integrations/sync-overview")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@etl_admin.command(name="runs")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.pass_context
def etl_admin_runs(ctx, page, page_size, fetch_all):
    """Tenant run history (ETL admin detail)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get("etl/admin/runs", params=p)
                items = data.get("items", data if isinstance(data, list) else [])
                all_items.extend(items)
                total = data.get("total", len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get("etl/admin/runs", params=params)
            result = data if isinstance(data, dict) and "items" in data else {
                "items": data if isinstance(data, list) else [],
                "total": len(data) if isinstance(data, list) else 0,
            }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields,
           columns=[("run_id", "RUN ID", 36), ("status", "STATUS", 11), ("stop_reason", "STOP REASON", 24),
                    ("integration_id", "INTEGRATION", 36), ("started_at", "STARTED", 20)])


@etl_admin.command(name="runs-active")
@click.pass_context
def etl_admin_runs_active(ctx):
    """Currently-executing pipeline runs for this tenant."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("etl/admin/runs/active")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@etl_admin.command(name="run")
@click.argument("run_id", metavar="RUN_ID")
@click.pass_context
def etl_admin_run(ctx, run_id):
    """Tenant run detail with operator metrics, drift, and DLQ entries."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"etl/admin/runs/{run_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@etl_admin.command(name="stats")
@click.pass_context
def etl_admin_stats(ctx):
    """Aggregate run stats for this tenant."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("etl/admin/stats")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@etl_admin.command(name="trigger")
@click.option("--integration-id", "integration_id", required=True,
              help="Integration to manually trigger.")
@click.option("--file", "input_file", default=None, metavar="FILE",
              help="Optional JSON/YAML body.")
@click.pass_context
def etl_admin_trigger(ctx, integration_id, input_file):
    """Manually trigger a pipeline run for this tenant.

    \b
    Example:
      torana etl admin trigger --integration-id <UUID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = _load_input_file(input_file) if input_file else {}
    body["integration_id"] = integration_id

    client = _client(ctx)
    try:
        data = client.post("etl/admin/ops/trigger", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        run_id = data.get("run_id", "unknown") if isinstance(data, dict) else "unknown"
        click.echo(f"Triggered ETL run: {run_id}")


@etl_admin.command(name="trigger-batch")
@click.option("--integration-id", "integration_id", required=True,
              help="Integration to sync (this tenant).")
@click.option("--data-source", "data_sources", multiple=True,
              help="Sync only this data source (repeatable). Omit = ALL syncable sources.")
@click.option("--mode", default="normal", type=click.Choice(["normal", "backfill"]),
              show_default=True)
@click.pass_context
def etl_admin_trigger_batch(ctx, integration_id, data_sources, mode):
    """Trigger a group sync across one-or-more data sources (default ALL) for this tenant.

    \b
    Every spawned run shares one sync_batch_id. Omit --data-source to sync everything.

    \b
    Examples:
      torana etl admin trigger-batch --integration-id <IID>
      torana etl admin trigger-batch --integration-id <IID> \\
        --data-source iam_members --data-source compute_instances
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {"integration_id": integration_id, "mode": mode}
    if data_sources:
        body["data_sources"] = list(data_sources)

    client = _client(ctx)
    try:
        data = client.post("etl/admin/ops/trigger-batch", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        if isinstance(data, dict):
            click.echo(f"Batch triggered: {data.get('sync_batch_id', 'unknown')}")
            click.echo(f"  triggered {data.get('triggered_count', 0)} data source(s)"
                       f"{', skipped ' + str(data.get('skipped')) if data.get('skipped') else ''}")
        else:
            click.echo(str(data))


# ---------------------------------------------------------------------------
# ETL DLQ console (tenant) — `torana etl dlq list` / `summary`
# ---------------------------------------------------------------------------

def _parse_since(since: str) -> str:
    """Turn a duration like '2h' / '30m' / '7d' into an absolute ISO-8601 UTC timestamp.

    The API filters on an absolute `created_after`, so the relative form is resolved
    here. Accepts s/m/h/d suffixes, or a bare ISO timestamp which is passed through.
    Raises click.BadParameter on anything else so the user gets a clean one-line
    error instead of a traceback or a silently-ignored filter.
    """
    s = (since or "").strip()
    if not s:
        raise click.BadParameter("--since cannot be empty")
    # A full ISO timestamp passes straight through.
    if len(s) >= 10 and s[4] == "-":
        return s
    units = {"s": "seconds", "m": "minutes", "h": "hours", "d": "days"}
    suffix = s[-1].lower()
    if suffix not in units:
        raise click.BadParameter(
            f"invalid --since value {since!r}; use a duration like 30m, 2h, 7d "
            "or an ISO-8601 timestamp"
        )
    try:
        qty = int(s[:-1])
    except ValueError:
        raise click.BadParameter(
            f"invalid --since value {since!r}; the part before {suffix!r} must be a "
            "whole number (e.g. 2h)"
        )
    if qty <= 0:
        raise click.BadParameter(f"invalid --since value {since!r}; must be positive")
    from datetime import datetime, timedelta, timezone
    return (datetime.now(timezone.utc) - timedelta(**{units[suffix]: qty})).isoformat()


def _dlq_params(run_id, data_source, integration_id, since, replayed=None):
    """Build the shared query params for the DLQ list + summary endpoints."""
    params = {}
    if run_id:
        params["run_id"] = run_id
    if data_source:
        params["data_source"] = data_source
    if integration_id:
        params["integration_id"] = integration_id
    if since:
        params["created_after"] = _parse_since(since)
    if replayed is not None:
        params["replayed"] = replayed
    return params


@etl.group(name="dlq", invoke_without_command=True)
@click.pass_context
def etl_dlq(ctx):
    """Dead-letter queue — the records a sync DROPPED, and why.

    This is how you get from "the run says partial" to the actual error text
    without touching the database.

    \b
    Examples:
      torana etl dlq list --since 2h                    # recent drops
      torana etl dlq list --run-id <RUN_ID>             # drops from one run
      torana etl dlq list --data-source repositories    # drops for one source
      torana etl dlq list --since 24h --group-by-error  # distinct errors + counts
      torana etl dlq summary --since 24h                # same as --group-by-error
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


_DLQ_LIST_COLS = [
    ("id", "ENTRY ID", 36),
    ("data_source", "DATA SOURCE", 24),
    # ⛔ R8 parity with the DLQ tab (§ 3.9h.1): WHICH scope unit's record failed.
    # ⚠️ "not recorded" for a record that failed BEFORE the project was derived, and
    # blank for a single-container provider — never a guessed attribution.
    ("scope_key", "PROJECT", 22),
    ("error", "ERROR", 60),
    ("created", "CREATED", 19),
]

_DLQ_GROUP_COLS = [
    ("count", "COUNT", 7),
    ("data_source", "DATA SOURCE", 30),
    ("step_id", "STEP", 10),
    ("error", "ERROR", 80),
    ("last_seen", "LAST SEEN", 19),
]


def _render_dlq_groups(data, fmt, raw, fields):
    """Render the grouped (distinct-error) view."""
    items = data.get("items", []) if isinstance(data, dict) else []
    if fmt != "text":
        output(data, fmt=fmt, raw=raw, fields=fields)
        return
    if not items:
        click.echo("No DLQ entries match. (Nothing was dropped in this window.)")
        return
    rows = [{
        "count": it.get("count"),
        "data_source": it.get("data_source"),
        "step_id": it.get("step_id"),
        # error_class is the useful discriminator when two errors share a prefix.
        "error": f"{it.get('error_class') or ''}: {it.get('error_message') or ''}".strip(": "),
        "last_seen": _fmt_ts(it.get("last_seen")),
    } for it in items]
    output({"items": rows, "total": len(rows), "page": 1, "page_size": len(rows)},
           fmt="text", raw=False, fields=fields, columns=_DLQ_GROUP_COLS)

    total_groups = data.get("total_groups", len(rows))
    total_entries = data.get("total_entries", 0)
    click.echo(f"\n{total_entries} entr{'y' if total_entries == 1 else 'ies'} "
               f"in {total_groups} distinct error(s).")
    # Never let a cap look like completeness.
    if total_groups > len(rows):
        click.echo(f"Showing the top {len(rows)} by count — "
                   f"{total_groups - len(rows)} more group(s) not shown (raise --limit).")
    sample = items[0].get("sample_entry_id")
    if sample:
        click.echo(f"Full record for the top error:  torana etl dlq-entry {sample}")


@etl_dlq.command(name="list")
@click.option("--run-id", "run_id", default=None, metavar="RUN_ID",
              help="Only entries dropped by this ETL run.")
@click.option("--data-source", "data_source", default=None, metavar="NAME",
              help="Only entries for this data source (e.g. repositories).")
@click.option("--integration-id", "integration_id", default=None, metavar="UUID",
              help="Only entries for this integration.")
@click.option("--since", default=None, metavar="DURATION",
              help="Only entries newer than this (e.g. 30m, 2h, 7d, or an ISO timestamp).")
@click.option("--group-by-error", "group_by_error", is_flag=True, default=False,
              help="Collapse identical errors into distinct groups with counts. "
                   "Use this first — a real DLQ is thousands of copies of a few errors.")
@click.option("--replayed/--not-replayed", "replayed", default=None,
              help="Filter by replay state. Default: both.")
@click.option("--limit", default=20, show_default=True, help="Max rows (server caps at 100).")
@click.option("--offset", default=0, show_default=True, help="Rows to skip.")
@click.pass_context
def etl_dlq_list(ctx, run_id, data_source, integration_id, since, group_by_error,
                 replayed, limit, offset):
    """List DLQ entries — the records a sync dropped, with the error that dropped them.

    \b
    Examples:
      torana etl dlq list --since 2h --group-by-error
      torana etl dlq list --run-id <RUN_ID>
      torana etl dlq list --data-source repositories --since 24h
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = _dlq_params(run_id, data_source, integration_id, since, replayed)
    params["limit"] = limit

    client = _client(ctx)

    if group_by_error:
        try:
            data = client.get("etl/admin/dlq/summary", params=params)
        except APIError as e:
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return
        _render_dlq_groups(data, fmt, raw, fields)
        return

    params["offset"] = offset
    try:
        data = client.get("etl/admin/dlq", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    items = data.get("items", []) if isinstance(data, dict) else []
    if not items:
        click.echo("No DLQ entries match. (Nothing was dropped in this window.)")
        return

    # Project to the four columns that answer "what broke". The raw payload carries
    # raw_record/intermediate_record blobs that, left in, ellipsize error_message —
    # the one field the command exists to show. Fetch a full record with `dlq-entry`.
    rows = [{
        "id": it.get("id"),
        "data_source": it.get("data_source"),
        # ⚠️ MUST be projected, not just added to _DLQ_COLS: this projection DROPS every
        # field it does not name, so declaring the column without carrying the value
        # rendered an always-blank PROJECT column — the API was returning it correctly
        # the whole time. Verified against real GCP DLQ rows.
        "scope_key": it.get("scope_key") or "",
        "error": f"{it.get('error_class') or ''}: {it.get('error_message') or ''}".strip(": "),
        "created": _fmt_ts(it.get("created_at")),
    } for it in items]
    total = data.get("total", len(rows))
    output({"items": rows, "total": total, "page": (offset // limit) + 1 if limit else 1,
            "page_size": limit},
           fmt="text", raw=False, fields=fields, columns=_DLQ_LIST_COLS)

    if total > len(rows):
        click.echo(f"\nShowing {len(rows)} of {total}. "
                   f"Use --group-by-error to see the distinct errors instead of every copy.")


@etl_dlq.command(name="summary")
@click.option("--run-id", "run_id", default=None, metavar="RUN_ID",
              help="Only entries dropped by this ETL run.")
@click.option("--data-source", "data_source", default=None, metavar="NAME",
              help="Only entries for this data source.")
@click.option("--integration-id", "integration_id", default=None, metavar="UUID",
              help="Only entries for this integration.")
@click.option("--since", default=None, metavar="DURATION",
              help="Only entries newer than this (e.g. 30m, 2h, 7d, or an ISO timestamp).")
@click.option("--replayed/--not-replayed", "replayed", default=None,
              help="Filter by replay state. Default: both.")
@click.option("--limit", default=50, show_default=True, help="Max groups (server caps at 100).")
@click.pass_context
def etl_dlq_summary(ctx, run_id, data_source, integration_id, since, replayed, limit):
    """Distinct DLQ errors with counts — the fastest read of why a sync is failing.

    Grouping happens server-side across the WHOLE matching set, not just one page,
    so the counts are true even when the DLQ holds six figures of entries.

    \b
    Example:
      torana etl dlq summary --since 24h
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = _dlq_params(run_id, data_source, integration_id, since, replayed)
    params["limit"] = limit

    client = _client(ctx)
    try:
        data = client.get("etl/admin/dlq/summary", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    _render_dlq_groups(data, fmt, raw, fields)


# ---------------------------------------------------------------------------
# ETL DLQ entry detail (tenant)
# ---------------------------------------------------------------------------

@etl.command(name="dlq-entry")
@click.argument("entry_id", metavar="ENTRY_ID")
@click.pass_context
def etl_dlq_entry(ctx, entry_id):
    """Get a single DLQ entry by ID.

    \b
    Example:
      torana etl dlq-entry <ENTRY_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"etl/dlq/entries/{entry_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ---------------------------------------------------------------------------
# SA ETL admin (under /api/v1/admin/etl/*)
# ---------------------------------------------------------------------------

@click.group(name="etl-sa")
def etl_sa():
    """Super-admin ETL operations (cross-tenant).

    \b
    Examples:
      torana etl-sa dlq
      torana etl-sa drift
      torana etl-sa runs
      torana etl-sa mappings list
      torana etl-sa threat-intel status
      torana etl-sa threat-intel refresh --source kev --source epss
    """


@etl_sa.group(name="threat-intel")
def etl_sa_threat_intel():
    """SA: global CVE-intel feed (CISA KEV / FIRST EPSS / NVD advisory dates) control.

    The feed populates the global public.vm_cve_metadata cache that enriches every
    tenant's vulnerabilities. Use `list` verbs; nothing here is tenant-scoped.
    """


@etl_sa_threat_intel.command(name="status")
@click.pass_context
def etl_sa_threat_intel_status(ctx):
    """SA: global CVE-intel feed status (row counts, per-source freshness, next run).

    \b
    NOTE: `cvss_count` is expected to be 0 — no live path writes cvss3_base_score
    (populating it would change precedence for existing scanner-supplied values).
    `advisory_date_count` is what the NVD feed actually delivers today.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("admin/etl/threat-intel/status")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@etl_sa_threat_intel.command(name="refresh")
@click.option("--source", "sources", multiple=True,
              type=click.Choice(["kev", "epss", "nvd"]),
              help="Feed(s) to refresh; repeatable. Omit for all.")
@click.pass_context
def etl_sa_threat_intel_refresh(ctx, sources):
    """SA: trigger a global CVE-intel feed refresh now (runs in the background)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = {"sources": list(sources)} if sources else {}
    client = _client(ctx)
    try:
        data = client.post("admin/etl/threat-intel/refresh", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@etl_sa.command(name="dlq")
@click.pass_context
def etl_sa_dlq(ctx):
    """SA: cross-tenant DLQ console."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("admin/etl/dlq")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@etl_sa.command(name="drift")
@click.pass_context
def etl_sa_drift(ctx):
    """SA: cross-tenant drift log."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("admin/etl/drift")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@etl_sa.command(name="sync-overview")
@click.option("--tenant-id", "tenant_id", default=None,
              help="Drill into one tenant. Omit for ALL tenants (SA default).")
@click.option("--integration-id", "integration_id", default=None,
              help="Filter by integration ID.")
@click.pass_context
def etl_sa_sync_overview(ctx, tenant_id, integration_id):
    """SA: ETL sync overview. Omit --tenant-id for ALL tenants; pass it to drill into one."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if tenant_id:
        params["tenant_id"] = tenant_id
    if integration_id:
        params["integration_id"] = integration_id

    client = _client(ctx)
    try:
        data = client.get("admin/etl/integrations/sync-overview", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@etl_sa.command(name="trigger-batch")
@click.option("--integration-id", "integration_id", required=True,
              help="Integration to sync.")
@click.option("--tenant-id", "tenant_id", required=True,
              help="Target tenant UUID.")
@click.option("--data-source", "data_sources", multiple=True,
              help="Sync only this data source (repeatable). Omit = ALL syncable sources.")
@click.option("--mode", default="normal", type=click.Choice(["normal", "backfill"]),
              show_default=True)
@click.pass_context
def etl_sa_trigger_batch(ctx, integration_id, tenant_id, data_sources, mode):
    """SA: trigger a group sync across one-or-more data sources (default ALL) as one batch.

    \b
    Every spawned run shares one sync_batch_id, so run history can roll up
    "one Sync -> each data source's status".

    \b
    Examples:
      torana etl-sa trigger-batch --integration-id <IID> --tenant-id <TID>
      torana etl-sa trigger-batch --integration-id <IID> --tenant-id <TID> \\
        --data-source iam_members --data-source compute_instances
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {"integration_id": integration_id, "tenant_id": tenant_id, "mode": mode}
    if data_sources:
        body["data_sources"] = list(data_sources)

    client = _client(ctx)
    try:
        data = client.post("admin/etl/ops/trigger-batch", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        if isinstance(data, dict):
            click.echo(f"Batch triggered: {data.get('sync_batch_id', 'unknown')}")
            click.echo(f"  triggered {data.get('triggered_count', 0)} data source(s)"
                       f"{', skipped ' + str(data.get('skipped')) if data.get('skipped') else ''}")
        else:
            click.echo(str(data))


@etl_sa.command(name="run-history")
@click.argument("integration_id", metavar="INTEGRATION_ID")
@click.pass_context
def etl_sa_run_history(ctx, integration_id):
    """SA: ETL run history for a specific integration."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"admin/etl/integrations/{integration_id}/run-history")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@etl_sa.command(name="runs")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.pass_context
def etl_sa_runs(ctx, page, page_size, fetch_all):
    """SA: all-tenant run history."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get("admin/etl/runs", params=p)
                items = data.get("items", data if isinstance(data, list) else [])
                all_items.extend(items)
                total = data.get("total", len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get("admin/etl/runs", params=params)
            result = data if isinstance(data, dict) and "items" in data else {
                "items": data if isinstance(data, list) else [],
                "total": len(data) if isinstance(data, list) else 0,
            }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields,
           columns=[("run_id", "RUN ID", 36), ("status", "STATUS", 11), ("stop_reason", "STOP REASON", 24),
                    ("integration_id", "INTEGRATION", 36), ("started_at", "STARTED", 20)])


@etl_sa.command(name="runs-active")
@click.pass_context
def etl_sa_runs_active(ctx):
    """SA: all currently-executing pipeline runs."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("admin/etl/runs/active")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@etl_sa.command(name="runs-stats")
@click.option("--integration-id", "integration_id", default=None,
              help="Filter by integration ID.")
@click.pass_context
def etl_sa_runs_stats(ctx, integration_id):
    """SA: aggregate run stats filtered by integration."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if integration_id:
        params["integration_id"] = integration_id

    client = _client(ctx)
    try:
        data = client.get("admin/etl/runs/stats", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@etl_sa.command(name="run")
@click.argument("run_id", metavar="RUN_ID")
@click.pass_context
def etl_sa_run(ctx, run_id):
    """SA: run detail with operator metrics, drift, and DLQ entries."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"admin/etl/runs/{run_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@etl_sa.command(name="stats")
@click.pass_context
def etl_sa_stats(ctx):
    """SA: aggregate run stats across all tenants."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("admin/etl/stats")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@etl_sa.command(name="scheduler-health")
@click.pass_context
def etl_sa_scheduler_health(ctx):
    """SA: scheduler leader/follower health."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("admin/etl/scheduler/health")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@etl_sa.command(name="scheduler-jobs")
@click.pass_context
def etl_sa_scheduler_jobs(ctx):
    """SA: all registered APScheduler jobs."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("admin/etl/scheduler/jobs")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@etl_sa.command(name="startup")
@click.pass_context
def etl_sa_startup(ctx):
    """SA: last N service startup events."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("admin/etl/startup")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@etl_sa.command(name="trigger")
@click.option("--file", "input_file", required=True, metavar="FILE",
              help="JSON/YAML body with integration_id and optional params.")
@click.pass_context
def etl_sa_trigger(ctx, input_file):
    """SA: manually trigger a pipeline run.

    \b
    Example:
      torana etl-sa trigger --file trigger.yaml
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = _load_input_file(input_file)

    client = _client(ctx)
    try:
        data = client.post("admin/etl/ops/trigger", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        run_id = data.get("run_id", "unknown") if isinstance(data, dict) else "unknown"
        click.echo(f"SA triggered ETL run: {run_id}")


@etl_sa.command(name="pause")
@click.argument("integration_id", metavar="INTEGRATION_ID")
@click.pass_context
def etl_sa_pause(ctx, integration_id):
    """SA: pause ETL scheduling for an integration."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"admin/etl/ops/{integration_id}/pause", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Paused ETL for integration: {integration_id}")


@etl_sa.command(name="resume")
@click.argument("integration_id", metavar="INTEGRATION_ID")
@click.pass_context
def etl_sa_resume(ctx, integration_id):
    """SA: resume ETL scheduling for an integration."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"admin/etl/ops/{integration_id}/resume", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Resumed ETL for integration: {integration_id}")


@etl_sa.command(name="cancel")
@click.argument("run_id", metavar="RUN_ID")
@click.pass_context
def etl_sa_cancel(ctx, run_id):
    """SA: request cancellation of an active run."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"admin/etl/ops/{run_id}/cancel", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Cancellation requested for run: {run_id}")


@etl_sa.command(name="replay")
@click.argument("run_id", metavar="RUN_ID")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def etl_sa_replay(ctx, run_id, yes):
    """SA: replay DLQ entries for a finished run."""
    _confirm(f"Replay DLQ for run {run_id}?", yes=yes)
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"admin/etl/ops/{run_id}/replay", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Replayed DLQ for run: {run_id}")


@etl_sa.command(name="replay-check")
@click.argument("run_id", metavar="RUN_ID")
@click.pass_context
def etl_sa_replay_check(ctx, run_id):
    """SA: check if run's mapping has non-idempotent operators."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"admin/etl/ops/{run_id}/replay/check")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# SA ETL mapping drafts + editor operations

@etl_sa.group(name="mappings")
def etl_sa_mappings():
    """SA: manage ETL mapping configs (cross-tenant)."""


@etl_sa_mappings.command(name="list")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.pass_context
def etl_sa_mappings_list(ctx, page, page_size, fetch_all):
    """SA: list all mapping configs (cross-tenant)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get("admin/etl/mappings", params=p)
                items = data.get("items", data if isinstance(data, list) else [])
                all_items.extend(items)
                total = data.get("total", len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get("admin/etl/mappings", params=params)
            result = data if isinstance(data, dict) and "items" in data else {
                "items": data if isinstance(data, list) else [],
                "total": len(data) if isinstance(data, list) else 0,
            }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields,
           columns=[("id", "ID", 36), ("name", "NAME", 30), ("status", "STATUS", 12)])


@etl_sa_mappings.command(name="get")
@click.argument("config_id", metavar="CONFIG_ID")
@click.pass_context
def etl_sa_mappings_get(ctx, config_id):
    """SA: fetch a single mapping config by ID."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"admin/etl/mappings/{config_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@etl_sa_mappings.command(name="history")
@click.argument("config_id", metavar="CONFIG_ID")
@click.pass_context
def etl_sa_mappings_history(ctx, config_id):
    """SA: full version history for a mapping config."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"admin/etl/mappings/{config_id}/history")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields)


@etl_sa_mappings.command(name="resolved")
@click.argument("config_id", metavar="CONFIG_ID")
@click.pass_context
def etl_sa_mappings_resolved(ctx, config_id):
    """SA: resolved mapping config with non-idempotent operator flag."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"admin/etl/mappings/{config_id}/resolved")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@etl_sa_mappings.command(name="activate")
@click.argument("config_id", metavar="CONFIG_ID")
@click.pass_context
def etl_sa_mappings_activate(ctx, config_id):
    """SA: make a specific mapping version active."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.patch(f"admin/etl/mappings/{config_id}/activate", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Activated mapping version: {config_id}")


@etl_sa_mappings.command(name="draft-upsert")
@click.option("--file", "input_file", required=True, metavar="FILE",
              help="JSON/YAML file with draft body.")
@click.pass_context
def etl_sa_mappings_draft_upsert(ctx, input_file):
    """SA: upsert a mapping draft.

    \b
    Example:
      torana etl-sa mappings draft-upsert --file draft.yaml
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = _load_input_file(input_file)

    client = _client(ctx)
    try:
        data = client.put("admin/etl/mappings/drafts", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Upserted mapping draft: {data.get('id', 'unknown') if isinstance(data, dict) else 'ok'}")


@etl_sa_mappings.command(name="draft-delete")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def etl_sa_mappings_draft_delete(ctx, yes):
    """SA: delete a mapping draft."""
    _confirm("Delete mapping draft?", yes=yes)
    client = _client(ctx)
    try:
        client.delete("admin/etl/mappings/drafts")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo("Deleted mapping draft.")


# ── integration data: what an integration OWNS (and removing it) ────────────
#
# The DUAL of `torana etl admin sync-overview`. That reports FLOW — records
# processed across runs, which re-syncs inflate without bound. These report
# STOCK — rows currently attributable, derived from each row's
# `contributing_sources` provenance map.
#
# MEASURED on T1: the GCP integration shows 235,046 records processed but owns
# 84,357 rows. Those answer different questions and only the first was
# obtainable before this command existed.

_DATA_COLS = [
    ("table", "TABLE", 34),
    ("rows", "ROWS", 10),
    ("sole_contributor", "SOLE", 10),
    ("shared", "SHARED", 10),
]

_DISCOVER_COLS = [
    ("provenance_key", "PROVENANCE KEY", 46),
    ("integration_name", "NAME", 34),
    ("rows", "ROWS", 10),
    ("state", "STATE", 12),
]


@integrations.command(name="data")
@click.argument("integration_id", metavar="INTEGRATION_ID", required=False)
@click.option("--orphans", is_flag=True, default=False,
              help="List every integration present in the data, flagging orphaned ones.")
@click.option("--orphans-only", is_flag=True, default=False,
              help="With --orphans, show ONLY integrations whose record is gone.")
@click.option("--all-sources", is_flag=True, default=False,
              help="Also list non-integration writers (platform-derived rows, "
                   "uploads with no integration). Hidden by default — they cannot "
                   "be opened or purged.")
@click.option("--table", "table", default=None, metavar="RELATION",
              help="Expand one table: its derived state + the transformers it feeds.")
@click.option("--depth", default=0, show_default=True, type=int,
              help="Expansion depth. >0 requires --table.")
@click.option("--source", default=None,
              help="Disambiguate when one id appears under two providers.")
@click.option("--tenant-id", "tenant_id", default=None,
              help="Read another tenant's data (super_admin only).")
@click.option("--absolute-time", is_flag=True, default=False,
              help="Show exact timestamps instead of relative ones. Relative is the default.")
@click.pass_context
def integrations_data(ctx, integration_id, orphans, orphans_only, all_sources,
                      table, depth, source, tenant_id, absolute_time):
    """Rows an integration currently OWNS, per table.

    \b
    Without an id, use --orphans to discover what is present in the data —
    including integrations that were deleted but whose rows remain.

    \b
    Examples:
      torana integrations data --orphans
      torana integrations data --orphans --orphans-only
      torana integrations data 7dfb9d8c-959d-4d2e-9336-e3b96529bf81
      torana integrations data <id> --table assets --depth 1
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    if not integration_id and not (orphans or orphans_only):
        raise click.UsageError(
            "Give an INTEGRATION_ID, or use --orphans to discover what is in the data."
        )

    params = {}
    if tenant_id:
        params["tenant_id"] = tenant_id

    client = _client(ctx)
    try:
        if not integration_id:
            if orphans_only:
                params["orphans_only"] = "true"
            if all_sources:
                params["include_non_integration"] = "true"
            data = client.get("etl/admin/integration-data", params=params)
            columns = _DISCOVER_COLS
        else:
            if source:
                params["source"] = source
            if depth > 0 or table:
                params["depth"] = max(depth, 1)
                params["table"] = table
            data = client.get(f"etl/admin/integration-data/{integration_id}", params=params)
            columns = _DATA_COLS
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if raw or fmt in ("json", "yaml"):
        output(data, fmt=fmt, fields=fields, raw=raw)
        return

    _render_integration_data(data, integration_id, table, fmt, fields, columns,
                             absolute_time=absolute_time)


def _render_integration_data(data, integration_id, table, fmt, fields, columns,
                             absolute_time=False):
    """Human-readable rendering for the three shapes this command returns."""
    if not isinstance(data, dict):
        output(data, fmt=fmt, fields=fields, columns=columns)
        return

    # Shape 1 — discovery (no id).
    if "items" in data:
        totals = data.get("totals") or {}
        output({"items": data["items"], "total": len(data["items"])},
               fmt=fmt, fields=fields, columns=_DISCOVER_COLS)
        click.echo("")
        parts = [f"live: {totals.get('live', 0)}",
                 f"orphaned: {totals.get('orphaned', 0)}"]
        if totals.get("push_ingest"):
            parts.append(f"uploads: {totals['push_ingest']}")
        if totals.get("derived"):
            parts.append(f"platform-derived: {totals['derived']}")
        click.echo("  " + "   ".join(parts))
        # A row can carry several provenance keys, so the ROWS column does not
        # sum to the real total. Print the honest number rather than leaving the
        # reader to add up a column that overstates it.
        if data.get("distinct_rows") is not None:
            click.echo(f"  {data['distinct_rows']:,} distinct rows carry provenance "
                       f"(the ROWS column counts per source, so it does not sum to this).")
        hidden = data.get("hidden_non_integration") or 0
        if hidden:
            click.echo(f"  {hidden} non-integration source(s) hidden "
                       f"(platform-derived rows / uploads) — show with --all-sources.")
        if totals.get("orphaned"):
            click.echo("  Orphaned = the integration record is gone but its rows remain.")
            click.echo("  Remove them with: torana integrations purge-data <ID>")
        return

    # Shape 2 — one table expanded.
    if "feeds_transformers" in data:
        click.echo(f"\n{data.get('table')} — what it feeds\n")
        derived = data.get("derived_state") or []
        if derived:
            click.echo("  derived state")
            for d in derived:
                click.echo(f"    {d['table']:<38} {d['rows']:>8}")
        feeds = data.get("feeds_transformers") or []
        if feeds:
            click.echo("  feeds transformers")
            for f in feeds:
                if f.get("rows") is None:
                    # An aggregate projects no entity id, so no honest count
                    # exists. Saying 0 would be a lie.
                    click.echo(f"    {f['table']:<38} {'— not attributable':>18}")
                else:
                    click.echo(f"    {f['table']:<38} {f['rows']:>8} of {f.get('of')}")
        if not derived and not feeds:
            click.echo("  (nothing downstream)")
        click.echo("")
        return

    # Shape 3 — Level 0 summary.
    sink = data.get("sink_tables") or []
    totals = data.get("totals") or {}
    name = data.get("integration_name") or integration_id
    state = "" if data.get("integration_exists") else "   [ORPHANED — integration record is gone]"
    click.echo(f"\n{name}{state}")
    click.echo(f"{totals.get('sink_rows', 0)} rows across "
               f"{totals.get('tables_with_rows', 0)} table(s)\n")
    if sink:
        output({"items": sink, "total": len(sink)}, fmt=fmt, fields=fields, columns=_DATA_COLS)
    else:
        click.echo("  (no rows carry this integration's provenance key)")
    empty = data.get("empty_tables") or []
    if empty:
        click.echo(f"\n  {len(empty)} table(s) with no rows from this integration")
    if sink:
        click.echo(f"\n  Expand one: torana integrations data {integration_id} "
                   f"--table {sink[0]['table']}")

    # Sync health, per data source. Sits BESIDE the table list rather than inside
    # it: tables and data sources are many-to-many, so "the cursor for `assets`"
    # does not exist — several sources write it, each with its own cursor.
    sources = data.get("data_sources") or []
    if sources:
        # RELATIVE by default, matching the FE. These timestamps exist to answer
        # "is this stale?", and a wall-clock value makes the reader do that
        # subtraction themselves. --absolute-time gives exact values for
        # correlating against logs or a run id.
        from torana_cli.time_util import format_relative  # noqa: PLC0415

        def _when(value):
            """Relative when the value is a real timestamp, verbatim otherwise.

            A CURSOR is opaque by contract — an ISO timestamp for some data
            sources, a provider page token for others (VERIFIED in the mapping
            YAMLs: `updated_at` vs `cursor_token`). format_relative returns '—'
            for anything it cannot parse, which IS the "not a timestamp" test,
            so an opaque token passes through rather than being mangled.
            """
            if value is None:
                return None
            if absolute_time:
                return str(value)[:19].replace("T", " ")
            rel = format_relative(str(value))
            return str(value)[:19].replace("T", " ") if rel == "—" else rel

        mode = "absolute" if absolute_time else "relative"
        click.echo(f"\n  Data sources ({len(sources)}) — last sync + incremental cursor "
                   f"[{mode} time]\n")
        click.echo(f"    {'DATA SOURCE':<32}{'STATUS':<10}{'LAST SYNC':<22}{'CURSOR':<26}{'ROWS':>7}")
        for e in sources:
            last = _when(e.get("last_run_at")) or "—"
            # NOT "full pull": a null cursor does not imply that (VERIFIED — a
            # source can declare `cursor: type: none` and still hold a value, and
            # vice versa). Say only what is true: nothing is recorded.
            cur = _when(e.get("cursor_value")) or "not set"
            click.echo(f"    {e['data_source']:<32}{e['status']:<10}{last[:21]:<22}"
                       f"{cur[:24]:<26}{e.get('records_out', 0):>7}")
        stale = [e for e in sources
                 if e.get("cursor_value") and e.get("status") == "success"
                 and (e.get("records_out") or 0) == 0]
        if not absolute_time:
            click.echo("\n    Times are relative — use --absolute-time for exact values.")
        if stale:
            # The silent-staleness signature: the run says success, the cursor is
            # set, and nothing came back. Worth naming rather than leaving the
            # reader to spot a zero in a column.
            click.echo(f"\n    {len(stale)} source(s) succeeded but returned 0 rows — "
                       f"check whether the cursor has advanced past the data.")
    click.echo("")


@integrations.command(name="purge-data")
@click.argument("integration_id", metavar="INTEGRATION_ID")
@click.option("--dry-run/--no-dry-run", default=True, show_default=True,
              help="Preview only. --no-dry-run actually removes rows.")
@click.option("--yes", "-y", is_flag=True, default=False,
              help="Skip the confirmation prompt (the preview is still printed).")
@click.option("--source", default=None,
              help="Disambiguate when one id appears under two providers.")
@click.option("--tenant-id", "tenant_id", default=None,
              help="Purge within another tenant (super_admin only).")
@click.pass_context
def integrations_purge_data(ctx, integration_id, dry_run, yes, source, tenant_id):
    """Remove the datalake rows an integration contributed.

    \b
    Sole-contributor rows are DELETED. Rows another integration also wrote are
    DETACHED (this integration's key is stripped, the row stays) — a shared
    asset must not vanish because one contributor left.

    \b
    Transformer tables are never touched; rematerialize them afterwards.
    The id works even after the integration is deleted — that is the main case.

    \b
    Examples:
      torana integrations purge-data <ID>                    # preview
      torana integrations purge-data <ID> --no-dry-run       # prompts
      torana integrations purge-data <ID> --no-dry-run --yes # scripted
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    base_params = {"source": source} if source else {}
    if tenant_id:
        base_params["tenant_id"] = tenant_id

    client = _client(ctx)

    # The preview ALWAYS runs, even with --yes. --yes skips the PROMPT, not the
    # preview: a scripted purge must still leave a record of what it removed.
    try:
        preview = client.delete(
            f"internal/cleanup/integration/{integration_id}",
            params={**base_params, "dry_run": "true"},
        )
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    _render_purge(preview, integration_id, dry_run=True)

    if dry_run:
        click.echo("  Preview only — nothing was removed. "
                   "Re-run with --no-dry-run to apply.\n")
        return

    would_delete = (preview.get("totals") or {}).get("would_delete", 0)
    would_detach = (preview.get("totals") or {}).get("would_detach", 0)
    if not would_delete and not would_detach:
        click.echo("  Nothing to remove.\n")
        return

    _confirm(f"PERMANENTLY delete {would_delete} row(s) and detach {would_detach} "
            f"for integration {integration_id}? This cannot be undone.", yes=yes)
    try:
        result = client.delete(
            f"internal/cleanup/integration/{integration_id}",
            params={**base_params, "dry_run": "false"},
        )
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if raw or fmt in ("json", "yaml"):
        output(result, fmt=fmt, fields=fields, raw=raw)
        return
    _render_purge(result, integration_id, dry_run=False)


def _render_purge(data, integration_id, dry_run):
    if not isinstance(data, dict):
        click.echo(str(data))
        return
    totals = data.get("totals") or {}
    tables = data.get("tables") or []
    header = "WOULD REMOVE" if dry_run else "REMOVED"
    click.echo(f"\n{header} — integration {integration_id}\n")
    if not tables:
        click.echo("  " + (data.get("note") or "nothing matched this integration's key"))
        click.echo("")
        return
    click.echo(f"  {'TABLE':<34}{'DELETE':>10}{'DETACH':>10}")
    for t in tables:
        d = t.get("to_delete") if dry_run else t.get("deleted")
        x = t.get("to_detach") if dry_run else t.get("detached")
        click.echo(f"  {t['table']:<34}{d:>10}{x:>10}")
    if dry_run:
        click.echo(f"\n  total: {totals.get('would_delete', 0)} to delete, "
                   f"{totals.get('would_detach', 0)} to detach")
    else:
        click.echo(f"\n  total: {totals.get('deleted', 0)} deleted, "
                   f"{totals.get('detached', 0)} detached")
        click.echo("  Transformer tables were NOT touched — rematerialize them:")
        click.echo("    torana datalake transformer <transformer-id> execute-and-wait")
    click.echo("")


# ---------------------------------------------------------------------------
# Cursors — tenant-wide (collection scope)
# ---------------------------------------------------------------------------
#
# Per-integration cursor commands live on the SINGULAR group
# (`torana integration <ID> cursor …`). This collection form exists for the one
# case that has no single integration: the whole tenant's lake was cleared, so
# every source has to re-pull. It shares reset_cursors_core with the singular
# form, so the two cannot drift.

@integrations.group(name="cursor", invoke_without_command=True)
@click.pass_context
def integrations_cursor(ctx):
    """ETL cursors across the tenant.

    \b
    Examples:
      torana integrations cursor list
      torana integrations cursor reset --all-integrations
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@integrations_cursor.command(name="list")
@click.pass_context
def integrations_cursor_list(ctx):
    """Show every integration's cursors for this tenant."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.get("etl/cursors")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields, columns=[
        ("provider", "PROVIDER", 12),
        ("data_source", "DATA SOURCE", 24),
        ("status", "CURSOR", 44),
        ("updated_at", "COMMITTED", 30),
    ])


@integrations_cursor.command(name="reset")
@click.option("--all-integrations", "all_integrations", is_flag=True,
              help="Reset cursors for EVERY integration in this tenant.")
@click.option("--yes", is_flag=True, help="Skip the confirmation prompt.")
@click.pass_context
def integrations_cursor_reset(ctx, all_integrations, yes):
    """Clear cursors tenant-wide so every source re-pulls from the beginning.

    Requires --all-integrations: a tenant-wide reset triggers a full re-pull of
    every source on the next run, so it is opted into explicitly rather than
    being what happens when you forget an argument. To reset ONE integration use
    `torana integration <ID> cursor reset`.
    """
    if not all_integrations:
        click.echo("Refusing to guess the scope. Pass --all-integrations to reset every "
                   "integration in this tenant, or use `torana integration <ID> cursor "
                   "reset` for one.", err=True)
        sys.exit(2)
    _confirm("Reset cursors for EVERY integration in this tenant? "
                      "The next sync re-pulls everything from the beginning.", yes=yes)
    from torana_cli.integration import reset_cursors_core
    reset_cursors_core(ctx, all_integrations=True)


# ---------------------------------------------------------------------------
# Category labels + category models — SUPER-ADMIN ONLY (packet 2)
# ---------------------------------------------------------------------------
#
# These read PLATFORM CURATION, not tenant data: what a class of tool IS
# (packet 1's labels) and what it OUGHT to produce (packet 2's models). The
# server enforces `require_role("super_admin")`; the helper below turns the
# resulting 403 into a sentence instead of a stack trace or an empty table.

def _handle_sa_only(e: APIError, what: str) -> None:
    """Render a 403 from an SA-only endpoint as a clear message, else defer.

    Without this a tenant profile gets the generic APIError rendering, which
    reads like a bug rather than "you used the wrong profile" — the exact
    failure mode the packet calls out.
    """
    if getattr(e, "status_code", None) == 403:
        click.echo(
            f"\nERROR: {what} is super-admin only.\n"
            "  The server checks the token's `roles` claim for `super_admin`, not the\n"
            "  profile name. Re-run under a profile logged in as a super-admin user\n"
            "  (TORANA_PROFILE=SA locally; the profile name differs per deployment).",
            err=True,
        )
        sys.exit(1)
    handle_api_error(e)


@integrations.command(name="categories")
@click.pass_context
def integrations_categories(ctx):
    """List integration categories with family/source counts (super-admin only).

    \b
    Step 1 of two-step discovery — walk this rather than hard-coding the
    vocabulary, so a category gaining a model changes no caller.

    \b
    Examples:
      TORANA_PROFILE=SA torana integrations categories
      TORANA_PROFILE=SA torana integrations categories --format json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    client = _client(ctx)
    try:
        data = client.get("/api/v1/integrations/categories")
    except APIError as e:
        _handle_sa_only(e, "Listing integration categories")
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # --format json must stay the FULL server payload — packet 4's skill consumes
    # it. Only the human-facing table is reshaped.
    if fmt in ("json", "yaml") or raw:
        output(data, fmt=fmt, fields=fields, raw=raw)
        return

    rows = data.get("categories", []) if isinstance(data, dict) else data
    for r in rows:
        # `has_model` is a bool; render it as a word so the table column is
        # readable and greppable rather than 'True'/'False'.
        r["model"] = "yes" if r.get("has_model") else "—"
    columns = [
        ("name", "CATEGORY", 22),
        ("family_count", "FAMILIES", 9),
        ("source_count", "SOURCES", 8),
        ("model", "MODEL", 6),
        ("description", "DESCRIPTION", 60),
    ]
    output({"items": rows, "total": len(rows)}, fmt=fmt, fields=fields,
           raw=raw, columns=columns)


@integrations.command(name="category")
@click.argument("CATEGORY", metavar="CATEGORY")
@click.option("--model-only", is_flag=True, default=False,
              help="Print only the model (404s where the category has none yet).")
@click.pass_context
def integrations_category(ctx, category, model_only):
    """Show one category's families, sources and model (super-admin only).

    \b
    A category with no model yet returns `model: null` — that is a correct
    state, not an error. Two of twelve categories are modelled today.

    \b
    Examples:
      TORANA_PROFILE=SA torana integrations category security_scanner
      TORANA_PROFILE=SA torana integrations category security_scanner --model-only
      TORANA_PROFILE=SA torana integrations category code_scanner --format json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = f"/api/v1/integrations/categories/{category}"
    if model_only:
        path += "/model"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        _handle_sa_only(e, f"Reading category {category!r}")
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml") or raw:
        output(data, fmt=fmt, fields=fields, raw=raw)
        return

    _render_category_text(data, model_only=model_only)


def _render_category_text(data, *, model_only: bool) -> None:
    """Human rendering for `category` — a model is nested, so a flat table lies.

    The default text renderer flattens a dict; on a model that means the field
    list (the actual content) collapses to a repr. Rendered explicitly instead.
    """
    if model_only:
        click.echo(f"\nCATEGORY   {data.get('category')}")
        _render_model(data.get("model") or {})
        click.echo(f"\nREQUIRED   {', '.join(data.get('required_columns') or []) or '—'}")
        click.echo(f"OPTIONAL   {', '.join(data.get('optional_columns') or []) or '—'}")
        gaps = data.get("gaps_by_family") or {}
        if gaps:
            click.echo("\nPER-FAMILY GAPS (required columns not produced)")
            for fam, missing in sorted(gaps.items()):
                click.echo(f"  {fam:14s} {', '.join(missing) if missing else '— none'}")
        return

    click.echo(f"\nCATEGORY     {data.get('name')}")
    if data.get("description"):
        click.echo(f"DESCRIPTION  {data['description']}")
    click.echo(f"FAMILIES ({data.get('family_count', 0)})  "
               f"{', '.join(data.get('families') or []) or '—'}")
    click.echo(f"SOURCES      {data.get('source_count', 0)}")
    model = data.get("model")
    if model is None:
        # Not an error — say so plainly, or a reader assumes something failed.
        click.echo("\nMODEL        none defined yet for this category "
                   "(expected — see packet 6)")
        return
    _render_model(model)


def _render_model(model: dict) -> None:
    if not model:
        return
    click.echo(f"\nPRIMARY TABLE  {model.get('primary_table')}")
    if model.get("provisional"):
        click.echo("⚠ PROVISIONAL  " + (model.get("provisional_reason") or ""))
    fields = model.get("fields") or []
    req = [f for f in fields if f.get("requirement") == "required"]
    opt = [f for f in fields if f.get("requirement") == "optional"]
    if req:
        click.echo(f"\nREQUIRED FIELDS ({len(req)})")
        for f in req:
            wb = f.get("written_by") or []
            click.echo(f"  {f['column']:32s} {len(wb)} families: {', '.join(wb)}")
            if f.get("rationale"):
                click.echo(f"      {f['rationale']}")
    if opt:
        click.echo(f"\nOPTIONAL FIELDS ({len(opt)})")
        for f in opt:
            wb = f.get("written_by") or []
            click.echo(f"  {f['column']:32s} {len(wb)} families: {', '.join(wb)}")


@integrations.command(name="category-map")
@click.pass_context
def integrations_category_map(ctx):
    """Full family→categories and source→categories map (super-admin only).

    \b
    Examples:
      TORANA_PROFILE=SA torana integrations category-map --format json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    client = _client(ctx)
    try:
        data = client.get("/api/v1/integrations/category-map")
    except APIError as e:
        _handle_sa_only(e, "Reading the category map")
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml") or raw:
        output(data, fmt=fmt, fields=fields, raw=raw)
        return

    rows = [{"family": f, "categories": ", ".join(c)}
            for f, c in sorted((data.get("families") or {}).items())]
    click.echo(f"\n{data.get('family_count', 0)} families · "
               f"{data.get('source_count', 0)} data sources")
    output({"items": rows, "total": len(rows)}, fmt=fmt, fields=fields, raw=raw,
           columns=[("family", "FAMILY", 20), ("categories", "CATEGORIES", 70)])


@integrations.command(name="family-categories")
@click.argument("FAMILY", metavar="FAMILY")
@click.pass_context
def integrations_family_categories(ctx, family):
    """Categories for one integration family (super-admin only).

    \b
    Answers "which of my integrations are scanners?" at the family level.
    Family categories are DERIVED as the union of the family's data sources'.

    \b
    Examples:
      TORANA_PROFILE=SA torana integrations family-categories gcp
      TORANA_PROFILE=SA torana integrations family-categories snyk --format json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    client = _client(ctx)
    try:
        data = client.get(f"/api/v1/integrations/{family}/categories")
    except APIError as e:
        _handle_sa_only(e, f"Reading categories for family {family!r}")
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt in ("json", "yaml") or raw:
        output(data, fmt=fmt, fields=fields, raw=raw)
        return

    click.echo(f"\nFAMILY      {data.get('family')}")
    click.echo(f"CATEGORIES  {', '.join(data.get('categories') or []) or '—'}")
    rows = [{"data_source": ds, "categories": ", ".join(c)}
            for ds, c in sorted((data.get("sources") or {}).items())]
    output({"items": rows, "total": len(rows)}, fmt=fmt, fields=fields, raw=raw,
           columns=[("data_source", "DATA SOURCE", 38), ("categories", "CATEGORIES", 60)])


# ──────────────────────────────────────────────────────────────────────────
# BACK-COMPAT — hidden aliases for the old `<noun>-by-<param>` names.
# ⏳ ONE RELEASE ONLY (decision D4). Delete this block next release.
# ──────────────────────────────────────────────────────────────────────────

_LEGACY_BY_PARAM_INTEGRATIONS = {
    "providers-by-provider-name": ("provider", "get"),
    "providers-by-type": ("provider", "list"),
}


def _register_legacy_integrations_by_param() -> None:
    """Old flat names, hidden so they cannot be discovered anew."""
    import copy
    for _old, (_sub, _verb) in _LEGACY_BY_PARAM_INTEGRATIONS.items():
        _grp = integrations.commands.get(_sub)
        if not isinstance(_grp, click.Group):
            continue
        _cmd = _grp.commands.get(_verb)
        if _cmd is None:
            continue
        # ⛔ Never let an alias overwrite a real group of the same name.
        if isinstance(integrations.commands.get(_old), click.Group):
            continue
        _alias = copy.copy(_cmd)
        _alias.name = _old
        _alias.hidden = True
        integrations.add_command(_alias)


_register_legacy_integrations_by_param()


# ===========================================================================
# threat-intel — the GLOBAL CVE-intel cache (SUPER-ADMIN ONLY)
# ===========================================================================
#
# ⛔ CLOSES THE R8 THREE-SURFACE PARITY GAP. The API and the FE have carried threat-intel
# status since the advisory-dates work; the CLI never did, and the gap was recorded twice
# without being fixed. Recording a known issue a second time is how it becomes permanent.
#
# ⛔ GLOBAL, NOT PER-TENANT — and there is no per-tenant variant to add.
# `public.vm_cve_metadata` is ONE table with no tenant_id, shared by every tenant. An
# advisory date is a fact about a CVE, not about an estate. Tenants see the effect through
# the decoration layer, which is where tenant scoping actually lives.


# ⚠️ No pre-flight role check here. The house pattern for SA-only verbs is to send the
# request and let the server's `has_role("super_admin")` answer; `_handle_sa_only` turns
# the 403 into a sentence. A local check was tried (profile-NAME match, then a JWT
# `roles` decode) and both were worse: the name match refused Classie's `CSA` profile
# outright, and the decode collapsed "not logged in" into "not a super-admin". The
# server already holds the rule; mirroring it client-side only adds a second place to
# be wrong. `etl-sa threat-intel` hits the same routes with no local check at all.


@integrations.group(name="threat-intel")
def threat_intel():
    """Global CVE-intel feed cache (KEV / EPSS / NVD). SUPER-ADMIN ONLY.

    \b
    Examples:
      TORANA_PROFILE=SA torana integrations threat-intel status
      TORANA_PROFILE=SA torana integrations threat-intel refresh --mode sweep
    """


@threat_intel.command(name="status")
@click.pass_context
def threat_intel_status(ctx):
    """Feed freshness, row counts, and the NVD bulk-cache state."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("admin/etl/threat-intel/status")
    except APIError as e:
        _handle_sa_only(e, "Reading the global CVE-intel cache")
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text" or raw:
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    click.echo(f"rows          : {data.get('row_count', 0):,}")
    click.echo(f"  kev         : {data.get('kev_count', 0):,}")
    click.echo(f"  epss        : {data.get('epss_count', 0):,}")
    click.echo(f"  cvss        : {data.get('cvss_count', 0):,}")
    click.echo(f"last refresh  : {data.get('last_refresh_at')}")
    click.echo(f"next run      : {data.get('next_run_at')}")

    feeds = data.get("feeds") or []
    if feeds:
        click.echo("\nper-feed:")
        for f in feeds:
            click.echo(f"  {str(f.get('feed', '?')):8s} {str(f.get('status', '?')):8s} "
                       f"{str(f.get('row_count', '?')):>10s}  {f.get('refreshed_at')}")

    cache = data.get("nvd_cache") or {}
    click.echo("\nnvd bulk cache:")
    if not cache.get("present"):
        # ⚠️ An absent cache is NORMAL, not an error: it is rebuildable by design, and the
        # next sweep repopulates it. Say so, rather than showing a bare `false`.
        click.echo(f"  not present at {cache.get('dir', '?')} "
                   f"(normal — a sweep repopulates it)")
    else:
        click.echo(f"  dir         : {cache.get('dir')}")
        click.echo(f"  years       : {cache.get('years_cached', 0)} cached"
                   + (f", {cache.get('years_configured')} configured"
                      if cache.get("years_configured") else ""))
        click.echo(f"  size        : {(cache.get('bytes') or 0) / 1e6:.0f} MB")
        if cache.get("restricted"):
            # ⛔ Surfaced deliberately: a restricted set means years are ABSENT because
            # they were never fetched — NOT because NVD has no dates for them. That
            # distinction is the whole reason the cache records the configured set.
            click.echo("  ⚠️ RESTRICTED year set — years outside it were never fetched "
                       "(not 'no dates')")


@threat_intel.command(name="refresh")
@click.option("--mode", type=click.Choice(["auto", "delta", "sweep"]), default="auto",
              show_default=True,
              help="auto: pick by staleness. delta: the `modified` feed (8-day window). "
                   "sweep: per-year .meta comparison (~10 KB when nothing changed).")
@click.option("--source", "sources", multiple=True,
              type=click.Choice(["kev", "epss", "nvd"]),
              help="Restrict to specific feeds (repeatable). Default: all.")
@click.pass_context
def threat_intel_refresh(ctx, mode, sources):
    """Trigger a refresh of the global CVE-intel cache.

    \b
    ⛔ A full corpus seed is NOT available here — it cannot finish inside the request's
    worker lifetime. Run it offline instead:
      docker exec -d pantheon-integration-dev python3 -m torana_mesh.etl.nvd_backfill --full
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    body = {"nvd_mode": mode}
    if sources:
        body["sources"] = list(sources)

    client = _client(ctx)
    try:
        data = client.post("admin/etl/threat-intel/refresh", json=body)
    except APIError as e:
        _handle_sa_only(e, "Refreshing the global CVE-intel cache")
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text" or raw:
        output(data, fmt=fmt, raw=raw)
        return
    click.echo(f"started: sources={data.get('sources')} nvd_mode={data.get('nvd_mode')}")
    click.echo("(runs in the background — re-run `threat-intel status` to see the result)")


# ── deletion cleanup, collection view (INTEGRATION_DELETE_CLEANUP_TODO.md § 3.5) ──

@integrations.command(name="cleanup-status")
@click.option("--failed-only", is_flag=True, default=False,
              help="Only cleanups that failed and need attention.")
@click.pass_context
def integrations_cleanup_status(ctx, failed_only):
    """Deletions whose data cleanup is still running or has failed.

    \b
    Deleting an integration also removes the data it brought in, in the background.
    This is where you see one that did not finish. A failed cleanup means the data
    is STILL THERE and nothing else will remove it — retry with:
      torana integration <UUID> cleanup

    \b
    Examples:
      torana integrations cleanup-status
      torana integrations cleanup-status --failed-only
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    client = _client(ctx)
    params = {"failed_only": "true"} if failed_only else {}
    try:
        data = client.get("integrations/cleanup-status", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if raw or fmt in ("json", "yaml"):
        output(data, fmt=fmt, fields=fields, raw=raw)
        return

    items = (data or {}).get("items") or []
    if not items:
        click.echo("\n  No deletions are awaiting cleanup.\n"
                   if not failed_only else "\n  No failed cleanups.\n")
        return

    click.echo(f"\n  {'NAME':<34}{'STATE':<12}{'TRIES':>6}  LAST ERROR")
    for row in items:
        name = (row.get("name") or "(unnamed)")[:32]
        state = row.get("purge_state") or "?"
        tries = f"{row.get('purge_attempts', 0)}/{row.get('max_attempts', '?')}"
        err = (row.get("purge_last_error") or "")[:60]
        click.echo(f"  {name:<34}{state:<12}{tries:>6}  {err}")
    failed = [r for r in items if r.get("purge_state") == "failed"]
    if failed:
        click.echo(f"\n  ⚠ {len(failed)} cleanup(s) FAILED — that data is still present.")
        click.echo(f"    Retry: torana integration {failed[0].get('integration_id')} cleanup")
    click.echo("")


@integrations.command(name="cleanup-orphaned")
@click.option("--dry-run/--no-dry-run", default=True, show_default=True,
              help="Preview only. --no-dry-run actually removes rows.")
@click.option("--yes", "-y", is_flag=True, default=False,
              help="Skip the confirmation prompt (the preview is still printed).")
@click.pass_context
def integrations_cleanup_orphaned(ctx, dry_run, yes):
    """SUPER-ADMIN: remove datalake rows left behind by deleted integrations, all tenants.

    \b
    For integrations deleted BEFORE deletion-cleanup shipped: their record is already
    gone, so there is no per-integration handle left — only the rows themselves. This
    finds them across every tenant and removes them in one pass.

    \b
    Sole-contributor rows are DELETED. Rows another live integration also wrote are
    DETACHED (its key is stripped, the row stays).

    \b
    Examples:
      TORANA_PROFILE=SA torana integrations cleanup-orphaned
      TORANA_PROFILE=SA torana integrations cleanup-orphaned --no-dry-run --yes
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    client = _client(ctx)

    # The preview ALWAYS runs, even with --yes: --yes skips the PROMPT, not the
    # preview, so a scripted sweep still leaves a record of what it removed.
    # (Same contract as `purge-data`.)
    try:
        preview = client.delete("internal/cleanup/orphaned-integration-data",
                                params={"dry_run": "true"})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if dry_run:
        # ⚠️ Honour --format json/yaml on the DRY-RUN path too. A machine caller asking
        # for the preview must get the envelope, not the human table — this branch
        # returns early, so forgetting it here silently makes --format a no-op for the
        # most-used invocation.
        if raw or fmt in ("json", "yaml"):
            output(preview, fmt=fmt, fields=fields, raw=raw)
            return
        _render_orphan_sweep(preview, dry_run=True)
        click.echo("  Preview only — nothing was removed. "
                   "Re-run with --no-dry-run to apply.\n")
        return

    _render_orphan_sweep(preview, dry_run=True)

    totals = (preview or {}).get("totals") or {}
    if not (totals.get("would_delete") or totals.get("would_detach")):
        click.echo("  Nothing to remove.\n")
        return

    _confirm(f"PERMANENTLY delete {totals.get('would_delete', 0)} row(s) and detach "
            f"{totals.get('would_detach', 0)} across "
            f"{(preview or {}).get('tenants_with_orphans', 0)} tenant(s)? "
            f"This cannot be undone.", yes=yes)
    try:
        result = client.delete("internal/cleanup/orphaned-integration-data",
                               params={"dry_run": "false"})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if raw or fmt in ("json", "yaml"):
        output(result, fmt=fmt, fields=fields, raw=raw)
        return
    _render_orphan_sweep(result, dry_run=False)


def _render_orphan_sweep(data, dry_run):
    if not isinstance(data, dict):
        click.echo(str(data))
        return
    totals = data.get("totals") or {}
    header = "WOULD REMOVE" if dry_run else "REMOVED"
    click.echo(f"\n{header} — orphaned integration data (all tenants)\n")
    click.echo(f"  tenants scanned        {data.get('tenants_scanned', 0)}")
    click.echo(f"  tenants with orphans   {data.get('tenants_with_orphans', 0)}")
    skipped = data.get("tenants_skipped_draining", 0)
    if skipped:
        # Skipped is a normal outcome, not a failure — say which, so it is not read as one.
        click.echo(f"  skipped (mid-refresh)  {skipped}   (picked up on the next run)")
    if dry_run:
        click.echo(f"\n  total: {totals.get('would_delete', 0)} to delete, "
                   f"{totals.get('would_detach', 0)} to detach")
    else:
        click.echo(f"\n  total: {totals.get('deleted', 0)} deleted, "
                   f"{totals.get('detached', 0)} detached")
        marked = data.get("tenants_marked_dirty") or []
        if marked:
            click.echo(f"  {len(marked)} tenant(s) queued for a graph refresh.")
    click.echo("")


# ===========================================================================
# ETL raw capture — what a sync RECEIVED, and where each record LANDED
#
# ⛔ A DEVELOPMENT INSTRUMENT, off by default (ETL_RAW_CAPTURE_ENABLED).
# Reads the on-disk capture tree via pantheon-integration; ZERO database.
# ⚠️ Super-admin only: a capture holds raw, unmasked third-party payloads —
# strictly more sensitive than the normalised datalake rows they become.
# ===========================================================================

@etl.group(name="capture")
def etl_capture():
    """Raw ETL capture — the records a sync received, and what they became.

    \b
    Answers the per-RECORD question nothing else on the platform can:
    "this GCP record — what did it look like before we touched it, and
    which datalake rows did it become?"

    \b
    Examples:
      torana etl capture status
      torana etl capture runs
      torana etl capture runs --integration-id <UUID>
      torana etl capture records <RUN_ID> --q cve-2026
      torana etl capture records <RUN_ID> --landed no      # became NOTHING
      torana etl capture lineage <RUN_ID> 0                # the fan-out
      torana etl capture sweep
    """


@etl_capture.command(name="status")
@click.pass_context
def etl_capture_status(ctx):
    """Is capture on, and what has it captured?"""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    client = _client(ctx)
    try:
        data = client.get("etl/capture/status")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt == "json" or raw:
        output(data, fmt="json", raw=raw)
        return
    # ⚠️ Lead with the FLAGS. "0 runs" means something completely different
    # when the feature is switched off, and a status line that omits that
    # sends the reader hunting a bug that does not exist.
    state = "ON" if data.get("enabled") else "OFF"
    click.echo(f"capture            {state}"
               + ("  (unmasked — raw PII on disk)" if data.get("unmasked") else ""))
    click.echo(f"dir                {data.get('dir')}")
    click.echo(f"runs captured      {data.get('runs')}")
    click.echo(f"bytes              {data.get('bytes'):,}")
    click.echo(f"cap / run          {data.get('max_records_per_run')} records")
    click.echo(f"retention          {data.get('retention_days')} days, "
               f"{data.get('max_total_mb')} MB ceiling")
    if not data.get("enabled"):
        click.echo("\nSet ETL_RAW_CAPTURE_ENABLED=true, then "
                   "`dev-compose reload-env pantheon-integration`.")


@etl_capture.command(name="runs")
@click.option("--integration-id", "integration_id", default=None)
@click.option("--data-source", "data_source", default=None)
@click.option("--limit", default=50, show_default=True, type=int)
@click.pass_context
def etl_capture_runs(ctx, integration_id, data_source, limit):
    """Captured runs, newest first."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    params = {"limit": limit}
    if integration_id:
        params["integration_id"] = integration_id
    if data_source:
        params["data_source"] = data_source
    client = _client(ctx)
    try:
        data = client.get("etl/capture/runs", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt == "json" or raw:
        output(data, fmt="json", raw=raw)
        return
    runs = data.get("runs") or []
    if not data.get("enabled"):
        click.echo("⚠️  capture is OFF — these are whatever earlier runs left behind.\n")
    if not runs:
        click.echo("No captured runs.")
        return
    click.echo(f"{'RUN':<38}{'DATA SOURCE':<34}{'STATUS':<10}"
               f"{'SEEN':>8}{'KEPT':>8}{'WRITES':>8}")
    for r in runs:
        # ⚠️ SEEN vs KEPT are different numbers whenever the per-run cap trips;
        # showing only one would make a capped capture look like a small sync.
        click.echo(f"{str(r.get('run_id','')):<38}{str(r.get('data_source',''))[:32]:<34}"
                   f"{str(r.get('status','')):<10}{r.get('records_seen',0):>8}"
                   f"{r.get('records_captured',0):>8}{r.get('lineage_rows',0):>8}")


@etl_capture.command(name="records")
@click.argument("run_id")
@click.option("--q", default=None, help="Case-insensitive substring over the whole record.")
@click.option("--sort", default=None, help="Field to sort by.")
@click.option("--direction", type=click.Choice(["asc", "desc"]), default="asc")
@click.option("--landed", type=click.Choice(["yes", "no"]), default=None,
              help="'no' = records that produced NO datalake write at all.")
@click.option("--page", default=1, show_default=True, type=int)
@click.option("--page-size", default=100, show_default=True, type=int)
@click.pass_context
def etl_capture_records(ctx, run_id, q, sort, direction, landed, page, page_size):
    """Raw records for a run — filtered, sorted, paginated SERVER-SIDE."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    params = {"page": page, "page_size": page_size, "direction": direction}
    for k, v in (("q", q), ("sort", sort), ("landed", landed)):
        if v:
            params[k] = v
    client = _client(ctx)
    try:
        data = client.get(f"etl/capture/runs/{run_id}/records", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt == "json" or raw:
        output(data, fmt="json", raw=raw)
        return
    items = data.get("items") or []
    click.echo(f"{data.get('total', 0)} record(s) match  "
               f"(page {data.get('page')} of "
               f"{max(1, -(-data.get('total', 0) // max(1, data.get('page_size', 1))))})\n")
    for r in items:
        landed_in = ", ".join(r.get("landed_in") or []) or "— nothing"
        click.echo(f"  [{r.get('record_idx')}] → {landed_in}")
        flat = r.get("flat") or {}
        preview = "  ".join(f"{k}={str(v)[:28]}" for k, v in list(flat.items())[:4])
        if preview:
            click.echo(f"       {preview}")
    if items:
        click.echo(f"\nDrill into one:  torana etl capture lineage {run_id} "
                   f"{items[0].get('record_idx')}")


@etl_capture.command(name="lineage")
@click.argument("run_id")
@click.argument("record_idx", type=int)
@click.pass_context
def etl_capture_lineage(ctx, run_id, record_idx):
    """What ONE raw record became in the datalake.

    ⭐ More than one write is a FAN-OUT — one source record that became rows
    in two different sink tables. Because the `tee` that does it is
    conditional on record content, this cannot be read off the mapping.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    client = _client(ctx)
    try:
        data = client.get(f"etl/capture/runs/{run_id}/records/{record_idx}/lineage")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt == "json" or raw:
        output(data, fmt="json", raw=raw)
        return
    writes = data.get("writes") or []
    click.echo(f"record {record_idx} → {len(writes)} datalake write(s)"
               + ("   ⭐ FAN-OUT" if len({w.get('table') for w in writes}) > 1 else ""))
    for w in writes:
        click.echo(f"\n  {w.get('table')}")
        click.echo(f"    {w.get('primary_key_field')} = {w.get('primary_key_value')}")
        cols = w.get("columns_written") or []
        click.echo(f"    {len(cols)} column(s): {', '.join(cols[:10])}"
                   + (" …" if len(cols) > 10 else ""))
    if not writes:
        click.echo("\n  ⚠️ This record produced NO datalake write — filtered out by "
                   "the mapping,\n     or skipped by a conditional tee.")


@etl_capture.command(name="sweep")
@click.pass_context
def etl_capture_sweep(ctx):
    """Apply retention + size limits now.

    ⛔ The capture tree grows per sync, forever — unlike the NVD cache, whose
    corpus is finite. Nothing else in the service sweeps it.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    client = _client(ctx)
    try:
        data = client.post("etl/capture/sweep", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt == "json" or raw:
        output(data, fmt="json", raw=raw)
        return
    click.echo(f"removed {data.get('removed_count', 0)} run(s), "
               f"freed {(data.get('freed_bytes') or 0) / 1e6:.1f} MB; "
               f"{(data.get('total_bytes') or 0) / 1e6:.1f} MB remains")


@etl_capture.command(name="schema")
@click.argument("run_id")
@click.argument("record_idx", type=int)
@click.option("--status", type=click.Choice(["declared", "undeclared", "missing"]),
              default=None, help="Show only fields with this status.")
@click.option("--q", default=None, help="Substring match on the field path.")
@click.option("--page", default=1, show_default=True, type=int)
@click.option("--page-size", default=100, show_default=True, type=int)
@click.pass_context
def etl_capture_schema(ctx, run_id, record_idx, status, q, page, page_size):
    """One raw record RENDERED against its declared source schema.

    \b
    Instead of a wall of untyped JSON, each field is shown with its declared
    type, description, PII flag and allowed values from
    integrations/catalogs/<provider>.yaml.

    \b
    ⚠️ Three statuses, and the last two are the interesting ones:
      declared    present, and the catalog describes it
      undeclared  present, but the catalog does NOT declare it
      missing     declared, but the vendor did not send it
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    params = {"page": page, "page_size": page_size}
    for k, v in (("status", status), ("q", q)):
        if v:
            params[k] = v
    client = _client(ctx)
    try:
        data = client.get(
            f"etl/capture/runs/{run_id}/records/{record_idx}/schema", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt == "json" or raw:
        output(data, fmt="json", raw=raw)
        return

    # ⚠️ Lead with whether a schema was found at all. Without this line, a record
    # whose every field reads "undeclared" is indistinguishable from a provider
    # whose catalog was never written.
    if not data.get("schema_available"):
        click.echo(click.style(
            "⚠️  No source catalog for this provider — showing the raw record "
            "with observed types only.", fg="yellow"))
    else:
        click.echo(f"{data.get('source')}/{data.get('data_source')}  "
                   f"— {data.get('declared_field_count')} declared field(s)")
        if data.get("schema_description"):
            click.echo(f"  {data['schema_description'][:100]}")
    c = data.get("counts") or {}
    click.echo(f"\n  declared {c.get('declared', 0)}   "
               f"undeclared {c.get('undeclared', 0)}   "
               f"missing {c.get('missing', 0)}"
               f"      (showing {len(data.get('fields') or [])} of {data.get('total', 0)})\n")

    _MARK = {"declared": "✓", "undeclared": "+", "missing": "∅"}
    for f in (data.get("fields") or []):
        st = f.get("status", "")
        flags = []
        if f.get("pii"):
            flags.append("PII")
        if f.get("required"):
            flags.append("required")
        if f.get("type_mismatch"):
            flags.append(f"⚠ declared {f.get('declared_type')}")
        if f.get("enum_violation"):
            flags.append("⚠ not in enum")
        tail = ("  [" + ", ".join(flags) + "]") if flags else ""
        val = f.get("value")
        if f.get("container"):
            shown = f"<{f['container']}, {f.get('child_count', 0)} item(s)>"
        elif val is None and st == "missing":
            shown = "—"
        else:
            shown = str(val)[:70]
        typ = f.get("declared_type") or f.get("observed_type") or ""
        click.echo(f"  {_MARK.get(st, ' ')} {f.get('path'):<44}{typ:<10}{shown}{tail}")
        if f.get("description"):
            click.echo(f"      {f['description'][:96]}")
        if f.get("enum"):
            click.echo(f"      allowed: {', '.join(str(e) for e in f['enum'][:8])}")
