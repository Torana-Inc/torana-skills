"""torana widgets — widget collection management commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW, CollectionGroup
from torana_cli.output import output
from torana_cli.rules import _load_input_file

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 35),
    ("widget_type", "TYPE", 20),
    ("dashboard_id", "DASHBOARD_ID", 36),
    ("created_by", "CREATED_BY", 36),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(cls=CollectionGroup, singular="widget")
def widgets():
    """Manage dashboard widgets (collection operations).

    \b
    Instance commands (get, update, delete, move) are under:
      torana widget <UUID> <verb>

    \b
    Examples:
      torana widgets list
      torana widgets list --dashboard-id <UUID>
      torana widgets create --name "Alert Count" --dashboard-id <UUID> --file widget.yaml
    """


@widgets.command(name="list")
@click.option("--dashboard-id", default=None, help="Filter by dashboard UUID.")
@click.option("--search", default=None, help="Search by name.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def widgets_list(ctx, dashboard_id, search, page, page_size, fetch_all):
    """List widgets."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if dashboard_id:
        params["dashboard_id"] = dashboard_id
    if search:
        params["search"] = search

    client = _client(ctx)
    try:
        if dashboard_id:
            # The collection endpoint ignores `dashboard_id` (server-side gap), and a
            # widget payload carries no dashboard linkage, so membership can only be
            # read from the dashboard itself — the same source `dashboard <id> widgets
            # list` uses. Route the filter there rather than returning every widget on
            # the tenant as if it were the answer.
            dash = client.get(f"dashboards/{dashboard_id}")
            items = (dash or {}).get("widgets", []) if isinstance(dash, dict) else []
            if search:
                needle = search.lower()
                items = [w for w in items if needle in (w.get("name") or "").lower()]
            result = {"items": items, "total": len(items), "page": 1,
                      "page_size": len(items)}
        elif fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                p.update({k: v for k, v in params.items() if k not in ("skip", "limit")})
                data = client.get("widgets/", params=p)
                if isinstance(data, dict):
                    items = data.get("items", [])
                    total = data.get("total", len(items))
                else:
                    items = data if isinstance(data, list) else []
                    total = len(all_items) + len(items)
                all_items.extend(items)
                if not items or len(all_items) >= total:
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items), "page": 1,
                      "page_size": len(all_items)}
        else:
            data = client.get("widgets/", params=params)
            result = data if isinstance(data, dict) and "items" in data else {
                "items": data if isinstance(data, list) else [],
                "total": len(data) if isinstance(data, list) else 0,
                "page": page, "page_size": effective_page_size
            }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@widgets.command(name="create")
@click.option("--name", default=None)
@click.option("--dashboard-id", default=None,
              help="Dashboard UUID. The widget is created AND attached to it.")
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def widgets_create(ctx, name, dashboard_id, input_file):
    """Create a new widget.

    \b
    ⛔ `display_config` is REQUIRED on EVERY widget type, and its shape differs per
    type. Omitting it returns 422 `display_config: Field required`; supplying the
    wrong shape returns 400 naming one missing key at a time, so a three-key shape
    costs three round trips. The shapes, as used by the widgets on this platform:

    \b
      table         {"columns": ["col_a", "col_b"]}
      scalar        {"value_column": "n", "label": "Open criticals"}
      bar | line    {"x_axis": "severity", "y_axis": "count"}
      pie           {"x_axis": "...", "y_axis": "...",
                     "label_field": "severity", "value_field": "count"}

    \b
    ⚠️ `widget_type` DEFAULTS TO `table` — the one type whose display_config is
    easiest to omit. Set it explicitly or every panel renders as a table.

    \b
    The body also requires `workspace_id` and `query_id`; neither is a flag, so a
    real create needs --file:

    \b
      torana widgets create --name "Open by severity" --dashboard-id <DASH> --file w.json
      # w.json:
      # {"widget_type": "bar", "workspace_id": "<WS>", "query_id": "<Q>",
      #  "display_config": {"x_axis": "severity", "y_axis": "count"}}
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if dashboard_id:
        body["dashboard_id"] = dashboard_id

    if not body.get("name"):
        click.echo("ERROR: --name is required.", err=True)
        import sys
        sys.exit(2)

    # `dashboard_id` in the create body is accepted and dropped by the server, so
    # the widget is created attached to nothing while the call reports success.
    # Attach explicitly afterwards — the same call `dashboard <id> add-widget`
    # makes — so the flag means what it says.
    attach_to = body.pop("dashboard_id", None)

    client = _client(ctx)
    try:
        data = client.post("widgets/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    widget_id = data.get("id") if isinstance(data, dict) else None
    if attach_to and widget_id:
        try:
            client.post(f"dashboards/{attach_to}/widgets", json={"widget_id": widget_id})
        except (APIError, AuthError) as e:
            # The widget itself exists — say so, and say the attach did not, rather
            # than reporting a plain success for a half-completed operation.
            click.echo(
                f"Created widget: {widget_id}\n"
                f"WARNING: created, but attaching it to dashboard {attach_to} failed: {e}\n"
                f"         attach it with: torana dashboard {attach_to} add-widget {widget_id}",
                err=True)
            import sys
            sys.exit(1)

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        msg = f"Created widget: {data.get('id', 'unknown')}"
        if attach_to:
            msg += f" (attached to dashboard {attach_to})"
        click.echo(msg)


@widgets.command(name="by-type-by-widget-type")
@click.argument("WIDGET_TYPE", metavar="WIDGET_TYPE")
@click.pass_context
def widgets_by_type_by_widget_type(ctx, widget_type):
    """Get Widgets By Type."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"widgets/by-type/{widget_type}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@widgets.command(name="by-query-by-query-id")
@click.argument("QUERY_ID", metavar="QUERY_ID")
@click.pass_context
def widgets_by_query_by_query_id(ctx, query_id):
    """Get Widgets By Query."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"widgets/by-query/{query_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@widgets.command(name="verdict")
@click.argument("widget_id", metavar="WIDGET_ID")
@click.pass_context
def widgets_verdict(ctx, widget_id):
    """Why is this widget empty — and WHO can fix it?

    Resolves an empty widget to one of four verdicts, each with a different owner:

      blocked  a shipped integration can write this, but none you have connected does
      empty    everything is connected; there is genuinely nothing to show yet
      stale    the source is connected but its sync is failing
      live     rows returned

    A silent zero cannot tell those apart, and they need different people to act.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        data = client.get(f"render/widget/{widget_id}/verdict")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt in ("json", "yaml"):
        output(data, fmt=fmt)
        return

    verdict = (data.get("verdict") or "unknown").upper()
    # Glyph + word, never colour alone.
    cue = {"LIVE": "✓", "EMPTY": "○", "BLOCKED": "✕", "STALE": "⚠", "UNKNOWN": "?"}.get(verdict, "?")
    click.echo(f"\nWidget {data.get('widget_id')}")
    click.echo(f"  [{cue} {verdict}]  {data.get('message') or ''}")
    if data.get("owner"):
        click.echo(f"  owner: {data['owner']}")
    if data.get("missing_integrations"):
        click.echo(f"  connect: {', '.join(data['missing_integrations'])}")
    ev = data.get("evidence") or {}
    for k, v in ev.items():
        click.echo(f"  {k:20} {str(v)[:100]}")
    click.echo("")


# ⛔ SURFACE PARITY — the FE shows a health chip on every widget; the CLI must
# answer the same question for the same artifact, from the same resolver.
from torana_cli.supply_health import health_command  # noqa: E402
widgets.add_command(health_command("widget"))
