"""torana widgets — widget collection commands (list, create) and the app-wide sweep core.

Instance commands live in widget.py (`torana widget <ID> <verb>`).
"""

import sys

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error, echo_reference
from torana_cli.config.settings import get_settings
from torana_cli.dashboards import fetch_dashboards, with_start_here
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW, CollectionGroup
from torana_cli.output import output
from torana_cli.pagination import PagingError, fetch_all_pages
from torana_cli.rules import _load_input_file
from torana_cli.supply_health import glyph_for, workspace_health_map
from torana_cli.widget_card import FAIL_ON, card_state, finish, render_batch, summary_line

_PAGE = 100
WIDGET_TYPES = ("table", "pie", "bar", "line", "scalar")

_LIST_COLS = [
    ("id", "ID", None),
    ("name", "NAME", 50),
    ("widget_type", "TYPE", 8),
    ("query_id", "QUERY", None),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(cls=CollectionGroup, singular="widget")
def widgets():
    """Widgets: list them, or create one on a dashboard.

    A widget is one card on a dashboard: a query plus how to draw its result.

    {START_HERE}

    \b
    Examples:
      torana widgets list --app-id <APP_ID>
      torana widgets list --dashboard-id <DASHBOARD_ID>
      torana widgets create --name "Open by severity" --dashboard-id <DASHBOARD_ID> --file w.json

    To read, change or delete one widget use the singular form, `torana widget <ID> ...`.
    """


with_start_here(widgets)


def _as_rows(data) -> list:
    return data.get("items", []) if isinstance(data, dict) else (data or [])


@widgets.command(name="list")
@click.option("--app-id", "app_id", default=None, help="Only this app's widgets.")
@click.option("--dashboard-id", default=None, help="Only the widgets on this dashboard.")
@click.option("--type", "widget_type", default=None, type=click.Choice(WIDGET_TYPES),
              help="Only widgets of this type.")
@click.option("--query-id", default=None, help="Only the widgets that use this query.")
@click.option("--search", default=None, help="Only widgets whose name contains this text.")
@click.option("--page", default=None, type=int, help="Page to print, with --page-size.")
@click.option("--page-size", default=None, type=int, help="Rows per page. Default: every widget.")
@click.pass_context
def widgets_list(ctx, app_id, dashboard_id, widget_type, query_id, search, page, page_size):
    """List widgets, optionally by app, dashboard, type or query.

    Names, types and ids only. Use one filter at a time. The list is always complete:
    it is read page by page from the server.

    \b
    For each widget's health, freshness and whether it renders, use the sweep:
      torana app <APP_ID> widgets list

    \b
    Examples:
      torana widgets list --app-id <APP_ID>
      torana widgets list --dashboard-id <DASHBOARD_ID>
      torana widgets list --type scalar
      torana widgets list --query-id <QUERY_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    chosen = [n for n, v in (("--app-id", app_id), ("--dashboard-id", dashboard_id),
                             ("--type", widget_type), ("--query-id", query_id)) if v]
    if len(chosen) > 1:
        click.echo(f"ERROR: use one filter at a time, not {' and '.join(chosen)}.", err=True)
        sys.exit(2)

    client = _client(ctx)
    try:
        if dashboard_id:
            # A widget carries no dashboard link; membership is on the dashboard itself.
            rows = (client.get(f"dashboards/{dashboard_id}") or {}).get("widgets") or []
        elif widget_type:
            rows = _as_rows(client.get(f"widgets/by-type/{widget_type}"))
        elif query_id:
            rows = _as_rows(client.get(f"widgets/by-query/{query_id}"))
        else:
            def get_page(index):
                params = {"skip": index * _PAGE, "limit": _PAGE}
                if app_id:
                    params["workspace_id"] = app_id
                return _as_rows(client.get("widgets/", params=params)), None
            rows, _ = fetch_all_pages(get_page, page_size=_PAGE)
    except PagingError as e:
        click.echo(f"ERROR: could not list every widget: {e}", err=True)
        sys.exit(1)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if search:
        needle = search.lower()
        rows = [w for w in rows if needle in (w.get("name") or "").lower()]
    total = len(rows)
    if page_size:
        start = ((page or 1) - 1) * page_size
        rows = rows[start:start + page_size]
    output({"items": rows, "total": total, "page": page or 1, "page_size": page_size or len(rows)},
           fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


# ── the app-wide sweep: `torana app <APP_ID> widgets list` ────────────────────
# The command is registered on the app group; these two functions are its whole body.
#
# ⛔ HEALTH AND STATUS ARE DIFFERENT QUESTIONS, so the sweep shows both:
#   status  -> did this run return rows just now      (success | no_data | error)
#   health  -> can it ever return complete data, and who fixes it when it cannot
# A `degraded` widget still renders rows; a `no_data` widget can be perfectly healthy.

def app_widget_rows(client, app_id: str) -> list:
    """Every widget across an app's dashboards, once each, with the dashboards it is on.

    Read from the dashboards list (each dashboard embeds its widgets), walked to the end,
    so no dashboard is missed and no per-dashboard call is made. A widget on two
    dashboards is ONE row.
    """
    rows = {}
    for d in fetch_dashboards(client, app_id):
        for w in d.get("widgets") or []:
            key = w.get("id")
            if not key:
                continue
            row = rows.setdefault(key, {"id": key, "name": w.get("name") or "(untitled)",
                                        "widget_type": w.get("widget_type"), "dashboards": []})
            row["dashboards"].append(d.get("name") or d["id"])
    for r in rows.values():
        r["dashboard"] = ", ".join(r["dashboards"])
    return list(rows.values())


def _row_count(data):
    if not isinstance(data, dict):
        return "-"
    if "rows" in data:
        return len(data["rows"])
    if "labels" in data:
        return len(data["labels"])
    return data.get("value", "-")


def list_app_widgets_core(ctx, app_id, *, no_render=False, refresh=False, fail_on=()) -> None:
    """Sweep an app: every widget with its health, freshness and render status.

    One batch render per 100 widgets, with health in the same call (never a render per
    widget). Exits 1 when a widget fails to render, or matches --fail-on.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)

    try:
        rows = app_widget_rows(client, app_id)
        rendered = []
        if no_render:
            health = workspace_health_map(client, app_id, kinds=("widget",))
        elif rows:
            rendered, _ = render_batch(client, [r["id"] for r in rows], refresh=refresh,
                                       include_health=True)
            health = {w.get("widget_id"): w.get("health") for w in rendered}
        else:
            health = {}
    except PagingError as e:
        click.echo(f"ERROR: could not list every dashboard of this app: {e}", err=True)
        sys.exit(1)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    by_id = {w.get("widget_id"): w for w in rendered}
    for r in rows:
        h = health.get(r["id"]) or {}
        # A widget with no health answer is `unknown`, never healthy by omission.
        state = h.get("health_state") or "unknown"
        r["health_state"] = state
        r["health"] = f"{glyph_for(state)} {h.get('health_label') or state.upper()}"
        r["why"] = h.get("why")
        r["owner"] = h.get("owner")
        w = by_id.get(r["id"])
        if w is not None:
            r["status"] = w.get("status") or "?"
            r["state"] = card_state(w)
            r["rows"] = _row_count(w.get("data"))
            r["freshness"] = w.get("freshness") or "unknown"
            r["data_as_of"] = w.get("data_as_of")
            r["reason"] = ((w.get("card") or {}).get("empty") or {}).get("message")

    cols = [("name", "WIDGET", 44), ("widget_type", "TYPE", 8), ("health", "HEALTH", 18)]
    if not no_render:
        cols += [("status", "STATUS", 9), ("rows", "ROWS", 6), ("freshness", "FRESHNESS", 9)]
    cols += [("dashboard", "DASHBOARD", 28), ("id", "ID", None)]

    output({"items": rows, "total": len(rows), "page": 1, "page_size": len(rows)},
           fmt=fmt, raw=raw, fields=fields, columns=cols)
    if rendered:
        if fmt == "text":
            click.echo(summary_line(rendered))
        finish(rendered, fail_on)


#: The options of `app <APP_ID> widgets list`, kept beside its core so the registration is one line.
def app_widgets_list_options(f):
    f = click.option("--fail-on", "fail_on", multiple=True, type=click.Choice(FAIL_ON),
                     help="Exit 1 when a widget is stale, empty or failed. Repeat for several. "
                          "A failed render exits 1 even without this.")(f)
    f = click.option("--refresh", is_flag=True, default=False,
                     help="Run every query again now (skip the 30-minute result cache).")(f)
    f = click.option("--no-render", is_flag=True, default=False,
                     help="Health only: skip rendering (no STATUS, ROWS or FRESHNESS).")(f)
    return f


@widgets.command(name="create")
@click.option("--name", default=None, help="The widget's title.")
@click.option("--dashboard-id", default=None,
              help="The dashboard to put it on. The widget is created AND attached to it.")
@click.option("--app-id", "app_id", default=None,
              help="The app the widget belongs to (or `app_id` in the file).")
@click.option("--query-id", "query_id", default=None,
              help="The query it draws (or `query_id` in the file).")
@click.option("--file", "input_file", default=None, metavar="FILE",
              help="JSON/YAML body: widget_type, display_config, and any of the above.")
@click.pass_context
def widgets_create(ctx, name, dashboard_id, app_id, query_id, input_file):
    """Create a widget and attach it to a dashboard.

    A widget needs a query first: make one with `torana queries create`, then pass its
    id in the file as `query_id`.

    \b
    ⛔ `display_config` is REQUIRED on EVERY widget type, and its shape differs per
    type. Omitting it returns 422 `display_config: Field required`; supplying the
    wrong shape returns 400 naming one missing key at a time, so a three-key shape
    costs three round trips. The shapes, as used by the widgets on this platform:

    \b
      table         {"columns": ["col_a", "col_b"]}
      scalar        {"value_column": "n", "label": "Open criticals"}
      bar | line    {"x_axis": "severity", "y_axis": "count"}
      pie           {"x_axis": "...", "y_axis": "...",
                     "label_field": "severity", "value_field": "count"}

    \b
    ⚠️ `widget_type` DEFAULTS TO `table` — the one type whose display_config is
    easiest to omit. Set it explicitly or every panel renders as a table.

    \b
    A widget also needs its app and its query: pass --app-id and --query-id, or put
    `app_id` and `query_id` in the file.

    \b
    Examples:
      torana queries create --name "Open by severity" --file q.json
      # q.json: {"sql_command": "SELECT severity, count(*) AS count FROM vulnerabilities GROUP BY severity"}
      torana widgets create --name "Open by severity" --dashboard-id <DASHBOARD_ID> \\
          --app-id <APP_ID> --query-id <QUERY_ID> --file w.json
      # w.json:
      # {"widget_type": "bar", "display_config": {"x_axis": "severity", "y_axis": "count"}}
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if dashboard_id:
        body["dashboard_id"] = dashboard_id
    # The CLI says app; the API's body key is workspace_id.
    if "app_id" in body:
        body.setdefault("workspace_id", body.pop("app_id"))
    if app_id:
        body["workspace_id"] = app_id
    if query_id:
        body["query_id"] = query_id

    if not body.get("name"):
        click.echo("ERROR: --name is required.", err=True)
        sys.exit(2)

    # `dashboard_id` in the create body is accepted and dropped by the server, so
    # the widget is created attached to nothing while the call reports success.
    # Attach explicitly afterwards — the same call `dashboard <id> widgets add`
    # makes — so the flag means what it says.
    attach_to = body.pop("dashboard_id", None)

    client = _client(ctx)
    try:
        data = client.post("widgets/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    widget_id = data.get("id") if isinstance(data, dict) else None
    if attach_to and widget_id:
        try:
            client.post(f"dashboards/{attach_to}/widgets", json={"widget_id": widget_id})
        except (APIError, AuthError) as e:
            # The widget itself exists — say so, and say the attach did not, rather
            # than reporting a plain success for a half-completed operation.
            click.echo(
                f"Created widget: {widget_id}\n"
                f"WARNING: created, but attaching it to dashboard {attach_to} failed: {e}\n"
                f"         attach it with: torana dashboard {attach_to} widgets add {widget_id}",
                err=True)
            echo_reference(e)
            sys.exit(1)

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        msg = f"Created widget: {data.get('id', 'unknown')}"
        if attach_to:
            msg += f" (attached to dashboard {attach_to})"
        click.echo(msg)
