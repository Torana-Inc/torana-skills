"""torana vm transformers — VM transformer catalog & materialization (Spec B).

Attaches the ``transformers`` subgroup onto the shared ``torana vm`` parent via
``register_vm_subgroup`` (see vm.py) — this module never re-defines ``vm``, so
Specs A/B/C can be built in parallel without colliding.

Three-surface parity (R8): every read/operational capability on the API is here
and on the FE. The internal ``materialize`` / ``release`` calls are deliberately
NOT CLI verbs — they are service-to-service install side-effects (Spec B § 3.9.1);
only their *effect* (the materialization row: refcount + status) is CLI-visible,
via ``materialized``. That is the explicitly-argued internal-only case, not a
missing surface.

Spec: pantheon-program-framework/docs/VM/02_SpecB_Transformer_Catalog.md § 3.4.1
"""

import json
import os
import re
from pathlib import Path

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.vm import register_vm_subgroup

_BASE = "vm/transformers"

_CATALOG_COLS = [
    ("id", "ID", 34),
    ("version", "VER", 4),
    ("description", "DESCRIPTION", 44),
    ("source_tables", "SOURCES", 28),
]

_MATERIALIZED_COLS = [
    ("catalog_entry_id", "ENTRY", 34),
    ("status", "STATUS", 13),
    ("refcount", "REFS", 5),
    ("physical_table", "TABLE", 34),
    ("last_refreshed_at", "REFRESHED", 26),
]

_DECISION_COLS = [
    ("id", "ID", 36),
    ("decision", "DECISION", 13),
    ("gap_category", "GAP", 17),
    ("near_miss_entry_id", "NEAR-MISS", 34),
    ("state", "STATE", 10),
]

_GAP_CATEGORIES = [
    "missing_column",
    "missing_hole",
    "wrong_grain",
    "different_join",
    "genuinely_novel",
    # "the entry is RIGHT but the platform cannot run it" — a platform bug, not a coverage
    # gap. The other five all mean "author new SQL", and the decision queue is mined to plan
    # catalog investment, so filing a broken-but-correct entry under one of them puts an item
    # in the "needs new SQL" queue that needs none. Measured: vm.tf.p0_actions and
    # vm.tf.reachable_actionable_vulns were both filed as `different_join` when neither had a
    # join problem at all.
    "platform_defect",
    # "the writer exists but has never been RUN" — the SQL is authorable and the column is
    # reachable; it is empty because nothing invoked the caller. Supply reports this as
    # NEEDS_CALLER and names the bridge. Measured: exploitability_status is written only by
    # torana-pentest and was NULL on all 86,696 T2 rows, so a correct refusal had to be filed
    # as `different_join` — routing a "run a pentest" item to whoever fixes joins.
    # ⚠️ NOT "no data": a column nothing can ever write is UNREACHABLE, not this.
    "needs_caller",
]

_STATES = ["new", "reviewed", "actioned", "dismissed"]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _fmt(ctx) -> str:
    return ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"


def _raw(ctx) -> bool:
    return ctx.obj.get(CTX_RAW, False) if ctx.obj else False


def _fields(ctx):
    return ctx.obj.get(CTX_FIELDS) if ctx.obj else None


@click.group(name="transformers")
def transformers():
    """VM transformer catalog — pre-authored convenience tables and their materializations.

    \b
    The catalog is reviewed CODE, not rows: entries are pre-authored once, correctly,
    so a program references a transformer by id instead of an LLM authoring SQL.

    \b
    Typical flow:
      torana vm transformers definitions list      # ALL 77 definitions (the converged store)
      torana vm transformers catalog search "<need>"   # the REUSE PROBE — scored candidates
      torana vm transformers definitions show <name>   # one definition + its SQL and grain
      torana vm transformers materialized          # what THIS tenant has materialized
      torana vm transformers decisions list        # where the store fell short
      torana vm transformers decisions review <id> --state actioned

    \b
    ⚠️ `catalog list` is the OLD 40-entry surface and is being retired. It serves 40
    rows where `definitions list` serves 77 — measured 2026-09-16 — so a reuse check
    run against it silently cannot see 37 definitions. Use `definitions list`.
    """


# ---------------------------------------------------------------------------
# catalog (collection group — bare invocation shows help, `list` lists)
# ---------------------------------------------------------------------------

@transformers.group(name="catalog", invoke_without_command=True)
@click.pass_context
def catalog(ctx):
    """The platform-authored catalog entries. Use `list` to list them."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@catalog.command(name="list")
@click.pass_context
def catalog_list(ctx):
    """List all VM transformer catalog entries."""
    client = _client(ctx)
    try:
        data = client.get(f"{_BASE}/catalog")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if _raw(ctx) or fmt != "text":
        output(data, fmt=fmt, raw=_raw(ctx), fields=_fields(ctx), columns=_CATALOG_COLS)
        return

    # THE FULL CATALOG, UNTRUNCATED — this is the reuse decision surface.
    #
    # Not a fixed-width table: `output()` clips any cell past its column width, and
    # `grain` — the field a reuse decision actually turns on — is exactly the one long
    # enough to lose its qualifying clause. Truncating the evidence to fit a column
    # defeats the point of printing it.
    #
    # A caller reads this ONCE per build and adjudicates against it. The whole catalog
    # is ~5k tokens; ranking it first is what introduced every retrieval failure we
    # have chased (shape-vs-intent mismatch, scores clustered within 0.005, the right
    # entry hidden below top_k). There is nothing to rank when you can read it all.
    items = data.get("items", [])
    for e in items:
        tables = e.get("source_tables")
        tables = ", ".join(tables) if isinstance(tables, list) else (tables or "—")
        ver = e.get("version_in_catalog") or e.get("version")
        click.echo(f"{e['id']}  v{ver}  [{e.get('materialization', 'view')}]")
        click.echo(f"    answers : {e.get('description') or '—'}")
        click.echo(f"    one row : {e.get('grain') or '(grain not declared)'}")
        click.echo(f"    reads   : {tables}")
        click.echo("")
    click.echo(f"  {len(items)} entries. Read `one row` to judge whether an entry")
    click.echo("  SATISFIES your need; `catalog show <id>` for its SQL.")


@catalog.command(name="render")
@click.option("--file", "sql_file", type=click.Path(exists=True, dir_okay=False),
              default=None, help="File containing the templated SQL.")
@click.option("--sql", "sql_text", default=None, help="Templated SQL as a string.")
@click.option("--vocabulary", "vocab_json", default=None,
              help="JSON object of explicit vocabulary values. Omit to bind from "
                   "this tenant's resolved policy + conservative defaults.")
@click.pass_context
def catalog_render(ctx, sql_file, sql_text, vocab_json):
    """Bind {{vocabulary}} placeholders into templated SQL. Render only — never executes.

    \b
    Templated SQL is the NORM for tenant-neutral authoring: per-tenant policy is
    written as placeholders so ONE SQL serves every tenant. This binds them through
    the platform's own binder, so what you check is what materialize would build.

    \b
    Examples:
      torana vm transformers catalog render --file query.sql
      torana vm transformers catalog render --sql "SELECT ... {{severity_floor.at_or_above}}"
      torana vm transformers catalog render --file q.sql --format json
    """
    if bool(sql_file) == bool(sql_text):
        raise click.UsageError("pass exactly one of --file or --sql")

    sql = Path(sql_file).read_text() if sql_file else sql_text

    payload = {"sql": sql}
    if vocab_json:
        try:
            payload["vocabulary"] = json.loads(vocab_json)
        except json.JSONDecodeError as e:
            raise click.UsageError(f"--vocabulary is not valid JSON: {e}")

    client = _client(ctx)
    try:
        data = client.post(f"{_BASE}/catalog/render", json=payload)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if fmt != "text":
        output(data, fmt=fmt, fields=_fields(ctx))
        return

    # Text mode prints the SQL to STDOUT and its provenance to STDERR, so
    # `... render --file q.sql > bound.sql` yields a usable file rather than one
    # with a commentary header wedged into it.
    click.echo(data.get("rendered_sql", ""))
    used = data.get("used_keys") or []
    defaulted = data.get("defaulted_keys") or []
    if used:
        click.echo(f"# vocabulary keys used: {', '.join(used)}", err=True)
    if defaulted:
        # Surfaced ALWAYS: "the platform assumed this" must never be invisible.
        click.echo(f"# ⚠️  bound from CONSERVATIVE DEFAULTS (not this tenant's "
                   f"stated policy): {', '.join(defaulted)}", err=True)


#: Origins a decision row can carry. ⛔ The curation ranking is computed over `live` ONLY.
_DECISION_ORIGINS = ("live", "test", "seed")


def _resolve_origin(explicit: str | None) -> str:
    """Who is recording this decision — 'live' (default), 'test' or 'seed'.

    ⛔ **Load-bearing for curation, not cosmetic.** Measured 2026-08-26 on the live queue:
    93 of 225 decision rows came from verification lanes, and they did not merely pad the
    counts — they INVERTED them. `finding_enriched` read as the #1 gap at 55 when it is
    really #3 at 15, behind `asset_posture` at 19; `em_017` read #2 at 51 and was entirely
    probes. A curator acting on that widens the wrong entry, which is worse than having no
    ranking at all.

    ⚠️ **This CLI is how every one of those 87 rows was written** — by an agent or human
    running a verification lane and typing `record-miss`. Server-side env plumbing cannot
    reach that path, which is why the flag lives here.

    ⭐ Falls back to `TORANA_DECISION_ORIGIN` so a lane declares itself ONCE in its
    environment and every command it runs inherits it — no per-invocation flag to forget.

    Default `live` is deliberate: an undeclared caller counts as REAL demand, so a
    forgetful lane OVER-reports a gap rather than hiding one.
    """
    origin = (explicit or os.getenv("TORANA_DECISION_ORIGIN") or "live").strip().lower()
    if origin not in _DECISION_ORIGINS:
        # Warn and continue — this is telemetry, and refusing the record would cost a real
        # decision row over a mislabelled provenance field.
        click.echo(f"  ! unknown origin '{origin}' — recording as 'live'", err=True)
        origin = "live"
    return origin


#: Shared by `record-miss` and `search --record-miss`, so the two cannot drift.
_ORIGIN_OPTION = click.option(
    "--origin", "origin", default=None, type=click.Choice(_DECISION_ORIGINS),
    help="Who is recording this: live (default) | test | seed. ⛔ An automated lane MUST "
         "pass 'test' (or export TORANA_DECISION_ORIGIN=test) — the curation ranking is "
         "computed over 'live' rows only.")


@catalog.command(name="search")
@click.argument("query", metavar="QUERY")
# ⛔ THE TWO KNOBS ARE NOT SYMMETRIC — widen top_k, do NOT lower the threshold.
#
# `top-k` was hardcoded 5, overriding the server's 10. Widened to the server default:
# the server picked 10 because "a wider candidate set costs tokens but a missed entry
# costs a duplicate definition forever", and a candidate the caller never sees is one
# they will re-author. Measured 2026-09-16: 5 -> 10 surfaced five real definitions that
# sat just under the old cut. Pure gain — the reader still adjudicates on grain.
#
# ⛔ `threshold` stays at 0.7 and does NOT fall through to the server's 0.45. Measured
# 2026-09-16 on T2, and it reverses the intuition: at 0.45 "average rainfall in
# Bangalore in July" comes back is_miss=False with TEN cleared candidates, while a
# genuine need gains only two (8 -> 10). The recall gain is marginal; the discrimination
# loss is total. And `is_miss` is not cosmetic — it drives `--record-miss`, so at 0.45 a
# genuinely novel need records NO GAP AT ALL, silently, which is precisely the demand
# signal the curation queue exists to collect.
@click.option("--top-k", default=None, type=int,
              help="Max candidates to return.  [server default: 10]")
@click.option("--threshold", default=0.7, show_default=True,
              help="Below this similarity, a candidate is not an acceptable match. "
                   "⚠️ The score cannot see GRAIN — it is recall, not a verdict. Read "
                   "each candidate's `one row` line; do not treat clearing the bar as a "
                   "fit.")
@click.option("--record-miss", is_flag=True,
              help="Record an authoring-decision row when this lookup misses.")
@click.option("--gap-category", type=click.Choice(_GAP_CATEGORIES), default=None,
              help="Typed gap category; applies to a MISS only (ignored on a hit).")
@click.option("--rationale", default="", help="Supporting evidence for the decision.")
@_ORIGIN_OPTION
@click.pass_context
def catalog_search(ctx, query, top_k, threshold, record_miss, gap_category, rationale, origin):
    """Find a pre-authored entry that already does what you need.

    This is the point of the catalog: RETRIEVE a reviewed transformer instead of
    authoring SQL. With --record-miss, a lookup that finds nothing acceptable is
    recorded as a catalog gap for curation.
    """
    payload = {
        "query": query,
        "record_miss": record_miss,
        "rationale": rationale,
    }
    # Omit rather than send None: the server's Field defaults only apply to an ABSENT
    # key, and an explicit null fails validation.
    if top_k is not None:
        payload["top_k"] = top_k
    if threshold is not None:
        payload["similarity_threshold"] = threshold
    if record_miss:
        # Only meaningful when this lookup will WRITE a row. On a pure read there is no
        # decision to attribute, and sending it anyway would imply one was recorded.
        payload["origin"] = _resolve_origin(origin)
    if gap_category:
        payload["gap_category"] = gap_category

    client = _client(ctx)
    try:
        data = client.post(f"{_BASE}/catalog/search", json=payload)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if fmt != "text":
        output(data, fmt=fmt, fields=_fields(ctx))
        return

    # The output is a REPORT, not a result list. A caller — human or agent — has to
    # be able to judge the decision from what is printed: what was sought, what came
    # back, and on what axis each candidate differs. `grain` is the field most
    # rejections turn on, so it is shown per candidate rather than left to a
    # follow-up `catalog show`.
    click.echo("")
    click.echo(f"CATALOG SEARCH  ·  looking for: {data.get('query', '')}")
    click.echo("─" * 78)

    # On a MISS the threshold filters `matches` empty, so show what was CONSIDERED
    # and rejected instead. "No match" is an assertion; "these three were closest,
    # and each fails on grain" is something a reader can disagree with.
    matches = data.get("matches", [])
    shown = matches or data.get("considered", [])
    if matches:
        click.echo("  CLEARED THE THRESHOLD:")
    elif shown:
        click.echo("  CONSIDERED (none cleared the threshold):")
    else:
        click.echo("  nothing in the catalog is even close — genuinely novel shape")
    for m in shown:
        tables = ", ".join(m.get("source_tables") or []) or "—"
        click.echo(f"  {m['similarity']:.3f}  {m['entry_id']}  [{m.get('materialization', 'view')}]"
                   f"  →  {m['destination_table']}")
        click.echo(f"         answers : {m['description']}")
        click.echo(f"         one row : {m.get('grain') or '(grain not declared)'}")
        click.echo(f"         reads   : {tables}")
        # `projects:` — what the candidate actually SELECTs.
        #
        # ⛔ The reason this line exists: the cook rejected a perfect candidate with
        # "kev_watchlist does not project days_open and threat_score" — BOTH of which it
        # projects. The judge was asked to rule on `missing_column` while shown no columns,
        # so it guessed from the description and guessed wrong.
        #
        # ⛔ ABSENT IS HONEST; INCOMPLETE IS MISLEADING. The upstream parser returns NOTHING
        # (not a partial list) for `SELECT <alias>.*` forms it cannot resolve — measured
        # 2026-09-16: 67 of 77 entries resolve, and 2 of the 5 candidates in a live search
        # come back empty. Printing "projects: (none)" for those would assert that an entry
        # projects no columns, which is the same false-rejection this line was added to
        # prevent, just inverted. So an unresolved projection prints NO LINE AT ALL, and the
        # legend below tells the reader what a missing line means.
        projects = m.get("projected_columns")
        if projects:
            click.echo(f"         projects: {', '.join(projects)}")
        click.echo("")

    click.echo("─" * 78)
    # NO VERDICT HERE — deliberately (§ 4.21).
    #
    # This used to print "DECISION: HIT". It should not: cosine similarity measures
    # whether two sentences RESEMBLE each other, not whether an entry SATISFIES the
    # caller's intent. Two candidates can score within 0.05 of each other and produce
    # completely different grains. A platform-side verdict on a number that cannot
    # see grain is a verdict on the wrong question.
    #
    # The similarity ranking is RECALL. The caller — a model reading each candidate's
    # grain and source tables — is the adjudicator. What it decides, and on what axis,
    # is the reviewable artifact; a score is not.
    click.echo("YOU decide. Similarity is RECALL, not a verdict — it ranks by textual")
    click.echo("resemblance and cannot see grain. Read each candidate's `one row` line")
    click.echo("and judge whether it SATISFIES your need.")
    click.echo("")
    # Only print the legend when at least one candidate is MISSING its projection —
    # a permanently-displayed caveat is one readers learn to skip, and this one has to
    # be read on exactly the occasions it applies.
    if any(not m.get("projected_columns") for m in shown):
        click.echo("  ⚠️  no `projects:` line = the column list could NOT be resolved")
        click.echo("      (a `SELECT <alias>.*` form), NOT that the entry projects nothing.")
        click.echo("      Judge that candidate on grain; never reject it for a missing column.")
        click.echo("")
    click.echo("  reuse  → reference the entry by id; never copy its SQL")
    click.echo("  author → record the miss first, naming the AXIS that fails:")
    click.echo("             --record-miss --gap-category <cat> --rationale '<why>'")
    if data.get("near_miss_entry_id"):
        click.echo(f"\n  closest candidate : {data['near_miss_entry_id']}")
    if data.get("decision_id"):
        click.echo(f"  recorded decision : {data['decision_id']}")
        click.echo("  → pass this as catalog_decision_id when you create the transformer.")
    click.echo("")


@catalog.command(name="by-question")
@click.option("--min-count", "min_count", type=int, default=1,
              help="Only questions asked at least this often.")
@click.option("--include-synthetic", "include_synthetic", is_flag=True,
              help="Include rows produced by verification lanes and seed fixtures "
                   "(origin != 'live'). Default OFF — same rule as `decisions list`; the "
                   "two surfaces are read together and must share one denominator.")
@click.pass_context
def catalog_by_question(ctx, min_count, include_synthetic):
    """Which QUESTION do people keep asking that we cannot answer? SA only.

    `decisions list` groups by which ENTRY nearly fit — useful for "widen em_012". This
    groups by what was ASKED, which is the axis that says "add a NEW entry": a question
    missed fourteen times is a coverage gap, not a shape problem in any one entry.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        # ⚠️ The decisions router mounts at /vm/transformers/decisions, NOT under /catalog/ —
        # verified against the running server's openapi.json.
        params = {"min_count": min_count}
        if include_synthetic:
            params["include_synthetic"] = "true"
        data = client.get(f"{_BASE}/decisions/by-question", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if _raw(ctx) or fmt != "text":
        output(data, fmt=fmt)
        return

    items = data.get("items", [])
    click.echo(f"\nMISSES BY QUESTION   {data.get('total', 0)} question(s)")
    if data.get("unresolved"):
        # Say this plainly: an empty list is NOT evidence that nothing is being missed.
        click.echo(f"  ! {data['unresolved']} miss(es) have no question_id and cannot be "
                   f"grouped — {data.get('note', '')}")
    click.echo("")
    for b in items:
        tc = b.get("tenant_count", 0)
        click.echo(f"  {b['question_id']:10} asked {b['count']}x across {tc} tenant(s)")
        near = b.get("near_misses") or {}
        if near:
            top = sorted(near.items(), key=lambda kv: kv[1], reverse=True)[0]
            click.echo(f"             closest entry: {top[0]} ({top[1]}x)")
        for n in (b.get("needs") or [])[:2]:
            click.echo(f"             \"{n}\"")
    click.echo("")


@catalog.command(name="record-miss")
@click.argument("need", metavar="NEED")
@click.option("--gap-category", required=True,
              type=click.Choice(_GAP_CATEGORIES),
              help="Which axis the closest entry fails on.")
@click.option("--rationale", required=True,
              help="WHY no entry fits — name the axis and the closest entry.")
@click.option("--question-id", "question_id", default=None, metavar="EM-NNN",
              help="Canonical corpus question this need resolves to, when known. Free text "
                   "cannot be grouped — this is what lets the same question asked five ways "
                   "count once in the curation queue.")
@click.option("--near-miss", "near_miss", default=None, metavar="ENTRY_ID",
              help="The entry that came closest. This is the curation anchor.")
@_ORIGIN_OPTION
@click.pass_context
def catalog_record_miss(ctx, need, gap_category, rationale, question_id, near_miss, origin):
    """Record that the catalog could not serve a need, and get the decision id.

    Authoring new SQL requires this id — the deposit gate rejects a transformer
    artifact that carries its own SQL without one. That is deliberate: the reviewed
    definitions existed for weeks and were used zero times, which is what advice
    without enforcement produces.

    \b
    The rationale is read by whoever decides the NEXT catalog entry, so it must name
    an axis rather than report failure:
      weak   : "no entry matched"
      strong : "em_012 is finding-grain; this needs one row per (team, month),
                so the counts would double"

    \b
    Example:
      TORANA_PROFILE=SA torana vm transformers catalog record-miss \
        "one row per team per month with SLA breach counts" \
        --gap-category wrong_grain --near-miss vm.tf.em_012 \
        --rationale "em_012 is action-grain; I need a (team, month) rollup."
    """
    client = _client(ctx)
    # Recorded through the search endpoint, which owns the decision-row write. The
    # threshold is pinned to the maximum the API accepts so effectively nothing can
    # clear it — a score of exactly 1.0 needs vectors that are identical, which a
    # free-text need against a stored description does not produce.
    #
    # Suppressing the match is the point. The caller has ALREADY adjudicated against
    # the full catalog listing; re-ranking here would either second-guess that
    # judgement or silently record a "reuse" they never chose.
    payload = {
        "query": need,
        "top_k": 1,
        "similarity_threshold": 1.0,
        "record_miss": True,
        "gap_category": gap_category,
        "rationale": rationale,
        "origin": _resolve_origin(origin),
    }
    # Sent explicitly so the recorded near-miss is the one the AUTHOR judged closest.
    # Absent this the server derives one by re-ranking — an entry the author may never
    # have considered, recorded in the curation queue as if it were their judgement.
    if near_miss:
        payload["near_miss_entry_id"] = near_miss
    if question_id:
        payload["question_id"] = question_id
    try:
        data = client.post(f"{_BASE}/catalog/search", json=payload)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if _raw(ctx) or fmt != "text":
        output(data, fmt=fmt, raw=_raw(ctx), fields=_fields(ctx))
        return

    decision_id = data.get("decision_id")
    if not decision_id:
        click.echo("⚠ The miss was NOT recorded — the decision row could not be written.")
        click.echo("  Recording is best-effort by design (it must never fail the authoring")
        click.echo("  path it observes), but without an id the transformer write will 400.")
        return
    click.echo(f"Recorded: {decision_id}")
    click.echo(f"  gap     : {gap_category}")
    if near_miss:
        click.echo(f"  closest : {near_miss}")
    click.echo("")
    click.echo("  → set definition.catalog_decision_id to this id on the transformer artifact.")


@catalog.command(name="show")
@click.argument("entry_id", metavar="ENTRY_ID")
@click.pass_context
def catalog_show(ctx, entry_id):
    """Show one catalog entry, including its SQL template and declared surface."""
    client = _client(ctx)
    try:
        data = client.get(f"{_BASE}/catalog/{entry_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if fmt != "text":
        output(data, fmt=fmt, fields=_fields(ctx))
        return

    # Show the SAME version `catalog list` shows, so the two surfaces cannot disagree.
    # `version_in_catalog` is the seeded catalog row's version; `version` is the code-side
    # definition version. They are different numbers for the same entry, and printing only
    # one here while the list printed the other made `list` say v2 and `show` say v1 for
    # vm.tf.p0_actions. Prefer the catalog version (matching list's precedence) and name
    # the definition version explicitly when it differs, rather than hiding one of them.
    _ver = data.get("version_in_catalog") or data.get("version")
    _defv = data.get("version")
    _suffix = (f"  [definition v{_defv}]"
               if data.get("version_in_catalog") and _defv != data.get("version_in_catalog")
               else "")
    click.echo(f"Entry           : {data.get('id')}  (v{_ver}){_suffix}")
    click.echo(f"Description     : {data.get('description')}")
    click.echo(f"Destination     : {data.get('destination_table')}")
    click.echo(f"Source tables   : {', '.join(data.get('source_tables') or []) or '-'}")
    click.echo(f"Vocabulary keys : {', '.join(data.get('vocabulary_keys') or []) or '-'}")
    click.echo(f"Scope dimensions: {', '.join(data.get('scope_dimensions') or []) or '-'}")
    click.echo(f"Modules         : {', '.join(data.get('modules') or []) or '-'}")

    shape = data.get("output_shape") or {}
    click.echo(f"Output columns  : {', '.join(shape.get('columns') or []) or '-'}")
    click.echo(f"Unique key      : {', '.join(shape.get('unique_key') or []) or '-'}")

    click.echo("\nSemantic description:")
    click.echo(f"  {data.get('semantic_description') or '-'}")

    if data.get("sql_template"):
        click.echo("\nSQL template (holes are filled by the policy binder):")
        for line in data["sql_template"].rstrip().split("\n"):
            click.echo(f"  {line}")


# ---------------------------------------------------------------------------
# materialized (this tenant's materializations — refcount + status)
# ---------------------------------------------------------------------------

@transformers.command(name="materialized")
@click.option("--status", "status_filter", default=None,
              type=click.Choice(["materializing", "ready", "failed", "stale", "tearing_down"]),
              help="Filter by materialization status.")
@click.option("--verify", is_flag=True, default=False,
              help="Probe each relation and report whether it ACTUALLY still exists.")
@click.option("--limit", default=50, show_default=True,
              help="Page size (max 100).")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.pass_context
def materialized(ctx, status_filter, verify, limit, page):
    """List this tenant's materialized VM convenience tables.

    \b
    Shows the reference count (how many installed use-cases share the table) and
    the materialization status, so standing data-layer cost is visible.

    \b
    ⚠️ `status` is a claim written ONCE at materialize time and never re-checked. A
    relation dropped out-of-band still reads `ready`. Measured: an entry read
    `ready` with a physical_table while the relation was gone — it had been
    cascade-dropped when a sibling rebuilt the base view it depends on, and the only
    symptom was an HTTP 400 from a different service minutes later. Use --verify
    when a query says a vm_tf_* relation does not exist but this list says ready.

    \b
    Examples:
      torana vm transformers materialized
      torana vm transformers materialized --verify
      torana vm transformers materialized --status ready --verify
    """
    params = {"page": page, "page_size": min(limit, 100)}
    if status_filter:
        params["status"] = status_filter
    if verify:
        params["verify"] = "true"

    client = _client(ctx)
    try:
        data = client.get(f"{_BASE}/materialized", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if fmt == "text":
        # Surface the two conditions an operator must not miss: a failed
        # materialization (fail-closed, never a silently-empty table) and an
        # entry whose catalog definition has moved past what was materialized.
        for item in data.get("items", []):
            if item.get("last_error"):
                click.echo(
                    f"! {item['catalog_entry_id']}: FAILED — {item['last_error'][:160]}"
                )
            if item.get("version_drift"):
                click.echo(
                    f"~ {item['catalog_entry_id']}: catalog entry version has moved on "
                    f"(materialized v{item.get('catalog_entry_version')}) — will refresh"
                )
            # The registry LYING is the loudest thing this command can report: `ready`
            # against a relation that no longer exists. Only reachable with --verify;
            # None means "not probed" and must never render as a problem.
            if item.get("relation_exists") is False:
                click.echo(
                    f"⛔ {item['catalog_entry_id']}: registry says "
                    f"'{item.get('status')}' but relation "
                    f"'{item.get('physical_table')}' DOES NOT EXIST — anything reading "
                    f"it will fail. Re-materialize by redeploying a program that "
                    f"references this entry."
                )

    output(
        data,
        fmt=fmt,
        raw=_raw(ctx),
        fields=_fields(ctx),
        columns=_MATERIALIZED_COLS,
    )


# ---------------------------------------------------------------------------
# definitions (the platform BOOTSTRAP transformer set — Stream U)
#
# ⚠️ NOT the same thing as `catalog` above. `catalog` is the vm.tf.* question→SQL
# corpus (reviewed CODE, reusable shapes an author picks FROM). `definitions` is
# the set of CONCRETE relations the platform maintains and app bundles REFERENCE
# by id instead of carrying SQL for. Different artifact, different lifecycle.
# ---------------------------------------------------------------------------

_DEFINITION_COLS = [
    ("name", "NAME", 32),
    ("version", "VER", 4),
    ("state", "STATE", 8),
    # ⛔ Beside STATE, not at the end. `retired` on its own does not tell a reader
    # whether the relation was replaced or simply dropped, and those have opposite
    # fixes — follow the pointer, or re-author. A column that answers that must sit
    # where the state is read, and a table output truncated at the terminal edge
    # must not be where it gets cut.
    ("superseded_by", "SUPERSEDED BY", 28),
    ("dbt_strategy", "STRATEGY", 12),
    ("description", "DESCRIPTION", 44),
]


@transformers.group(name="definitions", invoke_without_command=True)
@click.pass_context
def definitions(ctx):
    """Platform transformer definitions — what app bundles reference."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@definitions.command(name="list")
@click.option("--state", default="active", show_default=True,
              type=click.Choice(["active", "retired", "all"]),
              help="Lifecycle state. A definition is never deleted — one that "
                   "leaves the code set is RETIRED, because a materialized table "
                   "built from it may still exist.")
@click.pass_context
def definitions_list(ctx, state):
    """List the platform transformer definitions.

    These are the relations a bundle points at with `transformer_ref(...)`
    instead of carrying their SQL. One definition, one authority — which is the
    point: the same foundation authored by three bundles three ways is how a
    defect fixed in one stayed live in the other two.
    """
    client = _client(ctx)
    try:
        data = client.get("transformer-definitions/", params={"state": state})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    items = data if isinstance(data, list) else data.get("items", [])
    fmt = _fmt(ctx)
    if _raw(ctx) or fmt != "text":
        output(items, fmt=fmt, raw=_raw(ctx), fields=_fields(ctx),
               columns=_DEFINITION_COLS)
        return

    for e in items:
        uk = e.get("unique_key")
        uk = ", ".join(uk) if uk else "— (none: aggregate / no row identity)"
        click.echo(f"{e['name']}  v{e.get('version')}  [{e.get('state')}]")
        # ⛔ Print this FIRST on a retired row. A retired definition is not a defect
        # — bootstrap definitions are immutable, so a change authors a new relation
        # and retires the old one, and `--state retired|all` is exactly where a
        # reader lands holding a dead reference. The successor is what they came for.
        if e.get("superseded_by"):
            click.echo(f"    ➜ SUPERSEDED BY: {e['superseded_by']}  (use this instead)")
        elif e.get("state") == "retired":
            # Say it rather than printing nothing: an absent line reads as "not
            # looked up", and sends the reader hunting for a successor that is not
            # there. Retired-with-no-successor is a real, final state.
            click.echo("    ➜ retired, no successor recorded")
        click.echo(f"    answers  : {e.get('description') or '—'}")
        # ⛔ `one row` (the grain) is what a reuse decision turns on — a listing that omits
        # it forces the reader to judge on the description, which cannot distinguish "one
        # row per finding" from "one row per (team, month)". Those answer different
        # questions and differ by a multiple, silently.
        click.echo(f"    one row  : {e.get('grain') or '(grain not declared)'}")
        click.echo(f"    strategy : {e.get('dbt_strategy')}  "
                   f"(materialized={e.get('materialized')})")
        click.echo(f"    merge key: {uk}")
        bundles = e.get("declaring_bundles")
        if bundles:
            click.echo(f"    used by  : {', '.join(bundles)}")
        click.echo("")
    inc = sum(1 for e in items if e.get("dbt_strategy") == "incremental")
    click.echo(f"  {len(items)} definitions ({inc} incremental, "
               f"{len(items) - inc} full-table).")
    click.echo("  `definitions show <name>` for the SQL and full semantics.")


#: ⛔ Health states carry a TEXT GLYPH, never colour alone. Two reasons, both hard:
#: the maintainer of this platform has red/green colour blindness, and CLI output is
#: routinely piped, redirected and pasted where ANSI is stripped entirely. A state
#: distinguishable only by colour is unreadable in both cases.
_HEALTH_GLYPH = {
    "healthy": "[ok]",
    "stale": "[~ ]",
    "broken": "[XX]",
    "quarantined": "[!!]",
    "unbuilt": "[--]",
}

#: dbt writes a banner (`Running with dbt=…`, `Registered adapter: …`) before the
#: real failure and colours its output, so `last_error` begins with ANSI escapes and
#: several uninformative lines. Printing `splitlines()[0]` shows every failure as
#: "Running with dbt=1.11.11" — identical for 18 different problems, which is worse
#: than no error line at all.
_DBT_NOISE = ("running with dbt", "registered adapter", "found ", "concurrency:",
              "encountered an error")


def _first_real_error(raw: str) -> str:
    """The first line of `last_error` that actually says what went wrong.

    ⚠️ A bare error CLASS ("Compilation Error", "Database Error") is a header, not
    a diagnosis — it reads identically for 18 different failures. When one is hit,
    keep reading and return the following detail line instead.
    """
    clean = re.sub(r"\x1b\[[0-9;]*m", "", raw or "")
    lines = []
    for line in clean.splitlines():
        s = re.sub(r"^\d{2}:\d{2}:\d{2}\s*", "", line.strip())
        if not s or s.startswith("-"):
            continue
        if any(s.lower().startswith(n) for n in _DBT_NOISE):
            continue
        lines.append(s)
    for i, s in enumerate(lines):
        if s.rstrip().lower().endswith("error") and i + 1 < len(lines):
            return f"{s} — {lines[i + 1]}"[:160]
        return s[:160]
    return "(no detail)"


_HEALTH_COLS = [
    ("health", "HEALTH", 12),
    ("name", "NAME", 38),
    ("last_status", "STATUS", 12),
    ("last_run_at", "LAST RUN", 22),
    ("domain", "DOMAIN", 14),
    ("owner", "OWNER", 10),
]


@definitions.command(name="coverage")
@click.option("--state", "state_filter", default="all", show_default=True,
              type=click.Choice(["all", "ok", "degraded", "empty", "unknown"]),
              help="Filter to one state. Default `all` — filtering by default "
                   "would hide the thing the operator came to see.")
@click.pass_context
def definitions_coverage(ctx, state_filter):
    """Bootstrap coverage for EVERY tenant — who is missing their transformers?

    ⭐ CROSS-TENANT, unlike `definitions health`, which only ever sees YOUR
    tenant. Super-admin only. This is the board that answers "did tenant X ever
    get its bootstrap set?" — a question that had no surface at all until a
    recreated tenant silently received ZERO transformers and only surfaced when
    an app-bundle install refused it.

    \b
    ⛔ `present` IS NOT `built`. `built` trusts the row's last_status; `present`
       asks the datalake whether the relation actually EXISTS. They disagree
       when a relation is dropped out from under its row, and the row keeps
       claiming success forever — the automatic repair and sweep both judge by
       status and will never rebuild it.
    ⚠️ `phantom` is exactly that disagreement: rows claiming success over
       nothing. A non-zero phantom count means self-healing cannot see the gap.

    \b
    States:
      [ok]  ok         rows present, all built, nothing phantom
      [~ ]  degraded   some failed or phantom — look at those two columns
      [XX]  empty      ZERO rows. The tenant never got its bootstrap set.
      [? ]  unknown    the datalake could not be reached, so present/phantom
                       are not meaningful for that tenant
    """
    client = _client(ctx)
    try:
        data = client.get("transformer-definitions/coverage")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if _raw(ctx) or fmt != "text":
        output(data, fmt=fmt, raw=_raw(ctx), fields=_fields(ctx))
        return

    items = data.get("items") or []
    if state_filter != "all":
        items = [i for i in items if i.get("state") == state_filter]

    # ⚠️ GLYPHS, not colour alone — the state must be readable without relying on
    # red/green discrimination.
    marks = {"ok": "[ok]", "degraded": "[~ ]", "empty": "[XX]", "unknown": "[? ]"}

    click.echo("")
    click.echo(f"  {data.get('tenants', 0)} tenant(s)   "
               f"in-scope definitions: {data.get('in_scope', 0)}")
    if not data.get("datalake_checked", True):
        click.echo("  ⚠ the datalake was unreachable for at least one tenant — "
                   "`present`/`phantom` are not meaningful there")
    click.echo("")
    click.echo(f"  {'':4} {'TENANT':22} {'STATE':9} {'ROWS':>5} {'PRESENT':>8} "
               f"{'BUILT':>6} {'FAILED':>7} {'PHANTOM':>8}")
    for i in items:
        label = i.get("tenant_name") or (i.get("tenant_id") or "")[:8]
        click.echo(f"  {marks.get(i.get('state'), '[? ]')} {label:22.22} "
                   f"{i.get('state',''):9} {i.get('rows',0):>5} "
                   f"{i.get('present',0):>8} {i.get('built',0):>6} "
                   f"{i.get('failed',0):>7} {i.get('phantom',0):>8}")

    empty = data.get("empty_tenants", 0)
    phantom_total = sum(i.get("phantom", 0) for i in (data.get("items") or []))
    click.echo("")
    if empty:
        click.echo(f"  ⛔ {empty} tenant(s) have ZERO bootstrap transformers. "
                   f"They cannot install an app bundle. Run "
                   f"`torana vm transformers definitions repair --apply` as that "
                   f"tenant, or restart data-transformers to let boot repair heal them.")
    if phantom_total:
        click.echo(f"  ⚠ {phantom_total} row(s) claim success but their relation "
                   f"does NOT exist. Repair and the sweep judge by status and will "
                   f"not rebuild these — a forced re-materialize is required.")
    if not empty and not phantom_total:
        click.echo("  Every tenant has its bootstrap set, and every row that "
                   "claims success has a relation behind it.")


@definitions.command(name="health")
@click.option("--health", "health_filter", default="all", show_default=True,
              type=click.Choice(["all", "healthy", "stale", "broken",
                                 "quarantined", "unbuilt"]),
              help="Filter to one state. Default `all` — filtering by default "
                   "would hide the thing the operator came to see.")
@click.option("--owner", "owner_filter", default="bootstrap", show_default=True,
              type=click.Choice(["bootstrap", "catalog", "all"]),
              help="Which definition set to report. Default `bootstrap` — the set "
                   "this tenant is SUPPOSED to have. `catalog` entries are a "
                   "reference menu and are unbuilt by design.")
@click.pass_context
def definitions_health(ctx, health_filter, owner_filter):
    """Per-tenant health for every active definition.

    ⚠️ TENANT-SCOPED, unlike its sibling `definitions list`, which is
    tenant-neutral by design. The tenant comes from your credentials and cannot be
    passed as an argument.

    ⛔ It answers "is this DEFINITION healthy in MY tenant?" — never "is my tenant
    healthy?". A failing relation whose definition is not active cannot appear in
    the listing at all; those are reported separately as ORPHANED FAILURES, and a
    non-zero count there means the board below is incomplete.

    The five states:

    \b
      [ok] healthy      built, succeeded, and fresh
      [~ ] stale        succeeded, but older than the staleness threshold
      [XX] broken       last build failed — do NOT read from it
      [!!] quarantined  parked out of the dbt graph. ⚠️ STILL RETURNS ROWS, and
                        they are stale — the most dangerous state, because a
                        query against it answers plausibly instead of failing
      [--] unbuilt      this tenant never materialized it (not a failure)

    ⭐ TWO OWNERS, AND ONLY ONE OF THEM IS SUPPOSED TO BE BUILT.

    \b
      bootstrap  the set every tenant gets, instantiated by repair. `unbuilt`
                 here means something did not happen — a real gap.
      catalog    the `vm_tf_*` REFERENCE MENU. Built on demand, refcounted,
                 by the catalog's own lifecycle. `unbuilt` is its resting
                 state, and reporting it as a gap is simply wrong.

    ⚠️ This defaults to `--owner bootstrap` for that reason. Measured on T1
    2026-09-22, the undivided board read "79 active definitions — 38 healthy,
    41 unbuilt", which looks like a fleet-wide failure; the honest reading is
    38 of 39 bootstrap healthy plus 40 catalog entries behaving as designed.
    """
    client = _client(ctx)
    try:
        data = client.get("transformer-definitions/health",
                          params={"health": health_filter})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    all_items = data.get("items", [])

    # ⛔ SPLIT CLIENT-SIDE, and label every row. The API returns the whole board
    # because `counts` must stay unfiltered (see below) — so the owner split has to
    # happen here, on `is_catalog`, which the server derives from declaring_bundles.
    def _owner(e):
        return "catalog" if e.get("is_catalog") else "bootstrap"

    for e in all_items:
        e["owner"] = _owner(e)
    items = ([e for e in all_items if _owner(e) == owner_filter]
             if owner_filter != "all" else all_items)

    fmt = _fmt(ctx)
    if _raw(ctx) or fmt != "text":
        output(items, fmt=fmt, raw=_raw(ctx), fields=_fields(ctx),
               columns=_HEALTH_COLS)
        return

    for e in items:
        glyph = _HEALTH_GLYPH.get(e.get("health"), "[??]")
        tag = "  (catalog)" if e.get("is_catalog") else ""
        click.echo(f"{glyph} {e.get('health'):12} {e['name']}{tag}")
        if e.get("last_run_at"):
            click.echo(f"        last run : {e['last_run_at']}")
        if e.get("last_error"):
            click.echo(f"        error    : {_first_real_error(e['last_error'])}")
    if items:
        click.echo("")

    # ⛔ The counts are over the WHOLE board for the SELECTED OWNER, never the
    # `--health` filter. A summary that moved with `--health` would make every
    # filtered read look like a different tenant — the same "clean board over a
    # dirty tenant" this command exists to end. The owner split is different in
    # kind: it does not hide a state, it names which system is accountable for it.
    scope = [e for e in all_items if owner_filter in ("all", _owner(e))]
    counts = {}
    for e in scope:
        counts[e["health"]] = counts.get(e["health"], 0) + 1
    label = "active definitions" if owner_filter == "all" else f"{owner_filter} definitions"
    click.echo(f"  {len(scope)} {label} — "
               + ", ".join(f"{_HEALTH_GLYPH.get(k, '')} {v} {k}"
                           for k, v in sorted(counts.items()) if v))
    if health_filter != "all":
        click.echo(f"  (showing {len(items)} × {health_filter}; "
                   f"counts above are the whole board)")

    # ⭐ ALWAYS NAME THE OTHER HALF. Silently dropping 40 definitions would trade
    # one wrong number for a different wrong number — the operator must be able to
    # tell "not reported" from "not there".
    n_cat = sum(1 for e in all_items if e.get("is_catalog"))
    if owner_filter == "bootstrap" and n_cat:
        built = sum(1 for e in all_items
                    if e.get("is_catalog") and e.get("health") != "unbuilt")
        click.echo(f"  + {n_cat} catalog definitions not shown ({built} built on "
                   f"demand) — a menu, unbuilt by design. `--owner catalog`")
    click.echo(f"  stale after {data.get('staleness_hours')}h.")

    orphans = data.get("orphaned_failures") or 0
    if orphans:
        # ⛔ NOT a footnote. These are failing relations THIS TENANT HAS that can
        # never appear above, because no active definition backs them. Reporting the
        # board without them would be a clean board over a dirty tenant.
        click.echo("")
        click.echo(f"  ⚠️  {orphans} ORPHANED FAILURE(S) — failing here, but no "
                   f"active definition backs them,")
        click.echo("      so they cannot appear in the listing above:")
        for n in data.get("orphaned_failure_names", []):
            click.echo(f"        [XX] {n}")
        # ⛔ Deliberately NOT "these need retiring". An orphan is a relation with no
        # ACTIVE DEFINITION — that is not the same as UNUSED, and the two were
        # conflated once already. Measured on T2: `remediation_base` is an orphan
        # with FIVE dependents and `threat_intel_ranked` with four; deleting either
        # breaks nine working relations. Check dependents before retiring anything.
        click.echo("      ⚠️  Orphaned ≠ unused. Check what reads each one "
                   "(`definitions show <name>`, source_tables)")
        click.echo("          BEFORE retiring it — an orphan can still be a base "
                   "relation others depend on.")


@definitions.command(name="repair")
@click.option("--apply", "apply_", is_flag=True, default=False,
              help="Actually repair. Without it this is a DRY RUN that only reports drift.")
@click.option("--no-materialize", is_flag=True, default=False,
              help="Repair the rows and model files but do not rebuild the tables.")
@click.option("--workspace-id", default="bootstrap", show_default=True,
              help="Workspace to attach newly created rows to.")
@click.pass_context
def definitions_repair(ctx, apply_, no_materialize, workspace_id):
    """Restore this tenant's bootstrap relations to what the definitions declare.

    Closes four drifts, each of which is SILENT — the relation keeps serving
    whatever it last held, so the only symptom is answers that quietly stop moving:

    \b
      MISSING   an active definition has no transformer row here (deleted).
                ⚠️ A tenant whose rows were ALL deleted drops out of the hourly
                sweep entirely, so this is the only way back.
      UNFILED   the row exists but its dbt model file does not (quarantined).
                Releasing it needs a re-write, which only create/update perform —
                the sweep can never recover it on its own.
      STALE     built long ago, or never. Handled by the normal builder.
      OUTDATED  the row runs SQL from an OLDER definition generation — the
                platform definition was edited and this tenant never picked it
                up. It builds cleanly and reports success, so nothing else shows
                it. Rewritten from the active definition, then rebuilt from
                scratch (--full-refresh).
                Rows built before generation tracking carry no stamp; those are
                compared by SQL, and if already current are only stamped.

    Idempotent: running it twice changes nothing the second time.

    \b
    Examples:
      torana vm transformers definitions repair              # dry run — what is wrong?
      torana vm transformers definitions repair --apply      # fix it, and rebuild
      torana vm transformers definitions repair --apply --no-materialize
    """
    client = _client(ctx)
    payload = {
        "dry_run": not apply_,
        "materialize": not no_materialize,
        "workspace_id": workspace_id,
    }
    try:
        data = client.post("transformer-definitions/repair", json=payload)
    except APIError as e:
        # ⛔ A 504 HERE DOES NOT MEAN THE REPAIR FAILED — IT MEANS THE GATEWAY GAVE
        # UP WAITING. `--apply` runs the dbt build inline, which on a tenant with
        # tens of relations takes minutes and outlives nginx's proxy timeout. The
        # work continues server-side and normally completes.
        #
        # ⚠️ The bare "API error (HTTP 504)" is actively harmful advice by omission:
        # it reads as a failure, so the natural response is to re-run — which
        # contends for the same materialization lock and can make a healthy repair
        # look permanently broken. Measured 2026-09-22 on tenant 08552d33: the CLI
        # reported 504 at 17:38:13 while the server went on building 38 relations.
        if getattr(e, "status_code", None) == 504:
            click.echo("")
            click.echo("  ⚠ The gateway timed out — but the repair is probably STILL "
                       "RUNNING on the server.")
            click.echo("    `--apply` builds inline, which outlasts the HTTP timeout "
                       "on a large tenant.")
            click.echo("    Do NOT immediately re-run (it contends for the build "
                       "lock). Watch it finish with:")
            click.echo("      torana vm transformers definitions health")
            ctx.exit(1)
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if _raw(ctx) or fmt != "text":
        output(data, fmt=fmt, raw=_raw(ctx), fields=_fields(ctx))
        return

    dry = data.get("dry_run", True)
    click.echo(f"  tenant {data.get('tenant_id','?')}  "
               f"{'DRY RUN — nothing changed' if dry else 'REPAIR APPLIED'}")
    click.echo("")

    def _section(title, found, done, verb):
        if not found:
            click.echo(f"  {title}: none")
            return
        # ⛔ FOUND and DONE are printed separately on purpose. A single "fixed N"
        # would hide the interesting case — an item that was found and could NOT
        # be repaired, which is the one a reader must act on.
        if dry:
            click.echo(f"  {title}: {len(found)}")
        else:
            click.echo(f"  {title}: {len(done)} {verb} of {len(found)} found")
        for n in found:
            mark = "  " if dry else ("✓ " if n in done else "✗ ")
            click.echo(f"      {mark}{n}")

    _section("MISSING  (no transformer row)", data.get("missing_found") or [],
             data.get("missing_created") or [], "created")
    _section("UNFILED  (no dbt model file)", data.get("unfiled_found") or [],
             data.get("unfiled_restored") or [], "restored")
    # OUTDATED (rev 021). ⚠️ `.get(...) or []` — an older server omits these keys, and
    # "none" is the right reading of that: it cannot detect this drift at all.
    _section("OUTDATED (older definition generation)", data.get("outdated_found") or [],
             data.get("outdated_rewritten") or [], "rewritten")

    # ⭐ NOT A REPAIR, and printed so it can't be mistaken for one. These rows predate
    # generation tracking; their SQL was compared with the active definition and already
    # matched, so they were only stamped. Folding them into a repaired count would
    # overstate what changed — and silence would leave a reader wondering why every
    # row's drift state flipped from "unknown" to "current" at once.
    backfilled = data.get("generation_backfilled") or []
    if backfilled:
        verb = "would record" if dry else "recorded"
        click.echo(f"  {len(backfilled)} relation(s) {verb} their definition generation "
                   f"— already current, nothing rebuilt.")

    # ⭐ SKIPPED IS PRINTED SEPARATELY FROM FAILED, and before it. These are
    # EXPECTED non-creations: 19 of the 37 in-scope definitions carry
    # `{{vocab:…}}` and are bound per tenant at BUNDLE INSTALL, and 5 more read
    # one of those. Repair can never create them, and that is the design.
    #
    # ⚠️ Until 2026-09-21 they were counted as FAILURES, so a correct repair on a
    # healthy tenant reported "23 failed" and read as an outage. Two counters,
    # never one — a single number cannot tell "working as designed" from "broken".
    # ⛔ TWO SKIP REASONS, AND THEY CALL FOR OPPOSITE RESPONSES. The header asserted
    # "bound at bundle install" for every skip, which is PERMANENT for repair — those
    # definitions carry {{vocab:…}} and only a bundle install ever creates them, so no
    # number of re-runs changes anything. An upstream that is merely UNBUILT is
    # TRANSIENT: build it and the next repair creates the dependent.
    #
    # ⚠️ Measured 2026-09-22 on tenant 08552d33: `prioritize_fixes` was skipped on
    # `prioritize_fix_locations (created this pass, not built yet)` and reported under
    # the "bound at bundle install" header — telling the operator to go look for an
    # install that was never the problem, when the answer was to re-run this very
    # command. The service already splits these two in its own summary line; the CLI
    # was the surface still conflating them.
    # ⛔ A "verify" skip (rev 021) is a DIFFERENT thing from the two create-skips below:
    # the row exists, but its definition generation could not be checked — usually a
    # vocabulary key that does not resolve for this tenant. Under the create-skip
    # header it would read "bound at bundle install — repair never creates these",
    # which is wrong on both counts: nothing was being created, and the fix is to
    # make the key resolve, not to install a bundle.
    all_skipped = data.get("skipped") or []
    verify_skipped = [s for s in all_skipped if s.get("phase") == "verify"]
    if verify_skipped:
        click.echo("")
        click.echo(f"  — {len(verify_skipped)} definition generation(s) could not be "
                   f"checked (left as 'unknown', not changed):")
        for s in verify_skipped:
            click.echo(f"      {s.get('name')}: {s.get('reason')}")
        click.echo("      ↳ usually a policy vocabulary key this tenant cannot resolve. "
                   "Nothing was rewritten on a guess.")

    skipped = [s for s in all_skipped if s.get("phase") != "verify"]
    if skipped:
        def _transient(s):
            return any(m in (s.get("reason") or "")
                       for m in ("not built yet", "table does not"))
        _defer = [s for s in skipped if _transient(s)]
        _bound = [s for s in skipped if not _transient(s)]
        click.echo("")
        click.echo(f"  — {len(skipped)} skipped (not a failure):")
        for s in _bound:
            click.echo(f"      {s.get('name')}: {s.get('reason')}")
        if _bound:
            click.echo("      ↳ bound at bundle install — repair never creates these.")
        for s in _defer:
            click.echo(f"      {s.get('name')}: {s.get('reason')}")
        if _defer:
            # ⭐ SAY WHAT TO DO — AND THE UPSTREAM MUST BE *BUILT*, NOT MERELY
            # CREATED. A chain needs one pass per level, so this is slow rather than
            # stuck; but a re-run only helps once the upstream has a TABLE.
            #
            # ⚠️ Measured 2026-09-22 on 08552d33: the first apply created
            # `prioritize_fix_locations` and deferred `prioritize_fixes`; the
            # immediate re-run deferred it again, because the build had been skipped
            # (the startup repair held the materialization lock) so the upstream was
            # still a row with no table. Telling the operator to re-run, with no
            # mention of the build, sends them into a loop that cannot progress.
            click.echo("      ↳ waiting on an upstream that has no table yet. "
                       "Re-run once it is BUILT —")
            click.echo("        check with `torana vm transformers definitions "
                       "health`; if the build was skipped above, the hourly sweep "
                       "or the next restart builds it.")

    failed = data.get("failed") or []
    if failed:
        click.echo("")
        click.echo(f"  ⚠ {len(failed)} could not be repaired:")
        for f in failed:
            click.echo(f"      {f.get('name')} [{f.get('phase')}] {str(f.get('error'))[:120]}")

    built = data.get("materialized") or []
    mfail = data.get("materialize_failed") or []
    if built or mfail:
        click.echo("")
        click.echo(f"  rebuilt: {len(built)}   failed: {len(mfail)}")
    if data.get("skipped_locked"):
        click.echo("  ⚠ build skipped — another worker holds the materialization lock. "
                   "Re-run, or wait for the hourly sweep.")

    click.echo("")
    if dry:
        # ⛔ SUBTRACT THE SKIPS. A dry run that counts vocab-bound relations as
        # "need repair" promises something `--apply` will not deliver: those are
        # bound at bundle install and repair deliberately refuses them. Measured
        # 2026-09-21 on T1 — the preview said "4 relation(s) need repair" when
        # all 4 were skips and `--apply` would correctly change nothing.
        # Create-phase skips only — a "verify" skip is reported above and is not a
        # missing relation, so it must not feed the "bound at bundle install" line.
        skipped_names = {s.get("name") for s in skipped}
        # ⛔ OUTDATED COUNTS AS ACTIONABLE (rev 021). Leaving it out would print
        # "Nothing to repair — this tenant matches the definitions" for a tenant whose
        # only drift is outdated SQL: a false green, on the one drift class that has no
        # other symptom anywhere.
        actionable = [
            n for n in ((data.get("missing_found") or [])
                        + (data.get("unfiled_found") or [])
                        + (data.get("outdated_found") or []))
            if n not in skipped_names
        ]
        if actionable:
            click.echo(f"  {len(actionable)} relation(s) need repair. "
                       f"Re-run with --apply to fix them.")
            if skipped_names:
                click.echo(f"  ({len(skipped_names)} more are bound at bundle "
                           f"install and cannot be repaired here.)")
        elif skipped_names:
            click.echo(f"  Nothing repairable here — all {len(skipped_names)} "
                       f"missing relation(s) are bound at bundle install. "
                       f"Install the owning app bundle.")
        else:
            click.echo("  Nothing to repair — this tenant matches the definitions.")


@definitions.command(name="show")
@click.argument("name")
@click.pass_context
def definitions_show(ctx, name):
    """Show one definition — its SQL, materialization config and semantics."""
    client = _client(ctx)
    try:
        e = client.get(f"transformer-definitions/{name}")
    except APIError as ex:
        handle_api_error(ex)
        return
    except AuthError as ex:
        handle_auth_error(ex)
        return

    if not e:
        # ⭐ `/{name}` serves ACTIVE rows only, so a retired definition lands here —
        # and that is the single most likely reason someone types this command: they
        # are holding a reference that stopped resolving. Telling them "no active
        # definition" and stopping makes them run a second, differently-shaped
        # command to learn the one thing they needed. Look it up for them.
        retired = None
        try:
            allrows = client.get("transformer-definitions/", params={"state": "retired"})
            rows = allrows if isinstance(allrows, list) else allrows.get("items", [])
            # Newest version wins: a definition retired more than once carries its
            # current forwarding address on the latest row.
            matches = sorted((r for r in rows if r.get("name") == name),
                             key=lambda r: r.get("version") or 0, reverse=True)
            retired = matches[0] if matches else None
        except (APIError, AuthError):
            # ⛔ Best-effort by design. This is a convenience lookup on an error
            # path; failing it must not replace the real answer ("no active
            # definition") with a second, less useful error.
            retired = None

        if retired:
            click.echo(f"'{name}' is RETIRED (v{retired.get('version')}).")
            if retired.get("superseded_by"):
                click.echo(f"  ➜ superseded by: {retired['superseded_by']}")
                click.echo(f"  `definitions show {retired['superseded_by']}` "
                           f"for its SQL and semantics.")
            else:
                click.echo("  ➜ no successor recorded — it left the code set without "
                           "a replacement.")
            return

        click.echo(f"No active definition named '{name}'.")
        click.echo("  `definitions list --state all` includes retired ones.")
        return

    fmt = _fmt(ctx)
    if _raw(ctx) or fmt != "text":
        output(e, fmt=fmt, raw=_raw(ctx), fields=_fields(ctx))
        return

    uk = e.get("unique_key")
    click.echo(f"{e['name']}  v{e.get('version')}  [{e.get('state')}]")
    if e.get("superseded_by"):
        click.echo(f"  ➜ SUPERSEDED BY: {e['superseded_by']}  (use this instead)")
    click.echo(f"  id        : {e.get('definition_id')}")
    click.echo(f"  answers   : {e.get('description') or '—'}")
    # The STRUCTURED grain column, not the prose inside `semantics`. Both may state a
    # grain; this one is the field the store curates and every other surface reads, so
    # it is the one to judge on.
    click.echo(f"  one row   : {e.get('grain') or '(grain not declared)'}")
    if e.get("domain"):
        click.echo(f"  domain    : {e['domain']}")
    if e.get("answers_questions"):
        click.echo(f"  questions : {', '.join(e['answers_questions'])}")
    click.echo(f"  strategy  : {e.get('dbt_strategy')} "
               f"(materialized={e.get('materialized')}"
               f"{', ' + e['materialization'] if e.get('materialization') else ''})")
    click.echo(f"  merge key : {', '.join(uk) if uk else '— (none)'}")
    click.echo(f"  reads     : {', '.join(e.get('source_tables') or []) or '—'}")
    if e.get("depends_on"):
        click.echo(f"  depends on: {', '.join(e['depends_on'])}")
    if e.get("declaring_bundles"):
        click.echo(f"  used by   : {', '.join(e['declaring_bundles'])}")
    click.echo(f"  hash      : {e.get('content_hash', '')[:16]}…")
    if e.get("semantic_description"):
        click.echo("\n  semantics:")
        for line in (e["semantic_description"] or "").splitlines():
            click.echo(f"    {line}")
    click.echo("\n  SQL:")
    for line in (e.get("custom_sql") or "").splitlines():
        click.echo(f"    {line}")


# ---------------------------------------------------------------------------
# decisions (catalog-gap curation)
# ---------------------------------------------------------------------------

@transformers.group(name="decisions", invoke_without_command=True)
@click.pass_context
def decisions(ctx):
    """Catalog-gap authoring decisions. Use `list` to query them."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@decisions.command(name="list")
@click.option("--gap-category", "gap_category", default=None,
              type=click.Choice(_GAP_CATEGORIES),
              help="Filter by typed gap category — the curation-actionable field.")
@click.option("--near-miss", "near_miss", default=None,
              help="Filter to decisions where this entry was ~90% there.")
@click.option("--state", "state", default=None, type=click.Choice(_STATES),
              help="Filter by curation state.")
@click.option("--limit", default=50, show_default=True, help="Page size (max 100).")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--include-synthetic", "include_synthetic", is_flag=True,
              help="Include rows produced by verification lanes and seed fixtures "
                   "(origin != 'live'). Default OFF: those rows INVERT the ranking, so the "
                   "curation queue is only meaningful over real demand.")
@click.pass_context
def decisions_list(ctx, gap_category, near_miss, state, limit, page, include_synthetic):
    """Query authoring-decision records.

    Each record is the account of a catalog lookup MISS: which entries were
    considered, why they did not fit, and what was authored instead. Filtering by
    --gap-category and --near-miss is what turns the table into a catalog edit
    ("entry X was a near-miss 14 times, each missing the same column → widen it").
    """
    params = {"page": page, "page_size": min(limit, 100)}
    # ⚠️ Sent only when TRUE. The server already defaults to live-only; passing
    # `include_synthetic=false` explicitly would work but makes the two trees' requests
    # differ for no reason, and they must stay byte-comparable when diagnosing a mismatch.
    if include_synthetic:
        params["include_synthetic"] = "true"
    if gap_category:
        params["gap_category"] = gap_category
    if near_miss:
        params["near_miss_entry_id"] = near_miss
    if state:
        params["state"] = state

    client = _client(ctx)
    try:
        data = client.get(f"{_BASE}/decisions", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(
        data,
        fmt=_fmt(ctx),
        raw=_raw(ctx),
        fields=_fields(ctx),
        columns=_DECISION_COLS,
    )


@decisions.command(name="show")
@click.argument("decision_id", metavar="DECISION_ID")
@click.pass_context
def decisions_show(ctx, decision_id):
    """Show one decision record, including every candidate considered."""
    client = _client(ctx)
    try:
        # The API exposes decisions as a filtered collection; fetch and select.
        # ⛔ `include_synthetic` is TRUE here on purpose, and it is NOT the same decision as
        # the list default. Listing ranks demand, so it excludes lanes; SHOW resolves one id
        # the caller already holds. Inheriting the list default would make `show <id>` fail
        # with "not found" for any lane-recorded row — an id that plainly exists.
        data = client.get(f"{_BASE}/decisions",
                          params={"page_size": 100, "include_synthetic": "true"})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    match = next(
        (d for d in data.get("items", []) if str(d.get("id")) == decision_id), None
    )
    if match is None:
        click.echo(f"Decision not found: {decision_id}", err=True)
        raise SystemExit(3)

    fmt = _fmt(ctx)
    if fmt != "text":
        output(match, fmt=fmt, fields=_fields(ctx))
        return

    click.echo(f"Decision      : {match.get('id')}")
    click.echo(f"Outcome       : {match.get('decision')}")
    click.echo(f"Gap category  : {match.get('gap_category')}")
    click.echo(f"Near miss     : {match.get('near_miss_entry_id') or '-'}")
    click.echo(f"Reused entry  : {match.get('reused_entry_id') or '-'}")
    click.echo(f"Curation state: {match.get('state')}")
    click.echo(f"Created       : {match.get('created_at') or '-'}")

    click.echo("\nCandidates considered:")
    for cand in match.get("candidates_considered") or []:
        click.echo(f"  - {cand.get('entry_id')}  [fit: {cand.get('fit')}]")
        for label, key in (
            ("missing columns", "missing_columns"),
            ("missing holes", "missing_holes"),
            ("missing vocab keys", "missing_vocab_keys"),
        ):
            vals = cand.get(key) or []
            if vals:
                click.echo(f"      {label}: {', '.join(vals)}")
    if not (match.get("candidates_considered") or []):
        click.echo("  (none recorded)")

    click.echo("\nRationale (supporting evidence, not the primary field):")
    click.echo(f"  {match.get('rationale') or '-'}")


@decisions.command(name="review")
@click.argument("decision_id", metavar="DECISION_ID")
@click.option("--state", "state", required=True, type=click.Choice(_STATES[1:]),
              help="New curation state: reviewed | actioned | dismissed.")
@click.option("--gap-category", "gap_category", default=None,
              type=click.Choice(_GAP_CATEGORIES),
              help="RE-FILE the gap under a corrected category.")
@click.option("--note", "note", default=None,
              help="Why this gap was reviewed/actioned/dismissed. Persisted on the row.")
@click.pass_context
def decisions_review(ctx, decision_id, state, gap_category, note):
    """Transition a decision's curation state, and optionally re-file it.

    This records what a human decided about a catalog gap. It never mutates the
    catalog itself — catalog entries are reviewed code, edited in the repo.

    \b
    An author assigns a category knowing their own need, but not how it relates to other
    tenants' misses; curation is where that becomes visible. A mis-filed row silently fails
    to group with the pattern it belongs to — which matters most for `platform_defect`,
    because those rows need NO new SQL and must not sit in the "author new SQL" queue.
    The API has always supported correcting it here; the CLI previously sent only `state`,
    so the correction was unreachable from the command line.

    \b
    Examples:
      torana vm transformers decisions review <id> --state actioned
      torana vm transformers decisions review <id> --state actioned \\
        --gap-category platform_defect --note "entry was correct; platform bug, now fixed"
    """
    body = {"state": state}
    if gap_category:
        body["gap_category"] = gap_category
    if note:
        body["note"] = note
    client = _client(ctx)
    try:
        data = client.patch(f"{_BASE}/decisions/{decision_id}", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if fmt == "text":
        click.echo(f"Decision {data.get('id')} → state: {data.get('state')}")
        return
    output(data, fmt=fmt, fields=_fields(ctx))


register_vm_subgroup(transformers)


# ---------------------------------------------------------------------------
# catalog versions — the retirement surface (Domain Primitives spec § 4.20.2)
#
# ⚠️ THE ONE DELIBERATE EXCEPTION to the latest-only read contract.
# `catalog list` returns the newest version of each entry and nothing else,
# precisely so an agent building a program cannot pick a superseded definition.
# This command exists for the OPPOSITE job — deciding what may be retired — and
# nothing on a build path should call it.
# ---------------------------------------------------------------------------

_VERSION_COLS = [
    ("catalog_entry_id", "ENTRY", 34),
    ("version", "VER", 5),
    ("state", "STATE", 12),
    ("refcount", "REFS", 6),
    ("consumer_count", "TENANTS", 8),
    ("materializations", "BUILT", 6),
    ("deletable", "DELETABLE", 10),
    ("grain", "ONE ROW IS", 40),
]


@catalog.group(name="decisions")
def catalog_decisions():
    """Catalog-gap decisions — the queue of what the catalog is missing.

    Every time an author could not reuse an entry, `record-miss` wrote a row here
    naming the axis that failed and the entry that came closest. Read as an
    aggregate, that is the catalog's own backlog: five misses citing the same
    near-miss entry on the same axis is a specific entry someone should author.

    It answers the other question too — IS the catalog being used? A build that
    silently authored its own SQL leaves no row, so a period with new transformers
    and no decisions means the gate was bypassed, not that reuse was perfect.
    """


@catalog_decisions.command(name="list")
@click.option("--gap-category", default=None,
              type=click.Choice(_GAP_CATEGORIES),
              help="Only misses that failed on this axis.")
@click.option("--near-miss", "near_miss_entry_id", default=None, metavar="ENTRY_ID",
              help="Only misses that cited this entry as closest.")
@click.option("--state", default=None,
              type=click.Choice(["new", "reviewed", "actioned", "dismissed"]),
              help="Curation state. `new` is the unreviewed queue.")
@click.option("--page", default=1, show_default=True, type=int)
@click.option("--page-size", default=50, show_default=True, type=int)
@click.option("--include-synthetic", "include_synthetic", is_flag=True,
              help="Include rows produced by verification lanes and seed fixtures "
                   "(origin != 'live'). Default OFF: those rows INVERT the ranking, so the "
                   "curation queue is only meaningful over real demand.")
@click.pass_context
def catalog_decisions_list(ctx, gap_category, near_miss_entry_id, state, page, page_size,
                           include_synthetic):
    """List recorded catalog gaps, newest first.

    Super-admin sees every tenant's — the aggregate is the point, since one gap hit
    across several tenants is a stronger signal than the same gap hit once.

    \b
      TORANA_PROFILE=SA torana vm transformers catalog decisions list --state new
      TORANA_PROFILE=SA torana vm transformers catalog decisions list --near-miss vm.tf.em_012
    """
    client = _client(ctx)
    params = {"page": page, "page_size": page_size}
    # ⛔ Must match `vm transformers decisions list` exactly — two trees hitting one
    # endpoint that disagree on defaults is how a curator gets two different answers to
    # the same question and trusts the wrong one.
    if include_synthetic:
        params["include_synthetic"] = "true"
    if gap_category:
        params["gap_category"] = gap_category
    if near_miss_entry_id:
        params["near_miss_entry_id"] = near_miss_entry_id
    if state:
        params["state"] = state
    try:
        data = client.get(f"{_BASE}/decisions", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if _raw(ctx) or fmt != "text":
        output(data, fmt=fmt, raw=_raw(ctx), fields=_fields(ctx))
        return

    items = data.get("items", [])
    if not items:
        click.echo("No recorded gaps match.")
        click.echo("  An empty queue means either the catalog served every need, or the")
        click.echo("  gate was bypassed. Cross-check against transformers authored since.")
        return
    # Untruncated: the rationale IS the content. Clipped to a column width it degrades
    # to "no entry matched", which is exactly the non-reason the gap-category field
    # exists to prevent.
    for d in items:
        click.echo(f"{d.get('id')}  [{d.get('state', 'new')}]  {d.get('gap_category')}")
        click.echo(f"    needed  : {d.get('need') or '—'}")
        click.echo(f"    closest : {d.get('near_miss_entry_id') or '(none cited)'}")
        click.echo(f"    because : {d.get('rationale') or '—'}")
        click.echo("")
    click.echo(f"  {len(items)} of {data.get('total', len(items))} gaps "
               f"(page {data.get('page', page)}).")


@catalog_decisions.command(name="review")
@click.argument("decision_id", metavar="DECISION_ID")
@click.option("--state", required=True,
              type=click.Choice(["new", "reviewed", "actioned", "dismissed"]),
              help="actioned = an entry now covers this gap; dismissed = it should not.")
@click.option("--note", default=None, help="Why — especially for `dismissed`. Persisted.")
@click.option("--gap-category", "gap_category", default=None,
              type=click.Choice(_GAP_CATEGORIES),
              help="RE-FILE under a corrected category. The author picks a category "
                   "knowing their own need but not how it relates to other tenants' "
                   "misses; a mis-filed row will not group with the pattern it belongs to.")
@click.pass_context
def catalog_decisions_review(ctx, decision_id, state, note, gap_category):
    """Move a recorded gap through curation.

    Closing the loop is what keeps the queue meaningful: a gap left `new` forever is
    indistinguishable from one nobody has read, so the backlog stops being a signal.

    \b
      TORANA_PROFILE=SA torana vm transformers catalog decisions review <id> \
        --state actioned --note "covered by vm.tf.em_104"
    """
    client = _client(ctx)
    payload = {"state": state}
    if note:
        payload["note"] = note
    if gap_category:
        payload["gap_category"] = gap_category
    try:
        data = client.patch(f"{_BASE}/decisions/{decision_id}", json=payload)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if _raw(ctx) or _fmt(ctx) != "text":
        output(data, fmt=_fmt(ctx), raw=_raw(ctx), fields=_fields(ctx))
        return
    click.echo(f"{decision_id} → {data.get('state', state)}")
    if gap_category:
        click.echo(f"  gap   : {data.get('gap_category', gap_category)}")
    # Echo the STORED note, not the one sent: it may carry a re-file stamp the server
    # prepended, and showing the sent value would hide that.
    stored = data.get("curation_note")
    if stored:
        click.echo(f"  note  : {stored}")


@catalog.command(name="versions")
@click.option("--entry-id", "entry_id", default=None, metavar="ID",
              help="Restrict to one catalog entry.")
@click.option("--deletable", is_flag=True, default=False,
              help="Only versions that are superseded AND unused — the retirement queue.")
@click.option("--held", is_flag=True, default=False,
              help="Only superseded versions a tenant is STILL reading.")
@click.pass_context
def catalog_versions(ctx, entry_id, deletable, held):
    """Every version of every catalog entry, with who is using it.

    A definition lives in code; this table is its durable record. When a
    definition changes, the old version is KEPT rather than replaced — a tenant
    may have a physical table built from it, and deleting the definition would
    leave that table unexplainable.

    \b
    REFS is the delete gate: > 0 means a tenant is reading that version now.
    TENANTS names who, because a bare count tells you deletion is unsafe
    without telling you who to talk to.

    \b
    Examples:
      TORANA_PROFILE=SA torana transformers catalog versions
      TORANA_PROFILE=SA torana transformers catalog versions --deletable
      TORANA_PROFILE=SA torana transformers catalog versions --entry-id vm.tf.finding_enriched
    """
    fmt = _fmt(ctx)
    raw = _raw(ctx)
    client = _client(ctx)

    params = {"entry_id": entry_id} if entry_id else None
    try:
        data = client.get(f"{_BASE}/catalog/versions", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    items = data.get("items", [])
    if deletable:
        items = [i for i in items if i.get("deletable")]
    if held:
        items = [i for i in items if i.get("state") != "active" and (i.get("refcount") or 0) > 0]

    for i in items:
        i["consumer_count"] = len(i.get("consumers") or [])

    if raw or fmt == "json":
        output(items, fmt=fmt, raw=raw, columns=_VERSION_COLS)
        return

    # NOT a fixed-width table. `output()` truncates any cell past its column width
    # with an ellipsis, and the two fields a reader actually needs here — `grain`
    # (what one row IS) and the consumer tenant ids — are exactly the ones long
    # enough to get clipped. A grain cut at 80 chars usually loses the qualifying
    # clause, which is the part that decides whether an entry fits. Truncating the
    # evidence to fit a column defeats the point of printing it.
    for i in items:
        flag = ""
        if i.get("deletable"):
            flag = "  ← DELETABLE"
        elif i.get("orphaned"):
            flag = "  ← ORPHANED (entry gone from code)"
        elif i.get("state") != "active" and (i.get("refcount") or 0) > 0:
            flag = "  ← superseded but STILL HELD"
        click.echo(f"{i['catalog_entry_id']}  v{i['version']}  [{i.get('state')}]"
                   f"  refs={i.get('refcount', 0)}  built={i.get('materializations', 0)}{flag}")
        if i.get("grain"):
            click.echo(f"    one row : {i['grain']}")
        if i.get("consumers"):
            click.echo(f"    held by : {', '.join(i['consumers'])}")
        click.echo("")

    click.echo("")
    click.echo(f"  {data.get('total', 0)} versions  ·  "
               f"{data.get('deletable_now', 0)} deletable now  ·  "
               f"{data.get('superseded_but_held', 0)} superseded but still held  ·  "
               f"{data.get('orphaned', 0)} orphaned")
    if data.get("superseded_but_held"):
        click.echo("  ⚠ a superseded version with REFS > 0 needs a migration "
                   "conversation before it can be retired.")
    if data.get("orphaned"):
        click.echo("  ⚠ orphaned = the entry id no longer exists in code, but a "
                   "materialization still points at it.")
