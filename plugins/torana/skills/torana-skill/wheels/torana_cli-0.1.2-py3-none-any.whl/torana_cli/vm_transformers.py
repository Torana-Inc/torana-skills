"""torana vm transformers — the platform bootstrap transformer definitions.

Attaches the ``transformers`` subgroup onto the shared ``torana vm`` parent via
``register_vm_subgroup`` (see vm.py) — this module never re-defines ``vm``.

Only the ``definitions`` group lives here: the bootstrap set
(``bootstrap_transformers/definitions.json``) that app bundles reference by name.
The VM transformer catalog and its surfaces were retired on 2026-09-28
(pantheon-data-transformers/docs/DT_MATERIALIZATION_POLICY_SPEC.md § 3.2.13).
"""

import re

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.vm import register_vm_subgroup


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _fmt(ctx) -> str:
    return ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"


def _raw(ctx) -> bool:
    return ctx.obj.get(CTX_RAW, False) if ctx.obj else False


def _fields(ctx):
    return ctx.obj.get(CTX_FIELDS) if ctx.obj else None


@click.group(name="transformers")
def transformers():
    """VM transformers — the platform bootstrap definitions app bundles reference.

    \b
    Typical flow:
      torana vm transformers definitions list          # every active definition
      torana vm transformers definitions show <name>   # one definition + its SQL and grain
      torana vm transformers definitions health        # per-definition health in YOUR tenant
      torana vm transformers definitions repair        # dry run: what is missing here
      torana vm transformers definitions render --file q.sql   # bind {{vocab:…}} for your tenant
    """


# ---------------------------------------------------------------------------
# definitions (the platform BOOTSTRAP transformer set — Stream U)
#
# The CONCRETE relations the platform maintains and app bundles REFERENCE by
# name (`transformer_ref`) instead of carrying SQL for.
# ---------------------------------------------------------------------------

_DEFINITION_COLS = [
    ("name", "NAME", 32),
    ("version", "VER", 4),
    ("state", "STATE", 8),
    # ⛔ Beside STATE, not at the end. `retired` on its own does not tell a reader
    # whether the relation was replaced or simply dropped, and those have opposite
    # fixes — follow the pointer, or re-author. A column that answers that must sit
    # where the state is read, and a table output truncated at the terminal edge
    # must not be where it gets cut.
    ("superseded_by", "SUPERSEDED BY", 28),
    ("dbt_strategy", "STRATEGY", 12),
    ("description", "DESCRIPTION", 44),
]


@transformers.group(name="definitions", invoke_without_command=True)
@click.pass_context
def definitions(ctx):
    """Platform transformer definitions — what app bundles reference."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@definitions.command(name="list")
@click.option("--state", default="active", show_default=True,
              type=click.Choice(["active", "retired", "all"]),
              help="Lifecycle state. A definition is never deleted — one that "
                   "leaves the code set is RETIRED, because a materialized table "
                   "built from it may still exist.")
@click.pass_context
def definitions_list(ctx, state):
    """List the platform transformer definitions.

    These are the relations a bundle points at with `transformer_ref(...)`
    instead of carrying their SQL. One definition, one authority — which is the
    point: the same foundation authored by three bundles three ways is how a
    defect fixed in one stayed live in the other two.
    """
    client = _client(ctx)
    try:
        data = client.get("transformer-definitions/", params={"state": state})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    items = data if isinstance(data, list) else data.get("items", [])
    fmt = _fmt(ctx)
    if _raw(ctx) or fmt != "text":
        output(items, fmt=fmt, raw=_raw(ctx), fields=_fields(ctx),
               columns=_DEFINITION_COLS)
        return

    for e in items:
        uk = e.get("unique_key")
        uk = ", ".join(uk) if uk else "— (none: aggregate / no row identity)"
        # `enabled` (§ 3.2.13) as a WORD, never a colour: an absent field reads as unknown.
        _en = e.get("enabled")
        _en_word = "enabled" if _en is True else ("DISABLED" if _en is False else "enabled?")
        click.echo(f"{e['name']}  v{e.get('version')}  [{e.get('state')}]  {_en_word}")
        # ⛔ Print this FIRST on a retired row. A retired definition is not a defect
        # — bootstrap definitions are immutable, so a change authors a new relation
        # and retires the old one, and `--state retired|all` is exactly where a
        # reader lands holding a dead reference. The successor is what they came for.
        if e.get("superseded_by"):
            click.echo(f"    ➜ SUPERSEDED BY: {e['superseded_by']}  (use this instead)")
        elif e.get("state") == "retired":
            # Say it rather than printing nothing: an absent line reads as "not
            # looked up", and sends the reader hunting for a successor that is not
            # there. Retired-with-no-successor is a real, final state.
            click.echo("    ➜ retired, no successor recorded")
        click.echo(f"    answers  : {e.get('description') or '—'}")
        # ⛔ `one row` (the grain) is what a reuse decision turns on — a listing that omits
        # it forces the reader to judge on the description, which cannot distinguish "one
        # row per finding" from "one row per (team, month)". Those answer different
        # questions and differ by a multiple, silently.
        click.echo(f"    one row  : {e.get('grain') or '(grain not declared)'}")
        click.echo(f"    strategy : {e.get('dbt_strategy')}  "
                   f"(materialized={e.get('materialized')})")
        click.echo(f"    merge key: {uk}")
        bundles = e.get("declaring_bundles")
        if bundles:
            click.echo(f"    used by  : {', '.join(bundles)}")
        click.echo("")
    inc = sum(1 for e in items if e.get("dbt_strategy") == "incremental")
    click.echo(f"  {len(items)} definitions ({inc} incremental, "
               f"{len(items) - inc} full-table).")
    click.echo("  `definitions show <name>` for the SQL and full semantics.")


#: ⛔ Health states carry a TEXT GLYPH, never colour alone. Two reasons, both hard:
#: the maintainer of this platform has red/green colour blindness, and CLI output is
#: routinely piped, redirected and pasted where ANSI is stripped entirely. A state
#: distinguishable only by colour is unreadable in both cases.
_HEALTH_GLYPH = {
    "healthy": "[ok]",
    "stale": "[~ ]",
    "broken": "[XX]",
    "quarantined": "[!!]",
    "unbuilt": "[--]",
    "not_created": "[  ]",
    "phantom": "[ph]",
    # DT spec § 3.2.5: retired definition, nothing reads it — policy health (the default;
    # absent with TRANSFORMER_POLICY_HEALTH_DISABLED=true).
    "dormant": "[zz]",
}

#: dbt writes a banner (`Running with dbt=…`, `Registered adapter: …`) before the
#: real failure and colours its output, so `last_error` begins with ANSI escapes and
#: several uninformative lines. Printing `splitlines()[0]` shows every failure as
#: "Running with dbt=1.11.11" — identical for 18 different problems, which is worse
#: than no error line at all.
_DBT_NOISE = ("running with dbt", "registered adapter", "found ", "concurrency:",
              "encountered an error")


def _first_real_error(raw: str) -> str:
    """The first line of `last_error` that actually says what went wrong.

    ⚠️ A bare error CLASS ("Compilation Error", "Database Error") is a header, not
    a diagnosis — it reads identically for 18 different failures. When one is hit,
    keep reading and return the following detail line instead.
    """
    clean = re.sub(r"\x1b\[[0-9;]*m", "", raw or "")
    lines = []
    for line in clean.splitlines():
        s = re.sub(r"^\d{2}:\d{2}:\d{2}\s*", "", line.strip())
        if not s or s.startswith("-"):
            continue
        if any(s.lower().startswith(n) for n in _DBT_NOISE):
            continue
        lines.append(s)
    for i, s in enumerate(lines):
        if s.rstrip().lower().endswith("error") and i + 1 < len(lines):
            return f"{s} — {lines[i + 1]}"[:160]
        return s[:160]
    return "(no detail)"


_HEALTH_COLS = [
    ("health", "HEALTH", 12),
    ("name", "NAME", 38),
    ("last_status", "STATUS", 12),
    ("last_run_at", "LAST RUN", 22),
    ("domain", "DOMAIN", 14),
]


@definitions.command(name="coverage")
@click.option("--state", "state_filter", default="all", show_default=True,
              type=click.Choice(["all", "ok", "degraded", "incomplete", "empty",
                                 "unknown"]),
              help="Filter to one state. Default `all` — filtering by default "
                   "would hide the thing the operator came to see.")
@click.pass_context
def definitions_coverage(ctx, state_filter):
    """Bootstrap coverage for EVERY tenant — who is missing their transformers?

    ⭐ CROSS-TENANT, unlike `definitions health`, which only ever sees YOUR
    tenant. Super-admin only. This is the board that answers "did tenant X ever
    get its bootstrap set?" — a question that had no surface at all until a
    recreated tenant silently received ZERO transformers and only surfaced when
    an app-bundle install refused it.

    \b
    ⛔ `present` IS NOT `built`. `built` trusts the row's last_status; `present`
       asks the datalake whether the relation actually EXISTS. They disagree
       when a relation is dropped out from under its row, and the row keeps
       claiming success forever — the automatic repair and sweep both judge by
       status and will never rebuild it.
    ⚠️ `phantom` is exactly that disagreement: rows claiming success over
       nothing. A non-zero phantom count means self-healing cannot see the gap.

    \b
    States:
      [ok]  ok         rows present, all built, nothing phantom
      [~ ]  degraded   some failed or phantom — look at those two columns
      [XX]  empty      ZERO rows. The tenant never got its bootstrap set.
      [? ]  unknown    the datalake could not be reached, so present/phantom
                       are not meaningful for that tenant
    """
    client = _client(ctx)
    try:
        data = client.get("transformer-definitions/coverage")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if _raw(ctx) or fmt != "text":
        output(data, fmt=fmt, raw=_raw(ctx), fields=_fields(ctx))
        return

    items = data.get("items") or []
    if state_filter != "all":
        items = [i for i in items if i.get("state") == state_filter]

    # ⚠️ GLYPHS, not colour alone — the state must be readable without relying on
    # red/green discrimination.
    marks = {"ok": "[ok]", "degraded": "[~ ]", "incomplete": "[..]", "empty": "[XX]",
             "unknown": "[? ]"}

    click.echo("")
    click.echo(f"  {data.get('tenants', 0)} tenant(s)   "
               f"in-scope definitions: {data.get('in_scope', 0)}")
    if not data.get("datalake_checked", True):
        click.echo("  ⚠ the datalake was unreachable for at least one tenant — "
                   "`present`/`phantom` are not meaningful there")
    click.echo("")
    click.echo(f"  {'':4} {'TENANT':22} {'STATE':9} {'ROWS':>5} {'PRESENT':>8} "
               f"{'BUILT':>6} {'FAILED':>7} {'PHANTOM':>8}")
    for i in items:
        label = i.get("tenant_name") or (i.get("tenant_id") or "")[:8]
        click.echo(f"  {marks.get(i.get('state'), '[? ]')} {label:22.22} "
                   f"{i.get('state',''):9} {i.get('rows',0):>5} "
                   f"{i.get('present',0):>8} {i.get('built',0):>6} "
                   f"{i.get('failed',0):>7} {i.get('phantom',0):>8}")

    empty = data.get("empty_tenants", 0)
    phantom_total = sum(i.get("phantom", 0) for i in (data.get("items") or []))
    click.echo("")
    if empty:
        click.echo(f"  ⛔ {empty} tenant(s) have ZERO bootstrap transformers. "
                   f"They cannot install an app bundle. Run "
                   f"`torana vm transformers definitions repair --apply` as that "
                   f"tenant, or restart data-transformers to let boot repair heal them.")
    if phantom_total:
        click.echo(f"  ⚠ {phantom_total} row(s) claim success but their relation "
                   f"does NOT exist. Repair and the sweep judge by status and will "
                   f"not rebuild these — a forced re-materialize is required.")
    incomplete = data.get("incomplete_tenants", 0)
    if incomplete:
        click.echo(f"  ⚠ {incomplete} tenant(s) have only PART of the set (ROWS < "
                   f"{data.get('in_scope', 0)}). A bundle referencing an absent one is "
                   f"refused. Run `torana vm transformers definitions repair --apply` as "
                   f"that tenant.")
    # ⛔ Only when NOTHING above fired. This line used to print over three tenants
    # holding 15 of 41, because it checked empty and phantom but never the count.
    if not empty and not phantom_total and not incomplete:
        click.echo("  Every tenant has its bootstrap set, and every row that "
                   "claims success has a relation behind it.")


@definitions.command(name="health")
@click.option("--health", "health_filter", default="all", show_default=True,
              type=click.Choice(["all", "healthy", "stale", "broken",
                                 "quarantined", "unbuilt", "not_created",
                                 "phantom"]),
              help="Filter to one state. Default `all` — filtering by default "
                   "would hide the thing the operator came to see.")
@click.pass_context
def definitions_health(ctx, health_filter):
    """Per-tenant health for every active definition.

    ⚠️ TENANT-SCOPED, unlike its sibling `definitions list`, which is
    tenant-neutral by design. The tenant comes from your credentials and cannot be
    passed as an argument.

    ⛔ It answers "is this DEFINITION healthy in MY tenant?" — never "is my tenant
    healthy?". A failing relation whose definition is not active cannot appear in
    the listing at all; those are reported separately as ORPHANED FAILURES, and a
    non-zero count there means the board below is incomplete.

    The five states:

    \b
      [ok] healthy      built, succeeded, and fresh
      [~ ] stale        succeeded, but older than the staleness threshold
      [XX] broken       last build failed — do NOT read from it
      [!!] quarantined  parked out of the dbt graph. ⚠️ STILL RETURNS ROWS, and
                        they are stale — the most dangerous state, because a
                        query against it answers plausibly instead of failing
      [--] unbuilt      this tenant never materialized it (not a failure)
      [  ] not_created  no row in this tenant at all — `materialize` cannot
                        help; `definitions repair --apply` creates it
      [ph] phantom      the row says its last build succeeded, but the table/view
                        is NOT in the tenant's schema (dropped out from under it).
                        `torana datalake transformer <name> materialize` rebuilds it
      [..] owed         (shown beside `stale`) a rebuild is owed and happens on the
                        next build: `owed full refresh` = repair rewrote the SQL,
                        `owed rebuild` = a build died before reaching it

    Every active definition is a bootstrap definition — the set every tenant
    gets, instantiated by repair — so `unbuilt` here means something did not
    happen: a real gap.
    """
    client = _client(ctx)
    try:
        data = client.get("transformer-definitions/health",
                          params={"health": health_filter})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    items = data.get("items", [])

    fmt = _fmt(ctx)
    if _raw(ctx) or fmt != "text":
        output(items, fmt=fmt, raw=_raw(ctx), fields=_fields(ctx),
               columns=_HEALTH_COLS)
        return

    from torana_cli.datalake import OWED_GLYPH, owed_label

    for e in items:
        glyph = _HEALTH_GLYPH.get(e.get("health"), "[??]")
        click.echo(f"{glyph} {e.get('health'):12} {e['name']}")
        # § 3.11.6: an owed row reads `stale`; say WHY, with the raw status in words.
        if owed_label(e.get("last_status")):
            click.echo(f"        status   : {OWED_GLYPH} {owed_label(e['last_status'])}")
        if e.get("last_run_at"):
            click.echo(f"        last run : {e['last_run_at']}")
        if e.get("last_error"):
            click.echo(f"        error    : {_first_real_error(e['last_error'])}")
    if items:
        click.echo("")

    # ⛔ The counts are over the WHOLE board, never the `--health` filter. A summary
    # that moved with `--health` would make every filtered read look like a
    # different tenant — the same "clean board over a dirty tenant" this command
    # exists to end. The server already returns the unfiltered `counts`.
    counts = data.get("counts") or {}
    total = sum(counts.values())
    click.echo(f"  {total} bootstrap definitions — "
               + ", ".join(f"{_HEALTH_GLYPH.get(k, '')} {v} {k}"
                           for k, v in sorted(counts.items()) if v))
    n_owed = sum(1 for e in items if owed_label(e.get("last_status")))
    if n_owed:
        click.echo(f"  {OWED_GLYPH} {n_owed} of the stale are owed a rebuild on the next build.")
    if health_filter != "all":
        click.echo(f"  (showing {len(items)} × {health_filter}; "
                   f"counts above are the whole board)")

    click.echo(f"  stale after {data.get('staleness_hours')}h.")

    orphans = data.get("orphaned_failures") or 0
    if orphans:
        # ⛔ NOT a footnote. These are failing relations THIS TENANT HAS that can
        # never appear above, because no active definition backs them. Reporting the
        # board without them would be a clean board over a dirty tenant.
        click.echo("")
        click.echo(f"  ⚠️  {orphans} ORPHANED FAILURE(S) — failing here, but no "
                   f"active definition backs them,")
        click.echo("      so they cannot appear in the listing above:")
        for n in data.get("orphaned_failure_names", []):
            click.echo(f"        [XX] {n}")
        # ⛔ Deliberately NOT "these need retiring". An orphan is a relation with no
        # ACTIVE DEFINITION — that is not the same as UNUSED, and the two were
        # conflated once already. Measured on T2: `remediation_base` is an orphan
        # with FIVE dependents and `threat_intel_ranked` with four; deleting either
        # breaks nine working relations. Check dependents before retiring anything.
        click.echo("      ⚠️  Orphaned ≠ unused. Check what reads each one "
                   "(`definitions show <name>`, source_tables)")
        click.echo("          BEFORE retiring it — an orphan can still be a base "
                   "relation others depend on.")


@definitions.command(name="render")
@click.option("--file", "sql_file", type=click.Path(exists=True, dir_okay=False),
              default=None, help="File containing SQL with {{vocab:…}} placeholders.")
@click.option("--sql", "sql_text", default=None, help="SQL with {{vocab:…}} placeholders.")
@click.pass_context
def definitions_render(ctx, sql_file, sql_text):
    """Bind {{vocab:…}} placeholders for YOUR tenant. Render only — never executes.

    \b
    The same render repair writes into a bootstrap relation: each key is resolved
    from this tenant's policy (agent-builder resolve-and-gate) and rendered by
    pantheon_shared.vocab. An unknown key REFUSES by name — no default is ever
    substituted. Successor of the retired `catalog render` (spec § 3.2.13 D7).

    \b
    Grammar:  {{vocab:vm.<category>.<subcategory>.<key>[.<verb>]}}
              {{vocab:vm.<category>.<subcategory>.<key>.lookup[<alias>.<column>]}}
    Keys and verbs: `torana vm policy vocabulary`.

    \b
    Examples:
      torana vm transformers definitions render --file query.sql
      torana vm transformers definitions render --sql "SELECT … IN ({{vocab:vm.prioritization.scope_gates.actionable_status_set.in}})"
      torana vm transformers definitions render --file q.sql --format json
    """
    from pathlib import Path

    if bool(sql_file) == bool(sql_text):
        raise click.UsageError("pass exactly one of --file or --sql")
    sql = Path(sql_file).read_text() if sql_file else sql_text

    client = _client(ctx)
    try:
        data = client.post("transformer-definitions/render", json={"sql": sql})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if _raw(ctx) or fmt != "text":
        output(data, fmt=fmt, raw=_raw(ctx), fields=_fields(ctx))
        return
    bound = data.get("bound") or []
    click.echo(f"  tenant : {data.get('tenant_id')}")
    if bound:
        click.echo(f"  bound  : {len(bound)} key(s)")
        for b in bound:
            origin = "platform default" if b.get("default_in_effect") else "tenant value"
            shown = b.get("expanded") if b.get("expanded") else b.get("value")
            click.echo(f"    {b.get('key')} = {shown!r}  ({origin})")
    else:
        click.echo("  bound  : none — the SQL carries no {{vocab:…}} placeholder")
    left = data.get("unrendered_placeholders") or []
    if left:
        click.echo(f"  ⚠ left as text (not vocabulary): {', '.join(left)}")
    click.echo("\n  SQL:")
    for line in (data.get("rendered_sql") or "").splitlines():
        click.echo(f"    {line}")


@definitions.command(name="repair")
@click.option("--apply", "apply_", is_flag=True, default=False,
              help="Actually repair. Without it this is a DRY RUN that only reports drift.")
@click.option("--no-materialize", is_flag=True, default=False,
              help="Repair the rows and model files but do not rebuild the tables.")
@click.option("--workspace-id", default="bootstrap", show_default=True,
              help="Workspace to attach newly created rows to.")
@click.pass_context
def definitions_repair(ctx, apply_, no_materialize, workspace_id):
    """Restore this tenant's bootstrap relations to what the definitions declare.

    Closes four drifts, each of which is SILENT — the relation keeps serving
    whatever it last held, so the only symptom is answers that quietly stop moving:

    \b
      MISSING   an active definition has no transformer row here (deleted).
                ⚠️ A tenant whose rows were ALL deleted drops out of the hourly
                sweep entirely, so this is the only way back.
      UNFILED   the row exists but its dbt model file does not (quarantined).
                Releasing it needs a re-write, which only create/update perform —
                the sweep can never recover it on its own.
      DANGLING  a model FILE references a model no live row owns (any
                workspace). dbt fails it and everything downstream with
                "depends on a node named 'x' which was not found". Regenerated
                from its row; a real reference that survives is reported failed.
      STALE     built long ago, or never. Handled by the normal builder.
      OUTDATED  the row runs SQL from an OLDER definition generation — the
                platform definition was edited and this tenant never picked it
                up. It builds cleanly and reports success, so nothing else shows
                it. Rewritten from the active definition, then rebuilt from
                scratch (--full-refresh).
                Rows built before generation tracking carry no stamp; those are
                compared by SQL, and if already current are only stamped.

    Idempotent: running it twice changes nothing the second time.

    \b
    Examples:
      torana vm transformers definitions repair              # dry run — what is wrong?
      torana vm transformers definitions repair --apply      # fix it, and rebuild
      torana vm transformers definitions repair --apply --no-materialize
    """
    client = _client(ctx)
    payload = {
        "dry_run": not apply_,
        "materialize": not no_materialize,
        "workspace_id": workspace_id,
    }
    try:
        data = client.post("transformer-definitions/repair", json=payload)
    except APIError as e:
        # ⛔ A 504 HERE DOES NOT MEAN THE REPAIR FAILED — IT MEANS THE GATEWAY GAVE
        # UP WAITING. `--apply` runs the dbt build inline, which on a tenant with
        # tens of relations takes minutes and outlives nginx's proxy timeout. The
        # work continues server-side and normally completes.
        #
        # ⚠️ The bare "API error (HTTP 504)" is actively harmful advice by omission:
        # it reads as a failure, so the natural response is to re-run — which
        # contends for the same materialization lock and can make a healthy repair
        # look permanently broken. Measured 2026-09-22 on tenant 08552d33: the CLI
        # reported 504 at 17:38:13 while the server went on building 38 relations.
        if getattr(e, "status_code", None) == 504:
            click.echo("")
            click.echo("  ⚠ The gateway timed out — but the repair is probably STILL "
                       "RUNNING on the server.")
            click.echo("    `--apply` builds inline, which outlasts the HTTP timeout "
                       "on a large tenant.")
            click.echo("    Do NOT immediately re-run (it contends for the build "
                       "lock). Watch it finish with:")
            click.echo("      torana vm transformers definitions health")
            ctx.exit(1)
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if _raw(ctx) or fmt != "text":
        output(data, fmt=fmt, raw=_raw(ctx), fields=_fields(ctx))
        return

    dry = data.get("dry_run", True)
    click.echo(f"  tenant {data.get('tenant_id','?')}  "
               f"{'DRY RUN — nothing changed' if dry else 'REPAIR APPLIED'}")
    click.echo("")

    def _section(title, found, done, verb, reasons=None):
        if not found:
            click.echo(f"  {title}: none")
            return
        # ⛔ FOUND and DONE are printed separately on purpose. A single "fixed N"
        # would hide the interesting case — an item that was found and could NOT
        # be repaired, which is the one a reader must act on.
        if dry:
            click.echo(f"  {title}: {len(found)}")
        else:
            click.echo(f"  {title}: {len(done)} {verb} of {len(found)} found")
        for n in found:
            mark = "  " if dry else ("✓ " if n in done else "✗ ")
            # ⛔ THE REASON, when known, so a reader can tell "the platform moved" from
            # "your own policy value moved" WITHOUT opening `... transformer <name>
            # versions` for every row — two different things to do about it. `.get()`,
            # not `[]`: an older server, or a row whose cause could not be
            # distinguished, simply omits the tag rather than crashing the printout.
            reason = (reasons or {}).get(n)
            tag = {"definition": "  [platform definition moved]",
                   "tenant_policy": "  [your tenant policy value changed]"}.get(
                       reason, f"  [{reason}]" if reason else "")
            click.echo(f"      {mark}{n}{tag}")

    _section("MISSING  (no transformer row)", data.get("missing_found") or [],
             data.get("missing_created") or [], "created")
    _section("UNFILED  (no dbt model file)", data.get("unfiled_found") or [],
             data.get("unfiled_restored") or [], "restored")
    # DANGLING (2026-09-29): {model file: [missing refs]}. `.get() or {}` — an older
    # server cannot detect it, and "none" is the right reading of that.
    _dangling = data.get("dangling_found") or {}
    _section("DANGLING (model file references a missing model)", sorted(_dangling),
             data.get("dangling_regenerated") or [], "regenerated",
             reasons={m: f"refs {', '.join(r)}" for m, r in _dangling.items()})
    # OUTDATED (rev 021, cause split 2026-09-23). ⚠️ `.get(...) or []` — an older
    # server omits these keys, and "none" is the right reading of that: it cannot
    # detect this drift at all. `outdated_reasons` is newer still than `outdated_found`
    # itself, so a mid-rollout server can report the drift with no cause tags yet —
    # handled the same way, by `_section`'s `.get()` falling through to no tag.
    _section("OUTDATED (older definition generation, or your policy changed)",
             data.get("outdated_found") or [], data.get("outdated_rewritten") or [],
             "rewritten", reasons=data.get("outdated_reasons") or {})

    # ⭐ NOT A REPAIR, and printed so it can't be mistaken for one. These rows predate
    # generation tracking; their SQL was compared with the active definition and already
    # matched, so they were only stamped. Folding them into a repaired count would
    # overstate what changed — and silence would leave a reader wondering why every
    # row's drift state flipped from "unknown" to "current" at once.
    backfilled = data.get("generation_backfilled") or []
    if backfilled:
        verb = "would record" if dry else "recorded"
        click.echo(f"  {len(backfilled)} relation(s) {verb} their definition generation "
                   f"— already current, nothing rebuilt.")

    # ⭐ SKIPPED IS PRINTED SEPARATELY FROM FAILED, and before it. These are
    # EXPECTED non-creations: 19 of the 37 in-scope definitions carry
    # `{{vocab:…}}` and are bound per tenant at BUNDLE INSTALL, and 5 more read
    # one of those. Repair can never create them, and that is the design.
    #
    # ⚠️ Until 2026-09-21 they were counted as FAILURES, so a correct repair on a
    # healthy tenant reported "23 failed" and read as an outage. Two counters,
    # never one — a single number cannot tell "working as designed" from "broken".
    # ⛔ TWO SKIP REASONS, AND THEY CALL FOR OPPOSITE RESPONSES. The header asserted
    # "bound at bundle install" for every skip, which is PERMANENT for repair — those
    # definitions carry {{vocab:…}} and only a bundle install ever creates them, so no
    # number of re-runs changes anything. An upstream that is merely UNBUILT is
    # TRANSIENT: build it and the next repair creates the dependent.
    #
    # ⚠️ Measured 2026-09-22 on tenant 08552d33: `prioritize_fixes` was skipped on
    # `prioritize_fix_locations (created this pass, not built yet)` and reported under
    # the "bound at bundle install" header — telling the operator to go look for an
    # install that was never the problem, when the answer was to re-run this very
    # command. The service already splits these two in its own summary line; the CLI
    # was the surface still conflating them.
    # ⛔ A "verify" skip (rev 021) is a DIFFERENT thing from the two create-skips below:
    # the row exists, but its definition generation could not be checked — usually a
    # vocabulary key that does not resolve for this tenant. Under the create-skip
    # header it would read "bound at bundle install — repair never creates these",
    # which is wrong on both counts: nothing was being created, and the fix is to
    # make the key resolve, not to install a bundle.
    all_skipped = data.get("skipped") or []
    verify_skipped = [s for s in all_skipped if s.get("phase") == "verify"]
    if verify_skipped:
        click.echo("")
        click.echo(f"  — {len(verify_skipped)} definition generation(s) could not be "
                   f"checked (left as 'unknown', not changed):")
        for s in verify_skipped:
            click.echo(f"      {s.get('name')}: {s.get('reason')}")
        click.echo("      ↳ usually a policy vocabulary key this tenant cannot resolve. "
                   "Nothing was rewritten on a guess.")

    skipped = [s for s in all_skipped if s.get("phase") != "verify"]
    if skipped:
        def _transient(s):
            return any(m in (s.get("reason") or "")
                       for m in ("not built yet", "table does not"))
        _defer = [s for s in skipped if _transient(s)]
        _bound = [s for s in skipped if not _transient(s)]
        click.echo("")
        click.echo(f"  — {len(skipped)} skipped (not a failure):")
        for s in _bound:
            click.echo(f"      {s.get('name')}: {s.get('reason')}")
        if _bound:
            click.echo("      ↳ bound at bundle install — repair never creates these.")
        for s in _defer:
            click.echo(f"      {s.get('name')}: {s.get('reason')}")
        if _defer:
            # ⭐ SAY WHAT TO DO — AND THE UPSTREAM MUST BE *BUILT*, NOT MERELY
            # CREATED. A chain needs one pass per level, so this is slow rather than
            # stuck; but a re-run only helps once the upstream has a TABLE.
            #
            # ⚠️ Measured 2026-09-22 on 08552d33: the first apply created
            # `prioritize_fix_locations` and deferred `prioritize_fixes`; the
            # immediate re-run deferred it again, because the build had been skipped
            # (the startup repair held the materialization lock) so the upstream was
            # still a row with no table. Telling the operator to re-run, with no
            # mention of the build, sends them into a loop that cannot progress.
            click.echo("      ↳ waiting on an upstream that has no table yet. "
                       "Re-run once it is BUILT —")
            click.echo("        check with `torana vm transformers definitions "
                       "health`; if the build was skipped above, the hourly sweep "
                       "or the next restart builds it.")

    failed = data.get("failed") or []
    if failed:
        click.echo("")
        click.echo(f"  ⚠ {len(failed)} could not be repaired:")
        for f in failed:
            click.echo(f"      {f.get('name')} [{f.get('phase')}] {str(f.get('error'))[:120]}")

    built = data.get("materialized") or []
    mfail = data.get("materialize_failed") or []
    if built or mfail:
        click.echo("")
        click.echo(f"  rebuilt: {len(built)}   failed: {len(mfail)}")
    if data.get("skipped_locked"):
        click.echo("  ⚠ build skipped — another worker holds the materialization lock. "
                   "Re-run, or wait for the hourly sweep.")

    click.echo("")
    if dry:
        # ⛔ SUBTRACT THE SKIPS. A dry run that counts vocab-bound relations as
        # "need repair" promises something `--apply` will not deliver: those are
        # bound at bundle install and repair deliberately refuses them. Measured
        # 2026-09-21 on T1 — the preview said "4 relation(s) need repair" when
        # all 4 were skips and `--apply` would correctly change nothing.
        # Create-phase skips only — a "verify" skip is reported above and is not a
        # missing relation, so it must not feed the "bound at bundle install" line.
        skipped_names = {s.get("name") for s in skipped}
        # ⛔ OUTDATED COUNTS AS ACTIONABLE (rev 021). Leaving it out would print
        # "Nothing to repair — this tenant matches the definitions" for a tenant whose
        # only drift is outdated SQL: a false green, on the one drift class that has no
        # other symptom anywhere.
        actionable = [
            n for n in ((data.get("missing_found") or [])
                        + (data.get("unfiled_found") or [])
                        + sorted(data.get("dangling_found") or {})
                        + (data.get("outdated_found") or []))
            if n not in skipped_names
        ]
        if actionable:
            click.echo(f"  {len(actionable)} relation(s) need repair. "
                       f"Re-run with --apply to fix them.")
            if skipped_names:
                click.echo(f"  ({len(skipped_names)} more are bound at bundle "
                           f"install and cannot be repaired here.)")
        elif skipped_names:
            click.echo(f"  Nothing repairable here — all {len(skipped_names)} "
                       f"missing relation(s) are bound at bundle install. "
                       f"Install the owning app bundle.")
        else:
            click.echo("  Nothing to repair — this tenant matches the definitions.")


@definitions.command(name="prune")
@click.option("--apply", "apply_", is_flag=True, default=False,
              help="Actually delete. Without it this is a DRY RUN that only reports the plan.")
@click.option("--tenant-id", default=None, help="SA only: prune this tenant.")
@click.option("--all-tenants", is_flag=True, default=False,
              help="SA only: every tenant pantheon-auth knows.")
@click.option("--name", "names", multiple=True,
              help="Only these candidate names (repeatable). Narrows, never widens.")
@click.pass_context
def definitions_prune(ctx, apply_, tenant_id, all_tenants, names):
    """Delete rows of bootstrap definitions the platform no longer enables — the mirror of repair.

    `enabled: false` (or removing a definition from the set) stops repair creating it, but
    never deletes what a tenant already has: the row, its dbt model file and its relation stay
    forever. Prune removes them, and ONLY those nothing reads.

    \b
      candidate     a live row in the `bootstrap` workspace whose definition the file does
                    not enable. Rows in any other workspace are never touched.
      deletable     a candidate no app, rule, widget, KPI, card or live transformer reads.
      kept          a candidate something reads — never deleted; its readers are listed.
      refused       the consumer list could not be read completely — nothing is deleted;
                    or a live dbt model FILE still refs it after regeneration.

    The delete is the one `transformer <id> delete` performs: row, model file, relation.
    Readers the platform cannot see (chat-time SQL, the datalake query API, external BI)
    are listed on every run.

    \b
    Examples:
      torana vm transformers definitions prune                        # dry run, your tenant
      torana vm transformers definitions prune --apply
      TORANA_PROFILE=SA torana vm transformers definitions prune --all-tenants
      TORANA_PROFILE=SA torana vm transformers definitions prune --tenant-id <id> --apply
    """
    if tenant_id and all_tenants:
        raise click.UsageError("pass --tenant-id OR --all-tenants, not both")
    client = _client(ctx)
    payload = {"apply": apply_}
    if tenant_id:
        payload["tenant_id"] = tenant_id
    if all_tenants:
        payload["all_tenants"] = True
    if names:
        payload["names"] = list(names)
    try:
        data = client.post("transformer-definitions/prune", json=payload)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if _raw(ctx) or fmt != "text":
        output(data, fmt=fmt, raw=_raw(ctx), fields=_fields(ctx))
        return

    dry = data.get("dry_run", True)
    click.echo(f"  {'DRY RUN — nothing changed' if dry else 'PRUNE APPLIED'}")
    for t in data.get("tenants") or []:
        label = t.get("tenant_name") or ""
        click.echo("")
        click.echo(f"  tenant {t.get('tenant_id', '?')}" + (f"  ({label})" if label else ""))
        if t.get("skipped_locked"):
            click.echo("    ⚠ SKIPPED — a repair or build holds this tenant's lock. "
                       "Nothing changed; re-run shortly.")
        cands = t.get("candidates") or []
        click.echo(f"    candidates: {len(cands)}")
        deletable = t.get("deletable") or []
        deleted = set(t.get("deleted") or [])
        if dry:
            click.echo(f"    would delete ({len(deletable)} — nothing reads them):")
            for n in deletable:
                click.echo(f"        - {n}")
        else:
            click.echo(f"    deleted: {len(deleted)} of {len(deletable)} deletable")
            for n in deletable:
                click.echo(f"        {'✓ deleted ' if n in deleted else '✗ NOT deleted '}{n}")
        # A stale MODEL FILE is a reader too: dbt resolves every ref() in it, comments
        # included. Apply regenerates these files first and refuses a candidate a file
        # still refs afterwards (2026-09-29, Classie 876788f6).
        regen = t.get("regenerate_first") or {}
        if regen:
            verb = "would regenerate first" if dry else "regenerated first"
            click.echo(f"    model files that ref a candidate — {verb}:")
            for n, files in regen.items():
                click.echo(f"        ~ {n}  ← {', '.join(files)}")
        kept = t.get("kept_consumed") or []
        if kept:
            click.echo(f"    KEPT — read by something ({len(kept)}):")
            for k in kept:
                readers = ", ".join(f"{r.get('kind')} '{r.get('name') or r.get('id')}'"
                                    for r in k.get("readers") or [])
                click.echo(f"        = {k.get('name')}  ← {readers}")
        refused = t.get("refused") or []
        if refused:
            click.echo(f"    REFUSED — not judged safely ({len(refused)}):")
            for r in refused:
                click.echo(f"        ! {r.get('name')}: {r.get('why')}")
        failed = t.get("failed") or []
        if failed:
            click.echo(f"    ⚠ FAILED ({len(failed)}):")
            for f in failed:
                click.echo(f"        ✗ {f.get('name')}: {f.get('why')}")
        errs = t.get("consumer_errors") or []
        if errs:
            click.echo(f"    consumer read errors: {'; '.join(errs)}")
    nv = data.get("not_visible") or []
    if nv:
        click.echo("")
        click.echo(f"  Not visible to any consumer check: {', '.join(nv)}.")
    if dry and any(t.get("deletable") for t in data.get("tenants") or []):
        click.echo("  Re-run with --apply to delete the rows listed under 'would delete'.")


@definitions.command(name="adopt")
@click.option("--apply", "apply_", is_flag=True, default=False,
              help="Actually move the rows. Without it this is a DRY RUN.")
@click.option("--tenant-id", default=None, help="SA only: adopt in this tenant.")
@click.option("--name", "names", multiple=True,
              help="Only these candidate names (repeatable). Narrows, never widens.")
@click.pass_context
def definitions_adopt(ctx, apply_, tenant_id, names):
    """Move app-owned rows of platform definitions into platform (bootstrap) ownership.

    An app installed INLINE before a definition was registered owns the tenant's row, so
    repair treats the name as a collision: it never re-renders that row, and `vm policy
    apply` never reaches it. Adopt moves the row's owner to `bootstrap` — same id, same
    relation, same history — so the next repair covers it.

    \b
      candidate  a live row of an ACTIVE, enabled definition in an app workspace, where
                 the tenant has no bootstrap row of that name.
      refused    two app workspaces own a copy — which is the platform's is your call.

    \b
    Examples:
      torana vm transformers definitions adopt                        # dry run, your tenant
      torana vm transformers definitions adopt --apply
      TORANA_PROFILE=SA torana vm transformers definitions adopt --tenant-id <id>
      TORANA_PROFILE=SA torana vm transformers definitions adopt --tenant-id <id> --apply
    """
    client = _client(ctx)
    payload = {"apply": apply_}
    if tenant_id:
        payload["tenant_id"] = tenant_id
    if names:
        payload["names"] = list(names)
    try:
        data = client.post("transformer-definitions/adopt", json=payload)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    fmt = _fmt(ctx)
    if _raw(ctx) or fmt != "text":
        output(data, fmt=fmt, raw=_raw(ctx), fields=_fields(ctx))
        return

    dry = data.get("dry_run", True)
    click.echo(f"  {'DRY RUN — nothing changed' if dry else 'ADOPT APPLIED'}")
    label = data.get("tenant_name") or ""
    click.echo(f"  tenant {data.get('tenant_id', '?')}" + (f"  ({label})" if label else ""))
    if data.get("skipped_locked"):
        click.echo("    ⚠ SKIPPED — a repair holds this tenant's lock. Nothing changed; "
                   "re-run shortly.")
    cands = data.get("candidates") or []
    adopted = set(data.get("adopted") or [])
    click.echo(f"    candidates: {len(cands)}")
    for c in cands:
        mark = ("        - " if dry else
                "        ✓ adopted " if c.get("name") in adopted else "        ✗ NOT adopted ")
        click.echo(f"{mark}{c.get('name')}  (owned by app workspace {c.get('workspace_id')})")
    for r in data.get("refused") or []:
        click.echo(f"    ! REFUSED {r.get('name')}: {r.get('why')}")
    for f in data.get("failed") or []:
        click.echo(f"    ✗ FAILED {f.get('name')}: {f.get('why')}")
    if dry and cands:
        click.echo("  Re-run with --apply to move them to bootstrap; then run "
                   "`torana vm transformers definitions repair --apply`.")


@definitions.command(name="show")
@click.argument("name")
@click.option("--tenant-id", "profile_tenant_id", default=None,
              help="Tenant whose instance row supplies the time profile (SA only; "
                   "default: your tenant).")
@click.pass_context
def definitions_show(ctx, name, profile_tenant_id):
    """Show one definition — its SQL, materialization config, semantics and the time
    profile of one tenant's instance row.

    \b
    Examples:
      torana vm transformers definitions show prioritized_vulnerabilities
      torana vm transformers definitions show prioritized_vulnerabilities --tenant-id <T1>
    """
    client = _client(ctx)
    params = {"with_profile": "true"}
    if profile_tenant_id:
        params["profile_tenant_id"] = profile_tenant_id
    try:
        e = client.get(f"transformer-definitions/{name}", params=params)
    except APIError as ex:
        handle_api_error(ex)
        return
    except AuthError as ex:
        handle_auth_error(ex)
        return

    if not e:
        # ⭐ `/{name}` serves ACTIVE rows only, so a retired definition lands here —
        # and that is the single most likely reason someone types this command: they
        # are holding a reference that stopped resolving. Telling them "no active
        # definition" and stopping makes them run a second, differently-shaped
        # command to learn the one thing they needed. Look it up for them.
        retired = None
        try:
            allrows = client.get("transformer-definitions/", params={"state": "retired"})
            rows = allrows if isinstance(allrows, list) else allrows.get("items", [])
            # Newest version wins: a definition retired more than once carries its
            # current forwarding address on the latest row.
            matches = sorted((r for r in rows if r.get("name") == name),
                             key=lambda r: r.get("version") or 0, reverse=True)
            retired = matches[0] if matches else None
        except (APIError, AuthError):
            # ⛔ Best-effort by design. This is a convenience lookup on an error
            # path; failing it must not replace the real answer ("no active
            # definition") with a second, less useful error.
            retired = None

        if retired:
            click.echo(f"'{name}' is RETIRED (v{retired.get('version')}).")
            if retired.get("superseded_by"):
                click.echo(f"  ➜ superseded by: {retired['superseded_by']}")
                click.echo(f"  `definitions show {retired['superseded_by']}` "
                           f"for its SQL and semantics.")
            else:
                click.echo("  ➜ no successor recorded — it left the code set without "
                           "a replacement.")
            return

        click.echo(f"No active definition named '{name}'.")
        click.echo("  `definitions list --state all` includes retired ones.")
        return

    fmt = _fmt(ctx)
    if _raw(ctx) or fmt != "text":
        output(e, fmt=fmt, raw=_raw(ctx), fields=_fields(ctx))
        return

    uk = e.get("unique_key")
    click.echo(f"{e['name']}  v{e.get('version')}  [{e.get('state')}]")
    if e.get("superseded_by"):
        click.echo(f"  ➜ SUPERSEDED BY: {e['superseded_by']}  (use this instead)")
    click.echo(f"  id        : {e.get('definition_id')}")
    click.echo(f"  answers   : {e.get('description') or '—'}")
    # The STRUCTURED grain column, not the prose inside `semantics`. Both may state a
    # grain; this one is the field the store curates and every other surface reads, so
    # it is the one to judge on.
    click.echo(f"  one row   : {e.get('grain') or '(grain not declared)'}")
    if e.get("domain"):
        click.echo(f"  domain    : {e['domain']}")
    if e.get("answers_questions"):
        click.echo(f"  questions : {', '.join(e['answers_questions'])}")
    click.echo(f"  strategy  : {e.get('dbt_strategy')} "
               f"(materialized={e.get('materialized')}"
               f"{', ' + e['materialization'] if e.get('materialization') else ''})")
    click.echo(f"  merge key : {', '.join(uk) if uk else '— (none)'}")
    click.echo(f"  reads     : {', '.join(e.get('source_tables') or []) or '—'}")
    if e.get("depends_on"):
        click.echo(f"  depends on: {', '.join(e['depends_on'])}")
    if e.get("declaring_bundles"):
        click.echo(f"  used by   : {', '.join(e['declaring_bundles'])}")
    click.echo(f"  hash      : {e.get('content_hash', '')[:16]}…")
    _en = e.get("enabled")
    click.echo(f"  enabled   : {'true' if _en is True else ('false' if _en is False else 'unknown')}")
    from torana_cli.refresh_plan_render import profile_lines
    for line in profile_lines(e):
        click.echo(line)
    if e.get("semantic_description"):
        click.echo("\n  semantics:")
        for line in (e["semantic_description"] or "").splitlines():
            click.echo(f"    {line}")
    click.echo("\n  SQL:")
    for line in (e.get("custom_sql") or "").splitlines():
        click.echo(f"    {line}")


register_vm_subgroup(transformers)
