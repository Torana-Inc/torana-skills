"""torana workflow <WORKFLOW_ID> — instance-scoped workflow commands."""

import json
import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _wid(ctx) -> str:
    return ctx.obj.get("_workflow_id", "") if ctx.obj else ""


# ---------------------------------------------------------------------------
# Root group — takes WORKFLOW_ID as positional argument
# ---------------------------------------------------------------------------

@click.group(name="workflow", invoke_without_command=True)
@click.argument("workflow_id", metavar="WORKFLOW_ID")
@click.pass_context
def workflow(ctx, workflow_id):
    """Manage a single workflow by ID.

    \b
    Examples:
      torana workflow <UUID> get
      torana workflow <UUID> execute
      torana workflow <UUID> update --name "New Name"
      torana workflow <UUID> delete --yes
    """
    ctx.ensure_object(dict)
    ctx.obj["_workflow_id"] = workflow_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


# ---------------------------------------------------------------------------
# Instance commands
# ---------------------------------------------------------------------------

@workflow.command(name="get")
@click.pass_context
def workflow_get(ctx):
    """Get details for this workflow.

    \b
    Examples:
      torana workflows list                    # find the id
      torana workflow <WORKFLOW_ID> get
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"enhanced-workflows/{_wid(ctx)}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workflow.command(name="update")
@click.option("--name", default=None, help="New workflow name.")
@click.option("--description", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE",
              help="Load updates from JSON/YAML file.")
@click.pass_context
def workflow_update(ctx, name, description, input_file):
    """Update this workflow."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if description:
        body["description"] = description

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"enhanced-workflows/{_wid(ctx)}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated workflow: {_wid(ctx)}")


@workflow.command(name="delete")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def workflow_delete(ctx, yes):
    """Delete this workflow."""
    _confirm(f"Delete workflow {_wid(ctx)}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"enhanced-workflows/{_wid(ctx)}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted workflow: {_wid(ctx)}")


@workflow.command(name="execute")
@click.option("--input", "input_data", default=None, metavar="JSON",
              help="JSON input for the workflow.")
@click.option("--input-file", default=None, metavar="FILE",
              help="Read input from file.")
@click.pass_context
def workflow_execute(ctx, input_data, input_file):
    """Execute this workflow.

    \b
    Example:
      torana workflow <UUID> execute --input '{"trigger": "manual"}'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    elif input_data:
        try:
            body = json.loads(input_data)
        except json.JSONDecodeError as exc:
            click.echo(f"ERROR: Invalid JSON in --input: {exc}", err=True)
            import sys
            sys.exit(6)

    client = _client(ctx)
    try:
        data = client.post(f"enhanced-workflows/{_wid(ctx)}/execute/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Executed workflow: {_wid(ctx)}")
        if isinstance(data, dict):
            for k, v in data.items():
                if k != "id":
                    click.echo(f"  {k}: {v}")


@workflow.command(name="publish")
@click.pass_context
def workflow_publish(ctx):
    """Publish this workflow."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"enhanced-workflows/{_wid(ctx)}/publish/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Published workflow: {_wid(ctx)}")


@workflow.command(name="archive")
@click.pass_context
def workflow_archive(ctx):
    """Archive this workflow."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"enhanced-workflows/{_wid(ctx)}/archive/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Archived workflow: {_wid(ctx)}")


@workflow.command(name="unpublish")
@click.pass_context
def workflow_unpublish(ctx):
    """Unpublish this workflow."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"enhanced-workflows/{_wid(ctx)}/unpublish"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workflow.command(name="clone")
@click.option("--name", default=None, help="Name for the cloned workflow.")
@click.pass_context
def workflow_clone(ctx, name):
    """Clone this workflow."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if name:
        body["name"] = name

    client = _client(ctx)
    try:
        data = client.post(f"enhanced-workflows/{_wid(ctx)}/clone/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Cloned workflow: {_wid(ctx)} → {data.get('id', 'unknown')}")


@workflow.command(name="export")
@click.pass_context
def workflow_export(ctx):
    """Export this workflow definition (legacy endpoint).

    \b
    Example:
      torana workflow <UUID> export > workflow.yaml
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get(f"workflows/{_wid(ctx)}/export/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt if fmt != "text" else "yaml")


@workflow.command(name="export-json")
@click.pass_context
def workflow_export_json(ctx):
    """Export this workflow as JSON."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"workflows/{_wid(ctx)}/export/json"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workflow.command(name="export-yaml")
@click.pass_context
def workflow_export_yaml(ctx):
    """Export this workflow as YAML."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"workflows/{_wid(ctx)}/export/yaml"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workflow.command(name="export-package")
@click.pass_context
def workflow_export_package(ctx):
    """Export this workflow as a package."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"workflows/{_wid(ctx)}/export/package"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workflow.command(name="suites-add")
@click.option("--suite-id", "suite_id", required=True, help="ID of the suite to add.")
@click.pass_context
def workflow_suites_add(ctx, suite_id):
    """Add a suite to this workflow."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"workflows/{_wid(ctx)}/suites"
    body = {"suite_id": suite_id}

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workflow.command(name="suites-remove")
@click.option("--suite-id", "suite_id", required=True, help="ID of the suite to remove.")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def workflow_suites_remove(ctx, suite_id, yes):
    """Remove a suite from this workflow."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"workflows/{_wid(ctx)}/suites/{suite_id}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@workflow.command(name="move")
@click.option("--target-workspace-id", "target_workspace_id", required=True)
@click.pass_context
def workflow_move(ctx, target_workspace_id):
    """Move this workflow to a different workspace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"workflows/{_wid(ctx)}/move"
    body = {"target_workspace_id": target_workspace_id}

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)
