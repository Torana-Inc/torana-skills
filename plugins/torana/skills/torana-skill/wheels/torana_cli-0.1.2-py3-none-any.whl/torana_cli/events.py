"""torana events — the platform event timeline.

Everything the platform did in a window: syncs, retirements, posture changes, deploys.
The CLI mirrors `GET /api/v1/events` 1:1, so every datum the API returns is printable
here (`--format json` emits the full envelope including facets and roll-up members).

`events` is a TOP-LEVEL group by design. The feed is tenant-scoped and spans
workspaces, so nesting it under `workspaces` would misdescribe its scope; it is a
first-class platform noun like `rules` or `integrations`.
"""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output

_LIST_COLS = [
    ("created_at", "WHEN", 20),
    ("line_type", "KIND", 7),
    ("producer", "SOURCE", 13),
    ("actor_kind", "BY", 9),
    ("severity", "SEV", 9),
    ("title", "WHAT HAPPENED", 60),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(name="events")
def events():
    """Platform event timeline — what the platform did, and when.

    \b
    Examples:
      torana events list
      torana events list --window 7d
      torana events list --producer etl_sync --severity critical
      torana events list --actor-kind user            # only human-triggered work
      torana events list --format json                # full envelope incl. members
    """


@events.command(name="list")
@click.option("--window", type=click.Choice(["1h", "6h", "24h", "7d"]),
              default=None, help="Preset window. Default: last 24h.")
@click.option("--since", default=None, help="Window start (ISO). Overrides --window.")
@click.option("--workspace", "workspace_id", default=None,
              help="Narrow to one workspace.")
@click.option("--producer", default=None,
              help="CSV: etl_sync,retirement,funnel_diff,graph_health,deploy")
@click.option("--line-type", default=None, help="CSV: delta,work,nudge")
@click.option("--severity", default=None, help="CSV: critical,high,none")
@click.option("--actor-kind", default=None, help="CSV: user,schedule,system")
@click.option("--tenant", "tenant_id", default=None,
              help="Super-admin only: read another tenant's events.")
@click.option("--limit", default=50, show_default=True, type=int)
@click.option("--cursor", default=None, help="Opaque pagination cursor.")
@click.pass_context
def events_list(ctx, window, since, workspace_id, producer, line_type, severity,
                actor_kind, tenant_id, limit, cursor):
    """List platform events, newest first.

    Repeated events collapse into one line with a x N badge; the count is per PAGE,
    not the group's total size. Use --format json to see the collapsed members.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {"limit": min(limit, 100)}
    for key, val in (
        ("window", window), ("since", since), ("workspace_id", workspace_id),
        ("producer", producer), ("line_type", line_type), ("severity", severity),
        ("actor_kind", actor_kind), ("tenant_id", tenant_id), ("cursor", cursor),
    ):
        if val:
            params[key] = val

    client = _client(ctx)
    try:
        data = client.get("events", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # json/yaml get the FULL envelope (facets, total, members, next_cursor) so the
    # CLI has zero gaps against the API.
    if fmt in ("json", "yaml") or raw:
        output(data, fmt=fmt, raw=raw, fields=fields)
        return

    items = data.get("items", []) if isinstance(data, dict) else []
    rows = []
    for it in items:
        title = it.get("title", "")
        n = it.get("rolled_up_count", 1)
        if n > 1:
            # "on this page" — a prefix cut partitions rows, not groups, so a group
            # can continue on the next page (see group_continues).
            title = f"{title}  x{n}{'+' if it.get('group_continues') else ''}"
        rows.append({
            **it,
            "title": title,
            # Blank, not the string "None" — most events carry no severity, and a
            # column of "None" reads as a value rather than an absence.
            "severity": it.get("severity") or "",
            "actor_kind": it.get("actor_kind") or "",
        })

    # `total` counts EVENTS in the window; `items` are collapsed LINES, so passing
    # total here would make the pager claim rows it will never show.
    output({"items": rows, "total": len(rows)},
           fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)

    if isinstance(data, dict) and fmt == "text":
        total = data.get("total", len(rows))
        if total != len(rows):
            # Facet counts are per-EVENT over the whole window; the list shows
            # collapsed LINES for this page. Saying so prevents "the chip says 9 but
            # I count 4" from reading as a bug.
            click.echo(f"\n  {len(rows)} line(s) shown · {total} event(s) in window")
        facets = data.get("facets") or {}
        if facets:
            click.echo("")
            for group in ("producer", "line_type", "severity", "actor_kind"):
                counts = facets.get(group) or {}
                if counts:
                    parts = "  ".join(f"{k}={v}" for k, v in sorted(counts.items()))
                    click.echo(f"  {group:11} {parts}")
        if data.get("next_cursor"):
            click.echo(f"\n  more: --cursor {data['next_cursor']}")
