"""torana namespaces — namespace management commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 30),
    ("slug", "SLUG", 25),
    ("tenant_id", "TENANT_ID", 36),
    ("is_default", "DEFAULT", 7),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group()
def namespaces():
    """Manage namespaces.

    \b
    Examples:
      torana namespaces list
      torana namespaces get <UUID>
      torana namespaces create --name engineering --slug eng
      torana namespaces delete <UUID> --yes
    """


@namespaces.command(name="list")
@click.option("--tenant-id", "tenant_id", default=None,
              help="List another tenant's namespaces (super-admin). Without it the "
                   "listing is scoped to the authenticated tenant.")
@click.option("--search", default=None, help="Search by name.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.pass_context
def namespaces_list(ctx, tenant_id, search, page, page_size, fetch_all):
    """List namespaces."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if tenant_id:
        params["tenant_id"] = tenant_id
    if search:
        params["search"] = search

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                p.update({k: v for k, v in params.items() if k not in ("skip", "limit")})
                data = client.get("namespaces/", params=p)
                items = data.get("items", data if isinstance(data, list) else [])
                all_items.extend(items)
                total = data.get("total", len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items), "page": 1,
                      "page_size": len(all_items)}
        else:
            data = client.get("namespaces/", params=params)
            result = data if isinstance(data, dict) and "items" in data else {
                "items": data if isinstance(data, list) else [],
                "total": len(data) if isinstance(data, list) else 0,
                "page": page, "page_size": effective_page_size
            }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@namespaces.command(name="get")
@click.argument("namespace_id", metavar="NAMESPACE_ID")
@click.pass_context
def namespaces_get(ctx, namespace_id):
    """Get details for a specific namespace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"namespaces/{namespace_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@namespaces.command(name="create")
@click.option("--name", default=None)
@click.option("--slug", default=None, help="Unique slug identifier.")
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def namespaces_create(ctx, name, slug, input_file):
    """Create a new namespace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if slug:
        body["slug"] = slug

    if not body.get("name"):
        click.echo("ERROR: --name is required.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post("namespaces/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created namespace: {data.get('id', 'unknown')}")
        click.echo(f"  Name: {data.get('name', '')}")


@namespaces.command(name="update")
@click.argument("namespace_id", metavar="NAMESPACE_ID")
@click.option("--name", default=None)
@click.option("--slug", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def namespaces_update(ctx, namespace_id, name, slug, input_file):
    """Update a namespace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if slug:
        body["slug"] = slug

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"namespaces/{namespace_id}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated namespace: {namespace_id}")


@namespaces.command(name="delete")
@click.argument("namespace_id", metavar="NAMESPACE_ID")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def namespaces_delete(ctx, namespace_id, yes):
    """Delete a namespace."""
    _confirm(f"Delete namespace {namespace_id}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"namespaces/{namespace_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted namespace: {namespace_id}")


@namespaces.command(name="quota-usage")
@click.argument("NAMESPACE_ID", metavar="NAMESPACE_ID")
@click.pass_context
def namespaces_quota_usage(ctx, namespace_id):
    """Get Namespace Quota Usage."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"namespaces/{namespace_id}/quota-usage"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)
