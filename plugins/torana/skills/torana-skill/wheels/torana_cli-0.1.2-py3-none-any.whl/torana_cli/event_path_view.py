"""The `path` section of `torana alert <id> view` as text: the event path the platform built (GET /alerts/{id}/view?section=path).

The platform builds the levels, the groups, the stuck flags and the words; this module only prints them. An entry prints
level 1 (its own events) and level 2 (its findings grouped by path, groups whose review is pending first); a finding prints level 3 (its
chain in time order) and the shared upstream steps it points at, once.
"""
from typing import Any, Callable, Dict, List

import click

#: The customer's neutral word for a review that did not finish recording (the platform retries it); never "stuck".
PENDING = "Review pending"


def _when(fmt: Callable[[Any], str], iso: Any) -> str:
    return fmt(iso) if iso else ""


def _step_line(st: Dict[str, Any], fmt: Callable[[Any], str], all_steps: bool = False) -> None:
    flag = f" · {st['flag'].replace('_', ' ')}" if st.get("flag") else ""
    status = f" [{st['status']}]" if st.get("status") else ""
    click.echo(f"    {_when(fmt, st.get('at')):<22} {st.get('label') or st.get('event') or '':<20}"
               f" {st.get('service') or ''} / {st.get('component') or ''}{status}{flag}")
    if st.get("text"):
        click.echo(f"      {st['text']}")
    extra = []
    if st.get("ref"):
        extra.append(f"shared: {st['ref']}")
    if st.get("jaeger_trace_id") or st.get("trace_id"):
        extra.append(f"trace: {st.get('jaeger_trace_id') or st.get('trace_id')}")
    if extra:
        click.echo(f"      ({' · '.join(extra)})")
    folded = st.get("folded") or []
    if folded and all_steps:
        for f in folded:
            _step_line(f, fmt)
    elif folded:
        runs = st.get("runs") or len(folded)
        click.echo(f"      ↳ its {runs} run{'s' if runs != 1 else ''}, step by step: add --all-reasons")


def _counts(d: Dict[str, int]) -> str:
    return " · ".join(f"{k.replace('_', ' ')} {v}" for k, v in sorted((d or {}).items(), key=lambda kv: -kv[1]))


def _print_entry(body: Dict[str, Any], fmt: Callable[[Any], str], all_groups: bool) -> None:
    entry = body.get("entry") or {}
    click.echo("  The entry")
    for st in entry.get("steps") or []:
        _step_line(st, fmt)
    m = entry.get("members") or {}
    span = " – ".join(x for x in (_when(fmt, m.get("first_joined_at")), _when(fmt, m.get("last_joined_at"))) if x)
    click.echo(f"    {m.get('total', 0)} findings in it ({m.get('joined_events', 0)} joins, {m.get('left_events', 0)} left"
               + (f"; {span}" if span else "") + ")")
    groups: List[Dict[str, Any]] = body.get("groups") or []
    click.echo("")
    stuck = body.get("stuck_members") or 0
    click.echo(f"  Paths its findings took ({len(groups)} groups" + (f"; {stuck} with the review pending" if stuck else "") + ")")
    shown = groups if all_groups else groups[:12]
    for g in shown:
        mark = "· " if g.get("stuck") else "  "
        click.echo(f"  {mark}{g.get('key')}  {g.get('count')} {g.get('state')}  {g.get('label')}")
        if g.get("stuck_text"):
            click.echo(f"        {PENDING}: {g['stuck_text']}")
        facts = [x for x in (f"verdict by: {_counts(g.get('by_verdict_source'))}" if g.get("by_verdict_source") else "",
                             f"closed as: {_counts(g.get('by_close_reason'))}" if g.get("by_close_reason") else "") if x]
        if facts:
            click.echo(f"        {' · '.join(facts)}")
        if g.get("example_id"):
            click.echo(f"        one of them: torana alert {g['example_id']} view --section path")
    if len(shown) < len(groups):
        click.echo(f"     … and {len(groups) - len(shown)} more groups (--all-reasons shows them; --format json has every group)")


def _print_finding(body: Dict[str, Any], fmt: Callable[[Any], str], all_steps: bool = False) -> None:
    if body.get("stuck_text"):
        click.echo(f"  {PENDING}. Details: {body['stuck_text']}")
    if body.get("parent_alert_id"):
        click.echo(f"  Part of entry {body['parent_alert_id']} (its path: torana alert {body['parent_alert_id']} view --section path)")
    for st in body.get("steps") or []:
        _step_line(st, fmt, all_steps)
    shared = body.get("shared") or {}
    if shared:
        click.echo("")
        click.echo("  Shared upstream (one step many findings point at, shown once)")
        for ref, s in shared.items():
            click.echo(f"    {ref}  rule {s.get('rule_name') or s.get('rule_id')} · {str(s.get('trigger') or '').lower()}"
                       f" · {s.get('signals', 0)} signals, {s.get('findings_created', 0)} new findings"
                       f" · {_when(fmt, s.get('enqueued_at'))} [{s.get('status')}]")


def print_path(body: Dict[str, Any], fmt: Callable[[Any], str], all_groups: bool = False) -> None:
    """Print the `path` section. `fmt` formats an ISO time in the reader's zone (the CLI's half of the date contract)."""
    if body.get("level") == "entry":
        _print_entry(body, fmt, all_groups)
    else:
        _print_finding(body, fmt, all_groups)
    for n in body.get("notes") or []:
        click.echo(f"  Note: {n}")
