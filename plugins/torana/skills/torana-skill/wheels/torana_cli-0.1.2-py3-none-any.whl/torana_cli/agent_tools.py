"""torana agent-tools — agent tool management commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 30),
    ("agent_id", "AGENT", 36),
    ("tool_type", "TYPE", 15),
    ("description", "DESCRIPTION", 40),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(name="agent-tools")
def agent_tools():
    """Manage agent tools.

    \b
    Examples:
      torana agent-tools list --agent-id <UUID>
      torana agent-tools get <UUID>
      torana agent-tools create --file tool.yaml
      torana agent-tools execute <UUID> --input '{"key": "value"}'
      torana agent-tools delete <UUID> --yes
    """


@agent_tools.command(name="list")
@click.option("--agent-id", default=None, help="Filter by agent UUID.")
@click.option("--search", default=None, help="Search by name.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def tools_list(ctx, agent_id, search, page, page_size):
    """List agent tools."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if agent_id:
        params["agent_id"] = agent_id
    if search:
        params["search"] = search

    client = _client(ctx)
    try:
        data = client.get("tools/", params=params)
        result = data if isinstance(data, dict) and "items" in data else {
            "items": data if isinstance(data, list) else [],
            "total": len(data) if isinstance(data, list) else 0,
            "page": page, "page_size": effective_page_size
        }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@agent_tools.command(name="get")
@click.argument("tool_id", metavar="TOOL_ID")
@click.pass_context
def tools_get(ctx, tool_id):
    """Get a specific agent tool."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"tools/{tool_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agent_tools.command(name="create")
@click.option("--name", default=None)
@click.option("--agent-id", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def tools_create(ctx, name, agent_id, input_file):
    """Create a new agent tool."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if agent_id:
        body["agent_id"] = agent_id

    if not body.get("name"):
        click.echo("ERROR: --name is required.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post("tools/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created tool: {data.get('id', 'unknown')}")


@agent_tools.command(name="update")
@click.argument("tool_id", metavar="TOOL_ID")
@click.option("--name", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def tools_update(ctx, tool_id, name, input_file):
    """Update an agent tool."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"tools/{tool_id}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated tool: {tool_id}")


@agent_tools.command(name="delete")
@click.argument("tool_id", metavar="TOOL_ID")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def tools_delete(ctx, tool_id, yes):
    """Delete an agent tool."""
    _confirm(f"Delete tool {tool_id}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"tools/{tool_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted tool: {tool_id}")


@agent_tools.command(name="execute")
@click.argument("tool_id", metavar="TOOL_ID")
@click.option("--input", "input_data", default=None, metavar="JSON",
              help="JSON input for the tool execution.")
@click.option("--input-file", default=None, metavar="FILE",
              help="Read input from file (use '-' for stdin).")
@click.pass_context
def tools_execute(ctx, tool_id, input_data, input_file):
    """Execute an agent tool.

    \b
    Examples:
      torana agent-tools execute <UUID> --input '{"query": "critical vulns"}'
      torana agent-tools execute <UUID> --input-file params.json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    elif input_data:
        import json
        try:
            body = json.loads(input_data)
        except json.JSONDecodeError as exc:
            click.echo(f"ERROR: Invalid JSON in --input: {exc}", err=True)
            import sys
            sys.exit(6)

    client = _client(ctx)
    try:
        data = client.post(f"tools/{tool_id}/execute/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        if isinstance(data, dict):
            result = (
                data.get("result") or data.get("output")
                or data.get("response") or data.get("data")
            )
            if result is not None:
                if isinstance(result, str):
                    click.echo(result)
                else:
                    import json
                    click.echo(json.dumps(result, indent=2, default=str))
            else:
                import json
                click.echo(json.dumps(data, indent=2, default=str))
        else:
            click.echo(str(data))


@agent_tools.command(name="validate")
@click.argument("tool_id", metavar="TOOL_ID")
@click.pass_context
def tools_validate(ctx, tool_id):
    """Validate an agent tool configuration."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"tools/{tool_id}/validate/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        if isinstance(data, dict):
            valid = data.get("valid", data.get("status", "unknown"))
            click.echo(f"Tool {tool_id}: {valid}")
            for k, v in data.items():
                if k not in ("valid", "status"):
                    click.echo(f"  {k}: {v}")
        else:
            click.echo(str(data))


@agent_tools.command(name="providers")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def tools_providers(ctx, page, page_size, fetch_all):
    """List Providers."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "tools/providers"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@agent_tools.command(name="api-groups")
@click.argument("PROVIDER_ID", metavar="PROVIDER_ID")
@click.pass_context
def tools_api_groups(ctx, provider_id):
    """Get Provider Api Groups."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"tools/providers/{provider_id}/api-groups"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agent_tools.command(name="agents")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def tools_agents(ctx, page, page_size, fetch_all):
    """List Agent Tools."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "tools/agents"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@agent_tools.command(name="functions")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def tools_functions(ctx, page, page_size, fetch_all):
    """List Function Tools."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "tools/functions"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@agent_tools.command(name="search")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--search", "search", default=None)
@click.option("--capabilities", "capabilities", default=None)
@click.option("--tags", "tags", default=None)
@click.option("--api-group-id", "api_group_id", default=None)
@click.option("--status", "status", default=None)
@click.option("--authentication-type", "authentication_type", default=None)
@click.option("--is-public", "is_public", default=None)
@click.pass_context
def tools_search(ctx, search, capabilities, tags, api_group_id, status, authentication_type, is_public, page, page_size, fetch_all):
    """Search Apis."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "tools/apis/search"
    params = {}
    if search is not None:
        params["search"] = search
    if capabilities is not None:
        params["capabilities"] = capabilities
    if tags is not None:
        params["tags"] = tags
    if api_group_id is not None:
        params["api_group_id"] = api_group_id
    if status is not None:
        params["status"] = status
    if authentication_type is not None:
        params["authentication_type"] = authentication_type
    if is_public is not None:
        params["is_public"] = is_public
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@agent_tools.command(name="by-service-type-by-service-type")
@click.argument("SERVICE_TYPE", metavar="SERVICE_TYPE")
@click.pass_context
def tools_by_service_type_by_service_type(ctx, service_type):
    """Get Apis By Service Type."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"tools/apis/by-service-type/{service_type}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agent_tools.command(name="validate-ref")
@click.option("--input-file", "-f", default=None, help="JSON/YAML body for validation.")
@click.pass_context
def tools_validate_ref(ctx, input_file):
    """Validate a tool reference (no tool ID required)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = {}
    if input_file:
        body = _load_input_file(input_file)

    client = _client(ctx)
    try:
        data = client.post("tools/validate", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@agent_tools.command(name="run")
@click.option("--input-file", "-f", default=None, help="JSON/YAML body with tool execution input.")
@click.option("--input", "input_data", default=None, help="JSON string with execution input.")
@click.pass_context
def tools_run(ctx, input_file, input_data):
    """Execute a tool without specifying a tool ID (POST /api/v1/tools/execute)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    elif input_data:
        import json
        body = json.loads(input_data)

    client = _client(ctx)
    try:
        data = client.post("tools/execute", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)
