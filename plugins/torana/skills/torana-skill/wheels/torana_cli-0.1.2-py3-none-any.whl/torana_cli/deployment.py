"""torana deployment <id> — instance ops for one Deployment (EM Deployment_Object_and_
Runtime_Provenance.md § 3.5.1).

Singular/instance group per the CLI plural/singular rule. Collection ops (create/list/
test-connection/exposure-intelligence) live in the plural `deployments` group.

  deployment <id> get
  deployment <id> update [--internet-facing/...] [--criticality ...] ...
  deployment <id> delete
  deployment <id> status
  deployment <id> workloads
  deployment <id> sync
"""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import (
    APIError,
    ToranaClient,
    handle_api_error,
    handle_auth_error,
)
from torana_cli.config.settings import get_settings
from torana_cli.deployments import DEPLOYMENT_COLS, parse_json_opt
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output


_WORKLOAD_COLS = [
    ("service_name", "SERVICE", 22),
    ("service_application", "ENV", 10),
    ("container_image_id", "IMAGE", 44),
    ("public_access", "PUBLIC", 7),
    ("criticality_name", "CRIT", 9),
    ("asset_owner", "OWNER", 16),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    return ToranaClient(base_url=get_settings(profile).base_url)


def _ctx(ctx):
    return (
        ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text",
        ctx.obj.get(CTX_RAW, False) if ctx.obj else False,
        ctx.obj.get(CTX_FIELDS) if ctx.obj else None,
    )


def _did(ctx) -> str:
    return ctx.obj.get("_deployment_id", "") if ctx.obj else ""


# ─── singular instance group ────────────────────────────────────────────────────

@click.group(name="deployment", invoke_without_command=True)
@click.argument("deployment_id", metavar="DEPLOYMENT_ID")
@click.pass_context
def deployment(ctx, deployment_id):
    """Operate on ONE deployment by id.

    \b
    A deployment owns a bound integration — so `delete` removes both, and `update`
    on its governance fires the graph repaint. Use `torana deployments list` to
    find the id.

    \b
    Examples:
      torana deployments list                        find the id
      torana deployment <DEPLOYMENT_ID> get
      torana deployment <DEPLOYMENT_ID> status       bound-integration sync health
      torana deployment <DEPLOYMENT_ID> workloads    observed service nodes
      torana deployment <DEPLOYMENT_ID> sync         on-demand cluster sync
    """
    ctx.ensure_object(dict)
    ctx.obj["_deployment_id"] = deployment_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@deployment.command(name="get")
@click.pass_context
def get(ctx):
    """Get this deployment."""
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.get(f"deployments/{_did(ctx)}")
    except AuthError as e:
        handle_auth_error(e); return
    except APIError as e:
        handle_api_error(e); return
    output(data, fmt=fmt, raw=raw, fields=fields, columns=DEPLOYMENT_COLS)


@deployment.command(name="update")
@click.option("--description", default=None, help="Update description.")
@click.option("--internet-facing/--no-internet-facing", "internet_facing", default=None,
              help="Update internet-facing governance.")
@click.option("--has-customer-data/--no-customer-data", "has_customer_data", default=None,
              help="Update customer-data governance.")
@click.option("--criticality", default=None,
              type=click.Choice(["low", "medium", "high", "critical"]), help="Update criticality.")
@click.option("--owner", default=None, help="Update accountable owner (person/handle).")
@click.option("--team", default=None,
              help="Update owning team (org unit) — feeds assets.asset_team.")
@click.option("--provenance-label-map", default=None, help="JSON per-field OCI label-key overrides.")
@click.pass_context
def update(ctx, description, internet_facing, has_customer_data, criticality, owner, team,
           provenance_label_map):
    """Update this deployment's governance (fires the graph repaint job)."""
    fmt, raw, fields = _ctx(ctx)
    body = {}
    if description is not None:
        body["description"] = description
    if internet_facing is not None:
        body["internet_facing"] = internet_facing
    if has_customer_data is not None:
        body["has_customer_data"] = has_customer_data
    if criticality is not None:
        body["criticality"] = criticality
    if owner is not None:
        body["owner"] = owner
    if team is not None:
        body["team"] = team
    if provenance_label_map is not None:
        body["provenance_label_map"] = parse_json_opt(provenance_label_map, "--provenance-label-map")
    if not body:
        raise click.UsageError("Nothing to update — pass at least one field.")
    client = _client(ctx)
    try:
        data = client.put(f"deployments/{_did(ctx)}", json=body)
    except AuthError as e:
        handle_auth_error(e); return
    except APIError as e:
        handle_api_error(e); return
    output(data, fmt=fmt, raw=raw, fields=fields, columns=DEPLOYMENT_COLS)


@deployment.command(name="delete")
@click.pass_context
def delete(ctx):
    """Soft-delete this deployment (+ its bound integration)."""
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.delete(f"deployments/{_did(ctx)}")
    except AuthError as e:
        handle_auth_error(e); return
    except APIError as e:
        handle_api_error(e); return
    output(data or {"status": "deleted", "id": _did(ctx)}, fmt=fmt, raw=raw, fields=fields)


@deployment.command(name="status")
@click.pass_context
def status(ctx):
    """Show this deployment's bound-integration sync status / health."""
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.get(f"deployments/{_did(ctx)}/status")
    except AuthError as e:
        handle_auth_error(e); return
    except APIError as e:
        handle_api_error(e); return
    output(data, fmt=fmt, raw=raw, fields=fields)


@deployment.command(name="workloads")
@click.option("--limit", type=click.IntRange(1, 100), default=100,
              help="Page size (max 100).")
@click.option("--offset", type=click.IntRange(min=0), default=0,
              help="Rows to skip for paging.")
@click.pass_context
def workloads(ctx, limit, offset):
    """List this deployment's observed workloads (service nodes) + governance/exposure.

    Paginated — a real cluster has many workloads. Use --limit/--offset to page;
    `total` in the envelope is the full count.
    """
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.get(f"deployments/{_did(ctx)}/workloads",
                          params={"limit": limit, "offset": offset})
    except AuthError as e:
        handle_auth_error(e); return
    except APIError as e:
        handle_api_error(e); return
    page_size = data.get("limit", limit) or limit
    off = data.get("offset", offset) or 0
    data = {"items": data.get("workloads", []),
            "total": data.get("total", data.get("count", 0)),
            "page": (off // page_size) + 1 if page_size else 1,
            "page_size": page_size}
    output(data, fmt=fmt, raw=raw, fields=fields, columns=_WORKLOAD_COLS)


@deployment.command(name="sync")
@click.pass_context
def sync(ctx):
    """Trigger an on-demand sync of this deployment's cluster."""
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.post(f"deployments/{_did(ctx)}/sync", json={})
    except AuthError as e:
        handle_auth_error(e); return
    except APIError as e:
        handle_api_error(e); return
    output(data, fmt=fmt, raw=raw, fields=fields)
