"""
Settings — reads from ~/.torana/config.yaml and environment variables.

Precedence (connection):
  1. TORANA_BASE_URL env var
  2. Active profile base_url in config.yaml
  3. Default: http://localhost

Precedence (auth): handled in client/auth.py
"""

import os
from functools import lru_cache
from pathlib import Path
from typing import Optional

import yaml

CONFIG_DIR = Path.home() / ".torana"
CONFIG_FILE = CONFIG_DIR / "config.yaml"

DEFAULT_PROFILE = {
    "base_url": "http://localhost",
    "email": "",
    "format": "text",
    "log_level": "info",
    "log_format": "text",
    "log_file": str(Path.home() / ".torana" / "logs" / "torana-cli.log"),
    "page_size": 50,
}


def _load_config_file() -> dict:
    """Load config.yaml. Returns empty dict if missing."""
    if not CONFIG_FILE.exists():
        return {}
    try:
        return yaml.safe_load(CONFIG_FILE.read_text()) or {}
    except Exception:
        return {}


def _save_config_file(config: dict) -> None:
    """Write config.yaml, creating the directory if needed."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(yaml.dump(config, default_flow_style=False))
    CONFIG_FILE.chmod(0o600)


class Settings:
    """Resolved CLI settings for the current invocation."""

    def __init__(self, profile_name: Optional[str] = None):
        config = _load_config_file()
        active = profile_name or os.environ.get("TORANA_PROFILE") or config.get(
            "active_profile", "default"
        )
        profiles = config.get("profiles", {})
        profile = profiles.get(active, {})

        # Merge: defaults ← profile
        merged = {**DEFAULT_PROFILE, **profile}

        # Connection: env var overrides all
        self.base_url: str = os.environ.get("TORANA_BASE_URL") or merged["base_url"]
        self.active_profile: str = active

        # Output
        self.format: str = merged.get("format", "text")
        self.page_size: int = int(merged.get("page_size", 50))

        # Logging
        self.log_level: str = merged.get("log_level", "info")
        self.log_format: str = merged.get("log_format", "text")
        self.log_file: str = merged.get("log_file", DEFAULT_PROFILE["log_file"])

        # Email (for display / auto-login hint)
        self.email: str = merged.get("email", "")


@lru_cache(maxsize=1)
def get_settings(profile_name: Optional[str] = None) -> Settings:
    """Return cached Settings instance. Call invalidate_settings() after config changes."""
    return Settings(profile_name)


def invalidate_settings() -> None:
    """Clear settings cache so the next call re-reads config.yaml."""
    get_settings.cache_clear()


# ── Profile management ─────────────────────────────────────────────────────────

def list_profiles() -> dict:
    """Return {name: profile_dict} for all profiles."""
    config = _load_config_file()
    profiles = config.get("profiles", {})
    if not profiles:
        profiles = {"default": dict(DEFAULT_PROFILE)}
    return profiles


def get_active_profile_name() -> str:
    config = _load_config_file()
    return config.get("active_profile", "default")


def resolve_profile_name(profile_name: Optional[str] = None) -> str:
    """Resolve the effective profile name for this invocation.

    Same precedence as Settings.__init__ uses to pick the active profile:
      1. explicit profile_name (e.g. --profile)
      2. TORANA_PROFILE env var
      3. active_profile in config.yaml
      4. "default"

    Used to key the per-profile token cache so each profile keeps its own
    cached session and switching profiles never forces a re-login.
    """
    if profile_name:
        return profile_name
    config = _load_config_file()
    return os.environ.get("TORANA_PROFILE") or config.get("active_profile", "default")


def activate_profile(name: str) -> None:
    """Set the active_profile in config.yaml."""
    config = _load_config_file()
    profiles = config.get("profiles", {})
    if name != "default" and name not in profiles:
        raise ValueError(f"Profile '{name}' does not exist. Create it first.")
    config["active_profile"] = name
    _save_config_file(config)
    invalidate_settings()


def create_profile(name: str, base_url: str, email: str = "", **kwargs) -> None:
    """Create or replace a named profile."""
    config = _load_config_file()
    if "profiles" not in config:
        config["profiles"] = {}
    profile = dict(DEFAULT_PROFILE)
    profile["base_url"] = base_url
    if email:
        profile["email"] = email
    profile.update(kwargs)
    config["profiles"][name] = profile
    _save_config_file(config)
    invalidate_settings()


def delete_profile(name: str) -> None:
    """Delete a named profile (cannot delete 'default')."""
    if name == "default":
        raise ValueError("Cannot delete the default profile.")
    config = _load_config_file()
    profiles = config.get("profiles", {})
    if name not in profiles:
        raise ValueError(f"Profile '{name}' does not exist.")
    del profiles[name]
    if config.get("active_profile") == name:
        config["active_profile"] = "default"
    config["profiles"] = profiles
    _save_config_file(config)
    invalidate_settings()


def set_config_value(key: str, value: str, profile_name: Optional[str] = None) -> None:
    """Set a single config key in the active (or named) profile."""
    config = _load_config_file()
    active = profile_name or config.get("active_profile", "default")
    if "profiles" not in config:
        config["profiles"] = {}
    if active not in config["profiles"]:
        config["profiles"][active] = dict(DEFAULT_PROFILE)
    config["profiles"][active][key.replace("-", "_")] = value
    _save_config_file(config)
    invalidate_settings()


def get_config_value(key: str, profile_name: Optional[str] = None) -> Optional[str]:
    """Get a single config key from the active (or named) profile."""
    config = _load_config_file()
    active = profile_name or config.get("active_profile", "default")
    profile = config.get("profiles", {}).get(active, {})
    normalized = key.replace("-", "_")
    return profile.get(normalized) or DEFAULT_PROFILE.get(normalized)
