"""Configuration layer for Torana CLI."""
