"""torana atlas code <PATH> overview|entries|libraries|place|flow|path|search — walk one repository's code in Atlas.

Free and model-less: every verb is a GET over the node's code index: its latest code snapshot, or --snapshot K / --version N
(CODE_WALKER.md § 3.4.5, MODEL_FREE_SNAPSHOTS.md OI-180). PATH is the
repository node's path (`code/acme/api`). Every text renderer prints the API's own words (possible, entry (by name
only), file level, not recorded yet, imported in N files): the claims are written by the service, never here.
`--json` prints the raw response.
"""

import click

from torana_cli.atlas import _call, _client, _fmt, state_line
from torana_cli.atlas_node import tenant_option
from torana_cli.output import output

GLYPH = {"function": "ƒ", "file": "▤", "folder": "▣", "entry": "▶", "import_site": "▤", "count": "#", "note": "○",
         "Third-party": "◆", "Ours": "◈", "Built-in": "◇"}
KIND_GLYPH = {"third_party": "◆", "ours": "◈", "builtin": "◇"}
KIND_WORD = {"third_party": "Third-party", "ours": "Ours", "builtin": "Built-in", "route": "API route",
             "cli": "CLI command", "main": "Script", "task": "Background task"}
#: CODE_WALKER.md § 3.3.6: the display words of `LibraryRow.mapping` (the FE shows the same).
MAPPING_WORDS = {"first_party": "ours", "measured": "measured", "wheel_metadata": "from the package's metadata",
                 "convention": "guessed from the package name", "stdlib": "built-in"}
POSSIBLE = "?~ possible"
REASON_WORDS = {"several_definitions": "several functions share the name",
                "test_file_target": "the only target is a test file",
                "receiver_unknown": "what the call is made on is unknown"}


def _path(ctx) -> str:
    return (ctx.obj.get("_atlas_code_path", "") if ctx.obj else "").strip("/")


def _keep_snapshot(ctx, _param, value):
    if value is not None:
        ctx.ensure_object(dict)
        ctx.obj["_atlas_code_snapshot"] = value
    return value


def _version_opt(f):
    """--version N or --snapshot K (OI-180: the walker reads the latest code snapshot by default)."""
    f = click.option("--snapshot", type=click.IntRange(min=1), default=None, metavar="K", expose_value=False,
                     callback=_keep_snapshot,
                     help="A code snapshot of the node (default: the latest). Exclusive with --version.")(f)
    return click.option("--version", "version", type=int, default=None, metavar="N",
                        help="A written skill version of the node (its code snapshot, else its own index).")(f)


def _get(ctx, op: str, version: int | None, **params) -> dict:
    q = {"node": _path(ctx), **{k: v for k, v in params.items() if v is not None and v is not False}}
    snapshot = ctx.obj.get("_atlas_code_snapshot") if ctx.obj else None
    if version is not None and snapshot is not None:
        raise click.UsageError("--version and --snapshot are exclusive: a skill version or a code snapshot")
    if version is not None:
        q["version"] = version
    if snapshot is not None:
        q["snapshot"] = snapshot
    tenant = ctx.obj.get("_atlas_tenant") if ctx.obj else None
    if tenant:
        q["tenant"] = tenant
    return _call(_client(ctx).get, f"atlas/code/{op}", params=q)


def _emit(ctx, data, render) -> None:
    fmt, _, _ = _fmt(ctx)
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt)
        return
    click.echo(render(data, _path(ctx)))


def _n(count, one: str) -> str:
    count = count or 0
    return f"{count:,} {one}{'' if count == 1 else 's'}"


def _cmd(path: str) -> str:
    return f"torana atlas code {path}"


def _header(node: dict) -> str:
    """`◉ path · snapshot 3 · commit abc1234` (OI-180; `version N` from a server without snapshots or a legacy
    version's own index), then the server's Skill line when it sends one."""
    commit = (node.get("commit") or "")[:7] or "commit not known"
    source = (f"snapshot {node['snapshot']}" if node.get("snapshot") else f"version {node.get('version')}")
    out = f"◉ {node.get('path')} · {source} · commit {commit}"
    if node.get("current") is False:
        out += " · older snapshot" if node.get("snapshot") else " · older version"
    if (node.get("index_format") or 1) < 2:
        out += " · built before the current index"
    skill = state_line("Skill", node.get("skill"))
    return out + (f"\n{skill}" if skill else "")


def _place_cmd(path: str, ref: dict | None) -> str:
    """The command that opens a ref. ⛔ The service root is `place --kind folder`, never `--id ""` (R1-B4)."""
    if not ref:
        return ""
    kind, ident = ref.get("kind"), ref.get("id") or ""
    if kind == "entries":
        return f"{_cmd(path)} entries --kind {ident}" if ident else f"{_cmd(path)} entries"
    if kind == "libraries":
        return f"{_cmd(path)} libraries"
    if kind == "folder" and not ident:
        return f"{_cmd(path)} place --kind folder"
    return f"{_cmd(path)} place --kind {kind} --id {_quote(ident)}"


def _quote(s: str) -> str:
    return f"'{s}'" if any(c in s for c in " :@$()") else s


# ── renderers (pure: a response dict in, text out) ───────────────────────────

def render_overview(d: dict, path: str) -> str:
    e, c, lib, q = d.get("entries") or {}, d.get("code") or {}, d.get("libraries") or {}, d.get("quality") or {}
    lines = [_header(d.get("node") or {}), "",
             f"Entry points: {_n(e.get('route'), 'API route')} · {_n(e.get('cli'), 'CLI command')} · "
             f"{_n(e.get('main'), 'script')} · {_n(e.get('task'), 'background task')}"
             + (f" · {e['by_name_only']} entry (by name only)" if e.get("by_name_only") else ""),
             f"Code: {_n(c.get('folders'), 'folder')} · {_n(c.get('files'), 'file')} · "
             f"{_n(c.get('functions'), 'function')}",
             f"Libraries: {lib.get('third_party') or 0:,} third-party · {lib.get('ours') or 0:,} ours · "
             f"{lib.get('builtin') or 0:,} built-in · {lib.get('declared_never_imported') or 0:,} declared, no import found",
             f"Calls: {_n(q.get('call_sites'), 'call site')} · {q.get('resolved') or 0:,} resolve here · "
             f"{q.get('certain') or 0:,} certain · {q.get('possible') or 0:,} possible", ""]
    if d.get("sentences"):
        lines.append("Data quality, in words:")
        lines += [f"  · {s}" for s in d["sentences"]]
        lines.append("")
    lines += [f"Next: {_cmd(path)} entries · {_cmd(path)} place --kind folder · {_cmd(path)} libraries"]
    return "\n".join(lines)


def _route_where(it: dict) -> str:
    if it.get("kind") != "route":
        return ""
    method = it.get("method") or "?"
    if it.get("full_paths"):
        return f"{method} {', '.join(it['full_paths'])} (the full URL may be longer)"
    if it.get("path"):
        return f"{method} {(it.get('router_prefix') or '') + it['path']}"
    return f"{method} path not known"


def _pager(d: dict, path: str, verb: str) -> str:
    total, page, size = d.get("total", 0), d.get("page", 1), d.get("page_size", 50)
    pages = max(1, -(-total // size)) if size else 1
    out = f"{total} total · page {page} of {pages}"
    if page < pages:
        out += f" · next: {_cmd(path)} {verb} --page {page + 1} --page-size {size}"
    return out


def render_entries(d: dict, path: str) -> str:
    rows = []
    for it in d.get("items") or ():
        fn = it.get("fn") or {}
        tag = "entry (by name only)" if it.get("by_name_only") else ""
        rows.append((KIND_WORD.get(it.get("kind"), it.get("kind") or ""), _route_where(it) or "—", fn.get("name", ""),
                     f"{fn.get('file')}:{fn.get('line')}", tag))
    if not rows:
        return "No entry points found." + ("\n" + _pager(d, path, "entries") if d.get("total") else "")
    return _table(("KIND", "METHOD PATH", "FUNCTION", "FILE:LINE", ""), rows) + "\n" + _pager(d, path, "entries")


def render_libraries(d: dict, path: str) -> str:
    rows, opens = [], []
    for r in d.get("items") or ():
        kind = r.get("kind") or "third_party"
        n = r.get("imported_in_files", 0)
        imported = f"imported in {n} file{'s' if n != 1 else ''}" + (" (lock only)" if r.get("lock_only") else "")
        rows.append((r.get("name", ""), f"{KIND_GLYPH.get(kind, '')} {KIND_WORD.get(kind, kind)}",
                     r.get("version") or "no lock read", ", ".join(r.get("declared") or ()) or "—", imported,
                     MAPPING_WORDS.get(r.get("mapping"), r.get("mapping") or "")))
        if r.get("open_node"):
            opens.append(f"  {r['name']}: {_cmd(r['open_node'])} overview")
    if not rows:
        return "No libraries found."
    out = _table(("NAME", "KIND", "VERSION", "DECLARED", "IMPORTED IN", "MAPPING"), rows) + "\n" + \
        _pager(d, path, "libraries")
    if opens:
        out += "\nOpen this service:\n" + "\n".join(opens)
    return out


def _item_line(it: dict) -> str:
    glyph = GLYPH.get(it.get("kind_word")) if it.get("type") == "library" else GLYPH.get(it.get("type"), "·")
    parts = [f"{glyph or '·'} {it.get('label', '')}"]
    if it.get("type") == "library" and it.get("kind_word"):
        parts[0] += f" ({it['kind_word']})"
    if it.get("file") and it.get("line") and it.get("type") not in ("import_site",):
        parts.append(f"{it['file']}:{it['line']}")
    if it.get("count") is not None and it.get("type") in ("count", "folder", "function", "file"):
        cc, pc = it.get("certain_count"), it.get("possible_count")
        if cc is not None or pc is not None:
            parts.append(f"{it['count']} calls ({cc or 0} certain, {pc or 0} possible)")
        elif it.get("type") == "count":
            parts.append(str(it["count"]))
    if it.get("certain") is False:
        why = REASON_WORDS.get(it.get("possible_reason"))
        parts.append(POSSIBLE + (f": {why}" if why else ""))
    tags = [t for t in it.get("tags") or () if t != "possible"]
    if tags:
        parts.append("[" + ", ".join(tags) + "]")
    return "  ".join(parts)


def render_place(d: dict, path: str) -> str:
    what = d.get("what") or {}
    place = d.get("place") or {}
    lines = [_header(d.get("node") or {}), "",
             f"{what.get('glyph', '')} {what.get('kind_word', '')}: {what.get('name', '')}   {what.get('where', '')}",
             f"  {what.get('summary', '')}"]
    if what.get("quote"):
        lines.append(f"  {what['quote']}")
    if what.get("full_paths"):
        lines.append(f"  {what.get('method') or '?'} {', '.join(what['full_paths'])} (the full URL may be longer)")
    for n in d.get("notes") or ():
        lines.append(f"  ○ {n}")
    if what.get("open_node"):
        lines.append(f"  Open this service: {_cmd(what['open_node'])} overview")
    base = _place_cmd(path, place)
    for group, title in (("reached_by", "How it's reached"), ("uses", "What it uses"), ("inside", "What's inside")):
        secs = d.get(group) or []
        if not secs:
            continue
        lines += ["", f"## {title}"]
        for s in secs:
            lines.append(f"{s.get('title')} ({s.get('total', 0)})")
            if not s.get("items"):
                lines.append(f"  {s.get('empty_text') or 'Nothing here.'}")
            for it in s.get("items") or ():
                lines.append("  " + _item_line(it))
            if s.get("more"):
                shown = len(s.get("items") or ())
                rest = s.get("total", 0) - shown
                lines.append(f"  … {rest} more ({base} --section {s['key']} --offset {shown})")
    g = d.get("graph")
    if g:
        lines += ["", "## Graph (left calls right)" + (" · capped" if g.get("capped") else "")]
        cols: dict[int, list[str]] = {}
        for n in g.get("nodes") or ():
            cols.setdefault(n.get("column", 0), []).append(n.get("label", ""))
        for c in sorted(cols):
            lines.append(f"  column {c}: " + " · ".join(cols[c]))
        for e in g.get("edges") or ():
            lines.append(f"  {e['a']} → {e['b']}  {e.get('certain', 0)} certain, {e.get('possible', 0)} possible")
    return "\n".join(lines)


def _flow_tree(nodes: list[dict]) -> dict[int, list[int]]:
    """Children by node index. A node's parent is the earliest node at depth - 1 with that function id that still
    has room (BFS order: a parent always comes first; one function can appear on two branches)."""
    kids: dict[int, list[int]] = {}
    for i, n in enumerate(nodes[1:], start=1):
        for j in range(i):
            p = nodes[j]
            if ((p.get("fn") or {}).get("id") == n.get("parent") and p.get("depth", 0) == n.get("depth", 0) - 1
                    and len(kids.get(j, [])) < (p.get("children_shown") or 0)):
                kids.setdefault(j, []).append(i)
                break
    return kids


def render_flow(d: dict, path: str) -> str:
    nodes = d.get("nodes") or []
    kids = _flow_tree(nodes)
    lines = [_header(d.get("node") or {}), ""]
    if d.get("truncated"):
        lines.append(f"Showing the first {len(nodes)} steps.")

    def walk(i: int, indent: int) -> None:
        n = nodes[i]
        fn = n.get("fn") or {}
        words = []
        if n.get("certain") is False:
            why = REASON_WORDS.get(n.get("possible_reason"))
            words.append(POSSIBLE + (f": {why}" if why else ""))
        if n.get("loop"):
            words.append("↺ already above")
        if fn.get("by_name_only"):
            words.append("entry (by name only)")
        lines.append("  " * indent + f"{'▶' if fn.get('entry_kind') else 'ƒ'} {fn.get('name')}  "
                     f"{fn.get('file')}:{fn.get('line')}" + (f"  {'  '.join(words)}" if words else ""))
        for lc in n.get("lib_calls") or ():
            attr = f".{lc['attr']}" if lc.get("attr") else ""
            lines.append("  " * (indent + 1) + f"↳ {lc.get('module')}{attr}  ({lc.get('library')})")
        for c in kids.get(i, []):
            walk(c, indent + 1)
        hidden = (n.get("children_total") or 0) - (n.get("children_shown") or 0)
        if hidden > 0 and not n.get("loop"):
            more = "--max-children 100" if n.get("children_shown") else "--depth 2"
            lines.append("  " * (indent + 1) + f"+{hidden} more calls ({_cmd(path)} flow --function "
                                               f"{_quote(fn.get('id', ''))} {more})")

    if nodes:
        walk(0, 0)
    if d.get("lib_calls_recorded") is False:
        lines += ["", "Library calls per function: not recorded yet"]
    ends = d.get("libraries_at_ends") or []
    if ends:
        lines += ["", "Libraries at the ends (file level):"]
        for e in ends:
            files = e.get("files")
            n = len(files) if isinstance(files, list) else (files or 0)
            lines.append(f"  {KIND_GLYPH.get(e.get('kind'), '◆')} {e.get('name')}  in {n} file{'s' if n != 1 else ''}")
    return "\n".join(lines)


def render_path(d: dict, path: str) -> str:
    lines = [_header(d.get("node") or {}), ""]
    for i, h in enumerate(d.get("chain") or ()):
        fn = h.get("fn") or {}
        lines.append(f"{i + 1}. {'▶' if i == 0 else 'ƒ'} {fn.get('name')}  {fn.get('file')}:{fn.get('line')}"
                     + ("" if h.get("certain", True) else f"  {POSSIBLE}"))
    lines.append(d.get("sentence") or "")
    return "\n".join(lines)


def render_search(d: dict, path: str) -> str:
    rows = []
    for it in d.get("items") or ():
        where = f"{it['file']}:{it['line']}" if it.get("file") and it.get("line") else (it.get("file") or "")
        rows.append((it.get("kind_word") or it.get("type", ""), it.get("label", ""), where, _place_cmd(path, it.get("ref"))))
    if not rows:
        return f"Nothing matches {d.get('q')!r}."
    out = _table(("TYPE", "NAME", "WHERE", "OPEN"), rows)
    if d.get("more"):
        out += f"\n{d.get('total')} matches; showing {len(rows)} (--limit up to 100)"
    return out


def _table(head: tuple, rows: list[tuple]) -> str:
    widths = [max(len(str(x)) for x in col) for col in zip(head, *rows)]
    fmt = "  ".join(f"{{:<{w}}}" for w in widths)
    return "\n".join(fmt.format(*map(str, r)).rstrip() for r in [head, *rows])


# ── commands ──────────────────────────────────────────────────────────────────

@click.group(name="code", invoke_without_command=True)
@click.argument("node_path", metavar="PATH")
@click.pass_context
def atlas_code(ctx, node_path):
    """Walk a repository's code: entry points, folders, files, functions, libraries. Free, no model.

    Reads Atlas's stored code index of the repository node PATH (needs atlas:read; --tenant is SA only).
    Calls that may go to several functions are marked `?~ possible`; libraries say what the code imports
    ("imported in N files"), never whether a library is used.

    \b
    Examples:
      torana atlas code code/acme/api overview
      torana atlas code code/acme/api entries --kind route
      torana atlas code code/acme/api place --kind folder                 # the service root
      torana atlas code code/acme/api place --kind folder --id src/api
      torana atlas code code/acme/api flow --function 'src/api/chat.py::chat'
      torana atlas code code/acme/api search litellm
    """
    ctx.ensure_object(dict)
    ctx.obj["_atlas_code_path"] = node_path
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@atlas_code.command(name="overview")
@_version_opt
@tenant_option
@click.pass_context
def code_overview(ctx, version):
    """What this service is: entry points, code and libraries counted, and the data quality in words.

    \b
    Example:
      torana atlas code code/acme/api overview
    """
    _emit(ctx, _get(ctx, "overview", version), render_overview)


@atlas_code.command(name="entries")
@click.option("--kind", type=click.Choice(["route", "cli", "main", "task"]), default=None, help="One kind of entry point.")
@click.option("--q", default=None, help="Text to find in the path, function or file.")
@click.option("--page", type=click.IntRange(1), default=1, show_default=True)
@click.option("--page-size", type=click.IntRange(1, 100), default=50, show_default=True)
@_version_opt
@tenant_option
@click.pass_context
def code_entries(ctx, kind, q, page, page_size, version):
    """The doors in: API routes (method + path where known), CLI commands, scripts, background tasks.

    \b
    Examples:
      torana atlas code code/acme/api entries
      torana atlas code code/acme/api entries --kind route --q chat
    """
    _emit(ctx, _get(ctx, "entries", version, kind=kind, q=q, page=page, page_size=page_size), render_entries)


@atlas_code.command(name="libraries")
@click.option("--kind", type=click.Choice(["third_party", "ours", "builtin"]), default=None)
@click.option("--declared-never-imported", is_flag=True, help="Only declared packages with no import found.")
@click.option("--q", default=None, help="Text to find in the name or module.")
@click.option("--page", type=click.IntRange(1), default=1, show_default=True)
@click.option("--page-size", type=click.IntRange(1, 100), default=50, show_default=True)
@_version_opt
@tenant_option
@click.pass_context
def code_libraries(ctx, kind, declared_never_imported, q, page, page_size, version):
    """Third-party, ours and built-in libraries: version from the lock, declared, imported in N files, mapping basis.

    \b
    Examples:
      torana atlas code code/acme/api libraries
      torana atlas code code/acme/api libraries --declared-never-imported
    """
    _emit(ctx, _get(ctx, "libraries", version, kind=kind, declared_never_imported=declared_never_imported, q=q,
                    page=page, page_size=page_size), render_libraries)


@atlas_code.command(name="place")
@click.option("--kind", type=click.Choice(["folder", "file", "function", "route", "library"]), required=True)
@click.option("--id", "ident", default=None, metavar="ID",
              help="The folder, file, function (`<file>::<qualname>`), route (`<function>@<line>`) or library. "
                   "Optional for --kind folder: omitted = the service root.")
@click.option("--section", default=None, help="Page ONE section (with --offset).")
@click.option("--offset", type=click.IntRange(0), default=None)
@click.option("--limit", type=click.IntRange(1, 100), default=None, help="Items per section (default 20).")
@click.option("--graph", is_flag=True, help="Also the graph (columns: left calls right).")
@_version_opt
@tenant_option
@click.pass_context
def code_place(ctx, kind, ident, section, offset, limit, graph, version):
    """One place: what it is, how it's reached, what it uses, what's inside.

    \b
    Examples:
      torana atlas code code/acme/api place --kind folder
      torana atlas code code/acme/api place --kind file --id src/api/chat.py
      torana atlas code code/acme/api place --kind library --id litellm
      torana atlas code code/acme/api place --kind route --id 'src/api/chat.py::chat@12'
    """
    if kind != "folder" and not ident:
        raise click.UsageError(f"--id is required for --kind {kind}")
    _emit(ctx, _get(ctx, "place", version, kind=kind, id=ident or None, section=section, offset=offset, limit=limit,
                    graph=graph), render_place)


@atlas_code.command(name="flow")
@click.option("--function", "function", required=True, metavar="ID", help="A function id (`<file>::<qualname>`).")
@click.option("--depth", type=click.IntRange(1, 5), default=None, help="Levels (default 3).")
@click.option("--max-nodes", type=click.IntRange(1, 500), default=None)
@click.option("--max-children", type=click.IntRange(1, 100), default=None)
@_version_opt
@tenant_option
@click.pass_context
def code_flow(ctx, function, depth, max_nodes, max_children, version):
    """What a function calls, downward, with possible calls marked and the libraries at the ends (file level).

    \b
    Example:
      torana atlas code code/acme/api flow --function 'src/api/chat.py::chat' --depth 3
    """
    _emit(ctx, _get(ctx, "flow", version, function=function, depth=depth, max_nodes=max_nodes,
                    max_children=max_children), render_flow)


@atlas_code.command(name="path")
@click.option("--function", "function", required=True, metavar="ID")
@_version_opt
@tenant_option
@click.pass_context
def code_path(ctx, function, version):
    """One chain from an entry point to this function, one hop per line.

    \b
    Example:
      torana atlas code code/acme/api path --function 'src/llm/client.py::complete'
    """
    _emit(ctx, _get(ctx, "path", version, function=function), render_path)


@atlas_code.command(name="search")
@click.argument("query")
@click.option("--limit", type=click.IntRange(1, 100), default=None, help="Results (default 20).")
@_version_opt
@tenant_option
@click.pass_context
def code_search(ctx, query, limit, version):
    """Find a route, folder, file, function or library by name, with the command that opens each.

    \b
    Example:
      torana atlas code code/acme/api search litellm
    """
    _emit(ctx, _get(ctx, "search", version, q=query, limit=limit), render_search)
