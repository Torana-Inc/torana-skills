"""torana alert-routes — alert routing rule collection management commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW, CollectionGroup
from torana_cli.output import output
from torana_cli.rules import _load_input_file

# Columns chosen to work for BOTH route shapes:
#  - workspace endpoint (AlertRouteSummary): id, name, description,
#    destination_type, priority, stop_on_match
#  - global /alert-routing/rules: fuller objects (enabled, severity_levels, …)
# Routes evaluate in PRIORITY order (lower first); _on_match shows whether a match
# stops routing (STOP) or lets lower-priority routes also fire (CONTINUE).
_LIST_COLS = [
    ("priority", "PRI", 4),
    ("name", "NAME", 38),
    ("destination_type", "DESTINATION", 12),
    ("_on_match", "ON MATCH", 9),
    ("id", "ID", 36),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(name="alert-routes", cls=CollectionGroup, singular="alert-route")
def alert_routes():
    """Manage alert routing rules (collection operations).

    \b
    Instance commands (get, update, delete, test, enable, disable, move) are under:
      torana alert-route <UUID> <verb>

    \b
    Examples:
      torana alert-routes list
      torana alert-routes create --file route.yaml
    """


@alert_routes.command(name="list")
@click.option("--workspace-id", default=None, help="Filter by workspace UUID.")
@click.option("--severity", default=None,
              type=click.Choice(["critical", "high", "medium", "low", "info"],
                                case_sensitive=False),
              help="Filter by severity.")
@click.option("--search", default=None, help="Search by name.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def alert_routes_list(ctx, workspace_id, severity, search, page, page_size, fetch_all):
    """List alert routing rules.

    \b
    Examples:
      torana alert-routes list
      torana alert-routes list --workspace-id <UUID>
    """
    list_alert_routes_core(ctx, workspace_id=workspace_id, severity=severity,
                           search=search, page=page, page_size=page_size,
                           fetch_all=fetch_all)


def list_alert_routes_core(ctx, *, workspace_id=None, severity=None, search=None,
                           page=1, page_size=None, fetch_all=False):
    """Shared alert-routes-list routine.

    `torana alert-routes list` and `torana workspace <id> alert-routes list`
    both call this. When `workspace_id` is bound, the workspace-scoped endpoint
    is used; otherwise the global one. Single source of truth.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    endpoint = (f"workspaces/{workspace_id}/alert-routes" if workspace_id
                else "api/v2/alert-routing/rules")

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"page": page, "page_size": effective_page_size}
    if severity:
        params["severity"] = severity
    if search:
        params["search"] = search

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"page": page_num, "page_size": effective_page_size}
                p.update({k: v for k, v in params.items() if k not in ("page", "page_size")})
                data = client.get(endpoint, params=p)
                items = data.get("items", [])
                all_items.extend(items)
                if len(all_items) >= data.get("total", len(all_items)):
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items), "page": 1,
                      "page_size": len(all_items)}
        else:
            result = client.get(endpoint, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # The workspace-scoped endpoint nests rows under "alert_routes"; normalize to
    # the {items, total, ...} envelope output() expects. It also carries a top-level
    # stop_on_match_enforced flag — when False (legacy first-match-wins), the per-route
    # stop_on_match is meaningless, so the ON MATCH column shows 'n/a'.
    enforced = True
    if isinstance(result, dict) and "items" not in result and "alert_routes" in result:
        enforced = bool(result.get("stop_on_match_enforced", True))
        result = {"items": result.get("alert_routes", []), "total": result.get("total", 0),
                  "page": page, "page_size": effective_page_size}

    # Sort by routing priority (lower = evaluated first) and derive the ON MATCH
    # display so the text/table output reflects the real evaluation order + behaviour.
    if isinstance(result, dict) and isinstance(result.get("items"), list):
        items = result["items"]
        items.sort(key=lambda r: (r.get("priority") is None, r.get("priority") or 0))
        for r in items:
            som = r.get("stop_on_match")
            if not enforced:
                r["_on_match"] = "n/a"          # legacy mode — flag not honoured
            elif som is True:
                r["_on_match"] = "STOP"         # terminal — no lower route fires
            elif som is False:
                r["_on_match"] = "CONTINUE"     # lower-priority routes still fire
            else:
                r["_on_match"] = ""

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@alert_routes.command(name="create")
@click.option("--name", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def alert_routes_create(ctx, name, input_file):
    """Create a new alert route."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name

    if not body.get("name"):
        click.echo("ERROR: --name is required.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post("alert-routing/rules", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created alert route: {data.get('id', 'unknown')}")


@alert_routes.command(name="rules")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with request body.")
@click.option("--workspace-id", "workspace_id", required=True, help="Workspace ID")
@click.option("--name", "name", required=True, help="Name of the routing rule")
@click.option("--description", "description", default=None)
@click.option("--enabled", "enabled", type=bool, default=True)
@click.option("--priority", "priority", type=int, default=100)
@click.option("--stop-on-match", "stop_on_match", type=bool, default=False)
@click.option("--severity-levels", "severity_levels", default=None)
@click.option("--required-tags", "required_tags", default=None)
@click.option("--source-rule-ids", "source_rule_ids", default=None)
@click.option("--source-suite-ids", "source_suite_ids", default=None)
@click.option("--matching-operator", "matching_operator", default="all")
@click.option("--destination-type", "destination_type", default="workflow")
@click.option("--destination-config", "destination_config", required=True)
@click.option("--max-executions-per-hour", "max_executions_per_hour", default=None, type=int)
@click.option("--labels", "labels", default=None)
@click.pass_context
def alert_routing_rules(ctx, workspace_id, name, description, enabled, priority, stop_on_match,
                        severity_levels, required_tags, source_rule_ids, source_suite_ids,
                        matching_operator, destination_type, destination_config,
                        max_executions_per_hour, labels, input_file):
    """Create Routing Rule (full form with all fields)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    if input_file:
        body = _load_input_file(input_file)
    else:
        body = {"workspace_id": workspace_id, "name": name}
        if description is not None:
            body["description"] = description
        if enabled is not None:
            body["enabled"] = enabled
        if priority is not None:
            body["priority"] = priority
        if stop_on_match is not None:
            body["stop_on_match"] = stop_on_match
        if severity_levels is not None:
            body["severity_levels"] = severity_levels
        if required_tags is not None:
            body["required_tags"] = required_tags
        if source_rule_ids is not None:
            body["source_rule_ids"] = source_rule_ids
        if source_suite_ids is not None:
            body["source_suite_ids"] = source_suite_ids
        if matching_operator is not None:
            body["matching_operator"] = matching_operator
        if destination_type is not None:
            body["destination_type"] = destination_type
        body["destination_config"] = destination_config
        if max_executions_per_hour is not None:
            body["max_executions_per_hour"] = max_executions_per_hour
        if labels is not None:
            body["labels"] = labels

    client = _client(ctx)
    try:
        data = client.post("alert-routing/rules", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert_routes.command(name="routing-rules")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", "page_size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.option("--skip", "skip", type=int, default=0)
@click.option("--limit", "limit", type=int, default=100)
@click.option("--enabled-only", "enabled_only", type=bool, default=False)
@click.option("--tag", "tag", default=None)
@click.option("--workspace-id", "workspace_id", default=None)
@click.pass_context
def alert_routes_routing_rules(ctx, skip, limit, enabled_only, tag, workspace_id, page, page_size, fetch_all):
    """Get Routing Rules (skip/limit form)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {
        "skip": (page - 1) * effective_page_size,
        "limit": effective_page_size,
    }
    if enabled_only is not None:
        params["enabled_only"] = enabled_only
    if tag is not None:
        params["tag"] = tag
    if workspace_id is not None:
        params["workspace_id"] = workspace_id

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get("alert-routing/rules", params=p)
                items = data.get("items", data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get("total", len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get("alert-routing/rules", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@alert_routes.command(name="executions")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", "page_size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.option("--alert-id", "alert_id", default=None)
@click.option("--routing-rule-id", "routing_rule_id", default=None)
@click.option("--skip", "skip", type=int, default=0)
@click.option("--limit", "limit", type=int, default=100)
@click.pass_context
def alert_routing_executions(ctx, alert_id, routing_rule_id, skip, limit, page, page_size, fetch_all):
    """Get Routing Executions."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {
        "skip": (page - 1) * effective_page_size,
        "limit": effective_page_size,
    }
    if alert_id is not None:
        params["alert_id"] = alert_id
    if routing_rule_id is not None:
        params["routing_rule_id"] = routing_rule_id

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get("alert-routing/executions", params=p)
                items = data.get("items", data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get("total", len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get("alert-routing/executions", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@alert_routes.command(name="reorder")
@click.pass_context
def alert_routing_reorder(ctx):
    """Reorder Routing Rules."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.post("alert-routing/rules/reorder", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert_routes.command(name="routing-test")
@click.option("--input", "input_file", default=None, help="JSON/YAML file with alert data to test routing.")
@click.pass_context
def alert_routes_routing_test(ctx, input_file):
    """Test alert routing rules against sample alert data."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = _load_input_file(input_file) if input_file else {}
    client = _client(ctx)
    try:
        data = client.post("alert-routing/test", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ── bulk ops (CLI-4) ─────────────────────────────────────────────────────────
# There is no server-side bulk endpoint — these loop the per-instance
# enable/disable calls. run_bulk reports per-item outcomes and exits non-zero on
# any failure, so a partial apply can never read as success.

@alert_routes.group(name="bulk", invoke_without_command=True)
@click.pass_context
def alert_routes_bulk(ctx):
    """Bulk operations across alert routes. Use `enable` / `disable`."""
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _bulk_route_ids(client, only_disabled=None):
    """Ids of routing rules, optionally filtered by current enabled state."""
    from torana_cli.bulk import resolve_ids

    def _pred(item):
        if only_disabled is None:
            return True
        enabled = item.get("is_enabled", item.get("enabled"))
        return (enabled is False) if only_disabled else (enabled is True)

    return resolve_ids(client, "alert-routing/rules", predicate=_pred)


@alert_routes_bulk.command(name="enable")
@click.option("--all-disabled", is_flag=True, default=False,
              help="Target every currently-disabled route (the demo-prep recovery case).")
@click.option("--id", "ids", multiple=True, help="Explicit route id (repeatable).")
@click.option("--dry-run", is_flag=True, default=False, help="Show what would change.")
@click.pass_context
def alert_routes_bulk_enable(ctx, all_disabled, ids, dry_run):
    """Enable many alert routes at once."""
    from torana_cli.bulk import run_bulk
    client = _client(ctx)
    target = list(ids) if ids else (_bulk_route_ids(client, only_disabled=True)
                                    if all_disabled else [])
    if not target and not ids and not all_disabled:
        click.echo("ERROR: pass --id <id> (repeatable) or --all-disabled.", err=True)
        ctx.exit(2)
    run_bulk(ctx, target,
             lambda rid: client.post(f"alert-routing/rules/{rid}/enable", json={}),
             label="enable alert routes", dry_run=dry_run)


@alert_routes_bulk.command(name="disable")
@click.option("--all-enabled", is_flag=True, default=False,
              help="Target every currently-enabled route.")
@click.option("--id", "ids", multiple=True, help="Explicit route id (repeatable).")
@click.option("--dry-run", is_flag=True, default=False, help="Show what would change.")
@click.pass_context
def alert_routes_bulk_disable(ctx, all_enabled, ids, dry_run):
    """Disable many alert routes at once."""
    from torana_cli.bulk import run_bulk
    client = _client(ctx)
    target = list(ids) if ids else (_bulk_route_ids(client, only_disabled=False)
                                    if all_enabled else [])
    if not target and not ids and not all_enabled:
        click.echo("ERROR: pass --id <id> (repeatable) or --all-enabled.", err=True)
        ctx.exit(2)
    run_bulk(ctx, target,
             lambda rid: client.post(f"alert-routing/rules/{rid}/disable", json={}),
             label="disable alert routes", dry_run=dry_run)
