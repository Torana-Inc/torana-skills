"""torana chats — list an app's chats and start a new one."""

import sys

import click

from torana_cli import chat_core
from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output

_MAX_LIMIT = 100


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    return ToranaClient(base_url=get_settings(profile).base_url)


def read_message(message, message_file):
    """The text of -m / --message-file (`-` = stdin). None when neither was given."""
    if message and message_file:
        raise click.UsageError("Give the message with -m or with --message-file, not both.")
    if message_file:
        if message_file == "-":
            text = click.get_text_stream("stdin").read()
        else:
            from pathlib import Path
            text = Path(message_file).read_text()
        text = text.strip()
        if not text:
            raise click.UsageError("The message file is empty.")
        return text
    return message


def wait_options(fn):
    """--stream / --no-wait / --timeout, shared by every command that sends a message."""
    fn = click.option("--timeout", type=float, default=300.0, show_default=True,
                      help="Seconds to wait for the reply. The turn keeps running if this "
                           "passes (exit 8); check it with `torana chat <CHAT_ID> status`.")(fn)
    fn = click.option("--no-wait", is_flag=True, default=False,
                      help="Return as soon as the message is accepted. Exit 9 if a turn is "
                           "already running in the chat.")(fn)
    fn = click.option("--stream", is_flag=True, default=False,
                      help="Print the reply as it is written, and each tool step on stderr.")(fn)
    return fn


def run_turn(ctx, fmt, *, stream, no_wait, call):
    """Run `call(on_event)` → TurnResult, print it, and exit with its code."""
    if stream and no_wait:
        raise click.UsageError("--stream and --no-wait cannot be used together.")
    printer = chat_core.StreamPrinter(fmt) if stream else None
    try:
        result = call(printer)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    chat_core.print_turn_result(result, fmt=fmt, streamed=bool(printer and printer.printed_text))
    sys.exit(result.exit_code)


@click.group(name="chats", invoke_without_command=True)
@click.pass_context
def chats(ctx):
    """Talk to an app's assistant: start a chat, and find the chats you already have.

    A chat is a conversation with an agent. Chat inside an app goes to the "Ask AI
    Orchestrator" agent, scoped to that app (the app's Chat tab and `widget chat` use
    it too); `chats start --app-id` finds it for you. `--agent <AGENT_ID>` talks to
    another agent instead.

    \b
    Start here: talk to an app's assistant
      torana apps list                                          find the app's ID
      torana chats start --app-id <APP_ID> -m "your question"   ask, and wait for the reply
      torana chat <CHAT_ID> send -m "follow-up"                 continue the same chat
      torana chats list --app-id <APP_ID> --waiting             chats that are waiting on you
      torana chat <CHAT_ID> answer --option 1                   answer the question it asked

    \b
    Exit codes (start -m, and chat <CHAT_ID> send / answer)
      0  the assistant replied          7  it is waiting on your answer
      8  the run failed, timed out or was cancelled
      9  a turn is already running (only with --no-wait)

    \b
    One chat (send, history, status, answer, stop, steer, rename, delete):
      torana chat <CHAT_ID> --help
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _row_state(row: dict) -> str:
    if row.get("waiting_on_user"):
        return "waiting"
    lock = ((row.get("metadata") or {}).get("execution_lock") or {}).get("status")
    return "running" if lock == "processing" else "idle"


def list_chats_core(ctx, *, app_id=None, agent_id=None, waiting=False, any_context=False,
                    limit=50, offset=0):
    """Shared fetch and format routine for a list of chats (one agent, optionally one app)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    if not app_id and not agent_id:
        raise click.UsageError("Say which chats: --app-id <APP_ID> (the app's assistant) "
                               "or --agent <AGENT_ID>.")
    if any_context and not agent_id:
        raise click.UsageError("--any-context needs --agent <AGENT_ID>.")
    if limit < 1 or limit > _MAX_LIMIT:
        raise click.UsageError(f"--limit must be between 1 and {_MAX_LIMIT}.")

    client = _client(ctx)
    try:
        if not agent_id:
            agent_id = chat_core.resolve_ask_ai_agent(client)["agent_id"]
        # The route has no grand total, so ask for one row more than the page to learn
        # whether more chats exist.
        params = {"limit": limit + 1, "offset": offset}
        if app_id:
            params["workspace_id"] = app_id
            if not any_context:
                params["context_type"] = "workspace"
        if waiting:
            params["waiting"] = "true"
        data = client.get(f"agents/{agent_id}/sessions", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    rows = (data.get("sessions") or []) if isinstance(data, dict) else (data or [])
    has_more = len(rows) > limit
    rows = rows[:limit]
    items = [{**r, "chat_id": r.get("session_id"), "state": _row_state(r)} for r in rows]
    envelope = {"items": items, "total": len(items), "page": offset // limit + 1,
                "page_size": limit, "has_more": has_more}

    if fmt in ("text", "table"):
        labels = {"waiting": "waiting on you", "running": "running", "idle": "idle"}
        envelope = {**envelope, "items": [
            {**it, "state": labels[it["state"]],
             "last_update_timestamp": chat_core._fmt_epoch(it.get("last_update_timestamp"))}
            for it in items]}
    output(envelope, fmt=fmt, fields=fields, raw=raw, columns=[
        ("chat_id", "CHAT ID", None),      # never truncated: it is pasted into the next command
        ("name", "NAME", 36),
        ("state", "STATE", None),
        ("last_update_timestamp", "UPDATED", None),
    ])
    if fmt in ("text", "table") and has_more:
        click.echo(f"More chats exist; add --offset {offset + limit} to see the next page.",
                   err=True)


@chats.command(name="list")
@click.option("--app-id", default=None, metavar="APP_ID",
              help="The app whose chats to list (your Ask AI chats in that app).")
@click.option("--agent", "agent_id", default=None, metavar="AGENT_ID",
              help="List this agent's chats instead of Ask AI's (e.g. chats started before "
                   "chat moved to Ask AI were with the app's operator agent).")
@click.option("--waiting", is_flag=True, default=False,
              help="Only chats where the assistant asked you a question and is waiting.")
@click.option("--any-context", is_flag=True, default=False,
              help="With --agent: include chats of every context type, not only chats "
                   "opened from an app's Chat tab (e.g. page and widget chats).")
@click.option("--limit", type=int, default=50, show_default=True, help="Chats per page (max 100).")
@click.option("--offset", type=int, default=0, show_default=True, help="Chats to skip.")
@click.pass_context
def chats_list(ctx, app_id, agent_id, waiting, any_context, limit, offset):
    """List chats, newest first, with what each one is doing.

    Use it to find a chat to continue, or the chats that need you. STATE is
    `waiting on you` (the assistant asked a question), `running` (a turn is in
    progress) or `idle`. The CHAT ID is what every `torana chat <CHAT_ID>` command takes.

    \b
    Examples:
      torana chats list --app-id <APP_ID>
      torana chats list --app-id <APP_ID> --waiting
      torana chats list --app-id <APP_ID> --json | jq '.items[] | {chat_id, name, state}'
      torana chats list --agent <AGENT_ID> --any-context

    \b
    Related:
      torana chat <CHAT_ID> status      what one chat is waiting on
      torana chat <CHAT_ID> history     read a chat
    """
    list_chats_core(ctx, app_id=app_id, agent_id=agent_id, waiting=waiting,
                    any_context=any_context, limit=limit, offset=offset)


@chats.command(name="start")
@click.option("--app-id", default=None, metavar="APP_ID",
              help="The app to chat in. Ask AI is found for you (by name), and what it "
                   "does is scoped to this app.")
@click.option("--agent", "agent_id", default=None, metavar="AGENT_ID",
              help="Chat with this agent instead of Ask AI.")
@click.option("--title", default=None, help="A name for the chat (default: its first message).")
@click.option("--message", "-m", default=None, help="First message. Without it the chat is "
                                                    "only opened.")
@click.option("--message-file", default=None, metavar="FILE",
              help="Read the first message from a file ('-' for stdin).")
@click.option("--anchor-type", default=None, hidden=True)
@click.option("--anchor-id", default=None, hidden=True)
@click.option("--new", "new_session", is_flag=True, default=False, hidden=True)
@wait_options
@click.pass_context
def chats_start(ctx, app_id, agent_id, title, message, message_file, anchor_type, anchor_id,
                new_session, stream, no_wait, timeout):
    """Open a new chat with an app's assistant and, with -m, ask the first question.

    With -m the command waits for the reply and prints it (JSON: `reply`,
    `chat_id`, `status`). Keep the chat id to continue with `torana chat <CHAT_ID>
    send`. Without -m it prints the new chat's id and nothing is asked yet.

    \b
    Examples:
      torana chats start --app-id <APP_ID> -m "Which repositories have the most critical findings?"
      torana chats start --app-id <APP_ID> -m "…" --json | jq -r '.reply, .chat_id'
      torana chats start --app-id <APP_ID> --title "Weekly review"
      torana chats start --app-id <APP_ID> -m "…" --stream

    \b
    Exit codes with -m: 0 replied · 7 waiting on your answer · 8 failed, timed out
    or cancelled · 9 busy (--no-wait only).

    \b
    Related:
      torana apps list                  find the app's ID
      torana chat <CHAT_ID> send        continue the chat
      torana chat <CHAT_ID> answer      answer a question the assistant asked
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    if not app_id and not agent_id:
        raise click.UsageError("Say who to chat with: --app-id <APP_ID> (the app's assistant) "
                               "or --agent <AGENT_ID>.")
    if bool(anchor_type) != bool(anchor_id):
        raise click.UsageError("--anchor-type and --anchor-id go together.")
    if anchor_type and not agent_id:
        raise click.UsageError("An anchored chat needs --agent <AGENT_ID>.")
    text = read_message(message, message_file)

    client = _client(ctx)
    try:
        app_name = attachment_id = None
        if app_id:
            app = client.get(f"workspaces/{app_id}")
            app_name = app.get("name") if isinstance(app, dict) else None
            if not agent_id:
                # Platform chat always goes to Ask AI (scoped to this app by the chat's
                # metadata), the same agent the Chat tab and `widget chat` use.
                agent_id = chat_core.resolve_ask_ai_agent(client)["agent_id"]
        anchor = {"type": anchor_type, "id": anchor_id} if anchor_type else None
        created = chat_core.create_chat_session(
            client, agent_id=agent_id, app_id=app_id, app_name=app_name,
            attachment_id=attachment_id, anchor=anchor, title=title, new_session=new_session)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    session_id = created.get("session_id")
    if not text:
        info = {"chat_id": session_id, "session_id": session_id,
                "agent_id": created.get("agent_id") or agent_id,
                "workspace_id": app_id, "name": title}
        if fmt != "text":
            output(info, fmt=fmt)
        else:
            click.echo(f"Started chat: {session_id}")
            click.echo(f"  torana chat {session_id} send -m \"your question\"")
        return

    # The chat id is printed once, by the result printer (every outcome names it).
    run_turn(ctx, fmt, stream=stream, no_wait=no_wait, call=lambda printer: chat_core.send_and_wait(
        client, session_id=session_id, agent_id=agent_id, message=text,
        wait=not no_wait, timeout=timeout, on_event=printer))
