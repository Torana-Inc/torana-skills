"""What started a rule run, in words. The platform sends `execution_trigger_label`; this is the same map, for a server that does not yet."""
from __future__ import annotations

_WORDS = {"MANUAL": "Manual", "SCHEDULED": "Scheduled", "API": "API", "SUITE": "Suite", "DATA_CHANGE": "Data change"}


def run_trigger_label(run) -> str | None:
    """The run's trigger in words ("Data change"); the platform's own label wins; None when nothing is stated."""
    if not isinstance(run, dict):
        return None
    sent = run.get("execution_trigger_label")
    if sent:
        return str(sent)
    raw = run.get("execution_trigger") or run.get("trigger")
    return None if not raw else _WORDS.get(str(raw).upper(), str(raw))
