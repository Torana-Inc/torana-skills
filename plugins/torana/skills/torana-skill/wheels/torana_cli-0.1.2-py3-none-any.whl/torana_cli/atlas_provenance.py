"""torana atlas provenance — does a package reach the image a repository's build produces, and at which version
(pantheon-knowledge PACKAGE_PROVENANCE.md). Free: Atlas's stored code snapshots, no build, no model.

The server writes every state and every sentence (`{state, glyph, words}`); this command prints them verbatim and
derives none. ⚠️ File output is `--out`, never `-o` (the root group lifts `-o` as the global format flag).
"""

import click

from torana_cli.atlas import _call, _client, _fmt, _params
from torana_cli.output import output


def _repo_key(value: str) -> str:
    """`repo:github.com/acme/api` as given; `github.com/acme/api` gets the `repo:` prefix."""
    v = (value or "").strip()
    return v if v.startswith("repo:") else f"repo:{v}"


def _line(label: str, w: dict | None) -> str:
    if not w:
        return f"{label}: (none)"
    return f"{label}: {w.get('glyph', '?')} {w.get('state', '?')} — {w.get('words', '')}"


def _where(step: dict) -> str:
    place = step.get("file") or ""
    if place and step.get("line"):
        place += f":{step['line']}"
    repo = str(step.get("repository") or "").removeprefix("repo:")
    snap = step.get("snapshot")
    at = f" @ snapshot {snap} ({str(step.get('commit') or '')[:7]})" if snap is not None else ""
    return f"{place} · {repo}{at}".strip(" ·")


def render_provenance(data: dict) -> str:
    pkg, repo = data.get("package", ""), data.get("repository", "")
    lines = [f"provenance  {pkg} in {repo}  (vulnerable {data.get('vulnerable_range', '')})",
             _line("Verdict", data.get("verdict"))]
    if data.get("image"):
        lines.append(_line("Image", data["image"]))
    if data.get("headline_gap"):
        g = data["headline_gap"]
        lines.append(f"Main gap: ○ {g.get('code')}: {g.get('words', '')}")
    for d in data.get("declared_vs_observed") or []:
        lines.append(f"Declared vs observed: {d.get('glyph', '≠')} {d.get('code')} — {d.get('words', '')}")
    if data.get("declared"):
        lines.append(_line("Declared by the build", data["declared"].get("verdict")))
    k = data.get("knowledge") or {}
    lines.append(_line("Knowledge", k))
    for n in k.get("nodes") or []:
        lines.append(f"  {n.get('glyph', '?')} {n.get('state', '?')} — {n.get('words', '')}")
    if data.get("file_status"):
        lines.append(_line("Reported file", data["file_status"]))
    lines.append(_line("Running", data.get("running")))
    if data.get("shipped"):
        lines.append("Ships:")
        for s in data["shipped"]:
            rng = {True: "inside the range", False: "outside the range"}.get(s.get("in_range"), "range undecided")
            where = f"{s.get('file')}:{s.get('line')}" if s.get("line") else s.get("file")
            lines.append(f"  {s.get('version')}  {where} in {str(s.get('repository', '')).removeprefix('repo:')} "
                         f"({s.get('basis', '').replace('_', ' ')}; {rng})")
    if data.get("fix_at"):
        lines.append(f"Fix at: {data['fix_at'].get('words', '')}")
    apart = {(m.get("code"), m.get("words")) for m in data.get("also_not_read") or []}
    missing = [m for m in data.get("missing") or [] if (m.get("code"), m.get("words")) not in apart]
    if missing:
        lines.append("Missing:")
        for m in missing:
            lines.append(f"  ○ {m.get('code')}: {m.get('words', '')}")
    if apart:
        lines.append("Also not read (less likely to affect Python packages):")
        for m in data["also_not_read"]:
            lines.append(f"  ○ {m.get('code')}: {m.get('words', '')}")
    if data.get("chain"):
        lines.append("Proof:")
        for i, c in enumerate(data["chain"], 1):
            lines.append(f"  {i}. [{c.get('step')}] {c.get('claim', '')}")
            lines.append(f"       {_where(c)}" + (f"  {c['anchor']}" if c.get("anchor") else ""))
            if c.get("digest"):
                lines.append(f"       image {c['digest'][:19]}" + (f" · layer {c['layer'][:19]}" if c.get("layer") else ""))
            if (c.get("fact") or {}).get("check") == "from_recipe":
                lines.append("       (from the recipe: no build record, read from the builder image's Dockerfile)")
            if c.get("ref") and c.get("node_path"):
                lines.append(f"       open: torana atlas node {c['node_path']} anchor '{c['ref']}'")
    if data.get("as_of"):
        lines.append("As of: " + "; ".join(
            f"snapshot {a.get('snapshot')} of {a.get('node_path')} at {str(a.get('commit') or '')[:7]}"
            for a in data["as_of"]))
    lines.append(f"request {data.get('request_id', '')} · ${float(data.get('cost_usd') or 0):.2f}")
    return "\n".join(lines)


@click.command(name="provenance")
@click.argument("repository")
@click.argument("package")
@click.option("--file", "file_path", default=None, metavar="PATH",
              help="The manifest the scanner reported, repository-relative (e.g. requirements-dev.txt).")
@click.option("--fixed", "fixed_version", default=None, metavar="VERSION",
              help="The advisory's fixed version: every version below it is vulnerable.")
@click.option("--vulnerable", "vulnerable_range", default=None, metavar="SPEC",
              help="The advisory's vulnerable range instead, e.g. '<24.3.0' or '>=2.0,<2.4.1'.")
@click.option("--ecosystem", default="pypi", show_default=True, help="The package's ecosystem (pypi today).")
@click.option("--commit", default=None, metavar="SHA",
              help="The commit the finding was scanned at: the knowledge line says whether Atlas's snapshot includes it.")
@click.option("--no-observe", "no_observe", is_flag=True, default=False,
              help="Skip the running-image read (the datalake); the verdict is unchanged, the Running line says so.")
@click.option("--tenant", default=None, help="Another tenant's knowledge (SA only).")
@click.pass_context
def atlas_provenance(ctx, repository, package, file_path, fixed_version, vulnerable_range, ecosystem, commit,
                     no_observe, tenant):
    """Does PACKAGE reach the image REPOSITORY's build produces, at a vulnerable version? Free, no model.

    Reads Atlas's stored code snapshots: whether the reported file is installed by any build, which file really sets
    the version (it may be another repository's lock, e.g. a shared base image), that version, and whether it is
    inside the vulnerable range. Outcomes: not_shipped · fixed_in_shipped · vulnerable_in_shipped (with the file:line
    to fix) · unknown (with the missing link named). Every verdict says what Atlas knew: current, stale (N commits
    behind), not indexed, or index failed; a "no action" verdict is never given on knowledge Atlas could not read.
    Every proof step is an anchor: open it with the printed `torana atlas node … anchor` command.

    When an image of REPOSITORY is known (its OCI source label names it) with an SBOM, the verdict comes from the
    IMAGE: the running one first, else the newest built from a commit that includes what Atlas read. Proof then walks
    package → layer → base image → history step → Dockerfile line → lock line → its `# via` input line. Without image
    evidence the build's verdict stands, marked "Not observed". "Declared vs observed" lines compare the image with
    what the code declares (e.g. pyproject >=1.39.1 while the image carries 1.37.0); "Main gap" names the gap that
    matters; "Also not read" lists build steps less likely to affect Python packages.

    \b
    Examples:
      torana atlas provenance repo:github.com/acme/api black --file requirements-dev.txt --fixed 24.3.0
      torana atlas provenance github.com/acme/api requests --vulnerable '<2.32.0' --commit 1a2b3c4
      torana atlas provenance repo:github.com/acme/api black --fixed 24.3.0 --json
    """
    fmt, _, _ = _fmt(ctx)
    if bool(fixed_version) == bool(vulnerable_range):
        raise click.UsageError("give the advisory as --fixed VERSION or --vulnerable SPEC (exactly one)")
    body = {"repository": _repo_key(repository), "package": package, "ecosystem": ecosystem,
            "observe": not no_observe}
    body.update({k: v for k, v in (("file", file_path), ("fixed_version", fixed_version),
                                   ("vulnerable_range", vulnerable_range), ("commit", commit)) if v})
    data = _call(_client(ctx).post, "atlas/package-provenance", json=body, params=_params(tenant=tenant))
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt)
        return
    click.echo(render_provenance(data))
