"""torana roles — role management commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 30),
    ("description", "DESCRIPTION", 50),
]

_PERMISSION_COLS = [
    ("name", "PERMISSION", 50),
    ("resource", "RESOURCE", 30),
    ("action", "ACTION", 20),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group()
def roles():
    """Manage roles and permissions.

    \b
    Examples:
      torana roles list
      torana roles get <UUID>
      torana roles create --name analyst --file role.yaml
    """


@roles.command(name="list")
@click.option("--search", default=None, help="Search by name.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def roles_list(ctx, search, page, page_size):
    """List roles.

    \b
    Examples:
      torana roles list
      torana roles list --search analyst
      torana roles list --json | jq '.items[] | {name, id}'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if search:
        params["search"] = search

    client = _client(ctx)
    try:
        data = client.get("roles/", params=params)
        result = data if isinstance(data, dict) and "items" in data else {
            "items": data if isinstance(data, list) else [],
            "total": len(data) if isinstance(data, list) else 0,
            "page": page, "page_size": effective_page_size
        }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@roles.command(name="get")
@click.argument("role_id", metavar="ROLE_ID")
@click.pass_context
def roles_get(ctx, role_id):
    """Get details for a specific role.

    \b
    Examples:
      torana roles list                        # find the id
      torana roles get <ROLE_ID>
      torana roles role-permissions <ROLE_ID>  # what this role actually grants
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"roles/{role_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@roles.command(name="create")
@click.option("--name", default=None)
@click.option("--description", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def roles_create(ctx, name, description, input_file):
    """Create a new role.

    \b
    Examples:
      torana roles create --name security_analyst --description "Read + triage"
      torana roles create --file role.yaml

    \b
      Then assign it, and check what a user ends up with:
        torana roles assign <ROLE_ID> --user-id <USER_ID>
        torana roles user-permissions <USER_ID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if description:
        body["description"] = description

    if not body.get("name"):
        click.echo("ERROR: --name is required.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post("roles/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created role: {data.get('id', 'unknown')}")


@roles.command(name="update")
@click.argument("role_id", metavar="ROLE_ID")
@click.option("--name", default=None)
@click.option("--description", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def roles_update(ctx, role_id, name, description, input_file):
    """Update a role."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if description:
        body["description"] = description

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"roles/{role_id}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated role: {role_id}")


@roles.command(name="delete")
@click.argument("role_id", metavar="ROLE_ID")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def roles_delete(ctx, role_id, yes):
    """Delete a role."""
    _confirm(f"Delete role {role_id}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"roles/{role_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted role: {role_id}")


# ---------------------------------------------------------------------------
# permissions sub-group (read-only reference data)
# ---------------------------------------------------------------------------

@click.group()
def permissions():
    """List available permissions.

    \b
    Examples:
      torana permissions list
      torana permissions mapping
    """


@permissions.command(name="list")
@click.option("--search", default=None, help="Search permissions.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def permissions_list(ctx, search, page, page_size):
    """List all available permissions."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if search:
        params["search"] = search

    client = _client(ctx)
    try:
        data = client.get("permissions/", params=params)
        result = data if isinstance(data, dict) and "items" in data else {
            "items": data if isinstance(data, list) else [],
            "total": len(data) if isinstance(data, list) else 0,
            "page": page, "page_size": effective_page_size
        }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_PERMISSION_COLS)


@permissions.command(name="mapping")
@click.pass_context
def permissions_mapping(ctx):
    """Get role-to-permission mapping."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.get("permissions/mapping/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt if fmt != "text" else "json")


@roles.command(name="roles")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--tenant-id", "tenant_id", default=None, help="Filter by tenant ID")
@click.option("--search", "search", default=None, help="Search in name/description")
@click.option("--is-system-role", "is_system_role", default=None, help="Filter by system role status")
@click.option("--cursor", "cursor", default=None, help="Cursor for pagination")
@click.option("--limit", "limit", type=int, default=50, help="Items per page")
@click.option("--sort-by", "sort_by", default="id", help="Sort field")
@click.option("--sort-order", "sort_order", default="desc", help="Sort order")
@click.pass_context
def rbac_roles(ctx, tenant_id, search, is_system_role, cursor, limit, sort_by, sort_order, page, page_size, fetch_all):
    """List Roles."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "rbac/roles"
    params = {}
    if tenant_id is not None:
        params["tenant_id"] = tenant_id
    if search is not None:
        params["search"] = search
    if is_system_role is not None:
        params["is_system_role"] = is_system_role
    if cursor is not None:
        params["cursor"] = cursor
    if limit is not None:
        params["limit"] = limit
    if sort_by is not None:
        params["sort_by"] = sort_by
    if sort_order is not None:
        params["sort_order"] = sort_order
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@roles.command(name="create-role")
@click.option("--name", "name", required=True)
@click.option("--description", "description", default=None)
@click.option("--tenant-name", "tenant_name", required=True)
@click.option("--permissions", "permissions", default=[])
@click.option("--is-system-role", "is_system_role", type=bool, default=False)
@click.option("--role-hierarchy", "role_hierarchy", default=None)
@click.pass_context
def roles_create_role(ctx, name, description, tenant_name, permissions, is_system_role, role_hierarchy):
    """Create Role."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "rbac/roles"
    body = {}
    body["name"] = name
    if description is not None:
        body["description"] = description
    body["tenant_name"] = tenant_name
    if permissions is not None:
        body["permissions"] = permissions
    if is_system_role is not None:
        body["is_system_role"] = is_system_role
    if role_hierarchy is not None:
        body["role_hierarchy"] = role_hierarchy

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ──────────────────────────────────────────────────────────────────────────
# Instance reads regrouped from `<noun>-by-<param>` leaves onto verbs
# (CLI Discoverability Contract, rule 2 — see ../CLAUDE.md). The route
# parameter belongs in the positional ARGUMENT, not the command name.
#
# Old flat names remain as HIDDEN aliases for ONE release (D4).
# ──────────────────────────────────────────────────────────────────────────


@roles.group(name="role")
def roles_role_grp():
    """One role, by id.

    Examples:
      torana roles role get --help
    """


@roles.group(name="role-assignment")
def roles_role_assignment_grp():
    """Role assignments on a user.

    Examples:
      torana roles role-assignment remove --help
    """


@roles_role_grp.command(name="get")
@click.argument("ROLE_ID", metavar="ROLE_ID")
@click.pass_context
def rbac_roles_by_role_id(ctx, role_id):
    """Get Role."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"rbac/roles/{role_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@roles.command(name="update-role")
@click.argument("ROLE_ID", metavar="ROLE_ID")
@click.option("--name", "name", default=None)
@click.option("--description", "description", default=None)
@click.option("--permissions", "permissions", default=None)
@click.option("--is-system-role", "is_system_role", default=None)
@click.option("--role-hierarchy", "role_hierarchy", default=None)
@click.pass_context
def roles_update_role(ctx, role_id, name, description, permissions, is_system_role, role_hierarchy):
    """Update Role."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"rbac/roles/{role_id}"
    body = {}
    if name is not None:
        body["name"] = name
    if description is not None:
        body["description"] = description
    if permissions is not None:
        body["permissions"] = permissions
    if is_system_role is not None:
        body["is_system_role"] = is_system_role
    if role_hierarchy is not None:
        body["role_hierarchy"] = role_hierarchy

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@roles.command(name="delete-role")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("ROLE_ID", metavar="ROLE_ID")
@click.pass_context
def roles_delete_role(ctx, role_id, yes):
    """Delete Role."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"rbac/roles/{role_id}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@roles.command(name="assign-user-role")
@click.option("--user-id", "user_id", required=True)
@click.option("--role-id", "role_id", required=True)
@click.option("--namespace-id", "namespace_id", default=None)
@click.pass_context
def roles_assign_user_role(ctx, user_id, role_id, namespace_id):
    """Assign User Role."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "rbac/users/roles"
    body = {}
    body["user_id"] = user_id
    body["role_id"] = role_id
    if namespace_id is not None:
        body["namespace_id"] = namespace_id

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@roles.command(name="assign-role-to-user")
@click.argument("USER_ID", metavar="USER_ID")
@click.pass_context
def roles_assign_role_to_user(ctx, user_id):
    """Assign Role To User."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"rbac/users/{user_id}/roles"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@roles.command(name="remove-user-role")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("USER_ID", metavar="USER_ID")
@click.option("--role", "role", required=True)
@click.option("--resource-type", "resource_type", required=True)
@click.option("--resource-id", "resource_id", required=True)
@click.pass_context
def roles_remove_user_role(ctx, user_id, role, resource_type, resource_id, yes):
    """Remove User Role."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"rbac/users/{user_id}/roles"
    params = {}
    if role is not None:
        params["role"] = role
    if resource_type is not None:
        params["resource_type"] = resource_type
    if resource_id is not None:
        params["resource_id"] = resource_id

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@roles.command(name="user-roles")
@click.argument("USER_ID", metavar="USER_ID")
@click.option("--namespace-id", "namespace_id", default=None)
@click.pass_context
def roles_user_roles(ctx, user_id, namespace_id):
    """Get User Roles."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"rbac/users/{user_id}/roles"
    params = {}
    if namespace_id is not None:
        params["namespace_id"] = namespace_id

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@roles.command(name="revoke-user-role")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("USER_ID", metavar="USER_ID")
@click.argument("ROLE_ID", metavar="ROLE_ID")
@click.option("--namespace-id", "namespace_id", default=None)
@click.pass_context
def roles_revoke_user_role(ctx, user_id, role_id, namespace_id, yes):
    """Revoke User Role."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"rbac/users/{user_id}/roles/{role_id}"
    params = {}
    if namespace_id is not None:
        params["namespace_id"] = namespace_id

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@roles.command(name="bulk-roles")
@click.option("--user-ids", "user_ids", required=True)
@click.option("--role-id", "role_id", required=True)
@click.option("--namespace-id", "namespace_id", default=None)
@click.pass_context
def rbac_bulk_roles(ctx, user_ids, role_id, namespace_id):
    """Bulk Assign Roles."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "rbac/users/bulk-roles"
    body = {}
    body["user_ids"] = user_ids
    body["role_id"] = role_id
    if namespace_id is not None:
        body["namespace_id"] = namespace_id

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@roles.command(name="check")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with request body. Use '-' for stdin.")
@click.option("--user-id", "user_id", required=True)
@click.option("--resource", "resource", required=True)
@click.option("--action", "action", required=True)
@click.option("--namespace-id", "namespace_id", default=None)
@click.pass_context
def rbac_check(ctx, user_id, resource, action, namespace_id, input_file):
    """Check Access."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "rbac/check"
    if input_file:
        body = _load_input_file(input_file)
    else:
        body = {}
        body["user_id"] = user_id
        body["resource"] = resource
        body["action"] = action
        if namespace_id is not None:
            body["namespace_id"] = namespace_id

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@roles.command(name="user-permissions")
@click.argument("USER_ID", metavar="USER_ID")
@click.option("--namespace-id", "namespace_id", default=None)
@click.pass_context
def rbac_permissions(ctx, user_id, namespace_id):
    """Get User Permissions."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"rbac/users/{user_id}/permissions"
    params = {}
    if namespace_id is not None:
        params["namespace_id"] = namespace_id

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@roles.command(name="role-permissions")
@click.argument("ROLE_ID", metavar="ROLE_ID")
@click.pass_context
def rbac_permissions_1(ctx, role_id):
    """Get Role Permissions."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"rbac/roles/{role_id}/permissions"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@roles.command(name="update-permissions")
@click.argument("ROLE_ID", metavar="ROLE_ID")
@click.pass_context
def roles_update_permissions(ctx, role_id):
    """Update Role Permissions."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"rbac/roles/{role_id}/permissions"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@roles.command(name="assign")
@click.argument("ROLE_ID", metavar="ROLE_ID")
@click.option("--user-id", "user_id", required=True)
@click.option("--namespace-id", "namespace_id", default=None)
@click.option("--business-justification", "business_justification", default=None)
@click.option("--assignment-source", "assignment_source", default="manual")
@click.option("--expires-at", "expires_at", default=None)
@click.pass_context
def roles_assign(ctx, role_id, user_id, namespace_id, business_justification, assignment_source, expires_at):
    """Assign Role To User."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"roles/{role_id}/assign"
    body = {}
    body["user_id"] = user_id
    if namespace_id is not None:
        body["namespace_id"] = namespace_id
    if business_justification is not None:
        body["business_justification"] = business_justification
    if assignment_source is not None:
        body["assignment_source"] = assignment_source
    if expires_at is not None:
        body["expires_at"] = expires_at

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@roles_role_assignment_grp.command(name="remove")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("ROLE_ID", metavar="ROLE_ID")
@click.argument("USER_ID", metavar="USER_ID")
@click.option("--deactivation-reason", "deactivation_reason", default=None, help="Reason for role removal")
@click.pass_context
def roles_assign_by_user_id(ctx, role_id, user_id, deactivation_reason, yes):
    """Remove Role From User."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"roles/{role_id}/assign/{user_id}"
    params = {}
    if deactivation_reason is not None:
        params["deactivation_reason"] = deactivation_reason

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@roles.command(name="roles-user-permissions")
@click.argument("USER_ID", metavar="USER_ID")
@click.option("--namespace-id", "namespace_id", default=None, help="Optional namespace for scoping")
@click.pass_context
def roles_permissions(ctx, user_id, namespace_id):
    """Get User Permissions."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"roles/users/{user_id}/permissions"
    params = {}
    if namespace_id is not None:
        params["namespace_id"] = namespace_id

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@roles.command(name="expanded-permissions")
@click.argument("ROLE_ID", metavar="ROLE_ID")
@click.pass_context
def roles_expanded_permissions(ctx, role_id):
    """Get Role Expanded Permissions."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"roles/{role_id}/expanded-permissions"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@roles.command(name="validate-permissions")
@click.argument("ROLE_ID", metavar="ROLE_ID")
@click.pass_context
def roles_validate_permissions(ctx, role_id):
    """Validate Role Permissions."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"roles/{role_id}/validate-permissions"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@roles.command(name="all-permissions")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def roles_permissions_1(ctx, page, page_size, fetch_all):
    """Get All Roles And Permissions."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "roles/all/permissions"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


# ──────────────────────────────────────────────────────────────────────────
# BACK-COMPAT — hidden aliases for the old `<noun>-by-<param>` names.
# ⏳ ONE RELEASE ONLY (decision D4). Delete this block next release.
# ──────────────────────────────────────────────────────────────────────────

_LEGACY_BY_PARAM_ROLES = {
    "assign-by-user-id": ("role-assignment", "remove"),
    "roles-by-role-id": ("role", "get"),
}


def _register_legacy_roles_by_param() -> None:
    """Old flat names, hidden so they cannot be discovered anew."""
    import copy
    for _old, (_sub, _verb) in _LEGACY_BY_PARAM_ROLES.items():
        _grp = roles.commands.get(_sub)
        if not isinstance(_grp, click.Group):
            continue
        _cmd = _grp.commands.get(_verb)
        if _cmd is None:
            continue
        # ⛔ Never let an alias overwrite a real group of the same name.
        if isinstance(roles.commands.get(_old), click.Group):
            continue
        _alias = copy.copy(_cmd)
        _alias.name = _old
        _alias.hidden = True
        roles.add_command(_alias)


_register_legacy_roles_by_param()
