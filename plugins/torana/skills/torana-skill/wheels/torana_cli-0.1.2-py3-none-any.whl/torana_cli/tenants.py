"""torana tenants — tenant management commands (super admin)."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 30),
    ("domain", "DOMAIN", 30),
    ("state", "STATE", 12),
    ("created_at", "CREATED", 20),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group()
def tenants():
    """Manage tenants (super admin only).

    \b
    Examples:
      torana tenants list
      torana tenants get <UUID>
      torana tenants create --name "Acme Corp" --domain acme.com
      torana tenants suspend <UUID>
      torana tenants resume <UUID>
      torana tenants force-logout <UUID> --reason "suspected compromise"
    """


@tenants.command(name="list")
@click.option("--state", default=None, help="Filter by state.")
@click.option("--search", default=None, help="Search by name or domain.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.pass_context
def tenants_list(ctx, state, search, page, page_size, fetch_all):
    """List tenants."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if state:
        params["state"] = state
    if search:
        params["search"] = search

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                p.update({k: v for k, v in params.items() if k not in ("skip", "limit")})
                data = client.get("tenants/", params=p)
                items = data.get("items", data if isinstance(data, list) else [])
                all_items.extend(items)
                total = data.get("total", len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items), "page": 1,
                      "page_size": len(all_items)}
        else:
            data = client.get("tenants/", params=params)
            result = data if isinstance(data, dict) and "items" in data else {
                "items": data if isinstance(data, list) else [],
                "total": len(data) if isinstance(data, list) else 0,
                "page": page, "page_size": effective_page_size
            }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@tenants.command(name="get")
@click.argument("tenant_id", metavar="TENANT_ID")
@click.pass_context
def tenants_get(ctx, tenant_id):
    """Get details for a specific tenant."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"tenants/{tenant_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@tenants.command(name="create")
@click.option("--name", default=None)
@click.option("--domain", default=None, help="Tenant domain (e.g. acme.com).")
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def tenants_create(ctx, name, domain, input_file):
    """Create a new tenant."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if domain:
        body["domain"] = domain

    if not body.get("name"):
        click.echo("ERROR: --name is required.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post("tenants/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created tenant: {data.get('id', 'unknown')}")
        click.echo(f"  Name: {data.get('name', '')}")


@tenants.command(name="update")
@click.argument("tenant_id", metavar="TENANT_ID")
@click.option("--name", default=None)
@click.option("--domain", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def tenants_update(ctx, tenant_id, name, domain, input_file):
    """Update a tenant."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if domain:
        body["domain"] = domain

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"tenants/{tenant_id}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated tenant: {tenant_id}")


@tenants.command(name="delete")
@click.argument("tenant_id", metavar="TENANT_ID")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def tenants_delete(ctx, tenant_id, yes):
    """Delete a tenant."""
    _confirm(f"Delete tenant {tenant_id}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"tenants/{tenant_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted tenant: {tenant_id}")


@tenants.command(name="suspend")
@click.argument("tenant_id", metavar="TENANT_ID")
@click.pass_context
def tenants_suspend(ctx, tenant_id):
    """Suspend a tenant (disables all logins)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"tenants/{tenant_id}/suspend/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Suspended tenant: {tenant_id}")


@tenants.command(name="resume")
@click.argument("tenant_id", metavar="TENANT_ID")
@click.pass_context
def tenants_resume(ctx, tenant_id):
    """Resume a suspended tenant."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"tenants/{tenant_id}/resume/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Resumed tenant: {tenant_id}")


@tenants.command(name="force-logout")
@click.argument("tenant_id", metavar="TENANT_ID")
@click.option("--reason", required=True, help="Reason for the force-logout (audited).")
@click.option("--yes", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def tenants_force_logout(ctx, tenant_id, reason, yes):
    """Force-logout all sessions for a tenant.

    Bumps the tenant's token epoch so every outstanding user token for the tenant is
    rejected by the edge token validator (within one cache-TTL window). Use after a
    suspected compromise, or after deleting/recreating a tenant during testing.

    Super admins may force-logout any tenant; a tenant admin may only force-logout
    their own tenant.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    _confirm(f"Force-logout ALL sessions for tenant {tenant_id}?", yes=yes)
    client = _client(ctx)
    try:
        data = client.post(f"tenants/{tenant_id}/force-logout/", json={"reason": reason})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        new_epoch = data.get("token_epoch") if isinstance(data, dict) else None
        click.echo(f"Force-logged-out tenant: {tenant_id} (new token epoch: {new_epoch})")


@tenants.command(name="voice-input-enabled")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def tenants_voice_input_enabled(ctx, page, page_size, fetch_all):
    """Check whether voice input is enabled for this tenant."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "tenants/voice-input-enabled"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@tenants.command(name="hard")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("TENANT_ID", metavar="TENANT_ID")
@click.pass_context
def tenants_hard(ctx, tenant_id, yes):
    """Hard Delete Tenant."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"tenants/{tenant_id}/hard"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@tenants.command(name="usage")
@click.argument("TENANT_ID", metavar="TENANT_ID")
@click.option("--period", "period", default="30d")
@click.pass_context
def tenants_usage(ctx, tenant_id, period):
    """Get Tenant Usage."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"tenants/{tenant_id}/usage"
    params = {}
    if period is not None:
        params["period"] = period

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@tenants.command(name="status")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--db-session", "db_session", default=None)
@click.option("--id", "id", required=True, help="User unique identifier")
@click.option("--email", "email", required=True, help="User email")
@click.option("--name", "name", default=None, help="User display name")
@click.option("--tenant-id", "tenant_id", required=True, help="User's tenant ID")
@click.option("--tenant-name", "tenant_name", default=None, help="User's tenant name")
@click.option("--namespace-id", "namespace_id", default=None, help="User's namespace ID")
@click.option("--roles", "roles", default=None, help="User roles")
@click.option("--permissions", "permissions", default=None, help="User permissions")
@click.option("--is-internal", "is_internal", type=bool, default=False, help="True if this is an internal service user")
@click.option("--is-active", "is_active", type=bool, default=True, help="Whether the user is active")
@click.option("--is-verified", "is_verified", type=bool, default=False, help="Whether the user is verified")
@click.option("--user-info", "user_info", default=None, help="Original user info from token")
@click.pass_context
def tenants_status(ctx, db_session, id, email, name, tenant_id, tenant_name, namespace_id, roles, permissions, is_internal, is_active, is_verified, user_info, page, page_size, fetch_all):
    """Get tenant database status."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "tenants/status"
    params = {}
    if db_session is not None:
        params["db_session"] = db_session
    body = {}
    body["id"] = id
    body["email"] = email
    if name is not None:
        body["name"] = name
    body["tenant_id"] = tenant_id
    if tenant_name is not None:
        body["tenant_name"] = tenant_name
    if namespace_id is not None:
        body["namespace_id"] = namespace_id
    if roles is not None:
        body["roles"] = roles
    if permissions is not None:
        body["permissions"] = permissions
    if is_internal is not None:
        body["is_internal"] = is_internal
    if is_active is not None:
        body["is_active"] = is_active
    if is_verified is not None:
        body["is_verified"] = is_verified
    if user_info is not None:
        body["user_info"] = user_info
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@tenants.command(name="reset")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with request body. Use '-' for stdin.")
@click.option("--db-session", "db_session", default=None)
@click.option("--id", "id", required=True, help="User unique identifier")
@click.option("--email", "email", required=True, help="User email")
@click.option("--name", "name", default=None, help="User display name")
@click.option("--tenant-id", "tenant_id", required=True, help="User's tenant ID")
@click.option("--tenant-name", "tenant_name", default=None, help="User's tenant name")
@click.option("--namespace-id", "namespace_id", default=None, help="User's namespace ID")
@click.option("--roles", "roles", default=None, help="User roles")
@click.option("--permissions", "permissions", default=None, help="User permissions")
@click.option("--is-internal", "is_internal", type=bool, default=False, help="True if this is an internal service user")
@click.option("--is-active", "is_active", type=bool, default=True, help="Whether the user is active")
@click.option("--is-verified", "is_verified", type=bool, default=False, help="Whether the user is verified")
@click.option("--user-info", "user_info", default=None, help="Original user info from token")
@click.pass_context
def tenants_reset(ctx, db_session, id, email, name, tenant_id, tenant_name, namespace_id, roles, permissions, is_internal, is_active, is_verified, user_info, input_file):
    """Reset tenant database."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "tenants/reset"
    params = {}
    if db_session is not None:
        params["db_session"] = db_session
    if input_file:
        body = _load_input_file(input_file)
    else:
        body = {}
        body["id"] = id
        body["email"] = email
        if name is not None:
            body["name"] = name
        body["tenant_id"] = tenant_id
        if tenant_name is not None:
            body["tenant_name"] = tenant_name
        if namespace_id is not None:
            body["namespace_id"] = namespace_id
        if roles is not None:
            body["roles"] = roles
        if permissions is not None:
            body["permissions"] = permissions
        if is_internal is not None:
            body["is_internal"] = is_internal
        if is_active is not None:
            body["is_active"] = is_active
        if is_verified is not None:
            body["is_verified"] = is_verified
        if user_info is not None:
            body["user_info"] = user_info

    client = _client(ctx)
    try:
        data = client.post(path, json=body, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@tenants.command(name="purge")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.option("--db-session", "db_session", default=None)
@click.option("--id", "id", required=True, help="User unique identifier")
@click.option("--email", "email", required=True, help="User email")
@click.option("--name", "name", default=None, help="User display name")
@click.option("--tenant-id", "tenant_id", required=True, help="User's tenant ID")
@click.option("--tenant-name", "tenant_name", default=None, help="User's tenant name")
@click.option("--namespace-id", "namespace_id", default=None, help="User's namespace ID")
@click.option("--roles", "roles", default=None, help="User roles")
@click.option("--permissions", "permissions", default=None, help="User permissions")
@click.option("--is-internal", "is_internal", type=bool, default=False, help="True if this is an internal service user")
@click.option("--is-active", "is_active", type=bool, default=True, help="Whether the user is active")
@click.option("--is-verified", "is_verified", type=bool, default=False, help="Whether the user is verified")
@click.option("--user-info", "user_info", default=None, help="Original user info from token")
@click.pass_context
def tenants_purge(ctx, db_session, id, email, name, tenant_id, tenant_name, namespace_id, roles, permissions, is_internal, is_active, is_verified, user_info, yes):
    """Purge tenant database."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = "tenants/purge"
    params = {}
    if db_session is not None:
        params["db_session"] = db_session
    body = {}
    body["id"] = id
    body["email"] = email
    if name is not None:
        body["name"] = name
    body["tenant_id"] = tenant_id
    if tenant_name is not None:
        body["tenant_name"] = tenant_name
    if namespace_id is not None:
        body["namespace_id"] = namespace_id
    if roles is not None:
        body["roles"] = roles
    if permissions is not None:
        body["permissions"] = permissions
    if is_internal is not None:
        body["is_internal"] = is_internal
    if is_active is not None:
        body["is_active"] = is_active
    if is_verified is not None:
        body["is_verified"] = is_verified
    if user_info is not None:
        body["user_info"] = user_info

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@tenants.command(name="preview")
@click.argument("TENANT_ID", metavar="TENANT_ID")
@click.pass_context
def tenants_preview(ctx, tenant_id):
    """Preview Tenant Deletion."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"tenants/{tenant_id}/hard/preview"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)
