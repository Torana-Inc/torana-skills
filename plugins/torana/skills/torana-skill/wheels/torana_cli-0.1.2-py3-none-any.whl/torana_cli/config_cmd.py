"""torana config — configuration management commands."""

import sys

import click
import yaml

from torana_cli.config.settings import (
    CONFIG_FILE,
    activate_profile,
    create_profile,
    delete_profile,
    get_active_profile_name,
    get_config_value,
    get_settings,
    list_profiles,
    set_config_value,
)
from torana_cli.main import CTX_FORMAT, CTX_PROFILE
from torana_cli.output import output
from torana_cli.confirm import confirm as _confirm

# Valid settable keys with descriptions
VALID_KEYS = {
    "email": "Default login email address",
    "format": "Default output format (text|json|yaml|table)",
    "log-level": "Log verbosity (debug|info|warn|error)",
    "log-format": "Log format (text|json)",
    "log-file": "Log file path",
    "page-size": "Default page size for list commands (max 100)",
    "base-url": "Torana API base URL (nginx gateway)",
}


@click.group(name="config")
def config():
    """Manage CLI configuration.

    \b
    Examples:
      torana config set email <your-email>
      torana config set format json
      torana config get email
      torana config list
      torana config profiles list
      torana config profiles activate production
    """


@config.command(name="set")
@click.argument("key", metavar="KEY")
@click.argument("value", metavar="VALUE")
@click.pass_context
def config_set(ctx, key, value):
    """Set a configuration value in the active profile.

    \b
    Valid keys:
      email       Default login email
      format      Output format: text|json|yaml|table
      log-level   Log verbosity: debug|info|warn|error
      log-format  Log format: text|json
      log-file    Log file path
      page-size   Default page size (max 100)
      base-url    Torana API base URL

    \b
    Examples:
      torana config set email <your-email>
      torana config set format json
      torana config set log-level debug
    """
    normalized = key.lower().replace("_", "-")
    if normalized not in VALID_KEYS:
        click.echo(f"ERROR: Unknown key '{key}'. Valid keys: {', '.join(VALID_KEYS)}", err=True)
        sys.exit(2)

    # Validate certain values
    if normalized == "format" and value not in ("text", "json", "yaml", "table"):
        click.echo("ERROR: format must be one of: text, json, yaml, table", err=True)
        sys.exit(6)
    if normalized == "log-level" and value not in ("debug", "info", "warn", "error"):
        click.echo("ERROR: log-level must be one of: debug, info, warn, error", err=True)
        sys.exit(6)
    if normalized == "page-size":
        try:
            n = int(value)
            if n < 1 or n > 100:
                raise ValueError
        except ValueError:
            click.echo("ERROR: page-size must be an integer between 1 and 100", err=True)
            sys.exit(6)

    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    set_config_value(normalized, value, profile)
    click.echo(f"Set {normalized} = {value}")


@config.command(name="get")
@click.argument("key", metavar="KEY")
@click.pass_context
def config_get(ctx, key):
    """Get a configuration value from the active profile.

    \b
    Example:
      torana config get email
    """
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    value = get_config_value(key, profile)
    if value is None:
        click.echo(f"ERROR: Key '{key}' not found.", err=True)
        sys.exit(3)
    click.echo(value)


@config.command(name="show")
@click.pass_context
def config_show(ctx):
    """Show what this invocation will actually use — profile, base URL, identity.

    \b
    ⚠️ Answers "why is my login going to the wrong platform?". `active_profile` in
    ~/.torana/config.yaml is STICKY: it persists across shells, so a profile set
    once keeps applying until something overrides it. This prints the resolved
    value AND where each one came from, so a surprise is visible immediately
    rather than after a debugging session.

    \b
    Example:
      torana config show
    """
    import os
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    profile_name = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile_name)

    # Provenance matters more than the value — a base_url that came from the
    # environment and one that came from the config file fail very differently.
    if profile_name:
        profile_src = "--profile flag"
    elif os.environ.get("TORANA_PROFILE"):
        profile_src = "TORANA_PROFILE env var"
    else:
        profile_src = "active_profile in ~/.torana/config.yaml (sticky)"

    url_src = ("TORANA_BASE_URL env var" if os.environ.get("TORANA_BASE_URL")
               else f"profile '{settings.active_profile}' in ~/.torana/config.yaml")

    rows = [
        {"setting": "active_profile", "value": settings.active_profile, "source": profile_src},
        {"setting": "base_url", "value": settings.base_url, "source": url_src},
        {"setting": "email", "value": settings.email or "(none cached)",
         "source": "profile cache — run `torana auth me` for the live identity"},
        {"setting": "format", "value": settings.format, "source": "profile"},
        {"setting": "page_size", "value": str(settings.page_size), "source": "profile"},
        {"setting": "config_file", "value": str(CONFIG_FILE), "source": "fixed"},
    ]

    if fmt in ("json", "yaml"):
        output({"items": rows, "total": len(rows)}, fmt=fmt)
        return

    click.echo("Resolved configuration for this invocation:\n")
    for r in rows:
        click.echo(f"  {r['setting']:<16} {r['value']}")
        click.echo(f"  {'':<16} \u2514\u2500 {r['source']}")
    click.echo("\n  Identity is NOT shown here (it is a live call): torana auth me")


@config.command(name="list")
@click.pass_context
def config_list(ctx):
    """List all configuration values for the active profile.

    \b
    Example:
      torana config list
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    profile_name = ctx.obj.get(CTX_PROFILE) if ctx.obj else None

    active = get_active_profile_name()
    profiles = list_profiles()
    current = profiles.get(profile_name or active, {})

    if fmt == "json":
        import json
        click.echo(json.dumps({"profile": profile_name or active, "settings": current}, indent=2))
    elif fmt == "yaml":
        click.echo(yaml.dump({"profile": profile_name or active, "settings": current}))
    else:
        click.echo(f"Profile: {profile_name or active}")
        click.echo()
        max_k = max((len(k) for k in current), default=10)
        for k, v in current.items():
            click.echo(f"  {k.ljust(max_k)}  {v}")


# ── Profiles sub-group ─────────────────────────────────────────────────────────

@config.group(name="profiles")
def profiles():
    """Manage configuration profiles.

    \b
    Examples:
      torana config profiles list
      torana config profiles activate production
      torana config profiles create staging --base-url https://staging.torana.ai
      torana config profiles delete staging
    """


@profiles.command(name="list")
@click.pass_context
def profiles_list(ctx):
    """List all configuration profiles."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    active = get_active_profile_name()
    all_profiles = list_profiles()

    if fmt == "json":
        import json
        click.echo(json.dumps({"active": active, "profiles": all_profiles}, indent=2))
        return
    if fmt == "yaml":
        click.echo(yaml.dump({"active": active, "profiles": all_profiles}))
        return

    click.echo(f"Active profile: {active}\n")
    for name, settings in all_profiles.items():
        marker = " *" if name == active else ""
        click.echo(f"  {name}{marker}")
        click.echo(f"    base_url: {settings.get('base_url', 'http://localhost')}")
        click.echo(f"    email:    {settings.get('email', '')}")
        click.echo()


@profiles.command(name="activate")
@click.argument("name")
def profiles_activate(name):
    """Activate a named profile.

    \b
    Example:
      torana config profiles activate production
    """
    try:
        activate_profile(name)
    except ValueError as e:
        click.echo(f"ERROR: {e}", err=True)
        sys.exit(3)
    click.echo(f"Activated profile: {name}")


@profiles.command(name="create")
@click.argument("name")
@click.option("--base-url", required=True, help="Nginx gateway URL for this profile.")
@click.option("--email", default="", help="Default email for this profile.")
@click.option("--format", "fmt", default="text", help="Default output format.")
def profiles_create(name, base_url, email, fmt):
    """Create a new configuration profile.

    \b
    Example:
      torana config profiles create staging --base-url https://staging.torana.ai --email admin@stage.com
    """
    create_profile(name, base_url=base_url, email=email, format=fmt)
    click.echo(f"Created profile: {name}")
    click.echo(f"  base_url: {base_url}")
    if email:
        click.echo(f"  email: {email}")
    click.echo(f"\nActivate with: torana config profiles activate {name}")


@profiles.command(name="delete")
@click.argument("name")
@click.option("--yes", is_flag=True, help="Skip confirmation prompt.")
def profiles_delete(name, yes):
    """Delete a named profile.

    \b
    Example:
      torana config profiles delete staging --yes
    """
    _confirm(f"Delete profile '{name}'?", yes=yes)
    try:
        delete_profile(name)
    except ValueError as e:
        click.echo(f"ERROR: {e}", err=True)
        sys.exit(3)
    click.echo(f"Deleted profile: {name}")
