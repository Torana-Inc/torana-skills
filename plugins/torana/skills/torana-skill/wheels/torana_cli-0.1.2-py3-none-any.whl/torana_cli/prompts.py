"""torana prompts — agent prompt library COLLECTION commands.

Collection operations only (no instance ID): list, create, and cross-cutting
lookups. Instance operations (get/update/delete/... by ID) live in the singular
``prompt`` group in torana_cli/prompt.py.
"""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.rules import _load_input_file

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 30),
    ("agent_id", "AGENT", 36),
    ("drift", "STATUS", 12),
    ("description", "DESCRIPTION", 40),
]


def _drift_label(item):
    """Map the API's has_drift bool to the DRIFT / UP-TO-DATE column value.

    Grep-friendly: `torana prompts list | grep DRIFT` returns only drifted rows
    (UP-TO-DATE does not contain the token "DRIFT").
    """
    return "DRIFT" if item.get("has_drift") else "UP-TO-DATE"


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(name="prompts")
def prompts():
    """Manage the agent prompt library (collection).

    \b
    Examples:
      torana prompts list --agent-id <UUID>
      torana prompts create --file prompt.yaml
      torana prompts categories
    \b
    Instance operations use the singular group:
      torana prompt <UUID> get
      torana prompt <UUID> reload-from-source
      torana prompt <UUID> delete --yes
    """


@prompts.command(name="list")
@click.option("--agent-id", default=None, help="Filter by agent UUID.")
@click.option("--search", default=None, help="Search by name.")
@click.option("--show-drift", is_flag=True, default=False,
              help="Show ONLY prompts that have drifted from their source file.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def prompts_list(ctx, agent_id, search, show_drift, page, page_size):
    """List prompts.

    The DRIFT column is always shown (DRIFT / UP-TO-DATE), so you can do:
      torana prompts list | grep DRIFT      # only drifted prompts

    Use --show-drift to filter server-side listing to drifted prompts only.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if agent_id:
        params["agent_id"] = agent_id
    if search:
        params["search"] = search
    # Drift status is always requested so the DRIFT column is always populated.
    params["show_drift"] = "true"

    client = _client(ctx)
    try:
        data = client.get("prompts/", params=params)
        if isinstance(data, dict) and "items" in data:
            items = data["items"]
            total = data.get("total", len(items))
        elif isinstance(data, dict) and "prompts" in data:
            # Agent-builder returns {"prompts": [...], "total": N} — normalize to items envelope
            items = data["prompts"]
            total = data.get("total", len(items))
        else:
            items = data if isinstance(data, list) else []
            total = len(items)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Derive the grep-friendly DRIFT / UP-TO-DATE column value on every row.
    for item in items:
        if isinstance(item, dict):
            item["drift"] = _drift_label(item)

    # --show-drift narrows the listing to drifted prompts only (client-side).
    if show_drift:
        items = [i for i in items if isinstance(i, dict) and i.get("has_drift")]
        total = len(items)

    result = {"items": items, "total": total, "page": page, "page_size": effective_page_size}
    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@prompts.command(name="create")
@click.option("--name", default=None)
@click.option("--content", default=None, help="Prompt content text.")
@click.option("--agent-id", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def prompts_create(ctx, name, content, agent_id, input_file):
    """Create a new prompt."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if content:
        body["content"] = content
    if agent_id:
        body["agent_id"] = agent_id

    if not body.get("name"):
        click.echo("ERROR: --name is required.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post("prompts/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created prompt: {data.get('id', 'unknown')}")


@prompts.command(name="categories")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.pass_context
def prompts_categories(ctx, page, page_size, fetch_all):
    """Get Categories."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "prompts/categories"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@prompts.command(name="popular")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--limit", "limit", type=int, default=10, help="Number of prompts to return")
@click.pass_context
def prompts_popular(ctx, limit, page, page_size, fetch_all):
    """Get Popular Prompts."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "prompts/popular"
    params = {}
    if limit is not None:
        params["limit"] = limit
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@prompts.command(name="recent")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--limit", "limit", type=int, default=10, help="Number of prompts to return")
@click.pass_context
def prompts_recent(ctx, limit, page, page_size, fetch_all):
    """Get Recent Prompts."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "prompts/recent"
    params = {}
    if limit is not None:
        params["limit"] = limit
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


@prompts.command(name="by-name")
@click.argument("NAME", metavar="NAME")
@click.pass_context
def prompts_by_name(ctx, name):
    """Get a prompt by its name."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"prompts/by-name/{name}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@prompts.command(name="validate")
@click.pass_context
def prompts_validate(ctx):
    """Validate Prompt."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "prompts/validate"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)
