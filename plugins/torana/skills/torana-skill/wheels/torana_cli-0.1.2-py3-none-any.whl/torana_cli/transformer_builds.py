"""torana datalake transformers builds / build — the durable build record.

DT_BATCHED_DBT_SPEC § 3.12.2 / § 3.12.7. One row per build request (a sweep's tenant, a
repair, a drain's execute-batch), from `requested` to a terminal state; the server reads
`transformer_builds`, this module only renders.

    torana datalake transformers builds list  [--state] [--all-tenants] [--limit]
    torana datalake transformers builds stats [--window 24h] [--all-tenants]
    torana datalake transformers build <BUILD_ID> show [--follow]
    torana datalake transformers builds locks list [--all-tenants]

Relation build locks (pantheon-data-transformers core/relation_locks.py): every builder of a
relation holds that relation's lock while it builds; another builder waits (bounded), and a
relation still held at the end of the wait is `lock_busy` — NOT failed — naming the holder.

⚠️ The spec writes these as `builds [--stats]` and `build <id>`; the CLI's hard rules
(collections are groups with a `list` verb, no group has a default action) put them as
`builds list|stats` and `build <id> show`.

Every state is a glyph plus a word, never colour alone (the maintainer is red/green
colour-blind).
"""
import json
import re
import sys
import time

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FORMAT, CTX_PROFILE

TERMINAL = ("done", "failed", "abandoned", "skipped")
LIVE_STATES = "requested,queued,locked,wave,maintenance,dependents"
FOLLOW_SECONDS = 5
_UUID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I)

# § 3.12.7 glyphs: ✓ done/success, ✗ failed, ▶ live, … queued, ⚠ stuck/abandoned,
# – skipped/deferred. Always followed by the word.
_STATE_GLYPH = {"done": "✓", "success": "✓", "failed": "✗", "abandoned": "⚠",
                "skipped": "–", "requested": "…", "queued": "…", "pending": "…"}


def state_label(state, stuck=False, item=False) -> str:
    """`✓ done`, `▶ wave`, `⚠ stuck (wave)`. An unlisted BUILD state is live (`▶`); an
    unlisted ITEM status (unverified, lock_contention, sweep_blocked…) needs a look (`⚠`)."""
    s = str(state or "?")
    if stuck:
        return f"⚠ stuck ({s})"
    if s.startswith("deferred") or s in ("already_current", "not_found", "lock_busy"):
        return f"– {s}"
    return f"{_STATE_GLYPH.get(s, '⚠' if item else '▶')} {s}"


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    return ToranaClient(base_url=get_settings(profile).base_url)


def _fmt(ctx, local_fmt=None) -> str:
    return local_fmt or (ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text")


def _get(ctx, path, params=None):
    try:
        return _client(ctx).get(path, params=params)
    except APIError as e:
        handle_api_error(e)
    except AuthError as e:
        handle_auth_error(e)
    return None


def _hhmmss(ts) -> str:
    """`2026-09-25T14:02:11.123` → `14:02:11` (UTC, as stored)."""
    return str(ts)[11:19] if ts else "—"


def _secs(ms) -> str:
    if ms is None:
        return "—"
    return "<1s" if 0 < ms < 1000 else f"{round(ms / 1000)}s"


def render_builds_table(builds, show_tenant=False) -> str:
    lines = [f"{'BUILD':9} {'CALLER':13} {'MODE':8} {'STATE':20} {'POSITION':32} "
             f"{'ITEMS':8} {'FAILED':7} {'BUSY':5} {'REQUESTED':10} {'WALL':7} {'RL WAIT':8} "
             f"REASONS" + ("  TENANT" if show_tenant else "")]
    for b in builds:
        items = f"{b.get('items_done', 0)}/{b.get('items_total', 0)}"
        # DT_MATERIALIZATION_POLICY_SPEC § 3.3.2: the union of the items' reasons. "—" for a
        # build recorded before reasons existed (never a guessed reason).
        reasons = ",".join(b.get("reasons") or []) or "—"
        lines.append(f"{str(b['build_id'])[:8]:9} {str(b.get('caller')):13} "
                     f"{str(b.get('mode')):8} "
                     f"{state_label(b.get('state'), b.get('stuck')):20} "
                     f"{str(b.get('position') or '—')[:32]:32} {items:8} "
                     f"{b.get('items_failed', 0):<7} {b.get('items_lock_busy') or 0:<5} "
                     f"{_hhmmss(b.get('requested_at')):10} "
                     f"{_secs(b.get('wall_ms')):7} {_secs(b.get('relation_lock_wait_ms')):8} "
                     f"{reasons[:40]}"
                     + (f"  {str(b.get('tenant_id') or 'another tenant')[:8]}"
                        if show_tenant else ""))
    if not builds:
        lines.append("  (no builds)")
    return "\n".join(lines)


def render_build_detail(d) -> str:
    head = (f"build {str(d['build_id'])[:8]}  {d.get('caller')}  {d.get('mode')}  "
            f"{state_label(d.get('state'), d.get('stuck'))}  "
            f"{d.get('items_done', 0)}/{d.get('items_total', 0)}  "
            f"spawns {d.get('spawns', 0)}  wall {_secs(d.get('wall_ms'))}  "
            f"lock wait {_secs(d.get('lock_wait_ms'))}  "
            f"relation-lock wait {_secs(d.get('relation_lock_wait_ms'))}  "
            f"trace {str(d.get('trace_id') or '—')[:8]}…")
    lines = [head]
    if d.get("items_lock_busy"):
        lines.append(f"  – lock_busy {d['items_lock_busy']}: another builder held the relation "
                     f"for the whole wait (not failed) — see each item")
    if d.get("position"):
        lines.append(f"  at: {d['position']}")
    for k in ("fallback_reason", "stopped"):
        if d.get(k):
            lines.append(f"  {k.replace('_', ' ')}: {d[k]}")
    lines.append(f"  {'WAVE':5} {'MODEL':34} {'STATUS':26} NOTES / REMEDY")
    for it in d.get("items") or []:
        status = state_label(it.get("status"), item=True)
        extra = it.get("remedy") or ", ".join(it.get("notes") or []) or ""
        wave = it.get("wave") if it.get("wave") is not None else "—"
        lines.append(f"  {str(wave):5} {it['model'][:34]:34} {status[:26]:26} {extra}")
        if it.get("reasons") or it.get("swap"):
            lines.append(f"  {'':5} {'':34} reasons: {', '.join(it.get('reasons') or []) or '—'}"
                         + (f"  swap: {it['swap']}" if it.get("swap") else ""))
        if it.get("lock_busy_by") or it.get("lock_wait_ms"):
            lines.append(f"  {'':5} {'':34} relation lock: waited {_secs(it.get('lock_wait_ms'))}"
                         + (f", held by {it['lock_busy_by']}" if it.get("lock_busy_by") else ""))
        if it.get("fallback_reason"):
            lines.append(f"  {'':5} {'':34} reason: {it['fallback_reason']}")
        if it.get("error"):
            lines.append(f"  {'':5} {'':34} error:  {str(it['error'])[:200]}")
        if str(it.get("status") or "").startswith("sweep_blocked") or \
                str(it.get("fallback_reason") or "").startswith("sweep_blocked"):
            lines.append(f"  {'':5} {'':34} release: torana datalake transformer "
                         f"{it['model']} sweep --allow-mass-tombstone")
    owed = d.get("owed_dependents") or []
    if owed:
        lines.append(f"  owed dependents ({len(owed)}): "
                     + ", ".join(o.get("model", "?") for o in owed[:10])
                     + (" …" if len(owed) > 10 else ""))
    return "\n".join(lines)


def render_stats(s) -> str:
    rate = s.get("failure_rate")
    lines = [f"Builds — {s.get('scope')} — last {s.get('window_hours')}h",
             f"  builds {s.get('builds', 0)} · ✗ failed {s.get('failed', 0)}"
             f" ({'—' if rate is None else f'{rate:.1%}'}) · ⚠ abandoned "
             f"{s.get('abandoned', 0)} · – skipped {s.get('skipped', 0)}",
             f"  wall p50 {_secs(s.get('wall_ms_p50'))} · p95 {_secs(s.get('wall_ms_p95'))}"
             f" · lock wait p50 {_secs(s.get('lock_wait_ms_p50'))} · p95 "
             f"{_secs(s.get('lock_wait_ms_p95'))} · spawns/build "
             f"{s.get('spawns_per_build_avg') if s.get('spawns_per_build_avg') is not None else '—'}"]
    fb = s.get("fallbacks_by_reason") or {}
    lines.append("  fallbacks: " + (", ".join(f"{k} {v}" for k, v in sorted(fb.items()))
                                    if fb else "none"))
    # Relation build locks: items that ended lock_busy (not failures) and how long builds
    # waited for another builder of the same relation.
    lines.append(f"  relation locks: – lock_busy {s.get('items_lock_busy', 0)} item(s) in "
                 f"{s.get('builds_lock_busy', 0)} build(s) · wait p50 "
                 f"{_secs(s.get('relation_lock_wait_ms_p50'))} · p95 "
                 f"{_secs(s.get('relation_lock_wait_ms_p95'))} · max "
                 f"{_secs(s.get('relation_lock_wait_ms_max'))}")
    by_tenant = s.get("by_tenant") or []
    if by_tenant:
        lines.append(f"  {'TENANT':10} {'BUILDS':>6} {'FAILED':>6} {'WALL P95':>9} "
                     f"{'BUSY':>5} {'RL WAIT P95':>11}")
        for t in by_tenant:
            lines.append(f"  {str(t.get('tenant_id'))[:8]:10} {t.get('builds', 0):>6} "
                         f"{t.get('failed', 0):>6} {_secs(t.get('wall_ms_p95')):>9} "
                         f"{t.get('items_lock_busy', 0):>5} "
                         f"{_secs(t.get('relation_lock_wait_ms_p95')):>11}")
    return "\n".join(lines)


@click.group(name="builds")
@click.pass_context
def builds(ctx):
    """Transformer builds — who is building, who is waiting, and how builds went.

    \b
    One row per build request (sweep, repair, drain, execute-batch), newest first.
    States: … requested/queued, ▶ locked/wave/maintenance/dependents, ✓ done,
    ✗ failed, ⚠ abandoned/stuck, – skipped.

    \b
    Examples:
      TORANA_PROFILE=T1 torana datalake transformers builds list
      TORANA_PROFILE=T1 torana datalake transformers builds list --state queued,locked,wave
      TORANA_PROFILE=SA torana datalake transformers builds list --all-tenants
      TORANA_PROFILE=T1 torana datalake transformers builds stats --window 24h
      TORANA_PROFILE=T1 torana datalake transformers builds locks list
    """
    ctx.ensure_object(dict)


@builds.command(name="list")
@click.option("--state", default=None,
              help=f"Comma-separated states. `live` = {LIVE_STATES}.")
@click.option("--all-tenants", is_flag=True, default=False,
              help="Super admin: every tenant's builds (403 on a tenant profile).")
@click.option("--limit", type=click.IntRange(1, 100), default=50, show_default=True)
@click.option("--format", "local_fmt", type=click.Choice(["text", "json"]), default=None)
@click.pass_context
def builds_list(ctx, state, all_tenants, limit, local_fmt):
    """List builds, newest first.

    \b
    Examples:
      TORANA_PROFILE=T1 torana datalake transformers builds list
      TORANA_PROFILE=T1 torana datalake transformers builds list --state live
      TORANA_PROFILE=SA torana datalake transformers builds list --all-tenants --state live
    """
    params = {"limit": limit}
    if state:
        params["state"] = LIVE_STATES if state == "live" else state
    if all_tenants:
        params["all_tenants"] = "true"
    data = _get(ctx, "transformers/builds", params)
    if data is None:
        return
    if _fmt(ctx, local_fmt) == "json":
        click.echo(json.dumps(data, indent=2, default=str))
        return
    click.echo(render_builds_table(data.get("builds") or [], show_tenant=all_tenants))
    click.echo(f"({len(data.get('builds') or [])} of {data.get('total', 0)} builds)")


@builds.command(name="stats")
@click.option("--window", default="24h", show_default=True,
              help="Look-back window in hours, e.g. 24h, 168h.")
@click.option("--all-tenants", is_flag=True, default=False,
              help="Super admin: fleet-wide, with one row per tenant.")
@click.option("--format", "local_fmt", type=click.Choice(["text", "json"]), default=None)
@click.pass_context
def builds_stats(ctx, window, all_tenants, local_fmt):
    """Failure rate, fallbacks and durations over a window (fleet-wide, survives restarts).

    \b
    Examples:
      TORANA_PROFILE=T1 torana datalake transformers builds stats
      TORANA_PROFILE=SA torana datalake transformers builds stats --window 168h --all-tenants
    """
    params = {"window": window}
    if all_tenants:
        params["all_tenants"] = "true"
    data = _get(ctx, "transformers/builds/stats", params)
    if data is None:
        return
    if _fmt(ctx, local_fmt) == "json":
        click.echo(json.dumps(data, indent=2, default=str))
        return
    click.echo(render_stats(data))


def _resolve_build_id(ctx, ident) -> str:
    """A full UUID as-is; an 8+ char prefix (as the list prints) by the newest 100 builds."""
    if _UUID_RE.match(ident or ""):
        return ident
    data = _get(ctx, "transformers/builds", {"limit": 100}) or {}
    hits = [b["build_id"] for b in data.get("builds") or []
            if str(b["build_id"]).startswith(ident.lower())]
    if not hits:
        # A super admin looking at another tenant's build; a tenant profile gets 403,
        # which only means "not yours", so it is swallowed here.
        try:
            data = _client(ctx).get("transformers/builds",
                                    params={"limit": 100, "all_tenants": "true"}) or {}
            hits = [b["build_id"] for b in data.get("builds") or []
                    if str(b["build_id"]).startswith(ident.lower())]
        except (APIError, AuthError):
            pass
    if len(hits) == 1:
        return hits[0]
    click.echo(f"ERROR: '{ident}' matches {len(hits)} of the newest 100 builds — "
               f"pass the full build id.", err=True)
    sys.exit(3 if not hits else 6)


@click.group(name="build", invoke_without_command=True)
@click.argument("build_id", metavar="BUILD_ID")
@click.pass_context
def build(ctx, build_id):
    """One build: its waves, each item's status, reason and remedy.

    BUILD_ID is the full id or the 8-character prefix `builds list` prints.

    \b
    Examples:
      TORANA_PROFILE=T1 torana datalake transformers build 3f9a1c2b show
      TORANA_PROFILE=T1 torana datalake transformers build 3f9a1c2b show --follow
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())
        return
    ctx.obj["_build_id"] = _resolve_build_id(ctx, build_id)


@build.command(name="show")
@click.option("--follow", is_flag=True, default=False,
              help=f"Re-print every {FOLLOW_SECONDS}s until the build is terminal.")
@click.option("--format", "local_fmt", type=click.Choice(["text", "json"]), default=None)
@click.pass_context
def build_show(ctx, follow, local_fmt):
    """Show the build detail; with --follow, poll until it ends.

    \b
    Examples:
      TORANA_PROFILE=T1 torana datalake transformers build 3f9a1c2b show
      TORANA_PROFILE=T1 torana datalake transformers build 3f9a1c2b show --follow
    """
    bid = ctx.obj["_build_id"]
    fmt = _fmt(ctx, local_fmt)
    while True:
        data = _get(ctx, f"transformers/builds/{bid}")
        if data is None:
            return
        if fmt == "json":
            click.echo(json.dumps(data, indent=2, default=str))
        else:
            if follow:
                click.clear()
            click.echo(render_build_detail(data))
        if not follow or data.get("state") in TERMINAL:
            return
        try:
            time.sleep(FOLLOW_SECONDS)
        except KeyboardInterrupt:
            return


# ── Relation build locks: who holds, who waits (GET /transformers/builds/relation-locks) ──

def lock_items(data) -> list:
    """The report's holders and waiters as ONE collection (the CLI's collection contract),
    each row tagged `role` = holding | waiting."""
    return ([{**h, "role": "holding"} for h in data.get("holders") or []]
            + [{**w, "role": "waiting"} for w in data.get("waiters") or []])


def render_locks_table(items, show_tenant=False) -> str:
    lines = [f"{'ROLE':10} {'RELATION':34} {'OWNER':20} {'CALLER':12} {'POSITION':24} "
             f"{'WAITING':8} BLOCKED BY" + ("  TENANT" if show_tenant else "")]
    for it in items:
        role = "▶ holding" if it["role"] == "holding" else "… waiting"
        owner = f"{it.get('owner_kind', '?')} {str(it.get('owner_id') or '')[:8]}"
        blocked = (f"{it.get('blocked_by_kind')} {str(it.get('blocked_by_id') or '')[:8]}"
                   if it.get("blocked_by_id") else "—")
        lines.append(f"{role:10} {str(it.get('relation'))[:34]:34} {owner:20} "
                     f"{str(it.get('caller') or '—')[:12]:12} "
                     f"{str(it.get('position') or '—')[:24]:24} "
                     f"{_secs(it.get('waiting_ms')) if it['role'] == 'waiting' else '—':8} "
                     f"{blocked}"
                     + (f"  {str(it.get('tenant_id') or '')[:8]}" if show_tenant else ""))
    if not items:
        lines.append("  (no relation locks held — nothing is building)")
    return "\n".join(lines)


@builds.group(name="locks", invoke_without_command=True)
@click.pass_context
def builds_locks(ctx):
    """Relation build locks — which builder holds each relation, and who waits for it.

    \b
    Every builder (rebuild-all, execute, execute-batch, the drain, the tick, the sweep,
    repair) locks the relations it builds. A second builder of the same relation waits;
    one still held when its wait ends is `lock_busy` (not failed), naming the holder.

    \b
    Examples:
      TORANA_PROFILE=T1 torana datalake transformers builds locks list
      TORANA_PROFILE=SA torana datalake transformers builds locks list --all-tenants
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@builds_locks.command(name="list")
@click.option("--all-tenants", is_flag=True, default=False,
              help="Super admin: every tenant's relation locks (403 on a tenant profile).")
@click.option("--format", "local_fmt", type=click.Choice(["text", "json"]), default=None)
@click.pass_context
def builds_locks_list(ctx, all_tenants, local_fmt):
    """List relation locks held and waited for right now (read from Postgres, any pod).

    \b
    Examples:
      TORANA_PROFILE=T1 torana datalake transformers builds locks list
      TORANA_PROFILE=SA torana datalake transformers builds locks list --all-tenants
      TORANA_PROFILE=T1 torana datalake transformers builds locks list --format json
    """
    params = {"all_tenants": "true"} if all_tenants else None
    data = _get(ctx, "transformers/builds/relation-locks", params)
    if data is None:
        return
    items = lock_items(data)
    if _fmt(ctx, local_fmt) == "json":
        click.echo(json.dumps({"items": items, "total": len(items),
                               "scope": data.get("scope")}, indent=2, default=str))
        return
    click.echo(render_locks_table(items, show_tenant=all_tenants))
    n_wait = sum(1 for i in items if i["role"] == "waiting")
    click.echo(f"({len(items) - n_wait} held · {n_wait} waiting)")
