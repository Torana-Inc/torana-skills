"""torana suite <ID> — instance-scoped suite commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _sid(ctx) -> str:
    return ctx.obj.get("_suite_id", "") if ctx.obj else ""


@click.group(name="suite", invoke_without_command=True)
@click.argument("suite_id", metavar="SUITE_ID")
@click.pass_context
def suite(ctx, suite_id):
    """Manage a single detection suite by ID.

    \b
    Examples:
      torana suite <UUID> get
      torana suite <UUID> activate
      torana suite <UUID> execute
      torana suite <UUID> rules-add --rule-id <RULE_ID>
      torana suite <UUID> delete --yes
    """
    ctx.ensure_object(dict)
    ctx.obj["_suite_id"] = suite_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@suite.command(name="get")
@click.pass_context
def suite_get(ctx):
    """Get details for a specific suite."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    sid = _sid(ctx)
    client = _client(ctx)
    try:
        data = client.get(f"suites/{sid}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@suite.command(name="update")
@click.option("--name", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def suite_update(ctx, name, input_file):
    """Update a detection suite."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    sid = _sid(ctx)
    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"suites/{sid}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated suite: {sid}")


@suite.command(name="delete")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def suite_delete(ctx, yes):
    """Delete a detection suite."""
    sid = _sid(ctx)
    _confirm(f"Delete suite {sid}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"suites/{sid}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted suite: {sid}")


@suite.command(name="activate")
@click.pass_context
def suite_activate(ctx):
    """Activate a detection suite."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    sid = _sid(ctx)
    client = _client(ctx)
    try:
        data = client.post(f"suites/{sid}/activate/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Activated suite: {sid}")


@suite.command(name="execute")
@click.pass_context
def suite_execute(ctx):
    """Execute all rules in a detection suite."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    sid = _sid(ctx)
    client = _client(ctx)
    try:
        data = client.post(f"suites/{sid}/execute/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Executed suite: {sid}")


@suite.command(name="active-dashboards")
@click.pass_context
def suite_active_dashboards(ctx):
    """Get Active Dashboards By Suite."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    sid = _sid(ctx)
    path = f"active-dashboards/suite/{sid}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@suite.command(name="logs")
@click.option("--skip", "skip", type=int, default=0)
@click.option("--limit", "limit", type=int, default=50)
@click.pass_context
def suite_logs(ctx, skip, limit):
    """Get Suite Execution Logs By Suite."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    sid = _sid(ctx)
    path = f"suite-execution-logs/suites/{sid}/logs"
    params = {}
    if skip is not None:
        params["skip"] = skip
    if limit is not None:
        params["limit"] = limit

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@suite.command(name="rules-add")
@click.option("--rule-id", "rule_id", required=True, help="UUID string of an existing detection rule.")
@click.pass_context
def suite_rules_add(ctx, rule_id):
    """Add a rule to a suite."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    sid = _sid(ctx)
    path = f"suites/{sid}/rules"
    body = {"rule_id": rule_id}

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@suite.command(name="rules-remove")
@click.option("--rule-id", "rule_id", required=True, help="UUID of the rule to remove.")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def suite_rules_remove(ctx, rule_id, yes):
    """Remove Rule From Suite."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    sid = _sid(ctx)
    path = f"suites/{sid}/rules/{rule_id}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@suite.command(name="dashboards-add")
@click.option("--dashboard-id", "dashboard_id", required=True, help="ID of the dashboard to add to the suite")
@click.pass_context
def suite_dashboards_add(ctx, dashboard_id):
    """Add a dashboard to a suite."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    sid = _sid(ctx)
    path = f"suites/{sid}/dashboards"
    body = {"dashboard_id": dashboard_id}

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@suite.command(name="dashboards-remove")
@click.option("--dashboard-id", "dashboard_id", required=True, help="ID of the dashboard to remove.")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def suite_dashboards_remove(ctx, dashboard_id, yes):
    """Remove Dashboard From Suite."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    sid = _sid(ctx)
    path = f"suites/{sid}/dashboards/{dashboard_id}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@suite.command(name="deactivate")
@click.pass_context
def suite_deactivate(ctx):
    """Deactivate Suite."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    sid = _sid(ctx)
    path = f"suites/{sid}/deactivate"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@suite.command(name="status")
@click.pass_context
def suite_status(ctx):
    """Get Suite Activation Status."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    sid = _sid(ctx)
    path = f"suites/{sid}/status"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@suite.command(name="update-active")
@click.option("--dashboard-enabled", "dashboard_enabled", default=None)
@click.pass_context
def suite_update_active(ctx, dashboard_enabled):
    """Update Active Suite."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    sid = _sid(ctx)
    path = f"suites/active/{sid}"
    body = {}
    if dashboard_enabled is not None:
        body["dashboard_enabled"] = dashboard_enabled

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@suite.command(name="executions")
@click.option("--skip", "skip", type=int, default=0)
@click.option("--limit", "limit", type=int, default=50)
@click.pass_context
def suite_executions(ctx, skip, limit):
    """Get suite execution history."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    sid = _sid(ctx)
    path = f"suites/{sid}/executions"
    params = {}
    if skip is not None:
        params["skip"] = skip
    if limit is not None:
        params["limit"] = limit

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@suite.command(name="move")
@click.option("--target-workspace-id", "target_workspace_id", required=True)
@click.pass_context
def suite_move(ctx, target_workspace_id):
    """Move suite to a different workspace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    sid = _sid(ctx)
    path = f"suites/{sid}/move"
    body = {"target_workspace_id": target_workspace_id}

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)
