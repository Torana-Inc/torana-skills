"""torana skills — agent skill management commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 30),
    ("state", "STATE", 10),
    ("description", "DESCRIPTION", 40),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group()
def skills():
    """Manage agent skills.

    \b
    Examples:
      torana skills list
      torana skills get <UUID>
      torana skills create --file skill.yaml
      torana skills delete <UUID> --yes
    """


@skills.command(name="list")
@click.option("--search", default=None)
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def skills_list(ctx, search, page, page_size):
    """List skills."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if search:
        params["search"] = search

    client = _client(ctx)
    try:
        data = client.get("skills/", params=params)
        result = data if isinstance(data, dict) and "items" in data else {
            "items": data if isinstance(data, list) else [],
            "total": len(data) if isinstance(data, list) else 0,
            "page": page, "page_size": effective_page_size
        }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@skills.command(name="get")
@click.argument("skill_id", metavar="SKILL_ID")
@click.pass_context
def skills_get(ctx, skill_id):
    """Get a specific skill."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"skills/{skill_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@skills.command(name="create")
@click.option("--name", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def skills_create(ctx, name, input_file):
    """Create a new skill."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name

    if not body.get("name"):
        click.echo("ERROR: --name is required.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post("skills/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created skill: {data.get('id', 'unknown')}")


@skills.command(name="update")
@click.argument("skill_id", metavar="SKILL_ID")
@click.option("--name", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def skills_update(ctx, skill_id, name, input_file):
    """Update a skill."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"skills/{skill_id}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated skill: {skill_id}")


@skills.command(name="delete")
@click.argument("skill_id", metavar="SKILL_ID")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def skills_delete(ctx, skill_id, yes):
    """Delete a skill."""
    _confirm(f"Delete skill {skill_id}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"skills/{skill_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted skill: {skill_id}")
