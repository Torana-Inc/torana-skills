"""torana repository <KEY> — instance operations on one datalake repository record.

Collection operations (list) are under: torana repositories <verb>
"""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, handle_api_error, handle_auth_error
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_RAW
from torana_cli.output import output
from torana_cli.repositories import _client, _normalize_list_response, resolve_repository_key


@click.group(name="repository")
@click.argument("repo_key", metavar="REPO_KEY")
@click.pass_context
def repository(ctx, repo_key):
    """Operate on one repository by key.

    REPO_KEY accepts the canonical source-neutral key
    (`repo:github.com/org/name`), an `org/name` pair, or a bare repo name —
    partial references are resolved to the canonical key.

    \b
    Examples:
      torana repository repo:github.com/acme/api get
      torana repository acme/api get
    """
    ctx.ensure_object(dict)
    ctx.obj["_repo_key"] = repo_key


def _rkey(ctx) -> str:
    return ctx.obj.get("_repo_key", "") if ctx.obj else ""


@repository.command(name="get")
@click.pass_context
def repository_get(ctx):
    """Get one repository asset record by key."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    # Resolve first so a partial reference (bare name / org-name) works, and so an
    # ambiguous one errors loudly rather than silently returning an arbitrary row.
    repo_key = resolve_repository_key(client, _rkey(ctx))

    try:
        data = client.get("/tables/repositories/data",
                          params={"torana_repository_id": repo_key, "limit": 1})
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    items = _normalize_list_response(data).get("items", [])
    if not items:
        # Resolution succeeded but the row is gone — report it as not-found rather
        # than printing an empty object that reads like a successful lookup.
        click.echo(f"ERROR: no repository record for {repo_key!r}.", err=True)
        raise SystemExit(3)

    output(items[0], fmt=fmt, raw=raw, fields=fields)
