"""torana sdg — Synthetic Data Generator admin commands.

Internal developer tooling. Requires super-admin credentials.
"""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.confirm import confirm as _confirm


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _fmt(ctx):
    return ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"


def _raw(ctx):
    return ctx.obj.get(CTX_RAW, False) if ctx.obj else False


def _fields(ctx):
    return ctx.obj.get(CTX_FIELDS) if ctx.obj else None


@click.group()
def sdg():
    """Synthetic Data Generator — internal developer tooling.

    \b
    Manage SDG state, configuration, scenarios, datasets and replay controls.
    Requires super-admin credentials.

    \b
    Examples:
      torana sdg status
      torana sdg stats
      torana sdg generate --scenario github
      torana sdg config get
      torana sdg replay start
    """


# ── Status & stats ───────────────────────────────────────────────────────────

@sdg.command(name="status")
@click.pass_context
def sdg_status(ctx):
    """Get SDG running status."""
    client = _client(ctx)
    try:
        data = client.get("sdg/admin/status")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx), fields=_fields(ctx))


@sdg.command(name="stats")
@click.pass_context
def sdg_stats(ctx):
    """Get SDG generation statistics."""
    client = _client(ctx)
    try:
        data = client.get("sdg/admin/stats")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx), fields=_fields(ctx))


@sdg.command(name="history")
@click.pass_context
def sdg_history(ctx):
    """Get SDG generation history."""
    client = _client(ctx)
    try:
        data = client.get("sdg/admin/history")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx), raw=_raw(ctx), fields=_fields(ctx))


# ── Generate / control ───────────────────────────────────────────────────────

@sdg.command(name="generate")
@click.option("--scenario", default=None, metavar="NAME", help="Scenario to run.")
@click.option("--file", "input_file", default=None, metavar="FILE",
              help="JSON/YAML file with generation parameters.")
@click.pass_context
def sdg_generate(ctx, scenario, input_file):
    """Trigger synthetic data generation."""
    body = {}
    if scenario:
        body["scenario"] = scenario
    if input_file:
        import json as _json
        import yaml as _yaml
        from pathlib import Path
        raw_text = Path(input_file).read_text()
        try:
            body.update(_json.loads(raw_text))
        except _json.JSONDecodeError:
            body.update(_yaml.safe_load(raw_text))

    client = _client(ctx)
    try:
        data = client.post("sdg/admin/generate", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx), fields=_fields(ctx))


@sdg.command(name="pause")
@click.pass_context
def sdg_pause(ctx):
    """Pause SDG data generation."""
    client = _client(ctx)
    try:
        data = client.post("sdg/admin/pause", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


@sdg.command(name="resume")
@click.pass_context
def sdg_resume(ctx):
    """Resume SDG data generation."""
    client = _client(ctx)
    try:
        data = client.post("sdg/admin/resume", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


@sdg.command(name="reset")
@click.option("--yes", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def sdg_reset(ctx, yes):
    """Reset SDG to initial state."""
    _confirm("Reset SDG to initial state?", yes=yes)
    client = _client(ctx)
    try:
        data = client.post("sdg/admin/reset", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


# ── Scenarios & datasets ──────────────────────────────────────────────────────

@sdg.command(name="scenarios")
@click.pass_context
def sdg_scenarios(ctx):
    """List active and recently completed SDG scenarios."""
    client = _client(ctx)
    try:
        data = client.get("sdg/admin/scenarios")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    # Flatten {active, recently_completed} into a single items list
    fmt = _fmt(ctx)
    if fmt in ("json", "yaml"):
        output(data, fmt=fmt, raw=_raw(ctx), fields=_fields(ctx))
        return
    items = [{"status": "active", **s} for s in data.get("active", [])]
    items += [{"status": "completed", **s} for s in data.get("recently_completed", [])]
    envelope = {"items": items, "total": len(items)}
    columns = [
        ("status", "STATUS", 10),
        ("scenario_id", "SCENARIO ID", 36),
        ("scenario_type", "TYPE", 20),
        ("started_at", "STARTED AT", 26),
        ("last_event_index", "LAST IDX", 8),
    ]
    output(envelope, fmt=fmt, fields=_fields(ctx), columns=columns)


_DATASET_LIST_COLUMNS = [
    ("id", "ID", 36),
    ("slug", "SLUG", 50),
    ("name", "NAME", 55),
    ("theme_slug", "THEME", 30),
    ("duration_hours", "DURATION H", 10),
    ("status", "STATUS", 12),
]


@sdg.group(name="datasets", invoke_without_command=True)
@click.pass_context
def sdg_datasets(ctx):
    """Collection operations on SDG datasets (list, create, themes).

    \b
    Plural = collection ops. For a specific dataset use the singular form:
      torana sdg dataset <id> get|validate|publish|delete|mock-replay ...
    """
    # Bare `sdg datasets` shows help; use `sdg datasets list` to list.
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


# ── Dataset lifecycle helpers ─────────────────────────────────────────────────

def _load_body(input_file):
    """Read a JSON or YAML file into a dict. Returns {} when input_file is None."""
    if not input_file:
        return {}
    import json as _json
    import yaml as _yaml
    from pathlib import Path
    raw_text = Path(input_file).read_text()
    try:
        return _json.loads(raw_text)
    except _json.JSONDecodeError:
        return _yaml.safe_load(raw_text)




@sdg.group(name="dataset", invoke_without_command=True)
@click.argument("dataset_id", metavar="DATASET_ID")
@click.pass_context
def sdg_dataset(ctx, dataset_id):
    """Instance operations on ONE SDG dataset, addressed by id or slug.

    \b
    Singular = instance ops. DATASET_ID may be the dataset slug or UUID.
    For collection ops (list/create/themes) use the plural form:
      torana sdg datasets list|create|themes

    \b
    Examples:
      torana sdg dataset <id> get
      torana sdg dataset <id> validate
      torana sdg dataset <id> publish
      torana sdg dataset <id> delete --force
      torana sdg dataset <id> mock-replay start --mode manual
    """
    ctx.ensure_object(dict)
    ctx.obj["_dataset_id"] = dataset_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _did(ctx) -> str:
    """Resolve the dataset id from the singular group context."""
    return ctx.obj.get("_dataset_id", "") if ctx.obj else ""


@sdg_datasets.command(name="list")
@click.option("--status", default=None, help="Filter by status (draft|published|archived).")
@click.option("--theme-id", default=None, metavar="UUID", help="Filter by theme id.")
@click.option("--q", "query", default=None, help="Search name / semantic blob.")
@click.option("--show-deleted", is_flag=True, default=False,
              help="Also show soft-deleted datasets (adds a DELETED column).")
@click.option("--tenant-id", default=None, metavar="UUID",
              help="Read another tenant's datasets (super admin only).")
@click.pass_context
def sdg_dataset_list(ctx, status, theme_id, query, show_deleted, tenant_id):
    """List datasets visible to your tenant (own authored drafts + committed on-disk datasets).

    \b
    Use --show-deleted to surface soft-deleted datasets so you can hard-delete
    them with `torana sdg dataset <id> delete --force`.
    """
    client = _client(ctx)
    try:
        params = {}
        if status:
            params["status"] = status
        if theme_id:
            params["theme_id"] = theme_id
        if query:
            params["q"] = query
        if show_deleted:
            params["show_deleted"] = "true"
        if tenant_id:
            params["tenant_id"] = tenant_id
        data = client.get("sdg/admin/datasets", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    columns = _DATASET_LIST_COLUMNS
    if show_deleted:
        columns = _DATASET_LIST_COLUMNS + [("is_deleted", "DELETED", 8)]
    output(data, fmt=_fmt(ctx), raw=_raw(ctx), fields=_fields(ctx), columns=columns)


# ── Themes (read-only) ─────────────────────────────────────────────────────────

@sdg_datasets.command(name="themes")
@click.pass_context
def sdg_dataset_themes(ctx):
    """List themes (system + tenant). Datasets are authored WITHIN a theme.

    \b
    This command is read-only. The dataset skill never creates or edits
    themes — it only picks one of these and uses its phase vocabulary.
    """
    client = _client(ctx)
    try:
        data = client.get("sdg/admin/datasets/themes")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    # Endpoint returns a bare list; wrap for the formatter.
    if isinstance(data, list):
        data = {"items": data, "total": len(data)}
    output(data, fmt=_fmt(ctx), raw=_raw(ctx), fields=_fields(ctx), columns=[
        ("id", "ID", 36),
        ("slug", "SLUG", 22),
        ("name", "NAME", 40),
        ("is_system_seed", "SYSTEM", 8),
        ("phase_vocabulary", "PHASE VOCABULARY", 60),
    ])


# ── Dataset CRUD ────────────────────────────────────────────────────────────────

@sdg_datasets.command(name="create")
@click.option("--file", "input_file", required=True, metavar="FILE",
              help="JSON/YAML body: name, original_intent, theme_slug (or theme_id), "
                   "duration_hours, event_window_hours, resolved_intent, default_start_phase.")
@click.pass_context
def sdg_dataset_create(ctx, input_file):
    """Create a draft dataset within an existing theme.

    \b
    Body example (new.json):
      {"name": "Log4Shell Critical",
       "original_intent": "zero-day exploited across slack/jira/snyk/tenable",
       "theme_slug": "incident-response",
       "duration_hours": 772, "event_window_hours": 0.5}
    """
    client = _client(ctx)
    try:
        body = _load_body(input_file)
        data = client.post("sdg/admin/datasets", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


@sdg_dataset.command(name="update")
@click.option("--file", "input_file", required=True, metavar="FILE",
              help="JSON/YAML body with fields to update (PATCH — merged).")
@click.pass_context
def sdg_dataset_update(ctx, input_file):
    """Update dataset metadata (name, resolved_intent, durations, provider_config…)."""
    dataset_id = _did(ctx)
    client = _client(ctx)
    try:
        body = _load_body(input_file)
        data = client.patch(f"sdg/admin/datasets/{dataset_id}", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


@sdg_dataset.command(name="clone")
@click.option("--name", required=True, help="Name for the new cloned draft.")
@click.option("--slug", default=None, help="Slug for the new draft (generated from name if omitted).")
@click.pass_context
def sdg_dataset_clone(ctx, name, slug):
    """Clone any dataset (including committed on-disk datasets) into a new tenant-owned draft."""
    dataset_id = _did(ctx)
    client = _client(ctx)
    try:
        body = {"name": name}
        if slug:
            body["slug"] = slug
        data = client.post(f"sdg/admin/datasets/{dataset_id}/clone", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


@sdg_dataset.command(name="delete")
@click.option("--yes", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.option("--force", is_flag=True, default=False,
              help="Hard delete — physically remove rows instead of soft-delete.")
@click.option("--force-system", is_flag=True, default=False,
              help="Allow deleting a system-seed dataset (protected by default).")
@click.pass_context
def sdg_dataset_delete(ctx, yes, force, force_system):
    """Delete a dataset (cascades to phases/records/identities/events).

    Soft-delete by default. --force does a hard delete (irreversible).
    System seeds are protected unless --force-system is passed.
    """
    dataset_id = _did(ctx)
    if not yes:
        if force:
            prompt = (f"HARD-delete dataset '{dataset_id}'? This PERMANENTLY removes the "
                      f"dataset and all its rows from the DB (irreversible)")
        else:
            prompt = (f"Soft-delete dataset '{dataset_id}'? It will be marked deleted but "
                      f"kept in the DB (recoverable; re-run with --force to hard-delete)")
        _confirm(prompt, yes=False)
    params = {}
    if force:
        params["hard"] = "true"
    if force_system:
        params["force_system"] = "true"
    client = _client(ctx)
    try:
        client.delete(f"sdg/admin/datasets/{dataset_id}", params=params or None)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if force:
        click.echo(f"Hard-deleted dataset '{dataset_id}' — permanently removed from the DB "
                   f"(dataset + phases + records + identities + events).")
    else:
        click.echo(f"Soft-deleted dataset '{dataset_id}' — marked is_deleted=true but kept "
                   f"in the DB (cascaded to all child rows). Restore it, or run "
                   f"`torana sdg dataset {dataset_id} delete --force` to hard-delete.")


# ── Phases ──────────────────────────────────────────────────────────────────────

@sdg_dataset.group(name="phase", invoke_without_command=True)
@click.pass_context
def sdg_dataset_phase(ctx):
    """Add, update and remove dataset phases."""
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@sdg_dataset_phase.command(name="add")
@click.option("--file", "input_file", required=True, metavar="FILE",
              help="JSON/YAML phase body: phase_key, name, offset_hours, duration_hours, "
                   "sort_order, phase_intent, and optional events/normalized_records/narratives.")
@click.pass_context
def sdg_dataset_phase_add(ctx, input_file):
    """Create a phase (optionally with its events, normalized records, and narratives)."""
    dataset_id = _did(ctx)
    client = _client(ctx)
    try:
        body = _load_body(input_file)
        data = client.post(f"sdg/admin/datasets/{dataset_id}/phases", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


@sdg_dataset_phase.command(name="update")
@click.argument("phase_id", metavar="PHASE_ID")
@click.option("--file", "input_file", required=True, metavar="FILE",
              help="JSON/YAML body with phase fields to update.")
@click.pass_context
def sdg_dataset_phase_update(ctx, phase_id, input_file):
    """Update phase metadata."""
    dataset_id = _did(ctx)
    client = _client(ctx)
    try:
        body = _load_body(input_file)
        data = client.patch(f"sdg/admin/datasets/{dataset_id}/phases/{phase_id}", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


@sdg_dataset_phase.command(name="delete")
@click.argument("phase_id", metavar="PHASE_ID")
@click.option("--yes", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def sdg_dataset_phase_delete(ctx, phase_id, yes):
    """Delete a phase (cascades its events and normalized records)."""
    dataset_id = _did(ctx)
    _confirm(f"Delete phase '{phase_id}'?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"sdg/admin/datasets/{dataset_id}/phases/{phase_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    click.echo(f"Deleted phase {phase_id}.")


# ── Content (bulk replace) ──────────────────────────────────────────────────────

@sdg_dataset.command(name="identities")
@click.option("--file", "input_file", required=True, metavar="FILE",
              help='JSON/YAML body: {"identities": [ {login, display_name, email, ...}, ... ]}.')
@click.pass_context
def sdg_dataset_identities(ctx, input_file):
    """Replace the dataset's identity directory (full replace)."""
    dataset_id = _did(ctx)
    client = _client(ctx)
    try:
        body = _load_body(input_file)
        data = client.put(f"sdg/admin/datasets/{dataset_id}/identities", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


@sdg_dataset.command(name="events")
@click.argument("phase_id", metavar="PHASE_ID")
@click.option("--file", "input_file", required=True, metavar="FILE",
              help='JSON/YAML body: {"events": [ {...}, ... ]} (replaces all events for the phase).')
@click.pass_context
def sdg_dataset_events(ctx, phase_id, input_file):
    """Replace all provider events for a phase (bulk)."""
    dataset_id = _did(ctx)
    client = _client(ctx)
    try:
        body = _load_body(input_file)
        data = client.put(f"sdg/admin/datasets/{dataset_id}/phases/{phase_id}/events",
                          json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


@sdg_dataset.command(name="normalized")
@click.argument("phase_id", metavar="PHASE_ID")
@click.option("--file", "input_file", required=True, metavar="FILE",
              help='JSON/YAML body: {"records": [ {...}, ... ]} (replaces all normalized records).')
@click.pass_context
def sdg_dataset_normalized(ctx, phase_id, input_file):
    """Replace all normalized (datalake push) records for a phase (bulk).

    \b
    Every tick that writes records MUST have a matching narrative beat —
    set them with `torana sdg dataset narratives`.
    """
    dataset_id = _did(ctx)
    client = _client(ctx)
    try:
        body = _load_body(input_file)
        data = client.put(f"sdg/admin/datasets/{dataset_id}/phases/{phase_id}/normalized",
                          json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


@sdg_dataset.command(name="narratives")
@click.argument("phase_id", metavar="PHASE_ID")
@click.option("--file", "input_file", required=True, metavar="FILE",
              help='JSON/YAML body: {"narratives": [ {tick_index, offset_hours, beat, ...}, ... ]}.')
@click.pass_context
def sdg_dataset_narratives(ctx, phase_id, input_file):
    """Replace all per-tick narrative beats for a phase (bulk)."""
    dataset_id = _did(ctx)
    client = _client(ctx)
    try:
        body = _load_body(input_file)
        data = client.put(f"sdg/admin/datasets/{dataset_id}/phases/{phase_id}/narratives",
                          json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


# ── Validate / footprint / publish ──────────────────────────────────────────────

@sdg_dataset.command(name="validate")
@click.pass_context
def sdg_dataset_validate(ctx):
    """Run the integrity contract; returns errors + warnings."""
    dataset_id = _did(ctx)
    client = _client(ctx)
    try:
        data = client.post(f"sdg/admin/datasets/{dataset_id}/validate", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


@sdg_dataset.command(name="footprint")
@click.option("--tenant-id", default=None, metavar="UUID",
              help="Read another tenant's datasets (super admin only).")
@click.pass_context
def sdg_dataset_footprint(ctx, tenant_id):
    """Static footprint: total tables/records, per-table, per-phase, intent size."""
    dataset_id = _did(ctx)
    client = _client(ctx)
    try:
        params = {"tenant_id": tenant_id} if tenant_id else None
        data = client.get(f"sdg/admin/datasets/{dataset_id}/footprint", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


@sdg_dataset.command(name="publish")
@click.pass_context
def sdg_dataset_publish(ctx):
    """Publish a dataset (requires validation_status=passing). Becomes replayable."""
    dataset_id = _did(ctx)
    client = _client(ctx)
    try:
        data = client.post(f"sdg/admin/datasets/{dataset_id}/publish", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


# ── Mock replay (side-effect-free narration) ────────────────────────────────────

@sdg_dataset.group(name="mock-replay", invoke_without_command=True)
@click.pass_context
def sdg_dataset_mock_replay(ctx):
    """Side-effect-free narrated replay (writes to NO datalake).

    \b
    Use to preview a draft while authoring, or to understand any dataset
    in the catalog. Manual mode steps one stage per `tick`; auto mode
    streams stages over SSE.
    """
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@sdg_dataset_mock_replay.command(name="start")
@click.option("--mode", type=click.Choice(["auto", "manual"]), default="manual",
              help="manual: step via `tick`; auto: stream via `stream`.")
@click.option("--granularity", type=click.Choice(["window", "phase"]), default="window",
              help="Advance one event window or one full phase per stage.")
@click.option("--tick-interval", "tick_interval_seconds", default=None, type=float,
              metavar="SECONDS", help="Auto mode: seconds between window ticks.")
@click.option("--phase-interval", "phase_interval_seconds", default=None, type=float,
              metavar="SECONDS", help="Auto mode: seconds between phases (phase granularity).")
@click.option("--start-phase", default=None, metavar="PHASE",
              help="Start from a named phase (e.g. t2).")
@click.option("--start-offset", "start_offset_hours", default=None, type=float,
              metavar="HOURS", help="Start from a specific offset.")
@click.pass_context
def sdg_dataset_mock_replay_start(ctx, dataset_id, mode, granularity, tick_interval_seconds,
                                  phase_interval_seconds, start_phase, start_offset_hours):
    """Start a mock-replay session; returns {mock_session_id, total_stages}."""
    dataset_id = _did(ctx)
    client = _client(ctx)
    body = {"mode": mode, "granularity": granularity}
    if tick_interval_seconds is not None:
        body["tick_interval_seconds"] = tick_interval_seconds
    if phase_interval_seconds is not None:
        body["phase_interval_seconds"] = phase_interval_seconds
    if start_phase is not None:
        body["start_phase"] = start_phase
    if start_offset_hours is not None:
        body["start_offset_hours"] = start_offset_hours
    try:
        data = client.post(f"sdg/admin/datasets/{dataset_id}/mock-replay/start", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


@sdg_dataset_mock_replay.command(name="tick")
@click.argument("session_id", metavar="SESSION_ID")
@click.pass_context
def sdg_dataset_mock_replay_tick(ctx, session_id):
    """Manual mode: advance one stage and return its MockTick."""
    dataset_id = _did(ctx)
    client = _client(ctx)
    try:
        data = client.post(
            f"sdg/admin/datasets/{dataset_id}/mock-replay/{session_id}/tick",
            json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


@sdg_dataset_mock_replay.command(name="status")
@click.argument("session_id", metavar="SESSION_ID")
@click.pass_context
def sdg_dataset_mock_replay_status(ctx, session_id):
    """Current cursor, stages remaining, mode."""
    dataset_id = _did(ctx)
    client = _client(ctx)
    try:
        data = client.get(
            f"sdg/admin/datasets/{dataset_id}/mock-replay/{session_id}/status")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


@sdg_dataset_mock_replay.command(name="stop")
@click.argument("session_id", metavar="SESSION_ID")
@click.pass_context
def sdg_dataset_mock_replay_stop(ctx, session_id):
    """End the session and free its in-memory cursor."""
    dataset_id = _did(ctx)
    client = _client(ctx)
    try:
        client.post(
            f"sdg/admin/datasets/{dataset_id}/mock-replay/{session_id}/stop",
            json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    click.echo(f"Stopped mock-replay session {session_id}.")


def _print_dataset_text(data: dict) -> None:
    """Render a single dataset in a friendly text view."""
    click.echo(f"ID:              {data.get('id', '')}")
    click.echo(f"Name:            {data.get('name', '')}")
    click.echo(f"Theme:           {data.get('theme_display') or data.get('theme', '')}")
    click.echo(f"Duration:        {data.get('duration_hours', '')} hours")
    click.echo(f"Event window:    {data.get('event_window_hours', '')} hours")
    default_phase = data.get('default_start_phase')
    if default_phase:
        click.echo(f"Default start:   {default_phase}")
    tags = data.get('tags') or []
    if tags:
        click.echo(f"Tags:            {', '.join(tags)}")

    desc = (data.get('description') or '').strip()
    if desc:
        click.echo("\nDescription:")
        for line in desc.splitlines():
            click.echo(f"  {line}")

    semantic = data.get('semantic') or {}
    summary = (semantic.get('summary') or '').strip()
    if summary:
        click.echo("\nSummary:")
        click.echo(f"  {summary}")

    phases = data.get('phases') or []
    tick_schedule = data.get('tick_schedule') or []
    if phases:
        click.echo(f"\nPhases ({len(phases)}):")
        # Aggregate datalake records per phase
        phase_counts = {p['id']: {} for p in phases}
        phase_ticks = {p['id']: 0 for p in phases}
        for tick in tick_schedule:
            offset = tick.get('offset_hours', 0)
            phase_id = None
            for p in phases:
                p_off = p.get('offset_hours', 0)
                p_end = p_off + p.get('duration_hours', 0)
                if p_off <= offset < p_end:
                    phase_id = p['id']
                    break
            if phase_id is None:
                continue
            phase_ticks[phase_id] += 1
            for table, count in (tick.get('tables') or {}).items():
                phase_counts[phase_id][table] = phase_counts[phase_id].get(table, 0) + count

        for p in phases:
            pid = p.get('id', '')
            pname = p.get('name', '')
            offset = p.get('offset_hours', 0)
            duration = p.get('duration_hours', 0)
            end = offset + duration
            click.echo(f"  {pid:<4} {pname:<30} {offset:>7.1f}h - {end:>7.1f}h "
                       f"({duration}h, {phase_ticks[pid]} ticks)")
            counts = phase_counts[pid]
            if counts:
                parts = [f"{tbl}={n}" for tbl, n in sorted(counts.items())]
                click.echo(f"       records: {', '.join(parts)}")

    providers = (semantic.get('provider_coverage') or [])
    if providers:
        click.echo(f"\nProviders:       {', '.join(providers)}")

    tables = (semantic.get('datalake_tables_populated') or [])
    if tables:
        click.echo(f"Datalake tables: {', '.join(tables)}")

    tick_schedule = data.get('tick_schedule') or []
    if tick_schedule:
        click.echo(f"\nTick schedule:   {len(tick_schedule)} ticks "
                   f"(use --json for full schedule)")


@sdg_dataset.command(name="get")
@click.option("--tenant-id", default=None, metavar="UUID",
              help="Read another tenant's datasets (super admin only).")
@click.pass_context
def sdg_dataset_get(ctx, tenant_id):
    """Get full details for a single SDG dataset (phases, identities, intent).

    \b
    DATASET_ID may be the dataset slug or its UUID.

    \b
    Example:
      torana sdg dataset get vm-advisor-test-v1
    """
    dataset_id = _did(ctx)
    client = _client(ctx)
    try:
        params = {"tenant_id": tenant_id} if tenant_id else None
        data = client.get(f"sdg/admin/datasets/{dataset_id}", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    fmt = _fmt(ctx)
    if fmt == "text":
        _print_dataset_text(data)
        return
    output(data, fmt=fmt, fields=_fields(ctx))


# NOTE: `torana sdg dataset seed` and `clear` were removed as part of seed removal
# — committed on-disk datasets are now served straight from disk (they appear in
# `torana sdg dataset list` with source=disk, no DB copy). There is nothing to
# seed; `list`/`get`/`mock-replay` work against disk datasets directly.


# ── Config ───────────────────────────────────────────────────────────────────

@sdg.group(name="config")
def sdg_config():
    """Manage SDG configuration."""


@sdg_config.command(name="get")
@click.pass_context
def sdg_config_get(ctx):
    """Get current SDG configuration."""
    client = _client(ctx)
    try:
        data = client.get("sdg/admin/config")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx), fields=_fields(ctx))


@sdg_config.command(name="set")
@click.option("--file", "input_file", required=True, metavar="FILE",
              help="JSON/YAML file with config values to set (PUT — full replacement).")
@click.pass_context
def sdg_config_set(ctx, input_file):
    """Replace SDG configuration (full update)."""
    import json as _json
    import yaml as _yaml
    from pathlib import Path
    raw_text = Path(input_file).read_text()
    try:
        body = _json.loads(raw_text)
    except _json.JSONDecodeError:
        body = _yaml.safe_load(raw_text)

    client = _client(ctx)
    try:
        data = client.put("sdg/admin/config", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


@sdg_config.command(name="patch")
@click.option("--file", "input_file", required=True, metavar="FILE",
              help="JSON/YAML file with config values to merge (POST — partial update).")
@click.pass_context
def sdg_config_patch(ctx, input_file):
    """Partially update SDG configuration."""
    import json as _json
    import yaml as _yaml
    from pathlib import Path
    raw_text = Path(input_file).read_text()
    try:
        body = _json.loads(raw_text)
    except _json.JSONDecodeError:
        body = _yaml.safe_load(raw_text)

    client = _client(ctx)
    try:
        data = client.post("sdg/admin/config", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


@sdg_config.command(name="delete-key")
@click.argument("key", metavar="KEY")
@click.option("--yes", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def sdg_config_delete_key(ctx, key, yes):
    """Delete a single SDG config key."""
    _confirm(f"Delete config key '{key}'?", yes=yes)
    client = _client(ctx)
    try:
        data = client.delete(f"sdg/admin/config/{key}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


# ── Replay controls ───────────────────────────────────────────────────────────

@sdg.group(name="replay")
def sdg_replay():
    """Control SDG replay mode."""


@sdg_replay.command(name="start")
@click.option("--dataset-id", default=None, metavar="ID",
              help="Dataset ID to replay (see: torana sdg datasets).")
@click.option("--tenant-id", default=None, metavar="TENANT",
              help="Tenant ID to replay into.")
@click.option("--namespace-id", default=None, metavar="NAMESPACE",
              help="Namespace ID (required when --normalized is set).")
@click.option("--start-phase", default=None, metavar="PHASE",
              help="Start from a named phase (e.g. t0, t1, t2). Defaults to dataset default_start_phase.")
@click.option("--tick-mode", default=None, type=click.Choice(["auto", "manual"]),
              help="auto: background loop; manual: user-triggered ticks.")
@click.option("--tick-interval", default=None, type=int, metavar="SECONDS",
              help="Real seconds between push ticks (default: 30, min: 5).")
@click.option("--speed", default=None, type=int, metavar="FACTOR",
              help="Event windows pushed per tick (1–10, default: 1).")
@click.option("--normalized/--no-normalized", default=None,
              help="Push normalized.jsonl events to datalake (default: false).")
@click.option("--clear/--no-clear", default=None,
              help="Delete prior SDG datalake rows before replay (default: false).")
@click.option("--skip-deps/--no-skip-deps", default=None,
              help="Do NOT auto-preload the dataset's depends_on datasets (default: false).")
@click.option("--file", "input_file", default=None, metavar="FILE",
              help="JSON/YAML file with additional replay parameters (merged with flags).")
@click.pass_context
def sdg_replay_start(ctx, dataset_id, tenant_id, namespace_id, start_phase, tick_mode,
                     tick_interval, speed, normalized, clear, skip_deps, input_file):
    """Start SDG replay.

    \b
    Examples:
      torana sdg replay start --dataset-id ransomware-attack-v1 --tenant-id t1
      torana sdg replay start --dataset-id ransomware-attack-v1 --tenant-id t1 --start-phase t2
      torana sdg replay start --dataset-id ransomware-attack-v1 --tenant-id t1 --normalized --clear

    \b
    ⭐ CLEAR-ONLY (wipe a dataset's rows without replaying it): pair `--clear` with
    `--no-normalized`, then stop. The engine performs the tag+source-scoped delete
    on startup and pushes nothing, so this is the one-command way to reset a
    dataset's datalake footprint.

    \b
      torana sdg replay start --dataset-id <id> --tenant-id <t> --clear --no-normalized
      torana sdg replay stop  --dataset-id <id> --tenant-id <t>
    """
    body = {}
    if input_file:
        import json as _json
        import yaml as _yaml
        from pathlib import Path
        raw_text = Path(input_file).read_text()
        try:
            body = _json.loads(raw_text)
        except _json.JSONDecodeError:
            body = _yaml.safe_load(raw_text)
    # CLI flags override file values
    if dataset_id is not None:
        body["dataset_id"] = dataset_id
    if tenant_id is not None:
        body["tenant_id"] = tenant_id
    if namespace_id is not None:
        body["namespace_id"] = namespace_id
    if start_phase is not None:
        body["start_phase"] = start_phase
    if tick_mode is not None:
        body["tick_mode"] = tick_mode
    if tick_interval is not None:
        body["tick_interval_seconds"] = tick_interval
    if speed is not None:
        body["speed_factor"] = speed
    if normalized is not None:
        body["update_normalized_data"] = normalized
    if clear is not None:
        body["clear_previous_data"] = clear
    if skip_deps is not None:
        body["skip_deps"] = skip_deps
    client = _client(ctx)
    try:
        data = client.post("sdg/admin/replay/start", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


@sdg_replay.command(name="stop")
@click.option("--tenant-id", "tenant_id", required=True, help="Tenant ID to stop replay for.")
@click.pass_context
def sdg_replay_stop(ctx, tenant_id):
    """Stop SDG replay."""
    client = _client(ctx)
    try:
        data = client.post("sdg/admin/replay/stop", json={"tenant_id": tenant_id})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


@sdg_replay.command(name="set-phase")
@click.argument("phase", metavar="PHASE")
@click.option("--tenant-id", "tenant_id", required=True, help="Tenant ID whose replay to set.")
@click.pass_context
def sdg_replay_set_phase(ctx, phase, tenant_id):
    """Jump a manual replay to phase POSITION and materialise everything up to it.

    \b
    A phase is a WINDOW, not a point, so PHASE names a POSITION and the boundary
    is part of the token:
      t2:start        the moment t2 begins      (== default_start_phase: t2)
      t2:end          everything through t2
      start-of-time   nothing has happened yet
      end-of-time     the whole dataset

    \b
    A bare "t2" is rejected — it is ambiguous between the two readings, and the
    old behaviour (silently END) made the start of the timeline unreachable.

    \b
    Forward jumps push the delta to the datalake (when the replay was started
    with --update-normalized). Only works for a manual-mode replay.

    \b
    Example (hold-narrate-nudge demo):
      torana sdg replay set-phase t2:start --tenant-id <TID>  # then sync, observe
      torana sdg replay set-phase t3:start --tenant-id <TID>  # then sync, see delta
    """
    client = _client(ctx)
    try:
        data = client.post(
            "sdg/admin/replay/set-phase",
            json={"tenant_id": tenant_id, "phase": phase},
        )
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


@sdg_replay.command(name="status")
@click.pass_context
def sdg_replay_status(ctx):
    """Get current replay status."""
    client = _client(ctx)
    try:
        data = client.get("sdg/admin/replay/status")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


@sdg_replay.command(name="all-status")
@click.pass_context
def sdg_replay_all_status(ctx):
    """Get replay status for all datasets."""
    client = _client(ctx)
    try:
        data = client.get("sdg/admin/replay/all-status")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx), raw=_raw(ctx), fields=_fields(ctx))


@sdg_replay.command(name="tick-history")
@click.pass_context
def sdg_replay_tick_history(ctx):
    """Get replay tick history."""
    client = _client(ctx)
    try:
        data = client.get("sdg/admin/replay/tick-history")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx), raw=_raw(ctx), fields=_fields(ctx))


@sdg_replay.command(name="tick")
@click.option("--tenant-id", default=None, help="Tenant ID to advance tick for.")
@click.option("--file", "input_file", default=None, metavar="FILE",
              help="JSON/YAML file with tick parameters.")
@click.pass_context
def sdg_replay_tick(ctx, tenant_id, input_file):
    """Advance replay by one tick."""
    body = {}
    if input_file:
        import json as _json
        import yaml as _yaml
        from pathlib import Path
        raw_text = Path(input_file).read_text()
        try:
            body = _json.loads(raw_text)
        except _json.JSONDecodeError:
            body = _yaml.safe_load(raw_text)
    if tenant_id:
        body["tenant_id"] = tenant_id
    client = _client(ctx)
    try:
        data = client.post("sdg/admin/replay/tick", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


@sdg_replay.command(name="set-speed")
@click.argument("speed", type=float, metavar="SPEED")
@click.pass_context
def sdg_replay_set_speed(ctx, speed):
    """Set replay speed multiplier."""
    client = _client(ctx)
    try:
        data = client.post("sdg/admin/replay/set-speed", json={"speed": speed})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx))


@sdg_replay.command(name="datalake-query")
@click.option("--file", "input_file", required=True, metavar="FILE",
              help="JSON/YAML file with the datalake query body.")
@click.pass_context
def sdg_replay_datalake_query(ctx, input_file):
    """Run a datalake query in replay context."""
    import json as _json
    import yaml as _yaml
    from pathlib import Path
    raw_text = Path(input_file).read_text()
    try:
        body = _json.loads(raw_text)
    except _json.JSONDecodeError:
        body = _yaml.safe_load(raw_text)
    client = _client(ctx)
    try:
        data = client.post("sdg/admin/replay/datalake-query", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=_fmt(ctx), raw=_raw(ctx), fields=_fields(ctx))
