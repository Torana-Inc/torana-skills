"""Shared pagination flag handling — accept both conventions everywhere.

The CLI historically grew two pagination idioms:
  - page-based:   --page / --page-size   (alerts, rules, agents, ...)
  - offset-based: --limit / --offset      (vulnerabilities, several admin cmds)

Users (and scripts) shouldn't have to remember which command uses which. These
helpers let a command declare BOTH and resolve whichever the user passed into the
single convention that command's endpoint expects. Either alias works on either
command; the native pair stays the documented default.

⛔ The server maximum is 100. A request for more is CLAMPED, and a clamp that says
nothing is how a page gets mistaken for a population: a caller asks for 200, gets
exactly 100, and tallies it as complete. `_warn_clamped` announces it on stderr —
stderr so `--format json` on stdout stays parseable — and points at `--all`.
"""

import sys

MAX_PAGE_SIZE = 100


def _warn_clamped(requested, effective):
    """Tell the caller their page size was capped, once, on stderr."""
    if requested is not None and requested > effective:
        print(
            f"WARNING: requested page size {requested} exceeds the server maximum "
            f"{effective}; returning at most {effective} rows.\n"
            f"         This page is NOT the full result set — use --all to "
            f"auto-paginate.",
            file=sys.stderr,
        )

def resolve_page(page, page_size, limit, offset, default_page_size=50):
    """Collapse the four flags into a (page, page_size) pair for page-based APIs.

    Precedence: explicit --page/--page-size win; otherwise derive from
    --limit/--offset (page = offset // limit + 1, page_size = limit).
    """
    requested = page_size if page_size is not None else limit
    eff_size = page_size if page_size is not None else (limit if limit is not None else default_page_size)
    eff_size = min(eff_size, MAX_PAGE_SIZE)
    _warn_clamped(requested, eff_size)
    if page is not None:
        eff_page = page
    elif offset is not None and eff_size:
        eff_page = (offset // eff_size) + 1
    else:
        eff_page = 1
    return eff_page, eff_size


def resolve_limit_offset(page, page_size, limit, offset, default_limit=50):
    """Collapse the four flags into a (limit, offset) pair for offset-based APIs.

    Precedence: explicit --limit/--offset win; otherwise derive from
    --page/--page-size (limit = page_size, offset = (page-1)*page_size).
    """
    requested = limit if limit is not None else page_size
    eff_limit = limit if limit is not None else (page_size if page_size is not None else default_limit)
    eff_limit = min(eff_limit, MAX_PAGE_SIZE)
    _warn_clamped(requested, eff_limit)
    if offset is not None:
        eff_offset = offset
    elif page is not None:
        eff_offset = (max(page, 1) - 1) * eff_limit
    else:
        eff_offset = 0
    return eff_limit, eff_offset
