"""Shared pagination flag handling — accept both conventions everywhere.

The CLI historically grew two pagination idioms:
  - page-based:   --page / --page-size   (alerts, rules, agents, ...)
  - offset-based: --limit / --offset      (vulnerabilities, several admin cmds)

Users (and scripts) shouldn't have to remember which command uses which. These
helpers let a command declare BOTH and resolve whichever the user passed into the
single convention that command's endpoint expects. Either alias works on either
command; the native pair stays the documented default.

⛔ The server maximum is 100. A request for more is CLAMPED, and a clamp that says
nothing is how a page gets mistaken for a population: a caller asks for 200, gets
exactly 100, and tallies it as complete. `_warn_clamped` announces it on stderr —
stderr so `--format json` on stdout stays parseable — and points at `--all`.
"""

import sys

MAX_PAGE_SIZE = 100


def _warn_clamped(requested, effective):
    """Tell the caller their page size was capped, once, on stderr."""
    if requested is not None and requested > effective:
        print(
            f"WARNING: requested page size {requested} exceeds the server maximum "
            f"{effective}; returning at most {effective} rows.\n"
            f"         This page is NOT the full result set — use --all to "
            f"auto-paginate.",
            file=sys.stderr,
        )

def resolve_page(page, page_size, limit, offset, default_page_size=50):
    """Collapse the four flags into a (page, page_size) pair for page-based APIs.

    Precedence: explicit --page/--page-size win; otherwise derive from
    --limit/--offset (page = offset // limit + 1, page_size = limit).
    """
    requested = page_size if page_size is not None else limit
    eff_size = page_size if page_size is not None else (limit if limit is not None else default_page_size)
    eff_size = min(eff_size, MAX_PAGE_SIZE)
    _warn_clamped(requested, eff_size)
    if page is not None:
        eff_page = page
    elif offset is not None and eff_size:
        eff_page = (offset // eff_size) + 1
    else:
        eff_page = 1
    return eff_page, eff_size


def resolve_limit_offset(page, page_size, limit, offset, default_limit=50):
    """Collapse the four flags into a (limit, offset) pair for offset-based APIs.

    Precedence: explicit --limit/--offset win; otherwise derive from
    --page/--page-size (limit = page_size, offset = (page-1)*page_size).
    """
    requested = limit if limit is not None else page_size
    eff_limit = limit if limit is not None else (page_size if page_size is not None else default_limit)
    eff_limit = min(eff_limit, MAX_PAGE_SIZE)
    _warn_clamped(requested, eff_limit)
    if offset is not None:
        eff_offset = offset
    elif page is not None:
        eff_offset = (max(page, 1) - 1) * eff_limit
    else:
        eff_offset = 0
    return eff_limit, eff_offset


class PagingError(Exception):
    """`--all` could not walk the collection safely (see `fetch_all_pages`)."""


def extract_items(data, item_keys=("items",)):
    """The rows of one collection response: a bare list, or the first LIST found under
    `item_keys`. ⛔ Never falls back to the response itself: `data.get('items', data)`
    on a dict whose rows live under another key iterates the DICT and yields its KEY
    NAMES — `transformer-executions list --all` returned the strings "executions",
    "total", "limit", "offset" over and over."""
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for key in item_keys:
            if isinstance(data.get(key), list):
                return data[key]
        raise PagingError(f"response has no row list under {list(item_keys)} "
                          f"(keys: {sorted(data)[:8]})")
    raise PagingError(f"unexpected response type {type(data).__name__}")


def _row_key(row):
    return row.get("id") if isinstance(row, dict) and row.get("id") else repr(row)


def fetch_all_pages(get_page, *, page_size, max_pages=1000):
    """Walk a paged collection to its end. `get_page(index)` (0-based) returns
    `(rows, total_or_None)`. Returns `(all_rows, total)`.

    Stops on an empty page, a short page, or once `total` rows are in hand. ⛔ Raises
    instead of spinning when a page REPEATS the previous one — the endpoint ignored
    the offset. The old inline loops stopped only at `len(rows) >= total`, so a
    server that ignored `skip`, or a response whose rows sat under another key (the
    workspace alert-routes list returns `alert_routes`, not `items`), looped forever:
    `alert-routes list --all` never returned.
    """
    rows, total, prev_first = [], None, None
    for index in range(max_pages):
        page_rows, page_total = get_page(index)
        if page_total is not None:
            total = page_total
        if not page_rows:
            break
        first = _row_key(page_rows[0])
        if index and first == prev_first:
            raise PagingError(
                f"page {index + 1} repeated page {index}: the endpoint ignored the "
                f"offset, so --all cannot page it (got {len(rows)} rows so far)")
        prev_first = first
        rows.extend(page_rows)
        if (total is not None and len(rows) >= total) or len(page_rows) < page_size:
            break
    else:
        raise PagingError(f"stopped after {max_pages} pages ({len(rows)} rows)")
    return rows, (total if total is not None else len(rows))
