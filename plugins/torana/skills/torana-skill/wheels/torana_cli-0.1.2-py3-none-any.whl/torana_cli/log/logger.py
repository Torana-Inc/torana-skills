"""
CLI logger — writes to a log file only (never to stdout/stderr).
stdout/stderr are reserved for command output and user-facing errors.
"""

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


_configured = False
_root_logger: Optional[logging.Logger] = None


class _TextFormatter(logging.Formatter):
    """Human-readable log format: timestamp LEVEL [module] message"""

    def format(self, record: logging.LogRecord) -> str:
        ts = datetime.fromtimestamp(record.created, tz=timezone.utc).strftime(
            "%Y-%m-%d %H:%M:%S"
        )
        level = record.levelname.ljust(5)
        module = record.name.split(".")[-1]
        return f"{ts} {level} [{module}] {record.getMessage()}"


class _JsonFormatter(logging.Formatter):
    """Structured JSON log format."""

    def format(self, record: logging.LogRecord) -> str:
        entry = {
            "ts": datetime.fromtimestamp(record.created, tz=timezone.utc).isoformat(),
            "level": record.levelname,
            "module": record.name.split(".")[-1],
            "msg": record.getMessage(),
        }
        if record.exc_info:
            entry["exc"] = self.formatException(record.exc_info)
        return json.dumps(entry)


def configure_logging(
    log_level: str = "info",
    log_format: str = "text",
    log_file: Optional[str] = None,
) -> None:
    """
    Configure the CLI logger. Call once at startup from the main Click group.
    Writes only to the log file — never to console.
    """
    global _configured, _root_logger

    numeric_level = getattr(logging, log_level.upper(), logging.INFO)

    # Resolve log file path
    if not log_file:
        log_file = str(Path.home() / ".torana" / "logs" / "torana-cli.log")

    log_path = Path(log_file).expanduser()
    log_path.parent.mkdir(parents=True, exist_ok=True)

    formatter: logging.Formatter
    if log_format == "json":
        formatter = _JsonFormatter()
    else:
        formatter = _TextFormatter()

    handler = logging.FileHandler(str(log_path), encoding="utf-8")
    handler.setFormatter(formatter)

    root = logging.getLogger("torana_cli")
    root.setLevel(numeric_level)
    root.handlers.clear()
    root.addHandler(handler)
    root.propagate = False

    _root_logger = root
    _configured = True


def get_logger(name: str) -> logging.Logger:
    """Get a child logger under the torana_cli namespace."""
    if not _configured:
        # Lazy default config — no file output until configure_logging() is called
        logger = logging.getLogger(name)
        logger.addHandler(logging.NullHandler())
        return logger
    return logging.getLogger(name)
