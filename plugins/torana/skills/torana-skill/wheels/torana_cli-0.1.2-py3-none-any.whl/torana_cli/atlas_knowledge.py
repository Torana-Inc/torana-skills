"""torana atlas context | ask | answer | skill | facts | map | reachability — the knowledge APIs (KNOWLEDGE_API.md § 3.4.5).

Two ways to use the knowledge, both over the same assembled context:
  * `context` and the pulls (`skill`, `facts`, `map`): deterministic retrieval, no model, no cost. The caller infers.
  * `ask`: one bounded model session over that context; the answer comes back with its statements, certainty and anchors.
    PAID: it spends the tenant's money (capped per ask); `context` first, `ask` only when the question needs inference.

If an answer is wrong, `context` for the same keys shows whether retrieval or synthesis failed.

Instance operations on one stored answer: `torana atlas answer <ID> get|cancel|bundle` (the plural/singular rule).
Anchors of a node version live in atlas_node.py (`torana atlas node <PATH> anchors|anchor`).

⚠️ File output is `--out`, never `-o` (the root group lifts `-o` as the global format flag).
"""

import json
import re
import sys
import time

import click

from torana_cli.atlas import _call, _client, _fmt, _params, human_time
from torana_cli.client.base import EXIT_RUN_FAILED
from torana_cli.output import output

_MARK = {"evidenced": "✓", "believed": "?", "not_known": "○"}     # always printed beside the WORD (never colour alone)
_ANCHOR_REF = re.compile(r"^atlas:(?P<path>.*)@(?P<version>\d+)#(?P<id>a:\d+|ix:(?:imports|callgraph):\d+:\d+)$")


def tenant_opt(f):
    return click.option("--tenant", default=None, help="Another tenant's knowledge (SA only).")(f)


def _money(value) -> str:
    return f"${float(value or 0):.2f}"


def anchor_command(ref: str) -> str | None:
    """`atlas:code/acme/api@3#a:17` (or a code-index anchor, `…#ix:imports:4:12`) -> the command that opens that anchor's
    proof; None for an unparseable ref."""
    m = _ANCHOR_REF.match(ref or "")
    if not m:
        return None
    return f"torana atlas node {m['path']} anchor {m['id']} --version {m['version']}"


def _statement_lines(stmts: list, indent: str = "  ") -> list:
    out = []
    for s in stmts or []:
        cert = s.get("certainty", "?")
        sec = f" §{s['section']}" if s.get("section") else ""
        out.append(f"{indent}{s.get('id', '?')}{sec} {_MARK.get(cert, '?')} {cert}: {s.get('text', '')}")
        if s.get("open_question"):
            out.append(f"{indent}    open question: {s['open_question']}")
        if s.get("basis"):
            out.append(f"{indent}    basis: {s['basis']}")
        if s.get("overridden_by"):
            out.append(f"{indent}    overridden by {s['overridden_by']}")
        for a in s.get("anchors") or []:
            cmd = anchor_command(a.get("ref", ""))
            state = "" if a.get("resolved", True) else "  (UNRESOLVED: that anchor id is not in the version)"
            where = f"{a.get('target')}" + (f":{a['line']}" if a.get("line") else "")
            out.append(f"{indent}    proof {a.get('kind')} {where}{state}")
            if cmd:
                out.append(f"{indent}      {cmd}")
    return out


def _gap_lines(gaps: list) -> list:
    out = []
    for g in gaps or []:
        out.append(f"  {g.get('id')} {g.get('about_type')} {g.get('about')}: {g.get('reason')} — {g.get('detail')}")
        if g.get("unlocks"):
            out.append(f"      unlocks: {g['unlocks']}")
    return out


def _header(data: dict, noun: str) -> str:
    u = data.get("usage") or {}
    out = (f"{noun} {data.get('request_id', '?')}  status {data.get('status')}  outcome {data.get('outcome')}  "
           f"as of {human_time(data.get('as_of'))}  bundle {u.get('tokens_total', '?')} tokens  "
           f"{u.get('latency_ms', '?')} ms")
    if data.get("truncated"):
        out += "  (truncated)"
    return out


def _trace_line(data: dict) -> str:
    links = data.get("links") or {}
    return f"trace {data.get('trace_id')}  {links.get('trace', '')}".rstrip()


def _resolution_lines(res: list) -> list:
    out = []
    for r in res or []:
        sk = (r.get("skill") or {}).get("name")
        tail = f" -> {r['entity_key']}" if r.get("entity_key") else ""
        tail += f"  skill {sk}" if sk else ""
        tail += f"  ({r['reason']})" if r.get("reason") else ""
        tail += f"  {r['label']}" if r.get("label") else ""
        out.append(f"  {r.get('key')}{tail}  [{r.get('rung')}, {r.get('certainty')}]")
    return out


def _contribution_lines(contribs: list) -> list:
    out = []
    for c in contribs or []:
        sk = c.get("skill") or {}
        ver = f"v{sk['version']}" if sk.get("version") else "rendered"
        cert = c.get("certainty") or {}
        counts = f"✓{cert.get('evidenced', 0)} ?{cert.get('believed', 0)} ○{cert.get('not_known', 0)}"
        stale = "  STALE" if sk.get("stale") else ""
        out.append(f"  {c.get('id')} {sk.get('name')}  {ver}  {c.get('role')}/{c.get('portion')}  "
                   f"distance {c.get('distance')}  {c.get('tokens')} tokens  {counts}{stale}  why: {c.get('reason')}")
        files = c.get("files") or []
        if files:
            left = [f for f in files if not f.get("included", True)]
            out.append(f"      files: {len(files) - len(left)} included, {len(left)} left out "
                       f"(fetch one: torana atlas skill {sk.get('name')} --file F)"
                       + ("" if not left else "; left out: " + ", ".join(f"{f['path']} [{f.get('reason')}]" for f in left[:6])
                          + (" …" if len(left) > 6 else "")))
        out.extend(_statement_lines(c.get("statements"), indent="      "))
    return out


def _asked_keys(asked: dict) -> str:
    keys = [k.get("key") if isinstance(k, dict) else k for k in asked.get("keys") or []]
    return ", ".join(keys) or "(overview)"


def render_context(data: dict) -> str:
    asked = data.get("asked") or {}
    lines = [_header(data, "context"),
             f"asked: keys {_asked_keys(asked)}"
             + (f"  question: {asked['question']}" if asked.get("question") else "")]
    if data.get("resolution"):
        lines += ["", f"resolution ({len(data['resolution'])})", *_resolution_lines(data["resolution"])]
    walk = data.get("walk") or {}
    if walk.get("not_included"):
        lines += ["", "keys with no knowledge yet"] + [
            f"  {n.get('key')}: {n.get('reason')}" + (f" — {n['unlock']}" if n.get("unlock") else "")
            for n in walk["not_included"]]
    contribs = data.get("contributions") or []
    lines += ["", f"contributions ({len(contribs)})", *_contribution_lines(contribs)]
    if data.get("gaps"):
        lines += ["", f"gaps ({len(data['gaps'])})", *_gap_lines(data["gaps"])]
    pull = data.get("pull")
    if pull:
        lines += ["", "pull next",
                  f"  skills: {', '.join(pull.get('skills') or []) or '-'}",
                  f"  maps: {', '.join(pull.get('maps') or []) or '-'}",
                  f"  facts keys: {', '.join(pull.get('facts_keys') or []) or '-'}"]
    if data.get("bundle"):
        lines.append(f"\nbundle {data['bundle'].get('bundle_id')}  {data['bundle'].get('tokens_total')} tokens  "
                     f"(torana atlas context get {data.get('request_id')} --out FILE)")
    lines.append(_trace_line(data))
    return "\n".join(lines)


def render_answer(data: dict) -> str:
    status = data.get("status")
    lines = [_header(data, "answer")]
    asked = data.get("asked") or {}
    if asked.get("question"):
        lines.append(f"question: {asked['question']}")
    if status == "running":
        lines += ["", f"still running. Follow it: torana atlas answer {data.get('request_id')} get --wait"]
    err = data.get("error")
    if err:
        lines += ["", f"error {err.get('error')}: {err.get('message')}"]
    ans = data.get("answer")
    if ans:
        lines += ["", ans.get("summary", ""), "", f"statements ({len(ans.get('statements') or [])})",
                  *_statement_lines(ans.get("statements"))]
    facts = data.get("caller_facts") or []
    if facts:
        lines += ["", "facts you supplied"] + [
            f"  fact {f.get('n')} ({f.get('source')}{', ' + f['label'] if f.get('label') else ''}): "
            f"cited by {', '.join(f.get('cited_by') or []) or 'no statement'}" for f in facts]
    if data.get("contributions"):
        lines += ["", f"knowledge given to the session ({len(data['contributions'])} skills)",
                  *_contribution_lines([{**c, "statements": [], "files": []} for c in data["contributions"]])]
    if data.get("gaps"):
        lines += ["", f"gaps ({len(data['gaps'])})", *_gap_lines(data["gaps"])]
    s, u = data.get("session") or {}, data.get("usage") or {}
    prof = data.get("profile") or {}
    lines += ["", f"COST {_money(u.get('cost_usd'))}"
                  + (f"  session {s.get('model')}  {s.get('num_turns')} turns  {s.get('tokens_in', 0)} in / "
                     f"{s.get('tokens_out', 0)} out  {s.get('duration_ms', 0) // 1000}s  status {s.get('status')}"
                     if s else "")
                  + (f"  profile {prof.get('name')}" if prof.get("name") else ""),
              _trace_line(data)]
    return "\n".join(lines)


def _save_bundle(ctx, client, route: str, out_file: str, tenant) -> None:
    content, _ = _call(client.get_bytes, route, params=_params(tenant=tenant) or None)
    with open(out_file, "wb") as f:
        f.write(content)
    if _fmt(ctx)[0] == "text":
        click.echo(f"wrote {out_file} ({len(content)} bytes)", err=True)


# ---------------------------------------------------------------------------
# torana atlas context
# ---------------------------------------------------------------------------

class _ContextGroup(click.Group):
    """`atlas context KEY… [--question Q]` is `atlas context query …`; `atlas context get ID` reads a stored one.
    A bare `atlas context` prints help and calls nothing. Keys are `<type>:<rest>`, so none collides with a verb."""

    def parse_args(self, ctx, args):
        if args and args[0] not in self.commands and args[0] not in ("--help", "-h"):
            args = ["query", *args]
        return super().parse_args(ctx, args)


@click.group(name="context", cls=_ContextGroup, invoke_without_command=True)
@click.pass_context
def atlas_context(ctx):
    """Get the knowledge for keys and/or a question: deterministic, no model, no cost. YOU do the inferring.

    Keys are entity keys (`repo:github.com/acme/api`, `image:…`, `pkg:…`). No keys = the tenant overview.
    The question only guides trimming and focus; it never selects a node. Needs atlas:read.

    \b
    Examples:
      torana atlas context repo:github.com/acme/api
      torana atlas context repo:github.com/acme/api --question "which base image?" --delivery hybrid
      torana atlas context get 7c1d...-request-id --json
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@atlas_context.command(name="query")
@click.argument("keys", nargs=-1, metavar="KEY...")
@click.option("--question", default=None, help="The question this context is for (guides trimming and focus only).")
@click.option("--delivery", type=click.Choice(["push", "pull", "hybrid"]), default=None,
              help="push = full bundle; pull = starter + what to pull next; hybrid = both (default: the profile's).")
@click.option("--goal", type=click.Choice(["answer", "build"]), default="answer", show_default=True,
              help="Freshness rules: answer (read) or build.")
@click.option("--budget", "budget_tokens", type=click.IntRange(min=1000), default=None,
              help="Token budget for the bundle (default: the platform's).")
@click.option("--explain", is_flag=True, default=False, help="Say why each node was reached or trimmed.")
@click.option("--statements", "with_statements", is_flag=True, default=False,
              help="Parse every skill into its statements (certainty and anchors) in the answer.")
@click.option("--no-files", is_flag=True, default=False, help="Do not list files or build the bundle.")
@click.option("--out", "out_file", default=None, metavar="FILE", help="Also download the bundle tarball to FILE.")
@tenant_opt
@click.pass_context
def atlas_context_query(ctx, keys, question, delivery, goal, budget_tokens, explain, with_statements, no_files,
                        out_file, tenant):
    """Get knowledge for KEY... and/or --question: which skills, why, how certain, and what is missing.

    \b
    Examples:
      torana atlas context repo:github.com/acme/api --statements
      torana atlas context --question "what runs in the payments namespace?" --explain
      TORANA_PROFILE=SA torana atlas context repo:github.com/acme/api --tenant <TENANT_ID> --json
    """
    fmt, _, _ = _fmt(ctx)
    if not keys and not question:
        click.echo("note: no keys and no question: this is the tenant overview", err=True)
    body = {"keys": [{"key": k} for k in keys], "goal": goal, "explain": explain,
            "include": {"files": not no_files, "statements": with_statements}}
    body.update(_params(question=question, delivery=delivery, budget_tokens=budget_tokens))
    client = _client(ctx)
    data = _call(client.post, "atlas/context", json=body, params=_params(tenant=tenant) or None)
    if out_file and isinstance(data, dict) and data.get("request_id"):
        _save_bundle(ctx, client, f"atlas/context/{data['request_id']}/bundle", out_file, tenant)
    if fmt == "text" and isinstance(data, dict):
        click.echo(render_context(data))
        return
    output(data, fmt=fmt)


@atlas_context.command(name="get")
@click.argument("request_id", metavar="ID")
@click.option("--out", "out_file", default=None, metavar="FILE", help="Also download the bundle tarball to FILE.")
@tenant_opt
@click.pass_context
def atlas_context_get(ctx, request_id, out_file, tenant):
    """Read a stored context exactly as it was served (and, with --out, rebuild its bundle).

    \b
    Examples:
      torana atlas context get 7c1d2e0a-1111-2222-3333-444455556666
      torana atlas context get 7c1d2e0a-1111-2222-3333-444455556666 --out bundle.tar --json
    """
    fmt, _, _ = _fmt(ctx)
    client = _client(ctx)
    data = _call(client.get, f"atlas/context/{request_id}", params=_params(tenant=tenant) or None)
    if out_file:
        _save_bundle(ctx, client, f"atlas/context/{request_id}/bundle", out_file, tenant)
    if fmt == "text" and isinstance(data, dict):
        click.echo(render_context(data))
        return
    output(data, fmt=fmt)


# ---------------------------------------------------------------------------
# torana atlas ask / answer <ID>
# ---------------------------------------------------------------------------

def _parse_fact(raw: str) -> dict:
    source, sep, text = raw.partition("=")
    if not sep or not source.strip() or not text.strip():
        raise click.UsageError(f"--fact wants SOURCE=TEXT (e.g. detection='the alert fired at 10:02'), got: {raw}")
    return {"source": source.strip(), "fact": text.strip()}


def wait_for_answer(ctx, client, request_id: str, tenant, poll: float, timeout: float):
    """Poll GET /atlas/answers/{id} until it leaves `running`. Status changes go to STDERR, the final answer to stdout.
    Exit 0 when it completed, 8 when it failed, was cancelled, or the wait timed out. Ctrl-C stops watching, not the ask."""
    fmt, _, _ = _fmt(ctx)
    deadline, last, body = time.monotonic() + timeout, None, None
    try:
        while True:
            body = _call(client.get, f"atlas/answers/{request_id}", params=_params(tenant=tenant) or None)
            if body.get("status") != last:
                last = body.get("status")
                click.echo(f"answer {request_id}: {last}", err=True)
            if body.get("status") != "running":
                break
            if time.monotonic() >= deadline:
                click.echo(f"answer {request_id} still running after {int(timeout)}s; stopped waiting "
                           f"(torana atlas answer {request_id} get)", err=True)
                _print_answer(fmt, body)
                sys.exit(EXIT_RUN_FAILED)
            time.sleep(poll)
    except KeyboardInterrupt:
        click.echo(f"\nstopped watching; the ask continues (torana atlas answer {request_id} get)", err=True)
        sys.exit(130)
    _print_answer(fmt, body)
    if body.get("status") != "complete":
        sys.exit(EXIT_RUN_FAILED)


def _print_answer(fmt: str, data) -> None:
    if fmt == "text" and isinstance(data, dict):
        click.echo(render_answer(data))
    else:
        output(data, fmt=fmt)


def wait_options(f):
    f = click.option("--wait-timeout", type=click.FloatRange(min=1), default=900.0, show_default=True,
                     help="With --wait: stop waiting after this many seconds (exit 8; the ask continues).")(f)
    f = click.option("--poll", type=click.FloatRange(min=1), default=3.0, show_default=True,
                     help="With --wait: seconds between status checks.")(f)
    return click.option("--wait", is_flag=True, default=False,
                        help="Follow the ask until it finishes: status on stderr, the answer on stdout; "
                             "exit 0 complete, 8 failed, cancelled or timed out.")(f)


@click.command(name="ask")
@click.argument("question", metavar="QUESTION")
@click.option("--key", "keys", multiple=True, metavar="KEY", help="An entity key to ground the answer (repeatable).")
@click.option("--fact", "facts", multiple=True, metavar="SOURCE=TEXT",
              help="A fact YOU supply, marked caller-supplied in the answer, never evidenced (repeatable).")
@click.option("--max-budget", "max_budget_usd", type=click.FloatRange(min=0.01), default=None,
              help="Spend cap in USD for this ask (the profile's cap still applies; default $0.75).")
@click.option("--session-timeout", "timeout_s", type=click.IntRange(min=30), default=None,
              help="Seconds the model session may run (the profile's cap still applies).")
@click.option("--budget", "budget_tokens", type=click.IntRange(min=1000), default=None,
              help="Token budget for the knowledge bundle given to the session.")
@click.option("--explain", is_flag=True, default=False, help="Also say why each node was reached or trimmed.")
@wait_options
@tenant_opt
@click.pass_context
def atlas_ask(ctx, question, keys, facts, max_budget_usd, timeout_s, budget_tokens, explain, wait, poll, wait_timeout,
              tenant):
    """Ask a question: Atlas runs ONE bounded model session over the knowledge and answers with proof. PAID.

    Answers at once with a request id (status running); --wait follows it. Every statement carries a certainty
    (✓ evidenced, ? believed, ○ not known) and the anchors that prove it: open one with
    `torana atlas node <PATH> anchor <ID> --version N`. Needs atlas:ask. For a free, deterministic read use
    `torana atlas context`.

    \b
    Examples:
      torana atlas ask "Which base image does pantheon-agent-builder build FROM?" --wait
      torana atlas ask "Who owns the payments repo?" --key repo:github.com/acme/payments --max-budget 0.5 --wait
      torana atlas ask "Is this alert reachable?" --fact "detection=alert 41 fired on checkout" --wait --json
    """
    fmt, _, _ = _fmt(ctx)
    body = {"question": question, "keys": [{"key": k} for k in keys], "explain": explain,
            "context": [_parse_fact(f) for f in facts]}
    body.update(_params(budget_tokens=budget_tokens))
    inference = _params(max_budget_usd=max_budget_usd, timeout_s=timeout_s)
    if inference:
        body["inference"] = inference
    client = _client(ctx)
    if fmt == "text":
        click.echo("asking (paid: one bounded model session, cost is shown on the answer)", err=True)
    data = _call(client.post, "atlas/answers", json=body, params=_params(tenant=tenant) or None)
    rid = data.get("request_id") if isinstance(data, dict) else None
    if not wait or not rid:
        _print_answer(fmt, data)
        return
    wait_for_answer(ctx, client, rid, tenant, poll, wait_timeout)


@click.group(name="answer", invoke_without_command=True)
@click.argument("request_id", metavar="ID")
@click.pass_context
def atlas_answer(ctx, request_id):
    """Operate on one stored answer by request id: read it, cancel it, or fetch its bundle.

    \b
    Examples:
      torana atlas answer 7c1d2e0a-1111-2222-3333-444455556666 get --wait
      torana atlas answer 7c1d2e0a-1111-2222-3333-444455556666 cancel
    """
    ctx.ensure_object(dict)
    ctx.obj["_atlas_answer_id"] = request_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _answer_id(ctx) -> str:
    return ctx.obj["_atlas_answer_id"]


@atlas_answer.command(name="get")
@wait_options
@tenant_opt
@click.pass_context
def atlas_answer_get(ctx, wait, poll, wait_timeout, tenant):
    """Read the answer: summary, statements with certainty and anchors, what it cost, the trace.

    \b
    Examples:
      torana atlas answer 7c1d2e0a-1111-2222-3333-444455556666 get
      torana atlas answer 7c1d2e0a-1111-2222-3333-444455556666 get --wait --json
    """
    fmt, _, _ = _fmt(ctx)
    client = _client(ctx)
    if wait:
        wait_for_answer(ctx, client, _answer_id(ctx), tenant, poll, wait_timeout)
        return
    _print_answer(fmt, _call(client.get, f"atlas/answers/{_answer_id(ctx)}", params=_params(tenant=tenant) or None))


@atlas_answer.command(name="cancel")
@tenant_opt
@click.pass_context
def atlas_answer_cancel(ctx, tenant):
    """Cancel a running ask (kills the session; the answer shows the cost recorded).

    \b
    Examples:
      torana atlas answer 7c1d2e0a-1111-2222-3333-444455556666 cancel
    """
    fmt, _, _ = _fmt(ctx)
    _print_answer(fmt, _call(_client(ctx).post, f"atlas/answers/{_answer_id(ctx)}/cancel",
                             params=_params(tenant=tenant) or None))


@atlas_answer.command(name="bundle")
@click.option("--out", "out_file", required=True, metavar="FILE", help="Where to write the bundle tarball.")
@tenant_opt
@click.pass_context
def atlas_answer_bundle(ctx, out_file, tenant):
    """Download the knowledge bundle the session was given (rebuilt at the same versions).

    \b
    Examples:
      torana atlas answer 7c1d2e0a-1111-2222-3333-444455556666 bundle --out given.tar
    """
    _save_bundle(ctx, _client(ctx), f"atlas/answers/{_answer_id(ctx)}/bundle", out_file, tenant)
    if _fmt(ctx)[0] != "text":
        output({"out": out_file}, fmt=_fmt(ctx)[0])


# ---------------------------------------------------------------------------
# pulls: skill, facts, map
# ---------------------------------------------------------------------------

def _slice_note(sl: dict | None) -> str:
    if not sl:
        return ""
    done = "" if sl.get("complete") in (True, None) else "  (incomplete: truncated at build time)"
    return f"sliced {', '.join(sl.get('terms') or [])}: kept {sl.get('kept')} of {sl.get('total')} records{done}"


@click.command(name="skill")
@click.argument("name", metavar="NAME")
@click.option("--file", "file_path", default="SKILL.md", show_default=True, help="The file inside the skill folder.")
@click.option("--version", "version", type=click.IntRange(min=1), default=None,
              help="A version number (default: the current one).")
@click.option("--term", "terms", multiple=True, metavar="FIELD:VALUE",
              help="On a fact file: only the records matching this (repeatable; a bare value is expanded).")
@tenant_opt
@click.pass_context
def atlas_skill(ctx, name, file_path, version, terms, tenant):
    """Pull one skill file by its skill NAME (see `context --delivery hybrid` or `node PATH get`): free, no model.

    The text goes to stdout; the version, slice and the skill's other files go to stderr.

    \b
    Examples:
      torana atlas skill atlas-code-acme-api
      torana atlas skill atlas-code-acme-api --file facts/usage.json --term package:litellm
      torana atlas skill atlas-code-acme-api --version 3 --json
    """
    fmt, _, _ = _fmt(ctx)
    params = _params(file=file_path, version=version, tenant=tenant)
    if terms:
        params["term"] = list(terms)
    data = _call(_client(ctx).get, f"atlas/skills/{name}", params=params)
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt)
        return
    sk = data.get("skill") or {}
    click.echo(f"{sk.get('name')}  {('v' + str(sk['version'])) if sk.get('version') else 'rendered'}  "
               f"{data.get('file')}  as of {human_time(sk.get('as_of'))}" + ("  STALE" if sk.get("stale") else ""),
               err=True)
    if data.get("slice"):
        click.echo(_slice_note(data["slice"]), err=True)
    others = [f["path"] for f in data.get("files") or []]
    if others:
        click.echo("files: " + ", ".join(others), err=True)
    text = data.get("text")
    if text is None:
        click.echo(f"(no text: {data.get('file')} is binary or over the cap)", err=True)
        return
    click.echo(text, nl=not text.endswith("\n"))


@click.command(name="facts")
@click.argument("key", metavar="KEY")
@click.option("--term", "terms", multiple=True, required=True, metavar="FIELD:VALUE",
              help="REQUIRED (the API refuses a whole-file dump): only records matching this "
                   "(repeatable; a bare value is expanded).")
@click.option("--file", "file_path", default=None, help="Only this fact file (e.g. facts/usage.json).")
@click.option("--from", "source", type=click.Choice(["snapshot", "skill"]), default=None,
              help="snapshot (the server's default): the latest code snapshot, computed without the model; skill: the "
                   "facts exactly as the written skill version cites them.")
@tenant_opt
@click.pass_context
def atlas_facts(ctx, key, terms, file_path, source, tenant):
    """Pull the fact records for an entity KEY that match --term, with the anchors they cite: free, no model.

    At least one --term is required. To read a whole fact file use `skill NAME --file facts/X.json`.

    \b
    Examples:
      torana atlas facts repo:github.com/acme/api --term package:litellm
      torana atlas facts repo:github.com/acme/api --term package:litellm --from skill
      torana atlas facts repo:github.com/acme/api --file facts/dockerfiles.json --json
    """
    fmt, _, _ = _fmt(ctx)
    params = _params(key=key, file=file_path, tenant=tenant, **{"from": source})
    if terms:
        params["term"] = list(terms)
    data = _call(_client(ctx).get, "atlas/facts", params=params)
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt)
        return
    click.echo(f"facts {key}  {data.get('total', 0)} records  terms {data.get('terms') or '-'}")
    for r in _resolution_lines(data.get("resolution")):
        click.echo(r)
    for sl in data.get("slices") or []:
        click.echo(f"\n{(sl.get('skill') or {}).get('name')}  {sl.get('file')}  {_slice_note(sl.get('slice'))}")
        if (sl.get("snapshot") or {}).get("words"):            # OI-180 C6: the server's words for the code snapshot
            click.echo(f"  {sl['snapshot']['words']}")
        for rec in sl.get("records") or []:
            click.echo("  " + json.dumps(rec, separators=(",", ":"), ensure_ascii=False))
        for a in sl.get("anchors") or []:
            cmd = anchor_command(a.get("ref", ""))
            click.echo(f"  proof {a.get('kind')} {a.get('target')}" + (f":{a['line']}" if a.get("line") else "")
                       + (f"\n    {cmd}" if cmd else ""))
    if data.get("gaps"):
        click.echo("\ngaps")
        for ln in _gap_lines(data["gaps"]):
            click.echo(ln)


@click.command(name="map")
@click.argument("name", metavar="NAME")
@click.option("--filter", "--key", "key", default=None, metavar="TEXT",
              help="Only the map rows mentioning TEXT (an entity key or a name). Omit for the whole map (up to --limit).")
@click.option("--limit", type=click.IntRange(1, 500), default=50, show_default=True, help="Rows to return.")
@tenant_opt
@click.pass_context
def atlas_map(ctx, name, key, limit, tenant):
    """Pull the rows of a cross-node map (dependencies, ingress, …), all of them or those mentioning a key: free, no model.

    \b
    Examples:
      torana atlas map ingress --limit 500
      torana atlas map dependencies --filter litellm
      torana atlas map dependencies --filter repo:github.com/acme/api --limit 20 --json
    """
    fmt, _, _ = _fmt(ctx)
    data = _call(_client(ctx).get, f"atlas/maps/{name}", params=_params(key=key, limit=limit, tenant=tenant))
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt)
        return
    cols = data.get("columns") or []
    click.echo(f"map {name}  {data.get('total', 0)} rows" + (f" match '{key}'" if key else "")
               + (f" (showing {len(data.get('rows') or [])})" if data.get("total", 0) > len(data.get("rows") or []) else ""))
    if data.get("rows"):
        output({"items": data["rows"], "total": len(data["rows"])}, fmt="text",
               columns=[(c, c.upper(), None) for c in cols], pagination_hint=False)   # None: never cut a path (OI-133)
    for ln in _gap_lines(data.get("gaps")):
        click.echo(ln)


# ── reachability (REACHABILITY_EXTRACTOR.md § 3.4.1, § 3.4.3) ─────────────────────────────────────────────────

_STATE_MARK = {"measured": "✓", "measured_at_other_commit": "✓", "not_known": "○"}   # beside the WORD, never colour alone


def _reach_node_source(node: dict) -> str:
    """What an answer was measured on (OI-180 contract C2): `code facts at commit X (snapshot K) · skill vN`, or
    `· skill not written yet`; a server without snapshots: `vN built at X` as before."""
    commit = str(node.get("commit") or node.get("built_against") or "")[:12]
    if not node.get("snapshot"):
        return f"v{node.get('version')} built at {commit}"
    skill = f"skill v{node['version']}" if node.get("version") else "skill not written yet"
    return f"code facts at commit {commit} (snapshot {node['snapshot']}) · {skill}"


def render_reachability(data: dict) -> str:
    lines = [f"reachability  {data.get('repository', '')}  request {data.get('request_id', '')}"]
    for a in data.get("answers") or []:
        state = a.get("state", "?")
        head = f"  {a.get('id', '?')}  {_STATE_MARK.get(state, '?')} {state}"
        if a.get("verdict"):
            head += f": {a['verdict']}" + (f" ({a['certainty']})" if a.get("certainty") else "")
        lines.append(head)
        if state == "not_known":
            lines.append(f"      {a.get('reason')}: {a.get('reason_text') or ''}".rstrip())
        ev = a.get("evidence") or {}
        node = a.get("node") or {}
        if node.get("path"):
            lines.append(f"      node {node['path']} {_reach_node_source(node)}")
        if ev.get("reason"):                                     # the library's one-sentence why
            lines.append(f"      {ev['reason']}")
        if state == "measured_at_other_commit" and ev.get("measured_at"):
            lines.append(f"      measured at {str(ev['measured_at'])[:12]}, asked about {str(ev.get('alert_commit') or '')[:12]}:"
                         " no file this answer rests on changed between them")
        for ref in (ev.get("anchors") or [])[:5]:
            cmd = anchor_command(ref)
            lines.append(f"      evidence {ref}" + (f"\n        open: {cmd}" if cmd else ""))
        if len(ev.get("anchors") or []) > 5:
            lines.append(f"      … {len(ev['anchors']) - 5} more anchors (--json lists them all)")
    return "\n".join(lines)


@click.command(name="reachability")
@click.option("--repository", default=None, metavar="KEY",
              help="The repository key, e.g. repo:github.com/acme/api (see `torana atlas selection list`). Required, "
                   "except with --questions-file whose body names it (an explicit --repository fills it if absent).")
@click.option("--package", default=None, help="Package question: does the repository import this package?")
@click.option("--ecosystem", default=None, help="The package's ecosystem as the finding spells it (pypi, npm, golang, cargo, …).")
@click.option("--file", "file_path", default=None, metavar="PATH",
              help="Code question: is a function in this repository-relative file reachable from an entry point?")
@click.option("--function", default=None, help="With --file: one function (default: every def in the file).")
@click.option("--subject", type=click.Choice(["repository", "image"]), default="repository", show_default=True,
              help="image: the question is about an image the repository builds (needs --image-digest).")
@click.option("--image-digest", default=None, metavar="sha256:…", help="With --subject image: the image's digest.")
@click.option("--commit", "commit", default=None, metavar="SHA",
              help="The commit the finding was scanned at; the answer says whether Atlas's build speaks for it.")
@click.option("--questions-file", type=click.File("r"), default=None, metavar="FILE",
              help="A JSON request body with many questions ({repository, questions: [...]}); '-' reads stdin.")
@tenant_opt
@click.pass_context
def atlas_reachability(ctx, repository, package, ecosystem, file_path, function, subject, image_digest, commit,
                       questions_file, tenant):
    """Ask whether a repository imports a package, or reaches a function, from Atlas's stored code index: free, no model.

    Every question gets an answer: measured, measured at another commit (no file it rests on changed), or not known
    with a reason (not selected, not built yet, built before the code index existed, the commit is unknown, …).
    Each piece of evidence is an anchor: open it with `torana atlas node <PATH> anchor <ID>`.

    \b
    Examples:
      torana atlas reachability --repository repo:github.com/acme/api --package litellm --ecosystem pypi
      torana atlas reachability --repository repo:github.com/acme/api --file src/api.py --function handler
      torana atlas reachability --repository repo:github.com/acme/api --package requests --ecosystem pypi --commit 1a2b3c4
      torana atlas reachability --questions-file questions.json --json     # the body names its repository
    """
    fmt, _, _ = _fmt(ctx)
    if questions_file is not None:
        if package or file_path:
            raise click.UsageError("--questions-file replaces --package/--file; give one or the other")
        try:
            body = json.load(questions_file)
        except ValueError as e:
            raise click.UsageError(f"--questions-file is not JSON: {e}")
        if not isinstance(body, dict):
            raise click.UsageError("--questions-file must hold one JSON object: {repository, questions: [...]}")
        if repository:
            body.setdefault("repository", repository)
        if not body.get("repository"):
            raise click.UsageError("the request needs a repository: put it in the --questions-file body or pass --repository")
    else:
        if not repository:
            raise click.UsageError("--repository is required (unless --questions-file names it)")
        if bool(package) == bool(file_path):
            raise click.UsageError("ask one question: --package (with --ecosystem) or --file")
        if package and not ecosystem:
            raise click.UsageError("--package needs --ecosystem")
        if function and not file_path:
            raise click.UsageError("--function needs --file")
        if subject == "image" and not image_digest:
            raise click.UsageError("--subject image needs --image-digest")
        q = {"id": "q1", "kind": "package" if package else "code", "subject": subject}
        q.update({k: v for k, v in (("ecosystem", ecosystem), ("package", package), ("file", file_path),
                                    ("function", function), ("image_digest", image_digest),
                                    ("scanned_commit", commit)) if v})
        body = {"repository": repository, "questions": [q]}
    data = _call(_client(ctx).post, "atlas/reachability", json=body, params=_params(tenant=tenant))
    if fmt != "text" or not isinstance(data, dict):
        output(data, fmt=fmt)
        return
    click.echo(render_reachability(data))
