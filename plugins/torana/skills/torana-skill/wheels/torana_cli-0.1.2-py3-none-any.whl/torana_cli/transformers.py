"""torana transformers — data transformer management commands."""

import sys

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.datalake import datalake_transformers
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm

_TEMPLATE_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 40),
    ("category", "CATEGORY", 20),
    ("description", "DESCRIPTION", 50),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@datalake_transformers.command(name="create")
@click.option("--name", default=None)
@click.option("--sql-template", default=None, help="SQL template name.")
@click.option("--destination-table", default=None, help="Destination table name.")
@click.option("--schedule", default=None,
              help="Cron schedule expression. Creates a scheduler task bound to this "
                   "transformer (scheduling lives in the workflow service, not on the "
                   "transformer itself).")
@click.option("--unique-key", "unique_key", default=None, help="Natural row key (comma-separated columns) for incremental materialization. Usually only meaningful for custom-SQL row-projections (set those via --file). Backend auto-infers when omitted.")
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def transformers_create(ctx, name, sql_template, destination_table, schedule, unique_key, input_file):
    """Create a new transformer."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if sql_template:
        body["sql_template"] = sql_template
    if destination_table:
        body["destination_table"] = destination_table
    if unique_key:
        body["unique_key"] = [c.strip() for c in unique_key.split(",") if c.strip()]

    if not body.get("name"):
        click.echo("ERROR: --name is required (or provide --file with 'name' field).", err=True)
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post("transformers/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # `schedule` is not a field on the transformer API or model — sending it in the
    # create body was silently dropped, so the caller got a success and no schedule.
    # Scheduling actually lives in a workflow-service task row, so create one.
    transformer_id = data.get("id") if isinstance(data, dict) else None
    scheduled = None
    if schedule and transformer_id:
        task = {
            "name": f"sched_{data.get('name') or transformer_id}",
            "task_type": "transformer",
            "task_name": data.get("destination_table") or data.get("name"),
            "transformer_id": transformer_id,
            "schedule_type": "cron",
            "schedule_expression": schedule,
            # Defaults to disabled server-side; an inert scheduler would recreate
            # the very trap this fixes — a transformer that looks scheduled and
            # never runs. Every build-deposited scheduler on a working app is enabled.
            "is_enabled": True,
        }
        if data.get("workspace_id"):
            task["workspace_id"] = data["workspace_id"]
        try:
            sched_row = client.post("scheduler/tasks", json=task)
            scheduled = sched_row.get("id") if isinstance(sched_row, dict) else None
        except (APIError, AuthError) as e:
            click.echo(
                f"Created transformer: {transformer_id}\n"
                f"WARNING: --schedule was NOT applied — creating the scheduler task "
                f"failed: {e}\n"
                f"         the transformer exists but will never run on its own.\n"
                f"         retry with: torana schedulers create --file <task.json>",
                err=True)
            sys.exit(1)

    if fmt != "text":
        if scheduled:
            data = dict(data, scheduler_id=scheduled)
        output(data, fmt=fmt)
    else:
        click.echo(f"Created transformer: {data.get('id', 'unknown')}")
        click.echo(f"  Name: {data.get('name', '')}")
        if scheduled:
            click.echo(f"  Schedule: {schedule} (scheduler {scheduled})")


# ---------------------------------------------------------------------------
# sql-templates sub-group
# ---------------------------------------------------------------------------

@click.group(name="sql-templates")
def sql_templates():
    """Manage SQL transformer templates.

    \b
    Examples:
      torana sql-templates list
      torana sql-templates search mttr
      torana sql-templates preview <UUID> --params '{"severity": "high"}'
    """


@sql_templates.command(name="list")
@click.option("--category", default=None, help="Filter by category.")
@click.option("--search", default=None, help="Search by name.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.pass_context
def sql_templates_list(ctx, category, search, page, page_size):
    """List SQL templates."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}
    if category:
        params["category"] = category
    if search:
        params["search"] = search

    client = _client(ctx)
    try:
        data = client.get("sql-templates/", params=params)
        result = data if isinstance(data, dict) and "items" in data else {
            "items": data if isinstance(data, list) else [],
            "total": len(data) if isinstance(data, list) else 0,
            "page": page, "page_size": effective_page_size
        }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_TEMPLATE_COLS)


@sql_templates.command(name="get")
@click.argument("template_id", metavar="TEMPLATE_ID")
@click.pass_context
def sql_templates_get(ctx, template_id):
    """Get a specific SQL template."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"sql-templates/{template_id}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@sql_templates.command(name="search")
@click.argument("query", metavar="QUERY")
@click.pass_context
def sql_templates_search(ctx, query):
    """Search SQL templates by name or content."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("sql-templates/", params={"search": query, "limit": 100})
        result = data if isinstance(data, dict) and "items" in data else {
            "items": data if isinstance(data, list) else [],
            "total": len(data) if isinstance(data, list) else 0,
        }
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, fields=fields, columns=_TEMPLATE_COLS)


@sql_templates.command(name="preview")
@click.argument("template_id", metavar="TEMPLATE_ID")
@click.option("--params", "params_data", default=None, metavar="JSON",
              help="JSON parameters for the template.")
@click.pass_context
def sql_templates_preview(ctx, template_id, params_data):
    """Preview rendered SQL for a template with given parameters.

    \b
    Example:
      torana sql-templates preview <UUID> --params '{"severity": "high"}'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if params_data:
        import json
        try:
            body = json.loads(params_data)
        except json.JSONDecodeError as exc:
            click.echo(f"ERROR: Invalid JSON in --params: {exc}", err=True)
            sys.exit(6)

    client = _client(ctx)
    try:
        data = client.post(f"sql-templates/{template_id}/preview/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        if isinstance(data, dict):
            sql = data.get("sql") or data.get("query") or data.get("rendered_sql")
            if sql:
                click.echo(sql)
            else:
                import json
                click.echo(json.dumps(data, indent=2, default=str))
        else:
            click.echo(str(data))


@sql_templates.command(name="validate")
@click.argument("template_id", metavar="TEMPLATE_ID")
@click.pass_context
def sql_templates_validate(ctx, template_id):
    """Validate a SQL template."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    client = _client(ctx)
    try:
        data = client.post(f"sql-templates/{template_id}/validate/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        if isinstance(data, dict):
            valid = data.get("valid", data.get("status", "unknown"))
            click.echo(f"Template {template_id}: {valid}")
        else:
            click.echo(str(data))


# ──────────────────────────────────────────────────────────────────────────
# Instance reads regrouped from `<noun>-by-<param>` leaves onto verbs
# (CLI Discoverability Contract, rule 2 — see ../CLAUDE.md). The route
# parameter belongs in the positional ARGUMENT, not the command name.
#
# Old flat names remain as HIDDEN aliases for ONE release (D4).
# ──────────────────────────────────────────────────────────────────────────


@datalake_transformers.group(name="tenant-cleanup")
def datalake_transformers_tenant_cleanup_grp():
    """Internal per-tenant cleanup (SA).

    Examples:
      torana datalake transformers tenant-cleanup run --help
    """


@datalake_transformers_tenant_cleanup_grp.command(name="run")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.argument("TENANT_ID", metavar="TENANT_ID")
@click.option("--dry-run", "dry_run", type=bool, default=False)
@click.pass_context
def internal_tenant_by_tenant_id(ctx, tenant_id, dry_run, yes):
    """Cleanup Tenant Data."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = f"internal/cleanup/tenant/{tenant_id}"
    params = {}
    if dry_run is not None:
        params["dry_run"] = dry_run

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@datalake_transformers.command(name="orphaned")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.option("--dry-run", "dry_run", type=bool, default=False, help="If True, report orphaned objects without deleting them")
@click.pass_context
def internal_orphaned(ctx, dry_run, yes):
    """Cleanup Orphaned Objects."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    path = "internal/cleanup/orphaned"
    params = {}
    if dry_run is not None:
        params["dry_run"] = dry_run

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@datalake_transformers.command(name="create-and-execute")
@click.option("--file", "input_file", default=None, metavar="FILE", help="JSON/YAML file with request body. Use '-' for stdin.")
@click.option("--sync", "sync", type=bool, default=False, help="Execute synchronously and return final status instead of running in background")
@click.option("--workspace-id", "workspace_id", required=True, help="Workspace ID")
@click.option("--name", "name", required=True, help="Unique transformer name")
@click.option("--description", "description", default=None, help="Transformer description")
@click.option("--semantic-description", "semantic_description", default=None, help="Semantic description used for AI-powered search and discovery")
@click.option("--template-id", "template_id", default=None, help="Template UUID if using template (recommended)")
@click.option("--sql-template", "sql_template", default=None, help="Template name if using template (deprecated - use template_id)")
@click.option("--custom-sql", "custom_sql", default=None, help="Custom SQL if not using template")
@click.option("--materialized", "materialized", type=bool, default=True, help="Whether to materialize as table")
@click.option("--destination-table", "destination_table", required=True, help="Output table name")
@click.option("--source-tables", "source_tables", default=None, help="Source table names")
@click.option("--parameters", "parameters", default=None, help="Template parameters")
@click.option("--backend", "backend", default="auto", help="Backend type: snowflake, duckdb, or auto")
@click.option("--created-by", "created_by", default=None, help="Creator identifier (auto-set from auth token)")
@click.option("--tags", "tags", default=None, help="Tags for categorization and filtering")
@click.option("--unique-key", "unique_key", default=None, help="Natural row key (comma-separated columns) for a single-row-per-entity projection. When set, the output materializes incrementally (merge on this key) with maintained created_at/updated_at so detection rules can watermark it. Omit for aggregates/metrics — the backend auto-infers an unambiguous id column when possible.")
@click.pass_context
def transformers_create_and_execute(ctx, sync, workspace_id, name, description, semantic_description, template_id, sql_template, custom_sql, materialized, destination_table, source_tables, parameters, backend, created_by, tags, unique_key, input_file):
    """Create and Execute Transformer."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "transformers/create-and-execute"
    params = {}
    if sync is not None:
        params["sync"] = sync
    if input_file:
        body = _load_input_file(input_file)
    else:
        body = {}
        body["workspace_id"] = workspace_id
        body["name"] = name
        if description is not None:
            body["description"] = description
        if semantic_description is not None:
            body["semantic_description"] = semantic_description
        if template_id is not None:
            body["template_id"] = template_id
        if sql_template is not None:
            body["sql_template"] = sql_template
        if custom_sql is not None:
            body["custom_sql"] = custom_sql
        if materialized is not None:
            body["materialized"] = materialized
        body["destination_table"] = destination_table
        if source_tables is not None:
            body["source_tables"] = source_tables
        if parameters is not None:
            body["parameters"] = parameters
        if backend is not None:
            body["backend"] = backend
        if created_by is not None:
            body["created_by"] = created_by
        if tags is not None:
            body["tags"] = tags
        if unique_key is not None:
            # API expects List[str]; accept comma-separated columns (single-column key
            # is the common case). Empty entries trimmed.
            body["unique_key"] = [c.strip() for c in unique_key.split(",") if c.strip()]

    client = _client(ctx)
    try:
        data = client.post(path, json=body, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ---------------------------------------------------------------------------
# transformer-executions — cross-transformer execution history
# ---------------------------------------------------------------------------

@click.group(name="transformer-executions")
def transformer_executions():
    """Transformer execution history, across all transformers.

    \b
    ⚠️ There is no top-level `transformers` group. The pieces are:
      torana transformer-executions   run history (this group)
      torana transformer-tables       the OUTPUT tables and their data
      torana datalake transformers    manage transformers in the datalake
      torana vm transformers catalog  the reviewed VM catalog

    \b
    Examples:
      torana transformer-executions list
      torana transformer-executions list --json | jq '.items[] | {name, status, finished_at}'
    """


@transformer_executions.command(name="list")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", "page_size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.pass_context
def transformer_executions_list(ctx, page, page_size, fetch_all):
    """List all transformer executions."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "transformer-executions"
    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"skip": (page - 1) * effective_page_size, "limit": effective_page_size}

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


# ──────────────────────────────────────────────────────────────────────────
# BACK-COMPAT — hidden aliases for the old `<noun>-by-<param>` names.
# ⏳ ONE RELEASE ONLY (decision D4). Delete this block next release.
# ──────────────────────────────────────────────────────────────────────────

_LEGACY_BY_PARAM_DATALAKE_TRANSFORMERS = {
    "tenant-by-tenant-id": ("tenant-cleanup", "run"),
}


def _register_legacy_datalake_transformers_by_param() -> None:
    """Old flat names, hidden so they cannot be discovered anew."""
    import copy
    for _old, (_sub, _verb) in _LEGACY_BY_PARAM_DATALAKE_TRANSFORMERS.items():
        _grp = datalake_transformers.commands.get(_sub)
        if not isinstance(_grp, click.Group):
            continue
        _cmd = _grp.commands.get(_verb)
        if _cmd is None:
            continue
        # ⛔ Never let an alias overwrite a real group of the same name.
        if isinstance(datalake_transformers.commands.get(_old), click.Group):
            continue
        _alias = copy.copy(_cmd)
        _alias.name = _old
        _alias.hidden = True
        datalake_transformers.add_command(_alias)


_register_legacy_datalake_transformers_by_param()
