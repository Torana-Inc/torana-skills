"""torana chat <CHAT_ID> — send to, read, answer, stop, steer and rename one chat."""

import json
import sys
import time

import click

from torana_cli import chat_core
from torana_cli.chats import _client, read_message, run_turn, wait_options
from torana_cli.client.auth import AuthError
from torana_cli.client.base import (
    APIError,
    EXIT_USAGE,
    handle_api_error,
    handle_auth_error,
)
from torana_cli.main import CTX_FORMAT
from torana_cli.output import output

_STATE_LINES = {
    "running": "A turn is running.",
    "waiting": "Waiting on your answer.",
    "idle": "Idle: nothing is running and nothing is being asked.",
    "completed": "Idle: the last turn finished.",
    "failed": "The last turn failed.",
    "timeout": "The last turn timed out on the server.",
    "cancelled": "The last turn was cancelled.",
}


def _sid(ctx) -> str:
    return ctx.obj.get("_chat_id", "") if ctx.obj else ""


def _fmt(ctx) -> str:
    return ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"


def agent_option(fn):
    return click.option("--agent", "agent_id", default=None, metavar="AGENT_ID",
                        help="The chat's agent. Only needed when the chat id does not "
                             "start with 'agent_<AGENT_ID>_'.")(fn)


def _usage(message: str) -> None:
    click.echo(f"\nERROR: {message}", err=True)
    sys.exit(EXIT_USAGE)


@click.group(name="chat", invoke_without_command=True)
@click.argument("chat_id", metavar="CHAT_ID")
@click.pass_context
def chat(ctx, chat_id):
    """Work with one chat: send a message, read it, answer its question, stop it.

    CHAT_ID comes from `torana chats list` or `torana chats start` (JSON key
    `chat_id`; the API calls the same value `session_id`).

    \b
    Start here
      torana chat <CHAT_ID> send -m "your question"     send, and wait for the reply
      torana chat <CHAT_ID> status                      running, waiting on you, or idle
      torana chat <CHAT_ID> answer --option 1           answer the question it asked
      torana chat <CHAT_ID> history --last 3            read the last turns
      torana chat <CHAT_ID> stop                        stop the running turn

    \b
    Exit codes (send, answer)
      0  the assistant replied          7  it is waiting on your answer
      8  the run failed, timed out or was cancelled
      9  a turn is already running (only with --no-wait)

    \b
    Start a new chat or list chats:
      torana chats --help
    """
    ctx.ensure_object(dict)
    ctx.obj["_chat_id"] = chat_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


# ── send ─────────────────────────────────────────────────────────────────────

@chat.command(name="send")
@click.option("--message", "-m", default=None, help="The message to send.")
@click.option("--message-file", default=None, metavar="FILE",
              help="Read the message from a file ('-' for stdin).")
@agent_option
@wait_options
@click.pass_context
def chat_send(ctx, message, message_file, agent_id, stream, no_wait, timeout):
    """Send a message and wait for the assistant's reply.

    Prints the reply (JSON: `reply`, `status`, `tool_steps`, `pending_question`).
    If the assistant is already waiting on an answer from you, nothing is sent and
    the question is shown (exit 7): use `answer` for that, because any message
    would be taken as the answer. If a turn is already running, the command waits
    for it to end and then sends; with --no-wait it exits 9 instead.

    \b
    Examples:
      torana chat <CHAT_ID> send -m "Which of those are internet-facing?"
      torana chat <CHAT_ID> send -m "…" --json | jq -r .reply
      torana chat <CHAT_ID> send -m "…" --stream
      torana chat <CHAT_ID> send --message-file question.txt --timeout 600
      torana chat <CHAT_ID> send -m "…" --no-wait

    \b
    Exit codes: 0 replied · 7 waiting on your answer · 8 failed, timed out or
    cancelled (also when --timeout passes; the turn keeps running) · 9 busy.

    \b
    Related:
      torana chat <CHAT_ID> answer      answer a question the assistant asked
      torana chat <CHAT_ID> status      see what the chat is doing
    """
    text = read_message(message, message_file)
    if not text:
        raise click.UsageError("Give the message with -m \"…\" or --message-file FILE.")
    client = _client(ctx)
    run_turn(ctx, _fmt(ctx), stream=stream, no_wait=no_wait, call=lambda printer: chat_core.send_and_wait(
        client, session_id=_sid(ctx), agent_id=agent_id, message=text,
        wait=not no_wait, timeout=timeout, on_event=printer))


# ── history ──────────────────────────────────────────────────────────────────

@chat.command(name="history")
@click.option("--last", default=None, type=int, metavar="N",
              help="Show only the last N turns (default: all).")
@click.option("--detail", is_flag=True, default=False,
              help="Show per-turn timing and model details where the server has them.")
@agent_option
@click.pass_context
def chat_history(ctx, last, detail, agent_id):
    """Show the conversation: what you asked, what the assistant said and showed.

    Each turn lists your message, the assistant's text and the charts, tables and
    questions it displayed. If the assistant is waiting on you, the question and
    its numbered options are shown last (JSON: `pending_question`, `state`).

    \b
    Examples:
      torana chat <CHAT_ID> history
      torana chat <CHAT_ID> history --last 3
      torana chat <CHAT_ID> history --json | jq '.turns[-1]'

    \b
    Related:
      torana chat <CHAT_ID> status      only what the chat is doing now
    """
    sid = _sid(ctx)
    fmt = _fmt(ctx)
    client = _client(ctx)
    try:
        aid = chat_core.require_agent_id(sid, agent_id)
        hist = client.get(f"agents/{aid}/sessions/{sid}/history")
        state = chat_core.read_state(client, agent_id=aid, session_id=sid)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    flat = []
    for turn in hist.get("conversation", []):
        for msg in turn.get("messages", []):
            flat.append({
                "role": turn.get("role", ""),
                "message_type": msg.get("type", ""),
                "content": msg.get("content", ""),
                "timestamp": msg.get("timestamp") or turn.get("timestamp", ""),
                "turn_id": turn.get("turn_id", ""),
                "otel_trace_id": turn.get("turn_id", ""),
            })
    # The open question is drawn from the typed read below, never guessed from the events,
    # so the parser is told nothing is pending.
    parsed = chat_core._parse_session_messages({
        "messages": flat, "trace_summary": [], "pending_checkpoint_id": None,
        "session_status": state["state"], "agent_id": aid, "session_id": sid,
    })
    if fmt in ("json", "yaml"):
        result = chat_core._build_chat_get_json(parsed, detail=detail, last=last)
        result.pop("hitl_pending", None)
        result.update({"chat_id": sid, "state": state["state"],
                       "pending_question": state.get("pending")})
        output(result, fmt=fmt)
        return
    chat_core._print_chat_get_text(parsed, detail=detail, last=last)
    if state.get("pending"):
        chat_core.print_pending_question(state["pending"], sid, err=False)


# ── status ───────────────────────────────────────────────────────────────────

@chat.command(name="status")
@agent_option
@click.pass_context
def chat_status(ctx, agent_id):
    """Show what the chat is doing now: running, waiting on you, or idle.

    When the assistant asked a question, prints it with its numbered options and
    the command that answers it. JSON: `state` (running | waiting | idle |
    completed | failed | timeout | cancelled), `pending` (the question, or null),
    `turn_id`, `lock_status`. Always exits 0.

    \b
    Examples:
      torana chat <CHAT_ID> status
      torana chat <CHAT_ID> status --json | jq '{state, question: .pending.prompt}'

    \b
    Related:
      torana chat <CHAT_ID> history     the whole conversation
      torana chats list --app-id <APP_ID> --waiting
    """
    sid = _sid(ctx)
    fmt = _fmt(ctx)
    client = _client(ctx)
    try:
        aid = chat_core.require_agent_id(sid, agent_id)
        state = chat_core.read_state(client, agent_id=aid, session_id=sid)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    state["chat_id"] = sid
    if fmt != "text":
        output(state, fmt=fmt)
        return
    line = _STATE_LINES.get(state["state"], state["state"])
    if state["state"] == "running" and state.get("turn_id"):
        line += f" (turn {state['turn_id']})"
    click.echo(line)
    if state.get("pending"):
        chat_core.print_pending_question(state["pending"], sid, err=False)


# ── answer ───────────────────────────────────────────────────────────────────

def _match_option(question: dict, key: str) -> dict:
    options = question.get("options") or []
    for opt in options:
        if str(opt.get("key")) == key:
            return opt
    for opt in options:
        if str(opt.get("label")) == key:
            return opt
    valid = ", ".join(f"{o.get('key')} ({o.get('label')})" for o in options) or "none"
    _usage(f"'{key}' is not one of this question's options. Options: {valid}.")


@chat.command(name="answer")
@click.option("--option", "options", multiple=True, metavar="KEY",
              help="Pick an option by its number (or exact label). Repeat it only when the "
                   "question allows several.")
@click.option("--text", "text", default=None, help="Answer in your own words.")
@click.option("--values", "values", default=None, metavar="JSON",
              help="Fill in a form: a JSON object of field name to value.")
@click.option("--approve", is_flag=True, default=False, help="Say yes to a confirmation.")
@click.option("--reject", is_flag=True, default=False, help="Say no to a confirmation.")
@click.option("--reason", default=None, help="With --reject: why.")
@agent_option
@wait_options
@click.pass_context
def chat_answer(ctx, options, text, values, approve, reject, reason, agent_id,
                stream, no_wait, timeout):
    """Answer the question the assistant is waiting on, then wait for it to continue.

    Run `torana chat <CHAT_ID> status` first to read the question and its options.
    Give exactly one kind of answer: --option for a numbered choice, --text for
    your own words, --values for a form, --approve or --reject for a confirmation.
    The question and your answer are printed, then the command behaves like
    `send`. Exits 2 when the chat is not waiting on a question.

    \b
    Examples:
      torana chat <CHAT_ID> answer --option 2
      torana chat <CHAT_ID> answer --text "Only the production repositories"
      torana chat <CHAT_ID> answer --values '{"owner": "alice", "due_date": "2026-11-01"}'
      torana chat <CHAT_ID> answer --approve
      torana chat <CHAT_ID> answer --reject --reason "Wrong dashboard"

    \b
    Exit codes: 0 the assistant continued and replied · 7 it asked another
    question · 8 failed, timed out or cancelled · 2 nothing to answer, or the
    answer does not fit the question.

    \b
    Related:
      torana chat <CHAT_ID> status                      read the question
      torana chats list --app-id <APP_ID> --waiting     every chat waiting on you
    """
    sid = _sid(ctx)
    fmt = _fmt(ctx)
    kinds = [bool(options), text is not None, values is not None, approve, reject]
    if sum(kinds) != 1:
        raise click.UsageError("Give exactly one answer: --option, --text, --values, "
                               "--approve or --reject.")
    if reason and not reject:
        raise click.UsageError("--reason goes with --reject.")

    client = _client(ctx)
    try:
        aid = chat_core.require_agent_id(sid, agent_id)
        state = chat_core.read_state(client, agent_id=aid, session_id=sid)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    question = state.get("pending")
    if not question:
        _usage("This chat is not waiting on a question. "
               f"(`torana chat {sid} status` shows what it is doing.)")

    option_keys = [str(o.get("key")) for o in question.get("options") or []]
    is_confirmation = option_keys == ["approve", "reject"]
    decision = None            # True / False for an explicit approve / reject
    message = None
    hitl = {"checkpoint_id": question["checkpoint_id"], "tool_call_id": question["tool_call_id"]}

    if options:
        if not option_keys:
            _usage("This question has no options. Answer with --text or --values.")
        picked = [_match_option(question, str(k)) for k in options]
        if len(picked) > 1 and not question.get("allow_multiple"):
            _usage("This question takes one option.")
        if is_confirmation:
            decision = str(picked[0]["key"]) == "approve"
        else:
            message = ", ".join(str(p["value"]) for p in picked)
            hitl["selected"] = message
    elif text is not None:
        if is_confirmation or question.get("fields"):
            _usage("This question does not take free text. "
                   + ("Use --approve or --reject." if is_confirmation else "Use --values."))
        if option_keys and not question.get("allow_free_text"):
            _usage("This question takes one of its options only: --option "
                   + " | ".join(option_keys) + ".")
        message = text
        hitl["selected"] = "__custom__"
    elif values is not None:
        fields = question.get("fields") or []
        if not fields:
            _usage("This question is not a form. Answer with --option or --text.")
        try:
            parsed = json.loads(values)
        except json.JSONDecodeError as exc:
            _usage(f"--values must be a JSON object: {exc}")
        if not isinstance(parsed, dict):
            _usage("--values must be a JSON object of field name to value.")
        names = [f.get("name") for f in fields]
        unknown = [k for k in parsed if k not in names]
        if unknown:
            _usage(f"Unknown field(s): {', '.join(unknown)}. Fields: {', '.join(names)}.")
        missing = [f.get("name") for f in fields
                   if f.get("required") and parsed.get(f.get("name")) in (None, "")]
        if missing:
            _usage(f"Missing required field(s): {', '.join(missing)}.")
        message = "; ".join(f"{k}: {v}" for k, v in parsed.items())
        hitl["values"] = parsed
    else:
        if not is_confirmation:
            _usage("This question is not a yes/no confirmation. Answer with "
                   + ("--values." if question.get("fields") else "--option or --text."))
        decision = approve

    if fmt == "text":
        chat_core.print_pending_question(question, sid)
        shown = message if message is not None else ("approve" if decision else "reject")
        click.echo(f"  Your answer: {shown}\n", err=True)

    if decision is None:
        run_turn(ctx, fmt, stream=stream, no_wait=no_wait, call=lambda printer: chat_core.send_and_wait(
            client, session_id=sid, agent_id=aid, message=message, answer=hitl,
            wait=not no_wait, timeout=timeout, on_event=printer))
        return

    # A confirmation carries an explicit decision, which only this route accepts.
    def _decide(printer):
        body = {"checkpoint_id": question["checkpoint_id"], "approved": decision}
        if reason:
            body["reason"] = reason
        resp = client.post(f"agents/{aid}/sessions/{sid}/hitl-checkpoint-response", json=body)
        turn_id = (resp or {}).get("turn_id")
        if not turn_id:
            return chat_core.TurnResult(session_id=sid, agent_id=aid, turn_id=None,
                                        status="completed",
                                        reply=None if decision else "Rejected. Nothing was run.")
        if no_wait:
            return chat_core.TurnResult(session_id=sid, agent_id=aid, turn_id=turn_id,
                                        status="sent")
        return chat_core.follow_turn(client, agent_id=aid, session_id=sid, turn_id=turn_id,
                                     timeout=timeout, on_event=printer)

    run_turn(ctx, fmt, stream=stream, no_wait=no_wait, call=_decide)


# ── stop / steer / rename ────────────────────────────────────────────────────

@chat.command(name="stop")
@agent_option
@click.pass_context
def chat_stop(ctx, agent_id):
    """Stop the turn that is running in this chat.

    Nothing new is started. If nothing is running the command says so and exits 0
    without doing anything. Prints the chat's state afterwards (JSON: `stopped`,
    `state`).

    \b
    Examples:
      torana chat <CHAT_ID> stop
      torana chat <CHAT_ID> stop --json

    \b
    Related:
      torana chat <CHAT_ID> steer -m "…"    redirect the running turn instead
      torana chat <CHAT_ID> status
    """
    sid = _sid(ctx)
    fmt = _fmt(ctx)
    client = _client(ctx)
    try:
        aid = chat_core.require_agent_id(sid, agent_id)
        state = chat_core.read_state(client, agent_id=aid, session_id=sid)
        stopped = False
        if state.get("lock_status") == "processing":
            client.post(f"agents/{aid}/stop", json={"session_id": sid})
            stopped = True
            deadline = time.monotonic() + 30
            while time.monotonic() < deadline:
                time.sleep(2)
                state = chat_core.read_state(client, agent_id=aid, session_id=sid)
                if state.get("lock_status") != "processing":
                    break
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt != "text":
        output({"chat_id": sid, "stopped": stopped, "state": state["state"],
                "turn_id": state.get("turn_id")}, fmt=fmt)
        return
    if not stopped:
        click.echo("Nothing is running in this chat.")
    elif state["state"] == "running":
        click.echo("Stop requested; the turn has not ended yet. "
                   f"Check with `torana chat {sid} status`.")
    else:
        click.echo(f"Stopped. {_STATE_LINES.get(state['state'], state['state'])}")


@chat.command(name="steer")
@click.option("--message", "-m", required=True, help="What the assistant should do instead.")
@agent_option
@click.pass_context
def chat_steer(ctx, message, agent_id):
    """Redirect the turn that is running, without waiting for it to finish.

    Use it when the assistant is working on the wrong thing. Only works while a
    turn is running; otherwise it exits 2 and you should use `send`.

    \b
    Examples:
      torana chat <CHAT_ID> steer -m "Only consider the production repositories"

    \b
    Related:
      torana chat <CHAT_ID> stop        end the running turn
      torana chat <CHAT_ID> send        send a message when nothing is running
    """
    sid = _sid(ctx)
    fmt = _fmt(ctx)
    client = _client(ctx)
    try:
        aid = chat_core.require_agent_id(sid, agent_id)
        state = chat_core.read_state(client, agent_id=aid, session_id=sid)
        if state.get("lock_status") != "processing":
            _usage(f"Nothing is running to steer. Use `torana chat {sid} send -m \"…\"`.")
        data = client.post(f"agents/{aid}/steer", json={"session_id": sid, "message": message})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt != "text":
        output({"chat_id": sid, **(data if isinstance(data, dict) else {})}, fmt=fmt)
    else:
        click.echo("Steering sent; the running turn will take it up.")


@chat.command(name="rename")
@click.option("--title", required=True, help="The chat's new name.")
@agent_option
@click.pass_context
def chat_rename(ctx, title, agent_id):
    """Update the chat's name, as shown in the app's Chat list.

    \b
    Examples:
      torana chat <CHAT_ID> rename --title "Weekly remediation review"
    """
    sid = _sid(ctx)
    fmt = _fmt(ctx)
    client = _client(ctx)
    try:
        aid = chat_core.require_agent_id(sid, agent_id)
        data = client.patch(f"agents/{aid}/sessions/{sid}", json={"name": title})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt != "text":
        output({"chat_id": sid, **(data if isinstance(data, dict) else {})}, fmt=fmt)
    else:
        click.echo(f"Renamed chat {sid}: {title}")
