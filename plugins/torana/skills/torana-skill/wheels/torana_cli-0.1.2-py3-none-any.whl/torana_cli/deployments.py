"""torana deployments — collection ops for Deployment objects (EM Deployment_Object_and_
Runtime_Provenance.md § 3.5.1).

Collection-only per the CLI plural/singular rule: `create`, `list`, plus the cross-cutting
`test-connection` (pre-create, no id) and `exposure-intelligence` (cross-deployment output).
Instance verbs (get/update/delete/status/workloads/sync) live in the singular `deployment`
group (deployment.py).

A Deployment is a tenant-scoped governance object pointing at a live cluster
(GKE/EKS/AKS/raw-k8s); on create it provisions a bound Kubernetes-cluster integration that
reads the running workloads/services and their image provenance.
"""

import json

import click

# Sourced from the domain-property registry, never hardcoded here: a surface
# with its own copy of the vocabulary is how a tenant ends up storing a value
# the filters do not recognise.
#
# WHY THE FALLBACK IS EMPTY, NOT A COPY OF THE LIST
# -------------------------------------------------
# The obvious fallback — restating ["production","staging","development"] — is
# the drift this whole change removes. It looks harmless because it matches
# TODAY; it becomes wrong silently the moment a value is added to the registry,
# and the CLI would then reject a value the API accepts, with no signal that the
# two disagreed.
#
# Empty means "this CLI cannot enumerate the vocabulary", which Click renders as
# an unconstrained string. The value still gets validated — by the API's schema
# and the service layer, both of which read the registry. So a bare-environment
# CLI loses the local pre-check and the tab-completion, never the correctness.
# Degrading to "ask the server" beats degrading to "guess, confidently".
try:
    from pantheon_shared.domain_properties import allowed_values_for
    ENVIRONMENTS = list(allowed_values_for("env_label"))
except Exception:  # pragma: no cover - shared lib absent
    ENVIRONMENTS = []

from torana_cli.client.auth import AuthError
from torana_cli.client.base import (
    APIError,
    ToranaClient,
    handle_api_error,
    handle_auth_error,
)
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW, CollectionGroup
from torana_cli.output import output


DEPLOYMENT_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 16),
    ("cluster_host", "HOST", 8),          # gke|eks|aks|generic (the hosting cloud — a property)
    ("env_label", "ENV", 8),
    ("cluster_ref", "CLUSTER", 26),
    # api_server surfaces WHERE the cluster actually is — a user can tell a real endpoint from a
    # mock/replay one at a glance (a mock points at an internal host, not a real cloud API server).
    ("api_server", "API-SERVER", 40),
    ("internet_facing", "PUBLIC", 7),
    ("has_customer_data", "CUST-DATA", 10),
    ("criticality", "CRIT", 9),
    # Governance ownership: OWNER is the accountable person/handle, TEAM the org unit
    # that feeds assets.asset_team (Spec G) — distinct fields, both surfaced.
    ("owner", "OWNER", 12),
    ("team", "TEAM", 12),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    return ToranaClient(base_url=get_settings(profile).base_url)


def _ctx(ctx):
    return (
        ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text",
        ctx.obj.get(CTX_RAW, False) if ctx.obj else False,
        ctx.obj.get(CTX_FIELDS) if ctx.obj else None,
    )


def parse_json_opt(value, label):
    """Parse a --json-ish option; raise a clear BadParameter on bad JSON. Shared with the
    singular group (deployment.py imports this)."""
    if value is None:
        return None
    try:
        return json.loads(value)
    except (ValueError, TypeError) as exc:
        raise click.BadParameter(f"{label} must be valid JSON: {exc}")


# ─── parent group ─────────────────────────────────────────────────────────────

@click.group(name="deployments", cls=CollectionGroup, singular="deployment")
def deployments():
    """Manage deployments (cluster targets + governance + runtime provenance).

    \b
    Collection ops: create, list, test-connection, exposure-intelligence.
    Instance ops (get/update/delete/status/workloads/sync): `torana deployment <id> ...`.

    \b
    Examples:
      torana deployments create --name prod --cluster-host gke \\
        --cluster-ref my-proj/prod-cluster/us-central1 --env-label production \\
        --internet-facing --criticality high \\
        --auth '{"service_account_key":"...","project_id":"my-proj","location":"us-central1","gke_cluster_id":"prod-cluster"}'
      torana deployments list
      torana deployments test-connection --cluster-host gke --auth '{...}'
      torana deployment <id> status
    """


# ─── create ───────────────────────────────────────────────────────────────────

@deployments.command(name="create")
@click.option("--name", required=True, help="Deployment name (unique among live deployments).")
@click.option("--source-type", type=click.Choice(["cluster", "manifest"]), default="cluster",
              help="cluster = bound live k8s integration (observed); manifest = declared, "
                   "rendered manifests pushed via `entity-graph parse-manifests` (no cluster/creds).")
@click.option("--cluster-host", default=None,
              type=click.Choice(["gke", "eks", "aks", "generic"]),
              help="Cluster host: where it runs (gke|eks|aks|generic). One Kubernetes integration; "
                   "the host is a property. `generic` = self-hosted / any API-server + token.")
@click.option("--cluster-type", default=None, type=click.Choice(["gke", "eks", "aks", "k8s"]),
              help="Deprecated alias for --cluster-host.")
@click.option("--cluster-ref", default=None, help="project/cluster/region or endpoint (cluster only).")
@click.option("--env-label", required=True,
              # Constrained only when the registry could be read (see ENVIRONMENTS
              # above). click.Choice([]) would reject EVERY value, so an empty
              # vocabulary must fall through to an unconstrained string and let
              # the API do the validating.
              type=click.Choice(ENVIRONMENTS, case_sensitive=False) if ENVIRONMENTS else str,
              help="Deployment environment. Becomes part of the entity key "
                   "(service:<env>/<name>) and cannot be changed afterwards.")
@click.option("--description", default="", help="Semantic description of this deployment.")
@click.option("--internet-facing/--no-internet-facing", default=False, help="Governance: public?")
@click.option("--has-customer-data/--no-customer-data", default=False, help="Governance: customer data?")
@click.option("--criticality", default=None,
              type=click.Choice(["low", "medium", "high", "critical"]), help="Governance criticality.")
@click.option("--owner", default=None, help="Accountable owner (person/handle).")
@click.option("--team", default=None,
              help="Owning team (org unit) — feeds assets.asset_team.")
@click.option("--provenance-label-map", default=None,
              help='JSON per-field OCI label-key overrides, e.g. \'{"commit":["com.acme.git.sha"]}\'.')
@click.option("--auth", default=None, help="JSON provider cluster credentials/config (cluster only).")
@click.pass_context
def create(ctx, name, source_type, cluster_host, cluster_type, cluster_ref, env_label, description,
           internet_facing, has_customer_data, criticality, owner, team, provenance_label_map, auth):
    """Create a deployment.

    source_type=cluster provisions a bound cluster integration reading the live cluster.
    source_type=manifest is a declared deployment (no cluster, no credentials) — feed it
    rendered manifests with `torana entity-graph parse-manifests --deployment <id>`.
    """
    fmt, raw, fields = _ctx(ctx)
    body = {
        "name": name,
        "source_type": source_type,
        "env_label": env_label,
        "description": description,
        "internet_facing": internet_facing,
        "has_customer_data": has_customer_data,
        "criticality": criticality,
        "owner": owner,
        "team": team,
        "provenance_label_map": parse_json_opt(provenance_label_map, "--provenance-label-map"),
        "auth": parse_json_opt(auth, "--auth") or {},
    }
    # cluster identity only for cluster deployments; a manifest deployment has none.
    host = cluster_host or cluster_type   # --cluster-host preferred; --cluster-type is the alias
    if host:
        body["cluster_host"] = host
    if cluster_ref:
        body["cluster_ref"] = cluster_ref
    client = _client(ctx)
    try:
        data = client.post("deployments", json=body)
    except AuthError as e:
        handle_auth_error(e); return
    except APIError as e:
        handle_api_error(e); return
    output(data, fmt=fmt, raw=raw, fields=fields, columns=DEPLOYMENT_COLS)


# ─── list ─────────────────────────────────────────────────────────────────────

@deployments.command(name="list")
@click.option("--limit", default=100, type=int, help="Max rows (<=100).")
@click.option("--offset", default=0, type=int, help="Pagination offset.")
@click.pass_context
def list_deployments(ctx, limit, offset):
    """List deployments."""
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.get("deployments", params={"limit": limit, "offset": offset})
    except AuthError as e:
        handle_auth_error(e); return
    except APIError as e:
        handle_api_error(e); return
    data = {"items": data.get("deployments", []), "total": data.get("count", 0),
            "page": 1, "page_size": limit}
    output(data, fmt=fmt, raw=raw, fields=fields, columns=DEPLOYMENT_COLS)


@deployments.command(name="discoverable-clusters")
@click.pass_context
def discoverable_clusters(ctx):
    """On-demand: GKE clusters already ingested via the GCP integration, for create autofill.

    Read-only, nothing persisted. Each row prefills a new deployment (cluster identity only,
    NOT governance/credentials) and is flagged `already_added` if a deployment already exists
    for that cluster.
    """
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.get("deployments/discoverable-clusters")
    except AuthError as e:
        handle_auth_error(e); return
    except APIError as e:
        handle_api_error(e); return
    data = {"items": data.get("clusters", []), "total": data.get("count", 0),
            "page": 1, "page_size": len(data.get("clusters", []))}
    output(data, fmt=fmt, raw=raw, fields=fields, columns=[
        ("cluster_name", "CLUSTER", 24), ("cluster_ref", "REF", 36),
        ("control_plane_public", "CP-PUBLIC", 10), ("already_added", "ADDED", 6),
    ])


# ─── test-connection (collection-level: pre-create, no id) ─────────────────────

@deployments.command(name="test-connection")
@click.option("--cluster-host", default=None,
              type=click.Choice(["gke", "eks", "aks", "generic"]), help="Cluster host.")
@click.option("--cluster-type", default=None, type=click.Choice(["gke", "eks", "aks", "k8s"]),
              help="Deprecated alias for --cluster-host.")
@click.option("--auth", default=None, help="JSON provider cluster credentials/config.")
@click.pass_context
def test_connection(ctx, cluster_host, cluster_type, auth):
    """Test a cluster connection without persisting anything (pre-create check)."""
    fmt, raw, fields = _ctx(ctx)
    body = {"cluster_host": cluster_host or cluster_type or "generic",
            "auth": parse_json_opt(auth, "--auth") or {}}
    client = _client(ctx)
    try:
        data = client.post("deployments/test-connection", json=body)
    except AuthError as e:
        handle_auth_error(e); return
    except APIError as e:
        handle_api_error(e); return
    output(data, fmt=fmt, raw=raw, fields=fields)


# ─── sync (instance: re-run the deployment's cluster sync) ─────────────────────

@deployments.command(name="sync")
@click.argument("deployment_id", metavar="DEPLOYMENT_ID")
@click.pass_context
def sync(ctx, deployment_id):
    """Trigger an on-demand sync of DEPLOYMENT_ID's cluster (workloads + services/ingresses).

    Re-runs the k8s extractors against the live cluster, refreshing service:/image: nodes,
    deployed_as/exposed_via edges, and per-service governance (e.g. public_access) on the
    existing asset rows. Use after changing a deployment's governance or the cluster's topology.
    """
    fmt, raw, fields = _ctx(ctx)
    client = _client(ctx)
    try:
        data = client.post(f"deployments/{deployment_id}/sync", json={})
    except AuthError as e:
        handle_auth_error(e); return
    except APIError as e:
        handle_api_error(e); return
    output(data, fmt=fmt, raw=raw, fields=fields)


# ─── exposure-intelligence (cross-deployment output) ───────────────────────────

@deployments.command(name="exposure-intelligence")
@click.option("--severity", default=None,
              help="Comma-separated severities to surface, e.g. 'critical,high' "
                   "(backend default: critical,high). Not repeatable — pass one list.")
@click.option("--require-exposed/--no-require-exposed", "require_exposed", default=None,
              help="Only network-exposed services (backend default: on).")
@click.option("--require-customer-data/--no-require-customer-data", "require_customer_data",
              default=None, help="Only services handling customer data (backend default: off).")
@click.option("--write-findings", is_flag=True, default=False,
              help="Persist policy findings (requires deployment:update — 403 otherwise).")
@click.option("--limit", default=None, type=click.IntRange(1, 500),
              help="Max ranked rows (1..500 — this endpoint allows up to 500, not the usual 100).")
@click.pass_context
def exposure_intelligence(ctx, severity, require_exposed, require_customer_data,
                          write_findings, limit):
    """"Where must I act" — ranked exposure intelligence across deployments (Phase 8).

    \b
    Examples:
      torana deployments exposure-intelligence --severity critical,high --require-exposed
      torana deployments exposure-intelligence --write-findings   # needs deployment:update
    """
    fmt, raw, fields = _ctx(ctx)
    params = {}
    if severity:
        params["severity"] = severity           # comma-list passed through verbatim
    if require_exposed is not None:
        params["require_exposed"] = "true" if require_exposed else "false"
    if require_customer_data is not None:
        params["require_customer_data"] = "true" if require_customer_data else "false"
    if write_findings:
        params["write_findings"] = "true"
    if limit is not None:
        params["limit"] = limit                 # already validated to 1..500 (not clamped)

    client = _client(ctx)
    try:
        data = client.get("deployments/exposure-intelligence", params=params)
    except AuthError as e:
        handle_auth_error(e); return
    except APIError as e:
        handle_api_error(e); return             # 403 (needs deployment:update) → clean error
    output(data, fmt=fmt, raw=raw, fields=fields)
