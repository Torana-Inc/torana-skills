"""torana remediations — PR-lifecycle remediation collection commands.

A `remediation` follows the life of the PR that fixes an alert and drives the
alert's status (opened → checks → review → merged → deployed → ...). Created by
the torana-alert-triage skill at PR time; advanced by the GitHub App webhook loop
(or manually via `torana remediation <id> set-state`).
"""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output


_REM_COLS = [
    ("id", "ID", 36),
    ("state", "STATE", 16),
    ("alert_id", "ALERT", 36),
    ("pr_url", "PR", 0),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group()
def remediations():
    """PR-lifecycle remediations (collection operations).

    \b
    Examples:
      torana remediations list --alert-id <UUID>
      torana remediations create --alert-id <UUID> --pr-url https://github.com/o/r/pull/1
    """


@remediations.command(name="list")
@click.option("--alert-id", default=None, help="Filter by alert id.")
@click.option("--vulnerability-id", default=None, help="Filter by datalake vulnerability id.")
@click.option("--repo", default=None, help="Filter by canonical repo key (with --pr-number).")
@click.option("--pr-number", type=int, default=None, help="Filter by PR number (with --repo).")
@click.pass_context
def remediations_list(ctx, alert_id, vulnerability_id, repo, pr_number):
    """List remediations (optionally filtered)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if alert_id:
        params["alert_id"] = alert_id
    if vulnerability_id:
        params["vulnerability_id"] = vulnerability_id
    if repo:
        params["repo"] = repo
    if pr_number is not None:
        params["pr_number"] = pr_number

    client = _client(ctx)
    try:
        data = client.get("remediations", params=params)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields, columns=_REM_COLS)


@remediations.command(name="create")
@click.option("--alert-id", required=True, help="Alert this PR remediates.")
@click.option("--pr-url", default=None, help="Pull request URL.")
@click.option("--pr-number", type=int, default=None, help="Pull request number.")
@click.option("--vulnerability-id", default=None, help="Datalake vulnerability id.")
@click.option("--repo", default=None, help="Canonical asset key, e.g. github.com/org/repo.")
@click.option("--branch", default=None, help="PR head branch.")
@click.option("--base-branch", default=None, help="PR base branch.")
@click.option("--head-sha", default=None, help="PR head commit sha.")
@click.option("--description", default=None, help="Semantic description of the remediation.")
@click.pass_context
def remediations_create(ctx, alert_id, pr_url, pr_number, vulnerability_id, repo,
                        branch, base_branch, head_sha, description):
    """Create a remediation linking a PR to an alert (flips the alert to
    pending_remediation)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = {"alert_id": alert_id}
    for key, value in dict(
        pr_url=pr_url, pr_number=pr_number, vulnerability_id=vulnerability_id,
        repo=repo, branch=branch, base_branch=base_branch, head_sha=head_sha,
        description=description,
    ).items():
        if value is not None:
            body[key] = value

    client = _client(ctx)
    try:
        data = client.post("remediations", json=body)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    output(data, fmt=fmt, raw=raw, fields=fields, columns=_REM_COLS)
