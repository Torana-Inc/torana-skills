"""A fix PR's CI as text (EM D-05A § 3.7.3): the platform's `FixPrCi` body, printed as the server worded it.

Used by `torana remediation <ID> ci get`, `torana remediation <ID> refresh` and `torana alert <ID> view --section
fix-pr-ci`, so the three print the same thing.

⛔ The words are the server's (`answer.words`), never re-derived here. Check names, step names and annotations were
written by the PR's code: the platform already stripped control characters, and they are printed as plain text only.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

import click

#: Belt and braces: never let a terminal escape through, even from an older server.
_CONTROL = re.compile(r"[\x00-\x08\x0b-\x1f\x7f-\x9f]")
_PASS = ("success", "neutral", "skipped")


def _clean(text: Any) -> str:
    return _CONTROL.sub("", str(text or ""))


def _failed(c: Dict[str, Any]) -> bool:
    if c.get("kind") == "status":
        return c.get("status") in ("failure", "error")
    return c.get("status") == "completed" and (c.get("conclusion") or "") not in _PASS


def _pending(c: Dict[str, Any]) -> bool:
    return (c.get("status") == "pending") if c.get("kind") == "status" else c.get("status") != "completed"


def attribution_line(c: Dict[str, Any]) -> Optional[str]:
    """EM D-05B § 3.6: `⟳ not caused by the fix: the runner killed the job … Next: …`. The glyph, word and sentence
    are the server's (`attribution.sentence`, written by the one words module), printed verbatim. None for a check
    with no attribution (a read stored before D-05B, or an older server)."""
    a = c.get("attribution") or {}
    sentence = _clean(a.get("sentence")).strip()
    if not a.get("verdict") or not sentence:
        return None
    word = _clean(a.get("word") or a.get("verdict"))
    glyph = _clean(a.get("glyph") or "?")
    return f"{glyph} {sentence}" if sentence.startswith(word) else f"{glyph} {word}: {sentence}"


#: EM D-23 S2: the attempt outcomes as a person reads them.
_ATTEMPT_WORDS = {"withheld": " (withheld)", "over_cost": " (over the cost cap)",
                  "error": " (the reviewer stopped without an answer)"}


def judgement_lines(c: Dict[str, Any]) -> List[str]:
    """EM D-23 S2 § 3.4.7: a check's judgement, ONCE (the attribution line keeps its own words). The label and the
    sentence are the server's. ⛔ `reason` is model or person text; a CI one was written after reading the PR's own
    CI log: printed as plain, cleaned text, never followed."""
    j = c.get("judgement")
    if not isinstance(j, dict) or not j.get("verdict"):
        return []
    label = _clean(j.get("label") or j.get("by_kind") or "a judgement")
    if j.get("verdict") == "cannot_tell":
        head = f"Judgement ({label}): could not tell{_ATTEMPT_WORDS.get(str(j.get('outcome')), '')}"
    else:
        head = _clean(j.get("sentence")).strip().rstrip(".") or f"Judgement ({label}): {_clean(j.get('word'))}"
    if j.get("by_kind") == "ci":
        head += " (written by a model that read the PR's CI log)"
    out = [head]
    reason = " ".join(_clean(j.get("reason")).split())
    if reason and j.get("verdict") != "cannot_tell":
        out.append(f"Why: {reason}")
    return out


def check_lines(ci: Dict[str, Any]) -> List[str]:
    """One line per failed or pending check (the server already orders failed first), with step, the platform's quote
    and run link; under a failed check, its attribution (verdict, evidence, next step)."""
    out = []
    for c in ci.get("checks") or []:
        if not (_failed(c) or _pending(c)):
            continue
        glyph = "✗ failed " if _failed(c) else "… running"
        line = f"{glyph}  {_clean(c.get('name'))}"
        if c.get("failed_step"):
            line += f" · step {_clean(c['failed_step'])}"
        # ⛔ The error the PLATFORM chose (`quote`), never re-chosen here (round 2, finding 9): the first annotation
        # was a warning ("Node.js 20 is deprecated") under API drift.
        quote = _clean(c.get("quote")).splitlines()
        if quote and quote[0].strip():
            line += f" · {quote[0].strip()}"
        if c.get("html_url"):
            line += f" → {c['html_url']}"
        out.append(line)
        att = attribution_line(c) if _failed(c) else None
        if att:
            out.append(f"    {att}")
        if _failed(c):
            out.extend(f"    {x}" for x in judgement_lines(c))
    return out


def changed_files_line(ci: Dict[str, Any]) -> Optional[str]:
    """EM D-23 S2: `Changed in this PR: 3 file(s): a, b, c` from the stored read's `changed_files.paths`."""
    cf = ci.get("changed_files") or {}
    paths = [_clean(p) for p in cf.get("paths") or [] if p]
    if not paths:
        return None
    more = ", …" if len(paths) > 5 or cf.get("truncated") else ""
    return f"Changed in this PR: {len(paths)} file(s): {', '.join(paths[:5])}{more}"


#: EM D-23 § 3.6: the flip state as a person reads it.
_FLIP_WORDS = {"due": "Torana will mark it ready", "claimed": "Torana is marking it ready",
               "done": "marked ready by Torana's GitHub App", "done_by_other": "a person marked it ready",
               "not_permitted": "Torana's App may not mark it ready here", "failed": "Torana's last try failed",
               "superseded": "a newer commit arrived; the next read decides"}


def ready_lines(ready: Optional[Dict[str, Any]]) -> List[str]:
    """EM D-23 § 3.6: `READY  <sentence>`, one line per blocker (or what a ready PR still lacks), and the flip.
    The words are the server's (`ready.sentence`, `blockers[].words`); None/empty before the first D-23 read."""
    if not ready or not ready.get("sentence"):
        return []
    sentence = _clean(ready["sentence"])
    # ⛔ The glyph is the server's `is_ready` (EM D-23 DL4 words fix), never outcome/flip: ✓ ready for review now,
    # ○ a draft. A server from before the fix sends no `is_ready`: then no glyph rather than a guess.
    is_ready = ready.get("is_ready")
    glyph = "✓ " if is_ready is True else ("○ " if is_ready is False else "")
    out = [f"READY  {glyph}{sentence}"]
    for b in ready.get("blockers") or []:
        words = _clean(b.get("words") or b.get("code"))
        if words.lower() not in sentence.lower():          # the sentence is "Draft: <first blocker>"
            out.append(f"  ✗ {words}")
    unmet = [_clean(u.get("words") or u.get("code")) for u in ready.get("unmet") or []]
    if unmet and ready.get("outcome") == "already_ready":
        out.append(f"  ○ Torana would still want: {'; '.join(unmet)}")
    flip = ready.get("flip") or {}
    state = flip.get("state") or "none"
    if state != "none":
        when = f" at {flip['at']}" if flip.get("at") else ""
        said = _FLIP_WORDS.get(state, state)
        if state in ("done", "done_by_other") and is_ready is False:
            said = "marked ready earlier; a person converted it back to draft"
        out.append(f"  flip: {state} ({said}){when}")
    if state == "not_permitted":
        cmd = f"gh pr ready {ready.get('pr_number') or ''}".strip()
        if cmd not in sentence:
            out.append(f"  Mark it ready yourself: {cmd}")
    return out


def print_fix_pr_ci(ci: Optional[Dict[str, Any]], indent: str = "") -> None:
    if not ci:
        click.echo(f"{indent}No fix PR.")
        return
    ans = ci.get("answer") or {}
    glyph = f"{ans['glyph']} " if ans.get("glyph") else ""
    click.echo(f"{indent}{glyph}{_clean(ans.get('words') or ans.get('state') or 'CI not read')}")
    for line in ready_lines(ci.get("ready")):
        click.echo(f"{indent}{line}")
    for line in check_lines(ci):
        click.echo(f"{indent}  {line}")
    for s in ci.get("pending_suites") or []:
        click.echo(f"{indent}  … running  workflow {_clean(s)}")
    changed = changed_files_line(ci)
    if changed:
        click.echo(f"{indent}  {changed}")
    base = ci.get("baseline") or {}
    if base.get("same_checks") or base.get("validate_main"):
        same = ", ".join(f"{_clean(x.get('key', '')).split(':', 1)[-1]} {x.get('conclusion')}"
                         for x in base.get("same_checks") or [])
        vm = base.get("validate_main") or {}
        parts = [p for p in (same, f"torana/validate-main {vm.get('state')}" if vm else "") if p]
        click.echo(f"{indent}  On the base commit {str(base.get('sha') or '')[:7]}: {'; '.join(parts)}")
    meta = [f"read {ci['checked_at']}" if ci.get("checked_at") else "never read",
            f"statuses {ci.get('statuses')}", f"steps {ci.get('steps')}"]
    if ci.get("pr_url"):
        meta.insert(0, ci["pr_url"])
    click.echo(f"{indent}  ({' · '.join(meta)})")
