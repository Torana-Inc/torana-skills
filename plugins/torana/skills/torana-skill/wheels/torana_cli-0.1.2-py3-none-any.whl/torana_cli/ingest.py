"""torana ingest — push-based scan ingestion.

Subcommands
-----------
  sarif <report.sarif>            POST a SARIF 2.1.0 document to /api/v1/ingest/sarif.
  trivy <report.json>             POST a native Trivy JSON report to /api/v1/ingest/trivy.
  assets <asset.json|yaml>        POST an asset-inventory doc to /api/v1/ingest/assets.
  receipts <scan_id>              Look up a previously-accepted scan's receipt.
  cve-feed <feed.json>            Bulk upsert into the CVE enrichment cache.

The canonical caller is the `torana-scan` skill (which emits SARIF) and the
`torana-asset-inventory` skill (which emits asset documents). Skills shell out to
this command; this module is the single place HTTP calls to the ingestor service
live, so OAuth, retry, idempotency, and output formatting are uniform.

Pattern mirrors torana_cli/rules.py and torana_cli/alerts.py.
"""

import json
import sys
from pathlib import Path

import click
import yaml

from torana_cli.client.auth import AuthError
from torana_cli.client.base import (
    APIError,
    ToranaClient,
    handle_api_error,
    handle_auth_error,
)
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output


# Column hints used by `output()` when --format=table.
_RECEIPT_COLS = [
    ("scan_id", "SCAN_ID", 28),
    ("source", "SOURCE", 24),
    ("received_at", "RECEIVED_AT", 22),
    ("counts", "COUNTS", 0),
]


def _client(ctx) -> ToranaClient:
    """Standard CLI client constructor (same as rules.py / alerts.py)."""
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _load_input_file(file_path: str) -> dict:
    """Load a JSON or YAML envelope. '-' reads from stdin."""
    if file_path == "-":
        content = click.get_text_stream("stdin").read()
    else:
        path = Path(file_path)
        if not path.exists():
            click.echo(f"ERROR: File not found: {file_path}", err=True)
            sys.exit(2)
        content = path.read_text()

    try:
        return json.loads(content)
    except json.JSONDecodeError:
        pass
    try:
        return yaml.safe_load(content) or {}
    except yaml.YAMLError as e:
        click.echo(f"ERROR: Cannot parse {file_path}: {e}", err=True)
        sys.exit(6)


# ─── Command group ────────────────────────────────────────────────────────────

@click.group()
def ingest():
    """Push-based scan ingestion (called by torana-<engine>-scan skills).

    \b
    Examples:
      torana ingest sarif ./scan.sarif --format json --raw
      torana ingest trivy ./trivy-report.json
      torana ingest assets ./asset-inventory.json
      torana ingest receipts 01HXYZA1B2C3D4E5F6G7H8J9K0
      torana ingest cve-feed nvd-2026-05-24.json
    """


# ─── sarif ────────────────────────────────────────────────────────────────────

@ingest.command(name="sarif")
@click.argument("sarif_file", type=click.Path(dir_okay=False, allow_dash=True))
@click.option("--asset-ref", default=None,
              help="Repository reference for keyless SARIF (no versionControlProvenance), "
                   "e.g. a git remote or host/org/repo. Required for raw semgrep output.")
@click.pass_context
def sarif(ctx, sarif_file, asset_ref):
    """POST a SARIF 2.1.0 document to /api/v1/ingest/sarif.

    Accepts any tool's SARIF (semgrep, CodeQL, GitHub, Trivy, claude_review).
    Findings land in `vulnerabilities` and link to a source-neutral `repositories`
    row. If the SARIF carries no versionControlProvenance (e.g. raw semgrep), pass
    --asset-ref so the findings can be linked. Re-POSTing the same scan is a no-op.

    Pass `-` for SARIF_FILE to read from stdin.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text")
    raw = ctx.obj.get(CTX_RAW, False)
    fields = ctx.obj.get(CTX_FIELDS)

    sarif_doc = _load_input_file(sarif_file)
    if not isinstance(sarif_doc, dict) or "runs" not in sarif_doc:
        click.echo("ERROR: SARIF file must be a JSON object with a `runs` array", err=True)
        sys.exit(6)

    body = {"sarif": sarif_doc}
    if asset_ref:
        body["asset_ref"] = asset_ref

    client = _client(ctx)
    try:
        receipt = client.post("ingest/sarif", json=body)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    output(receipt, fmt=fmt, raw=raw, fields=fields, columns=_RECEIPT_COLS)


# ─── trivy ────────────────────────────────────────────────────────────────────

@ingest.command(name="trivy")
@click.argument("report_file", type=click.Path(dir_okay=False, allow_dash=True))
@click.option("--asset-ref", default=None,
              help="Repository reference, e.g. a git remote or host/org/repo. Optional — "
                   "a `trivy image` scan is identified by its image digest and needs no repo.")
@click.pass_context
def trivy(ctx, report_file, asset_ref):
    """POST a native Trivy JSON report to /api/v1/ingest/trivy.

    Produce one with `trivy image --format json -o report.json <image>` (or
    `trivy fs`). Findings land in `vulnerabilities`.

    Prefer this over `torana ingest sarif` when you need CVE identity, package
    identity, or fix status: SARIF cannot carry them. Measured on one image —
    via SARIF `cve_id` and `package_name` land 0/366 and `Status`/`FixedVersion`
    are absent entirely; via this route they are 356/366, 366/366, 366/366 and
    230/366. (The 10 non-CVE ids are Debian TEMP-* placeholders, correctly
    excluded.) SARIF remains fine for triage-by-severity.

    Scope it to `--scanners vuln`: a report carrying a `Secrets` block is
    rejected rather than stored. Re-POSTing the same report is a no-op.

    Pass `-` for REPORT_FILE to read from stdin.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text")
    raw = ctx.obj.get(CTX_RAW, False)
    fields = ctx.obj.get(CTX_FIELDS)

    report = _load_input_file(report_file)
    if not isinstance(report, dict) or "SchemaVersion" not in report:
        click.echo(
            "ERROR: not a Trivy JSON report (no `SchemaVersion`). Generate one with "
            "`trivy image --format json -o report.json <image>` — note --format json, "
            "not sarif.",
            err=True,
        )
        sys.exit(6)

    body = {"report": report}
    if asset_ref:
        body["asset_ref"] = asset_ref

    client = _client(ctx)
    try:
        receipt = client.post("ingest/trivy", json=body)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    output(receipt, fmt=fmt, raw=raw, fields=fields, columns=_RECEIPT_COLS)


# ─── assets ───────────────────────────────────────────────────────────────────

@ingest.command(name="assets")
@click.argument("asset_file", type=click.Path(dir_okay=False, allow_dash=True))
@click.pass_context
def assets(ctx, asset_file):
    """POST an asset-inventory document to /api/v1/ingest/assets.

    The file must conform to asset_inventory.v1.json (identity + governance,
    keyed by `asset_ref`). Re-POSTing an updated asset is intentional and
    re-runs server-side so governance edits (criticality, owner, SLA) take
    effect — the upsert is idempotent on the source-neutral repository id.

    Produced by the `torana-asset-inventory` skill. Pass `-` to read stdin.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text")
    raw = ctx.obj.get(CTX_RAW, False)
    fields = ctx.obj.get(CTX_FIELDS)

    doc = _load_input_file(asset_file)
    if not isinstance(doc, dict) or not doc.get("asset_ref"):
        click.echo("ERROR: asset file must be a JSON/YAML object with an `asset_ref` key", err=True)
        sys.exit(6)

    client = _client(ctx)
    try:
        receipt = client.post("ingest/assets", json=doc)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    output(receipt, fmt=fmt, raw=raw, fields=fields, columns=_RECEIPT_COLS)


# ─── entity-edges ──────────────────────────────────────────────────────────────

@ingest.command(name="entity-edges")
@click.argument("edges_file", type=click.Path(dir_okay=False, allow_dash=True))
@click.pass_context
def entity_edges(ctx, edges_file):
    """POST an entity-edges document to /api/v1/ingest/entity-edges.

    The file must conform to entity_edges.v1 (a `source` plus an `edges` array of
    typed, directional edges between polymorphic keys). Re-POSTing is idempotent
    on the deterministic edge id; the server applies monotonic-max confidence,
    per-source evidence merge, and un-tombstones re-observed edges. A
    type-incorrect edge is DLQ'd (counts.dlq) without failing the batch.

    Produced by the `torana-entity-graph` skill. Pass `-` to read stdin.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text")
    raw = ctx.obj.get(CTX_RAW, False)
    fields = ctx.obj.get(CTX_FIELDS)

    doc = _load_input_file(edges_file)
    if not isinstance(doc, dict) or not isinstance(doc.get("edges"), list):
        click.echo("ERROR: entity-edges file must be a JSON/YAML object with an `edges` array", err=True)
        sys.exit(6)

    client = _client(ctx)
    try:
        receipt = client.post("ingest/entity-edges", json=doc)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    output(receipt, fmt=fmt, raw=raw, fields=fields, columns=_RECEIPT_COLS)


# ─── entity-edge-candidates ──────────────────────────────────────────────────────

@ingest.command(name="entity-edge-candidates")
@click.argument("candidates_file", type=click.Path(dir_okay=False, allow_dash=True))
@click.pass_context
def entity_edge_candidates(ctx, candidates_file):
    """POST an entity-edge-candidates document to /api/v1/ingest/entity-edge-candidates.

    A candidate is an edge whose ONE endpoint could not be keyed from the declared
    data — e.g. a compose `exposed_via` whose cloud LB is unknowable from the
    manifest. The file conforms to entity_edge_candidates.v1 (a `source` plus a
    `candidates` array; each carries the keyed side + `reason` + `candidate_value`,
    no edge id). It lands `status=open` in the candidates ledger and AUTO-PROMOTES
    when the observed/derived edge later supplies the missing key. Idempotent on a
    deterministic id; a re-declared candidate bumps `occurrence_count`.

    Produced by the `torana-entity-graph` skill. Pass `-` to read stdin.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text")
    raw = ctx.obj.get(CTX_RAW, False)
    fields = ctx.obj.get(CTX_FIELDS)

    doc = _load_input_file(candidates_file)
    if not isinstance(doc, dict) or not isinstance(doc.get("candidates"), list):
        click.echo(
            "ERROR: entity-edge-candidates file must be a JSON/YAML object with a `candidates` array",
            err=True,
        )
        sys.exit(6)

    client = _client(ctx)
    try:
        receipt = client.post("ingest/entity-edge-candidates", json=doc)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    output(receipt, fmt=fmt, raw=raw, fields=fields, columns=_RECEIPT_COLS)


# ─── receipts ─────────────────────────────────────────────────────────────────

# Receipt scan ids are SOURCE-QUALIFIED server-side (`<source>:<id>`), but the id a
# user has in hand is usually the BARE one their tool printed — e.g. build_sarif.py
# prints `scan_id=017B…` while the ingestor keys the receipt `sarif:017B…`
# (torana_mesh/etl/ingestors/sarif.py: `return f"sarif:{guid}"`). Looking up the id as
# printed then 404s, which reads as "the scan was never accepted" (CLI-25).
#
# So: try the id verbatim first (an already-qualified id, or any future unprefixed
# source, still works), and on 404 retry against the known source prefixes. Listed
# rather than assuming `sarif:` — the server also mints `asset:`, `entity-edges:` and
# `entity-edge-candidates:` receipts (torana_mesh/api/routes/ingest.py), so a
# hardcoded single prepend would be wrong for those.
_RECEIPT_SOURCE_PREFIXES = ("sarif", "asset", "entity-edges", "entity-edge-candidates")


@ingest.command(name="receipts")
@click.argument("scan_id")
@click.pass_context
def receipts(ctx, scan_id):
    """Fetch the receipt for a previously-accepted scan.

    Idempotency check: if a scan with this id has been accepted, returns the
    receipt; otherwise 404.

    Accepts either the source-qualified id (`sarif:017B…`) or the bare id as
    printed by the scan tool (`017B…`) — the source prefix is resolved for you.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text")
    raw = ctx.obj.get(CTX_RAW, False)
    fields = ctx.obj.get(CTX_FIELDS)

    client = _client(ctx)

    # Verbatim first, then source-qualified candidates. An id that already carries a
    # known prefix is never re-prefixed.
    candidates = [scan_id]
    if not any(scan_id.startswith(f"{p}:") for p in _RECEIPT_SOURCE_PREFIXES):
        candidates += [f"{p}:{scan_id}" for p in _RECEIPT_SOURCE_PREFIXES]

    receipt = None
    last_error = None
    for candidate in candidates:
        try:
            receipt = client.get(f"ingest/receipts/{candidate}")
            break
        except AuthError as e:
            handle_auth_error(e)
            return
        except APIError as e:
            # Only a 404 means "try the next prefix"; anything else is a real
            # failure and must surface immediately rather than being masked by
            # subsequent lookups.
            if e.status_code != 404:
                handle_api_error(e)
                return
            last_error = e

    if receipt is None:
        if len(candidates) > 1:
            click.echo(
                f"\nERROR: no receipt for {scan_id!r} (also tried "
                f"{', '.join(repr(c) for c in candidates[1:])}).",
                err=True)
            click.echo(
                "  The scan may not have been accepted, or it belongs to another tenant.",
                err=True)
            sys.exit(last_error.exit_code if last_error else 3)
        handle_api_error(last_error)
        return

    output(receipt, fmt=fmt, raw=raw, fields=fields, columns=_RECEIPT_COLS)


# ─── cve-feed ─────────────────────────────────────────────────────────────────

@ingest.command(name="cve-feed")
@click.argument("feed_file", type=click.Path(dir_okay=False, allow_dash=True))
@click.pass_context
def cve_feed(ctx, feed_file):
    """Bulk upsert into the CVE enrichment cache (CVSS / KEV / EPSS).

    Body must be:
        { "entries": [ { "cve_id": "...", "cvss_v3": ..., "epss": ..., "kev": ... } ] }
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text")
    raw = ctx.obj.get(CTX_RAW, False)
    fields = ctx.obj.get(CTX_FIELDS)

    body = _load_input_file(feed_file)
    if not isinstance(body, dict) or "entries" not in body:
        click.echo("ERROR: feed file must be a JSON object with an `entries` array", err=True)
        sys.exit(6)

    client = _client(ctx)
    try:
        result = client.post("ingest/cve-feed", json=body)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields)
