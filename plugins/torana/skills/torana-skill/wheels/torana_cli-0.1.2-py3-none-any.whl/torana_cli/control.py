"""torana control <id> — one compensating control, instance ops (T10).

Instance-scoped verbs for a single control. Reads via /tables/controls/data
(filtered by PK); lifecycle + efficacy writes via PATCH
/api/v1/compensating-controls/{id}.

    torana control <id> get
    torana control <id> promote            # shadow → active, action=block
    torana control <id> retire
    torana control <id> efficacy --status blocked --evidence-file diff.json
"""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    return ToranaClient(base_url=get_settings(profile).base_url)


def _fmt(ctx):
    return (
        ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text",
        ctx.obj.get(CTX_RAW, False) if ctx.obj else False,
        ctx.obj.get(CTX_FIELDS) if ctx.obj else None,
    )


def _cid(ctx) -> str:
    return ctx.obj.get("_control_id", "") if ctx.obj else ""


def _patch(ctx, body: dict):
    """PATCH the control and print the response."""
    fmt, raw, fields = _fmt(ctx)
    client = _client(ctx)
    try:
        data = client.patch(f"compensating-controls/{_cid(ctx)}", json=body)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    output(data, fmt=fmt, raw=raw, fields=fields)


@click.group(name="control", invoke_without_command=True)
@click.argument("control_id", metavar="CONTROL_ID")
@click.pass_context
def control(ctx, control_id):
    """One compensating control (by id) — get / promote / retire / efficacy.

    \b
    A control starts in SHADOW (observing, not blocking) and is promoted to
    blocking only once its efficacy verdict shows it stops the exploit without
    breaking traffic. Record the verdict first; promote second.

    \b
    Examples:
      torana control <CONTROL_ID> get
      torana control <CONTROL_ID> efficacy --help    record the before/after verdict
      torana control <CONTROL_ID> promote            shadow → blocking
      torana control <CONTROL_ID> retire
    """
    ctx.ensure_object(dict)
    ctx.obj["_control_id"] = control_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@control.command(name="get")
@click.pass_context
def control_get(ctx):
    """Get one control (including its efficacy verdict)."""
    fmt, raw, fields = _fmt(ctx)
    client = _client(ctx)
    try:
        data = client.get("/tables/controls/data",
                          params={"limit": 1, "torana_control_id": _cid(ctx)})
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    rows = (data.get("data") or data.get("rows") or data.get("items") or []) \
        if isinstance(data, dict) else []
    output(rows[0] if rows else {}, fmt=fmt, raw=raw, fields=fields)


@control.command(name="promote")
@click.pass_context
def control_promote(ctx):
    """Promote a shadow control to blocking (status=active, action=block)."""
    _patch(ctx, {"status": "active", "action": "block"})


@control.command(name="retire")
@click.pass_context
def control_retire(ctx):
    """Retire a control (status=retired)."""
    _patch(ctx, {"status": "retired"})


@control.command(name="efficacy")
@click.option("--status", "efficacy_status", required=True,
              type=click.Choice(["blocked", "bypassed", "partial", "untested"]),
              help="The before/after efficacy verdict.")
@click.option("--evidence", default=None, help="Evidence JSON/string (before/after run refs + diff).")
@click.option("--evidence-file", "evidence_file", default=None, type=click.Path(exists=True),
              help="Path to a file whose contents become the evidence.")
@click.option("--verified-at", "efficacy_verified_at", default=None,
              help="ISO-8601 timestamp the verdict was produced (defaults to server now).")
@click.pass_context
def control_efficacy(ctx, efficacy_status, evidence, evidence_file, efficacy_verified_at):
    """Record the before/after control-efficacy verdict on this control (T10).

    \b
    Example:
      torana control <id> efficacy --status blocked --evidence-file diff.json
    """
    body = {"efficacy_status": efficacy_status}
    if evidence_file:
        with open(evidence_file, encoding="utf-8") as fh:
            evidence = fh.read()
    if evidence is not None:
        body["efficacy_evidence"] = evidence
    if efficacy_verified_at:
        body["efficacy_verified_at"] = efficacy_verified_at
    _patch(ctx, body)
