"""torana fix-impact — raw blast-radius compute over the entity graph (T6).

`torana fix-impact analyze` calls integration's /fix-impact/analyze directly to
show the up/downstream/owners of a fix, without persisting a report. The
persisted, remediation-scoped report is `torana remediation <id> impact`.
"""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE
from torana_cli.output import output


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(name="fix-impact", invoke_without_command=True)
@click.pass_context
def fix_impact(ctx):
    """Blast-radius (fix-impact) analysis over the entity graph.

    \b
    Examples:
      torana fix-impact analyze --repo repo:github.com/o/r --changed-pkgs pkg:npm/lodash@4.17.20
    """
    ctx.ensure_object(dict)
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@fix_impact.command(name="analyze")
@click.option("--repo", default=None, help="repo: key of the fixed repository.")
@click.option("--changed-pkgs", default=None, help="Comma-separated changed pkg: keys.")
@click.option("--base-sha", default=None, help="Base commit sha (diff against --head-sha to derive changed pkgs).")
@click.option("--head-sha", default=None, help="Head commit sha.")
@click.option("--repo-path", default=".",
              help="Local git checkout used to derive changed packages for --base-sha/--head-sha "
                   "(default: current directory).")
@click.option("--direction", default="both", type=click.Choice(["forward", "reverse", "both"]),
              help="Traversal direction (upstream=reverse, downstream=forward).")
@click.option("--max-depth", default=8, type=int, help="Depth cap (1..16).")
@click.pass_context
def fix_impact_analyze(ctx, repo, changed_pkgs, base_sha, head_sha, repo_path, direction, max_depth):
    """Compute the up/downstream blast radius for a fix (does not persist).

    \b
    Give it changed packages one of two ways:
      --changed-pkgs pkg:pypi/litellm@1.74.15.post2,pkg:npm/lodash@4.17.20
      --base-sha <sha> --head-sha <sha> [--repo-path <dir>]   (GAP-A2: derives them from the
          local git diff of requirements*.txt / go.mod / poetry.lock / package-lock.json)
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    body = {"direction": direction, "max_depth": max_depth}
    if repo:
        body["repo"] = repo

    pkg_list = [p.strip() for p in changed_pkgs.split(",") if p.strip()] if changed_pkgs else []
    # GAP-A2 — derive changed pkgs from a local git diff when SHAs are given and no explicit list.
    if base_sha and head_sha and not pkg_list:
        from torana_cli._pkg_diff import derive_changed_pkgs
        diff = derive_changed_pkgs(repo_path, base_sha, head_sha)
        for n in diff["notes"]:
            click.echo(f"[fix-impact] {n}", err=True)
        # GAP-A2 correctness: the blast radius is keyed on the BASE (currently-deployed) versions.
        # Seeding with the head versions matches ZERO images — nothing runs the new version yet —
        # which reported "affects nothing" for every version bump. head/names are informational.
        pkg_list = list(diff["base"])
        click.echo(
            f"[fix-impact] derived from {base_sha[:8]}..{head_sha[:8]}: "
            f"{len(pkg_list)} base pkg(s) → blast radius; "
            f"{len(diff['head'])} head pkg(s) → target"
            + (f"; names: {', '.join(diff['names'])}" if diff["names"] else ""),
            err=True)
        if diff["head"] and not pkg_list:
            click.echo("[fix-impact] every change is a NEWLY-ADDED dependency (no base version) — "
                       "nothing currently deployed is disturbed by the dependency itself; the "
                       "repo's own services still come from --repo.", err=True)
        elif not diff["head"]:
            click.echo("[fix-impact] nothing to analyze — pass --changed-pkgs explicitly, or check "
                       "--repo-path / the SHAs.", err=True)
    if pkg_list:
        body["changed_pkgs"] = pkg_list
    if base_sha:
        body["base_sha"] = base_sha
    if head_sha:
        body["head_sha"] = head_sha
    client = _client(ctx)
    try:
        data = client.post("fix-impact/analyze", json=body)
    except AuthError as e:
        handle_auth_error(e)
        return
    except APIError as e:
        handle_api_error(e)
        return
    # Base-vs-head advisory: warn (before the result) when a requested pkg version isn't
    # deployed, so an empty blast radius isn't mistaken for "no impact". version_not_deployed
    # is the load-bearing case — the user likely keyed on the upgrade TARGET, not the base.
    for note in (data.get("seed_notes") or []):
        if note.get("reason") == "version_not_deployed":
            click.echo(f"[fix-impact] ⚠ {note.get('message')}", err=True)
        elif note.get("reason") == "package_not_in_graph":
            click.echo(f"[fix-impact] {note.get('message')}", err=True)
    output(data, fmt=fmt, fields=fields)
