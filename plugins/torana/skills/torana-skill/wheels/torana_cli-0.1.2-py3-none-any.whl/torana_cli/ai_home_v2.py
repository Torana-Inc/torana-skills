"""AI Home V2 CLI — the V2 page as the page shows it: `torana workspace <id> ai-home-v2 get`.

Spec: pantheon-fe/docs/AI_HOME_V2_HOME_PROOF_SPEC.md. The page is pantheon-fe/src/app/ai-home-v2/.

⭐ NOTHING HERE DECIDES WHAT THE PAGE SAYS. The Needs-you cards are `proof.home.cards`, arranged ONCE by
pantheon_shared.proof.home.cards (home v5) and read by the page too; hero, funnel, trust, stale and rest are
`proof.home`; the zones the V2 page shares with the classic page are printed by the classic renderer
(`ai_home._render_page(data, only={zone})`). This module only looks ids up and lays the page out, top to bottom,
in the template's zone order, as pantheon-fe ai-home-v2.component.html draws it.
✦ marks ONLY AI-written text (the narrator's recommendations); ◆ marks proven facts and code findings.
"""
from datetime import datetime, timezone

import click

from torana_cli.ai_home import (_OPEN_STATUSES, _ago, _cited_text, _ctx, _first_proven_hint, _flatten_cited,
                                _funnel_lines, _render_page, _trust_lines, _zone_title)
from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, handle_api_error, handle_auth_error
from torana_cli.output import output

#: The zones V2 draws (pantheon-fe v2-page.ts V2_ZONES); any other template zone is named in the classic-only note.
V2_ZONES = ("Z0", "Z1", "Z2", "Zhealth", "Z3", "Z4", "Zrules", "Zdash", "Z6")
#: Zones V2 shares with the classic page: printed by the classic renderer, never a second way.
SHARED_ZONES = ("Z0", "Zhealth", "Z4", "Zrules", "Zdash", "Z6")
#: What the classic page calls zones whose template title is null (v2-page.ts ZONE_NAME).
ZONE_NAME = {"Z5": "Questions answered", "Z8": "Assessment", "Z9": "Instrumentation", "Z10": "Assessment",
             "Z11": "Reading guide", "gaps": "What this app can't answer yet"}
#: The proof chip glyphs (home-view.ts PROOF_GLYPH): the shape carries the kind, never colour alone.
CHIP_GLYPH = {"group": "◆", "stale": "▲", "unjudged": "○", "drift": "◇", "unmodelled": "⊘"}
HEALTH_GLYPH = {"bad": "▲", "watch": "◐"}   # ◆ means proven/derived on V2
CARD_GLYPH = {"insight": "◆", "group": "◆", "retired": "▲", "row": "▸"}


def register(workspace_group, client_factory):
    """Attach the `ai-home-v2` sub-group to the `workspace <id>` group (registered from workspace.py)."""

    def _wid(ctx) -> str:
        return ctx.obj.get("_workspace_id", "") if ctx.obj else ""

    @workspace_group.group(name="ai-home-v2", invoke_without_command=True)
    @click.pass_context
    def ai_home_v2(ctx):
        """The AI Home V2 page: decision cards first, every fact proven, every AI sentence marked ✦."""
        ctx.ensure_object(dict)
        if ctx.invoked_subcommand is None:
            click.echo(ctx.get_help())

    @ai_home_v2.command(name="get")
    @click.option("--run", "run_id", default=None,
                  help="Show this earlier proven run instead of the latest (ids from `ai-home runs --kind proven`).")
    @click.pass_context
    def ai_home_v2_get(ctx, run_id):
        """Show the AI Home V2 page as the page shows it: stamp, hero, funnel, trust, the Needs-you
        decision cards (highlight, groups, the retired card, single rows, the rest), then the other zones.
        "How this app is running" is written by code (home v6: title + one line per fact, ▲ bad ◐ watch ✓ ok,
        ○ switched off); a run stored before v6 shows the narrator's strip.

        Examples:
          torana workspace <ID> ai-home-v2 get
          torana workspace <ID> ai-home-v2 get --run <RUN_ID>
          torana workspace <ID> ai-home-v2 get --format json
        """
        fmt, raw, fields = _ctx(ctx)
        params = {"kind": "proven", **({"run_id": run_id} if run_id else {})}
        try:
            data = client_factory(ctx).get(f"workspaces/{_wid(ctx)}/ai-home", params=params)
        except APIError as e:
            if getattr(e, "status_code", None) == 404 and not run_id:
                _first_proven_hint(_wid(ctx))      # a STATE, not an error: the scheduler prepares the first page
                return
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return
        view = v2_view(data or {}, _wid(ctx))
        if fmt in ("json", "yaml"):
            output(view, fmt=fmt, raw=raw, fields=fields)
            return
        render(view, data or {}, _wid(ctx))


# ── the view: one object, printed as text or returned as JSON ────────────────────────────────────────────────────
def _age(created_at, now: datetime) -> str | None:
    """The row's wait, as the page's age tile: hours under 48, then days (home-view.ts ageLabel)."""
    if not created_at:
        return None
    try:
        t = datetime.fromisoformat(str(created_at).replace("Z", "+00:00"))
    except ValueError:
        return None
    t = t if t.tzinfo else t.replace(tzinfo=timezone.utc)
    hrs = max(0, int((now - t).total_seconds() // 3600))
    return f"{hrs} hr{'' if hrs == 1 else 's'}" if hrs < 48 else f"{hrs // 24} days"


def _row(key: str, narr_by_key: dict, alerts: dict, items: dict, chips: dict, ws: str, now: datetime) -> dict:
    """One Needs-you row (v2-needs-you-row): the narrator's headline and ✦ recommendation, the alert's own columns,
    the proof chips, the citations, and the commands that open its proof."""
    a = narr_by_key.get(key) or {}
    al = alerts.get(key) or {}
    it = items.get(key) or {}
    cites = list(dict.fromkeys((a.get("headline") or {}).get("cites", []) + (a.get("recommendation") or {}).get("cites", [])))
    return {
        "alert_id": key,
        "headline": _cited_text(a.get("headline")) or it.get("title") or al.get("name") or key,
        "recommendation": _cited_text(a.get("recommendation")) or None,
        "severity": (al.get("severity") or "").lower() or None,
        "status": str(al.get("status") or "").replace("_", " ") or None,
        "owner": "owned by a person" if al.get("assigned_to") else None,
        "chips": [{"kind": c.get("kind"), "glyph": CHIP_GLYPH.get(c.get("kind"), "·"), "text": c.get("text")}
                  for c in chips.get(key) or []],
        "cites": cites,
        "age": _age(al.get("created_at"), now),
        "change": {"still_here": "still here", "new": "new", "resolved": "resolved"}.get(al.get("change") or ""),
        "has_graph": it.get("has_graph"),
        "proof_command": f"torana alert {key} proof",
        "brief_command": f"torana alert {key} brief --workspace {ws}",
    }


def _member(aid: str, items: dict) -> dict:
    it = items.get(aid) or {}
    return {"alert_id": aid, "title": it.get("title") or aid, "stale": bool(it.get("stale"))}


def v2_view(data: dict, ws: str, now: datetime | None = None) -> dict:
    """The V2 page as named keys, in page order. Pure: reads `data` (GET …/ai-home?kind=proven) only."""
    now = now or datetime.now(timezone.utc)
    proof = data.get("proof") or {}
    home = proof.get("home") or {}
    narr = data.get("narration") or {}
    facts = data.get("facts") or {}
    items = {it["alert_id"]: it for it in proof.get("items") or []}
    alerts = {str(a.get("id")): a for a in (facts.get("alerts") or {}).get("items") or [] if isinstance(a, dict)}
    narr_by_key = {a.get("item_key"): a for a in narr.get("attention_items") or []}
    chips = home.get("chips") or {}
    # The page's rows (home-view.ts provenRows): the narrator's, in its order; without narration, the chosen rows.
    keys = [a.get("item_key") for a in narr.get("attention_items") or []] or list(chips)
    row = lambda k: _row(k, narr_by_key, alerts, items, chips, ws, now)  # noqa: E731
    stored = home.get("cards")
    cards = []
    for c in (stored if stored is not None else [{"kind": "row", "key": "r:" + k, "title": None, "text": "", "lead": k,
                                                    "members": [], "sections": [], "brief": None} for k in keys]):
        lead = row(c["lead"]) if c.get("lead") else None
        cards.append({
            "kind": c["kind"], "key": c["key"], "title": c.get("title") or (lead or {}).get("headline") or "",
            "text": c.get("text") or "", "lead": lead,
            "why": (home.get("highlight") or {}).get("reason") if c["kind"] == "insight" else None,
            "members": [_member(m, items) for m in c.get("members") or []],
            "sections": [{"label": s.get("label"), "members": list(s.get("members") or [])} for s in c.get("sections") or []],
        })
    zones = [z for z in (facts.get("template") or {}).get("zones") or []]
    alerts_f = facts.get("alerts") or {}
    open_total = alerts_f.get("open_total") if isinstance(alerts_f.get("open_total"), int) else alerts_f.get("open_count")
    rest = home.get("rest")
    # ⭐ home v6: "How this app is running" is CODE-written (pantheon_shared.proof.health), one value for the hero tile
    # and the strip; a run stored before v6 keeps the narrator's health_block.
    code_health = home.get("health")
    health = narr.get("health_block")
    if code_health:
        health_view = {"source": "code", **code_health}
    elif health:
        health_view = {"source": "narration", "tone": health.get("tone"),
                       "glyph": HEALTH_GLYPH.get(health.get("tone"), "✓"), "title": health.get("verdict"),
                       "lines": [{"glyph": "", "text": health.get("body")}] if health.get("body") else []}
    else:
        health_view = None
    z3 = next((z for z in zones if z.get("id") == "Z3"), {})
    return {
        "run_id": data.get("run_id"), "workspace_id": ws, "status": data.get("status"),
        "stamp": {"window": data.get("window_label"), "generated_at": data.get("generated_at"),
                  "scheduled": data.get("trigger") == "scheduled"},
        "notes": (["Proof unavailable for this run: no row could be proven, so the rows come from the facts."]
                  if not proof.get("items") else
                  ["No narration passed the code critic, so the rows are shown without prose."] if not narr else []),
        "zones": [z.get("id") for z in zones if z.get("id") in V2_ZONES],
        "classic_only": [z.get("title") or ZONE_NAME.get(z.get("id")) or z.get("id") for z in zones
                         if z.get("id") not in V2_ZONES],
        "hero": {"title": home.get("hero") or _cited_text(narr.get("title_sentence")) or None,
                 "scope": _cited_text(narr.get("scope_sentence")) or None, "need_you": len(keys),
                 "handled": (facts.get("since") or {}).get("handled_count"),
                 "health": ({"glyph": health_view["glyph"], "verdict": health_view["title"]}
                            if health_view else {"glyph": "✓", "verdict": "nothing to report about the app itself"})},
        "health": health_view,
        "funnel": {"summary": home.get("funnel_summary"), "steps": home.get("funnel") or []},
        "trust": home.get("trust") or [],
        "data_only": not narr,
        "collector_errors": data.get("collector_errors") or [],
        "needs_you": {"title": z3.get("title") or "Needs you", "showing": len(keys), "open": open_total,
                      "cards_stored": stored is not None, "cards": cards,
                      "rest": ({"count": rest.get("count"), "text": rest.get("text"),
                                "command": f"torana alerts list --workspace-id {ws} --status {_OPEN_STATUSES}"}
                               if rest and rest.get("count") else None)},
        "home_version": home.get("version"),
    }


# ── the text render: top to bottom, in the template's zone order ─────────────────────────────────────────────────
def _row_lines(r: dict, ind: str) -> list:
    out = [f"{ind}▸ {r['headline']}" + ("   ✦ AI" if r["recommendation"] else "")]
    cols = [x for x in (r["severity"], r["status"], r["owner"]) if x] + [f"{c['glyph']} {c['text']}" for c in r["chips"]]
    if cols:
        out.append(f"{ind}  {' · '.join(cols)}")
    if r["recommendation"]:
        out.append(f"{ind}  ✦ AI {r['recommendation']}")
    side = [x for x in (f"◆ cites {len(r['cites'])} proven fact{'' if len(r['cites']) == 1 else 's'}" if r["cites"] else None,
                        f"waiting {r['age']}" if r["age"] else None, ("◷ " + r["change"]) if r["change"] == "still here"
                        else r["change"]) if x]
    if side:
        out.append(f"{ind}  {' · '.join(side)}")
    out.append(f"{ind}  proof{' + graph' if r['has_graph'] else ''}: {r['proof_command']}")
    return out


def _members(c: dict, ind: str) -> list:
    by = {m["alert_id"]: m for m in c["members"]}
    out = []
    for s in c["sections"] or [{"label": None, "members": [m["alert_id"] for m in c["members"]]}]:
        if s["label"]:
            out.append(f"{ind}{s['label']}")
        for aid in s["members"]:
            m = by.get(aid) or {"title": aid, "stale": False}
            out.append(f"{ind}  - {'▲ retired image · ' if m['stale'] else ''}{m['title']}   ({aid[:8]})")
    return out


def _card_lines(c: dict) -> list:
    n = len(c["members"])
    if c["kind"] == "row":
        return _row_lines(c["lead"], "  ")
    if c["kind"] == "insight":
        out = [f"  ◆ {c['title']}"]
        if c["why"]:
            out.append(f"    why this one: {c['why']}")
        if c["lead"] and c["lead"]["recommendation"]:
            out.append(f"    ✦ AI {c['lead']['recommendation']}")
        if c["lead"] and c["lead"]["cites"]:
            out.append(f"    ◆ cites {len(c['lead']['cites'])} proven fact{'' if len(c['lead']['cites']) == 1 else 's'}")
        if n > 1:
            out += [f"    the {n} rows:"] + _members(c, "    ")
        lead = c["members"][0]["alert_id"] if c["members"] else None
        if lead:
            out.append(f"    proof: torana alert {lead} proof · brief: torana alert {lead} brief")
        return out
    out = [f"  {CARD_GLYPH[c['kind']]} {c['title']}" + ("" if c["kind"] == "retired" else f" · {n} row{'' if n == 1 else 's'}")]
    if c["kind"] == "retired" and c["text"]:
        out.append(f"    {c['text']}")
    if c["lead"]:
        out += _row_lines(c["lead"], "    ")
    out += [f"    the {n} row{'' if n == 1 else 's'}:"] + _members(c, "    ")
    return out


def render(view: dict, data: dict, ws: str) -> None:
    st = view["stamp"]
    gen = f" · generated {_ago(st['generated_at'])} · written by the platform" if st["generated_at"] else ""
    click.echo(f"\n{st['window'] or 'AI Home'}{gen}{' · scheduled' if st['scheduled'] else ''}   (run {view['run_id']})")
    for n in view["notes"]:
        click.echo(f"▲ {n}")
    shared = {**data, "narration": _flatten_cited(data.get("narration"))}
    home = (data.get("proof") or {}).get("home") or {}
    for z in view["zones"]:
        if z == "Zhealth" and (view.get("health") or {}).get("source") == "code":
            h = view["health"]
            click.echo(f"\n{_zone_title(data, 'Zhealth', 'How this app is running')}")
            click.echo(f"  {h['glyph']} {h['title']}")
            for ln in h.get("lines") or []:
                click.echo(f"    {ln['glyph']} {ln['text']}")
        elif z in SHARED_ZONES:
            _render_page(shared, only={z})
        elif z == "Z1":
            h = view["hero"]
            click.echo(f"\n{h['title'] or str(h['need_you']) + ' items need you.'}")
            if h["scope"]:
                click.echo(h["scope"])
            click.echo(f"  {h['need_you']} need you · {h['handled'] if h['handled'] is not None else '—'} handled for you"
                       f" · {h['health']['glyph']} {h['health']['verdict']}")
            for line in _funnel_lines(home, "  "):
                click.echo(line)
        elif z == "Z2":
            lines = _trust_lines(home, ws, "  ")
            if lines or view["data_only"] or view["collector_errors"] or view["classic_only"]:
                click.echo("")
            for line in lines:
                click.echo(line)
            if view["data_only"]:
                click.echo("  Showing measured data only. This run produced no narration; the figures are unaffected.")
            if view["collector_errors"]:
                click.echo(f"  ▲ {len(view['collector_errors'])} source(s) could not be read; the figures may under-count:")
                for e in view["collector_errors"]:
                    click.echo(f"    - {e.get('source')}: {e.get('error')}")
            if view["classic_only"]:
                k = len(view["classic_only"])
                click.echo(f"  {k} section{'' if k == 1 else 's'} of this page {'is' if k == 1 else 'are'} only on the "
                           f"classic Home: {', '.join(view['classic_only'])}.  See: torana workspace {ws} ai-home get")
        elif z == "Z3":
            _needs_you(view["needs_you"])
    click.echo("")


def _needs_you(ny: dict) -> None:
    head = f"\n{ny['title']}"
    if ny["showing"] and ny["open"] is not None:
        head += f"   (showing {ny['showing']} of {ny['open']:,} open)"
    click.echo(head)
    if not ny["cards"]:
        click.echo("  Nothing needs a decision from you right now.")
        return
    click.echo("  One card per decision; the largest first." if ny["cards_stored"] else
               "  (this run predates stored cards, home v5: rows in the narrator's order)")
    for c in ny["cards"]:
        click.echo("")
        for line in _card_lines(c):
            click.echo(line)
    if ny["rest"]:
        click.echo(f"\n  ⋯ {ny['rest']['text']}")
        click.echo(f"    see them: {ny['rest']['command']}")
