# Generated command stubs — auto-created by scripts/generate-commands.py
