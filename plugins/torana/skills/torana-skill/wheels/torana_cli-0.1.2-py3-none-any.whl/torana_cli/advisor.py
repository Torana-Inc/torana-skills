"""torana advisor — cross-workspace advisor signals and sweeps."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group()
def advisor():
    """Program Advisor — cross-workspace data signals and sweep inspection.

    \b
    Examples:
      torana advisor data-sources
      torana advisor kev-match
      torana advisor rule-run-results <RULE_UUID> --window 30d
      torana advisor rule-alert-dispositions <RULE_UUID>
      torana advisor sweeps list
      torana advisor sweeps get <SWEEP_ID>
    """


# ---------------------------------------------------------------------------
# Datalake advisor signals
# ---------------------------------------------------------------------------

@advisor.command(name="data-sources")
@click.option("--workspace-id", "workspace_id", default=None, help="Filter by workspace UUID.")
@click.pass_context
def advisor_data_sources(ctx, workspace_id):
    """List DataLake tables with freshness, row counts, and kind (advisor signal).

    \b
    Example:
      torana advisor data-sources --workspace-id <UUID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if workspace_id:
        params["workspace_id"] = workspace_id

    client = _client(ctx)
    try:
        data = client.get("advisor/data-sources", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    from torana_cli.output import output
    output(data, fmt=fmt, raw=raw, fields=fields,
           columns=[("table_name", "TABLE", 40), ("kind", "KIND", 12),
                    ("row_count", "ROWS", 12), ("last_updated", "LAST UPDATED", 20)])


@advisor.command(name="kev-match")
@click.option("--workspace-id", "workspace_id", default=None, help="Filter by workspace UUID.")
@click.pass_context
def advisor_kev_match(ctx, workspace_id):
    """Count open vulnerabilities matched against the CISA KEV catalog.

    \b
    Example:
      torana advisor kev-match --workspace-id <UUID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if workspace_id:
        params["workspace_id"] = workspace_id

    client = _client(ctx)
    try:
        data = client.get("advisor/kev-match", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    from torana_cli.output import output
    output(data, fmt=fmt, fields=fields)


# ---------------------------------------------------------------------------
# Detection framework advisor signals
# ---------------------------------------------------------------------------

@advisor.command(name="rule-run-results")
@click.argument("rule_id", metavar="RULE_ID")
@click.option("--window", default=None, help="Trailing window (e.g. 7d, 30d).")
@click.pass_context
def advisor_rule_run_results(ctx, rule_id, window):
    """Rule firing statistics over a trailing window (advisor signal).

    \b
    Example:
      torana advisor rule-run-results <RULE_UUID> --window 30d
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if window:
        params["window"] = window

    client = _client(ctx)
    try:
        data = client.get(f"advisor/rule-run-results/{rule_id}", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    from torana_cli.output import output
    output(data, fmt=fmt, fields=fields)


@advisor.command(name="rule-alert-dispositions")
@click.argument("rule_id", metavar="RULE_ID")
@click.pass_context
def advisor_rule_alert_dispositions(ctx, rule_id):
    """Alert disposition breakdown and FP rate for a rule (advisor signal).

    \b
    Example:
      torana advisor rule-alert-dispositions <RULE_UUID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"advisor/rule-alert-dispositions/{rule_id}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    from torana_cli.output import output
    output(data, fmt=fmt, fields=fields)


# ---------------------------------------------------------------------------
# Sweeps (admin) — /api/v1/admin/advisor/sweeps
# ---------------------------------------------------------------------------

_SWEEP_LIST_COLS = [
    ("sweep_session_id", "SWEEP_ID", 36),
    ("workspace_name", "WORKSPACE", 20),
    ("tenant_name", "TENANT", 20),
    ("mode", "MODE", 10),
    ("agent_status", "STATUS", 12),
    ("proposals_count", "PROPOSALS", 9),
    ("started_at", "STARTED", 20),
]


@advisor.group(name="sweeps")
def advisor_sweeps():
    """Inspect Program Advisor sweeps (SA/TA).

    \b
    Examples:
      torana advisor sweeps list
      torana advisor sweeps list --tenant-id <UUID> --mode bootstrap
      torana advisor sweeps list --workspace-id <UUID> --status success --limit 1
      torana advisor sweeps get <SWEEP_ID>
      torana advisor sweeps get <SWEEP_ID> --include-llm-calls
    """


@advisor_sweeps.command(name="list")
@click.option("--tenant-id", "tenant_id", default=None, help="Filter by tenant UUID.")
@click.option("--workspace-id", "workspace_id", default=None, help="Filter by workspace UUID.")
@click.option("--mode", "mode", type=click.Choice(["bootstrap", "refresh"]), default=None,
              help="Filter by sweep mode.")
@click.option("--status", "agent_status", default=None,
              help="Filter by agent_status (e.g. success, in_progress, failed).")
@click.option("--page", "page", default=1, show_default=True, type=int)
@click.option("--page-size", "page_size", default=None, type=int,
              help="Results per page (max 100). Defaults to profile page_size.")
@click.option("--limit", "limit", default=None, type=int,
              help="Shorthand for --page-size; takes precedence.")
@click.pass_context
def advisor_sweeps_list(ctx, tenant_id, workspace_id, mode, agent_status,
                        page, page_size, limit):
    """List Program Advisor sweeps with optional filters."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective = limit if limit is not None else (page_size or settings.page_size)
    effective = min(effective, 100)

    params = {"page": page, "page_size": effective}
    if tenant_id:
        params["tenant_id"] = tenant_id
    if workspace_id:
        params["workspace_id"] = workspace_id
    if mode:
        params["mode"] = mode
    if agent_status:
        params["agent_status"] = agent_status

    client = _client(ctx)
    try:
        data = client.get("admin/advisor/sweeps", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    from torana_cli.output import output
    output(data, fmt=fmt, raw=raw, fields=fields, columns=_SWEEP_LIST_COLS)


@advisor_sweeps.command(name="get")
@click.argument("sweep_id", metavar="SWEEP_ID")
@click.option("--include-llm-calls", "include_llm_calls", is_flag=True, default=False,
              help="Include full LLM call records (may be large).")
@click.pass_context
def advisor_sweeps_get(ctx, sweep_id, include_llm_calls):
    """Get full sweep detail by sweep_session_id."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    params = {}
    if include_llm_calls:
        params["include_llm_calls"] = "true"

    client = _client(ctx)
    try:
        data = client.get(f"admin/advisor/sweeps/{sweep_id}", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    from torana_cli.output import output
    output(data, fmt=fmt, fields=fields)


@advisor_sweeps.command(name="diff")
@click.option("--a", "sweep_a", required=True, help="First sweep_session_id.")
@click.option("--b", "sweep_b", required=True, help="Second sweep_session_id.")
@click.pass_context
def advisor_sweeps_diff(ctx, sweep_a, sweep_b):
    """Diff two sweeps by sweep_session_id."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("admin/advisor/sweeps/diff",
                          params={"a": sweep_a, "b": sweep_b})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    from torana_cli.output import output
    output(data, fmt=fmt, fields=fields)


@advisor_sweeps.command(name="retire")
@click.argument("sweep_id", metavar="SWEEP_ID")
@click.option("--reason", required=True, help="Mandatory reason for retirement.")
@click.option("--dry-run", is_flag=True, default=False,
              help="Preview which proposals would be retired without writing.")
@click.pass_context
def advisor_sweeps_retire(ctx, sweep_id, reason, dry_run):
    """Retire all proposals from a sweep (SA only)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    suffix = ":dry-run" if dry_run else ""
    path = f"admin/advisor/sweeps/{sweep_id}/retire{suffix}"
    body = {"reason": reason}

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    from torana_cli.output import output
    output(data, fmt=fmt, fields=fields)
