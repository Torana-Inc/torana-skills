"""`torana version` — report WHICH BUILD is running, not just its version string.

⛔ WHY THIS COMMAND EXISTS. The skill bootstrap has always tried to detect build skew
(a CLI whose code differs from the wheel the skill shipped) by running
`torana version --format json`. That command did not exist: every invocation returned
empty, the guard `[ -n "$INSTALLED_COMMIT" ]` was therefore always false, and the skew
warning COULD NEVER FIRE. Measured on a clean plugin install, 2026-09-15.

The failure it was meant to catch is the one SKILL-1 documents: two builds can carry the
SAME version string and DIFFERENT code, so a version compare passes while the caller runs
code it did not expect — and concludes a working capability is a missing surface. Only the
commit distinguishes them, which is why `_version.py` records it at build time.

Fixed here, in the CLI, rather than by teaching the skill to read `_version.py` itself:
the skill asked the CLI a fair question and the CLI had no answer. Any consumer — a skill,
CI, a support request — needs the same answer.
"""

import json

import click

from torana_cli import _version
from torana_cli.main import CTX_FORMAT


@click.command(name="version")
@click.option("--format", "fmt", type=click.Choice(["text", "json", "yaml"]), default=None,
              help="Output format (defaults to the profile's format).")
@click.pass_context
def version(ctx, fmt):
    """Show the CLI version and the exact build it came from.

    \b
    Examples:
      torana version
      torana version --format json
    """
    fmt = fmt or (ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text")

    data = {
        "version": getattr(_version, "VERSION", "unknown"),
        "commit": getattr(_version, "COMMIT_SHA", ""),
        "dirty": bool(getattr(_version, "DIRTY", False)),
        "built_at": getattr(_version, "BUILT_AT", ""),
    }

    if fmt == "json":
        click.echo(json.dumps(data, indent=2))
    elif fmt == "yaml":
        for k, v in data.items():
            click.echo(f"{k}: {v}")
    else:
        dirty = "  (dirty — commit does not fully describe this build)" if data["dirty"] else ""
        click.echo(f"torana {data['version']}")
        click.echo(f"  commit:   {data['commit'] or 'unknown'}{dirty}")
        click.echo(f"  built at: {data['built_at'] or 'unknown'}")
