"""torana workspace-templates — workspace template collection commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 35),
    ("category", "CATEGORY", 28),
    ("is_active", "ACTIVE", 6),
    ("is_public", "PUBLIC", 6),
    ("usage_count", "USED", 5),
    ("description", "DESCRIPTION", 40),
]


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(name="workspace-templates")
def workspace_templates():
    """Manage workspace templates.

    \b
    A template's `category` determines the type of workspace created from it
    (e.g. category "Vulnerability Management" -> type vulnerability_management).

    \b
    Examples:
      torana workspace-templates list
      torana workspace-templates categories
      torana workspace-templates list --category "SOC"
    """


@workspace_templates.command(name="list")
@click.option("--category", default=None, help="Filter by category.")
@click.option("--search", default=None, help="Search in name or description.")
@click.option("--active/--no-active", "is_active", default=None,
              help="Filter by active status.")
@click.option("--public/--no-public", "is_public", default=None,
              help="Filter by public status.")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int,
              help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False,
              help="Auto-paginate and return all results.")
@click.pass_context
def workspace_templates_list(ctx, category, search, is_active, is_public,
                             page, page_size, fetch_all):
    """List workspace templates.

    \b
    Examples:
      torana workspace-templates list
      torana workspace-templates list --active --format table
      torana workspace-templates list --json | jq '.items[] | {category, name}'
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    effective_page_size = min(page_size or settings.page_size, 100)

    params = {}
    if category:
        params["category"] = category
    if search:
        params["search"] = search
    if is_active is not None:
        params["is_active"] = is_active
    if is_public is not None:
        params["is_public"] = is_public

    path = "workspace-templates"
    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "page": page_num, "page_size": effective_page_size}
                data = client.get(path, params=p)
                items = data.get("items", data if isinstance(data, list) else [])
                all_items.extend(items)
                total = data.get("total", len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total or not items:
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items), "page": 1,
                      "page_size": len(all_items)}
        else:
            data = client.get(path, params={**params, "page": page,
                                            "page_size": effective_page_size})
            if isinstance(data, list):
                result = {"items": data, "total": len(data), "page": page,
                          "page_size": effective_page_size}
            else:
                result = data
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


_CATEGORY_COLS = [
    ("category", "CATEGORY", 30),
    ("type", "TYPE (pass to --type)", 30),
    ("configured", "CONFIGURED", 10),
]


@workspace_templates.command(name="categories")
@click.pass_context
def workspace_templates_categories(ctx):
    """List template categories and the workspace type each maps to.

    \b
    The TYPE column is the value to pass to `torana workspaces create --type`.
    CONFIGURED reports whether the type seeds agents and a home layout; types
    marked False are accepted on create but produce an empty workspace.

    \b
    Examples:
      torana workspace-templates categories
      torana workspace-templates categories --json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get("workspace-templates/categories/types")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    items = data if isinstance(data, list) else data.get("items", [])
    result = {"items": items, "total": len(items), "page": 1, "page_size": len(items)}

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_CATEGORY_COLS)
