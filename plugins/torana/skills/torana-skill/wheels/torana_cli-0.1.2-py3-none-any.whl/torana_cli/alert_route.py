"""torana alert-route — per-route instance commands."""

import json as _json

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)



def _as_list(value):
    """Coerce a CLI-supplied list flag into the JSON list the API requires.

    These fields are list-typed server-side, so forwarding the raw string 422s
    with `Input should be a valid list`. Accepts a repeated flag (click gives a
    tuple), a JSON array string, or a comma-separated string.
    """
    if value is None:
        return None
    if isinstance(value, (list, tuple)):
        items = []
        for v in value:
            items.extend(_as_list(v) or [])
        return items
    text = str(value).strip()
    if not text:
        return []
    if text.startswith("["):
        import json as _json
        try:
            parsed = _json.loads(text)
            if isinstance(parsed, list):
                return [str(x).strip() for x in parsed if str(x).strip()]
        except ValueError:
            pass
    return [part.strip() for part in text.split(",") if part.strip()]

@click.group(name="alert-route", invoke_without_command=True)
@click.argument("route_id", metavar="ROUTE_ID")
@click.pass_context
def alert_route(ctx, route_id):
    """Per-route instance commands.

    \b
    Examples:
      torana alert-route <UUID> get
      torana alert-route <UUID> update --name "New Name"
      torana alert-route <UUID> delete --yes
      torana alert-route <UUID> test --severity high
      torana alert-route <UUID> enable
      torana alert-route <UUID> disable
      torana alert-route <UUID> move --target-workspace-id <UUID>
    """
    ctx.ensure_object(dict)
    ctx.obj["_route_id"] = route_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _rid(ctx) -> str:
    return ctx.obj.get("_route_id", "") if ctx.obj else ""


@alert_route.command(name="get")
@click.pass_context
def alert_route_get(ctx):
    """Get details for a specific alert route."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"alert-routing/rules/{_rid(ctx)}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert_route.command(name="update")
@click.option("--name", default=None)
@click.option("--description", default=None)
@click.option("--enabled", default=None, type=bool)
@click.option("--priority", default=None, type=int)
@click.option("--stop-on-match", "stop_on_match", default=None, type=bool)
@click.option("--severity-levels", "severity_levels", default=None)
@click.option("--required-tags", "required_tags", default=None)
@click.option("--source-rule-ids", "source_rule_ids", multiple=True,
              help="Rule UUID to bind this route to. Repeatable, or pass a "
                   "comma-separated list. Binding a route to its rule is what "
                   "stops it matching every alert of a given severity.")
@click.option("--source-suite-ids", "source_suite_ids", multiple=True,
              help="Suite UUID. Repeatable, or comma-separated.")
@click.option("--matching-operator", "matching_operator", default=None)
@click.option("--destination-type", "destination_type", default=None)
@click.option("--destination-config", "destination_config", default=None)
@click.option("--max-executions-per-hour", "max_executions_per_hour", default=None, type=int)
@click.option("--labels", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def alert_route_update(ctx, name, description, enabled, priority, stop_on_match,
                       severity_levels, required_tags, source_rule_ids, source_suite_ids,
                       matching_operator, destination_type, destination_config,
                       max_executions_per_hour, labels, input_file):
    """Update an alert route."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name is not None:
        body["name"] = name
    if description is not None:
        body["description"] = description
    if enabled is not None:
        body["enabled"] = enabled
    if priority is not None:
        body["priority"] = priority
    if stop_on_match is not None:
        body["stop_on_match"] = stop_on_match
    if severity_levels is not None:
        body["severity_levels"] = _as_list(severity_levels)
    if required_tags is not None:
        body["required_tags"] = _as_list(required_tags)
    if source_rule_ids:
        body["source_rule_ids"] = _as_list(source_rule_ids)
    if source_suite_ids:
        body["source_suite_ids"] = _as_list(source_suite_ids)
    if matching_operator is not None:
        body["matching_operator"] = matching_operator
    if destination_type is not None:
        body["destination_type"] = destination_type
    if destination_config is not None:
        # `--destination-config` is a JSON OBJECT on the wire (the API types it
        # Dict[str, Any]). Passing the raw string through made every invocation 422 with
        # "Input should be a valid dictionary", so the flag could never be used at all.
        # Parse here and fail with a readable message rather than a server-side error.
        if isinstance(destination_config, str):
            try:
                destination_config = _json.loads(destination_config)
            except ValueError as exc:
                raise click.BadParameter(
                    f"--destination-config must be a JSON object: {exc}",
                    param_hint="--destination-config",
                )
        if not isinstance(destination_config, dict):
            raise click.BadParameter(
                "--destination-config must be a JSON OBJECT, e.g. "
                "'{\"workflow_id\": \"<uuid>\"}'",
                param_hint="--destination-config",
            )
        body["destination_config"] = destination_config
    if max_executions_per_hour is not None:
        body["max_executions_per_hour"] = max_executions_per_hour
    if labels is not None:
        body["labels"] = labels

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"alert-routing/rules/{_rid(ctx)}", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, fields=fields)
    else:
        click.echo(f"Updated alert route: {_rid(ctx)}")


@alert_route.command(name="patch")
@click.option("--name", default=None)
@click.option("--description", default=None)
@click.option("--enabled", default=None, type=bool)
@click.option("--priority", default=None, type=int)
@click.option("--stop-on-match", "stop_on_match", default=None, type=bool)
@click.option("--severity-levels", "severity_levels", default=None)
@click.option("--required-tags", "required_tags", default=None)
@click.option("--source-rule-ids", "source_rule_ids", multiple=True,
              help="Rule UUID to bind this route to. Repeatable, or pass a "
                   "comma-separated list. Binding a route to its rule is what "
                   "stops it matching every alert of a given severity.")
@click.option("--source-suite-ids", "source_suite_ids", multiple=True,
              help="Suite UUID. Repeatable, or comma-separated.")
@click.option("--matching-operator", "matching_operator", default=None)
@click.option("--destination-type", "destination_type", default=None)
@click.option("--destination-config", "destination_config", default=None)
@click.option("--max-executions-per-hour", "max_executions_per_hour", default=None, type=int)
@click.option("--labels", default=None)
@click.pass_context
def alert_route_patch(ctx, name, description, enabled, priority, stop_on_match,
                      severity_levels, required_tags, source_rule_ids, source_suite_ids,
                      matching_operator, destination_type, destination_config,
                      max_executions_per_hour, labels):
    """Patch an alert route (partial update)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = {}
    if name is not None:
        body["name"] = name
    if description is not None:
        body["description"] = description
    if enabled is not None:
        body["enabled"] = enabled
    if priority is not None:
        body["priority"] = priority
    if stop_on_match is not None:
        body["stop_on_match"] = stop_on_match
    if severity_levels is not None:
        body["severity_levels"] = _as_list(severity_levels)
    if required_tags is not None:
        body["required_tags"] = _as_list(required_tags)
    if source_rule_ids:
        body["source_rule_ids"] = _as_list(source_rule_ids)
    if source_suite_ids:
        body["source_suite_ids"] = _as_list(source_suite_ids)
    if matching_operator is not None:
        body["matching_operator"] = matching_operator
    if destination_type is not None:
        body["destination_type"] = destination_type
    if destination_config is not None:
        # `--destination-config` is a JSON OBJECT on the wire (the API types it
        # Dict[str, Any]). Passing the raw string through made every invocation 422 with
        # "Input should be a valid dictionary", so the flag could never be used at all.
        # Parse here and fail with a readable message rather than a server-side error.
        if isinstance(destination_config, str):
            try:
                destination_config = _json.loads(destination_config)
            except ValueError as exc:
                raise click.BadParameter(
                    f"--destination-config must be a JSON object: {exc}",
                    param_hint="--destination-config",
                )
        if not isinstance(destination_config, dict):
            raise click.BadParameter(
                "--destination-config must be a JSON OBJECT, e.g. "
                "'{\"workflow_id\": \"<uuid>\"}'",
                param_hint="--destination-config",
            )
        body["destination_config"] = destination_config
    if max_executions_per_hour is not None:
        body["max_executions_per_hour"] = max_executions_per_hour
    if labels is not None:
        body["labels"] = labels

    client = _client(ctx)
    try:
        data = client.post(f"alert-routing/rules/{_rid(ctx)}", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert_route.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False)
@click.pass_context
def alert_route_delete(ctx, yes):
    """Delete an alert route."""
    _confirm(f"Delete alert route {_rid(ctx)}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"alert-routing/rules/{_rid(ctx)}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted alert route: {_rid(ctx)}")


@alert_route.command(name="test")
@click.option("--severity", default="high", help="Test alert severity.")
@click.pass_context
def alert_route_test(ctx, severity):
    """Send a test alert through this routing rule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {"severity": severity}
    client = _client(ctx)
    try:
        data = client.post(f"alert-routing/rules/{_rid(ctx)}/test", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        status = data.get("status", "sent") if isinstance(data, dict) else "sent"
        click.echo(f"Test alert sent via route {_rid(ctx)}: {status}")


@alert_route.command(name="enable")
@click.pass_context
def alert_route_enable(ctx):
    """Enable this routing rule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.post(f"alert-routing/rules/{_rid(ctx)}/enable", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, fields=fields)
    else:
        click.echo(f"Enabled alert route: {_rid(ctx)}")


@alert_route.command(name="disable")
@click.pass_context
def alert_route_disable(ctx):
    """Disable this routing rule."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.post(f"alert-routing/rules/{_rid(ctx)}/disable", json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt, fields=fields)
    else:
        click.echo(f"Disabled alert route: {_rid(ctx)}")


@alert_route.command(name="move")
@click.option("--target-workspace-id", "target_workspace_id", required=True)
@click.pass_context
def alert_route_move(ctx, target_workspace_id):
    """Move alert route to a different workspace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = {"target_workspace_id": target_workspace_id}
    client = _client(ctx)
    try:
        data = client.post(f"alert-routing/{_rid(ctx)}/move", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)
