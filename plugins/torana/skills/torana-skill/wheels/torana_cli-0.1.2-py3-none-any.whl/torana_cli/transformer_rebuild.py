"""torana datalake transformers rebuild-all / graph — the dependency order, and one build of it.

    torana datalake transformers graph        [--format json]
    torana datalake transformers rebuild-all  [--dry-run] [--full-refresh] [--follow] [--yes]

The server owns both: `GET transformers/dependency-graph` and `POST transformers/rebuild-all`
use the rule every build orders by (the SQL text), so what `graph` prints is what a build does.
rebuild-all is ONE server-side batch build; this module only starts and follows it. Ctrl-C
stops the FOLLOWING, never the build — `build <ID> show --follow` re-attaches.

Every state is a glyph plus a word, never colour alone (the maintainer is red/green
colour-blind).
"""
import json
import sys
import time

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, handle_api_error, handle_auth_error
from torana_cli.confirm import confirm
from torana_cli.transformer_builds import (FOLLOW_SECONDS, TERMINAL, _client, _fmt,
                                           render_build_detail, state_label)

_STAGE_WORDS = {"app": "workspace transformers",
                "bootstrap": "platform transformers (under the build lock)",
                "app_after_bootstrap": "workspace transformers that read platform ones"}


def _call(fn, *a, **k):
    try:
        return fn(*a, **k)
    except AuthError as e:
        handle_auth_error(e)
    except APIError as e:
        handle_api_error(e)
    return None


def render_graph(g) -> str:
    """Base transformers at the top level; every other transformer ONCE, under `tree_parent`
    (the input it waits for last, chosen by the server), so depth follows build order. Its
    other inputs are named on its line (`+ also reads …`)."""
    nodes = g.get("nodes") or []
    kids = {}
    for n in nodes:
        kids.setdefault(n.get("tree_parent"), []).append(n)
    lines = [f"{g.get('total', 0)} transformers · {g.get('edges', 0)} dependencies · "
             f"{g.get('waves', 0)} waves"]
    shown = set()

    def emit(n, depth):
        if n["transformer_id"] in shown:
            return
        shown.add(n["transformer_id"])
        label = n["name"] + (f" → {n['model']}" if n["model"] != n["name"] else "")
        tags = [f"wave {n['wave']}"]
        if n.get("is_bootstrap"):
            tags.append("platform")
        if not n.get("is_active"):
            tags.append("inactive")
        if n.get("last_status"):
            tags.append(state_label(n["last_status"], item=True))
        also = [r for r in n.get("reads") or [] if r != n.get("tree_parent")]
        prefix = ("   " * (depth - 1) + "└─ ") if depth else ""
        lines.append(f"  {prefix}{label}  [{' · '.join(tags)}]"
                     + (f"  + also reads {', '.join(also)}" if also else ""))
        for child in kids.get(n["model"], []):
            emit(child, depth + 1)

    for n in kids.get(None, []):
        emit(n, 0)
    for n in nodes:                                   # defensive: nothing is ever dropped
        emit(n, 0)
    for c in g.get("cycles") or []:
        lines.append(f"  ⚠ cycle: {' ⇄ '.join(c)} — usually a name matched in SQL by accident")
    return "\n".join(lines)


def render_plan(p) -> str:
    waves = p.get("waves") or []
    lines = [f"{p.get('total', 0)} transformers in {len(waves)} waves"
             + ("  (full refresh)" if p.get("full_refresh") else "")]
    stage = None
    for w in waves:
        if w["stage"] != stage:
            stage = w["stage"]
            lines.append(f"  — {_STAGE_WORDS.get(stage, stage)}")
        names = ", ".join(m["name"] for m in w["models"])
        lines.append(f"    wave {w['wave']:<3} {names}")
    for nb in p.get("not_built") or []:
        lines.append(f"  – not built: {nb['transformer_id'][:8]} ({nb['status']})")
    return "\n".join(lines)


def register(group):
    """Attach `graph` and `rebuild-all` to `torana datalake transformers`."""

    @group.command(name="graph")
    @click.option("--format", "local_fmt", type=click.Choice(["text", "json"]), default=None)
    @click.pass_context
    def transformers_graph(ctx, local_fmt):
        """Show which transformer reads which, as a tree in build order.

        \b
        A transformer with no inputs among the others is a BASE (wave 1). Each reader is
        indented under what it reads; build a base before the transformers under it.

        \b
        Examples:
          TORANA_PROFILE=T1 torana datalake transformers graph
          TORANA_PROFILE=T1 torana datalake transformers graph --format json
        """
        data = _call(_client(ctx).get, "transformers/dependency-graph")
        if data is None:
            return
        if _fmt(ctx, local_fmt) == "json":
            click.echo(json.dumps(data, indent=2, default=str))
        else:
            click.echo(render_graph(data))

    @group.command(name="rebuild-all")
    @click.option("--dry-run", is_flag=True, default=False,
                  help="Print the waves; build nothing.")
    @click.option("--full-refresh", is_flag=True, default=False,
                  help="Rebuild incremental relations from scratch. ⚠️ Resets the created_at "
                       "watermark detection rules read on keyed relations.")
    @click.option("--follow", is_flag=True, default=False,
                  help=f"Follow the build every {FOLLOW_SECONDS}s until it ends. Ctrl-C stops "
                       "following; the build keeps running.")
    @click.option("--yes", "-y", is_flag=True, default=False, help="Skip the confirmation.")
    @click.option("--format", "local_fmt", type=click.Choice(["text", "json"]), default=None)
    @click.pass_context
    def transformers_rebuild_all(ctx, dry_run, full_refresh, follow, yes, local_fmt):
        """Rebuild every active transformer of this tenant, in dependency order.

        \b
        ONE build on the server: base transformers first, then each wave of readers, batched
        (the same order and path the automatic refresh uses). The command returns the build
        id at once; --follow watches it. Ctrl-C only stops watching — the build finishes on
        the server, and `build <ID> show --follow` picks it up again.

        \b
        A second rebuild-all of the same tenant while one runs is refused with its build id.
        Platform transformers wait for the tenant's build lock (a repair or a refresh may
        hold it); any that cannot get it within 5 minutes are reported `lock_lost`.

        \b
        Examples:
          TORANA_PROFILE=T1 torana datalake transformers rebuild-all --dry-run
          TORANA_PROFILE=T1 torana datalake transformers rebuild-all --follow
          TORANA_PROFILE=T1 torana datalake transformers rebuild-all --full-refresh --yes
        """
        fmt = _fmt(ctx, local_fmt)
        client = _client(ctx)
        plan = _call(client.post, "transformers/rebuild-all",
                     json={"dry_run": True, "full_refresh": full_refresh})
        if plan is None:
            return
        if dry_run or not plan.get("total"):
            click.echo(json.dumps(plan, indent=2, default=str) if fmt == "json"
                       else (render_plan(plan) if plan.get("total")
                             else plan.get("detail") or "No active transformers."))
            return
        if fmt == "text":
            click.echo(render_plan(plan))
        confirm(f"Rebuild {plan['total']} transformer(s)"
                + (" with --full-refresh" if full_refresh else "") + "?", yes=yes)
        try:
            started = client.post("transformers/rebuild-all",
                                  json={"dry_run": False, "full_refresh": full_refresh})
        except APIError as e:
            d = e.detail if isinstance(e.detail, dict) else {}
            if e.status_code == 409 and d.get("build_id"):
                click.echo(f"⚠ {d.get('message')} build {d['build_id'][:8]}\n"
                           f"  follow it: torana datalake transformers build "
                           f"{d['build_id'][:8]} show --follow", err=True)
                sys.exit(e.exit_code)
            handle_api_error(e)
            return
        except AuthError as e:
            handle_auth_error(e)
            return
        bid = started.get("build_id")
        if fmt == "json" and not follow:
            click.echo(json.dumps(started, indent=2, default=str))
            return
        click.echo(f"▶ started build {str(bid)[:8]} — {started.get('total')} transformers, "
                   f"{len(started.get('waves') or [])} waves")
        if not follow:
            click.echo(f"  follow it: torana datalake transformers build {str(bid)[:8]} "
                       "show --follow")
            return
        _follow(client, bid, fmt)


def _follow(client, bid, fmt) -> None:
    """Poll until terminal. Ctrl-C detaches (the build is the server's); exit 1 when the build
    failed or any item did not succeed, so a script can tell."""
    last = None
    try:
        while True:
            d = _call(client.get, f"transformers/builds/{bid}")
            if d is None:
                return
            if fmt != "json":
                line = (f"  {state_label(d.get('state'), d.get('stuck'))}  "
                        f"{d.get('items_done', 0)}/{d.get('items_total', 0)}"
                        + (f"  at: {d['position']}" if d.get("position") else ""))
                if line != last:
                    click.echo(line)
                    last = line
            if d.get("state") in TERMINAL:
                break
            time.sleep(FOLLOW_SECONDS)
    except KeyboardInterrupt:
        click.echo(f"\nStopped following. Build {str(bid)[:8]} keeps running on the server.\n"
                   f"  re-attach: torana datalake transformers build {str(bid)[:8]} show "
                   "--follow", err=True)
        sys.exit(130)
    if fmt == "json":
        click.echo(json.dumps(d, indent=2, default=str))
    else:
        click.echo(render_build_detail(d))
    bad = [i for i in d.get("items") or []
           if i.get("status") not in ("success", "already_current")]
    if d.get("state") != "done" or bad:
        if fmt != "json" and bad:
            click.echo(f"\n⚠ {len(bad)} transformer(s) not rebuilt — fix the causes above, "
                       "then run rebuild-all again (it rebuilds everything).", err=True)
        sys.exit(1)
