"""torana query — per-query instance commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE
from torana_cli.output import output
from torana_cli.rules import _load_input_file
from torana_cli.confirm import confirm as _confirm


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(name="query", invoke_without_command=True)
@click.argument("query_id", metavar="QUERY_ID")
@click.pass_context
def query(ctx, query_id):
    """Per-query instance commands.

    \b
    Examples:
      torana query <UUID> get
      torana query <UUID> update --name "New Name"
      torana query <UUID> delete --yes
      torana query <UUID> move --target-workspace-id <UUID>
    """
    ctx.ensure_object(dict)
    ctx.obj["_query_id"] = query_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _qid(ctx) -> str:
    return ctx.obj.get("_query_id", "") if ctx.obj else ""


@query.command(name="get")
@click.pass_context
def query_get(ctx):
    """Get details for a specific saved query."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"queries/{_qid(ctx)}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@query.command(name="update")
@click.option("--name", default=None)
@click.option("--sql", "sql_command", default=None,
              help="New SQL SELECT statement. The backend validates it, runs EXPLAIN, "
                   "and re-derives source_tables.")
@click.option("--sql-file", "sql_file", default=None, metavar="FILE",
              type=click.Path(exists=True, dir_okay=False, readable=True),
              help="Read the new SQL from a file (alternative to --sql for long queries).")
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def query_update(ctx, name, sql_command, sql_file, input_file):
    """Update a saved query (including its SQL).

    \b
    Examples:
      torana query <UUID> update --name "New Name"
      torana query <UUID> update --sql "SELECT ... FROM ..."
      torana query <UUID> update --sql-file new-query.sql
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    if sql_command and sql_file:
        click.echo("ERROR: Use either --sql or --sql-file, not both.", err=True)
        import sys
        sys.exit(2)
    if sql_file:
        with open(sql_file) as f:
            sql_command = f.read().strip()

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if sql_command:
        body["sql_command"] = sql_command

    if not body:
        click.echo("ERROR: No fields to update.", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.put(f"queries/{_qid(ctx)}/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Updated query: {_qid(ctx)}")


@query.command(name="delete")
@click.option("--yes", is_flag=True, default=False)
@click.pass_context
def query_delete(ctx, yes):
    """Delete a saved query."""
    _confirm(f"Delete query {_qid(ctx)}?", yes=yes)
    client = _client(ctx)
    try:
        client.delete(f"queries/{_qid(ctx)}/")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    click.echo(f"Deleted query: {_qid(ctx)}")


@query.command(name="move")
@click.option("--target-workspace-id", "target_workspace_id", required=True)
@click.pass_context
def query_move(ctx, target_workspace_id):
    """Move query to a different workspace."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = {"target_workspace_id": target_workspace_id}

    client = _client(ctx)
    try:
        data = client.post(f"queries/{_qid(ctx)}/move", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)
