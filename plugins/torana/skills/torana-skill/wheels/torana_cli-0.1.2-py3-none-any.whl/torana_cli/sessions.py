"""torana sessions — agent session collection management commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FORMAT, CTX_PROFILE
from torana_cli.output import output


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group()
def sessions():
    """Manage agent sessions (collection operations).

    \b
    Cross-tenant session listing (SA only):
      torana admin chats list

    \b
    Instance commands (get, delete, chat, cancel, history) are under:
      torana session <UUID> <verb>

    \b
    Examples:
      torana sessions create --agent-id <UUID>
      torana admin chats list
      torana admin chats list --agent-id <UUID>
    """


@sessions.command(name="create")
@click.option("--agent-id", required=True, help="Agent UUID to create a session for.")
@click.option("--title", default=None, help="Optional session title.")
@click.pass_context
def sessions_create(ctx, agent_id, title):
    """Create a new chat session for an agent."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if title:
        body["title"] = title

    client = _client(ctx)
    try:
        data = client.post(f"agents/{agent_id}/sessions", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        sid = data.get("session_id") or data.get("id", "unknown")
        click.echo(f"Created session: {sid}")
        click.echo(f"  Agent: {agent_id}")


# Field names match the server payload exactly: the endpoint returns
# {"sessions":[{session_id, name, status, event_count, ...}]} — NOT id/title.
_SESSION_COLS = [
    ("session_id", "SESSION ID", 52),
    ("name", "NAME", 40),
    ("status", "STATUS", 8),
    ("event_count", "EVENTS", 7),
]


@sessions.command(name="list")
@click.option("--agent-id", required=True,
              help="Agent UUID whose sessions to list (the API is agent-scoped).")
@click.option("--workspace-id", "workspace_id", default=None,
              help="Filter to one workspace.")
@click.option("--limit", type=int, default=50, show_default=True)
@click.option("--offset", type=int, default=0, show_default=True)
@click.pass_context
def sessions_list(ctx, agent_id, workspace_id, limit, offset):
    """List an agent's sessions, optionally scoped to a workspace.

    Uses the agent-scoped endpoint `agents/{id}/sessions`, which already supports a
    `workspace_id` filter. (The unscoped `/api/v1/sessions` route 404s — see CLI-10;
    it is not the path to build on.)

    \b
    Examples:
      torana sessions list --agent-id <UUID>
      torana sessions list --agent-id <UUID> --workspace-id <WS_UUID>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    params = {"limit": limit, "offset": offset}
    if workspace_id:
        params["workspace_id"] = workspace_id

    client = _client(ctx)
    try:
        data = client.get(f"agents/{agent_id}/sessions", params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if isinstance(data, dict):
        items = data.get("items", data.get("sessions", []))
        total = data.get("total", len(items))
    elif isinstance(data, list):
        items, total = data, len(data)
    else:
        items, total = [], 0
    output({"items": items, "total": total, "page": 1, "page_size": limit},
           fmt=fmt, columns=_SESSION_COLS)
