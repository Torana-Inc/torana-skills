"""Shared chat machinery: find the agent, start a chat, send and follow a turn to its end.

Every chat command (`torana chats …`, `torana chat <CHAT_ID> …`, `torana widget <W> chat`)
goes through this module, so there is one definition of "the turn finished", "the
assistant is waiting on you" and "the chat is busy", and one exit code for each.

⛔ This module never imports a command module (`chats`, `chat`, `agent`, `widget`, `main`):
those import it. Design: docs/specs/CHAT_SURFACE_SPEC.md § 3.4.5 to § 3.4.8.

How a turn runs (so the waiting logic below reads right):
  POST /sessions/{sid}/chat returns 202 {turn_id} at once and the turn runs in the
  background. Its events are stored in the database; GET …/stream?turn_id= replays them
  from the start (or from Last-Event-ID) and closes when the turn's lock is no longer
  `processing`, sending a `stream_end` event first for AG-UI agents. The truth about a
  turn is therefore the lock and the stored events, never the response to the send.
"""

import json
import re
import sys
import time
from dataclasses import dataclass, field as dc_field
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional

import click
import httpx

from torana_cli.client.base import (
    APIError,
    EXIT_BUSY,
    EXIT_GENERAL,
    EXIT_NOT_FOUND,
    EXIT_RUN_FAILED,
    EXIT_WAITING_ON_USER,
)

# The agent page chat and widget chat talk to. The screen looks it up by this name
# (pantheon-fe ask-ai-page.component.ts), so the CLI does too.
ASK_AI_AGENT_NAME = "Ask AI Orchestrator"

# Every session id is `agent_<36-char agent uuid>_…` (agent_chat.py create_agent_session).
_SESSION_AGENT_RE = re.compile(r"^agent_([0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12})(?:_|$)")

# Outcome of a turn → what the command exits with.
STATUS_EXIT = {
    "completed": 0,
    "sent": 0,
    "waiting": EXIT_WAITING_ON_USER,
    "busy": EXIT_BUSY,
    "failed": EXIT_RUN_FAILED,
    "timeout": EXIT_RUN_FAILED,
    "cancelled": EXIT_RUN_FAILED,
    "wait_timeout": EXIT_RUN_FAILED,
}

# Lock status (meta_data.execution_lock.status) → outcome.
_LOCK_OUTCOME = {
    "completed": "completed",
    "hitl_waiting": "waiting",
    "cancelled": "cancelled",
    "timeout": "timeout",
    "error": "failed",
    "service_restart": "failed",
}

_MAX_SILENT_RECONNECTS = 5      # reconnects in a row that delivered no event
_NO_LOCK_GRACE_SECONDS = 10.0   # after RunFinished, how long to wait for stream_end


@dataclass
class TurnResult:
    """What happened to one message. Callers print it and exit with `exit_code`."""

    session_id: str
    agent_id: str
    turn_id: Optional[str]
    status: str                      # a key of STATUS_EXIT
    reply: Optional[str] = None      # the assistant's final text for this turn
    tool_steps: List[dict] = dc_field(default_factory=list)    # [{name}]
    pending_question: Optional[dict] = None                 # set when status == "waiting"
    state_tag: Optional[str] = None
    message_sent: bool = True        # False when an open question or a busy chat stopped the send
    answered_question: bool = False  # True when the server took a plain message as an answer
    error: Optional[str] = None

    @property
    def exit_code(self) -> int:
        return STATUS_EXIT.get(self.status, EXIT_RUN_FAILED)

    def to_json(self) -> dict:
        return {
            "chat_id": self.session_id,
            "session_id": self.session_id,
            "agent_id": self.agent_id,
            "turn_id": self.turn_id,
            "status": self.status,
            "reply": self.reply,
            "tool_steps": self.tool_steps,
            "pending_question": self.pending_question,
            "state_tag": self.state_tag,
            "message_sent": self.message_sent,
            "answered_question": self.answered_question,
            "error": self.error,
        }


# ── Finding the agent ────────────────────────────────────────────────────────

def agent_id_from_session(session_id: str) -> Optional[str]:
    """`agent_<uuid>_…` → the uuid; None when the id has another shape."""
    m = _SESSION_AGENT_RE.match(session_id or "")
    return m.group(1) if m else None


def require_agent_id(session_id: str, agent_id: Optional[str] = None) -> str:
    """The chat's agent: `--agent` if given, else read from the chat id. Exits 2 if neither."""
    aid = agent_id or agent_id_from_session(session_id)
    if not aid:
        raise click.UsageError(
            f"Cannot tell which agent chat '{session_id}' belongs to (a chat id normally starts "
            "with 'agent_<AGENT_ID>_'). Pass --agent <AGENT_ID>."
        )
    return aid


def _not_found(message: str) -> None:
    click.echo(f"\nERROR: {message}", err=True)
    sys.exit(EXIT_NOT_FOUND)


def _agent_by_name(client, name: str) -> Optional[dict]:
    data = client.get("agents", params={"state": "published", "is_active": "true", "name": name})
    rows = data.get("agents") or data.get("items") or [] if isinstance(data, dict) else (data or [])
    exact = [a for a in rows if isinstance(a, dict) and a.get("name") == name]
    return exact[0] if exact else None


def resolve_operator_agent(client, app_id: str) -> dict:
    """The agent an app's Chat tab talks to → {agent_id, agent_name, attachment_id}.

    Same steps as the screen: the app's `operator` attachment, then that agent by id,
    falling back to a lookup by name when the attachment has no agent id, the read fails,
    or it comes back empty (an attachment keeps the id it was created with, and a
    re-created agent gets a new one). Exits 3 with the screen's wording when the app has
    no chat agent or the agent cannot be found.
    """
    data = client.get(f"workspaces/{app_id}/agents", params={"role": "operator"})
    items = (data.get("items") or []) if isinstance(data, dict) else (data or [])
    if not items:
        _not_found("No chat agent is attached to this app.")
    attachment = items[0]
    name = attachment.get("agent_name") or "Bodhi"
    agent = None
    if attachment.get("agent_id"):
        try:
            agent = client.get(f"agents/{attachment['agent_id']}")
        except APIError:
            agent = None
    if not agent or not agent.get("id"):
        agent = _agent_by_name(client, name)
    if not agent or not agent.get("id"):
        _not_found(f'Agent "{name}" not found.')
    return {"agent_id": agent["id"], "agent_name": agent.get("name") or name,
            "attachment_id": attachment.get("id")}


def resolve_ask_ai_agent(client) -> dict:
    """The agent page chat and widget chat use → {agent_id, agent_name}.

    Looked up by exact name among published, active agents, as the screen does. None →
    exit 3. More than one → the first, as the screen takes it, with a line on stderr.
    """
    data = client.get("agents", params={"state": "published", "is_active": "true",
                                        "name": ASK_AI_AGENT_NAME})
    rows = (data.get("agents") or data.get("items") or []) if isinstance(data, dict) else (data or [])
    exact = [a for a in rows if isinstance(a, dict) and a.get("name") == ASK_AI_AGENT_NAME]
    if not exact:
        _not_found(f'The "{ASK_AI_AGENT_NAME}" agent is not published in this tenant, so page '
                   "and widget chat are unavailable.")
    if len(exact) > 1:
        click.echo(f'Note: {len(exact)} agents are named "{ASK_AI_AGENT_NAME}"; using '
                   f"{exact[0]['id']}. Pass --agent to choose another.", err=True)
    return {"agent_id": exact[0]["id"], "agent_name": ASK_AI_AGENT_NAME}


# ── Starting a chat ──────────────────────────────────────────────────────────

def create_chat_session(client, *, agent_id: str, app_id: Optional[str] = None,
                        app_name: Optional[str] = None, attachment_id: Optional[str] = None,
                        anchor: Optional[dict] = None, title: Optional[str] = None,
                        new_session: bool = False) -> dict:
    """POST agents/{agent_id}/sessions → the server's response ({session_id, agent_id, …}).

    With `app_id` the chat carries the same metadata the screen sends, so the agent's
    writes land in that app and the chat shows in the app's Chat list. Without it the
    chat belongs to no app. `anchor` is `{"type": …, "id": …}` (e.g. a widget).
    """
    body: Dict[str, Any] = {}
    if app_id:
        metadata: Dict[str, Any] = {"context_type": "workspace", "workspace_id": app_id}
        if app_name:
            metadata["workspace_name"] = app_name
        if attachment_id:
            metadata["attachment_id"] = attachment_id
        body["metadata"] = metadata
    if anchor:
        body["anchor"] = anchor
    if new_session:
        body["new_session"] = True
    if title:
        body["name"] = title
    return client.post(f"agents/{agent_id}/sessions", json=body)


# ── Reading a chat's state ───────────────────────────────────────────────────

def state_name(state: dict) -> str:
    """One word for what a chat is doing: an open question wins over the lock status."""
    if state.get("pending"):
        return "waiting"
    lock = state.get("lock_status")
    if lock == "processing":
        return "running"
    if lock in (None, ""):
        return "idle"
    if lock == "hitl_waiting":
        # The lock still says it paused, but the question is gone (answered elsewhere or
        # expired). Nothing is running and nothing is being asked.
        return "idle"
    return _LOCK_OUTCOME.get(lock, lock)


def read_state(client, *, agent_id: str, session_id: str) -> dict:
    """GET agents/{agent_id}/sessions/{session_id}/pending, plus a computed `state`.

    → {session_id, agent_id, lock_status, turn_id, state_tag, pending, state}.
    A server without this route cannot support safe chatting from the CLI (the CLI could
    not see an open question before sending), so that case stops with one clear message.
    """
    try:
        state = client.get(f"agents/{agent_id}/sessions/{session_id}/pending")
    except APIError as e:
        detail = e.detail if isinstance(e.detail, str) else ""
        if e.status_code == 404 and detail.startswith("Session not found"):
            _not_found(f"No chat with id '{session_id}' for you in this tenant. "
                       "`torana chats list --app-id <APP_ID>` lists your chats.")
        if e.status_code == 404:
            click.echo("\nERROR: This server does not have the chat state route; the platform "
                       "must be updated before this CLI can chat.", err=True)
            sys.exit(EXIT_GENERAL)
        raise
    state["state"] = state_name(state)
    return state


def turn_reply(client, *, agent_id: str, session_id: str, turn_id: Optional[str]) -> tuple:
    """(reply text, tool steps) of one turn, read from the stored history.

    The reply is the assistant's text messages of that turn in order; tool steps are the
    names of the tools it called. Read after the turn ends, so it is the same text a later
    `chat <CHAT_ID> history` shows.
    """
    hist = client.get(f"agents/{agent_id}/sessions/{session_id}/history")
    texts: Dict[str, str] = {}
    order: List[str] = []
    plain: List[str] = []
    steps: List[dict] = []
    for entry in hist.get("conversation") or []:
        if entry.get("role") == "user":
            continue
        if turn_id and entry.get("turn_id") != turn_id:
            continue
        for msg in entry.get("messages") or []:
            mtype = msg.get("type")
            content = msg.get("content")
            if mtype == "ag_ui_event":
                try:
                    evt = json.loads(content) if isinstance(content, str) else (content or {})
                except Exception:
                    continue
                etype = evt.get("type")
                if etype == "TextMessageContent":
                    mid = evt.get("messageId") or "_"
                    if mid not in texts:
                        texts[mid] = ""
                        order.append(mid)
                    texts[mid] += evt.get("delta") or ""
                elif etype == "ToolCallStart" and evt.get("toolCallName"):
                    steps.append({"name": evt["toolCallName"]})
            elif mtype in ("text", "agent_message") and isinstance(content, str) and content.strip():
                plain.append(content.strip())
    parts = [texts[m].strip() for m in order if texts[m].strip()] or plain
    return ("\n\n".join(parts) or None), steps


# ── Following a turn ─────────────────────────────────────────────────────────

def _stream_end(payload: Any) -> Optional[dict]:
    content = payload.get("content") if isinstance(payload, dict) else None
    if isinstance(content, dict) and content.get("type") == "Custom" \
            and content.get("name") == "stream_end":
        return content.get("value") or {}
    return None


def _is_run_finished(payload: Any) -> bool:
    content = payload.get("content") if isinstance(payload, dict) else None
    return isinstance(content, dict) and content.get("type") == "RunFinished"


def _finish(client, *, agent_id: str, session_id: str, turn_id: Optional[str],
            outcome: str, state: Optional[dict] = None, error: Optional[str] = None,
            state_tag: Optional[str] = None) -> TurnResult:
    """Build the result for a turn that has ended (or that the CLI stopped waiting for)."""
    result = TurnResult(session_id=session_id, agent_id=agent_id, turn_id=turn_id,
                        status=outcome, error=error, state_tag=state_tag)
    if outcome == "waiting":
        state = state or read_state(client, agent_id=agent_id, session_id=session_id)
        result.pending_question = state.get("pending")
        result.state_tag = state.get("state_tag") or state_tag
        if not result.pending_question:
            # The pause was resolved between the stream ending and this read.
            result.status = "completed"
    if result.status in ("completed", "waiting"):
        try:
            result.reply, result.tool_steps = turn_reply(
                client, agent_id=agent_id, session_id=session_id, turn_id=turn_id)
        except APIError as e:
            result.error = f"turn ended but its reply could not be read: {e}"
    return result


def follow_turn(client, *, agent_id: str, session_id: str, turn_id: str,
                timeout: float = 300.0,
                on_event: Optional[Callable[[Optional[str], Any], None]] = None) -> TurnResult:
    """Follow one turn to its end. Never sends anything.

    Ends on the stream's `stream_end`, or, when the stream closes without one, on the
    lock status. Reconnects with Last-Event-ID for as long as the lock says `processing`,
    until `timeout`; only reconnects in a row that deliver nothing end the wait early.
    """
    deadline = time.monotonic() + timeout
    last_id: Optional[str] = None
    silent = 0
    path = f"agents/{agent_id}/sessions/{session_id}/stream"

    while True:
        got_event = False
        run_finished_at: Optional[float] = None
        ended: Optional[dict] = None
        try:
            for event_id, payload in client.get_stream(path, params={"turn_id": turn_id},
                                                       last_event_id=last_id):
                got_event = True
                if event_id:
                    last_id = event_id
                if on_event:
                    on_event(event_id, payload)
                ended = _stream_end(payload)
                if ended is not None:
                    break
                if _is_run_finished(payload):
                    run_finished_at = time.monotonic()
                if time.monotonic() > deadline:
                    break
        except httpx.ReadTimeout:
            pass
        except APIError as e:
            if e.status_code != 0:      # 0 = connection dropped; anything else is a real answer
                raise

        if ended is not None:
            outcome = _LOCK_OUTCOME.get(ended.get("status"), "failed")
            return _finish(client, agent_id=agent_id, session_id=session_id, turn_id=turn_id,
                           outcome=outcome, state_tag=ended.get("state_tag"),
                           error=None if outcome != "failed" else f"turn ended: {ended.get('status')}")

        # The stream closed, went silent or we hit the deadline without a stream_end.
        state = read_state(client, agent_id=agent_id, session_id=session_id)
        lock = state.get("lock_status")
        if lock and lock != "processing":
            outcome = _LOCK_OUTCOME.get(lock, "failed")
            return _finish(client, agent_id=agent_id, session_id=session_id, turn_id=turn_id,
                           outcome=outcome, state=state, state_tag=state.get("state_tag"),
                           error=None if outcome != "failed" else f"turn ended: {lock}")
        if not lock and run_finished_at is not None:
            # A chat with no lock record (lost before the server fix): the run finished and
            # no stream_end will ever come. Give it a short grace, then decide from the read.
            wait = _NO_LOCK_GRACE_SECONDS - (time.monotonic() - run_finished_at)
            if wait > 0:
                time.sleep(min(wait, max(0.0, deadline - time.monotonic())))
                state = read_state(client, agent_id=agent_id, session_id=session_id)
            if not state.get("lock_status"):
                return _finish(client, agent_id=agent_id, session_id=session_id, turn_id=turn_id,
                               outcome="waiting" if state.get("pending") else "completed",
                               state=state, state_tag=state.get("state_tag"))
        if time.monotonic() >= deadline:
            return _finish(client, agent_id=agent_id, session_id=session_id, turn_id=turn_id,
                           outcome="wait_timeout", state_tag=state.get("state_tag"),
                           error=f"still running after {int(timeout)}s; the turn continues")
        silent = 0 if got_event else silent + 1
        if silent >= _MAX_SILENT_RECONNECTS:
            return _finish(client, agent_id=agent_id, session_id=session_id, turn_id=turn_id,
                           outcome="wait_timeout", state_tag=state.get("state_tag"),
                           error="stream unavailable; the turn may still be running")
        time.sleep(1.0)


# ── Sending ──────────────────────────────────────────────────────────────────

def _stopped(session_id: str, agent_id: str, status: str, state: dict) -> TurnResult:
    return TurnResult(session_id=session_id, agent_id=agent_id, turn_id=state.get("turn_id"),
                      status=status, message_sent=False, state_tag=state.get("state_tag"),
                      pending_question=state.get("pending") if status == "waiting" else None)


def send_and_wait(client, *, session_id: str, message: str, agent_id: Optional[str] = None,
                  context: Optional[dict] = None, answer: Optional[dict] = None,
                  wait: bool = True, timeout: float = 300.0,
                  on_event: Optional[Callable[[Optional[str], Any], None]] = None) -> TurnResult:
    """Send one message and, unless wait=False, follow the turn to its end.

    `answer` is the screen's `hitl_response` dict {checkpoint_id, tool_call_id, selected,
    values?}: when given, the message IS the answer to the open question. Without it, an
    open question stops the send (status `waiting`, message_sent False), because the server
    would take any message as the answer.

    A chat that is already running a turn: with wait=True that turn is followed first and
    the message is then sent once; with wait=False the result is `busy`.

    Raises APIError / AuthError for HTTP failures. Every turn outcome is returned, never
    raised; the caller exits with `result.exit_code`.
    """
    agent_id = require_agent_id(session_id, agent_id)
    deadline = time.monotonic() + timeout
    followed_other = False
    conflict_retried = False

    while True:
        state = read_state(client, agent_id=agent_id, session_id=session_id)
        if state.get("pending") and answer is None:
            return _stopped(session_id, agent_id, "waiting", state)
        running_turn = state.get("turn_id") if state.get("lock_status") == "processing" else None

        resp = None
        if not running_turn:
            metadata: Dict[str, Any] = {"input_mode": "text"}
            if answer:
                metadata["hitl_response"] = answer
            body: Dict[str, Any] = {
                "messages": [{"type": "text", "content": message, "metadata": metadata}],
                "session_id": session_id,
            }
            if context:
                body["context"] = context
            if state.get("state_tag"):
                body["expected_state_tag"] = state["state_tag"]
            try:
                resp = client.post(f"sessions/{session_id}/chat", json=body)
            except APIError as e:
                detail = e.detail if isinstance(e.detail, dict) else {}
                if e.status_code == 423:
                    running_turn = detail.get("turn_id") or read_state(
                        client, agent_id=agent_id, session_id=session_id).get("turn_id")
                    if not running_turn:
                        continue            # the lock was released between the two calls
                elif (e.status_code == 409 and detail.get("error") == "conversation_advanced"
                        and not conflict_retried):
                    conflict_retried = True
                    continue                # the chat moved on since the read; look again
                else:
                    raise

        if running_turn:
            if not wait or followed_other:
                return _stopped(session_id, agent_id, "busy", state)
            followed_other = True
            earlier = follow_turn(client, agent_id=agent_id, session_id=session_id,
                                  turn_id=running_turn,
                                  timeout=max(1.0, deadline - time.monotonic()))
            if earlier.status == "wait_timeout":
                earlier.message_sent = False
                return earlier
            continue                        # that turn ended; read the state again and send

        turn_id = (resp or {}).get("turn_id")
        answered = bool((resp or {}).get("resumed_from_checkpoint")) and answer is None
        if answered:
            click.echo("Warning: the assistant asked a question at the moment this message was "
                       "sent, and the server took the message as its answer.", err=True)
        if not wait or not turn_id:
            return TurnResult(session_id=session_id, agent_id=agent_id, turn_id=turn_id,
                              status="sent", state_tag=state.get("state_tag"),
                              answered_question=answered)
        result = follow_turn(client, agent_id=agent_id, session_id=session_id, turn_id=turn_id,
                             timeout=max(1.0, deadline - time.monotonic()), on_event=on_event)
        result.answered_question = answered
        return result


# ── Printing ─────────────────────────────────────────────────────────────────

def print_pending_question(question: dict, chat_id: str, err: bool = True) -> None:
    """The question the assistant asked, with the command that answers it."""
    def out(line: str = "") -> None:
        click.echo(line, err=err)

    out("  The assistant is waiting on your answer:")
    out(f"    {question.get('prompt') or '(no question text)'}")
    if question.get("description"):
        for line in str(question["description"]).splitlines():
            out(f"      {line}")
    options = question.get("options") or []
    for opt in options:
        out(f"      {opt.get('key')}. {opt.get('label')}")
    for f in question.get("fields") or []:
        req = "required" if f.get("required") else "optional"
        out(f"      field {f.get('name')} ({f.get('field_type') or 'text'}, {req}): {f.get('label') or ''}")
    waiting = _waiting_for(question.get("waiting_since"))
    if waiting:
        out(f"    Waiting: {waiting}")
    keys = [str(o.get("key")) for o in options]
    if keys == ["approve", "reject"]:
        out(f"  Answer with:  torana chat {chat_id} answer --approve   (or --reject --reason \"…\")")
    elif question.get("fields"):
        out(f"  Answer with:  torana chat {chat_id} answer --values '{{\"<field>\": \"<value>\"}}'")
    elif options:
        extra = "   (or --text \"…\")" if question.get("allow_free_text") else ""
        out(f"  Answer with:  torana chat {chat_id} answer --option {keys[0]}{extra}")
    else:
        out(f"  Answer with:  torana chat {chat_id} answer --text \"…\"")


def _waiting_for(since: Optional[str]) -> str:
    if not since:
        return ""
    try:
        start = datetime.fromisoformat(since.replace("Z", "+00:00"))
        secs = int((datetime.now(timezone.utc) - start).total_seconds())
    except Exception:
        return ""
    if secs < 60:
        return f"{secs}s"
    if secs < 3600:
        return f"{secs // 60}m"
    return f"{secs // 3600}h {secs % 3600 // 60}m"


def print_turn_result(result: TurnResult, *, fmt: str = "text", streamed: bool = False) -> None:
    """Print a turn's outcome. JSON goes to stdout whole; text puts the reply on stdout and
    everything about state (waiting, failed, busy) on stderr with the next command."""
    if fmt == "json":
        click.echo(json.dumps(result.to_json(), indent=2, default=str))
        return
    if fmt == "yaml":
        import yaml
        click.echo(yaml.safe_dump(result.to_json(), sort_keys=False, default_flow_style=False))
        return
    sid = result.session_id
    if result.reply and not streamed:
        click.echo(result.reply)
    if result.status == "completed":
        click.echo(f"\n[chat {sid}]", err=True)
    elif result.status == "sent":
        click.echo(f"Sent. Turn {result.turn_id} is running.\n"
                   f"  torana chat {sid} status      see whether it finished\n"
                   f"  torana chat {sid} history     read the reply", err=True)
    elif result.status == "waiting":
        if not result.message_sent:
            click.echo("\nNot sent: this chat is waiting on an answer from you, and any "
                       "message would be taken as that answer.", err=True)
        click.echo("", err=True)
        if result.pending_question:
            print_pending_question(result.pending_question, sid)
    elif result.status == "busy":
        click.echo(f"\nNot sent: a turn is already running in this chat (turn {result.turn_id}).\n"
                   f"  torana chat {sid} status      see when it finishes\n"
                   "  Leave out --no-wait to wait for it and then send.", err=True)
    elif result.status == "wait_timeout":
        prefix = "Not sent: " if not result.message_sent else ""
        click.echo(f"\n{prefix}{result.error or 'the turn is still running'}.\n"
                   f"  torana chat {sid} status      see whether it finished\n"
                   f"  torana chat {sid} history     read the reply once it has", err=True)
    else:
        word = {"failed": "failed", "timeout": "timed out on the server",
                "cancelled": "was cancelled"}.get(result.status, result.status)
        click.echo(f"\nThe turn {word}." + (f" ({result.error})" if result.error else "") +
                   f"\n  torana chat {sid} history     see what it did before that", err=True)


class StreamPrinter:
    """`--stream`: assistant text to stdout as it arrives, one line per tool step on stderr.

    With JSON output each event is printed as one JSON line instead (the result object
    follows as the last line).
    """

    def __init__(self, fmt: str = "text"):
        self.fmt = fmt
        self.printed_text = False
        self._names: Dict[str, str] = {}

    def __call__(self, event_id: Optional[str], payload: Any) -> None:
        if self.fmt == "json":
            click.echo(json.dumps({"event_id": event_id, "event": payload}, default=str))
            return
        content = payload.get("content") if isinstance(payload, dict) else None
        if not isinstance(content, dict):
            return
        etype = content.get("type")
        if etype == "TextMessageContent" and content.get("delta"):
            click.echo(content["delta"], nl=False)
            self.printed_text = True
        elif etype == "TextMessageEnd" and self.printed_text:
            click.echo("")
        elif etype == "ToolCallStart" and content.get("toolCallName"):
            click.echo(f"  · {content['toolCallName']}", err=True)


# ═══════════════════════════════════════════════════════════════════════════
# History rendering (moved from agent.py, where the old `chat get` used it)
# ═══════════════════════════════════════════════════════════════════════════

# ── Constants ────────────────────────────────────────────────────────────────

# Widgets that pause execution and require a human response
HITL_WIDGETS = {"ui_user_choice", "ui_form", "ui_confirmation", "ui_text_input", "ui_date_range"}

# Human-readable labels + icons for known widget types
WIDGET_LABELS = {
    "ui_bar_chart": ("📊", "Bar Chart"),
    "ui_line_chart": ("📈", "Line Chart"),
    "ui_pie_chart": ("🥧", "Pie Chart"),
    "ui_table": ("📋", "Table"),
    "ui_scalar": ("🔢", "Scalar"),
    "ui_gauge": ("🎯", "Gauge"),
    "ui_heatmap": ("🌡", "Heatmap"),
    "ui_treemap": ("🗂", "Treemap"),
    "ui_radar": ("📡", "Radar"),
    "ui_sankey": ("〰", "Sankey"),
    "ui_funnel": ("🔽", "Funnel"),
    "ui_scatter": ("⠿", "Scatter"),
    "ui_timeline": ("📅", "Timeline"),
    "ui_calendar_heatmap": ("📆", "Calendar Heatmap"),
    "ui_waterfall": ("🌊", "Waterfall"),
    "ui_boxplot": ("📦", "Boxplot"),
    "ui_status_card": ("🃏", "Status Card"),
    "ui_markdown_display": ("📝", "Markdown"),
    "ui_code_display": ("💻", "Code"),
    "ui_plan_display": ("📋", "Plan"),
    "ui_plan_tracker": ("✅", "Plan Tracker"),
    "ui_user_choice": ("❓", "Choice"),
    "ui_form": ("📝", "Form"),
    "ui_confirmation": ("✅", "Confirmation"),
    "ui_text_input": ("💬", "Text Input"),
    "ui_date_range": ("📅", "Date Range"),
    "emit_status": ("💬", "Status"),
}


def _widget_label(tool_name: str) -> tuple[str, str]:
    """Return (icon, label) for a widget tool name."""
    return WIDGET_LABELS.get(tool_name, ("🔧", tool_name))


def _widget_title(tool_name: str, args: dict) -> str:
    """Extract a human-readable title from widget args."""
    # Try common title fields in order of preference
    for field in ("title", "question", "header", "label", "prompt", "content"):
        val = args.get(field)
        if val and isinstance(val, str):
            return val[:80] + ("…" if len(val) > 80 else "")
    return ""


# ── Helpers ───────────────────────────────────────────────────────────────────

def _fmt_ts(ts: str | None) -> str:
    """Format ISO timestamp to HH:MM:SS local."""
    if not ts:
        return "—"
    try:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        local = dt.astimezone()
        return local.strftime("%H:%M:%S")
    except Exception:
        return ts[:19]


def _fmt_ts_full(ts: str | None) -> str:
    """Format ISO timestamp to full local datetime."""
    if not ts:
        return "—"
    try:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        local = dt.astimezone()
        return local.strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return ts[:19]


def _fmt_epoch(ts) -> str:
    """Format a Unix epoch (int/float/numeric str) as local 'YYYY-MM-DD HH:MM:SS'.

    The sessions endpoint returns created/last_update as epoch FLOATS, not ISO
    strings, so `_fmt_ts_full` (which parses ISO) cannot read them — it would
    fall through to its except branch and print the raw float sliced to 19
    chars. Keep this separate rather than widening the ISO parser: a bare
    number is a distinct wire shape, not a malformed ISO string.
    """
    if ts is None or ts == "":
        return "—"
    try:
        return datetime.fromtimestamp(float(ts)).astimezone().strftime("%Y-%m-%d %H:%M:%S")
    except (ValueError, OSError, OverflowError, TypeError):
        return str(ts)


def _elapsed(since_ts: str | None) -> str:
    """Human-readable elapsed time since ISO timestamp."""
    if not since_ts:
        return ""
    try:
        dt = datetime.fromisoformat(since_ts.replace("Z", "+00:00"))
        secs = int((datetime.now(timezone.utc) - dt).total_seconds())
        if secs < 60:
            return f"{secs}s"
        elif secs < 3600:
            return f"{secs // 60}m {secs % 60}s"
        else:
            return f"{secs // 3600}h {(secs % 3600) // 60}m"
    except Exception:
        return ""


def _duration(start: str | None, end: str | None) -> str:
    """Format duration between two ISO timestamps."""
    if not start or not end:
        return ""
    try:
        s = datetime.fromisoformat(start.replace("Z", "+00:00"))
        e = datetime.fromisoformat(end.replace("Z", "+00:00"))
        secs = (e - s).total_seconds()
        if secs < 60:
            return f"{secs:.1f}s"
        else:
            return f"{secs // 60:.0f}m {secs % 60:.0f}s"
    except Exception:
        return ""



def _parse_session_messages(data: dict) -> dict:
    """Parse the audit/sessions/{sid}/messages response into a structured summary."""
    messages = data.get("messages", [])
    trace_summary = data.get("trace_summary", [])
    pending_checkpoint_id = data.get("pending_checkpoint_id")
    session_status = data.get("session_status", "unknown")

    # Build a map from otel_trace_id -> turn for matching ag_ui events to turns
    # trace_summary entries carry trace_id which matches otel_trace_id on messages
    trace_to_turn: dict[str, dict] = {}
    turns = []

    for m in messages:
        mtype = m.get("message_type", "")
        role = m.get("role", "")
        ts = m.get("timestamp") or m.get("created_at", "")
        otel = m.get("otel_trace_id", "")
        msg_turn_id = m.get("turn_id", "")

        if role == "user" and mtype == "text":
            turn = {
                "turn_id": msg_turn_id,
                "otel_trace_id": otel,
                "user": {"text": m.get("content", ""), "sent_at": ts},
                "agent_text": "",
                "widgets": [],          # list of rendered widget dicts
                "hitl_tool_call": None,
                "_tool_call_args": {},  # tcid -> {name, args, ts}
                "_text_messages": {},   # mid -> accumulated text
                "is_hitl_resume": False,
            }
            turns.append(turn)
            if otel:
                trace_to_turn[otel] = turn

    # Synthesize turns for trace_summary entries that have no user message
    # (HITL-resume turns: agent-side turn triggered by HITL response, no user text message)
    user_otels = set(trace_to_turn.keys())
    for tr in trace_summary:
        tid = tr.get("trace_id", "")
        if tid and tid not in user_otels:
            turn = {
                "turn_id": tr.get("turn_id", ""),
                "otel_trace_id": tid,
                "user": None,           # no user message — HITL resume
                "agent_text": "",
                "widgets": [],
                "hitl_tool_call": None,
                "_tool_call_args": {},
                "_text_messages": {},
                "is_hitl_resume": True,
            }
            turns.append(turn)
            trace_to_turn[tid] = turn

    # Sort turns by started_at from trace_summary so HITL-resume turns appear in order
    def _turn_sort_key(t: dict) -> str:
        otel = t.get("otel_trace_id", "")
        matched = next((tr for tr in trace_summary if tr.get("trace_id", "") == otel), None)
        return (matched or {}).get("started_at", "") or t.get("user", {}) and t["user"].get("sent_at", "") or ""

    turns.sort(key=_turn_sort_key)

    # Second pass: attach ag_ui_events to the correct turn via otel_trace_id
    for m in messages:
        mtype = m.get("message_type", "")
        if mtype != "ag_ui_event":
            continue
        otel = m.get("otel_trace_id", "")
        ts = m.get("timestamp") or m.get("created_at", "")
        turn = trace_to_turn.get(otel)
        if turn is None:
            continue

        try:
            evt = json.loads(m.get("content", "{}"))
        except Exception:
            continue
        etype = evt.get("type", "")

        if etype == "ToolCallStart":
            tcid = evt.get("toolCallId", "")
            tcname = evt.get("toolCallName", "")
            turn["_tool_call_args"][tcid] = {"name": tcname, "args": "", "ts": ts}

        elif etype == "ToolCallArgs":
            tcid = evt.get("toolCallId", "")
            if tcid in turn["_tool_call_args"]:
                turn["_tool_call_args"][tcid]["args"] += evt.get("delta", "")

        elif etype == "TextMessageContent":
            mid = evt.get("messageId", "")
            turn["_text_messages"][mid] = (
                turn["_text_messages"].get(mid, "") + evt.get("delta", "")
            )

    # Post-process: collapse text messages, build widget list, detect HITL, attach trace info
    for i, turn in enumerate(turns):
        # Collapse accumulated text per turn
        turn["agent_text"] = " ".join(turn["_text_messages"].values()).strip()
        del turn["_text_messages"]

        # Build ordered widget list + detect HITL tool call
        for tcid, info in turn["_tool_call_args"].items():
            name = info["name"]
            if not name.startswith("ui_") and name not in ("emit_status",):
                continue
            try:
                args = json.loads(info["args"]) if info["args"] else {}
            except Exception:
                args = {}
            widget_entry = {
                "tool_call_id": tcid,
                "widget": name,
                "args": args,
                "ts": info["ts"],
            }
            turn["widgets"].append(widget_entry)
            # First HITL widget found becomes the hitl_tool_call
            if name in HITL_WIDGETS and turn["hitl_tool_call"] is None:
                turn["hitl_tool_call"] = widget_entry
        del turn["_tool_call_args"]

        # Attach trace info by matching otel_trace_id to trace_summary entries
        otel = turn.get("otel_trace_id", "")
        matched_trace = next(
            (tr for tr in trace_summary if tr.get("trace_id", "") == otel), None
        )
        if matched_trace:
            raw_status = matched_trace.get("execution_status", "")
            outcome = matched_trace.get("outcome", "")
            # Backend leaves execution_status=RUNNING / ended_at=None for hitl_pause turns.
            # Treat hitl_pause as a terminal state, not "still running".
            if outcome == "hitl_pause" and raw_status == "RUNNING":
                raw_status = "HITL_PAUSE"
            turn["trace"] = {
                "trace_id": matched_trace.get("trace_id", ""),
                "outcome": outcome,
                "status": raw_status,
                "started_at": matched_trace.get("started_at"),
                "ended_at": matched_trace.get("ended_at"),
                "duration_seconds": matched_trace.get("duration_seconds"),
            }
        else:
            turn["trace"] = None

    return {
        "session_id": data.get("session_id", ""),
        "session_status": session_status,
        "agent_id": data.get("agent_id", ""),
        "agent_name": data.get("agent_name", ""),
        "pending_checkpoint_id": pending_checkpoint_id,
        "turns": turns,
        "raw_trace_summary": trace_summary,
    }


def _wrap_indent(text: str, indent: str = "  ", width: int = 76) -> str:
    """Wrap text at width, preserving newlines, with a hanging indent."""
    import textwrap
    lines = text.splitlines()
    out = []
    for line in lines:
        if len(line) <= width:
            out.append(indent + line)
        else:
            wrapped = textwrap.fill(line, width=width, initial_indent=indent,
                                    subsequent_indent=indent)
            out.append(wrapped)
    return "\n".join(out)


def _print_chat_get_text(parsed: dict, detail: bool, last: int | None) -> None:
    """Render chat get as human-readable text."""
    turns = parsed["turns"]
    if last is not None:
        turns = turns[-last:] if last < len(turns) else turns

    pending_id = parsed["pending_checkpoint_id"]

    if not turns:
        click.echo("No messages yet.")
        return

    W = 72  # separator width

    for i, turn in enumerate(turns):
        user = turn.get("user", {})
        trace = turn.get("trace") or {}
        outcome = trace.get("outcome", "")
        status = trace.get("status", "")
        started = trace.get("started_at")
        ended = trace.get("ended_at")
        duration = trace.get("duration_seconds")
        agent_text = turn.get("agent_text", "")
        widgets = turn.get("widgets", [])
        hitl = turn.get("hitl_tool_call")
        is_hitl_resume = turn.get("is_hitl_resume", False)

        if i > 0:
            click.echo()

        # ── USER block ──────────────────────────────────────────────────────
        user_ts = _fmt_ts(user.get("sent_at") if user else started)
        user_text = (user.get("text", "") if user else "").strip()

        if is_hitl_resume:
            click.echo(f"  YOU  [{_fmt_ts(started)}]  HITL response submitted")
        else:
            click.echo(f"  YOU  [{user_ts}]")
            if user_text:
                click.echo(_wrap_indent(user_text, "    "))

        click.echo()

        # ── AGENT block ─────────────────────────────────────────────────────
        truly_running = (status == "RUNNING") and outcome not in ("hitl_pause", "completed", "error")

        if truly_running and not ended:
            elapsed = _elapsed(started)
            click.echo(f"  AGENT  ⏳ processing...  ({elapsed} elapsed)")
            if detail and trace.get("trace_id"):
                click.echo(f"    Turn: {trace['trace_id']}")

        elif agent_text or widgets:
            dur_str = f"{duration:.1f}s" if duration else _duration(started, ended)
            status_tag = f"✓  {dur_str}" if dur_str else "✓"
            click.echo(f"  AGENT  [{_fmt_ts(ended or started)}]  {status_tag}")

            if agent_text:
                click.echo(_wrap_indent(agent_text, "    "))
                if widgets:
                    click.echo()

            for w in widgets:
                wname = w["widget"]
                if wname == "emit_status":
                    continue
                icon, label = _widget_label(wname)
                args = w.get("args", {})
                title = _widget_title(wname, args)

                # Header line for widget
                title_str = f"  {title}" if title else ""
                click.echo(f"    {icon}  {label}{title_str}")

                # Show widget body content where useful
                if wname == "ui_markdown_display":
                    body = args.get("content", args.get("markdown", ""))
                    if body:
                        # First 8 lines only unless --detail
                        lines = body.strip().splitlines()
                        limit = len(lines) if detail else min(8, len(lines))
                        for ln in lines[:limit]:
                            click.echo(f"       {ln}")
                        if not detail and len(lines) > limit:
                            click.echo(f"       … ({len(lines) - limit} more lines — use --detail)")
                elif wname in ("ui_user_choice", "ui_confirmation"):
                    prompt = args.get("prompt", args.get("message", ""))
                    choices = args.get("choices", args.get("options", []))
                    if prompt:
                        click.echo(f"       {prompt}")
                    if choices:
                        for idx, ch in enumerate(choices, 1):
                            label_text = ch if isinstance(ch, str) else ch.get("label", str(ch))
                            click.echo(f"       {idx}. {label_text}")
                elif wname == "ui_form":
                    prompt = args.get("prompt", args.get("title", ""))
                    if prompt:
                        click.echo(f"       {prompt}")
                    for field in args.get("fields", []):
                        fname = field.get("label", field.get("name", ""))
                        click.echo(f"       • {fname}")

            if detail and trace.get("trace_id"):
                click.echo()
                click.echo(f"    Turn: {trace['trace_id']}")

        elif outcome == "hitl_pause" or status == "HITL_PAUSE" or hitl:
            click.echo(f"  AGENT  [{_fmt_ts(started)}]  ⏸  paused — waiting for your input")

        click.echo()
        click.echo("  " + "─" * W)

    # ── HITL action block ────────────────────────────────────────────────────
    last_turn = turns[-1] if turns else {}
    hitl = last_turn.get("hitl_tool_call")
    last_trace = (last_turn.get("trace") or {})
    last_outcome = last_trace.get("outcome", "")

    if hitl and (pending_id or last_outcome == "hitl_pause"):
        args = hitl.get("args", {})
        prompt = args.get("prompt", "")
        choices = args.get("choices", args.get("options", []))
        widget = hitl.get("widget", "")
        waiting = _elapsed(hitl.get("ts"))
        aid = parsed.get("agent_id", "<AGENT_ID>")
        sid = parsed.get("session_id", "<SESSION_ID>")

        click.echo()
        click.echo("  ┌─ WAITING FOR YOUR INPUT " + "─" * (W - 24) + "┐")
        if prompt:
            click.echo(f"  │  {prompt}")
        if choices:
            for idx, ch in enumerate(choices, 1):
                ch_label = ch if isinstance(ch, str) else ch.get("label", str(ch))
                click.echo(f"  │    {idx}. {ch_label}")
        if waiting:
            click.echo(f"  │  Waiting: {waiting}")
        click.echo(f"  │")
        click.echo(f"  │  Respond:")
        click.echo(f"  │    torana chat {sid} answer --option <N>")
        click.echo("  └" + "─" * (W - 1) + "┘")


def _build_chat_get_json(parsed: dict, detail: bool, last: int | None) -> dict:
    """Build structured JSON for chat get."""
    turns = parsed["turns"]
    if last is not None:
        turns = turns[-last:] if last < len(turns) else turns

    out_turns = []
    for i, turn in enumerate(turns):
        trace = turn.get("trace") or {}
        status = trace.get("status", "")
        started = trace.get("started_at")
        ended = trace.get("ended_at")
        duration = trace.get("duration_seconds")

        t = {
            "index": i + 1,
            "user": {
                "text": turn["user"].get("text", ""),
                "sent_at": turn["user"].get("sent_at"),
            },
            "agent": {
                "status": "running" if status == "RUNNING" else ("completed" if ended else "paused"),
                "started_at": started,
                "completed_at": ended,
                "duration_seconds": duration,
            },
        }

        if turn.get("agent_text"):
            t["agent"]["text"] = turn["agent_text"]

        # Widgets — always include terse summary; full args only with --detail
        turn_widgets = turn.get("widgets", [])
        if turn_widgets:
            if detail:
                t["agent"]["widgets"] = [
                    {
                        "widget": w["widget"],
                        "title": _widget_title(w["widget"], w.get("args", {})),
                        "args": w.get("args", {}),
                        "ts": w.get("ts"),
                    }
                    for w in turn_widgets
                ]
            else:
                t["agent"]["widgets"] = [
                    {
                        "widget": w["widget"],
                        "title": _widget_title(w["widget"], w.get("args", {})),
                    }
                    for w in turn_widgets
                ]

        if detail:
            t["turn_id"] = trace.get("trace_id", "")
            t["agent"]["outcome"] = trace.get("outcome", "")
            if status == "RUNNING":
                t["agent"]["elapsed_seconds"] = None
                try:
                    s = datetime.fromisoformat(started.replace("Z", "+00:00"))
                    t["agent"]["elapsed_seconds"] = int(
                        (datetime.now(timezone.utc) - s).total_seconds()
                    )
                except Exception:
                    pass

        out_turns.append(t)

    result = {
        "session_id": parsed["session_id"],
        "session_status": parsed["session_status"],
        "agent_id": parsed["agent_id"],
        "agent_name": parsed["agent_name"],
        "turns": out_turns,
    }

    # HITL block
    last_turn = (parsed["turns"][-last:] if last else parsed["turns"])
    if last_turn:
        last_t = last_turn[-1]
        hitl = last_t.get("hitl_tool_call")
        last_outcome = (last_t.get("trace") or {}).get("outcome", "")
        pending_id = parsed["pending_checkpoint_id"]

        if hitl and (pending_id or last_outcome == "hitl_pause"):
            args = hitl.get("args", {})
            hitl_block = {
                "widget": hitl.get("widget"),
                "prompt": args.get("prompt"),
                "options": args.get("choices", args.get("options", [])),
                "checkpoint_id": pending_id,
                "waiting_since": hitl.get("ts"),
            }
            if detail:
                try:
                    s = datetime.fromisoformat(hitl["ts"].replace("Z", "+00:00"))
                    hitl_block["waiting_seconds"] = int(
                        (datetime.now(timezone.utc) - s).total_seconds()
                    )
                except Exception:
                    pass
                hitl_block["tool_call_id"] = hitl.get("tool_call_id")
            result["hitl_pending"] = hitl_block

    return result
