"""torana playbooks — playbook management commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW, CollectionGroup
from torana_cli.output import output
from torana_cli.rules import _load_input_file

_LIST_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 40),
    ("status", "STATUS", 12),
    ("description", "DESCRIPTION", 40),
]


def _list_filters(state, search):
    """Build the v2 SelectFields `filters` JSON for the playbooks list endpoint.

    The v2 endpoint (api/v2/playbooks) consumes a single JSON `filters` query string
    (FilterClause map), NOT flat state=/search= params. Map the user-facing flags onto
    the fields the endpoint declares: status (equals) and name (contains, ci).
    """
    import json
    clauses = {}
    if state:
        clauses["status"] = {"operation": "equals", "value": state}
    if search:
        clauses["name"] = {"operation": "contains_ignore_case", "value": search}
    return json.dumps(clauses) if clauses else None


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


@click.group(cls=CollectionGroup, singular="playbook")
def playbooks():
    """Manage playbooks.

    \b
    Instance commands (get, update, delete, execute, etc.) are under:
      torana playbook <UUID> <verb>

    \b
    Examples:
      torana playbooks list
      torana playbooks create --file playbook.yaml
    """


@playbooks.command(name="list")
@click.option("--workspace-id", default=None, help="Filter by workspace UUID.")
@click.option("--state", default=None, help="Filter by state.")
@click.option("--search", default=None, help="Search by name.")
@click.option("--page", default=1, show_default=True)
@click.option("--page-size", default=None, type=int)
@click.option("--all", "fetch_all", is_flag=True, default=False)
@click.pass_context
def playbooks_list(ctx, workspace_id, state, search, page, page_size, fetch_all):
    """List playbooks.

    \b
    Examples:
      torana playbooks list
      torana playbooks list --state active --search ransomware
      torana playbooks list --workspace-id <UUID>
      torana playbooks list --json | jq '.items[] | {name, state}'
    """
    list_playbooks_core(ctx, workspace_id=workspace_id, state=state, search=search,
                        page=page, page_size=page_size, fetch_all=fetch_all)


def list_playbooks_core(ctx, *, workspace_id=None, state=None, search=None,
                        page=1, page_size=None, fetch_all=False):
    """Shared playbooks-list routine.

    `torana playbooks list` and `torana workspace <id> playbooks list` both call
    this. When `workspace_id` is bound, the workspace-scoped endpoint is used;
    otherwise the global one. Single source of truth.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)

    # The workspace-scoped endpoint `workspaces/{id}/playbooks` returns 0 rows even
    # for a workspace that plainly holds playbooks, so a scoped read looked empty.
    # Every row on the tenant-wide listing carries `workspace_id`, so scope by
    # filtering that instead — an empty result then means "none", not "not asked".
    endpoint = "api/v2/playbooks"

    effective_page_size = min(page_size or settings.page_size, 100)
    params = {"page": page, "page_size": effective_page_size}
    filters_json = _list_filters(state, search)
    if filters_json:
        params["filters"] = filters_json

    # Scoping happens client-side, so every page must be read before filtering —
    # otherwise a workspace's rows beyond page 1 vanish silently.
    if workspace_id:
        fetch_all = True

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {"page": page_num, "page_size": effective_page_size}
                p.update({k: v for k, v in params.items() if k not in ("page", "page_size")})
                data = client.get(endpoint, params=p)
                items = data.get("items", [])
                all_items.extend(items)
                if len(all_items) >= data.get("total", len(all_items)):
                    break
                page_num += 1
            result = {"items": all_items, "total": len(all_items), "page": 1,
                      "page_size": len(all_items)}
        else:
            result = client.get(endpoint, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # The workspace-scoped endpoint nests rows under "playbooks"; normalize to
    # the {items, total, ...} envelope output() expects.
    if isinstance(result, dict) and "items" not in result and "playbooks" in result:
        result = {"items": result.get("playbooks", []), "total": result.get("total", 0),
                  "page": page, "page_size": effective_page_size}

    if workspace_id and isinstance(result, dict):
        scoped = [pb for pb in result.get("items", [])
                  if str(pb.get("workspace_id") or "") == str(workspace_id)]
        result = {"items": scoped, "total": len(scoped), "page": 1,
                  "page_size": len(scoped)}

    output(result, fmt=fmt, raw=raw, fields=fields, columns=_LIST_COLS)


@playbooks.command(name="create")
@click.option("--name", default=None)
@click.option("--description", default=None)
@click.option("--file", "input_file", default=None, metavar="FILE")
@click.pass_context
def playbooks_create(ctx, name, description, input_file):
    """Create a new playbook.

    \b
    Examples:
      torana playbooks create --file playbook.yaml
      torana playbooks create --name "Ransomware triage" --description "..."

    \b
      A playbook is created in `draft`; publish it before it can execute:
        torana playbook <PLAYBOOK_ID> publish
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"

    body = {}
    if input_file:
        body = _load_input_file(input_file)
    if name:
        body["name"] = name
    if description:
        body["description"] = description

    if not body.get("name"):
        click.echo("ERROR: --name is required (or provide --file with 'name' field).", err=True)
        import sys
        sys.exit(2)

    client = _client(ctx)
    try:
        data = client.post("playbooks/", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text":
        output(data, fmt=fmt)
    else:
        click.echo(f"Created playbook: {data.get('id', 'unknown')}")
        click.echo(f"  Name: {data.get('name', '')}")


@playbooks.command(name="all")
@click.option("--page", default=1, show_default=True, help="Page number.")
@click.option("--page-size", "page_size", default=None, type=int, help="Results per page (max 100).")
@click.option("--all", "fetch_all", is_flag=True, default=False, help="Auto-paginate and return all results.")
@click.option("--status", "status", default=None, help="Filter by status")
@click.option("--limit", "limit", type=int, default=50, help="Max results")
@click.option("--offset", "offset", type=int, default=0, help="Pagination offset")
@click.pass_context
def playbooks_all(ctx, status, limit, offset, page, page_size, fetch_all):
    """List All Executions."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    path = "playbooks/executions/all"
    params = {}
    if status is not None:
        params["status"] = status
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    effective_page_size = min(page_size or settings.page_size, 100)
    params["skip"] = (page - 1) * effective_page_size
    params["limit"] = effective_page_size

    client = _client(ctx)
    try:
        if fetch_all:
            all_items = []
            page_num = 1
            while True:
                p = {**params, "skip": (page_num - 1) * effective_page_size, "limit": effective_page_size}
                data = client.get(path, params=p)
                items = data.get('items', data) if isinstance(data, dict) else data
                all_items.extend(items)
                total = data.get('total', len(items)) if isinstance(data, dict) else len(items)
                if len(all_items) >= total:
                    break
                page_num += 1
            data = {"items": all_items, "total": len(all_items)}
        else:
            data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields, raw=raw)


# ──────────────────────────────────────────────────────────────────────────
# Instance reads regrouped from `<noun>-by-<param>` leaves onto verbs
# (CLI Discoverability Contract, rule 2 — see ../CLAUDE.md). The route
# parameter belongs in the positional ARGUMENT, not the command name.
#
# Old flat names remain as HIDDEN aliases for ONE release (D4).
# ──────────────────────────────────────────────────────────────────────────


@playbooks.group(name="execution")
def playbooks_execution_grp():
    """One playbook execution, by id.

    Examples:
      torana playbooks execution get --help
    """


@playbooks_execution_grp.command(name="get")
@click.argument("EXECUTION_ID", metavar="EXECUTION_ID")
@click.pass_context
def playbooks_executions_by_execution_id(ctx, execution_id):
    """Get Execution."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"playbooks/executions/{execution_id}"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@playbooks.command(name="logs")
@click.argument("EXECUTION_ID", metavar="EXECUTION_ID")
@click.pass_context
def playbooks_logs(ctx, execution_id):
    """Get Execution Logs."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"playbooks/executions/{execution_id}/logs"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@playbooks.command(name="cancel")
@click.argument("EXECUTION_ID", metavar="EXECUTION_ID")
@click.pass_context
def playbooks_cancel(ctx, execution_id):
    """Cancel Execution."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = f"playbooks/executions/{execution_id}/cancel"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@playbooks.command(name="validate")
@click.option("--workspace-id", "workspace_id", default=None)
@click.option("--id", "id", default=None)
@click.option("--name", "name", required=True)
@click.option("--description", "description", default=None)
@click.option("--semantic-description", "semantic_description", default=None)
@click.option("--input-parameters", "input_parameters", default=None)
@click.option("--instructions", "instructions", required=True)
@click.option("--template-variables", "template_variables", default=None)
@click.option("--author", "author", default=None)
@click.option("--tags", "tags", default=None)
@click.option("--category", "category", default=None)
@click.option("--status", "status", type=click.Choice(["draft", "active", "archived"], case_sensitive=False), default=None, help="Playbook status.")
@click.option("--version", "version", default="1.0.0")
@click.option("--agent-config", "agent_config", default=None, help="AI agent configuration.")
@click.option("--created-at", "created_at", default=None)
@click.option("--updated-at", "updated_at", default=None)
@click.option("--published-at", "published_at", default=None)
@click.option("--created-by", "created_by", default=None)
@click.option("--execution-count", "execution_count", type=int, default=0)
@click.option("--last-executed-at", "last_executed_at", default=None)
@click.pass_context
def playbooks_validate(ctx, workspace_id, id, name, description, semantic_description, input_parameters, instructions, template_variables, author, tags, category, status, version, agent_config, created_at, updated_at, published_at, created_by, execution_count, last_executed_at):
    """Validate Playbook."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    path = "playbooks/validate"
    body = {}
    if workspace_id is not None:
        body["workspace_id"] = workspace_id
    if id is not None:
        body["id"] = id
    body["name"] = name
    if description is not None:
        body["description"] = description
    if semantic_description is not None:
        body["semantic_description"] = semantic_description
    if input_parameters is not None:
        body["input_parameters"] = input_parameters
    body["instructions"] = instructions
    if template_variables is not None:
        body["template_variables"] = template_variables
    if author is not None:
        body["author"] = author
    if tags is not None:
        body["tags"] = tags
    if category is not None:
        body["category"] = category
    if status is not None:
        body["status"] = status
    if version is not None:
        body["version"] = version
    if agent_config is not None:
        body["agent_config"] = agent_config
    if created_at is not None:
        body["created_at"] = created_at
    if updated_at is not None:
        body["updated_at"] = updated_at
    if published_at is not None:
        body["published_at"] = published_at
    if created_by is not None:
        body["created_by"] = created_by
    if execution_count is not None:
        body["execution_count"] = execution_count
    if last_executed_at is not None:
        body["last_executed_at"] = last_executed_at

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@playbooks.command(name="render-template")
@click.option("--file", "-f", "input_file", default=None, help="JSON/YAML file with template body.")
@click.pass_context
def playbooks_render_template(ctx, input_file):
    """Preview template variable rendering (dry-run, no persistence)."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    body = _load_input_file(input_file) if input_file else {}

    client = _client(ctx)
    try:
        data = client.post("playbooks/render", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


# ──────────────────────────────────────────────────────────────────────────
# BACK-COMPAT — hidden aliases for the old `<noun>-by-<param>` names.
# ⏳ ONE RELEASE ONLY (decision D4). Delete this block next release.
# ──────────────────────────────────────────────────────────────────────────

_LEGACY_BY_PARAM_PLAYBOOKS = {
    "executions-by-execution-id": ("execution", "get"),
}


def _register_legacy_playbooks_by_param() -> None:
    """Old flat names, hidden so they cannot be discovered anew."""
    import copy
    for _old, (_sub, _verb) in _LEGACY_BY_PARAM_PLAYBOOKS.items():
        _grp = playbooks.commands.get(_sub)
        if not isinstance(_grp, click.Group):
            continue
        _cmd = _grp.commands.get(_verb)
        if _cmd is None:
            continue
        # ⛔ Never let an alias overwrite a real group of the same name.
        if isinstance(playbooks.commands.get(_old), click.Group):
            continue
        _alias = copy.copy(_cmd)
        _alias.name = _old
        _alias.hidden = True
        playbooks.add_command(_alias)


_register_legacy_playbooks_by_param()
