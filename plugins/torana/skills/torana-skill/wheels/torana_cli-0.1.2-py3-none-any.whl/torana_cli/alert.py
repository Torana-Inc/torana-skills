"""torana alert <ALERT_ID> — instance-scoped alert commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.confirm import confirm as _confirm


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _aid(ctx) -> str:
    return ctx.obj.get("_alert_id", "") if ctx.obj else ""


@click.group(name="alert", invoke_without_command=True)
@click.argument("alert_id", metavar="ALERT_ID")
@click.pass_context
def alert(ctx, alert_id):
    """Manage a single alert by ID.

    \b
    Examples:
      torana alert <UUID> get
      torana alert <UUID> status --status closed --resolution-reason wont_fix
      torana alert <UUID> reopen --message "still reported"
      torana alert <UUID> keep-closed
      torana alert <UUID> assign --assigned-to <user-id>
      torana alert <UUID> verdict --triage-verdict true_positive
      torana alert <UUID> delete --yes
    """
    ctx.ensure_object(dict)
    ctx.obj["_alert_id"] = alert_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def _activity_actor(row) -> str:
    """`actor_type` plus a short id — who did this, in one column."""
    kind = (row.get("actor_type") or "").lower()
    who = row.get("actor_id") or row.get("user_id") or ""
    extra = (row.get("extra_data") or {}) if isinstance(row.get("extra_data"), dict) else {}
    if kind == "system" and extra.get("rule_id"):
        return "the ranking"
    if not kind:
        return ""
    return f"{kind}:{str(who)[:8]}" if who else kind


#: What a person needs to see about a member: is it done, and what was decided.
_MEMBER_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 40),
    ("severity", "SEVERITY", 10),
    ("triage_priority", "PRIO", 6),
    ("status", "STATUS", 20),
    ("triage_verdict", "VERDICT", 15),
    ("reason_code", "REASON", 24),
]


def _print_alert_head(data) -> None:
    """The six things a person opens an alert to find, before the raw keys."""
    verdict = data.get("triage_verdict") or "(not yet judged)"
    code = data.get("reason_code")
    actor_type = (data.get("verdict_actor_type") or "").lower()
    actor_id = data.get("verdict_actor_id") or ""
    if actor_type == "system" and str(actor_id).startswith("rule:"):
        decided_by = "the ranking"
    elif actor_type:
        decided_by = f"{actor_type} {str(actor_id)[:8]}" if actor_id else actor_type
    else:
        decided_by = ""
    verdict_line = verdict + (f"  [{code}]" if code else "") + (f"  — by {decided_by}" if decided_by else "")

    fix = data.get("proposed_fix") or data.get("remediation_summary") or ""
    fix_src = {"rule": "from the ranking", "agent": "from the triage agent",
               "user": "written by a person"}.get(data.get("proposed_fix_source") or "", "")
    if fix and fix_src:
        fix = f"{fix}  ({fix_src})"

    _box = {"needs_attention": "Needs attention", "closed": "Closed",
            "moved": "Moved"}.get(data.get("box") or "", data.get("box") or "")
    # Row 3.24 — "Was: <verdict>" when a platform closure changed it.
    kept = data.get("verdict_before_close") or {}
    if kept and data.get("status") in ("closed", "resolved"):
        verdict_line += f"  (was {kept.get('verdict') or 'no verdict'})"
    status_line = data.get("status") or ""
    if data.get("closed_by_display_name"):
        # Row 3.23: who closed it and why, on every closed row.
        status_line += f"  — by {data['closed_by_display_name']}"
        if data.get("resolution_reason"):
            status_line += f" ({data['resolution_reason']})"
    rows = [
        ("NAME", data.get("name") or ""),
        ("SEVERITY", data.get("severity") or ""),
        ("BOX", _box),
        ("WHY", data.get("why_label") or "—"),
        ("STATUS", status_line),
        ("VERDICT", verdict_line),
    ]
    # What the agent found and where, for a closure on evidence the platform does not
    # hold. Only shown when present, so an ordinary alert's output is unchanged.
    if data.get("verdict_evidence"):
        rows.append(("EVIDENCE", data["verdict_evidence"]))
    rows += [
        ("PROPOSED FIX", fix or "(none)"),
        ("DESCRIPTION", (data.get("description") or "").strip()),
    ]
    # ⭐ WHY IT CLOSED, when the LIFECYCLE closed it. An operator who finds work gone from
    # their queue has no other record of what removed it — the reason code alone is a
    # word, not an account. Only shown when the lifecycle acted, so an ordinary alert's
    # output is unchanged.
    ev = data.get("lifecycle_evidence") or {}
    if ev:
        reason = ev.get("resolution_reason") or ""
        sentence = ev.get("reason_sentence") or ev.get("reason_label") or ev.get("why") or ""
        seen = (ev.get("observed_at") or "")[:19].replace("T", " ")
        line = reason + (f" — {sentence}" if sentence else "")
        if seen:
            line += f"  (read at {seen})"
        rows.append(("CLOSED BECAUSE", line or "(no reason recorded)"))
        rels = ev.get("relations") or []
        if rels:
            rows.append(("READ FROM", "; ".join(
                f"{r.get('table')} built {(r.get('built_at') or '')[:19].replace('T', ' ')}"
                for r in rels[:4])))

    # Fix-grain WP4 — what this alert IS in its group. Only shown when it is part of one,
    # so an ordinary finding's output is unchanged.
    if (data.get("group_role") or "member") == "root":
        total = data.get("member_count")
        settled = data.get("members_settled")
        if total is None:
            progress = "(no members yet)"
        else:
            progress = f"{settled or 0} of {total} settled"
            if total and (settled or 0) >= total:
                progress += "  — the fix is done"
        rows.append(("GROUP", f"root — clears {total if total is not None else 0} "
                              f"finding(s);  {progress}"))
    elif data.get("parent_alert_id"):
        rows.append(("GROUP", f"member of {data['parent_alert_id']}  "
                              f"(torana alert {data['parent_alert_id']} get)"))
    # Row 3.36: the actions the platform will accept on this item right now.
    if isinstance(data.get("allowed_actions"), list):
        rows.append(("ACTIONS", ", ".join(data["allowed_actions"]) or "(none)"))
    for label, value in rows:
        click.echo(f"{label:<14} {value}")
    click.echo("")


@alert.command(name="get")
@click.pass_context
def alert_get(ctx):
    """Get details for a specific alert.

    \b
    Example:
      torana alert 550e8400-e29b-41d4-a716-446655440000 get
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    client = _client(ctx)
    try:
        data = client.get(f"alerts/{aid}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # In text mode, lead with the answer. `get` printed every key the API returns in
    # whatever order it returned them, each cut at 20 characters — so the verdict, who
    # reached it and what to do about it were somewhere in a wall of ids.
    if fmt == "text" and not fields and isinstance(data, dict):
        _print_alert_head(data)

    output(data, fmt=fmt, fields=fields)


@alert.command(name="members")
@click.option("--limit", type=int, default=100, show_default=True,
              help="Maximum members to return (max 100).")
@click.option("--offset", type=int, default=0, show_default=True, help="Rows to skip.")
@click.pass_context
def alert_members(ctx, limit, offset):
    """The findings this alert's fix clears.

    A ROOT alert stands for one action — an upgrade, a base-image rebuild — and owns the
    findings it clears. This lists them, in the ranking's own order. An ordinary alert
    owns nothing and prints an empty list rather than failing.

    \b
    Example:
      torana alert 550e8400-e29b-41d4-a716-446655440000 members
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    aid = _aid(ctx)
    client = _client(ctx)
    try:
        data = client.get(f"alerts/{aid}/members",
                          params={"limit": min(limit, 100), "skip": offset})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt == "text" and not fields and isinstance(data, list) and not data:
        click.echo("No members — this alert does not stand for a group.")
        return
    output(data, fmt=fmt, raw=raw, fields=fields, columns=_MEMBER_COLS)


@alert.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def alert_delete(ctx, yes):
    """Delete Alert."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    aid = _aid(ctx)
    path = f"alerts/{aid}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="activities")
@click.option("--thread-id", "thread_id", default=None)
@click.pass_context
def alert_activities(ctx, thread_id):
    """Get Alert Activities."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/activities"
    params = {}
    if thread_id is not None:
        params["thread_id"] = thread_id

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Explicit columns. Without them `output` printed every field of the first activity
    # cut at 20 characters, which truncated `message` — the only column worth reading.
    items = data.get("items", data) if isinstance(data, dict) else data
    if isinstance(items, list):
        for row in items:
            if isinstance(row, dict):
                row["actor"] = _activity_actor(row)
    cols = [("timestamp", "WHEN", 20), ("actor", "ACTOR", 24),
            ("activity_type", "WHAT", 22), ("message", "DETAIL", 100)]
    output(data, fmt=fmt, fields=fields, columns=cols)


@alert.command(name="graph")
@click.pass_context
def alert_graph(ctx):
    """Alert context graph — the entities this alert references, and their relationships.

    \b
      torana alert <UUID> graph
      torana alert <UUID> entities    # just the entity summary, no relationships
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"api/graph/alert/{_aid(ctx)}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="entities")
@click.pass_context
def alert_entities(ctx):
    """Alert entity summary — which entities this alert's results reference.

    \b
      torana alert <UUID> entities
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"api/graph/alert/{_aid(ctx)}/entities")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="status")
@click.option("--status", "status", type=click.Choice(["closed", "resolved"], case_sensitive=False),
              required=True,
              help="Close the item: closed or resolved. This command only closes. To reopen "
                   "use `reopen`; to escalate, `escalate`; to give a verdict, `verdict`; "
                   "to send it to the agent, `assign --assignee-type agent`.")
@click.option("--resolution-reason", "resolution_reason",
              # Rows 3.2 / 3.27: a person's six. auto_resolved is the platform's default
              # for a closure given no reason, and the API refuses it from a person.
              type=click.Choice(["fixed", "accepted_risk", "wont_fix", "duplicate", "benign", "false_positive"], case_sensitive=False),
              default=None,
              help="Reason for alert closure. Recorded on the Alert row; "
                   "typically set together with --status closed.")
@click.option("--message", "message", default=None)
@click.pass_context
def alert_status(ctx, status, resolution_reason, message):
    """Close an item, recording you as who closed it.

    The item moves to the Closed box. The finding itself is not changed. A closed item
    is refused with the reason (HTTP 409).

    \b
    Examples:
      torana alert <id> status --status closed --resolution-reason accepted_risk --message "Compensating control in place"
      torana alert <id> status --status resolved --resolution-reason fixed
      torana alert <id> status --status closed --resolution-reason false_positive
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/status"
    body = {}
    body["status"] = status
    if resolution_reason is not None:
        body["resolution_reason"] = resolution_reason
    if message is not None:
        body["message"] = message

    client = _client(ctx)
    try:
        data = client.put(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


def _person_action(ctx, verb: str, message):
    """POST alerts/<id>/<verb> with an optional note, and print the item it returns."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    body = {"message": message} if message is not None else {}
    client = _client(ctx)
    try:
        data = client.post(f"alerts/{_aid(ctx)}/{verb}", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt == "text" and not fields and isinstance(data, dict):
        _print_alert_head(data)
        return
    output(data, fmt=fmt, fields=fields)


@alert.command(name="reopen")
@click.option("--message", "message", default=None, help="Why, for the item's history.")
@click.pass_context
def alert_reopen(ctx, message):
    """Reopen a closed item.

    It goes back to Needs attention. The verdict a platform closure replaced comes back,
    and the item is pending_remediation when that verdict is true positive, otherwise
    open. Reopening a platform closure stops the platform closing it again for the same
    reason. The closure stays in its history. Refused (HTTP 409) on an item that is not
    closed.

    \b
    Example:
      torana alert <id> reopen --message "Still reported by the scanner"
    """
    _person_action(ctx, "reopen", message)


@alert.command(name="keep-closed")
@click.option("--message", "message", default=None, help="Why, for the item's history.")
@click.pass_context
def alert_keep_closed(ctx, message):
    """Agree with a closure the platform made, so it becomes yours.

    Status, reason and verdict stay as they are, and the platform never reopens it. Refused (HTTP 409) on an open item and on one a person
    already closed.

    \b
    Example:
      torana alert <id> keep-closed --message "Confirmed decommissioned"
    """
    _person_action(ctx, "keep-closed", message)


@alert.command(name="severity")
@click.option("--severity", "severity", type=click.Choice(["low", "medium", "high", "critical"], case_sensitive=False), required=True)
@click.option("--message", "message", default=None)
@click.pass_context
def alert_severity(ctx, severity, message):
    """Update Alert Severity."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/severity"
    body = {}
    body["severity"] = severity
    if message is not None:
        body["message"] = message

    client = _client(ctx)
    try:
        data = client.put(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="assign")
@click.option("--assigned-to", "assigned_to", required=True)
@click.option("--assignee-type", "assignee_type", type=click.Choice(["user", "agent", "unassigned"], case_sensitive=False), default=None, help="Type of assignee (user or agent).")
@click.option("--assignee-display-name", "assignee_display_name", default=None, help="Human-readable name of the assignee, stored alongside UUID for display")
@click.option("--message", "message", default=None)
@click.pass_context
def alert_assign(ctx, assigned_to, assignee_type, assignee_display_name, message):
    """Assign Alert."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/assign"
    body = {}
    body["assigned_to"] = assigned_to
    if assignee_type is not None:
        body["assignee_type"] = assignee_type
    if assignee_display_name is not None:
        body["assignee_display_name"] = assignee_display_name
    if message is not None:
        body["message"] = message

    client = _client(ctx)
    try:
        data = client.put(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="comment")
@click.option("--comment", "comment", required=True)
@click.pass_context
def alert_comment(ctx, comment):
    """Add Alert Comment."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/comments"
    body = {}
    body["comment"] = comment

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="verdict")
@click.option("--triage-verdict", "triage_verdict", required=True,
              type=click.Choice(["true_positive", "false_positive", "benign", "inconclusive"],
                                case_sensitive=False),
              help="Triage classification verdict.")
@click.option("--triage-summary", "triage_summary", default=None,
              help="Summary of triage findings")
@click.option("--message", "message", default=None,
              help="Optional message to record with the verdict")
@click.option("--reason-code", "reason_code", default=None,
              help="WHY this verdict was reached — one code from `torana alerts reason-codes`. "
                   "Optional for a person; the triage agent must supply one once guards are on. "
                   "A code that does not accompany this verdict is refused, naming the ones that do.")
@click.option("--proposed-fix", "proposed_fix", default=None,
              help="One sentence a developer can act on, e.g. 'Upgrade lodash 4.17.20 to 4.17.21'. "
                   "Shown on the alert; NOT the same field as remediation_summary, which the "
                   "remediation service overwrites with the pull-request reference.")
@click.option("--verdict-evidence", "verdict_evidence", default=None,
              help="What you found and where (the document, the control, the precondition). "
                   "Required when the reason code closes on evidence the platform does not "
                   "hold (ground `new_evidence` in `torana alerts reason-codes`); omit it "
                   "otherwise. Shown on the alert for a person to judge.")
@click.option("--resolution-reason", "resolution_reason", default=None,
              type=click.Choice(["fixed", "accepted_risk", "false_positive", "benign",
                                 "duplicate", "wont_fix", "auto_resolved"],
                                case_sensitive=False),
              help="Override the default resolution reason on a closing verdict.")
@click.pass_context
def alert_verdict(ctx, triage_verdict, triage_summary, message, reason_code, proposed_fix,
                  verdict_evidence, resolution_reason):
    """Set the triage verdict on this alert.

    \b
    Examples:
      torana alert <UUID> verdict --triage-verdict true_positive \\
        --reason-code exposed_and_fixable \\
        --proposed-fix "Upgrade lodash 4.17.20 to 4.17.21"
      torana alerts reason-codes          # the grounds a verdict may cite
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/verdict"
    body = {}
    body["triage_verdict"] = triage_verdict
    if triage_summary is not None:
        body["triage_summary"] = triage_summary
    if message is not None:
        body["message"] = message
    if reason_code is not None:
        body["reason_code"] = reason_code
    if proposed_fix is not None:
        body["proposed_fix"] = proposed_fix
    if verdict_evidence is not None:
        body["verdict_evidence"] = verdict_evidence
    if resolution_reason is not None:
        body["resolution_reason"] = resolution_reason.lower()

    client = _client(ctx)
    try:
        data = client.put(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # The platform may RECORD the verdict rather than apply it, when the tenant's
    # triage-autonomy policy says a person decides. That is a success, not a failure —
    # say so plainly instead of printing a bare {"status": "recommended"}.
    if fmt == "text" and isinstance(data, dict) and data.get("status") == "recommended":
        click.echo(f"Recommended (autonomy level {data.get('autonomy_level', 'Manual')}); "
                   f"a person must confirm it.")
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="invoke")
@click.pass_context
def alert_invoke(ctx):
    """Invoke Triage."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/triage/invoke"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="cancel")
@click.pass_context
def alert_cancel(ctx):
    """Cancel Triage."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/triage/cancel"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="question")
@click.option("--question", "question", required=True, help="Question to ask about the alert")
@click.option("--thread-id", "thread_id", default=None, help="Optional thread ID to group related questions")
@click.option("--parent-activity-id", "parent_activity_id", default=None, help="Optional parent activity ID for reply threading")
@click.pass_context
def alert_question(ctx, question, thread_id, parent_activity_id):
    """Post Question."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/question"
    body = {}
    body["question"] = question
    if thread_id is not None:
        body["thread_id"] = thread_id
    if parent_activity_id is not None:
        body["parent_activity_id"] = parent_activity_id

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="remediation")
@click.option("--remediation-instructions", "remediation_instructions", required=True, help="Instructions or description of remediation actions to take")
@click.option("--auto-remediate", "auto_remediate", type=bool, default=False, help="Whether to attempt automatic remediation")
@click.pass_context
def alert_remediation(ctx, remediation_instructions, auto_remediate):
    """Start Remediation."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/remediation"
    body = {}
    body["remediation_instructions"] = remediation_instructions
    if auto_remediate is not None:
        body["auto_remediate"] = auto_remediate

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="escalate")
@click.option("--escalation-reason", "escalation_reason", required=True, help="Reason for escalation")
@click.option("--escalate-to", "escalate_to", default=None, help="Optional specific user/agent/team to escalate to")
@click.pass_context
def alert_escalate(ctx, escalation_reason, escalate_to):
    """Escalate Alert Triage."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/escalate"
    body = {}
    body["escalation_reason"] = escalation_reason
    if escalate_to is not None:
        body["escalate_to"] = escalate_to

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="compress-context")
@click.pass_context
def alert_compress_context(ctx):
    """Compress Context."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/compress-context"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="provenance")
@click.pass_context
def alert_provenance(ctx):
    """Show how this alert came to exist — full provenance + pipeline trace.

    \b
    Walks bottom→top: the originating RULE and how it was triggered (manual /
    scheduled / suite), the rule run, the alert (finding), and every pipeline
    stage it passed through — each with status + timing. Backed by
    GET /api/v1/pipeline/trace/by-alert/{id}.

    \b
    Example:
      torana alert <UUID> provenance
      torana alert <UUID> provenance --json
    """
    # Shared renderer/fetch lives in pipeline.py (single owner of the trace
    # endpoint + provenance formatting). Imported lazily to avoid any import cycle.
    from torana_cli.pipeline import provenance_by_alert_core
    provenance_by_alert_core(ctx, _aid(ctx))


@alert.command(name="triage-context")
@click.option("--rendered", is_flag=True, default=False,
              help="Also print the message the triage agent saw on its last run "
                   "and the one it would receive now.")
@click.pass_context
def alert_triage_context(ctx, rendered):
    """Get Triage Context.

    \b
    With --rendered (text format), prints the first message of the agent's
    last run under "Last run", then the message it would receive if invoked
    now under "If invoked now". JSON/YAML carry both as fields.

    \b
    Example:
      torana alert <UUID> triage-context
      torana alert <UUID> triage-context --rendered
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/triage-context"

    client = _client(ctx)
    try:
        data = client.get(path, params={"rendered": "true"} if rendered else None)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if rendered and fmt == "text" and isinstance(data, dict) and (
            data.get("last_run_message") or data.get("rendered_message")):
        _echo_triage_messages(data)
        return
    output(data, fmt=fmt, fields=fields)


def _echo_triage_messages(data: dict) -> None:
    """Print the last run's first message, then the one the agent would get now."""
    sections = [("Last run", data.get("last_run_message")),
                ("If invoked now", data.get("rendered_message"))]
    first = True
    for header, message in sections:
        if not message:
            continue
        if not first:
            click.echo("")
        click.echo(f"=== {header} ===")
        click.echo(message)
        first = False
