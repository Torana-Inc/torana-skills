"""torana alert <ALERT_ID> — instance-scoped alert commands."""

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE
from torana_cli.output import output
from torana_cli.confirm import confirm as _confirm


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _aid(ctx) -> str:
    return ctx.obj.get("_alert_id", "") if ctx.obj else ""


@click.group(name="alert", invoke_without_command=True)
@click.argument("alert_id", metavar="ALERT_ID")
@click.pass_context
def alert(ctx, alert_id):
    """Manage a single alert by ID.

    \b
    Examples:
      torana alert <UUID> get
      torana alert <UUID> status --status resolved
      torana alert <UUID> assign --assigned-to <user-id>
      torana alert <UUID> verdict --triage-verdict true_positive
      torana alert <UUID> delete --yes
    """
    ctx.ensure_object(dict)
    ctx.obj["_alert_id"] = alert_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@alert.command(name="get")
@click.pass_context
def alert_get(ctx):
    """Get details for a specific alert.

    \b
    Example:
      torana alert 550e8400-e29b-41d4-a716-446655440000 get
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    client = _client(ctx)
    try:
        data = client.get(f"alerts/{aid}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def alert_delete(ctx, yes):
    """Delete Alert."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    aid = _aid(ctx)
    path = f"alerts/{aid}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="activities")
@click.option("--thread-id", "thread_id", default=None)
@click.pass_context
def alert_activities(ctx, thread_id):
    """Get Alert Activities."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/activities"
    params = {}
    if thread_id is not None:
        params["thread_id"] = thread_id

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="graph")
@click.pass_context
def alert_graph(ctx):
    """Alert context graph — the entities this alert references, and their relationships.

    \b
      torana alert <UUID> graph
      torana alert <UUID> entities    # just the entity summary, no relationships
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"api/graph/alert/{_aid(ctx)}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="entities")
@click.pass_context
def alert_entities(ctx):
    """Alert entity summary — which entities this alert's results reference.

    \b
      torana alert <UUID> entities
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"api/graph/alert/{_aid(ctx)}/entities")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="status")
@click.option("--status", "status", type=click.Choice(["open", "triaging", "awaiting_input", "pending_remediation", "escalated", "resolved", "closed"], case_sensitive=False), required=True, help="Alert lifecycle status.")
@click.option("--resolution-reason", "resolution_reason",
              type=click.Choice(["fixed", "accepted_risk", "false_positive", "duplicate", "wont_fix", "auto_resolved"], case_sensitive=False),
              default=None,
              help="Reason for alert closure. Recorded on the Alert row; "
                   "typically set together with --status closed.")
@click.option("--message", "message", default=None)
@click.pass_context
def alert_status(ctx, status, resolution_reason, message):
    """Update Alert Status.

    \b
    Examples:
      torana alert <id> status --status pending_remediation --message "Picked up for remediation"
      torana alert <id> status --status resolved --message "PR merged, fix deployed"
      torana alert <id> status --status closed --resolution-reason fixed
      torana alert <id> status --status closed --resolution-reason false_positive
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/status"
    body = {}
    body["status"] = status
    if resolution_reason is not None:
        body["resolution_reason"] = resolution_reason
    if message is not None:
        body["message"] = message

    client = _client(ctx)
    try:
        data = client.put(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="severity")
@click.option("--severity", "severity", type=click.Choice(["low", "medium", "high", "critical"], case_sensitive=False), required=True)
@click.option("--message", "message", default=None)
@click.pass_context
def alert_severity(ctx, severity, message):
    """Update Alert Severity."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/severity"
    body = {}
    body["severity"] = severity
    if message is not None:
        body["message"] = message

    client = _client(ctx)
    try:
        data = client.put(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="assign")
@click.option("--assigned-to", "assigned_to", required=True)
@click.option("--assignee-type", "assignee_type", type=click.Choice(["user", "agent", "unassigned"], case_sensitive=False), default=None, help="Type of assignee (user or agent).")
@click.option("--assignee-display-name", "assignee_display_name", default=None, help="Human-readable name of the assignee, stored alongside UUID for display")
@click.option("--message", "message", default=None)
@click.pass_context
def alert_assign(ctx, assigned_to, assignee_type, assignee_display_name, message):
    """Assign Alert."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/assign"
    body = {}
    body["assigned_to"] = assigned_to
    if assignee_type is not None:
        body["assignee_type"] = assignee_type
    if assignee_display_name is not None:
        body["assignee_display_name"] = assignee_display_name
    if message is not None:
        body["message"] = message

    client = _client(ctx)
    try:
        data = client.put(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="comment")
@click.option("--comment", "comment", required=True)
@click.pass_context
def alert_comment(ctx, comment):
    """Add Alert Comment."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/comments"
    body = {}
    body["comment"] = comment

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="verdict")
@click.option("--triage-verdict", "triage_verdict", type=click.Choice(["true_positive", "false_positive", "benign", "inconclusive"], case_sensitive=False), required=True, help="Triage classification verdict.")
@click.option("--triage-summary", "triage_summary", default=None, help="Summary of triage findings")
@click.option("--message", "message", default=None, help="Optional message to record with the verdict")
@click.pass_context
def alert_verdict(ctx, triage_verdict, triage_summary, message):
    """Set Verdict."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/verdict"
    body = {}
    body["triage_verdict"] = triage_verdict
    if triage_summary is not None:
        body["triage_summary"] = triage_summary
    if message is not None:
        body["message"] = message

    client = _client(ctx)
    try:
        data = client.put(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="invoke")
@click.pass_context
def alert_invoke(ctx):
    """Invoke Triage."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/triage/invoke"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="cancel")
@click.pass_context
def alert_cancel(ctx):
    """Cancel Triage."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/triage/cancel"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="question")
@click.option("--question", "question", required=True, help="Question to ask about the alert")
@click.option("--thread-id", "thread_id", default=None, help="Optional thread ID to group related questions")
@click.option("--parent-activity-id", "parent_activity_id", default=None, help="Optional parent activity ID for reply threading")
@click.pass_context
def alert_question(ctx, question, thread_id, parent_activity_id):
    """Post Question."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/question"
    body = {}
    body["question"] = question
    if thread_id is not None:
        body["thread_id"] = thread_id
    if parent_activity_id is not None:
        body["parent_activity_id"] = parent_activity_id

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="remediation")
@click.option("--remediation-instructions", "remediation_instructions", required=True, help="Instructions or description of remediation actions to take")
@click.option("--auto-remediate", "auto_remediate", type=bool, default=False, help="Whether to attempt automatic remediation")
@click.pass_context
def alert_remediation(ctx, remediation_instructions, auto_remediate):
    """Start Remediation."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/remediation"
    body = {}
    body["remediation_instructions"] = remediation_instructions
    if auto_remediate is not None:
        body["auto_remediate"] = auto_remediate

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="escalate")
@click.option("--escalation-reason", "escalation_reason", required=True, help="Reason for escalation")
@click.option("--escalate-to", "escalate_to", default=None, help="Optional specific user/agent/team to escalate to")
@click.pass_context
def alert_escalate(ctx, escalation_reason, escalate_to):
    """Escalate Alert Triage."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/escalate"
    body = {}
    body["escalation_reason"] = escalation_reason
    if escalate_to is not None:
        body["escalate_to"] = escalate_to

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="compress-context")
@click.pass_context
def alert_compress_context(ctx):
    """Compress Context."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/compress-context"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="provenance")
@click.pass_context
def alert_provenance(ctx):
    """Show how this alert came to exist — full provenance + pipeline trace.

    \b
    Walks bottom→top: the originating RULE and how it was triggered (manual /
    scheduled / suite), the rule run, the alert (finding), and every pipeline
    stage it passed through — each with status + timing. Backed by
    GET /api/v1/pipeline/trace/by-alert/{id}.

    \b
    Example:
      torana alert <UUID> provenance
      torana alert <UUID> provenance --json
    """
    # Shared renderer/fetch lives in pipeline.py (single owner of the trace
    # endpoint + provenance formatting). Imported lazily to avoid any import cycle.
    from torana_cli.pipeline import provenance_by_alert_core
    provenance_by_alert_core(ctx, _aid(ctx))


@alert.command(name="triage-context")
@click.pass_context
def alert_triage_context(ctx):
    """Get Triage Context."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/triage-context"

    client = _client(ctx)
    try:
        data = client.get(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)
