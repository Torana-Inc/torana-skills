"""torana alert <ALERT_ID> — instance-scoped alert commands."""

import re
import sys

import click

from torana_cli.client.auth import AuthError
from torana_cli.client.base import APIError, ToranaClient, handle_api_error, handle_auth_error
from torana_cli.config.settings import get_settings
from torana_cli.main import CTX_FIELDS, CTX_FORMAT, CTX_PROFILE, CTX_RAW
from torana_cli.output import output
from torana_cli.section_descriptions import all_reasons_option, with_sections_help
from torana_cli.confirm import confirm as _confirm


def _client(ctx) -> ToranaClient:
    profile = ctx.obj.get(CTX_PROFILE) if ctx.obj else None
    settings = get_settings(profile)
    return ToranaClient(base_url=settings.base_url)


def _aid(ctx) -> str:
    return ctx.obj.get("_alert_id", "") if ctx.obj else ""


@click.group(name="alert", invoke_without_command=True)
@click.argument("alert_id", metavar="ALERT_ID")
@click.pass_context
def alert(ctx, alert_id):
    """One item of the Inbox, by ID: read it, decide it, assign it.

    \b
    Start here:
      Read the item as the Inbox shows it   torana alert <UUID> view
      One section only                      torana alert <UUID> view --section verdict
      The findings an entry's fix clears    torana alert <UUID> members
      The evidence behind it                torana alert <UUID> proof
      Set a verdict, close, reopen, assign  verdict, close, reopen, assign (below)

    \b
    Examples:
      torana alert <UUID> view
      torana alert <UUID> view --section why-here --section history
      torana alert <UUID> get
      torana alert <UUID> close --reason wont_fix
      torana alert <UUID> reopen --message "still reported"
      torana alert <UUID> keep-closed
      torana alert <UUID> assign --assigned-to <user-id>
      torana alert <UUID> verdict --triage-verdict true_positive
      torana alert <UUID> delete --yes
    """
    ctx.ensure_object(dict)
    ctx.obj["_alert_id"] = alert_id
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


def code_read_detail(extra):
    """What a `code_read` activity's `extra_data` adds to its line: what was asked, how much came back and at which commit,
    e.g. "lines 148, 370 · 2 locations, 1,800 chars · at 7acd0a2". Never code: the record holds none. Empty for any other
    shape."""
    if not isinstance(extra, dict) or extra.get("tool") != "read_code":
        return ""
    req = extra.get("request") or {}
    kind = str(req.get("kind") or "")
    arg = {"lines": ", ".join(str(x) for x in req.get("lines") or []), "function": req.get("function"),
           "callers_of": req.get("callers_of"), "range": req.get("range")}.get(kind)
    asked = " ".join(x for x in [kind.replace("_", " "), str(arg) if arg else ""] if x)
    sizes = extra.get("sizes") or {}
    got = (f"{sizes.get('locations', 0)} location{'' if sizes.get('locations') == 1 else 's'}, "
           f"{int(sizes.get('chars') or 0):,} chars") if sizes else ""
    commit = f"at {str(extra['commit'])[:7]}" if extra.get("commit") else "on the default branch (not pinned)"
    status = str(extra.get("status") or "")
    return " · ".join(x for x in [asked, got if status == "ok" else status.replace("_", " "), commit] if x)


def _activity_actor(row) -> str:
    """`actor_type` plus a short id — who did this, in one column."""
    kind = (row.get("actor_type") or "").lower()
    who = row.get("actor_id") or row.get("user_id") or ""
    extra = (row.get("extra_data") or {}) if isinstance(row.get("extra_data"), dict) else {}
    if kind == "system" and extra.get("rule_id"):
        return "the ranking"
    if not kind:
        return ""
    return f"{kind}:{str(who)[:8]}" if who else kind


#: What a person needs to see about a member: is it done, and what was decided.
_MEMBER_COLS = [
    ("id", "ID", 36),
    ("name", "NAME", 40),
    ("severity", "SEVERITY", 10),
    ("triage_priority", "PRIO", 6),
    ("state", "STATE", 7),
    ("box", "BOX", 15),
    ("status", "STATUS", 20),
    ("triage_verdict", "VERDICT", 15),
    ("reason_code", "REASON", 24),
    # The entity-graph node the member is about, only when the graph has it (API `graph_nodes=true`); '—' otherwise.
    ("graph_node_key", "GRAPH NODE", 48),
]


def clears_phrase(data) -> str:
    """" — clears N finding(s)" for a root, with how many are at or above the tenant's severity floor when that differs
    ("clears 36 (35 at or above your severity floor)"). One number when the two are equal, or when the platform does not say
    (`findings_cleared_above_floor` is null when not known; it is never guessed). Empty when nothing is declared."""
    cleared = (data or {}).get("findings_cleared")
    if cleared is None:
        return ""
    floor = (data or {}).get("findings_cleared_above_floor")
    unknown = (data or {}).get("findings_floor_unknown")
    if isinstance(floor, int) and not isinstance(floor, bool) and floor != cleared:
        return f" — clears {cleared} finding(s) ({floor} at or above your severity floor)"
    if isinstance(unknown, int) and not isinstance(unknown, bool) and unknown > 0:
        return f" — clears {cleared} finding(s) ({unknown} not classified against your severity floor)"
    return f" — clears {cleared} finding(s)"


def facts_changed_rows(data) -> list:
    """The rows saying a fact the verdict relied on has changed and the item is waiting to be re-triaged. Empty when nothing is
    pending. The text is the platform's own sentence for each change; nothing is composed here."""
    if not (data or {}).get("facts_changed_at"):
        return []
    changes = data.get("facts_changed") or []
    since = str(data["facts_changed_at"])[:19].replace("T", " ")
    texts = [c.get("text") for c in changes if c.get("text")]
    first = f"⚠ facts changed since the verdict ({since} UTC): " + ("; ".join(texts) if texts else "not available")
    return [("", first), ("", "  The item is re-triaged automatically when the change has held; see `torana alert <id> activities`.")]


def lifecycle_evidence_rows(ev) -> list:
    """The rows for the lifecycle's last decision on an item. The evidence is the LAST decision, which may be a reopen: calling
    that "closed because" on an open item reads as a contradiction, so the label follows what the lifecycle did."""
    if not ev:
        return []
    rows = []
    label = "REOPENED BECAUSE" if str(ev.get("outcome") or "").lower() == "reopen" else "CLOSED BECAUSE"
    reason = ev.get("resolution_reason") or ""
    sentence = ev.get("reason_sentence") or ev.get("reason_label") or ev.get("why") or ""
    seen = (ev.get("observed_at") or "")[:19].replace("T", " ")
    line = reason + (f" — {sentence}" if sentence else "")
    if seen:
        line += f"  (read at {seen})"
    rows.append((label, line or "(no reason recorded)"))
    rels = ev.get("relations") or []
    if rels:
        rows.append(("READ FROM", "; ".join(
            f"{r.get('table')} built {(r.get('built_at') or '')[:19].replace('T', ' ')}"
            for r in rels[:4])))
    return rows


def code_links_rows(links):
    """The rows for a code finding's links to GitHub (the platform's `code_links`): "<path> L148, L370 at 7acd0a2", or
    "... on the default branch (not pinned to the scanned commit)" when no commit is known, then the file's URL. No code
    is printed: the links are where to read it. Empty for a finding with none."""
    if not links:
        return []
    from urllib.parse import unquote
    url = str(links.get("file_url") or "")
    path = unquote(url.split("/blob/", 1)[1].split("/", 1)[1]) if "/blob/" in url and "/" in url.split("/blob/", 1)[1] else ""
    lines = ", ".join(f"L{loc.get('line')}" for loc in links.get("locations") or [] if loc.get("line"))
    where = (f"at {str(links.get('commit'))[:7]}" if links.get("pinned") and links.get("commit")
             else "on the default branch (not pinned to the scanned commit)")
    first = " ".join(x for x in [path or "file", lines, where] if x)
    return [("CODE IN GITHUB", first), ("", url)] if url else [("CODE IN GITHUB", first)]


def _header_severity(head) -> str:
    """The severity the item view's header shows, worded as the screen words it ("Critical", "Not recorded").

    The platform states the item's severity as `severity_shown`; when it sends that key and it is empty, the item has no
    severity of its own and the header says so. It must NOT fall back to `severity`, which is the declaring rule's one
    constant for every item the rule raises (it read "medium" on an item whose finding has none)."""
    if "severity_shown" in head:
        shown = str(head.get("severity_shown") or "").strip()
        return (shown[:1].upper() + shown[1:]) if shown else "Not recorded"
    shown = str(head.get("finding_severity") or head.get("severity") or "").strip()
    return (shown[:1].upper() + shown[1:]) if shown else "Not recorded"


def _print_alert_head(data) -> None:
    """The six things a person opens an alert to find, before the raw keys."""
    verdict = data.get("triage_verdict") or "(not yet judged)"
    code = data.get("reason_code")
    actor_type = (data.get("verdict_actor_type") or "").lower()
    actor_id = data.get("verdict_actor_id") or ""
    if data.get("verdict_source_detail"):
        decided_by = data["verdict_source_detail"]        # stated by the platform (T1-15)
    elif actor_type == "system" and str(actor_id).startswith("rule:"):
        decided_by = "the ranking"
    elif actor_type:
        decided_by = f"{actor_type} {str(actor_id)[:8]}" if actor_id else actor_type
    else:
        decided_by = ""
    verdict_line = verdict + (f"  [{code}]" if code else "") + (f"  — by {decided_by}" if decided_by else "")

    fix = data.get("proposed_fix") or data.get("remediation_summary") or ""
    # The same rule as the Inbox view: a fix is shown for a confirmed finding only. An item judged not a problem (or
    # with that recommended) keeps the stored fix, but it is not offered; an entry or undecided item has no verdict.
    _effective = str(((data.get("pending_recommendation") or {}).get("verdict")
                      or data.get("triage_verdict") or "")).lower()
    if _effective and _effective != "true_positive":
        fix = ""
    fix_src = {"rule": "from the ranking", "agent": "from the triage agent",
               "user": "written by a person"}.get(data.get("proposed_fix_source") or "", "")
    if fix and fix_src:
        fix = f"{fix}  ({fix_src})"

    _box = {"needs_attention": "Needs attention", "closed": "Closed",
            "moved": "Moved"}.get(data.get("box") or "", data.get("box") or "")
    # Row 3.24 — "Was: <verdict>" when a platform closure changed it.
    kept = data.get("verdict_before_close") or {}
    if kept and data.get("status") in ("closed", "resolved"):
        verdict_line += f"  (was {kept.get('verdict') or 'no verdict'})"
    status_line = data.get("status") or ""
    if data.get("closed_by_display_name"):
        # Row 3.23: who closed it and why, on every closed row.
        status_line += f"  — by {data['closed_by_display_name']}"
        if data.get("resolution_reason"):
            status_line += f" ({data['resolution_reason']})"
    rows = [
        ("NAME", data.get("name") or ""),
        ("SEVERITY", data.get("severity") or ""),
        ("BOX", _box),
        ("WHY", data.get("why_label") or "—"),
        ("STATUS", status_line),
        ("VERDICT", verdict_line),
    ]
    # What the agent found and where, for a closure on evidence the platform does not
    # hold. Only shown when present, so an ordinary alert's output is unchanged.
    if data.get("verdict_evidence"):
        rows.append(("EVIDENCE", data["verdict_evidence"]))
    if data.get("remediation_action"):
        _rem = data["remediation_action"] + (
            f" {data['remediation_target_type']}" if data.get("remediation_target_type") else "")
        if data.get("remediation_target_version"):
            _rem += f" to {data['remediation_target_version']}"
        rows.append(("REMEDIATION", _rem))
        rows.append(("ENTRY KEY", data.get("remediation_key")
                     or "(not built: a fact the policy needs is missing)"))
    if data.get("assignee_chosen_by_person"):
        rows.append(("OWNER CHOICE", "chosen by a person"
                     + (f" at {data['assignee_chosen_at']}" if data.get("assignee_chosen_at") else "")
                     + "; no automatic step overrides it"))
    if data.get("cve_fixes"):
        rows.append(("CVE FIXES", "; ".join(
            f"{c['cve']}: " + (f"{c['fixed_version']}" if c.get("fixed_version")
                               else "versions differ (" + ", ".join(c.get("versions") or []) + ")")
            for c in data["cve_fixes"])))
    if data.get("follow_up_actions"):
        rows.append(("FOLLOW-UP", "; ".join(str(a) for a in data["follow_up_actions"])))
    if data.get("continuity_note"):
        rows.append(("CONTINUITY NOTE", data["continuity_note"]))
    # T-3 — the last triage attempt FAILED. Shown only then: "(not yet judged)" above
    # reads the same for an alert never triaged and one whose triage crashed.
    tf = data.get("triage_failure") or {}
    if tf.get("state") == "failed":
        when = str(tf.get("at") or "")[:16].replace("T", " ")
        hint = ("a requeue should work" if tf.get("recoverable")
                else "fix the cause before re-running")
        rows.append(("TRIAGE", f"FAILED after {tf.get('attempts')}/{tf.get('max_attempts')} "
                               f"attempts at {when} UTC ({tf.get('error_kind')}); will not "
                               f"retry on its own — {hint}: {tf.get('error') or ''}"))
    elif tf.get("state") == "retrying":
        when = str(tf.get("at") or "")[:16].replace("T", " ")
        nxt = f"next ~{when} UTC" if when else "retrying now"
        rows.append(("TRIAGE", f"failed {tf.get('attempts')}/{tf.get('max_attempts')}, "
                               f"retrying ({nxt}): {tf.get('error') or ''}"))
    # F-o01-1/F-o01-2 — what this verdict RELIED ON at runtime, and whether it still
    # runs. Only shown when the platform recorded a place, so an ordinary alert's output
    # is unchanged. ⛔ The ⚠ glyph and the words carry the state: no colour, and the
    # stale line says "verdict unchanged" because this is an observation, not a
    # re-decision.
    if data.get("verdict_runtime_key"):
        _f = data.get("verdict_runtime_facts") or {}
        _bits = [str(data["verdict_runtime_key"]).split("/")[-1] or data["verdict_runtime_key"]]
        if _f.get("services") is not None:
            _svc = f"{_f['services']} services"
            if _f.get("internet_facing_services") is not None:
                _svc += f" ({_f['internet_facing_services']} internet-facing)"
            _bits.append(_svc)
        _seen = data.get("verdict_runtime_last_seen_at") or data.get("verdict_runtime_seen_at")
        if _seen:
            _bits.append(f"seen {str(_seen)[:19].replace('T', ' ')}")
        rows.append(("RUNTIME", " · ".join(_bits)))
        if data.get("verdict_runtime_stale"):
            # ⚠️ "last seen" is omitted when unknown rather than printed as "None": a
            # record adopted from a finding_key carries a place but no observation time,
            # and "last seen None" reads as a bug to an operator. Measured on T1.
            _since = str(data.get("verdict_runtime_stale_at"))[:10]
            _tail = f" — last seen {str(_seen)[:10]}" if _seen else ""
            rows.append(("", f"⚠ not running since {_since}{_tail}; verdict unchanged"))
    rows += facts_changed_rows(data)
    rows += [
        ("PROPOSED FIX", fix or "(none)"),
        *code_links_rows(data.get("code_links")),
        ("DESCRIPTION", (data.get("description") or "").strip()),
    ]
    # ⭐ WHY IT CLOSED, when the LIFECYCLE closed it. An operator who finds work gone from
    # their queue has no other record of what removed it — the reason code alone is a
    # word, not an account. Only shown when the lifecycle acted, so an ordinary alert's
    # output is unchanged.
    rows += lifecycle_evidence_rows(data.get("lifecycle_evidence"))

    # Fix-grain WP4 — what this alert IS in its group. Only shown when it is part of one,
    # so an ordinary finding's output is unchanged.
    if (data.get("group_role") or "member") == "root":
        total = data.get("member_count")
        settled = data.get("members_settled")
        if not total:
            progress = "no linked items yet"
        else:
            progress = f"{settled or 0} of {total} linked item(s) settled"
            if (settled or 0) >= total:
                progress += "  — the fix is done"
        # ⛔ ONE NUMBER, from the platform: `findings_cleared` = what the rule declares plus the
        # items linked to it. Null means the rule declares no count, and then NOTHING is said
        # about how many findings it clears. It used to print the linked-item count, which is 0
        # for a root whose findings were never raised as items: "clears 0" beside a title that
        # said 2.
        clears = clears_phrase(data)
        rows.append(("GROUP", f"root{clears};  {progress}"))
    elif data.get("parent_alert_id"):
        rows.append(("GROUP", f"member of {data['parent_alert_id']}  "
                              f"(torana alert {data['parent_alert_id']} get)"))
    # Row 3.36: the actions the platform will accept on this item right now.
    if isinstance(data.get("allowed_actions"), list):
        rows.append(("ACTIONS", ", ".join(data["allowed_actions"]) or "(none)"))
    for label, value in rows:
        click.echo(f"{label:<14} {value}")
    click.echo("")


@alert.command(name="get")
@click.pass_context
def alert_get(ctx):
    """The item's raw record: status, severity, verdict, assignee, owner, SLA and timestamps.

    Use this when you need the stored fields as the API holds them (for a script, or to check one field). To read the item
    the way the Inbox shows it, with the reasons and the fix, use `inbox` instead.

    \b
    Output:
      One record. Add --json for every field, or --fields id,status,severity to pick some.

    \b
    Related:
      torana alert <UUID> view         the item as the Inbox shows it
      torana alert <UUID> activities    what happened to it, in order

    \b
    Examples:
      torana alert 550e8400-e29b-41d4-a716-446655440000 get
      torana alert 550e8400-e29b-41d4-a716-446655440000 get --fields id,status,severity
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    client = _client(ctx)
    try:
        data = client.get(f"alerts/{aid}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # In text mode, lead with the answer. `get` printed every key the API returns in
    # whatever order it returned them, each cut at 20 characters — so the verdict, who
    # reached it and what to do about it were somewhere in a wall of ids.
    if fmt == "text" and not fields and isinstance(data, dict):
        _print_alert_head(data)

    output(data, fmt=fmt, fields=fields)


#: The server's page size for `alerts/{id}/members`, and how many pages the default walk takes before it stops.
_MEMBERS_PAGE = 100
_MEMBERS_MAX_PAGES = 50


def _fetch_all_members(client, aid):
    """Every member of an entry, by paging until a short page (cap `_MEMBERS_MAX_PAGES`, with a warning).

    ⛔ A single call returns at most 100 rows and says nothing, so an entry with 205 members looked complete at 100.
    Returns (rows, truncated)."""
    rows = []
    for page in range(_MEMBERS_MAX_PAGES):
        chunk = client.get(f"alerts/{aid}/members",
                           params={"limit": _MEMBERS_PAGE, "skip": page * _MEMBERS_PAGE, "graph_nodes": "true"})
        if not isinstance(chunk, list):
            return chunk, False                 # not the list shape: hand it back untouched
        rows.extend(chunk)
        if len(chunk) < _MEMBERS_PAGE:
            return rows, False
    return rows, True


@alert.command(name="members")
@click.option("--limit", type=int, default=None,
              help="Return ONE page of at most this many members (max 100). Without --limit and --offset every "
                   "member is returned, paging for you.")
@click.option("--offset", type=int, default=None, help="Rows to skip; returns ONE page from here.")
@click.pass_context
def alert_members(ctx, limit, offset):
    """The findings this alert's fix clears (the rows behind "What this fix clears").

    Use this to list an entry's findings; the headline counts are in `alert <UUID> view --section clears`.

    A ROOT alert stands for one action — an upgrade, a base-image rebuild — and owns the
    findings it clears. This lists ALL of them, in the ranking's own order, paging through
    the server's 100-row pages itself (up to 50 pages, with a warning if there are more).
    Pass --limit or --offset to get a single page instead. An ordinary alert owns nothing
    and prints an empty list rather than failing.

    \b
    Examples:
      torana alert 550e8400-e29b-41d4-a716-446655440000 members
      torana alert 550e8400-e29b-41d4-a716-446655440000 members --limit 50 --offset 100
      torana alert 550e8400-e29b-41d4-a716-446655440000 members --format json

    Related: `alert <UUID> view`, `alerts list`.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    aid = _aid(ctx)
    client = _client(ctx)
    try:
        if limit is None and offset is None:
            data, truncated = _fetch_all_members(client, aid)
            if truncated:
                click.echo(f"WARNING: stopped after {_MEMBERS_MAX_PAGES * _MEMBERS_PAGE} members "
                           f"({_MEMBERS_MAX_PAGES} pages); there are more. Use --offset "
                           f"{_MEMBERS_MAX_PAGES * _MEMBERS_PAGE} to continue.", err=True)
        else:
            size, skip = min(limit if limit is not None else _MEMBERS_PAGE, _MEMBERS_PAGE), offset or 0
            data = client.get(f"alerts/{aid}/members", params={"limit": size, "skip": skip, "graph_nodes": "true"})
            if isinstance(data, list) and size and len(data) >= size:
                click.echo(f"showing {skip + 1}-{skip + len(data)}; more may exist, use --offset {skip + len(data)}",
                           err=True)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt == "text" and not fields and isinstance(data, list) and not data:
        click.echo("No members — this alert does not stand for a group.")
        return
    output(data, fmt=fmt, raw=raw, fields=fields, columns=_MEMBER_COLS)
    if fmt == "text" and not fields and isinstance(data, list):
        hint = _graph_hint(data)
        if hint:
            click.echo(hint)


def _graph_hint(rows) -> str:
    """How many members have a node in the entity graph, and how to open one. Empty when none does."""
    keyed = [r["graph_node_key"] for r in rows if isinstance(r, dict) and r.get("graph_node_key")]
    if not keyed:
        return ""
    return (f"\n{len(keyed)} of {len(rows)} member(s) have a node in the entity graph. Open one:\n"
            f"  torana entity-graph neighbors {keyed[0]} --direction both\n"
            f"  UI: /entity-graph/explore?seed={keyed[0]}")


#: What a person scans for first about a CVE: how bad, how likely, is it being exploited.
_CVE_INTEL_COLS = [
    ("cve_id", "CVE", 16),
    ("cvss", "CVSS", 6),
    ("epss", "EPSS", 7),
    ("kev", "KEV", 34),
    ("cwe", "CWE", 22),
    ("published", "PUBLISHED", 10),
    ("summary", "DESCRIPTION", 60),
]


def _cve_intel_row(item):
    """The columns derived for the table view (the record's own fields are untouched, for --format json)."""
    def num(v, places):
        return "—" if not isinstance(v, (int, float)) or isinstance(v, bool) else f"{v:.{places}f}"
    if not item.get("known"):
        return {**item, "cvss": "—", "epss": "—", "kev": "—", "cwe": "—", "published": "—",
                "summary": "not in the threat-intel table"}
    kev = "—" if not item.get("kev_listed") else "KEV" + (
        f" (due {item['kev_due_date']})" if item.get("kev_due_date") else "")
    if item.get("kev_known_ransomware") not in (None, "", False, "Unknown", "unknown"):
        kev += " ransomware"
    desc = " ".join(str(item.get("description") or "").split())
    return {**item, "cvss": num(item.get("cvss3_base_score"), 1),
            "epss": num(item.get("epss_score"), 3) if item.get("epss_score") is not None else "—",
            "kev": kev, "cwe": str(item.get("cwe_ids") or item.get("cwe_id") or "—"),
            "published": str(item.get("published_date") or "—")[:10],
            "summary": desc[:57] + "..." if len(desc) > 60 else (desc or "—")}


@alert.command(name="cve-intel")
@click.pass_context
def alert_cve_intel(ctx):
    """What the platform holds about the CVEs on this item.

    One row per CVE: CVSS, EPSS, whether it is on the CISA KEV list (and ransomware use), its CWE, the
    description and dates. A single finding shows its own CVE; an ENTRY shows the distinct CVEs across its
    members, the worst CVSS first, at most 50 (`total` in --format json says how many there are). A CVE the
    threat-intel table does not hold is listed as "not in the threat-intel table", not an error.

    \b
    Examples:
      torana alert 550e8400-e29b-41d4-a716-446655440000 cve-intel
      torana alert 550e8400-e29b-41d4-a716-446655440000 cve-intel --format json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    raw = ctx.obj.get(CTX_RAW, False) if ctx.obj else False

    aid = _aid(ctx)
    client = _client(ctx)
    try:
        data = client.get(f"alerts/{aid}/cve-intel")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    items = data.get("items") if isinstance(data, dict) else None
    if fmt in ("text", "table") and not raw and isinstance(items, list):
        if not items:
            click.echo("No CVE on this item.")
            return
        data = {**data, "items": [_cve_intel_row(i) for i in items]}
        output(data, fmt=fmt, raw=raw, fields=fields, columns=_CVE_INTEL_COLS)
        if data.get("truncated"):
            click.echo(f"Showing {len(items)} of {data.get('total')} CVEs (worst CVSS first).", err=True)
        return
    output(data, fmt=fmt, raw=raw, fields=fields, columns=_CVE_INTEL_COLS)


@alert.command(name="delete")
@click.option("--yes", "-y", is_flag=True, default=False, help="Skip confirmation prompt.")
@click.pass_context
def alert_delete(ctx, yes):
    """Delete an item from the Inbox for good (it does not close it).

    Use `status` to close an item and keep its history. Delete is for an item that should never have existed, such as one
    created by mistake. It cannot be undone. Asks for confirmation unless you pass --yes.

    \b
    Output:
      The platform's confirmation.

    \b
    Related:
      torana alert <UUID> close --reason wont_fix    close it and keep the history

    \b
    Examples:
      torana alert <UUID> delete
      torana alert <UUID> delete --yes
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    _confirm("Are you sure?", yes=yes)
    aid = _aid(ctx)
    path = f"alerts/{aid}"

    client = _client(ctx)
    try:
        data = client.delete(path)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="activities")
@click.option("--thread-id", "thread_id", default=None)
@click.pass_context
def alert_activities(ctx, thread_id):
    """What happened to this item: who did what, and when.

    Use this to see decisions and events as a list: verdicts, assignments, comments, questions and answers, closures, reopens
    and the agent's reads of the code. The Inbox shows the same record as the History section of `inbox`.

    \b
    Output:
      One row per event: WHEN, ACTOR, WHAT, DETAIL. --thread-id keeps only the events of one question thread.

    \b
    Related:
      torana alert <UUID> view --section history    the same history, as the Inbox words it
      torana alert <UUID> comment --comment "..."     add to it

    \b
    Examples:
      torana alert <UUID> activities
      torana alert <UUID> activities --thread-id <THREAD>
      torana alert <UUID> activities --json
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/activities"
    params = {}
    if thread_id is not None:
        params["thread_id"] = thread_id

    client = _client(ctx)
    try:
        data = client.get(path, params=params)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # Explicit columns. Without them `output` printed every field of the first activity
    # cut at 20 characters, which truncated `message` — the only column worth reading.
    items = data.get("items", data) if isinstance(data, dict) else data
    if isinstance(items, list):
        for row in items:
            if isinstance(row, dict):
                row["actor"] = _activity_actor(row)
                if row.get("activity_type") == "code_read" and code_read_detail(row.get("extra_data")):
                    row["message"] = f"{row.get('message')} [{code_read_detail(row.get('extra_data'))}]"
    cols = [("timestamp", "WHEN", 20), ("actor", "ACTOR", 24),
            ("activity_type", "WHAT", 22), ("message", "DETAIL", 100)]
    output(data, fmt=fmt, fields=fields, columns=cols)


#: The Inbox's own section headings, in the order `order` names them. `header` and `activity` are
#: printed by this command; `clears` / `affected` / `closure` are member and closure content the
#: dedicated sub-commands already serve, so they are named in the footer rather than re-rendered.
_VIEW_HEADINGS = {
    "about": "ABOUT", "exposure_path": "EXPOSURE PATH", "verdict": "VERDICT",
    "reachability": "CODE REACHABILITY", "how_to_fix": "HOW TO FIX",
    "clears": "WHAT THIS FIX CLEARS", "affected": "AFFECTED ITEMS", "reported_by": "REPORTED BY",
    "why_here": "WHY IT'S HERE", "history": "HISTORY",
    # the keys of the previous API, for a platform that has not been updated yet
    "description": "ABOUT", "fix": "HOW TO FIX", "reported": "REPORTED BY", "closure": "WHY IT'S HERE", "activity": "HISTORY",
}

#: The sections `alert <id> view --section` accepts, by their CLI key (the API key with `_` written `-`), in screen order.
#: `clears` and `affected` are the same section (the platform names it by the kind of item). The platform checks each key
#: against the kind of item and answers an unknown one with the list of valid keys.
VIEW_SECTION_KEYS = ("about", "exposure-path", "verdict", "reachability", "how-to-fix", "clears", "affected", "reported-by", "why-here", "history")


def _api_section_key(key: str) -> str:
    return key.strip().lower().replace("-", "_")


def _print_section_body(sid: str, body: dict) -> None:
    """One section as text: a platform note (`empty`, `unavailable`), the exposure path (a proof record), or its lines."""
    if not body:
        return
    if body.get("empty") or body.get("unavailable"):
        click.echo(f"    {body.get('empty') or body.get('unavailable')}")
        return
    if sid == "exposure_path" and body.get("record"):
        from torana_cli import proof_view
        for line in proof_view.graph_lines((body["record"] or {}).get("item") or {}):
            click.echo(line.lstrip("\n") if line else "")
        return
    for row in body.get("lines") or []:
        _print_view_line(row)
    for f in body.get("followUps") or []:
        click.echo(f"    → {f}")
    for block in (body.get("cves") or []) + (body.get("others") or []):
        _print_identifier_block(block)
    _print_notes(body)


def _view_time(iso) -> str:
    """An ISO timestamp in the caller's own timezone.

    ⚠️ The API sends these UNFORMATTED on purpose (lines flagged `iso`): the server cannot know the
    viewer's timezone, and the Inbox renders them in the VIEWER's. Formatting here is the CLI's half
    of that contract — print the raw value and a terminal reader silently reads UTC as local.
    """
    import datetime as _dt
    try:
        t = _dt.datetime.fromisoformat(str(iso).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return str(iso or "")
    if t.tzinfo is None:
        t = t.replace(tzinfo=_dt.timezone.utc)
    return t.astimezone().strftime("%-d %b %Y, %H:%M")


def _view_date(iso) -> str:
    """A DATE (no clock) as the Inbox writes it: "6 Sept 2026". Used for CVE publication and KEV
    dates, which are days, not moments — unlike `_view_time`, which carries a time of day."""
    import datetime as _dt
    try:
        t = _dt.datetime.fromisoformat(str(iso).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return str(iso or "")
    month = {1: "Jan", 2: "Feb", 3: "Mar", 4: "Apr", 5: "May", 6: "Jun", 7: "Jul",
             8: "Aug", 9: "Sept", 10: "Oct", 11: "Nov", 12: "Dec"}[t.month]
    return f"{t.day} {month} {t.year}"


def _line_value(row) -> str:
    """A line's text for a terminal. Dates are the CLI's to format (the platform cannot know the reader's zone): `iso` is one moment,
    `template` + `dates` is a sentence with `{0}`, `{1}` for days or moments. "Seen" is the item's sighting count: its `iso` is the last
    sighting, not the value."""
    if row.get("template") and row.get("dates"):
        return re.sub(r"\{(\d+)\}", lambda m: _view_time(row["dates"][int(m.group(1))]), row["template"])
    if row.get("iso") is True:                      # the value IS the moment (the item view's earlier shape)
        return _view_time(row.get("value"))
    if row.get("label") == "Seen" and row.get("iso"):
        return f"{row.get('value')} times, last seen {_view_time(row['iso'])}"
    return row.get("value") or ""


def _print_view_line(row, indent="  ") -> None:
    """One `Label: value` line of a section, with its links, bullets and folded extras beneath it."""
    label = row.get("label") or ""
    value = _line_value(row)
    muted = f"  {row['muted']}" if row.get("muted") else ""
    if row.get("label") == "Took over" and row.get("iso"):
        muted = f"  moved here {_view_time(row['iso'])}"
    if row.get("level") == "warning":
        indent = f"{indent}⚠ "
    if label and value:
        click.echo(f"{indent}{label}: {value}{muted}")
    elif label:
        click.echo(f"{indent}{label}:{muted}" if muted else f"{indent}{label}:")
    elif value:
        click.echo(f"{indent}{value}{muted}")
    indent = indent.replace("⚠ ", "")
    for link in row.get("links") or []:
        click.echo(f"{indent}  → {link.get('text')}  {link.get('url') or link.get('drill') or link.get('alert_id') or link.get('inbox_filter') or ''}".rstrip())
    if row.get("links_more"):                       # "and 2 more": after the links it is about, not beside the sentence
        click.echo(f"{indent}  {row['links_more']}")
    for b in row.get("bullets") or []:
        click.echo(f"{indent}  • {b}")
    # `wording` and `notes` are folded behind a toggle in the UI; the CLI has no toggle, so they are
    # printed under their own label rather than silently dropped.
    if row.get("wording"):
        click.echo(f"{indent}  ↳ in the ranking's words: {row['wording']}")
    if row.get("notes"):
        click.echo(f"{indent}  ↳ agent's notes: {row['notes']}")
    more = row.get("more")
    if isinstance(more, dict) and more.get("bullets"):
        if _all_reasons():
            for b in more["bullets"]:
                click.echo(f"{indent}  – {b}")
        else:
            click.echo(f"{indent}  ↳ {more.get('label') or 'Show all reasons'}: rerun with --all-reasons")


def _all_reasons() -> bool:
    """Whether `--all-reasons` was given: the lines' folded `more` bullets are printed instead of a hint."""
    ctx = click.get_current_context(silent=True)
    return bool(ctx and ctx.meta.get("torana_all_reasons"))


def _print_notes(body, indent="  ") -> None:
    """A section's `notes` (what its counts are over, caps, caveats), muted, under the section, as the screen shows them."""
    notes = body.get("notes") if isinstance(body, dict) else None
    for n in ([notes] if isinstance(notes, str) else notes or []):
        if n:
            click.echo(f"{indent}{n}")


def _sla_bit(head) -> str:
    """"SLA: breached (due 11 Oct 2026, 14:20)" from the server's `sla_state` and `sla_due_at`; empty when the item has none (no deadline, or closed).
    The state is the platform's; this only words it and renders the moment in the reader's zone."""
    state = (head or {}).get("sla_state")
    word = {"breached": "breached", "due_soon": "due soon", "on_track": "on track"}.get(state or "")
    if not word:
        return ""
    due = (head or {}).get("sla_due_at")
    return f"SLA: {word}" + (f" (due {_view_time(due)})" if due else "")


def _print_description(body, indent="  ") -> None:
    """A section's `description` (what the card shows), muted, under its heading. Present on every section the platform sends."""
    if isinstance(body, dict) and body.get("description"):
        click.echo(f"{indent}{body['description']}")

def _intel_value(row) -> str:
    """An intel row's text, with any dates in it rendered in the caller's timezone.

    ⚠️ A row holding dates sends `template` ("Published {0} · updated {1}") plus the ISO `dates`;
    its `value` has the ISO strings already substituted, for a reader that does not format them.
    Printing `value` here showed "Published 2026-09-06T18:17:20.553000" where the Inbox shows
    "Published 6 Sept 2026".
    """
    template = row.get("template")
    dates = row.get("dates")
    if not template or not dates:
        return row.get("value") or ""
    out = template
    for idx, iso in enumerate(dates):
        out = out.replace("{%d}" % idx, _view_date(iso))
    return out


def _print_identifier_block(block) -> None:
    """A CVE or CWE block: its heading, what is known about it, and its description."""
    heading = block.get("heading") or ""
    name = f" — {block['name']}" if block.get("name") else ""
    click.echo(f"    {heading}{name}")
    for r in block.get("rows") or []:
        lbl = r.get("label") or ""
        click.echo(f"      {lbl + ': ' if lbl else ''}{_intel_value(r)}")
    if block.get("text"):
        click.echo(f"      {block['text']}")


@alert.command(name="view")
@click.option("--section", "sections_wanted", multiple=True, type=click.Choice(VIEW_SECTION_KEYS, case_sensitive=False),
              help="Show only this section (repeatable). Without it, every section of the item. A key the item's kind does not "
                   "have (`clears` vs `affected`) is answered with the keys that kind does.")
@click.option("--activity/--no-activity", "show_activity", default=True,
              help="Include the item's history (on by default, as the Inbox shows it).")
@all_reasons_option
@click.pass_context
def alert_inbox(ctx, sections_wanted, show_activity, all_reasons):
    """The item exactly as the Inbox shows it, whole or one section at a time.

    Use this to read one item: why it is here, the verdict and who decided it, the fix, what the
    fix clears, where it was reported from and its history. To work through the Inbox use
    `torana alerts list`; to see one CVE or CWE across the app use `torana alerts cve` or
    `torana alerts cwe`.
    CODE REACHABILITY is one of those sections, and it is absent on any finding
    nothing has measured — an image-layer finding shows it only where the entity graph
    traces the image back to a repository that builds it.

    The platform builds the sections (`GET /alerts/{id}/view`) and this command only prints them,
    so the CLI and the Inbox word an item the same way. A section with nothing to say is left out
    of the whole view; asked for by name it prints the reason it is empty. `Not recorded` means the
    source never gave the value. `get` is the operator view with the runtime and triage detail the
    Inbox leaves out.

    \b
    --section keys, with what each card shows (the platform sends the same text as `description` on every section):
      {SECTIONS}

    \b
    To act on how-to-fix: make the change, then `torana remediations create --alert-id <UUID> --pr-url <URL>`;
    `torana alert <UUID> remediation --help` says what recording a plan does and does not do. `clears` and `affected` are one
    card: an entry of one remediation has `clears`, a situation entry has `affected`.

    \b
    Examples:
      torana alert 550e8400-e29b-41d4-a716-446655440000 view
      torana alert 550e8400-e29b-41d4-a716-446655440000 view --section verdict
      torana alert 550e8400-e29b-41d4-a716-446655440000 view --section verdict --section how-to-fix --format json
      torana alert 550e8400-e29b-41d4-a716-446655440000 view --section exposure-path
      torana alert 550e8400-e29b-41d4-a716-446655440000 view --section verdict --all-reasons

    Related: `alert <id> members` (the findings behind an entry), `alert <id> proof`, `alerts list`.
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    ctx.meta["torana_all_reasons"] = all_reasons

    aid = _aid(ctx)
    client = _client(ctx)
    wanted = [_api_section_key(k) for k in sections_wanted]
    try:
        data = client.get(f"alerts/{aid}/view", params={"section": wanted} if wanted else None)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt != "text" or fields or not isinstance(data, dict):
        output(data, fmt=fmt, fields=fields)
        return

    head = data.get("header") or {}
    sections = data.get("sections") or {}
    # A platform that has not been updated sends only the previous keys: read those.
    order = data.get("order_v2") or data.get("order") or []

    click.echo("")
    click.echo(head.get("name") or "")
    bits = [b for b in [
        # ⚠️ The FINDING's severity when the platform records one — that is what the Inbox shows
        # (`findingSeverity()`); the alert's own `severity` can differ ("high" vs "Critical").
        # The platform's own words when it sends them (the screen's labels); else the previous output.
        head.get("finding_severity_label") or _header_severity(head),
        head.get("verdict_label"),
        {"needs_attention": "Needs attention", "closed": "Closed",
         "moved": "Moved"}.get(head.get("box") or "", head.get("box") or ""),
        head.get("status_label") or head.get("status"),
        _sla_bit(head),
    ] if b]
    if bits:
        click.echo("  ·  ".join(str(b) for b in bits))

    for sid in order:
        if sid in ("header", "activity", "history"):
            continue
        body = sections.get(sid)
        if not body:
            continue
        # The decider / proposer is the section's header, never repeated as a line (release T1-19).
        attribution = f"  — {body['attribution']}" if body.get("attribution") else ""
        click.echo("")
        click.echo(f"{_VIEW_HEADINGS.get(sid, sid.upper())}{attribution}")
        _print_description(body)
        _print_section_body(sid, body)

    if not data.get("cve_intel_available", True):
        click.echo("")
        click.echo("  (the threat-intel table could not be read: CVE details are missing)")

    activity = data.get("activity") or []
    history = sections.get("history")
    if show_activity and ("history" in order or "activity" in order) and (activity or history):
        click.echo("")
        click.echo(f"{_VIEW_HEADINGS['history']}")
        _print_description(history)
        if history and not history.get("empty"):
            for row in history.get("lines") or []:
                _print_view_line(row)
        # The events as the server words them (history.events); an older server sends only the raw activity rows.
        events = (history or {}).get("events") if isinstance(history, dict) else None
        if events is None:
            events = [{"at": r.get("timestamp") or r.get("created_at"), "who": _activity_actor(r),
                       "what": r.get("activity_type") or "", "text": (r.get("message") or "").replace("\n", " ")}
                      for r in activity]
        for ev in events:
            if ev.get("sentence"):
                # The platform words the line (one map, the screen's words): who by source, then the sentence.
                line = " ".join(str(ev["sentence"]).split())            # one line; the full text is in --format json
                line = line if len(line) <= 160 else line[:159].rstrip() + "…"
                click.echo(f"  {_view_time(ev.get('at')):<18} {ev.get('actor_label') or ev.get('who') or '':<18} {line}")
                continue
            click.echo(f"  {_view_time(ev.get('at')):<18} {ev.get('who') or '':<18} {ev.get('what') or '':<20} {(ev.get('text') or '')[:90]}")

    total = data.get("members_total") or 0
    if total and not wanted:
        click.echo("")
        click.echo(f"  {total} finding(s) in this group — torana alert {aid} members")
    click.echo("")


with_sections_help(alert_inbox, "item")


@alert.command(name="graph")
@click.pass_context
def alert_graph(ctx):
    """Alert context graph — the entities this alert references, and their relationships.

    \b
      torana alert <UUID> graph
      torana alert <UUID> entities    # just the entity summary, no relationships
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"api/graph/alert/{_aid(ctx)}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="entities")
@click.pass_context
def alert_entities(ctx):
    """Alert entity summary — which entities this alert's results reference.

    \b
      torana alert <UUID> entities
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    client = _client(ctx)
    try:
        data = client.get(f"api/graph/alert/{_aid(ctx)}/entities")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="proof")
@click.option("--claim", "claim_id", default=None, metavar="CLAIM_ID",
              help="Trace one claim: every row, selection, column meaning and rule output behind it.")
@click.option("--save", "save_path", default=None, metavar="FILE", type=click.Path(dir_okay=False),
              help="Also write the proof record (JSON) to FILE, for `torana datalake proof verify|replay`.")
@click.pass_context
def alert_proof(ctx, claim_id, save_path):
    """Show the proof for this alert: each claim and the rows, rules and meanings behind it.

    Every value in a claim points at what it was read from (a datalake row, a selection, a column
    meaning, the build clock, or a rule output), so it can be traced, replayed and re-verified. The header
    line names the item type. Modelled: vuln_in_image (a CVE finding on a container image), fix_entry and
    mitigation_entry (also an Inbox entry "Upgrade X" / "Mitigate X" for one package), threat_signal,
    posture_summary, code_finding (a SAST, IaC or secrets finding in one file of a repository: its state, lines,
    rule, whether the code ships to running services, and its owner), group_check (an alert that stands for a group its
    rule declared: how many rows it covers and how many are open); each also carries the alert's own facts.
    Any other item answers "No proof model for this item type yet" (not modelled, not "no evidence"). Read-only.

    \b
    Examples:
      torana alert <UUID> proof
      torana alert <UUID> proof --claim stale
      torana alert <UUID> proof --save /tmp/proof.json
      torana alert <UUID> proof --format json
    """
    from torana_cli import proof_view

    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        rec = client.get(f"datalake/proof/alerts/{_aid(ctx)}")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if save_path:
        proof_view.save(save_path, rec)
    if claim_id and claim_id not in proof_view.claim_ids(rec):
        click.echo(f"ERROR: no claim '{claim_id}' on this item. Claims: "
                   f"{', '.join(proof_view.claim_ids(rec)) or '(none)'}", err=True)
        ctx.exit(2)
    if fmt not in ("text", "table"):
        output(rec, fmt=fmt)
    elif claim_id:
        proof_view.echo(proof_view.claim_lines(rec, claim_id))
    else:
        proof_view.echo(proof_view.record_lines(rec))


@alert.command(name="assessment")
@click.pass_context
def alert_assessment(ctx):
    """Show this item's assessments: the effort estimate, and how strong the evidence behind it is.

    An assessment answers a question about the item that no row states. Today the question is effort: a range of
    days for an upgrade (fix_entry) or a code finding (code_finding), computed by the platform from rows it already
    holds. It is marked "◈ assessed": an estimate, never a proven fact. Under the line: "Based on N checks. K more are
    not available yet."; "How we got this", one row per part (edit, review, test, rollout) with its reason and days, their sum, and
    one sentence on why it is a range; "What it rests on", the checks that are in; "Not checked yet:", the missing checks, each
    with what is not known ("*" marks the ones that matter most to accuracy). The platform cannot run those yet: an
    instruction is printed only under "What you can do now", when there is something you can act on.

    The estimate is the platform's. Quote it as printed; never restate, round or recompute it. An item type with no
    assessment yet (a mitigation, a vulnerability in an image) prints so and exits 3. Read-only.

    \b
    Examples:
      torana alert <UUID> assessment
      torana alert <UUID> assessment --format json
    """
    from torana_cli import assessment_view

    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    try:
        body = client.get(f"datalake/proof/alerts/{_aid(ctx)}/assessment")
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt not in ("text", "table"):
        output(body, fmt=fmt)
    elif not body.get("assessments"):
        click.echo(assessment_view.no_assessment(body))
    else:
        click.echo("\n".join(assessment_view.body_lines(body)))
    if not body.get("assessments"):
        ctx.exit(3)


def _brief_run(ctx, workspace_id, write, wait):
    """Show the AI brief for this alert, or with `write` write a new one (and with `wait` wait for it)."""
    from torana_cli import brief_view

    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    client = _client(ctx)
    aid = _aid(ctx)
    try:
        ws = workspace_id or (ctx.obj or {}).get("_workspace_id") or brief_view.alert_workspace(client, aid)
        if not ws:
            click.echo("ERROR: this alert has no workspace; pass --workspace <WORKSPACE_ID>.", err=True)
            ctx.exit(2)
        if write:
            started = brief_view.write(client, ws, aid)
            if not wait:
                click.echo(f"Writing brief {started['brief_id']}. Show it with: torana alert {aid} brief")
                return
            row = brief_view.wait(client, ws, aid, started["brief_id"])
            latest = {"latest_ready": row if row["status"] == "ready" else None, "in_flight": None, "latest": row}
        else:
            latest = brief_view.latest(client, ws, aid)
            if latest is None:
                click.echo(f"No brief yet. Write one with: torana alert {aid} brief write --wait")
                ctx.exit(3)
        check = brief_view.check(client, ws, aid, latest)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if fmt not in ("text", "table"):
        output({**latest, "staleness": check}, fmt=fmt)
    else:
        click.echo("\n".join(brief_view.lines(latest, check, aid)))


_BRIEF_WORKSPACE = click.option("--workspace", "workspace_id", default=None, metavar="WORKSPACE_ID",
                                help="The app (workspace) the item belongs to. Default: the alert's own workspace.")


def _brief_flag_moved(value, flag):
    """`brief --write` and `brief --wait` are gone: reading a brief never writes one. Exit 2 and say where the write went."""
    if value:
        raise click.UsageError(f"`brief {flag}` no longer exists: `brief` only reads. To write a new brief use `brief write` "
                               "(add `--wait` there to wait for it).")
    return value


@alert.group(name="brief", invoke_without_command=True)
@_BRIEF_WORKSPACE
@click.option("--write", "write", is_flag=True, hidden=True, expose_value=False, callback=lambda c, p, v: _brief_flag_moved(v, "--write"))
@click.option("--wait", "wait", is_flag=True, hidden=True, expose_value=False, callback=lambda c, p, v: _brief_flag_moved(v, "--wait"))
@click.pass_context
def alert_brief(ctx, workspace_id):
    """Show the AI brief for this alert: proven claims in prose, each sentence with the claims it cites.

    Reading a brief changes nothing. To write a new one (one AI call, about a minute) use `brief write`.

    A brief is written by one AI call over this item's proven claims only, and checked by code: every
    number, id and name in a sentence must appear in a claim it cites. Shown against the item's proof as
    it is NOW: a sentence whose claims changed since it was written is marked "◇ claims changed since
    written"; one whose claim only aged (e.g. "37.9 hours ago") is dated "as of <build time>".

    \b
    Examples:
      torana alert <UUID> brief
      torana alert <UUID> brief --format json
      torana alert <UUID> brief write --wait
    """
    if ctx.invoked_subcommand is not None:
        ctx.meta["torana_brief_workspace"] = workspace_id
        return
    _brief_run(ctx, workspace_id, False, False)


@alert_brief.command(name="get")
@_BRIEF_WORKSPACE
@click.pass_context
def alert_brief_get(ctx, workspace_id):
    """Show the latest AI brief for this alert (the same as `brief`). Changes nothing."""
    _brief_run(ctx, workspace_id or ctx.meta.get("torana_brief_workspace"), False, False)


@alert_brief.command(name="write")
@_BRIEF_WORKSPACE
@click.option("--wait", "wait", is_flag=True,
              help="Check every 5 s until the brief is ready or failed (up to 10 minutes).")
@click.pass_context
def alert_brief_write(ctx, workspace_id, wait):
    """Write a NEW AI brief for this alert: one AI call over its proven claims (about a minute).

    This starts work and stores a new brief, which is why it is its own command; `brief` only reads.

    \b
    Examples:
      torana alert <UUID> brief write
      torana alert <UUID> brief write --wait
    """
    _brief_run(ctx, workspace_id or ctx.meta.get("torana_brief_workspace"), True, wait)


@alert.command(name="status")
@click.option("--status", "status", type=click.Choice(["closed", "resolved"], case_sensitive=False),
              required=True,
              help="Close the item: closed or resolved. This command only closes. To reopen "
                   "use `reopen`; to escalate, `escalate`; to give a verdict, `verdict`; "
                   "to send it to the agent, `assign --assignee-type agent`.")
@click.option("--resolution-reason", "resolution_reason",
              # Rows 3.2 / 3.27: a person's six. auto_resolved is the platform's default
              # for a closure given no reason, and the API refuses it from a person.
              type=click.Choice(["fixed", "accepted_risk", "wont_fix", "duplicate", "benign", "false_positive"], case_sensitive=False),
              default=None,
              help="Reason for alert closure. Recorded on the Alert row; "
                   "typically set together with --status closed.")
@click.option("--message", "message", default=None)
@click.pass_context
def alert_status(ctx, status, resolution_reason, message):
    """Close an item, recording you as who closed it.

    The item moves to the Closed box. The finding itself is not changed. A closed item
    is refused with the reason (HTTP 409). `torana alert <id> close --reason <reason>` does the
    same thing under a plainer name.

    \b
    Examples:
      torana alert <id> status --status closed --resolution-reason accepted_risk --message "Compensating control in place"
      torana alert <id> status --status resolved --resolution-reason fixed
      torana alert <id> status --status closed --resolution-reason false_positive
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/status"
    body = {}
    body["status"] = status
    if resolution_reason is not None:
        body["resolution_reason"] = resolution_reason
    if message is not None:
        body["message"] = message

    client = _client(ctx)
    try:
        data = client.put(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="close")
@click.option("--reason", "resolution_reason", required=True,
              type=click.Choice(["fixed", "accepted_risk", "wont_fix", "duplicate", "benign", "false_positive"], case_sensitive=False),
              help="Why it is closed. Recorded on the item and shown as the reason it is closed.")
@click.option("--message", "message", default=None, help="A note recorded with the closure.")
@click.pass_context
def alert_close(ctx, resolution_reason, message):
    """Close an item, recording you as who closed it and why.

    The plain form of `torana alert <id> status --status closed --resolution-reason <reason>`: the same
    permission, the same history line, the same result. The item moves to the Closed box; the finding
    itself is not changed. To open it again use `reopen`.

    \b
    Examples:
      torana alert <id> close --reason wont_fix
      torana alert <id> close --reason accepted_risk --message "Compensating control in place"
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    body = {"status": "closed", "resolution_reason": resolution_reason}
    if message is not None:
        body["message"] = message
    client = _client(ctx)
    try:
        data = client.put(f"alerts/{_aid(ctx)}/status", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields)


def _person_action(ctx, verb: str, message):
    """POST alerts/<id>/<verb> with an optional note, and print the item it returns."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    body = {"message": message} if message is not None else {}
    client = _client(ctx)
    try:
        data = client.post(f"alerts/{_aid(ctx)}/{verb}", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    if fmt == "text" and not fields and isinstance(data, dict):
        _print_alert_head(data)
        return
    output(data, fmt=fmt, fields=fields)


@alert.command(name="reopen")
@click.option("--message", "message", default=None, help="Why, for the item's history.")
@click.pass_context
def alert_reopen(ctx, message):
    """Reopen a closed item.

    It goes back to Needs attention. The verdict a platform closure replaced comes back,
    and the item is pending_remediation when that verdict is true positive, otherwise
    open. Reopening a platform closure stops the platform closing it again for the same
    reason. The closure stays in its history. Refused (HTTP 409) on an item that is not
    closed.

    \b
    Example:
      torana alert <id> reopen --message "Still reported by the scanner"
    """
    _person_action(ctx, "reopen", message)


@alert.command(name="keep-closed")
@click.option("--message", "message", default=None, help="Why, for the item's history.")
@click.pass_context
def alert_keep_closed(ctx, message):
    """Agree with a closure the platform made, so it becomes yours.

    Status, reason and verdict stay as they are, and the platform never reopens it. Refused (HTTP 409) on an open item and on one a person
    already closed.

    \b
    Example:
      torana alert <id> keep-closed --message "Confirmed decommissioned"
    """
    _person_action(ctx, "keep-closed", message)


@alert.command(name="severity")
@click.option("--severity", "severity", type=click.Choice(["low", "medium", "high", "critical"], case_sensitive=False), required=True)
@click.option("--message", "message", default=None)
@click.pass_context
def alert_severity(ctx, severity, message):
    """Change an item's severity (low, medium, high or critical) and record why.

    Use this when the severity the platform computed is wrong for this item and a person has judged it. The change is recorded in
    the item's history with your name and the message. It changes the item's urgency and SLA, not its verdict or status.

    \b
    Output:
      The updated item.

    \b
    Related:
      torana alert <UUID> verdict    say whether the finding is real
      torana alerts sla-policy get   the hours each severity allows

    \b
    Examples:
      torana alert <UUID> severity --severity high --message "Internet-facing in production"
      torana alert <UUID> severity --severity low
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/severity"
    body = {}
    body["severity"] = severity
    if message is not None:
        body["message"] = message

    client = _client(ctx)
    try:
        data = client.put(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="assign")
@click.option("--assigned-to", "assigned_to", required=True)
@click.option("--assignee-type", "assignee_type", type=click.Choice(["user", "agent", "unassigned"], case_sensitive=False), default=None, help="Type of assignee (user or agent).")
@click.option("--assignee-display-name", "assignee_display_name", default=None, help="Human-readable name of the assignee, stored alongside UUID for display")
@click.option("--message", "message", default=None)
@click.pass_context
def alert_assign(ctx, assigned_to, assignee_type, assignee_display_name, message):
    """Assign this alert to a person or to an agent.

    A person is a USER IN THIS TENANT, given as their UUID or their email address; the
    platform stores the UUID. Anything else (a team or queue name, another tenant's address)
    is refused with 422 and the valid forms. To clear the assignee use `unassign`.

    \b
    Examples:
      torana alert <UUID> assign --assigned-to jay@acme.com
      torana alert <UUID> assign --assigned-to <user-uuid> --message "taking this one"
      torana alert <UUID> assign --assigned-to <agent-uuid> --assignee-type agent
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/assign"
    body = {}
    body["assigned_to"] = assigned_to
    if assignee_type is not None:
        body["assignee_type"] = assignee_type
    if assignee_display_name is not None:
        body["assignee_display_name"] = assignee_display_name
    if message is not None:
        body["message"] = message

    client = _client(ctx)
    try:
        data = client.put(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


def _move_member(ctx, entry_id):
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None
    client = _client(ctx)
    try:
        data = client.put(f"alerts/{_aid(ctx)}/entry", json={"entry_id": entry_id})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return
    output(data, fmt=fmt, fields=fields)


@alert.command(name="move")
@click.argument("entry_id")
@click.pass_context
def alert_move(ctx, entry_id):
    """Move this member to another Inbox entry.

    The choice stays until a person changes it: no later sighting or grouping change undoes it.
    Both entries are recomputed (severity, priority, version, title, status) in the same step,
    and each side records an activity line.

    \b
    Example:
      torana alert <member-UUID> move <entry-UUID>
    """
    _move_member(ctx, entry_id)


@alert.command(name="split")
@click.pass_context
def alert_split(ctx):
    """Split this member out of its entry so it is its own Inbox entry.

    The choice stays until a person changes it. The member takes the owner of the entry it left
    (unless a person chose its owner), and both are recomputed.

    \b
    Example:
      torana alert <member-UUID> split
    """
    _move_member(ctx, None)


@alert.command(name="unassign")
@click.option("--message", "message", default=None,
              help="Why, recorded in the item's activity.")
@click.pass_context
def alert_unassign(ctx, message):
    """Clear this alert's assignee, leaving it unassigned.

    Sends assignee_type=unassigned with an empty assignee, which the platform stores as no
    assignee (NULL). The item's status and verdict are not changed.

    \b
    Examples:
      torana alert <UUID> unassign
      torana alert <UUID> unassign --message "back to the queue"
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    body = {"assigned_to": "", "assignee_type": "unassigned"}
    if message is not None:
        body["message"] = message

    client = _client(ctx)
    try:
        data = client.put(f"alerts/{aid}/assign", json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="comment")
@click.option("--comment", "comment", required=True)
@click.pass_context
def alert_comment(ctx, comment):
    """Leave a comment on an item, shown in its history under your name.

    Use this for a note to whoever opens the item next: what you checked, why you decided, what is still unknown. A comment does
    not change the item's status, verdict or assignee. Write plain words; a person reads it.

    \b
    Output:
      The new history entry.

    \b
    Related:
      torana alert <UUID> activities               read the comments and everything else
      torana alert <UUID> question --question ...  ask the item's agent something instead

    \b
    Examples:
      torana alert <UUID> comment --comment "Checked with the owner: this service is retired next month"
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/comments"
    body = {}
    body["comment"] = comment

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


def entry_verdict_lines(data, verdict: str):
    """The text for a verdict that was applied to an ENTRY's open members: how many findings took
    it, then each refused finding with its reason (never silent). None when `data` is not that."""
    if not isinstance(data, dict) or data.get("status") != "applied_to_members":
        return None
    n = int(data.get("applied") or 0)
    words = verdict.replace("_", " ")
    lines = [f"Confirmed {n} finding{'' if n == 1 else 's'} as {words}."]
    refused = data.get("refused") or []
    if refused:
        lines.append(f"{len(refused)} finding{' was' if len(refused) == 1 else 's were'} refused:")
        lines += [f"  {str(r.get('member_id', ''))[:8]}: {r.get('reason', '')}" for r in refused]
    return lines


@alert.command(name="verdict")
@click.option("--triage-verdict", "triage_verdict", required=True,
              type=click.Choice(["true_positive", "false_positive", "benign", "inconclusive"],
                                case_sensitive=False),
              help="Triage classification verdict.")
@click.option("--triage-summary", "triage_summary", default=None,
              help="Summary of triage findings")
@click.option("--message", "message", default=None,
              help="Optional message to record with the verdict")
@click.option("--reason-code", "reason_code", default=None,
              help="WHY this verdict was reached — one code from `torana alerts reason-codes` (run it to see every ground, "
                   "the verdicts each accompanies and what each says). Optional for a person; the triage agent must supply one "
                   "once guards are on. A code that does not accompany this verdict is refused, naming the ones that do. "
                   "The grounds that say the AGENT read the code or the record (agent_confirmed_by_analysis, "
                   "agent_confirmed_from_record) describe the agent's own work: they are for the triage agent, so as a person "
                   "give the ground you actually rest on and put what you found in --verdict-evidence.")
@click.option("--proposed-fix", "proposed_fix", default=None,
              help="One sentence a developer can act on, e.g. 'Upgrade lodash 4.17.20 to 4.17.21'. "
                   "Shown on the alert; NOT the same field as remediation_summary, which the "
                   "remediation service overwrites with the pull-request reference.")
@click.option("--verdict-evidence", "verdict_evidence", default=None,
              help="What you found and where (the document, the control, the precondition). "
                   "Required when the reason code closes on evidence the platform does not "
                   "hold (ground `new_evidence` in `torana alerts reason-codes`); omit it "
                   "otherwise. Shown on the alert for a person to judge.")
@click.option("--resolution-reason", "resolution_reason", default=None,
              type=click.Choice(["fixed", "accepted_risk", "false_positive", "benign",
                                 "duplicate", "wont_fix", "auto_resolved"],
                                case_sensitive=False),
              help="Override the default resolution reason on a closing verdict.")
@click.option("--remediation-action", "remediation_action", default=None,
              help="WHAT to do about a confirmed finding (true_positive only): upgrade, "
                   "roll_back (a downgrade to an older version), mitigate, fix, configure, "
                   "rotate, rebuild, accept or none. accept and none "
                   "are recorded and take no target (they close nothing). See `torana alerts remediation-vocabulary`.")
@click.option("--remediation-target-type", "remediation_target_type", default=None,
              help="WHAT it is done to: package, code_location, service, image, config_setting "
                   "or secret. Which types each action takes is in the vocabulary. The platform "
                   "takes the target's identity from the finding; do not supply it.")
@click.option("--remediation-target-version", "remediation_target_version", default=None,
              help="The version to move to. Only for upgrade, roll_back and rebuild.")
@click.option("--follow-up-action", "follow_up_actions", multiple=True,
              help="One plain-word action the verdict asks of people: who should act and what "
                   "they do. Repeat for several. Allowed on any verdict.")
@click.option("--continuity-note", "continuity_note", default=None,
              help="Three to five sentences for the next triage of this finding: what decided "
                   "this verdict and what new fact would change it. Allowed on any verdict.")
@click.option("--assign-to", "--assignee", "assignee", default=None,
              help="On a true-positive verdict: the person who should own the finding (a user "
                   "UUID or email in this tenant). Omit it and the tenant admin owns it.")
@click.pass_context
def alert_verdict(ctx, triage_verdict, triage_summary, message, reason_code, proposed_fix,
                  verdict_evidence, resolution_reason, remediation_action,
                  remediation_target_type, remediation_target_version, follow_up_actions,
                  continuity_note, assignee):
    """Set the triage verdict on this alert.

    \b
    Examples:
      torana alert <UUID> verdict --triage-verdict true_positive \\
        --reason-code exposed_and_fixable \\
        --proposed-fix "Upgrade lodash 4.17.20 to 4.17.21"
      torana alerts reason-codes          # the grounds a verdict may cite
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/verdict"
    body = {}
    body["triage_verdict"] = triage_verdict
    if triage_summary is not None:
        body["triage_summary"] = triage_summary
    if message is not None:
        body["message"] = message
    if reason_code is not None:
        body["reason_code"] = reason_code
    if proposed_fix is not None:
        body["proposed_fix"] = proposed_fix
    if verdict_evidence is not None:
        body["verdict_evidence"] = verdict_evidence
    if resolution_reason is not None:
        body["resolution_reason"] = resolution_reason.lower()
    if follow_up_actions:
        body["follow_up_actions"] = list(follow_up_actions)
    if continuity_note is not None:
        body["continuity_note"] = continuity_note
    if assignee is not None:
        body["assignee"] = assignee
    for _k, _v in (("remediation_action", remediation_action),
                   ("remediation_target_type", remediation_target_type),
                   ("remediation_target_version", remediation_target_version)):
        if _v is not None:
            body[_k] = _v

    client = _client(ctx)
    try:
        data = client.put(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # The platform may RECORD the verdict rather than apply it, when the tenant's
    # triage-autonomy policy says a person decides. That is a success, not a failure —
    # say so plainly instead of printing a bare {"status": "recommended"}.
    if fmt == "text" and isinstance(data, dict) and data.get("status") == "recommended":
        click.echo(f"Recommended (autonomy level {data.get('autonomy_level', 'Manual')}); "
                   f"a person must confirm it.")
        return

    # A verdict on an ENTRY is applied to its open members: say how many, and name every refusal.
    entry_lines = entry_verdict_lines(data, triage_verdict) if fmt == "text" else None
    if entry_lines:
        for line in entry_lines:
            click.echo(line)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="invoke")
@click.pass_context
def alert_invoke(ctx):
    """Invoke Triage."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/triage/invoke"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    # ⚠️ TEXT ONLY, and the asymmetry is deliberate. The response model carries every field
    # so JSON keeps a stable shape, but an outcome legitimately holds fewer facts than the
    # model can — `already_recorded` has no verdict and no priority at all — and a reader
    # shown "PRIORITY KEPT BY  None" reads None as the answer rather than as "this outcome
    # has no such fact". Measured on demo: a second write at the same commit printed four.
    if fmt == "text" and isinstance(data, dict):
        data = {k: v for k, v in data.items() if v is not None}

    output(data, fmt=fmt, fields=fields)


@alert.command(name="cancel")
@click.pass_context
def alert_cancel(ctx):
    """Cancel Triage."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/triage/cancel"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="question")
@click.option("--question", "question", required=True, help="Question to ask about the alert")
@click.option("--thread-id", "thread_id", default=None, help="Optional thread ID to group related questions")
@click.option("--parent-activity-id", "parent_activity_id", default=None, help="Optional parent activity ID for reply threading")
@click.pass_context
def alert_question(ctx, question, thread_id, parent_activity_id):
    """Ask the item's triage agent a question; the answer arrives in the item's history.

    Use this to ask why the agent decided as it did, or to ask it to look again. The question is recorded at once and the answer
    is produced afterwards, so this returns before the answer exists. Read it with `activities`, or in the History section of
    `inbox`. The agent answers only when the item is assigned to one; otherwise the question waits as a note.

    \b
    Output:
      The ids of the recorded question (activity_id and thread_id). Use the thread_id to follow up.

    \b
    Related:
      torana alert <UUID> activities --thread-id <THREAD>   read the answer
      torana alert <UUID> comment --comment "..."            leave a note without asking anything

    \b
    Examples:
      torana alert <UUID> question --question "Why is this reachable from the internet?"
      torana alert <UUID> question --question "And in staging?" --thread-id <THREAD>
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/question"
    body = {}
    body["question"] = question
    if thread_id is not None:
        body["thread_id"] = thread_id
    if parent_activity_id is not None:
        body["parent_activity_id"] = parent_activity_id

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="remediation")
@click.option("--remediation-instructions", "remediation_instructions", required=True, help="Instructions or description of remediation actions to take")
@click.option("--auto-remediate", "auto_remediate", type=bool, default=False, help="Whether to attempt automatic remediation")
@click.pass_context
def alert_remediation(ctx, remediation_instructions, auto_remediate):
    """Record the plan for fixing an item, in the item's history. It does not open a pull request or change the item's status.

    Use this to write down what is being done about the item and by whom, so the next person sees it in the History section.
    The text is saved as the item's remediation summary and a "remediation started" entry is added to its history.
    --auto-remediate is recorded with the entry; nothing acts on it yet.

    \b
    What starts the fix itself:
      The proposed fix is in `torana alert <UUID> view --section how-to-fix` (the upgrade or the change, and what it clears).
      Make the change, open the pull request, then link it with `torana remediations create --alert-id <UUID> --pr-url <URL>`.
      That moves the item to pending remediation. `torana remediation <ID> set-state` follows the pull request to merged.

    \b
    Output:
      {"status": "success"}

    \b
    Related:
      torana alert <UUID> view --section how-to-fix   what to change, and what the change clears
      torana remediations create --alert-id <UUID> --pr-url <URL>   link the pull request
      torana remediations list --alert-id <UUID>        the pull requests already linked

    \b
    Examples:
      torana alert <UUID> remediation --remediation-instructions "Upgrade pyjwt to 2.15.0 in services/auth; PR by Friday"
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/remediation"
    body = {}
    body["remediation_instructions"] = remediation_instructions
    if auto_remediate is not None:
        body["auto_remediate"] = auto_remediate

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="escalate")
@click.option("--escalation-reason", "escalation_reason", required=True, help="Reason for escalation")
@click.option("--escalate-to", "escalate_to", default=None, help="Optional specific user/agent/team to escalate to")
@click.pass_context
def alert_escalate(ctx, escalation_reason, escalate_to):
    """Hand an item to a person because it cannot be decided here, and say why.

    Use this when the evidence is inconclusive and a person must judge. Do not use it for a confirmed finding: a confirmed
    finding is already "to be fixed". It does not change the assignee; use `assign` as well if a person or queue should own it.
    Allowed on an open item only: a closed or already-escalated item is refused (HTTP 409); reopen it first.

    \b
    Output:
      The updated item, now escalated.

    \b
    Related:
      torana alert <UUID> assign --assigned-to <USER>    give it an owner
      torana alert <UUID> verdict --triage-verdict ...    decide it instead

    \b
    Examples:
      torana alert <UUID> escalate --escalation-reason "Cannot tell if the endpoint is reachable from outside"
      torana alert <UUID> escalate --escalation-reason "Needs the service owner" --escalate-to payments-team
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/escalate"
    body = {}
    body["escalation_reason"] = escalation_reason
    if escalate_to is not None:
        body["escalate_to"] = escalate_to

    client = _client(ctx)
    try:
        data = client.post(path, json=body)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="compress-context")
@click.pass_context
def alert_compress_context(ctx):
    """Compress Context."""
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/compress-context"

    client = _client(ctx)
    try:
        data = client.post(path, json={})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


@alert.command(name="provenance")
@click.pass_context
def alert_provenance(ctx):
    """Show how this alert came to exist — full provenance + pipeline trace.

    \b
    Walks bottom→top: the originating RULE and how it was triggered (manual /
    scheduled / suite), the rule run, the alert (finding), and every pipeline
    stage it passed through — each with status + timing. Backed by
    GET /api/v1/pipeline/trace/by-alert/{id}.

    \b
    Example:
      torana alert <UUID> provenance
      torana alert <UUID> provenance --json
    """
    # Shared renderer/fetch lives in pipeline.py (single owner of the trace
    # endpoint + provenance formatting). Imported lazily to avoid any import cycle.
    from torana_cli.pipeline import provenance_by_alert_core
    provenance_by_alert_core(ctx, _aid(ctx))


@alert.command(name="triage-context")
@click.option("--rendered", is_flag=True, default=False,
              help="Also print the message the triage agent saw on its last run "
                   "and the one it would receive now.")
@click.pass_context
def alert_triage_context(ctx, rendered):
    """What the triage agent was given to decide this item: the facts it saw, and how it looked up the evidence.

    Use this to check why the agent decided as it did: what the platform put in front of it. Add --rendered to see the actual
    message of its last run and the one it would get if run now.

    \b
    With --rendered (text format), prints the first message of the agent's
    last run under "Last run", then the message it would receive if invoked
    now under "If invoked now". JSON/YAML carry both as fields.

    \b
    Output:
      The context record (JSON-like). With --rendered in text format, the two messages under "Last run" and "If invoked now".

    \b
    Related:
      torana alert <UUID> view --section verdict    the verdict and the reasons, as the Inbox shows them
      torana alert <UUID> proof                      the evidence behind each claim

    \b
    Examples:
      torana alert <UUID> triage-context
      torana alert <UUID> triage-context --rendered
    """
    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    aid = _aid(ctx)
    path = f"alerts/{aid}/triage-context"

    client = _client(ctx)
    try:
        data = client.get(path, params={"rendered": "true"} if rendered else None)
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    if rendered and fmt == "text" and isinstance(data, dict) and (
            data.get("last_run_message") or data.get("rendered_message")):
        _echo_triage_messages(data)
        return
    output(data, fmt=fmt, fields=fields)


def _echo_triage_messages(data: dict) -> None:
    """Print the last run's first message, then the one the agent would get now."""
    sections = [("Last run", data.get("last_run_message")),
                ("If invoked now", data.get("rendered_message"))]
    first = True
    # How the posture-record lookup went (found / not_found / failed / not_posture): a `failed` one is why the prompt
    # fell back to the rule's matched row, so it is said first, with the datalake's error.
    lookup = data.get("posture_lookup")
    if isinstance(lookup, dict) and lookup.get("status"):
        click.echo(f"Posture lookup: {lookup['status']}" + (f" ({lookup['error']})" if lookup.get("error") else ""))
        first = False
    for header, message in sections:
        if not message:
            continue
        if not first:
            click.echo("")
        click.echo(f"=== {header} ===")
        click.echo(message)
        first = False


@alert.command(name="reachability")
@click.option("--verdict", "verdict", required=True,
              type=click.Choice(["not_imported", "build_only", "no_path_from_entry_point",
                                 "reachable", "inconclusive"], case_sensitive=False),
              help="What a deterministic read of the repository found. Only the first three "
                   "lower an item; `reachable` and `inconclusive` are recorded and change no "
                   "order.")
@click.option("--commit", "commit", required=True, metavar="SHA",
              help="The commit the analysis read. ⛔ REQUIRED: without it 'not imported' and "
                   "'not imported as of last Tuesday' read identically, and the platform's "
                   "rule is that an unmeasured answer must never look like a measured one.")
@click.option("--analyzer", "analyzer", required=True, metavar="NAME",
              help="Which engine said it, e.g. 'import-index/1' or 'callgraph/1'. A verdict "
                   "outlives the version that produced it.")
@click.option("--repository", "repository", required=True, metavar="REPO_KEY",
              help="⛔ REQUIRED. The repo:<host>/<org>/<repo> you measured. The write is "
                   "REFUSED (422) unless this alert's finding key is bound to that same "
                   "repository — a source scan read one tree and may only speak for that "
                   "tree. An Inbox entry, and a member found in a built image, are bound to "
                   "no repository and so cannot be answered this way at all.")
@click.option("--evidence-file", "evidence_file", default=None, metavar="FILE",
              help="JSON/YAML holding the rest of the evidence this verdict needs ('-' reads "
                   "stdin). not_imported: files_scanned. build_only: files_scanned, scopes. "
                   "no_path_from_entry_point: function, entry_points_considered. reachable: "
                   "function, path. inconclusive: reason.")
@click.pass_context
def alert_reachability(ctx, verdict, commit, analyzer, repository, evidence_file):
    """Record a measured code-reachability verdict, lowering the priority if it says so.

    The ranking orders the Inbox from facts it holds and deliberately does NOT claim a
    finding's code runs. This is where that missing fact arrives, measured at a named commit.

    A verdict only ever lowers an item. Idempotent per (alert, commit): a repeat for the same
    commit returns `already_recorded` and writes nothing, so an at-least-once cron is safe.
    A new commit is a new fact and does append.

    ⛔ The answer may not leave the tree it was measured in: `--repository` must name the
    repository this alert's finding is bound to, or the write is refused.

    \b
    Examples:
      # in the lockfile, in no import statement — the strongest absence claim
      echo '{"files_scanned":71}' > ev.json
      torana alert <UUID> reachability --verdict not_imported --commit a1b2c3d --analyzer import-index/1 --repository repo:github.com/acme/api --evidence-file ev.json
    \b
      # a SAST finding whose function nothing calls from an entry point
      echo '{"function":"check_redirect_uri","entry_points_considered":101}' > ev.json
      torana alert <UUID> reachability --verdict no_path_from_entry_point --commit a1b2c3d --analyzer callgraph/1 --repository repo:github.com/acme/api --evidence-file ev.json
    \b
      # confirmation — recorded, order unchanged. '-' reads stdin, for a cron.
      echo '{"function":"decode_jwt_token","path":["oauth_token","decode_jwt_token"]}' | torana alert <UUID> reachability --verdict reachable --commit a1b2c3d --analyzer callgraph/1 --repository repo:github.com/acme/api --evidence-file -
    """  # noqa: E501 — Click renders a \b block verbatim, so an example must not be wrapped
    from torana_cli.rules import _load_input_file

    fmt = ctx.obj.get(CTX_FORMAT, "text") if ctx.obj else "text"
    fields = ctx.obj.get(CTX_FIELDS) if ctx.obj else None

    evidence = _load_input_file(evidence_file) if evidence_file else {}
    if not isinstance(evidence, dict):
        click.echo("ERROR: --evidence-file must hold an object, not a list or scalar.", err=True)
        sys.exit(2)
    # ⚠️ The three universals are FLAGS, not file keys, so a missing one fails here with a
    # usage error naming it rather than reaching the API as a 422 about evidence. They are
    # merged in (and win) so the file cannot disagree with what was asked for on the command
    # line — and `repository` in particular decides whether the write is allowed at all.
    evidence = {**evidence, "commit": commit, "analyzer": analyzer, "repository": repository}

    aid = _aid(ctx)
    path = f"alerts/{aid}/reachability"

    client = _client(ctx)
    try:
        data = client.post(path, json={"verdict": verdict.lower(), "evidence": evidence})
    except APIError as e:
        handle_api_error(e)
        return
    except AuthError as e:
        handle_auth_error(e)
        return

    output(data, fmt=fmt, fields=fields)


#: Operator commands: callable as before, out of the default listing (INBOX_SECTIONS_SPEC § 3.4.3.4; see
#: `skills/torana-skill/references/detection.md`, "Operator commands").
for _name in ("invoke", "cancel", "compress-context"):
    if alert.commands.get(_name) is not None:
        alert.commands[_name].hidden = True


def _hidden_alias(group, command, old_name):
    """Register `command` under its older spelling too, hidden from `--help`, so existing scripts and skills keep working."""
    import copy
    alias = copy.copy(command)
    alias.name, alias.hidden = old_name, True
    group.add_command(alias, name=old_name)


_hidden_alias(alert, alert_inbox, "inbox")             # `alert <ID> inbox` is now `alert <ID> view`
