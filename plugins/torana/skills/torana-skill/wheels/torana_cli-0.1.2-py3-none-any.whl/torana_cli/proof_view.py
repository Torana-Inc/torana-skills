"""Text rendering for proof records (`torana alert <ID> proof`, `torana datalake proof verify|replay`).

A proof record is what GET /api/v1/datalake/proof/alerts/{id} returns: claims whose every span carries a
pointer to the row, selection, column meaning, clock or rule output behind it. Spec:
pantheon-datalake/docs/PROOF_FRAMEWORK_SPEC.md § 3.4.2. JSON output passes the record through untouched;
everything here is presentation only.
"""
from __future__ import annotations

import json

import click

SECTION_TITLES = {"alert": "The alert", "state": "What is actually true", "deep": "Deep-dive", "tech": "Technical", "fix": "Remediation"}
_MAX_VALUE = 120
_RULE_DEPTH = 3


def plain(spans) -> str:
    return "".join(s.get("text", "") for s in spans or [])


def _short(value) -> str:
    s = json.dumps(value, sort_keys=True, default=str, ensure_ascii=False)
    return s if len(s) <= _MAX_VALUE else s[:_MAX_VALUE - 1] + "…"


def _key(key) -> str:
    return json.dumps(key, sort_keys=True) if isinstance(key, (dict, list)) else str(key)


def _where(where) -> str:
    return " AND ".join(f"{c} {op} {_short(v)}" if op not in ("is_null", "not_null") else f"{c} {op}"
                        for c, op, v in where or [])


def record_lines(rec: dict) -> list:
    """The whole proof: a header, then each claim's question and its text, by section."""
    item, meta = rec.get("item") or {}, rec.get("meta") or {}
    claims = item.get("claims") or []
    unmodelled = [f"No proof model for this item type yet ({item.get('reason') or item.get('type')})."]
    if item.get("type") == "unmodelled" and not claims:
        return unmodelled + graph_lines(item, rec.get("leaves"))
    lines = [f"{plain(item.get('title'))} · {item.get('type')} · {len(claims)} claims · built {meta.get('now')} · "
             f"schema {meta.get('schema_version')}"]
    if item.get("type") == "unmodelled":
        lines += unmodelled                       # it still carries the alert's own claims (framework 0.2.0)
    sections = []
    for c in claims:
        if c.get("section") not in sections:
            sections.append(c.get("section"))
    for sec in sections:
        lines += ["", f"── {SECTION_TITLES.get(sec, sec)}"]
        for c in (c for c in claims if c.get("section") == sec):
            lines.append(f"[{c.get('kind')}] {c.get('q')}")
            lines.append(f"    {plain(c.get('spans'))}")
            if c.get("missing"):
                lines.append(f"    not recorded: {plain(c.get('missing'))}")
    lines += graph_lines(item, rec.get("leaves"))
    lines += ["", "Trace any claim:  torana alert <ID> proof --claim <CLAIM_ID>   "
                  f"(ids: {', '.join(c.get('id') for c in claims)})"]
    return lines


def _full(p, leaves) -> dict | None:
    """A slim graph pointer (no value/keys/q) read back from the record's leaves, where each is held once."""
    if not p or not p.get("slim"):
        return p
    same = (lambda x: x.get("where") == p.get("where")) if p.get("k") == "sel" else \
        (lambda x: _key(x.get("key")) == _key(p.get("key")) and x.get("path") == p.get("path"))
    return next((x for x in (leaves or {}).values() if x.get("k") == p.get("k") and x.get("table") == p.get("table")
                 and same(x)), p)


def _cite(p) -> str:
    """Where a graph node or edge was read from, in one short phrase."""
    if not p:
        return "no pointer"
    if p.get("k") == "cell":
        return f"{p.get('table')}[{_key(p.get('key'))[:48]}].{p.get('path')}"
    if p.get("k") == "sel":
        return f"{p.get('table')} where {_where(p.get('where'))[:60]} ({len(p.get('keys') or [])} rows)"
    if p.get("k") == "rule":
        return f"rule run {p.get('run')}.{p.get('out')}"
    return str(p.get("k"))


def graph_lines(item: dict, leaves: dict | None = None) -> list:
    """The item's Graph (the page's Graph tab): every edge as `from —label→ to`, then nodes no edge reaches, each
    with the row or selection it was read from. Kinds the code draws no graph for say so (the page hides the tab)."""
    g = item.get("graph") or {}
    nodes, edges = g.get("nodes") or [], g.get("edges") or []
    if not nodes:
        return ["", "── Graph: none (this item has no graph; the page shows no Graph tab)"]
    name = {n.get("id"): f"{n.get('t1')} ({n.get('t2')})" if n.get("t2") else str(n.get("t1")) for n in nodes}
    lines = ["", f"── Graph · {len(nodes)} nodes, {len(edges)} edges"]
    for e in edges:
        lines.append(f"  {name.get(e.get('from'))} —{e.get('label') or ''}→ {name.get(e.get('to'))}"
                     f"   [{e.get('style')}: {_cite(_full(e.get('p'), leaves))}]")
    linked = {x for e in edges for x in (e.get("from"), e.get("to"))}
    for n in nodes:
        if n.get("id") not in linked:
            lines.append(f"  {name[n.get('id')]}   [{_cite(_full(n.get('p'), leaves))}]")
    return lines


def claim_ids(rec: dict) -> list:
    return [c.get("id") for c in (rec.get("item") or {}).get("claims") or []]


def _pointers(claim: dict) -> list:
    """Every unique pointer behind a claim: its spans, its 'not recorded' spans, then its refs."""
    out, seen = [], set()
    ptrs = [s.get("p") for s in (claim.get("spans") or []) + (claim.get("missing") or [])]
    ptrs += [r.get("p") for r in claim.get("refs") or []]
    for p in ptrs:
        if not p:
            continue
        k = json.dumps(p, sort_keys=True, default=str)
        if k not in seen:
            seen.add(k)
            out.append(p)
    return out


def pointer_lines(rec: dict, p: dict, depth: int = 0, expanded: set | None = None) -> list:
    """One pointer, resolved against the record; a rule output expands into its inputs (to depth 3).
    A run is expanded once; later outputs of the same run point back to it (`expanded` is shared)."""
    expanded = set() if expanded is None else expanded
    pad = "    " * (depth + 1)
    queries = {q.get("q"): q for q in rec.get("queries") or []}
    k = p.get("k")
    if k == "cell":
        q = queries.get(p.get("q"))
        src = f"  ({p['q']}: {q.get('text', '')[:120]})" if q else ""
        return [f"{pad}{p.get('table')} · {_key(p.get('key'))} · {p.get('path')} = {_short(p.get('value'))}{src}"]
    if k == "sel":
        return [f"{pad}{p.get('table')} WHERE {_where(p.get('where'))}  → {len(p.get('keys') or [])} rows"]
    if k == "absent":
        return [f"{pad}{p.get('table')} {_key(p.get('key'))}: row not found"]
    if k == "meaning":
        return [f"{pad}{p.get('table')}.{p.get('column')}: {p.get('text')}"]
    if k == "now":
        return [f"{pad}clock {p.get('value')}"]
    if k == "rule":
        run = (rec.get("runs") or {}).get(p.get("run")) or {}
        value = (run.get("outputs") or {}).get(p.get("out"))
        lines = [f"{pad}rule {run.get('rule')} v{run.get('version')} ({p.get('run')}): {p.get('out')} = {_short(value)}"]
        if not run.get("inputs"):
            return lines
        if p.get("run") in expanded:
            lines.append(f"{pad}    (inputs of {p.get('run')} listed above)")
        elif depth + 1 < _RULE_DEPTH:
            expanded.add(p.get("run"))
            seen = set()
            for i in run["inputs"]:
                ik = json.dumps(i, sort_keys=True, default=str)
                if ik not in seen:
                    seen.add(ik)
                    lines += pointer_lines(rec, i, depth + 1, expanded)
        else:
            lines.append(f"{pad}    … {len(run['inputs'])} inputs (deeper than {_RULE_DEPTH} levels; --format json has all)")
        return lines
    if k == "llm":
        return [f"{pad}model text by {p.get('by')} (a label, not evidence)"]
    return [f"{pad}{_short(p)}"]


def claim_lines(rec: dict, claim_id: str) -> list:
    claim = next(c for c in (rec.get("item") or {}).get("claims") or [] if c.get("id") == claim_id)
    lines = [f"[{claim.get('kind')}] {claim.get('q')}", f"  {plain(claim.get('spans'))}"]
    if claim.get("missing"):
        lines.append(f"  not recorded: {plain(claim.get('missing'))}")
    lines.append("")
    lines.append("Behind it:")
    expanded: set = set()
    for p in _pointers(claim):
        lines += pointer_lines(rec, p, 0, expanded)
    return lines


def _reason(r: dict) -> str:
    kind = r.get("kind")
    if kind == "value_changed":
        return f"{kind}: {r.get('table')} · {_key(r.get('key'))} · {r.get('path')}: {r.get('then')} → {r.get('now')}"
    if kind == "membership_changed":
        return (f"{kind}: {r.get('table')} WHERE {_where(r.get('where'))}: {r.get('then')} → {r.get('now')} rows"
                f" (added {r.get('added')}, removed {r.get('removed')})")
    if kind == "row_gone":
        return f"{kind}: {r.get('table')} {_key(r.get('key'))}"
    if kind == "rule_changed":
        return f"{kind}: {r.get('rule')} v{r.get('then')} → v{r.get('now')} (or its code changed)"
    if kind == "clock_moved":
        return f"{kind}: {r.get('then')} → {r.get('now')}"
    rest = {k: v for k, v in r.items() if k != "kind" and v is not None}
    return f"{kind}: {_short(rest)}" if rest else str(kind)


def diff_lines(d: dict) -> list:
    counts = ", ".join(f"{n} {o}" for o, n in sorted((d.get("counts") or {}).items()))
    lines = [f"{counts or 'no claims'}  (then {d.get('then')} · now {d.get('now')})"]
    if d.get("then_schema") != d.get("now_schema"):
        lines.append(f"schema {d.get('then_schema')} → {d.get('now_schema')}")
    for cid, r in (d.get("claims") or {}).items():
        if r.get("outcome") == "unchanged":
            continue
        lines += ["", f"[{r.get('outcome')}] {cid}", f"    then: {r.get('then')}", f"    now:  {r.get('now')}"]
        lines += [f"    {_reason(x)}" for x in r.get("reasons") or []]
    return lines


def replay_line(res: dict) -> list:
    lines = [f"reproduced: {'yes' if res.get('reproduced') else 'no'} "
             f"({res.get('runs_replayed')}/{res.get('runs_then')} runs)"]
    if res.get("error"):
        lines.append(f"error: {res['error']}")
    elif not res.get("reproduced"):
        lines.append(f"rule outputs identical: {res.get('rule_outputs_identical')} · "
                     f"claims: {res.get('claim_outcomes')}")
    return lines


def echo(lines) -> None:
    click.echo("\n".join(lines))


def read_record(path: str) -> dict:
    """A saved proof record (the JSON `torana alert <ID> proof --save FILE` wrote)."""
    try:
        with open(path) as f:
            rec = json.load(f)
    except ValueError as e:
        raise click.UsageError(f"{path} is not JSON: {e}")
    if not isinstance(rec, dict) or not isinstance(rec.get("meta"), dict) or not isinstance(rec.get("item"), dict):
        raise click.UsageError(f"{path} is not a proof record (needs meta and item; save one with "
                               "`torana alert <ID> proof --save FILE`)")
    return rec


def save(path: str, obj: dict) -> None:
    with open(path, "w") as f:
        json.dump(obj, f, indent=1, ensure_ascii=False)
    click.echo(f"saved {path}", err=True)
