"""Text rendering for an item's assessments (`torana alert <ID> assessment`).

An assessment is the answer to a named question about an item (today: effort, a range of days), with what it rests on:
how the days add up, which checks it rests on, and which checks would sharpen it. It is what
GET /api/v1/datalake/proof/alerts/{id}/assessment returns. Spec: pantheon-datalake/docs/PROOF_ASSESSMENTS_SPEC.md
§ 3.4.2. Presentation only: every number, every count and every sentence is printed as the platform returned it;
nothing is recomputed here. JSON output passes the body through untouched.
"""
from __future__ import annotations

_TITLE_WIDTH = 20
_PART_WIDTH = 11
_WHY_WIDTH = 42


def _g(x) -> str:
    """A number of days as the proof layer prints it (0.0 → "0", 2.0 → "2", 0.25 → "0.25")."""
    return "—" if x is None else f"{float(x):g}"


def no_assessment(body: dict) -> str:
    return f"No assessment for this kind of item yet ({body.get('item_type')})"


def _estimate_text(a: dict) -> str:
    """The estimate claim's own sentence (for an item that could not be estimated: "Not estimated: …")."""
    claims = a.get("claims") or []
    c = next((c for c in claims if c.get("section") == a.get("question") and c.get("kind") in ("assessed", "missing")),
             None) or next((c for c in claims if c.get("section") == a.get("question")), None)
    return (c or {}).get("text") or "Not estimated."


def _priced(a: dict) -> bool:
    return bool(a.get("line")) and (a.get("estimate") or {}).get("low") is not None


def _row(label: str, why, days) -> str:
    return f"  {label:<{_PART_WIDTH}}{str(why or ''):<{_WHY_WIDTH}}{_g(days)}".rstrip()


def _breakdown(est: dict) -> list:
    """How the days add up: one row per part, a rule, their sum, then the platform's sentence on why it is a range."""
    width = 2 + _PART_WIDTH + _WHY_WIDTH
    lines = ["How we got this".ljust(width) + "days"]
    lines += [_row(str(p.get("part") or "").capitalize(), p.get("why"), p.get("days")) for p in est.get("parts") or []]
    lines.append("  " + "─" * (width + 2))
    lines.append(_row("Estimate", "", est.get("low")))
    if est.get("range_note"):
        lines += ["", est["range_note"], ""]
    return lines


def _pass_line(mark: str, p: dict, text, star: bool = False) -> str:
    title = f"{p.get('title')}{' *' if star else ''} ".ljust(_TITLE_WIDTH)       # padded to 20, never glued
    return f"  {mark} {title}{text or ''}".rstrip()


def based_on(cov: dict) -> str:
    """How many checks the answer is based on, and how many more nobody can run yet (the platform's own count)."""
    done, n = cov.get("done"), cov.get("not_available")
    if not n:
        return f"Based on {done} of {cov.get('total')} checks."
    return (f"Based on {done} check{'' if done == 1 else 's'}. "
            f"{n} more {'is' if n == 1 else 'are'} not available yet.")


def assessment_lines(a: dict) -> list:
    """One assessment: the headline, how many checks it is based on, how the days add up, what it rests on, and what
    is not checked yet. ⛔ A missing check is shown as what is NOT KNOWN (its `gap`). Its `ask` (an instruction) is
    printed only when the platform says it can be acted on (`ask_ready`), under "What you can do now". Each group
    keeps the registry's order."""
    cov = a.get("coverage") or {}
    passes = cov.get("passes") or []
    priced = _priced(a)
    lines = [f"{a.get('title')}   ◈ assessed   {a.get('short') or a.get('line')}" if priced
             else f"{a.get('title')}   {_estimate_text(a)}"]
    lines.append(based_on(cov))
    if priced:
        lines += _breakdown(a.get("estimate") or {})
    texts = {c.get("id"): c.get("text") for c in a.get("claims") or []}
    # `rests_on` is the platform's wording per check; a server without it gives the claim's own text.
    rests = a.get("rests_on")
    if rests is None:
        rests = [{**p, "text": texts.get(p.get("claim"))} for p in passes if p.get("done")]
    if rests:
        lines.append("What it rests on")
        lines += [_pass_line("✓", r, r.get("text")) for r in rests]
    missing = [p for p in passes if not p.get("done")]
    ready, later = [p for p in missing if p.get("ask_ready")], [p for p in missing if not p.get("ask_ready")]
    if ready:
        lines.append("What you can do now")
        lines += [_pass_line("○", p, p.get("ask")) for p in ready]
    if later:
        lines.append("Not checked yet:")
        ordered = [p for p in later if p.get("required")] + [p for p in later if not p.get("required")]
        lines += [_pass_line("○", p, p.get("gap"), star=bool(p.get("required"))) for p in ordered]
        if any(p.get("required") for p in later):
            lines.append("  * matters most to the accuracy of this estimate")
    return lines


def body_lines(body: dict) -> list:
    """Every assessment of the item, a blank line between two."""
    lines: list = []
    for a in body.get("assessments") or []:
        lines += ([""] if lines else []) + assessment_lines(a)
    return lines
